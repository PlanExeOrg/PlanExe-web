## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers address the core tensions: evidence versus cash (Shielding Proof Standard, Year-1 Burn Sequencing), demand certainty versus commitment speed (Presale and Demand Validation, Buyer Segment Sequencing), and design integrity versus market breadth (Enclosure Architecture, Threat Narrative and Claim Scope). Production, compliance, gate definition, sourcing and fulfilment are largely downstream. No key dimensions are clearly missing, though pricing and unit economics are not explicit levers.

### Decision 1: Shielding Proof Standard
**Lever ID:** `4c01db71-e333-4832-a2b3-319b70079b4c`

**The Core Decision:** Sets the evidentiary basis for every performance claim: which method, which lab, which frequency range, and how much is published. Success metrics are a repeatable attenuation figure across the claimed band, acceptance by critical-infrastructure procurement reviewers, few failed lab runs, and test cost per design revision kept within the Year-1 budget.

**Why It Matters:** Defines how shielding effectiveness is measured and published, which sets the credibility ceiling for every sales claim. A recognised third-party method (for example IEEE 299.1 for small enclosures, applicability not verified) costs more and takes longer, but supports critical-infrastructure procurement. A cheaper in-house method speeds iteration but weakens trust with sceptical buyers.

**Strategic Choices:**

1. Commission an accredited EMC laboratory to test production-representative units against a recognised enclosure-shielding standard and publish the full frequency-sweep report with every unit sold.
2. Build an in-house shielding test rig for rapid design iteration, then buy a single accredited lab validation only for the final design and use it as the public claim.
3. Release a public open-verification programme where independent engineers and hobbyist testers measure sample units, and publish all results, including unfavourable ones, as a trust-building differentiator.

**Trade-Off / Risk:** Third-party testing buys credibility with infrastructure buyers, but each failed lab run during design iteration burns scarce Year-1 budget, so the test plan must be staged around a design already proven on an in-house rig.

**Strategic Connections:**

**Synergy:** Amplifies Presale and Demand Validation Mechanism, because a published sweep report gives infrastructure pilots and sceptical prepper communities a verifiable basis to commit. It also supports Compliance and Liability Posture by backing claims with documented evidence.

**Conflict:** Competes with Year-1 Burn Sequencing, since accredited lab runs are costly and lumpy. It also depends on Enclosure Architecture being stable: seam or lid changes after testing force expensive re-qualification.

**Justification:** *Critical*, Critical because it sets the credibility ceiling for every sales claim and links to Presale, Compliance, Enclosure Architecture and Year-1 Burn. It controls the core trade-off between proof rigor (lab cost, time) and scarce Year-1 cash, and gates infrastructure procurement.

### Decision 2: Threat Narrative and Claim Scope
**Lever ID:** `55eea0d1-5a33-452c-9505-307ea668c827`

**The Core Decision:** Chooses the story and the claims the product is sold on, which fixes the target audience, price tolerance and legal exposure. A passive box protects only stored spare devices, so the scope statement determines whether buyers feel informed or misled. Key metrics are claim-to-evidence match, size of the reachable market, complaint and return rates, and message consistency across channels.

**Why It Matters:** Determines which threat the product is sold against: solar storm, electromagnetic pulse, or everyday RF exposure. A passive enclosure protects only what is placed inside it, and a Carrington-class storm mainly threatens grid-connected equipment, so a narrow solar-storm claim risks being technically weak. Broader positioning widens the addressable market but dilutes the brand and raises claim-substantiation exposure.

**Strategic Choices:**

1. Position the product around solar-storm and pulse resilience for preppers, with explicit scope statements that it protects stored spare devices rather than grid-connected equipment.
2. Reposition the same enclosure as a multi-use RF-isolation product for privacy, travel, key-fob security and digital-forensics buyers, with disaster preparedness as one use case.
3. Lead with a documented continuity-of-operations kit for critical-infrastructure operators, bundling the enclosure with a written spare-device recovery procedure instead of selling a standalone box.

**Trade-Off / Risk:** A tighter, honest claim scope reduces consumer-law and reputational risk, but a niche prepper narrative may cap volume well below what the €750k plan needs unless a second, steadier market is opened.

**Strategic Connections:**

**Synergy:** Directs Buyer Segment Sequencing, since the narrative defines which segment is approached first. It also pairs with Shielding Proof Standard, because narrower and honest claims need less demanding proof to be credible.

**Conflict:** Broad or multi-use positioning raises the claim-substantiation burden under Compliance and Liability Posture. A narrow prepper narrative can also undercut the volumes that Presale and Demand Validation Mechanism needs to unlock the second tranche.

**Justification:** *High*, High because it fixes the target audience, addressable market size and legal exposure. It directs Buyer Segment Sequencing, pairs with Shielding Proof Standard, and conflicts with Compliance and Presale volume needs. A niche prepper claim may cap volume below plan needs.

### Decision 3: Enclosure Architecture
**Lever ID:** `fb23f166-d427-4f20-9a96-916716cbe2a5`

**The Core Decision:** Fixes the physical form of the single SKU: materials, seam and closure method, internal fit and the wear-part strategy. It determines shielding margin, weight, freight cost, tooling spend and the range of devices accommodated. Key metrics are attenuation retained after repeated lid cycles, fit across common laptop sizes, unit bill of materials and shipped weight.

**Why It Matters:** Sets the physical design: a rigid sheet-metal box, a flexible conductive-fabric pouch, or a hybrid. Rigid metal with conductive gaskets suits Tallinn's fabrication base and high shielding, but seam and lid integrity dominate performance and degrade with wear. The choice drives tooling cost, weight, shipping cost and how many laptop sizes one SKU can fit.

**Strategic Choices:**

1. Develop a rigid folded-aluminium or steel enclosure with a continuous conductive-gasket lid seam, sized to fit the largest common laptop and several phones in one SKU.
2. Develop a nested double-wall enclosure with an insulating liner between the shells to improve shielding margin and prevent contact between devices and metal.
3. Develop a hybrid with a rigid sheet-metal frame and a replaceable seal cartridge, so the wear part can be swapped or re-verified without replacing the full unit.

**Trade-Off / Risk:** A replaceable seal improves long-term shielding integrity, but every added interface is another potential leakage path that must be re-qualified, and a single size may fit no customer's devices well.

**Strategic Connections:**

**Synergy:** Rigid metal variants fit the Tallinn Production Model, since laser-cut and bent sheet metal matches local fabrication skills. A well-defined seam also makes Shielding Proof Standard testing more repeatable and cheaper.

**Conflict:** Added interfaces such as replaceable seals raise re-qualification cost under Shielding Proof Standard and complicate Cross-Border Fulfilment Footprint through heavier, bulkier or multi-part shipments. Single-SKU sizing also limits fit for some customers.

**Justification:** *High*, High because seam and lid design drives shielding margin, tooling cost, weight and freight. It anchors the Tallinn Production Model and test repeatability, and late changes force costly re-qualification. It is the physical foundation of the single SKU.

### Decision 4: Presale and Demand Validation Mechanism
**Lever ID:** `8756bf10-cb84-437a-aaa4-a932db815f5f`

**The Core Decision:** Defines the evidence of demand that must exist before major cash is committed to tooling and inventory. It selects the channel for early commitments: deposits, paid pilots or retailer wholesale. Key metrics are committed orders against a stated threshold (proposed), deposit conversion, refund exposure, pilot-to-procurement conversion time and the contribution of presale cash to Year-1 funding.

**Why It Matters:** Controls how demand is proven before the bulk of cash is spent. Refundable-deposit presales build an early signal and fund tooling but create refund liabilities and delivery-date pressure. Pilots with infrastructure buyers produce slower, larger and more credible orders. Prepper communities are vocal but price-sensitive and sceptical of marketing.

**Strategic Choices:**

1. Run a refundable-deposit presale through prepper forums and communities, with a stated minimum order threshold that must be met before tooling money is committed.
2. Sign paid pilot agreements with a small number of critical-infrastructure operators, using their test feedback and reference status to unlock wider procurement.
3. Sell through established preparedness and survival retailers on consignment-free wholesale terms, using their audience and fulfilment instead of building a direct storefront.

**Trade-Off / Risk:** Presale volume from enthusiast communities is a weak proxy for infrastructure procurement, which has long sales cycles that may not close within Year-1 and can leave the cash-flow gate for the second tranche unmet.

**Strategic Connections:**

**Synergy:** Feeds Tallinn Production Model by gating when dedicated tooling is released, and informs Buyer Segment Sequencing by showing which segment commits first. Strong presale cash also eases Year-1 Burn Sequencing.

**Conflict:** Refundable deposits create delivery pressure that clashes with the testing time required by Shielding Proof Standard. Slow infrastructure pilots may leave the Cash-Flow Gate Measurement Convention unmet, so deposits and gate timing must be aligned.

**Justification:** *Critical*, Critical because it is a hub: it gates tooling release, informs segment choice, eases Year-1 burn and interacts with the cash-flow gate. It controls the central tension between proving demand cheaply and delivery pressure against testing time.

### Decision 5: Year-1 Burn Sequencing
**Lever ID:** `4599bd07-0660-4c7e-873d-06157fe11e62`

**The Core Decision:** Orders the €400k Year-1 budget (user constraint) across design, test-lab fees, tooling, first production and marketing so that irreversible commitments come only after evidence. It is the main control on option value: how long redesign remains affordable before hard tooling locks the design. Success metrics: cash remaining at each test milestone, months of runway, cost of any redesign or retest, and time to first revenue.

**Why It Matters:** How the €400k Year-1 budget (user constraint) is ordered across design, test-lab fees, tooling, first production run and marketing determines how long the company can run before commitments become irreversible. Spending early on hard tooling gives production readiness but removes flexibility if test results force a redesign. Delaying it protects options but pushes first revenue later. The follow-on tranche condition stays unchanged.

**Strategic Choices:**

1. Front-load design, prototyping and test-lab work with soft tooling, and defer hard tooling and the main production run until pre-test results confirm the design and presales exist.
2. Commit early to production-grade tooling and a first batch to shorten time to revenue, accepting that a failed certification test would leave sunk cost in tooling that needs rework.
3. Hold a defined reserve of the Year-1 budget (proposed share, to be set in planning) outside all committed spending until the first confirmed orders, using the reserve to absorb redesign or retest costs.

**Trade-Off / Risk:** Sequencing spend later protects against redesign but delays revenue, and an uncommitted reserve can be consumed by overruns, leaving too little runway to reach the positive cash flow the second tranche requires.

**Strategic Connections:**

**Synergy:** Amplifies Shielding Proof Standard and Enclosure Architecture, because holding hard tooling until pre-test results arrive lets test findings shape the design cheaply. It also pairs with Presale and Demand Validation Mechanism by tying commitment to deposits.

**Conflict:** Trades off against Cash-Flow Gate Measurement Convention and Buyer Segment Sequencing: delaying tooling protects against redesign but postpones revenue, which makes reaching the positive cash flow needed for the €350k follow-on harder.

**Justification:** *Critical*, Critical because it is the main control on option value, ordering the €400k (user constraint) so irreversible commitments follow evidence. It connects to proof, architecture, tooling, presale, compliance, hiring and the cash-flow gate, governing the speed-versus-flexibility trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Tallinn Production Model
**Lever ID:** `067c9de7-dca5-4402-933d-94fc940d48e4`

**The Core Decision:** Governs how production is organised in and around Tallinn: tooling type, capital commitment, supplier concentration and the point at which volume justifies dedicated tooling. It balances unit cost against flexibility during design iteration and certification. Key metrics are tooling spend before demand is confirmed, unit cost trajectory, lead time, defect rate and fabricator capacity headroom.

**Why It Matters:** Decides how much capital is locked into tooling and how tightly production is tied to Tallinn suppliers. Soft tooling with laser cutting and CNC bending keeps early cost and design-change risk low but raises unit cost. Hard tooling lowers unit cost only if volumes are real. Over-reliance on a local ecosystem also concentrates supplier risk, and specialised gasket materials may need importing (not verified).

**Strategic Choices:**

1. Contract an existing Tallinn precision-metal fabricator for low-volume batches using flexible laser-cut and bent tooling, deferring dedicated tooling until pre-orders confirm demand.
2. Invest early in dedicated progressive or stamping tooling in Tallinn to reach a lower unit cost, accepting that design changes after certification become expensive.
3. Split production so that the metal shell is made in Tallinn while gaskets and finishing are sourced from qualified specialist suppliers elsewhere, with a second-source plan for each critical part.

**Trade-Off / Risk:** Soft tooling protects cash against a failed launch, but if demand proves real, high unit costs and fabricator capacity limits can cap margins just when the follow-on tranche is being judged.

**Strategic Connections:**

**Synergy:** Works with Presale and Demand Validation Mechanism: a minimum order threshold can trigger tooling release only when demand is proven. It also supports Year-1 Burn Sequencing by keeping early capital flexible.

**Conflict:** Early hard tooling conflicts with Enclosure Architecture and Shielding Proof Standard, because design changes after certification become costly. Soft tooling's higher unit cost can weaken margins when the Cash-Flow Gate Measurement Convention is applied.

**Justification:** *Medium*, Medium because tooling type governs capital lock-in and unit cost, and it links to Presale gating and Year-1 Burn. Its main choice (soft tooling until demand is proven) is largely determined by the burn and presale levers, so it is more an execution consequence.

### Decision 7: Compliance and Liability Posture
**Lever ID:** `5416083a-323b-4b93-b628-13f717f2b9ad`

**The Core Decision:** Defines how the company limits legal and reputational exposure when selling a product whose value only shows in a rare, extreme event. Scope covers claim wording, determination of applicable EU product-safety rules (not verified), voluntary certification, warranty terms and insurability. Success metrics: no claim exceeding measured data, no regulatory challenge, insurance obtainable at acceptable premium, and certification acting as a procurement qualifier.

**Why It Matters:** Sets the legal approach to marketing a safety-adjacent product. A passive enclosure may fall outside the EMC Directive and CE marking, but general product-safety and consumer-protection rules still apply (applicability not verified). Performance claims that fail in a real event create reputational and warranty exposure that is difficult to insure.

**Strategic Choices:**

1. Obtain a legal opinion on which EU product rules apply, and limit marketing claims strictly to the measured shielding values and tested frequency range.
2. Pursue voluntary conformity documentation and a third-party quality certification beyond legal minimums, using it as a procurement qualifier for infrastructure buyers.
3. Offer an annual shielding re-verification service and a limited warranty tied to seal condition, shifting liability toward documented use and creating a recurring revenue stream.

**Trade-Off / Risk:** Voluntary certification and warranty services strengthen buyer trust, but they add fixed costs and long-tail obligations that a single-SKU, self-funded company may struggle to carry if volumes stay small.

**Strategic Connections:**

**Synergy:** Strengthens Shielding Proof Standard, because claims limited to measured values give the legal posture an evidential base. Also supports Buyer Segment Sequencing by supplying the documentation packs critical-infrastructure buyers require.

**Conflict:** Competes with Year-1 Burn Sequencing for scarce cash, since legal opinions, voluntary certification and warranty reserves add fixed costs. It also narrows Threat Narrative and Claim Scope by restricting persuasive marketing language.

**Justification:** *Medium*, Medium because it limits legal and reputational exposure and supplies documentation for infrastructure buyers, but it mostly follows from the proof standard and claim scope. It adds fixed costs competing with Year-1 cash, so it needs sizing rather than strategic leadership.

### Decision 8: Buyer Segment Sequencing
**Lever ID:** `dec973f3-e4e6-40f8-8cc8-9600b526b21c`

**The Core Decision:** Decides which buyer group funds the company first and so shapes the revenue timing, proof requirements and unit economics of the whole launch. The choice sets how quickly presale deposits arrive, how much documentation is needed, and which reference customers exist for later sales. Success metrics: first confirmed orders within the Year-1 window, average order size, presale conversion rate and sales-cycle length.

**Why It Matters:** Choosing which buyer group to approach first sets the sales cycle length, the proof demanded, and the order sizes. Prepper networks buy quickly in small units but are price-sensitive and skeptical. Critical-infrastructure buyers pay for documentation but move slowly through procurement, which stretches the time to the positive cash flow that unlocks the follow-on tranche.

**Strategic Choices:**

1. Lead with prepper networks and online communities to generate fast small-unit presales, then use that sales record as a reference when approaching infrastructure buyers.
2. Lead with a small number of critical-infrastructure and emergency-planning buyers using pilot units and documentation packs, accepting slower orders in exchange for larger, repeatable contracts.
3. Lead with intermediaries such as emergency-preparedness retailers, insurers and civil-protection consultants who bundle the enclosure into their own offers and carry the sales effort for a margin share.

**Trade-Off / Risk:** Sequencing by segment looks tidy on paper, but prepper volume may be too small and infrastructure procurement too slow, so either path can leave the cash-flow gate unmet for longer than the Year-1 burn allows.

**Strategic Connections:**

**Synergy:** Works with Presale and Demand Validation Mechanism, since the lead segment determines where deposits are collected and how credible the reference record is. Also guides Cross-Border Fulfilment Footprint by showing where stock is needed.

**Conflict:** Pulls against Cash-Flow Gate Measurement Convention, because slow infrastructure procurement delays delivered-unit receipts while prepper volumes may be too small. It also strains Year-1 Burn Sequencing if the runway must stretch for long sales cycles.

**Justification:** *High*, High because the lead segment sets sales-cycle length, order size, proof demanded and time to the positive cash flow that unlocks the follow-on. It conflicts with the Cash-Flow Gate and Year-1 Burn, and guides presale and fulfilment choices.

### Decision 9: Cross-Border Fulfilment Footprint
**Lever ID:** `15fc0782-3888-48e9-826d-3a746c279d70`

**The Core Decision:** Sets the physical and fiscal route from the Tallinn workshop to European buyers: where stock is held, who ships, and how VAT, customs and returns are handled. It governs delivery promise, working capital tied in inventory and per-unit logistics cost for a dense metal product. Success metrics: delivery lead time by region, landed cost per unit, return rate, and days of inventory held.

**Why It Matters:** Where inventory sits and who ships it determines delivery time, customs friction, VAT handling and returns across European markets. Shipping heavy metal goods from Tallinn is straightforward within the EU but adds cost to distant or non-EU destinations. The choice also decides how much cash is tied up in stock before orders are confirmed.

**Strategic Choices:**

1. Ship all orders directly from the Tallinn production site, keeping stock and handling in one place and accepting longer, costlier delivery to distant markets.
2. Contract a third-party logistics provider with EU warehousing to hold small buffer stock, reducing delivery times while adding storage fees and some working capital in inventory.
3. Build to order against confirmed presales only, with batch shipments to buyers or distributors, so that no unsold stock is held but delivery lead times are long.

**Trade-Off / Risk:** Build-to-order protects cash but turns long lead times into a sales objection for buyers who want protection now, while buffer stock in third-party warehouses ties up the working capital the staged funding cannot spare.

**Strategic Connections:**

**Synergy:** Complements Tallinn Production Model, since a single production site pairs naturally with centralised or batch shipping. It also supports Presale and Demand Validation Mechanism by letting delivery dates be quoted credibly to buyers.

**Conflict:** Conflicts with Cash-Flow Gate Measurement Convention and Year-1 Burn Sequencing: buffer stock in third-party warehouses ties up cash and can delay the positive-cash-flow gate, while build-to-order lengthens delivery lead times.

**Justification:** *Low*, Low because it is largely downstream and tactical: a single SKU shipped from one Tallinn site makes the choice fairly straightforward. It affects working capital and lead times, but is driven by Presale, Segment and Production choices.

### Decision 10: Cash-Flow Gate Measurement Convention
**Lever ID:** `c3388353-87b5-436a-8fa2-ff57303563a4`

**The Core Decision:** Fixes the accounting rule that decides when the €350k follow-on (user constraint) is released, including what counts as cash flow, whether presale deposits count, and the measurement window. It is a governance control protecting the founder's personal capital from being committed on weak signals. Success metrics: a rule written before launch, unambiguous to audit, and resistant to timing distortions or manipulation.

**Why It Matters:** The €350k follow-on remains conditional on positive cash flow, but the plan must define what counts as cash flow and over what window. The convention determines whether presale deposits, which are cash received before the product is delivered, can unlock the tranche. A lenient reading releases money earlier but risks funding the second stage from obligations that are still unfulfilled.

**Strategic Choices:**

1. Measure positive cash flow on trailing-quarter operating receipts from delivered units only, excluding presale deposits, so the tranche opens only on proven fulfilment.
2. Count presale deposits as inflows but net them against the committed cost of fulfilling those orders, so the test reflects real surplus rather than gross cash received.
3. Measure cumulative operating cash flow from first shipment onward on a rolling basis, so a single strong or weak month cannot open or block the gate.

**Trade-Off / Risk:** A stricter definition guards the founder's personal capital, but it may delay the second tranche past the point where inventory and marketing momentum are needed, while a looser one lets deposits masquerade as profit.

**Strategic Connections:**

**Synergy:** Reinforces Presale and Demand Validation Mechanism by clarifying how deposits are treated, so presale design and gate logic agree. It also gives Year-1 Burn Sequencing a clear target for when to commit follow-on spending.

**Conflict:** Constrains Buyer Segment Sequencing and Cross-Border Fulfilment Footprint: a strict delivered-units rule penalises slow infrastructure sales and build-to-order lead times, while a lenient rule risks funding stage two from unfulfilled obligations.

**Justification:** *Medium*, Medium because it is a governance rule protecting the founder's capital for the €350k tranche (user constraint). It affects presale, segment and fulfilment choices, but it is a one-off definition decision rather than an ongoing driver of outcomes.

### Decision 11: Engineering Capability Sourcing
**Lever ID:** `afdf0df2-7683-4cc3-9ea1-b0edce21e76d`

**The Core Decision:** Determines how RF and shielding expertise enters a founder-led company: a salaried engineer, a milestone-paid EMC consultancy, or an Estonian university or lab partnership. It governs time to a test-ready prototype, ownership of design knowledge and intellectual property, and fixed-cost exposure. Success metrics: months to first prototype passing internal shielding tests, cost per milestone, and IP clarity before work starts.

**Why It Matters:** The product depends on RF design and measurement competence that a founder-led team may lack. This lever decides whether that capability is hired, contracted, or borrowed from an academic or lab partner. Each route changes how quickly the first test-ready prototype appears and who holds the design knowledge afterwards.

**Strategic Choices:**

1. Hire one full-time RF and shielding engineer in Tallinn, accepting a fixed salary cost in exchange for retained in-house design knowledge.
2. Contract an independent EMC consultancy on a milestone basis, paying only for defined deliverables and keeping fixed headcount at zero during Year 1.
3. Co-develop the enclosure with a university or research lab in Estonia, trading shared access to measurement facilities for agreed publication or credit rights.

**Trade-Off / Risk:** A lab partnership could give low-cost access to measurement chambers and independent credibility, but academic timelines and publication expectations may not match a commercial launch schedule, and ownership of results must be settled before work begins.

**Strategic Connections:**

**Synergy:** Strengthens Shielding Proof Standard, because in-house or partner expertise helps define credible test methods and pass accredited measurement. It also accelerates Enclosure Architecture, where RF design choices on seams, gaskets and apertures drive shielding performance.

**Conflict:** Constrains Year-1 Burn Sequencing, since a full-time hire adds fixed salary cost before presale revenue arrives. A lab partnership's academic timelines and publication expectations can conflict with Presale and Demand Validation Mechanism delivery dates.

**Justification:** *Medium*, Medium because RF competence speeds the first test-ready prototype and strengthens proof and architecture. Its fixed-cost conflict with Year-1 Burn matters, but it is an enabling input, and a milestone-based option can limit its strategic risk.
