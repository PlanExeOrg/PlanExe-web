_Consistency: first pass found 2 high / 6 medium / 0 low contradictions. Repair: round 1: 38 edits → 0 high / 7 medium. Shown below: the final check of the repaired documents (0 high / 7 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the written cash-flow gate convention signed by the founder and the external advisor, with the deposit share and deposit-use rule decided, before any presale deposit is taken? | Signed by Month 0.5: deposits excluded as liabilities in a separate earmarked account; gate = delivered-and-paid receipts - direct unit costs - recurring opex >= EUR 25k (proposed threshold); ambiguous band -5k to +25k with a 90-day extension; deposit share of the EUR 149 price and whether deposits may pay unit cost stated. | Signed convention document and earmarked-account confirmation, Month 0.5 to Month 1. | Delay the presale launch (Month 1) until signed. Do not take deposits under an undefined rule; this is the cheapest point to stop. |
| 2 | Do the signed accredited-lab statement of work and the legal opinion keep lab cost, standard and schedule inside the funded plan? | Fixed lab cost EUR 15k, IEEE 299.1 or equivalent confirmed, samples Month 4, report Month 5 (latest Month 6); legal opinion (Month 1) finds no CE/EMC Directive work, or a funding source is named for the 10-30k (estimate) gap. Lab quote of EUR 20k or more (estimate) is a tripwire. | Lab pre-engagement results (Month 0.5), signed statement of work (Month 1.5), legal opinion (Month 1), insurer terms (Month 2.5). | Switch to the backup lab or delay. If the unfunded lab or CE gap is above the 15k (estimate) stop-rule level with no signed funding decision (Month 3 for CE, Month 6 for lab), downsize (raise the reserve to 30k by cutting marketing 10k) or stop. |
| 3 | Do written Tallinn quotes confirm a unit cost low enough to hold the gate economics, with capacity for batch 1? | Unit cost <= EUR 77 (estimate; baseline 70 + freight 12), capacity reservation for 800 units, gasket lead time <= 3 weeks; payment terms with no more than 50% upfront (proposed threshold). | Fixed-price quotes from 2-3 fabricators and 2 gasket suppliers (Month 1); secondary-fabricator trial (Month 2). | Activate the secondary fabricator. If no qualified source reaches <= EUR 77 by Month 7, the 5.25k gate headroom is gone: resize batch 1, reprice, or stop. |
| 4 | Does early demand data show a mix and price that can plausibly clear the gate? | At Month 3: prepper share of deposits <= 70%, presale conversion >= 40%, average realised price >= EUR 120 (proposed thresholds). The gate itself needs about 672 units per quarter at EUR 67 margin, which the EUR 120 floor does not deliver. This threshold needs repair before it is used. | Weekly segment tracker, landing-page tests and buyer interviews (Months 1-3); infrastructure pilot agreements (10-20 units at EUR 84, Month 3). | Reallocate EUR 10-15k to infrastructure and privacy segments and re-test. If the mix stays prepper-heavy (margin about EUR 15, gate missed by 33.75k), withhold tooling and review wind-down. |
| 5 | Are net presale deposits at least EUR 80k and does the lab report confirm the design, so hard tooling can be released? | Net deposits after refunds >= EUR 80k (target EUR 120k) AND accredited lab report/pre-test confirms the design at the Month 6 decision; cumulative refunds <= 15% by Month 8. | Earmarked-account reconciliation and lab report (Month 5 to Month 6); refund log to Month 8. | No hard tooling. Extend presale to Month 8 at most with a pivot. If still below EUR 80k at Month 8, the tranche is expected to be withheld and the founder reviews wind-down. A lab re-test (report about Month 7) means delay and a likely 90-day gate extension. |
| 6 | Does the trailing-quarter operating cash surplus clear the gate so the EUR 350k follow-on can be released? | >= EUR 25k for Months 9-12 (receipts from delivered and paid units - direct unit costs - EUR 20k recurring opex), deposits excluded. Base case 750 units gives EUR 30.25k. Below -5k fails; -5k to +25k allows a 90-day extension. Sign-off by founder and advisor at Month 12.5. | Month 9-12 ledger, reconciliation of deposits versus receipts, advisor sign-off (Month 12.5). | Between -5k and +25k: extend 90 days and re-measure. Below -5k: tranche withheld, and the founder decides on wind-down or an extension with own funds. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: premortem A2; executive summary Overall Takeaway; review_plan KPI 1 / Review 2 #2 (and canonical demand_pivot_triggers for the floor)
    canonical: gate_arithmetic = Gate pass needs 672 units per quarter at EUR 67 contribution; 750 units give EUR 30.25k
    observed:  EUR 120 realised price holds EUR 67 contribution; EUR 50-67 margin range passes
HIGH CF-002  document: pitch (Metrics, Call to Action) and review_plan Review 13 #3; canonical_facts lacks the decision
    canonical: batch1_and_year1_volume = 1,500 units: 750 in Months 7-8 and 750 in Months 9-12
    observed:  800 units batch 1 delivered by Month 8; presale cutoff Month 8 with delivery Months 6-9
HIGH CF-003  document: pitch
    canonical: deposit_use_open_decision = OPEN: deposit share of unit price and whether deposits may pay unit cost
    observed:  deposits of EUR 149 per unit; EUR 120 effective with deposit timing
MEDIUM CF-004  document: canonical_facts (design_milestones)
    canonical: design_milestones = Month 5 tooling decision gate; first batch committed Month 6
    observed:  hard-tooling gate at Month 6 with deposits and lab report; Month 5 'decision gate to commit tooling'
MEDIUM CF-005  document: canonical_facts (unbudgeted_items_absorbed vs recurring_opex_eur); review_plan Review 11 #2
    canonical: unbudgeted_items_absorbed_eur = Legal 2-5k, LCA 2-5k, premium (not estimated), part-time ops 5-8k funded inside the 75k line
    observed:  premium 'unfunded line item within the 75k'; recurring opex 80k per year including insurance 8k
MEDIUM CF-006  document: review_plan (Reviews 4, 12, 13, 15); self_audit item 17
    canonical: unit_cost_and_margin_eur = Contribution = 149 - 82 = 67 per unit (estimate)
    observed:  EUR 15-30k = 100-200 units at EUR 67 margin
MEDIUM CF-007  document: review_plan Reviews 9, 10, 11, 14
    canonical: production_line_composition_eur = 160k = tooling 30k + gasket stock 7k + 105k units + 18k freight; headroom 0k
    observed:  50% of unit cost = EUR 75; 135k left for tooling and batch-2 labor/overhead
MEDIUM CF-008  document: self_audit item 8
    canonical: gate_arithmetic = Surplus = units x 67 - 20,000
    observed:  900 units = EUR 48.25k; margin EUR 40-57; reduction EUR 7.5-20k
MEDIUM CF-009  document: self_audit items 2 and 19
    canonical: demand_pivot_triggers = Prepper > 70% pivot; conversion < 40%; price < EUR 120 halts presale marketing
    observed:  halt if < EUR 115; infrastructure >= 35% and privacy >= 25%
MEDIUM CF-010  document: self_audit item 19; review_plan Review 16
    canonical: year1_budget_allocation_eur = design/prototyping 70k + rig 40k + lab 15k + soft tooling 20k + production 160k + 75k + reserve 20k
    observed:  target burn <= EUR 33k/month; freeze > 37k
MEDIUM CF-011  document: review_plan Reviews 2, 4, 5
    canonical: deposit_accounting_rule = Deposits are liabilities, never gate cash; refund cap 15% by Month 8
    observed:  refund spike in Months 10-12 consumes presale deposits
MEDIUM CF-012  document: self_audit item 13
    canonical: month05_prerequisites = Signed consultancy/university milestones by Month 0.5
    observed:  lock a signed milestone agreement with the chosen consultant by Month 1
```

### 1. Realised-price floor and margin range vs gate arithmetic (🔴 High) — needs a project decision

- **premortem A2; executive summary Overall Takeaway; review_plan Review 6 KPI 1 and Review 2 #2:** Premortem A2: a realised price of EUR 120 or more per unit holds the EUR 67 contribution and passes the EUR 25k gate. Exec summary: a demand mix yielding an EUR 50-67 average unit margin passes. Review 6 KPI 1: EUR 120 AOV supports a EUR 50-67 margin. Review 2 #2: Year-1 revenue of EUR 60-80k at healthy margin gives a EUR 30-50k quarterly surplus.
- **canonical gate_arithmetic and unit_cost_and_margin_eur:** Contribution 149 - 82 = 67 holds only at the list price. At EUR 120 the contribution is 120 - 82 = 38, so 750 units give 750 x 38 - 20k = EUR 8.5k (recomputed), far below EUR 25k. Passing the gate needs 672 units at 67, about 900 units at EUR 50 margin, or at least EUR 60 margin at 750 units.
- **Why it conflicts:** The thresholds that let the project continue (price >= 120, margin 50-67, prepper share <= 70%) do not lead to a gate pass. A project can clear every Month 3 trigger and still be unable to reach EUR 25k. Review 2 #2's total Year-1 revenue of EUR 60-80k also cannot produce a EUR 30-50k quarterly surplus.
- **Suggested resolution:** Keep the arithmetic. State that EUR 120 is a marketing halt trigger, not a condition that preserves the EUR 67 margin. Add a gate-consistent floor: at 750 units a price of about EUR 142 or more (margin >= 60), or a stated volume (900+ units at EUR 50 margin; about 1,180 units at EUR 38). Remove the 'EUR 50-67 passes' claims.

### 2. Gate-quarter volume vs presale cutoff and delivery schedule (🔴 High) — needs a project decision

- **canonical batch1_and_year1_volume; pitch Metrics and Call to Action; review_plan KPI 3:** Year-1 deliveries: 750 units in Months 7-8 and 750 in Months 9-12; gate quarter needs about 750 units delivered and paid in Months 9-12. Pitch: '800 units batch 1 delivered by Month 8'; presale delivery Months 6-9; presale offer closes Month 8.
- **canonical presale_tooling_gate and presale_cutoff_and_lead_time; review_plan Review 13 #3:** Presale targets of EUR 80-120k deposits equal only about 540-805 units at EUR 149 (recomputed), and these are scheduled for delivery before or at the start of the gate window. The roughly 700 gate-quarter units must come from ordinary orders after the cutoff, for which no demand evidence, channel or test is planned. Review 13 #3 instead argues presale orders must be delivered inside the window.
- **Why it conflicts:** The gate is measured on Months 9-12 receipts, yet the presale evidence gathered by Month 6-8 mostly lands before that window. The plan does not say where the 750 gate-quarter units come from or how a deposit paid earlier counts as receipts when delivered. Pitch batch 1 (800 by Month 8) also differs from 750 delivered in Months 7-8.
- **Suggested resolution:** Needs a project decision: (a) define the gate-quarter demand source (post-cutoff orders, wholesale, pilots) and add a test for it before Month 6; (b) decide whether deposits convert to gate receipts at delivery. Either way, align batch 1 delivery to one figure (canonical 750 in Months 7-8) and state that gate volume is not covered by presale evidence.

### 3. Pitch treats a full EUR 149 deposit as settled while deposit share and use are open (🔴 High) — needs a project decision

- **pitch Project Overview, Stakeholder Benefits, Call to Action:** Pitch: 'deposits of EUR 149 per unit'; 'Early access at EUR 149 (EUR 120 effective with deposit timing)'; Call to Action: presale deposits 'at EUR 149 per unit'.
- **canonical deposit_use_open_decision; review_plan Reviews 9, 10, 11, 14:** OPEN: whether ring-fenced deposits may pay unit cost, and what share of the unit price a deposit is. Reviews 9-11 and 14 repeat that this is undecided. EUR 120 is a halt threshold on realised price, not an 'effective price'.
- **Why it conflicts:** A full-price deposit is a choice that changes working capital, the 160k production-line funding, refund exposure and what counts as gate cash. Calling EUR 120 an 'effective' price also treats a halt trigger as an expected outcome.
- **Suggested resolution:** Decide the deposit share (for example partial versus full price) and whether ring-fenced deposits may fund matching unit cost, and record it in the gate convention by Month 0.5. Until then, the pitch should state 'deposit share to be decided' and drop 'EUR 120 effective'.

### 4. Tooling decision gate in Month 5 vs Month 6 (🟡 Medium) — needs a project decision

- **canonical design_milestones; exec summary monthly reviews; assumptions; self-audit 7:** 'Month 5 tooling decision gate' and monthly decision gates at Months 5, 8, 12 to commit or pivot tooling.
- **canonical presale_tooling_gate and presale_shortfall_stop_rule; project plan; pitch Tooling gate:** Hard tooling is released when net deposits >= EUR 80k (target EUR 120k by Month 6) and the lab report confirms the design; first batch committed Month 6; the report may arrive as late as Month 6; the shortfall stop rule is tested at Month 6.
- **Why it conflicts:** A decision at Month 5 cannot rely on a deposit count due at Month 6 or on a report that may arrive at Month 6. The documents use both months for the same gate.
- **Suggested resolution:** Use Month 5 as the lab-result and reserve checkpoint, and Month 6 as the only tooling release decision (deposits plus report). Edit the canonical design_milestones line and the Month 5 'commit tooling or pivot' wording.

### 5. 75k marketing/sales/operations line vs listed costs and Year-1 opex (🟡 Medium) — needs a project decision

- **canonical unbudgeted_items_absorbed; review_plan Review 11 #2:** Legal opinion, LCA, product-liability premium and part-time operations are 'funded inside the 75k'; the premium is 'not estimated'. Review 11 calls the premium an 'unfunded line item within the 75k'.
- **canonical recurring_opex_eur and annual_operating_economics; self-audit 7 and 12:** Recurring opex is 80k per year (marketing 40k, operations 13k, insurance 8k, accountant 7k, re-verification 12k), more than the 75k line before 9-18k of one-offs. The line has about 57-66k left against about 67k of recurring items. The 20k gate-quarter opex (Months 9-12) is not shown inside the Year-1 cap. Insurance is estimated at 8k in one fact and 'not estimated' in another.
- **Why it conflicts:** The line cannot hold both the one-offs and a full year of recurring opex, and the premium is both estimated and unestimated. Self-audit labels the line 'operations (75k)' and others 'marketing', though it is a mix. Cuts to this line also feed the 10k reserve top-up.
- **Suggested resolution:** A project decision is needed: which opex items are Year-1 cost versus Year-2, and which are cut or deferred (for example the 12k re-verification, which self-audit 12 proposes deferring). Then restate the 75k breakdown and the insurance estimate in one place.

### 6. Units-to-money conversion at EUR 67 margin (🟡 Medium)

- **review_plan Reviews 4 #1, 12 #3, 13 #1, 13 #3, 15 #1; self-audit 17:** 'EUR 15-30k (100-200 units at EUR 67 margin)' revenue/cash loss from a supplier switch or late delivery; '10-20k (75-150 units at EUR 67 margin)' in Review 13 #3.
- **canonical unit_cost_and_margin_eur and gate_arithmetic:** Recomputed: 100-200 units x EUR 67 = EUR 6.7-13.4k, and 75-150 units = EUR 5.0-10.1k. EUR 15-30k matches 100-200 units at the EUR 149 list price (revenue), not at margin.
- **Why it conflicts:** Revenue and contribution are mixed. For the gate the correct unit is contribution. The base-case headroom is 5.25k, about 78 units, so a slip of 100 units already fails the gate. The text overstates dollar impact in some places and hides how little slack there is.
- **Suggested resolution:** Restate as EUR 6.7-13.4k contribution (100-200 units) and note that a slip of about 80 or more units uses the whole 5.25k gate headroom. Or label EUR 15-30k as revenue.

### 7. Production-line and deposit arithmetic in Reviews 9, 10, 11, 14 (🟡 Medium)

- **review_plan Review 9 #2, Review 10 #1, Review 11 #1, Review 14 #2:** 'If deposits pay 50% of unit cost (EUR 75 per unit)'; 'leaving EUR 135k for batch-1 hard tooling (30k) and batch-2 labor/overhead'; a deposit shortfall 'leaves batch-1 tooling (30k) unfunded'.
- **canonical production_line_composition_eur and unit_financing_baseline:** Unit cost is 70, so 50% is 35; EUR 75 is about 50% of the EUR 149 price. The 160k line is hard tooling 30k + gasket stock 7k + units 105k + freight 18k with 0k headroom, so 135k is not free and there is no 'labor/overhead' line. Tooling is inside the 160k and program-financed.
- **Why it conflicts:** Percentages, per-unit figures and the 135k remainder do not follow from the canonical structure and imply headroom or an unfunded tooling line that the budget does not have.
- **Suggested resolution:** Rewrite using the canonical structure: if deposits pay unit cost, deposits cover part of the 105k unit-cost portion by timing only; the cap stays 400k and headroom stays 0k. Express deposit shares as % of the EUR 149 price. Remove 'batch-2 labor/overhead' and the 'tooling unfunded' claim.

### 8. Sensitivity arithmetic in self-audit item 8 (🟡 Medium)

- **self_audit item 8:** Optimistic case: 900 units x EUR 67 = 'EUR 48.25k quarterly surplus (23.25k buffer)'; a 10-20% cost increase 'reduces margin to EUR 40-57, compressing surplus by EUR 7.5-20k'.
- **canonical gate_arithmetic; review_plan Reviews 8 and 10:** Recomputed: 900 x 67 - 20k = EUR 40.3k, a buffer of 15.3k. A 10-20% rise on EUR 70 is +7 to +14, so margin 53-60 and surplus 25.0k to 19.75k, a reduction of 5.25-10.5k (Review 8 shows 25.0k and 19.0k at cost 77 and 85).
- **Why it conflicts:** The figures do not follow from the canonical 70 + 12 structure and conflict with the sensitivities in the review.
- **Suggested resolution:** Correct to 40.3k / 15.3k buffer for the optimistic case, and margin 53-60 with a 5.25-10.5k reduction for the cost-increase case.

### 9. Demand-mix and price halt thresholds differ between documents (🟡 Medium)

- **canonical demand_pivot_triggers; review_plan KPI 1; premortem FM3:** Pivot if prepper share > 70% (non-prepper >= 30%); halt presale marketing if average realised price < EUR 120. KPI 1: infrastructure + privacy combined >= 30%.
- **self_audit items 2 and 19:** Self-audit 19 dashboard: prepper <= 70%, infrastructure >= 35%, privacy >= 25% (non-prepper >= 60%) and 'halt if < EUR 115'; self-audit 2 uses a killer-app segment >= 35% deposit share.
- **Why it conflicts:** A 115 halt versus 120 changes when presale marketing stops. Segment shares of 35% + 25% imply prepper <= 40%, not <= 70%, so the targets are internally inconsistent and the dashboard trips before the stated pivot rule.
- **Suggested resolution:** Use the canonical values: halt below EUR 120, pivot above 70% prepper, conversion below 40%. Drop or relabel the 35%/25% segment targets as aspirations.

### 10. Burn-rate control vs front-loaded budget (🟡 Medium)

- **self_audit item 19; review_plan Review 16 #2:** Monthly cash-burn target <= EUR 33k/month (400k / 12); freeze if > EUR 37k. Variance flags at EUR 40k (Month 5) and EUR 120k (Month 8).
- **executive summary Timeline and Budget; canonical year1_budget_allocation_eur:** Executive summary schedule: design EUR 110k in Months 0-2 (about 55k/month) and lab plus soft tooling EUR 35k in Months 2-5, so about 145k is spent by Month 5. The flat plan would be 66.7k by Month 2.
- **Why it conflicts:** Against a flat 33k/month plan the front-loaded schedule breaches the 10% freeze rule in the first months. The 40k/120k variance amounts do not match either schedule.
- **Suggested resolution:** Set the freeze trigger against the monthly burn schedule due at Month 0.5, not a flat 33k. Recompute the Month 5 and Month 8 variance thresholds as 10% of the scheduled cumulative spend.

### 11. Refund spike in Months 10-12 vs refund window closing at Month 8.5 (🟡 Medium)

- **review_plan Reviews 2 #3, 4 #3, 5 #3:** A presale refund spike of 15-30% in Months 10-12 consumes presale deposits and cuts operating cash by EUR 15-30k just as the gate opens.
- **pitch Call to Action; canonical deposit_accounting_rule; review_plan Review 13 #3:** Deposits are refundable only until Month 8.5; the cap is measured by Month 8; the presale liability is finalised before the Month 9 window opens; deposits are never gate cash.
- **Why it conflicts:** By Months 10-12 the presale deposits are either delivered or already refunded, and deposits are excluded from the gate, so they cannot be 'consumed'. If the intended risk is post-delivery returns (30-day money-back), that is a different mechanism not covered by the 15% deposit cap.
- **Suggested resolution:** Describe the Months 10-12 exposure as post-delivery returns that reduce gate receipts, and add a return-rate metric for the gate window. Keep the 15% deposit cap tied to Month 8.

### 12. Consultancy agreement timing (Month 0.5 vs Month 1) (🟡 Medium)

- **canonical month05_prerequisites; exec summary; premortem A5:** Signed consultancy/university milestone agreements by Month 0.5 with penalty clauses and IP terms.
- **self_audit item 13:** Self-audit 13: survey 8-12 consultants and interview 3-4 by Month 0.5, then 'by Month 1 lock a signed milestone agreement'.
- **Why it conflicts:** Two deadlines for the same agreement. The self-audit sequence also puts the consultant survey due on the same date as the signature, so signing cannot follow it.
- **Suggested resolution:** Keep the canonical Month 0.5 for the signature. Move the consultant survey earlier or limit it to a shortlist, and treat Month 1.5 (the premortem A5 failure trigger) as the backstop for the university agreement.

## Summary

The plan is largely coherent on dates, the EUR 750k / 400k / 350k structure, the 160k production-line composition and the gate definition; most earlier timing and arithmetic errors have been repaired. The main remaining problems are economic: the EUR 120 price floor and the EUR 50-67 margin range cannot reach the EUR 25k gate, and the 750 units needed in Months 9-12 have no demand source once presales close at Month 8. The open deposit decision, the overloaded 75k line and several recomputation slips (units vs margin, 50% of unit cost, the optimistic case) also need repair before the gate figures can be relied on.