## Focus and Context
A single-SKU Faraday enclosure manufactured in Tallinn protects phones and laptops from electromagnetic threats. Presales validate demand before hard tooling is committed. Staged EUR 750k funding (EUR 400k Year-1, EUR 350k on positive cash-flow gate by Month 12.5 = 2027-10-23) protects founder capital and enforces evidence-gated sequencing.

## Purpose and Goals
Launch a certified, presale-funded hardware business reaching 1,500 unit Year-1 deliveries and EUR 25k+ quarterly operating cash flow (proposed threshold) by Month 12 (2027-10-08) to unlock the EUR 350k follow-on tranche. Prove demand, design integrity, and unit economics within a EUR 400k Year-1 cap.

## Key Deliverables and Outcomes
Accredited EMC lab shielding report (Month 5 = 2027-03-08); EUR 80k+ net presale deposits (Month 6 = 2027-04-08); 1,500 units delivered Year-1; trailing-quarter operating surplus ≥EUR 25k (Months 9–12 = 2027-07-08 to 2027-10-08); EUR 350k tranche released Month 12.5 (2027-10-23) or withheld.

## Timeline and Budget
Year-1 EUR 400k cap (Month 0–12 = 2026-10-08 to 2027-10-08): design EUR 110k (Months 0–2 = 2026-10-08 to 2026-12-08), lab EUR 35k (Months 2–5 = 2026-12-08 to 2027-03-08), production EUR 160k (Months 5–12 = 2027-03-08 to 2027-10-08), marketing EUR 75k. Free contingency EUR 20k reserve only. Gate measurement and sign-off Months 9–12 (2027-07-08 to 2027-10-08).5 (2027-07-08 to 2027-10-23).

## Risks and Mitigations
Accredited lab cost/standard unverified (EUR 10–20k overrun risk, +4–8 weeks delay estimate); presale demand-mix untested (prepper-only scenario yields EUR 11.25k quarterly margin, missing EUR 25k gate by EUR 13.75k); cash-flow gate rule not yet published (deposits risk miscounting as operating cash). Mitigations: lock lab SoW by Month 1.5 (2026-11-23), run parallel presale segment campaigns with weekly tracking and pivot triggers by Month 3 (2027-01-08), publish written gate convention by Month 0.5 (2026-10-23).

## Audience Tailoring
Tailored for a founder and external financial advisor evaluating a self-funded hardware venture with staged tranche release. Tone is pragmatic and capital-conscious, focusing on execution gatekeeping and risk mitigation rather than optimistic upside scenarios.

## Action Orientation
By Month 0.5 (2026-10-23): draft gate convention, monthly burn schedule, EMC lab pre-engagement, consultancy/university contracts, legal opinion commission. By Month 1 (2026-11-08): presale campaigns live, weekly segment tracking, secondary fabricator trial, insurance quote. By Month 3 (2027-01-08): assess demand-mix, pivot marketing if needed, lock infrastructure pilots. By Month 6 (2027-04-08): hard-tooling release on EUR 80k deposits + lab confirmation. Monthly cash reviews at Months 2, 5, 8, 12 (2026-12-08, 2027-03-08, 2027-06-08, 2027-10-08).

## Overall Takeaway
The plan is executable within the EUR 400k Year-1 cap if three critical assumptions hold: accredited lab cost stays EUR 15k and report arrives by Month 5 (2027-03-08), presale demand mix yields EUR 50–67 average unit margin (not EUR 15 prepper-only downside), and cash-flow gate rule is locked upfront to prevent moral hazard on EUR 350k tranche release. Free contingency is EUR 20k only; any lab overrun or demand-mix collapse triggers a 90-day gate extension or tranche withhold. Execution discipline on gatekeeping and early validation is essential.

## Feedback
Strengthen clarity on: (1) Accredited lab selection by Month 0.5 (2026-10-23)—lock signed SoW with fixed cost EUR 15k, standard IEEE 299.1 applicability confirmed, report Month 5 = 2027-03-08. (2) Presale deposit accounting—specify whether deposits pay unit cost, and publish separate earmarked account and weekly reconciliation by Month 1 (2026-11-08). (3) Demand-mix validation and segment pivots—run parallel landing-page A/B tests, measure weekly deposit velocity by segment (prepper, infrastructure, privacy), and formalize pivot triggers by Month 3 (2027-01-08). (4) Post-gate tranche allocation—by Month 11 (2027-09-08), publish written plan for EUR 350k use (inventory, marketing, R&D) so gate sign-off includes Year-2 strategy clarity.