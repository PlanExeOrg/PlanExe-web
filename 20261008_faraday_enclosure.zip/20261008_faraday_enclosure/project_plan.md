**Goal Statement:** Design, certify and launch a single-SKU Faraday enclosure for phones and laptops, manufactured in Tallinn and presold across Europe, within the EUR 400k Year-1 cap, and meet the cash-flow gate (surplus ≥ EUR 25k, proposed threshold) by Month 12.5 (2027-10-23) to release the EUR 350k follow-on.

## SMART Criteria

- **Specific:** Deliver one rigid folded aluminium/steel Faraday enclosure with a conductive-gasket lid seam, validated by one accredited EMC test, produced in Tallinn and sold in Europe, funded by EUR 750k self-funding (user constraint) in two stages.
- **Measurable:** Accredited lab report published; net presale deposits ≥ EUR 80k (proposed threshold); about 1,500 units delivered in Year-1 (estimate); trailing-quarter operating cash surplus ≥ EUR 25k (proposed threshold); Year-1 outlay ≤ EUR 400k.
- **Achievable:** Faraday enclosures are a proven concept and Tallinn has sheet-metal fabricators. Hard tooling is gated on presales and lab results, and EMC expertise is contracted rather than hired. The base case leaves only a EUR 5.25k margin over the gate (estimate), and free contingency is limited to EUR 20k (estimate).
- **Relevant:** Staged, evidence-gated spending protects the founder's personal capital. It also tests whether a niche hardware business can reach positive cash flow before the EUR 350k follow-on is committed.
- **Time-bound:** Start now (Month 0 = 2026-10-08). Lab report by Month 5 (2027-03-08), first batch committed by Month 6 (2027-04-08), gate measurement over Months 9-12 (2027-07-08 to 2027-10-08), and sign-off by Month 12.5 (2027-10-23).

## Dependencies

- Written cash-flow gate convention and monthly burn schedule agreed (Month 0.5 = 2026-10-23)
- Accredited EMC lab selected with fixed-cost statement of work (Month 1.5 = 2026-11-23)
- EMC consultancy and Estonian university lab milestone agreements signed
- Legal opinion on applicable EU product rules and claim scope
- Presale terms, delivery SLA and net presale deposits meeting the tooling gate
- Tallinn fabricator and gasket supplier secured, with backups

## Resources Required

- Year-1 budget of EUR 400k (user constraint)
- Tallinn precision sheet-metal fabricator and gasket suppliers
- In-house shielding test rig and accredited EMC lab access
- EMC consultancy and university lab partnership
- Legal counsel, product-liability insurance and presale platform

## Related Goals

- Release the EUR 350k follow-on tranche
- Open a smaller or phone-only SKU variant after the gate
- Set up EU buffer-stock warehousing after the gate
- Win critical-infrastructure reference customers
- Consider server-grade cages once traction is proven

## Tags

- Faraday enclosure
- EMC testing
- Hardware startup
- Tallinn manufacturing
- Presale

## Risk Assessment and Mitigation Strategies


### Key Risks

- Failed or costlier accredited lab test (re-test EUR 8-15k, estimate; costlier standard +10-20k, estimate) exceeds the EUR 20k reserve and delays the report by about 2 months
- Presale deposits stay below EUR 80k (proposed threshold), so hard tooling is not released
- Prepper-heavy mix cuts margin to about EUR 15 per unit (estimate) and the cash-flow gate fails
- EMC Directive or CE requirements apply (not verified), adding unfunded cost (+10-30k, estimate) and delay
- Claim-substantiation and liability exposure if the product underperforms in a real event

### Diverse Risks

- Tallinn fabricator capacity or price increases, and gasket supply delays
- Fit complaints from a single size and freight cost eroding margin
- Founder overload, and RF expertise or university timelines slipping
- Refund spike if the news cycle fades, and competitor entry

### Mitigation Plans

- Hold tooling until the pre-test and lab pre-engagement are done, run the in-house rig twice, and keep the EUR 20k reserve uncommitted until Month 5 (2027-03-08). Decide whether to raise it to 30k by cutting marketing
- Track segment deposits weekly. At Month 3 (2027-01-08), shift marketing if preppers exceed 70% of deposits. Under the stop rule, if deposits are below EUR 80k at Month 6 (2027-04-08), extend presale to Month 8 (2027-06-08) at most with no hard tooling
- Obtain a legal opinion by Month 1 (2026-11-08), limit claims to measured attenuation, state the scope (stored spare devices only), and lock insurance terms by Month 2.5 (2026-12-23)
- Pre-qualify a secondary fabricator and two gasket suppliers, fix pricing with the primary supplier, and hold gasket buffer stock
- Ring-fence presale deposits as liabilities, set a presale cutoff at Month 8 (2027-06-08), publish a fit guide, and add a part-time operations person and a backup contact

## Stakeholder Analysis


### Primary Stakeholders

- Founder / funder
- EMC consultancy
- Estonian university lab
- Tallinn fabricator
- External financial advisor (gate sign-off)

### Secondary Stakeholders

- Accredited EMC laboratory
- Prepper and privacy/forensics communities
- Critical-infrastructure pilot buyers
- Gasket suppliers and logistics carriers
- Legal counsel and insurer

### Engagement Strategies

- Founder, consultancy and fabricator: weekly progress and cash reviews, with milestone-based agreements and prompt answers to information requests
- Accredited lab and university: fixed statement of work, pre-test design review and milestone check-ins
- Buyers: segment-specific campaigns, a clear presale SLA and refund terms, and pilot agreements with reference rights
- Advisor, legal counsel and insurer: monthly cash reconciliation and a Month 12.5 (2027-10-23) gate sign-off
- Suppliers and carriers: capacity and price agreements with monthly lead-time reviews

## Regulatory and Compliance Requirements


### Permits and Licenses

- Business registration and VAT/OSS registration for EU distance sales
- Product-liability insurance policy
- Presale terms compliant with EU consumer law

### Compliance Standards

- IEEE 299.1 or equivalent shielding standard (not verified)
- EU General Product Safety rules (applicability not verified)
- EMC Directive applicability (not verified)
- EU consumer-protection and distance-selling rules

### Regulatory Bodies

- Estonian Consumer Protection and Technical Regulatory Authority
- EU Commission product-safety framework
- Accredited EMC laboratory (accreditation body-recognised)
- Estonian Tax and Customs Board

### Compliance Actions

- Commission legal opinion on EU product rules by Month 1 (2026-11-08)
- Lock lab statement of work by Month 1.5 (2026-11-23) and publish the lab report with every unit
- Limit marketing claims to measured attenuation and include the scope statement
- Lock product-liability insurance terms by Month 2.5 (2026-12-23)
- Review the compliance checklist monthly