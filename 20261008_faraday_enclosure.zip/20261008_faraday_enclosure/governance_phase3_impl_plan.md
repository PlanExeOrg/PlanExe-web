### 1. Founder establishes the Carrington Event Prep project governance framework by drafting a written governance charter defining the five internal governance bodies, their roles, decision rights, meeting cadence, and escalation paths. Founder also drafts the cash-flow gate measurement convention (definition: operating revenue from delivered units only, excluding presale deposits; threshold: EUR 25k quarterly surplus; measurement window: Months 9–12 = 2027-07-08 to 2027-10-08) and the monthly Year-1 burn schedule (EUR 400k allocation across design, lab, soft tooling, production, and marketing). Both documents are circulated for advisor review.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- Written Governance Charter (draft, defining all five bodies)
- Cash-Flow Gate Measurement Convention (written definition, threshold, measurement window, tiebreak rule)
- Monthly Year-1 Burn Schedule (EUR 400k allocation by category)

**Dependencies:**

- Project start and founder commitment
- Decision on five governance bodies (already defined in project inputs)

### 2. Founder identifies and recruits one external financial advisor (accountant or experienced mentor) to serve as an independent co-signatory on the cash-flow gate result at Month 12.5 (2027-10-23) and to review monthly cash reconciliation quarterly. Advisor is briefed on the project scope, budget cap, gate logic, and their role in governance oversight. A written advisory engagement letter is signed, outlining advisor responsibilities, meeting schedule, and compensation (if any).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- External Advisor Identified and Confirmed (name, expertise, availability)
- Signed Advisory Engagement Letter (roles, responsibilities, meeting cadence, compensation)
- Advisor Briefing Complete (project overview, governance framework, gate logic)

**Dependencies:**

- Governance charter and gate convention drafted
- Advisor availability and willingness confirmed

### 3. Founder publishes the written cash-flow gate measurement convention and governance charter in all project materials (presale terms, website, investor/stakeholder communications) so that all buyers and stakeholders understand the gate logic and tranche-release criteria upfront. Founder also finalizes and publishes the presale terms document, including refund policy (maximum 30-day window, refund cap 15% of deposits by Month 8 = 2027-06-08 as a pivot trigger), delivery SLA (build-to-order, 2–3 week lead time), and scope statement (protects stored spare devices only).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Published Cash-Flow Gate Convention (in presale materials and website)
- Published Governance Charter (summary version for stakeholders)
- Finalized Presale Terms Document (refund policy, SLA, scope statement, accepted payment methods)
- Presale Platform Ready (deposits accepted through separate earmarked account)

**Dependencies:**

- Cash-flow gate convention and charter approved by founder and advisor
- Accredited lab selection and legal opinion in progress (see parallel steps)

### 4. Founder contacts 2–3 accredited EMC laboratories (Germany, Sweden, Netherlands, or Estonia) for no-cost pre-engagement consultations. Founder documents each lab's recommendation for the applicable standard (proposed IEEE 299.1, not verified), frequency range, test methodology, estimated cost (target: EUR 15k, locked), timeline (target: report by Month 5 = 2027-03-08), and design-readiness review scope (EUR 2–3k, estimate). Founder compares quotes and selects the lab best aligned with cost predictability and timeline.

**Responsible Body/Role:** Founder / Project Principal (with EMC Consultancy support from Month 1 = 2026-11-08 onward)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Lab Pre-Engagement Consultation Summaries (3 labs, standard recommendations, cost estimates, timelines)
- Lab Selection Recommendation (based on cost, timeline, credibility)

**Dependencies:**

- Project start
- EMC consultancy contact established (parallel step)

### 5. Founder identifies and engages an independent EMC consultancy on a fixed milestone-based agreement. The agreement specifies deliverables: prototype RF design review (Month 2 = 2026-12-08), in-house rig design and setup consultation (Month 2 = 2026-12-08), accredited lab coordination and design-readiness confirmation (Month 4 = 2027-02-08), and lab result interpretation (Month 5 = 2027-03-08). Total cost is capped at EUR 20–25k (estimate) with no overruns permitted. Milestone agreement includes penalty clauses for missed deadlines. If the consultancy cannot commit to the timeline by Month 0.5 (2026-10-23), a backup consultancy is identified immediately.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- EMC Consultancy Selected (name, expertise, references checked)
- Signed Milestone Agreement (deliverables, cost cap EUR 20–25k, timeline, penalty clauses)
- Backup Consultancy Identified (in case primary fails)

**Dependencies:**

- Project scope and design requirements known (single-SKU rigid enclosure)
- Timeline milestones agreed (Month 2–5 = 2026-12-08 to 2027-03-08 design and lab cycle)

### 6. Founder initiates co-development partnership with an Estonian university lab (e.g., Tallinn University of Technology) providing access to in-house shielding test-rig facilities and RF measurement equipment. Partnership agreement specifies: (1) university provides measurement access and capital support for rig setup (EUR 5–10k estimate), (2) founder provides consumables and operational costs, (3) IP and publication rights are clarified upfront, (4) milestones are tied to prototype availability (Month 2 = 2026-12-08) and validation completion (Month 3 = 2027-01-08). Partnership is documented in a written co-development agreement signed by Month 0.5 (2026-10-23). If university partnership is not confirmed by Month 1.5 (2026-11-23), founder immediately hires a part-time RF engineer (0.5 FTE, EUR 25k Year-1 estimate) as backup.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 0.5 (2026-10-23)

**Key Outputs/Deliverables:**

- University Lab Partner Identified (institution, lab director, capabilities)
- Signed Co-Development Agreement (IP rights, capital/consumables costs, publication terms, milestones)
- In-House Rig Design Specification (frequency range, attenuation measurement methodology, calibration standard)
- Backup RF Engineer Hiring Plan (in case university partnership fails by Month 1.5 = 2026-11-23)

**Dependencies:**

- Project scope and design requirements known
- University lab capability and availability confirmed

### 7. Founder commissions a legal opinion on applicable EU product-safety rules, including General Product Safety Directive, EMC Directive applicability, and consumer-protection duties. Legal counsel (prefer Estonian or EU-based) delivers findings by Month 1 (2026-11-08). Legal opinion documents: (1) which directives apply (if any), (2) product-liability exposure and warranty obligations, (3) claim substantiation requirements, (4) compliance recommendations. Cost budget: EUR 2–5k (estimate). Findings are shared with the Compliance and Liability Committee and used to finalize the scope statement and marketing disclaimers.

**Responsible Body/Role:** Founder / Project Principal (with external legal counsel)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Legal Opinion on EU Product-Safety Rules (applicability of EMC Directive, General Product Safety Directive, consumer law)
- Regulatory Compliance Roadmap (CE marking requirement assessment, claim substantiation rules)
- Scope Statement Final Version (protects stored spare devices only; does not protect active equipment or grid-scale events)

**Dependencies:**

- Project scope and marketing narrative defined
- Legal counsel identified and engaged

### 8. Founder sets up the presale-deposit account as a separate, earmarked bank account, distinct from operational cash. Founder documents the deposit ring-fencing policy: (1) deposits are classified as liabilities, not revenue or cash flow, (2) operational spending is never drawn from this account, (3) deposits are used only to fulfill presale orders, (4) refunds are approved by founder and tracked, (5) month-end reconciliation is completed. An accountant or operations person is designated to manage this account. The separate account is audited monthly by Month 1.5 (2026-11-23) onward.

**Responsible Body/Role:** Founder / Project Principal (with part-time operations/finance support from Month 1 = 2026-11-08)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Presale Deposit Account Opened (separate from operational cash)
- Deposit Ring-Fencing Policy Documented (written procedures for deposit use, refunds, accounting)
- Monthly Reconciliation Template (deposits received, refunds paid, net deposits, liability tracking)
- Audit Log Started (deposits and refunds recorded daily)

**Dependencies:**

- Presale terms document finalized
- Bank account access confirmed
- Governance charter and gate convention approved

### 9. Founder formally establishes the Project Steering Committee by confirming membership: (1) Founder / Project Principal, (2) External Financial Advisor (recruited earlier). Founder schedules the first Steering Committee meeting for Month 1 (2026-11-08) to review and approve the governance charter, cash-flow gate convention, burn schedule, and initial risks. Founder documents committee decision rights, meeting cadence (monthly, last week of month, typically 1 hour), and escalation procedures. A written Steering Committee Charter is signed by both members by Month 1.5 (2026-11-23).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Project Steering Committee Formally Constituted (founder and advisor confirmed, written confirmation)
- Steering Committee Charter Signed (decision rights, meeting cadence, escalation paths, tiebreak rules)
- First Steering Committee Meeting Held (Month 1 = 2026-11-08)
- Meeting Minutes: Gate Convention Approved, Burn Schedule Approved, Initial Risk Register Reviewed

**Dependencies:**

- External advisor recruited and engaged
- Governance charter and gate convention drafted by founder
- Legal and lab engagement in progress

### 10. Founder identifies and pre-qualifies the primary Tallinn precision-metal fabricator and a secondary backup fabricator. Founder requests quotations for: (1) soft tooling (laser cutting and CNC bending for prototyping and early batches), (2) hard tooling (progressive die or equivalent for production), and (3) per-unit production cost (target: EUR 70 estimate). Founder also conducts trial laser-cut batches with both primary and secondary suppliers (Month 0–1 = 2026-10-08 to 2026-11-08) to assess quality, tolerance, finish, and lead times. Trial samples are reviewed and documented.

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee support from Month 1.5 = 2026-11-23 onward)

**Suggested Timeframe:** Month 0 (2026-10-08) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Primary Fabricator Identified and Quoted (soft tooling, hard tooling, unit cost)
- Secondary Backup Fabricator Identified and Quoted (same scope)
- Trial Laser-Cut Samples Received and Inspected (primary and secondary, documented pass/fail)
- Fabricator Capability Assessment (quality, tolerance, lead time, capacity)

**Dependencies:**

- Enclosure design specification finalized (single-SKU rigid aluminium/steel, conductive-gasket seam)
- Target unit cost (EUR 70 estimate) and production volume (1,500 units Year-1) known

### 11. Founder identifies and pre-qualifies conductive-gasket material suppliers (primary and backup). Founder requests quotations for RF-shielding-grade gasket materials matching the enclosure seam design, specifying: (1) attenuation performance (to support shielding claims), (2) durability and compression-set characteristics, (3) lead times (minimum 4 weeks estimate), (4) per-unit cost (to fit within EUR 70 total unit cost estimate). Founder also calculates buffer-stock requirement: 30-day supply based on expected monthly production (target: 125 units/month Year-1 average) = approximately 125 units worth of gasket material, costing EUR 5–10k (estimate). Gasket supplier agreements are documented by Month 1 (2026-11-08).

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee support from Month 1.5 = 2026-11-23 onward)

**Suggested Timeframe:** Month 0.5 (2026-10-23) to Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Primary Gasket Supplier Identified and Quoted (material spec, attenuation, lead time, unit cost)
- Backup Gasket Supplier Identified and Quoted (same spec)
- Gasket Buffer Stock Calculated (30-day supply, EUR 5–10k estimate)
- Supplier Quality and Lead-Time Confirmation

**Dependencies:**

- Enclosure seam design finalized (conductive-gasket type and spec)
- Production volume and lead-time forecast known

### 12. Founder formally establishes the Design and Certification Working Group by confirming membership: (1) Founder (design lead and decision authority), (2) EMC Consultancy (RF design and lab coordination), (3) Estonian University Lab (in-house rig and measurement support), (4) Accredited EMC Laboratory (external, once selected), and (5) Backup RF Engineer (if university partnership fails by Month 1.5 = 2026-11-23). Founder schedules the first Design & Certification meeting for Month 1.5 (2026-11-23) to review: (1) prototype design requirements, (2) in-house rig validation methodology, (3) accredited lab engagement timeline, (4) design-readiness criteria. A written working group charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Design and Certification Working Group Formally Constituted (membership confirmed, roles assigned)
- Working Group Charter Signed (decision rights, meeting cadence bi-weekly, agenda framework)
- First Working Group Meeting Held (Month 1.5 = 2026-11-23)
- Meeting Minutes: Design Requirements Reviewed, Rig Validation Plan Confirmed, Lab Timeline Locked

**Dependencies:**

- EMC consultancy and university lab agreements signed
- Accredited lab pre-engagement consultations completed
- Design and Certification group charter drafted by founder

### 13. Founder obtains a fixed-cost statement of work from the selected accredited EMC laboratory. Statement of work specifies: (1) applicable standard (IEEE 299.1 or equivalent, documented), (2) frequency range (to be confirmed), (3) attenuation measurement method, (4) number of test samples required, (5) total cost (fixed at EUR 15k cap, estimate), (6) design-readiness review cost (EUR 2–3k estimate, included in total), (7) report delivery date (committed by Month 5 = 2027-03-08, latest Month 6 = 2027-04-08), (8) re-test cost if first attempt fails (EUR 8–15k estimate, outside the original contract). Statement of work is signed by founder and lab director by Month 1.5 (2026-11-23). A copy is shared with the Design & Certification Working Group.

**Responsible Body/Role:** Founder / Project Principal (with Design and Certification Working Group input)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Signed Lab Statement of Work (cost fixed EUR 15k, report date Month 5 = 2027-03-08)
- Lab Standard and Frequency Range Confirmed (IEEE 299.1 or equivalent documented)
- Design-Readiness Review Scope Defined (EUR 2–3k estimate, Month 4 = 2027-02-08)
- Re-Test Cost and Timeline Documented (EUR 8–15k estimate, outside original contract)

**Dependencies:**

- Accredited lab selected (Month 0–1 = 2026-10-08 to 2026-11-08)
- Enclosure design specification finalized

### 14. Founder signs a binding pricing and capacity agreement with the primary Tallinn fabricator, locking in: (1) soft-tooling cost (estimated for laser-cut and bend iterations, Months 1–3 = 2026-11-08 to 2027-01-08), (2) hard-tooling cost (estimated EUR 30k, range 20–40k estimate, released only at Month 5–6 = 2027-03-08 to 2027-04-08 after presale gate is met), (3) per-unit production cost (EUR 70 estimate, no increase without 60-day notice and founder approval), (4) production batch schedule (Batch 1: 800 units, Months 7–8 = 2027-05-08 to 2027-06-08; follow-on batches: 700 units Months 9–12 = 2027-07-08 to 2027-10-08), (5) capacity reservation (committed slot for these batches, no capacity loss or reallocation to other customers), (6) price-increase cap (no more than 10% annually, effective Month 13 = 2027-11-08 onward). Agreement is signed by founder and fabricator by Month 1.5 (2026-11-23). A backup agreement with the secondary fabricator is signed simultaneously, contingent on primary failure.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Signed Primary Fabricator Agreement (pricing locked, capacity reserved, schedule committed)
- Signed Secondary Fabricator Backup Agreement (same terms, contingent on primary failure)
- Soft Tooling Budget Confirmed (estimated cost, Months 1–3 = 2026-11-08 to 2027-01-08)
- Hard Tooling Cost Locked (EUR 30k estimate, release gated on Month 5–6 = 2027-03-08 to 2027-04-08 presale deposits)

**Dependencies:**

- Primary and secondary fabricators identified and quoted
- Enclosure design specification finalized
- Budget allocation (EUR 20k soft tooling, EUR 30k hard tooling, EUR 105k unit cost) approved

### 15. Founder establishes the Compliance and Liability Committee by confirming membership: (1) Founder (compliance owner, decision authority), (2) External Legal Counsel (EU product law expertise), (3) Product-Liability Insurer (coverage assessment and terms), (4) Design & Certification Group Liaison (to align lab report and claims). Founder schedules the first Compliance & Liability meeting for Month 1.5 (2026-11-23) to review: (1) legal opinion findings on applicable directives, (2) product-liability insurance quotes and coverage terms, (3) scope statement and claim-limiting language, (4) warranty and refund obligations. A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Compliance and Liability Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, meeting cadence monthly, escalation paths)
- First Committee Meeting Held (Month 1.5 = 2026-11-23)
- Meeting Minutes: Legal Opinion Reviewed, Insurance Quotes Compared, Scope Statement Finalized

**Dependencies:**

- Legal opinion commissioned and delivered
- External legal counsel and insurer contacts established
- Governance charter and compliance framework drafted by founder

### 16. Founder contacts 2–3 product-liability insurers who cover Faraday enclosures, RF-shielding products, or consumer electronics. Founder requests quotes for coverage limits of EUR 250–500k (estimate) for defect claims, failure, and misrepresentation liability. Founder asks each insurer to clarify: (1) whether Faraday-enclosure claims are insurable (no exclusion for 'rare events'), (2) claim-substantiation requirements, (3) warranty and refund exposure, (4) premium costs, (5) exclusions or limitations, (6) whether annual re-verification is required. Quotes are compared by Month 2 (2026-12-08). Insurance terms are locked with the selected insurer by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Founder / Project Principal (with Compliance and Liability Committee oversight)

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2.5 (2026-12-23)

**Key Outputs/Deliverables:**

- Insurance Quotes Received (3 insurers, coverage EUR 250–500k estimate, premiums compared)
- Insurance Policy Locked (coverage limits, exclusions, premium, effective date Month 3 = 2027-01-08)
- Coverage Confirmation Letter (insurer confirms Faraday-enclosure claims are covered)
- Compliance Summary: Insurance and Warranty Obligations Documented

**Dependencies:**

- Legal opinion on applicable product-safety rules completed
- Scope statement drafted and reviewed
- Compliance and Liability Committee formed

### 17. Founder designs and prepares parallel presale campaigns targeting three buyer segments: (1) Prepper Networks and Online Communities (disaster-preparedness theme, messaging about solar-storm and pulse resilience, deposit rate 40–50% estimate, average order value EUR 50–70 estimate), (2) Critical-Infrastructure and Emergency-Planning Buyers (documentation and pilots, messaging about continuity of operations, deposit rate 30–40% estimate, order value EUR 200–300+ estimate), (3) Privacy, Digital-Forensics, and Corporate IT Buyers (multi-use RF-isolation narrative, messaging about privacy and RF security, deposit rate 35–45% estimate, order value EUR 80–150 estimate). Founder drafts distinct presale marketing copy, landing pages, email templates, and buyer-contact lists for each segment. Campaigns are reviewed by founder and external advisor by Month 1.5 (2026-11-23). Presale platforms (web form, payment processor, email list) are set up by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Prepper Campaign Materials Drafted (messaging, landing page, email templates, community contact list)
- Infrastructure Campaign Materials Drafted (pilot proposal, documentation pack outline, buyer contact list)
- Privacy/Corporate Campaign Materials Drafted (multi-use RF-isolation narrative, contact list)
- Presale Platform Set Up (web form, payment processor linked to separate deposit account, email automation)
- Campaign Launch Plan Confirmed (Month 1 = 2026-11-08 release date for all three segments)

**Dependencies:**

- Scope statement and marketing disclaimers finalized
- Presale terms and delivery SLA published
- Presale deposit account and ring-fencing procedures ready

### 18. Founder formally establishes the Presale and Revenue Validation Committee by confirming membership: (1) Founder (presale strategy, buyer relationships), (2) Part-Time Operations Person (deposit tracking, data dashboard, reporting), (3) External Advisor Liaison (segment analysis, pivot trigger assessment). Founder schedules the first meeting for Month 1.5 (2026-11-23) to review: (1) presale campaign designs, (2) deposit-tracking methodology and weekly dashboard, (3) segment-mix analysis triggers (prepper > 70% by Month 3 = 2027-01-08 escalates presale pivot), (4) conversion-rate and average-order-value thresholds, (5) presale cutoff date (Month 8 = 2027-06-08). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Presale and Revenue Validation Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, weekly/monthly meeting cadence, pivot triggers)
- First Committee Meeting Held (Month 1.5 = 2026-11-23)
- Presale Dashboard Template Confirmed (weekly tracking: deposits, refunds, segment mix, conversion rate, AOV)
- Pivot Trigger Criteria Documented (prepper > 70%, conversion < 40%, AOV < EUR 50 estimate)

**Dependencies:**

- Presale campaigns designed and reviewed
- Presale deposit account set up
- Part-time operations person identified (to be hired Month 1 = 2026-11-08 or earlier)

### 19. Founder launches all three parallel presale campaigns (prepper, infrastructure, privacy/forensics) simultaneously by Month 1 (2026-11-08). Presale offers are posted on the project website, announced in prepper forums and communities, sent to critical-infrastructure buyer contacts, and shared in digital-forensics and privacy-advocacy networks. Presale terms, delivery SLA (2–3 week build-to-order lead time), refund policy (30-day window, 15% cumulative cap by Month 8 = 2027-06-08 as pivot trigger), and scope statement (protects stored spare devices only) are displayed prominently. Presale deposits begin flowing into the separate earmarked account. The operations person tracks deposits and refunds daily starting Month 1 (2026-11-08).

**Responsible Body/Role:** Founder / Project Principal (with Part-Time Operations support)

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- All Three Presale Campaigns Launched (prepper, infrastructure, privacy/forensics)
- Presale Deposits Begin Flowing (tracked daily into separate account)
- First Week Presale Dashboard (deposits, refunds, segment mix)
- Communications Log (campaign reach, email opens, landing-page clicks, deposit velocity)

**Dependencies:**

- Presale campaigns designed and tested
- Presale platform and deposit account ready
- Presale terms and delivery SLA published
- Part-time operations person on board

### 20. Founder formally establishes the Production and Supply Chain Committee by confirming membership: (1) Founder (supplier relationships, production decisions, quality sign-off), (2) Primary Tallinn Fabricator (manufacturing partner), (3) Secondary Backup Fabricator (contingency), (4) Gasket Material Suppliers (primary and backup), (5) Freight Logistics Partner (DHL, UPS, or local carrier), (6) Part-Time Operations/Supply-Chain Manager (tracking, inspections, inventory management). Founder schedules the first Production & Supply Chain meeting for Month 2 (2026-12-08) to review: (1) soft-tooling schedule (laser-cut trials, Months 1–3 = 2026-11-08 to 2027-01-08), (2) hard-tooling readiness (Month 5–6 gate = 2027-03-08 to 2027-04-08), (3) gasket buffer stock (30-day supply in place by Month 6 = 2027-04-08), (4) production batch schedule (Batch 1: Months 7–8 = 2027-05-08 to 2027-06-08). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Production and Supply Chain Committee Formally Constituted (membership confirmed, roles assigned)
- Committee Charter Signed (decision rights, bi-weekly/monthly meeting cadence, escalation paths)
- First Committee Meeting Held (Month 2 = 2026-12-08)
- Meeting Minutes: Soft Tooling Schedule Reviewed, Supplier Agreements Confirmed, Quality-Control Plan Finalized

**Dependencies:**

- Primary and secondary fabricators identified and agreements signed
- Gasket suppliers identified and quoted
- Freight logistics partner identified and rates negotiated
- Production and supply-chain committee charter drafted by founder

### 21. Founder negotiates volume-discount freight rates with 2–3 freight carriers (DHL, UPS, FedEx, local carriers) for Year-1 presale and production shipments. Founder requests quotes for: (1) standard parcel shipments from Tallinn to major EU destinations (EUR 8–15 per unit estimate), (2) volume discounts based on 1,500 units Year-1 forecast, (3) pricing lock-in period (Year-1, with price adjustment effective Month 13 = 2027-11-08 onward), (4) tracking and delivery-confirmation capability. Freight rates are locked with the selected carrier(s) by Month 1.5 (2026-11-23). Landed cost impact on unit margin is calculated (EUR 12 per unit estimate, part of EUR 82 direct cost). Freight costs are incorporated into the monthly cash-flow dashboard.

**Responsible Body/Role:** Founder / Project Principal (with Production and Supply Chain Committee input)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 1.5 (2026-11-23)

**Key Outputs/Deliverables:**

- Freight Carrier Quotes Received (3 carriers, rates per unit EUR 8–15 estimate, volume discounts)
- Freight Rates Locked (selected carrier(s), pricing locked for Year-1, EUR 12 per unit budgeted)
- Freight Contract Signed (carrier, pricing, SLA, tracking, delivery confirmation)
- Landed Cost Impact Documented (included in EUR 82 direct cost, EUR 67 contribution margin)

**Dependencies:**

- Production volume forecast (1,500 units Year-1) and shipment destinations known
- Primary production site (Tallinn) confirmed

### 22. Founder establishes the Financial Governance and Gate Measurement Committee by confirming membership: (1) Founder (cash-flow owner, tranche decision authority), (2) External Financial Advisor (independent co-signatory on gate result), (3) Part-Time Operations/Finance Person (monthly cash reconciliation, invoice tracking). Founder schedules the first meeting for Month 2 (2026-12-08) to review: (1) the written cash-flow gate measurement convention, (2) the monthly burn schedule and budget allocation, (3) monthly cash-reconciliation methodology (budget vs. actuals, presale deposits, delivered-unit revenue, opex), (4) the gate calculation formula (EUR 25k quarterly surplus threshold, Months 9–12 = 2027-07-08 to 2027-10-08 measurement window). A written committee charter is confirmed by Month 2 (2026-12-08).

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1.5 (2026-11-23) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Financial Governance and Gate Measurement Committee Formally Constituted (membership confirmed)
- Committee Charter Signed (decision rights, monthly meeting cadence, gate measurement protocol)
- First Committee Meeting Held (Month 2 = 2026-12-08)
- Monthly Cash-Reconciliation Template Confirmed (budget vs. actuals, presale deposits, revenue, opex, runway)
- Gate Calculation Formula Locked (EUR 25k quarterly threshold, Months 9–12 = 2027-07-08 to 2027-10-08 measurement window)

**Dependencies:**

- Cash-flow gate measurement convention drafted and approved by Steering Committee
- Monthly burn schedule created and approved
- External financial advisor recruited
- Part-time operations/finance person identified

### 23. Founder creates a comprehensive compliance checklist (to be reviewed monthly by the Compliance and Liability Committee and Financial Governance Committee) covering: (1) marketing claims limiting to measured attenuation and tested frequency band, (2) scope statement (protects stored spare devices only) present in all materials, (3) warranty and refund terms aligned with consumer law, (4) product-liability insurance active and cover verified, (5) accredited lab report published with every unit sold, (6) presale SLA (2–3 week lead time, 30-day refund window) honored, (7) no claims of protection for active equipment or grid-scale events, (8) monthly audit sample (presale marketing, website, email communications reviewed). Compliance checklist is finalized and published by Month 2 (2026-12-08). First audit is conducted by Month 2.5 (2026-12-23).

**Responsible Body/Role:** Founder / Project Principal (with Compliance and Liability Committee oversight)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Compliance Checklist Document (monthly audit protocol, 8-item checklist, responsibility assignments)
- First Monthly Audit Conducted (Month 2.5 = 2026-12-23, sample of marketing materials reviewed)
- Audit Result Documented (pass/fail per item, any drift noted and corrected)
- Compliance Dashboard Created (tracking compliance status monthly, flagging any corrective actions needed)

**Dependencies:**

- Scope statement and marketing disclaimers finalized
- Product-liability insurance locked
- Accredited lab engagement plan confirmed
- Presale terms and delivery SLA published

### 24. Founder hires or confirms a part-time operations and finance person (10–15 hours/week, EUR 200–300/week estimate) by Month 1 (2026-11-08), or immediately if presale volume warrants earlier start. This person is responsible for: (1) daily presale-deposit tracking and reconciliation, (2) refund approvals and processing, (3) monthly cash-reconciliation (budget vs. actuals), (4) presale-to-delivery queue management and shipment coordination, (5) quality-control inspections (initial production batches), (6) supplier and fabricator communications, (7) presale dashboard updates (weekly), (8) monthly compliance audit. Person is on-boarded by Month 1 (2026-11-08) with documented procedures and access to all systems (deposit account, budget spreadsheet, supplier contacts). Backup procedures are documented in case this person becomes unavailable.

**Responsible Body/Role:** Founder / Project Principal

**Suggested Timeframe:** Month 1 (2026-11-08)

**Key Outputs/Deliverables:**

- Part-Time Operations/Finance Person Hired and On-Boarded
- Job Description and Procedures Manual Created (deposit tracking, refunds, cash reconciliation, quality control, supplier coordination)
- System Access Granted (deposit account, budget spreadsheet, presale platform, supplier databases)
- Backup Procedures Documented (in case person becomes unavailable)

**Dependencies:**

- Budget for operations person allocated (EUR 5–8k Year-1 within the EUR 75k marketing/operations line)
- Presale platform ready and campaigns launching

### 25. Founder convenes the first Steering Committee review meeting at Month 2 (2026-12-08) to assess Project governance setup progress across all five committees. Agenda includes: (1) governance framework checklist (five committees formally established? charters signed? first meetings held?), (2) budget allocation and burn-schedule approval (EUR 400k Year-1 by category), (3) lab engagement status (statement of work signed? report date locked?), (4) presale campaign launch confirmation (all three segments active? deposit tracking working?), (5) compliance framework status (legal opinion received? insurance locked? scope statement published?), (6) production timeline confirmation (soft and hard tooling gated correctly?), (7) risk register initial review (top 10–15 risks identified and mitigation assigned). Meeting minutes are documented and each committee head confirms their readiness. A governance 'go' decision is issued or a blockers list is escalated.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Governance Readiness Checklist Completed (five committees established, charters signed, kickoff meetings held)
- First Steering Committee Review Meeting Held (Month 2 = 2026-12-08)
- Meeting Minutes: Governance 'Go' Decision Issued or Blockers Escalated
- Risk Register Initial (15 risks, owners, mitigation plans, review cadence)
- Budget Allocation Approved (EUR 400k Year-1 by category, monthly burn schedule locked)

**Dependencies:**

- All five committees formally established and chartered
- First meetings of each committee held
- Lab, EMC consultancy, university, fabricator, and insurer agreements signed
- Presale campaigns launched

### 26. Founder initiates prototype RF design with the EMC consultancy and university lab. Prototype design activities include: (1) enclosure geometry, seam design, gasket specification, and internal layout for phones and laptops, (2) RF shielding analysis (seam leakage, aperture shielding, lid-seal performance) using simulation or lab measurement, (3) materials selection (aluminum or steel, gasket material), (4) preliminary bill of materials and unit cost estimate. Design is reviewed by Month 2 (2026-12-08) (prototype readiness for rig testing). Prototype fabrication begins using soft tooling (laser-cut samples from the primary fabricator). First prototype samples are ready for in-house rig testing by Month 3 (2027-01-08). Design documentation and trade-off rationale are recorded.

**Responsible Body/Role:** Design and Certification Working Group (EMC Consultancy, University Lab, Founder)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 2 (2026-12-08)

**Key Outputs/Deliverables:**

- Prototype Design Specification (enclosure geometry, materials, seam design, gasket spec, BOM, unit cost estimate)
- RF Shielding Analysis (simulation or preliminary measurement, attenuation expectations, frequency band)
- Prototype Fabrication Samples Ordered (soft-tooling laser-cut samples, primary fabricator)
- Design Review Meeting (Month 2 = 2026-12-08, EMC consultancy, university lab, founder approval)

**Dependencies:**

- Enclosure architecture decision finalized (single-SKU rigid metal, conductive-gasket seam)
- EMC consultancy and university lab agreements signed
- Prototype fabricator (primary and secondary) qualified

### 27. University lab sets up the in-house shielding test rig for RF measurement and validation. Rig setup activities include: (1) RF source (signal generator or pulser), (2) measurement equipment (field probes, RF meter), (3) calibration and frequency-range setup (target frequency band matching accredited lab standard, proposed IEEE 299.1 or equivalent), (4) test sample holder and sealing methodology, (5) validation methodology (attenuation measurement across frequency band, two independent seam cycles for durability assessment). Rig is ready for prototype testing by Month 3 (2027-01-08). Rig calibration and baseline testing are documented. Cost of rig capital and consumables (EUR 5–10k estimate) is funded from the co-development agreement.

**Responsible Body/Role:** Design and Certification Working Group (University Lab lead, EMC Consultancy support)

**Suggested Timeframe:** Month 1 (2026-11-08) to Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- In-House Shielding Test Rig Designed and Built (RF source, measurement equipment, holder, calibration)
- Rig Calibration Report (baseline frequency response, measurement accuracy verification)
- Test Methodology Documented (frequency band, attenuation measurement procedure, durability/seam-cycle protocol)
- Rig Ready for Prototype Testing by Month 3 (2027-01-08)

**Dependencies:**

- University lab partnership agreement signed
- Frequency band and measurement standard confirmed (from accredited lab pre-engagement)
- Rig capital and consumables budget (EUR 5–10k estimate) allocated

### 28. University lab and founder conduct in-house shielding validation testing on the first prototype enclosures using the test rig. Testing includes: (1) attenuation measurement across the target frequency band (e.g., 50 MHz to 1 GHz, estimate, to be confirmed by lab standard), (2) seam integrity and gasket contact assessment (visual and measurement), (3) first seam-cycle durability test (open and close the lid 10 times, re-measure attenuation to verify gasket resilience), (4) second independent seam cycle on a fresh sample (confirm repeatability). Test results are documented with attenuation curves, frequency-band summary, pass/fail criteria (minimum attenuation target, e.g., >60 dB estimate, to be confirmed by lab). If results meet in-house criteria (two passing cycles), design is deemed 'pre-test ready' and escalated to the accredited lab for design-readiness review. If results fall short, a redesign scope and impact are assessed by the Design & Certification group and escalated to Steering Committee.

**Responsible Body/Role:** Design and Certification Working Group (University Lab lead, Founder, EMC Consultancy support)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- In-House Rig Validation Test Report (attenuation data across frequency band, two independent seam cycles, pass/fail criteria met)
- Design Pre-Test Readiness Confirmed (documented by university lab and EMC consultancy)
- Prototype Revision Summary (any minor changes made to prototype based on rig results, seam adjustments, gasket refinements)
- Lab Samples Prepared (prototype enclosure(s) packaged for shipment to accredited lab, Month 4 = 2027-02-08)

**Dependencies:**

- In-house test rig operational and calibrated
- Prototype samples from soft-tooling fabrication ready
- Test methodology and pass/fail criteria documented

### 29. Founder and Design & Certification group coordinate with the accredited EMC laboratory to conduct a pre-submission design-readiness review. This review (EUR 2–3k estimate, included in the EUR 15k lab budget) includes: (1) presentation of the prototype design, RF analysis, and in-house rig results to the lab's RF engineer, (2) lab assessment of design readiness and likely attenuation performance, (3) lab confirmation of test methodology and frequency range (aligned with the lab's standard), (4) discussion of sample preparation and submission timing, (5) lab feedback on any design features that may impact shielding or require re-qualification. Output: design-readiness confirmation letter from the lab. If the lab raises any concerns (e.g., seam design may not achieve claimed attenuation, frequency range mismatch), the Design & Certification group assesses redesign scope and cost impact (potentially drawing from the EUR 20k reserve). If readiness is confirmed, sample submission is scheduled for Month 4 (2027-02-08).

**Responsible Body/Role:** Design and Certification Working Group (EMC Consultancy lead, Founder, Lab liaison)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Lab Pre-Submission Design-Readiness Review Conducted (Month 4 = 2027-02-08)
- Lab Design-Readiness Confirmation Letter (design is test-ready, no major concerns, attenuation expectations align with measured targets)
- Test Sample Preparation Plan (prototype enclosure(s), gasket condition, sealing procedure, sample handling)
- Lab Test Schedule Confirmed (samples submitted Month 4 = 2027-02-08, report delivery Month 5 = 2027-03-08)

**Dependencies:**

- In-house rig validation completed and pre-test readiness confirmed
- Accredited lab statement of work signed with design-readiness review scope defined
- Prototype samples ready for lab submission

### 30. Founder and EMC consultancy coordinate final prototype sample preparation and submission to the accredited EMC laboratory. Sample preparation includes: (1) enclosure unit(s) representing production-representative design (soft tooling or limited hard-tool trial sample), (2) gasket in production-representative condition, (3) sealing and assembly per production procedure, (4) documentation of sample condition, serial numbers, and photographic record. Samples are shipped to the lab by early Month 4 (2027-02-08) with handling instructions and test-request form. Lab acknowledges receipt and confirms expected report delivery by Month 5 (2027-03-08), latest Month 6 (2027-04-08). Any concerns about sample condition or test feasibility are escalated immediately to the Design & Certification group.

**Responsible Body/Role:** Design and Certification Working Group (Founder, EMC Consultancy, Lab liaison)

**Suggested Timeframe:** Month 4 (2027-02-08)

**Key Outputs/Deliverables:**

- Lab Samples Prepared and Documented (production-representative enclosure, gasket, sealing per procedure, photos)
- Samples Shipped to Accredited Lab (shipping confirmation, tracking number, test-request form submitted)
- Lab Receipt Confirmed (email from lab acknowledging receipt, sample condition OK, test schedule confirmed)

**Dependencies:**

- Prototype design finalized and pre-test readiness confirmed by lab
- Prototype samples from soft-tooling fabrication ready for submission
- Lab statement of work and design-readiness review completed

### 31. Accredited EMC laboratory conducts full shielding-effectiveness testing on the submitted prototype samples. Testing includes: (1) RF source application across the frequency band (proposed IEEE 299.1 standard or equivalent, not verified), (2) attenuation measurement at multiple frequencies (e.g., 50 MHz to 1 GHz in 50 MHz steps, estimate), (3) attenuation data plotted as frequency sweep, (4) identification of any frequency bands with lower-than-expected attenuation or seam/seal issues, (5) final report with attenuation curves, summary table (minimum/maximum/average attenuation), frequency range tested, test methodology, and recommendations (if any). Lab delivers the report by Month 5 (2027-03-08) as scheduled in the statement of work. Report is marked 'final' and suitable for publication with products.

**Responsible Body/Role:** Accredited EMC Laboratory (external test execution)

**Suggested Timeframe:** Month 4 (2027-02-08) to Month 5 (2027-03-08)

**Key Outputs/Deliverables:**

- Accredited Lab Test Execution (RF testing per IEEE 299.1 or equivalent standard)
- Lab Report Delivered (attenuation curves, frequency sweep, summary table, test methodology, recommendations, Month 5 = 2027-03-08)

**Dependencies:**

- Lab samples submitted and received
- Lab testing schedule confirmed
- Test methodology and frequency range aligned between lab and founder

### 32. Design & Certification Working Group receives and reviews the accredited lab report. Review includes: (1) confirmation that attenuation results meet or exceed in-house rig predictions and marketing claims, (2) identification of any frequency bands with lower attenuation or potential seam/gasket issues, (3) assessment of whether results support the intended sales claims (e.g., '>60 dB attenuation from 50 MHz to 1 GHz' estimate, to be confirmed by actual lab data), (4) evaluation of any lab recommendations for design changes or re-qualification, (5) discussion of re-test cost and timeline if results fall short of claims. If results are satisfactory, the group approves the design as 'certified' and the report is designated for publication with every product. If results reveal issues requiring redesign, the group escalates cost/timeline impact to Steering Committee and assesses whether to: (a) accept narrower frequency-range or attenuation claims (no redesign), (b) fund a minor redesign from the EUR 20k reserve and schedule a re-test (EUR 8–15k re-test cost), or (c) halt the project. Design readiness for hard tooling is confirmed by Month 5.5 (2027-03-23).

**Responsible Body/Role:** Design and Certification Working Group (Founder, EMC Consultancy, Steering Committee oversight)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Lab Report Reviewed and Assessed (attenuation data, frequency range, claim alignment confirmed)
- Design Certification Decision (approved for publication, or requires redesign with cost/timeline impact)
- Marketing Claims Finalized (attenuation values, frequency band, scope statement, all backed by lab data)
- Lab Report Approved for Publication (final version, to be published with every product shipped)

**Dependencies:**

- Accredited lab report delivered (Month 5 = 2027-03-08)
- In-house rig results available for comparison
- Design and Certification group meeting held to review report

### 33. Steering Committee holds a special review meeting at Month 5 (2027-03-08) or Month 5.5 (2027-03-23) to assess the accredited lab report and confirm readiness for the hard-tooling gate decision at Month 5–6 (2027-03-08 to 2027-04-08). Agenda includes: (1) lab report summary and design certification status, (2) presale deposit status (target EUR 80k net deposits, proposed threshold, by Month 6 = 2027-04-08), (3) in-house rig validation completion (two independent seam cycles confirmed), (4) hard-tooling release decision criteria: deposits >= EUR 80k AND lab pre-test confirms design readiness AND in-house rig passes twice. If all gate criteria are met (or expected to be met by Month 6 = 2027-04-08), the committee issues a 'gate conditional' approval, authorizing founder to submit the hard-tooling order to the fabricator once deposits are confirmed. If gate criteria are not met (e.g., lab results fall short, deposits lag), the committee escalates redesign or presale-pivot recommendations.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 5.5 (2027-03-23)

**Key Outputs/Deliverables:**

- Steering Committee Special Review Meeting Held (Month 5 = 2027-03-08)
- Lab Report Assessment and Design Certification Confirmed (or redesign scope escalated)
- Hard-Tooling Gate Readiness Assessed (design certified, presale deposits approaching EUR 80k estimate, in-house rig validated)
- Conditional Hard-Tooling Gate Approval (founder authorized to release tooling order once deposits confirmed at Month 6 = 2027-04-08)

**Dependencies:**

- Accredited lab report delivered and reviewed
- Presale deposits tracked and reported (current status at Month 5 = 2027-03-08)
- In-house rig validation completed
- Steering Committee meeting scheduled and held

### 34. Financial Governance and Gate Measurement Committee, led by founder and external advisor, confirms that net presale deposits (after refunds) have reached or are projected to exceed EUR 80k (proposed threshold) by Month 6 (2027-04-08). Verification includes: (1) total deposits received (summed from separate deposit account), (2) refunds approved and paid (summed), (3) net deposits calculated (deposits minus refunds), (4) projection of deposits through Month 6 (2027-04-08) based on current deposit velocity and any campaign adjustments. Once net deposits reach EUR 80k, founder and advisor jointly sign a 'Hard-Tooling Gate Confirmation' document, authorizing the Production and Supply Chain Committee to release the hard-tooling order to the primary fabricator. Gate confirmation is documented in writing by Month 6 (2027-04-08).

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Founder, External Advisor, Operations/Finance support)

**Suggested Timeframe:** Month 5 (2027-03-08) to Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Monthly Presale Dashboard Updated (deposits, refunds, net deposits, segment mix, conversion rate, AOV)
- Hard-Tooling Gate Confirmation Calculated (net deposits >= EUR 80k verified, documented in writing)
- Gate Confirmation Signed (founder and external advisor sign-off, Month 6 = 2027-04-08)
- Hard-Tooling Authorization Issued to Production Committee (move forward with tooling order)

**Dependencies:**

- Presale campaigns active and deposits flowing for 4–5 months (Months 1–5 = 2026-11-08 to 2027-03-08)
- Deposit tracking and reconciliation procedures working
- Gate threshold (EUR 80k) and confirmation protocol established

### 35. Production and Supply Chain Committee, authorized by the hard-tooling gate confirmation, submits the hard-tooling order to the primary Tallinn fabricator. Hard-tooling order includes: (1) tool specification and design documentation (from the finalized prototype design), (2) production quantity (first batch: 800 units; follow-on batches: 700 units Months 9–12 = 2027-07-08 to 2027-10-08), (3) delivery schedule (Batch 1 ready by Month 8 = 2027-06-08, follow-on by Month 12 = 2027-10-08), (4) quality standards and inspection requirements, (5) tooling cost (locked at EUR 30k estimate per agreement), (6) contingency contact (if primary fabricator encounters issues, secondary fabricator is notified). Hard-tooling order is formalized in a signed purchase order by founder and fabricator by Month 6 (2027-04-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Founder, Primary Fabricator, Backup Fabricator standby)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Hard-Tooling Order Submitted (tool design, production batch quantities, delivery schedule, cost EUR 30k locked)
- Purchase Order Signed (founder and primary fabricator, Month 6 = 2027-04-08)
- Secondary Fabricator Alert (notified of tooling order and backup readiness)
- Tool Delivery Schedule Confirmed (fabricator commits delivery timeline for Batch 1 by Month 8 = 2027-06-08)

**Dependencies:**

- Hard-tooling gate confirmation signed and authorization issued
- Design finalized and certified by accredited lab
- Prototype design documentation complete and ready for tooling
- Primary fabricator agreement signed with tooling cost and schedule locked

### 36. Production and Supply Chain Committee confirms that conductive-gasket buffer stock (30-day supply, EUR 5–10k estimate) is secured, in stock, and ready for production. Gasket material sourcing verification includes: (1) primary gasket supplier orders and delivery confirmed (30-day supply in-house or in-transit), (2) backup gasket supplier identified and samples tested, (3) gasket material specifications confirmed to match lab-validated seam design, (4) material storage conditions appropriate (temperature, humidity control), (5) consumption schedule understood (gaskets consumed as units are produced). Gasket buffer-stock order is placed by Month 6 (2027-04-08) to ensure 30-day supply is available when production begins (Batch 1, Months 7–8 = 2027-05-08 to 2027-06-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Gasket Supplier, Backup Supplier, Founder oversight)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Gasket Buffer Stock Secured (30-day supply in-house or in-transit, EUR 5–10k investment)
- Supplier Delivery Confirmed (primary supplier commitment to delivery by Month 6.5 = 2027-04-23)
- Quality and Spec Verification (material samples tested, attenuation performance confirmed, seam design compatibility)
- Storage Plan Confirmed (handling procedures, environment control, inventory tracking)

**Dependencies:**

- Enclosure seam design finalized and lab-validated
- Primary and backup gasket suppliers qualified and agreements signed
- Gasket budget (EUR 5–10k estimate, part of EUR 160k production line) allocated

### 37. Presale and Revenue Validation Committee, supported by the operations/finance person, conducts the Month 3 (2027-01-08) segment-mix analysis. Analysis includes: (1) deposit count and value by segment (prepper, infrastructure, privacy/forensics), (2) deposit rates and conversion percentages for each segment, (3) average order values by segment, (4) pivot trigger assessment: if prepper deposits > 70% of total, a marketing-spend reallocation recommendation is issued (shift EUR 10–15k from prepper to infrastructure/privacy channels). If pivot triggers are activated, the committee meets with founder to approve the reallocation and executes revised marketing campaigns within 3 business days. If segment mix looks balanced or infrastructure/privacy leads, presale momentum is confirmed and no major pivot is needed. Analysis is documented and shared with Steering Committee.

**Responsible Body/Role:** Presale and Revenue Validation Committee (Founder, Operations/Finance, External Advisor)

**Suggested Timeframe:** Month 3 (2027-01-08)

**Key Outputs/Deliverables:**

- Segment-Mix Analysis Report (deposits by segment, conversion rates, AOV by segment, pivot trigger assessment)
- Month 3 (2027-01-08) Presale Dashboard Updated (deposits YTD, refunds, net deposits, segment % breakdown, rolling conversion rate)
- Pivot Decision Issued (marketing spend reallocation approved/not needed, messaging adjustments if any)
- Marketing Campaign Adjustments Executed (if pivot triggered, EUR 10–15k reallocated within 3 days)

**Dependencies:**

- Presale campaigns running for 2 months (Months 1–3 = 2026-11-08 to 2027-01-08)
- Deposit tracking dashboard operational
- Pivot trigger thresholds and reallocation plan pre-approved by Steering Committee

### 38. Presale and Revenue Validation Committee conducts the Month 6 (2027-04-08) presale-cutoff decision and announcement. Decision includes: (1) confirmation that presale deposit offer (refundable) closes on Month 8 (2027-06-08), (2) communication to presale customers that orders placed after Month 8 (2027-06-08) will not be fulfilled within the Months 7–12 (2027-05-08 to 2027-10-08) delivery window and will defer to later batches, (3) rationale: ensuring all presale orders from Months 1–8 (2026-11-08 to 2027-06-08) are delivered by Month 12 (2027-10-08) so that delivery-unit revenue counts toward the cash-flow gate measurement, (4) continued presale marketing through Month 8 (2027-06-08), with a final push in Month 7–8 (2027-05-08 to 2027-06-08), (5) presale cutoff enforcement: any orders after Month 8 (2027-06-08) are accepted as 'regular orders' with longer lead times or deferred to post-gate fulfillment. Cutoff announcement is published on the website and sent to presale list by Month 6.5 (2027-04-23).

**Responsible Body/Role:** Presale and Revenue Validation Committee (Founder, Operations/Finance)

**Suggested Timeframe:** Month 6 (2027-04-08)

**Key Outputs/Deliverables:**

- Presale Cutoff Decision Document (Month 8 = 2027-06-08 cutoff, rationale, delivery window locked)
- Presale Cutoff Announcement (published on website, sent to presale list by Month 6.5 = 2027-04-23)
- Order Queue Management Plan (presale orders tracked separately from post-cutoff orders, delivery sequencing confirmed)

**Dependencies:**

- Hard-tooling gate confirmation and production authorization complete (Month 6 = 2027-04-08)
- Presale momentum confirmed (deposits on track for EUR 80–120k estimate)
- Delivery schedule and fulfillment capacity understood (build-to-order, 2–3 week lead time)

### 39. Production and Supply Chain Committee confirms receipt of hard-tooling from the primary Tallinn fabricator and validates tool quality. Tool validation includes: (1) physical inspection of the hardened tool/dies for accuracy and finish, (2) trial production run: 10–20 sample units produced using the hard tooling to verify fit, finish, seam integrity, and gasket contact, (3) comparison of trial-run units against prototype design and lab-validated specification, (4) identification of any tool adjustments needed (minor tweaks to die tolerance, gasket seating, or sealing surfaces), (5) quality-control checklist sign-off. If trial run is successful, full production authorization is issued. If issues emerge, they are corrected by the fabricator before production ramp (no charge to founder per agreement). Tool validation is completed by Month 7 (2027-05-08).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator, Founder quality sign-off, Operations/Finance inspection support)

**Suggested Timeframe:** Month 7 (2027-05-08)

**Key Outputs/Deliverables:**

- Hard Tool Received and Validated (tool quality verified, trial production run completed)
- Trial Production Report (10–20 sample units, fit/finish/seam assessment, QC checklist sign-off)
- Tool Adjustment Confirmation (any minor adjustments completed by fabricator)
- Full Production Authorization Issued (Batch 1 production can proceed, month 7–8 = 2027-05-08 to 2027-06-08)

**Dependencies:**

- Hard-tooling order submitted and delivered (Month 6–7 = 2027-04-08 to 2027-05-08)
- Quality-control inspection procedures documented
- Trial production trial capacity available in fabricator's schedule

### 40. Production and Supply Chain Committee confirms launch of Batch 1 production (800 units) at the primary Tallinn fabricator. Production launch includes: (1) release of material (sheet metal, gaskets, fasteners, packaging) to the fabricator's production floor, (2) start of laser-cutting, bending, seam-welding (or assembly), gasket placement, and final assembly per production procedure, (3) in-process quality checks (seam inspection, gasket seating verification, fit testing with representative phones and laptops), (4) final packing and labeling per presale order specifications, (5) production status tracked weekly (units produced, quality issues, on-time delivery forecast). Batch 1 production runs Months 7–8 (2027-05-08 to 2027-06-08), with delivery expected by end of Month 8 (2027-06-08). First units (50–100 estimate) are ready for presale fulfillment by Month 7.5 (2027-05-23).

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator lead, Founder QA oversight, Operations/Finance coordination)

**Suggested Timeframe:** Month 7 (2027-05-08) to Month 8 (2027-06-08)

**Key Outputs/Deliverables:**

- Batch 1 Production Launched (800 units, laser cutting through final assembly and packing)
- Weekly Production Status Reports (units produced, defect findings, on-time delivery forecast)
- Quality Control Inspections (in-process checks, final fit testing, documented results)
- First Units Ready for Fulfillment (50–100 units by Month 7.5 = 2027-05-23, shipped to presale customers)

**Dependencies:**

- Hard tool delivered and validated (Month 7 = 2027-05-08)
- Gasket buffer stock in-house and ready (Month 6–7 = 2027-04-08 to 2027-05-08)
- Presale order queue compiled and prioritized
- Freight carrier pickup schedule coordinated

### 41. Presale fulfillment begins at the operations/finance team level. Fulfillment process includes: (1) daily order queue review (presale orders chronologically ordered, build-to-order confirmation sent to customer with 2–3 week delivery estimate), (2) production status check with fabricator (where are my units in the queue?), (3) unit receipt from fabricator and quality-final inspection (visual check, test fit with representative devices, gasket condition), (4) packing and labeling (include accredited lab report, scope statement card, warranty terms, contact info), (5) pickup coordination with freight carrier (DHL, UPS, or local carrier), (6) shipment tracking number sent to customer, (7) delivery confirmation received and recorded. Fulfillment pace scales with Batch 1 delivery: 50–100 units Months 7.5–8 (2027-05-23 to 2027-06-08), 400–500 units by end of Month 9 (2027-07-08), 750 units by end of Month 12 (2027-10-08). Monthly fulfillment dashboard tracks units shipped, refunds issued, delivery-time compliance.

**Responsible Body/Role:** Presale and Revenue Validation Committee (Operations/Finance lead, Production & Supply Chain coordination, Founder oversight)

**Suggested Timeframe:** Month 7 (2027-05-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Daily Fulfillment Process Implemented (order queue, production coordination, QC inspection, packing, shipment tracking)
- Monthly Fulfillment Dashboard (units shipped, refunds issued, delivery-time compliance, customer satisfaction notes)
- Lab Report Packaged with Every Unit (accredited lab report, scope statement, warranty terms)
- Delivery Performance Tracked (target: 750 units delivered by Month 12 = 2027-10-08)

**Dependencies:**

- Batch 1 production and first units ready (Month 7.5 = 2027-05-23)
- Presale order queue compiled and prioritized
- Freight carrier integration completed (pickup, tracking, delivery)
- Operations/finance fulfillment procedures documented

### 42. Production and Supply Chain Committee confirms launch of follow-on production batches (700 units total, split across Months 9–12 = 2027-07-08 to 2027-10-08) at the primary fabricator. Follow-on batches are scheduled to match presale fulfillment demand: (1) Month 9 (2027-07-08): 350 units, (2) Month 11 (2027-09-08): 350 units, with flexible adjustment based on presale delivery pace and customer feedback. Each batch follows the same quality-control procedures as Batch 1. Production status and quality metrics are reported weekly to the Production Committee. By Month 12 (2027-10-08), all follow-on batches are delivered and presale fulfillment is complete.

**Responsible Body/Role:** Production and Supply Chain Committee (Primary Fabricator, Founder, Operations/Finance coordination)

**Suggested Timeframe:** Month 9 (2027-07-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Follow-On Batch Schedule Confirmed (700 units total: 350 Months 9–10 = 2027-07-08 to 2027-08-08, 350 Months 11–12 = 2027-07-08 to 2027-10-08)
- Weekly Production Status Reports (units produced, delivery tracking, quality metrics)
- By Month 12 (2027-10-08): All Year-1 Units Delivered (1,500 units total shipped to presale customers)

**Dependencies:**

- Batch 1 production completed and fulfillment underway (Months 7–9 = 2027-05-08 to 2027-07-08)
- Presale demand and fulfillment pace confirmed
- Fabricator capacity and delivery schedule confirmed for follow-on batches

### 43. Financial Governance and Gate Measurement Committee begins monthly cash-flow tracking and reconciliation, starting Month 1 (2026-11-08). Monthly reconciliation activities include: (1) summary of Year-1 budget allocation vs. actual spending (design, lab, soft tooling, hard tooling, production, marketing, reserves), (2) variance analysis (any category >10% variance is flagged and explained), (3) presale deposits (gross received, refunds approved, net deposits held in earmarked account, never commingled with operational cash), (4) delivered-unit revenue (units shipped, invoiced, paid; sample audit of 10–15% of receipts to confirm cash payment), (5) operating expenses (salaries, software, legal, insurance), (6) cash balance and months of runway (based on current burn rate), (7) gate projection: on track for EUR 25k quarterly surplus by Month 12 (2027-10-08) or on-risk. Monthly reconciliation is completed by Month-end + 7 days and reviewed by founder and external advisor. Results are documented in the monthly dashboard and escalated to Steering Committee.

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead, External Advisor, Founder review)

**Suggested Timeframe:** Ongoing, Month 1 (2026-11-08) through Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Monthly Cash-Flow Reconciliation Dashboard (budget vs. actuals, presale deposits, delivered-unit revenue, opex, cash balance, runway)
- Monthly Variance Report (flagging categories >10% variance and corrective actions)
- Quarterly Deep-Dive Analysis (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) with advisor sign-off

**Dependencies:**

- Monthly burn schedule and budget allocation established (Month 0.5 = 2026-10-23)
- Presale deposit account set up and ring-fenced (Month 0.5 = 2026-10-23)
- Operations/finance person on-boarded with reconciliation procedures documented

### 44. Compliance and Liability Committee conducts monthly compliance audits starting Month 2.5 (2026-12-23), reviewing a sample of presale marketing materials, website copy, email communications, and product packing insert. Each audit checks the 8-item compliance checklist: (1) marketing claims limited to measured attenuation, (2) scope statement present, (3) warranty/refund terms compliant, (4) insurance status verified, (5) lab report to be published with units, (6) presale SLA honored, (7) no claims of protection for active equipment or grid-scale events, (8) customer refund/complaint log reviewed. Audit results (pass/fail per item, any drift) are documented and shared with founder. If drift is detected (e.g., a marketing email mentions 'grid-scale protection'), founder is notified and has 3 business days to correct it. Audits are completed monthly and escalated to Steering Committee quarterly (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08).

**Responsible Body/Role:** Compliance and Liability Committee (Founder, Legal Counsel, Compliance auditor role)

**Suggested Timeframe:** Ongoing, Month 2.5 (2026-12-23) through Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Monthly Compliance Audit Report (8-item checklist completed, pass/fail per item, drift corrections)
- Compliance Dashboard (tracking compliance status monthly, flagging corrective actions)
- Quarterly Escalations (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) to Steering Committee if major issues

**Dependencies:**

- Compliance checklist established and documented (Month 2 = 2026-12-08)
- Marketing materials and communications published and accessible for audit
- Compliance audit procedures documented and assigned

### 45. Steering Committee holds monthly oversight meetings (last week of each month, typically 1 hour) starting Month 1 (2026-11-08) through Month 12 (2027-10-08). Monthly agenda includes: (1) actual vs. budgeted spending (design, lab, tooling, production, marketing) and variance explanation, (2) presale deposit velocity, refund rate, and segment mix; pivot triggers assessed (prepper > 70%, conversion < 40%), (3) lab status (in progress, pre-test results, design certification), (4) hard-tooling gate readiness assessment (Months 5–6 = 2027-03-08 to 2027-04-08 focus), (5) production progress and quality metrics (Months 7–12 = 2027-05-08 to 2027-10-08), (6) quarterly cash-flow projection and months of runway remaining, (7) any unbudgeted items, overruns, or requests to reallocate reserve funds, (8) compliance audit results (quarterly summary), (9) risk register review and updates. Monthly minutes are documented, and decisions/escalations are recorded. Special meetings are convened if spending variance exceeds 10%, presale conversion falls below 40% (estimated), or cash balance threatens runway.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor)

**Suggested Timeframe:** Ongoing, Month 1 (2026-11-08) through Month 12 (2027-10-08), monthly cadence, last week of month

**Key Outputs/Deliverables:**

- Monthly Steering Committee Meeting Minutes (agenda items, decisions, escalations documented)
- Monthly Dashboard Review (budget variance, presale progress, lab/production status, cash position)
- Special Meetings (convened if triggers met: 10% variance, <40% conversion, runway threatened)

**Dependencies:**

- Steering Committee charter and meeting calendar established (Month 0.5 = 2026-10-23)
- Monthly input dashboards from each working committee available
- Founder and advisor availability and engagement confirmed

### 46. Financial Governance and Gate Measurement Committee, with founder and external advisor participation, begins the EUR 350k tranche gate-measurement process at Month 11 (2027-09-08), preparing for the final gate decision at Month 12 (2027-10-08). Gate-measurement activities include: (1) compilation of delivered-unit revenue data for the trailing quarter (Months 9–12 = 2027-07-08 to 2027-10-08): units shipped, invoiced, and paid only (no presale deposits), (2) subtraction of direct unit costs (EUR 70 unit cost + EUR 12 freight = EUR 82 per unit estimate) from revenue, (3) subtraction of recurring opex (EUR 20k per quarter estimate: marketing, operations, insurance, legal, software), (4) calculation of operating cash surplus (or deficit) for Months 9–12 (2027-07-08 to 2027-10-08), (5) comparison of result against the gate threshold (EUR 25k proposed threshold). Preliminary gate result is ready by Month 12 (2027-10-08), documented in writing with supporting invoices and payment records audited (10–15% sample). Final gate sign-off is scheduled for Month 12.5 (2027-10-23).

**Responsible Body/Role:** Financial Governance and Gate Measurement Committee (Operations/Finance lead, External Advisor, Founder)

**Suggested Timeframe:** Month 11 (2027-09-08) to Month 12 (2027-10-08)

**Key Outputs/Deliverables:**

- Gate-Measurement Data Compiled (delivered units, revenue, costs, opex for Months 9–12 = 2027-07-08 to 2027-10-08)
- Supporting Documentation Audited (sample of invoices and payment records verified, 10–15% of transactions)
- Gate Calculation Completed (operating cash surplus or deficit computed, threshold comparison)
- Preliminary Gate Result Documented (revenue, costs, opex, surplus/deficit, signature lines for final sign-off)

**Dependencies:**

- Delivered-unit revenue tracking active and complete (Months 7–12 = 2027-05-08 to 2027-10-08)
- Presale fulfillment complete by Month 12 (2027-10-08) (1,500 units delivered)
- Monthly cash-flow reconciliation and expense tracking ongoing

### 47. Project Steering Committee holds a final gate-measurement review meeting at Month 12 (2027-10-08) or Month 12.5 (2027-10-23) to assess the calculated gate result against the threshold (EUR 25k quarterly operating surplus, Months 9–12 = 2027-07-08 to 2027-10-08). Meeting agenda includes: (1) review of gate-measurement calculation (revenue, costs, opex, surplus/deficit), (2) assessment of whether result is clearly above EUR 25k threshold (gate PASS), clearly below (gate FAIL), or ambiguous (-EUR 5k to +EUR 25k estimate), (3) discussion of any methodology questions or corrections needed, (4) if gate result is PASS (>= EUR 25k): founder and advisor sign the gate-result document and recommend release of EUR 350k follow-on tranche to founder for allocation decision, (5) if gate result is FAIL (< EUR 25k): root-cause analysis (insufficient delivered-unit volume, higher-than-expected refunds, cost inflation) and decision whether to pursue the 90-day tiebreak extension (founder may extend and re-measure in Months 13–14 = 2027-11-08 to 2027-12-08) or accept withholding of the tranche.

**Responsible Body/Role:** Project Steering Committee (Founder + External Advisor) with Financial Governance Committee support

**Suggested Timeframe:** Month 12 (2027-10-08) to Month 12.5 (2027-10-23)

**Key Outputs/Deliverables:**

- Final Gate-Measurement Review Meeting Held (Month 12.5 = 2027-10-23)
- Gate Result Confirmed (PASS >= EUR 25k, FAIL < EUR 25k, or AMBIGUOUS -EUR 5k to +EUR 25k)
- Gate Decision Document Signed (founder and external advisor, EUR 350k tranche release recommendation or withholding rationale documented)
- Tranche Release Authorization (if PASS, EUR 350k authorized for founder allocation) or Tiebreak Decision (if AMBIGUOUS, founder exercises discretion; if FAIL, withholding documented)

**Dependencies:**

- Gate-measurement data compiled and audited (Month 12 = 2027-10-08)
- Presale fulfillment complete and all Year-1 delivered-unit revenue recognized
- Steering Committee meeting convened and both members present

### 48. Founder makes the EUR 350k follow-on tranche allocation decision (once gate is passed and authorization is issued at Month 12.5 = 2027-10-23). Allocation options include: (1) inventory replenishment (EUR 80–120k estimate): buffer stock in EU warehouse (200–300 units trial, 30–60 day inventory cycle) to reduce lead times and accelerate customer fulfillment, (2) marketing and sales acceleration (EUR 80–120k estimate): campaigns to expand infrastructure and privacy segments, establish distribution partnerships, attend trade shows, (3) R&D and product variants (EUR 50–100k estimate): smaller SKU variant (phone-only enclosure) or server-grade cage exploration, (4) personnel and operations (EUR 30–50k estimate): full-time operations manager, part-time sales, expanded customer support, (5) working capital and contingency reserve (EUR 30–50k estimate). Founder, in consultation with external advisor, documents the allocation plan and submits it to the Steering Committee for approval by Month 13 (2027-11-08). Once approved, tranche spending begins under the same governance oversight as Year-1.

**Responsible Body/Role:** Founder / Project Principal (with External Advisor consultation and Steering Committee approval)

**Suggested Timeframe:** Month 12.5 (2027-10-23) to Month 13 (2027-11-08)

**Key Outputs/Deliverables:**

- EUR 350k Tranche Allocation Plan (inventory, marketing, R&D, personnel, working capital breakdown)
- Allocation Plan Approved by Steering Committee (Month 13 = 2027-11-08)
- Tranche Spending Authorization Issued (founder proceeds with planned investments)

**Dependencies:**

- EUR 350k tranche released by gate decision (Month 12.5 = 2027-10-23)
- Allocation options assessed and prioritized
- Steering Committee consultation completed

### 49. Post-gate governance review and continuous improvement: At Month 13 (2027-11-08) onward, Steering Committee transitions all five governance committees to Year-2 operational mode with updated charters, KPIs, and decision-making authority reflecting the newly released EUR 350k tranche. Activities include: (1) update Steering Committee charter to reflect expanded budget authority and any new strategic decisions (e.g., smaller SKU variant, server-grade cage feasibility study), (2) update each working committee charter with Year-2 responsibilities (Design & Certification: SKU variant design or deferred R&D; Production: increased volumes and potential multi-site sourcing; Presale/Revenue: ongoing marketing and distribution partnerships; Compliance: post-market monitoring and customer feedback; Financial Governance: continued monthly tracking, annual budget for Year-2, tranche spending reallocation rules), (3) schedule governance refresher meetings (all five committees, Month 13 = 2027-11-08) to confirm Year-2 engagement, (4) document lessons learned from Year-1 governance execution (what worked, what would improve), (5) establish Year-2 KPIs and success metrics for each committee. Continuous governance evolution ensures that the governance framework remains aligned with the venture's evolving scale and complexity.

**Responsible Body/Role:** Project Steering Committee (with input from all five working committees)

**Suggested Timeframe:** Month 13 (2027-11-08) onward

**Key Outputs/Deliverables:**

- Updated Steering Committee Charter for Year-2 (budget authority, strategic decisions, new risks)
- Updated Working Committee Charters for Year-2 (roles, responsibilities, decision rights under expanded budget)
- Governance Refresher Meetings Held (all five committees, Month 13 = 2027-11-08, Year-2 priorities confirmed)
- Year-1 Lessons-Learned Report (governance effectiveness, improvements for Year-2)
- Year-2 KPIs and Success Metrics (by committee, tied to EUR 350k tranche and growth targets)

**Dependencies:**

- Year-1 governance execution complete and EUR 350k tranche released
- Steering Committee and all five working committees fully operational
- Year-1 outcomes known (presale volume, delivered units, cash-flow gate result, customer feedback)