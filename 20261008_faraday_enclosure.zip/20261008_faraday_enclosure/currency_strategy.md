This plan involves money.

## Currencies

- **EUR:** Primary currency for all budgeting, reporting, and transactions. Manufacturing anchored in Tallinn (Eurozone), accredited testing in EU, buyer network across European Union. All major costs—tooling, prototyping, lab fees, production, logistics, staffing—occur naturally in EUR. User-specified budget (€750k) is already denominated in EUR, eliminating forex friction.

**Primary currency:** EUR

**Currency strategy:** All operations and revenue occur within the Eurozone and EU. Use EUR for budgeting, supplier payments, lab fees, and financial reporting. No foreign exchange hedging or multi-currency management required. Consolidate all costs and revenue in EUR quarterly and annually for tranche-gate measurement and follow-on funding decisions.