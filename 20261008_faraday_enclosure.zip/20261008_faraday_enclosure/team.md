*Roles Needed & Example People*

# Roles

## 1. RF & Electromagnetic Shielding Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: RF & Electromagnetic Shielding Engineer provides specialized, episodic expertise concentrated in Months 0–5 (2026-10-08 to 2027-03-08) (design, prototype validation, accredited lab coordination). The plan explicitly proposes a milestone-based EMC consultancy (EUR 20–25k, estimated) rather than salary. Work is front-loaded and outcome-focused; no ongoing operational accountability beyond Month 5 (2027-03-08). If university partnership materializes, the consultant's role is further reduced. Part-time RF hire (0.5 FTE fallback) would shift to part_time_employee if the university partnership fails by Month 1.5 (2026-11-23).

**Explanation**:
Leads design and validation of the Faraday enclosure's shielding performance. Responsible for seam/gasket architecture, attenuation targets across frequency bands, in-house rig setup, pre-test design review with accredited lab, and claim substantiation. Critical path item from Month 0–5 (2026-10-08 to 2027-03-08).

**Consequences**:
Design delays exceed Month 5 (2027-03-08) report deadline, compressing presale fulfillment window and missing the cash-flow gate. Attenuation claims fall short in lab test, forcing costly re-qualification (8–15k, estimate) within the 20k reserve. Accredited lab cannot issue credible report, blocking infrastructure buyer procurement and regulatory compliance. Without shielding expertise, the core product value proposition—measurable RF protection—collapses.

**People Count**:
min 1, max 2. A single competent RF engineer or milestone-based EMC consultant (20–25k, estimate) suffices for design and lab coordination. A second resource (part-time, 0.5 FTE) becomes necessary if university partnership delays or in-house rig iteration reveals unexpected seam/gasket failure modes requiring rapid iteration.

**Typical Activities**:
Design the rigid enclosure geometry, seam configuration and conductive-gasket specification to meet attenuation targets. Build and operate the in-house shielding test rig; measure prototypes across frequency bands (50 MHz to 1 GHz estimate) through multiple seam cycles to verify repeatability. Coordinate with the accredited EMC lab on test-methodology confirmation and design-readiness review (Month 4–5 = 2027-02-08 to 2027-03-08). Interpret lab results and recommend design adjustments or claim-scope narrowing. Document attenuation data and test methodology for presale credibility. Attend weekly progress calls with the product manager.

**Background Story**:
Dr. Kadri Tamm, RF engineer from Tallinn, Estonia. PhD in electromagnetic compatibility from TalTech, 8 years' experience designing RF enclosures and test rigs for European medical-device and defence contractors. Previously led EMC validation for a shielded cabinet manufacturer, managing accredited lab partnerships and seam-design iteration. Fluent in Estonian, English and German. Lives in Tallinn, enabling hands-on prototype testing and fabricator coordination. Motivated by the presale model and evidence-gated design approach; sees this as a chance to build an independent product rather than contract engineering.

**Equipment Needs**:
RF test rig (signal generator, spectrum analyzer, shielded measurement chamber or Faraday cage for prototype validation), laptop/workstation for design iteration and data analysis, CAD software (AutoCAD, SolidWorks, or equivalent for enclosure geometry), prototype samples (aluminium/steel sheets, gasket materials, fasteners for hand-assembly testing), oscilloscope and impedance analyzer for seam characterization. Estimated annual cost for test equipment: EUR 15–25k (amortized over multiple projects).

**Facility Needs**:
Laboratory or workshop space in Tallinn with RF isolation capability (shielded area or access to university lab chamber) for in-house rig operation and prototype testing. Bench space for prototype assembly, measurement, and gasket compression-cycle validation (2–3 seam-cycle test rigs in parallel). Temperature and humidity control for consistent test conditions. Access to the university RF measurement facility or independent lab for design-readiness reviews. Part-time space: ~40–60 sq m estimate.

## 2. Hardware Product Manager & Project Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Hardware Product Manager & Project Lead owns end-to-end timeline, gate decisions, and stakeholder coordination from Month 0 (2026-10-08) through Month 12.5 (2027-10-23), spanning design freeze, tooling release, presale fulfillment, and cash-flow gate measurement. This is continuous core accountability with evolving but sustained responsibility. Founder-led initially, but if founder capacity becomes strained by Month 6 (2027-04-08), escalates to a dedicated 1 FTE role. The role cannot be outsourced or modularized; it requires sustained authority and presence.

**Explanation**:
Oversees end-to-end product development timeline, coordinates design–test–tooling gates, manages presale demand tracking and pivots, and ensures burn sequencing meets the EUR 400k cap. Owns the decision gates at Months 5, 6, and 8 (2027-03-08, 2027-04-08, 2027-06-08) and communicates cash-flow status weekly to founder and advisor. Bridges RF engineer, fabricator, lab, and presale teams.

**Consequences**:
Gate milestones slip (design freeze, lab submission, tooling release) by 2–4 weeks, compressing presale window and redesign buffer. Presale demand tracking is ad-hoc; segment-level pivots (prepper vs. infrastructure) are missed, leaving capital at risk if presale skews toward low-margin preppers. Cash burn is not reconciled weekly; budget overruns (lab re-test, soft tooling) are discovered late, forcing reactive cuts. Hard tooling is released without validated presale threshold, risking EUR 20–40k sunk cost if demand fails.

**People Count**:
1. A single founder-led PM role, potentially fulfilled by the founder themselves with structured processes and weekly milestone checklist. If founder is unavailable or overloaded by Month 6 (2027-04-08), escalate to a full-time PM; otherwise, a structured presale and gate-tracking spreadsheet suffices for Months 0–12 (2026-10-08 to 2027-10-08).

**Typical Activities**:
Maintain a detailed monthly milestone tracker (design freeze, lab submission, tooling release, presale targets). Review cash burn weekly against the EUR 400k cap and presale deposit thresholds. Facilitate design-readiness gates at Months 5, 6, and 8 (2027-03-08, 2027-04-08, 2027-06-08) by aggregating RF data, lab feedback, and demand signals. Coordinate timing between accredited-lab submission and presale campaign rollout. Manage gate decision logic: if deposits fall below EUR 80k by Month 6 (2027-04-08), trigger a pivot decision (extend presale or halt hard tooling). Weekly status call with founder and RF engineer.

**Background Story**:
Marie Poulsen, hardware product manager and founder's deputy, Copenhagen-based but remote-capable. 12 years in hardware startups: crowdfunded consumer electronics, IoT product launches and staged-funding ventures. Expertise in design-to-market timelines, gate discipline and presale campaign mechanics. Experienced in capital-constrained environments and founder support during bottlenecks. Recruited as a part-time advisor by the founder (Month 0 = 2026-10-08); transition to 1 FTE from Month 6 (2027-04-08) if founder becomes overloaded. Committed to rigorous milestone tracking and weekly cash reconciliation.

**Equipment Needs**:
Project-management software (Asana, Monday.com, or equivalent for milestone tracking, EUR 200–500/year estimate), shared spreadsheets and dashboards (Google Sheets, Excel) for cash-burn tracking and presale metrics, Slack or similar for team communication, presale reporting tools (Typeform or similar for presale intake), document repository (Google Drive, Sharepoint). Laptop/workstation. Estimated annual cost: EUR 1–3k for subscriptions and tools.

**Facility Needs**:
Remote-capable office space or distributed access; no specialized facility required. Video-conferencing infrastructure for weekly calls with founder, RF engineer, fabricator, and advisors. Shared access to monthly financial dashboards and gate-decision checkpoints. Presale campaign coordination may require internet-based marketing-automation tools (HubSpot, Mailchimp estimate: EUR 500–2k/year). Minimal space requirement: essentially digital-first role.

## 3. Supply Chain & Manufacturing Coordinator

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Supply Chain & Manufacturing Coordinator manages Tallinn supplier relationships, capacity reservations, and quality control on a recurring, though variable, cadence. Role is ongoing but peaks during soft tooling (Months 0–6 = 2026-10-08 to 2027-04-08) and production ramp (Months 6–12 = 2027-04-08 to 2027-10-08). Estimated 10–15 hrs/week for Months 0–6 (2026-10-08 to 2027-04-08), scaling to 15–20 hrs/week Months 6–12 (2027-04-08 to 2027-10-08) if volume ramps. Workload is continuous but does not justify full-time; part-time employment (or 1 FTE from Month 6 = 2027-04-08 onward if production exceeds capacity) protects cost against presale volume uncertainty.

**Explanation**:
Manages Tallinn fabricator relationships, soft and hard tooling sourcing, gasket supplier qualification and inventory, and production batch sequencing. Responsible for capacity reservations, pricing lock-in, lead-time tracking, and contingency supplier transitions. Coordinates with logistics carrier for freight and buffer-stock logistics. Quality control on first batches.

**Consequences**:
Primary fabricator raises prices 10–20% (estimate) mid-year, eroding margins and reducing cash-flow gate surplus by EUR 5–15k. Gasket supply disruption delays first batch by 2–4 weeks, missing presale delivery SLA and triggering refund spike that strains deposited cash. Secondary supplier is not pre-qualified; loss of primary fabricator forces urgent 4–6 week sourcing delay, forcing hard-tooling reschedule and presale cancellations. Freight cost negotiations are not locked in, adding EUR 2–5 per unit (estimate) margin erosion.

**People Count**:
1. A single part-time (10–15 hrs/week) coordinator for Months 0–6 (2026-10-08 to 2027-04-08) during soft-tooling and first-batch ramp. May escalate to full-time (1 FTE) from Month 6 (2027-04-08) onward if production volume and multi-supplier management exceed part-time capacity. Founder can cover this role if travel to Tallinn is feasible for quarterly visits.

**Typical Activities**:
Identify and pre-qualify the primary Tallinn fabricator and two backup gasket suppliers by Month 1 (2026-11-08). Negotiate and lock soft-tooling pricing and capacity-reservation agreements (Month 1 = 2026-11-08). Monitor laser-cut accuracy, bend tolerances and burr removal on prototype batches. Maintain a live supply-chain risk register (lead times, pricing, capacity headroom) with monthly reviews. Coordinate sample preparation for accredited lab (Month 4 = 2027-02-08). Oversee first production batch (hard tooling, gasket integration, packaging). Quarterly in-person Tallinn site visits (Months 1, 3, 5, 7–8) for quality assurance and supplier communication.

**Background Story**:
Taavi Karvonen, supply-chain coordinator and quality engineer from Tallinn. 10 years' experience in Estonian precision sheet-metal fabrication, including soft-tooling ramp, capacity planning and supplier relationships. Previous role: quality manager at a Tallinn ISO-certified fabricator serving Nordic and German customers. Deep knowledge of local gasket and materials suppliers. Speaks Estonian, English and Swedish. Works part-time (10–15 hrs/week) through Month 6 (2027-04-08), scaling to full-time if production volume warrants.

**Equipment Needs**:
Laser-cutting and CNC-bending equipment (for soft tooling and prototype fabrication) on-site at Tallinn fabricator partner. CAD file transfer and design-review tools (shared with RF engineer). Sample packaging and shipping labels. Precision measurement tools (callipers, gauges) for dimensional quality checks on prototypes and first batches (EUR 2–5k estimate, supplied by fabricator or purchased). No direct capital need for supply-chain coordinator beyond standard office equipment (laptop, phone, email).

**Facility Needs**:
Quarterly site-access requirement at Tallinn precision-metal fabricator (shared fabrication workshop, estimated 20–40 sq m access for prototype evaluation and batch staging). Access to gasket-supplier facility or warehouse for buffer-stock receiving and inspection (~10–20 sq m). Shipping/logistics coordination infrastructure (carrier partnerships, online shipping platforms). No dedicated facility; all operations occur at partner suppliers' sites or via remote coordination.

## 4. Presale & Demand Validation Manager

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Presale & Demand Validation Manager owns weekly segment tracking, deposit conversion metrics, and marketing pivots from Month 0 (2026-10-08) through Month 8 (2027-06-08 to 2027-06-08), with gate-critical work ending at Month 6 (2027-04-08). Role is episodic and data-driven: intensive campaign launch (Months 0–2 = 2026-10-08 to 2026-12-08), weekly tracking (Months 1–6 = 2026-11-08 to 2027-04-08), and pivot execution (Month 3 = 2027-01-08 if prepper dominance detected). Estimated 15–20 hrs/week; can be outsourced to a contractor or absorbed by founder if bandwidth permits, but part-time employment ensures accountability for weekly metrics and segment pivots.

**Explanation**:
Owns presale campaign strategy, buyer-segment outreach (preppers, infrastructure, privacy/forensics), deposit tracking and conversion metrics, and demand-mix pivot logic. Establishes presale terms, delivery SLA, and refund process. Tracks segment deposit rates weekly and triggers marketing reallocations if prepper conversion exceeds 70% by Month 3 (2027-01-08). Negotiates fast-track infrastructure pilot agreements.

**Consequences**:
Presale deposits remain scattered, untracked by segment; demand-mix insight is delayed until Month 5–6 (2027-03-08 to 2027-04-08), leaving insufficient time to pivot marketing if prepper ratio exceeds 70%. Conversion rate to deposits is not measured; weak presales are discovered late (Month 5 = 2027-03-08 onward), delaying hard-tooling stop decision by 2–3 weeks and consuming redesign buffer if tooling is released prematurely. Infrastructure pilots are not negotiated; revenue from this high-margin segment arrives late or not at all, leaving cash-flow gate dependent on low-margin prepper units. Presale refund requests are not tracked; refund spike (20–30% estimate) that strains deposited cash is not detected until cash is already committed.

**People Count**:
1. A single part-time (15–20 hrs/week) campaigns/community manager from Month 0 (2026-10-08) or 1 FTE contractor for Months 1–8 (2026-11-08 to 2027-06-08) if parallel segment campaigns and weekly tracking are outsourced. Founder can cover if marketing bandwidth permits. A second resource is necessary if infrastructure pilot negotiations or international forum engagement exceed one person's capacity.

**Typical Activities**:
Establish and maintain three separate presale tracking channels (prepper forums, infrastructure buyer contacts, privacy/forensics groups) with distinct messaging. Launch targeted campaigns by Month 1 (2026-11-08) emphasising disaster prep, business continuity and data privacy respectively. Track weekly deposit velocity, average order value and refund rate by segment. At Month 3 (2027-01-08), analyze which segment dominates; if prepper conversion exceeds 70%, reallocate marketing spend (EUR 10–15k estimate) to infrastructure and privacy segments. Negotiate fast-track infrastructure pilot agreements (cost + 20%, delivery Month 5 = 2027-03-08). Report segment metrics weekly to the product manager.

**Background Story**:
James Chen, digital marketing specialist and community manager, London-based. 7 years in niche hardware and preparedness communities: crowdfunding campaigns, forum moderation, and segment-specific messaging. Expertise in prepper networks, privacy/digital-forensics communities and critical-infrastructure buyer outreach. Previous work with a US emergency-preparedness retailer and a digital-forensics tool company. Contracted part-time (15–20 hrs/week) for Months 1–8 (2026-11-08 to 2027-06-08) to manage presale campaigns across segments.

**Equipment Needs**:
Presale marketing platform (Shopify, WooCommerce, or custom landing page: EUR 2–5k estimate initial setup, EUR 500–1.5k/year recurring). Email and CRM tools for buyer segment tracking (MailChimp, HubSpot: EUR 500–2k/year). Social-media and forum-access tools (Slack, Discord for community liaison). Analytics dashboard (Google Analytics, custom presale conversion tracker). Laptop/workstation. Estimated annual software cost: EUR 3–6k for platforms and subscriptions.

**Facility Needs**:
Remote/distributed access sufficient; no physical facility required. Online presence infrastructure: presale landing pages (web hosting EUR 500–2k/year estimate), email-list management, presale-intake forms. Forum and community-access infrastructure (prepper networks, infrastructure buyer groups may require in-person contact for pilot agreements; Months 1–3 = 2026-11-08 to 2027-01-08 assume occasional travel to EU centres for buyer engagement, ~5–8 days estimate per region). Presale customer-support infrastructure (email, ticketing system, live chat optional: EUR 100–500/month estimate for support tools).

## 5. Financial Management & Cash-Flow Governance Officer

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Financial Management & Cash-Flow Governance Officer provides monthly reconciliation and gate-measurement preparation from Month 1 (2026-11-08) through Month 12.5 (2027-10-23). Role is recurring on a fixed monthly cycle (cash review, burn tracking, variance reporting) with workload intensifying in Months 11–12 (2027-09-08 to 2027-10-08) for gate calculation and sign-off preparation. Estimated 8–12 hrs/week normally, scaling to 16–20 hrs/week Months 11–12 (2027-09-08 to 2027-10-08). Part-time employment (e.g., part-time bookkeeper or finance advisor) protects cost and allows founder to manage if financial discipline is strong; escalates to 1 FTE if founder has weak financial background.

**Explanation**:
Owns monthly cash reconciliation, burn-rate tracking against the EUR 400k cap, presale-deposit accounting (liabilities, not cash flow), and gate-measurement preparation. Reports cash position and variance weekly to founder and advisor. Prepares the EUR 25–30k (estimate) positive-cash-flow gate measurement by Month 12 (2027-10-08) and coordinates sign-off by founder + advisor by Month 12.5 (2027-10-23).

**Consequences**:
Cash burn is not reconciled against the EUR 400k cap; overruns in lab fees, soft tooling, or prototype iteration are discovered late, forcing reactive cuts. Presale deposits are misclassified as cash flow, leading to premature release of the EUR 350k follow-on before fulfillment is proven, leaving Year-2 underfunded if refunds spike. Gate-measurement calculation is ambiguous or disputed at Month 12 (2027-10-08); if result is borderline (EUR 20–30k range), tiebreaker rule is unclear, delaying the EUR 350k decision into Month 13–14 (2027-11-08 to 2027-12-08) and risking loss of market timing. Audit trail for presale liability accounting is weak, creating tax and consumer-protection compliance risk if regulators investigate.

**People Count**:
1. Founder can manage this role with a structured monthly template if cash discipline is strong. For transparency and governance separation, a part-time (8–12 hrs/week) bookkeeper or finance advisor from Month 1 (2026-11-08) onward is recommended; escalates gate-measurement work to 16–20 hrs/week in Months 11–12 (2027-09-08 to 2027-10-08). If founder has weak financial background, hire 1 FTE part-time accountant by Month 2 (2026-12-08).

**Typical Activities**:
Establish separate accounting for presale deposits (classified as liabilities in a dedicated earmarked account). Reconcile cash burn monthly against the EUR 400k budget cap; flag overruns >10% for founder review. Track presale refund requests and monitor deposit balance. Prepare weekly cash position dashboard for founder and external advisor. In Months 11–12 (2027-09-08 to 2027-10-08), calculate trailing-quarter operating cash surplus (delivered-unit revenue minus direct unit costs and recurring opex). Coordinate with founder and advisor on gate sign-off by Month 12.5 (2027-10-23). Maintain audit trail and tax documentation.

**Background Story**:
Sofia Nunes, freelance bookkeeper and accountant, Lisbon-based, 6 years' experience in early-stage hardware and SaaS startups. Expertise in presale liability accounting, cash reconciliation and staged-funding governance. Previously managed cash flow and funding gates for a EU hardware venture with founder-led financing. Contracted part-time (8–12 hrs/week) starting Month 1 (2026-11-08), scaling to 16–20 hrs/week in Months 11–12 (2027-09-08 to 2027-10-08) for gate-measurement preparation.

**Equipment Needs**:
Accounting software (QuickBooks, Xero, or similar: EUR 500–1.5k/year estimate), spreadsheet tools (Excel, Google Sheets) for cash-flow reconciliation and monthly burn tracking, bank integration tools for automated transaction feeds. Laptop/workstation. Document repository for audit trail and compliance documentation (secure cloud storage: EUR 100–300/year estimate). Estimated annual cost: EUR 1–2.5k for accounting platform and tools.

**Facility Needs**:
Remote-capable office space; no specialized facility required. Secure, encrypted workspace for confidential financial data and tax documentation (home office or co-working space acceptable with data-security measures). Monthly coordination with founder and external advisor (video call infrastructure). Year-1 workload intensifies in Months 11–12 (2027-09-08 to 2027-10-08) for gate measurement; may require dedicated quiet workspace during those months for concentration. Minimal space: digital-first role.

## 6. Regulatory Compliance & Legal Advisor

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Regulatory Compliance & Legal Advisor provides episodic, specialist deliverables: legal opinion on EU product rules (Month 0.5–1 = 2026-10-23 to 2026-11-08, EUR 2–5k estimated), insurance coordination (Months 1–2 = 2026-11-08 to 2026-12-08.5 = 2026-11-08 to 2026-12-23), and presale-terms drafting (Month 0.5–1 = 2026-10-23 to 2026-11-08). Work is front-loaded, milestone-driven, and does not require ongoing presence after Month 2.5 (2026-12-23). Quarterly compliance checklist updates (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08) are low-touch and can be scheduled. Independent-contractor terms fit the one-time deliverables and episodic availability needed.

**Explanation**:
Secures legal opinion on EU product-safety applicability (EMC Directive, General Product Safety Directive, consumer-protection rules), drafts presale terms and scope-limitation language, and coordinates product-liability insurance (EUR 250–500k estimate). Publishes compliance checklist and scope statement in presale materials and product documentation. Advises on claim substantiation and reputational-risk mitigation if a real EMI event occurs.

**Consequences**:
Applicable EU regulations (EMC Directive, CE marking requirements) are not verified; a regulatory challenge post-launch incurs 30–80k (estimate) in fines, mandatory recall, and redesign costs. Presale terms and scope statements lack legal grounding; consumer complaints and refund disputes are not defensible. Product-liability insurance is not secured by Month 2.5 (2026-12-23); if a real EMI event damages customer devices post-launch, uninsured liability exposure and reputational damage exceed reserves and threaten venture viability. Marketing claims are not tied to measured data; substantiation challenge from regulators or consumer-protection bodies forces claim revision and credibility loss with infrastructure buyers.

**People Count**:
1. A contracted product-compliance attorney (external) for the legal opinion and insurance coordination (Month 0.5–2 = 2026-10-23 to 2026-12-08, estimate 2–5k). A part-time internal compliance coordinator (5–8 hrs/week from Month 1 = 2026-11-08 onward) maintains the compliance checklist and quarterly updates; this can be bundled with the financial officer if both are part-time contractors.

**Typical Activities**:
Review the enclosure design and marketing claims against applicable EU regulations (EMC Directive 2014/30/EU, General Product Safety Directive 2001/95/EC, consumer-protection rules). Draft a legal opinion addressing whether CE marking or notified-body assessment is required. Co-author presale terms, delivery SLA, and a scope-limitation statement: 'Protects stored spare devices only; does not protect active grid-connected equipment or prevent grid-scale events.' Coordinate with product-liability insurers to confirm insurability of Faraday-enclosure claims (EUR 250–500k estimate coverage). Lock insurance terms by Month 2.5 (2026-12-23). Quarterly compliance checklist updates.

**Background Story**:
Prof. Markku Ahonen, legal counsel specialising in EU product safety and consumer protection, Helsinki-based. 15 years' experience advising hardware and electronics manufacturers on EMC Directive, General Product Safety Directive and product-liability insurance. Previous advisory roles with medtech and IoT companies. Contacted by the founder in Month 0 (2026-10-08) to deliver a legal opinion on regulatory applicability by Month 1 (2026-11-08). Engagement: 2–5k (estimate) for the opinion, presale terms drafting, and insurance coordination.

**Equipment Needs**:
Legal research and document-drafting tools (standard office software, or legal-specific platforms for compliance templates and risk assessment EUR 500–2k estimate). Laptop/workstation. Access to EU regulatory databases and standards documentation (typically library or institutional access; independent attorneys may subscribe to ETSI or IEC standards catalogues at EUR 1–3k/year estimate, shared across multiple projects). Product-liability insurance quote platforms or access to underwriting networks (insurance brokers provide this access, no direct cost to the coordinator).

**Facility Needs**:
Remote-capable office; no specialized facility required. Attorney engagement is episodic (Months 0.5–2.5 = 2026-10-23 to 2026-12-23) for legal opinion and presale-terms drafting. Quarterly compliance-checklist updates (Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08) can be remote. Insurance coordination may require in-person or video meetings with underwriters (typically 1–2 meetings estimate). Minimal ongoing facility need beyond standard office access.

## 7. Accredited EMC Testing & Lab Liaison

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Accredited EMC Testing & Lab Liaison manages the single lab validation via a pre-contracted statement of work (signed by Month 1.5 = 2026-11-23). Work spans Months 2–6 (2026-12-08 to 2027-04-08): pre-engagement consultation, design-readiness review (Month 4 = 2027-02-08), sample coordination (Month 4 = 2027-02-08), and report delivery (Month 5 = 2027-03-08). Role is episodic, lab-engagement-focused, and may be bundled with the RF engineer consultant's responsibilities. No ongoing accountability after Month 6 (2027-04-08); phase-specific expertise.

**Explanation**:
Manages the single accredited lab validation, including pre-engagement consultation (standard selection, frequency range, cost lock), design-readiness review (Month 4–5 = 2027-02-08 to 2027-03-08), sample preparation and submission (Month 4 = 2027-02-08), and report delivery (Month 5 = 2027-03-08, latest Month 6 = 2027-04-08). Coordinates re-test contingency if initial results fall short. Ensures published report and test data are formatted for presale and procurement use.

**Consequences**:
Lab standard, cost, and timeline are not confirmed in advance; a higher-cost standard (MIL-STD-285, estimate +10–20k) or longer timeline (4–8 weeks slip = estimate) is discovered in Month 3–4 (2027-01-08 to 2027-02-08), compressing the redesign buffer and presale fulfillment window. Design-readiness review is skipped; sample submission goes forward without pre-test feedback, resulting in failed initial lab run (EUR 8–15k loss, estimate) that consumes the redesign reserve and delays report to Month 7 (2027-05-08), missing the cash-flow gate window. Lab report is late or incomplete; presale fulfillment proceeds without published shielding data, weakening credibility with infrastructure buyers and increasing regulatory compliance risk if claims are challenged.

**People Count**:
1. External accredited laboratory relationship (signed statement of work by Month 1.5 = 2026-11-23); internal liaison (10–15 hrs/week) from Month 2 (2026-12-08) to Month 6 (2027-04-08) to manage the engagement. Can be combined with the RF engineer if that person has lab-coordination experience, or outsourced to the EMC consultancy (included in the 20–25k estimate).

**Typical Activities**:
Conduct no-cost pre-engagement consultations with 2–3 accredited EMC laboratories (Germany, Sweden, Netherlands) by Month 0.5 (2026-10-23) to confirm applicable standard (IEEE 299.1 or equivalent estimate), frequency range, cost (lock at EUR 15k cap), and timeline (report by Month 5 = 2027-03-08). Prepare design-readiness dossier by Month 4 (2027-02-08) documenting enclosure material, seam design, in-house rig results and test plan. Schedule design-readiness review (EUR 2–3k estimate) with the lab by Month 4.5 (2027-02-23). Coordinate formal sample submission (Month 4 = 2027-02-08) and report delivery (Month 5 = 2027-03-08). If results reveal attenuation shortfalls, recommend design iteration or claim narrowing. Prepare report for publication with presale units.

**Background Story**:
Dr. Elena Svetlova, RF measurement and test coordination specialist, Stockholm-based. 12 years' experience managing accredited EMC laboratory relationships for European hardware companies. Expertise in test-standard selection, sample preparation, cost negotiation and report interpretation. Previous role: quality assurance manager for an automotive electronics supplier managing multiple lab partnerships. Contracted part-time (10–15 hrs/week, Months 2–6 = 2026-12-08 to 2027-04-08) via the EMC consultancy or independently to manage the single accredited lab validation.

**Equipment Needs**:
Design-readiness dossier preparation tools (document authoring, image capture for prototypes, CAD file export and formatting). Data submission platform access (accredited lab's online portal or secure file transfer). Frequency-sweep analysis software (usually provided by the lab or standard RF measurement tools like Anritsu or network-analyzer interfaces). Laptop/workstation for report interpretation and client communication. No direct capital cost beyond standard office equipment; lab provides testing equipment.

**Facility Needs**:
Prototype sample preparation space co-located with RF engineer (Tallinn or university lab facility, ~20–30 sq m estimate, shared with in-house rig). Access to the accredited EMC laboratory (location: Germany, Sweden, Netherlands, or Estonia) for formal sample submission and measurement (Months 4–5 = 2027-02-08 to 2027-03-08; ~3–5 day site visit estimate, or remote handoff via courier). Remote communication infrastructure with lab contact (email, video calls, file sharing). No dedicated facility required; liaison role is episodic and lab-engagement-focused.

## 8. Backup Operations & Decision Authority

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Backup Operations & Decision Authority is an advisory/escalation role, not a full-time operational position. Estimated 0.2 FTE (8–10 hrs/week), providing decision-authority cover if the founder is unavailable during Months 4–10 (2027-02-08 to 2027-08-08). Role is contingency-focused and reactive; no continuous workload unless founder incapacity is triggered. Can be a part-time advisor or seasoned operations person contracted on a retainer (5–8k Year-1 estimate) to maintain availability without full-time commitment. Independent-contractor terms suit the on-call, episodic nature and the reputational authority required (an advisor, mentor, or experienced operator rather than a staff member).

**Explanation**:
Serves as founder backup for escalation decisions, fulfillment bottleneck resolution, and communication continuity if founder is unavailable (illness, family, visa issues) for extended periods (Months 4–10 = 2027-02-08 to 2027-08-08). Maintains decision-checkpoint authority for gate releases, segment pivots, and supplier transitions. Coordinates with Tallinn fabricator and lab contacts as a secondary point of contact.

**Consequences**:
Founder illness or visa constraint during critical Month 4–5 (2027-02-08 to 2027-03-08) lab-submission window causes 2–4 week paralysis; accredited lab pre-test and sample submission are delayed. Without escalation authority, supplier and buyer communications stall, missed deadlines compound. Presale customer escalations and refund requests are not answered, triggering public complaints and reputational damage. Hard-tooling release or pivot decisions are postponed, leaving critical path exposed. Single-point-of-failure risk is unmitigated; the venture is not resilient to founder incapacity.

**People Count**:
min 0.2 FTE (part-time, 8–10 hrs/week), ideally an experienced startup advisor or operations person with hardware background. Can be the same person as the supply-chain coordinator or financial officer if three-person team exists; otherwise, recruit a part-time advisor/operations person by Month 1.5 (2026-11-23). Founder must identify and brief this person by Month 2 (2026-12-08).

**Typical Activities**:
Serve as founder's escalation contact for critical decisions (segment pivots, tooling releases, supplier transitions) if founder is unavailable due to illness, visa issues or personal constraint, particularly during Months 4–10 (2027-02-08 to 2027-08-08). Maintain familiarity with accredited lab contacts, Tallinn fabricator relationships and presale campaign status. Step in for founder in discussions with suppliers or buyers if requested. Coordinate with the external financial advisor on gate measurement if founder incapacity extends into Months 11–12 (2027-09-08 to 2027-10-08). Provide mentorship on cash-flow discipline and founder resilience.

**Background Story**:
Erik Mänd, experienced startup operations advisor and mentor, Tallinn-based. 20 years' background in Estonian tech startups and hardware ventures. Deep network in Tallinn supplier ecosystem and EU funding circles. Recruited by the founder as a part-time advisor and backup decision-authority contact by Month 1.5 (2026-11-23). Estimated capacity: 0.2 FTE (8–10 hrs/week on-call retainer, EUR 5–8k Year-1 estimate).

**Equipment Needs**:
Communication tools (email, phone, Slack, video conference access) for escalation contact and decision-authority backup. Laptop/workstation. Access to shared project dashboards and decision logs (Google Sheets, project-management tools). No specialized equipment; standard office setup.

**Facility Needs**:
Remote/on-call access; minimal dedicated facility required. Should maintain familiarity with Tallinn fabricator and lab contacts (may require occasional site visits or video meetings, ~2–3 times per year estimate if no emergency escalation occurs). If founder incapacity triggers active backup role (Months 4–10 = 2027-02-08 to 2027-08-08), may need temporary office access in Tallinn or liaison location for supplier/buyer coordination. Part-time advisor role: ~0.2 FTE (8–10 hrs/week on-call), accommodated within advisor's existing office and travel budget.

---

# Omissions

## 1. Missing Core Product Owner / Chief Product and Engineering Officer Role

The plan assigns project leadership to 'Hardware Product Manager & Project Lead' (Marie Poulsen, part-time initially) and RF expertise to an external consultant, but no single person owns the product definition, feature scope, or quality acceptance criteria end-to-end. The RF consultant is episodic (Months 0–5 = 2026-10-08 to 2027-03-08), while the PM is part-time and coordination-focused. Critical decisions about seam design trade-offs, gasket material selection, and tolerance stacking for shielding performance require a continuous, hands-on engineering voice—not just a consultant. This gap creates risk that design compromises are made without clear ownership, lab results are misinterpreted, and presale claims diverge from measured performance.

**Recommendation**:
Designate one person as Chief Product and Engineering Officer (CPEO), responsible for end-to-end design quality, lab-results interpretation, and claim substantiation. This role should own the design-readiness checkpoint (Month 4 = 2027-02-08) and lab pre-test review, and sign off on any claim narrowing or redesign after lab results arrive. If the RF consultant (Dr. Tamm) can be retained part-time (0.3–0.5 FTE) beyond Month 5 (2027-03-08) for this, assign her. Otherwise, hire or contract a product engineer by Month 2 (2026-12-08) to grow into this role. Clarify in writing that this role holds final authority on design, not the PM or the lab.

## 2. Missing Dedicated Presale Customer Support and Fulfillment Operations Role

Presale & Demand Validation Manager (James Chen) owns campaign strategy and deposit tracking, but no role owns the fulfillment logistics, customer-support escalation, refund processing, and delivery-SLA compliance. The plan assumes 'part-time operations' added Month 6 (2027-04-08) if presale volume warrants, but presale customer support and refund management are mission-critical from Month 1 (2026-11-08) onward—the first customers will place orders weeks into presale, and unresponsive support or delayed refunds damage brand trust during the critical early-sales phase. Financial Officer (Sofia) handles cash accounting but not customer-facing fulfillment. This gap creates risk of cascading refund requests, customer complaints on forums, and reputational damage if presale orders slip or fit issues trigger disputes.

**Recommendation**:
Create a dedicated Presale Customer Support & Fulfillment Coordinator role (part-time, 10–15 hrs/week, starting Month 0.5 = 2026-10-23, growing to 0.5–1 FTE from Month 6 = 2027-04-08 onward). Responsibilities: presale intake and confirmation (order tracking, delivery estimates), customer escalation (48-hour response SLA), refund requests (processed within 10 business days per published policy), fit-complaint triage (log and escalate to product team), and delivery coordination with logistics. This person bridges the Presale Manager (campaign) and Supply Chain Coordinator (production). If founder has capacity, absorb this until Month 6 (2027-04-08); otherwise, hire part-time by Month 1 (2026-11-08).

## 3. Missing External Advisory Board or Governance Checkpoint Structure

The plan assigns gate sign-off (Month 12.5 = 2027-10-23) to 'founder + one external advisor,' but no advisory structure, standing meetings, or checkpoint cadence is documented. The single external advisor is the financial officer (Sofia), who handles cash accounting but may lack product, market, or RF expertise to evaluate design-readiness gates or presale segment risks. Without a formal advisory structure, critical gate decisions (Month 5–6 = 2027-03-08 to 2027-04-08: hard-tooling release, design confirmation) lack independent review. Founder decisions may be clouded by cash pressure or optimism bias, and the lack of external checkpoint creates governance risk and potential disputes over gate results.

**Recommendation**:
Establish a lightweight Advisory Board or Checkpoint Panel by Month 0.5 (2026-10-23), comprising: (1) the financial officer (Sofia) as primary gate-measurement authority, (2) an external hardware-startup advisor with product-development experience (e.g., Erik, the backup operations contact, can serve dual role), and (3) ideally a third advisor with RF/compliance expertise or market-access experience. Quarterly checkpoint calls (Months 3, 6, 9, 12 = 2027-01-08, 2027-04-08, 2027-07-08, 2027-10-08) to review design progress, presale data, and burn rate. Monthly (~15 min) check-in calls for cash reconciliation. Formalize decision authority: the Advisory Panel collectively sign off on gate results by Month 12.5 (2027-10-23), with documented reasoning if result is ambiguous (−5k to +25k range). This costs minimal overhead (advisor time mostly already budgeted) and reduces single-point-of-failure and governance risk.

## 4. Missing Responsibility for Claim Substantiation and Marketing Message Credibility

Presale & Demand Validation Manager owns campaign strategy, and Regulatory Compliance & Legal Advisor handles legal framework, but no role is explicitly accountable for ensuring that every marketing claim is tied to measured data, that messaging is consistent across channels, and that claim changes post-lab-test are communicated to presale customers. The risk: lab results show attenuation that falls short of presale marketing in certain frequency bands, but the messaging is not updated in time for Month 6+ presale orders. Customers later complain they were misled, triggering refunds and regulatory exposure. Additionally, the multi-use RF-isolation narrative (privacy, travel, forensics, disaster prep) creates four distinct claim stories; if they are not centrally managed and coordinated, message drift and inconsistency across forums and channels will erode credibility, especially with infrastructure buyers.

**Recommendation**:
Assign responsibility for Claim Substantiation and Message Consistency to the Chief Product and Engineering Officer (if that role is created; see Omission 1) or to the Presale Manager in coordination with Legal. Specifically: (1) by Month 5.5 (2027-03-23), after accredited lab report is final, conduct a claim-review meeting: compare presale marketing claims to lab-measured attenuation by frequency band, identify any shortfalls, and document approved claim changes. (2) Update all presale materials (landing pages, email templates, social posts, forum responses) with revised claims and publish a notice to existing presale customers explaining any narrowed claims and re-confirming their product specification. (3) Maintain a master 'Claim Substantiation Matrix' (spreadsheet) mapping each marketing claim to the underlying lab data or test method, reviewed monthly. (4) Designate a single person (Presale Manager + Chief Product Officer, or Legal) as approver for any new marketing materials before publication. This ensures consistency and evidence-based claims across all customer touchpoints.

## 5. Missing Stakeholder Communication Plan and Founder Availability/Burnout Mitigation

The plan identifies a 'Backup Operations & Decision Authority' role to cover founder illness or visa issues, but no proactive communication plan, meeting cadence, or workload-sharing model is defined to prevent founder burnout and ensure continuity. The founder is owner of product, presale strategy, supplier coordination, and gate decisions—spanning design, marketing, operations and fundraising. Months 6–12 (2027-04-08 to 2027-10-08) are high-stress (presale fulfillment, production ramp, cash-flow gate measurement approaching). No mention of regular 1:1 check-ins with founder, clarity on decision-support roles, or a structured handoff plan if founder needs to step back. Risk: founder exhaustion in Months 8–10 (2027-06-08 to 2027-08-08) leads to poor decisions, missed deadlines, or inability to respond to presale crises, compromising cash flow and gate timing.

**Recommendation**:
Establish a Founder Support and Stakeholder Communication plan by Month 0.5 (2026-10-23): (1) Weekly 30-minute founder check-in with the PM and financial officer to review cash, presale metrics, and any blockers. (2) Monthly (~60-minute) advisory board call to discuss progress, gate readiness, and strategic pivots. (3) Quarterly (~30-minute) supplier calls to maintain Tallinn relationships (rotate between founder and supply-chain coordinator). (4) Clear escalation: all decisions that block revenue (hard-tooling release, segment pivots, refund policy changes) require advisory-board input or approval, not founder solo decision. (5) Backup availability: ensure backup ops contact (Erik) attends monthly advisory calls and is briefed weekly on critical path, so he can step in immediately if founder becomes unavailable. (6) By Month 6 (2027-04-08), if presale fulfillment and cash management become overwhelming, hire the part-time operations person immediately (do not wait). These measures reduce founder burnout risk and ensure no single-point-of-failure in decision-making or stakeholder communication.

---

# Potential Improvements

## 1. Clarify and Formalize RF Engineer Contract and Expertise Retention

The plan proposes 'milestone-based EMC consultancy (EUR 20–25k estimate)' but does not specify whether the consultant (Dr. Tamm) is retained beyond Month 5 (2027-03-08), or whether knowledge transfer and design ownership remain with the founder or are handed off to a subsequent hire. If Dr. Tamm departs after Month 5 (2027-03-08), the company loses in-house RF expertise just as production ramp and potential post-launch troubleshooting begin. Additionally, the milestone-based contract structure (payments tied to deliverables, not time) may create misalignment: if the accredited lab requests design revisions in Month 5–6 (2027-03-08 to 2027-04-08), does the consultant engage, or has the contract ended? This ambiguity creates execution risk.

**Recommendation**:
By Month 0.5 (2026-10-23), formalize the EMC consultancy contract with Dr. Tamm to include: (1) Milestones: prototype design (Month 2 = 2026-12-08, EUR 5k), in-house rig validation (Month 3 = 2027-01-08, EUR 8k), lab submission and pre-test review (Month 4–5 = 2027-02-08 to 2027-03-08, EUR 7k), and design-revision support if lab results trigger changes (Month 5–6 = 2027-03-08 to 2027-04-08, EUR 3–5k contingent). Total: 23–25k, within budget. (2) Post-Month 5 (2027-03-08): retainer option (~5 hrs/week, EUR 200–400/month estimate) for Q&A and troubleshooting during production ramp and warranty issues, funded from the recurring opex line (EUR 80k/year). (3) IP and knowledge transfer: consultancy retains design credit and publication rights (supporting academic credibility); founder owns exclusive manufacturing and commercial rights. Document this in writing. (4) Exit plan: if Dr. Tamm is unavailable post-launch, a second RF engineer is hired (part-time, 0.3 FTE) to own ongoing design changes and warranty diagnostics. This removes ambiguity, protects knowledge continuity, and clarifies cost and expertise responsibility.

## 2. Define Explicit Roles and Authority for Gate Decisions (Hard-Tooling Release, Segment Pivot, Tranche Release)

The plan identifies decision gates at Months 5, 6, 8, and 12.5 (2027-03-08, 2027-04-08, 2027-06-08, 2027-10-23) but does not assign clear decision authority. For example, at Month 5 (2027-03-08), 'the accredited lab pre-test results confirm the design readiness'—but who evaluates this? The RF consultant, the PM, the Chief Product Officer (if role is created), or the advisory board? If results are borderline (e.g., attenuation meets specs at 100 MHz but falls short at 50 MHz), who decides: iterate the design or narrow the claim scope? Without clear decision authority, delays and conflicts emerge.

**Recommendation**:
Create a 'Gate Authority Matrix' document (one-page, finalized by Month 0.5 = 2026-10-23) mapping each gate to a decision owner and approval process: (1) Month 5 (2027-03-08) design-readiness gate: RF engineer + Chief Product Officer (or PM if CPEO role not created) + Legal review (60-minute meeting, decision same day or next). Decision: proceed to formal lab submission, or iterate design. (2) Month 6 (2027-04-08) hard-tooling release gate: founder + advisory board (Sofia + Erik, or a formal panel) approval on presale deposits >= 80k + design readiness confirmed. (3) Month 8 (2027-06-08) presale cutoff gate: PM + Presale Manager, no advisory approval needed (operational, not strategic). (4) Month 12.5 (2027-10-23) cash-flow gate sign-off: Sofia (financial officer) + founder + external advisor (Erik or formal advisor), with documented tiebreaker rule if result is ambiguous. Document this matrix in a one-page governance document, share with all stakeholders, and reference it in monthly checkpoint calls. This removes ambiguity and accelerates decisions.

## 3. Strengthen Supply-Chain Risk Management and Diversification Planning

The Supply Chain & Manufacturing Coordinator role includes secondary-fabricator pre-qualification and backup gasket suppliers, which is strong. However, the plan does not assign responsibility for supply-chain contingency scenarios: if the primary Tallinn fabricator raises prices >10% (estimate) mid-year, who decides to transition to secondary and when? If gasket supply is disrupted for >2 weeks, who escalates to founder and advises on alternative materials? The risk register is mentioned but no owner is named, and no decision framework is published. Supply-chain decisions interact with cash-flow gate timing (e.g., transition delay pushes first batch shipment, missing the gate measurement window), so they need escalation authority.

**Recommendation**:
Strengthen supply-chain governance: (1) Assign 'Supply Chain Risk Owner' to the Supply Chain Coordinator (Taavi) with monthly decision authority (up to EUR 5k contingency spend) for supplier transitions, quality re-qualification, or buffer-stock adjustments. Escalate decisions >5k or >2-week timeline impact to founder and advisory board. (2) Formalize the supply-chain risk register as a shared spreadsheet (updated weekly, reviewed monthly) with: lead-time baseline and alert thresholds, pricing baseline and alert thresholds (>10% increase = trigger secondary-supplier evaluation), capacity reservation status, and known vendor risks (e.g., key-person dependency, financial health). (3) Pre-qualify the secondary fabricator by Month 1 (2026-11-08) with a trial batch (not just capacity check; actual laser-cut and bend samples, quality comparison). Document trial cost and quality metrics. (4) Hold gasket buffer stock (30-day supply, EUR 5–10k estimate) by Month 3 (2027-01-08), not just Month 6 (2027-04-08), to cover any pre-production supply disruption. (5) Define contingency timelines in writing: if primary supplier signals >10% price increase or capacity loss, secondary transition must begin within 5 business days, with re-qualification target of 2 weeks. If gasket supply is disrupted, sourcing alternative material must begin within 3 business days. This reduces surprise and ensures supply-chain decisions do not slip critical-path milestones.

## 4. Formalize Presale Segment Tracking and Pivot Trigger Ownership

The plan proposes weekly segment tracking and a pivot trigger at Month 3 (2027-01-08) if prepper deposits exceed 70%, but does not assign ownership of the tracking data or the pivot decision. Is the Presale Manager (James) solely responsible for reporting segment metrics, and does the PM (Marie) decide the pivot, or is it a collaborative decision? If prepper conversion is at 65% by Month 3 (2027-01-08) (ambiguous vs. 70% threshold), who decides whether to pivot? Without clear ownership and decision criteria, the pivot is delayed, and by Month 4–5 (2027-02-08 to 2027-03-08), if the mix continues prepper-heavy, the hard-tooling decision is already committed without evidence of a profitable mix.

**Recommendation**:
Formalize presale segment tracking and pivot ownership: (1) The Presale Manager (James) owns the weekly segment-tracking data (deposit count, AOV, conversion rate by segment) and publishes a one-page 'Presale Weekly Dashboard' every Monday by 09:00 UTC, visible to PM (Marie), founder, and advisory board. (2) By Month 3 (2027-01-08), the PM + Presale Manager + founder hold a 90-minute 'Demand-Mix Review' meeting to analyze segment trends, compare to targets (prepper 40–50%, infrastructure 30–40%, privacy/forensics 35–45%), and decide: proceed with current mix or pivot marketing. (3) Pivot decision criteria (formalized by Month 0.5 = 2026-10-23): (a) if prepper deposits exceed 70% of total by Month 3 (2027-01-08), reallocate EUR 10–15k from prepper to infrastructure/privacy channels immediately; (b) if total deposit rate is <40% (estimate target is 40–50%) by Month 3 (2027-01-08), extend presale campaign by 4 weeks (to Month 10 = 2027-08-08 instead of Month 8 = 2027-06-08) and cut presale price by 10% (estimate) for a limited-time offer; (c) if prepper AOV falls below EUR 60 (estimate target EUR 50–70), reduce marketing spend on that segment by EUR 5k. (4) Document each pivot decision and publish results of the Month 3 (2027-01-08) review to stakeholders. This ensures decisions are data-driven, timely, and transparent.

## 5. Expand Regulatory and Compliance Ownership to Include Ongoing Monitoring and Claim-Audit

The Regulatory Compliance & Legal Advisor provides episodic deliverables (legal opinion by Month 1 = 2026-11-08, presale terms, insurance), but no ongoing compliance monitoring or claim-audit function is assigned. The plan states 'quarterly compliance checklist' but does not specify who updates it, who reviews customer complaints for compliance implications, or who decides whether a claim needs revision after real-world reports or new regulatory guidance. This creates risk: a customer complaint that the enclosure fails to protect in a real RF event could be mishandled or trigger uncoordinated responses across marketing, customer support, and legal. Additionally, as the plan scales post-Year-1, compliance risk (warranty claims, regulatory inquiry) will increase, and reactive legal engagement may be too slow.

**Recommendation**:
Expand compliance responsibility: (1) Assign 'Ongoing Compliance Monitor' role to a combination of Legal (quarterly) + Financial Officer (monthly) + Presale Support (real-time). (2) Monthly 'Compliance Review' meeting (20 minutes, Month 1 = 2026-11-08 onward): Legal reviews customer complaints, warranty requests, and social-media mentions for claim-substantiation risks; Financial Officer reports on refund patterns (fit vs. performance issues); Presale Support reports support-ticket themes (commonly disputed functionality, delivery issues). (3) Quarterly 'Claims Audit' (30 minutes, Months 3, 6, 9, 12 = 2027-01-08 to 2027-10-08): compare all published marketing claims (website, presale materials, forum posts, social media) to the accredited lab report; flag any claim that exceeds measured attenuation or is unclear. Update materials accordingly. Document all changes in a 'Claims Change Log' shared with stakeholders. (4) Post-gate: if real-world Carrington event occurs and customer losses are reported, Legal has a pre-drafted 'Incident Response Plan' (drafted by Month 3 = 2027-01-08, <2 pages) defining escalation, communication, warranty interpretation, and insurance-claim process. This proactive monitoring reduces reactivity and regulatory surprise risk.

## 6. Define Explicit Success Metrics and KPIs for Each Role, with Monthly Tracking

The plan defines overall project metrics (1,500 units delivered, EUR 25k+ cash flow, presale EUR 80–120k deposits) but does not assign KPIs to individual roles. For example, what is James's (Presale Manager) success metric? Deposits by Month 6 (2027-04-08), or deposit rate (deposits/week), or presale conversion rate (deposits/website visits)? What is Taavi's (Supply Chain) metric: on-time delivery of first batch by Month 6 (2027-04-08), or zero production delays >5 days? Without clear metrics, accountability is soft, and performance issues are discovered late.

**Recommendation**:
Create a 'Role KPI Scorecard' (simple spreadsheet) by Month 0.5 (2026-10-23) defining one primary and two secondary metrics for each role, with targets and monthly tracking: (1) RF Engineer: primary = 'prototype design ready for lab by Month 4 (2027-02-08)' (yes/no), secondary = 'in-house rig attenuation variance <5% (estimate) across two independent seam cycles' and 'zero design changes post-Month 5 (2027-03-08) pre-test review'. (2) Product Manager (Marie): primary = 'all gate milestones met on schedule (design freeze Month 2 = 2026-12-08, lab submission Month 4 = 2027-02-08, tooling release Month 6 = 2027-04-08)' (yes/no), secondary = 'cash burn within ±10% of plan' (monthly), 'zero blocker issues unresolved >3 days'. (3) Supply Chain (Taavi): primary = 'first batch delivered to fulfillment by Month 6.5 (2027-04-23)' (yes/no), secondary = 'fabricator pricing locked by Month 1.5 (2026-11-23)' (yes/no), 'zero unplanned supply delays >2 weeks'. (4) Presale Manager (James): primary = 'EUR 80k+ net presale deposits by Month 6 (2027-04-08)' (EUR amount), secondary = 'segment-mix breakdown by Month 3 (2027-01-08)' (% prepper, infrastructure, privacy), 'presale conversion rate ≥40% (estimate) by Month 3 (2027-01-08)' (%). (5) Financial Officer (Sofia): primary = 'cash-flow gate pass/fail by Month 12.5 (2027-10-23)' (decision), secondary = 'monthly burn within ±5% of plan' (EUR amount), 'presale deposit liability separately accounted' (yes/no). Review metrics monthly in the advisory-board call; escalate any role on track to miss target >5% variance. This creates accountability and early warning.

## 7. Formalize Handoff and Documentation Practices to Reduce Knowledge Fragmentation

The team plan lists individual roles and their responsibilities, but does not define how knowledge, decisions, and project context are shared or documented. For example, when Dr. Tamm (RF Engineer) completes design validation by Month 5 (2027-03-08), what documentation does she leave behind for the production and warranty team? When the Presale Manager launches three parallel campaigns (prepper, infrastructure, privacy), does he document the messaging, audience segments, and channel strategy in a shared location so that others can maintain or adapt it post-gate? If the founder becomes unavailable (Backup Ops role), what does Erik need to know to step in? Without formalized documentation and handoff practices, knowledge remains in individuals' heads, and key decisions or context are lost if turnover occurs.

**Recommendation**:
Establish documentation and handoff practices by Month 0.5 (2026-10-23): (1) Create a shared project repository (Google Drive or equivalent) with the following structure: /Project-Overview (goal, budget, timeline, key decisions), /Design (design files, CAD, RF calculations, in-house rig protocols, lab correspondence, final accredited-lab report), /Presale (campaign strategy, segment targeting, messaging, landing-page assets, customer-support SOP), /Compliance (legal opinion, presale terms, scope statements, insurance policy, regulatory checklist), /Supply-Chain (fabricator agreements, gasket supplier contacts, quality-assurance checklists, production timeline), /Financials (budget allocation, monthly burn tracking, presale deposit accounting, gate-measurement spreadsheet). (2) At each major gate (Months 5, 6, 8, 12.5 = 2027-03-08, 2027-04-08, 2027-06-08, 2027-10-23), responsible role owner (RF for Month 5 = 2027-03-08, PM for Months 6 & 8 = 2027-04-08, 2027-06-08, Financial Officer for Month 12.5 = 2027-10-23) updates a 1-page 'Gate Checkpoint Summary' (decision made, data used, next actions, risks identified) and files it in /Project-Overview/Gate-Records. (3) Monthly 'Knowledge Handoff' document (30 minutes to draft): PM collects a bulleted summary of who did what, key decisions made, outstanding issues, and who to contact for each topic. Circulates to the team on the 1st of each month. (4) Exit plan for each role: RF Engineer documents design rationale and known edge cases by Month 5 (2027-03-08); Presale Manager documents campaign performance and segment insights by Month 8 (2027-06-08); Supply Chain documents supplier relationships and lead-time baselines by Month 10 (2027-08-08). This practice ensures continuity if a person leaves or becomes unavailable.