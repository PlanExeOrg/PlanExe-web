Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 10 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 9 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a biomedical research and development initiative aimed at investigating and scaling therapies for cellular aging reversal. Reversing biological aging through mechanisms like cellular reprogramming, senescent cell clearance, and epigenetic modification operates entirely within known biophysics — organisms are open systems that locally reduce entropy by consuming energy, fully consistent with the second law of thermodynamics. The plan does not require breaking any named law of physics, nor does it depend on any non-physical causal mechanism.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan hinges on a novel combination of product (cellular aging reversal), market (Singapore as 'global epicenter'), tech/process (high-throughput automation + biomarker validation), and policy (Singapore's progressive regulatory framework). While Altos Labs ($3B) provides credible precedent for the core scientific mission at comparable or larger scale, no single entity has executed this specific whole-system combination before. However, credible precedent exists for the core components (Altos Labs, Calico, Buck Institute, Unity Biotechnology), and failure would not be existential because the scientific knowledge, validated biomarker hierarchy, and physical infrastructure would retain value even if the specific positioning goals are not fully achieved.

**Mitigation**: Run parallel validation tracks covering four critical subdomains: (1) Market/Demand — validate Singapore's positioning through competitive analysis against Altos Labs and Calico, confirming first-mover viability; (2) Legal/IP/Regulatory — execute HSA pre-submission consultation with three distinct classification scenarios and obtain formal legal opinion on regulatory pathway; (3) Technical/Operational/Safety — establish biomarker validation hierarchy with independent replication of at least three candidate surrogate endpoints by year 3; (4) Ethics/Societal — launch public advisory board and transparent engagement program to test societal legitimacy assumptions. Define two global NO-GO gates: (1) empirical/engineering validity — validated surrogate endpoints must pass independent replication before any human trial trigger; (2) legal/compliance clearance — HSA must provide actionable classification guidance before binding facility or talent commitments. Reject domain-mismatched PoCs that do not address the specific aging-reversal intervention class. Owner: Project Director with regulatory, scientific, and communications leads; Deliverable: Validated classification determination, biomarker evidence package, and public legitimacy assessment; Date: Within 180 days of plan initiation.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while one-pagers exist for all 19 strategic decisions with mechanism-of-action descriptions, there are material gaps in the strategic architecture: the governance architecture is absent during the critical startup phase (circular dependency where the Board must ratify the charter but does not yet exist), the C-suite reporting structure among eight executive roles is undefined, six critical roles (Clinical Operations Director, Safety and Pharmacovigilance Officer, GMP Manufacturing Director, Technology Transfer Officer, General Counsel, Head of Biomarker Validation) are missing from the team structure, and specific biomarker candidates referenced as 'defined cellular reversal markers' are never specified. These gaps mean that while the strategic frameworks are conceptually defined, the operational ownership and measurable outcome structures are incomplete for several critical concepts.

**Mitigation**: Project Director with Legal Counsel: Draft and ratify an Interim Governance Authority with a written Interim Decision-Rights Charter within 14 days (by 2026-Sep-19), specifying dollar thresholds and approval requirements to eliminate the accountability vacuum during charter development. Chief Risk & Governance Officer: Establish a formal C-suite organizational chart with a RACI matrix within 3 months, defining reporting hierarchy, escalation pathways, and boundary agreements between overlapping roles. Scientific Director with HR: Appoint the six missing C-suite roles (Clinical Operations Director, Safety and Pharmacovigilance Officer, GMP Manufacturing Director, Technology Transfer Officer, General Counsel, Head of Biomarker Validation) by 2027-Q1, each with defined one-pagers including value hypotheses, success metrics, and decision hooks. Scientific Director with Biomarker Team Lead: Commission an independent pre-validation assessment by 2026-Q4 to specify exact biomarker candidates, assay methods, and replication standards for go/no-go gates, replacing the currently undefined 'cellular reversal markers' with documented, measurable evidentiary thresholds.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register covers 16 hazards with owners and controls, but material gaps exist in insurance/liability coverage, governance architecture, and regulatory classification. Cascades are partially analyzed in the risk summary but not systematically mapped across interdependent risk domains.

**Mitigation**: Risk Management Lead: Expand the risk register to include insurance/liability coverage, governance architecture, and regulatory classification as first-order risks; map explicit cascade chains (e.g., regulatory classification delay → insurance scoping failure → HSA authorization block → clinical timeline delay → revenue shortfall); establish monthly risk review cadence with dated checkpoints. Within 60 days of plan initiation.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical predecessors are unmapped and contradictory. The HSA classification determination—the foundational gate that every downstream decision (ethics protocols, GMP specs, insurance scope, biomarker thresholds) depends on—is treated as one parallel workstream rather than THE critical path gate, and no pre-submission consultation has occurred. Insurance is scheduled 6 months after inception (2027-Mar-05) yet insurance evidence is a prerequisite for HSA Clinical Trial Authorization and IRB ethics approval—a direct sequencing contradiction. The governance charter has a circular dependency (Board must ratify but does not yet exist), and the SAB with binding veto power does not convene until 2026-Dec-15, leaving 100+ days without independent scientific oversight. The permit/approval matrix for the most critical determination is effectively absent, and the reclassification contingency is described as 'dangerously naive.' These contradictions meet criterion (c) for HIGH regardless of added buffers.

**Mitigation**: Project Director with Regulatory Affairs Lead: Immediately elevate HSA pre-submission consultation to THE single critical project gate—condition all binding commitments (facility lease, talent contracts, equipment procurement) on the classification outcome. Engage a specialized regulatory law firm (Hogan Lovells Singapore) within 2 weeks to prepare three distinct classification scenarios with corresponding evidence requirements. Restructure the regulatory-insurance-ethics sequence into a parallel critical path: engage biomedical insurance brokers (Marsh, Aon, WTW) within 2 weeks alongside HSA consultation so classification and insurance risk assessment proceed simultaneously. Establish an Interim Governance Authority with a written Interim Decision-Rights Charter within 14 days (by 2026-Sep-19) to break the circular dependency, and accelerate SAB convening to 2026-Nov-15. Within 30 days of plan initiation.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan describes a blended funding architecture (core public/institutional commitment of SGD 200–250 million plus private partnership funding across four channels) but documents zero signed/committed funding sources or term sheets. The funding model exists entirely as an assumption ('will materialize as planned'), with the risk register explicitly flagging 'private co-funding shortfalls (20–30%, SGD 50–100 million additional public burden)' as a significant risk. No formal funding agreement, ministerial endorsement, or investor commitment has been documented. Financing gates/covenants are defined (milestone-linked disbursements, SGD 25M board approval thresholds, 15% contingency reserve), but without any committed sources, the runway is entirely dependent on unvalidated assumptions.

**Mitigation**: CFO with Treasury Specialist: Within 30 days, secure binding letters of intent from at least two private investors and a formal memorandum of understanding from NRF/A*STAR confirming the SGD 200–250 million core public commitment; establish a dated financing plan listing all sources/status, draw schedule tied to go/no-go gate milestones, and a NO-GO trigger if private co-funding falls below 15% of total budget by 2027-Q1.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the SGD 500M budget includes a 15% contingency reserve and references four comparables (Altos Labs, Calico, Buck Institute, Unity Biotechnology), but lacks vendor quotes and per-area normalization to substantiate the figure's adequacy.

**Mitigation**: CFO with Facility Director: Obtain site-specific lease and equipment quotes from ≥3 vendors, calculate normalized cost per m²/ft² against Altos Labs and Buck Institute benchmarks, and adjust budget or de-scope by 2026-Nov-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents its most critical projections—the SGD 500 million total budget, the 10-year timeline, and the year 3–4 first human trial target—as single-point estimates without providing sensitivity analysis, worst-case scenarios, or confidence intervals. While individual risk items carry ranges (e.g., construction overruns of 15–25%), the aggregate projections lack contingency planning: no scenario addresses what happens if the total budget reaches SGD 600–650 million or if timelines slip by 2–3 years. The plan discusses alternative strategic postures (Builder/Pioneer/Consolidator) but does not provide quantitative best/worst/base-case analyses for its key financial and completion-date projections, indicating optimism that the SGD 500 million and 10-year horizon will hold without material deviation.

**Mitigation**: CFO with Scientific Director: Conduct a sensitivity analysis on the two most critical projections—total budget and timeline—defining best-case (SGD 450M, 9 years), base-case (SGD 500M, 10 years), and worst-case (SGD 650M, 12 years) scenarios with explicit trigger conditions for each. Model the compound impact of simultaneous construction overruns (25%), co-funding shortfalls (30%), and timeline slippage (2 years) on the contingency reserve and project viability. Deliverable: Published scenario analysis with NO-GO triggers (e.g., if private co-funding <15% by 2027-Q1 or cumulative delays >18 months, activate scope reduction). Within 60 days of plan initiation.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan describes conceptual frameworks for all build-critical components but lacks the detailed engineering artifacts needed to execute them. Most critically, the biomarker validation hierarchy—the evidentiary gatekeeper for the entire pipeline—has no defined biomarkers, assay methods, replication standards, or validation protocols; the plan references only undefined 'cellular reversal markers.' The facility (15,000–20,000 sq ft lease/retrofit) lacks detailed engineering specifications, acceptance test criteria, or non-functional requirements (temperature, humidity, clean-room specs, power capacity). The modular technology platform lacks technical specifications, interface definitions between automation modules, or acceptance criteria for throughput and data quality. The governance architecture (Board of Governors, SAB with binding veto) lacks detailed specifications, interface contracts, or acceptance criteria for decision processes. No integration plan with specific milestones, owners, and dates exists for cross-system integration, and no non-functional requirements are documented for any build-critical component.

**Mitigation**: Project Director with Scientific Director, COO, and CTO: Produce comprehensive engineering artifacts for all build-critical components within 90 days: (1) Technical specifications for the facility (clean-room standards, HVAC, power, humidity controls) and technology platform (throughput targets, latency, data quality thresholds); (2) Interface contracts defining data flows and dependencies between facility systems, automation platforms, biomarker validation, governance systems, and clinical trial infrastructure; (3) Acceptance test criteria for each component (facility readiness, platform throughput, biomarker validation, governance process); (4) A detailed integration map with named owners, milestones, and dates for cross-system integration; (5) Non-functional requirements (availability ≥99.5%, security standards, scalability) for all components. Owner: Project Director; Deliverable: Complete engineering artifact package (specs, interface contracts, acceptance tests, integration map, NFRs); Date: Within 90 days of plan initiation.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes numerous critical legal, contractual, and operational claims without any verifiable artifacts. The SGD 500M blended funding architecture (SGD 200–250M core public commitment plus private co-funding across four channels) exists only as an assumption—no signed funding agreements, term sheets, or letters of intent are documented. The partnerships with MIT, Stanford, Oxford, and Cambridge are described as planned but no formal agreements exist. The HSA pre-submission consultation—the foundational regulatory gate—has not occurred, and the plan itself states 'current assumptions are speculative.' No facility lease agreements for one-north have been executed. No insurance broker quotes, actuarial assessments, or coverage indications have been obtained. The governance charter is undrafted, the Board of Governors is not constituted, and the Scientific Advisory Board has not convened. The 'defined cellular reversal markers' referenced as the evidentiary gatekeeper are never specified—no biomarker candidates, assay methods, or replication standards are documented. The plan's own SWOT 'Missing Information' section and expert reviews confirm these gaps are systemic, not isolated.

**Mitigation**: Project Director with Regulatory Affairs Lead, CFO, and Chief Risk & Governance Officer: Within 30 days, execute binding letters of intent from at least two private investors and a formal MOU from NRF/A*STAR confirming the SGD 200–250M core public commitment; engage specialized regulatory law firm (Hogan Lovells Singapore) to prepare three HSA classification scenarios; engage biomedical insurance brokers (Marsh, Aon, WTW) for preliminary coverage indications; commission an actuarial risk assessment; draft and ratify the Interim Governance Authority charter with decision-rights matrix; accelerate SAB convening to 2026-Nov-15; and commission an independent pre-validation assessment to specify exact biomarker candidates, assay methods, and replication standards for go/no-go gates. Deliverable: Signed funding commitments, HSA classification determination, insurance coverage indications, ratified governance charter, and documented biomarker validation protocols. Date: Within 90 days of plan initiation.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while several key milestones are specific (first human trials by year 3–4, SGD 500 million budget deployment, GMP-ready manufacturing by years 8–10), the project's core deliverable—'Establish a state-of-the-art Reverse Aging Research Lab'—is mentioned without defining what 'state-of-the-art' means in verifiable terms. Similarly, 'positioning Singapore as the definitive global epicenter of longevity science,' 'building public trust and societal legitimacy,' and 'developing a self-sustaining research model' are cited as final outputs without any specific, quantifiable KPI. The 'Measurable' criteria describe outcomes like 'facility fully operational' and 'go/no-go gates established and functioning' without specifying acceptance thresholds or performance indicators.

**Mitigation**: Project Director with Scientific Director: Define SMART acceptance criteria for abstract deliverables within 60 days, including specific KPIs for facility readiness (≥95% infrastructure operational), global epicenter positioning (≥3 top-tier publications/year), and public trust (≥60% positive perception score).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains multiple features that add significant cost and complexity without demonstrably supporting the project's primary objectives of establishing a Singapore-based Reverse Aging Research Lab and positioning Singapore as the global epicenter of longevity science. Four clear gold-plating features were identified: (1) The distributed consortium model with satellite research nodes worldwide (Decision 10, Choice 2) adds massive governance complexity, data sovereignty conflicts, and IP management burden across jurisdictions — the core objective is a Singapore-based lab, not a global distributed network. (2) The fully automated AI-integrated high-throughput screening facility (Decision 12, Choice 1) commits SGD 50–100 million in capital with acknowledged obsolescence risk, when the modular approach achieves identical discovery goals. (3) The integrated GMP manufacturing facility built from project inception (Decision 13, Choice 1) commits SGD 100–200 million before any therapy has proven human efficacy, when pilot-scale manufacturing achieves the same Phase I/II clinical trial supply needs. (4) The 'Killer Application' biomarker validation hub ambition adds significant complexity and cost beyond the lab's own research mission, positioning the lab as 'the field's authoritative validation hub' — an aspirational goal that is not a stated primary objective. These features collectively represent hundreds of millions in unnecessary capital commitment and operational complexity that could be redirected toward the core mission.

**Mitigation**: Project Director with Scientific Director and CFO: For each flagged feature, require a one-page Benefit Case Review within 30 days containing: (a) explicit demonstration of how the feature supports a primary project objective; (b) a defined KPI measuring its contribution; (c) estimated total cost of ownership; and (d) a named owner accountable for delivering that KPI. Features that cannot produce a credible benefit case must be moved to the project backlog. Specifically: (1) Distributed Consortium Model — replace with formal co-location agreements at one-north only; (2) Fully Automated Screening — adopt the modular platform strategy (Decision 12, Choice 2) with incremental automation; (3) Integrated GMP Manufacturing — adopt pilot-scale manufacturing with GMP expansion contingent on efficacy milestones (Decision 13, Choice 3); (4) Killer Application Biomarker Hub — defer to a post-initiative phase after core research objectives are met. Owner: Project Director; Deliverable: Benefit Case Reviews for each flagged feature with KPI, owner, and cost, or backlog reassignment; Date: Within 30 days of plan initiation.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Chief Regulatory & Ethics Officer must navigate an unprecedented regulatory category with zero precedents while owning the single most critical project gate determining every downstream decision from ethics to GMP.

**Mitigation**: Chief Risk & Governance Officer: Within 14 days, engage a specialized Singapore biomedical regulatory law firm (e.g., Hogan Lovells Singapore) to validate the talent market for this specific role, assessing candidate pool size, compensation benchmarks, and whether the required HBPA expertise for unprecedented intervention classification can be sourced.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names controlling regimes—Singapore's Human Biomedical Products Act (HBPA) and Health Sciences Authority (HSA)—and defines lead times (pre-submission consultation within 30 days, IRB submission by 2026-Dec-31). However, the plan itself acknowledges that aging-reversal interventions are 'an unprecedented regulatory category with no established precedents,' the reclassification contingency to 'regenerative medicine' is described as dangerously naive, and no HSA consultation has occurred, leaving the required approval pathway effectively unmapped and uncosted.

**Mitigation**: Regulatory Affairs Lead with Legal Counsel: Elevate HSA pre-submission consultation to THE single critical project gate—condition all binding commitments on the classification outcome. Engage a specialized Singapore biomedical regulatory law firm (e.g., Hogan Lovells Singapore) within 2 weeks to prepare three distinct classification scenarios with corresponding evidence requirements. Establish a formal legal opinion on the regulatory classification landscape and restructure the regulatory-insurance-ethics sequence into a parallel critical path. Within 30 days of plan initiation.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has no quantified post-year-10 revenue model despite explicitly acknowledging a SGD 30–60 million annual funding gap after the initial horizon, no succession protocols for anchor investigators whose departure costs SGD 15–30 million each, and SGD 50–100 million technology obsolescence risk from automated platforms. The 'self-sustaining model' remains aspirational with no committed commercialization pathway, no endowment fund capitalization plan, and no government bridge funding commitment. The plan's own risk register confirms: 'If no therapy reaches clinical deployment, existential funding cliff threatens institutional closure.'

**Mitigation**: CFO with Scientific Director: Develop a detailed sustainability roadmap by 2027-Q2 including scenario-based financial models projecting revenue from spin-out equity, licensing royalties, and state-supported deployment; establish a target endowment fund size (SGD 150–300 million) with a defined capitalization timeline; engage VC and pharmaceutical partners with term sheet templates; secure a government commitment framework guaranteeing baseline funding for the first 5 years post-initiative. Chief Risk & Governance Officer: Establish explicit succession protocols for all anchor investigators with bench-strength pipeline requirements ensuring at least two qualified researchers can backfill any departure within 6 months. CTO: Formalize technology refresh cycles and upgrade paths with dedicated technology watch function to mitigate obsolescence risk.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lists required permits (building, Green Mark, biosafety, GMP) but has obtained none, and the foundational HSA classification determining facility constraints hasn't occurred, leaving requirements unverified.

**Mitigation**: COO with Regulatory Affairs Lead: Perform a fatal-flaw screen with Singapore BCA, HSA, and environmental authorities to confirm zoning, fire load, structural, and occupancy constraints for the one-north facility; obtain written permit confirmations and define dated NO-GO thresholds tied to constraint outcomes. Within 60 days of plan initiation.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan establishes partial redundancy across external dependencies—diversified vendor pools (2-3 suppliers with 3-6 month strategic reserves), phased facility lease-and-retrofit preserving capital flexibility, federated data architecture distributing raw data across jurisdictions, and CDMO backup partnerships for GMP manufacturing. However, material gaps remain: no tested failovers exist for any critical external dependency, the HSA classification determination is a single point of failure with a 'dangerously naive' reclassification contingency, and the absence of insurance coverage and governance architecture creates untested single points of failure that could cascade through vendor, data, and facility dependencies simultaneously.

**Mitigation**: COO with Regulatory Affairs Lead and CFO: Within 60 days, (1) execute binding SLAs with at least 2 backup vendors per critical reagent category and test failover by simulating a 3-month supply disruption; (2) condition all facility commitments on HSA classification outcome and establish a documented facility relocation/alternative-site contingency; (3) formalize federated data architecture with tested cross-jurisdiction data transfer failover and GDPR/PDPA compliance baseline; (4) engage biomedical insurance brokers within 2 weeks and restructure insurance as a parallel critical path; (5) establish Interim Governance Authority with decision-rights charter within 14 days to enable timely external-dependency decisions.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Finance stakeholders (Singapore Government, private investors) are incentivized by quarterly budget adherence and milestone-linked disbursements requiring demonstrable short-term progress, while R&D teams are incentivized by long-term scientific discovery requiring patient capital and tolerance for failure—creating a fundamental conflict over resource allocation between disciplined spending and speculative innovation.

**Mitigation**: CFO with Scientific Director: Co-create a shared OKR framework within 30 days defining a common outcome—'Validate three surrogate endpoints and advance one therapeutic candidate to Phase I/II by year 5'—with jointly owned KPIs (pipeline velocity, budget adherence per gate, evidence quality score) that align financial discipline with scientific ambition, ensuring tranche releases are tied to collaborative milestones rather than unilateral spending targets.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan defines partial feedback-loop components—KPIs (Pipeline Velocity, FRI, TRIIS), review cadences (quarterly financial reviews, quarterly integration health checks, monthly C-suite meetings), owners (IMO, CFO, CTIO), and change-control mechanisms (go/no-go gates with biomarker benchmarks, SGD 25M decision-rights thresholds)—but these are not integrated into an operational governance loop. The governance architecture (Board of Governors, SAB with binding veto) that would make these elements functional is absent due to a circular dependency, and no explicit thresholds for when to re-plan or stop the entire initiative are defined. The plan acknowledges these gaps but has not yet closed them.

**Mitigation**: Project Director with Chief Risk & Governance Officer: Establish an Interim Governance Authority with a written Interim Decision-Rights Charter within 14 days (by 2026-Sep-19), specifying dollar thresholds and approval requirements. Accelerate SAB convening to 2026-Nov-15 with a preliminary mandate to review go/no-go gate criteria. Publish the Financial Resilience Index quarterly starting Q1 2026 with automated alerts when any sub-metric falls below target. Define explicit NO-GO triggers (e.g., FRI <60% for two consecutive quarters, pipeline velocity <2 candidates per gate for two consecutive quarters, TRIIS <70% for two consecutive quarters) that mandate scope reduction or project termination review. Within 30 days of plan initiation.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because three High-severity risks—scientific hypothesis failure (SGD 150–250M at risk), financial sustainability (15–25% construction overruns + 20–30% co-funding shortfalls), and public perception/legitimacy (SGD 100–200M in threatened funding)—are explicitly coupled in a reinforcing spiral where scientific setbacks amplify financial risks, which intensify public scrutiny, which further constrains governance flexibility. More critically, a single dependency—the HSA regulatory classification determination—triggers multi-domain failure across ethics protocols, GMP specifications, insurance scoping, biomarker validation thresholds, and the entire clinical timeline, yet no pre-submission consultation has occurred and the reclassification contingency is described as 'dangerously naive.' The absence of a formal interdependency map or bow-tie analysis means these cascades are identified but not systematically surfaced or governed.

**Mitigation**: Risk Management Lead with Scientific Director and CFO: Within 30 days, produce (1) a cross-impact interdependency map linking all 16 risks with explicit cascade chains (e.g., regulatory classification delay → insurance scoping failure → HSA authorization block → clinical timeline delay → revenue shortfall); (2) a bow-tie/FTA analysis for the top three coupled risk clusters identifying common-cause failures and single-point triggers; (3) a combined heatmap with named owners, dated checkpoints, and explicit NO-GO/contingency thresholds (e.g., if HSA classification is unresolved by 2026-Dec-31, freeze all binding commitments; if FRI <60% for two consecutive quarters, activate scope reduction). Deliverable: Integrated risk cascade dashboard with NO-GO triggers; Date: Within 30 days of plan initiation.