**Primary domain:** Biogerontology

**Secondary domains:** Regenerative Medicine, Bioinformatics, Clinical Trials

**Rationale:** Biogerontology is the primary discipline because the project's core success criterion — reversing cellular aging — is the defining mission of this field, and it holds the highest importance × specificity score (25) as the sole outcome-role candidate. All other candidates (Regenerative Medicine, Clinical Trials, Bioinformatics, Translational Medicine, Biomedical Engineering as methods; Biomedical Ethics, Health Policy as constraints; Science Policy as a lower-scoring method) are subordinate to the central scientific purpose that biogerontology owns.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Biogerontology | 5 | 5 | outcome | The entire project's core mission is reversing cellular aging, making biogerontology the central discipline that defines the lab's scientific purpose and success criterion. |
| Regenerative Medicine | 5 | 4 | method | The project explicitly recruits regenerative medicine specialists to develop therapies that reverse aging processes, making this discipline a primary method for delivering the lab's therapeutic goals. |
| Clinical Trials | 5 | 4 | method | The project explicitly targets responsible human trial implementation and validation of aging therapies, making clinical trial methodology a core operational discipline. |
| Biomedical Ethics | 4 | 4 | constraint | The project relies on Singapore's streamlined ethical approval processes and emphasizes responsible human trial implementation, making ethics oversight a critical constraint. |
| Translational Medicine | 4 | 4 | method | The project's core mission is accelerating the path from cellular aging discovery to validated human therapies, which is the definition of translational medicine. |
| Biomedical Engineering | 4 | 4 | method | Essential for designing and constructing the state-of-the-art research facility infrastructure, specialized lab equipment, and technical systems required for cutting-edge aging reversal research. |
| Health Policy | 4 | 4 | constraint | Critical for leveraging Singapore's progressive biomedical regulatory framework, navigating ethical approval processes, and ensuring compliance with national and international research governance standards. |
| Bioinformatics | 3 | 4 | method | Bioinformatics experts are explicitly named as part of the multidisciplinary team, providing critical computational and data-analysis methods essential for aging research and therapy validation. |
| Science Policy | 3 | 3 | method | Important for governing the large-scale multidisciplinary research initiative, shaping strategic research priorities, and managing the policy landscape for positioning Singapore as a global science hub. |