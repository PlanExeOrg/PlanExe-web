### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the $500 million, 10-year initiative, ensuring alignment with organizational goals and managing strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major project changes and deviations from the plan.
- Oversee risk management at a strategic level.
- Ensure alignment with Singapore's biomedical strategy.
- Approve key partnerships and collaborations.
- Review and approve annual operating plans and budgets.

**Initial Setup Actions:**

- Define Terms of Reference and operating procedures.
- Appoint Committee Chair and members.
- Establish communication protocols.
- Review and approve the initial project plan.

**Membership:**

- Chief Executive Officer (CEO)
- Chief Scientific Officer (CSO)
- Chief Financial Officer (CFO)
- Representative from the Singaporean Government (e.g., Ministry of Health)
- Independent External Advisor (Biomedical Industry Expert)

**Decision Rights:** Strategic decisions related to project scope, budget (above $5 million USD), timeline, and key partnerships. Approval of annual operating plans.

**Decision Mechanism:** Decisions made by majority vote, with the CEO having the tie-breaking vote. Any decision with significant ethical implications requires unanimous approval.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Discussion and approval of major project changes.
- Review of strategic risks and mitigation plans.
- Approval of annual operating plans and budgets.
- Updates from the Project Management Office (PMO).
- Review of key performance indicators (KPIs).

**Escalation Path:** Board of Directors
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to the project plan, budget, and timeline. Provides operational risk management and support to the project team.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage the project budget and track expenses.
- Monitor project progress and identify potential delays or issues.
- Coordinate project activities and resources.
- Manage operational risks and implement mitigation plans.
- Provide regular project status reports to the Steering Committee.
- Ensure compliance with project governance policies and procedures.
- Facilitate communication and collaboration among project team members.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management methodologies and tools.
- Define project reporting templates and procedures.
- Set up project communication channels.

**Membership:**

- Project Manager
- Project Coordinator
- Financial Analyst
- Risk Manager
- Communications Manager

**Decision Rights:** Operational decisions related to project execution, budget management (below $5 million USD), and resource allocation. Approval of minor project changes within defined tolerances.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Escalation to the Steering Committee for decisions exceeding the PMO's authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against the plan.
- Discussion of project risks and issues.
- Review of project budget and expenses.
- Coordination of project activities and resources.
- Preparation of project status reports for the Steering Committee.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct of research, compliance with regulatory requirements (including GDPR), and adherence to ethical guidelines. Addresses ethical concerns related to reverse aging therapies.

**Responsibilities:**

- Develop and maintain an ethical framework for the project.
- Review and approve research protocols from an ethical perspective.
- Ensure compliance with regulatory requirements, including GDPR and HSA regulations.
- Provide guidance on ethical issues related to reverse aging therapies.
- Monitor research activities for potential ethical violations.
- Investigate and resolve ethical complaints.
- Develop and implement data protection policies and procedures.
- Conduct regular compliance audits.

**Initial Setup Actions:**

- Define Terms of Reference and operating procedures.
- Appoint Committee Chair and members.
- Establish ethical review processes.
- Develop data protection policies and procedures.

**Membership:**

- Bioethicist (Independent)
- Legal Expert (Specializing in Biomedical Law)
- Patient Advocate (Independent)
- Representative from the Singapore Health Sciences Authority (HSA)
- Data Protection Officer
- Senior Researcher

**Decision Rights:** Ethical approval of research protocols, decisions related to data protection and privacy, and recommendations on compliance matters. Authority to halt research activities that violate ethical guidelines or regulatory requirements.

**Decision Mechanism:** Decisions made by majority vote, with the Bioethicist having the tie-breaking vote. Decisions involving patient safety require unanimous approval.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research protocols for ethical compliance.
- Discussion of ethical issues related to reverse aging therapies.
- Review of data protection policies and procedures.
- Updates on regulatory requirements and compliance matters.
- Investigation of ethical complaints.
- Review of informed consent processes.

**Escalation Path:** Project Steering Committee, Board of Directors (for significant ethical breaches)
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on research methodologies, technology acquisition, and scientific challenges. Ensures the project leverages cutting-edge technologies and best practices.

**Responsibilities:**

- Provide technical expertise and guidance on research methodologies.
- Evaluate and recommend technology acquisition strategies.
- Assess the feasibility of research proposals.
- Identify and address technical challenges.
- Review research findings and provide feedback.
- Monitor advancements in reverse aging research and related fields.
- Advise on intellectual property strategy.
- Support the development of research automation strategies.

**Initial Setup Actions:**

- Define Terms of Reference and operating procedures.
- Appoint Committee Chair and members.
- Establish communication protocols.
- Identify key technical areas for focus.

**Membership:**

- Leading Biogerontologist (External)
- Geneticist (Internal)
- Bioinformatics Expert (Internal)
- Regenerative Medicine Specialist (Internal)
- Technology Acquisition Specialist (External)

**Decision Rights:** Recommendations on research methodologies, technology acquisition, and intellectual property strategy. Approval of technical specifications for research equipment.

**Decision Mechanism:** Decisions made by consensus, with the Leading Biogerontologist having the final say in case of disagreement.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research proposals and methodologies.
- Discussion of technology acquisition strategies.
- Assessment of technical challenges and potential solutions.
- Review of research findings and publications.
- Updates on advancements in reverse aging research.
- Discussion of intellectual property strategy.

**Escalation Path:** Chief Scientific Officer (CSO), Project Steering Committee