This plan involves money.

## Currencies

- **SGD:** Singapore's official currency for all local transactions including facility construction/lease, equipment procurement, staff salaries, and clinical trial operations. Singapore has a stable economy and progressive biomedical regulatory framework, making SGD the sole relevant currency for this single-country project.

**Primary currency:** SGD

**Currency strategy:** The local currency (SGD) will be used for all transactions with no additional international risk management needed, as the project is confined to a single country (Singapore) with a stable economy and no currency instability concerns.