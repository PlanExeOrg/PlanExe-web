### 1. Interim Formation Lead drafts initial Governance Charter and Terms of Reference for the Board of Governors, defining composition, decision-rights matrix, and conflict resolution protocols

**Responsible Body/Role:** Interim Formation Lead / Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Governance Charter v0.1
- Draft Terms of Reference for Board of Governors

**Dependencies:**

- Project Sponsor Identified
- Project Kickoff Completed

### 2. Project Sponsor identifies and confirms initial Board of Governors membership nominees across government (40%), private investor (30%), and scientific leadership (30%) categories

**Responsible Body/Role:** Project Sponsor / Senior Management

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Confirmed Nominee List for Board of Governors
- Verified Representation Ratios

**Dependencies:**

- Draft Governance Charter v0.1 Approved by Sponsor
- Candidate Profiles Defined

### 3. Project Sponsor appoints the Independent Chair of the Board of Governors, ensuring no conflicting financial interests in the project

**Responsible Body/Role:** Project Sponsor / Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation for Independent Chair
- Conflict of Interest Disclosure Filed

**Dependencies:**

- Confirmed Nominee List Available
- Independent Chair Candidate Identified

### 4. Hold Board of Governors Inaugural Meeting to formally constitute the body, with Interim Formation Lead facilitating and Independent Chair presiding

**Responsible Body/Role:** Interim Formation Lead / Board of Governors (Independent Chair presiding)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Board of Governors Inaugural Meeting Minutes
- Formal Establishment Record

**Dependencies:**

- Appointment Confirmation for Independent Chair
- Nominees Confirmed
- Draft Governance Charter Finalized

### 5. Board of Governors ratifies its Governance Charter, Decision-Rights Matrix, and confirms final membership roster at its second formal meeting

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ratified Governance Charter
- Approved Decision-Rights Matrix
- Confirmed Membership Roster

**Dependencies:**

- Board of Governors Formally Constituted
- Draft Charter and Terms of Reference Available

### 6. Board of Governors recruits and appoints the Chair of the Scientific Advisory Board, selecting an internationally recognized biogerontologist with no project affiliations

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 4-6

**Key Outputs/Deliverables:**

- SAB Chair Appointment Confirmation
- SAB Chair Conflict of Interest Verification

**Dependencies:**

- Board of Governors Ratified Charter
- SAB Chair Candidate Identified and Vetted

### 7. Board of Governors recruits and confirms the 4-6 independent external members of the Scientific Advisory Board with expertise in biogerontology, genetics, bioinformatics, and regenerative medicine

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 5-8

**Key Outputs/Deliverables:**

- Confirmed SAB Membership Roster
- Independent Member Vetting Dossiers

**Dependencies:**

- SAB Chair Appointed
- Candidate Profiles Defined
- Board Ratified Charter Available

### 8. Board of Governors ratifies the Scientific Advisory Board Charter, formalizing the scope of binding veto authority and 2/3 supermajority voting procedures

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Ratified SAB Charter
- Defined Voting Procedures Document

**Dependencies:**

- SAB Members Confirmed
- Draft SAB Charter Prepared

### 9. Scientific Advisory Board holds its Inaugural Kick-off Meeting to establish review procedures and initial go/no-go gate criteria

**Responsible Body/Role:** Scientific Advisory Board (Chair presiding)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- SAB Inaugural Meeting Minutes
- Initial Gate Review Criteria Document

**Dependencies:**

- SAB Charter Ratified
- SAB Members Confirmed

### 10. Board of Governors recruits and appoints the Chair of the Ethics & Compliance Committee, selecting an independent bioethicist or legal scholar specializing in biomedical research

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- Ethics & Compliance Chair Appointment Confirmation
- Ethics Chair Vetting Completed

**Dependencies:**

- Board of Governors Ratified Charter
- Ethics Chair Candidate Identified

### 11. Board of Governors recruits and confirms the independent members of the Ethics & Compliance Committee, including GDPR/PDPA experts, regulatory affairs specialists, biosecurity experts, and patient protection advocates

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Membership Roster
- Independent Member Vetting Dossiers

**Dependencies:**

- Ethics Chair Appointed
- Candidate Profiles Defined
- Board Ratified Charter Available

### 12. Board of Governors ratifies the Ethics & Compliance Committee Charter and defines the compliance framework covering GDPR, PDPA, Human Biomedical Products Act, and biosecurity norms

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ratified Ethics & Compliance Charter
- Defined Compliance Framework Document

**Dependencies:**

- Ethics Members Confirmed
- Draft Ethics Charter Prepared

### 13. Ethics & Compliance Committee holds its Inaugural Kick-off Meeting, establishing whistleblower portal procedures and quarterly audit schedules

**Responsible Body/Role:** Ethics & Compliance Committee (Chair presiding)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Ethics & Compliance Inaugural Meeting Minutes
- Whistleblower Portal Established

**Dependencies:**

- Ethics Charter Ratified
- Members Confirmed

### 14. Board of Governors appoints the Integration Management Office Director, recruiting an experienced manager with expertise in multidisciplinary research programs

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 6-8

**Key Outputs/Deliverables:**

- IMO Director Appointment Confirmation
- IMO Director Vetting Completed

**Dependencies:**

- Board of Governors Ratified Charter
- IMO Director Candidate Identified

### 15. IMO Director drafts the Integration Management Office Charter, integration metrics, and operational budget plan for Board of Governors ratification

**Responsible Body/Role:** Integration Management Office Director / Board of Governors

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- IMO Charter Draft
- Defined Integration Metrics
- Operational Budget Plan

**Dependencies:**

- IMO Director Appointed
- Board Ratified Charter Available

### 16. Board of Governors ratifies the Integration Management Office Charter and approves the operational budget below the SGD 25 million threshold

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Ratified IMO Charter
- Approved Operational Budget

**Dependencies:**

- IMO Charter Draft Submitted
- IMO Director Appointed

### 17. Integration Management Office holds its Inaugural Kick-off Meeting, establishing weekly operational meeting schedules and quarterly integration health check protocols

**Responsible Body/Role:** Integration Management Office (Director presiding)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- IMO Inaugural Meeting Minutes
- Facility Readiness Timeline Draft
- Quarterly Integration Health Check Calendar

**Dependencies:**

- IMO Charter Ratified
- IMO Director Appointed

### 18. Board of Governors recruits and appoints the Chair of the Public Advisory Board, selecting an independent public health communication or science ethics expert

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 8-10

**Key Outputs/Deliverables:**

- Public Advisory Board Chair Appointment Confirmation
- Public Advisory Chair Vetting Completed

**Dependencies:**

- Board of Governors Ratified Charter
- Public Advisory Chair Candidate Identified

### 19. Board of Governors recruits and confirms the 7-9 members of the Public Advisory Board, including ethicists, patient advocacy leaders, community leaders, and religious representatives

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Confirmed Public Advisory Membership Roster
- Independent Member Vetting Dossiers

**Dependencies:**

- Public Advisory Chair Appointed
- Candidate Profiles Defined
- Board Ratified Charter Available

### 20. Board of Governors ratifies the Public Advisory Board Charter, defining its advisory scope, reporting procedures, and 60-day response protocol for recommendations

**Responsible Body/Role:** Board of Governors

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Ratified Public Advisory Board Charter
- Advisory Scope and Reporting Procedures Document

**Dependencies:**

- Public Advisory Members Confirmed
- Draft Public Advisory Charter Prepared

### 21. Public Advisory Board holds its Inaugural Kick-off Meeting, establishing public sentiment monitoring protocols and the annual public forum schedule

**Responsible Body/Role:** Public Advisory Board (Chair presiding)

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Public Advisory Inaugural Meeting Minutes
- Public Sentiment Monitoring Protocol
- Annual Public Forum Schedule

**Dependencies:**

- Public Advisory Charter Ratified
- Members Confirmed