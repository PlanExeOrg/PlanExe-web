### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by the proposed SteerCo members (CEO, CSO, CFO, Government Representative, External Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Nominated Members List Available

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on the SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Feedback from SteerCo members

### 4. CEO formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Chief Executive Officer (CEO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. CEO formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Chief Executive Officer (CEO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. CEO formally appoints the remaining members of the Project Steering Committee (CSO, CFO, Government Representative, External Advisor).

**Responsible Body/Role:** Chief Executive Officer (CEO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0
- SteerCo Chair Appointed

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- SteerCo Members Appointed

### 8. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Members Appointed
- SteerCo ToR Approved
- SteerCo Kick-off Meeting Scheduled

### 9. Project Manager establishes the PMO structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Document
- Job Descriptions

**Dependencies:**

- Project Plan Approved

### 10. Project Manager develops project management methodologies and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Handbook
- Templates and Tools

**Dependencies:**

- PMO Structure Document

### 11. Project Manager defines project reporting templates and procedures for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Reporting Templates
- Reporting Schedule

**Dependencies:**

- Project Management Handbook

### 12. Project Manager sets up project communication channels for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Plan
- Distribution Lists

**Dependencies:**

- Reporting Templates

### 13. Project Manager schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- PMO Structure Document
- Project Management Handbook
- Reporting Templates
- Communication Plan

### 14. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Structure Document
- Project Management Handbook
- Reporting Templates
- Communication Plan
- PMO Kick-off Meeting Scheduled

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 16. Project Manager circulates Draft Ethics and Compliance Committee ToR v0.1 for review by Legal Counsel and potential Bioethicist.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Circulation Email

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 17. Project Manager consolidates feedback on the Ethics and Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Ethics and Compliance Committee ToR v0.2

**Dependencies:**

- Feedback from Legal Counsel and potential Bioethicist

### 18. Project Steering Committee formally approves the Ethics and Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.2
- Project Steering Committee established

### 19. Project Steering Committee formally appoints the Ethics and Compliance Committee Chair (Bioethicist).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0
- Project Steering Committee established

### 20. Ethics and Compliance Committee Chair, in consultation with the Project Steering Committee, appoints the remaining members of the Ethics and Compliance Committee (Legal Expert, Patient Advocate, HSA Representative, Data Protection Officer, Senior Researcher).

**Responsible Body/Role:** Ethics and Compliance Committee Chair

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved Ethics and Compliance Committee ToR v1.0
- Ethics and Compliance Committee Chair Appointed
- Project Steering Committee established

### 21. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Ethics and Compliance Committee Members Appointed

### 22. Hold the initial Ethics and Compliance Committee kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics and Compliance Committee Members Appointed
- Ethics and Compliance Committee ToR Approved
- Ethics and Compliance Committee Kick-off Meeting Scheduled

### 23. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 24. Project Manager circulates Draft Technical Advisory Group ToR v0.1 for review by the Chief Scientific Officer (CSO) and potential Leading Biogerontologist.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Circulation Email

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 25. Project Manager consolidates feedback on the Technical Advisory Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.2

**Dependencies:**

- Feedback from CSO and potential Leading Biogerontologist

### 26. Chief Scientific Officer (CSO) formally approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Chief Scientific Officer (CSO)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Draft Technical Advisory Group ToR v0.2

### 27. Chief Scientific Officer (CSO) formally appoints the Technical Advisory Group Chair (Leading Biogerontologist).

**Responsible Body/Role:** Chief Scientific Officer (CSO)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 28. Technical Advisory Group Chair, in consultation with the Chief Scientific Officer (CSO), appoints the remaining members of the Technical Advisory Group (Geneticist, Bioinformatics Expert, Regenerative Medicine Specialist, Technology Acquisition Specialist).

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0
- Technical Advisory Group Chair Appointed

### 29. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Technical Advisory Group Members Appointed

### 30. Hold the initial Technical Advisory Group kick-off meeting to review project goals, governance structure, and initial plans.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Technical Advisory Group Members Appointed
- Technical Advisory Group ToR Approved
- Technical Advisory Group Kick-off Meeting Scheduled