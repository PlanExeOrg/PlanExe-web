## Domain of the expert reviewer
Biomedical Research Infrastructure & Strategic Project Risk Management

## Domain-specific considerations

- Singapore biomedical regulatory landscape (HSA, Human Biomedical Products Act)
- Aging-reversal scientific uncertainty and biomarker validation
- Multi-stakeholder governance for $500M public-private initiatives
- Clinical trial insurance and participant protection frameworks
- Cross-border data governance (GDPR, Singapore PDPA)
- Global talent competition (Altos Labs, Calico, academic centers)
- GMP manufacturing pathway for novel therapeutic modalities
- Public legitimacy and societal acceptance of life-extension research

## Issue 1 - Missing Comprehensive Insurance and Liability Framework
The plan mentions cyber insurance (SGD 20M) but completely omits clinical trial insurance, professional indemnity for researchers, product liability for therapies, directors & officers insurance, and participant no-fault compensation schemes. For a $500M initiative conducting human trials on novel aging-reversal interventions, this is a critical gap. A single adverse safety event could generate liabilities exceeding SGD 200-500 million, potentially terminating the entire initiative and exposing Singapore to international legal action.

**Recommendation:** Engage specialized biomedical insurance brokers within the first 6 months to structure a comprehensive coverage program including: clinical trial insurance (minimum SGD 500M aggregate), professional indemnity for all researchers (SGD 100M per practitioner), D&O insurance (SGD 200M), product liability for any commercialized therapy (SGD 1B), and a participant compensation fund (SGD 50M). Establish a dedicated risk financing reserve of SGD 75-100M specifically for liability exposure, separate from the existing 15% contingency.

**Sensitivity:** Without adequate clinical trial insurance, a single serious adverse event could trigger liabilities of SGD 100-500 million, potentially exceeding the project's total contingency reserve of SGD 75 million by 133-667%. If the lab operates without participant compensation mechanisms, Singapore's HSA could deny trial authorization entirely, delaying the project by 12-24 months and costing SGD 50-100 million in lost research momentum. Insurance premium costs for this coverage profile would realistically range SGD 8-15 million annually (baseline: SGD 2M cyber only), representing a 300-650% increase in annual insurance expenditure.

## Issue 2 - Oversimplified Currency and Financial Risk Assumption
The currency strategy states SGD is the 'sole relevant currency' with 'no additional international risk management needed' because the project is confined to Singapore. This is dangerously flawed. The project will procure specialized equipment globally (USD/EUR/JPY), hire international talent requiring foreign-currency compensation, potentially receive funding in foreign currencies, and face construction cost inflation tied to global commodity markets. Additionally, the plan assumes private co-funding will materialize without addressing currency hedging for international investors concerned about SGD-denominated returns.

**Recommendation:** Implement a comprehensive foreign exchange risk management program including: (1) forward contracts for all known foreign-currency equipment purchases exceeding SGD 5M, (2) currency-hedged compensation packages for international hires, (3) multi-currency funding agreements with built-in hedging clauses, and (4) a currency risk reserve of SGD 25-40M (5-8% of budget). Engage a treasury specialist within 3 months of project initiation.

**Sensitivity:** A 10-15% adverse currency movement against SGD on international procurement (estimated SGD 150-250M in foreign-denominated equipment and talent costs over 10 years) could increase total project costs by SGD 15-38 million (3-7.6% budget overrun). If international investors demand currency hedging that the project hasn't planned for, funding commitments could be delayed or reduced by 15-25%, creating a funding gap of SGD 75-125 million. The assumed 'zero currency risk' baseline is incorrect; realistic currency exposure is SGD 30-50 million over the project lifetime.

## Issue 3 - Absent Governance Architecture and Decision Rights
The plan outlines 19 strategic decisions across multiple stakeholders (Singapore government, private investors, academic partners, commercial entities, international collaborators) but defines no explicit governance structure, decision rights, voting mechanisms, or conflict resolution protocols. With the Builder strategy requiring 'externally reviewed go/no-go gates' and 'adaptive governance,' the absence of a defined governance architecture creates a fundamental execution risk. Who has authority to reallocate budget between modalities? Who decides to terminate a research line? How are disputes between anchor investigators resolved? Without answers, the project faces decision paralysis.

**Recommendation:** Establish a formal governance charter within the first 6 months defining: (1) a Board of Governors with representation from government (40%), private investors (30%), and scientific leadership (30%), (2) clear decision-rights matrices specifying which decisions require board approval vs. scientific director authority, (3) an independent Scientific Advisory Board with binding veto power over go/no-go gate decisions, (4) dispute resolution mechanisms including binding arbitration, and (5) explicit succession protocols for key personnel.

**Sensitivity:** Governance deadlocks on critical decisions (e.g., terminating a failing modality, reallocating SGD 50-100M between research lines) could delay decisions by 6-12 months, costing SGD 30-60 million in delayed or abandoned research. Without clear decision rights, the risk of suboptimal resource allocation increases by 25-40%, potentially reducing overall research ROI by 10-20%. If governance failures trigger investor confidence crises, funding commitments could be withdrawn, creating a cascading financial impact of SGD 100-200 million.

## Review conclusion
Three critical missing assumptions jeopardize the $500M initiative: (1) the absence of a comprehensive insurance and liability framework creates existential financial risk from a single adverse event; (2) the oversimplified 'zero currency risk' assumption ignores SGD 30-50 million in realistic foreign exchange exposure; and (3) the absent governance architecture threatens decision-making capability across a multi-stakeholder initiative. These issues are interconnected—governance failures amplify financial risks, which compound insurance gaps. Immediate action is required: establish governance charter within 6 months, engage insurance brokers within 6 months, and implement currency risk management within 3 months. The Builder strategy's adaptive governance philosophy cannot function without the explicit governance structures, financial safeguards, and risk transfer mechanisms outlined above.