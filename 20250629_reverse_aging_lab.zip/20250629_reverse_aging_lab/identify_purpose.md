**Purpose:** business

**Purpose Detailed:** Large-scale infrastructure and scientific initiative to build a world-class research facility focused on cellular aging reversal, recruiting global multidisciplinary talent, and positioning Singapore as the global epicenter of longevity and anti-aging science through accelerated discovery, validation, and human trial implementation of safe aging therapies.

**Topic:** Establishment of a $500 million Reverse Aging Research Lab in Singapore