# Documents to Create

## Create Document 1: Project Charter

**ID**: 637d2dc3-c203-48d1-a01b-9072e0ffe717

**Description**: The foundational project management document that formally establishes the Reverse Aging Research Lab initiative in Singapore. It defines the project's purpose, scope, objectives, stakeholders, authority structure, and high-level boundaries. This charter anchors all subsequent planning documents and provides the mandate for the $500 million, 10-year initiative to establish Singapore as the global epicenter of longevity science. It references the Builder strategy as the chosen strategic approach and identifies the five Critical levers and eight High levers as the strategic decision framework governing the project.

**Responsible Role Type**: Project Director

**Primary Template**: PMI Project Charter Template

**Secondary Template**: Singapore Public Sector Project Charter Framework

**Steps to Create**:

- Define project purpose, goals, and measurable objectives aligned with the SMART criteria
- Identify and document all primary and secondary stakeholders with their roles and expectations
- Establish high-level scope boundaries including the 10-year horizon, $500M budget cap, and Singapore location requirement
- Define the project's authority structure referencing the future Board of Governors and Scientific Advisory Board
- Identify key dependencies including governance charter, facility lease, HSA engagement, and funding architecture
- Document major risks at a high level and the overall mitigation approach
- Obtain formal sign-off from the sponsoring authority (Singapore NRF/A*STAR) to formally charter the project

**Approval Authorities**: Singapore National Research Foundation (NRF) or Agency for Science, Technology and Research (A*STAR) as the primary government sponsor; Project Director with legal counsel

**Essential Information**:

- Define all 19 strategic levers (5 Critical, 14 High) with explicit Lever IDs, core decision statements, and justification for criticality ranking
- For each lever, detail: the Core Decision, Why It Matters, 3 Strategic Choices, Trade-Off/Risk analysis, and Strategic Connections (Synergy and Conflict mappings)
- Articulate how the five Critical levers collectively address the three foundational tensions: Speed vs Scientific Rigor, Capital Commitment vs Flexibility, and Talent Coherence vs Star Power
- Map how the eight High levers layer onto secondary trade-offs: Open Science vs Commercial Value (IP), Bold Positioning vs Credibility (positioning, ethics), and Screening Throughput vs Capital Intensity (technology platform)
- Explicitly document the interplay between Critical levers—particularly how Phased research portfolio allocation constrains Facility build versus lease and Funding architecture decisions—to enable active governance and avoid suboptimization
- Identify all cross-lever synergies and conflicts to ensure strategic coherence across the decision framework
- Provide sufficient strategic choice detail to enable decision-makers to select specific approaches aligned with The Builder scenario path

**Risks of Poor Quality**:

- Incomplete mapping of inter-lever conflicts leads to strategic decisions in one domain undermining another (e.g., facility build commitments conflicting with portfolio allocation flexibility), causing capital waste and operational paralysis
- Missing the interplay between Critical levers results in suboptimization where portfolio allocation decisions constrain facility and funding without governance mechanisms to resolve tensions
- Vague or missing justification for Critical vs High lever rankings prevents stakeholders from prioritizing governance attention and resource allocation effectively
- Absence of concrete strategic choices per lever leaves decision-makers without actionable options, forcing ad-hoc decisions that may contradict the overall Builder strategy
- Failure to document Synergy and Conflict connections between levers creates blind spots where collaborative benefits are missed or contradictory decisions are made in isolation

**Worst Case Scenario**: The $500 million initiative suffers from strategic incoherence where decisions across the 19 levers are made in isolation or conflict with one another—such as a purpose-built facility locking in capital that contradicts phased portfolio allocation, or aggressive positioning conflicting with conservative ethics—leading to cascading resource misallocation, loss of scientific credibility, failure to establish Singapore as the global epicenter, and potential termination of the initiative due to accumulated strategic contradictions.

**Best Case Scenario**: The document provides a comprehensive, actionable strategic decision framework that enables active governance across all 19 levers, explicitly preventing suboptimization through documented inter-lever dependencies. It empowers decision-makers to select Builder-aligned strategic choices, resolves foundational tensions (Speed vs Rigor, Capital vs Flexibility, Talent Coherence vs Star Power) through informed trade-offs, and establishes the strategic coherence necessary to position Singapore as the global epicenter of longevity science while maintaining fiscal discipline and scientific integrity over the 10-year horizon.

**Fallback Alternative Approaches**:

- Create a 'Critical Levers Only' minimum viable document covering the five Critical levers with full detail (core decision, choices, trade-offs, connections), deferring the 14 High levers to a subsequent phase once foundational governance is established
- Develop a strategic decision matrix format that maps all 19 levers across dimensions (tension addressed, criticality, key trade-off, primary conflict) to provide quick-reference guidance without exhaustive narrative for each lever
- Conduct a facilitated workshop with key stakeholders (Singapore government, scientific leadership, private investors) to co-define and validate the strategic levers and their interdependencies, ensuring buy-in and reducing documentation burden through collaborative synthesis
- Engage a strategic consulting firm or technical writer specializing in complex initiative planning to structure the document, ensuring all 19 levers meet consistent quality standards and inter-lever connections are rigorously mapped

## Create Document 2: Strategic Framework: The Builder Strategy

**ID**: 3d345251-68e5-4895-a91e-081997ba876b

**Description**: The overarching strategic document that codifies the chosen strategic path (The Builder) for the Reverse Aging Research Lab. It articulates the strategic logic of adaptive governance, staged commitment, and balanced parallel research tracks. This document defines how the project will navigate the fundamental tensions of Speed vs. Scientific Rigor, Capital Commitment vs. Flexibility, and Talent Coherence vs. Star Power through externally reviewed go/no-go gates, blended funding, phased facility approaches, and hybrid talent models. It serves as the strategic umbrella under which all intervention-area frameworks operate.

**Responsible Role Type**: Strategic Planning Director

**Primary Template**: Strategic Framework Template (McKinsey/BCG-style)

**Secondary Template**: Singapore Public Policy Strategic Planning Framework

**Steps to Create**:

- Synthesize the analysis from strategic_decisions.md and scenarios.md into a coherent strategic narrative
- Define the Builder strategy's core principles: adaptive governance, staged commitment, blended funding, phased facility approach, hybrid talent model
- Articulate the strategic logic connecting all five Critical levers and eight High levers into an integrated framework
- Define the decision-rights philosophy that underpins the go/no-go gate structure
- Establish the strategic rationale for why The Builder was chosen over The Pioneer and The Consolidator
- Define success metrics and strategic fit indicators (target: 8/10 fit score)
- Validate the strategic framework against the project's ambition, risk, complexity, and domain profile

**Approval Authorities**: Board of Governors (once constituted); Strategic Planning Director with Scientific Director

**Essential Information**:

- Synthesize the analysis from strategic_decisions.md (19 strategic levers) and scenarios.md (Builder vs. Pioneer vs. Consolidator assessment) into a coherent strategic narrative that codifies The Builder as the optimal path
- Define the Builder strategy's five core principles: adaptive governance via externally reviewed go/no-go gates, staged commitment of the SGD 500 million, blended funding architecture (core public commitment + private partnership), phased facility approach (lease and retrofit in phases), and hybrid talent model (anchor investigators + rotating project teams)
- Articulate the strategic logic connecting all five Critical levers (Discovery-to-validation sequencing, Facility build vs. lease, Talent recruitment, Funding architecture, Phased research portfolio allocation) and the secondary High levers into an integrated framework showing how they reinforce or conflict with one another
- Define the decision-rights philosophy that underpins the go/no-go gate structure, specifying who holds authority to reallocate budget between modalities (thresholds exceeding SGD 25 million), terminate research lines, and resolve disputes between anchor investigators
- Establish the strategic rationale for why The Builder was chosen over The Pioneer (fit 6/10) and The Consolidator (fit 5/10), specifically addressing why Pioneer's full capital commitment and parallel human trials from year two are unsuitable, and why Consolidator's five-year delay of human trials undermines the 'global epicenter' ambition
- Define success metrics and strategic fit indicators (target: 8/10 fit score) including measurable criteria for adaptive governance effectiveness, milestone velocity, and stakeholder alignment
- Validate the strategic framework against the project's core profile: mega-scale geopolitical ambition (SGD 500 million, 10-year horizon), extreme scientific uncertainty (cellular aging reversal), multi-stakeholder complexity (government, private investors, academic partners), and Singapore's progressive biomedical regulatory context
- Explicitly map how the framework resolves the three foundational tensions: Speed vs. Scientific Rigor (through go/no-go gates and biomarker benchmarks), Capital Commitment vs. Flexibility (through phased facility approach and blended funding), and Talent Coherence vs. Star Power (through hybrid talent model)

**Risks of Poor Quality**:

- If the framework fails to clearly define the adaptive governance philosophy, the project reverts to ad-hoc decision-making with no consistent criteria for go/no-go gates, leading to arbitrary resource allocation and scientific drift
- If the strategic rationale for choosing Builder over Pioneer/Consolidator is not explicitly articulated, stakeholders may default to more aggressive (Pioneer) or conservative (Consolidator) approaches that contradict the project's risk profile and 'global epicenter' positioning
- If the interdependencies between the 19 levers are not properly mapped, suboptimization occurs—for example, portfolio allocation constraining facility decisions, or funding architecture conflicting with positioning and claim management
- If the decision-rights philosophy is vague or absent, governance deadlocks occur on critical decisions like terminating a failing modality (SGD 150-250 million at risk) or reallocating SGD 50-100 million between research lines, causing 6-12 month delays
- If success metrics and the 8/10 strategic fit score are not defined with measurable criteria, the project cannot track whether it is achieving strategic coherence or drifting toward contradictory approaches
- If the framework does not explicitly address the three foundational tensions (Speed vs. Scientific Rigor, Capital Commitment vs. Flexibility, Talent Coherence vs. Star Power), downstream decisions across all 19 levers will be contradictory and mutually undermining

**Worst Case Scenario**: The project adopts a contradictory hybrid strategy that unconsciously blends Builder, Pioneer, and Consolidator elements without clear governance protocols, leading to decision paralysis, SGD 100-200 million in wasted resources from inconsistent capital deployment, loss of Singapore's 'global epicenter' positioning to competitors like Altos Labs and Calico, and potential termination of the initiative due to governance failure and complete stakeholder confidence collapse.

**Best Case Scenario**: Creates a unified strategic umbrella that enables all 19 downstream decisions, aligns diverse stakeholders (Singapore government, private investors, scientific leadership, international partners) around a coherent adaptive governance model, provides clear criteria for go/no-go gates that balance scientific rigor with speed, and ensures the SGD 500 million is deployed with both flexibility and discipline, achieving the 8/10 strategic fit score and establishing Singapore as the definitive global epicenter of longevity science.

**Fallback Alternative Approaches**:

- Develop separate strategy documents for each of the five Critical levers rather than a single integrated framework, then attempt to align them through a separate integration memorandum, accepting the risk of inconsistency between levers
- Use a pre-approved McKinsey/BCG-style strategic framework template and adapt it to the project context without fully synthesizing the specific nuances from strategic_decisions.md and scenarios.md, risking misalignment with the project's unique tensions
- Create a simplified 'minimum viable strategy' covering only the five Critical levers initially, deferring the 14 High levers to subsequent planning cycles, which may leave critical trade-offs (IP architecture, ethical posture, positioning) unaddressed during early execution
- Engage external strategy consultants (e.g., McKinsey, BCG, or Singapore-based strategic advisors) to draft the framework rather than relying on internal synthesis of the existing documents, increasing cost but potentially bringing proven methodology
- Adopt The Pioneer or Consolidator strategy wholesale if the complexity of synthesizing the Builder strategy proves too resource-intensive, accepting the associated risks of premature clinical activity or excessive caution respectively

## Create Document 3: Governance Charter

**ID**: c46eb712-8feb-44a3-b2c3-840eff741078

**Description**: The formal governance document defining the Board of Governors (40% government, 30% private investors, 30% scientific leadership), the decision-rights matrix with SGD 25 million budget reallocation thresholds, and the independent Scientific Advisory Board (SAB) with binding veto power over go/no-go gate decisions. This document establishes voting mechanisms, conflict resolution protocols, escalation pathways, and succession protocols for key personnel. It resolves the governance paradox identified in the expert review by providing the structural foundation for all decision-making authority.

**Responsible Role Type**: Chief Risk & Governance Officer

**Primary Template**: Corporate Governance Charter Template

**Secondary Template**: Singapore Public-Private Partnership Governance Framework

**Steps to Create**:

- Define the Board of Governors composition, voting rights, and meeting cadence (monthly during startup, transitioning to quarterly)
- Establish the decision-rights matrix specifying dollar thresholds for Board approval vs. scientific director authority
- Define the Scientific Advisory Board structure, member selection criteria, and binding veto power over go/no-go gates
- Create conflict resolution mechanisms including binding arbitration protocols
- Establish succession protocols for key personnel including anchor investigators
- Define the interim governance authority structure for the pre-charter period
- Draft dispute resolution mechanisms for disagreements between government, private investor, and scientific leadership representatives
- Obtain legal review and formal ratification by all governing bodies

**Approval Authorities**: Board of Governors (ratification); Singapore Ministry of Law (governance framework compliance); all three stakeholder groups (government, private investors, scientific leadership)

**Essential Information**:

- Define the Board of Governors composition with exact stakeholder split (40% government, 30% private investors, 30% scientific leadership) and specify voting rights, meeting cadence (monthly during startup transitioning to quarterly), and quorum requirements
- Establish a decision-rights matrix with explicit dollar thresholds (e.g., SGD 25 million budget reallocation requires Board approval vs. scientific director authority) covering modality switches, facility investments, and personnel decisions
- Define the Scientific Advisory Board (SAB) structure including member selection criteria, independence safeguards, and binding veto power over go/no-go gate decisions with pre-defined biomarker benchmarks
- Create conflict resolution mechanisms including binding arbitration protocols for disputes between government, private investor, and scientific leadership representatives
- Establish succession protocols for key personnel including anchor investigators, specifying interim authority and knowledge transfer requirements
- Define the interim governance authority structure for the pre-charter period (2026-Q3 to charter ratification) to prevent decision paralysis during startup
- Draft dispute resolution mechanisms and escalation pathways for budget reallocation exceeding SGD 25 million, modality termination, and strategic pivots
- Obtain legal review and formal ratification by all governing bodies ensuring compliance with Singapore Ministry of Law and Public-Private Partnership frameworks

**Risks of Poor Quality**:

- Governance deadlocks on critical decisions (e.g., terminating a failing modality or reallocating SGD 50-100M between research lines) could delay decisions by 6-12 months, costing SGD 30-60 million in delayed or abandoned research
- Without clear decision rights, the risk of suboptimal resource allocation increases by 25-40%, potentially reducing overall research ROI by 10-20% and undermining the Builder strategy's adaptive governance philosophy
- If governance failures trigger investor confidence crises, funding commitments could be withdrawn, creating a cascading financial impact of SGD 100-200 million and potentially terminating the $500M initiative
- Absence of binding veto power for the Scientific Advisory Board over go/no-go gates could allow premature clinical progression or continuation of failing hypotheses, exposing SGD 150-250 million to scientific uncertainty
- Lack of defined succession protocols for anchor investigators could create leadership vacuums, destabilizing research lines and requiring SGD 15-30 million in replacement costs per lost investigator

**Worst Case Scenario**: Complete governance paralysis where conflicting stakeholder interests prevent any budget reallocation or strategic decision, causing the $500 million initiative to stall indefinitely, Singapore's credibility as a global science hub to be severely damaged, and the opportunity cost of lost leadership in aging-reversal research to compound as competitors (Altos Labs, Calico) consolidate first-mover advantage.

**Best Case Scenario**: The Governance Charter enables the Builder strategy's adaptive governance philosophy to function optimally, allowing dynamic resource reallocation between modalities based on evidence, rapid termination of failing hypotheses via SAB veto power, and balanced stakeholder representation that maintains investor confidence and scientific integrity, ensuring the $500M initiative can navigate extreme scientific uncertainty while preserving forward momentum toward establishing Singapore as the global longevity epicenter.

**Fallback Alternative Approaches**:

- Develop a simplified interim Governance Memorandum of Understanding (MOU) covering only critical decision rights (budget thresholds and go/no-go veto) within 3 months, with full charter ratification deferred to month 6-9
- Adopt a default consensus-based decision-making framework with pre-agreed tie-breaker mechanisms (e.g., independent mediator appointed by Singapore Ministry of Law) if full charter ratification is delayed
- Engage an external governance consultant specializing in public-private research partnerships to facilitate rapid charter development using a standardized template adapted to Singapore's regulatory context
- Implement a phased governance approach starting with a minimal viable charter (Board composition and budget thresholds only) and expanding to include SAB veto power and dispute resolution in subsequent phases

## Create Document 4: Risk Management Framework

**ID**: 14058979-2cf4-4705-bccf-df6364f93888

**Description**: The comprehensive risk management document establishing the risk register, risk assessment methodology, mitigation strategies, and governance mechanisms for the $500 million initiative. It covers all 16 identified risks including scientific uncertainty (SGD 150-250M at risk), financial sustainability (15-25% construction overruns), public perception (SGD 100-200M threatened funding), regulatory uncertainty (6-18 month delays), and the critical gaps identified in the expert review (insurance, currency, governance). It defines risk ownership, monitoring cadence, and escalation protocols.

**Responsible Role Type**: Chief Risk & Governance Officer

**Primary Template**: PMI Risk Management Framework

**Secondary Template**: Singapore Government Risk Management Framework

**Steps to Create**:

- Compile the comprehensive risk register from the pre-project assessment, including all 16 identified risks with impact/likelihood assessments
- Define risk assessment methodology including quantitative financial impact modeling and qualitative severity ratings
- Establish mitigation strategies for each risk category, including the 15% contingency reserve, go/no-go gates, and diversified portfolio
- Address the critical gaps identified in expert review: insurance and liability framework, currency risk management, and governance architecture
- Define risk monitoring cadence (quarterly reviews) and escalation protocols for high-severity risks
- Establish the dedicated risk financing reserve of SGD 75-100 million separate from the 15% contingency
- Create risk ownership assignments for each identified risk to specific C-suite roles
- Integrate risk management with the go/no-go gate structure and milestone-linked funding

**Approval Authorities**: Board of Governors; Chief Risk & Governance Officer with Finance Director

**Essential Information**:

- Compile a comprehensive risk register covering all 16 identified risks with quantitative impact/likelihood assessments, including scientific uncertainty (SGD 150-250M at risk), financial sustainability (15-25% construction overruns), public perception (SGD 100-200M threatened funding), regulatory uncertainty (6-18 month delays), and operational risks
- Define risk assessment methodology combining quantitative financial impact modeling (Monte Carlo simulations for budget variance) and qualitative severity ratings (High/Medium/Low with explicit criteria)
- Establish mitigation strategies for each risk category: externally reviewed go/no-go gates with pre-defined biomarker benchmarks, 15% financial contingency reserve (SGD 75M), diversified modality portfolio (no single modality >40% of discovery funding), and phased facility approach
- Address critical gaps identified in expert review: comprehensive insurance and liability framework (clinical trial insurance SGD 500M aggregate, participant no-fault compensation SGD 50M, professional indemnity, D&O, product liability), currency risk management (SGD 25-40M reserve, hedging for SGD 150-250M foreign-denominated costs), and formal governance architecture (Board of Governors with 40/30/30 split, Scientific Advisory Board with binding veto power, decision-rights matrix)
- Assign risk ownership to specific C-suite roles (Chief Risk & Governance Officer, CFO, Scientific Director, CTO) with clear accountability for monitoring and escalation
- Define risk monitoring cadence (quarterly reviews with independent audit oversight) and escalation protocols for high-severity risks triggering Board of Governors intervention
- Establish dedicated risk financing reserve of SGD 75-100M separate from the 15% contingency, specifically for liability exposure and catastrophic risk events
- Integrate risk management triggers with go/no-go gate structure and milestone-linked funding disbursements to ensure automatic budget reallocation or termination when risk thresholds are breached
- Create technology platform risk protocols including modular automation strategy to prevent SGD 50-100M stranded investment from platform obsolescence
- Develop supply chain risk mitigation including 3-6 month strategic reserves, multi-vendor diversification, and in-house capability development for critical reagents

**Risks of Poor Quality**:

- Inadequate insurance coverage leaves the project exposed to existential liabilities of SGD 100-500M from a single adverse clinical event, potentially terminating the initiative and exposing Singapore to international legal action
- Unmanaged currency risk (SGD 30-50M realistic exposure) could create 10-15% budget overruns on international procurement, triggering funding gaps of SGD 75-125M if international investors demand unplanned hedging
- Absent governance architecture leads to decision paralysis on critical choices (terminating failing modalities, reallocating SGD 50-100M between research lines), causing 6-12 month delays costing SGD 30-60M and potentially triggering investor confidence crises
- Failure to address scientific uncertainty through rigorous go/no-go gates risks SGD 150-250M in sunk costs if primary hypotheses prove invalid, with 2-4 year delays from failed biomarker validation
- Inadequate public engagement and societal legitimacy planning exposes the SGD 500M investment to political backlash, threatening SGD 100-200M in future funding and potentially triggering regulatory restrictions
- Lack of comprehensive risk monitoring allows cascading failures (scientific setbacks amplifying financial risks intensifying public scrutiny) to go undetected until they become unmanageable
- Poorly defined risk ownership creates accountability gaps where critical risks fall between organizational silos, delaying response actions by months

**Worst Case Scenario**: Multiple critical risks materialize simultaneously—scientific hypothesis failure consumes SGD 150-250M, a serious adverse clinical event generates uninsured liabilities of SGD 100-500M, governance deadlock prevents strategic pivots, and public backlash triggers withdrawal of SGD 100-200M in future funding—resulting in complete project failure, total loss of the SGD 500M investment, severe reputational damage to Singapore's biomedical sector, and potential legal liability exceeding the project's total value.

**Best Case Scenario**: The comprehensive Risk Management Framework enables proactive identification and mitigation of all 16 risks, allowing the $500M initiative to successfully navigate extreme scientific uncertainty through adaptive go/no-go gates, maintain fiscal discipline via 15% contingency and diversified funding, attract global talent through robust insurance and governance structures, and establish Singapore as the global epicenter of longevity science while preserving public trust and scientific credibility throughout the 10-year horizon.

**Fallback Alternative Approaches**:

- Develop a 'minimum viable risk framework' focusing exclusively on the top 5 critical risks (scientific uncertainty, financial sustainability, insurance gaps, governance absence, currency exposure) within 3 months, deferring lower-priority risks to subsequent phases
- Engage external specialized risk management consultants (PMI-certified) to draft the framework using established templates, reducing development time from months to weeks while ensuring methodological rigor
- Create the document in two phases: Phase 1 addresses immediate existential risks (insurance, governance charter, currency hedging) within 6 months; Phase 2 expands to the full 16-risk register and monitoring systems over the following 6 months
- Leverage the existing assumptions.md and project-plan.md risk sections as the foundational content, enhancing them with quantitative modeling and governance mechanisms rather than creating the document from scratch
- Establish interim governance and insurance coverage immediately using the project-plan.md dependencies as action items, while the comprehensive Risk Management Framework document is being finalized by the Chief Risk & Governance Officer

## Create Document 5: Monitoring, Evaluation, and Go/No-Go Gate Framework

**ID**: a1dc20fe-c5cf-4c43-8014-75e6ec0c072a

**Description**: The strategic document establishing the monitoring and evaluation architecture for the initiative, centered on the externally reviewed go/no-go gates that serve as the evidentiary gatekeeper between laboratory promise and clinical reality. It defines the tiered biomarker confidence framework from molecular signatures to functional and lifespan correlates, the surrogate endpoint acceptance criteria, and the specific assay benchmarks that determine pipeline progression. It establishes the 'negative results' analysis team, the biomarker qualification investment (SGD 15-20 million), and the independent Scientific Advisory Board's binding veto power over gate decisions.

**Responsible Role Type**: Scientific Director

**Primary Template**: M&E Framework Template (Logical Framework Approach)

**Secondary Template**: Singapore Biomedical Research M&E Framework

**Steps to Create**:

- Define the go/no-go gate structure with specific assay benchmarks tied to each pipeline phase transition
- Establish the tiered biomarker confidence framework from epigenetic clocks to functional tissue assays to animal model longevity data
- Define surrogate endpoint acceptance criteria determining which biomarkers are admissible as clinical benefit proxies
- Establish the 'negative results' analysis team mandate and rapid termination protocols for failing hypotheses
- Define the biomarker qualification investment plan (SGD 15-20 million) and stress-testing methodology
- Establish the Scientific Advisory Board's evidence review process and binding veto power over gate decisions
- Create the pipeline velocity metrics and stakeholder communication cadence for gate outcomes
- Define the portfolio allocation reallocation mechanism triggered by gate decisions

**Approval Authorities**: Scientific Director; Scientific Advisory Board (binding veto); Board of Governors

**Essential Information**:

- Define the go/no-go gate structure with specific assay benchmarks tied to each pipeline phase transition (discovery→validation→human trials)
- Establish the tiered biomarker confidence framework from epigenetic clocks to functional tissue assays to animal model longevity data, defining evidentiary thresholds for each tier
- Define surrogate endpoint acceptance criteria determining which biomarkers are admissible as clinical benefit proxies and under what conditions
- Establish the 'negative results' analysis team mandate, composition, and rapid termination protocols for failing hypotheses
- Define the biomarker qualification investment plan (SGD 15-20 million) and stress-testing methodology against historical datasets and negative controls
- Establish the Scientific Advisory Board's evidence review process, meeting cadence, and binding veto power over gate decisions
- Create pipeline velocity metrics and stakeholder communication cadence for gate outcomes, including public reporting protocols
- Define the portfolio allocation reallocation mechanism triggered by gate decisions, specifying budget movement thresholds between preclinical and clinical work
- Integrate gate criteria with the $500 million funding architecture to ensure milestone-linked disbursements align with evidentiary standards
- Specify the interaction between gate decisions and facility readiness timelines, ensuring clinical infrastructure activation is evidence-gated rather than schedule-driven

**Risks of Poor Quality**:

- Unclear or overly loose gating criteria could lead to premature human trials on an unproven mechanistic basis, eroding regulatory and public trust
- Inadequate biomarker validation standards risk producing therapies that fail on hard clinical endpoints after years of investment, wasting SGD 150-250 million
- Lack of explicit rapid termination protocols enables sunk-cost drift, where failing hypotheses continue receiving funding due to political or institutional inertia
- Weak governance without binding veto power allows gate decisions to be influenced by non-scientific factors, undermining the Builder strategy's adaptive governance philosophy
- Poorly defined surrogate endpoint acceptance criteria produce ambiguous evidence that is scientifically indefensible and regulatorily non-compliant
- Absence of portfolio reallocation mechanisms means gate decisions fail to redirect resources, causing suboptimization between discovery, validation, and clinical phases
- Inadequate stakeholder communication protocols for gate outcomes create uncertainty among investors, talent, and partners, threatening funding continuity and recruitment
- Misalignment between gate criteria and facility readiness timelines leaves clinical infrastructure idle or prematurely activated without sufficient evidentiary justification

**Worst Case Scenario**: The lab commits to human trials on an unproven mechanistic basis due to weak or absent gate criteria, producing negative results that destroy Singapore's credibility as a global longevity epicenter, trigger regulatory intervention, and terminate the $500 million initiative with SGD 150-250 million in unrecoverable investment losses and lasting reputational damage to Singapore's biomedical research standing.

**Best Case Scenario**: The framework enables rigorous, evidence-based go/no-go decisions that protect the $500 million investment while maintaining scientific integrity, allowing the Builder strategy's adaptive governance to function effectively—terminating failing hypotheses rapidly, reallocating resources to promising therapeutic candidates, and establishing Singapore's credibility as a scientifically disciplined global epicenter through transparent, externally validated evaluation standards that attract top talent and sustained funding.

**Fallback Alternative Approaches**:

- Utilize the existing strategic decisions document (strategic_decisions.md) as a baseline template and expand it into a full M&E framework by adding specific assay benchmarks, quantitative thresholds, and termination protocols to the existing go/no-go gate descriptions
- Schedule a focused workshop with the Scientific Director, Scientific Advisory Board members, and Board of Governors to collaboratively define gate criteria and veto mechanisms in a single intensive session, then document outcomes
- Engage a technical writer or subject matter expert in M&E frameworks to structure the document using the Logical Framework Approach template referenced in document.json, adapting it to the aging-reversal context
- Develop a simplified 'minimum viable document' covering only the critical gate criteria, binding veto authority, and rapid termination protocols initially, with detailed biomarker qualification frameworks and communication cadences added in subsequent phases
- Leverage the Risk Summary and Mitigation Plans from project-plan.md as the foundational structure, mapping each risk to specific gate triggers and monitoring metrics rather than starting from scratch


# Documents to Find

## Find Document 1: Singapore Human Biomedical Products Act (HBPA) Full Legislation Text

**ID**: 2023925d-2d4b-48a4-a3f9-716a4bbdd03a

**Description**: The complete text of Singapore's Human Biomedical Products Act, which is the primary regulatory framework governing human biological products including cellular therapy products. This legislation is the foundational legal source needed to analyze how aging-reversal interventions might be classified, what regulatory pathways exist, and what evidentiary standards apply. It is the critical raw input for the Regulatory and Ethics Strategy Framework and the HSA pre-submission consultation strategy.

**Recency Requirement**: Current as of 2026, with all amendments through the most recent legislative session

**Responsible Role Type**: Chief Regulatory & Ethics Officer

**Steps to Find**:

- Access Singapore's Statutes Online portal (sso.agc.gov.sg) to retrieve the full HBPA text
- Download all associated regulations and subsidiary legislation under the HBPA
- Review HSA's guidelines on registration of cellular therapy products referenced in the HBPA
- Obtain any recent amendments or proposed amendments to the HBPA related to novel therapeutic products
- Cross-reference with the WHO's 'Regulatory Considerations on Human Cells and Tissues Products' for international context

**Access Difficulty**: Easy

**Essential Information**:

- Specific classification of aging-reversal interventions under the HBPA (e.g., 'cellular therapy products,' 'experimental biological products,' or 'novel therapeutic approaches') and the precise regulatory pathway this classification triggers
- Detailed evidentiary standards and preclinical data requirements (including biomarker validation thresholds and animal model data) necessary for HSA clinical trial authorization under the HBPA
- Institutional Review Board (IRB) approval processes, ethical oversight requirements, and informed consent protocols mandated by Singapore law for human subjects research involving novel biomedical interventions
- Definitions of key statutory terms including 'human biomedical product,' 'cellular therapy,' and 'experimental product' as they apply to aging-reversal technologies
- Any existing HBPA guidelines, circulars, or precedents for novel/emerging biomedical technologies, including previous HSA decisions on similar cellular or gene therapy products
- Provisions for adaptive, accelerated, or conditional approval pathways that might apply to high-uncertainty interventions with breakthrough potential
- Manufacturing quality requirements (GMP standards) and facility licensing conditions imposed under the HBPA for clinical-grade production
- Cross-border data governance and international collaboration provisions relevant to multi-jurisdictional clinical trials and federated data architectures

**Risks of Poor Quality**:

- Misclassification of aging-reversal interventions leading to application of incorrect regulatory standards, resulting in 6–18 month delays in ethical approvals and clinical trial licenses
- Inability to identify viable regulatory pathway causing SGD 5–15 million in additional compliance costs and forced reclassification that undermines the core 'aging reversal' mission
- Failed HSA pre-submission consultation derailing the project timeline and requiring strategic pivots that consume SGD 30–60 million in delayed research momentum
- Non-compliance with Singapore's Human Biomedical Products Act exposing the initiative to legal challenges, trial holds, or revocation of research authorization
- Inadequate understanding of evidentiary standards leading to clinical trial applications that are rejected outright, wasting SGD 20–50 million in preparatory costs

**Worst Case Scenario**: The HBPA analysis fails to identify any viable regulatory pathway for cellular aging-reversal interventions under Singapore law, forcing the project to either operate in a legal gray area, seek approval in a competing jurisdiction (losing the Singapore 'global epicenter' advantage), or terminate entirely—resulting in the total loss of the $500 million investment, international legal exposure, and permanent damage to Singapore's reputation as a biomedical innovation hub.

**Best Case Scenario**: The HBPA analysis reveals a clear or adaptable regulatory pathway (such as classification under regenerative medicine or a novel therapeutic framework) that leverages Singapore's progressive legislative framework, enabling efficient clinical trial authorization, establishing Singapore as the global regulatory first-mover for aging-reversal interventions, and accelerating the timeline to first human trials by year 3–4 while attracting international talent and partnerships.

**Fallback Alternative Approaches**:

- Engage specialized Singapore-based biomedical regulatory consultants with direct HSA relationships to obtain informal pre-submission guidance on classification without requiring the full legislation text
- Request formal pre-submission consultation with HSA using existing published HSA guidelines and WHO's 'Regulatory Considerations on Human Cells and Tissues Products' as interim references while the full HBPA text is being analyzed
- Partner with Singapore-based law firms specializing in the Human Biomedical Products Act to conduct targeted regulatory research and gap analysis
- Utilize international regulatory harmonization frameworks and published HSA decision summaries from approved cellular therapy products to infer applicable standards and evidentiary thresholds
- Establish a dedicated regulatory affairs team to conduct parallel analysis of HBPA provisions alongside international regulatory comparisons, creating a comprehensive regulatory mapping document that bridges gaps in legislation access

## Find Document 2: Singapore Health Sciences Authority (HSA) Clinical Trial Authorization Guidelines

**ID**: 9cd8f138-9260-47cf-80e8-6cdaf5d0308c

**Description**: The official HSA guidelines and regulatory frameworks governing clinical trial authorization in Singapore, including requirements for novel biological products, cellular therapy products, and regenerative medicine interventions. These guidelines are the raw regulatory source material needed to understand the pre-submission consultation process, evidentiary requirements for trial authorization, and the classification criteria that will determine how aging-reversal interventions are regulated.

**Recency Requirement**: Current as of 2026, reflecting the most recent HSA guidance updates

**Responsible Role Type**: Chief Regulatory & Ethics Officer

**Steps to Find**:

- Access the HSA website (hsa.gov.sg) and navigate to the Clinical Trials and Research Involving Human Subjects section
- Download the HSA's 'Guidelines on Clinical Trial Authorization' and any related guidance documents
- Retrieve HSA's 'Guidelines on Registration of Cellular Therapy Products'
- Obtain any HSA advisory correspondence or guidance notes on novel therapeutic product classifications
- Review HSA's pre-submission consultation process documentation and requirements

**Access Difficulty**: Medium

**Essential Information**:

- Classification criteria and framework for aging-reversal interventions under Singapore's Human Biomedical Products Act (HBPA) — specifically whether cellular reversal therapies fall under 'cellular therapy products,' 'regenerative medicine,' or a novel category requiring new classification
- Pre-submission consultation process requirements, timelines, and procedural steps for novel biological products with no established regulatory precedent
- Evidentiary thresholds and data requirements for Clinical Trial Authorization (CTA) of novel aging-reversal interventions, including preclinical package expectations, biomarker validation standards, and safety data requirements
- Specific regulatory requirements for transitioning from preclinical animal-model data to human trial authorization, including any Singapore-specific gates or additional documentation beyond standard GCP/ICH guidelines
- Existing HSA precedents, guidance notes, or advisory correspondence on how similar novel therapeutic modalities (e.g., gene therapies, cell-based interventions) have been classified and authorized
- Requirements for Institutional Review Board (IRB) approval as it intersects with HSA CTA, including any dual-review or harmonized processes
- Timeline expectations and typical duration for HSA review of novel biological product applications, including any expedited or adaptive pathways available for breakthrough interventions
- Post-authorization regulatory obligations, including pharmacovigilance requirements, long-term follow-up mandates, and reporting standards specific to novel aging-reversal therapies

**Risks of Poor Quality**:

- Misclassification of aging-reversal interventions under the wrong HBPA category could trigger 6–18 month delays in ethical approvals and clinical trial licenses, costing SGD 5–15 million in additional compliance and lost research momentum
- Incomplete understanding of evidentiary requirements could result in rejected or returned CTA applications, forcing costly re-submission cycles and potentially derailing the year 3–4 first-human-trial timeline
- Failure to identify pre-submission consultation requirements could leave the project without critical regulatory feedback, leading to fundamental misalignment between the lab's scientific approach and HSA expectations
- Absence of clarity on Singapore-specific GCP and post-authorization obligations could expose the initiative to regulatory non-compliance, potential clinical holds, and reputational damage with the HSA
- Without established HSA precedents for aging-reversal classification, the project risks being forced into an inappropriate regulatory pathway that constrains trial design, endpoint selection, and biomarker validation strategy

**Worst Case Scenario**: The HSA determines that aging-reversal interventions do not fit any existing regulatory category and refuses to authorize human trials entirely, or requires a completely novel regulatory framework to be developed before any clinical work can proceed — effectively terminating the project's clinical timeline, undermining the $500 million investment's core mission, and destroying Singapore's positioning as the global epicenter of longevity science.

**Best Case Scenario**: The HSA provides clear guidance that aging-reversal interventions can be classified under Singapore's progressive biomedical framework (potentially as a novel subcategory of regenerative medicine or cellular therapy), establishes a defined pre-submission consultation pathway, and outlines evidentiary requirements that the lab can meet within its 10-year timeline — enabling timely trial authorization, positioning Singapore as the global regulatory leader in aging-reversal science, and accelerating the project's path from discovery to human trials.

**Fallback Alternative Approaches**:

- Engage specialized Singapore biomedical regulatory consultants (e.g., firms with prior HSA pre-submission experience) to provide expert interpretation of how aging-reversal interventions would likely be classified, even without a published document covering this exact modality
- Submit a formal pre-submission consultation request directly to the HSA within 30 days of project initiation, presenting the aging-reversal classification challenge and requesting written guidance — this creates an official regulatory record regardless of whether published guidelines exist
- Partner with existing Singapore biotech companies or A*STAR institutes that have successfully navigated HSA authorization for novel cellular or regenerative medicine products to obtain first-hand regulatory pathway intelligence
- Engage international regulatory experts familiar with analogous frameworks (FDA RMAT pathway, EMA ATMP regulation) to extrapolate likely Singapore requirements based on how comparable jurisdictions classify and authorize similar novel interventions
- Review published HSA guidance on related product categories (e.g., gene therapy, CAR-T cell therapy, tissue-engineered products) and adapt those evidentiary and procedural requirements to the aging-reversal context, supplemented by direct HSA engagement

## Find Document 3: Singapore One-North Biomedical Research Hub Infrastructure and Leasing Data

**ID**: c26af41b-9e7d-4138-afad-7b391f10e3a1

**Description**: Comprehensive data on the one-north biomedical research hub including Biopolis, Singapore Science Park, and Jurong Innovation District, covering available laboratory space, leasing terms, infrastructure specifications, rental rates, and occupancy status. This is the raw source material needed for the facility strategy decision and the phased lease-and-retrofit planning.

**Recency Requirement**: Current as of 2026 Q3, with up-to-date leasing availability and pricing information

**Responsible Role Type**: Chief Operating Officer

**Steps to Find**:

- Contact JTC Corporation (JTC) for one-north biomedical zone leasing availability and terms
- Access CapitaLand and Mapletree commercial property databases for Biopolis and Singapore Science Park listings
- Request information from A*STAR regarding shared infrastructure and co-location opportunities at one-north
- Obtain comparative leasing data for alternative locations (Singapore Science Park, Jurong Innovation District)
- Retrieve building specifications, floor plate sizes, and MEP infrastructure details for candidate facilities

**Access Difficulty**: Medium

**Essential Information**:

- Current availability and leasing terms for biomedical-grade laboratory space (15,000–20,000 sq ft minimum) at one-north biomedical research hub, including Biopolis, Singapore Science Park, and Jurong Innovation District, with rental rates per square foot and lease duration options
- Building specifications for candidate facilities: floor plate sizes, ceiling heights, MEP (mechanical, electrical, plumbing) infrastructure capacity, clean room and climate-controlled environment capabilities, and load-bearing specifications for heavy laboratory equipment
- Phased retrofit feasibility assessment for each candidate location: which infrastructure elements can be modified incrementally versus which require full reconstruction, and estimated retrofit timelines and costs
- Occupancy status and tenant mix at each location to assess co-location opportunities with A*STAR institutes, university hospitals, and existing biomedical partners
- Comparative analysis of leasing versus constructing purpose-built facilities at each location, including capital commitment profiles, flexibility for future GMP manufacturing expansion, and alignment with the phased lease-and-retrofit strategy
- JTC Corporation leasing policies, incentives, and co-location frameworks for biomedical research tenants at one-north, including any government-subsidized rates or strategic partnership terms

**Risks of Poor Quality**:

- Inaccurate or outdated leasing data could lead to selecting a facility that cannot accommodate the required modular instrumentation and phased retrofit, resulting in SGD 10–30 million in unplanned reconstruction costs and 3–9 month delays
- Missing or incomplete infrastructure specifications (e.g., insufficient MEP capacity for high-throughput automation or GMP requirements) could force expensive upgrades after lease signing, locking the project into a facility that cannot support future therapeutic manufacturing
- Failure to compare all three candidate locations could result in choosing a suboptimal site that lacks co-location synergies with A*STAR and partner hospitals, undermining the collaborative network design and adding SGD 20–40 million in redundant infrastructure costs
- Outdated occupancy data could lead to leasing space occupied by departing tenants with unresolved lease obligations, creating legal disputes and facility readiness delays that cost SGD 5–15 million in idle talent expenses
- Incomplete understanding of JTC leasing terms and government incentives could forfeit SGD 10–20 million in available subsidies or co-location benefits, increasing the effective cost of the facility strategy

**Worst Case Scenario**: Selecting a leased facility that proves structurally incapable of supporting GMP manufacturing expansion or accommodating the full modular instrumentation program, forcing the project to either absorb SGD 50–100 million in reconstruction costs or relocate entirely after committing to a long-term lease—delaying the initiative by 2–3 years, eroding first-mover advantage against competitors like Altos Labs, and potentially triggering investor confidence crisis that jeopardizes the SGD 500 million funding commitment.

**Best Case Scenario**: Identifying an optimal leased facility at one-north that perfectly matches the phased lease-and-retrofit strategy, with existing infrastructure that can be incrementally upgraded to support high-throughput automation, GMP manufacturing, and team absorption—saving SGD 20–30 million compared to purpose-built construction, accelerating facility readiness by 6–12 months, enabling seamless co-location with A*STAR partners, and preserving maximum flexibility to redirect capital as research priorities evolve under the Builder strategy's adaptive governance model.

**Fallback Alternative Approaches**:

- Engage specialized commercial real estate brokers (e.g., JLL, CBRE, Cushman & Wakefield) with biomedical property expertise to obtain proprietary leasing databases and off-market opportunities not available through public channels
- Request direct data from JTC Corporation's one-north management office, including internal occupancy reports, future development plans for the biomedical zone, and government-subsidized leasing programs not publicly advertised
- Conduct physical site visits and direct negotiations with property managers at Biopolis, Singapore Science Park, and Jurong Innovation District to obtain building-specific specifications and retrofit feasibility assessments
- Leverage A*STAR's institutional relationships to access internal data on shared infrastructure capacity, co-location terms, and partnership opportunities at one-north that may not be available through standard leasing channels
- Supplement with published market reports from property consultancies (e.g., Urban Redevelopment Authority data, Knight Frank Singapore biomedical market reports) and industry benchmarks to triangulate leasing rates and availability where direct data is unavailable

## Find Document 4: Singapore Biomedical Research Funding and Investment Statistics

**ID**: 730ae9a6-b1a5-4c21-86aa-6e5e921a2315

**Description**: Official statistical data on Singapore's biomedical research funding ecosystem, including government expenditure on biomedical research through NRF and A*STAR, private sector investment in Singapore biotech, philanthropic funding for biomedical research, and international grant flows. This is the raw source material for designing the blended funding architecture and assessing the feasibility of the SGD 200-250 million core public commitment and private co-funding targets.

**Recency Requirement**: Most recent available year (2024-2025 data preferred), with historical trends for the past 5 years

**Responsible Role Type**: Chief Financial Officer

**Steps to Find**:

- Access Singapore's Ministry of Finance data on research and development expenditure
- Retrieve NRF and A*STAR annual reports and funding allocation data
- Obtain Singapore Economic Development Board (EDB) biomedical sector investment statistics
- Access Singapore's Department of Statistics (SingStat) databases on R&D spending and biotech sector data
- Review private equity and venture capital investment data for Singapore biomedical startups
- Compile data on international grant funding available for aging research through NIH, ERC, and other sources

**Access Difficulty**: Medium

**Essential Information**:

- Exact government expenditure figures on biomedical research through NRF and A*STAR for the most recent year (2024-2025) and historical trends for the past 5 years
- Private sector investment data for Singapore biotech sector, including venture capital and private equity flows specifically targeting biomedical/longevity research
- Philanthropic funding amounts directed toward biomedical research in Singapore, including major donor contributions and foundation grants
- International grant flows available for aging research through sources like NIH, ERC, and other international funding bodies accessible to Singapore-based researchers
- Breakdown of funding channels to assess the feasibility of the SGD 200-250 million core public commitment and private co-funding targets required for the blended funding architecture
- Comparative data on how similar mega-scale biomedical initiatives in other jurisdictions were funded, to validate the proposed four-channel diversification strategy

**Risks of Poor Quality**:

- Inability to validate the blended funding architecture, leading to financial planning based on incorrect assumptions about available public and private capital
- Overestimation of available funds resulting in a funding shortfall of SGD 50-100 million or more during the 10-year initiative
- Private co-funding targets may prove unrealistic if actual private sector investment in Singapore biotech is lower than projected
- The SGD 200-250 million core public commitment may be unattainable if NRF and A*STAR budget allocations are insufficient or already committed to other priorities
- Inaccurate historical trend data could mislead long-term financial projections and contingency planning

**Worst Case Scenario**: The entire funding architecture is built on flawed or outdated statistical data, resulting in a critical funding gap exceeding SGD 100 million that threatens the viability of the $500 million initiative and forces project suspension or drastic scope reduction.

**Best Case Scenario**: Accurate and comprehensive funding statistics enable a robust blended funding architecture that confirms the feasibility of the SGD 200-250 million core public commitment and realistic private co-funding targets, ensuring financial resilience and diversified funding security for the full 10-year horizon.

**Fallback Alternative Approaches**:

- Engage subject matter experts and former NRF/A*STAR officials for targeted interviews to obtain unpublished budget allocation insights and forward-looking funding commitments
- Use proxy data from comparable biomedical research ecosystems (e.g., Hong Kong, Switzerland, or UK biomedical hubs) to estimate Singapore's funding capacity if official statistics are incomplete
- Purchase specialized industry reports from firms like McKinsey, Deloitte, or CBRE that provide detailed Singapore biomedical sector investment analyses
- Initiate direct negotiations with Singapore's Ministry of Finance and Economic Development Board to obtain classified or pre-release funding data under confidentiality agreements
- Apply conservative estimation techniques using the lowest historical funding levels from the past 5 years as baseline assumptions for the funding architecture

## Find Document 5: Singapore Talent Market and Compensation Benchmarks for Biogerontologists

**ID**: e55b3633-a026-41f8-a761-59dc1cb4545b

**Description**: Comprehensive data on the global and Singapore-specific talent market for biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists, including compensation benchmarks, signing bonus structures, academic-industry salary differentials, visa processing timelines, and competition from Altos Labs, Calico, and academic institutions. This is the raw source material for the talent recruitment strategy and compensation framework.

**Recency Requirement**: Current as of 2026, with the most recent compensation surveys and talent market reports

**Responsible Role Type**: Chief Talent & Integration Officer

**Steps to Find**:

- Access Singapore's Ministry of Manpower (MOM) work pass and employment pass data including processing timelines
- Retrieve compensation benchmarking data from sources like Radford, Mercer, or Aon for biomedical research roles
- Obtain data on academic-industry salary differentials for biogerontologists and related disciplines
- Access LinkedIn and industry reports on talent mobility patterns for aging research scientists
- Review joint appointment models at MIT, Stanford, Oxford, and Cambridge for dual-affiliation compensation structures
- Compile data on visa processing timelines for biomedical talent through Singapore's streamlined channels

**Access Difficulty**: Medium

**Essential Information**:

- Current base salary ranges and total compensation packages (base, bonus, equity) for biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists across US, European, Asian, and Singapore-specific markets as of 2026
- Signing bonus benchmarks and structures (equity stakes, relocation packages, housing allowances) differentiated by seniority level: anchor investigators (SGD 500,000–1,000,000 range), early-to-mid-career researchers, and technical staff
- Academic-industry salary differentials and dual-appointment compensation models at top-tier universities (MIT, Stanford, Oxford, Cambridge), including how joint appointments are structured and funded
- Singapore-specific visa processing timelines and work pass requirements (Employment Pass, Personalized Employment Pass) for international biomedical talent through Ministry of Manpower channels, including processing durations and approval rates
- Competitive intelligence on compensation packages offered by Altos Labs, Calico, Unity Biotechnology, and leading academic aging-reversal centers for comparable roles, including total rewards and non-monetary benefits
- Talent mobility patterns and retention factors for aging-reversal scientists, including primary reasons for job changes, geographic preferences, and career trajectory expectations
- Supply and demand dynamics for biogerontologists and related disciplines in Singapore and globally as of 2026, including pipeline of available PhDs and postdocs entering the field

**Risks of Poor Quality**:

- Setting compensation below market rates, causing failure to attract anchor investigators and delaying project launch by 1–2 years at a cost of SGD 50–100 million
- Budget misallocation on talent acquisition due to inaccurate salary benchmarks, leading to SGD 15–30 million in unnecessary expenditure or inability to retain key personnel after recruitment
- Visa processing delays due to lack of specific data on Singapore's biomedical work pass timelines, creating critical skill gaps during the startup phase and costing SGD 5–15 million in idle talent
- Inability to compete with Altos Labs and Calico for top talent, resulting in loss of scientific leadership and credibility that undermines Singapore's positioning as the global longevity epicenter
- Misalignment between compensation structures and academic-industry norms, undermining joint appointment partnerships with top universities and reducing the pool of eligible anchor investigators

**Worst Case Scenario**: Complete failure to recruit the required 3–5 anchor investigators and larger cohort of multidisciplinary researchers, resulting in the inability to execute the scientific program, potential termination of the $500 million initiative, and permanent loss of Singapore's positioning as the global epicenter of longevity science to competitors.

**Best Case Scenario**: Successful recruitment of world-class anchor investigators and a cohesive multidisciplinary team within target timelines, establishing Singapore as the definitive global hub for aging-reversal science and enabling the 10-year scientific program to proceed on schedule with credible, high-impact results that attract sustained funding and commercial partnerships.

**Fallback Alternative Approaches**:

- Engage specialized biomedical executive search firms (e.g., Heidrick & Struggles, Spencer Stuart) to conduct targeted talent market mapping and compensation benchmarking for the specific disciplines required
- Initiate direct interviews and surveys with 15–20 current biogerontologists and geneticists at leading institutions to gather primary compensation and mobility data as first-party evidence
- Leverage existing partnerships with MIT, Stanford, Oxford, and Cambridge HR departments to obtain anonymized compensation data and joint appointment models for dual-affiliation structures
- Purchase industry-standard compensation surveys (e.g., Radford, Mercer, Aon) specifically for the biomedical research sector to obtain validated benchmark data
- Analyze public compensation disclosures and job postings from Altos Labs, Calico, and Unity Biotechnology as proxy benchmarks for competitive positioning

## Find Document 6: Aging-Reversal Biomarker Validation Studies and Epigenetic Clock Data

**ID**: 9b7987e6-dfb3-4a78-b773-d544db17a27c

**Description**: The published scientific literature and datasets on aging biomarkers including epigenetic clocks (Horvath, Hannum, GrimAge), functional tissue assays, animal model longevity data, and senolytic biomarker validation studies. This is the raw scientific source material needed to design the biomarker validation hierarchy, define surrogate endpoint acceptance criteria, and establish the evidentiary thresholds for go/no-go gates.

**Recency Requirement**: Most recent publications from 2024-2026, with foundational studies included for context

**Responsible Role Type**: Scientific Director

**Steps to Find**:

- Search PubMed and Google Scholar for recent publications on epigenetic clock validation and aging biomarkers
- Retrieve the original Horvath, Hannum, and GrimAge epigenetic clock papers and their validation studies
- Access published data on senolytic biomarker validation including p16INK4a, SA-beta-gal, and SASP markers
- Obtain animal model longevity data from published studies on partial reprogramming, senolytic clearance, and metabolic interventions
- Review the biomarker qualification literature including frameworks for surrogate endpoint validation
- Compile data on functional tissue assays and their correlation with lifespan outcomes

**Access Difficulty**: Medium

**Essential Information**:

- Identify the specific validation metrics (sensitivity, specificity, and correlation coefficients) for Horvath, Hannum, and GrimAge epigenetic clocks across relevant tissue types to determine their reliability as gatekeeping criteria.
- Quantify the exact threshold levels for senolytic biomarkers (p16INK4a, SA-beta-gal, SASP factors) that constitute definitive evidence of successful clearance or modulation for go/no-go decisions.
- Detail the required correlation coefficients between functional tissue assays and actual lifespan outcomes in animal models necessary to advance a candidate to human trials.
- Compile a tiered biomarker confidence framework categorizing markers from molecular signatures to functional and lifespan correlates, defining admissible surrogate endpoints for clinical benefit proxies.
- List the specific pre-defined assay benchmarks that will trigger externally reviewed go/no-go gate decisions.

**Risks of Poor Quality**:

- Using unvalidated or poorly characterized epigenetic clocks as gatekeeping criteria could lead to premature advancement of ineffective therapies, resulting in failed clinical trials and loss of scientific credibility.
- If surrogate endpoint acceptance criteria are too lenient, the lab risks producing evidence that regulators and clinicians view as insufficient, undermining the project's legitimacy and delaying clinical authorization.
- Inaccurate biomarker data could cause the lab to terminate promising research lines prematurely, wasting the foundational scientific potential of the $500M investment and delaying the 10-year timeline.

**Worst Case Scenario**: The lab commits SGD 150–250 million to a therapeutic candidate based on a flawed or unvalidated biomarker that fails to predict actual functional or lifespan outcomes in humans, resulting in catastrophic financial loss, a 2–4 year project delay, and irreversible reputational damage to Singapore's position as the global longevity epicenter.

**Best Case Scenario**: The lab establishes a rigorous, internationally recognized biomarker validation hierarchy that serves as the global gold standard for aging-reversal research, enabling rapid and credible go/no-go decisions, accelerating the pipeline, and attracting top-tier talent and partnerships by demonstrating unparalleled scientific rigor.

**Fallback Alternative Approaches**:

- Engage a panel of independent subject matter experts (SMEs) in biogerontology and biomarker validation to conduct an ad-hoc review and synthesis of existing literature to establish interim acceptance criteria.
- Initiate targeted consultations with regulatory bodies (HSA) and international standardization organizations to adopt existing regulatory biomarker guidelines as a temporary baseline.
- Purchase or license specialized industry-standard biomarker validation datasets or reports from established biomedical research consortia to supplement internal literature reviews.

## Find Document 7: Singapore Building Construction Cost Data and Biomedical Facility Retrofit Estimates

**ID**: f1ee3c0c-43b8-4295-9245-16bddcec1858

**Description**: Current construction cost data for Singapore including per-square-foot costs for biomedical laboratory construction and retrofit, material costs, labor rates, and typical project timelines for phased facility development. This is the raw source material for the facility build-versus-lease decision and the financial risk assessment around construction cost overruns (15-25%).

**Recency Requirement**: Current as of 2026 Q3, with the most recent construction cost indices and market data

**Responsible Role Type**: Chief Operating Officer

**Steps to Find**:

- Access Singapore construction cost indices from sources like the Building and Construction Authority (BCA) or RICS Singapore
- Retrieve per-square-foot cost data for biomedical laboratory construction and retrofit in Singapore
- Obtain quotes or estimates from GMP-experienced facility retrofit contractors for the one-north area
- Access data on construction material costs, labor rates, and supply chain conditions in Singapore's construction market
- Review historical construction cost escalation data for Singapore biomedical facilities
- Compile data on typical phased construction timelines and cost escalation clauses

**Access Difficulty**: Medium

**Essential Information**:

- Current per-square-foot construction and retrofit costs for biomedical laboratories in Singapore's one-north biomedical research hub (2026 Q3 data)
- Detailed breakdown of material costs, labor rates, and equipment procurement expenses specific to GMP-compliant facility retrofits
- Historical construction cost escalation indices for Singapore biomedical facilities over the past 3-5 years to validate the 15-25% overrun risk assumption
- Obtained quotes or estimates from at least 2-3 GMP-experienced facility retrofit contractors for the one-north area with phased development timelines
- Typical project timelines for phased lease-and-retrofit approaches versus purpose-built construction, including critical path dependencies
- Data on construction cost escalation clauses and contract structures available in Singapore's current market conditions
- Comparative cost analysis between core leased facility with modular instrumentation versus integrated purpose-built facility

**Risks of Poor Quality**:

- Inaccurate or outdated cost data leads to underestimation of the SGD 30-75 million construction overrun risk, jeopardizing the 15% contingency reserve (SGD 75 million)
- Flawed build-versus-lease decision based on incomplete cost analysis locks in capital prematurely or commits to unsuitable facility constraints
- Underestimated retrofit timelines delay facility readiness beyond the 2027-Q4 target, causing SGD 5-15 million in idle talent costs
- Missing GMP-experienced contractor quotes result in unrealistic budgeting for clinical manufacturing pathway, risking SGD 100-200 million in sunk costs
- Lack of historical escalation data prevents accurate modeling of the 15-25% construction inflation scenario, undermining financial risk mitigation strategies

**Worst Case Scenario**: Outdated or inaccurate construction cost data results in a 25%+ budget overrun (SGD 75-100 million+) that exhausts the contingency reserve, triggers funding gaps of SGD 30-60 million, and forces either project scope reduction or termination of the facility build-versus-lease strategy, delaying first human trials by 12-18 months and costing SGD 50-100 million in lost research momentum.

**Best Case Scenario**: Precise, current cost data enables an optimized phased lease-and-retrofit strategy that completes facility readiness by 2027-Q2 for core labs and 2027-Q4 for clinical suites within budget, preserves the full SGD 75 million contingency reserve, validates the Builder strategy's adaptive governance approach, and establishes a cost baseline that protects the entire SGD 500 million initiative from construction inflation risks.

**Fallback Alternative Approaches**:

- Engage specialized biomedical construction consultants (e.g., Turner & Townsend, Arcadis) to produce bespoke cost estimates for the one-north area if public indices are insufficient
- Use international biomedical laboratory cost benchmarks from RICS or RSMeans adjusted for Singapore market conditions as a minimum viable dataset
- Proceed with current real estate market rates from commercial property agents for lease costs while deferring detailed construction cost analysis to the retrofit phase
- Leverage A*STAR or NUS facility management contacts to obtain internal cost data for recent biomedical retrofits in the one-north ecosystem
- Utilize Singapore Building and Construction Authority (BCA) published cost indices and government construction statistics as a baseline, supplemented by industry expert interviews