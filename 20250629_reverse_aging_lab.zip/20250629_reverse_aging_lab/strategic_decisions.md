## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers—Discovery-to-validation sequencing, Phased research portfolio allocation, Talent recruitment model, Funding architecture, and Facility build versus lease—collectively address the project's foundational tensions: Speed vs. Scientific Rigor (sequencing, biomarker gates), Capital Commitment vs. Flexibility (facility, funding, portfolio), and Talent Coherence vs. Star Power (recruitment). The eight High levers layer onto these by governing secondary trade-offs including Open Science vs. Commercial Value (IP), Bold Positioning vs. Credibility (positioning, ethics), and Screening Throughput vs. Capital Intensity (technology platform). No key strategic dimensions appear missing, though the interplay between the Critical levers—particularly how portfolio allocation constrains facility and funding decisions—warrants active governance to avoid suboptimization.

### Decision 1: Discovery-to-validation sequencing
**Lever ID:** `892cada7-234a-4340-bd3a-db33226a99b0`

**The Core Decision:** This lever governs the staged progression from mechanistic discovery through animal-model validation to human trials, defining the criteria and timing for transitioning between phases. It balances scientific rigor against the 10-year timeline pressure, determining when the clinical facility becomes active and how evidence accumulates to justify human studies. The sequencing approach directly shapes whether the lab produces credible reversal evidence or risks premature clinical commitments.

**Why It Matters:** Choosing a staged pipeline that gates human trials on predefined cellular and animal milestones slows early clinical ambition but prevents the lab from committing to human studies on an unproven mechanistic basis. If the gating criteria are too loose, the lab risks running trials that cannot demonstrate reversal and erodes regulatory and public trust; if too strict, the 10-year timeline may be consumed by preclinical work with no human data to show for it. The sequencing decision also determines whether the lab's clinical infrastructure sits idle or is continuously justified by incremental evidence.

**Strategic Choices:**

1. Anchor the first five years exclusively to mechanistic discovery and animal-model validation, releasing human trial funding only after independent replication of defined cellular reversal markers.
2. Run discovery and early-phase human observational studies in parallel from year two, accepting that some clinical activity will precede full mechanistic certainty in exchange for faster learning about human variability.
3. Structure the pipeline as a series of externally reviewed go/no-go gates tied to specific assay benchmarks, with each gate reallocating budget between preclinical and clinical work rather than following a fixed schedule.

**Trade-Off / Risk:** A fixed preclinical-then-clinical sequence protects scientific credibility but can leave the clinical facility underutilized if milestones slip, while parallel human work accelerates learning at the cost of running trials before the mechanism is adequately characterized.

**Strategic Connections:**

**Synergy:** Discovery-to-validation sequencing synergizes with Biomarker validation hierarchy and surrogate endpoint acceptance criteria because the sequencing gates depend on defined biomarker benchmarks, and the biomarker hierarchy determines what counts as sufficient evidence to pass each gate.

**Conflict:** Discovery-to-validation sequencing conflicts with Human trial eligibility and endpoint definition because strict sequencing delays human trial design, while the endpoint definition lever may push for earlier human engagement with broader eligibility that could bypass strict preclinical gates.

**Justification:** *Critical*, This lever is the central pipeline architecture that gates all downstream activity, directly controlling the project's core Speed vs. Scientific Rigor trade-off. Its synergy and conflict texts show it connects to biomarker validation, surrogate endpoints, human trial eligibility, and portfolio allocation, making it the hub that determines when the clinical facility becomes active and whether evidence accumulates credibly.

### Decision 2: Facility build versus lease and instrumentation strategy
**Lever ID:** `48fa84ab-8d89-45df-a290-1eb6823409f5`

**The Core Decision:** This lever determines the physical infrastructure approach for the Singapore laboratory, balancing upfront capital commitment against long-term operational flexibility. It affects how quickly the facility can absorb recruited teams, host specialized equipment, and adapt to shifting scientific priorities as the research portfolio evolves. The decision locks in or preserves the lab's ability to redirect resources over the decade.

**Why It Matters:** Deciding whether to construct a custom facility, lease and retrofit existing space, or phase instrumentation separately determines how much of the $500 million is committed before scientific direction is stable. A bespoke build maximizes control over layout and specialized systems but locks in capital early and makes later reconfiguration expensive; leasing preserves flexibility and can accelerate startup but may constrain the lab's ability to host the exact equipment and trial infrastructure it eventually needs. The choice also affects how quickly the lab can absorb recruited teams, because physical readiness often drives whether senior scientists accept positions.

**Strategic Choices:**

1. Construct a purpose-built facility with dedicated trial suites and specialized equipment rooms, accepting higher upfront capital in exchange for a fully integrated research and clinical environment.
2. Lease and retrofit an existing biomedical campus space in phases, aligning major capital outlays with confirmed team arrivals and validated research priorities rather than building everything at once.
3. Separate the investment into a core leased facility for shared infrastructure and a modular instrumentation program that scales equipment up or down as specific therapeutic lines prove worth pursuing.

**Trade-Off / Risk:** A purpose-built facility delivers the most coherent environment for a flagship longevity lab, but it commits the majority of capital before the science has proven which capabilities matter most, whereas phased leasing trades some integration quality for the ability to redirect money as priorities shift.

**Strategic Connections:**

**Synergy:** Facility build versus lease and instrumentation strategy synergizes with Talent recruitment model and team integration because physical readiness drives whether senior scientists accept positions, and the facility design must accommodate the organizational structure of the recruited teams.

**Conflict:** Facility build versus lease and instrumentation strategy conflicts with Phased research portfolio allocation and risk distribution because a purpose-built facility commits capital early and reduces the ability to redirect resources as research priorities shift, while phased leasing preserves flexibility that supports adaptive portfolio allocation.

**Justification:** *Critical*, Controls the foundational Capital Commitment vs. Flexibility trade-off for the physical $500M infrastructure. It is a central hub connecting talent recruitment (physical readiness drives hiring), clinical manufacturing, and portfolio allocation, and its decision locks in or preserves the lab's ability to redirect resources over the decade.

### Decision 3: Talent recruitment model and team integration
**Lever ID:** `91cf2f67-684b-48cf-a938-cbce928507f5`

**The Core Decision:** This lever shapes how the lab attracts, organizes, and coordinates its multidisciplinary team of biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists. It determines whether the facility operates as a collection of independent experts or a coherent research program, directly affecting scientific convergence and the timeline for developing a unified therapeutic hypothesis that the facility was built to test.

**Why It Matters:** How the lab recruits and organizes its multidisciplinary team determines whether the facility becomes a collection of independent experts or a coherent research program. Hiring globally recognized leaders individually raises prestige and funding potential but can produce competing agendas that are hard to integrate into a single aging-reversal pipeline; building smaller, cross-trained teams around shared assays and models improves cohesion but may sacrifice star power and external grant leverage. The integration model also affects the timeline, because a fragmented team can delay the convergence on a common therapeutic hypothesis that the facility was built to test.

**Strategic Choices:**

1. Recruit a small number of named principal investigators with strong independent funding and give each team autonomy over a distinct aging-reversal approach, coordinating only through shared core facilities.
2. Build integrated, cross-disciplinary pods that combine biogerontologists, geneticists, and bioinformaticians around specific model systems, prioritizing shared data standards and joint go/no-go decisions over individual prominence.
3. Use a hybrid model with a few anchor investigators setting scientific direction and a larger cohort of early-to-mid-career researchers organized into rotating project teams that can be reassigned as evidence favors some lines over others.

**Trade-Off / Risk:** Autonomous star investigators bring credibility and external funding but can fragment the lab's effort around competing hypotheses, while tightly integrated pods improve coherence and decision speed at the risk of reducing the lab's ability to attract top-tier independent talent.

**Strategic Connections:**

**Synergy:** Talent recruitment model and team integration synergizes with Collaborative network design and institutional partnership structure because the internal team integration model determines how effectively the lab can interface with external partners, and a well-integrated internal team strengthens collaborative credibility.

**Conflict:** Talent recruitment model and team integration conflicts with Intellectual property architecture and open-science posture because recruiting independent PIs with strong external funding may come with IP expectations that conflict with open-science commitments, while integrated pods with shared data standards may dilute individual IP value propositions.

**Justification:** *Critical*, The recruited multidisciplinary team IS the project's execution engine. This lever determines whether the facility becomes a coherent research program or a collection of independent experts, directly affecting scientific convergence and timeline. It connects to collaborative networks, IP architecture, and facility readiness as a central human-capital hub.

### Decision 4: Funding architecture and milestone-linked commitment
**Lever ID:** `c2895293-b9e8-429a-8224-f819106c682e`

**The Core Decision:** This lever governs how the $500 million budget is structured across the decade, determining whether funds flow as a single committed pool, externally reviewed tranches, or a hybrid public-private blend. Its success hinges on balancing financial resilience against scientific setbacks with the discipline of evidence-based resource allocation, directly shaping the lab's capacity to retain top talent and sustain long-term research programs without interruption.

**Why It Matters:** Structuring the $500 million as a single committed pool, a series of tranche releases, or a mixed public-private arrangement determines how resilient the project is to scientific setbacks and how much external scrutiny it invites. A fully committed pool gives the lab stable long-term freedom but makes it harder to justify continued spending if early results disappoint; tranche-based funding aligns money with evidence and protects against sunk-cost drift, yet it can create discontinuities that disrupt long-term studies and team retention. The funding model also affects the lab's ability to attract talent, because senior scientists often weigh whether the financial base is durable enough to support a decade-long program.

**Strategic Choices:**

1. Secure the full $500 million as a durable endowment-style commitment with internal milestone reviews, preserving long-term continuity while using internal gates to redirect effort rather than cut funding.
2. Arrange the budget as externally reviewed tranches tied to explicit scientific and operational milestones, so that continued funding depends on demonstrated progress and the lab cannot rely on the full sum by default.
3. Blend a core public or institutional commitment with private and partnership funding tied to specific therapeutic lines, using external co-funding to validate promising directions while protecting a baseline for high-risk discovery.

**Trade-Off / Risk:** A fully committed pool maximizes continuity and talent confidence but risks persisting with weak hypotheses past their useful life, while tranche-based funding enforces discipline and external validation at the cost of potential interruptions that can destabilize long-running studies and recruited teams.

**Strategic Connections:**

**Synergy:** This lever amplifies Talent Recruitment Model and Team Integration, because durable funding signals institutional stability that attracts senior scientists, and Phased Research Portfolio Allocation, because milestone-linked tranches naturally align with staged research investments and risk distribution across the portfolio.

**Conflict:** This lever constrains Positioning and Claim Management, because tranche-based funding demands demonstrable progress that pressures conservative messaging over bold hub-ambition claims, creating tension between financial discipline and the aggressive branding needed to establish Singapore as the global longevity epicenter.

**Justification:** *Critical*, The financial backbone of the entire $500M initiative, determining resilience against scientific setbacks and external scrutiny. It amplifies talent recruitment (durable funding attracts senior scientists) and phased portfolio allocation, while constraining positioning—making it a central hub connecting financial sustainability to scientific discipline.

### Decision 5: Phased research portfolio allocation and risk distribution
**Lever ID:** `4e0a13a1-e756-4b41-9670-6f29dd876aac`

**The Core Decision:** This lever determines how the $500 million budget is sequenced across fundamental biogerontological research, translational validation, and clinical development over the 10-year horizon. It is the single most consequential financial decision, determining whether the lab can recover from failed hypotheses or is locked into early bets. Front-loading discovery builds broad scientific foundations but delays clinical impact, while front-loading clinical development accelerates patient access but narrows scientific scope and concentrates risk.

**Why It Matters:** The $500 million budget must be allocated across fundamental biogerontological research, translational validation, and clinical development over a 10-year horizon, and the sequencing of this allocation determines whether the lab can recover from failed hypotheses or is locked into early bets. A front-loaded discovery strategy generates broad scientific knowledge but delays clinical impact, while a front-loaded clinical strategy risks exhausting resources on therapies that fail late-stage validation. The portfolio design is the single most consequential financial decision the initiative faces.

**Strategic Choices:**

1. Allocate the majority of funding to fundamental discovery and early-stage validation in the first five years, accepting delayed clinical milestones in exchange for a broad scientific foundation that de-risks later-stage investment through accumulated knowledge.
2. Distribute funding evenly across discovery, validation, and clinical phases throughout the 10-year period, maintaining parallel research tracks that provide continuous clinical progress while preserving fundamental research capacity.
3. Front-load clinical development by committing substantial resources to the most promising therapeutic candidates identified externally, using the remaining budget for targeted in-house validation, thereby accelerating patient impact but narrowing the scientific scope.

**Trade-Off / Risk:** Front-loading discovery funding builds a broad scientific foundation that de-risks later investment, but delays any clinical impact to the latter half of the 10-year timeline, testing stakeholder patience and political commitment.

**Strategic Connections:**

**Synergy:** This lever amplifies Therapeutic modality prioritization across cellular reprogramming, senolytics, and metabolic interventions because portfolio allocation determines how much funding each modality receives at each phase. It also aligns with Funding architecture and milestone-linked commitment, as phased spending must match how funding is released based on milestone achievement.

**Conflict:** This lever constrains Clinical manufacturing and therapeutic scale-up pathway because front-loading discovery funding delays the point at which manufacturing infrastructure investment becomes relevant. It also conflicts with Facility build versus lease and instrumentation strategy, as research phasing determines when facility capacity is needed, affecting build-versus-lease timing.

**Justification:** *Critical*, Explicitly described as 'the single most consequential financial decision the initiative faces,' this lever determines whether the lab can recover from failed hypotheses or is locked into early bets. It amplifies modality prioritization and aligns with funding architecture, controlling the fundamental resource distribution across the 10-year horizon.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Human trial eligibility and endpoint definition
**Lever ID:** `678cee5a-db45-4f31-be55-66e741bea54e`

**The Core Decision:** This lever specifies the inclusion and exclusion criteria for participants in aging-reversal trials and establishes what measurable outcomes will constitute evidence of efficacy. It directly affects enrollment feasibility, regulatory defensibility, and whether the lab's claims of cellular reversal can be substantiated or must remain at surrogate-marker levels. The endpoint choice also shapes the ethical narrative around reversal claims.

**Why It Matters:** Defining who qualifies for aging-reversal trials and what counts as a valid endpoint determines whether the lab can enroll patients, satisfy regulators, and produce interpretable results. Broad eligibility and soft endpoints make recruitment easier but produce ambiguous evidence that is hard to defend scientifically or translate into approvals; narrow eligibility and hard molecular endpoints improve rigor but shrink the eligible population and lengthen enrollment, potentially leaving the trial apparatus underused. The endpoint choice also shapes the ethical narrative, because claiming 'reversal' in humans before surrogate markers are validated invites scrutiny and reputational risk.

**Strategic Choices:**

1. Start with tightly defined surrogate endpoints in a small, highly selected population, treating early trials as marker-validation studies rather than claims of clinical reversal.
2. Design trials around functional and quality-of-life outcomes in broader age cohorts, prioritizing clinically meaningful signals over molecular reversal claims even if the mechanism remains partially opaque.
3. Adopt an adaptive endpoint strategy that begins with surrogate markers and pre-specifies the conditions under which the trial would shift to clinical outcomes, avoiding a permanent commitment to either frame.

**Trade-Off / Risk:** Surrogate-driven trials enroll faster and align with the lab's mechanistic identity, but they risk producing evidence that regulators and clinicians view as insufficient; functional endpoints are more persuasive to patients and payers yet may undercut the lab's core claim of cellular reversal.

**Strategic Connections:**

**Synergy:** Human trial eligibility and endpoint definition synergizes with Biomarker validation hierarchy and surrogate endpoint acceptance criteria because the endpoint definition depends on which biomarkers are accepted as valid surrogates, and the biomarker hierarchy determines whether surrogate endpoints can support regulatory approval.

**Conflict:** Human trial eligibility and endpoint definition conflicts with Positioning and claim management for the global longevity hub ambition because narrow eligibility and hard molecular endpoints produce rigorous but potentially unglamorous evidence that may not support the bold reversal claims needed for the hub's prestige.

**Justification:** *High*, Governs the critical trade-off between enrollment feasibility and evidentiary rigor, directly affecting whether the lab can produce interpretable, regulator-defensible results. It connects deeply to biomarker validation and surrogate endpoint criteria but is somewhat derivative of the upstream sequencing decision.

### Decision 7: Ethical and regulatory posture for aging-reversal trials
**Lever ID:** `53c74c50-5bb9-4a76-a549-f15bbacc1fd7`

**The Core Decision:** This lever defines the lab's approach to ethical review, informed consent protocols, and regulatory engagement for aging-reversal interventions. It balances the speed advantages of Singapore's streamlined processes against the reputational risks of working with an intervention class that makes fundamental claims about human aging, directly influencing public trust, international perception, and the project's legitimacy as a global epicenter.

**Why It Matters:** The lab's stance on ethical review, informed consent, and regulatory engagement shapes both its speed and its legitimacy when working with an intervention class that touches fundamental claims about human aging. A conservative posture that treats aging reversal as a high-uncertainty intervention will slow trial initiation and increase documentation burden, but it reduces the chance of ethical controversy or regulatory reversal later; a more assertive posture that leans on Singapore's streamlined processes can accelerate human studies yet raises the stakes if safety signals or overclaiming emerge. The posture also influences public and international perception, which matters because the project explicitly aims to position Singapore as the global epicenter of this field.

**Strategic Choices:**

1. Adopt a deliberately conservative ethics and regulatory framework that treats aging-reversal interventions as novel and high-uncertainty, requiring extended oversight, long follow-up, and explicit communication that reversal is not yet established.
2. Operate assertively within Singapore's existing regulatory pathways, framing the work as an extension of regenerative medicine and moving human studies forward with standard oversight while monitoring for field-specific safety concerns.
3. Create a dedicated internal ethics and patient-engagement layer that publishes its reasoning and trial-design rationale openly, using transparency as a buffer against external criticism while still pursuing an accelerated but carefully documented trial schedule.

**Trade-Off / Risk:** A conservative ethics posture protects the lab from overclaiming and safety backlash but can make the initiative look hesitant relative to its global ambitions, whereas an assertive posture uses Singapore's regulatory advantages to move faster but concentrates reputational risk if the field's uncertainty is underestimated.

**Strategic Connections:**

**Synergy:** Ethical and regulatory posture for aging-reversal trials synergizes with Public engagement and societal legitimacy strategy because a transparent, well-documented ethical posture provides the foundation for public trust and societal legitimacy, and the ethical framework's communication strategy directly feeds into how the lab presents itself to society.

**Conflict:** Ethical and regulatory posture for aging-reversal trials conflicts with Positioning and claim management for the global longevity hub ambition because a conservative ethical posture that emphasizes uncertainty and long follow-up may undermine the bold positioning needed to establish Singapore as the global epicenter, while an assertive posture supports the hub ambition but concentrates reputational risk.

**Justification:** *High*, Governs the Speed vs. Legitimacy trade-off, balancing Singapore's streamlined regulatory advantages against reputational risk from working with an intervention class making fundamental claims about human aging. It connects to public engagement and positioning but is somewhat reactive to decisions made by other levers.

### Decision 8: Positioning and claim management for the global longevity hub ambition
**Lever ID:** `98f02a57-04b5-417e-942e-09cd28cfcb20`

**The Core Decision:** This lever defines how the lab communicates its mission to the world, navigating the tension between bold 'reverse aging' branding that attracts talent, funding, and political support, and restrained scientific framing that preserves credibility. Its success depends on managing public expectations while maintaining the ambitious identity required to position Singapore as the global epicenter of longevity science.

**Why It Matters:** How the lab communicates its mission affects both its ability to attract talent and funding and its vulnerability to skepticism, because 'reverse aging' is a claim that outruns current evidence and invites both public excitement and scientific criticism. Aggressive positioning can accelerate recruitment and political support by making Singapore the obvious center for longevity science, but it also raises expectations that the lab may not meet and can attract scrutiny if results are modest or ambiguous; restrained positioning preserves credibility and room to pivot, but it may underdeliver on the branding and ecosystem-building goals stated in the plan. The communication strategy also interacts with ethics, because overstating readiness for human reversal therapies can distort patient expectations and regulatory perception.

**Strategic Choices:**

1. Position the lab explicitly as a global longevity hub with bold public claims about reversing aging, using the ambition to attract talent, partnerships, and attention while accepting the burden of delivering visibly meaningful results.
2. Frame the lab around rigorous aging biology and therapeutic validation with deliberately modest public language, emphasizing evidence generation and responsible translation over headline claims of reversal.
3. Separate external branding from internal scientific framing by maintaining an ambitious public narrative for ecosystem-building while keeping trial designs, endpoints, and public statements tightly anchored to what the current evidence can support.

**Trade-Off / Risk:** Bold positioning accelerates the hub-building goal and talent attraction but locks the lab into a public narrative that can become a liability if the science progresses more slowly than the messaging implies, whereas restrained framing protects credibility but may undercut the very global-centering ambition the plan depends on.

**Strategic Connections:**

**Synergy:** This lever amplifies Public Engagement and Societal Legitimacy Strategy, because a coherent positioning narrative anchors all public communications, and Talent Recruitment Model, because ambitious branding attracts researchers seeking to work at a globally recognized center for aging-reversal science.

**Conflict:** This lever conflicts with Ethical and Regulatory Posture, because aggressive claims about reversing aging distort patient expectations and regulatory perception, while restrained positioning may fail to generate the political momentum needed to leverage Singapore's progressive regulatory framework for human trials.

**Justification:** *High*, Determines whether the lab achieves its stated goal of positioning Singapore as the global epicenter of longevity science. It amplifies public engagement and talent recruitment but conflicts directly with ethical posture, creating the fundamental Bold Positioning vs. Credibility tension that shapes all external-facing strategy.

### Decision 9: Intellectual property architecture and open-science posture
**Lever ID:** `4b3b05ff-cfba-4d72-ac5e-2be2cecbb018`

**The Core Decision:** This lever determines the lab's approach to patenting discoveries versus open publication, directly shaping its commercial viability and scientific credibility. The choice between aggressive IP protection, fully open-access research, or a tiered hybrid model affects the lab's ability to attract collaborative researchers, secure commercial partnerships, and generate licensing revenue that could sustain long-term operations beyond initial funding.

**Why It Matters:** The lab must decide whether to patent discoveries aggressively, publish openly, or adopt a hybrid model that protects commercial rights while advancing scientific knowledge. This choice directly affects the lab's ability to attract top researchers, who value publication, and to secure commercial partnerships, which require IP protection. A misalignment here could either accelerate scientific impact at the cost of revenue, or generate licensing income but slow the pace of collaborative discovery.

**Strategic Choices:**

1. Adopt a fully open-access publication policy with no patenting of foundational aging-reversal discoveries, maximizing scientific collaboration and global credibility while relying on government funding and philanthropic support as primary revenue sources.
2. Implement a tiered IP strategy that patents therapeutic applications and clinical-stage interventions while publishing all foundational biogerontological research openly, balancing commercial exclusivity with scientific community goodwill.
3. Establish a proprietary-first model where all discoveries are internally patented and licensed exclusively to commercial partners, prioritizing revenue generation and self-sufficiency over rapid scientific dissemination.

**Trade-Off / Risk:** Aggressive patenting may attract commercial partners and generate licensing revenue, but it risks alienating the global scientific community whose collaborative input is essential for the complex, multi-disciplinary nature of aging-reversal research.

**Strategic Connections:**

**Synergy:** This lever enables Collaborative Network Design, because tiered open-access IP policies build trust with partner institutions and facilitate shared discovery rights, while also supporting Academic Publication Cadence by ensuring foundational research reaches the scientific community without restrictive embargoes.

**Conflict:** This lever conflicts with Therapeutic Commercialization Pathway, because fully open-access IP forfeits licensing revenue and commercial exclusivity that could generate economic returns for Singapore, while aggressive proprietary models deter the collaborative scientific community essential for complex aging-reversal research breakthroughs.

**Justification:** *High*, Governs the Open Science vs. Commercial Value trade-off, directly affecting the lab's ability to attract collaborative researchers and secure commercial partnerships. It enables collaborative network design and conflicts with therapeutic commercialization, making it a pivotal connector between scientific credibility and economic sustainability.

### Decision 10: Collaborative network design and institutional partnership structure
**Lever ID:** `0b5df4b3-1fdd-423a-bd57-1ac8e352bbd2`

**The Core Decision:** This lever shapes whether the lab operates as a standalone institution or embeds within a network of partner universities, hospitals, and research centers. Its success depends on balancing the research throughput gains from shared patient cohorts, equipment, and expertise against the governance complexity, authorship disputes, and decision-making delays that multi-institutional partnerships inevitably introduce.

**Why It Matters:** The lab's research throughput depends heavily on whether it operates as a standalone institution or embeds itself within a network of partner universities, hospitals, and research centers. Building deep institutional partnerships accelerates access to diverse patient populations and complementary expertise, but introduces governance complexity and potential conflicts over authorship and resource allocation. The choice here shapes whether the lab becomes a globally connected hub or a self-contained silo.

**Strategic Choices:**

1. Forge formal co-location agreements with Singapore's existing biomedical research institutes and university hospitals, embedding lab teams within partner facilities to share equipment, patient cohorts, and clinical infrastructure while maintaining independent governance.
2. Establish a distributed consortium model where the Singapore lab serves as the coordinating hub, with satellite research nodes at partner institutions worldwide that contribute specialized capabilities and share in discovery rights.
3. Operate as a fully self-contained institution with minimal external partnerships, building all required capabilities internally to maintain complete control over research direction, data, and intellectual property.

**Trade-Off / Risk:** Embedding within Singapore's existing research institutes accelerates access to patient cohorts and shared infrastructure, but cedes some governance autonomy and introduces institutional politics that can slow decision-making on high-risk research directions.

**Strategic Connections:**

**Synergy:** This lever amplifies Facility Build versus Lease and Instrumentation Strategy, because institutional partnerships enable shared infrastructure and co-located facilities that reduce capital expenditure, and Talent Recruitment Model, because embedded positions at partner hospitals attract clinician-scientists who value dual institutional affiliations.

**Conflict:** This lever conflicts with Data Sovereignty, because distributed partner networks create fragmented data repositories across jurisdictions with differing privacy laws, and Intellectual Property Architecture, because shared discovery rights across institutions complicate patent ownership and licensing revenue allocation.

**Justification:** *High*, Determines whether the lab operates as a globally connected hub or a self-contained silo, directly shaping research throughput through access to patient cohorts and complementary expertise. It amplifies facility strategy and talent recruitment but introduces governance complexity and data sovereignty challenges.

### Decision 11: Public engagement and societal legitimacy strategy
**Lever ID:** `7bb258b8-4cd3-46f3-a1fb-d43e85f48d51`

**The Core Decision:** This lever governs how the lab builds trust and legitimacy with the Singaporean public, patient communities, and global stakeholders, navigating deep societal questions about equity, access, and the ethics of life-extension technologies. Its success requires proactive transparency that positions the lab as a public trust institution while managing the risk that early-stage findings may be misinterpreted under public scrutiny.

**Why It Matters:** Aging-reversal research sits at the intersection of profound scientific ambition and deep societal questions about equity, access, and the meaning of aging itself. Without proactive public engagement, the project risks public skepticism, political backlash, and funding instability, especially given the ethical sensitivities around life-extension technologies. A deliberate legitimacy strategy shapes whether the lab is seen as a public good or a privilege of the wealthy.

**Strategic Choices:**

1. Launch a sustained public education campaign that transparently communicates research goals, timelines, and limitations, positioning the lab as a public trust institution accountable to Singaporean citizens and the global community.
2. Maintain a primarily scientific and policy-facing communications posture, engaging only with expert audiences, regulatory bodies, and institutional stakeholders to preserve research focus and avoid public controversy.
3. Partner with patient advocacy groups, aging-related disease communities, and civic organizations to co-design research priorities and ensure the lab's work addresses populations most affected by age-related disease.

**Trade-Off / Risk:** Prioritizing public transparency and accessibility builds societal trust and political support for the $500 million investment, but exposes early-stage findings to misinterpretation and creates pressure to deliver visible results on accelerated timelines.

**Strategic Connections:**

**Synergy:** This lever amplifies Positioning and Claim Management, because public legitimacy provides the political foundation for any branding strategy, and Ethical and Regulatory Posture, because societal trust creates the environment needed for Singapore's progressive regulatory framework to function effectively.

**Conflict:** This lever conflicts with Academic Publication Cadence, because public transparency demands open access conflicting with proprietary data embargoes needed for patents, and with Therapeutic Commercialization Pathway, because premature public disclosure of early results can undermine commercial partnerships and investor confidence.

### Decision 12: Technology platform and high-throughput automation strategy
**Lever ID:** `56b3513e-dc14-40cd-8357-ec438275a055`

**The Core Decision:** This lever defines the lab's core experimental throughput capacity by determining whether to build fully automated internal screening platforms, adopt a modular incremental automation approach, or license external high-throughput services. It directly governs how many compounds, genetic interventions, and cellular phenotypes can be tested simultaneously, shaping the pace of aging-reversal discovery. Success depends on balancing screening volume per researcher against capital intensity, technical talent availability in Singapore, and the platform's adaptability as emerging scientific paradigms shift the required experimental toolkit.

**Why It Matters:** The pace of aging-reversal discovery depends on the lab's ability to screen vast numbers of compounds, genetic interventions, and cellular phenotypes at scale. Investing in fully automated, high-throughput platforms accelerates hypothesis testing but requires massive upfront capital and specialized technical talent that may be scarce in Singapore's current biotech ecosystem. The platform choice determines whether the lab leads in discovery speed or adapts flexibly to emerging scientific paradigms.

**Strategic Choices:**

1. Build a fully automated, AI-integrated high-throughput screening facility from the outset, deploying robotic liquid handling, machine-learning-driven phenotype analysis, and closed-loop experimental design to maximize the volume of tests per researcher.
2. Adopt a modular platform strategy that starts with manually operated, flexible bench-space infrastructure and incrementally automates specific workflows as research priorities crystallize and validated technologies become available.
3. License or contract access to external high-throughput platforms operated by specialized service providers rather than building internal automation, redirecting capital toward biological expertise and clinical validation.

**Trade-Off / Risk:** Building fully automated internal platforms maximizes screening throughput and data ownership, but locks the lab into capital-intensive infrastructure that may become obsolete as emerging aging-reversal paradigms shift the required experimental toolkit.

**Strategic Connections:**

**Synergy:** This lever amplifies Discovery-to-validation sequencing by accelerating the discovery phase and feeding validated candidates into downstream validation. It also enables Biomarker validation hierarchy and surrogate endpoint acceptance criteria by generating the large-scale phenotypic and molecular datasets needed to establish robust biomarker thresholds.

**Conflict:** This lever constrains Funding architecture and milestone-linked commitment because fully automated platforms demand massive upfront capital before milestones are achieved. It also conflicts with Facility build versus lease and instrumentation strategy, as internal automation strongly favors building over leasing a facility.

**Justification:** *Medium*, Builds the political and social foundation for the $500M investment but is more of an enabling function than a strategic driver. It amplifies positioning and ethical posture but is downstream of the core research and financial decisions that determine the lab's actual credibility.

### Decision 13: Clinical manufacturing and therapeutic scale-up pathway
**Lever ID:** `4ba6e87d-bd45-4a8b-8163-edbb5a1af9f4`

**The Core Decision:** This lever governs the pathway from laboratory-scale discovery to GMP-compliant manufacturing for human trials and eventual clinical deployment. It determines whether Singapore evolves from a research site into a full therapeutic production hub, directly affecting the timeline from discovery to patient access. The decision carries significant regulatory and capital implications, as early GMP investment commits hundreds of millions before any therapy has proven human efficacy, while deferring manufacturing may slow clinical translation.

**Why It Matters:** Any successful aging-reversal therapy must eventually transition from laboratory-scale cellular and animal models to GMP-compliant manufacturing for human trials and eventual clinical deployment. The lab's decision about when and how to build manufacturing capability directly affects the timeline from discovery to patient access and determines whether Singapore becomes a production hub or merely a research site. This choice carries significant regulatory and capital implications.

**Strategic Choices:**

1. Construct an integrated GMP manufacturing facility within the Singapore campus from the project's early phases, enabling seamless transition from discovery to clinical-grade production and positioning Singapore as a global longevity therapeutics manufacturing center.
2. Defer manufacturing infrastructure entirely, partnering with established contract development and manufacturing organizations for clinical trial supply while the lab focuses exclusively on discovery and early-stage validation.
3. Build a pilot-scale manufacturing capability sufficient for Phase I/II clinical trial supply, with a planned expansion pathway to full GMP scale contingent on therapeutic efficacy milestones and regulatory feedback.

**Trade-Off / Risk:** Building integrated GMP manufacturing early creates a seamless path from discovery to clinic and attracts therapeutic partners, but commits hundreds of millions in capital before any therapy has proven efficacy in human trials.

**Strategic Connections:**

**Synergy:** This lever enables Therapeutic commercialization pathway and Singapore economic value capture by positioning Singapore as a global longevity therapeutics manufacturing center. It also reinforces Ethical and regulatory posture for aging-reversal trials, as GMP manufacturing must be designed within the same regulatory framework governing human trials.

**Conflict:** This lever constrains Phased research portfolio allocation and risk distribution because early GMP manufacturing consumes capital that could fund discovery or validation, especially risky before efficacy is proven. It also conflicts with Facility build versus lease and instrumentation strategy, as integrated GMP facilities represent the most capital-intensive build scenario.

**Justification:** *Medium*, Determines the path from discovery to patient access and whether Singapore becomes a production hub, but is downstream of modality prioritization and portfolio allocation decisions. It constrains portfolio allocation and facility strategy but depends on earlier choices about which therapies to pursue.

### Decision 14: Data sovereignty and cross-border research governance
**Lever ID:** `6cb2a8cb-2501-4dfa-8a59-2f5b14a548cc`

**The Core Decision:** This lever governs how the massive genomic, proteomic, and longitudinal clinical datasets generated by aging-reversal research are stored, governed, and shared across jurisdictions. It balances research utility against regulatory compliance and international collaboration needs, with choices ranging from centralized Singaporean data infrastructure to federated architectures or multi-jurisdictional data trusts. The decision shapes the lab's global collaborative capacity, regulatory vulnerability, and ability to conduct large-scale cross-border studies.

**Why It Matters:** Aging-reversal research generates massive datasets from genomic sequencing, proteomic profiling, and longitudinal clinical monitoring that span multiple jurisdictions and regulatory regimes. The lab must decide whether to centralize all data in Singapore or distribute it across partner institutions, a choice that affects both research utility and compliance with international data protection frameworks. This decision shapes the lab's ability to conduct global collaborative studies while maintaining regulatory compliance.

**Strategic Choices:**

1. Centralize all research data within Singapore's sovereign infrastructure under a unified governance framework, leveraging Singapore's progressive data-protection laws to enable global collaboration while maintaining a single point of regulatory compliance.
2. Implement a federated data architecture where raw data remains at originating institutions and only aggregated, anonymized analyses are shared through the Singapore hub, preserving partner data sovereignty while enabling collaborative science.
3. Establish a multi-jurisdictional data governance consortium with partner nations, creating shared legal frameworks and data trusts that allow cross-border research while respecting each jurisdiction's privacy and sovereignty requirements.

**Trade-Off / Risk:** Centralizing all genomic and clinical data in Singapore maximizes analytical power and research velocity, but creates a single-point regulatory vulnerability if international data-transfer frameworks or bilateral agreements shift unfavorably.

**Strategic Connections:**

**Synergy:** This lever enables Collaborative network design and institutional partnership structure because data governance architecture determines the depth and trust level of international partnerships. It also amplifies Technology platform and high-throughput automation strategy, as automated platforms generate the massive datasets that governance frameworks must accommodate.

**Conflict:** This lever constrains Collaborative network design and institutional partnership structure because a centralized data approach may deter partners who prefer to retain data sovereignty. It also conflicts with Public engagement and societal legitimacy strategy, as data governance choices directly affect public trust in how personal health data is handled.

**Justification:** *Medium*, Governs how massive genomic and clinical datasets are stored and shared across jurisdictions, affecting collaborative capacity and regulatory vulnerability. It enables and constrains collaborative network design but is more of an operational governance framework than a foundational strategic choice.

### Decision 15: Therapeutic modality prioritization across cellular reprogramming, senolytics, and metabolic interventions
**Lever ID:** `a458af5f-c78c-4810-bee4-9106159bdde9`

**The Core Decision:** This lever determines which mechanistic approach to aging reversal the lab will primarily pursue — cellular reprogramming, senolytic clearance, or metabolic interventions — and in what proportion. Concentrating on one modality accelerates depth of expertise but makes the entire $500 million dependent on a single mechanistic bet that human biology may reject. Spreading across modalities preserves optionality but fragments team focus and hinders the deep institutional expertise a decade-long timeline demands.

**Why It Matters:** Choosing a primary modality concentrates the lab's scientific talent, equipment procurement, and validation pipeline on one mechanistic approach, which accelerates depth but narrows the probability of finding any working therapy if that approach fails in human biology. A multi-modality spread preserves optionality but fragments the team's focus and makes it harder to build the deep institutional expertise that a 10-year timeline demands. The decision also shapes which external collaborators and funding partners the lab can credibly engage, since each modality carries different regulatory precedents and investor expectations.

**Strategic Choices:**

1. Commit the majority of discovery resources to partial cellular reprogramming as the lead modality, accepting that this path carries the highest scientific uncertainty but offers the largest therapeutic payoff if safety hurdles are solved.
2. Distribute the portfolio roughly equally across reprogramming, senolytic clearance, and metabolic reprogramming so that no single mechanistic bet can sink the entire initiative, while accepting slower progress in each lane.
3. Anchor the lab around a platform that measures and compares aging biomarkers across all three modalities without committing to a therapeutic lead until human-relevant validation data emerges, treating the first five years as a measurement and triage phase.

**Trade-Off / Risk:** Concentrating on one modality accelerates depth but makes the entire $500 million dependent on a mechanistic bet that human biology may reject, while spreading across modalities preserves optionality at the cost of the deep expertise a decade-long timeline requires.

**Strategic Connections:**

**Synergy:** This lever amplifies Phased research portfolio allocation and risk distribution because modality prioritization determines how the budget is distributed across research areas at each phase. It also enables Biomarker validation hierarchy and surrogate endpoint acceptance criteria, as each modality requires distinct biomarker validation approaches and acceptance thresholds.

**Conflict:** This lever constrains Phased research portfolio allocation and risk distribution because committing to a single modality concentrates risk in ways that may be incompatible with a diversified portfolio strategy. It also limits Collaborative network design and institutional partnership structure, as modality choice determines which external collaborators are credible and relevant partners.

**Justification:** *High*, Determines the core scientific bet the entire $500M initiative makes, concentrating or distributing risk across mechanistic approaches. It amplifies portfolio allocation and biomarker validation but is somewhat constrained by the portfolio allocation decision that determines how much each modality receives.

### Decision 16: Biomarker validation hierarchy and surrogate endpoint acceptance criteria
**Lever ID:** `6ceeb0d7-4901-4a7b-885c-cdfe55d0a012`

**The Core Decision:** This lever establishes the evidentiary thresholds governing when a candidate aging intervention transitions from preclinical discovery to human testing. It defines a tiered biomarker confidence framework — from molecular signatures to functional and lifespan correlates — determining which surrogate endpoints are admissible as clinical benefit proxies. The hierarchy shapes pipeline velocity, stakeholder communication cadence, and Singapore regulatory strategy, serving as the critical gatekeeper between laboratory promise and clinical reality.

**Why It Matters:** Defining which aging biomarkers count as acceptable surrogate endpoints determines how quickly the lab can claim progress and trigger downstream clinical trials, but premature acceptance of weak surrogates risks validating therapies that fail to produce meaningful functional or lifespan outcomes in humans. A stringent hierarchy slows the pipeline and may frustrate stakeholders expecting visible milestones, yet it protects the lab's scientific credibility if a therapy later fails on hard endpoints. The choice also interacts with Singapore's regulatory framework, since local approval pathways may or may not recognize the lab's preferred biomarkers as sufficient for trial authorization.

**Strategic Choices:**

1. Adopt a conservative biomarker hierarchy requiring concordant evidence from epigenetic clocks, functional tissue assays, and animal model longevity data before any human trial trigger, accepting slower milestone velocity in exchange for stronger evidentiary standards.
2. Permit early human trials on the basis of a narrower set of molecular biomarkers that are measurable in blood or tissue within months, trading evidentiary rigor for faster clinical translation and earlier opportunities to fail or succeed in humans.
3. Build an internal biomarker qualification team that systematically stress-tests each candidate surrogate against historical datasets and negative controls, delaying trial triggers until the lab has internally validated that its biomarkers predict functional outcomes rather than merely tracking molecular noise.

**Trade-Off / Risk:** Accepting weak surrogate endpoints accelerates trial triggers and stakeholder-visible milestones, but a therapy that moves the biomarker without improving function or lifespan would expose the lab's evidentiary standards as insufficient after years of investment.

**Strategic Connections:**

**Synergy:** It amplifies Human trial eligibility and endpoint definition, because the biomarker hierarchy directly defines which endpoints are admissible and thus shapes who qualifies for trials. It also reinforces Discovery-to-validation sequencing by setting the evidentiary gates that determine how quickly discoveries advance through the pipeline.

**Conflict:** It constrains Discovery-to-validation sequencing, because a conservative biomarker hierarchy deliberately slows pipeline velocity, creating tension with ambitions for rapid progression from discovery to validation. It also trades off against Phased research portfolio allocation and risk distribution, as stringent surrogate acceptance criteria concentrate risk in fewer programs that meet the highest evidentiary bars.

**Justification:** *High*, Serves as the evidentiary gatekeeper between laboratory promise and clinical reality, directly controlling pipeline velocity and scientific credibility. It amplifies human trial eligibility and discovery-to-validation sequencing but functions as a specification layer that supports the upstream sequencing decision rather than an independent strategic axis.

### Decision 17: Academic publication cadence and proprietary data embargo strategy
**Lever ID:** `70b274a6-d697-4e4d-906c-d830d28d6d95`

**The Core Decision:** This lever governs the temporal and substantive boundaries of the lab's external scientific communication, balancing the imperative to build credibility and attract global talent against the need to protect proprietary findings and partnership leverage. It determines whether results — including negative data — enter the public domain annually, are withheld until clinical milestones, or are selectively disclosed to serve dual purposes of scientific legitimacy and competitive positioning in Singapore's longevity hub strategy.

**Why It Matters:** A high-cadence publication strategy builds the lab's scientific reputation, attracts talent, and signals progress to stakeholders, but it also discloses methodological details and negative results that competitors can exploit and that may complicate future intellectual property claims. A restrictive embargo strategy protects competitive advantage and gives the lab leverage in partnerships, but it risks starving the lab of the visibility needed to recruit top researchers and to justify the initiative's public purpose in Singapore. The cadence decision also affects how the lab manages the tension between open-science credibility and the commercial value of any therapy that emerges.

**Strategic Choices:**

1. Publish peer-reviewed results on a regular annual cycle including negative findings, accepting that competitors gain early visibility in exchange for the talent attraction, regulatory trust, and scientific legitimacy that sustained publication provides.
2. Restrict external publication until a therapy reaches a defined clinical milestone, releasing only high-level progress summaries in the interim to preserve proprietary advantage and partnership leverage.
3. Adopt a selective publication model that discloses methodology and biomarker validation work openly while withholding therapeutic efficacy data until patent filings and trial design are locked, balancing scientific credibility with commercial protection.

**Trade-Off / Risk:** Regular publication builds reputation and talent appeal but hands competitors early insight, while long embargoes protect advantage but risk starving the lab of the visibility needed to recruit and to justify its public-purpose claims in Singapore.

**Strategic Connections:**

**Synergy:** It amplifies Positioning and claim management for the global longevity hub ambition, because sustained publication builds the scientific credibility and public trust that underpin Singapore's status as the global epicenter of aging science. It also reinforces Talent recruitment model and team integration, because publication visibility and academic reputation are primary magnets for attracting top international researchers.

**Conflict:** It constrains Intellectual property architecture and open-science posture, because high-cadence publication discloses methodological details and negative results that can undermine patentability and proprietary advantage. It also creates tension with Collaborative network design and institutional partnership structure, because restrictive embargo strategies may erode trust with institutional partners who expect data-sharing transparency.

**Justification:** *Medium*, Balances scientific credibility and talent attraction against competitive advantage and IP protection. It amplifies positioning and talent recruitment but is a policy choice that follows from the IP architecture and commercialization pathway decisions made at higher strategic levels.

### Decision 18: Therapeutic commercialization pathway and Singapore economic value capture
**Lever ID:** `de3ba797-6b91-42e7-83a6-d2dd9ec51912`

**The Core Decision:** This lever determines the institutional architecture through which the lab's therapeutic discoveries reach patients and markets, directly shaping how Singapore captures economic value from the $500 million investment. It governs whether each successful program becomes an independently governed spin-out, is licensed to global pharmaceutical partners, or remains within a state-supported entity prioritizing public health outcomes over financial returns, thereby defining alignment between scientific mission, national interest, and commercial incentive across the initiative's decade-long horizon.

**Why It Matters:** Deciding whether the lab's therapies will be commercialized through a spin-out, licensed to existing pharmaceutical companies, or kept within a state-supported development entity determines how Singapore captures economic value and how much control the lab retains over trial design and pricing. A spin-out maximizes potential financial return and signals entrepreneurial ambition, but it introduces governance complexity and may divert attention from the scientific mission. Licensing to established pharma accelerates development and regulatory navigation but cedes control and may limit Singapore's ability to claim the therapy as a national achievement. The pathway also shapes how the lab's stakeholders — government, investors, and the scientific team — align their expectations over the decade.

**Strategic Choices:**

1. Build a dedicated spin-out entity for each successful therapeutic program, retaining equity and governance control while accepting the management burden of operating commercial entities alongside the research lab.
2. License promising programs to global pharmaceutical partners at the validation stage, trading equity upside for accelerated development capacity and regulatory expertise that the lab itself may lack.
3. Keep therapeutic development within a state-supported entity that prioritizes Singapore's public health and economic interests over maximum financial return, accepting slower commercialization in exchange for sustained national control over access and pricing.

**Trade-Off / Risk:** A spin-out maximizes equity and control but adds commercial governance overhead, licensing accelerates development at the cost of national control, and a state-supported entity preserves public-interest alignment while likely slowing the path to market.

**Strategic Connections:**

**Synergy:** It amplifies Funding architecture and milestone-linked commitment, because the chosen commercialization pathway determines the expected return structure and how milestone-linked funding tranches are designed and disbursed. It also reinforces Therapeutic modality prioritization across cellular reprogramming, senolytics, and metabolic interventions, because different modalities have distinct commercial maturity profiles that align better with certain pathways than others.

**Conflict:** It constrains Ethical and regulatory posture for aging-reversal trials, because a spin-out prioritizing financial returns may create governance tensions with the ethical mandate to ensure equitable patient access and affordable pricing. It also conflicts with Positioning and claim management for the global longevity hub ambition, because licensing therapies to external pharma companies may undermine Singapore's narrative of national scientific achievement and self-determination.

**Justification:** *Medium*, Determines how Singapore captures economic value and how much control the lab retains, but is downstream of modality prioritization and funding architecture. It amplifies funding design and modality prioritization but constrains ethics and positioning as a later-stage strategic decision.

### Decision 19: Internal capability scope versus external outsourcing for specialized assays and manufacturing
**Lever ID:** `ec39d83b-f972-45dd-acc4-ed5414091f50`

**The Core Decision:** This lever maps the boundary between capabilities the lab develops internally and those it procures from external vendors, fundamentally shaping the facility's operational DNA and talent composition. It determines which specialized assays, preclinical manufacturing processes, and validation workflows are retained as core competencies versus contracted out, directly affecting capital allocation, intellectual property control, quality assurance, and the lab's resilience against vendor dependencies as therapies advance toward human trials.

**Why It Matters:** Building every specialized capability in-house gives the lab tight control over quality, timing, and intellectual property, but it also commits the $500 million to capabilities that may only be needed intermittently and that compete with core discovery work for talent and attention. Outsourcing specialized assays, preclinical manufacturing, or certain validation steps to external vendors preserves capital and flexibility, but it introduces dependency on vendor timelines, quality consistency, and confidentiality, which can become acute if a therapy approaches human trials. The make-versus-buy decision also shapes how the lab's team allocates its time between internal execution and external coordination.

**Strategic Choices:**

1. Bring core discovery, biomarker assay development, and preclinical manufacturing fully in-house to maximize control and protect proprietary methods, accepting that some capabilities will be underutilized between projects.
2. Outsource specialized assays and preclinical manufacturing to vetted external vendors while keeping therapeutic design and data interpretation internal, trading control for capital efficiency and flexibility.
3. Build in-house capacity only for the capabilities that are rate-limiting to the lab's timeline, such as the assays most central to the chosen modality, and outsource the rest, accepting that the boundary between internal and external will need active renegotiation as the science evolves.

**Trade-Off / Risk:** Full in-house capability maximizes control and IP protection but commits capital to intermittently used functions, outsourcing preserves flexibility but introduces vendor dependency and confidentiality risk, and a selective build strategy requires ongoing renegotiation as the science changes.

**Strategic Connections:**

**Synergy:** It amplifies Facility build versus lease and instrumentation strategy, because bringing capabilities in-house requires the physical facility to house specialized equipment and infrastructure, while outsourcing reduces the instrumentation demands on the leased or built space. It also reinforces Talent recruitment model and team integration, because in-house capabilities require hiring specialized technical staff, whereas outsourcing shifts the team composition toward coordination and oversight roles.

**Conflict:** It constrains Intellectual property architecture and open-science posture, because outsourcing specialized assays and manufacturing introduces vendor confidentiality obligations that can compromise proprietary method protection and open-science commitments. It also conflicts with Clinical manufacturing and therapeutic scale-up pathway, because relying on external vendors for preclinical manufacturing may limit the lab's direct control over the quality and consistency required as therapies scale toward human trials.

**Justification:** *Medium*, Maps the make-versus-buy boundary that shapes operational DNA and talent composition, amplifying facility strategy and talent recruitment. However, it is an implementation-level decision that follows from the facility, portfolio, and modality choices made at higher strategic levels.
