This plan involves money.

## Currencies

- **SGD:** Local currency for Singapore, where the research lab will be located.
- **USD:** A stable international currency for budgeting and reporting, especially given the project's scale and international collaboration.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks. SGD will be used for local transactions in Singapore. Given the project's scale, using USD as the primary currency is essential for financial stability and international collaboration.