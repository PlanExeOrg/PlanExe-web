This plan implies one or more physical locations.

## Requirements for physical locations

- Progressive biomedical regulatory framework
- Streamlined ethical approval processes
- World-class scientific infrastructure
- Proximity to biomedical research ecosystem and global talent pool
- Space for state-of-the-art laboratory and clinical trial facilities
- Capacity to accommodate a multidisciplinary team of biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists
- Strategic positioning as a global longevity and anti-aging science hub
- Scalability for future GMP manufacturing and therapeutic scale-up

## Location 1
Singapore

Singapore, nationwide

Singapore (primary facility to be sited in a biomedical research district)

**Rationale**: The plan explicitly specifies Singapore as the location for the Reverse Aging Research Lab, citing its progressive biomedical regulatory framework, streamlined ethical approval processes, and world-class scientific infrastructure as the core strategic advantages for establishing the global epicenter of longevity science.

## Location 2
Singapore

one-north biomedical research hub

one-north, Singapore (near Biopolis and A*STAR institutes)

**Rationale**: one-north is Singapore's dedicated biomedical research cluster, housing A*STAR research institutes, leading universities, and numerous biotech firms. Co-locating here provides immediate access to shared research infrastructure, collaborative networks, a concentrated talent pool of biomedical scientists, and proximity to clinical trial partners.

## Location 3
Singapore

Singapore Science Park

Singapore Science Park, one-north, Singapore

**Rationale**: Singapore Science Park offers purpose-built laboratory and office spaces designed specifically for research and technology enterprises, with established high-tech infrastructure suitable for advanced biomedical operations and proximity to the broader one-north ecosystem for collaboration.

## Location 4
Singapore

Jurong Innovation District

Jurong Innovation District, Singapore

**Rationale**: The Jurong Innovation District provides large-scale, modern facilities with significant room for expansion, including integrated manufacturing and research capabilities. This location could support future GMP manufacturing and therapeutic scale-up needs as the research program matures into clinical development.

## Location Summary
The plan explicitly targets Singapore for the Reverse Aging Research Lab due to its progressive biomedical regulatory framework, streamlined ethical approval processes, and world-class scientific infrastructure. The confirmed location is Singapore, with additional well-reasoned suggestions including the one-north biomedical research hub (for proximity to A*STAR institutes and collaborative research networks), Singapore Science Park (for purpose-built research infrastructure), and the Jurong Innovation District (for scalable facilities that could support future GMP manufacturing and therapeutic scale-up as the program advances from discovery to clinical deployment).