
## Risk 1 - Regulatory & Permitting
Despite Singapore's progressive biomedical regulatory framework, aging-reversal interventions represent an unprecedented regulatory category. The Human Biomedical Products Act and related frameworks may not have established precedents for 'cellular reversal' therapies, potentially leading to unexpected delays in ethical approval, clinical trial authorization, or novel regulatory pathway requirements. Over a 10-year horizon, regulatory frameworks may evolve in unpredictable ways, introducing new compliance burdens or restrictions on human trials for aging-modifying interventions.

**Impact:** Delays of 6–18 months in obtaining ethical approvals and clinical trial licenses, potentially pushing back the first human trial by a full year or more. Additional compliance costs of SGD 5–15 million for regulatory consultants, legal counsel, and expanded documentation. In worst-case scenarios, regulatory rejection of the aging-reversal framing could force the lab to reclassify its work, undermining the core mission and branding.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage Singapore's Health Sciences Authority (HSA) and ethics review boards proactively from project inception through pre-submission consultations. Establish a dedicated regulatory affairs team with expertise in both Singapore's biomedical regulatory framework and emerging international standards for aging-modifying therapies. Develop contingency regulatory pathways that could reclassify interventions as 'regenerative medicine' or 'novel therapeutic approaches' if aging-reversal framing faces resistance. Participate in international regulatory harmonization discussions to shape favorable precedents.

## Risk 2 - Financial
The SGD 500 million budget over 10 years faces multiple financial threats: construction cost inflation in Singapore's competitive biomedical real estate market, currency fluctuations affecting international procurement of specialized equipment, potential underestimation of operational costs for a facility of this scale, and the risk that scientific setbacks render continued spending unjustifiable. The 'Builder' strategy's blended funding model depends on securing private and partnership co-funding, which may not materialize at expected levels, leaving the core public commitment to absorb disproportionate costs.

**Impact:** Construction cost overruns of 15–25% (SGD 30–75 million) due to Singapore's high construction costs and specialized biomedical facility requirements. If private co-funding falls short by 20–30%, the public commitment would need to absorb SGD 50–100 million in additional burden. Operational cost overruns of SGD 10–20 million annually could erode the research budget. A 12–18 month delay in milestone achievement could trigger funding gaps of SGD 30–60 million under tranche-based arrangements.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a financial contingency reserve of at least 15% of total budget (SGD 75 million) held in a separate fund accessible only through governance-approved triggers. Implement quarterly financial reviews with independent audit oversight. Structure funding agreements with flexible milestone definitions that account for scientific uncertainty rather than rigid calendar-based triggers. Negotiate cost-escalation clauses with construction contractors and equipment vendors. Diversify funding sources across at least four distinct channels (government, private philanthropy, corporate partnerships, and international grants) to reduce dependency on any single source.

## Risk 3 - Technical
Cellular aging reversal is among the most scientifically uncertain endeavors in biomedical research. The fundamental biological mechanisms of aging are not fully understood, and no validated intervention has demonstrated safe, effective cellular reversal in humans. The lab's chosen modalities (cellular reprogramming, senolytics, metabolic interventions) each carry significant scientific risk: reprogramming carries oncogenic transformation risks, senolytics may have off-target effects, and metabolic interventions may not translate from model systems to humans. The biomarker validation hierarchy may fail to identify reliable surrogate endpoints, leaving the lab unable to demonstrate efficacy even if therapies show biological activity.

**Impact:** If the primary scientific hypothesis fails, up to SGD 150–250 million invested in the first 5 years could yield no clinically translatable results, requiring complete strategic pivots. Failed biomarker validation could delay clinical entry by 2–4 years. If reprogramming approaches trigger oncogenic events in human trials, the lab could face safety crises requiring full clinical holds, costing SGD 20–50 million in remediation and reputational damage. The entire 10-year timeline could be extended by 3–5 years if fundamental biological insights prove more elusive than anticipated.

**Likelihood:** High

**Severity:** High

**Action:** Implement the chosen 'Builder' strategy's externally reviewed go/no-go gates with strict, pre-defined biomarker benchmarks that must be independently replicated before advancing. Maintain a diversified modality portfolio (reprogramming, senolytics, metabolic) with no single modality receiving more than 40% of discovery funding in any phase. Establish a dedicated 'negative results' analysis team to rapidly identify and terminate failing hypotheses, redirecting resources to promising lines. Invest SGD 15–20 million in a comprehensive biomarker qualification program before initiating any human trials. Create scientific advisory boards with international experts who can provide independent assessment of scientific progress.

## Risk 4 - Operational
The operational complexity of establishing and running a state-of-the-art research facility housing multidisciplinary teams of biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists presents significant challenges. Facility readiness may lag behind team recruitment, creating a period where expensive talent is idle. Integration of diverse scientific disciplines with different methodologies, data formats, and publication cultures may prove more difficult than anticipated. The phased lease-and-retrofit approach, while financially prudent, may result in a facility that cannot accommodate all planned equipment and workflows, requiring costly reconfiguration.

**Impact:** Facility readiness delays of 3–9 months could leave recruited senior scientists idle, costing SGD 5–15 million in uncompensated salary and benefits during the gap period. Inadequate facility reconfiguration could require additional capital expenditure of SGD 10–30 million to retrofit spaces for specialized equipment. Cross-disciplinary integration failures could reduce research productivity by 20–40% in the first 2–3 years, effectively wasting SGD 30–60 million of research funding. Operational inefficiencies could add SGD 8–15 million annually to running costs.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt a 'facility readiness parallel track' that begins site preparation and lease negotiations 12–18 months before team recruitment begins, with milestone-based occupancy agreements that allow phased team arrival. Establish an integration management office (IMO) dedicated to cross-disciplinary coordination, with representatives from each scientific domain. Implement flexible laboratory design principles (modular walls, universal utility connections) that allow reconfiguration as research priorities shift. Conduct regular 'integration health checks' every quarter to identify and resolve cross-disciplinary workflow conflicts.

## Risk 5 - Talent Recruitment & Retention
Attracting and retaining a world-class multidisciplinary team of leading biogerontologists, geneticists, bioinformatics experts, and regenerative medicine specialists globally is a critical vulnerability. Singapore faces competition from established biomedical hubs (Boston, San Francisco, London, Tokyo) for top talent. Senior scientists may be reluctant to relocate to Singapore for a 10-year commitment, particularly given the scientific uncertainty of aging-reversal research. The hybrid talent model (anchor investigators + rotating project teams) may create tensions between established stars and early-career researchers, potentially leading to team fragmentation. Visa and immigration challenges for international researchers could delay team formation.

**Impact:** Failure to recruit even 2–3 key principal investigators could delay the research program by 1–2 years, costing SGD 50–100 million in delayed discovery output. Loss of a single anchor investigator mid-project could destabilize an entire research line, requiring SGD 15–30 million in replacement recruitment and ramp-up costs. Visa processing delays of 3–6 months for international hires could create critical skill gaps during the facility's startup phase. Team fragmentation could reduce research throughput by 25–35%, effectively wasting SGD 40–80 million over the project's lifetime.

**Likelihood:** Medium

**Severity:** High

**Action:** Create an attractive compensation package that includes SGD 500,000–1,000,000 signing bonuses for anchor investigators, equity participation in spin-out entities, and family relocation support. Establish partnerships with top-tier universities (MIT, Stanford, Oxford, Cambridge) for joint appointment programs that allow researchers to maintain dual affiliations. Develop a streamlined visa and work permit process through Singapore's Ministry of Manpower with dedicated support for biomedical researchers. Implement a 'rotating team' structure with clear career progression pathways that give early-career researchers tangible incentives to stay. Conduct annual talent satisfaction surveys and maintain a 'bench strength' pipeline of 3–5 candidates for each critical role.

## Risk 6 - Supply Chain
The lab's research activities depend on a complex global supply chain for specialized biomedical reagents, equipment, consumables, and pharmaceutical-grade materials. Critical items such as viral vectors for reprogramming, senolytic compounds, high-throughput screening equipment, and specialized sequencing reagents may face supply disruptions due to geopolitical tensions, manufacturing bottlenecks, or export controls. Singapore's reliance on imports for most specialized biomedical materials creates vulnerability to global supply chain disruptions similar to those experienced during the COVID-19 pandemic.

**Impact:** Supply disruptions for critical reagents or equipment could halt research programs for 2–6 months, costing SGD 20–50 million in delayed research output and potential sample loss. A 20–30% increase in procurement costs for specialized materials could consume SGD 15–30 million of the research budget over 10 years. Export controls on gene-editing technologies or viral vectors could prevent acquisition of essential tools, forcing the lab to develop alternatives at a cost of SGD 10–25 million and delaying research by 6–12 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish strategic reserves of critical reagents and consumables sufficient for 3–6 months of continuous operation. Diversify suppliers across at least 2–3 vendors for each critical category, including at least one regional (Asia-Pacific) supplier. Negotiate long-term supply agreements with price escalation caps for the most critical items. Develop in-house capabilities for the most supply-vulnerable reagents where feasible. Establish a supply chain risk monitoring system that tracks geopolitical, regulatory, and manufacturing developments affecting key suppliers.

## Risk 7 - Security
The lab will generate and store highly sensitive genomic, proteomic, and longitudinal clinical datasets that are attractive targets for cyberattacks, industrial espionage, and unauthorized access. The unique nature of aging-reversal research makes the lab a potential target for biosecurity threats, including theft of proprietary therapeutic methods, unauthorized replication of research, or deliberate sabotage. The lab's high-profile status as a 'global epicenter' increases its visibility as a target. Additionally, the dual-use nature of aging-reversal research (techniques that could be misapplied) creates biosecurity governance challenges.

**Impact:** A significant data breach could expose genomic and health data of thousands of research participants, resulting in regulatory fines of SGD 1–10 million under Singapore's Personal Data Protection Act (PDPA), plus reputational damage valued at SGD 50–100 million in lost partnerships and funding. Theft of proprietary therapeutic methods could cost the lab its competitive advantage, potentially reducing the value of any resulting intellectual property by SGD 100–200 million. A biosecurity incident could trigger international scrutiny, potentially leading to research restrictions or sanctions.

**Likelihood:** Low

**Severity:** High

**Action:** Implement a zero-trust cybersecurity architecture with end-to-end encryption for all genomic and clinical data, multi-factor authentication for all system access, and continuous security monitoring. Establish a dedicated biosecurity governance committee that reviews all research protocols for dual-use potential and implements appropriate containment measures. Conduct annual penetration testing and security audits by independent third parties. Develop a comprehensive incident response plan with predefined communication protocols for data breaches. Maintain cyber insurance coverage of at least SGD 20 million.

## Risk 8 - Environmental
The construction and operation of a state-of-the-art biomedical research facility carries environmental implications including energy consumption, waste generation (chemical, biological, and radioactive waste), water usage, and carbon footprint. Singapore's tropical climate requires significant energy for climate-controlled laboratory environments. The facility's high-throughput automation platforms, GMP manufacturing capabilities, and cryogenic storage systems will have substantial energy demands. Waste disposal from biomedical research, particularly genetically modified organisms and hazardous chemicals, must comply with Singapore's stringent environmental regulations.

**Impact:** Energy costs for the facility could reach SGD 3–8 million annually, significantly higher than standard commercial buildings due to 24/7 climate control, clean room operations, and specialized equipment. Waste disposal costs could amount to SGD 1–3 million annually. Failure to meet Singapore's environmental regulations could result in fines of SGD 500,000–2 million and potential operational restrictions. The facility's carbon footprint could attract environmental criticism, undermining the lab's public legitimacy and societal legitimacy strategy.

**Likelihood:** Medium

**Severity:** Low

**Action:** Design the facility to meet or exceed Singapore's Green Mark certification standards, incorporating energy-efficient HVAC systems, LED lighting, and smart building management systems. Invest in on-site waste treatment capabilities to reduce disposal costs and environmental impact. Implement a comprehensive sustainability plan that includes renewable energy procurement (solar panels on facility rooftops), water recycling systems, and waste minimization protocols. Conduct annual environmental impact assessments and publish sustainability reports as part of the public engagement strategy.

## Risk 9 - Social & Public Perception
Aging-reversal research sits at the intersection of profound scientific ambition and deep societal questions about equity, access, and the ethics of life-extension technologies. The lab's bold positioning as a 'global epicenter' of aging reversal could trigger public skepticism, religious opposition, and political backlash, particularly if early results are perceived as overpromised. Questions about equitable access to potentially expensive therapies could fuel narratives of 'anti-aging for the wealthy.' Singapore's multicultural society may have diverse views on life-extension technologies, and public opposition could destabilize the political support necessary for the SGD 500 million investment.

**Impact:** Public backlash could reduce political support for the initiative, potentially threatening future funding commitments of SGD 100–200 million beyond the initial investment. Negative media coverage could damage the lab's ability to recruit talent and attract partnerships, costing SGD 20–50 million in lost opportunities. If the lab is perceived as serving only the wealthy, it could face regulatory restrictions on human trials and public funding cuts. A major public controversy could delay the project by 1–2 years and cost SGD 30–60 million in crisis management and reputational recovery.

**Likelihood:** Medium

**Severity:** High

**Action:** Launch a proactive public engagement program from project inception, including transparent communication of research goals, timelines, and limitations. Establish a public advisory board comprising ethicists, patient advocates, community leaders, and religious representatives. Publish regular public-facing progress reports that honestly communicate both achievements and setbacks. Develop an equity framework that ensures access to therapies regardless of socioeconomic status, and communicate this commitment publicly. Partner with patient advocacy groups and aging-related disease communities to co-design research priorities and ensure the lab's work addresses populations most affected by age-related disease.

## Risk 10 - Intellectual Property & Commercialization
The lab's approach to intellectual property—balancing open-science credibility with commercial value—presents significant risks. If the lab adopts an overly open approach, it may fail to capture economic value from its discoveries, undermining Singapore's return on the SGD 500 million investment and reducing the lab's ability to attract commercial partnerships. If it adopts an overly proprietary approach, it may alienate the global scientific community whose collaborative input is essential for complex aging-reversal research. The choice of commercialization pathway (spin-out, licensing, or state-supported entity) carries governance complexity and may create conflicts between scientific mission and financial returns.

**Impact:** An overly open IP strategy could forfeit licensing revenue estimated at SGD 50–200 million over the decade, reducing Singapore's economic return on investment. An overly proprietary strategy could reduce collaborative publications by 30–50%, diminishing the lab's scientific credibility and talent attraction, potentially costing SGD 20–40 million in reduced research productivity. A failed spin-out could result in SGD 30–60 million in sunk costs and management distraction. Licensing disputes with partners could lead to litigation costs of SGD 5–15 million and delays of 1–2 years in therapeutic development.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt the tiered IP strategy that patents therapeutic applications and clinical-stage interventions while publishing foundational biogerontological research openly. Establish clear IP governance protocols that define ownership, licensing terms, and revenue-sharing arrangements for all collaborative research. Create a dedicated technology transfer office with expertise in both academic publishing and commercial licensing. Develop standardized material transfer agreements (MTAs) and collaboration agreements that balance openness with protection. Conduct annual IP portfolio reviews to assess the commercial potential of each discovery and adjust the strategy accordingly.

## Risk 11 - Data Sovereignty & Cross-Border Governance
The massive genomic, proteomic, and longitudinal clinical datasets generated by aging-reversal research span multiple jurisdictions and regulatory regimes. Singapore's data protection laws may conflict with international data transfer frameworks, particularly if the lab collaborates with institutions in the EU (subject to GDPR), the US, or other jurisdictions with differing privacy requirements. Centralizing all data in Singapore creates a single-point regulatory vulnerability, while distributing data across jurisdictions creates fragmentation and compliance complexity. International data transfer agreements may shift unfavorably over the 10-year horizon.

**Impact:** Non-compliance with international data protection regulations could result in fines of up to 4% of global turnover under GDPR (potentially SGD 20–50 million for a large organization). Data transfer restrictions could prevent collaboration with international partners, reducing research throughput by 15–30% and costing SGD 30–75 million in lost research value. A data sovereignty dispute could force the lab to restructure its collaborative network, requiring SGD 10–25 million in legal and technical remediation and delaying research by 6–12 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Implement a federated data architecture where raw genomic data remains at originating institutions and only aggregated, anonymized analyses are shared through the Singapore hub, preserving partner data sovereignty. Engage specialized international data law firms to monitor evolving data protection regulations across all partner jurisdictions. Establish data governance protocols that comply with the strictest applicable regulations (likely GDPR) as a baseline. Create a multi-jurisdictional data governance consortium with partner nations to establish shared legal frameworks. Invest SGD 5–10 million in secure data infrastructure that supports federated analysis while maintaining Singapore's analytical capabilities.

## Risk 12 - Market & Competitive
The longevity and anti-aging research field is rapidly attracting global investment, with major initiatives launched by Altos Labs (USD 3 billion), Calico (Alphabet subsidiary), Unity Biotechnology, and numerous academic centers worldwide. Singapore faces competition not only from well-funded private ventures but also from government-backed initiatives in Japan, the UK, the US, and China. The 'global epicenter' positioning requires the lab to establish first-mover advantage and scientific leadership before competitors consolidate their positions. If another jurisdiction establishes a more prominent aging-reversal research center, Singapore's initiative could be perceived as a follower rather than a leader, undermining its strategic positioning.

**Impact:** Loss of first-mover advantage could reduce the lab's ability to attract top talent (potentially 20–30% of target recruits choosing competitors) and partnerships, costing SGD 50–100 million in delayed or lost opportunities. If a competitor achieves a breakthrough first, the lab's SGD 500 million investment could be rendered less impactful, potentially reducing the value of its discoveries by 30–50%. Competitive pressure could force premature clinical trials or aggressive positioning that undermines scientific credibility, creating a cascade of reputational and financial consequences.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Accelerate the timeline for establishing the facility and recruiting core teams to create early momentum. Develop strategic partnerships with Singapore's existing biomedical ecosystem (A*STAR, National University of Singapore, Singapore General Hospital) to create an integrated research network that competitors cannot easily replicate. Establish a 'Singapore Aging Reversal Consortium' that brings together government, academia, and industry in a coordinated national effort. Engage in international scientific diplomacy to position Singapore as the preferred hub for aging-reversal research collaborations. Publish high-impact research aggressively to establish scientific leadership.

## Risk 13 - Integration with Existing Infrastructure
The lab's success depends on seamless integration with Singapore's existing biomedical research ecosystem, including A*STAR institutes, university hospitals, and biotech firms. Integration challenges could include incompatible data systems, conflicting governance structures, difficulties in sharing patient cohorts and clinical infrastructure, and institutional politics that slow decision-making. The co-location strategy at one-north, while advantageous, introduces dependencies on partner institutions' priorities and resource availability that may shift over the 10-year horizon.

**Impact:** Integration failures could reduce access to shared patient cohorts and clinical infrastructure, delaying clinical trial initiation by 6–12 months and costing SGD 20–40 million in delayed research. Governance conflicts with partner institutions could create decision-making paralysis, reducing research agility and potentially causing the lab to miss critical research windows. Incompatible data systems could require SGD 10–25 million in integration costs and ongoing maintenance of SGD 2–5 million annually.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish formal co-location agreements with clear governance structures, data-sharing protocols, and dispute resolution mechanisms at the outset. Create liaison positions embedded within partner institutions to facilitate communication and coordination. Invest in interoperable data systems and shared platforms that can integrate with partner infrastructure. Conduct annual partnership reviews to assess the health of collaborative relationships and identify emerging issues. Maintain a 'partnership health scorecard' that tracks access to shared resources, decision-making speed, and satisfaction levels.

## Risk 14 - Long-term Sustainability
The 10-year, SGD 500 million initiative must eventually transition to a self-sustaining model that continues beyond the initial funding period. The lab's long-term sustainability depends on generating revenue through therapeutic commercialization, licensing, or continued government funding. If no therapy reaches clinical deployment within the 10-year horizon, the lab faces an existential funding cliff. The facility's ongoing operational costs (estimated at SGD 30–60 million annually) must be covered by sustainable revenue streams, and the institution must maintain scientific relevance and institutional support beyond the initial investment period.

**Impact:** If no therapy reaches clinical deployment, the lab could face a funding gap of SGD 30–60 million annually after year 10, potentially requiring SGD 150–300 million in continued government support or leading to institutional closure. Failure to establish a sustainable commercialization pathway could mean the SGD 500 million investment yields no long-term economic return for Singapore. Loss of institutional support could result in the dispersal of the research team and the loss of all accumulated knowledge and infrastructure.

**Likelihood:** Medium

**Severity:** High

**Action:** Begin planning for long-term sustainability from year 1 by establishing a commercialization pathway for each therapeutic program. Develop a 'sustainability roadmap' that identifies potential revenue streams (licensing, spin-outs, therapeutic sales, continued government funding) and their projected timelines. Create a endowment fund that accumulates a portion of any commercial revenues to support ongoing operations. Establish relationships with venture capital and pharmaceutical partners who could provide continued funding for promising programs. Engage Singapore's government in long-term strategic planning for the facility's role in the national biomedical ecosystem.

## Risk 15 - Technology Platform & Automation
The lab's choice of technology platform—whether fully automated high-throughput screening, modular incremental automation, or external licensing—carries significant risks. Fully automated platforms require massive upfront capital and specialized technical talent that may be scarce in Singapore's current biotech ecosystem. These platforms may become obsolete as emerging aging-reversal paradigms shift the required experimental toolkit. Modular approaches may not achieve the throughput needed to compete globally. The platform choice also affects data quality, reproducibility, and the lab's ability to generate the large-scale datasets needed for biomarker validation.

**Impact:** A fully automated platform that becomes obsolete could represent a stranded investment of SGD 50–100 million, requiring complete platform replacement. Automation failures or downtime could reduce research throughput by 30–50%, costing SGD 20–40 million in delayed discoveries. Scarcity of specialized automation technicians in Singapore could lead to 3–6 month delays in platform deployment and ongoing reliance on expensive external support (SGD 3–8 million annually). Poor data quality from automation could invalidate research findings, requiring costly re-experimentation of SGD 10–25 million.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt the modular platform strategy that starts with flexible bench-space infrastructure and incrementally automates specific workflows as research priorities crystallize. Establish partnerships with automation technology providers who can offer upgrade paths and technology refresh programs. Invest in training programs for local automation technicians to reduce dependency on external support. Implement rigorous quality control protocols for all automated processes to ensure data reproducibility. Maintain a technology watch function that monitors emerging platforms and paradigms to inform future investment decisions.

## Risk 16 - Clinical Manufacturing & Scale-Up
If the lab's research programs succeed, the pathway from laboratory-scale discovery to GMP-compliant manufacturing for human trials presents significant challenges. Building integrated GMP manufacturing facilities early commits hundreds of millions in capital before any therapy has proven efficacy. Deferring manufacturing may slow clinical translation. The regulatory requirements for GMP manufacturing of aging-reversal therapies (particularly if they involve novel modalities like cellular reprogramming) may not be well-established, creating uncertainty in facility design and operational protocols.

**Impact:** Early GMP manufacturing investment could commit SGD 100–200 million before efficacy is proven, creating a sunk cost trap if therapies fail. If GMP manufacturing is deferred, clinical trial supply could be delayed by 6–12 months, costing SGD 15–30 million in delayed clinical progress and potentially missing regulatory windows. Non-compliance with GMP standards could result in clinical trial holds, regulatory penalties of SGD 5–20 million, and reputational damage that deters future partners and investors.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Adopt the pilot-scale manufacturing approach that builds capability sufficient for Phase I/II clinical trial supply, with a planned expansion pathway to full GMP scale contingent on therapeutic efficacy milestones. Engage GMP regulatory consultants from the earliest stages of facility design to ensure compliance with evolving standards. Establish partnerships with established contract development and manufacturing organizations (CDMOs) as a backup for clinical trial supply. Create a manufacturing readiness assessment process that triggers GMP investment only when specific efficacy and regulatory milestones are met.

## Risk summary
The most critical risks that could significantly jeopardize the project's success are: (1) **Scientific uncertainty and hypothesis failure** — Cellular aging reversal is among the most scientifically uncertain endeavors in biomedical research, and the high likelihood (medium-high) and high severity of fundamental scientific failure means that SGD 150–250 million could be at risk if primary hypotheses prove invalid. The Builder strategy's go/no-go gates and diversified modality portfolio partially mitigate this, but no governance structure can eliminate the fundamental uncertainty of the science. (2) **Financial sustainability and budget overrun** — The SGD 500 million budget faces multiple simultaneous threats including construction cost inflation, potential shortfalls in private co-funding, and operational cost overruns. A 15–25% construction overrun (SGD 30–75 million) combined with funding gaps from tranche-based arrangements could create a cascading financial crisis. (3) **Public perception and societal legitimacy** — The bold 'reverse aging' positioning creates a fundamental tension between attracting talent/funding and maintaining scientific credibility. Public backlash, ethical controversy, or perceptions of inequitable access could destabilize the political support necessary for the SGD 500 million investment and trigger regulatory restrictions. These three risks are interconnected: scientific setbacks amplify financial risks, which in turn intensify public scrutiny. The Builder strategy's adaptive governance, staged commitment, and balanced portfolio approach provides the best available framework for managing these interconnected risks, but active governance and continuous adaptation will be essential throughout the 10-year horizon.