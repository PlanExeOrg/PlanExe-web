**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential for uncontrolled spending, budget overruns, and compromised financial stability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO lacks the authority or resources to manage the materialized risk effectively, requiring strategic intervention.
Negative Consequences: Project delays, budget overruns, reputational damage, or project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO cannot reach a consensus on a critical vendor, requiring a higher-level decision to avoid delays.
Negative Consequences: Project delays, compromised quality, or increased costs due to unresolved vendor issues.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Strategic Alignment
Rationale: Significantly alters the project's objectives, budget, or timeline, requiring strategic re-evaluation.
Negative Consequences: Misalignment with strategic goals, budget overruns, project delays, or reduced ROI.

**Reported Ethical Concern**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation and Recommendation to Steering Committee
Rationale: Requires independent review and assessment to ensure ethical conduct and compliance.
Negative Consequences: Reputational damage, legal liabilities, loss of public trust, or project shutdown.

**Technical Advisory Group cannot agree on Technology Acquisition**
Escalation Level: Chief Scientific Officer (CSO)
Approval Process: CSO reviews the options and makes a final decision based on strategic research priorities.
Rationale: The TAG cannot reach a consensus on a critical technology, requiring a higher-level decision to avoid delays.
Negative Consequences: Project delays, compromised research, or increased costs due to unresolved technology issues.