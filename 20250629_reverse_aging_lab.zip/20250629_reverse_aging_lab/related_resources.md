## Suggestion 1 - Altos Labs

Altos Labs is a biotechnology company founded in January 2022 dedicated to cellular rejuvenation through partial reprogramming — the process of resetting epigenetic markers to reverse cellular aging. The company raised approximately $3 billion in its initial funding round from investors including Jeff Bezos, Yuri Milner, and Richard Klausner. It recruited Nobel laureate Shinya Yamanaka and leading biogerontologist Juan Carlos Izpisua Belmonte as core scientific leaders. Altos Labs operates across multiple global locations including the San Francisco Bay Area, Cambridge (UK), and San Diego, with the explicit mission of developing therapeutic interventions that reverse cellular aging and extend human healthspan. The company focuses on understanding and harnessing the mechanisms of cellular rejuvenation to develop transformative therapies.

### Success Metrics

Raised ~$3 billion in initial funding, demonstrating unprecedented investor confidence in aging-reversal science
Recruited globally recognized scientific leaders including a Nobel laureate (Shinya Yamanaka) and top-tier biogerontologists
Established multi-site global research infrastructure across San Francisco, Cambridge UK, and San Diego within 12 months of founding
Published foundational research on partial reprogramming and cellular rejuvenation in peer-reviewed journals
Built a multidisciplinary team spanning biogerontology, genetics, bioinformatics, and regenerative medicine
Established collaborative partnerships with leading academic institutions worldwide

### Risks and Challenges Faced

Scientific uncertainty: Cellular reprogramming carries oncogenic risks; ensuring safety while achieving rejuvenation remains an unresolved challenge
Talent competition: Competing with Calico, Unity Biotechnology, and academic centers for the same pool of top biogerontologists and geneticists
Regulatory novelty: No established regulatory pathway exists for 'cellular reversal' therapies, requiring novel frameworks
Public perception: Bold claims about reversing aging invite skepticism and scrutiny from the scientific community
Capital intensity: $3 billion in funding demands rapid scientific progress to justify continued investment
Geopolitical and funding risks: Dependence on private investors (Bezos, Milner) creates vulnerability to shifts in investor priorities

### Where to Find More Information

https://www.nature.com/articles/d41586-022-00045-6 (Nature article on Altos Labs founding and mission)
https://www.statnews.com/2022/01/19/altos-labs-bezos-aging-research/ (Stat News coverage of Altos Labs)
https://www.science.org/doi/10.1126/science.abq9805 (Science coverage of cellular rejuvenation research)
https://www.altoslabs.com (Official Altos Labs website)

### Actionable Steps

Contact Altos Labs' scientific leadership through their publicly listed research publications to understand their talent recruitment and team integration strategies
Reach out to their investor relations team via their official website to understand their funding architecture and milestone-linked commitment model
Engage with their regulatory affairs approach by reviewing their published papers on reprogramming safety and ethics frameworks
Study their multi-site facility strategy by examining their Cambridge UK and San Diego locations through LinkedIn and institutional partnerships
Connect with their scientific advisory board members through academic networks to understand go/no-go gate structures and biomarker validation approaches

### Rationale for Suggestion

Altos Labs is the single most directly comparable project to the Singapore Reverse Aging Research Lab initiative. It shares the core scientific mission of reversing cellular aging through reprogramming, operates at a comparable or larger scale ($3B vs $500M), recruits globally recognized multidisciplinary talent, and has established itself as a global hub for aging-reversal science. Its founding model — attracting top scientists with massive capital and building multi-site infrastructure — directly mirrors the Singapore project's ambition to recruit anchor investigators and build world-class facilities. The lessons from Altos Labs' rapid facility establishment, talent acquisition strategy, and scientific governance are directly transferable to the Singapore initiative, particularly regarding how to balance bold scientific ambition with rigorous evidence-based execution.
## Suggestion 2 - Calico (California Life Sciences Company)

Calico is a biotechnology and aging research company founded in 2013 as an Alphabet/Google subsidiary, headquartered in South San Francisco, California. Led by Arthur Levinson (former Apple chairman and Genentech CEO) and later by Hal Barron (former Genentech EVP), Calico's mission is to understand the biology of aging and intervene to extend human healthspan. The company has invested well over $1 billion in aging research, combining deep biological research with computational and data-driven approaches. Calico has established significant partnerships with academic institutions and pharmaceutical companies (notably a collaboration with AbbVie on aging and age-related diseases). Its research spans fundamental aging biology, biomarker development, and therapeutic intervention strategies, operating with a long-term research horizon that mirrors the 10-year timeline of the Singapore initiative.

### Success Metrics

Secured over $1 billion in Alphabet/Google funding, demonstrating sustained corporate commitment to aging research
Established partnerships with AbbVie and leading academic institutions for collaborative aging research
Built a multidisciplinary team of biologists, computational scientists, and clinical researchers
Published significant findings on aging biology including telomere biology, cellular senescence, and metabolic interventions
Developed research infrastructure combining wet-lab biology with AI/ML-driven discovery platforms
Maintained a 10+ year research horizon, demonstrating long-term commitment to aging biology

### Risks and Challenges Faced

Corporate governance tension: Operating as a subsidiary of Alphabet creates potential conflicts between scientific independence and corporate strategic priorities
Slow translation: Fundamental aging biology research has proven slower to yield clinical interventions than initially anticipated
Talent retention: Competing with Altos Labs, Unity Biotechnology, and academic centers for aging biology talent
Public visibility: High-profile corporate backing attracts scrutiny and raises expectations for rapid results
Regulatory uncertainty: Aging interventions lack established regulatory pathways, creating uncertainty for clinical translation
Scientific credibility: Balancing bold corporate-backed ambition with rigorous scientific standards

### Where to Find More Information

https://www.calicolabs.com (Official Calico website)
https://www.nature.com/articles/d41586-021-01792-9 (Nature article on Calico's research approach)
https://www.statnews.com/2018/07/23/calico-alphabet-aging-hal-barron/ (Stat News coverage of Calico leadership and strategy)
https://www.science.org/doi/10.1126/science.aaw7418 (Science article on Calico's aging research)

### Actionable Steps

Contact Calico's leadership team through their official website to understand their long-term funding architecture and how they balance corporate oversight with scientific independence
Study their AbbVie partnership model to understand how public-private partnerships can be structured for aging research
Reach out to their computational biology team to understand their AI/ML-driven discovery platform strategy
Engage with their academic partnership network to understand how they structure collaborative research agreements
Review their published research on aging biomarkers and intervention strategies to understand their biomarker validation hierarchy

### Rationale for Suggestion

Calico provides a critical comparative reference for the Singapore initiative because it demonstrates how a well-funded, long-term aging biology research organization operates within a corporate structure while maintaining scientific rigor. Its partnership model with AbbVie directly parallels the Singapore project's planned blended funding architecture (core public commitment + private partnership funding). Calico's experience with fundamental aging biology research over a 10+ year horizon provides valuable lessons on how to structure a discovery-to-validation pipeline that balances scientific patience with stakeholder expectations. Its computational biology approach also offers insights into the technology platform decisions the Singapore project must make.
## Suggestion 3 - The Buck Institute for Research on Aging

The Buck Institute, founded in 1999 in Novato, California, is one of the world's first dedicated research institutes focused exclusively on the biology of aging and age-related diseases. Established with a $50 million endowment and supported by the Buck Foundation, the institute operates a 488-acre campus with state-of-the-art laboratory facilities. The Buck Institute employs over 250 researchers and staff, organized into multidisciplinary research groups spanning biogerontology, genetics, proteomics, bioinformatics, and regenerative medicine. Its mission is to understand the mechanisms of aging and develop interventions that extend healthy lifespan. The institute has pioneered research on senescence, caloric restriction, mitochondrial function, and cellular reprogramming, and has established significant collaborative networks with academic institutions, pharmaceutical companies, and government agencies worldwide.

### Success Metrics

Established as one of the world's first dedicated aging research institutes, creating a model for purpose-built aging research facilities
Built a multidisciplinary research community of 250+ researchers across biogerontology, genetics, and bioinformatics
Published thousands of peer-reviewed papers establishing foundational aging biology knowledge
Developed collaborative partnerships with NIH, NASA, and numerous pharmaceutical companies
Created a 488-acre campus with specialized research facilities dedicated to aging biology
Established the model for how a standalone aging research institute can sustain long-term operations

### Risks and Challenges Faced

Funding sustainability: As a private foundation-funded institute, maintaining long-term financial stability requires continuous fundraising and endowment management
Scale limitations: With a smaller budget (~$30-40M annually) compared to the Singapore project, the Buck Institute has limited capacity for clinical translation
Talent competition: Competing with larger, better-funded institutions (Altos Labs, Calico) for top aging biology researchers
Clinical translation gap: The institute's focus on fundamental biology has limited its ability to translate discoveries into clinical interventions
Institutional isolation: Operating as a standalone institute without the ecosystem support of a larger university or government network
Public perception: Aging research has historically faced skepticism, requiring sustained public engagement to maintain legitimacy

### Where to Find More Information

https://www.buckinstitute.org (Official Buck Institute website)
https://www.nature.com/articles/d41586-019-03478-2 (Nature article on the Buck Institute's research model)
https://www.science.org/doi/10.1126/science.aax0098 (Science article on aging research at the Buck Institute)
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5904509/ (PubMed Central article on Buck Institute research outputs)

### Actionable Steps

Contact the Buck Institute's president or vice president of research to understand how they structure multidisciplinary research teams and manage go/no-go decisions
Study their facility design and campus planning to understand how a purpose-built aging research facility can be optimized for multidisciplinary collaboration
Reach out to their development office to understand their funding model and how they sustain long-term operations
Engage with their collaborative network to understand how they structure partnerships with universities, hospitals, and pharmaceutical companies
Review their public engagement strategies to understand how they build societal legitimacy for aging research

### Rationale for Suggestion

The Buck Institute provides the most directly relevant reference for the Singapore project's physical facility and organizational model. As one of the world's first purpose-built aging research institutes, it demonstrates how a dedicated facility can be designed to foster multidisciplinary collaboration among biogerontologists, geneticists, and bioinformaticians. Its 25-year history provides lessons on sustaining long-term aging research operations, managing endowment-style funding, and building collaborative networks. The Buck Institute's experience with fundamental discovery research and its challenges in clinical translation directly inform the Singapore project's discovery-to-validation sequencing decisions. Its campus model also provides insights into the facility build-versus-lease decision, as the Buck Institute chose to build a dedicated campus rather than lease existing space.
## Suggestion 4 - Unity Biotechnology

Unity Biotechnology is a clinical-stage biotechnology company founded in 2009 and headquartered in South San Francisco, California, focused on developing senolytic therapeutics — drugs that selectively clear senescent cells to treat age-related diseases. The company went public via IPO in 2018 and raised over $200 million in public market funding. Unity conducted multiple clinical trials including UNITY-001 (a Phase II trial of UBX0101 for osteoarthritis of the knee) and UNITY-K2 (a Phase II trial of UBX1325 for diabetic macular edema). The company has collaborated with leading academic institutions and pharmaceutical partners to advance senolytic biology from bench to bedside. Despite some clinical setbacks, including the discontinuation of certain trials due to insufficient efficacy, Unity has remained a leading example of translating aging biology into clinical practice and has contributed significantly to the scientific understanding of cellular senescence as a therapeutic target.

### Success Metrics

Successfully translated senolytic biology from fundamental research to clinical trials, demonstrating the feasibility of aging-targeted therapeutics
Conducted multiple Phase II clinical trials, generating real-world data on senolytic interventions in humans
Raised over $200 million in public market funding, demonstrating investor confidence in aging-targeted therapeutics
Published landmark papers on senolytic mechanisms and their therapeutic potential
Established collaborations with academic institutions and pharmaceutical companies for clinical development
Contributed to the FDA's evolving understanding of senolytic therapeutics as a novel therapeutic class

### Risks and Challenges Faced

Clinical trial failures: Several Unity trials failed to meet primary endpoints, demonstrating the difficulty of translating aging biology to clinical efficacy
Regulatory uncertainty: Senolytic therapeutics represent a novel therapeutic class with no established regulatory precedent
Market skepticism: Clinical setbacks led to significant stock price declines and investor skepticism
Scientific validation: The relationship between senescent cell clearance and clinical outcomes in humans remains incompletely understood
Funding pressure: As a public company, Unity faces quarterly performance pressure that conflicts with long-term research horizons
Talent retention: Clinical setbacks can demoralize research teams and make talent retention difficult

### Where to Find More Information

https://www.unitybiotech.com (Official Unity Biotechnology website)
https://www.clinicaltrials.gov (Search for Unity Biotechnology clinical trials on ClinicalTrials.gov)
https://www.nature.com/articles/d41586-020-01652-3 (Nature article on Unity Biotechnology's clinical progress)
https://www.fiercebiotech.com/unity-biotechnology (Fierce Biotech coverage of Unity Biotechnology)

### Actionable Steps

Contact Unity Biotechnology's clinical development team to understand how they structured their clinical trials and navigated regulatory pathways for a novel therapeutic class
Study their clinical trial failures and successes to understand how to design robust go/no-go gates for aging-reversal therapies
Reach out to their regulatory affairs team to understand how they engaged with the FDA on senolytic therapeutics
Engage with their investor relations team to understand how they managed public market expectations while conducting long-term aging research
Review their published clinical data to understand the biomarker validation challenges in aging therapeutics

### Rationale for Suggestion

Unity Biotechnology serves as a critical secondary reference because it provides real-world lessons on the clinical translation challenges that the Singapore project will inevitably face. Its experience with Phase II clinical trial failures demonstrates the importance of the Singapore project's go/no-go gate structure and biomarker validation hierarchy. Unity's regulatory navigation — working with the FDA on a novel therapeutic class (senolytics) — directly parallels the Singapore project's challenge of navigating unprecedented regulatory pathways for aging-reversal interventions. Its public market experience also provides cautionary lessons about the tension between bold positioning and scientific credibility, and the importance of managing stakeholder expectations. The Singapore project can learn from Unity's setbacks about the risks of premature clinical advancement and the need for rigorous evidence-based decision gates.

## Summary

The Singapore Reverse Aging Research Lab initiative ($500M, 10-year) is compared against four real, verifiable projects: (1) Altos Labs — the most directly comparable aging-reversal initiative at $3B scale, offering lessons on talent recruitment, multi-site infrastructure, and cellular reprogramming science; (2) Calico — Alphabet's aging biology subsidiary, offering lessons on long-term corporate-funded research, academic partnerships, and computational biology platforms; (3) The Buck Institute — the world's first purpose-built aging research institute, offering lessons on facility design, multidisciplinary team organization, and long-term endowment-based sustainability; and (4) Unity Biotechnology — a clinical-stage senolytic company, offering critical lessons on clinical trial execution, regulatory navigation for novel therapeutic classes, and the risks of premature clinical advancement. Together, these four references cover the full spectrum of strategic decisions the Singapore project must make: scientific mission alignment, research infrastructure design, funding architecture, clinical translation, and public-private partnership models.