
## Documents to Create

### 1. Project Charter

**ID:** 637d2dc3-c203-48d1-a01b-9072e0ffe717

**Description:** The foundational project management document that formally establishes the Reverse Aging Research Lab initiative in Singapore. It defines the project's purpose, scope, objectives, stakeholders, authority structure, and high-level boundaries. This charter anchors all subsequent planning documents and provides the mandate for the $500 million, 10-year initiative to establish Singapore as the global epicenter of longevity science. It references the Builder strategy as the chosen strategic approach and identifies the five Critical levers and eight High levers as the strategic decision framework governing the project.

**Responsible Role Type:** Project Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Singapore Public Sector Project Charter Framework

**Steps:**

- Define project purpose, goals, and measurable objectives aligned with the SMART criteria
- Identify and document all primary and secondary stakeholders with their roles and expectations
- Establish high-level scope boundaries including the 10-year horizon, $500M budget cap, and Singapore location requirement
- Define the project's authority structure referencing the future Board of Governors and Scientific Advisory Board
- Identify key dependencies including governance charter, facility lease, HSA engagement, and funding architecture
- Document major risks at a high level and the overall mitigation approach
- Obtain formal sign-off from the sponsoring authority (Singapore NRF/A*STAR) to formally charter the project

**Approval Authorities:** Singapore National Research Foundation (NRF) or Agency for Science, Technology and Research (A*STAR) as the primary government sponsor; Project Director with legal counsel

### 2. Strategic Framework: The Builder Strategy

**ID:** 3d345251-68e5-4895-a91e-081997ba876b

**Description:** The overarching strategic document that codifies the chosen strategic path (The Builder) for the Reverse Aging Research Lab. It articulates the strategic logic of adaptive governance, staged commitment, and balanced parallel research tracks. This document defines how the project will navigate the fundamental tensions of Speed vs. Scientific Rigor, Capital Commitment vs. Flexibility, and Talent Coherence vs. Star Power through externally reviewed go/no-go gates, blended funding, phased facility approaches, and hybrid talent models. It serves as the strategic umbrella under which all intervention-area frameworks operate.

**Responsible Role Type:** Strategic Planning Director

**Primary Template:** Strategic Framework Template (McKinsey/BCG-style)

**Secondary Template:** Singapore Public Policy Strategic Planning Framework

**Steps:**

- Synthesize the analysis from strategic_decisions.md and scenarios.md into a coherent strategic narrative
- Define the Builder strategy's core principles: adaptive governance, staged commitment, blended funding, phased facility approach, hybrid talent model
- Articulate the strategic logic connecting all five Critical levers and eight High levers into an integrated framework
- Define the decision-rights philosophy that underpins the go/no-go gate structure
- Establish the strategic rationale for why The Builder was chosen over The Pioneer and The Consolidator
- Define success metrics and strategic fit indicators (target: 8/10 fit score)
- Validate the strategic framework against the project's ambition, risk, complexity, and domain profile

**Approval Authorities:** Board of Governors (once constituted); Strategic Planning Director with Scientific Director

### 3. Governance Charter

**ID:** c46eb712-8feb-44a3-b2c3-840eff741078

**Description:** The formal governance document defining the Board of Governors (40% government, 30% private investors, 30% scientific leadership), the decision-rights matrix with SGD 25 million budget reallocation thresholds, and the independent Scientific Advisory Board (SAB) with binding veto power over go/no-go gate decisions. This document establishes voting mechanisms, conflict resolution protocols, escalation pathways, and succession protocols for key personnel. It resolves the governance paradox identified in the expert review by providing the structural foundation for all decision-making authority.

**Responsible Role Type:** Chief Risk & Governance Officer

**Primary Template:** Corporate Governance Charter Template

**Secondary Template:** Singapore Public-Private Partnership Governance Framework

**Steps:**

- Define the Board of Governors composition, voting rights, and meeting cadence (monthly during startup, transitioning to quarterly)
- Establish the decision-rights matrix specifying dollar thresholds for Board approval vs. scientific director authority
- Define the Scientific Advisory Board structure, member selection criteria, and binding veto power over go/no-go gates
- Create conflict resolution mechanisms including binding arbitration protocols
- Establish succession protocols for key personnel including anchor investigators
- Define the interim governance authority structure for the pre-charter period
- Draft dispute resolution mechanisms for disagreements between government, private investor, and scientific leadership representatives
- Obtain legal review and formal ratification by all governing bodies

**Approval Authorities:** Board of Governors (ratification); Singapore Ministry of Law (governance framework compliance); all three stakeholder groups (government, private investors, scientific leadership)

### 4. Baseline Assessment of Current State of Aging-Reversal Science and Singapore's Biomedical Research Ecosystem

**ID:** 094bf08a-13dd-42e7-a77f-04670ffad61c

**Description:** An initial baseline report establishing the current state of aging-reversal science, Singapore's biomedical research infrastructure, the competitive landscape, and the regulatory environment. This assessment provides the foundational data against which all strategic decisions are measured, including the current state of cellular reprogramming, senolytic, and metabolic intervention research; the maturity of Singapore's one-north biomedical ecosystem; the competitive positioning relative to Altos Labs, Calico, and other global initiatives; and the regulatory landscape under Singapore's Human Biomedical Products Act.

**Responsible Role Type:** Strategic Research Analyst

**Primary Template:** Current State Assessment Template (AS-IS Analysis)

**Secondary Template:** Singapore Biomedical Ecosystem Baseline Report Framework

**Steps:**

- Compile and analyze existing data on aging-reversal scientific progress, including biomarker validation status and preclinical evidence
- Assess Singapore's biomedical research infrastructure at one-north, including A*STAR institutes, NUS, and Singapore General Hospital capabilities
- Analyze the competitive landscape including Altos Labs ($3B), Calico, Unity Biotechnology, and the Buck Institute
- Evaluate Singapore's regulatory environment under the Human Biomedical Products Act for aging-reversal interventions
- Assess the global talent market for biogerontologists, geneticists, and bioinformaticians
- Review Singapore's funding ecosystem for biomedical research including government, private, and philanthropic channels
- Synthesize findings into a comprehensive baseline report identifying gaps, opportunities, and strategic implications

**Approval Authorities:** Scientific Director; Strategic Planning Director

### 5. Risk Management Framework

**ID:** 14058979-2cf4-4705-bccf-df6364f93888

**Description:** The comprehensive risk management document establishing the risk register, risk assessment methodology, mitigation strategies, and governance mechanisms for the $500 million initiative. It covers all 16 identified risks including scientific uncertainty (SGD 150-250M at risk), financial sustainability (15-25% construction overruns), public perception (SGD 100-200M threatened funding), regulatory uncertainty (6-18 month delays), and the critical gaps identified in the expert review (insurance, currency, governance). It defines risk ownership, monitoring cadence, and escalation protocols.

**Responsible Role Type:** Chief Risk & Governance Officer

**Primary Template:** PMI Risk Management Framework

**Secondary Template:** Singapore Government Risk Management Framework

**Steps:**

- Compile the comprehensive risk register from the pre-project assessment, including all 16 identified risks with impact/likelihood assessments
- Define risk assessment methodology including quantitative financial impact modeling and qualitative severity ratings
- Establish mitigation strategies for each risk category, including the 15% contingency reserve, go/no-go gates, and diversified portfolio
- Address the critical gaps identified in expert review: insurance and liability framework, currency risk management, and governance architecture
- Define risk monitoring cadence (quarterly reviews) and escalation protocols for high-severity risks
- Establish the dedicated risk financing reserve of SGD 75-100 million separate from the 15% contingency
- Create risk ownership assignments for each identified risk to specific C-suite roles
- Integrate risk management with the go/no-go gate structure and milestone-linked funding

**Approval Authorities:** Board of Governors; Chief Risk & Governance Officer with Finance Director

### 6. Stakeholder Engagement Plan

**ID:** 37c73fd0-9a4e-49d7-a73d-699876680aa8

**Description:** The strategic document defining how the project will engage, communicate with, and manage all primary and secondary stakeholders throughout the 10-year initiative. It covers the Singapore Government (NRF, A*STAR, MOH), Board of Governors, private investors, anchor investigators, partner universities (MIT, Stanford, Oxford, Cambridge), HSA, IRB, A*STAR institutes, NUS/Singapore General Hospital, CDMOs, patient advocacy groups, international regulatory bodies, automation technology providers, cybersecurity/insurance providers, the public advisory board, and global competitors. It defines engagement strategies, communication cadence, and relationship management mechanisms for each stakeholder group.

**Responsible Role Type:** Chief Communications & Public Engagement Officer

**Primary Template:** Stakeholder Engagement Plan Template (PMI)

**Secondary Template:** Singapore Government Stakeholder Engagement Framework

**Steps:**

- Identify and categorize all primary and secondary stakeholders from the project plan's stakeholder analysis
- Define engagement strategies for each stakeholder group including government (quarterly reports, annual strategic reviews), anchor investigators (one-on-one reviews, scientific retreats), private investors (quarterly updates, annual forums), and the public (sustained education campaign, advisory board)
- Establish communication cadence and reporting requirements for each stakeholder category
- Define the public advisory board structure including ethicists, patient advocates, community leaders, and religious representatives
- Create stakeholder mapping matrices showing influence, interest, and engagement level
- Establish mechanisms for managing stakeholder expectations around the bold 'global epicenter' positioning vs. scientific credibility
- Define conflict management approaches for competing stakeholder interests

**Approval Authorities:** Project Director; Chief Communications & Public Engagement Officer

### 7. Communication and Positioning Strategy

**ID:** 3b83e2aa-32d8-4d0a-8825-7435af8931b5

**Description:** The strategic document governing how the lab communicates its mission to the world, navigating the fundamental tension between bold 'reverse aging' branding that attracts talent, funding, and political support, and restrained scientific framing that preserves credibility. It defines the tiered communication strategy separating ambitious public narrative for ecosystem-building from evidence-anchored trial statements. It covers public engagement, societal legitimacy building, media relations, and the killer application biomarker validation hub positioning strategy.

**Responsible Role Type:** Chief Communications & Public Engagement Officer

**Primary Template:** Strategic Communication Plan Template

**Secondary Template:** Singapore Public Sector Communications Framework

**Steps:**

- Define the positioning strategy balancing bold 'global epicenter' branding with restrained scientific credibility
- Establish the tiered communication framework: ambitious public narrative vs. evidence-anchored trial statements
- Design the proactive public engagement program including transparent communication of goals, timelines, and limitations
- Define the public advisory board structure and meeting cadence with published minutes
- Create the equity framework ensuring access regardless of socioeconomic status
- Develop the killer application strategy positioning the lab as the field's authoritative biomarker validation hub
- Establish crisis communication protocols for scenarios where early results are ambiguous or negative
- Define the honest progress reporting framework communicating both achievements and setbacks

**Approval Authorities:** Board of Governors; Chief Communications & Public Engagement Officer with Scientific Director

### 8. High-Level Funding Architecture and Financial Framework

**ID:** bc736842-3ff9-4935-9376-2ba51ccabf6d

**Description:** The strategic document defining the blended funding architecture combining SGD 200-250 million core public/institutional commitment with private and partnership funding tied to specific therapeutic lines across at least four channels (government, private philanthropy, corporate partnerships, international grants). It establishes the 15% contingency reserve (SGD 75 million), milestone-linked disbursement discipline, quarterly independent audit oversight, and the foreign exchange risk management framework addressing SGD 30-50 million in realistic currency exposure. It defines the financial resilience architecture that supports the Builder strategy's adaptive governance.

**Responsible Role Type:** Chief Financial Officer

**Primary Template:** Blended Funding Architecture Framework Template

**Secondary Template:** Singapore Public-Private Partnership Financial Framework

**Steps:**

- Define the blended funding model specifying the SGD 200-250M core public commitment and private co-funding targets (20-30%)
- Establish the four-channel diversification strategy (government, private philanthropy, corporate partnerships, international grants)
- Design the milestone-linked disbursement structure aligned with externally reviewed go/no-go gates
- Define the 15% contingency reserve (SGD 75 million) management protocol in a segregated account
- Establish the foreign exchange risk management framework including forward contracts and currency hedging
- Create the quarterly financial review and independent audit oversight structure
- Define the currency risk reserve of SGD 25-40 million and treasury specialist engagement plan
- Establish the funding agreement structure and templates for private partnership agreements

**Approval Authorities:** Board of Governors; Chief Financial Officer with Singapore Ministry of Finance

### 9. Initial High-Level Schedule and Timeline Framework

**ID:** 7cd93881-b2c1-4006-bc15-881cdce9bdaa

**Description:** The strategic document establishing the 10-year phased timeline framework for the initiative, including facility lease and retrofit milestones, anchor investigator recruitment, HSA pre-submission consultation, first human trials (year 3-4), Phase I/II trials (years 5-8), and potential GMP-scale manufacturing readiness (years 8-10). It defines the externally reviewed go/no-go gate structure tied to specific assay benchmarks, with each gate reallocating budget between preclinical and clinical work rather than following a fixed schedule. It establishes the even funding distribution across discovery, validation, and clinical phases.

**Responsible Role Type:** Project Director

**Primary Template:** High-Level Project Schedule Template (MS Project/Primavera)

**Secondary Template:** Singapore Government Major Initiative Timeline Framework

**Steps:**

- Define the 10-year phased timeline with major milestones: facility lease (2026-Q4), core labs operational (2027-Q2), clinical suites ready (2027-Q4), anchor investigator recruitment (2026-Q4), HSA consultation (2026-Oct-05), first human trials (2029-2030)
- Establish the externally reviewed go/no-go gate structure with specific assay benchmarks and budget reallocation mechanisms
- Define the even funding distribution across discovery, validation, and clinical phases throughout the 10-year period
- Create the phased facility approach timeline aligning capital outlays with confirmed team arrivals and validated research priorities
- Establish the parallel research track timeline ensuring continuous progress across all fronts
- Define the manufacturing pathway timeline: pilot-scale Phase I/II capability with planned GMP expansion contingent on efficacy milestones
- Create the integration management office quarterly health check schedule
- Establish the 15% contingency reserve deployment timeline

**Approval Authorities:** Board of Governors; Project Director with Scientific Director

### 10. Monitoring, Evaluation, and Go/No-Go Gate Framework

**ID:** a1dc20fe-c5cf-4c43-8014-75e6ec0c072a

**Description:** The strategic document establishing the monitoring and evaluation architecture for the initiative, centered on the externally reviewed go/no-go gates that serve as the evidentiary gatekeeper between laboratory promise and clinical reality. It defines the tiered biomarker confidence framework from molecular signatures to functional and lifespan correlates, the surrogate endpoint acceptance criteria, and the specific assay benchmarks that determine pipeline progression. It establishes the 'negative results' analysis team, the biomarker qualification investment (SGD 15-20 million), and the independent Scientific Advisory Board's binding veto power over gate decisions.

**Responsible Role Type:** Scientific Director

**Primary Template:** M&E Framework Template (Logical Framework Approach)

**Secondary Template:** Singapore Biomedical Research M&E Framework

**Steps:**

- Define the go/no-go gate structure with specific assay benchmarks tied to each pipeline phase transition
- Establish the tiered biomarker confidence framework from epigenetic clocks to functional tissue assays to animal model longevity data
- Define surrogate endpoint acceptance criteria determining which biomarkers are admissible as clinical benefit proxies
- Establish the 'negative results' analysis team mandate and rapid termination protocols for failing hypotheses
- Define the biomarker qualification investment plan (SGD 15-20 million) and stress-testing methodology
- Establish the Scientific Advisory Board's evidence review process and binding veto power over gate decisions
- Create the pipeline velocity metrics and stakeholder communication cadence for gate outcomes
- Define the portfolio allocation reallocation mechanism triggered by gate decisions

**Approval Authorities:** Scientific Director; Scientific Advisory Board (binding veto); Board of Governors

### 11. Change Management Plan

**ID:** 503b385d-202c-49b6-bbb7-8c4e1178eb02

**Description:** The strategic document defining how the organization will manage the significant organizational change involved in establishing a new $500 million research institution, including the transition from project initiation to operational reality, the integration of diverse scientific disciplines (biogerontology, genetics, bioinformatics, regenerative medicine), the management of team tensions between anchor investigators and rotating project teams, and the evolution from a startup phase to a mature research institution. It addresses the cultural, structural, and personnel changes required over the 10-year horizon.

**Responsible Role Type:** Chief Talent & Integration Officer

**Primary Template:** Change Management Plan Template (Kotter/ADKAR)

**Secondary Template:** Singapore Public Sector Change Management Framework

**Steps:**

- Define the organizational change trajectory from project initiation to operational maturity over 10 years
- Establish the Integration Management Office (IMO) structure with quarterly integration health checks across all scientific domains
- Define strategies for managing the hybrid talent model tensions between autonomous star investigators and cohesive team models
- Create the cross-disciplinary integration workflows and shared data standards implementation plan
- Establish the bench-strength pipeline and succession planning for key personnel
- Define the change readiness assessment methodology and intervention strategies
- Create communication plans for organizational changes affecting team structure, reporting lines, and research priorities
- Establish metrics for measuring integration success and organizational cohesion

**Approval Authorities:** Chief Talent & Integration Officer; Project Director

### 12. Intellectual Property Strategy Framework

**ID:** ea132dbe-28c8-4df0-9b63-a0fc60ac7a30

**Description:** The strategic document defining the tiered IP architecture that patents therapeutic applications and clinical-stage interventions while publishing all foundational biogerontological research openly. It establishes the balance between open-science credibility and commercial value capture, defines the technology transfer office structure, and creates the IP governance protocols for managing patents across joint university appointments, collaborative network partnerships, and potential spin-out entities. It addresses the fundamental tension between aggressive patenting (which attracts commercial partners but risks alienating the scientific community) and fully open-access publication (which maximizes collaboration but forfeits licensing revenue).

**Responsible Role Type:** Chief Risk & Governance Officer

**Primary Template:** Tiered IP Strategy Framework Template

**Secondary Template:** Singapore Biomedical IP Strategy Framework

**Steps:**

- Define the tiered IP strategy: patent therapeutic applications and clinical-stage interventions while publishing foundational research openly
- Establish IP governance protocols for managing patents across joint university appointments and collaborative partnerships
- Define the technology transfer office structure and mandate for IP management and licensing
- Create standardized Material Transfer Agreements (MTAs) and data sharing protocols
- Establish the IP portfolio review cadence and patent prosecution strategy
- Define the IP implications of the collaborative network design and distributed consortium model
- Create the IP framework for potential spin-out entities and licensing to pharmaceutical partners
- Address the conflict between open-science commitments and proprietary data embargo needs for academic publication

**Approval Authorities:** Chief Risk & Governance Officer; Board of Governors; Technology Transfer Office

### 13. Regulatory and Ethics Strategy Framework

**ID:** 80c0b57b-7cf6-49f9-94dd-5d6abfe359a8

**Description:** The strategic document defining the lab's approach to regulatory engagement with Singapore's Health Sciences Authority (HSA) and Institutional Review Board (IRB), establishing the deliberately conservative ethics framework treating aging-reversal interventions as novel and high-uncertainty. It defines the contingency pathways to reclassify interventions as 'regenerative medicine' or 'novel therapeutic approaches' if the aging-reversal framing faces resistance, the dedicated regulatory affairs team structure (4-6 specialists), and the international regulatory harmonization strategy. It addresses the unprecedented regulatory category of 'cellular reversal' therapies under Singapore's Human Biomedical Products Act.

**Responsible Role Type:** Chief Regulatory & Ethics Officer

**Primary Template:** Regulatory Strategy Framework Template

**Secondary Template:** Singapore Biomedical Regulatory Strategy Framework

**Steps:**

- Define the deliberately conservative ethics framework requiring extended oversight, long follow-up, and explicit communication that reversal is not yet established
- Establish the HSA pre-submission consultation strategy including intervention classification analysis and contingency pathways
- Define the contingency reclassification pathways to 'regenerative medicine' or 'novel therapeutic approaches' with corresponding evidence requirements
- Establish the dedicated regulatory affairs team structure (4-6 specialists) and deployment timeline
- Create the international regulatory harmonization strategy identifying alternative jurisdictions and conditions for pursuing trials outside Singapore
- Define the informed consent framework addressing therapeutic misconception, long-term uncertainty, and biomarker vs. clinical reversal distinctions
- Establish the PDPA and GDPR compliance baseline for all genomic and clinical data handling
- Create the biosecurity governance committee structure with quarterly reviews

**Approval Authorities:** Chief Regulatory & Ethics Officer; HSA; IRB; Board of Governors

### 14. Facility and Infrastructure Strategy Framework

**ID:** 8191d64b-f654-4c98-9016-58ac9310b2a7

**Description:** The strategic document defining the physical infrastructure approach for the Singapore laboratory, governing the foundational Capital Commitment vs. Flexibility trade-off for the physical $500M infrastructure. It establishes the phased lease-and-retrofit strategy at the one-north biomedical research hub, aligning major capital outlays with confirmed team arrivals and validated research priorities rather than building everything at once. It defines the GMP manufacturing pathway from pilot-scale Phase I/II capability to full-scale expansion contingent on efficacy milestones, and addresses Singapore's tropical climate demands (SGD 3-8 million annually for climate control) and Green Mark certification requirements.

**Responsible Role Type:** Chief Operating Officer

**Primary Template:** Facility Strategy Framework Template

**Secondary Template:** Singapore Biomedical Facility Development Framework

**Steps:**

- Define the phased lease-and-retrofit strategy for 15,000-20,000 sq ft at one-north biomedical research hub
- Establish the capital deployment schedule aligning facility outlays with team arrivals and research priority validation
- Define the GMP manufacturing pathway: pilot-scale Phase I/II capability with planned expansion contingent on efficacy milestones
- Create the facility readiness timeline with core research labs operational by 2027-Q2 and clinical-grade suites by 2027-Q4
- Establish the modular instrumentation program that scales equipment up or down as therapeutic lines prove viable
- Define the Green Mark certification requirements and sustainability measures (energy-efficient HVAC, renewable energy, waste treatment)
- Create the facility integration requirements for modular automation platforms and federated data infrastructure
- Establish the contractor engagement strategy including GMP-experienced retrofit contractors

**Approval Authorities:** Chief Operating Officer; Board of Governors; Building and Construction Authority (BCA)

### 15. Talent and Organizational Strategy Framework

**ID:** f8114f5b-f9db-4e4f-bf5d-29ed73b0a06c

**Description:** The strategic document defining the hybrid talent recruitment model combining a few anchor investigators setting scientific direction with a larger cohort of early-to-mid-career researchers organized into rotating project teams. It establishes the global recruitment strategy for 3-5 anchor investigators (biogerontologists, geneticists, bioinformaticians) with SGD 500,000-1,000,000 signing bonuses and equity packages, the joint appointment partnerships with MIT, Stanford, Oxford, and Cambridge, the Ministry of Manpower streamlined visa processing, and the Integration Management Office structure for cross-disciplinary cohesion. It addresses the fundamental tension between star power and interdisciplinary convergence.

**Responsible Role Type:** Chief Talent & Integration Officer

**Primary Template:** Talent Strategy Framework Template

**Secondary Template:** Singapore Biomedical Talent Acquisition Framework

**Steps:**

- Define the hybrid talent model: anchor investigators setting scientific direction + rotating project teams of early-to-mid-career researchers
- Establish the global recruitment strategy for 3-5 anchor investigators with SGD 500K-1M signing bonuses, equity packages, and family relocation support
- Define the joint appointment partnership structure with at least four top-tier universities (MIT, Stanford, Oxford, Cambridge)
- Create the Ministry of Manpower streamlined biomedical visa processing strategy to prevent 3-6 month delays
- Establish the Integration Management Office (IMO) structure with quarterly integration health checks across all scientific domains
- Define the bench-strength pipeline and succession protocols for key personnel
- Create strategies for managing team tensions between established stars and rotating team members
- Establish the compensation benchmarking and retention strategies addressing global competition from Altos Labs and Calico

**Approval Authorities:** Chief Talent & Integration Officer; Project Director; Board of Governors

### 16. Funding Agreement Structure and Template

**ID:** 3f071470-286c-46cb-ae03-2c6bfe024b92

**Description:** The standardized template and structural framework for private partnership funding agreements, covering the terms, conditions, milestone-linked disbursement mechanisms, and governance rights for private investors and philanthropic partners contributing to the blended funding model. This document provides the legal and financial architecture for securing private co-funding across at least four channels, defining how milestone-linked tranches are structured, what constitutes satisfactory progress, and how investor rights interact with scientific autonomy.

**Responsible Role Type:** Chief Financial Officer

**Primary Template:** Blended Funding Agreement Template (Public-Private Partnership)

**Secondary Template:** Singapore Research Partnership Agreement Framework

**Steps:**

- Define the standard terms and conditions for private partnership funding agreements including milestone-linked disbursement mechanisms
- Establish the governance rights framework defining investor oversight vs. scientific autonomy boundaries
- Create the milestone-linked tranche structure with specific scientific and operational milestones triggering disbursement
- Define the investor reporting requirements and financial transparency obligations
- Establish the exit mechanisms and contingency provisions for scenarios where private co-funding falls short
- Create the intellectual property ownership and revenue-sharing provisions for privately funded research lines
- Define the dispute resolution mechanisms specific to funding agreements
- Obtain legal review and finalize template versions for different investor categories (philanthropic, corporate, venture capital)

**Approval Authorities:** Chief Financial Officer; Board of Governors; Singapore Attorney-General's Chambers (for public funding component)

### 17. Initial High-Level Budget and Resource Allocation Framework

**ID:** 1361e749-4220-4112-863c-46419b362c7c

**Description:** The high-level budget framework allocating the SGD 500 million across the 10-year initiative, defining the proportional distribution across discovery, validation, and clinical phases, the facility and infrastructure allocation, the talent and personnel budget, the technology platform investment, and the contingency reserve. This document provides the financial architecture that guides all subsequent detailed budgeting, establishing the 15% contingency reserve (SGD 75 million) and the four-channel funding diversification strategy at a summary level.

**Responsible Role Type:** Chief Financial Officer

**Primary Template:** High-Level Budget Framework Template (10-Year Horizon)

**Secondary Template:** Singapore Government Major Initiative Budget Framework

**Steps:**

- Define the high-level allocation across discovery (40-50%), validation (20-30%), and clinical phases (20-30%) over the 10-year horizon
- Establish the facility and infrastructure budget allocation including lease, retrofit, and GMP manufacturing pathway costs
- Define the talent and personnel budget including anchor investigator compensation (SGD 500K-1M signing bonuses), team salaries, and benefits
- Allocate the technology platform investment including modular automation and federated data infrastructure (SGD 5-10M)
- Establish the contingency reserve (SGD 75 million) and risk financing reserve (SGD 75-100 million) allocations
- Define the operational budget including insurance (SGD 8-15M annually), utilities (SGD 3-8M annually), and administrative costs
- Create the milestone-linked budget reallocation mechanism aligned with go/no-go gate decisions
- Establish the foreign exchange risk reserve (SGD 25-40 million) and currency hedging budget

**Approval Authorities:** Chief Financial Officer; Board of Governors; Singapore Ministry of Finance

### 18. Baseline Assessment of Singapore's Biomedical Regulatory Environment

**ID:** bea6014d-12d6-4874-a7db-51a0da451e00

**Description:** An initial assessment report analyzing Singapore's current biomedical regulatory environment, specifically evaluating how Singapore's Human Biomedical Products Act, HSA clinical trial authorization processes, and ethical review frameworks would apply to aging-reversal interventions. This baseline assessment identifies the regulatory gaps, classification challenges, and opportunities that the Regulatory and Ethics Strategy Framework must address, providing the raw analytical foundation for all regulatory planning.

**Responsible Role Type:** Chief Regulatory & Ethics Officer

**Primary Template:** Regulatory Environment Assessment Template

**Secondary Template:** Singapore Biomedical Regulatory Landscape Analysis Framework

**Steps:**

- Analyze the current classification of biomedical products under Singapore's HBPA and identify gaps for aging-reversal interventions
- Assess the HSA's pre-submission consultation process, timelines, and typical outcomes for novel therapeutic product classifications
- Evaluate Singapore's ethical review framework including IRB processes, informed consent requirements, and oversight mechanisms
- Identify precedent cases where HSA has classified novel or unprecedented biomedical interventions
- Assess the alignment between Singapore's regulatory framework and international standards (FDA, EMA, PMDA)
- Evaluate the potential for regulatory innovation or new pathways specific to aging-reversal interventions
- Identify the key regulatory risks and opportunities for the initiative
- Synthesize findings into a comprehensive baseline regulatory assessment report

**Approval Authorities:** Chief Regulatory & Ethics Officer; Scientific Director

## Documents to Find

### 1. Singapore Human Biomedical Products Act (HBPA) Full Legislation Text

**ID:** 2023925d-2d4b-48a4-a3f9-716a4bbdd03a

**Description:** The complete text of Singapore's Human Biomedical Products Act, which is the primary regulatory framework governing human biological products including cellular therapy products. This legislation is the foundational legal source needed to analyze how aging-reversal interventions might be classified, what regulatory pathways exist, and what evidentiary standards apply. It is the critical raw input for the Regulatory and Ethics Strategy Framework and the HSA pre-submission consultation strategy.

**Recency Requirement:** Current as of 2026, with all amendments through the most recent legislative session

**Responsible Role Type:** Chief Regulatory & Ethics Officer

**Access Difficulty:** Easy

**Steps:**

- Access Singapore's Statutes Online portal (sso.agc.gov.sg) to retrieve the full HBPA text
- Download all associated regulations and subsidiary legislation under the HBPA
- Review HSA's guidelines on registration of cellular therapy products referenced in the HBPA
- Obtain any recent amendments or proposed amendments to the HBPA related to novel therapeutic products
- Cross-reference with the WHO's 'Regulatory Considerations on Human Cells and Tissues Products' for international context

### 2. Singapore Health Sciences Authority (HSA) Clinical Trial Authorization Guidelines

**ID:** 9cd8f138-9260-47cf-80e8-6cdaf5d0308c

**Description:** The official HSA guidelines and regulatory frameworks governing clinical trial authorization in Singapore, including requirements for novel biological products, cellular therapy products, and regenerative medicine interventions. These guidelines are the raw regulatory source material needed to understand the pre-submission consultation process, evidentiary requirements for trial authorization, and the classification criteria that will determine how aging-reversal interventions are regulated.

**Recency Requirement:** Current as of 2026, reflecting the most recent HSA guidance updates

**Responsible Role Type:** Chief Regulatory & Ethics Officer

**Access Difficulty:** Medium

**Steps:**

- Access the HSA website (hsa.gov.sg) and navigate to the Clinical Trials and Research Involving Human Subjects section
- Download the HSA's 'Guidelines on Clinical Trial Authorization' and any related guidance documents
- Retrieve HSA's 'Guidelines on Registration of Cellular Therapy Products'
- Obtain any HSA advisory correspondence or guidance notes on novel therapeutic product classifications
- Review HSA's pre-submission consultation process documentation and requirements

### 3. Singapore Personal Data Protection Act (PDPA) and GDPR Compliance Requirements

**ID:** de2747db-5492-4260-b9d9-797d78f84e64

**Description:** The full text of Singapore's Personal Data Protection Act (PDPA) and the EU General Data Protection Regulation (GDPR) as they apply to genomic and clinical data handling, cross-border data transfers, and biomedical research data governance. These are the raw legal source materials needed to design the federated data architecture and establish the data sovereignty governance framework.

**Recency Requirement:** Current as of 2026, including all recent amendments to PDPA and GDPR enforcement decisions

**Responsible Role Type:** Chief Technology & Data Officer

**Access Difficulty:** Easy

**Steps:**

- Access Singapore's PDPC website (pdpc.gov.sg) to retrieve the PDPA text and associated guidelines
- Download the EU GDPR text and relevant European Data Protection Board (EDPB) guidelines
- Retrieve PDPC's 'Guidelines on Personal Data Protection in Clinical Research'
- Obtain any cross-border data transfer framework documentation from both PDPC and EU authorities
- Review recent enforcement decisions and penalty cases for data breach precedents

### 4. Singapore One-North Biomedical Research Hub Infrastructure and Leasing Data

**ID:** c26af41b-9e7d-4138-afad-7b391f10e3a1

**Description:** Comprehensive data on the one-north biomedical research hub including Biopolis, Singapore Science Park, and Jurong Innovation District, covering available laboratory space, leasing terms, infrastructure specifications, rental rates, and occupancy status. This is the raw source material needed for the facility strategy decision and the phased lease-and-retrofit planning.

**Recency Requirement:** Current as of 2026 Q3, with up-to-date leasing availability and pricing information

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Medium

**Steps:**

- Contact JTC Corporation (JTC) for one-north biomedical zone leasing availability and terms
- Access CapitaLand and Mapletree commercial property databases for Biopolis and Singapore Science Park listings
- Request information from A*STAR regarding shared infrastructure and co-location opportunities at one-north
- Obtain comparative leasing data for alternative locations (Singapore Science Park, Jurong Innovation District)
- Retrieve building specifications, floor plate sizes, and MEP infrastructure details for candidate facilities

### 5. Global Aging-Reversal Research Landscape and Competitive Intelligence Data

**ID:** 1ec13430-7f00-422c-b193-9f7314ce52b3

**Description:** Comprehensive data on the global competitive landscape for aging-reversal research, including information on Altos Labs ($3B funding, Shinya Yamanaka, Juan Carlos Izpisua Belmonte), Calico (Alphabet subsidiary, Arthur Levinson, Hal Barron), Unity Biotechnology (senolytic clinical trials), the Buck Institute (purpose-built aging research facility), and other relevant initiatives. This is the raw source material for competitive analysis, talent market assessment, and strategic positioning.

**Recency Requirement:** Current as of 2026, with the most recent funding rounds, publications, and strategic developments

**Responsible Role Type:** Strategic Research Analyst

**Access Difficulty:** Medium

**Steps:**

- Access Nature, Science, and Stat News archives for recent coverage of Altos Labs, Calico, and Unity Biotechnology
- Retrieve Altos Labs' published research papers and institutional announcements via their official website
- Access Calico's published research and partnership announcements through their official channels
- Review Unity Biotechnology's clinical trial data on ClinicalTrials.gov and published results
- Obtain the Buck Institute's research outputs and facility information from their official website
- Compile data on emerging competitors including government-backed initiatives worldwide

### 6. Singapore Biomedical Research Funding and Investment Statistics

**ID:** 730ae9a6-b1a5-4c21-86aa-6e5e921a2315

**Description:** Official statistical data on Singapore's biomedical research funding ecosystem, including government expenditure on biomedical research through NRF and A*STAR, private sector investment in Singapore biotech, philanthropic funding for biomedical research, and international grant flows. This is the raw source material for designing the blended funding architecture and assessing the feasibility of the SGD 200-250 million core public commitment and private co-funding targets.

**Recency Requirement:** Most recent available year (2024-2025 data preferred), with historical trends for the past 5 years

**Responsible Role Type:** Chief Financial Officer

**Access Difficulty:** Medium

**Steps:**

- Access Singapore's Ministry of Finance data on research and development expenditure
- Retrieve NRF and A*STAR annual reports and funding allocation data
- Obtain Singapore Economic Development Board (EDB) biomedical sector investment statistics
- Access Singapore's Department of Statistics (SingStat) databases on R&D spending and biotech sector data
- Review private equity and venture capital investment data for Singapore biomedical startups
- Compile data on international grant funding available for aging research through NIH, ERC, and other sources

### 7. Singapore Talent Market and Compensation Benchmarks for Biogerontologists

**ID:** e55b3633-a026-41f8-a761-59dc1cb4545b

**Description:** Comprehensive data on the global and Singapore-specific talent market for biogerontologists, geneticists, bioinformaticians, and regenerative medicine specialists, including compensation benchmarks, signing bonus structures, academic-industry salary differentials, visa processing timelines, and competition from Altos Labs, Calico, and academic institutions. This is the raw source material for the talent recruitment strategy and compensation framework.

**Recency Requirement:** Current as of 2026, with the most recent compensation surveys and talent market reports

**Responsible Role Type:** Chief Talent & Integration Officer

**Access Difficulty:** Medium

**Steps:**

- Access Singapore's Ministry of Manpower (MOM) work pass and employment pass data including processing timelines
- Retrieve compensation benchmarking data from sources like Radford, Mercer, or Aon for biomedical research roles
- Obtain data on academic-industry salary differentials for biogerontologists and related disciplines
- Access LinkedIn and industry reports on talent mobility patterns for aging research scientists
- Review joint appointment models at MIT, Stanford, Oxford, and Cambridge for dual-affiliation compensation structures
- Compile data on visa processing timelines for biomedical talent through Singapore's streamlined channels

### 8. Aging-Reversal Biomarker Validation Studies and Epigenetic Clock Data

**ID:** 9b7987e6-dfb3-4a78-b773-d544db17a27c

**Description:** The published scientific literature and datasets on aging biomarkers including epigenetic clocks (Horvath, Hannum, GrimAge), functional tissue assays, animal model longevity data, and senolytic biomarker validation studies. This is the raw scientific source material needed to design the biomarker validation hierarchy, define surrogate endpoint acceptance criteria, and establish the evidentiary thresholds for go/no-go gates.

**Recency Requirement:** Most recent publications from 2024-2026, with foundational studies included for context

**Responsible Role Type:** Scientific Director

**Access Difficulty:** Medium

**Steps:**

- Search PubMed and Google Scholar for recent publications on epigenetic clock validation and aging biomarkers
- Retrieve the original Horvath, Hannum, and GrimAge epigenetic clock papers and their validation studies
- Access published data on senolytic biomarker validation including p16INK4a, SA-beta-gal, and SASP markers
- Obtain animal model longevity data from published studies on partial reprogramming, senolytic clearance, and metabolic interventions
- Review the biomarker qualification literature including frameworks for surrogate endpoint validation
- Compile data on functional tissue assays and their correlation with lifespan outcomes

### 9. International Regulatory Frameworks for Aging Interventions (FDA RMAT, EMA ATMP)

**ID:** 45567f1c-9fb6-4160-9df8-527307f96faa

**Description:** The regulatory frameworks from major international jurisdictions including the FDA's Regenerative Medicine Advanced Therapy (RMAT) designation pathway, the EMA's Advanced Therapy Medicinal Products (ATMP) regulation, and Japan's PMDA frameworks for regenerative medicine. These are the raw regulatory source materials needed to design the international regulatory harmonization strategy and contingency pathways if Singapore's HBPA cannot accommodate aging-reversal interventions.

**Recency Requirement:** Current as of 2026, reflecting the most recent regulatory guidance updates

**Responsible Role Type:** Chief Regulatory & Ethics Officer

**Access Difficulty:** Medium

**Steps:**

- Access the FDA's RMAT designation guidance and recent designation decisions for aging-related therapies
- Retrieve the EMA's ATMP regulation and guideline documents for advanced therapy medicinal products
- Obtain Japan's PMDA guidelines on regenerative medicine products and conditional approval pathways
- Review ICH E6(R3) Good Clinical Practice guidelines and E8(R1) clinical trial design guidelines
- Compile comparative analysis of regulatory pathways for novel biological products across jurisdictions
- Review WHO guidance on regulatory considerations for human cells and tissues products

### 10. Singapore Green Mark Certification Requirements and Building Regulations

**ID:** 562e1a1f-b27c-4ce7-b588-76e42dbc7d47

**Description:** The official Green Mark certification standards from Singapore's Building and Construction Authority (BCA), including requirements for laboratory buildings, energy efficiency standards, and sustainability certification processes. This is the raw source material for the facility sustainability strategy and Green Mark certification planning.

**Recency Requirement:** Current as of 2026, reflecting the most recent Green Mark version and BCA requirements

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Easy

**Steps:**

- Access the BCA Green Mark website for the latest certification standards and requirements
- Retrieve the Green Mark for Laboratories scheme documentation
- Obtain BCA building regulations for biomedical laboratory facilities including fire safety, ventilation, and waste management requirements
- Download Green Mark certification application processes, fees, and timeline information
- Review case studies of Green Mark certified biomedical facilities in Singapore
- Compile Singapore's tropical climate-specific requirements for climate-controlled laboratory environments

### 11. Singapore Clinical Trial Insurance Market Data and Biomedical Coverage Requirements

**ID:** 20b3de2c-0eb2-4be6-82f8-891a0e0364a1

**Description:** Data on the Singapore and Asia-Pacific clinical trial insurance market, including premium estimates for novel biological therapy trials, participant compensation fund structures, and HSA-mandated insurance requirements for clinical trial authorization. This is the raw source material for structuring the comprehensive insurance and liability coverage framework.

**Recency Requirement:** Current as of 2026, with the most recent insurance market reports and premium benchmarks

**Responsible Role Type:** Chief Risk & Governance Officer

**Access Difficulty:** Hard

**Steps:**

- Contact specialized biomedical insurance brokers (Marsh Singapore, Aon, WTW) for preliminary coverage indications
- Retrieve Singapore's insurance regulatory requirements for clinical trial coverage from MAS
- Obtain international benchmarks for clinical trial insurance premiums for novel biological products
- Access case studies of insurance structures for comparable aging-reversal or gene therapy programs
- Review HSA's specific insurance and participant protection requirements for clinical trial authorization
- Compile data on captive insurance and risk retention structures for novel intervention classes

### 12. Singapore A*STAR Research Ecosystem and Collaborative Infrastructure Data

**ID:** 7fe068ea-6e27-4962-834b-855ce265462f

**Description:** Comprehensive data on Singapore's Agency for Science, Technology and Research (A*STAR) ecosystem including the Biomedical Research Council (BMRC), the Genome Institute of Singapore (GIS), the Institute of Medical Biology (IMB), and collaborative infrastructure at Biopolis. This is the raw source material for the collaborative network design, institutional partnership structure, and integration with existing biomedical research capabilities.

**Recency Requirement:** Current as of 2026, with the most recent A*STAR annual reports and research capability assessments

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Medium

**Steps:**

- Access A*STAR's official website and retrieve annual reports, research capability descriptions, and organizational structure
- Obtain information on A*STAR's Biomedical Research Council (BMRC) research programs and facilities
- Retrieve data on A*STAR's collaborative agreements with industry partners and international institutions
- Access information on the Genome Institute of Singapore (GIS), Institute of Medical Biology (IMB), and other A*STAR research institutes
- Obtain data on A*STAR's technology transfer and commercialization activities
- Review A*STAR's co-location and partnership models for external research organizations

### 13. Singapore Economic Indicators and Investment Climate Data

**ID:** caa9ed55-ba8c-49c7-9353-52ea114abcd5

**Description:** Official Singapore economic data including GDP growth, investment climate indicators, government research and development expenditure as a percentage of GDP, and biomedical sector economic contribution data. This is the raw source material for assessing Singapore's capacity to sustain the $500 million initiative and for the long-term sustainability planning beyond year 10.

**Recency Requirement:** Most recent available year (2024-2025), with 5-year historical trends

**Responsible Role Type:** Chief Financial Officer

**Access Difficulty:** Easy

**Steps:**

- Access Singapore Department of Statistics (SingStat) for GDP, R&D expenditure, and economic indicators
- Retrieve Singapore's Research and Development Survey data including biomedical sector contributions
- Obtain Ministry of Trade and Industry data on Singapore's economic outlook and investment climate
- Access data on Singapore's position as a biomedical hub including biotech company registrations and employment data
- Review Singapore's national research strategy documents and future R&D investment plans
- Compile data on Singapore's intellectual property creation and commercialization metrics

### 14. GMP Manufacturing Standards and ICH Guidelines for Novel Biological Products

**ID:** fa5c84f7-da72-4226-840c-9ea7284d60e8

**Description:** The complete set of Good Manufacturing Practice (GMP) standards and ICH guidelines applicable to novel biological products including cellular therapy products, covering EU GMP Annex 1, ICH Q7 (GMP for Active Pharmaceutical Ingredients), and ICH Q10 (Pharmaceutical Quality System). This is the raw regulatory source material for designing the GMP manufacturing pathway and pilot-scale manufacturing capability.

**Recency Requirement:** Current as of 2026, reflecting the most recent ICH guideline updates and GMP revisions

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Medium

**Steps:**

- Access the ICH website for current Q-series guidelines including Q7, Q10, and Q9 (Quality Risk Management)
- Retrieve EU GMP Annex 1 (Manufacture of Sterile Medicinal Products) and any recent revisions
- Obtain Singapore HSA's GMP guidelines for biomedical products and manufacturing facilities
- Download FDA GMP regulations (21 CFR Parts 210, 211) and EU GMP guidelines
- Review GMP requirements specific to cellular therapy products and gene therapy products
- Compile data on CDMO partnership structures and GMP compliance requirements for contract manufacturing

### 15. Singapore Building and Construction Authority (BCA) Regulations and Permit Requirements

**ID:** a7ef2e06-3d56-4824-ae4e-2c6f79910f50

**Description:** The official BCA building regulations, construction permit requirements, and renovation guidelines applicable to biomedical laboratory facilities in Singapore, including structural requirements, fire safety codes, environmental impact assessment requirements, and renovation permit processes for leased commercial space. This is the raw source material for the facility lease and retrofit planning.

**Recency Requirement:** Current as of 2026, reflecting the most recent BCA building code updates

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Easy

**Steps:**

- Access the BCA website (bca.gov.sg) for building regulations, codes, and permit requirements
- Retrieve BCA's renovation and addition guidelines for commercial and biomedical buildings
- Obtain information on building permit application processes, timelines, and fees
- Download BCA's sustainability requirements and Green Mark certification processes
- Review BCA requirements for laboratory-specific building modifications including HVAC, waste management, and biosafety
- Compile data on typical construction and renovation costs for biomedical facilities in Singapore

### 16. Singapore Ministry of Manpower Work Pass and Employment Visa Regulations for Biomedical Talent

**ID:** ec241fcb-0b95-4fdb-9237-2300ed08138d

**Description:** The official regulations and processing guidelines from Singapore's Ministry of Manpower (MOM) covering Employment Pass, S Pass, and Work Permit categories applicable to international biomedical researchers, including processing timelines, eligibility criteria, salary thresholds, and the streamlined biomedical channel. This is the raw regulatory source material for the talent recruitment strategy and visa processing planning.

**Recency Requirement:** Current as of 2026 Q3, reflecting the most recent MOM policy updates

**Responsible Role Type:** Chief Talent & Integration Officer

**Access Difficulty:** Easy

**Steps:**

- Access the Ministry of Manpower website (mom.gov.sg) and retrieve Employment Pass eligibility criteria and application procedures
- Download the MOM's guidelines on the Biomedical Sciences Work Pass framework if applicable
- Obtain current processing timelines for Employment Pass applications for foreign researchers
- Retrieve salary threshold requirements and quota limitations for foreign talent in Singapore
- Access information on the Overseas Networks & Expertise (ONE) Pass and other relevant visa categories
- Review any recent changes to Singapore's immigration policies affecting biomedical researchers

### 17. Singapore Building Construction Cost Data and Biomedical Facility Retrofit Estimates

**ID:** f1ee3c0c-43b8-4295-9245-16bddcec1858

**Description:** Current construction cost data for Singapore including per-square-foot costs for biomedical laboratory construction and retrofit, material costs, labor rates, and typical project timelines for phased facility development. This is the raw source material for the facility build-versus-lease decision and the financial risk assessment around construction cost overruns (15-25%).

**Recency Requirement:** Current as of 2026 Q3, with the most recent construction cost indices and market data

**Responsible Role Type:** Chief Operating Officer

**Access Difficulty:** Medium

**Steps:**

- Access Singapore construction cost indices from sources like the Building and Construction Authority (BCA) or RICS Singapore
- Retrieve per-square-foot cost data for biomedical laboratory construction and retrofit in Singapore
- Obtain quotes or estimates from GMP-experienced facility retrofit contractors for the one-north area
- Access data on construction material costs, labor rates, and supply chain conditions in Singapore's construction market
- Review historical construction cost escalation data for Singapore biomedical facilities
- Compile data on typical phased construction timelines and cost escalation clauses

### 18. Global Aging Research Publication and Scientific Output Data

**ID:** a5e88a13-4988-492a-9102-e0fc6de238fe

**Description:** Comprehensive bibliometric and scientific output data on global aging research including publication volumes, citation patterns, research collaboration networks, and emerging scientific paradigms in biogerontology, cellular reprogramming, senolytic biology, and metabolic interventions. This is the raw scientific source material for the academic publication cadence strategy and the scientific positioning of the lab.

**Recency Requirement:** Most recent 3-5 years of publication data (2021-2026), with historical trends for context

**Responsible Role Type:** Scientific Director

**Access Difficulty:** Medium

**Steps:**

- Access Web of Science or Scopus databases for bibliometric analysis of aging research publications
- Retrieve data on publication volumes and citation patterns for cellular reprogramming, senolytic, and metabolic aging research
- Obtain data on global research collaboration networks in aging biology
- Access data on the most impactful journals and publication venues for aging research
- Retrieve data on open-access vs. subscription publication trends in biomedical aging research
- Compile data on emerging scientific paradigms and paradigm shifts in biogerontology

### 19. Singapore Clinical Trial Insurance Market Premium Estimates and Coverage Structures

**ID:** fa2d3f2b-af04-4756-b011-3de6e06102b0

**Description:** Preliminary insurance market data including premium estimates, coverage structures, and underwriting requirements for clinical trial insurance covering novel biological products and cellular therapy products in Singapore and the Asia-Pacific region. This is the raw source material for structuring the comprehensive insurance and liability coverage framework, including clinical trial insurance (minimum SGD 500M aggregate), professional indemnity, D&O insurance, and product liability.

**Recency Requirement:** Current as of 2026, with the most recent insurance market reports and premium benchmarks for novel therapies

**Responsible Role Type:** Chief Risk & Governance Officer

**Access Difficulty:** Hard

**Steps:**

- Contact specialized biomedical insurance brokers (Marsh Singapore Life Sciences, Aon Clinical Trial Insurance, WTW Biomedical Risk Solutions) for preliminary premium estimates
- Retrieve international benchmarks for clinical trial insurance premiums for novel cellular therapy programs
- Obtain data on participant no-fault compensation fund structures and costs from comparable programs
- Access Singapore's insurance regulatory requirements for clinical trial coverage from MAS
- Review case studies of insurance structures for gene therapy and regenerative medicine trials
- Compile data on captive insurance and risk retention structures for novel intervention classes