## 1. HSA Regulatory Classification & Pre-Submission Strategy

The HSA classification determination is the single most critical project gate; every downstream decision (ethics protocol, endpoints, GMP specs, insurance, biomarker thresholds) flows from it. Proceeding without validated classification assumptions risks SGD 50-100 million in misdirected commitments and 6-18 month delays.

### Data to Collect

- HSA's current classification precedents for cellular therapy, gene therapy, and novel biological products under the Human Biomedical Products Act
- Specific evidentiary requirements, trial design implications, and licensing pathways for each plausible classification scenario
- HSA's formal insurance and participant protection prerequisites for Clinical Trial Authorization of novel interventions
- International regulatory precedents (FDA RMAT, EMA ATMP, PMDA) for analogous aging-reversal or cellular rejuvenation interventions

### Simulation Steps

- Use regulatory intelligence databases (e.g., Cortellis, Thomson Reuters Pharma) and Singapore HSA public guidance documents to map classification scenarios
- Run a structured classification matrix in a spreadsheet tool (Excel/Google Sheets) scoring each modality against HBPA Section 2(1) definitions and analogous product precedents
- Model timeline impact of each classification scenario using project scheduling software (Microsoft Project or Smartsheet) to quantify 6-18 month delay risk on downstream milestones

### Expert Validation Steps

- Engage a Singapore biomedical regulatory law firm (e.g., Hogan Lovells Singapore or Ropes & Gray Singapore) to commission a formal legal opinion on classification landscape
- Consult HSA's Division of Therapeutic Products directly through a pre-submission consultation request to validate classification assumptions and insurance prerequisites
- Review findings with an independent regulatory affairs director experienced in Singapore HBPA and international harmonization to challenge contingency reclassification feasibility

### Responsible Parties

- Chief Regulatory & Ethics Officer
- Project Director / Interim Governance Authority
- External regulatory law firm (Hogan Lovells / Ropes & Gray)
- HSA Division of Therapeutic Products (consulted)

### Assumptions

- **High:** HSA will accept a semantic pivot to 'regenerative medicine' or 'novel therapeutic approaches' without fundamentally different evidentiary standards or trial design requirements
- **High:** HSA pre-submission consultation will provide clear, actionable classification guidance within the planned timeline (by 2026-Oct-05)
- **High:** Insurance coverage and participant compensation mechanisms are not prerequisites for HSA pre-submission consultation or IRB ethics protocol submission

### SMART Validation Objective

By 2026-Sep-30, obtain a formal legal opinion and structured HSA pre-submission briefing document covering at least three distinct classification scenarios with corresponding evidence requirements, and confirm whether insurance/participant compensation are prerequisites for HSA consultation—validating or invalidating the reclassification contingency assumption before any binding facility or talent commitments are executed.

### Notes

- This is the highest-sensitivity assumption cluster; if invalidated, the entire project architecture may need restructuring
- The reclassification contingency is currently treated as naive; expert validation must stress-test whether reclassification triggers different evidentiary standards
- Missing data: no HSA pre-submission consultation has occurred yet; current assumptions are speculative


## 2. Interim Governance Architecture & Decision-Rights Framework

The project is executing binding commitments (facility leases, talent contracts, HSA submissions) without any ratified governance framework. The governance charter creates a circular dependency (Board must ratify charter, but Board doesn't exist yet), creating an accountability vacuum during the most consequential startup phase.

### Data to Collect

- Draft governance charter defining Board of Governors composition (40% government, 30% private investors, 30% scientific leadership), voting mechanisms, and conflict resolution protocols
- Interim Decision-Rights Charter specifying dollar thresholds, approval requirements, and authority limits for the pre-charter period
- Scientific Advisory Board member nominations, availability, and preliminary mandate for go/no-go gate review
- Precedents from A*STAR governance charters and Singapore Corporate Governance Code for public research governance structures

### Simulation Steps

- Draft a decision-rights matrix in a collaborative document platform (Google Docs/Confluence) mapping each decision type to authority level, dollar threshold, and approval body
- Model governance deadlock cost scenarios using a decision-tree tool (e.g., TreeAge or simple Excel scenario modeling) to quantify SGD 30-60 million delay risk from 6-12 month decision paralysis
- Simulate SAB convening timeline using project scheduling software to test whether 2026-Dec-15 first convening leaves a 100+ day oversight gap

### Expert Validation Steps

- Engage a specialized governance consultancy (e.g., McKinsey Singapore public sector practice or PwC governance advisory) to draft the governance charter and Interim Decision-Rights Charter
- Consult Singapore Ministry of Law and A*STAR's board governance office for governance framework precedents applicable to public-private research partnerships
- Review interim authority structure with a corporate governance specialist to validate that the IGA charter provides sufficient accountability without creating circular dependencies

### Responsible Parties

- Chief Risk & Governance Officer
- Project Director / Interim Governance Authority
- External governance consultancy (McKinsey / PwC)
- Singapore Ministry of Law (consulted)
- A*STAR board governance office (consulted)

### Assumptions

- **High:** A Board of Governors can be constituted and ratify the governance charter by 2026-Oct-31 without prior interim authority structure
- **High:** The Project Director can unilaterally execute early commitments (facility leases, talent contracts) without defined interim decision-rights or accountability mechanisms
- **Medium:** The Scientific Advisory Board can wait until 2026-Dec-15 to convene without creating a critical oversight gap during the first 100+ days of project execution

### SMART Validation Objective

By 2026-Sep-19, establish an Interim Governance Authority with a written Interim Decision-Rights Charter specifying dollar thresholds and approval requirements, and accelerate SAB member nominations to enable convening by 2026-Nov-15—validating that interim governance can prevent decision paralysis and accountability gaps before charter ratification.

### Notes

- Governance paradox is a foundational execution risk; without interim authority, all early decisions are effectively unilateral
- The SAB's binding veto power makes it one of the most powerful bodies, yet it operates without institutional support or timely convening
- Missing data: no interim authority structure currently exists; charter drafting has not begun


## 3. Clinical Trial Insurance, Liability Coverage & Participant Compensation

The complete absence of clinical trial insurance, participant compensation, and product liability coverage creates existential financial risk—a single adverse event could generate SGD 100-500 million in liabilities exceeding the total contingency reserve by 133-667%. Insurance is a regulatory prerequisite for HSA trial authorization, not a post-launch procurement task.

### Data to Collect

- Preliminary broker coverage indications and premium estimates for clinical trial insurance (SGD 500M aggregate), professional indemnity (SGD 100M/practitioner), D&O (SGD 200M), and product liability (SGD 1B) for novel aging-reversal interventions
- HSA's specific insurance and participant protection requirements for Clinical Trial Authorization of novel biological products under the HBPA
- Actuarial risk assessment data for novel cellular therapy trials with no established safety profile
- International insurance premium benchmarks for analogous programs (e.g., Altos Labs, Unity Biotechnology clinical trial coverage structures)

### Simulation Steps

- Engage preliminary broker consultations via email/portal with Marsh Singapore Life Sciences, Aon Clinical Trial Insurance, and WTW Biomedical Risk Solutions to obtain indicative premium ranges
- Model liability exposure scenarios in a risk modeling tool (e.g., @RISK or Excel Monte Carlo) simulating SGD 100-500 million adverse event liabilities against the SGD 75 million contingency reserve
- Structure a participant compensation fund legal framework draft using contract management software to define payout criteria and governance before trial protocol finalization

### Expert Validation Steps

- Engage specialized biomedical insurance brokers (Marsh Singapore, Aon, WTW) within 2 weeks to obtain preliminary coverage indications and confirm whether insurance evidence is required for HSA pre-submission
- Commission a formal actuarial risk assessment from a qualified actuary specializing in biomedical trial risk to determine realistic premium estimates for unprecedented intervention classes
- Obtain a formal legal opinion from Singapore regulatory counsel confirming specific insurance and participant protection mandates for HSA clinical trial authorization

### Responsible Parties

- Chief Financial Officer
- Chief Risk & Governance Officer
- Specialized biomedical insurance brokers (Marsh / Aon / WTW)
- Singapore regulatory counsel (legal opinion)
- HSA Insurance and Risk Management Division (consulted)

### Assumptions

- **High:** Clinical trial insurance premiums for novel aging-reversal interventions will be SGD 8-15 million annually, comparable to standard biomedical trial coverage
- **High:** Insurance and participant compensation can be deferred to 2027-Mar-05 without blocking HSA pre-submission consultation or IRB ethics protocol approval
- **Medium:** Commercial insurance markets will provide adequate coverage for an intervention class with no established safety profile without requiring captive insurance or risk retention structures

### SMART Validation Objective

By 2026-Sep-19, engage specialized biomedical insurance brokers to obtain preliminary coverage indications and premium estimates, commission an actuarial risk assessment, and confirm via legal opinion whether insurance evidence is a prerequisite for HSA pre-submission—validating whether the 6-month deferred insurance timeline is viable or must be restructured as an immediate critical path.

### Notes

- Insurance is currently scheduled 6 months after project inception, which is a fundamental regulatory compliance failure if HSA requires coverage evidence for trial authorization
- The SGD 8-15 million annual premium assumption is unvalidated and likely optimistic for novel cellular therapy trials
- Missing data: no broker quotes obtained; no actuarial assessment commissioned; HSA insurance prerequisites not yet confirmed


## 4. Foreign Exchange Risk Exposure & Currency Hedging Strategy

The current currency strategy assumes SGD is the sole relevant currency with zero international risk, ignoring realistic SGD 30-50 million in FX exposure from global equipment procurement and international talent compensation. A 10-15% adverse currency movement could increase total project costs by SGD 15-38 million, and unaddressed investor hedging demands could delay or reduce funding commitments by 15-25%.

### Data to Collect

- Full foreign currency exposure audit identifying all SGD 150-250 million in foreign-denominated equipment procurement, international talent compensation, and potential foreign-currency funding streams
- Forward contract and hedging instrument costs for covering USD, EUR, and JPY exposures over the 10-year horizon
- Currency risk reserve sizing analysis (SGD 25-40 million target) based on historical SGD volatility against major currencies
- Private investor currency hedging expectations and whether SGD-denominated returns require built-in hedging clauses in funding agreements

### Simulation Steps

- Conduct a foreign currency exposure audit using spreadsheet modeling (Excel) cataloging all known international procurement contracts, talent compensation packages, and funding agreements by currency
- Model FX impact scenarios using historical exchange rate data (e.g., from Bloomberg, Reuters, or XE.com) in a Monte Carlo simulation tool (@RISK or Python) to estimate SGD 15-38 million cost increase from 10-15% adverse movements
- Price forward contracts and hedging options using treasury management software or online FX platforms to estimate hedging costs for the SGD 25-40 million reserve target

### Expert Validation Steps

- Engage a treasury specialist within 3 months of project initiation to conduct the full foreign currency exposure audit and recommend hedging instruments
- Consult a corporate treasury advisor or bank treasury desk (e.g., DBS Treasury, UOB Treasury) to validate hedging strategy feasibility and reserve sizing
- Review currency risk assumptions with the Chief Financial Officer and private investor representatives to confirm whether investor demands for currency hedging affect funding commitment timelines

### Responsible Parties

- Chief Financial Officer
- Treasury Specialist
- Corporate treasury advisor / bank treasury desk (DBS / UOB)
- Private investor representatives (consulted)

### Assumptions

- **High:** SGD is the sole relevant currency for all project transactions with no additional international risk management needed
- **Medium:** Private co-funding commitments will materialize without requiring currency hedging clauses that the project has not planned for
- **Medium:** Historical SGD stability against USD, EUR, and JPY will persist over the 10-year horizon without significant adverse movements

### SMART Validation Objective

By 2026-Dec-05, engage a treasury specialist to complete a full foreign currency exposure audit covering all SGD 150-250 million in foreign-denominated costs, and establish a currency risk reserve of SGD 25-40 million with forward contracts for purchases exceeding SGD 5 million—validating whether the zero-currency-risk assumption is viable or must be replaced with active hedging.

### Notes

- The zero-currency-risk assumption is identified as dangerously flawed in the expert review but remains unaddressed in the current plan
- FX exposure is not just procurement—it includes international talent compensation and potential foreign-currency funding streams
- Missing data: no foreign currency exposure audit has been conducted; no treasury specialist engaged


## 5. Biomarker Validation Hierarchy & Go/No-Go Gate Scientific Rigor

The biomarker validation hierarchy is the evidentiary gatekeeper between laboratory promise and clinical reality, directly controlling pipeline velocity and scientific credibility. Without validated biomarker candidates and rigorous threshold criteria, go/no-go gates cannot function, risking either premature clinical commitments on unproven markers or excessive preclinical delay consuming the 10-year timeline.

### Data to Collect

- Specific biomarker candidates (epigenetic clocks, functional tissue assays, animal model longevity correlates) and their validation status for cellular reversal claims
- Assay reproducibility data and threshold criteria for each candidate surrogate endpoint
- Historical dataset stress-test results comparing candidate biomarkers against negative controls and known false-positive rates
- Independent replication requirements and evidence standards for externally reviewed go/no-go gate decisions

### Simulation Steps

- Build a biomarker confidence tier model in a data analysis tool (R, Python, or SPSS) ranking candidate surrogates by molecular signature strength, functional correlation, and animal model concordance
- Simulate go/no-go gate decision outcomes using decision analysis software (e.g., TreeAge) to test how different biomarker threshold strictness levels affect pipeline velocity and false-positive trial risk
- Model the SGD 15-20 million biomarker qualification investment allocation across assay development, historical dataset analysis, and independent replication studies

### Expert Validation Steps

- Consult a biogerontologist and cellular aging research director with expertise in epigenetic clocks, senolytic biomarkers, and reprogramming validation to review the proposed biomarker hierarchy rigor
- Engage the Head of Biomarker Validation and Assay Development (once hired) to validate assay reproducibility standards and threshold criteria for go/no-go gate evidence packages
- Review biomarker qualification strategy with an independent Scientific Advisory Board member specializing in translational aging biology to challenge whether the proposed surrogates predict functional outcomes

### Responsible Parties

- Scientific Director
- Head of Biomarker Validation and Assay Development
- Independent Scientific Advisory Board members (biogerontology/translational biology experts)
- Biomarker qualification team

### Assumptions

- **High:** Defined cellular reversal markers exist and can be validated within the first 2-3 years to support human trial triggers by year 3-4
- **Medium:** A conservative biomarker hierarchy requiring concordant evidence from epigenetic clocks, functional tissue assays, and animal model longevity data will not excessively delay pipeline velocity beyond stakeholder tolerance
- **Medium:** The SGD 15-20 million biomarker qualification investment is sufficient to establish rigorous evidentiary thresholds for go/no-go gate decisions

### SMART Validation Objective

By 2027-Q2, establish a dedicated biomarker qualification team with SGD 15-20 million investment, validate at least three candidate surrogate endpoints against historical datasets and negative controls, and define specific assay benchmarks and independent replication requirements for externally reviewed go/no-go gates—validating whether the biomarker hierarchy can function as a credible evidentiary gatekeeper without excessive pipeline delay.

### Notes

- The plan references 'defined cellular reversal markers' without specifying which biomarkers, assay methods, or replication standards will be used
- Biomarker validation failure could delay clinical entry by 2-4 years, compressing the clinical phase and leaving the facility underutilized
- Missing data: no specific biomarker candidates or validation protocols are documented; SGD 15-20 million investment allocation is undefined

## Summary

The five highest-priority data collection areas target the most sensitive assumptions identified in the expert review: (1) HSA regulatory classification—the foundational gate that determines every downstream decision; (2) interim governance architecture—the accountability vacuum during the critical startup phase; (3) clinical trial insurance and liability coverage—the existential financial risk currently deferred 6 months; (4) foreign exchange risk exposure—the dangerously unaddressed SGD 30-50 million currency exposure; and (5) biomarker validation hierarchy—the scientific gatekeeper whose rigor determines pipeline velocity and credibility. Immediate actionable tasks: (a) elevate HSA pre-submission consultation to the single most critical project gate and condition all binding commitments on classification outcome; (b) establish an Interim Governance Authority with a written Interim Decision-Rights Charter within 14 days; (c) engage specialized biomedical insurance brokers within 2 weeks and restructure insurance as a parallel critical path, not a deferred procurement task; (d) engage a treasury specialist within 3 months to conduct a full FX exposure audit; and (e) specify biomarker candidates, assay methods, and replication standards for go/no-go gates rather than referencing undefined 'cellular reversal markers.' These five areas must be validated before the project executes binding facility leases, talent contracts, or budget commitments, as invalidation of any one could require restructuring the entire project architecture.