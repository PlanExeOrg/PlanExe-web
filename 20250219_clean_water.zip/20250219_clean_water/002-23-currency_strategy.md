This plan involves money.

## Currencies

- **USD:** The project budget is defined in USD.
- **INR:** For local expenses in India (Rajasthan).
- **KES:** For local expenses in Kenya.
- **VND:** For local expenses in Vietnam.

**Primary currency:** USD

**Currency strategy:** USD will be used for budgeting and reporting. Local currencies (INR, KES, VND) will be used for local transactions. Exchange rate fluctuations should be monitored and hedged against where possible.