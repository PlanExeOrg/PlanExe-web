Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because success does not require breaking physical laws. The project focuses on water purification and distribution, which are based on well-established scientific principles and engineering practices. No quotes needed.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines product (clean water), market (rural areas), tech/process (purification + distribution), and policy (community engagement) without independent evidence at comparable scale. There is no mention of precedent for this specific combination. 

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: 2027-03-31


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "Pioneer's Gambit" without defining their mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes. The plan lacks one-pagers defining these strategic concepts. "The plan is highly ambitious...requiring significant infrastructure development."

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining the value hypothesis, success metrics, owner, and decision hooks. Due: 2027-03-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (climate change resilience) is absent. The plan does not explicitly address climate change impacts. "A key missing strategic dimension might be a specific focus on climate change resilience in infrastructure design."

**Mitigation**: Environmental Specialist: Expand the risk register to include climate change impacts, map potential cascades, and add controls with a dated review cadence. Due: 2027-03-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions securing necessary regulatory approvals and permits but lacks a detailed matrix. "Secure necessary regulatory approvals and permits." The risk assessment mentions delays in permits.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with lead times, dependencies, and responsible parties. Identify critical path permits and NO-GO thresholds. Due: 2027-03-31.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions securing initial funding but lacks details on sources, status, draw schedule, and covenants. "Secure initial funding." Runway length is undefined.

**Mitigation**: Finance Manager: Develop a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 2027-03-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks scale-appropriate benchmarks for capex/fit-out/opex. The plan states a budget of 200 million USD for 2 million people over 3 years, but there are no per-area cost breakdowns or vendor quotes.

**Mitigation**: Finance Manager: Obtain ≥3 relevant comparables, normalize costs per capita, and adjust budget or de-scope by 2027-03-31.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., serving 2 million people in 3 years) as single numbers without ranges or alternative scenarios. "serving 2 million people in rural areas over 3 years with a total budget of 200 million USD."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the user adoption projection. Due: 2027-03-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "Pioneer's Gambit" without defining their mechanism-of-action (inputs→process→customer value), owner, or measurable outcomes. The plan lacks one-pagers defining these strategic concepts. "The plan is highly ambitious...requiring significant infrastructure development."

**Mitigation**: Project Lead: Create one-pagers for each strategic concept, defining the value hypothesis, success metrics, owner, and decision hooks. Due: 2027-03-31.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Implement a user-fee system, charging residents a monthly fee..." but lacks evidence of community willingness or ability to pay.

**Mitigation**: Community Engagement Specialist: Conduct a detailed willingness-to-pay study in the target communities and document the findings by 2027-03-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "a new system" without specific, verifiable qualities. The project aims to provide clean water, but the specific attributes of the final water system are not clearly defined.

**Mitigation**: Project Manager: Define SMART criteria for the water system, including a KPI for water purity (e.g., <1 coliform forming unit per 100 mL) by 2027-03-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan selects 'The Pioneer's Gambit' which includes "Establish a piped water network to each household". This adds cost without clear benefit to the core goals of providing clean water and improving public health.

**Mitigation**: Project Team: Produce a one-page benefit case justifying piped water to each household, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2027-03-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Community Engagement Specialist' to build trust and ensure community buy-in. "Essential for building trust and ensuring community buy-in." This role is critical and likely difficult to fill.

**Mitigation**: HR: Validate the talent market for Community Engagement Specialists with experience in rural water infrastructure projects by 2027-03-31 to confirm feasibility.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions securing necessary regulatory approvals and permits but lacks a detailed matrix. "Secure necessary regulatory approvals and permits." The risk assessment mentions delays in permits.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with lead times, dependencies, and responsible parties. Identify critical path permits and NO-GO thresholds. Due: 2027-03-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive operational sustainability plan. The plan mentions financial sustainability but lacks details on long-term maintenance, technology obsolescence, and adaptation mechanisms. "Financial Sustainability Mechanism lever determines how the project will fund its ongoing operations."

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2027-03-31.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions regulatory approvals but lacks specifics. It states, "Secure necessary regulatory approvals and permits." It's uncertain if these are satisfied or if viable alternatives exist.

**Mitigation**: Permitting Lead: Perform a fatal-flaw screen with authorities to identify potential non-waivable constraints and define fallback designs. Due: 2027-03-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions establishing relationships with multiple suppliers but lacks details on SLAs, geographic diversity, or tested failover procedures. "Establish relationships with multiple suppliers."

**Mitigation**: Procurement Manager: Secure SLAs with geographically diverse suppliers, add a secondary supply path for critical components, and test failover procedures by 2027-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Community Engagement Team is incentivized by community satisfaction, creating a conflict over cost-cutting measures that may reduce community benefits.

**Mitigation**: Project Lead: Define a shared OKR focused on 'achieving project goals within budget while maintaining a community satisfaction score above 80%' by 2027-03-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to review progress, risks, and budget. Due: 2027-03-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Financial, Technical, Social) that are strongly coupled. For example, a financial risk (currency fluctuation) can trigger a technical risk (supply chain disruption), leading to a social risk (community resistance).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 2027-03-31.