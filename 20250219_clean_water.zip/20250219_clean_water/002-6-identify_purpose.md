**Purpose:** business

**Purpose Detailed:** Infrastructure project for water purification and distribution to serve a large population in rural areas.

**Topic:** Clean water infrastructure development