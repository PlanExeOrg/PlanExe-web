A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The user-fee system will be readily accepted and consistently paid by the rural communities. | Conduct a detailed willingness-to-pay survey across a representative sample of the target communities, offering hypothetical service scenarios and pricing tiers. | The survey reveals that more than 30% of households are unwilling or unable to pay the proposed user fees, even at the lowest tier. |
| A2 | The selected water purification technology will function reliably in the long term with minimal maintenance in the harsh environmental conditions of the rural areas. | Conduct accelerated aging tests on key components of the selected purification technology, simulating extreme temperature, humidity, and dust exposure. | The accelerated aging tests reveal that critical components fail or require significant maintenance more frequently than the projected schedule, increasing operational costs by more than 20%. |
| A3 | Local communities will readily adopt and consistently adhere to the operational management model imposed by the project. | Present the proposed operational management model to representative community groups and solicit feedback through structured interviews and focus groups. | The community feedback reveals significant resistance to the proposed model, with more than 40% of participants expressing concerns about lack of local control, transparency, or cultural appropriateness. |
| A4 | The local supply chain for necessary chemicals and consumables (e.g., chlorine, filter media) will remain reliable and cost-effective throughout the project's lifespan. | Conduct a thorough assessment of the local supply chain, identifying potential suppliers, evaluating their capacity, and negotiating preliminary pricing agreements. | The assessment reveals that there are limited local suppliers, their capacity is insufficient to meet the project's needs, or their pricing is significantly higher than anticipated, increasing operational costs by more than 15%. |
| A5 | The project will not face significant land disputes or challenges in acquiring the necessary land for infrastructure development (e.g., purification plant, reservoirs, pipelines). | Conduct a comprehensive land ownership and legal review for all proposed project sites, identifying potential disputes, encumbrances, or regulatory hurdles. | The review reveals significant land disputes, unclear ownership claims, or regulatory restrictions that would prevent the project from acquiring the necessary land within the planned timeframe or budget. |
| A6 | The project will not experience significant security threats or vandalism that would disrupt operations or damage infrastructure. | Conduct a security risk assessment for all proposed project sites, identifying potential threats, vulnerabilities, and mitigation measures. | The assessment reveals a high risk of security threats or vandalism, requiring significant investment in security measures that would increase operational costs by more than 10% or disrupt project timelines. |
| A7 | The local workforce possesses the necessary skills and capacity to effectively participate in the construction, operation, and maintenance of the water infrastructure. | Conduct a skills gap analysis within the target communities, assessing the availability of skilled labor and identifying training needs. | The analysis reveals a significant skills gap, requiring extensive and costly training programs that would delay project timelines or exceed budget constraints. |
| A8 | There will be no significant changes in government regulations or policies that would negatively impact the project's feasibility or financial viability. | Engage with relevant government agencies to obtain written confirmation of regulatory stability and assess the likelihood of future policy changes. | Government agencies indicate a high probability of regulatory changes that would significantly increase project costs, restrict water extraction, or impose new operational requirements. |
| A9 | The project will receive consistent and reliable support from local political leaders and community influencers throughout its lifecycle. | Conduct regular meetings and consultations with local political leaders and community influencers to gauge their level of support and address any concerns. | Local political leaders or community influencers express significant opposition to the project, threatening to withdraw their support or actively undermine its implementation. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Well of Good Intentions | Process/Financial | A1 | Finance Manager | CRITICAL (20/25) |
| FM2 | The Rusting Promise | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Bitter Taste of Imposition | Market/Human | A3 | Community Engagement Lead | CRITICAL (20/25) |
| FM4 | The Chemical Desert | Process/Financial | A4 | Procurement Manager | CRITICAL (20/25) |
| FM5 | The Landlocked Dream | Technical/Logistical | A5 | Permitting Lead | CRITICAL (15/25) |
| FM6 | The Shadow of Fear | Market/Human | A6 | Security Lead | CRITICAL (20/25) |
| FM7 | The Empty Toolbox | Technical/Logistical | A7 | Construction Manager | CRITICAL (20/25) |
| FM8 | The Shifting Sands of Governance | Process/Financial | A8 | Government Relations Lead | CRITICAL (15/25) |
| FM9 | The Withering Endorsement | Market/Human | A9 | Community Engagement Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Empty Well of Good Intentions

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Finance Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model hinges on a user-fee system. However, the rural communities targeted are economically vulnerable, with many families living below the poverty line. The willingness-to-pay survey, initially glossed over, revealed a significant portion of the population couldn't afford the proposed fees. Despite this warning, the project proceeded, assuming community goodwill would bridge the gap. As the system went live, payment rates plummeted. Families prioritized food and medicine over water bills. The project, lacking a robust subsidy mechanism or alternative revenue streams, quickly ran into a cash crunch. Maintenance was deferred, then halted. The purification plant, once a symbol of progress, fell into disrepair. The piped water network, starved of funds, sprung leaks that went unfixed. The project, intended to bring clean water, became a monument to financial miscalculation, leaving the communities worse off than before.

##### Early Warning Signs
- Willingness-to-pay survey indicates >25% of households cannot afford the lowest proposed user fee.
- Initial user sign-up rate is <50% within the first month of service launch.
- Payment collection rate falls below 70% within the first quarter of operation.

##### Tripwires
- Payment collection rate <= 60% after 6 months of operation.
- Operating expenses exceed revenue by >= 15% for two consecutive quarters.
- Reserve fund depleted by >= 50% within the first year.

##### Response Playbook
- Contain: Immediately suspend all non-essential spending and freeze new contracts.
- Assess: Conduct an emergency financial audit to identify the root causes of the revenue shortfall and explore alternative funding options.
- Respond: Renegotiate tariff structure with community input, aggressively pursue grant funding, and implement a targeted subsidy program for low-income households.


**STOP RULE:** Operating expenses cannot be covered by any combination of user fees, subsidies, and grants within 18 months, leading to imminent system shutdown.

---

#### FM2 - The Rusting Promise

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project banked on a cutting-edge membrane filtration system, touted for its efficiency and low maintenance. However, the system was designed for controlled laboratory conditions, not the harsh reality of rural deployment. The arid climate, combined with frequent power outages, took a heavy toll. The membranes, sensitive to temperature fluctuations, cracked and clogged. The automated cleaning cycles, designed to minimize manual intervention, proved inadequate against the persistent dust and sediment. Spare parts, sourced from overseas, were delayed by logistical bottlenecks and customs holdups. Local technicians, lacking specialized training, struggled to diagnose and repair the system. The purification plant, once a beacon of technological advancement, became a maintenance nightmare. Clean water became a sporadic luxury, not a reliable service. The community, disillusioned by broken promises, lost faith in the project and its backers.

##### Early Warning Signs
- Membrane replacement frequency exceeds manufacturer's specifications by >25%.
- Average daily water production falls below 75% of design capacity.
- Spare parts delivery times exceed 30 days for critical components.

##### Tripwires
- Membrane failure rate >= 10% per month.
- System downtime exceeds 72 hours per week.
- Inventory of critical spare parts falls below 30-day supply.

##### Response Playbook
- Contain: Immediately implement a manual cleaning protocol and ration water supply to critical needs.
- Assess: Conduct a thorough technical audit to identify the root causes of the system failures and evaluate alternative purification technologies.
- Respond: Retrofit the system with more robust components, establish a local spare parts depot, and provide intensive training to local technicians.


**STOP RULE:** The purification system cannot be reliably operated at >= 50% of design capacity for more than 3 consecutive months, rendering the project unsustainable.

---

#### FM3 - The Bitter Taste of Imposition

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Community Engagement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project imposed a top-down operational management model, assuming the rural communities would passively accept it. The model, designed for efficiency and control, disregarded local customs and traditions. The centralized management structure, staffed by outsiders, alienated community leaders. The rigid operating hours, dictated by distant bureaucrats, clashed with local work patterns. The community, feeling ignored and disrespected, grew resentful. Vandalism increased. Payment rates declined. Rumors spread about water contamination and unfair pricing. The project, intended to empower, became a symbol of external control. The community, once hopeful, turned hostile. The water system, though technically sound, became a source of conflict and division, ultimately failing to deliver its intended benefits.

##### Early Warning Signs
- Attendance at community meetings falls below 50% within the first six months.
- Number of formal complaints filed by community members increases by >20% per month.
- Vandalism incidents targeting water infrastructure increase by >10% per month.

##### Tripwires
- Community satisfaction score (measured via survey) falls below 60%.
- Number of vandalism incidents exceeds 5 per month.
- Participation in community-led maintenance activities falls below 25%.

##### Response Playbook
- Contain: Immediately suspend all top-down directives and initiate a series of community dialogues.
- Assess: Conduct a comprehensive social audit to identify the root causes of the community resistance and evaluate alternative management models.
- Respond: Decentralize decision-making, empower local leaders, and adapt the operational model to reflect community values and preferences.


**STOP RULE:** Irreparable breakdown in community relations, evidenced by sustained violent protests or sabotage, rendering the project unviable.

---

#### FM4 - The Chemical Desert

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Procurement Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's operational budget relied on a stable and affordable supply of essential chemicals, particularly chlorine for disinfection. However, the local supply chain proved to be fragile. A major regional supplier went bankrupt, creating a sudden shortage. Alternative suppliers, located further away, charged exorbitant prices, driving up operational costs. The project, lacking a diversified supply chain or a contingency plan, struggled to maintain adequate chlorine levels in the water supply. Water quality deteriorated, leading to a spike in waterborne diseases. The community, fearing for their health, lost trust in the project and its backers. The project, intended to provide safe water, became a source of public health crisis, leaving the communities worse off than before.

##### Early Warning Signs
- Local supplier capacity is <120% of projected demand.
- Lead times for chemical deliveries exceed 30 days.
- Price of chlorine increases by >10% within a single quarter.

##### Tripwires
- Chlorine levels in treated water fall below minimum safety standards for >= 7 consecutive days.
- Inventory of chlorine falls below 14-day supply.
- Cost of chlorine exceeds budgeted amount by >= 20% for two consecutive quarters.

##### Response Playbook
- Contain: Immediately implement emergency disinfection protocols and ration water supply to critical needs.
- Assess: Conduct a thorough supply chain audit to identify alternative suppliers and evaluate the feasibility of local chlorine production.
- Respond: Diversify the supply chain, negotiate long-term contracts with multiple suppliers, and explore the possibility of establishing a local chlorine production facility.


**STOP RULE:** The project cannot secure a reliable and affordable supply of chlorine within 6 months, rendering the water unsafe for consumption.

---

#### FM5 - The Landlocked Dream

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's ambitious infrastructure plans depended on acquiring specific parcels of land for the purification plant and distribution network. However, a complex web of land disputes and legal challenges emerged. A powerful local landowner refused to sell a critical plot, demanding an exorbitant price. A community group claimed ancestral rights to another site, blocking construction. Bureaucratic delays and legal battles dragged on for months, pushing back the project timeline. The construction crews, unable to access the designated sites, sat idle. The project, intended to bring clean water, became entangled in a quagmire of land disputes, leaving the communities thirsty and frustrated.

##### Early Warning Signs
- Land acquisition negotiations stall for >60 days.
- Legal challenges to land ownership are filed by community groups or landowners.
- Permitting delays exceed 90 days due to land-related issues.

##### Tripwires
- Critical land parcels remain unacquired >= 6 months after the planned acquisition date.
- Construction activities are halted due to land disputes for >= 30 consecutive days.
- Legal costs related to land acquisition exceed budgeted amount by >= 25%.

##### Response Playbook
- Contain: Immediately halt all construction activities on disputed land and initiate mediation efforts with landowners and community groups.
- Assess: Conduct a thorough legal review to evaluate the strength of the land claims and explore alternative site options.
- Respond: Negotiate fair compensation with landowners, explore alternative site locations, and engage with community leaders to address their concerns.


**STOP RULE:** The project cannot acquire the necessary land within 12 months, rendering the infrastructure plans unfeasible.

---

#### FM6 - The Shadow of Fear

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Security Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project, designed to bring clean water to vulnerable communities, became a target for criminal elements and disgruntled groups. A series of vandalism incidents targeted the purification plant and distribution network. Equipment was stolen, pipelines were sabotaged, and water sources were contaminated. The security forces, stretched thin and under-resourced, struggled to protect the infrastructure. The community, living in fear, hesitated to report the incidents. The project, intended to empower, became a source of anxiety and insecurity. The water supply, already unreliable, became even more precarious. The community, once hopeful, felt abandoned and vulnerable.

##### Early Warning Signs
- Theft of equipment or materials from construction sites increases by >50% per month.
- Vandalism incidents targeting water infrastructure increase by >25% per month.
- Reports of threats or intimidation against project personnel are received from community members.

##### Tripwires
- Security incidents result in >= 24 hours of system downtime per week.
- Cost of security measures exceeds budgeted amount by >= 20%.
- Community members express fear of using the water system due to security concerns (measured via survey).

##### Response Playbook
- Contain: Immediately increase security patrols, install surveillance equipment, and coordinate with local law enforcement.
- Assess: Conduct a thorough security risk assessment to identify vulnerabilities and evaluate alternative security measures.
- Respond: Implement a community-based security program, engage with local leaders to build trust, and provide incentives for reporting suspicious activity.


**STOP RULE:** Sustained security threats render the project personnel unsafe and the infrastructure unprotectable, forcing a complete shutdown.

---

#### FM7 - The Empty Toolbox

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Construction Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumed a readily available pool of skilled local labor. However, the skills gap analysis revealed a stark reality: a lack of trained technicians, plumbers, and electricians. The project, committed to local hiring, was forced to rely on inexperienced workers. Construction delays mounted as tasks took longer and required constant supervision. The purification plant, built with substandard workmanship, suffered frequent breakdowns. The distribution network, poorly installed, sprung leaks at every joint. The project, intended to empower the community, became a training ground for unskilled labor, leaving the water system unreliable and unsustainable.

##### Early Warning Signs
- Construction timelines exceed planned durations by >20%.
- Number of rework requests due to poor workmanship increases by >30% per month.
- Frequency of equipment malfunctions and breakdowns exceeds manufacturer's specifications.

##### Tripwires
- System downtime due to technical failures exceeds 48 hours per week.
- Water loss due to leaks in the distribution network exceeds 20%.
- Maintenance costs exceed budgeted amount by >= 25%.

##### Response Playbook
- Contain: Immediately halt all non-critical construction activities and implement a rigorous quality control program.
- Assess: Conduct a skills assessment of the existing workforce and develop a targeted training program to address the identified gaps.
- Respond: Partner with local vocational schools to provide intensive training, hire experienced supervisors to oversee construction, and implement a mentorship program to transfer skills to local workers.


**STOP RULE:** The project cannot achieve a minimum level of technical competency within the local workforce after 12 months of training, rendering the infrastructure unsustainable.

---

#### FM8 - The Shifting Sands of Governance

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Government Relations Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project secured initial funding and permits based on the existing regulatory framework. However, a sudden change in government policy threw everything into disarray. A new environmental regulation restricted water extraction, forcing the project to scale back its operations. A revised tax law eliminated a key subsidy, jeopardizing the financial model. A change in leadership brought in a new set of priorities, diverting funds to other projects. The project, once on solid footing, found itself adrift in a sea of regulatory uncertainty. Funding dried up, construction stalled, and the community lost hope. The project, intended to bring clean water, became a victim of political whims, leaving the communities parched and disillusioned.

##### Early Warning Signs
- Rumors of impending regulatory changes circulate within government agencies.
- Key government officials express reservations about the project's feasibility or alignment with new policy priorities.
- Funding disbursements from government sources are delayed or reduced.

##### Tripwires
- New regulations impose restrictions on water extraction that reduce the project's capacity by >= 20%.
- Government subsidies are reduced or eliminated, creating a funding shortfall of >= 15%.
- Permits are revoked or suspended due to non-compliance with new regulations.

##### Response Playbook
- Contain: Immediately engage with government officials to understand the implications of the regulatory changes and explore potential solutions.
- Assess: Conduct a thorough legal and financial review to evaluate the impact of the changes on the project's feasibility and viability.
- Respond: Renegotiate contracts, revise the financial model, and explore alternative funding sources to adapt to the new regulatory environment.


**STOP RULE:** The project cannot secure the necessary permits and funding to operate within the new regulatory framework, rendering it economically unviable.

---

#### FM9 - The Withering Endorsement

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Engagement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project initially enjoyed strong support from local political leaders and community influencers. However, a series of unforeseen events eroded that support. A corruption scandal implicated a key political ally, tarnishing the project's reputation. A community leader, feeling slighted by the project's management, turned against it, spreading misinformation and inciting opposition. A rival politician seized on the controversy, using it to gain political advantage. The project, once a source of local pride, became a political football. Funding was delayed, permits were blocked, and community meetings were disrupted. The project, intended to unite, became a source of division and conflict, leaving the communities without clean water and mired in political infighting.

##### Early Warning Signs
- Local political leaders publicly criticize the project or express reservations about its benefits.
- Community influencers withdraw their support or endorse rival projects.
- Attendance at community meetings declines sharply, and opposition voices become more prominent.

##### Tripwires
- Key political leaders publicly withdraw their endorsement of the project.
- Community influencers actively campaign against the project, organizing protests or disseminating misinformation.
- Community satisfaction scores (measured via survey) fall below 50% due to political controversies.

##### Response Playbook
- Contain: Immediately initiate damage control efforts, engaging with political leaders and community influencers to address their concerns and rebuild trust.
- Assess: Conduct a thorough assessment of the political landscape to identify the root causes of the opposition and evaluate alternative engagement strategies.
- Respond: Renegotiate agreements with political leaders, address community grievances, and implement a transparent communication campaign to counter misinformation.


**STOP RULE:** The project loses the support of key political leaders and community influencers, rendering it impossible to secure permits, funding, or community cooperation.
