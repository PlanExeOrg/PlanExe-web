**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the Core Project Team's delegated financial authority (>$500,000 DKK) and requires strategic oversight.
Negative Consequences: Potential budget overruns, scope creep, and failure to meet project objectives.

**Technical Advisory Group Deadlock on Security Architecture**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendations and Project Manager Recommendation, followed by Steering Committee Vote
Rationale: The Technical Advisory Group cannot reach a consensus on a critical technical decision, requiring higher-level arbitration to avoid project delays and ensure technical soundness.
Negative Consequences: Compromised security posture, technical debt, and potential project failure.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Impact Assessment and Vote
Rationale: Significant changes to the project scope impact strategic objectives, budget, and timeline, requiring Steering Committee approval.
Negative Consequences: Project delays, budget overruns, and failure to achieve strategic goals.

**Reported Ethical Violation**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation, followed by Project Steering Committee Review and Decision
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with relevant regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Lack of Stakeholder Support from Digitaliseringsstyrelsen**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Plan and Adjustment of Strategy
Rationale: Insufficient support from a key stakeholder threatens project success and requires strategic intervention.
Negative Consequences: Reduced influence on AltID procurement, policy, and potential project failure.

**Critical Risk Materialization (e.g., Security Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Incident Response Plan and Allocation of Additional Resources
Rationale: A critical risk has materialized, requiring immediate action and potentially significant resource allocation.
Negative Consequences: Reputational damage, financial losses, and legal liabilities.