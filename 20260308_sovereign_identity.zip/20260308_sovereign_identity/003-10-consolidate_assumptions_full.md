# Purpose

**Purpose:** business

**Purpose Detailed:** Improvement of Denmark's digital identity infrastructure by reducing dependency on foreign technology suppliers and establishing a platform-neutral fallback authentication path.

**Topic:** Denmark's Digital Identity Infrastructure Improvement

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This project, while focused on digital infrastructure, *heavily relies* on physical elements. It requires a physical base in Copenhagen for research, development, and stakeholder meetings. The project involves building demonstrators, engaging with government bodies, and influencing procurement processes, all of which necessitate physical presence and interaction. The project also requires a physical location with access-controlled workspace appropriate for security-sensitive digital identity research, development, and stakeholder meetings.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Access-controlled workspace
- Appropriate for security-sensitive digital identity research
- Development and stakeholder meetings

## Location 1
Denmark

Copenhagen

Danish university, independent research institution, or security-qualified R&D facility

**Rationale**: The project's primary physical base is specified to be in Copenhagen, Denmark, at a Danish university, independent research institution, or security-qualified R&D facility.

## Location 2
Denmark

Copenhagen, Innovation District

Symbion Science Park, Fruebjergvej 3, 2100 Copenhagen

**Rationale**: Symbion Science Park in Copenhagen's Innovation District offers a collaborative environment with access to resources and potential partners relevant to digital identity research and development.

## Location 3
Denmark

Copenhagen, University District

University of Copenhagen, Nørregade 10, 1165 Copenhagen

**Rationale**: The University of Copenhagen provides access to academic expertise, research facilities, and potential student talent, fostering innovation and collaboration in digital identity research.

## Location 4
Denmark

Copenhagen, City Center

R&D office space in central Copenhagen

**Rationale**: A centrally located R&D office space in Copenhagen provides easy access to government agencies, stakeholders, and potential partners, facilitating policy engagement and coalition building.

## Location Summary
The project requires a physical base in Copenhagen, Denmark, at a Danish university, independent research institution, or security-qualified R&D facility. Additional suggestions include Symbion Science Park, the University of Copenhagen, and a centrally located R&D office space to facilitate collaboration and stakeholder engagement.

# Currency Strategy

This plan involves money.

## Currencies

- **DKK:** The project budget is specified in Danish Krone, and the primary location is Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone will be used for all transactions. No additional international risk management is needed.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Delays or inability to obtain necessary permits or approvals for the technical demonstrators, particularly if they involve any interaction with live government systems or data, even in a simulated environment. The 'permit/approval and stakeholder matrix' deliverable in Phase 1 aims to identify these, but unforeseen regulatory hurdles could still arise.

**Impact:** A delay of 2-6 months in Phase 2, potentially jeopardizing the demonstrator development and impacting the project's ability to influence AltID procurement. Could also lead to increased legal costs of 50,000-100,000 DKK.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage with Digitaliseringsstyrelsen early in Phase 1 to clarify regulatory requirements for the demonstrators. Develop contingency plans for alternative demonstrator designs that minimize regulatory risk. Secure preliminary legal advice on potential permitting challenges.

## Risk 2 - Technical
The technical demonstrators may not be able to achieve the required level of security or functionality to be considered credible by stakeholders. This could be due to unforeseen technical challenges in implementing platform-neutral authentication or limitations in the chosen technologies (e.g., FIDO2/WebAuthn).

**Impact:** Loss of credibility with Digitaliseringsstyrelsen and other stakeholders, reducing the project's influence on AltID procurement. Could lead to a need to re-scope the technical work, resulting in a 3-4 month delay and an additional cost of 200,000-400,000 DKK.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough security reviews and penetration testing of the demonstrators. Engage with external security experts to identify and address potential vulnerabilities. Maintain a flexible demonstrator design that allows for adjustments based on technical feasibility.

## Risk 3 - Financial
The project budget of 10.5 million DKK may be insufficient to cover all planned activities, particularly if unforeseen technical challenges or regulatory hurdles arise. The project plan explicitly warns against assuming that 8 million DKK is sufficient.

**Impact:** A reduction in the scope of the project, potentially impacting the quality or credibility of the technical demonstrators or the extent of policy engagement. Could lead to a need to seek additional funding, which may not be available.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget breakdown and track expenses closely. Identify potential cost-saving measures and contingency plans for reducing the scope of the project if necessary. Explore opportunities for securing additional funding from other sources.

## Risk 4 - Social
Lack of support from key stakeholders, including Digitaliseringsstyrelsen, the MitID operator, or members of Folketinget's digital policy committee. This could be due to resistance to change, concerns about the cost or complexity of platform-neutral authentication, or lobbying from incumbent platform providers.

**Impact:** Reduced influence on AltID procurement and policy decisions. Could lead to a need to re-scope the project to focus on EU-level engagement or publication and coalition consolidation.

**Likelihood:** Medium

**Severity:** High

**Action:** Build strong relationships with key stakeholders through regular communication and engagement. Tailor the project's messaging to address their specific concerns and priorities. Highlight the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty.

## Risk 5 - Operational
Difficulty in recruiting and retaining qualified personnel, particularly those with expertise in mobile security, authentication protocols, and Danish/EU digital identity frameworks. The project plan emphasizes avoiding dependence on a single specialist, but finding suitable replacements could still be challenging.

**Impact:** Delays in project execution and a reduction in the quality of deliverables. Could lead to a need to outsource some of the technical work, increasing costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Develop a comprehensive recruitment plan and offer competitive salaries and benefits. Provide opportunities for professional development and training. Foster a collaborative and supportive work environment.

## Risk 6 - Security
Security vulnerabilities in the technical demonstrators could be exploited by malicious actors, compromising the security of the simulated Danish public-sector identity-provider environment or the privacy of user data. This could damage the project's credibility and undermine its efforts to promote platform-neutral authentication.

**Impact:** Significant reputational damage and loss of stakeholder trust. Could lead to legal liabilities and financial penalties.

**Likelihood:** Low

**Severity:** High

**Action:** Implement robust security measures throughout the development process. Conduct regular security audits and penetration testing. Comply with all relevant security standards and regulations. Ensure that all personnel are trained in security best practices.

## Risk 7 - Supply Chain
Delays or disruptions in the supply of hardware or software components required for the technical demonstrators, such as hardware tokens or GrapheneOS-compatible devices. This could be due to global supply chain issues, geopolitical events, or vendor-specific problems.

**Impact:** Delays in project execution and a need to find alternative suppliers or technologies. Could lead to increased costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Identify alternative suppliers for critical components. Maintain a buffer stock of essential hardware and software. Develop contingency plans for using alternative technologies if necessary.

## Risk 8 - Integration with Existing Infrastructure
Challenges in demonstrating the feasibility of platform-neutral authentication within the existing MitID ecosystem, which is tightly coupled to Apple/Google platform integrity signals. The project aims to influence AltID, but resistance from incumbent operators could limit the project's impact.

**Impact:** The project's recommendations may not be adopted by Digitaliseringsstyrelsen or the MitID operator, limiting its impact on Danish digital identity infrastructure.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Focus on demonstrating the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty. Engage with the MitID operator to identify potential areas of collaboration. Develop a clear and compelling value proposition for platform-neutral authentication.

## Risk 9 - Environmental
The project's activities, such as the development and testing of technical demonstrators, could have a negative impact on the environment, particularly in terms of energy consumption and electronic waste. While likely minimal, it's important to consider.

**Impact:** Minor reputational damage and potential criticism from environmental groups.

**Likelihood:** Low

**Severity:** Low

**Action:** Implement energy-efficient practices in the project's operations. Recycle electronic waste responsibly. Promote sustainable development practices within the project team.

## Risk 10 - Long-Term Sustainability
The project's impact may be limited if the recommendations are not implemented and sustained over the long term. This could be due to changes in government policy, funding priorities, or technological developments.

**Impact:** The project's efforts may be wasted if platform-neutral authentication is not adopted and sustained over the long term.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a long-term sustainability plan that includes strategies for promoting the adoption and maintenance of platform-neutral authentication. Engage with relevant stakeholders to ensure that the project's recommendations are integrated into long-term planning processes.

## Risk summary
The most critical risks are the potential for technical challenges in developing credible demonstrators, lack of support from key stakeholders, and insufficient budget to cover all planned activities. The project's success hinges on effectively managing these risks through proactive engagement with stakeholders, rigorous security testing, and careful budget management. The trade-off between technical demonstrator scope and certification rigor is also a key consideration. Overlapping mitigation strategies include building strong relationships with Digitaliseringsstyrelsen and other stakeholders, tailoring the project's messaging to address their specific concerns, and highlighting the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty.

# Make Assumptions


## Question 1 - What specific funding allocation is planned for external security reviews within the 10.5 million DKK budget?

**Assumptions:** Assumption: 250,000 DKK is allocated for external security reviews, based on industry standards for similar security-sensitive projects and the need for independent validation of the demonstrators.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the adequacy of the budget allocation for external security reviews.
Details: Insufficient funding for security reviews could lead to undetected vulnerabilities and reduced stakeholder confidence. A budget of 250,000 DKK allows for comprehensive security audits and penetration testing by qualified firms. Mitigation: Prioritize critical security reviews and seek pro bono support from security experts if budget constraints arise. Opportunity: A successful security review can enhance the project's credibility and attract further funding.

## Question 2 - What is the detailed timeline for securing a formal written response from Digitaliseringsstyrelsen, including milestones and dependencies?

**Assumptions:** Assumption: Securing a formal written response from Digitaliseringsstyrelsen will take approximately 6 months, with key milestones including initial contact, proposal submission, follow-up meetings, and response drafting.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Analysis of the timeline for securing a formal response from Digitaliseringsstyrelsen.
Details: A delayed response could impact the project's ability to influence AltID procurement. Mitigation: Establish clear communication channels with Digitaliseringsstyrelsen, proactively address their concerns, and escalate issues as needed. Opportunity: A timely and positive response can significantly enhance the project's impact and credibility.

## Question 3 - What specific roles and responsibilities will be assigned to each team member to avoid dependence on a single specialist, especially in technical areas?

**Assumptions:** Assumption: The technical lead will oversee the demonstrator development, with the additional engineer/contractor providing backup and specialized expertise in web authentication and Linux/GrapheneOS implementation. Knowledge transfer will be a priority.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of the resource allocation and personnel management strategy.
Details: Dependence on a single specialist poses a significant risk to project continuity. Mitigation: Implement cross-training programs, document key processes, and ensure knowledge sharing among team members. Opportunity: A well-rounded team with diverse skills can enhance the project's resilience and innovation capacity.

## Question 4 - What specific regulatory compliance standards, beyond eIDAS and NSIS, will the technical demonstrators need to adhere to, even in a non-production environment?

**Assumptions:** Assumption: The demonstrators will need to comply with GDPR and relevant Danish data protection laws, even in a simulated environment, to ensure responsible handling of user data and maintain stakeholder trust.

**Assessments:** Title: Governance & Regulations Assessment
Description: Analysis of the regulatory compliance requirements for the project.
Details: Failure to comply with relevant regulations could result in legal liabilities and reputational damage. Mitigation: Conduct a thorough regulatory review, implement appropriate data protection measures, and seek legal advice as needed. Opportunity: Demonstrating strong regulatory compliance can enhance the project's credibility and attract further support.

## Question 5 - What specific risk mitigation strategies will be implemented to address potential security vulnerabilities in the technical demonstrators, beyond external security reviews?

**Assumptions:** Assumption: Regular code reviews, penetration testing, and vulnerability scanning will be conducted throughout the development process to identify and address security vulnerabilities proactively.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the risk management strategies for the project.
Details: Security vulnerabilities in the demonstrators could undermine the project's credibility and impact. Mitigation: Implement a multi-layered security approach, including secure coding practices, regular security testing, and incident response planning. Opportunity: A robust security posture can enhance the project's reputation and attract further investment.

## Question 6 - What measures will be taken to minimize the environmental impact of the project's activities, such as energy consumption and electronic waste disposal?

**Assumptions:** Assumption: The project will prioritize energy-efficient computing practices, responsible electronic waste disposal, and the use of sustainable materials where possible to minimize its environmental footprint.

**Assessments:** Title: Environmental Impact Assessment
Description: Analysis of the project's potential environmental impact.
Details: Neglecting environmental considerations could damage the project's reputation and alienate stakeholders. Mitigation: Implement sustainable practices, such as using energy-efficient equipment, recycling electronic waste, and promoting responsible consumption. Opportunity: Demonstrating environmental responsibility can enhance the project's image and attract environmentally conscious stakeholders.

## Question 7 - What specific strategies will be used to engage with and address the concerns of incumbent platform providers (Apple and Google) regarding platform-neutral alternatives?

**Assumptions:** Assumption: The project will engage with Apple and Google through industry forums and direct communication to address their concerns and explore potential areas of collaboration, emphasizing the benefits of platform-neutrality for innovation and competition.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the stakeholder engagement strategy.
Details: Resistance from incumbent platform providers could hinder the project's progress. Mitigation: Engage with stakeholders proactively, address their concerns, and seek mutually beneficial solutions. Opportunity: Building strong relationships with stakeholders can foster collaboration and increase the project's impact.

## Question 8 - What specific operational systems will be put in place to ensure data security and privacy within the access-controlled workspace, especially concerning sensitive digital identity research data?

**Assumptions:** Assumption: Strict access control measures, data encryption, and regular security audits will be implemented within the access-controlled workspace to protect sensitive digital identity research data.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the operational systems for data security and privacy.
Details: Inadequate data security measures could lead to data breaches and reputational damage. Mitigation: Implement robust access control measures, data encryption, and regular security audits. Opportunity: Demonstrating strong data security practices can enhance the project's credibility and attract further investment.

# Distill Assumptions

- 250,000 DKK is allocated for external security reviews.
- Digitaliseringsstyrelsen response will take 6 months, including milestones and follow-up.
- Technical lead oversees demonstrator; engineer provides backup and specialized expertise.
- Demonstrators comply with GDPR and Danish data protection laws.
- Code reviews, penetration testing, and vulnerability scanning will be conducted regularly.
- Project prioritizes energy-efficient practices, waste disposal, and sustainable materials.
- Project will engage Apple and Google to address concerns and explore collaboration.
- Strict access control, encryption, and audits protect sensitive digital identity data.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment in Technology and Public Sector

## Domain-specific considerations

- Stakeholder management in a politically sensitive environment
- Technical feasibility of implementing platform-neutral solutions
- Regulatory compliance and data privacy
- Budget constraints and resource allocation
- Long-term sustainability and impact

## Issue 1 - Uncertainty Regarding Digitaliseringsstyrelsen's Response Timeline and Commitment
The assumption that securing a formal written response from Digitaliseringsstyrelsen will take approximately 6 months is a critical assumption that lacks sufficient detail. The project's success hinges on influencing AltID procurement, which requires timely and positive engagement from the agency. The plan does not address the possibility of non-response, negative response, or a significantly delayed response. This is a critical missing assumption.

**Recommendation:** Develop a detailed engagement plan with Digitaliseringsstyrelsen, including specific milestones, communication protocols, and escalation procedures. Conduct a stakeholder analysis to identify key influencers and decision-makers within the agency. Establish clear metrics for measuring the success of engagement efforts. Prepare alternative strategies in case of non-response or negative feedback, such as focusing on EU-level engagement or building broader coalition support.

**Sensitivity:** A delay in obtaining a formal response from Digitaliseringsstyrelsen (baseline: 6 months) could delay the project's impact on AltID procurement by 6-12 months, potentially reducing the project's ROI by 10-20%. A negative response could necessitate a complete re-scoping of the project, resulting in a 50% reduction in the project's intended impact and a potential loss of 25-50% of the invested capital.

## Issue 2 - Inadequate Budget Allocation for External Security Reviews
The assumption that 250,000 DKK is sufficient for external security reviews may be unrealistic, especially considering the security-sensitive nature of digital identity infrastructure. The plan does not provide a detailed breakdown of the scope of the security reviews or the qualifications of the security firms to be engaged. Underfunding security reviews could lead to undetected vulnerabilities and undermine stakeholder confidence.

**Recommendation:** Conduct a thorough cost analysis of external security reviews, considering the scope of the demonstrators, the complexity of the authentication protocols, and the required level of assurance. Allocate at least 500,000 DKK for external security reviews, ensuring that qualified security firms with expertise in mobile security and authentication protocols are engaged. Implement a staged certification approach, starting with basic security checks and progressively increasing rigor based on stakeholder feedback and available budget.

**Sensitivity:** If the budget for external security reviews is insufficient (baseline: 250,000 DKK), the project could face a 10-20% increase in the risk of security vulnerabilities, potentially leading to reputational damage and financial penalties. A major security breach could reduce the project's ROI by 20-30% and delay the project's completion by 6-12 months.

## Issue 3 - Over-Reliance on Technical Lead and Insufficient Knowledge Transfer
The assumption that the technical lead will oversee the demonstrator development, with the additional engineer/contractor providing backup, is a single point of failure. The plan does not provide sufficient detail on knowledge transfer mechanisms or contingency plans for the technical lead's absence. This dependence on a single specialist poses a significant risk to project continuity and could lead to delays and reduced quality of deliverables.

**Recommendation:** Implement a comprehensive knowledge transfer program, including detailed documentation of key processes, cross-training initiatives, and regular knowledge-sharing sessions. Assign specific roles and responsibilities to each team member to ensure that no single individual holds critical knowledge. Develop contingency plans for the technical lead's absence, such as identifying backup personnel and establishing clear communication protocols. Consider engaging a second senior engineer to provide additional expertise and redundancy.

**Sensitivity:** If the technical lead becomes unavailable (baseline: full availability), the project could face a 3-6 month delay in demonstrator development, potentially reducing the project's ROI by 5-10%. The cost of replacing the technical lead could range from 100,000-200,000 DKK, further impacting the project's budget.

## Review conclusion
The project plan demonstrates a solid understanding of the technical and political landscape. However, it needs to address the identified missing assumptions to ensure its success. Prioritizing stakeholder engagement, securing adequate funding for security reviews, and mitigating the risk of over-reliance on key personnel are crucial for achieving the project's goals of improving Denmark's digital identity infrastructure.