**Goal Statement:** Establish the technical, regulatory, and political basis for formal platform-neutral access requirements and a certified fallback authentication path for Danish digital identity within 24 months.

## SMART Criteria

- **Specific:** Establish the groundwork for platform-neutral access requirements and a certified fallback authentication path for Danish digital identity.
- **Measurable:** The goal will be measured by the production of a feasibility report, functional demonstrators, a formal response from Digitaliseringsstyrelsen, and the inclusion of platform-neutrality language in AltID-related documents.
- **Achievable:** The goal is achievable given the budget of 10.5 million DKK, the 24-month timeframe, and the focus on influencing AltID rather than replacing MitID.
- **Relevant:** The goal is relevant because it addresses the Danish public-sector digital strategy for 2026–2029, which calls for reduced dependence on a small number of large foreign technology suppliers and for stronger digital sovereignty.
- **Time-bound:** The goal must be achieved within 24 months.

## Dependencies

- Secure funding for each phase of the project (3.0 million DKK for phase one, 4.0 million DKK for phase two, 3.5 million for phase three).
- Establish a project team with expertise in mobile security, regulatory compliance, policy, and technical demonstration.
- Secure a physical base in Copenhagen at a suitable research institution or R&D facility.

## Resources Required

- Funding of 10.5 million DKK.
- Access-controlled workspace in Copenhagen.
- Hardware and software for technical demonstrators.
- Legal and procurement support.
- External security review services.

## Related Goals

- Reduce Denmark's dependence on foreign technology suppliers.
- Strengthen Denmark's digital sovereignty.
- Improve the resilience and continuity of service for Danish digital identity.
- Influence EU standards for digital identity wallets.

## Tags

- digital identity
- platform neutrality
- digital sovereignty
- eIDAS2
- AltID
- procurement
- Denmark

## Risk Assessment and Mitigation Strategies


### Key Risks

- Delays in obtaining permits for demonstrators.
- Technical demonstrators may lack required security or functionality.
- Insufficient budget.
- Lack of stakeholder support from Digitaliseringsstyrelsen, MitID operator, or Folketinget.
- Security vulnerabilities in demonstrators.

### Diverse Risks

- Regulatory risks
- Financial risks
- Social risks
- Operational risks
- Supply chain risks
- Integration risks
- Environmental risks
- Long-term sustainability risks

### Mitigation Plans

- Engage Digitaliseringsstyrelsen early, develop alternative demonstrator designs, and secure legal advice.
- Conduct security reviews and penetration testing, engage security experts, and maintain a flexible design.
- Develop a detailed budget breakdown, track expenses, identify cost-saving measures, and explore additional funding sources.
- Build stakeholder relationships, tailor messaging, and highlight the benefits of platform neutrality.
- Implement robust security measures, conduct regular audits and testing, comply with relevant standards, and provide security training.

## Stakeholder Analysis


### Primary Stakeholders

- Lead Researcher
- Regulatory and Compliance Specialist
- Policy and Public Affairs Coordinator
- Technical Lead
- Engineers/Contractors

### Secondary Stakeholders

- Digitaliseringsstyrelsen
- MitID Operator
- Folketinget's Digital Policy Committee
- Civil-Society Organizations
- Privacy Advocates
- Academic Researchers
- Security Experts
- EU Bodies and Technical Working Groups

### Engagement Strategies

- Provide regular updates and progress reports to primary stakeholders.
- Engage Digitaliseringsstyrelsen through formal proposals and consultations.
- Build a coalition with civil-society organizations and privacy advocates.
- Engage with EU bodies and technical working groups to align Danish advocacy with broader European requirements.
- Provide timely notification of significant changes to project scope or timeline to secondary stakeholders.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Permits for demonstrator development and testing within public-sector environments.
- Licenses for software and hardware used in the project.

### Compliance Standards

- eIDAS Regulation
- NSIS (National Standard for Information Security)
- GDPR (General Data Protection Regulation)
- Danish data protection laws

### Regulatory Bodies

- Digitaliseringsstyrelsen
- European Commission
- Danish Data Protection Agency

### Compliance Actions

- Conduct a compliance review to ensure all project activities align with GDPR and Danish data protection laws.
- Engage a legal advisor to provide guidance on compliance issues and document their recommendations.
- Implement any necessary changes to project plans based on the legal advisor's feedback.
- Apply for necessary permits for demonstrator development and testing.
- Schedule compliance audits to ensure adherence to eIDAS and NSIS standards.