
## Documents to Create

### 1. Project Charter

**ID:** 656e61b7-707b-4888-aef9-a27b770f6a8b

**Description:** A formal document that initiates the project, defines its objectives, scope, and stakeholders. It outlines the project's purpose, goals, and high-level requirements, and assigns roles and responsibilities. It serves as a foundational agreement among key stakeholders.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope.
- Identify key stakeholders.
- Outline roles and responsibilities.
- Establish high-level budget and timeline.
- Obtain stakeholder sign-off.

**Approval Authorities:** Lead Researcher, Regulatory and Compliance Specialist, Policy and Public Affairs Coordinator

### 2. Risk Register

**ID:** f486ceef-bc89-425f-b5a7-c76ba208a38d

**Description:** A comprehensive log of identified project risks, their potential impact, likelihood, and mitigation strategies. It serves as a central repository for risk management activities throughout the project lifecycle.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential project risks.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for high-priority risks.
- Assign risk owners.
- Regularly review and update the register.

**Approval Authorities:** Lead Researcher, Technical Lead

### 3. Communication Plan

**ID:** 3ade1e09-60ea-4852-8994-96e05a311791

**Description:** A detailed plan outlining how project information will be communicated to stakeholders. It specifies communication channels, frequency, and responsible parties for different types of information.

**Responsible Role Type:** Policy and Public Affairs Coordinator

**Steps:**

- Identify key stakeholders and their communication needs.
- Define communication channels and frequency.
- Assign responsibility for communication tasks.
- Establish a process for managing communication feedback.
- Document communication protocols.

**Approval Authorities:** Project Manager

### 4. Stakeholder Engagement Plan

**ID:** cf9b09d9-89ac-4aed-8ef3-7a526b983b54

**Description:** A plan outlining strategies for engaging with key stakeholders to ensure their support and involvement in the project. It identifies stakeholder interests, influence, and communication preferences.

**Responsible Role Type:** Policy and Public Affairs Coordinator

**Steps:**

- Identify key stakeholders and their interests.
- Assess stakeholder influence and communication preferences.
- Develop engagement strategies for each stakeholder group.
- Establish a process for managing stakeholder feedback.
- Document stakeholder engagement protocols.

**Approval Authorities:** Project Manager

### 5. Change Management Plan

**ID:** 34322847-272a-4308-8b97-c29df66bb488

**Description:** A plan outlining the process for managing changes to the project scope, timeline, or budget. It defines the roles and responsibilities for change control and ensures that changes are properly documented and approved.

**Responsible Role Type:** Project Manager

**Steps:**

- Define the change control process.
- Identify roles and responsibilities for change control.
- Establish a process for documenting and approving changes.
- Communicate changes to stakeholders.
- Track and manage change requests.

**Approval Authorities:** Lead Researcher, Regulatory and Compliance Specialist

### 6. High-Level Budget/Funding Framework

**ID:** 38a55ce5-12cd-4538-b39b-f3a2912c4af1

**Description:** A high-level overview of the project budget, including funding sources, allocation of funds to different project phases, and contingency planning. It provides a financial roadmap for the project.

**Responsible Role Type:** Project Manager

**Steps:**

- Identify all project costs.
- Allocate costs to different project phases.
- Identify funding sources.
- Develop a contingency plan for budget overruns.
- Obtain approval from funding sources.

**Approval Authorities:** Lead Researcher

### 7. Funding Agreement Structure/Template

**ID:** a46f646d-0eb3-461d-abbf-f8162dfced7d

**Description:** A template for formal agreements with funding sources, outlining the terms and conditions of funding, reporting requirements, and intellectual property rights. It ensures a clear understanding between the project and its funders.

**Responsible Role Type:** Regulatory and Compliance Specialist

**Steps:**

- Define the terms and conditions of funding.
- Outline reporting requirements.
- Specify intellectual property rights.
- Obtain legal review.
- Obtain approval from funding sources.

**Approval Authorities:** Lead Researcher, Project Manager

### 8. Initial High-Level Schedule/Timeline

**ID:** ddfad734-6aad-4064-8b62-87c371a92f0a

**Description:** A high-level timeline outlining the key project milestones, deliverables, and deadlines. It provides a roadmap for project execution and helps track progress.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify key project milestones and deliverables.
- Estimate the duration of each task.
- Establish dependencies between tasks.
- Create a timeline using project management software.
- Obtain stakeholder approval.

**Approval Authorities:** Lead Researcher, Technical Lead

### 9. M&E Framework

**ID:** b7b94022-80b1-444e-897a-b2abd40cea01

**Description:** A framework for monitoring and evaluating the project's progress and impact. It defines key performance indicators (KPIs), data collection methods, and reporting requirements. It ensures that the project is on track to achieve its objectives and provides valuable insights for future projects.

**Responsible Role Type:** Project Manager

**Primary Template:** Logical Framework Template

**Steps:**

- Define project objectives and outcomes.
- Identify key performance indicators (KPIs).
- Establish data collection methods.
- Define reporting requirements.
- Obtain stakeholder approval.

**Approval Authorities:** Lead Researcher, Policy and Public Affairs Coordinator

### 10. Current State Assessment of Digital Identity Infrastructure

**ID:** 8c313beb-2553-4817-adeb-1fab73168d04

**Description:** A comprehensive assessment of the current state of Denmark's digital identity infrastructure, including its strengths, weaknesses, and dependencies. It provides a baseline for measuring the project's impact and identifying areas for improvement.

**Responsible Role Type:** Lead Researcher

**Steps:**

- Gather data on the current digital identity infrastructure.
- Analyze the strengths and weaknesses of the current system.
- Identify dependencies on foreign technology providers.
- Assess the security and resilience of the current system.
- Document the findings in a comprehensive report.

**Approval Authorities:** Project Manager

### 11. Platform Neutrality and Fallback Authentication Strategy

**ID:** bcf6007b-9710-4632-a022-b1d4f75de20e

**Description:** A strategic plan outlining the project's approach to promoting platform neutrality and fallback authentication in Denmark's digital identity infrastructure. It defines the project's goals, objectives, and key strategies for achieving them.

**Responsible Role Type:** Lead Researcher

**Steps:**

- Define the project's goals and objectives.
- Identify key strategies for promoting platform neutrality and fallback authentication.
- Outline the project's approach to influencing AltID procurement and standards.
- Develop a timeline for implementing the strategy.
- Obtain stakeholder approval.

**Approval Authorities:** Project Manager, Policy and Public Affairs Coordinator

### 12. Technical Demonstrator Development Framework

**ID:** dc9ee6eb-c347-49f3-ace4-a20c4b7be509

**Description:** A framework outlining the approach to developing technical demonstrators that showcase the feasibility and security of platform-neutral alternatives. It defines the scope, functionality, and security requirements for the demonstrators.

**Responsible Role Type:** Technical Lead

**Steps:**

- Define the scope and functionality of the demonstrators.
- Establish security requirements for the demonstrators.
- Identify the technologies to be used in the demonstrators.
- Develop a timeline for developing the demonstrators.
- Obtain stakeholder approval.

**Approval Authorities:** Project Manager, Lead Researcher

### 13. Policy Influence and Advocacy Framework

**ID:** 495faf32-59b6-4a0d-8a5a-78663bbcf24d

**Description:** A framework outlining the project's approach to influencing policy and advocacy efforts related to platform neutrality and fallback authentication. It defines the project's target audience, key messages, and communication channels.

**Responsible Role Type:** Policy and Public Affairs Coordinator

**Steps:**

- Identify the project's target audience.
- Define the project's key messages.
- Identify the communication channels to be used.
- Develop a timeline for implementing the framework.
- Obtain stakeholder approval.

**Approval Authorities:** Project Manager, Lead Researcher

### 14. Coalition Building and Stakeholder Engagement Strategy

**ID:** 82655e3c-deaa-45c2-8428-1662815277ad

**Description:** A strategy outlining the project's approach to building a strong coalition of stakeholders to support its goals. It defines the project's target stakeholders, engagement methods, and communication channels.

**Responsible Role Type:** Policy and Public Affairs Coordinator

**Steps:**

- Identify the project's target stakeholders.
- Define the project's engagement methods.
- Identify the communication channels to be used.
- Develop a timeline for implementing the strategy.
- Obtain stakeholder approval.

**Approval Authorities:** Project Manager, Lead Researcher

## Documents to Find

### 1. Participating Nations Digital Identity Policies/Laws/Regulations

**ID:** 515c45fe-6cae-4b62-897e-5142f59d67f0

**Description:** Existing policies, laws, and regulations related to digital identity in Denmark and other relevant EU member states. This information is needed to understand the current regulatory landscape and identify opportunities for influencing policy changes. Intended audience: Regulatory and Compliance Specialist, Policy and Public Affairs Coordinator.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Regulatory and Compliance Specialist

**Access Difficulty:** Medium: Requires searching government portals and potentially contacting government agencies.

**Steps:**

- Search government legislative portals.
- Contact relevant government agencies.
- Consult legal databases.

### 2. Participating Nations eIDAS Implementation Guidelines

**ID:** 3ae9ec07-1783-4045-807f-bbf4bef96313

**Description:** Guidelines and best practices for implementing the eIDAS regulation in Denmark and other relevant EU member states. This information is needed to ensure compliance with EU standards and promote interoperability. Intended audience: Regulatory and Compliance Specialist, Technical Lead.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Regulatory and Compliance Specialist

**Access Difficulty:** Medium: Requires searching the European Commission website and potentially contacting national eID authorities.

**Steps:**

- Search the European Commission website.
- Contact national eID authorities.
- Consult industry experts.

### 3. Existing National Digital Identity System Technical Specifications

**ID:** f517501b-2110-40eb-a2de-6b6a4c3cbfb0

**Description:** Technical specifications for existing digital identity systems in Denmark (MitID) and other relevant EU member states (e.g., BankID in Sweden). This information is needed to understand the technical requirements for integrating with existing systems and developing interoperable solutions. Intended audience: Technical Lead, Web Authentication Engineer, Linux/GrapheneOS Implementation Engineer.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Technical Lead

**Access Difficulty:** Medium: Requires contacting system operators and searching technical documentation.

**Steps:**

- Contact system operators.
- Search technical documentation.
- Consult industry experts.

### 4. Official National Digital Identity Usage Statistics

**ID:** f057ec19-8090-46ac-9059-e2de0321b258

**Description:** Statistical data on the usage of digital identity systems in Denmark (MitID) and other relevant EU member states. This information is needed to understand the adoption rates and user preferences for different digital identity solutions. Intended audience: Lead Researcher, Policy and Public Affairs Coordinator.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Lead Researcher

**Access Difficulty:** Medium: Requires contacting national statistical offices and searching government publications.

**Steps:**

- Contact national statistical offices.
- Search government publications.
- Consult industry reports.

### 5. Existing National Procurement Policies for Digital Services

**ID:** 23c3aa0b-4ac6-47e8-8e65-df4e270e0f69

**Description:** Policies and guidelines for procuring digital services in Denmark, including any requirements related to platform neutrality or open standards. This information is needed to understand the current procurement landscape and identify opportunities for influencing future procurement decisions. Intended audience: Regulatory and Compliance Specialist, Policy and Public Affairs Coordinator.

**Recency Requirement:** Current policies essential

**Responsible Role Type:** Regulatory and Compliance Specialist

**Access Difficulty:** Medium: Requires searching government procurement portals and potentially contacting government agencies.

**Steps:**

- Search government procurement portals.
- Contact relevant government agencies.
- Consult legal databases.

### 6. Official National Security Standards for Digital Infrastructure

**ID:** 9bb17349-dcfc-4c01-8192-fde2b59e12e9

**Description:** Security standards and guidelines for digital infrastructure in Denmark (NSIS) and other relevant EU member states. This information is needed to ensure that the project's technical demonstrators meet the required security standards. Intended audience: Technical Lead, Security Review Specialist.

**Recency Requirement:** Current standards essential

**Responsible Role Type:** Technical Lead

**Access Difficulty:** Medium: Requires searching government websites and potentially contacting government agencies.

**Steps:**

- Search government websites.
- Contact relevant government agencies.
- Consult industry experts.

### 7. EU Digital Identity Wallet Framework Documentation

**ID:** a04cfa07-62b2-4ca4-b970-ac53cf1b757e

**Description:** Documentation and specifications for the European Digital Identity Wallet framework. This information is needed to align the project's efforts with broader European requirements and promote interoperability. Intended audience: Technical Lead, Policy and Public Affairs Coordinator.

**Recency Requirement:** Most recent available

**Responsible Role Type:** Policy and Public Affairs Coordinator

**Access Difficulty:** Medium: Requires searching the European Commission website and potentially contacting relevant EU bodies.

**Steps:**

- Search the European Commission website.
- Contact relevant EU bodies.
- Consult industry experts.

### 8. Existing National Data Protection Laws

**ID:** 038a7424-1c1d-4610-a203-1e01e07d11cc

**Description:** Data protection laws and regulations in Denmark (GDPR implementation) relevant to digital identity systems. This information is needed to ensure compliance with data privacy requirements. Intended audience: Regulatory and Compliance Specialist.

**Recency Requirement:** Current laws essential

**Responsible Role Type:** Regulatory and Compliance Specialist

**Access Difficulty:** Easy: Readily available on government websites and legal databases.

**Steps:**

- Search government legislative portals.
- Consult legal databases.
- Contact the Danish Data Protection Agency.

### 9. Official National Accessibility Standards for Digital Services

**ID:** d19313d0-cab9-4f3a-bffc-6783dc1bcc54

**Description:** Accessibility standards and guidelines for digital services in Denmark, ensuring inclusivity for all users. This information is needed to ensure that the project's technical demonstrators are accessible to people with disabilities. Intended audience: Technical Lead, Web Authentication Engineer, Linux/GrapheneOS Implementation Engineer.

**Recency Requirement:** Current standards essential

**Responsible Role Type:** Technical Lead

**Access Difficulty:** Medium: Requires searching government websites and potentially contacting relevant government agencies.

**Steps:**

- Search government websites.
- Contact relevant government agencies.
- Consult accessibility experts.

### 10. Official National Public Opinion Surveys on Digital Identity

**ID:** 2798ff0c-2423-42d1-b31f-b63255e5aa64

**Description:** Results of public opinion surveys in Denmark related to digital identity, privacy, and security. This information is needed to understand public attitudes and preferences for different digital identity solutions. Intended audience: Lead Researcher, Policy and Public Affairs Coordinator.

**Recency Requirement:** Within last 5 years

**Responsible Role Type:** Lead Researcher

**Access Difficulty:** Medium: Requires contacting national statistical offices and searching government publications.

**Steps:**

- Contact national statistical offices.
- Search government publications.
- Consult research institutions.