This plan involves money.

## Currencies

- **DKK:** The project budget is specified in Danish Krone, and the primary location is Denmark.

**Primary currency:** DKK

**Currency strategy:** The Danish Krone will be used for all transactions. No additional international risk management is needed.