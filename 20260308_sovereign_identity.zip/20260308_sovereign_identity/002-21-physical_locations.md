This plan implies one or more physical locations.

## Requirements for physical locations

- Access-controlled workspace
- Appropriate for security-sensitive digital identity research
- Development and stakeholder meetings

## Location 1
Denmark

Copenhagen

Danish university, independent research institution, or security-qualified R&D facility

**Rationale**: The project's primary physical base is specified to be in Copenhagen, Denmark, at a Danish university, independent research institution, or security-qualified R&D facility.

## Location 2
Denmark

Copenhagen, Innovation District

Symbion Science Park, Fruebjergvej 3, 2100 Copenhagen

**Rationale**: Symbion Science Park in Copenhagen's Innovation District offers a collaborative environment with access to resources and potential partners relevant to digital identity research and development.

## Location 3
Denmark

Copenhagen, University District

University of Copenhagen, Nørregade 10, 1165 Copenhagen

**Rationale**: The University of Copenhagen provides access to academic expertise, research facilities, and potential student talent, fostering innovation and collaboration in digital identity research.

## Location 4
Denmark

Copenhagen, City Center

R&D office space in central Copenhagen

**Rationale**: A centrally located R&D office space in Copenhagen provides easy access to government agencies, stakeholders, and potential partners, facilitating policy engagement and coalition building.

## Location Summary
The project requires a physical base in Copenhagen, Denmark, at a Danish university, independent research institution, or security-qualified R&D facility. Additional suggestions include Symbion Science Park, the University of Copenhagen, and a centrally located R&D office space to facilitate collaboration and stakeholder engagement.