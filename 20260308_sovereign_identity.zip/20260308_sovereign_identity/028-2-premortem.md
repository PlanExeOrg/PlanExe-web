A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Digitaliseringsstyrelsen is genuinely committed to exploring platform-neutral alternatives and will act in good faith to evaluate the project's proposals. | Track all interactions with Digitaliseringsstyrelsen, noting response times, feedback, and any signs of resistance or bias towards incumbent solutions. | Consistent delays in communication, dismissive feedback, or clear preference for platform-dependent solutions despite evidence to the contrary. |
| A2 | The necessary hardware and software components for the technical demonstrators will be readily available and within budget throughout the project lifecycle. | Obtain firm quotes from multiple suppliers for all key hardware and software components, and assess lead times and potential supply chain disruptions. | Significant price increases, long lead times, or unavailability of critical components that would jeopardize the demonstrator development timeline or budget. |
| A3 | The Danish public will readily adopt and trust platform-neutral digital identity solutions if they are technically sound and offer comparable functionality to existing solutions. | Conduct user surveys and focus groups to assess public awareness, attitudes, and concerns regarding digital identity and platform neutrality. | Widespread skepticism, lack of interest, or strong preference for existing platform-dependent solutions despite evidence of security or privacy benefits of platform-neutral alternatives. |
| A4 | The project team possesses sufficient expertise and experience in all relevant areas (mobile security, regulatory compliance, policy advocacy, technical demonstration) to execute the project successfully without significant external assistance. | Conduct a skills gap analysis of the project team, identifying areas where expertise is lacking or limited. | The skills gap analysis reveals significant deficiencies in key areas that cannot be addressed through internal training or mentoring, requiring extensive external consulting or new hires. |
| A5 | The project's focus on platform neutrality will not inadvertently create new security vulnerabilities or compromise the usability of digital identity solutions for certain user groups (e.g., elderly, disabled). | Conduct thorough security audits and usability testing of the technical demonstrators, specifically focusing on potential vulnerabilities and accessibility issues. | Security audits reveal new vulnerabilities introduced by the platform-neutral design, or usability testing demonstrates significant accessibility barriers for certain user groups. |
| A6 | The project's recommendations for platform-neutral access and fallback authentication will be compatible with the evolving technical landscape and will not become obsolete or irrelevant due to unforeseen technological advancements. | Continuously monitor emerging authentication technologies and assess their potential impact on the project's recommendations, updating the feasibility assessment as needed. | A new authentication technology emerges that renders the project's proposed solutions significantly less secure, less usable, or less cost-effective. |
| A7 | The Danish legal framework surrounding digital identity is sufficiently clear and stable to allow for the effective implementation of platform-neutral solutions without facing unforeseen legal challenges or ambiguities. | Engage legal experts to conduct a thorough review of the Danish legal framework, identifying potential ambiguities or conflicting regulations that could hinder the implementation of platform-neutral solutions. | The legal review reveals significant ambiguities or conflicting regulations that would require legislative changes or legal interpretations to implement platform-neutral solutions effectively. |
| A8 | The project's focus on technical demonstrators will effectively translate into real-world policy changes and procurement practices that favor platform-neutral solutions. | Develop a detailed plan for translating the findings from the technical demonstrators into concrete policy recommendations and procurement guidelines, and engage with policymakers to assess their receptiveness to these recommendations. | Policymakers express skepticism about the feasibility or practicality of implementing the project's recommendations, or procurement officials indicate that existing regulations or practices would prevent them from favoring platform-neutral solutions. |
| A9 | The project's coalition partners will remain actively engaged and aligned with the project's goals throughout the 24-month timeframe, providing consistent support and advocacy for platform neutrality. | Establish clear communication channels and engagement activities with coalition partners, and regularly assess their level of engagement and alignment with the project's goals. | Significant coalition partners withdraw their support, express conflicting views, or fail to actively participate in project activities. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Bureaucratic Black Hole | Process/Financial | A1 | Policy and Public Affairs Coordinator | CRITICAL (16/25) |
| FM2 | The Supply Chain Sabotage | Technical/Logistical | A2 | Technical Lead | CRITICAL (15/25) |
| FM3 | The Public Apathy Abyss | Market/Human | A3 | Policy and Public Affairs Coordinator | HIGH (12/25) |
| FM4 | The Expertise Erosion | Process/Financial | A4 | Project Manager | HIGH (12/25) |
| FM5 | The Unintended Vulnerability Vortex | Technical/Logistical | A5 | Technical Lead | CRITICAL (15/25) |
| FM6 | The Technological Time Warp | Market/Human | A6 | Lead Researcher | MEDIUM (8/25) |
| FM7 | The Legal Labyrinth | Process/Financial | A7 | Regulatory and Compliance Specialist | HIGH (12/25) |
| FM8 | The Policy Translation Turmoil | Technical/Logistical | A8 | Policy and Public Affairs Coordinator | CRITICAL (20/25) |
| FM9 | The Coalition Collapse Catastrophe | Market/Human | A9 | Policy and Public Affairs Coordinator | MEDIUM (8/25) |


### Failure Modes

#### FM1 - The Bureaucratic Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Policy and Public Affairs Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project's success hinges on influencing Digitaliseringsstyrelsen. If the agency is not genuinely committed to platform-neutrality, the project will fail. 
*   Digitaliseringsstyrelsen may delay responses, provide vague feedback, or prioritize incumbent solutions.
*   This leads to delays in policy influence and procurement changes.
*   The project's recommendations are ignored, and AltID continues to rely on platform-dependent solutions.
*   The project wastes resources on advocacy efforts with no tangible impact.

##### Early Warning Signs
- Digitaliseringsstyrelsen consistently misses deadlines for providing feedback.
- Meeting requests with Digitaliseringsstyrelsen are repeatedly postponed or cancelled.
- Digitaliseringsstyrelsen expresses skepticism about the feasibility or benefits of platform-neutral solutions.

##### Tripwires
- Digitaliseringsstyrelsen response time exceeds 90 days for initial proposal.
- Digitaliseringsstyrelsen rejects the inclusion of platform-neutrality language in AltID procurement documents.
- Digitaliseringsstyrelsen cancels scheduled meetings for 2 consecutive months.

##### Response Playbook
- Contain: Immediately escalate concerns to project leadership and key stakeholders.
- Assess: Conduct a thorough review of all communication and interactions with Digitaliseringsstyrelsen to identify the root cause of the resistance.
- Respond: Shift focus to EU-level advocacy and build stronger alliances with industry partners and civil society organizations to exert external pressure.


**STOP RULE:** Digitaliseringsstyrelsen formally announces a decision to proceed with AltID that explicitly excludes platform-neutrality requirements.

---

#### FM2 - The Supply Chain Sabotage

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Technical Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project relies on specific hardware and software components for the technical demonstrators. If these components become unavailable or significantly more expensive, the project will be severely hampered.
*   A key supplier goes bankrupt or discontinues a critical product.
*   Global chip shortages or geopolitical events disrupt the supply chain.
*   The cost of necessary components exceeds the allocated budget.
*   The demonstrators cannot be built as planned, reducing their functionality and impact.

##### Early Warning Signs
- Key suppliers announce production delays or price increases.
- Critical components become backordered or unavailable from multiple vendors.
- The project's budget for hardware and software is consistently overspent.

##### Tripwires
- Lead times for critical hardware components exceed 120 days.
- The cost of key software licenses increases by more than 25%.
- Alternative suppliers cannot be identified within 30 days of a component becoming unavailable.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and initiate a search for alternative components.
- Assess: Conduct a thorough review of the demonstrator design to identify potential areas for simplification or component substitution.
- Respond: Reduce the scope of the demonstrators to focus on core functionality that can be achieved with available components, or pivot to alternative technologies.


**STOP RULE:** The core functionality of the demonstrators cannot be achieved due to component unavailability or budget constraints, rendering them ineffective.

---

#### FM3 - The Public Apathy Abyss

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Policy and Public Affairs Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes that the Danish public will embrace platform-neutral digital identity solutions. If the public is apathetic or resistant, the project's impact will be limited.
*   The public is unaware of the benefits of platform neutrality or digital sovereignty.
*   Existing platform-dependent solutions are perceived as more convenient or secure.
*   The public is concerned about the complexity or usability of alternative solutions.
*   The project fails to gain public support, and policymakers are unwilling to prioritize platform neutrality.

##### Early Warning Signs
- User surveys reveal low awareness of platform neutrality and digital sovereignty.
- Focus groups express skepticism about the security or usability of alternative solutions.
- Social media engagement with the project's messaging is minimal.

##### Tripwires
- Less than 25% of survey respondents express interest in platform-neutral digital identity solutions.
- Focus groups consistently rate existing platform-dependent solutions as more convenient.
- Social media engagement (likes, shares, comments) falls below 100 per week.

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to educate the public about the benefits of platform neutrality and digital sovereignty.
- Assess: Conduct a thorough review of the project's messaging and communication strategy to identify areas for improvement.
- Respond: Partner with influential figures and organizations to promote the project's message and build public support, and simplify the user experience of the demonstrators.


**STOP RULE:** Public opinion polls consistently show a lack of support for platform-neutral digital identity solutions, making policy change politically infeasible.

---

#### FM4 - The Expertise Erosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes the team has all the necessary skills. If the team lacks critical expertise, the project will suffer.
*   The team underestimates the complexity of mobile security or regulatory compliance.
*   Poorly designed demonstrators fail to meet security standards or user needs.
*   Policy proposals are ineffective due to a lack of understanding of the political landscape.
*   The project fails to achieve its goals due to a lack of expertise.

##### Early Warning Signs
- Project deliverables are consistently late or of poor quality.
- Team members express uncertainty or lack of confidence in their ability to complete tasks.
- External stakeholders raise concerns about the team's expertise or competence.

##### Tripwires
- The skills gap analysis identifies critical deficiencies in key areas.
- External consultants are required for more than 20% of project tasks.
- Project deliverables are rated as 'unsatisfactory' by external reviewers.

##### Response Playbook
- Contain: Immediately identify and address the skills gaps through training, mentoring, or external consulting.
- Assess: Conduct a thorough review of the project plan to identify tasks that require specialized expertise.
- Respond: Reallocate resources to secure external expertise or adjust the project scope to align with the team's capabilities.


**STOP RULE:** The project team is unable to acquire the necessary expertise to address critical skills gaps, rendering the project unviable.

---

#### FM5 - The Unintended Vulnerability Vortex

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Technical Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes platform neutrality won't create new security or usability issues. If it does, the project will backfire.
*   Platform-neutral solutions introduce new attack vectors or vulnerabilities.
*   Usability is compromised for certain user groups (e.g., elderly, disabled).
*   The project loses credibility due to security breaches or accessibility issues.
*   The public rejects the solutions due to usability concerns.

##### Early Warning Signs
- Security audits reveal new vulnerabilities in the platform-neutral design.
- Usability testing demonstrates significant accessibility barriers for certain user groups.
- Stakeholders express concerns about the security or usability of the solutions.

##### Tripwires
- Security audits identify critical vulnerabilities that cannot be easily remediated.
- Usability testing demonstrates that the solutions are significantly less usable than existing solutions for more than 20% of users.
- Accessibility testing reveals non-compliance with WCAG guidelines.

##### Response Playbook
- Contain: Immediately halt the deployment of the affected solutions and initiate a thorough security and usability review.
- Assess: Conduct a root cause analysis to identify the source of the vulnerabilities or usability issues.
- Respond: Redesign the solutions to address the security and usability concerns, or pivot to alternative approaches.


**STOP RULE:** The security vulnerabilities or usability issues cannot be resolved without compromising the core principles of platform neutrality.

---

#### FM6 - The Technological Time Warp

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Lead Researcher
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The project assumes its recommendations will remain relevant. If technology evolves rapidly, the project will be obsolete.
*   A new authentication technology emerges that renders the project's solutions obsolete.
*   Existing solutions become more secure or user-friendly, negating the benefits of platform neutrality.
*   The project's recommendations are ignored due to their perceived irrelevance.
*   The project's impact is limited due to technological obsolescence.

##### Early Warning Signs
- New authentication technologies emerge that offer superior security or usability.
- Existing platform-dependent solutions become more secure or user-friendly.
- Stakeholders express concerns about the long-term relevance of the project's recommendations.

##### Tripwires
- A new authentication technology gains widespread adoption and offers significantly better security or usability.
- Existing platform-dependent solutions implement security enhancements that negate the benefits of platform neutrality.
- Stakeholders consistently express concerns about the long-term relevance of the project's recommendations.

##### Response Playbook
- Contain: Continuously monitor emerging authentication technologies and assess their potential impact on the project's recommendations.
- Assess: Conduct a thorough review of the project's recommendations to identify areas that may be vulnerable to technological obsolescence.
- Respond: Adapt the project's recommendations to incorporate new technologies or pivot to alternative approaches that are more future-proof.


**STOP RULE:** A new authentication technology emerges that renders the project's proposed solutions significantly less secure, less usable, or less cost-effective, and the project is unable to adapt.

---

#### FM7 - The Legal Labyrinth

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Regulatory and Compliance Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes a clear legal framework. If the legal landscape is ambiguous, the project will be stalled.
*   Conflicting regulations or legal challenges arise, delaying implementation.
*   Legal costs escalate due to the need for interpretations or legislative changes.
*   The project's recommendations are deemed legally unsound, hindering policy influence.
*   The project's budget is depleted by legal fees, reducing resources for other activities.

##### Early Warning Signs
- Legal experts identify significant ambiguities or conflicting regulations.
- The project receives legal challenges from stakeholders.
- The cost of legal advice exceeds the allocated budget.

##### Tripwires
- The legal review identifies more than 3 significant ambiguities or conflicting regulations.
- The project receives a formal legal challenge from a stakeholder.
- Legal fees exceed 150,000 DKK.

##### Response Playbook
- Contain: Immediately engage legal counsel to assess the legal challenges and develop a mitigation strategy.
- Assess: Conduct a thorough review of the project plan to identify areas that may be affected by the legal ambiguities.
- Respond: Adjust the project scope or recommendations to align with the legal framework, or advocate for legislative changes.


**STOP RULE:** The legal challenges cannot be resolved without compromising the core principles of platform neutrality, or the cost of legal fees exceeds 500,000 DKK.

---

#### FM8 - The Policy Translation Turmoil

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Policy and Public Affairs Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project assumes the demonstrators will translate into policy change. If policymakers are unreceptive, the project will fail to influence AltID.
*   Policymakers are skeptical about the feasibility or practicality of the recommendations.
*   Procurement officials indicate that existing regulations prevent favoring platform neutrality.
*   The project fails to bridge the gap between technical feasibility and policy implementation.
*   The demonstrators remain isolated prototypes with no real-world impact.

##### Early Warning Signs
- Policymakers express skepticism about the feasibility or practicality of the recommendations.
- Procurement officials indicate that existing regulations would prevent them from favoring platform-neutral solutions.
- The project struggles to secure meetings with key policymakers.

##### Tripwires
- Policymakers reject the inclusion of platform-neutrality language in AltID procurement documents.
- Procurement officials state that existing regulations prevent them from favoring platform-neutral solutions.
- The project fails to secure meetings with key policymakers for 3 consecutive months.

##### Response Playbook
- Contain: Immediately reassess the policy recommendations and identify areas for improvement or compromise.
- Assess: Conduct a thorough review of the communication strategy to identify ways to better convey the benefits of platform neutrality to policymakers.
- Respond: Engage with influential figures and organizations to advocate for policy changes, or pivot to alternative policy levers.


**STOP RULE:** Policymakers formally reject the project's recommendations and indicate that they will not prioritize platform neutrality in AltID.

---

#### FM9 - The Coalition Collapse Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Policy and Public Affairs Coordinator
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The project assumes coalition partners will remain engaged. If they withdraw support, the project's influence will diminish.
*   Significant partners withdraw due to conflicting views or priorities.
*   Partners fail to actively participate in project activities.
*   The coalition fragments, reducing its collective influence.
*   The project loses credibility and struggles to advocate for policy changes.

##### Early Warning Signs
- Significant coalition partners express conflicting views or priorities.
- Partners fail to actively participate in project activities.
- Communication with coalition partners becomes infrequent or strained.

##### Tripwires
- More than 25% of coalition partners withdraw their support.
- Key coalition partners fail to attend scheduled meetings for 2 consecutive months.
- Communication with coalition partners becomes infrequent or strained.

##### Response Playbook
- Contain: Immediately reach out to the affected partners to address their concerns and reaffirm the project's goals.
- Assess: Conduct a thorough review of the coalition's governance structure and communication channels to identify areas for improvement.
- Respond: Recruit new partners to replace those who have withdrawn, or adjust the project's goals to align with the remaining partners' priorities.


**STOP RULE:** The coalition collapses, and the project is unable to secure sufficient support for its policy recommendations.
