# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** The plan aims for national-level impact on Denmark's digital identity infrastructure, seeking to reduce reliance on foreign tech suppliers and establish a platform-neutral fallback. While not revolutionary, it targets a significant shift in procurement and standards.

**Risk and Novelty:** The plan involves moderate risk. It's not entirely novel, as it leverages existing standards like FIDO2/WebAuthn. However, influencing procurement and standards within a conservative ecosystem like MitID presents challenges. The project explicitly avoids building a production-ready replacement, mitigating some risk.

**Complexity and Constraints:** The plan is complex, involving technical demonstrators, policy proposals, coalition building, and engagement with EU bodies. Constraints include a 24-month timeline and a 10.5 million DKK budget. Institutional inertia, regulatory friction, and incumbent resistance are also anticipated.

**Domain and Tone:** The plan is in the domain of digital governance and public administration. The tone is pragmatic and solution-oriented, focusing on resilience, continuity of service, and supplier concentration risk.

**Holistic Profile:** The plan is a pragmatic, moderately risky initiative to improve Denmark's digital identity infrastructure by reducing platform dependency through technical demonstration, policy advocacy, and coalition building, operating within a constrained budget and timeline.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder's Foundation
**Strategic Logic:** This scenario seeks a pragmatic balance between innovation and stability. It focuses on building a solid foundation for platform neutrality through functional requirements and broad stakeholder engagement. This path aims for steady progress while managing risks and fostering collaboration with existing institutions.

**Fit Score:** 9/10

**Why This Path Was Chosen:** This scenario aligns well with the plan's focus on building a solid foundation through functional requirements, broad stakeholder engagement, and a balanced approach to innovation and stability. It reflects the plan's pragmatic and collaborative nature.

**Key Strategic Decisions:**

- **Procurement Language Specificity:** Establish functional requirements for fallback authentication paths, mandating that all digital identity systems must offer a certified alternative that does not rely on Apple or Google platform services
- **Technical Demonstrator Scope:** Expand the demonstrator to include integration with a simulated Danish public-sector service, showcasing end-to-end functionality and user experience
- **Coalition Partner Breadth:** Expand the coalition to include security experts, contingency-planning stakeholders, and sympathetic members of Folketinget's digital policy committee to broaden the base of support
- **Policy Framing Emphasis:** Adopt a balanced approach that addresses both resilience and privacy concerns, demonstrating how platform-neutral solutions can enhance both security and user autonomy
- **Digitaliseringsstyrelsen Engagement Depth:** Focus on informal channels and relationships within Digitaliseringsstyrelsen, cultivating internal champions and building support for platform-neutrality and fallback access from the inside

**The Decisive Factors:**

The Builder's Foundation is the most suitable scenario because its strategic logic aligns with the plan's pragmatic and balanced approach. The plan aims to build a solid foundation for platform neutrality through functional requirements and broad stakeholder engagement, mirroring the scenario's core tenets. 

*   The plan's ambition is to achieve steady progress while managing risks, which aligns with the scenario's focus on a pragmatic balance between innovation and stability.
*   The plan's complexity requires collaboration with existing institutions, a key element of the Builder's Foundation scenario.
*   The Pioneer's Gambit is too aggressive, while The Consolidator's Shield is too risk-averse for the plan's intended impact.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** This scenario aggressively pursues technological leadership and platform independence. It prioritizes innovation and comprehensive solutions, accepting higher risks and costs to establish Denmark as a frontrunner in digital sovereignty. This path aims to set a new standard for digital identity, even if it faces significant resistance from incumbents.

**Fit Score:** 6/10

**Assessment of this Path:** This scenario is too aggressive for the plan's pragmatic approach. While the plan aims for platform independence, it acknowledges the need to work within existing structures and doesn't prioritize radical innovation at all costs.

**Key Strategic Decisions:**

- **Procurement Language Specificity:** Define precise technical standards for platform-neutral authentication methods, such as requiring support for specific FIDO2 profiles and open-source cryptographic libraries
- **Technical Demonstrator Scope:** Develop multiple demonstrators, each showcasing a different fallback authentication method, such as browser-based authentication or hardware-token integration, to maximize coverage
- **Coalition Partner Breadth:** Actively engage with industry representatives and technology vendors who are committed to open standards and platform-neutral solutions, fostering collaboration and knowledge sharing
- **Policy Framing Emphasis:** Emphasize privacy and democratic accountability concerns, focusing on the need for greater transparency and control over digital identity data
- **Digitaliseringsstyrelsen Engagement Depth:** Establish a formal advisory role with Digitaliseringsstyrelsen, providing ongoing technical input and policy recommendations throughout the AltID development process

### The Consolidator's Shield
**Strategic Logic:** This scenario prioritizes stability, cost-control, and risk-aversion above all. It focuses on resilience framing and targeted coalition-building to achieve incremental improvements in platform neutrality. This path aims to minimize disruption and ensure continuity of service, even if it means accepting some level of platform dependency.

**Fit Score:** 5/10

**Assessment of this Path:** This scenario is too conservative. While the plan acknowledges the need for stability and cost-control, it also aims for more than just incremental improvements. The plan's ambition exceeds the risk-averse approach of this scenario.

**Key Strategic Decisions:**

- **Procurement Language Specificity:** Incorporate supplier-diversity criteria into the procurement process, giving preference to vendors who demonstrate a commitment to open standards and reduced platform lock-in
- **Technical Demonstrator Scope:** Prioritize a lean demonstrator focused solely on core authentication flows using FIDO2/WebAuthn on GrapheneOS, minimizing integration with non-essential services
- **Coalition Partner Breadth:** Focus coalition-building efforts on civil-society organizations, privacy advocates, and academic researchers with a shared interest in digital sovereignty
- **Policy Framing Emphasis:** Frame the issue primarily as a resilience and continuity-of-service risk, highlighting the potential impact of platform outages or policy changes on essential public services
- **Digitaliseringsstyrelsen Engagement Depth:** Maintain an arm's-length relationship with Digitaliseringsstyrelsen, submitting formal proposals and responding to consultations without seeking deeper integration
