# Purpose
# Denmark's Digital Identity Infrastructure Improvement

## Purpose

- Reduce dependency on foreign technology.
- Establish platform-neutral fallback authentication.

## Detailed Purpose

- Improve Denmark's digital identity infrastructure.


# Plan Type
# Physical Location Requirement

- Project requires physical locations.
- Cannot be executed digitally.

## Explanation

- Requires physical base in Copenhagen for research, development, stakeholder meetings.
- Involves building demonstrators, engaging with government, influencing procurement.
- Necessitates physical presence and interaction.
- Requires access-controlled workspace for security-sensitive digital identity research, development, and stakeholder meetings.


# Physical Locations
This plan implies one or more physical locations.

## Requirements for physical locations

- Access-controlled workspace
- Appropriate for security-sensitive digital identity research
- Development and stakeholder meetings

## Location 1
Denmark, Copenhagen
Danish university, independent research institution, or security-qualified R&D facility
Rationale: Project's primary physical base.

## Location 2
Denmark, Copenhagen, Innovation District
Symbion Science Park, Fruebjergvej 3, 2100 Copenhagen
Rationale: Collaborative environment, access to resources and potential partners.

## Location 3
Denmark, Copenhagen, University District
University of Copenhagen, Nørregade 10, 1165 Copenhagen
Rationale: Access to academic expertise, research facilities, and potential student talent.

## Location 4
Denmark, Copenhagen, City Center
R&D office space in central Copenhagen
Rationale: Easy access to government agencies, stakeholders, and potential partners.

## Location Summary
Physical base in Copenhagen, Denmark, at a Danish university, independent research institution, or security-qualified R&D facility. Suggestions include Symbion Science Park, the University of Copenhagen, and a centrally located R&D office space.

# Currency Strategy
## Currencies

- DKK: Project budget in Danish Krone, primary location is Denmark.
- Primary currency: DKK
- Currency strategy: DKK for all transactions. No international risk management needed.


# Identify Risks
# Risk 1 - Regulatory & Permitting

- Delays obtaining permits for demonstrators, especially with government systems.
- Impact: 2-6 month delay in Phase 2, impacting AltID procurement influence. Increased legal costs (50,000-100,000 DKK).
- Likelihood: Medium
- Severity: Medium
- Action: Engage Digitaliseringsstyrelsen early. Develop alternative demonstrator designs. Secure legal advice.

# Risk 2 - Technical

- Demonstrators may lack required security/functionality.
- Impact: Loss of stakeholder credibility, reduced influence on AltID procurement. 3-4 month delay, 200,000-400,000 DKK cost.
- Likelihood: Medium
- Severity: High
- Action: Conduct security reviews/penetration testing. Engage security experts. Maintain flexible design.

# Risk 3 - Financial

- Budget (10.5 million DKK) may be insufficient.
- Impact: Reduced project scope, impacting demonstrator quality/policy engagement. Need for additional funding.
- Likelihood: Medium
- Severity: Medium
- Action: Detailed budget breakdown, track expenses. Identify cost-saving measures. Explore additional funding.

# Risk 4 - Social

- Lack of stakeholder support (Digitaliseringsstyrelsen, MitID operator, Folketinget).
- Impact: Reduced influence on AltID procurement/policy. Re-scope to EU engagement/coalition consolidation.
- Likelihood: Medium
- Severity: High
- Action: Build stakeholder relationships. Tailor messaging. Highlight platform-neutral benefits.

# Risk 5 - Operational

- Difficulty recruiting/retaining qualified personnel.
- Impact: Project delays, reduced deliverable quality. Outsourcing, increased costs.
- Likelihood: Low
- Severity: Medium
- Action: Comprehensive recruitment plan, competitive salaries. Professional development. Collaborative environment.

# Risk 6 - Security

- Security vulnerabilities in demonstrators.
- Impact: Reputational damage, loss of trust. Legal liabilities, financial penalties.
- Likelihood: Low
- Severity: High
- Action: Robust security measures. Regular audits/testing. Comply with standards. Security training.

# Risk 7 - Supply Chain

- Delays in hardware/software components.
- Impact: Project delays, alternative suppliers needed. Increased costs.
- Likelihood: Low
- Severity: Medium
- Action: Identify alternative suppliers. Buffer stock. Contingency plans.

# Risk 8 - Integration with Existing Infrastructure

- Challenges demonstrating platform-neutral authentication within MitID ecosystem.
- Impact: Recommendations may not be adopted, limiting project impact.
- Likelihood: Medium
- Severity: Medium
- Action: Focus on platform-neutral benefits. Engage with MitID operator. Clear value proposition.

# Risk 9 - Environmental

- Negative environmental impact (energy, waste).
- Impact: Minor reputational damage.
- Likelihood: Low
- Severity: Low
- Action: Energy-efficient practices. Recycle waste. Promote sustainability.

# Risk 10 - Long-Term Sustainability

- Limited impact if recommendations not sustained.
- Impact: Wasted efforts if platform-neutral authentication not adopted.
- Likelihood: Medium
- Severity: Medium
- Action: Long-term sustainability plan. Engage stakeholders.

# Risk summary

- Critical risks: technical challenges, lack of support, insufficient budget.
- Success hinges on stakeholder engagement, security testing, budget management.
- Trade-off between demonstrator scope and certification rigor.
- Overlapping mitigation: build relationships, tailor messaging, highlight benefits.


# Make Assumptions
# Question 1 - Funding for External Security Reviews

- Assumption: 250,000 DKK for external security reviews.

## Assessments

- Title: Financial Feasibility Assessment
- Description: Budget adequacy for security reviews.
- Details: Insufficient funding risks vulnerabilities. 250,000 DKK allows audits/testing.

  - Mitigation: Prioritize reviews, seek pro bono support.
  - Opportunity: Successful review enhances credibility.

# Question 2 - Timeline for Digitaliseringsstyrelsen Response

- Assumption: 6 months for formal written response.

## Assessments

- Title: Timeline & Milestones Assessment
- Description: Timeline analysis for response.
- Details: Delayed response impacts AltID procurement.

  - Mitigation: Clear communication, address concerns, escalate issues.
  - Opportunity: Timely response enhances impact.

# Question 3 - Roles and Responsibilities

- Assumption: Technical lead oversees development; engineer provides backup. Knowledge transfer is key.

## Assessments

- Title: Resources & Personnel Assessment
- Description: Resource allocation and personnel management.
- Details: Dependence on a single specialist is a risk.

  - Mitigation: Cross-training, documentation, knowledge sharing.
  - Opportunity: Diverse team enhances resilience.

# Question 4 - Regulatory Compliance Standards

- Assumption: Compliance with GDPR and Danish data protection laws.

## Assessments

- Title: Governance & Regulations Assessment
- Description: Regulatory compliance requirements.
- Details: Failure to comply risks legal issues.

  - Mitigation: Regulatory review, data protection, legal advice.
  - Opportunity: Strong compliance enhances credibility.

# Question 5 - Risk Mitigation Strategies

- Assumption: Regular code reviews, penetration testing, and vulnerability scanning.

## Assessments

- Title: Safety & Risk Management Assessment
- Description: Risk management strategies.
- Details: Security vulnerabilities undermine credibility.

  - Mitigation: Multi-layered security, secure coding, testing, incident response.
  - Opportunity: Robust security attracts investment.

# Question 6 - Environmental Impact

- Assumption: Prioritize energy-efficient practices and responsible waste disposal.

## Assessments

- Title: Environmental Impact Assessment
- Description: Analysis of environmental impact.
- Details: Neglecting environment damages reputation.

  - Mitigation: Sustainable practices, recycling, responsible consumption.
  - Opportunity: Environmental responsibility enhances image.

# Question 7 - Engaging with Platform Providers

- Assumption: Engage with Apple and Google to address concerns.

## Assessments

- Title: Stakeholder Involvement Assessment
- Description: Stakeholder engagement strategy.
- Details: Resistance from providers hinders progress.

  - Mitigation: Proactive engagement, address concerns, seek solutions.
  - Opportunity: Strong relationships foster collaboration.

# Question 8 - Data Security and Privacy

- Assumption: Strict access control, data encryption, and security audits.

## Assessments

- Title: Operational Systems Assessment
- Description: Analysis of operational systems for data security.
- Details: Inadequate security risks data breaches.

  - Mitigation: Access control, encryption, security audits.
  - Opportunity: Strong security attracts investment.

# Distill Assumptions
# Project Plan

- 250,000 DKK for external security reviews.
- Digitaliseringsstyrelsen response: 6 months (milestones, follow-up).
- Technical lead: demonstrator oversight. Engineer: backup, expertise.
- Demonstrators comply with GDPR, Danish data protection laws.
- Regular code reviews, penetration testing, vulnerability scanning.
- Prioritize energy-efficient practices, waste disposal, sustainable materials.
- Engage Apple, Google: address concerns, explore collaboration.
- Access control, encryption, audits: protect digital identity data.


# Review Assumptions
# Domain of the expert reviewer
Project Management and Risk Assessment in Technology and Public Sector

## Domain-specific considerations

- Stakeholder management in a politically sensitive environment
- Technical feasibility of implementing platform-neutral solutions
- Regulatory compliance and data privacy
- Budget constraints and resource allocation
- Long-term sustainability and impact

## Issue 1 - Uncertainty Regarding Digitaliseringsstyrelsen's Response Timeline and Commitment
The assumption of a 6-month response from Digitaliseringsstyrelsen lacks detail. Project success depends on their engagement for AltID procurement. The plan doesn't address non-response, negative response, or delays.

Recommendation: Develop a detailed engagement plan with milestones, communication, and escalation. Conduct stakeholder analysis to identify key influencers. Establish metrics for measuring engagement success. Prepare alternative strategies for non-response or negative feedback (EU-level engagement, coalition support).

Sensitivity: Delay (6+ months) could delay impact by 6-12 months, reducing ROI by 10-20%. Negative response could require re-scoping, reducing impact by 50% and potentially losing 25-50% of capital.

## Issue 2 - Inadequate Budget Allocation for External Security Reviews
The assumption of 250,000 DKK for security reviews may be unrealistic. The plan lacks detail on the scope and qualifications of security firms. Underfunding could lead to undetected vulnerabilities.

Recommendation: Conduct a cost analysis of security reviews, considering scope, complexity, and assurance. Allocate at least 500,000 DKK, engaging qualified firms with expertise in mobile security. Implement a staged certification approach.

Sensitivity: Insufficient budget could increase the risk of vulnerabilities by 10-20%, potentially leading to reputational damage and penalties. A breach could reduce ROI by 20-30% and delay completion by 6-12 months.

## Issue 3 - Over-Reliance on Technical Lead and Insufficient Knowledge Transfer
Reliance on the technical lead is a single point of failure. The plan lacks detail on knowledge transfer or contingency plans. This poses a risk to project continuity.

Recommendation: Implement a knowledge transfer program with documentation, cross-training, and knowledge-sharing. Assign roles to ensure no single individual holds critical knowledge. Develop contingency plans for the lead's absence. Consider a second senior engineer.

Sensitivity: Lead unavailability could delay development by 3-6 months, reducing ROI by 5-10%. Replacement cost could be 100,000-200,000 DKK.

## Review conclusion
The plan demonstrates understanding but needs to address missing assumptions. Prioritize stakeholder engagement, secure security funding, and mitigate reliance on key personnel.