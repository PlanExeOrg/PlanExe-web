*Roles Needed & Example People*

# Roles

## 1. Lead Researcher (Mobile Security & Authentication Protocols)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires deep, consistent involvement throughout the project's lifecycle to provide technical leadership and expertise.

**Explanation**:
Provides deep technical expertise in mobile security, authentication protocols, and relevant standards (eIDAS, NSIS).

**Consequences**:
Inadequate technical foundation, flawed demonstrator design, and inability to credibly assess the feasibility of platform-neutral alternatives.

**People Count**:
1

**Typical Activities**:
Conducting research on mobile security and authentication protocols, analyzing relevant standards (eIDAS, NSIS), assessing the feasibility of platform-neutral alternatives, and providing technical leadership to the project team.

**Background Story**:
Astrid Nielsen, born and raised in Copenhagen, Denmark, has always been fascinated by the intersection of technology and security. She holds a PhD in Cryptography from the Technical University of Denmark, specializing in mobile security and authentication protocols. Astrid has over 10 years of experience in cybersecurity research, including a stint at a leading security firm where she focused on penetration testing and vulnerability analysis of mobile applications. Her deep understanding of eIDAS and NSIS standards, combined with her practical experience in mobile security, makes her the ideal lead researcher for this project. Astrid is driven by a desire to ensure that Denmark's digital infrastructure is secure, resilient, and independent.

**Equipment Needs**:
High-performance laptop with advanced security features, access to mobile security testing tools, software development environments, and relevant security standards documentation (eIDAS, NSIS).

**Facility Needs**:
Secure, access-controlled workspace suitable for sensitive digital identity research and development. Access to a research library and collaboration spaces.

## 2. Regulatory and Compliance Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent involvement to ensure regulatory compliance and navigate the complex legal landscape.

**Explanation**:
Ensures the project aligns with Danish and EU digital identity regulations (eIDAS, GDPR, etc.) and navigates the complex regulatory landscape.

**Consequences**:
Non-compliance with regulations, legal risks, and inability to influence policy effectively.

**People Count**:
1

**Typical Activities**:
Ensuring the project aligns with Danish and EU digital identity regulations (eIDAS, GDPR, etc.), navigating the complex regulatory landscape, providing legal advice, and ensuring compliance with relevant standards.

**Background Story**:
Jens Petersen, a lawyer from Aarhus, Denmark, specializes in regulatory compliance and digital identity frameworks. He holds a law degree from Aarhus University and a master's degree in EU law from the College of Europe. Jens has worked for several years at a prominent law firm, advising clients on eIDAS, GDPR, and other relevant regulations. He also served as a legal advisor to the Danish Data Protection Agency, where he gained valuable insights into the regulatory landscape. Jens is passionate about ensuring that digital identity solutions are compliant with the law and protect the privacy of citizens. His expertise in Danish and EU digital identity regulations makes him an invaluable asset to the project.

**Equipment Needs**:
Laptop with secure access to legal databases, regulatory documents, and communication tools for stakeholder engagement. Access to relevant EU and Danish legal frameworks.

**Facility Needs**:
Office space with access to legal research resources, secure communication channels, and meeting rooms for consultations.

## 3. Policy and Public Affairs Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent involvement to manage stakeholder relationships, build coalitions, and advocate for policy changes.

**Explanation**:
Manages stakeholder engagement, builds coalitions, and advocates for policy changes within the Danish digital governance ecosystem.

**Consequences**:
Weak stakeholder relationships, limited policy influence, and failure to achieve desired procurement outcomes.

**People Count**:
1

**Typical Activities**:
Managing stakeholder engagement, building coalitions, advocating for policy changes within the Danish digital governance ecosystem, and ensuring effective communication with key stakeholders.

**Background Story**:
Signe Christensen, a political scientist from Odense, Denmark, has extensive experience in Danish digital governance and procurement processes. She holds a master's degree in Public Policy from the University of Copenhagen and has worked for several years as a policy advisor to members of Folketinget's digital policy committee. Signe has a deep understanding of the Danish political landscape and a proven track record of building coalitions and advocating for policy changes. She is passionate about promoting digital sovereignty and ensuring that Denmark's digital infrastructure serves the interests of its citizens. Her experience in stakeholder engagement and policy advocacy makes her the perfect person to coordinate the project's policy and public affairs efforts.

**Equipment Needs**:
Laptop with communication and presentation software, CRM tools for stakeholder management, and access to policy databases and government resources.

**Facility Needs**:
Office space with meeting rooms for stakeholder engagement, presentation equipment, and access to government resources.

## 4. Technical Lead (Demonstrator Development)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent involvement to oversee the development and security of the technical demonstrators.

**Explanation**:
Oversees the development and security of the technical demonstrators, ensuring they meet project goals and security requirements.

**Consequences**:
Poorly designed or insecure demonstrators, lack of technical credibility, and inability to showcase the feasibility of platform-neutral alternatives.

**People Count**:
1

**Typical Activities**:
Overseeing the development and security of the technical demonstrators, ensuring they meet project goals and security requirements, providing technical guidance to the development team, and ensuring the demonstrators are robust and reliable.

**Background Story**:
Mads Jørgensen, a software architect from Aalborg, Denmark, has a passion for building secure and reliable systems. He holds a master's degree in Computer Science from Aalborg University and has over 15 years of experience in software development, with a focus on security and authentication. Mads has worked for several leading technology companies, where he has led the development of complex software systems. He is an expert in open standards such as FIDO2/WebAuthn and OpenID Connect, and he is committed to building platform-neutral solutions. His technical expertise and leadership skills make him the ideal person to oversee the development and security of the project's technical demonstrators.

**Equipment Needs**:
High-performance workstation with software development tools, security testing equipment, and access to relevant APIs and SDKs. Secure code repository and version control system.

**Facility Needs**:
Secure development lab with access-controlled environment, testing infrastructure, and collaboration spaces.

## 5. Web Authentication Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Web Authentication Engineers are needed for a specific task, and the project can benefit from specialized expertise without the commitment of a full-time employee. The number of contractors can vary based on the workload.

**Explanation**:
Focuses on implementing web-based authentication methods and hardware-token workflows for the fallback authentication path.

**Consequences**:
Limited expertise in web authentication technologies, hindering the development of a robust fallback authentication path. The second person is needed if the workload increases or if the project decides to explore multiple web authentication methods.

**People Count**:
min 1, max 2, depending on project scale and workload

**Typical Activities**:
Implementing web-based authentication methods, developing hardware-token workflows, ensuring the security of web authentication solutions, and collaborating with the technical lead to integrate web authentication into the project's demonstrators.

**Background Story**:
Rasmus Hansen, a freelance web developer from Copenhagen, Denmark, specializes in web authentication and hardware-token workflows. He has a strong background in computer science and has worked on various projects involving secure web applications. Rasmus is proficient in various web technologies and has a deep understanding of web security best practices. He is passionate about building user-friendly and secure web authentication solutions. Rasmus is brought in as a contractor to implement web-based authentication methods and hardware-token workflows for the fallback authentication path.

**Equipment Needs**:
Laptop with web development tools, hardware token testing equipment, and access to relevant web authentication standards and APIs.

**Facility Needs**:
Development workspace with access to web authentication testing tools and collaboration spaces. Access to hardware tokens for testing.

## 6. Linux/GrapheneOS Implementation Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Linux/GrapheneOS Implementation Engineers are needed for a specific task, and the project can benefit from specialized expertise without the commitment of a full-time employee. The number of contractors can vary based on the workload.

**Explanation**:
Specializes in implementing and securing the mobile-oriented demonstrator on GrapheneOS or a comparable privacy-respecting platform.

**Consequences**:
Lack of expertise in GrapheneOS and related technologies, hindering the development of a secure and privacy-respecting mobile demonstrator. The second person is needed if the workload increases or if the project decides to explore multiple mobile platforms.

**People Count**:
min 1, max 2, depending on project scale and workload

**Typical Activities**:
Implementing and securing the mobile-oriented demonstrator on GrapheneOS or a comparable privacy-respecting platform, ensuring the security and privacy of the mobile demonstrator, and collaborating with the technical lead to integrate the mobile demonstrator into the project's overall architecture.

**Background Story**:
Ida Olsen, a freelance Linux systems engineer from Roskilde, Denmark, specializes in implementing and securing mobile applications on GrapheneOS and other privacy-respecting platforms. She has extensive experience in Linux system administration and mobile security. Ida is passionate about privacy and security and is committed to building secure and privacy-respecting mobile solutions. Ida is brought in as a contractor to implement and secure the mobile-oriented demonstrator on GrapheneOS.

**Equipment Needs**:
Laptop with Linux development environment, GrapheneOS testing devices, and access to relevant mobile security tools and documentation.

**Facility Needs**:
Development workspace with access to GrapheneOS testing devices and collaboration spaces. Secure environment for mobile application development.

## 7. Security Review Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Security Review Specialists are needed for a specific task, and the project can benefit from specialized expertise without the commitment of a full-time employee. The number of contractors can vary based on the workload.

**Explanation**:
Conducts external security reviews and penetration testing of the demonstrators to identify and mitigate vulnerabilities.

**Consequences**:
Failure to identify critical security vulnerabilities, leading to reputational damage and loss of stakeholder trust. Multiple specialists are needed to provide diverse perspectives and expertise, especially if the project explores multiple authentication methods or platforms.

**People Count**:
min 2, max 3, depending on project scale and workload

**Typical Activities**:
Conducting external security reviews and penetration testing of the demonstrators, identifying and reporting security vulnerabilities, and providing recommendations for mitigating security risks.

**Background Story**:
Anders Lund and Sofie Møller, both independent security consultants based in Copenhagen, Denmark, specialize in conducting external security reviews and penetration testing of software systems. Anders has a background in cryptography and has worked on various projects involving secure software development. Sofie has a background in computer science and has extensive experience in penetration testing and vulnerability analysis. They are both passionate about security and are committed to helping organizations build secure software systems. Anders and Sofie are brought in as contractors to conduct external security reviews and penetration testing of the project's demonstrators.

**Equipment Needs**:
Laptop with penetration testing tools, security auditing software, and access to relevant security standards and vulnerability databases.

**Facility Needs**:
Secure testing environment with isolated network access, penetration testing tools, and reporting infrastructure.

## 8. Project Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires consistent involvement to manage the project timeline, budget, resources, and communication.

**Explanation**:
Manages the project timeline, budget, resources, and communication, ensuring the project stays on track and meets its goals.

**Consequences**:
Poor project coordination, missed deadlines, budget overruns, and failure to achieve project goals.

**People Count**:
1

**Typical Activities**:
Managing the project timeline, budget, resources, and communication, ensuring the project stays on track and meets its goals, coordinating the activities of the project team, and reporting progress to stakeholders.

**Background Story**:
Lars Brandt, a seasoned project manager from Hellerup, Denmark, has a proven track record of successfully managing complex technology projects. He holds a master's degree in Project Management from Copenhagen Business School and has over 20 years of experience in project management, with a focus on technology and public sector projects. Lars is highly organized, detail-oriented, and an excellent communicator. He is passionate about ensuring that projects are delivered on time, within budget, and to the highest quality standards. His experience in project management and his understanding of the Danish public sector make him the ideal person to manage this project.

**Equipment Needs**:
Laptop with project management software, communication tools, and access to project documentation and budget tracking systems.

**Facility Needs**:
Office space with access to project management tools, communication channels, and meeting rooms for team coordination.

---

# Omissions

## 1. Accessibility Specialist

Ensuring digital inclusion for all citizens, including those with disabilities, is crucial for a public digital identity system. The current team lacks explicit expertise in accessibility standards and inclusive design.

**Recommendation**:
Integrate accessibility considerations into all phases of the project, particularly demonstrator development and policy recommendations. Consult with accessibility experts or organizations representing people with disabilities to ensure compliance with WCAG guidelines and address specific user needs. This could be achieved through a short-term consultancy rather than a full-time role.

## 2. User Experience (UX) Researcher

The project focuses on technical feasibility and policy influence, but user experience is vital for adoption and acceptance of any digital identity solution. The team lacks a dedicated UX researcher to ensure the demonstrators are user-friendly and meet citizen needs.

**Recommendation**:
Incorporate user feedback and usability testing into the demonstrator development process. Conduct user research to understand citizen preferences and pain points related to digital identity. This could be achieved through targeted user interviews or surveys, potentially leveraging existing resources within a university setting.

## 3. Communication Specialist

Effective communication is essential for building stakeholder support and influencing policy decisions. The current team includes a Policy and Public Affairs Coordinator, but a dedicated communication specialist could enhance the project's outreach and messaging.

**Recommendation**:
Develop a comprehensive communication plan that includes targeted messaging for different stakeholder groups (e.g., policymakers, citizens, civil society organizations). Create clear and concise communication materials, such as infographics and videos, to explain the project's goals and benefits. This could be a part-time role or a collaboration with a university communications department.

---

# Potential Improvements

## 1. Clarify Responsibilities of Technical Lead and Engineers

The roles of the Technical Lead and the Web Authentication/Linux Engineers are somewhat overlapping. Clearer delineation of responsibilities will improve efficiency and reduce potential conflicts.

**Recommendation**:
Create a RACI matrix (Responsible, Accountable, Consulted, Informed) to clearly define the roles and responsibilities of each technical team member for specific tasks, such as demonstrator development, security testing, and platform integration.

## 2. Formalize Knowledge Transfer Processes

The assumption document mentions knowledge transfer, but lacks concrete details. A more structured approach will mitigate risks associated with personnel changes or absences.

**Recommendation**:
Implement a formal knowledge transfer plan that includes documentation standards, regular knowledge-sharing sessions, and cross-training opportunities. Use a shared documentation platform (e.g., a wiki or shared drive) to store project information and ensure accessibility for all team members.

## 3. Strengthen Stakeholder Engagement Plan

The stakeholder analysis identifies key stakeholders, but the engagement strategies are relatively generic. A more targeted and proactive approach will increase the project's influence.

**Recommendation**:
Develop a detailed stakeholder engagement plan that outlines specific communication channels, messaging strategies, and engagement activities for each stakeholder group. Prioritize building relationships with key decision-makers at Digitaliseringsstyrelsen and Folketinget's digital policy committee. Consider creating a stakeholder advisory group to provide ongoing feedback and guidance.