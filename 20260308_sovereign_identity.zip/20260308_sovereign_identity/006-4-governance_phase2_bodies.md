### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, given the project's complexity, budget, and strategic importance to Denmark's digital sovereignty.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (above 500,000 DKK).
- Oversee risk management at a strategic level.
- Resolve strategic-level conflicts and escalate issues as needed.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- Senior Representative from Digitaliseringsstyrelsen (non-voting observer).
- Senior Representative from a Danish University or Research Institution (independent).
- Project Sponsor (senior executive within the funding organization).
- Project Manager.
- Representative from the Folketinget's Digital Policy Committee (independent).

**Decision Rights:** Strategic decisions related to project scope, budget (above 500,000 DKK), timeline, and strategic risks.

**Decision Mechanism:** Decisions made by majority vote. Project Sponsor has tie-breaking vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review of project risks and mitigation strategies.
- Approval of major changes to project scope, budget, or timeline.
- Discussion of strategic issues and challenges.
- Review of stakeholder engagement activities.

**Escalation Path:** Project Sponsor; ultimately to the funding organization's executive leadership.
### 2. Core Project Team

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring deliverables are produced on time and within budget. Essential for operational efficiency.

**Responsibilities:**

- Manage day-to-day project activities.
- Develop and maintain project plans and schedules.
- Track project progress and report on status.
- Manage project budget (below 500,000 DKK) and resources.
- Identify and manage project risks and issues at an operational level.
- Coordinate communication and collaboration among project team members.
- Prepare reports for the Project Steering Committee.

**Initial Setup Actions:**

- Define roles and responsibilities.
- Establish communication protocols.
- Set up project management tools and systems.
- Develop detailed project plan and schedule.

**Membership:**

- Project Manager (Chair).
- Lead Researcher in Mobile Security and Authentication Protocols.
- Regulatory and Compliance Specialist.
- Policy and Public Affairs Coordinator.
- Technical Lead.
- Engineers/Contractors.

**Decision Rights:** Operational decisions related to day-to-day project execution, budget management (below 500,000 DKK), and resource allocation.

**Decision Mechanism:** Decisions made by the Project Manager, with input from team members as needed. Escalation to the Project Steering Committee for unresolved issues.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of project budget and expenses.
- Coordination of project activities.
- Preparation of reports for the Project Steering Committee.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on the project's technical aspects, ensuring the demonstrators are secure, functional, and aligned with industry best practices.

**Responsibilities:**

- Provide technical expertise and guidance on the project's technical aspects.
- Review and evaluate the technical design and architecture of the demonstrators.
- Advise on security best practices and vulnerability mitigation.
- Evaluate the feasibility and scalability of the proposed solutions.
- Provide input on the selection of technologies and tools.
- Review and approve technical deliverables.

**Initial Setup Actions:**

- Identify and recruit qualified technical experts.
- Define the group's scope and objectives.
- Establish communication protocols.
- Set up meeting schedule.

**Membership:**

- Lead Researcher in Mobile Security and Authentication Protocols.
- Technical Lead.
- Independent Security Expert (external).
- Representative from a relevant standards body (e.g., FIDO Alliance) (external).
- Engineer/Contractor with expertise in web authentication or hardware-token workflows.

**Decision Rights:** Provides recommendations on technical design, security, and feasibility. The Project Manager has final decision-making authority, considering the TAG's input.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Project Manager makes the final decision, documenting the rationale.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of technical design and architecture.
- Discussion of security vulnerabilities and mitigation strategies.
- Evaluation of the feasibility and scalability of proposed solutions.
- Review of technical deliverables.
- Discussion of emerging technologies and trends.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to ethical standards, GDPR, and relevant regulations, given the sensitive nature of digital identity data and the potential for privacy violations.

**Responsibilities:**

- Oversee compliance with GDPR, Danish data protection laws, and other relevant regulations.
- Review project activities to ensure ethical conduct and data privacy.
- Develop and implement data protection policies and procedures.
- Provide guidance on ethical issues and conflicts of interest.
- Monitor and investigate potential compliance violations.
- Ensure data security and privacy are prioritized throughout the project lifecycle.

**Initial Setup Actions:**

- Identify and recruit qualified ethics and compliance experts.
- Define the committee's scope and objectives.
- Establish communication protocols.
- Set up meeting schedule.
- Develop a compliance checklist based on relevant regulations.

**Membership:**

- Regulatory and Compliance Specialist.
- Legal Advisor (external, independent).
- Data Protection Officer (internal or external, independent).
- Representative from a civil-society organization focused on privacy (external, independent).

**Decision Rights:** Provides recommendations on ethical and compliance issues. The Project Manager is responsible for implementing the recommendations and ensuring compliance.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Legal Advisor makes the final decision, documenting the rationale.

**Meeting Cadence:** Monthly during Phase 1, then quarterly for Phases 2 and 3, or ad hoc as needed.

**Typical Agenda Items:**

- Review of compliance with GDPR and other relevant regulations.
- Discussion of ethical issues and conflicts of interest.
- Review of data protection policies and procedures.
- Investigation of potential compliance violations.
- Review of data security and privacy measures.

**Escalation Path:** Project Steering Committee; ultimately to the funding organization's legal department.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and collaboration with key stakeholders, ensuring their needs and concerns are addressed throughout the project lifecycle. Crucial for project acceptance and impact.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Identify and prioritize key stakeholders.
- Communicate project progress and findings to stakeholders.
- Solicit feedback from stakeholders and address their concerns.
- Build and maintain relationships with stakeholders.
- Organize stakeholder meetings and workshops.
- Monitor stakeholder sentiment and adjust engagement strategies as needed.

**Initial Setup Actions:**

- Identify and recruit qualified stakeholder engagement specialists.
- Define the group's scope and objectives.
- Establish communication protocols.
- Set up meeting schedule.
- Develop a stakeholder engagement plan.

**Membership:**

- Policy and Public Affairs Coordinator (Chair).
- Project Manager.
- Representative from Digitaliseringsstyrelsen (non-voting observer).
- Representative from a civil-society organization (external).
- Representative from the Folketinget's Digital Policy Committee (external).

**Decision Rights:** Provides recommendations on stakeholder engagement strategies. The Project Manager has final decision-making authority, considering the SEG's input.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Project Manager makes the final decision, documenting the rationale.

**Meeting Cadence:** Monthly during Phase 1, then quarterly for Phases 2 and 3, or ad hoc as needed.

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder feedback and concerns.
- Planning of stakeholder meetings and workshops.
- Monitoring of stakeholder sentiment.
- Adjustment of engagement strategies as needed.

**Escalation Path:** Project Steering Committee