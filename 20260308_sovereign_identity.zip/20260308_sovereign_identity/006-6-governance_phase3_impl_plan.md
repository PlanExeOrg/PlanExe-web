### 1. Project Sponsor designates an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Project Kickoff

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee, including responsibilities, membership, decision-making processes, and meeting cadence.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Sponsor Identified

### 3. Interim Chair reviews and provides feedback on the draft SteerCo ToR.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo ToR v0.2 with Interim Chair Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 4. Project Manager finalizes the SteerCo ToR based on feedback from the Interim Chair.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- SteerCo ToR v0.2 with Interim Chair Feedback

### 5. Project Sponsor formally approves the final SteerCo ToR.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Sponsor formally appoints members of the Project Steering Committee, including the Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Confirmed SteerCo Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Nominated Members List Available

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SteerCo Membership List

### 8. Hold the initial Project Steering Committee kick-off meeting to review the project plan, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 9. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Kickoff

### 10. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Project Kickoff

### 11. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Setup

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocols Document

### 12. Project Manager develops a detailed project plan and schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Plan and Schedule

**Dependencies:**

- Project Management Tools and Systems Setup

### 13. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Kick-off Meeting Invitation

**Dependencies:**

- Detailed Project Plan and Schedule

### 14. Hold the initial Core Project Team kick-off meeting to review roles, responsibilities, communication protocols, and the project plan.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Core Project Team Kick-off Meeting Invitation

### 15. Project Manager identifies and recruits qualified technical experts for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- List of Potential TAG Members

**Dependencies:**

- Core Project Team Established

### 16. Project Manager defines the scope and objectives of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope and Objectives Document

**Dependencies:**

- List of Potential TAG Members

### 17. Project Manager establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Protocols Document

**Dependencies:**

- Technical Advisory Group Scope and Objectives Document

### 18. Project Manager sets up a meeting schedule for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Meeting Schedule

**Dependencies:**

- Technical Advisory Group Communication Protocols Document

### 19. Project Manager formally appoints members of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Confirmed TAG Membership List

**Dependencies:**

- Technical Advisory Group Meeting Schedule

### 20. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Invitation

**Dependencies:**

- Confirmed TAG Membership List

### 21. Hold the initial Technical Advisory Group kick-off meeting to review the project's technical aspects, security best practices, and feasibility of proposed solutions.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Kick-off Meeting Invitation

### 22. Project Manager identifies and recruits qualified ethics and compliance experts for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- List of Potential Ethics & Compliance Committee Members

**Dependencies:**

- Core Project Team Established

### 23. Project Manager defines the scope and objectives of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Scope and Objectives Document

**Dependencies:**

- List of Potential Ethics & Compliance Committee Members

### 24. Project Manager establishes communication protocols for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Communication Protocols Document

**Dependencies:**

- Ethics & Compliance Committee Scope and Objectives Document

### 25. Project Manager sets up a meeting schedule for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Meeting Schedule

**Dependencies:**

- Ethics & Compliance Committee Communication Protocols Document

### 26. Project Manager develops a compliance checklist based on relevant regulations for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Compliance Checklist

**Dependencies:**

- Ethics & Compliance Committee Meeting Schedule

### 27. Project Manager formally appoints members of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Compliance Checklist

### 28. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 29. Hold the initial Ethics & Compliance Committee kick-off meeting to review compliance with GDPR, ethical issues, and data protection policies.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 30. Project Manager identifies and recruits qualified stakeholder engagement specialists for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- List of Potential SEG Members

**Dependencies:**

- Core Project Team Established

### 31. Project Manager defines the scope and objectives of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Scope and Objectives Document

**Dependencies:**

- List of Potential SEG Members

### 32. Project Manager establishes communication protocols for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Communication Protocols Document

**Dependencies:**

- Stakeholder Engagement Group Scope and Objectives Document

### 33. Project Manager sets up a meeting schedule for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Meeting Schedule

**Dependencies:**

- Stakeholder Engagement Group Communication Protocols Document

### 34. Project Manager develops a stakeholder engagement plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder Engagement Group Meeting Schedule

### 35. Project Manager formally appoints members of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Confirmed SEG Membership List

**Dependencies:**

- Stakeholder Engagement Plan

### 36. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SEG Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SEG Membership List

### 37. Hold the initial Stakeholder Engagement Group kick-off meeting to review the stakeholder engagement plan and communication strategies.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SEG Kick-off Meeting Invitation