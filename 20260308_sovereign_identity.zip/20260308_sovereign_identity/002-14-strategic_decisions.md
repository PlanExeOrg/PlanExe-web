## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the fundamental project tensions of Influence vs. Independence (Digitaliseringsstyrelsen Engagement Depth), Credibility vs. Cost (Demonstrator Certification Rigor), Breadth vs. Depth (Technical Demonstrator Scope), and Political Capital vs. Focus (Coalition Partner Breadth). The core strategic choices revolve around balancing technical feasibility with political influence and ensuring the project's message resonates with key stakeholders. No key strategic dimensions appear to be missing.

### Decision 1: Procurement Language Specificity
**Lever ID:** `6a84491a-e803-4a0f-a192-d5d120d166e3`

**The Core Decision:** This lever focuses on the degree of precision in defining requirements for platform neutrality and fallback mechanisms within AltID procurement documents. Success is measured by the clarity and enforceability of these requirements, ensuring that suppliers deliver solutions aligned with the project's goals of reduced platform dependency and enhanced resilience. It directly shapes the solution space.

**Why It Matters:** More specific procurement language directly translates to clearer requirements for platform neutrality and fallback mechanisms in AltID tenders. However, overly prescriptive language may limit supplier innovation or inadvertently exclude viable solutions, while vague language risks being interpreted in favor of incumbent platform-dependent solutions.

**Strategic Choices:**

1. Define precise technical standards for platform-neutral authentication methods, such as requiring support for specific FIDO2 profiles and open-source cryptographic libraries
2. Establish functional requirements for fallback authentication paths, mandating that all digital identity systems must offer a certified alternative that does not rely on Apple or Google platform services
3. Incorporate supplier-diversity criteria into the procurement process, giving preference to vendors who demonstrate a commitment to open standards and reduced platform lock-in

**Trade-Off / Risk:** Precise procurement language ensures platform neutrality, but it may stifle innovation or inadvertently exclude viable solutions if overly prescriptive.

**Strategic Connections:**

**Synergy:** Procurement Language Specificity works in synergy with Technical Feasibility Breadth, as clear requirements guide the scope and direction of technical feasibility assessments.

**Conflict:** This lever trades off against Technical Demonstrator Scope. Overly specific language might limit the range of solutions explored in the demonstrator phase.

**Justification:** *Critical*, Critical because it directly translates to enforceable requirements for platform neutrality and fallback mechanisms in AltID tenders. It shapes the solution space and has strong synergy with technical feasibility.

### Decision 2: Technical Demonstrator Scope
**Lever ID:** `ba68a8ce-ff7b-4c8f-b51f-47f7e4852f70`

**The Core Decision:** This lever determines the breadth and depth of the technical demonstrators. A key success metric is the demonstrator's ability to convincingly showcase the feasibility and security of platform-neutral and fallback authentication methods. The scope must balance comprehensiveness with resource constraints to deliver impactful results.

**Why It Matters:** A broader demonstrator scope provides more comprehensive evidence of feasibility but increases development costs and complexity, potentially delaying key milestones. A narrower scope allows for faster iteration and focused advocacy but may be perceived as less convincing or relevant to real-world deployment scenarios.

**Strategic Choices:**

1. Prioritize a lean demonstrator focused solely on core authentication flows using FIDO2/WebAuthn on GrapheneOS, minimizing integration with non-essential services
2. Expand the demonstrator to include integration with a simulated Danish public-sector service, showcasing end-to-end functionality and user experience
3. Develop multiple demonstrators, each showcasing a different fallback authentication method, such as browser-based authentication or hardware-token integration, to maximize coverage

**Trade-Off / Risk:** A broader demonstrator scope offers more comprehensive evidence, but it increases costs and complexity, potentially delaying key milestones.

**Strategic Connections:**

**Synergy:** Technical Demonstrator Scope amplifies Technical Feasibility Breadth by providing concrete examples that validate the feasibility assessment's findings.

**Conflict:** This lever conflicts with Demonstrator Certification Rigor. A broader scope may reduce the resources available for rigorous security testing and certification efforts.

**Justification:** *High*, High because it provides concrete evidence of feasibility, validating the assessment's findings. It has a direct impact on the project's credibility and ability to influence stakeholders. Scope needs to be balanced against certification rigor.

### Decision 3: Coalition Partner Breadth
**Lever ID:** `d6f96846-0207-4a46-abd9-506914edd6ab`

**The Core Decision:** This lever concerns the size and composition of the coalition supporting the project's goals. Success is measured by the coalition's ability to influence policy decisions and procurement processes in favor of platform neutrality and fallback access. Effective coordination and alignment are crucial for maximizing impact.

**Why It Matters:** A broader coalition increases political influence and support for platform-neutrality initiatives, but it also introduces coordination challenges and potential conflicts of interest among diverse stakeholders. A narrower coalition allows for more focused advocacy but may lack the necessary reach and credibility to influence policy decisions effectively.

**Strategic Choices:**

1. Focus coalition-building efforts on civil-society organizations, privacy advocates, and academic researchers with a shared interest in digital sovereignty
2. Expand the coalition to include security experts, contingency-planning stakeholders, and sympathetic members of Folketinget's digital policy committee to broaden the base of support
3. Actively engage with industry representatives and technology vendors who are committed to open standards and platform-neutral solutions, fostering collaboration and knowledge sharing

**Trade-Off / Risk:** A broader coalition increases political influence, but it also introduces coordination challenges and potential conflicts of interest among stakeholders.

**Strategic Connections:**

**Synergy:** Coalition Partner Breadth enhances Policy Framing Emphasis by providing diverse perspectives and amplifying the reach of the project's messaging.

**Conflict:** This lever trades off against Digitaliseringsstyrelsen Engagement Depth. A broader coalition may dilute the focus and complicate direct engagement with key decision-makers.

**Justification:** *High*, High because a broader coalition increases political influence and support for platform-neutrality initiatives. It amplifies the reach of the project's messaging and provides diverse perspectives. It trades off against engagement depth.

### Decision 4: Policy Framing Emphasis
**Lever ID:** `14d35a61-669c-46a3-bac6-cdab510081a6`

**The Core Decision:** This lever determines how the project frames the digital identity issue to resonate with different stakeholders. It involves choosing between emphasizing resilience/continuity, privacy/accountability, or a balanced approach. Success is measured by the degree to which the framing resonates with key stakeholders and advances the project's goals without alienating crucial support.

**Why It Matters:** Framing the issue primarily as a resilience and continuity-of-service risk resonates with public-sector stakeholders concerned about supplier concentration, but it may downplay privacy and democratic accountability concerns. Emphasizing privacy and democratic accountability may mobilize civil-society support but could alienate stakeholders who prioritize operational efficiency and cost-effectiveness.

**Strategic Choices:**

1. Frame the issue primarily as a resilience and continuity-of-service risk, highlighting the potential impact of platform outages or policy changes on essential public services
2. Emphasize privacy and democratic accountability concerns, focusing on the need for greater transparency and control over digital identity data
3. Adopt a balanced approach that addresses both resilience and privacy concerns, demonstrating how platform-neutral solutions can enhance both security and user autonomy

**Trade-Off / Risk:** Resilience framing resonates with public-sector stakeholders, but it may downplay privacy concerns, potentially alienating civil-society support.

**Strategic Connections:**

**Synergy:** A strong Resilience Narrative Emphasis amplifies the impact of this lever by providing a consistent and compelling message. It also works well with Procurement Language Specificity.

**Conflict:** This lever trades off against Coalition Partner Breadth. Emphasizing one framing too strongly may exclude potential partners who prioritize different aspects of the issue.

**Justification:** *Critical*, Critical because it determines how the project frames the digital identity issue to resonate with different stakeholders. It directly impacts stakeholder buy-in and has a trade-off with coalition breadth.

### Decision 5: Digitaliseringsstyrelsen Engagement Depth
**Lever ID:** `a686909c-896b-4456-9f81-92b16b0209f5`

**The Core Decision:** This lever manages the depth of engagement with Digitaliseringsstyrelsen, balancing influence with the risk of co-option. Deeper engagement can increase the project's impact on AltID design and procurement, but it also risks premature closure of alternative options. Success is measured by the project's ability to shape policy without compromising its independence.

**Why It Matters:** Deeper engagement with Digitaliseringsstyrelsen increases the likelihood of influencing AltID design and procurement. However, it also risks co-option or premature closure of alternative options if the agency is not receptive. Superficial engagement preserves independence but reduces the chances of concrete policy impact.

**Strategic Choices:**

1. Establish a formal advisory role with Digitaliseringsstyrelsen, providing ongoing technical input and policy recommendations throughout the AltID development process
2. Maintain an arm's-length relationship with Digitaliseringsstyrelsen, submitting formal proposals and responding to consultations without seeking deeper integration
3. Focus on informal channels and relationships within Digitaliseringsstyrelsen, cultivating internal champions and building support for platform-neutrality and fallback access from the inside

**Trade-Off / Risk:** Deeper engagement with Digitaliseringsstyrelsen risks co-option, while an arm's-length approach may limit the project's influence on AltID design and procurement.

**Strategic Connections:**

**Synergy:** This lever works well with Procurement Language Specificity. Deeper engagement allows for more effective advocacy for specific procurement requirements.

**Conflict:** This lever conflicts with Resilience Narrative Emphasis. Overly close alignment with Digitaliseringsstyrelsen may require downplaying certain aspects of the resilience narrative.

**Justification:** *Critical*, Critical because it manages the depth of engagement with Digitaliseringsstyrelsen, balancing influence with the risk of co-option. It directly impacts AltID design and procurement.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: EU Standards Engagement Level
**Lever ID:** `c58b0d89-1f08-406e-b251-ce94e9441837`

**The Core Decision:** This lever focuses on the level of involvement with EU bodies influencing digital identity standards. Success is measured by the project's ability to shape eIDAS2 and European Digital Identity Wallet standards to support platform-neutral access and fallback mechanisms. Active participation and strategic alliances are key.

**Why It Matters:** Deeper engagement with EU bodies and technical working groups can align Danish advocacy with broader European requirements, increasing the likelihood of influencing eIDAS2 and European Digital Identity Wallet standards. However, this requires significant time and resources, and the impact on Danish policy may be limited if EU-level decisions diverge from national priorities.

**Strategic Choices:**

1. Monitor relevant EU policy developments and technical discussions, providing informal feedback and input as opportunities arise
2. Actively participate in EU technical working groups and standards bodies, advocating for platform-neutral access and certified fallback mechanisms in eIDAS2 and the European Digital Identity Wallet framework
3. Forge strategic alliances with other EU member states and organizations that share Denmark's concerns about platform lock-in and digital sovereignty, amplifying the collective voice

**Trade-Off / Risk:** Deeper EU engagement aligns Danish advocacy with broader European requirements, but it requires significant resources and may not directly impact Danish policy.

**Strategic Connections:**

**Synergy:** EU Standards Engagement Level works in synergy with EU Standards Advocacy Intensity, as deeper engagement provides more opportunities for effective advocacy.

**Conflict:** This lever conflicts with Digitaliseringsstyrelsen Engagement Cadence, as increased EU engagement may divert resources from domestic policy efforts.

**Justification:** *Medium*, Medium because deeper EU engagement can align Danish advocacy with broader European requirements, but it requires significant resources and may not directly impact Danish policy.

### Decision 7: Fallback Authentication Modality
**Lever ID:** `faccd9cb-306f-4aa8-9ed6-05676b4fbad2`

**The Core Decision:** This lever determines the specific technology used for the fallback authentication path. Success is measured by the chosen modality's security, usability, and compatibility, ensuring it provides a reliable alternative to platform-dependent authentication methods. The choice must balance security with accessibility.

**Why It Matters:** Choosing a browser-based fallback offers broad compatibility but may be perceived as less secure than hardware tokens. Hardware tokens provide stronger security but introduce usability challenges and require additional infrastructure for distribution and management.

**Strategic Choices:**

1. Develop a browser-based fallback authentication path using open standards like WebAuthn, prioritizing ease of access and compatibility across devices
2. Explore a hardware-token-based fallback authentication path, leveraging existing smart-card infrastructure or deploying new USB-based tokens for enhanced security
3. Investigate a hybrid approach that combines browser-based authentication with a one-time password (OTP) delivered via SMS or email as a secondary fallback mechanism

**Trade-Off / Risk:** Browser-based fallbacks offer broad compatibility but may be less secure than hardware tokens, which introduce usability challenges and infrastructure needs.

**Strategic Connections:**

**Synergy:** Fallback Authentication Modality is synergistic with Demonstrator Security Posture, as the chosen modality dictates the security measures that must be implemented and validated.

**Conflict:** This lever trades off against Technical Feasibility Breadth. Some modalities may be technically challenging or costly to implement, limiting the range of feasible options.

**Justification:** *High*, High because it determines the specific technology used for the fallback authentication path, balancing security with accessibility. It dictates the security measures and has a trade-off with technical feasibility.

### Decision 8: Demonstrator Certification Rigor
**Lever ID:** `19e199ff-9622-4fd3-8bbd-c88060bc436f`

**The Core Decision:** This lever controls the level of security certification applied to the technical demonstrators. Higher rigor enhances credibility and trust, particularly with technical stakeholders, but increases costs and timelines. Success is measured by stakeholder confidence in the demonstrators' security and the absence of critical vulnerabilities.

**Why It Matters:** Increasing the rigor of demonstrator certification (e.g., formal security audits, penetration testing) enhances credibility with technical stakeholders and policymakers, but it also increases costs and may delay demonstrator availability. A highly rigorous certification process could also reveal vulnerabilities that require significant rework, potentially jeopardizing the project timeline. Conversely, a less rigorous approach may be dismissed as lacking sufficient security assurance.

**Strategic Choices:**

1. Conduct only basic functional testing on the demonstrators, prioritizing speed and cost-effectiveness over formal security validation
2. Subject the demonstrators to thorough security audits and penetration testing by independent security firms, aiming for a level of assurance comparable to existing MitID components
3. Pursue a staged certification approach, starting with basic security checks and progressively increasing rigor based on stakeholder feedback and available budget

**Trade-Off / Risk:** Higher certification rigor increases demonstrator credibility but also raises costs and delays, while lower rigor risks dismissal due to insufficient security assurance.

**Strategic Connections:**

**Synergy:** A strong Demonstrator Security Posture enhances the value of rigorous certification. It also complements Technical Feasibility Breadth by ensuring that explored solutions are secure.

**Conflict:** This lever conflicts with Technical Demonstrator Scope, as increased certification rigor may necessitate a narrower scope to manage costs and timelines effectively.

**Justification:** *High*, High because it enhances credibility with technical stakeholders and policymakers. It has a direct impact on stakeholder confidence and trades off against demonstrator scope.

### Decision 9: Digitaliseringsstyrelsen Engagement Cadence
**Lever ID:** `8623d28e-415b-4322-b176-a6ae8aab8d10`

**The Core Decision:** This lever manages the frequency of engagement with Digitaliseringsstyrelsen. More frequent engagement can increase influence but risks overwhelming or alienating officials. Success is measured by the project's ability to build a productive relationship with the agency and advance its policy goals without causing friction.

**Why It Matters:** Increasing the frequency and intensity of engagement with Digitaliseringsstyrelsen can improve the project's chances of influencing policy decisions, but it also risks overwhelming or alienating key officials. Overly aggressive lobbying could backfire, damaging the project's credibility and access. Conversely, infrequent engagement may result in the project's concerns being overlooked or dismissed.

**Strategic Choices:**

1. Maintain a low-profile approach, engaging with Digitaliseringsstyrelsen only when formally requested or required
2. Establish a regular cadence of meetings and briefings with Digitaliseringsstyrelsen officials to proactively communicate project findings and recommendations
3. Adopt a flexible approach, adjusting the frequency and intensity of engagement based on policy developments and stakeholder feedback

**Trade-Off / Risk:** Frequent engagement improves influence but risks overwhelming officials, while infrequent engagement may result in concerns being overlooked.

**Strategic Connections:**

**Synergy:** This lever works in synergy with Digitaliseringsstyrelsen Engagement Depth. Frequent engagement is more effective when it involves deeper, more substantive discussions.

**Conflict:** This lever trades off against Coalition Partner Breadth. Over-focusing on Digitaliseringsstyrelsen may reduce time available for broader coalition building.

**Justification:** *Medium*, Medium because it manages the frequency of engagement with Digitaliseringsstyrelsen. More frequent engagement can increase influence but risks overwhelming officials.

### Decision 10: Technical Feasibility Breadth
**Lever ID:** `bda2fc97-503e-431f-a433-d9bfaa3f1767`

**The Core Decision:** This lever determines the scope of the technical feasibility assessment, balancing breadth with depth. A broader assessment may uncover more alternative authentication methods, but it also risks diluting resources and delaying demonstrator development. Success is measured by the identification of viable and secure alternative authentication methods.

**Why It Matters:** A broader feasibility assessment increases the likelihood of identifying viable alternative authentication methods. However, it also dilutes focus and resources, potentially delaying demonstrator development and increasing the complexity of the policy recommendations. A narrow focus risks overlooking promising avenues but allows for deeper exploration of specific solutions.

**Strategic Choices:**

1. Prioritize a deep dive into FIDO2/WebAuthn and OpenID Connect on privacy-respecting Android platforms, focusing on near-term deployability and compatibility with existing systems
2. Conduct a broad survey of emerging authentication technologies, including decentralized identity solutions and hardware-backed security modules, to identify long-term opportunities and potential disruptions
3. Focus exclusively on browser-based and hardware-token-based fallback mechanisms, minimizing reliance on mobile operating systems and app stores to address the core dependency problem directly

**Trade-Off / Risk:** A broad feasibility study risks spreading resources too thin, while a narrow focus might miss crucial alternative authentication methods that could enhance platform neutrality.

**Strategic Connections:**

**Synergy:** This lever synergizes with Technical Demonstrator Scope. A broader feasibility assessment can inform the selection of the most promising demonstrator concepts.

**Conflict:** This lever conflicts with Demonstrator Security Posture. A broader feasibility assessment may limit the resources available for rigorous security testing of each potential solution.

**Justification:** *Medium*, Medium because a broader assessment may uncover more alternative authentication methods, but it also risks diluting resources and delaying demonstrator development.

### Decision 11: Resilience Narrative Emphasis
**Lever ID:** `60f27b8f-5c27-4349-bc51-4e60e7866fd1`

**The Core Decision:** This lever determines the primary justification used to promote platform-neutrality. It involves choosing between emphasizing resilience/continuity or digital sovereignty/democratic accountability, or balancing both. Success is measured by the breadth of stakeholder support and the persuasiveness of the chosen narrative in policy discussions and procurement decisions.

**Why It Matters:** Emphasizing resilience and continuity of service can broaden the appeal of platform-neutrality beyond privacy advocates. However, it also risks diluting the focus on digital sovereignty and democratic accountability, potentially leading to solutions that address resilience without fundamentally challenging platform dominance. A narrow focus on sovereignty may alienate stakeholders primarily concerned with service reliability.

**Strategic Choices:**

1. Frame platform-neutrality as a core component of national resilience, emphasizing the risks of supplier concentration and single points of failure in critical infrastructure
2. Prioritize the digital sovereignty and democratic accountability arguments, highlighting the importance of citizen control and data privacy in the digital identity ecosystem
3. Balance resilience and sovereignty narratives, tailoring the message to specific audiences and emphasizing the complementary benefits of both approaches

**Trade-Off / Risk:** Emphasizing resilience may dilute the focus on digital sovereignty, while prioritizing sovereignty could alienate stakeholders primarily concerned with service reliability.

**Strategic Connections:**

**Synergy:** This lever works well with Policy Framing Emphasis, as the chosen narrative will directly influence the policy proposals made to Digitaliseringsstyrelsen.

**Conflict:** This lever trades off against Digitaliseringsstyrelsen Engagement Depth, as a resilience narrative might require different engagement strategies than a sovereignty narrative.

**Justification:** *Medium*, Medium because emphasizing resilience and continuity of service can broaden the appeal of platform-neutrality beyond privacy advocates, but it also risks diluting the focus.

### Decision 12: Demonstrator Security Posture
**Lever ID:** `3711a53e-431b-4469-bc57-d2bd8cca8c5c`

**The Core Decision:** This lever defines the level of security rigor applied to the technical demonstrators. It balances the need for credibility with resource constraints. Success is measured by the demonstrators' ability to withstand scrutiny and influence stakeholders, without exceeding budget or delaying project timelines.

**Why It Matters:** A stronger security posture for the demonstrators increases their credibility and influence. However, it also increases development costs and complexity, potentially delaying completion and limiting the scope of the technical work. A weaker security posture reduces costs but risks undermining the project's technical authority.

**Strategic Choices:**

1. Implement rigorous security testing and formal verification of the demonstrators, adhering to industry best practices and relevant security standards
2. Adopt a pragmatic security approach, focusing on essential security controls and prioritizing rapid development and demonstration of core functionality
3. Engage an external security firm to conduct a comprehensive security audit of the demonstrators, providing independent validation of their security posture

**Trade-Off / Risk:** A stronger security posture increases credibility but also development costs, while a weaker posture risks undermining the project's technical authority.

**Strategic Connections:**

**Synergy:** A strong Demonstrator Security Posture amplifies the impact of Technical Feasibility Breadth, making the demonstrations more convincing.

**Conflict:** This lever conflicts with Technical Demonstrator Scope, as increased security measures may limit the features and complexity that can be implemented within the available resources.

**Justification:** *Medium*, Medium because a stronger security posture increases credibility but also development costs, while a weaker posture risks undermining the project's technical authority.

### Decision 13: EU Standards Advocacy Intensity
**Lever ID:** `de72cf0f-0574-48f7-ad38-c23b3af3c1df`

**The Core Decision:** This lever controls the level of effort dedicated to influencing EU standards related to digital identity wallets. It balances the potential for broader impact with the need to focus on Danish-specific goals. Success is measured by the inclusion of platform-neutrality or fallback language in relevant EU documents.

**Why It Matters:** More intensive EU standards advocacy increases the likelihood of influencing European Digital Identity Wallet requirements. However, it also diverts resources from Danish-specific interventions and risks overextending the project's capacity. Less intensive advocacy preserves focus but reduces the potential for broader impact.

**Strategic Choices:**

1. Actively participate in relevant EU technical working groups and standards bodies, advocating for platform-neutral access and certified fallback mechanisms in the European Digital Identity Wallet framework
2. Monitor EU standards developments and provide targeted input on specific issues, focusing on areas where Danish advocacy can have the greatest impact
3. Limit EU engagement to information gathering and dissemination, focusing primarily on Danish policy and procurement interventions

**Trade-Off / Risk:** Intensive EU standards advocacy risks diverting resources from Danish-specific interventions, while limited engagement reduces the potential for broader impact.

**Strategic Connections:**

**Synergy:** EU Standards Advocacy Intensity synergizes with Coalition Partner Breadth, as a broader coalition can provide more resources and expertise for EU engagement.

**Conflict:** This lever conflicts with Digitaliseringsstyrelsen Engagement Cadence, as increased EU engagement may reduce the time and resources available for domestic policy interventions.

**Justification:** *Low*, Low because intensive EU standards advocacy risks diverting resources from Danish-specific interventions, while limited engagement reduces the potential for broader impact.
