
## Question 1 - What specific funding allocation is planned for external security reviews within the 10.5 million DKK budget?

**Assumptions:** Assumption: 250,000 DKK is allocated for external security reviews, based on industry standards for similar security-sensitive projects and the need for independent validation of the demonstrators.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the adequacy of the budget allocation for external security reviews.
Details: Insufficient funding for security reviews could lead to undetected vulnerabilities and reduced stakeholder confidence. A budget of 250,000 DKK allows for comprehensive security audits and penetration testing by qualified firms. Mitigation: Prioritize critical security reviews and seek pro bono support from security experts if budget constraints arise. Opportunity: A successful security review can enhance the project's credibility and attract further funding.

## Question 2 - What is the detailed timeline for securing a formal written response from Digitaliseringsstyrelsen, including milestones and dependencies?

**Assumptions:** Assumption: Securing a formal written response from Digitaliseringsstyrelsen will take approximately 6 months, with key milestones including initial contact, proposal submission, follow-up meetings, and response drafting.

**Assessments:** Title: Timeline & Milestones Assessment
Description: Analysis of the timeline for securing a formal response from Digitaliseringsstyrelsen.
Details: A delayed response could impact the project's ability to influence AltID procurement. Mitigation: Establish clear communication channels with Digitaliseringsstyrelsen, proactively address their concerns, and escalate issues as needed. Opportunity: A timely and positive response can significantly enhance the project's impact and credibility.

## Question 3 - What specific roles and responsibilities will be assigned to each team member to avoid dependence on a single specialist, especially in technical areas?

**Assumptions:** Assumption: The technical lead will oversee the demonstrator development, with the additional engineer/contractor providing backup and specialized expertise in web authentication and Linux/GrapheneOS implementation. Knowledge transfer will be a priority.

**Assessments:** Title: Resources & Personnel Assessment
Description: Evaluation of the resource allocation and personnel management strategy.
Details: Dependence on a single specialist poses a significant risk to project continuity. Mitigation: Implement cross-training programs, document key processes, and ensure knowledge sharing among team members. Opportunity: A well-rounded team with diverse skills can enhance the project's resilience and innovation capacity.

## Question 4 - What specific regulatory compliance standards, beyond eIDAS and NSIS, will the technical demonstrators need to adhere to, even in a non-production environment?

**Assumptions:** Assumption: The demonstrators will need to comply with GDPR and relevant Danish data protection laws, even in a simulated environment, to ensure responsible handling of user data and maintain stakeholder trust.

**Assessments:** Title: Governance & Regulations Assessment
Description: Analysis of the regulatory compliance requirements for the project.
Details: Failure to comply with relevant regulations could result in legal liabilities and reputational damage. Mitigation: Conduct a thorough regulatory review, implement appropriate data protection measures, and seek legal advice as needed. Opportunity: Demonstrating strong regulatory compliance can enhance the project's credibility and attract further support.

## Question 5 - What specific risk mitigation strategies will be implemented to address potential security vulnerabilities in the technical demonstrators, beyond external security reviews?

**Assumptions:** Assumption: Regular code reviews, penetration testing, and vulnerability scanning will be conducted throughout the development process to identify and address security vulnerabilities proactively.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Evaluation of the risk management strategies for the project.
Details: Security vulnerabilities in the demonstrators could undermine the project's credibility and impact. Mitigation: Implement a multi-layered security approach, including secure coding practices, regular security testing, and incident response planning. Opportunity: A robust security posture can enhance the project's reputation and attract further investment.

## Question 6 - What measures will be taken to minimize the environmental impact of the project's activities, such as energy consumption and electronic waste disposal?

**Assumptions:** Assumption: The project will prioritize energy-efficient computing practices, responsible electronic waste disposal, and the use of sustainable materials where possible to minimize its environmental footprint.

**Assessments:** Title: Environmental Impact Assessment
Description: Analysis of the project's potential environmental impact.
Details: Neglecting environmental considerations could damage the project's reputation and alienate stakeholders. Mitigation: Implement sustainable practices, such as using energy-efficient equipment, recycling electronic waste, and promoting responsible consumption. Opportunity: Demonstrating environmental responsibility can enhance the project's image and attract environmentally conscious stakeholders.

## Question 7 - What specific strategies will be used to engage with and address the concerns of incumbent platform providers (Apple and Google) regarding platform-neutral alternatives?

**Assumptions:** Assumption: The project will engage with Apple and Google through industry forums and direct communication to address their concerns and explore potential areas of collaboration, emphasizing the benefits of platform-neutrality for innovation and competition.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the stakeholder engagement strategy.
Details: Resistance from incumbent platform providers could hinder the project's progress. Mitigation: Engage with stakeholders proactively, address their concerns, and seek mutually beneficial solutions. Opportunity: Building strong relationships with stakeholders can foster collaboration and increase the project's impact.

## Question 8 - What specific operational systems will be put in place to ensure data security and privacy within the access-controlled workspace, especially concerning sensitive digital identity research data?

**Assumptions:** Assumption: Strict access control measures, data encryption, and regular security audits will be implemented within the access-controlled workspace to protect sensitive digital identity research data.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the operational systems for data security and privacy.
Details: Inadequate data security measures could lead to data breaches and reputational damage. Mitigation: Implement robust access control measures, data encryption, and regular security audits. Opportunity: Demonstrating strong data security practices can enhance the project's credibility and attract further investment.