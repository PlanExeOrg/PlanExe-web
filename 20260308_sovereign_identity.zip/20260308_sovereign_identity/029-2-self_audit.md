Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project does not require breaking any physical laws. The project focuses on digital identity, platform neutrality, and digital sovereignty, which are within the realm of engineering and policy, not physics. No quotes are necessary.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (digital identity) + market (Denmark) + tech/process (platform neutrality) + policy (AltID procurement) without independent evidence at comparable scale. There is no mention of precedent for this specific combination. 

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because while the plan defines strategic choices for each decision lever, it lacks a clear, business-level mechanism-of-action (inputs→process→customer value) for the overall strategy. The plan does not include one-pagers for each strategic concept.

**Mitigation**: Project Manager: Create one-pagers for each strategic concept (e.g., platform neutrality, digital sovereignty) outlining the value hypothesis, success metrics, and decision hooks by 2026-05-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (security vulnerabilities) is minimized. While Risk 6 mentions security vulnerabilities, the plan lacks explicit analysis of cascade effects (e.g., vulnerability → data breach → reputational damage → legal liabilities).

**Mitigation**: Technical Lead: Expand the risk register to explicitly map security vulnerability cascades, adding controls and a dated review cadence by 2026-05-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions permits for demonstrators but lacks a comprehensive matrix detailing required permits, lead times, and dependencies. This absence creates uncertainty about timeline realism.

**Mitigation**: Regulatory and Compliance Specialist: Create a permit/approval matrix detailing required permits, lead times, dependencies, and responsible parties by 2026-05-31.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions funding of 10.5 million DKK but does not specify the funding sources, their status (e.g., LOI, term sheet, closed), the draw schedule, or the runway length. Without this information, it's impossible to assess funding plan integrity.

**Mitigation**: Project Manager: Develop a dated financing plan listing funding sources, status, draw schedule, covenants, and runway length by 2026-05-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits scale-appropriate benchmarks for the 10.5 million DKK budget. There are no vendor quotes or per-area cost normalizations. The plan lacks evidence that the budget is realistic for the stated scope.

**Mitigation**: Project Manager: Obtain ≥3 vendor quotes for demonstrator development, security audits, and personnel costs; normalize per-area costs; adjust budget or de-scope by 2026-06-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline for Digitaliseringsstyrelsen response) as single numbers without providing a range or discussing alternative scenarios. The assumption of a 6-month response lacks detail.

**Mitigation**: Policy and Public Affairs Coordinator: Develop a sensitivity analysis or best/worst/base-case scenario analysis for the Digitaliseringsstyrelsen response timeline by 2026-06-30.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and integration plans for critical components. This absence creates a significant risk of failure.

**Mitigation**: Technical Lead: Produce comprehensive technical specifications, interface definitions, acceptance tests, and an integration map with assigned owners and deadlines by 2026-06-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes claims about compliance with eIDAS, GDPR, and Danish data protection laws, but lacks verifiable artifacts such as legal opinions, compliance assessments, or audit reports. The plan states, "Conduct a compliance review..."

**Mitigation**: Regulatory and Compliance Specialist: Obtain a formal legal opinion confirming compliance with eIDAS, GDPR, and Danish data protection laws by 2026-06-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the "certified fallback authentication path" deliverable is mentioned without specific, verifiable qualities. The plan does not define what constitutes "certified" or the required security level.

**Mitigation**: Technical Lead: Define SMART criteria for the certified fallback authentication path, including a KPI for certification level (e.g., ISO 27001) by 2026-05-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes EU Standards Engagement Level and EU Standards Advocacy Intensity. These add cost/complexity but don't directly support the core goals of platform-neutral access and fallback authentication for *Danish* digital identity.

**Mitigation**: Project Manager: Produce a one-page benefit case for EU Standards Engagement, complete with KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-05-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies a Technical Lead (Demonstrator Development) as essential, but the plan lacks evidence that this role is easy to fill. The plan states, "Oversees the development and security of the technical demonstrators..."

**Mitigation**: Project Manager: Validate the talent market for a Technical Lead with demonstrator development experience by surveying ≥5 candidates by 2026-05-31.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a regulatory matrix (authority, artifact, lead time, predecessors). The plan mentions permits but lacks a comprehensive mapping of regulatory requirements. This absence creates uncertainty about legal feasibility.

**Mitigation**: Regulatory and Compliance Specialist: Develop a regulatory matrix (authority, artifact, lead time, predecessors) for all required permits and licenses by 2026-05-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a long-term sustainability plan but lacks details on funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms. The plan states, "Long-term sustainability plan. Engage stakeholders."

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2026-09-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies physical locations but lacks evidence of zoning/land-use compliance, occupancy limits, fire load, structural limits, noise restrictions, or permit pre-clearance. The plan states, "Requires physical base in Copenhagen..."

**Mitigation**: Project Manager: Perform a fatal-flaw screen with Copenhagen authorities to confirm zoning/land-use, occupancy/egress, fire load, structural limits, and noise by 2026-06-30.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions external dependencies (vendors, data, facilities) but lacks evidence of SLAs, redundancy, or tested failover plans. The plan mentions hardware/software components but lacks supplier diversity.

**Mitigation**: Technical Lead: Secure SLAs with key vendors, add a secondary supplier/path for critical components, and test failover procedures by 2026-09-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Technical Lead is incentivized by demonstrator functionality. This creates a conflict over resource allocation. The plan states, "Insufficient budget" as a risk.

**Mitigation**: Project Manager: Create a shared OKR focused on delivering core demonstrator functionality within budget, aligning Finance and the Technical Lead by 2026-05-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague ‘we will monitor’ is insufficient. The plan does not include a dashboard.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning/stopping by 2026-05-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Technical Demonstrator Scope, Coalition Partner Breadth, Fallback Authentication Modality) that are strongly coupled. A narrower demonstrator scope (Technical Demonstrator Scope) may reduce the resources available for rigorous security testing (Demonstrator Certification Rigor).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-06-30.