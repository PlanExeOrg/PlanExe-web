## Suggestion 1 - eIDAS (electronic IDentification, Authentication and trust Services)

eIDAS is an EU regulation establishing a framework for electronic identification and trust services for electronic transactions in the European Single Market. It ensures that people and businesses can use their own national electronic identification schemes (eIDs) to access public services in other EU countries. It sets standards for electronic signatures, electronic seals, time stamps, electronic delivery services and website authentication.

### Success Metrics

Increased cross-border recognition of electronic identities.
Harmonization of standards for trust services across EU member states.
Enhanced security and interoperability of electronic transactions.
Wider adoption of electronic signatures and other trust services by businesses and citizens.

### Risks and Challenges Faced

Achieving consensus among member states on technical standards and implementation details.
Ensuring interoperability between different national eID schemes.
Addressing concerns about data privacy and security.
Overcoming resistance from stakeholders who prefer proprietary solutions.
The eIDAS regulation had to balance the need for innovation with the need for security and interoperability. This was achieved through a combination of high-level principles and detailed technical standards.

### Where to Find More Information

https://digital-strategy.ec.europa.eu/en/policies/trust-services
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=uriserv%3AOJ.L_.2014.257.01.0073.01.ENG

### Actionable Steps

Contact the European Commission's Directorate-General for Communications Networks, Content and Technology (DG CONNECT) for information on eIDAS implementation.
Engage with national eID authorities in EU member states to understand their specific requirements and challenges.
Participate in relevant standardization bodies, such as ETSI, to contribute to the development of technical standards for eIDAS.

### Rationale for Suggestion

eIDAS is highly relevant because it provides the overarching regulatory framework for digital identity in Europe, including Denmark. The project's goal of influencing AltID and aligning with EU standards directly relates to eIDAS objectives. The challenges faced by eIDAS in achieving interoperability and addressing data privacy concerns are also relevant to the Danish project.
## Suggestion 2 - NemID to MitID Transition

The transition from NemID to MitID was a nationwide project in Denmark to upgrade the national digital identity infrastructure. NemID, used since 2010, was replaced by MitID, offering enhanced security and a more user-friendly experience. The project involved migrating millions of users, updating systems across public and private sectors, and ensuring a smooth transition with minimal disruption to essential services.

### Success Metrics

Successful migration of all NemID users to MitID.
High adoption rate of MitID among Danish citizens and businesses.
Improved security and reduced fraud compared to NemID.
Positive user feedback on the MitID platform.
Minimal disruption to public and private sector services during the transition.

### Risks and Challenges Faced

Migrating millions of users to a new system while maintaining security and usability.
Ensuring compatibility with a wide range of public and private sector services.
Addressing concerns about privacy and data security.
Managing public perception and building trust in the new system.
The project addressed user migration by implementing a phased rollout, providing extensive user support, and offering multiple authentication methods.

### Where to Find More Information

https://www.digitaliseringsstyrelsen.dk/english/
https://www.nets.eu/solutions/e-identity/nemid/Pages/default.aspx (archived)

### Actionable Steps

Contact Digitaliseringsstyrelsen (The Danish Agency for Digital Government) for information on the MitID project and its implementation.
Review public reports and evaluations of the NemID to MitID transition to understand the challenges and lessons learned.
Engage with Nets A/S, the company responsible for operating NemID and MitID, to learn about the technical aspects of the transition.

### Rationale for Suggestion

This project is directly relevant as it involves a major overhaul of Denmark's digital identity system. The challenges encountered during the NemID to MitID transition, such as user migration, system compatibility, and public perception, are highly relevant to the current project. Understanding how these challenges were addressed can provide valuable insights for influencing the AltID rollout and ensuring a smooth transition to platform-neutral authentication.
## Suggestion 3 - BankID (Sweden)

BankID is a Swedish electronic identification system used for authenticating users and signing transactions online. It is widely used in Sweden for banking, e-commerce, and public services. The system is supported by a consortium of Swedish banks and is considered a highly secure and reliable form of digital identification.

### Success Metrics

High adoption rate among Swedish citizens and businesses.
Widespread use across various online services.
Low fraud rates compared to other authentication methods.
Positive user feedback on the security and usability of the system.

### Risks and Challenges Faced

Maintaining security and preventing fraud in a constantly evolving threat landscape.
Ensuring accessibility for all users, including those with disabilities.
Addressing concerns about privacy and data security.
Managing the complexity of a system supported by multiple banks.
BankID addressed security concerns by implementing strong authentication protocols, regularly updating its security measures, and working closely with law enforcement agencies.

### Where to Find More Information

https://www.bankid.com/
https://en.wikipedia.org/wiki/BankID

### Actionable Steps

Contact Finansiell ID-Teknik BID AB, the company responsible for operating BankID, for information on the system's architecture and security measures.
Review public reports and evaluations of BankID to understand its strengths and weaknesses.
Engage with Swedish banks and government agencies to learn about their experiences with BankID.

### Rationale for Suggestion

While geographically distant, BankID in Sweden serves as a relevant example of a widely adopted and successful national digital identity system. Its success in achieving high adoption rates, maintaining security, and integrating with various online services provides valuable lessons for the Danish project. The challenges faced by BankID in addressing security concerns and ensuring accessibility are also relevant to the Danish context.

## Summary

The user is planning a project in Denmark to reduce the country's digital identity infrastructure's dependence on foreign technology providers, specifically Apple and Google. The project aims to establish a platform-neutral fallback authentication path, primarily by influencing the AltID rollout. The project involves technical demonstrators, policy proposals, and coalition building. The following are reference projects that have similar goals, challenges, and approaches.