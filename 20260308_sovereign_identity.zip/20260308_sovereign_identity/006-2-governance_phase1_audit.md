
## Audit - Corruption Risks

- Bribery of Digitaliseringsstyrelsen officials to influence AltID procurement decisions in favor of specific vendors or solutions.
- Kickbacks from contractors or suppliers in exchange for favorable treatment or contract awards.
- Conflicts of interest involving project team members with undisclosed financial ties to companies bidding on AltID-related contracts.
- Misuse of project funds for personal gain or unauthorized expenses, disguised as legitimate project costs.
- Nepotism or favoritism in the hiring of project personnel or selection of contractors, leading to unqualified individuals being placed in key roles.

## Audit - Misallocation Risks

- Overspending on demonstrator development, diverting funds from policy engagement or coalition building.
- Inefficient allocation of personnel time, with staff spending excessive time on low-impact tasks.
- Duplication of effort across different project phases, leading to wasted resources.
- Unauthorized use of project assets, such as hardware or software, for personal purposes.
- Misreporting of project progress or results to justify continued funding or to conceal delays or failures.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, including a review of all expenses and invoices, to ensure compliance with budget guidelines.
- Perform periodic technical audits of the demonstrators to identify and address any security vulnerabilities or functional deficiencies.
- Implement a contract review process with pre-defined thresholds (e.g., contracts exceeding 500,000 DKK) requiring independent legal review to ensure fairness and compliance.
- Establish a workflow for expense approvals, requiring multiple levels of authorization for expenses exceeding a certain amount (e.g., 50,000 DKK).
- Conduct a post-project external audit to assess the overall effectiveness of the project and identify any lessons learned for future initiatives.

## Audit - Transparency Measures

- Publish a project progress dashboard on a publicly accessible website, providing regular updates on key milestones, budget expenditures, and risk assessments.
- Publish minutes of key project meetings, including those of the project steering committee and technical advisory group, on the project website.
- Establish a whistleblower mechanism, allowing individuals to report suspected fraud, corruption, or other misconduct anonymously and without fear of retaliation.
- Make the project's feasibility report, policy proposal, and fallback-authentication concept note publicly available on the project website.
- Document and publish the selection criteria used for major decisions, such as the selection of contractors or the choice of demonstrator technologies.