
## Risk 1 - Regulatory & Permitting
Delays or inability to obtain necessary permits or approvals for the technical demonstrators, particularly if they involve any interaction with live government systems or data, even in a simulated environment. The 'permit/approval and stakeholder matrix' deliverable in Phase 1 aims to identify these, but unforeseen regulatory hurdles could still arise.

**Impact:** A delay of 2-6 months in Phase 2, potentially jeopardizing the demonstrator development and impacting the project's ability to influence AltID procurement. Could also lead to increased legal costs of 50,000-100,000 DKK.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage with Digitaliseringsstyrelsen early in Phase 1 to clarify regulatory requirements for the demonstrators. Develop contingency plans for alternative demonstrator designs that minimize regulatory risk. Secure preliminary legal advice on potential permitting challenges.

## Risk 2 - Technical
The technical demonstrators may not be able to achieve the required level of security or functionality to be considered credible by stakeholders. This could be due to unforeseen technical challenges in implementing platform-neutral authentication or limitations in the chosen technologies (e.g., FIDO2/WebAuthn).

**Impact:** Loss of credibility with Digitaliseringsstyrelsen and other stakeholders, reducing the project's influence on AltID procurement. Could lead to a need to re-scope the technical work, resulting in a 3-4 month delay and an additional cost of 200,000-400,000 DKK.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct thorough security reviews and penetration testing of the demonstrators. Engage with external security experts to identify and address potential vulnerabilities. Maintain a flexible demonstrator design that allows for adjustments based on technical feasibility.

## Risk 3 - Financial
The project budget of 10.5 million DKK may be insufficient to cover all planned activities, particularly if unforeseen technical challenges or regulatory hurdles arise. The project plan explicitly warns against assuming that 8 million DKK is sufficient.

**Impact:** A reduction in the scope of the project, potentially impacting the quality or credibility of the technical demonstrators or the extent of policy engagement. Could lead to a need to seek additional funding, which may not be available.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget breakdown and track expenses closely. Identify potential cost-saving measures and contingency plans for reducing the scope of the project if necessary. Explore opportunities for securing additional funding from other sources.

## Risk 4 - Social
Lack of support from key stakeholders, including Digitaliseringsstyrelsen, the MitID operator, or members of Folketinget's digital policy committee. This could be due to resistance to change, concerns about the cost or complexity of platform-neutral authentication, or lobbying from incumbent platform providers.

**Impact:** Reduced influence on AltID procurement and policy decisions. Could lead to a need to re-scope the project to focus on EU-level engagement or publication and coalition consolidation.

**Likelihood:** Medium

**Severity:** High

**Action:** Build strong relationships with key stakeholders through regular communication and engagement. Tailor the project's messaging to address their specific concerns and priorities. Highlight the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty.

## Risk 5 - Operational
Difficulty in recruiting and retaining qualified personnel, particularly those with expertise in mobile security, authentication protocols, and Danish/EU digital identity frameworks. The project plan emphasizes avoiding dependence on a single specialist, but finding suitable replacements could still be challenging.

**Impact:** Delays in project execution and a reduction in the quality of deliverables. Could lead to a need to outsource some of the technical work, increasing costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Develop a comprehensive recruitment plan and offer competitive salaries and benefits. Provide opportunities for professional development and training. Foster a collaborative and supportive work environment.

## Risk 6 - Security
Security vulnerabilities in the technical demonstrators could be exploited by malicious actors, compromising the security of the simulated Danish public-sector identity-provider environment or the privacy of user data. This could damage the project's credibility and undermine its efforts to promote platform-neutral authentication.

**Impact:** Significant reputational damage and loss of stakeholder trust. Could lead to legal liabilities and financial penalties.

**Likelihood:** Low

**Severity:** High

**Action:** Implement robust security measures throughout the development process. Conduct regular security audits and penetration testing. Comply with all relevant security standards and regulations. Ensure that all personnel are trained in security best practices.

## Risk 7 - Supply Chain
Delays or disruptions in the supply of hardware or software components required for the technical demonstrators, such as hardware tokens or GrapheneOS-compatible devices. This could be due to global supply chain issues, geopolitical events, or vendor-specific problems.

**Impact:** Delays in project execution and a need to find alternative suppliers or technologies. Could lead to increased costs.

**Likelihood:** Low

**Severity:** Medium

**Action:** Identify alternative suppliers for critical components. Maintain a buffer stock of essential hardware and software. Develop contingency plans for using alternative technologies if necessary.

## Risk 8 - Integration with Existing Infrastructure
Challenges in demonstrating the feasibility of platform-neutral authentication within the existing MitID ecosystem, which is tightly coupled to Apple/Google platform integrity signals. The project aims to influence AltID, but resistance from incumbent operators could limit the project's impact.

**Impact:** The project's recommendations may not be adopted by Digitaliseringsstyrelsen or the MitID operator, limiting its impact on Danish digital identity infrastructure.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Focus on demonstrating the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty. Engage with the MitID operator to identify potential areas of collaboration. Develop a clear and compelling value proposition for platform-neutral authentication.

## Risk 9 - Environmental
The project's activities, such as the development and testing of technical demonstrators, could have a negative impact on the environment, particularly in terms of energy consumption and electronic waste. While likely minimal, it's important to consider.

**Impact:** Minor reputational damage and potential criticism from environmental groups.

**Likelihood:** Low

**Severity:** Low

**Action:** Implement energy-efficient practices in the project's operations. Recycle electronic waste responsibly. Promote sustainable development practices within the project team.

## Risk 10 - Long-Term Sustainability
The project's impact may be limited if the recommendations are not implemented and sustained over the long term. This could be due to changes in government policy, funding priorities, or technological developments.

**Impact:** The project's efforts may be wasted if platform-neutral authentication is not adopted and sustained over the long term.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a long-term sustainability plan that includes strategies for promoting the adoption and maintenance of platform-neutral authentication. Engage with relevant stakeholders to ensure that the project's recommendations are integrated into long-term planning processes.

## Risk summary
The most critical risks are the potential for technical challenges in developing credible demonstrators, lack of support from key stakeholders, and insufficient budget to cover all planned activities. The project's success hinges on effectively managing these risks through proactive engagement with stakeholders, rigorous security testing, and careful budget management. The trade-off between technical demonstrator scope and certification rigor is also a key consideration. Overlapping mitigation strategies include building strong relationships with Digitaliseringsstyrelsen and other stakeholders, tailoring the project's messaging to address their specific concerns, and highlighting the benefits of platform-neutral authentication in terms of resilience, continuity of service, and digital sovereignty.