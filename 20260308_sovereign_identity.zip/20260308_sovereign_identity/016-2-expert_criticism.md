# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Behavioral Economist

**Knowledge**: behavioral insights, public policy, user adoption, incentive design

**Why**: To assess user adoption barriers and incentives for platform-neutral solutions, addressing the 'convenience arguments' threat.

**What**: Analyze user behavior and design interventions to promote adoption of platform-neutral digital identity solutions.

**Skills**: choice architecture, experimental design, data analysis, communication

**Search**: behavioral economist, user adoption, public policy, digital identity

## 1.1 Primary Actions

- Develop a detailed contingency plan for Digitaliseringsstyrelsen disengagement, including alternative strategies and revised timelines.
- Conduct user research to identify key user needs and preferences for digital identity solutions and develop a prototype 'killer application'.
- Define quantifiable KPIs for each strategic objective, including specific targets and measurement methods.

## 1.2 Secondary Actions

- Engage with behavioral economists and UX designers to optimize the user experience and increase adoption rates.
- Consult with policy strategists experienced in public-sector innovation to refine the engagement strategy with Digitaliseringsstyrelsen.
- Review and revise the project's risk assessment to incorporate the identified weaknesses and threats.

## 1.3 Follow Up Consultation

Discuss the revised project plan, including the contingency plan, user research findings, and quantifiable KPIs. Review the budget and timeline to ensure alignment with the revised scope and objectives. Assess the team's capacity to implement the changes and identify any additional resources or expertise required.

## 1.4.A Issue - Over-reliance on Digitaliseringsstyrelsen engagement without a robust contingency plan.

The project's success hinges significantly on the Digitaliseringsstyrelsen's receptiveness and active participation. While engagement is crucial, the plan lacks a clearly defined alternative strategy if the agency proves resistant or uncooperative. This dependency creates a single point of failure that could derail the entire project. The 'Builder's Foundation' scenario selection reinforces this dependency, potentially limiting the exploration of more independent paths.

### 1.4.B Tags

- stakeholder_dependency
- risk_mitigation
- strategic_flexibility

### 1.4.C Mitigation

Develop a detailed contingency plan outlining alternative strategies if Digitaliseringsstyrelsen engagement proves unfruitful. This could involve focusing on EU-level advocacy, building stronger alliances with industry partners, or shifting the focus to demonstrably superior technical solutions that create market demand. Consult with experienced policy strategists who have navigated similar challenges in public-sector innovation. Review the 'Pioneer's Gambit' scenario for potentially useful elements.

### 1.4.D Consequence

If Digitaliseringsstyrelsen is uncooperative, the project's impact will be severely limited, potentially resulting in wasted resources and a failure to achieve the desired policy changes.

### 1.4.E Root Cause

Optimistic assumptions about stakeholder cooperation.

## 1.5.A Issue - Insufficient focus on user experience and adoption.

The project prioritizes technical feasibility and policy influence, but it neglects the crucial aspect of user experience (UX) and adoption. Without a compelling user-centric design and a clear value proposition for citizens, even the most technically sound and politically supported solution will fail to gain traction. The lack of a 'killer application' exacerbates this issue. The project needs to move beyond infrastructure and policy and focus on creating a citizen-facing application that showcases the benefits of platform neutrality in a tangible way.

### 1.5.B Tags

- user_adoption
- ux_design
- value_proposition

### 1.5.C Mitigation

Conduct thorough user research to understand the needs and preferences of Danish citizens regarding digital identity solutions. Invest in UX design expertise to create intuitive and user-friendly interfaces for the technical demonstrators. Develop a prototype of a 'killer application' that showcases the benefits of platform-neutral digital identity in a compelling way. Consult with behavioral economists and UX designers to optimize the user experience and increase adoption rates. Read 'Nudge' by Thaler and Sunstein for insights on choice architecture.

### 1.5.D Consequence

Low user adoption will undermine the project's long-term sustainability and impact, even if it succeeds in influencing policy and procurement decisions.

### 1.5.E Root Cause

Technical and policy focus overshadowing user-centric considerations.

## 1.6.A Issue - Vague success metrics and lack of quantifiable KPIs.

While the project outlines success criteria, they are largely qualitative and lack specific, measurable, achievable, relevant, and time-bound (SMART) key performance indicators (KPIs). For example, 'inclusion of platform-neutrality language in AltID-related documents' is a desirable outcome, but it doesn't specify the level of specificity or enforceability of that language. Similarly, 'securing a formal written response from Digitaliseringsstyrelsen' doesn't guarantee meaningful engagement or commitment. The project needs to define more concrete and quantifiable KPIs to track progress and measure success effectively.

### 1.6.B Tags

- kpi_definition
- measurement
- goal_setting

### 1.6.C Mitigation

Develop a set of quantifiable KPIs that align with the project's strategic objectives. For example, instead of 'inclusion of platform-neutrality language,' specify the minimum number of specific, enforceable requirements related to platform neutrality that must be included in AltID procurement documents. Instead of 'securing a formal written response,' specify the level of commitment or action that the response must contain. Consult with experts in performance measurement and evaluation to develop robust and meaningful KPIs. Provide baseline data and targets for each KPI.

### 1.6.D Consequence

Without clear and measurable KPIs, it will be difficult to track progress, evaluate the project's impact, and make informed decisions about resource allocation.

### 1.6.E Root Cause

Lack of experience in defining and tracking performance metrics for policy-oriented projects.

---

# 2 Expert: EU Digital Policy Advisor

**Knowledge**: eIDAS, digital wallets, EU policy, standardization, interoperability

**Why**: To maximize influence on EU standards and ensure alignment with broader European requirements for digital identity wallets.

**What**: Advise on EU policy developments and advocacy strategies to promote platform-neutral access and fallback mechanisms.

**Skills**: policy analysis, advocacy, stakeholder engagement, regulatory affairs

**Search**: eIDAS, digital wallets, EU policy, digital identity

## 2.1 Primary Actions

- Conduct a detailed analysis of MitID architecture and identify potential integration points for platform-neutral solutions.
- Engage a legal expert specializing in eIDAS2 and NSIS to conduct a compliance gap analysis.
- Reframe the discussion around GrapheneOS as a reference platform and explore a broader range of platform-neutral options.
- Develop a detailed engagement plan with Digitaliseringsstyrelsen, including milestones, communication protocols, and escalation procedures.
- Proactively engage with Apple and Google to address their concerns and explore potential collaborations on platform-neutral solutions.
- Conduct user research to identify potential 'killer application' use-cases that would showcase the benefits of platform-neutral digital identity to citizens.
- Allocate additional budget (at least 250,000 DKK) for comprehensive security audits and penetration testing of the technical demonstrators.
- Implement a knowledge transfer program with documentation, cross-training, and knowledge-sharing to mitigate the risk of reliance on specific technical skills within the team.

## 2.2 Secondary Actions

- Consult with MitID operators (even informally) to understand their technical constraints and priorities.
- Consult with relevant regulatory bodies (e.g., the Danish Business Authority) to clarify any ambiguities and obtain guidance on compliance strategies.
- Conduct user research to understand the needs and preferences of different user groups and tailor the proposed solutions accordingly.
- Consult with accessibility experts to ensure that the proposed solutions are usable by people with disabilities.

## 2.3 Follow Up Consultation

In the next consultation, we should discuss the findings of the MitID architecture analysis, the eIDAS2/NSIS compliance gap analysis, and the user research on platform-neutral solutions. We should also review the engagement plan with Digitaliseringsstyrelsen and the strategy for engaging with Apple and Google.

## 2.4.A Issue - Lack of Concrete Interoperability Strategy with Existing MitID Infrastructure

The plan focuses heavily on AltID and influencing future procurement, but it lacks a concrete strategy for interoperability or graceful transition from the existing MitID infrastructure. While a full replacement is acknowledged as unrealistic, ignoring the existing system entirely creates a significant adoption barrier. The plan needs to address how the proposed platform-neutral solutions can coexist and interact with MitID, even if initially only in specific use cases or as a fallback mechanism. Without this, the project risks being perceived as an isolated effort with limited real-world applicability.

### 2.4.B Tags

- interoperability
- adoption
- legacy systems
- practicality

### 2.4.C Mitigation

Conduct a thorough analysis of the MitID architecture and identify specific integration points where platform-neutral solutions could be introduced without requiring a complete overhaul. Consult with MitID operators (if possible, even informally) to understand their technical constraints and priorities. Explore the feasibility of creating a 'bridge' or gateway that allows users to authenticate with platform-neutral methods and then access MitID-protected services. Document these findings in the feasibility report and use them to inform the design of the technical demonstrators.

### 2.4.D Consequence

Without a clear interoperability strategy, the project's recommendations are likely to be ignored by decision-makers who are responsible for maintaining the existing MitID infrastructure. This will significantly reduce the project's impact and limit the adoption of platform-neutral solutions.

### 2.4.E Root Cause

Overfocus on future systems (AltID) and a desire to avoid direct confrontation with the complexities of the existing MitID system.

## 2.5.A Issue - Insufficiently Granular Risk Assessment Regarding eIDAS2 and NSIS Compliance

The plan mentions eIDAS and NSIS compliance, but the risk assessment lacks granularity. It's not enough to simply state that the project will comply with these regulations. A detailed analysis is needed to identify specific requirements within eIDAS2 and NSIS that could pose challenges to the implementation of platform-neutral solutions. For example, what specific assurance levels are required for different use cases, and how can these be achieved without relying on platform-specific security features? What are the implications of the qualified trust service provider (QTSP) requirements for fallback authentication mechanisms? This level of detail is crucial for demonstrating the project's credibility and ensuring that the proposed solutions are legally and technically viable.

### 2.5.B Tags

- compliance
- eIDAS2
- NSIS
- risk assessment
- legal
- technical viability

### 2.5.C Mitigation

Engage a legal expert specializing in eIDAS2 and NSIS to conduct a detailed compliance gap analysis. Identify specific requirements that are relevant to platform-neutral authentication and fallback mechanisms. Develop a matrix that maps these requirements to the proposed technical solutions and outlines the steps needed to achieve compliance. Consult with relevant regulatory bodies (e.g., the Danish Business Authority) to clarify any ambiguities and obtain guidance on compliance strategies. Document these findings in the feasibility report and use them to inform the design of the technical demonstrators.

### 2.5.D Consequence

Failure to address eIDAS2 and NSIS compliance in detail could result in the project's recommendations being rejected by regulators or deemed legally invalid. This would significantly undermine the project's credibility and impact.

### 2.5.E Root Cause

Lack of deep expertise in eIDAS2 and NSIS regulations within the project team, leading to a superficial understanding of the compliance challenges.

## 2.6.A Issue - Over-Reliance on GrapheneOS as a Platform-Neutral Solution

While GrapheneOS is a commendable effort towards privacy-respecting Android, the plan's reliance on it as a cornerstone of platform neutrality is problematic. GrapheneOS has a very small market share and requires a technically proficient user base. It's not a realistic solution for the vast majority of Danish citizens. Presenting it as *the* platform-neutral option risks alienating stakeholders and undermining the project's credibility. The plan needs to acknowledge the limitations of GrapheneOS and explore a broader range of platform-neutral options that are more accessible and user-friendly.

### 2.6.B Tags

- platform neutrality
- user accessibility
- market share
- realism
- stakeholder perception

### 2.6.C Mitigation

Reframe the discussion around GrapheneOS as a *reference platform* for demonstrating the feasibility of platform-neutral authentication. Emphasize that the project is exploring a range of options, including browser-based authentication, hardware tokens, and other Android-compatible solutions that are more widely accessible. Conduct user research to understand the needs and preferences of different user groups and tailor the proposed solutions accordingly. Consult with accessibility experts to ensure that the proposed solutions are usable by people with disabilities. Document these findings in the feasibility report and use them to inform the design of the technical demonstrators.

### 2.6.D Consequence

Presenting GrapheneOS as the primary platform-neutral solution will likely be perceived as unrealistic and out-of-touch by stakeholders, undermining the project's credibility and reducing its impact.

### 2.6.E Root Cause

Potential bias towards technically sophisticated solutions and a lack of focus on user accessibility and real-world adoption.

---

# The following experts did not provide feedback:

# 3 Expert: Procurement Law Specialist

**Knowledge**: public procurement, contract law, EU directives, supplier diversity

**Why**: To ensure procurement language is legally sound and enforceable, addressing the 'Procurement Language Specificity' decision.

**What**: Review and refine procurement language to ensure compliance with relevant laws and maximize the project's impact.

**Skills**: legal drafting, negotiation, risk assessment, compliance

**Search**: procurement law, EU directives, contract law, Denmark

# 4 Expert: Contingency Planning Expert

**Knowledge**: risk management, business continuity, disaster recovery, resilience

**Why**: To strengthen the resilience narrative and develop robust fallback authentication paths, addressing continuity-of-service concerns.

**What**: Assess the project's risk mitigation strategies and develop contingency plans for potential disruptions to digital identity services.

**Skills**: risk assessment, scenario planning, crisis management, communication

**Search**: contingency planning, risk management, business continuity, Denmark

# 5 Expert: Mobile App Security Auditor

**Knowledge**: mobile security, penetration testing, reverse engineering, iOS, Android

**Why**: To rigorously assess the security of the technical demonstrators and identify potential vulnerabilities, addressing security risks.

**What**: Conduct comprehensive security audits and penetration testing of the mobile-oriented demonstrator.

**Skills**: vulnerability assessment, threat modeling, secure coding, ethical hacking

**Search**: mobile app security, penetration testing, iOS, Android, Denmark

# 6 Expert: Open Source Advocate

**Knowledge**: open source, licensing, community building, software development, governance

**Why**: To promote the use of open standards and open-source technologies in the project, fostering transparency and collaboration.

**What**: Advise on open-source licensing and community-building strategies for the project's technical demonstrators.

**Skills**: community management, advocacy, software development, licensing

**Search**: open source, licensing, community building, digital identity

# 7 Expert: Digital Accessibility Specialist

**Knowledge**: accessibility, WCAG, assistive technology, inclusive design, usability

**Why**: To ensure the platform-neutral solutions are accessible to all users, including those with disabilities, promoting inclusivity.

**What**: Assess the accessibility of the technical demonstrators and provide recommendations for improvement.

**Skills**: accessibility testing, usability, inclusive design, WCAG

**Search**: digital accessibility, WCAG, assistive technology, Denmark

# 8 Expert: Public Opinion Researcher

**Knowledge**: survey design, data analysis, public opinion, polling, focus groups

**Why**: To gauge public awareness and understanding of platform neutrality, informing the project's communication and advocacy strategies.

**What**: Conduct surveys and focus groups to assess public attitudes toward platform-neutral digital identity solutions.

**Skills**: survey design, data analysis, communication, public opinion

**Search**: public opinion research, survey design, digital identity, Denmark