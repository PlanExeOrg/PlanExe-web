Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project does not require breaking any physical laws. The plan focuses on engineering, economics, and social policy, which are outside the scope of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (Basis-Nahrung), market (Bürgergeld recipients), technology/process (wastewater treatment), and policy (mandatory acceptance) without independent evidence at comparable scale. There is no precedent for this specific system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Owner / Authoritative Source / 180 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear definition of 'Crisis-Resilience' and its mechanism-of-action. The plan states, "Reliance on 'Crisis-Resilience' regulatory category to bypass EU food safety laws." Without a one-pager, the strategic concept is undefined.

**Mitigation**: Regulatory Compliance Specialist: Produce a one-pager defining 'Crisis-Resilience' with inputs, process, customer value, owner, measurable outcomes, value hypotheses, success metrics, and decision hooks by Q3 2024.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan minimizes major hazard classes. The plan lacks a comprehensive risk assessment, especially regarding long-term health consequences and ethical considerations. The plan states, "Potential health issues from chemical residues in Basis-Nahrung."

**Mitigation**: Project Team: Expand the risk register to include long-term health impacts, ethical considerations, and legal challenges, mapping cascades and adding controls with a review cadence by Q2 2024.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a 6-month approval, but the plan omits a permit/approval matrix and authoritative lead times. The plan states, "Obtain necessary permits for the Bio-Ressourcen-Zentrum (BRZ)."

**Mitigation**: Regulatory Compliance Specialist: Build a permit/approval matrix with dated predecessors, authoritative permit lead times, and a NO-GO threshold on slip by Q2 2024.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "€21M contingency fund from Berlin" but lacks details on committed funding sources, draw schedule, and covenants. The plan does not specify the status (e.g., LOI, term sheet, closed) of this funding.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by Q2 2024.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €210 million lacks substantiation via vendor quotes or scale-appropriate benchmarks normalized by area. The plan states, "allocated budget of €210 million" without evidence of cost realism.

**Mitigation**: CFO: Benchmark (≥3) capex/fit-out/opex, obtain quotes, normalize per-area (cost per m²/ft²), and adjust budget or de-scope by Q3 2024.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., 36-month timeline) as single numbers without providing a range or discussing alternative scenarios. The plan states, "within 36 months" without sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 36-month completion projection by Q2 2024.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. The plan mentions hydrothermal carbonization and high-pressure filtration, but lacks specs, interface contracts, acceptance tests, and an integration plan.

**Mitigation**: Head of Engineering: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by Q3 2024.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Reliance on 'Crisis-Resilience' regulatory category to bypass EU food safety laws." but lacks a legal opinion validating this claim. Without this, the project's legality is uncertain.

**Mitigation**: Legal Counsel: Obtain a formal legal opinion from an EU regulatory lawyer confirming the applicability of the 'Crisis-Resilience' category by Q4 2024.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "Basis-Nahrung" is mentioned without specific, verifiable qualities. The plan states, "Produce Basis-Nahrung, a nutrient-rich food source," but lacks SMART acceptance criteria.

**Mitigation**: Project Team: Define SMART criteria for Basis-Nahrung, including a KPI for nutritional content (e.g., % of RDA met) and safety (e.g., contaminant levels) by Q2 2024.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "Celebrity Endorsement & Gamified Adoption" which adds cost/complexity without directly supporting core goals like debt reduction or food security. The plan states, "Partner with local chefs and influencers...rewards Basis-Nahrung consumption."

**Mitigation**: Project Team: Produce a one-page benefit case for 'Celebrity Endorsement & Gamified Adoption' with KPI, owner, and cost, or move the feature to the project backlog by Q2 2024.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Regulatory Compliance Specialist" to navigate complex EU and German regulations, particularly concerning food safety. This role is critical, and the plan states, "Significant delays, legal challenges, fines, and potential project shutdown due to non-compliance."

**Mitigation**: HR: Validate the talent market for an EU Regulatory Compliance Specialist with food safety expertise by engaging a specialist recruiter and mapping the available talent pool within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states, "Apply for necessary permits and licenses" without a regulatory matrix (authority, artifact, lead time, predecessors). The plan omits a fatal-flaw analysis and a NO-GO threshold on adverse findings.

**Mitigation**: Regulatory Compliance Specialist: Build a regulatory matrix (authority, artifact, lead time, predecessors) and a NO-GO threshold on adverse findings by Q2 2024.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive operational sustainability plan. The plan states, "Secure a domestic food reserve," but lacks a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Project Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by Q3 2024.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies the need for permits but lacks a fatal-flaw screen with authorities. The plan states, "Apply for necessary permits and licenses" but lacks evidence of pre-application consultation.

**Mitigation**: Regulatory Compliance Specialist: Conduct a fatal-flaw screen with relevant permitting authorities and document findings within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "multiple suppliers for essential inputs" but lacks evidence of contracts, SLAs, or tested failover plans. The plan states, "Buffer stock of critical supplies" without specifying size or location.

**Mitigation**: Procurement: Secure SLAs with secondary suppliers for critical inputs and test failover procedures by Q4 2024.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan pits the 'Finance Department' (municipal debt reduction) against 'Public Engagement' (public acceptance of mandatory Basis-Nahrung). Finance is incentivized by cost savings, while Public Engagement is incentivized by adoption.

**Mitigation**: Project Leadership: Define a shared OKR (Objective and Key Results) that aligns Finance and Public Engagement on a common outcome, such as 'Increase program participation while staying within budget' by Q2 2024.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Leadership: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds and owners by Q2 2024.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive assessment of interactions among risks, particularly the potential for legal challenges from consumer rights organizations and regulatory bodies to trigger multi-domain failures. The plan states, "Assess interactions among risks using cross-impact, bow-tie, or FTA to surface multi-node cascades and common-mode failures."

**Mitigation**: Risk Management Team: Develop an interdependency map, bow-tie analysis, and combined heatmap to identify critical risk interactions, with NO-GO thresholds, by Q3 2024.