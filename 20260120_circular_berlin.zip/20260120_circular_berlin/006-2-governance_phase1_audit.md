
## Audit - Corruption Risks

- Bribery of regulatory officials to expedite permits or bypass safety inspections for the BRZ facility.
- Kickbacks from equipment suppliers in exchange for awarding contracts for hydrothermal carbonization and high-pressure filtration equipment.
- Conflicts of interest involving project team members with undisclosed financial ties to companies involved in the Basis-Nahrung distribution network.
- Misuse of confidential information regarding the restructuring of the Bürgergeld system for personal gain or to benefit associates.
- Trading favors with contractors by overlooking substandard work in exchange for personal benefits or future considerations.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use.
- Double-billing for services or materials, with the same expenses claimed multiple times.
- Inefficient allocation of resources, such as overspending on non-essential aspects of the project while neglecting critical areas like quality control or safety.
- Unauthorized use of project assets, such as vehicles or equipment, for personal purposes.
- Misreporting project progress or results to secure further funding or avoid scrutiny, even if milestones are not actually met.

## Audit - Procedures

- Conduct periodic internal reviews of all financial transactions, with a focus on procurement processes and contract management, at least quarterly.
- Implement a robust expense workflow with multiple levels of approval and detailed documentation requirements for all expenditures above a defined threshold (€5,000).
- Perform regular compliance checks to ensure adherence to all relevant EU and German regulations, including food safety and environmental standards, at least annually.
- Conduct a post-project external audit by an independent auditing firm to assess the overall effectiveness and efficiency of the BRZ project.
- Establish a whistleblower mechanism with clear procedures for reporting suspected fraud or corruption, ensuring anonymity and protection for whistleblowers.

## Audit - Transparency Measures

- Create a public dashboard displaying key project metrics, including budget expenditures, progress against milestones, and environmental impact data.
- Publish minutes of steering committee meetings, including discussions and decisions related to regulatory compliance, funding, and risk management.
- Establish a publicly accessible repository for all relevant project policies, reports, and environmental impact assessments.
- Document and publish the selection criteria for all major decisions, including vendor selection and technology choices.
- Implement a system for tracking and responding to public inquiries and complaints related to the BRZ project.