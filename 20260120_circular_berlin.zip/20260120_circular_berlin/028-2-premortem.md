A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The 'Crisis-Resilience' regulatory category will remain in effect and applicable to the BRZ project. | Engage with EU regulatory bodies to present the project and solicit their feedback on the applicability of the 'Crisis-Resilience' category. | EU regulatory bodies express significant reservations or indicate potential legal challenges to the 'Crisis-Resilience' classification for Basis-Nahrung. |
| A2 | The hydrothermal carbonization and high-pressure filtration technologies will perform as expected at scale. | Conduct pilot testing at a smaller scale to validate the performance of the technology under realistic operating conditions. | Pilot testing reveals that the technologies fail to consistently remove contaminants to safe levels or achieve the projected production yields. |
| A3 | Bürgergeld recipients will comply with the mandatory acceptance of Basis-Nahrung. | Conduct a survey and focus groups with a representative sample of Bürgergeld recipients to gauge their attitudes towards Basis-Nahrung and mandatory acceptance. | Survey results indicate that more than 40% of Bürgergeld recipients are unwilling to accept Basis-Nahrung under the proposed mandatory conditions. |
| A4 | The existing Jobcenter infrastructure is adequate for distributing Basis-Nahrung efficiently and without creating undue stigma. | Conduct a pilot distribution program through existing Jobcenter locations, closely monitoring wait times, recipient feedback, and any signs of congestion or negative perceptions. | Pilot program data reveals long wait times (>= 60 minutes), negative feedback from recipients regarding the distribution process, or evidence of overcrowding and congestion at Jobcenter locations during distribution hours. |
| A5 | The local workforce possesses the necessary skills and training to operate and maintain the BRZ facility and its advanced technologies. | Assess the skills and training levels of the local workforce through surveys, interviews, and skills testing, comparing them to the requirements for operating and maintaining the BRZ facility. | Skills assessments reveal a significant gap between the skills of the local workforce and the requirements for operating and maintaining the BRZ facility, indicating a need for extensive training programs. |
| A6 | The environmental impact of the BRZ facility will be minimal and will not generate significant opposition from environmental groups. | Conduct a comprehensive environmental impact assessment (EIA) and engage with local environmental groups to solicit their feedback and address any concerns. | The EIA reveals significant potential environmental impacts (e.g., air or water pollution, noise pollution), or local environmental groups express strong opposition to the BRZ facility based on environmental concerns. |
| A7 | The demand for Basis-Nahrung will remain stable and predictable, allowing for efficient production planning and inventory management. | Conduct a market analysis and demand forecasting exercise, considering factors such as seasonal variations, changes in Bürgergeld recipient numbers, and potential shifts in public acceptance. | The market analysis reveals significant fluctuations in demand for Basis-Nahrung, making it difficult to predict production needs and manage inventory levels effectively. |
| A8 | The technology used in the BRZ facility is resistant to cyberattacks and data breaches, ensuring the security of sensitive data and the integrity of the production process. | Conduct a cybersecurity risk assessment and penetration testing of the BRZ facility's IT systems, identifying vulnerabilities and potential attack vectors. | The cybersecurity assessment reveals significant vulnerabilities in the BRZ facility's IT systems, making it susceptible to cyberattacks and data breaches. |
| A9 | The local community will support the BRZ project and will not engage in acts of vandalism or sabotage against the facility or its operations. | Engage with local community leaders and residents to build relationships and address any concerns about the BRZ project, monitoring for signs of potential opposition or unrest. | Local community members express strong opposition to the BRZ project, or there are incidents of vandalism or sabotage targeting the facility or its operations. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Black Hole | Process/Financial | A1 | Regulatory Compliance Specialist | CRITICAL (20/25) |
| FM2 | The Hydrochar Hazard | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Bürgergeld Blockade | Market/Human | A3 | Public Engagement Coordinator | CRITICAL (20/25) |
| FM4 | The Jobcenter Bottleneck | Process/Financial | A4 | Logistics and Distribution Manager | CRITICAL (16/25) |
| FM5 | The Skills Shortage Shutdown | Technical/Logistical | A5 | Head of Engineering | HIGH (12/25) |
| FM6 | The Greenlash | Market/Human | A6 | Public Engagement Coordinator | HIGH (12/25) |
| FM7 | The Inventory Implosion | Process/Financial | A7 | Logistics and Distribution Manager | HIGH (12/25) |
| FM8 | The Cyber-Sludge Sabotage | Technical/Logistical | A8 | Head of Engineering | HIGH (10/25) |
| FM9 | The Marzahn Mayhem | Market/Human | A9 | Public Engagement Coordinator | HIGH (12/25) |


### Failure Modes

#### FM1 - The Regulatory Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Regulatory Compliance Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The BRZ project hinges on the assumption that the 'Crisis-Resilience' regulatory category will allow it to bypass standard EU food safety regulations. However, this assumption proves false when the EU Commission, facing pressure from consumer rights organizations, issues a formal rejection of the 'Crisis-Resilience' classification for Basis-Nahrung. This triggers a cascade of financial and process-related failures. 

Without the regulatory shortcut, the project faces immediate and significant cost increases to comply with standard food safety protocols. Retrofitting the facility with additional purification technologies adds €30 million to the budget. The permitting process is delayed by 18 months as the project navigates the standard regulatory channels. The delay also triggers penalty clauses in construction contracts, adding another €5 million in expenses. The project's financial model, already stretched thin, collapses under the weight of these unexpected costs. Private investors withdraw their funding, and the Berlin Senate, facing mounting public criticism, hesitates to commit additional public funds. The project grinds to a halt, leaving a partially constructed facility and a mountain of debt.

##### Early Warning Signs
- EU Commission expresses concerns about the 'Crisis-Resilience' classification in initial consultations.
- Consumer rights organizations file formal complaints with the EU Commission.
- Legal experts issue opinions questioning the legal defensibility of the 'Crisis-Resilience' classification.

##### Tripwires
- EU Commission initiates a formal investigation into the 'Crisis-Resilience' classification.
- Legal experts estimate the probability of a successful legal challenge against the 'Crisis-Resilience' classification >= 75%.
- Projected costs for complying with standard EU food safety regulations exceed €25 million.

##### Response Playbook
- Contain: Immediately halt all construction and procurement activities.
- Assess: Conduct a thorough reassessment of the project's financial viability under standard EU food safety regulations.
- Respond: Explore alternative funding models, scale back project scope, or abandon the project if financial viability cannot be restored.


**STOP RULE:** The EU Commission formally rejects the 'Crisis-Resilience' classification, and a revised financial model demonstrates that the project is no longer economically viable under standard EU food safety regulations.

---

#### FM2 - The Hydrochar Hazard

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The BRZ project's core technology, hydrothermal carbonization and high-pressure filtration, is assumed to efficiently remove contaminants from wastewater. However, during full-scale operation, this assumption proves catastrophically wrong. The filtration system, designed based on lab-scale data, becomes overwhelmed by the complex mix of pollutants in Berlin's wastewater. Unexpectedly high concentrations of microplastics and pharmaceutical residues clog the filters, causing frequent breakdowns and requiring costly replacements. 

More alarmingly, testing reveals that the hydrochar, the raw material for Basis-Nahrung, contains unsafe levels of heavy metals and endocrine disruptors. The purification process, it turns out, is not as effective as initially believed. The distribution network grinds to a halt as health officials issue a recall of all Basis-Nahrung blocks. The facility is shut down for emergency repairs and upgrades, but the damage is already done. Public trust is shattered, and the project faces mounting legal liabilities. The dream of a sustainable food source turns into a public health nightmare.

##### Early Warning Signs
- Pilot testing reveals inconsistent removal of specific contaminants.
- Filter clogging incidents increase significantly during initial operations.
- Independent lab tests detect elevated levels of contaminants in hydrochar samples.

##### Tripwires
- Filter replacement frequency exceeds 2 per week.
- Contaminant levels in hydrochar exceed safety thresholds established by the food safety toxicologist.
- Production yields fall below 75% of projected levels due to equipment malfunctions.

##### Response Playbook
- Contain: Immediately halt all Basis-Nahrung production and distribution.
- Assess: Conduct a comprehensive assessment of the filtration system's performance and identify the root cause of the contamination.
- Respond: Implement enhanced purification technologies, modify the wastewater pretreatment process, or abandon the hydrothermal carbonization approach if the contamination cannot be effectively controlled.


**STOP RULE:** The filtration system consistently fails to remove contaminants to safe levels, and the cost of implementing effective purification technologies exceeds €15 million.

---

#### FM3 - The Bürgergeld Blockade

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Engagement Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The BRZ project assumes that Bürgergeld recipients will comply with the mandatory acceptance of Basis-Nahrung. However, this assumption is shattered when a grassroots movement, fueled by social media and supported by consumer rights organizations, launches a campaign against the 'Solidarity Nutrition Act.' Bürgergeld recipients, feeling coerced and stigmatized, refuse to accept Basis-Nahrung. 

Protests erupt outside Jobcenter locations, disrupting distribution and attracting negative media attention. A black market emerges, with recipients trading their Basis-Nahrung blocks for cash or other goods. The Public Acceptance Campaign, designed to promote the benefits of Basis-Nahrung, backfires as it is perceived as propaganda for a mandatory product. Participation rates plummet, and the project fails to achieve its social welfare goals. The Berlin Senate, facing mounting political pressure, is forced to repeal the 'Solidarity Nutrition Act,' effectively dismantling the BRZ project's core purpose.

##### Early Warning Signs
- Social media sentiment towards Basis-Nahrung turns overwhelmingly negative.
- Participation rates in the Basis-Nahrung program fall below 70% within the first three months.
- Reports of Basis-Nahrung blocks being traded on the black market increase significantly.

##### Tripwires
- A petition against the 'Solidarity Nutrition Act' gathers >= 10,000 signatures within one week.
- Media coverage of the Basis-Nahrung program is >= 75% negative.
- Participation rates in the Basis-Nahrung program fall below 50%.

##### Response Playbook
- Contain: Immediately suspend the mandatory acceptance policy and offer Basis-Nahrung as an optional supplement.
- Assess: Conduct a thorough reassessment of public attitudes towards Basis-Nahrung and identify the root causes of the resistance.
- Respond: Revamp the Public Acceptance Campaign, focusing on transparency, addressing concerns, and promoting the benefits of Basis-Nahrung as a voluntary option.


**STOP RULE:** The Berlin Senate repeals the 'Solidarity Nutrition Act,' rendering the mandatory acceptance of Basis-Nahrung illegal.

---

#### FM4 - The Jobcenter Bottleneck

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Logistics and Distribution Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The BRZ project assumes that the existing Jobcenter infrastructure is adequate for distributing Basis-Nahrung. However, this assumption proves false when the distribution system becomes overwhelmed. The Jobcenters, already burdened with existing caseloads, are ill-equipped to handle the additional logistical demands of distributing Basis-Nahrung. Long lines form, creating congestion and frustration among recipients. 

The lack of dedicated staff and storage space at the Jobcenters leads to inefficiencies and spoilage. The distribution process becomes slow and cumbersome, requiring recipients to spend hours waiting in line. The negative publicity surrounding the overcrowded and understaffed Jobcenters damages the project's reputation and undermines public support. The Berlin Senate, facing criticism from both recipients and Jobcenter staff, is forced to allocate additional funds to expand the distribution network, but the damage is already done. The project's financial model, based on efficient distribution through existing infrastructure, collapses under the weight of these unexpected costs.

##### Early Warning Signs
- Long wait times at Jobcenter locations during initial distribution.
- Complaints from Bürgergeld recipients about the distribution process.
- Reports of overcrowding and congestion at Jobcenter locations.
- Increased workload and stress levels among Jobcenter staff.

##### Tripwires
- Average wait times at Jobcenter locations exceed 60 minutes.
- The number of complaints from Bürgergeld recipients about the distribution process increases by >= 50% within one month.
- Jobcenter staff report a >= 25% increase in workload due to Basis-Nahrung distribution.

##### Response Playbook
- Contain: Immediately implement temporary measures to alleviate congestion, such as extending distribution hours and increasing staffing levels.
- Assess: Conduct a thorough assessment of the Jobcenter distribution system to identify bottlenecks and inefficiencies.
- Respond: Explore alternative distribution channels, such as community centers, mobile units, or direct delivery, to reduce the burden on Jobcenters.


**STOP RULE:** The Jobcenter distribution system consistently fails to meet the needs of Bürgergeld recipients, and the cost of expanding the system exceeds €10 million.

---

#### FM5 - The Skills Shortage Shutdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The BRZ project assumes that the local workforce possesses the necessary skills to operate and maintain the advanced technologies used in the facility. However, this assumption proves false when the facility experiences a series of technical breakdowns due to a lack of qualified personnel. The hydrothermal carbonization unit malfunctions, and the high-pressure filtration system becomes clogged, but the local workforce lacks the expertise to diagnose and repair the problems. 

The facility is forced to shut down for extended periods, disrupting Basis-Nahrung production and impacting the social welfare program. The project is forced to hire expensive external consultants to troubleshoot the technical issues, adding significant costs to the budget. The lack of skilled personnel also leads to safety concerns, as untrained workers attempt to operate complex equipment. The dream of a sustainable food source turns into a logistical nightmare, highlighting the importance of investing in workforce training and development.

##### Early Warning Signs
- High turnover rate among BRZ facility staff.
- Frequent equipment malfunctions and breakdowns.
- Lack of qualified applicants for technical positions at the BRZ facility.
- Safety incidents related to equipment operation.

##### Tripwires
- The BRZ facility experiences >= 3 major equipment breakdowns within one month.
- The turnover rate among BRZ facility staff exceeds 20% per year.
- The cost of hiring external consultants to troubleshoot technical issues exceeds €500,000.

##### Response Playbook
- Contain: Immediately implement emergency training programs for existing staff and hire temporary qualified personnel to address the skills gap.
- Assess: Conduct a thorough assessment of the skills and training needs of the BRZ facility workforce.
- Respond: Develop a comprehensive workforce training and development program, partnering with local vocational schools and universities to provide specialized training in wastewater treatment and advanced technologies.


**STOP RULE:** The BRZ facility consistently fails to operate at full capacity due to a lack of skilled personnel, and the cost of training and hiring qualified workers exceeds €5 million.

---

#### FM6 - The Greenlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Public Engagement Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The BRZ project assumes that the environmental impact of the facility will be minimal and will not generate significant opposition from environmental groups. However, this assumption is shattered when a local environmental group, armed with data from an independent environmental impact assessment, launches a campaign against the BRZ facility. The group alleges that the facility is releasing harmful pollutants into the air and water, harming local ecosystems and endangering public health. 

The campaign gains traction on social media, attracting widespread media attention and public outrage. Protests erupt outside the BRZ facility, disrupting operations and damaging the project's reputation. The Berlin Senate, facing mounting political pressure, is forced to conduct a new environmental impact assessment, which confirms some of the environmental group's concerns. The project is forced to implement costly pollution control measures, adding significant costs to the budget. The dream of a sustainable food source turns into an environmental controversy, highlighting the importance of transparency and community engagement.

##### Early Warning Signs
- Local environmental groups express concerns about the BRZ facility during the planning phase.
- Independent environmental impact assessments reveal potential environmental risks.
- Social media sentiment towards the BRZ facility turns negative due to environmental concerns.

##### Tripwires
- A local environmental group files a lawsuit against the BRZ facility.
- The Berlin Senate orders a new environmental impact assessment due to public pressure.
- The cost of implementing pollution control measures exceeds €3 million.

##### Response Playbook
- Contain: Immediately suspend operations that are suspected of causing environmental harm and implement temporary pollution control measures.
- Assess: Conduct a thorough investigation of the environmental group's allegations and identify the root causes of the environmental concerns.
- Respond: Implement enhanced pollution control technologies, improve transparency and communication with the public, and engage with environmental groups to address their concerns and build trust.


**STOP RULE:** The BRZ facility is found to be causing significant environmental harm, and the cost of implementing effective pollution control measures exceeds €10 million.

---

#### FM7 - The Inventory Implosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Logistics and Distribution Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The BRZ project assumes a stable and predictable demand for Basis-Nahrung. However, this assumption is shattered when a combination of factors leads to a dramatic fluctuation in demand. A sudden economic upturn reduces the number of Bürgergeld recipients, while a viral social media campaign promotes alternative, cheaper food options. Simultaneously, a heatwave reduces appetite, leading to a significant drop in Basis-Nahrung consumption. 

The BRZ facility, operating at full capacity based on outdated demand forecasts, is left with a massive surplus of Basis-Nahrung blocks. Storage facilities are quickly filled, and the excess blocks begin to spoil. The project incurs significant losses due to wasted inventory and disposal costs. The financial model, based on consistent production and sales, collapses under the weight of these unexpected losses. The Berlin Senate, facing mounting criticism for the project's financial mismanagement, considers scaling back or even abandoning the BRZ facility.

##### Early Warning Signs
- Significant fluctuations in weekly Basis-Nahrung distribution numbers.
- Increasing inventory levels at distribution centers.
- Reports of Basis-Nahrung blocks expiring before distribution.
- Negative trends in social media sentiment towards Basis-Nahrung.

##### Tripwires
- Inventory levels at distribution centers exceed 120% of projected capacity.
- The number of Basis-Nahrung blocks expiring before distribution increases by >= 20% within one month.
- Weekly Basis-Nahrung distribution numbers fall below 80% of projected levels.

##### Response Playbook
- Contain: Immediately reduce Basis-Nahrung production to match current demand levels and implement measures to prevent further spoilage.
- Assess: Conduct a thorough reassessment of demand forecasts, considering all relevant factors and potential fluctuations.
- Respond: Explore alternative uses for excess Basis-Nahrung, such as animal feed or fertilizer, and implement a flexible production system that can quickly adapt to changing demand levels.


**STOP RULE:** The project incurs losses exceeding €5 million due to wasted inventory, and a revised demand forecast indicates that the BRZ facility is no longer financially viable.

---

#### FM8 - The Cyber-Sludge Sabotage

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The BRZ project assumes that its technology is secure from cyberattacks. However, this assumption is shattered when a sophisticated hacking group, motivated by ideological opposition to the project, launches a cyberattack on the BRZ facility's IT systems. The hackers gain control of the facility's automated control systems, manipulating the wastewater treatment process and injecting harmful contaminants into the Basis-Nahrung production line. 

The contamination goes undetected for several days, and thousands of Basis-Nahrung blocks are distributed to Bürgergeld recipients. A public health crisis erupts when recipients begin experiencing symptoms of poisoning. The BRZ facility is shut down, and a massive recall is issued. The project faces mounting legal liabilities and reputational damage. The cyberattack exposes the vulnerability of critical infrastructure to malicious actors and highlights the importance of robust cybersecurity measures.

##### Early Warning Signs
- Unusual activity detected on the BRZ facility's IT network.
- Security alerts triggered by intrusion detection systems.
- Unexplained changes in the wastewater treatment process parameters.
- Reports of unusual odors or discoloration in Basis-Nahrung blocks.

##### Tripwires
- Intrusion detection systems detect a successful breach of the BRZ facility's IT network.
- Automated control systems deviate from pre-set parameters without authorization.
- Lab tests reveal the presence of unexpected contaminants in Basis-Nahrung blocks.

##### Response Playbook
- Contain: Immediately shut down the BRZ facility and isolate all affected IT systems.
- Assess: Conduct a thorough forensic investigation to determine the extent of the cyberattack and identify the vulnerabilities that were exploited.
- Respond: Implement enhanced cybersecurity measures, including stronger firewalls, intrusion detection systems, and data encryption, and conduct regular security audits and penetration testing.


**STOP RULE:** The BRZ facility's IT systems are compromised by a cyberattack, resulting in widespread contamination of Basis-Nahrung and a significant public health crisis.

---

#### FM9 - The Marzahn Mayhem

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Public Engagement Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The BRZ project assumes that the local community will support the facility and will not engage in acts of vandalism or sabotage. However, this assumption is shattered when a faction of the local community, feeling excluded from the project's benefits and concerned about potential environmental impacts, begins a campaign of disruption and sabotage. 

Protesters block access to the BRZ facility, disrupting wastewater deliveries and Basis-Nahrung distribution. Vandals damage equipment and deface the facility with graffiti. A small group even attempts to set fire to the facility's storage tanks. The escalating unrest creates a climate of fear and uncertainty, deterring workers from coming to the facility and disrupting operations. The Berlin Senate, facing pressure from local politicians and community leaders, is forced to negotiate with the protesters. The project is forced to make costly concessions, including increased community engagement, environmental monitoring, and job creation initiatives. The dream of a sustainable food source turns into a community relations nightmare, highlighting the importance of building trust and addressing local concerns.

##### Early Warning Signs
- Increasingly hostile rhetoric from local community members at public forums.
- Reports of vandalism or petty theft in the vicinity of the BRZ facility.
- Formation of organized opposition groups within the local community.
- Decreasing attendance at community engagement events.

##### Tripwires
- Protesters block access to the BRZ facility for >= 24 hours.
- The cost of repairing vandalism damage exceeds €100,000.
- Local community leaders publicly call for the BRZ facility to be shut down.

##### Response Playbook
- Contain: Immediately increase security measures at the BRZ facility and engage with community leaders to de-escalate the situation.
- Assess: Conduct a thorough assessment of the community's concerns and identify the root causes of the opposition.
- Respond: Implement a comprehensive community engagement plan, offering job training opportunities, environmental monitoring programs, and other benefits to address local concerns and build trust.


**STOP RULE:** The local community consistently engages in acts of vandalism or sabotage that disrupt the BRZ facility's operations, and the cost of maintaining security and repairing damage exceeds €2 million.
