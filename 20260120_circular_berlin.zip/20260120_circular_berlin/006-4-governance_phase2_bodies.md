### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides strategic oversight and guidance due to the project's high complexity, significant budget (€210 million), and potential impact on Berlin's social welfare system and EU circular economy targets.  It is needed to ensure alignment with strategic goals and manage high-level risks.

**Responsibilities:**

- Provide strategic direction and oversight for the BRZ project.
- Approve major project milestones and deliverables.
- Approve budget revisions exceeding €5 million.
- Oversee strategic risk management and mitigation.
- Resolve conflicts escalated from lower-level governance bodies.
- Ensure alignment with Berlin Senate's strategic objectives and EU regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference (TOR) and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol.
- Define escalation paths and conflict resolution mechanisms.
- Approve the initial project plan and budget.

**Membership:**

- Representative from the Berlin Senate (Chair)
- Representative from the EU Commission
- Representative from the Berlin Senate Department for Environment, Transport and Climate Protection
- Representative from the Berlin Senate Department for Social Affairs
- Independent Expert in Circular Economy
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (above €5 million), timeline, and key risks. Approval of major changes to the project plan or strategic direction.

**Decision Mechanism:** Decisions are made by majority vote. In case of a tie, the Chairperson (Berlin Senate Representative) has the deciding vote.  EU Commission representative has veto power on decisions impacting EU regulatory compliance.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance and budget status.
- Discussion and approval of proposed changes to project scope or timeline.
- Review of strategic risks and mitigation plans.
- Updates on regulatory compliance and stakeholder engagement.
- Escalated issues from the Project Management Office or other governance bodies.

**Escalation Path:** Escalate unresolved issues to the Governing Mayor of Berlin.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Essential for managing the day-to-day execution of the BRZ project, ensuring adherence to the project plan, and managing operational risks.  It provides a central point of coordination and control for project activities.

**Responsibilities:**

- Develop and maintain the project plan, including schedule, budget, and resource allocation.
- Monitor project progress and identify potential risks and issues.
- Manage project resources and ensure efficient utilization.
- Coordinate communication and collaboration among project team members.
- Track and report on project performance against key metrics.
- Manage operational risk and compliance below strategic thresholds.
- Implement and enforce project management standards and procedures.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Define roles and responsibilities for project team members.
- Develop a communication plan.
- Set up a project tracking system.
- Establish risk management procedures.

**Membership:**

- Project Director (Head of PMO)
- Project Manager
- Technical Lead
- Financial Controller
- Communications Manager
- Risk Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management within pre-defined budget and scope. Approval of budget expenditures up to €500,000.

**Decision Mechanism:** Decisions are made by the Project Director, in consultation with the relevant team members.  In case of disagreement, the Project Director has the final decision, but must document the dissenting opinions.

**Meeting Cadence:** Weekly, with daily stand-up meetings for the core project team.

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current risks and issues.
- Approval of budget expenditures.
- Coordination of project activities.
- Updates on stakeholder engagement.
- Review of compliance status.

**Escalation Path:** Escalate issues exceeding the PMO's authority or strategic risks to the Project Steering Committee.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on the hydrothermal carbonization, high-pressure filtration, and wastewater processing aspects of the BRZ project.  Ensures the technology is feasible, safe, and meets performance requirements.

**Responsibilities:**

- Provide technical guidance and expertise on wastewater processing technologies.
- Review and approve technical designs and specifications.
- Assess the performance and reliability of the hydrothermal carbonization and high-pressure filtration equipment.
- Identify and mitigate technical risks.
- Ensure compliance with environmental regulations.
- Advise on technological refinement strategies.

**Initial Setup Actions:**

- Define the scope of technical expertise required.
- Identify and recruit qualified technical experts.
- Establish a communication protocol.
- Define the process for reviewing and approving technical designs.
- Develop a risk assessment framework for technical risks.

**Membership:**

- Professor of Environmental Engineering (Independent)
- Expert in Hydrothermal Carbonization
- Expert in High-Pressure Filtration
- Wastewater Treatment Plant Operator
- BRZ Technical Lead
- Representative from the Berlin Senate Department for Environment, Transport and Climate Protection

**Decision Rights:** Technical approval of designs, specifications, and equipment selection.  Authority to recommend changes to the technology based on performance or risk assessments.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the independent Professor of Environmental Engineering has the deciding vote.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Assessment of equipment performance and reliability.
- Discussion of technical risks and mitigation plans.
- Updates on environmental regulations.
- Review of technological refinement strategies.
- Analysis of wastewater quality and nutrient content.

**Escalation Path:** Escalate unresolved technical issues or concerns about environmental compliance to the Project Steering Committee.
### 4. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations, including GDPR, food safety laws, and ethical standards related to the restructuring of the Bürgergeld system.  Addresses potential conflicts of interest and ensures transparency.

**Responsibilities:**

- Oversee compliance with all relevant laws and regulations, including GDPR, food safety laws, and environmental regulations.
- Develop and enforce a code of ethics for the BRZ project.
- Review and approve policies and procedures related to data privacy, conflict of interest, and whistleblower protection.
- Investigate allegations of ethical misconduct or regulatory violations.
- Provide training and education on ethical conduct and compliance.
- Ensure transparency in project operations and decision-making.

**Initial Setup Actions:**

- Develop a code of ethics.
- Establish compliance policies and procedures.
- Set up a whistleblower mechanism.
- Define the process for investigating ethical misconduct.
- Develop a training program on ethical conduct and compliance.

**Membership:**

- Legal Counsel (Independent)
- Ethics Officer (Independent)
- Compliance Officer (PMO)
- Representative from the Berlin Senate Department for Social Affairs
- Representative from a Consumer Rights Organization
- Data Protection Officer

**Decision Rights:** Authority to investigate ethical misconduct and recommend disciplinary action.  Authority to halt project activities that violate ethical standards or regulatory requirements.  Approval of all compliance-related policies and procedures.

**Decision Mechanism:** Decisions are made by majority vote. The independent Legal Counsel serves as tie-breaker.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for urgent compliance issues.

**Typical Agenda Items:**

- Review of compliance status.
- Discussion of potential ethical issues.
- Investigation of alleged misconduct.
- Approval of compliance-related policies and procedures.
- Updates on regulatory changes.
- Review of data privacy practices.

**Escalation Path:** Escalate unresolved ethical or compliance issues to the Governing Mayor of Berlin and relevant regulatory agencies.
### 5. Stakeholder Engagement Group (SEG)

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including Bürgergeld recipients, Berlin residents, and consumer rights organizations.  Addresses concerns, gathers feedback, and promotes public acceptance of the BRZ project.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct public opinion research and monitor public sentiment.
- Organize public forums, community meetings, and cooking demonstrations.
- Address stakeholder concerns and provide timely responses to inquiries.
- Gather feedback on Basis-Nahrung and the distribution network.
- Promote public acceptance of the BRZ project.
- Manage communication with media and the public.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication plan.
- Establish a feedback mechanism.
- Set up a stakeholder database.
- Define the process for responding to stakeholder inquiries.

**Membership:**

- Communications Manager (PMO)
- Public Relations Officer
- Representative from the Berlin Senate Department for Social Affairs
- Representative from a Bürgergeld Recipient Advocacy Group
- Representative from a Consumer Rights Organization
- Community Liaison Officer

**Decision Rights:** Authority to approve communication materials and engagement strategies.  Authority to recommend changes to the project based on stakeholder feedback.

**Decision Mechanism:** Decisions are made by consensus. If consensus cannot be reached, the Communications Manager has the deciding vote, in consultation with the Representative from the Berlin Senate Department for Social Affairs.

**Meeting Cadence:** Bi-weekly, with ad-hoc meetings as needed for urgent stakeholder issues.

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of communication strategies.
- Planning of public engagement events.
- Updates on public opinion research.
- Review of media coverage.
- Addressing stakeholder concerns.

**Escalation Path:** Escalate unresolved stakeholder issues or concerns about public acceptance to the Project Steering Committee.