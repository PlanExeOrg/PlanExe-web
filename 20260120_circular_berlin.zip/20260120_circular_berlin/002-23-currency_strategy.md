This plan involves money.

## Currencies

- **EUR:** The project is based in Berlin, Germany, and the budget is specified in Euros.

**Primary currency:** EUR

**Currency strategy:** The Euro will be used for all transactions. No additional international risk management is needed.