## Suggestion 1 - The NEWT Center (Nanotechnology Enabled Water Treatment)

The NEWT Center, a multi-institutional engineering research center funded by the National Science Foundation, focuses on developing compact, off-grid water treatment systems using nanotechnology. The project aims to provide clean and safe water in diverse settings, including disaster relief and remote communities. The center involves collaboration between Rice University, Arizona State University, Yale University, and the University of Texas at El Paso.

### Success Metrics

Development of novel nanomaterials for water purification.
Creation of prototype water treatment systems.
Peer-reviewed publications and patents.
Industry partnerships and technology transfer.
Training of students and researchers in nanotechnology and water treatment.

### Risks and Challenges Faced

Scaling up nanomaterial production to industrial levels: Overcome by optimizing synthesis methods and reactor designs.
Ensuring the long-term stability and safety of nanomaterials in water treatment systems: Addressed through rigorous testing and material characterization.
Integrating nanotechnology solutions into existing water treatment infrastructure: Mitigated by designing modular and adaptable systems.
Securing funding and maintaining collaboration among multiple institutions: Managed through strong leadership and clear communication protocols.

### Where to Find More Information

Official Website: [https://www.newtcenter.org/](https://www.newtcenter.org/)
NSF Award Abstract: [https://www.nsf.gov/awardsearch/showAward?AWD_ID=1160504](https://www.nsf.gov/awardsearch/showAward?AWD_ID=1160504)
Relevant Publications: Search for "NEWT Center water treatment" on Google Scholar.

### Actionable Steps

Contact NEWT Center's administrative staff via the website's contact form to inquire about specific research findings or collaboration opportunities.
Reach out to the principal investigators at Rice University, Arizona State University, Yale University, or the University of Texas at El Paso via their university email addresses, typically found on their respective faculty pages.
Engage with industry partners listed on the NEWT Center website to understand the commercialization aspects of their technologies.

### Rationale for Suggestion

The NEWT Center is relevant due to its focus on advanced water treatment technologies, particularly nanotechnology, which aligns with the BRZ project's use of hydrothermal carbonization and high-pressure filtration. While geographically distant, the technological challenges and solutions explored by NEWT are directly applicable. The emphasis on creating compact, efficient systems is also relevant given the urban context of Berlin. The BRZ project can learn from NEWT's approach to scaling up novel technologies and ensuring their safety and stability.
## Suggestion 2 - The Omni Processor (by Janicki Bioenergy)

The Omni Processor, developed by Janicki Bioenergy and supported by the Bill & Melinda Gates Foundation, is a self-sustaining system that converts sewage sludge into clean water, electricity, and sterile ash. The project aims to provide a sustainable sanitation solution for developing countries, addressing both waste management and energy needs. Pilot projects have been implemented in Dakar, Senegal, and other locations.

### Success Metrics

Successful conversion of sewage sludge into clean water and electricity.
Reduction in waste volume and environmental pollution.
Self-sustaining operation with minimal external energy input.
Positive impact on public health and sanitation in target communities.
Scalability and affordability for widespread adoption.

### Risks and Challenges Faced

Achieving consistent and reliable operation in diverse environmental conditions: Addressed through robust engineering design and remote monitoring systems.
Ensuring the safety and purity of the produced water and electricity: Mitigated by implementing rigorous quality control measures and testing protocols.
Gaining community acceptance and overcoming cultural barriers to using recycled water: Addressed through public education campaigns and community engagement initiatives.
Securing funding and managing logistics in remote and challenging locations: Managed through strong partnerships with local organizations and international aid agencies.

### Where to Find More Information

Official Website (Janicki Bioenergy): [https://janickibioenergy.com/](https://janickibioenergy.com/)
Bill & Melinda Gates Foundation: Search for "Omni Processor" on the Gates Foundation website.
Relevant Articles: Search for "Janicki Omni Processor" on reputable news and engineering websites.

### Actionable Steps

Contact Janicki Bioenergy directly through their website to inquire about the technical specifications and operational data of the Omni Processor.
Reach out to the Bill & Melinda Gates Foundation's water, sanitation, and hygiene (WASH) team to understand their perspective on the project's impact and scalability.
Connect with organizations that have implemented or studied the Omni Processor in developing countries to learn about their experiences and lessons learned.

### Rationale for Suggestion

The Omni Processor is highly relevant due to its direct focus on converting sewage sludge into usable resources, including water and energy. This aligns with the BRZ project's objective of extracting value from wastewater. Although the Omni Processor targets developing countries, the technological principles and operational challenges are similar. The BRZ project can learn from the Omni Processor's approach to self-sustainability, waste reduction, and community engagement. The challenges faced in gaining public acceptance of recycled water are particularly relevant to the BRZ project's concerns about public acceptance of Basis-Nahrung.
## Suggestion 3 - ReFood GmbH

ReFood GmbH, a German company, specializes in collecting and processing food waste from commercial and industrial sources to produce animal feed and biogas. The company operates several processing plants across Germany, utilizing advanced technologies to ensure the safe and efficient conversion of food waste into valuable products. This contributes to reducing landfill waste and promoting a circular economy.

### Success Metrics

Volume of food waste processed annually.
Production volume of animal feed and biogas.
Reduction in greenhouse gas emissions compared to landfill disposal.
Compliance with German and EU environmental regulations.
Economic viability and profitability of the operations.

### Risks and Challenges Faced

Ensuring the quality and safety of animal feed produced from food waste: Addressed through strict quality control measures and adherence to animal feed regulations.
Managing the variability in composition and contamination levels of food waste: Mitigated by implementing advanced sorting and pre-processing technologies.
Optimizing the biogas production process for maximum energy yield: Achieved through continuous monitoring and adjustment of process parameters.
Maintaining a reliable supply chain for food waste collection: Managed through long-term contracts with suppliers and efficient logistics planning.

### Where to Find More Information

Official Website: [https://www.refood.de/](https://www.refood.de/) (German language)
Industry Reports: Search for "ReFood GmbH" in German environmental and waste management reports.
Press Releases: Check ReFood's website for press releases and news articles.

### Actionable Steps

Contact ReFood GmbH directly through their website to inquire about their processing technologies and operational practices.
Reach out to German environmental agencies or waste management associations to obtain information about ReFood's regulatory compliance and environmental impact.
Connect with companies that supply food waste to ReFood to understand their perspective on the logistics and economic aspects of the partnership.

### Rationale for Suggestion

ReFood GmbH is relevant due to its focus on processing organic waste into usable products, specifically animal feed and biogas. While the BRZ project focuses on wastewater, the underlying principles of resource recovery and waste reduction are similar. ReFood's experience in managing the variability and contamination of organic waste is particularly relevant to the BRZ project's concerns about the composition of wastewater. The BRZ project can learn from ReFood's approach to quality control, regulatory compliance, and supply chain management within the German context. The geographical proximity makes this example particularly valuable.

## Summary

The user's project involves establishing a wastewater treatment facility in Berlin to produce nutrient blocks for social welfare recipients, aiming to reduce municipal debt and meet EU circular economy targets. Given the project's focus on wastewater treatment, food production from unconventional sources, and social welfare integration, the following projects are recommended as relevant references.