### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft PSC ToR v0.1 for review by nominated members (representatives from Berlin Senate, EU Commission, etc.).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PSC ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes PSC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor (Berlin Senate) formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PSC ToR v1.0

### 5. Project Manager formally notifies all nominated members of their appointment to the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email

### 6. Project Manager schedules initial Project Steering Committee (PSC) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 7. Hold initial Project Steering Committee (PSC) kick-off meeting to review ToR, project goals, and initial priorities.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 8. Project Director drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 9. Circulate Draft PMO ToR v0.1 for review by the Project Manager, Technical Lead, Financial Controller, Communications Manager, Risk Manager, and Compliance Officer.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Project Team Members Identified

### 10. Project Director finalizes PMO ToR based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 11. Project Director formally appoints members to the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final PMO ToR v1.0

### 12. Project Director schedules initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 13. Hold initial Project Management Office (PMO) kick-off meeting to review ToR, project goals, and assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 14. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 15. Circulate Draft TAG ToR v0.1 for review by potential members (Professor of Environmental Engineering, Experts in Hydrothermal Carbonization/High-Pressure Filtration, etc.).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Potential Members Identified

### 16. Project Manager finalizes TAG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 17. Project Director formally appoints members to the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0

### 18. Project Manager schedules initial Technical Advisory Group (TAG) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 19. Hold initial Technical Advisory Group (TAG) kick-off meeting to review ToR, project goals, and technical aspects.

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 21. Circulate Draft ECC ToR v0.1 for review by potential members (Legal Counsel, Ethics Officer, Compliance Officer, etc.).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1
- Potential Members Identified

### 22. Project Manager finalizes ECC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 23. Project Director formally appoints members to the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final ECC ToR v1.0

### 24. Project Manager schedules initial Ethics & Compliance Committee (ECC) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 25. Hold initial Ethics & Compliance Committee (ECC) kick-off meeting to review ToR, project goals, and ethical considerations.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 26. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 27. Circulate Draft SEG ToR v0.1 for review by potential members (Communications Manager, Public Relations Officer, etc.).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1
- Potential Members Identified

### 28. Project Manager finalizes SEG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 29. Project Director formally appoints members to the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SEG ToR v1.0

### 30. Project Manager schedules initial Stakeholder Engagement Group (SEG) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 31. Hold initial Stakeholder Engagement Group (SEG) kick-off meeting to review ToR, project goals, and stakeholder engagement strategies.

**Responsible Body/Role:** Stakeholder Engagement Group (SEG)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda