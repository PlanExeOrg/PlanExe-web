**Budget Request Exceeding PMO Authority (€500,000 Limit)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review due to potential impact on overall project budget and scope.
Negative Consequences: Potential budget overrun, project delays, or scope reduction if not addressed strategically.

**Critical Risk Materialization (e.g., Regulatory Rejection)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk (e.g., rejection of 'Crisis-Resilience' classification) threatens project viability and requires strategic decision-making and resource allocation beyond the PMO's authority.
Negative Consequences: Project failure, legal penalties, significant financial losses, and reputational damage if not addressed promptly and effectively.

**PMO Deadlock on Vendor Selection (Equal Votes)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of Options and Vote
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates escalation to ensure timely progress and prevent project delays. The PSC provides a higher-level perspective and decision-making authority.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor if the deadlock is not resolved.

**Proposed Major Scope Change (e.g., Adding New Waste Streams)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval Based on Strategic Alignment and Feasibility
Rationale: Significant changes to the project scope (e.g., incorporating new waste streams) impact the project's strategic objectives, budget, timeline, and resource requirements, necessitating review and approval by the Steering Committee.
Negative Consequences: Project misalignment with strategic goals, budget overruns, schedule delays, and increased complexity if not properly evaluated and managed.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Allegations of ethical misconduct or conflicts of interest require independent investigation and resolution to maintain project integrity, transparency, and compliance with ethical standards.
Negative Consequences: Reputational damage, legal penalties, loss of public trust, and project failure if ethical concerns are not addressed promptly and effectively.

**Unresolved Technical Issues Impacting Environmental Compliance**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Remediation Plan
Rationale: Technical issues that could lead to environmental non-compliance require immediate attention and strategic decisions to avoid fines, legal challenges, and reputational damage.
Negative Consequences: Fines, legal challenges, reputational damage, and project delays if environmental compliance is compromised.

**Stakeholder Backlash Against Mandatory Basis-Nahrung**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Stakeholder Engagement Strategy
Rationale: Significant public resistance to the mandatory nature of Basis-Nahrung acceptance requires strategic intervention to mitigate negative impacts on project success and public perception.
Negative Consequences: Project delays, increased costs, political pressure, and potential project failure if stakeholder concerns are not addressed effectively.

**Ethical or Compliance Violations**
Escalation Level: Governing Mayor of Berlin
Approval Process: Review by the Mayor's Office and potential referral to external regulatory agencies.
Rationale: Serious breaches of ethics or compliance require the highest level of oversight to ensure accountability and protect the city's interests.
Negative Consequences: Legal penalties, reputational damage, loss of public trust, and potential criminal charges.