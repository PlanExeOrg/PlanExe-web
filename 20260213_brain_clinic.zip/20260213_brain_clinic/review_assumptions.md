## Domain of the expert reviewer
Frontier Technology Project Management & Regulatory Strategy

## Domain-specific considerations

- Quantum Computing integration risk
- Novel bioethics and digital personhood compliance
- High-stakes political and societal acceptance
- Long-term viability of digital substrate stability

## Issue 1 - Missing Assumption: Viability of Quantum Computing Timeline for High-Fidelity Mapping
The plan's primary technical lever (Mapping Fidelity) is critically dependent on achieving sub-synaptic resolution, explicitly requiring 'unpredictable quantum computing breakthroughs' by the 2030 deadline. The current assumptions gloss over this timeline risk by simply allocating budget (60% R&D) and planning for declarative memory by Year 2. There is no explicit assumption regarding the *maturity date* or *availability* of the necessary fault-tolerant quantum hardware required for the *full* high-fidelity target. This dependency represents the single greatest existential threat.

**Recommendation:** Immediately establish an assumption defining the Minimum Acceptable Quantum Milestone (MAQM) required for the full fidelity target (Decision 1). If MAQM is not achieved by Q4 Year 2, trigger a mandatory, documented pivot to a proven, lower-fidelity, non-quantum substrate (e.g., neuromorphic ASIC cluster) with a revised ROI model, accepting a potential 15-20% reduction in perceived quality to maintain the timeline.

**Sensitivity:** Failure to achieve the MAQM by the baseline Year 2 assessment (assuming a 2-year delay in QC breakthrough) could lead to a 1.5x increase in R&D burn rate (€450M total R&D instead of €300M baseline) or, more critically, a 75% reduction in projected ROI due to a 3-year minimum launch delay past 2030, as competitors may stabilize the market in the interim.

## Issue 2 - Missing Assumption: Legal Status and Liability Shielding for Digital Beings
The plan commits to defining Consent Architecture (Decision 5) and submitting preliminary guidance on 'Digital Personhood,' but critically lacks an assumption regarding the *host country's* legal acceptance of this status. Germany/EU law is currently unequipped to handle a novel entity with legal agency derived from biological data. Without an assumed legal framework or a highly conservative assumption about legal status (i.e., 'Digital Copy = Property for 10 years'), the project faces absolute litigation risk, nullifying the liability shield.

**Recommendation:** Introduce a crucial assumption: 'The German/EU legal system will classify nascent digital consciousnesses as revocable, non-sentient cognitive property assets for the first 7 years post-transfer, offering a default liability shield provided annual psychological confirmation is documented.' If the counter-assumption holds (Legal status granted as 'Digital Person' early on), immediately allocate an additional 10% of the regulatory budget (€5M-€10M) to establish dedicated legal defense teams within the EU/German courts for immediate contestation.

**Sensitivity:** If full 'Digital Personhood' status is granted prematurely (baseline being property status), the project faces potential litigation liabilities estimated at 15-30% of the €500M capital, equivalent to €75M to €150M in potential settlement or defense costs, significantly hindering the Societal Access framework (Decision 3).

## Issue 3 - Under-Explored Assumption: Sustainability Cost Integration into Infrastructure Budget
The assumption states 100% renewable energy sourcing will be committed to. However, in Germany, securing high-capacity renewable Purchase Power Agreements (PPAs) for data centers/quantum loads is extremely capital intensive and time-consuming, unlike standard small office utility costs. This commitment is implicitly absorbed by the general 40% infrastructure budget, but this is often an insufficient estimation for massive, dedicated energy sourcing required by quantum systems.

**Recommendation:** Create a specific assumption: 'A dedicated €40M - €60M contingency fund, secured from the R&D budget (taking risk from the 60% R&D allocation), must be ring-fenced by Year 2 solely for negotiating high-volume, certified PPA costs or investing in specialized local renewable generation capacity to meet the 100% green energy mandate.'

**Sensitivity:** If the cost of securing 100% renewable energy for the required compute cluster (estimated to pull 5-10 MW initially) forces an under-commitment (e.g., only 60% renewable initially), regulatory pushback in Berlin could delay facility permitting (Risk 2) by 4-8 months, incurring €5M–€15M in operational delay costs. Conversely, securing PPAs at an aggressive fixed rate provides a 5-10% hedge against future EU energy price volatility, improving long-term operational ROI.

## Review conclusion
The project's success pivots on navigating three critical, missing assumptions related to technology maturity, legal reality, and infrastructure cost realism. The absolute highest priority must be resolving the **Quantum Viability Assumption**, as failure here invalidates the core technical promise. Secondarily, the **Legal Status Assumption** for digital entities must be conservatively defined to prevent existential legal attacks. Finally, the **Sustainability Cost Assumption** must be explicitly funded; treating high-energy, 100% renewable sourcing as a standard operational cost under the existing budget structure is highly unrealistic for a Berlin-based advanced compute facility and risks derailing infrastructure timelines.