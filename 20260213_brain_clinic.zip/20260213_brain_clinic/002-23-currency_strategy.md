This plan involves money.

## Currencies

- **EUR:** The project is based in Berlin, Germany.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for all transactions. No additional international risk management is needed.