Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project aims to achieve near-immortality through digital brain capture and AI replacement, which, while ambitious, does not inherently violate any known physical laws.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (digital immortality), market (global), tech/process (brain capture, AI replacement), and policy (EU AI regulations) without independent evidence at comparable scale. There is no precedent for this combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Project Lead: Produce validation report / 2029-12-31.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanisms-of-action, owners, and measurable outcomes for key strategic concepts like "digital immortality" and "consciousness capture". The plan mentions these concepts but doesn't define them operationally.

**Mitigation**: Project Lead: Create one-pagers for "digital immortality" and "consciousness capture" defining value hypotheses, success metrics, and decision hooks. Due: 2024-09-30.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (patient harm) is minimized. The plan mentions safety protocols but lacks explicit analysis of cascade effects (e.g., mapping error → AI malfunction → patient harm).

**Mitigation**: Risk Management Officer: Expand the risk register to include detailed cascade analysis for patient safety hazards, including controls and a dated review cadence. Due: 2024-12-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions permits and licenses but does not include a matrix detailing required approvals, lead times, and dependencies. "Secure necessary permits and licenses."

**Mitigation**: Regulatory Affairs Specialist: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds. Due: 2024-12-31.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a budget of €500M but does not specify the sources of funding, their status (e.g., LOI, term sheet, closed), the draw schedule, or the runway length.

**Mitigation**: Project Lead: Develop a dated financing plan listing funding sources, status, draw schedule, covenants, and NO-GO triggers for missed financing gates. Due: 2024-09-30.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €500M lacks scale-appropriate benchmarks or vendor quotes normalized by area. The plan mentions infrastructure costs but does not provide per-area cost breakdowns or contingency for fit-out.

**Mitigation**: Clinical Operations Manager: Obtain ≥3 vendor quotes for clinic fit-out, normalize costs per m², and adjust the budget or de-scope by 2025-03-31.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., timeline) as single numbers without ranges or alternative scenarios. "The brain clinic should be established and operational by 2030." This lacks contingency planning.

**Mitigation**: Project Lead: Conduct a sensitivity analysis for the project timeline, including best-case, worst-case, and base-case scenarios. Due: 2024-12-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan mentions neural mapping, AI integration, and consciousness capture but lacks technical specifications, interface definitions, test plans, and integration maps.

**Mitigation**: Head of Engineering: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for core components. Due: 2025-03-31.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Establish a brain clinic in Berlin by 2030 for digital brain capture and AI replacement to achieve near-immortality" without providing evidence of regulatory approvals or licenses.

**Mitigation**: Regulatory Affairs Specialist: Obtain preliminary written confirmation from relevant regulatory bodies regarding the feasibility of obtaining necessary licenses and approvals by 2025-06-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "near-immortality" without specific, verifiable qualities. The goal statement is "Establish a brain clinic in Berlin by 2030 for digital brain capture and AI replacement to achieve near-immortality."

**Mitigation**: Project Lead: Define SMART criteria for "near-immortality", including a KPI for average client lifespan post-procedure (e.g., 20 years beyond actuarial expectancy). Due: 2024-09-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'near-immortality' as a core goal, which adds complexity without supporting a legal/contractual requirement. The goal statement is "Establish a brain clinic in Berlin by 2030...to achieve near-immortality."

**Mitigation**: Project Team: Produce a one-page benefit case justifying 'near-immortality' as a core goal, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 2024-09-30.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'AI Integration Architect' role is critical for integrating digitized consciousness and maintaining cognitive function, but the plan lacks evidence of talent availability. "Designs and implements the AI systems responsible for integrating digitized consciousness..."

**Mitigation**: HR Team: Conduct a talent market analysis for AI Integration Architects with experience in neural networks and machine learning. Due: 2024-09-30.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions permits and licenses but does not include a matrix detailing required approvals, lead times, and dependencies. "Secure necessary permits and licenses."

**Mitigation**: Regulatory Affairs Specialist: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds. Due: 2024-12-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions maintenance of AI replacements but lacks a detailed plan. "Maintaining AI replacements will be challenging. AI systems may require updates." The plan does not address long-term costs or personnel.

**Mitigation**: Clinical Operations Manager: Develop a long-term AI maintenance plan, including cost projections, personnel requirements, and update schedules. Due: 2025-03-31.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires physical locations (brain clinic) but lacks evidence of zoning/land-use, occupancy/egress, fire load, structural limits, noise, and permit feasibility. "Plan requires a brain clinic in Berlin."

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen on potential Berlin clinic sites, addressing zoning, occupancy, fire load, and structural limits. Define NO-GO thresholds. Due: 2025-03-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions external dependencies (vendors, data, facilities) but lacks evidence of redundancy or tested failover plans. The plan requires physical locations but lacks evidence of backup facilities.

**Mitigation**: Clinical Operations Manager: Secure SLAs with key vendors (e.g., equipment maintenance, data storage) and develop/test failover plans for critical systems by 2025-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by budget adherence, while the R&D Team is incentivized by innovation, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Project Lead: Create a shared OKR aligning Finance and R&D on 'R&D spend efficiency' (e.g., 'achieve X technical milestones per €Y spent') by 2024-09-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds (when to re-plan/stop). Due: 2024-09-30.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Technical failures (Risk 2), ethical concerns (Risk 3), and security breaches (Risk 6) are strongly coupled. A technical failure could lead to ethical concerns and security breaches.

**Mitigation**: Risk Management Officer: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 2025-03-31.