### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Sponsor Identified

### 2. Project Manager circulates Draft SteerCo ToR v0.1 for review by the CEO/Executive Sponsor, Chief Technology Officer, Chief Financial Officer, and Chief Ethics Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation List
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback
- Circulation List

### 4. CEO/Executive Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. CEO/Executive Sponsor formally appoints the Project Steering Committee Vice-Chair.

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. CEO/Executive Sponsor confirms the Project Steering Committee membership (CEO/Executive Sponsor, Chief Technology Officer, Chief Financial Officer, Chief Ethics Officer, Independent External Advisor (Ethics/Regulation), Project Manager).

**Responsible Body/Role:** CEO/Executive Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment of Chair
- Appointment of Vice-Chair

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 8. Hold the initial Project Steering Committee kick-off meeting to review the project plan, budget, and governance structure.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 9. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Start

### 10. Project Manager establishes communication channels and reporting procedures for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Plan
- Reporting Procedures Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 11. Project Manager develops detailed project plans and schedules for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Plan
- Project Schedule

**Dependencies:**

- Communication Plan
- Reporting Procedures Document

### 12. Project Manager sets up project management tools and systems for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tools and Systems Configuration

**Dependencies:**

- Detailed Project Plan
- Project Schedule

### 13. Project Manager confirms the Core Project Team membership (Project Manager, Lead Neuroscientist, Lead AI Engineer, Lead Regulatory Affairs Specialist, Lead Ethicist, Finance Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Project Management Tools and Systems Configuration

### 14. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 15. Hold the initial Core Project Team kick-off meeting to review project plans, communication channels, and reporting procedures.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 16. Project Manager identifies and recruits external technical experts for the Technical Advisory Group (Quantum Computing Expert, Data Storage Expert, Cybersecurity Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of External Technical Experts
- Recruitment Documentation

**Dependencies:**

- Core Project Team Established

### 17. Project Manager defines the scope of advisory services for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Scope of Advisory Services Document

**Dependencies:**

- List of External Technical Experts

### 18. Project Manager establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Scope of Advisory Services Document

### 19. Project Manager confirms the Technical Advisory Group membership (Leading Neuroscientist (internal), Leading AI Engineer (internal), Quantum Computing Expert (external), Data Storage Expert (external), Cybersecurity Expert (external)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Communication Protocols Document

### 20. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 21. Hold the initial Technical Advisory Group kick-off meeting to review initial technical designs and specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 22. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 23. Project Manager circulates Draft Ethics & Compliance Committee ToR v0.1 for review by the Chief Ethics Officer and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation List
- Review Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 24. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback
- Circulation List

### 25. Chief Ethics Officer and Legal Counsel recruit ethicists, legal experts, and patient representatives for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Ethics Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- List of Potential Ethics & Compliance Committee Members
- Recruitment Documentation

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 26. Chief Ethics Officer establishes the ethical review process for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Ethics Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Ethical Review Process Document

**Dependencies:**

- List of Potential Ethics & Compliance Committee Members

### 27. Data Protection Officer develops data privacy and security policies for the Ethics & Compliance Committee.

**Responsible Body/Role:** Data Protection Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Data Privacy and Security Policies Document

**Dependencies:**

- List of Potential Ethics & Compliance Committee Members

### 28. Chief Ethics Officer confirms the Ethics & Compliance Committee membership (Chief Ethics Officer (internal), Legal Counsel (internal), Patient Representative (external), Ethicist (external), Data Protection Officer (internal)).

**Responsible Body/Role:** Chief Ethics Officer

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Data Privacy and Security Policies Document

### 29. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 30. Hold the initial Ethics & Compliance Committee kick-off meeting to review research protocols and ethical issues.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 31. Public Relations Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Public Relations Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**

- Project Start

### 32. Public Relations Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Public Relations Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Plan

**Dependencies:**

- List of Key Stakeholders

### 33. Public Relations Manager establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Public Relations Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Communication Channels Document

**Dependencies:**

- Communication Plan

### 34. Public Relations Manager confirms the Stakeholder Engagement Group membership (Public Relations Manager (internal), Community Liaison (internal), Patient Advocacy Representative (external), Regulatory Affairs Specialist (internal), Communications Specialist (internal)).

**Responsible Body/Role:** Public Relations Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Communication Channels Document

### 35. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 36. Hold the initial Stakeholder Engagement Group kick-off meeting to review stakeholder feedback and communication strategies.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda