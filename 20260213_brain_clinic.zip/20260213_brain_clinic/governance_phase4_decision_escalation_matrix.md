**Budget Request Exceeding Financial Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review of strategic necessity and formal vote based on the €25M threshold.
Rationale: Operational expenditure requests above the PMO's €1M limit, or capital requests exceeding the PSC's €25M/10% variance threshold (defined in PSC ToR), require strategic oversight.
Negative Consequences: Budget overrun or misallocation of critical R&D capital, threatening the €500M runway.

**Deadlock (Consensus Failure) in Technical Validation Group (TVG)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews the technical discrepancy report and votes on accepting the Independent External Computational Scientist's finding or issuing a strategic directive.
Rationale: Disagreement on the fundamental technical pass/fail status of the core deliverable (Mapping Fidelity/MAQM), which dictates project feasibility, cannot remain siloed in the technical body.
Negative Consequences: Project delay if technical direction is not finalized, or acceptance of scientifically dubious results leading to future catastrophic technical failure.

**ECDP Veto on Pilot Commencement or Regulatory Submission**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews the ECDP's justification for veto (breach of ethical/legal compliance) against strategic necessity. If PSC disagrees, external legal arbitration is triggered.
Rationale: The ECDP has binding veto rights regarding compliance and ethics that must be confirmed or overridden at the highest steering level before public-facing milestones are reached.
Negative Consequences: Immediate halting of pilot readiness, resulting in regulatory penalties or massive reputational damage if legal/ethical standards are deemed breached.

**Failure to Meet Minimum Acceptable Quantum Milestone (MAQM) by Year 2 Deadline**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Mandatory strategic review session to approve the required pivot (to lower fidelity/non-quantum substrate) or to formally request an extension impacting the 2030 goal.
Rationale: This is the primary existential feasibility risk (Risk 1). Failure requires a high-level decision on resource reallocation (diverting R&D funds) and project timeline resetting.
Negative Consequences: Potential 3-year delay in the 2030 goal and potential loss of investor confidence due to reliance on immature technology.

**Conflict between Funding Strategy and Societal Access Framework (e.g., VC pressure opposing 20% subsidy requirement)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews the conflict report detailing the financial impact vs. the risk of political/societal prohibition, requiring a vote to align strategic priorities.
Rationale: This reflects a fundamental tension between commercial capitalization (Funding Diversification) and core ethical mandate (Societal Access). The PSC must resolve this strategic contradiction.
Negative Consequences: Regulatory prohibition due to socio-economic discrimination claims, or loss of critical investment tranches if subsidy requirements are ignored.

**Unresolved Deadlock within the Project Steering Committee (PSC)**
Escalation Level: Sponsoring Organization's Board of Directors
Approval Process: The Executive Sponsor formally reports the unresolved strategic conflict, detailing dissenting opinions, for adjudication by the highest executive level.
Rationale: The PSC cannot resolve conflicts that exceed its defined financial or timeline boundaries (e.g., seeking budget increase beyond €500M or timeline shift beyond 12 months).
Negative Consequences: Project paralysis, failure to authorize necessary funding tranches, or deviation from the ultimate strategic mandate.