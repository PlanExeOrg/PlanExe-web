This plan involves money.

## Currencies

- **EUR:** The project is deeply rooted in Germany (Berlin) and operates under EU regulatory structures, making EUR the primary currency for contracts, grants, and expected operational costs (€500M budget).
- **USD:** Due to the ultra-high-risk, frontier R&D nature, involving quantum computing and global ambition, USD is prudent for large international capital raises (Venture Capital) and competitive benchmarking.

**Primary currency:** EUR

**Currency strategy:** The primary budgeting and reporting currency will be EUR, reflecting the legal and physical base in Germany/EU. However, given the high cost and international nature of securing R&D services (e.g., specialized quantum computing components or international legal consultation), transactions with non-Eurozone entities should be managed using USD or EUR, requiring active hedging against USD/EUR fluctuation for large capital equipment purchases.