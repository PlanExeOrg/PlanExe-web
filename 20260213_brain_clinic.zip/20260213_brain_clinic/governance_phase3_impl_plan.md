### 1. Project Sponsor identifies and formally appoints the Project Executive Sponsor and names an interim lead for governance setup (Formation Lead).

**Responsible Body/Role:** Sponsoring Organization Board/Executive Management

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Designation of Executive Sponsor
- Formation Lead Designated (e.g., Senior Advisor)

**Dependencies:**

- Project Kickoff Authorized

### 2. Formation Lead, guided by the Executive Sponsor, drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating binding decision rights and escalation paths.

**Responsible Body/Role:** Formation Lead

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Formal Designation of Executive Sponsor
- Adoption of the Pioneer's Gambit Strategic Path

### 3. Executive Sponsor formally appoints the initial membership for the PSC and designates the PSC Chair.

**Responsible Body/Role:** Project Executive Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal PSC Member Appointment Letters
- Designation of PSC Chair (Executive Sponsor)

**Dependencies:**

- Draft PSC ToR v0.1

### 4. The newly constituted Project Steering Committee (PSC) formally reviews, ratifies, and approves its own Terms of Reference (ToR) and establishes the Strategic Financial Threshold.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Formal Record of Strategic Financial Threshold (€25M/10% variance)

**Dependencies:**

- Formal PSC Member Appointment Letters

### 5. PSC authorizes the Project Director to establish the PMO, develops the integrated Master Project Schedule (4-year rollout plan), and defines initial operational decision thresholds.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Establishment Mandate
- Draft Master Project Schedule v0.1
- Definition of Operational Expenditure Limit (€1M)

**Dependencies:**

- Approved PSC ToR v1.0

### 6. Project Director appoints the Core Project Management Office (PMO) & Execution Team members and finalizes standardized reporting templates.

**Responsible Body/Role:** Project Director (via PMO Establishment Mandate)

**Suggested Timeframe:** Project Week 4 - 5

**Key Outputs/Deliverables:**

- Designated PMO Leadership Team Identified
- Standardized Reporting Templates

**Dependencies:**

- PMO Establishment Mandate

### 7. PMO & Execution Team finalize the initial Master Project Schedule, resource matrix, and commence operational risk tracking (Risks 5, 6, 7).

**Responsible Body/Role:** Core Project Management Office (PMO) & Execution Team

**Suggested Timeframe:** Project Week 6 - 7

**Key Outputs/Deliverables:**

- Finalized Master Project Schedule (Ready for Execution)
- Initial Operational Risk Register

**Dependencies:**

- Draft Master Project Schedule v0.1

### 8. PSC mandates the establishment of the Ethics, Compliance, and Digital Personhood Review Board (ECDP) and authorizes the CLCO to draft its scope of authority, emphasizing veto rights.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- ECDP Mandate Letter (Including Veto Authorization Scope)
- Budget allocation for external legal/ethics contracts

**Dependencies:**

- Approved PSC ToR v1.0
- Decision 5 (Consent Architecture) initiated

### 9. CLCO appoints ECDP membership (including independent reviewers) and drafts initial Terms of Reference covering compliance, consent architecture sign-off, and public communication vetting.

**Responsible Body/Role:** Chief Legal and Compliance Officer (CLCO)

**Suggested Timeframe:** Project Week 9 - 10

**Key Outputs/Deliverables:**

- Draft ECDP ToR v0.1
- Confirmation of Independent External Bioethicist

**Dependencies:**

- ECDP Mandate Letter

### 10. ECDP convenes its inaugural meeting, ratifies its ToR, establishes the internal whistleblower channel, and confirms the required scope for GDPR/EU AI documentation architecture.

**Responsible Body/Role:** Ethics, Compliance, and Digital Personhood Review Board (ECDP)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved ECDP ToR v1.0
- Minutes confirming Whistleblower Channel Establishment

**Dependencies:**

- Confirmation of Independent External Bioethicist
- Draft ECDP ToR v0.1

### 11. PSC mandates the establishment of the Technical Validation Group (TVG) and charges the Lead Neurotechnology Architect with defining objective metrics for the Minimum Acceptable Quantum Milestone (MAQM).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- TVG Establishment Directive
- MAQM Definition Mandate Issued to Neurotech Lead

**Dependencies:**

- Approved PSC ToR v1.0
- Assumption Issue 1 (Quantum Maturity Risk Mitigation)

### 12. Lead Neurotechnology Architect establishes the TVG structure, appoints members (including independent scientist), and finalizes the MAQM specification document.

**Responsible Body/Role:** Lead Neurotechnology Architect

**Suggested Timeframe:** Project Week 13 - 14

**Key Outputs/Deliverables:**

- TVG Membership confirmed
- Finalized MAQM Specification Document v1.0
- External Validation Contracts Initiated

**Dependencies:**

- TVG Establishment Directive
- MAQM Definition Mandate Issued

### 13. PMO initiates parallel workstreams: 1) Securing physical sites (Location 1, 2, 3) and 2) Establishing the Regulatory Sandbox Liaison Office in Brussels.

**Responsible Body/Role:** Core Project Management Office (PMO) & Execution Team

**Suggested Timeframe:** Project Week 7 - 15 (Parallel)

**Key Outputs/Deliverables:**

- Initial Real Estate Scouting Reports (Berlin)
- Brussels Regulatory Liaison Office lease/staffing initiated

**Dependencies:**

- Definition of Operational Expenditure Limit
- Decision 2 (Regulatory Engagement Posture) active

### 14. ECD/CLCO submits foundational documentation on 'Cognitive Preservation Asset' status to German and relevant EU bodies for preliminary feedback (per Assumption 4).

**Responsible Body/Role:** Ethics, Compliance, and Digital Personhood Review Board (ECDP)

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Formal Regulatory Inquiry on Digital Asset Status Submission

**Dependencies:**

- Approved ECDP ToR v1.0
- Assumption 4: First Legal Submission Target Met

### 15. PSC approves the final structure and initial budget allocation for the Independent Societal Trust/Future of Consciousness Council (per Assumption 7).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Trust Funding Authorized (Budget transfer initiation)
- Criteria for Trust Board Appointment Finalized

**Dependencies:**

- Decision 3 (Societal Access Framework) active
- Assumption 7: Year 1 Council Establishment Plan Approved

### 16. PMO completes the initial cybersecurity infrastructure setup (Zero-Trust, E2E Encryption) in the designated Compute Zone (Location 3) to meet the Year 1 security requirement.

**Responsible Body/Role:** Core Project Management Office (PMO) & Execution Team (led by Lead Cybersecurity Engineer)

**Suggested Timeframe:** Project Week 16 - 18

**Key Outputs/Deliverables:**

- Location 3 Security Certification (Initial State)
- Evidence of Zero-Trust Architecture Implementation

**Dependencies:**

- Assumption 5: Cybersecurity Mitigation Operationalized
- Lease/access confirmed for Location 3

### 17. TVG conducts official assessment of initial R&D outcomes, confirming preparedness for declarative memory reconstruction and benchmarking progress against MAQM.

**Responsible Body/Role:** Technical Validation Group (TVG)

**Suggested Timeframe:** Project Week 20

**Key Outputs/Deliverables:**

- TVG Technical Readiness Report v1.0
- Confirmation of Declarative Memory Reconstruction success (Year 2 Trigger Check)

**Dependencies:**

- TVG Membership confirmed
- TVG defining MAQM metrics

### 18. PSC holds the Milestone Review #1, assessing operational setup (PMO, ECDP, TVG established) and reviewing the TVG Readiness Report to confirm the transition from setup phase to intensive R&D/Pilot Phase.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 21

**Key Outputs/Deliverables:**

- Official Go/No-Go Decision for Year 2 Pilot Preparation Phase
- Q1 Strategic Risk Update

**Dependencies:**

- TVG Technical Readiness Report v1.0
- ECDP Annual Audit Procedures Kickoff