*Roles Needed & Example People*

# Roles

## 1. Programme Director / Executive Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Programme Director / Executive Lead requires continuous, single-point authority across the entire 10-year lifecycle (Months 0–120 = 2026-10-12 to 2036-10-12). Governs governance, funder alignment, gate releases, and programme integrity. Decision-making and stakeholder management are ongoing core accountability, not episodic. Full-time employment ensures exclusive focus and institutional authority necessary for a £250M multi-stakeholder initiative.

**Explanation**:
Owns overall programme delivery, governance, stakeholder alignment, and decision-making authority across 10-year lifecycle. Manages Programme Board, coordinates with 15+ funders and 30+ archives, enforces phase gates and gate criteria, escalates risk events, and ensures mission integrity throughout pilot validation and scale-up. Critical from Month 0 (2026-10-12) through Month 120 (2036-10-12).

**Consequences**:
No single authority to resolve funder conflicts, approve design choices, or enforce gates; governance delays cascade, funders pull commitments, schedule slips 3-6 months per decision cycle, Phase 2 and Phase 3 funding releases stall, calendar loss compounds media degradation losses, and archive partnerships fragment.

**People Count**:
1

**Typical Activities**:
Monthly Programme Board meetings with 8-10 representatives from funders and archives, setting decision criteria and escalation paths. Quarterly financial reviews and variance reporting to funder consortium. Monthly one-on-ones with phase leads (vintage equipment, AI, site logistics, privacy) to track risks and gate readiness. Funder engagement calls (2-3 per week) managing pledges, securing commitment registry translations, identifying contingency sources. Governance decision-making on design approvals, gate releases and risk escalations. Coordination with national archives and cultural foundations on strategic partnerships and pilot host selection. Monthly risk registry review with executive team.

**Background Story**:
Dr. Margaret Chen, 52, based in Arlington, Virginia. PhD in Museum Studies from UC Berkeley; 15 years leading large-scale digitization initiatives at the Smithsonian Institution and National Archives. Led the Smithsonian's audiovisual preservation network during the 2010s, managing budgets of USD 20-30M across five sites and negotiating with federal and philanthropic funders. Known for transparent governance, stakeholder alignment and resolving complex funder disputes. Familiar with multi-year gate-based capital projects and heritage institutional politics. Recruited to direct CDDIN because of prior experience establishing preservation networks and proven ability to enforce gates without eroding institutional trust.

**Equipment Needs**:
Secure office with video conferencing infrastructure (up to 12-person boards, poor-connection fallback); Programme Board meeting logistics (secure document sharing, decision-tracking database). Budget estimates from financial models and gate-decision software. Access to funder engagement platforms (Slack, email, video). Security protocols for sensitive funder and partnership agreements.

**Facility Needs**:
Dedicated office space in Arlington, Virginia (Programme Hub); proximity to national archives and cultural foundations for regular in-person stakeholder engagement. Conference and meeting space for quarterly Programme Board sessions (10-15 people). Secure, climate-controlled storage for contract files and governance records. Telecommunications infrastructure supporting 24/7 coordination across North America and Europe time zones.

## 2. Vintage Equipment Sustainment Engineer / Parts Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Vintage Equipment Sustainment Engineer / Parts Manager. Core operational responsibility for parts-depletion modeling, parts inventory discipline, 3D printing/CNC capability, and vendor relationships. The >90% uptime target depends on continuous parts-consumption monitoring and re-manufacture triggers at 50% depletion. This is ongoing throughout Months 0–120 (2026-10-12 to 2036-10-12), not project-specific. Requires institutional knowledge of equipment base and dedicated engineering focus.

**Explanation**:
Owns the 300-500 unit acquisition, condition assessment, parts inventory, cannibalization discipline, 3D printing/CNC fabrication for precision parts, and vendor relationships. Models parts-depletion curve, triggers re-manufacture at 50% depletion, maintains the central parts warehouse, and enforces uptime targets. Works closely with retired-engineer mentors to validate fabrication tolerance and playback fidelity. Essential for sustaining the >90% uptime target across all 30 units.

**Consequences**:
Parts depletion unmodeled; stockpile consumed faster than anticipated; units offline for weeks awaiting spares; uptime drops below 90% by Months 36-48 (2029-10-12 to 2030-10-12), causing 3-unit continuous downtime and 300-500TB monthly loss; emergency stockpile acquisition costs USD 15-25M unbudgeted; knowledge of precision part fabrication is lost, forcing reliance on external vendors or obsolete equipment suppliers at high cost.

**People Count**:
3-5 (min 1 dedicated parts engineer, 1 inventory manager, 1-3 fabrication/testing engineers)

**Typical Activities**:
Weekly condition assessments of acquired vintage machines (serial number, functional status, parts-harvest potential) logged to central inventory. Monthly parts-consumption reporting from all active units, modeling depletion curves by deck type and calculating when re-manufacture must trigger at 50% depletion. Hands-on validation testing of 3D-printed and CNC-machined parts on reference-grade decks, measuring azimuth offset (±0.05mm tolerance) and playback fidelity. Monthly mentoring supervision sessions with Parts Engineering team (3-5 engineers) and fabrication vendors. Quarterly stocktake of the 300-500 acquired vintage machines and the central parts warehouse. Coordination with Retired-Engineer Mentors on part tolerance specs and fabrication approval.

**Background Story**:
James 'Jim' Kellerman, 58, based in Culpeper, Virginia. Broadcast engineer with 32 years at NPR and PBS stations; trained by retired Ampex and Studer technicians in the 1990s on tape transport alignment, azimuth calibration and head fabrication. Led equipment sustainment programs at two public broadcasting stations before their consolidation in 2015. Built a parts warehouse managing 150+ decommissioned decks. Expert in 3D-printing tolerance for precision mechanical components; published two papers on legacy-equipment restoration. Recruited to model the parts-depletion curve and lead the Parts Engineering team because he has hands-on experience with the exact scarcity and repair challenges the plan depends on.

**Equipment Needs**:
Industrial-grade parts inventory and condition-assessment tools: precision calipers, azimuth-offset gauges (±0.05mm tolerance), speed-regulation testers, layer-adhesion test equipment, optical microscope. Reference-grade tape decks and film scanners for validation testing. 3D printer and CNC machining equipment (in-house or vendor partnerships) for parts fabrication. Telemetry and parts-tracking database (inventory management system with consumption forecasting).

**Facility Needs**:
Climate-controlled warehouse (4,000–6,000 sq ft minimum) for 300–500 vintage machines and parts inventory near Culpeper, Virginia or accessible to the central retrofit hub. Secure storage with organized shelving, parts bins and condition-assessment work benches. Industrial lift equipment for handling heavy decks and scanner frames. Testing laboratory with reference-grade equipment for tolerance validation. Office space for 3–5 parts engineers and fabrication oversight.

## 3. Retired-Engineer Mentor / Knowledge Transfer Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Retired-Engineer Mentor / Knowledge Transfer Lead. 6–8 broadcast and film engineers (aged 70–80) are sourced externally, outside the core programme staff, on time-limited mentoring contracts (18–24 months per successor cohort, with retention bonuses to Month 48 = 2030-10-12). These are specialized, perishable experts contracted for knowledge transfer, not permanent employment. Engagement is high-intensity but time-bound (Months 0–48 = 2026-10-12 to 2030-10-12 critical period), suited to independent contracting with defined deliverables (curriculum documentation, hands-on mentoring hours, tolerance validation).

**Explanation**:
6-8 broadcast and film engineers (aged 70-80) provide intensive mentoring in tape azimuth alignment, film registration, head calibration, belt replacement and mechanical repair—expertise unavailable elsewhere. Each mentor trains 2-3 successors over 18-24 months with documented curriculum. Mentors validate 3D-printed parts on reference equipment and ensure knowledge transfer is complete before mentoring exits. Perishable asset requiring urgent commitment by Month 1 (2026-11-12).

**Consequences**:
Loss of irreplaceable tape deck and film scanner repair expertise; younger engineers lack training in dead technology; unit failures cannot be diagnosed or repaired reliably; external consultant costs escalate to USD 5-10K per incident vs. USD 500-1K in-house; by Month 30-36 (2029-04-12 to 2029-10-12), mentor attrition leaves maintenance capability severely degraded or non-existent; fleet uptime target becomes unachievable.

**People Count**:
6-8 (min 2 per line type: Tape, Film, Card)

**Typical Activities**:
Weekly hands-on training sessions (16+ hours per month per successor engineer) covering tape azimuth alignment procedures, head calibration measurement techniques, belt and transport replacement, and diagnostic troubleshooting on reference decks. Documentation of training in video, written protocol and digital knowledge repository. Quarterly review of successor engineers' progress and competency sign-off on critical repairs. Monthly consultation on precision parts fabrication and tolerance validation, testing 3D-printed azimuth fixtures on working equipment. Technical problem-solving escalations from field units: diagnostics of tape-transport failures (azimuth drift, speed variation, wow/flutter) that field crews cannot resolve locally. Participation in quarterly mentoring curriculum updates.

**Background Story**:
Robert 'Bob' Sutherland, 76, retired from Ampex Corporation's tape-head division in 1998 after 38 years designing and repairing tape transports. Worked on the Ampex VRX-1000 series and trained broadcast engineers worldwide in azimuth alignment procedures. Post-retirement consultant to the Packard Campus conservation lab for 15 years. Holds 8 patents in tape-transport mechanics. Physically active and committed to documenting his knowledge before retirement. Contracted for 24-month intensive mentoring at USD 80K retainer plus USD 20K per successor trained, with retention bonus to Month 48 (2030-10-12) to ensure knowledge transfer completion and post-transition consultation on complex repairs.

**Equipment Needs**:
Reference-grade tape decks, film scanners and card readers representing each line type and degradation level for hands-on demonstration and validation. Video recording and documentation equipment for curriculum capture. Digital repository access for shared knowledge base (wiki, video library, technical documentation platform). Precision measurement tools for tolerance validation during hands-on training sessions.

**Facility Needs**:
Access to working laboratories with installed legacy equipment at one central hub (Northern Virginia or UK location) where mentors can conduct intensive, hands-on training. 1–2 dedicated workbenches per mentor with reference equipment and spare parts. Comfortable training space near or within the retrofit facility. Flexible scheduling to allow mentors to work part-time across 18–24 month mentoring periods. Video conferencing for remote consultation on field failures.

## 4. Site Operations and Logistics Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Site Operations and Logistics Coordinator. Owns Master Schedule and Queue Management System, site-readiness milestones, container transport and customs coordination, and residency workflow for all 30+ archives. This is continuous operational responsibility from Month 2 (2026-12-12) through Month 120 (2036-10-12), spanning all phases. Requires institutional knowledge of the full fleet schedule and direct coordination with host archives. Part-time or contracted logistics would fragment accountability and introduce scheduling risk.

**Explanation**:
Plans each MIU residency: coordinates with host archives on readiness (power, hardstand, security, fire-authority approval), manages container transport and customs clearance, liaises with facility managers on setup and power/data connections, and manages the 6-12 month residency workflow. Owns the Master Schedule and Queue Management System, tracks site-readiness milestones, maintains a Priority Waitlist, and coordinates relocation between residencies. Critical from Month 2 (2026-12-12) onward.

**Consequences**:
Unit arrivals at unprepared sites; 4-8 week delays per archive due to missing power, hardstand or fire approval; schedule slips accumulate across 30 residencies, consuming 6-12 months of calendar time; containers stranded awaiting customs clearance, losing USD 5-10K per day; site withdrawal mid-residency orphans collections; logistics costs escalate and cost tracking fails, producing opaque overspend.

**People Count**:
2-3 (min 1 dedicated scheduler, 1-2 site-readiness coordinators)

**Typical Activities**:
Daily Master Schedule and Queue Management System updates tracking all 30+ archive residencies, scheduling windows (6-12 months per site), readiness milestones and buffer periods. Weekly outreach to each upcoming host archive (6 months pre-arrival) conducting power audit, hardstand assessment, fire-authority and insurer pre-approval coordination. Site-Readiness Scorecard tracking (power, hardstand, security, staff liaison, fire-authority sign-off, insurer letter) for each host, escalating shortfalls to archive director and proposing remediation. Container transport and customs coordination (2-4 weeks pre-departure): documentation preparation, temporary-import carnet filing, customs broker liaison. Monthly relocation logistics (container trucking, setup, power/data connection) and site handoff meetings with host staff. Maintenance of Priority Waitlist of backup sites and contingency parking locations for schedule absorption.

**Background Story**:
Elena Vasquez, 48, based in Washington DC. Program manager with 16 years in logistics and site operations at the U.S. Geological Survey's facility network across 12 states. Led the containerized mobile lab program (geophysical instruments in shipping containers deployed to field sites) managing 8 units, 120+ site relocations over 12 years, and customs clearance for equipment across 6 countries. Expertise in fire-authority and insurer pre-approvals, hardstand and power requirements, and site-readiness scoring. Master's in Supply Chain Management. Recruited to coordinate 30+ archive residencies and master schedule because she has proven ability to manage complex multi-site logistics and regulatory approval timelines.

**Equipment Needs**:
Master Schedule and Queue Management System (proprietary or open-source scheduling software with Gantt views, resource allocation, critical-path analysis). Container-tracking systems (GPS, customs documentation, temporary-import carnet filing software). Archive readiness scorecards (spreadsheet templates or integrated database). Logistics cost and variance tracking tools. Telemetry dashboards for status updates from all 30+ host sites.

**Facility Needs**:
Office space in central coordination hub (Arlington, Virginia or equivalent) shared with Programme Director. Access to Archive Liaison Database (contact management for 30+ host institutions with readiness tracking). Direct phone and video conference capability for daily coordination with site managers and host archives. Secure documentation storage for source agreements, host commitments and site-readiness records.

## 5. AI Signal Processing and Metadata Engineering Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: AI Signal Processing and Metadata Engineering Lead. Owns the critical unvalidated AI pipeline (pre-screening, signal reconstruction, metadata extraction) that directly drives reviewer headcount and crew composition. Validates AI accuracy on real degraded content (Months 2–8 = 2026-12-12 to 2027-06-12), maintains living benchmark, detects model drift, and triggers retraining. This is a core technical dependency throughout the programme, not a procurement task. Continuous ownership ensures accountability for the assumptions upon which Phase 2 gates depend.

**Explanation**:
Owns the AI pipeline for pre-screening (copyright, privacy, classification detection), signal reconstruction (audio noise removal, video error correction, data recovery), and metadata extraction (speech-to-text, OCR, scene recognition). Validates AI accuracy on real degraded, multilingual 1950-2000 content by Month 4 (2027-02-12), maintains a living benchmark with canary deployments, detects model drift per site, and triggers retraining if precision/recall falls below 75% or flagging exceeds thresholds. Directly impacts reviewer headcount and crew composition.

**Consequences**:
AI accuracy unvalidated on real content; flagging rate assumed at 20% when actual is 35-40%; reviewer headcount required triples from 12-15 to 40-50 per unit; additional payroll USD 15-25M annually at full scale exceeds budget; model drift undetected, degrading output quality; Phase 1 budget consumed without evidence; Phase 2 release contingent on unvalidated metrics.

**People Count**:
2-3 (min 1 lead engineer, 1 validation/monitoring specialist, 1 retraining engineer)

**Typical Activities**:
Weekly validation of AI pre-screening and signal-reconstruction models on representative test samples (100-200 items per month) from proposed pilot archives, measuring precision, recall and false-positive rate by format, language and degradation level. Monthly gold-standard labeling coordination with 3-5 expert human reviewers (copyright, privacy, archivists) to build ground-truth datasets. Quarterly canary deployments: sending initial 10-20 items from each new archive through the full AI and review pipeline, measuring accuracy and triggering retraining if drift exceeds 5 percentage points. Living Leaderboard maintenance: publishing model performance monthly and analyzing drift patterns. Meetings with Privacy Review Panel on pre-screening flagging false-negatives and false-positives in real content. Coordination with data science teams on model retraining when accuracy falls below 75% precision/recall per category-format.

**Background Story**:
Dr. Amara Okafor, 41, based in Berkeley, California. PhD in Audio Signal Processing from Stanford; 12 years at Adobe developing noise-reduction and speech-enhancement algorithms for consumer audio. Transitioned to heritage audiovisual preservation in 2019, leading AI model development at Indiana University's Media Digitization and Preservation Initiative (MDPI) for 4 years. Published 6 papers on AI accuracy on degraded speech and music. Experienced in pre-screening copyright/privacy markers and knows the gaps in AI performance on 1950-2000 multilingual content. Recruited to validate AI pre-screening accuracy because she has tested real degraded content and understands where algorithms fail.

**Equipment Needs**:
High-performance compute infrastructure for AI model development and testing (GPUs or TPUs, data storage 100+ TB for training sets and results). AI/ML software platforms (PyTorch, TensorFlow or equivalent). Audio and video processing toolsets (libsndfile, FFmpeg or equivalent). Speech-to-text and OCR libraries. Reference audio, video and card-scan samples (100–200 items) from diverse sources and degradation levels for ground-truth labeling and validation.

**Facility Needs**:
Dedicated office and lab space in or near a major tech hub (Berkeley, Stanford region preferred) with reliable high-bandwidth internet for compute job submission and data transfer. Secure, climate-controlled server room or cloud compute account for GPU-intensive model training. Collaboration space for 2–3 signal-processing engineers and validation specialists. Regular access to archival test samples via secure file transfer or federated data agreements with pilot host archives.

## 6. Privacy, Rights and Legal Compliance Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Privacy, Rights and Legal Compliance Officer. Develops and enforces privacy frameworks, source-agreement templates, rights assessment, and data-residency compliance per jurisdiction (GDPR, UK DPA, etc.). Leads Privacy Review Panel, maintains decision logs, and manages incident response. This is a continuous gate-keeping function throughout digitization operations (Months 6–120 = 2027-04-12 to 2036-10-12) that cannot be delegated or outsourced. A single decision authority is required to prevent autonomous legal calls and enforce compliance consistently across all sites and jurisdictions.

**Explanation**:
Develops and enforces privacy frameworks, source-agreement templates, rights assessment workflows, and data-residency compliance per jurisdiction (GDPR, UK DPA, etc.). Leads Privacy Review Panel overseeing flagged items before upload, maintains decision log with rationale, handles copyright and classification disputes, manages incident response (24-hour breach notification), and ensures no autonomous legal decisions occur. Works with host archives on tiered consent and indemnity structures.

**Consequences**:
Privacy breaches leak PII to archives; GDPR fines USD 5-20M+ and regulatory investigation freezes operations; source agreements lack jurisdiction-specific terms; data-transfer violations block cross-border archival upload; handling incidents destroy unique items without clear liability assignment; archive partnerships terminate after trust failure; no decision log trail for incident post-mortems.

**People Count**:
1-2 (lead officer plus 1 specialist for rotating Privacy Review Panel membership)

**Typical Activities**:
Monthly Privacy Review Panel meetings (rotating 2-3 data-protection experts) reviewing flagged items before archival upload, recording decision rationale in Privacy Decision Log. Legal mapping and jurisdiction-specific compliance analysis: maintaining matrix of GDPR, UK DPA and other jurisdictional rules per country and data type. Source-agreement template maintenance and customization: developing jurisdiction-specific annexes (EU GDPR addendum, UK DPA addendum, US state-level restrictions). Incident-response coordination: 24-hour breach-notification protocol to archives and regulatory bodies per GDPR/DPA, managing containment and remedy. Quarterly audit of Privacy Review Panel decisions (5% sample) for consistency and legal defensibility. Copyright and classification dispute resolution: escalations from field units on items flagged as sensitive or restricted. Consultation on tiered-indemnity structures and loss-reserve administration.

**Background Story**:
Sarah Mitchell, 52, based in London. Barrister and specialist in UK Data Protection Law, GDPR and digital-preservation policy. 18 years at a London-based cultural law practice representing museums, archives and broadcasters on copyright, privacy and data-residency disputes. Leading advisor on UK Heritage Sector GDPR compliance guidance (2018-2024). Familiar with source agreements, tiered access regimes and incident-notification protocols. Recruited as Privacy, Rights and Legal Compliance Officer because her expertise spans the jurisdictions where CDDIN operates and she understands the unique legal exposure of pre-screening and on-site review.

**Equipment Needs**:
Legal research databases (Westlaw, LexisNexis or equivalent for GDPR, UK DPA, international data-protection law). Document management and decision-tracking software (shared secure legal documentation platform). Privacy Impact Assessment templates and jurisdiction-specific compliance mapping tools. Incident-response logging system. Video conferencing for Privacy Review Panel monthly meetings.

**Facility Needs**:
Office space in London or Brussels (jurisdiction centers for GDPR and UK DPA expertise). Access to legal libraries and regulatory databases. Meeting space for monthly Privacy Review Panel sessions (rotating 2–3 experts, video conference capability). Secure document storage for source agreements, privacy decision logs and incident records. Direct connectivity to host archives' legal representatives and data-protection authorities.

## 7. On-Site Unit Crew Lead / Resident Field Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: On-Site Unit Crew Lead / Resident Field Manager. Embedded with each MIU, responsible for daily operations, media intake, pre-treatment scheduling, robotic operations, field troubleshooting, and incident response. Each unit requires a dedicated resident lead (Month 6 = 2027-04-12 onward per unit deployment through Month 12–18 = 2027-10-12 to 2028-04-12 residency). Full-time employment on-site ensures operational control, safety compliance, and immediate incident response. Performance of digitization itself (the core mission) depends on resident crew reliability and continuity.

**Explanation**:
Embedded with each MIU: oversees daily operations at host sites, coordinates intake and media sorting with archive staff, manages pre-treatment scheduling (baking, humidification), operates robotic loading systems and decks, performs field troubleshooting, manages on-board storage and uplink to central archive, reports status and incidents via telemetry, and maintains safety and incident protocols. Manages 3-4 junior operators/technicians per unit and represents the programme to host institution.

**Consequences**:
Operational breakdowns on-site; media intake mismanaged; pre-treatment batches delayed; robotic loading errors; incident response delayed; telemetry gaps prevent remote diagnostics; units become liabilities at host sites; host relationships deteriorate; no local presence enforces safety and compliance protocols.

**People Count**:
3-4 per active MIU (min 1 crew lead, 2-3 junior operators/technicians); fleet-wide ~12-15 at Phase 1 (3 units), ~42-60 at Phase 2 (15 units), ~90-120 at Phase 3 (30 units)

**Typical Activities**:
Daily on-site operations: coordinating media intake and sorting with archive liaison staff, scheduling pre-treatment batches (baking ovens, humidity chambers), monitoring climate control and power status. Supervision of 2-3 junior operators per unit on robotic loading operations, deck monitoring and incident response. Weekly status reporting via telemetry dashboard (power, climate, error rates, throughput, on-board storage levels) to central operations. Safety and compliance: maintaining incident protocols, logging all media handling, notifying central operations of anomalies within 4 hours. Relationship management with host institution: daily liaison with archive director/curator on collection priorities, scheduling conflicts and emergencies. Monthly residency planning: coordinating intake pace, pre-treatment schedules and upload timing. Field troubleshooting: diagnosing equipment issues and escalating complex failures to central maintenance team.

**Background Story**:
Thomas Oakes, 44, based in rural Michigan. Audio technician with 20 years' experience operating and maintaining broadcast audio consoles, tape decks and mixing equipment at public radio stations. Transitioned to conservation work at the University of Michigan Library in 2015, managing audio transfer operations and handling delicate analog recordings. Trained in pre-treatment procedures (baking tapes, humidity stabilization), intake sorting and quality control. Known for calm, detail-oriented work under pressure and strong relationships with archivists. Recruited as On-Site Unit Crew Lead because he combines technical competence with the interpersonal skills needed to represent the programme to host institutions.

**Equipment Needs**:
On-board containerized digitization equipment: tape decks, film scanners or card readers (depending on MIU line type); robotic loading arms; climate-control instrumentation (thermometers, hygrometers); power monitoring (voltage, frequency, harmonic analysis); generator or facility-power interface; satellite or fiber uplink modem; telemetry monitoring sensors for power, climate, equipment error rates. On-board 500TB storage system. Standard tools (screwdrivers, wrenches, test equipment) for field troubleshooting.

**Facility Needs**:
40-ft shipping container retrofitted as a mobile processing unit, positioned at host archive for 6–12 months per residency. Hardstand (level concrete pad, minimum 50m x 15m); stable utility power (208–240V, 200+ kW) or on-site generator (400–500 kW); data connectivity (fiber or satellite, 10+ Mbps upload for archive transmission); proximity to host building for media intake and return (loading dock or entrance); security perimeter (fence or guard). Parking for crew vehicles. Contingency: detached pre-treatment pod (separate 20-ft container, 50+ meters from main archive) if fire-authority restrictions require thermal/chemical isolation.

## 8. Multilingual Review and Quality Assurance Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Multilingual Review and Quality Assurance Specialist. Embedded reviewers assess flagged items before archival upload. The review bottleneck (Months 6–120 = 2027-04-12 to 2036-10-12) is a sequential gate in the digitization workflow; review must happen on-site or in a centralized hub with real-time content access. Reviewers work at high density (15–20 minutes per flagged item) and must maintain quality consistency across diverse content types. Full-time employment per unit (or in a central review hub) ensures availability, reduces turnover risk, and enforces QC standards. Contractor or part-time reviewers would introduce inconsistency and delay in a gate-critical function.

**Explanation**:
Embedded reviewers assess flagged items (copyright markers, PII, classification labels) flagged by AI pre-screening before archival upload. Fluent in multiple languages, trained in cultural context, copyright assessment, and privacy law. Works at 2x speed (15-20 minutes per item vs. standard full review), flagging only high-risk content for escalation. Maintains quality consistency across diverse content types and degradation levels. Directly impacts review bottleneck and crew composition.

**Consequences**:
Review bottleneck unmanaged; 1,000+ hours of content per collection require review, delaying archival upload; copyright/privacy items not flagged leak into archive; incident and breach exposure; if AI pre-screening fails to achieve 80% reduction and actual flagging is 35-40%, reviewer headcount must triple, adding USD 15-25M annual payroll exceeding budget; content accumulates in on-board storage, units cannot move to next site; schedule collapses.

**People Count**:
12-15 per active MIU (360-450 fleet-wide at 30 units); if actual flagging exceeds 25%, scales to 40-50 per unit (960-1500 fleet-wide)

**Typical Activities**:
Daily review of 40-60 flagged items per day (15-20 minutes per item), assessing copyright markers (logos, watermarks, known broadcast content), privacy indicators (PII patterns, medical jargon, personal correspondence) and classification markers (government stamps, security labels). Flagging decisions recorded in Privacy Decision Log with rationale. Quality consistency checks: comparing own flagging decisions against the Privacy Review Panel's monthly audit sample to identify systematic bias or drift. Multilingual content assessment: applying cultural and linguistic context to understand whether handwritten labels, foreign-language speech or archival terminology indicates restricted status. Escalation of complex or disputed items to the Privacy Review Panel. Monthly team review and training coordination with other reviewers (12-14 colleagues per unit) on consistent thresholds and new types of marked content. Telemetry feedback: reporting flagging patterns, false-positive rates and emerging content types to the AI Signal Processing team for model retraining.

**Background Story**:
Dr. Kwame Asante, 39, based in Berlin, Germany. PhD in Comparative Literature; 11 years in multilingual content analysis and rights assessment at Deutsche Welle and the German Film Institute. Fluent in English, German, French, Spanish and Mandarin; working knowledge of Italian, Portuguese and Russian. Trained in copyright and privacy law as applied to broadcast archives. Led a team of 8 reviewers at the German Film Institute assessing rights and restrictions in archived film collections. Recruited as a Multilingual Review specialist because he combines linguistic depth with cultural knowledge and legal training—essential for accurate flagging of copyright, privacy and classification markers in degraded, non-English content.

**Equipment Needs**:
Computer workstations with high-resolution displays for content assessment. Access to the central AI pre-screening and metadata systems. Privacy Decision Log database. Headphones and speaker systems for audio review. Video playback and image-viewing software. Translation and reference tools for multilingual content. Secure note-taking and decision-documentation tools.

**Facility Needs**:
Dedicated review station on-site at each MIU container or in a secure central review hub (if review is centralized). Climate-controlled office space with 12–15 workstations per active unit. Acoustic isolation for audio review (sound-dampened review booths or headphone-only work). Secure storage for sensitive materials (restricted-access tier content). Meeting space for monthly Quality Assurance team reviews and Privacy Panel participation (remote or video conference). Comfortable, low-burnout workspace (ergonomic seating, breaks, professional development support).

## 9. Central Operations and Fleet Management Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Central Operations and Fleet Management Officer. Runs the central command center monitoring all 30 units via telemetry (power, climate, error rates, uptime, parts, throughput). Coordinates remote expert guidance, dispatches maintenance, tracks parts inventory and fabrication triggers, manages preventive maintenance and failure analysis. This is a continuous, real-time operational function from Month 6 (2027-04-12) (first pilot operations) through Month 120 (2036-10-12). Fleet uptime >90% depends on proactive centralized monitoring and dispatch, not episodic vendor support. Full-time employment ensures 24/7 availability and institutional accountability for uptime targets.

**Explanation**:
Runs the central command center monitoring all 30 units via telemetry dashboards (power, climate, error rates, uptime, parts consumption, media throughput). Coordinates remote expert guidance to field crews, dispatches central maintenance support, tracks parts inventory and fabrication triggers, manages the Parts Consumption Telemetry dashboard, schedules preventive maintenance, analyzes failure patterns, and provides escalation routing for field problems. Ensures >90% uptime target is met fleet-wide.

**Consequences**:
Telemetry unmonitored; equipment failures cascade undetected; preventive maintenance deferred; uptime drops below 90%; one unit's failure propagates to others; fleet-wide visibility lost; no early warning of parts depletion; remote support to field crews unable to prioritize or allocate expertise; central support team operates blindly, reactive rather than proactive.

**People Count**:
1-2 (min 1 operations manager, 1 telemetry/data analyst)

**Typical Activities**:
24/7 monitoring of all 30 units via telemetry dashboards (power, climate, error rates, uptime, parts consumption, media throughput) from the central operations room. Daily failure analysis and pattern detection: identifying systematic issues (e.g., all tape decks in a region showing azimuth drift), triggering escalation or preventive intervention. Weekly parts-consumption analysis and re-manufacture triggers at 50% depletion thresholds. Coordination of remote expert guidance: routing field problems to the correct specialist (retired-engineer mentor, parts engineer, AI signal specialist) and tracking resolution time. Preventive-maintenance scheduling: recommending maintenance windows for each unit based on uptime targets and residency calendars. Monthly uptime reporting to Programme Board (>90% target tracking). Escalation protocol management: flagging equipment failures that indicate design flaws and triggering design-review gates. Incident coordination: logging all significant events, near-misses and failures for pattern analysis and post-incident reviews.

**Background Story**:
David Patel, 45, based in Arlington, Virginia. Systems engineer with 18 years in military and civilian fleet management (command-and-control systems for vehicle and equipment networks). Led a 24/7 operations center managing 150+ distributed radar and communication stations across North America, with predictive maintenance, remote diagnostics and failure-rate analysis. Expertise in telemetry dashboards, remote expert routing and preventive maintenance scheduling. Familiar with high-availability targets (>99% uptime) and incident escalation. Recruited as Central Operations and Fleet Management Officer because he has proven ability to maintain fleet-wide uptime through distributed monitoring and proactive dispatch.

**Equipment Needs**:
Central operations dashboard software (telemetry aggregation, real-time monitoring of power, climate, error rates, uptime, parts consumption across all 30 units). Alert and escalation system (automated notifications for >90% uptime violations, equipment failures, parts-depletion thresholds). Parts Consumption Telemetry dashboard and re-manufacture triggers. Incident and failure logging database. Remote expert-routing system and ticketing platform for field-crew support requests. Fleet-wide analytics and reporting tools (monthly uptime, failure-pattern analysis).

**Facility Needs**:
Dedicated central operations room in Arlington, Virginia (Programme Hub), staffed 24/7 or on-call. High-bandwidth, redundant internet connectivity to all 30 units. Video conference capability for remote expert guidance coordination. Secure, climate-controlled server room or cloud-hosted telemetry platform (resilient to outages). Multiple large monitors for simultaneous unit-status monitoring. Direct phone and radio communication to field crews. Archive-liaison contacts and escalation protocols. Regular access to Retired-Engineer Mentor network for technical problem routing.

---

# Omissions

## 1. No documented quality-assurance and calibration regime for playback accuracy and fidelity across all line types and host sites.

The plan targets >95% successful digitization and >80% reconstruction accuracy but does not specify how these metrics are measured, calibrated or validated consistently across 30+ units and three line types (Tape, Film, Card). No reference media set, inter-unit drift detection or archival-standard playback verification is mentioned. This is critical because success claims rest on evidence the plan does not yet collect, and archivists will demand proof before releasing unique materials.

**Recommendation**:
By Month 4 (2027-02-12), establish a Reference Media Calibration Set: procure 10–15 standard-condition tape reels, film cans and card batches from known sources. At each new unit deployment, digitize the reference set and measure against baseline (azimuth, speed regulation, signal-to-noise ratio, colour accuracy). Publish a Playback Fidelity Dashboard showing all units' performance against reference standards. If any unit drifts >5% from baseline, trigger re-calibration or removal. Budget USD 500K–1M for reference-media procurement and quarterly inter-unit calibration.

## 2. No explicit data-custody and perpetual-storage plan beyond Month 120 (2036-10-12), creating an orphaned 200+ PB archive with no steward.

The plan targets 200+ PB recovered but does not specify who holds the masters, in what formats, with how many verified copies, or how costs are funded after the 10-year programme closes. Without a clear end-state, the recovered data itself becomes a liability: no institution may accept perpetual storage obligations, format-migration costs are not budgeted, and the archive may be inaccessible or degraded within 5–10 years of Month 120 (2036-10-12). This undermines the entire preservation mission.

**Recommendation**:
By Month 12 (2027-10-12), establish a Custody and Perpetual Storage Working Group tasked with deciding: (a) where masters live (host-held vs. federated network vs. central); (b) format standards (preservation master format, access derivative formats, migration triggers); (c) number of verified copies and geographic separation; (d) funding model post-Month 120 (2036-10-12) (endowment, cost-sharing with archives, government commitment). By Month 36 (2029-10-12), publish a Custody and Access Plan binding partner archives to multi-decade storage commitments. Budget USD 2M–5M from Phase 3 for data-migration and storage-sustainability planning.

## 3. No defined role for independent third-party audit and verification of recovery claims, recovery rates and success metrics.

The plan's headline targets (3.6M items, 200+ PB, >95% success, >80% accuracy) are stated but not independently validated. Self-reporting by the programme team invites optimistic metrics; funders and partner archives have no credible evidence that these targets are being met. Gate releases hinge on unverified success metrics, risking a Phase 2 decision based on inflated pilot results.

**Recommendation**:
By Month 3 (2027-01-12), establish an Independent Verification and Audit Regime: contract an external auditor (third-party preservation lab or consultancy) to sample recovered items at each site, compare against originals, and publish precision, recall and quality metrics per format and degradation level. Conduct quarterly audits (sampling 2–5% of recovered content per site). Publish results monthly in a public Verification Dashboard. Gate releases depend on third-party findings, not internal reports. Budget USD 1M–2M for independent audits over the programme.

## 4. Absence of a defined incident-response and near-miss reporting system across the fleet, creating blind spots on equipment failures, handling damage and close calls.

The plan mentions incident protocols but does not specify who logs failures, how data is aggregated, who analyzes patterns or how systematic issues (e.g. all Film Line units showing humidity-control drift) are escalated. Without central incident tracking, failure modes go undetected, root-cause analysis is impossible, and the same failure repeats across multiple units before remediation.

**Recommendation**:
By Month 6 (2027-04-12), establish a Centralized Incident and Failure Tracking System: every unit crew logs equipment failures, handling anomalies and near-misses within 4 hours via a secure web portal (equipment-ID, symptom, action taken, outcome). Automated daily aggregate to Central Operations and Fleet Management Officer. Weekly pattern detection: flag if any failure signature (e.g. 'tape transport azimuth drift') appears >1 time in a week across the fleet. Monthly root-cause analysis (engineering team + retired-mentor review). Quarterly trend reports to Programme Board. Budget USD 300K–500K for incident-tracking software and 1 FTE incident analyst.

## 5. No role or team dedicated to managing the knowledge base and digital scholarship access post-Month 120 (2036-10-12).

The plan states that recovered data has 'post-human value' and should be accessible to future AI and researchers, but no team owns the knowledge commons, documentation or digital-scholarship platform beyond the 10-year programme. Without a steward, the knowledge base (mentoring curricula, vintage-equipment specs, repair procedures, AI model versions) may become inaccessible or lost after Month 120 (2036-10-12).

**Recommendation**:
By Month 24 (2028-10-12), establish a Digital Knowledge Commons working group to design a public-facing platform (wiki, repository, or open-access archive) for knowledge artifacts: mentoring curricula, vintage-equipment technical specs, repair procedures, AI model versions and provenance, quality-control workflows. By Month 36 (2029-10-12), deploy the platform. By Month 90 (2034-04-12), ensure platform governance and stewardship are handed to a successor institution (university, national library or non-profit heritage body). Budget USD 1M–2M for platform development and 1 FTE knowledge manager throughout the programme.

## 6. No explicit environmental sustainability or end-of-life recycling plan for 30 containers, 300–500 vintage machines and consumables at programme closure.

The plan does not address what happens to the containerized units, vintage equipment, and hazardous consumables (baking-oven internals, solvents, electronics) after Month 120 (2036-10-12). Without a documented end-of-life plan, these assets may be landfilled (environmental violation), stored indefinitely (cost burden), or transferred without proper documentation (liability exposure).

**Recommendation**:
By Month 12 (2027-10-12), develop an Equipment Sunset and Recycling Plan specifying: (a) which units are retained for ongoing deployment (if any); (b) which are transferred to universities or archives with maintenance commitments; (c) which are decommissioned, with certified e-waste recycling and hazmat disposal protocols; (d) which vintage machines are donated to makers-spaces or museums (with condition assessment and liability waivers). By Month 60 (2031-10-12), identify receiving institutions and obtain written commitments. Budget USD 500K–1.5M for decommissioning, recycling and responsible equipment transfer.

---

# Potential Improvements

## 1. Clarify and reconcile the staffing model and operating-expense budget at Phase 1 scale before pilot design freezes.

The plan allocates 50–60 staff per active MIU and USD 2–3M annual opex per unit. Recomputation suggests payroll alone at USD 50–70K per staff member equals USD 2.5–4.2M per unit-year, leaving USD 0–0.7M for all other costs (equipment, parts, logistics, utilities). At face value, either staffing or budget assumptions are unfeasible. Without clarity by Month 4 (2027-02-12), Phase 2 commitments rest on a cost model that will fail.

**Recommendation**:
By Month 1 (2026-11-12), commission an independent operational cost audit of one active broadcast or archive digitization operation (e.g. Indiana University MDPI, Library of Congress Packard Campus) to benchmark salaries, loaded costs and opex per unit-year in comparable settings. By Month 2 (2026-12-12), restate the CDDIN budget with itemized line-item detail: salaries (by role), benefits and taxes, travel and visa, equipment and parts, consumables, utilities, satellite/fiber, insurance, overhead. Model three staffing scenarios (50–60, 35–40, 20–25 per unit) and show cost per scenario. By Month 4 (2027-02-12), lock the staffing and budget model; if reconciliation requires <25 staff per unit, adjust Months 24–120 (2028-10-12 to 2036-10-12) headcount planning accordingly or increase the budget cap.

## 2. Establish explicit success gates and decision criteria before Phase 1 operations begin, reducing ambiguity in gate releases.

The plan lists success metrics (>95% digitization, >80% accuracy, <20% review, >90% uptime) but does not define what 'sustained' means (3 months? 6 months?), how many sites must achieve it (2? 3?), or what constitutes a gate-release decision vs. a rework scenario. Ambiguous gates delay Phase 2 release and create funder disputes.

**Recommendation**:
By Month 1 (2026-11-12), convene the Programme Board and publish a Phase 1 Gate Release Charter specifying: (a) metrics (>95% digitization success = zero unrecoverable items in a batch of 1,000+; >80% reconstruction accuracy = third-party sampling comparison; <20% review = actual flagging rate measured over 3+ months; >90% uptime = trailing 6-month measurement); (b) duration (all metrics held for ≥3 consecutive months); (c) sites (≥2 different archives); (d) variance tolerance (±5% acceptable, >10% triggers rework assessment); (e) override rule (best-efforts at ≥80% of targets allows conditional tranche, not full release). Obtain written board approval and publish publicly by Month 3 (2027-01-12).

## 3. Create a dedicated Funder Engagement and Commitment Registry to track pledge-to-commitment conversion and identify funding gaps early.

The plan lists 15+ funders (government, philanthropic, technology sector) with pledged amounts but no registry tracking which pledges are binding committed contracts vs. best-effort statements. Without visibility into commitment status, programme leadership cannot assess cash flow risk or identify contingency sources early enough to avoid gate delays.

**Recommendation**:
By Month 1 (2026-11-12), establish a Funding Commitment Registry with entries for each funder: organization name, pledged amount, commitment status (pledged, intent-to-commit, committed with conditions, fully committed), expected release schedule (annual tranches?), contingency conditions (gates, milestones, variance limits). By Month 2 (2026-12-12), conduct outreach to each funder to convert pledges into binding contracts by Month 3 (2027-01-12). Target ≥50% (USD 30M) of Phase 1 committed. For unresolved pledges, identify 2–3 backup funders or a USD 15–20M bridge-credit line. Update registry monthly.

## 4. Define and document the Remote Diagnostics and Expert Routing system architecture before central operations begins.

The plan mentions remote expert guidance and central operations but does not specify how a field crew accesses a retired-engineer mentor for a tape-deck azimuth problem, how priority is assigned (which expert? how fast?), or what happens if the mentor is unavailable. Ad-hoc expert routing will delay repairs and create uptime variance.

**Recommendation**:
By Month 3 (2027-01-12), design the Remote Diagnostics architecture: (a) field crew logs a failure (equipment type, symptom, troubleshooting steps taken) via a mobile app or secure web form with photos; (b) automated triage routes to the appropriate specialist (retired-engineer mentor for legacy deck, parts engineer for fabrication, AI specialist for signal issues); (c) specialist responds within 4 hours with phone/video guidance or a parts recommendation; (d) escalation after 24 hours to Central Operations and Fleet Management Officer if unresolved. Build a simple ticketing system (open-source or cloud-based) and test with the first pilot. Budget USD 200K–300K for remote-diagnostics software and training.

## 5. Introduce a formal change-control and design-review process for containerized unit architecture before Phase 2 procurement.

The plan does not specify how design changes (e.g. upgraded climate control, reinforced robotic arm) are reviewed, tested and approved before being replicated into 12 Phase 2 units. Without formal design governance, unproven changes risk cascading rework across the fleet at cost and schedule penalty.

**Recommendation**:
By Month 4 (2027-02-12), establish a Design Review Gate (DRG) process: every material change to the MIU (container retrofit, equipment selection, software upgrade, control logic) must be reviewed by an independent panel (2–3 subject-matter experts from the mentor pool and engineering team) before design freeze. Changes are approved, rejected, or requested for testing. Design freeze for Phase 2 units occurs by Month 20 (2028-06-12), allowing 4 months for long-lead procurement. Changes identified after freeze are documented as 'Phase 2.1' rework and flagged for Phase 3 incorporation, not mid-Phase 2 retrofit. Publish change log monthly.

## 6. Establish a working group to define and enforce data-format standards for preservation masters and derivatives across all units.

The plan does not specify what preservation master formats are required (raw wideband for tape? lossless codec?), what access derivatives are created (MP3? JPEG2000?), or how formats are versioned and migrated over decades. Inconsistent formats across 30 units create archive integration headaches and risk format-obsolescence lock-in.

**Recommendation**:
By Month 6 (2027-04-12), establish a Data Format Standards Working Group (archivists, signal-processing engineers, preservation community liaisons) to publish preservation-format specifications for each line type (Tape, Film, Card). Specify master format (e.g. FLAC or uncompressed WAV for audio, TIFF or DPX for film, text or PDF for cards), metadata schema (Dublin Core or equivalent), access-derivative formats and transcoding rules. Test formats on all 3 pilot units. By Month 12 (2027-10-12), publish the standard and enforce it fleet-wide. Reserve USD 500K for format research and validation.

## 7. Create a Site Readiness Scorecard and Pre-Deployment Checklist to reduce ad-hoc delays and ensure consistent site preparation.

The plan mentions site readiness but does not specify what 'ready' means: power capacity, hardstand condition, fire-authority approval, insurer letter, staff liaison, security access? Without a standard scorecard, deployments are delayed by missing preconditions that could have been identified months in advance.

**Recommendation**:
By Month 2 (2026-12-12), develop a Site Readiness Scorecard with mandatory criteria: (a) power (208–240V, ≥200 kW stable or generator backup); (b) hardstand (level concrete, ≥50m × 15m); (c) security (perimeter fence or guard, access control); (d) fire-authority written approval of pre-treatment hazards; (e) insurer letter confirming on-site coverage; (f) staff liaison identified and trained; (g) data connectivity (fiber or satellite ≥10 Mbps). Each criterion is scored ready/not-ready/in-progress. Begin readiness coordination 6 months before scheduled unit arrival. A unit is dispatched only when all criteria are ready. Publish scorecard status monthly. Budget 1–2 FTE for Site Readiness Coordinator.

## 8. Define escalation thresholds and governance triggers for cost overruns, schedule slips and technical failures.

The plan identifies risks but does not specify at what variance a decision escalates to the Programme Board (5%? 10%? 20%?) or what actions result (pause, rework, governance re-assessment, go/no-go). Without clear triggers, cost and schedule variances accumulate silently until a crisis forces an emergency meeting.

**Recommendation**:
By Month 2 (2026-12-12), publish an Escalation and Governance Triggers Document specifying: (a) cumulative overspend >10% on any phase → halt that phase and conduct cost audit; (b) schedule slip >4 weeks → convene schedule-recovery task force; (c) uptime <90% for 2 consecutive months → root-cause investigation and corrective action required before continued operations; (d) any AI metric (precision, recall, flagging) outside acceptable range → governance decision on model retraining or workflow redesign; (e) two or more similar equipment failures across the fleet → design-review investigation. Establish a monthly Variance Review meeting (Programme Director, financial officer, technical lead) reporting to the Programme Board quarterly. Budget for monthly cost and schedule tracking.

## 9. Develop a supplier and vendor management strategy for 300–500 vintage machines, parts, and 3D-printing services.

The plan sources vintage equipment from eBay, auctions and decommissioned facilities but does not name suppliers, negotiate volume discounts, or document procurement procedures. Without a supplier strategy, acquisitions are reactive and inefficient, and critical parts may become unavailable if a key supplier exits.

**Recommendation**:
By Month 2 (2026-12-12), establish a Vintage Equipment Procurement Team tasked with: (a) mapping major decommissioned broadcast and film equipment suppliers (auctions, facility closures, salvage yards) in North America and Europe; (b) negotiating volume commitments (target 300–500 units at average USD 3–5K per deck/scanner); (c) documenting condition assessment and parts-harvest protocols; (d) establishing relationships with 2–3 specialist 3D-printing and CNC shops for precision-parts fabrication. By Month 4 (2027-02-12), secure written agreements with top-3 suppliers and begin acquisition. Track inventory and supplier reliability monthly. Budget USD 500K–1M for procurement coordination and supplier relationship management.