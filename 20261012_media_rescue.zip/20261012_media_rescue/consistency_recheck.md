_Consistency: first pass found 3 high / 6 medium / 1 low contradictions. Repair: round 1: 51 edits → 0 high / 9 medium. Shown below: the final check of the repaired documents (0 high / 9 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are at least 50% of Phase 1 funds (USD 30M of USD 60M) committed by binding contract, not pledged, by Month 3? | Committed (not pledged) Phase 1 funds >= USD 30M at Month 3 (proposed threshold); Funding Commitment Registry set up by Month 1; USD 15-20M bridge facility pre-qualified by Month 3. | Funding Commitment Registry showing executed multi-year contracts and milestone-release conditions; bridge facility term sheet; both at Month 3. | Delay: freeze long-lead procurement and hiring beyond the three pilots, draw only contingency under Board signature, and re-scope Phase 1 to the committed amount. Do not start pilot container assembly. |
| 2 | Does the independent cost audit give a funded path to at least 24 units, with the staffing model and capex financing for Phases 2-3 locked? | Reconciled cost within the USD 250M cap or funded by identified sources; fewer than 24 units fundable (a >20% unit reduction) or cumulative variance >10% overspend triggers governance re-assessment; staffing model fixed (50-60 per unit vs ~25 budget-consistent). | Audit findings, three escalation scenarios (22% / 34% / 48% cumulative) and the written decision on who finances MIU capex, published at Month 4. | Downsize or split: re-baseline to the funded scope (about 14 unit-equivalents at the cap), or run pilots only with Phase 2 conditional on new cost-share or funder commitments. Halt Phase 1 procurement until staffing is signed off. |
| 3 | Does the validated parts-depletion model show spares and mentors can sustain >90% uptime at the funded unit count? | At least 6 retired-engineer mentors contracted (min 2 per line type) by Month 1; validated model at Month 4-5 shows spares above the 50% re-manufacture trigger before Month 60 and not exhausted before Month 100; fabricated parts hold azimuth +/-0.05 mm. | Provisional model at Month 2; bench test of 10 reference decks (8-12 weeks), 3D-print tolerance results and signed mentor contracts, validated model at Month 4-5. | Downsize or delay: cap unit builds at what spares support, budget the USD 15-25M emergency stockpile refresh (estimate) explicitly, or pivot to a vendor-operated model if spares are exhausted before Month 100. |
| 4 | Is there written insurer and fire-authority approval at one pilot site and are three host agreements signed on terms the programme can honour by Month 6? | At least 1 written approval and 3 signed multi-year host agreements by Month 6 (no exclusivity or training-data terms); stop rule: fewer than 2 agreements, or no approved pre-treatment design, by Month 9. | Insurer and fire-authority letters, signed source agreements with tiered indemnity, pooled loss reserve funded, Month 6; customs pathway documented by Month 4. | Delay and redesign: activate the detached pre-treatment pod (USD 0.5-1.5M each, +4-6 weeks per site) and re-baseline pilot dates. If still unapproved at Month 9, cancel on-site pre-treatment or halt the pilot build and redesign the partnership model. |
| 5 | Does AI pre-screening meet its accuracy and review-load thresholds on real degraded, multilingual samples? | Precision and recall >=75% per category-format; flagging <=25% (20% hypothesis); review hours per content hour <=0.5; privacy false-negative rate <5%. Below 75% -> retrain; <70% after retraining -> governance re-assessment; >30% flagging -> redesign review workflow. | Labelled 100-200 sample test (Month 4) and pilot review pod results on live content (Month 8), reported by format, language and degradation level. | Delay the Phase 2 design freeze (Month 20) and re-baseline crew composition (21-30 reviewers per unit at 35-40% flagging, estimate). Any reportable privacy incident suspends uploads and triggers governance review. |
| 6 | Do the pilots meet every Phase 1 to Phase 2 gate threshold for at least 3 consecutive months on at least 2 host sites, with at least 70% of Phase 2 funds (USD 84M) committed? | Digitization success >95%, reconstruction >80%, metadata >70%, human review <20%, uptime >90%, precision/recall >=75%, zero privacy/legal incidents, cumulative variance <=10%, >=USD 84M of Phase 2 committed before Phase 2 starts. | Evidence package compiled at Month 22 with third-party audit sampling; Board vote at Month 24; commitment registry. | Hold the Phase 2 tranche (no full override). At >=80% of targets with flagging <=25%, a conditional limited tranche with governance approval is allowed. Otherwise rework or reduce to the funded unit count; design rework costs USD 2-5M and 6-9 months. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: project plan goal statement; executive summary; pitch overview
    canonical: cap_affordable_scale = At USD 250M the plan's costs support ~47% of scope: ~14 unit-equivalents, ~1.7M items, ~95 PB (estimate)
    observed:  3.6M+ items and 200+ PB via 30 units "within the USD 250M cap"
HIGH CF-002  document: review plan Review 13; self-audit item 6; premortem FM1
    canonical: phase2_first_unit_timing = First Phase 2 unit operational at Month 28; Phase 2 released at Month 24 gate
    observed:  Phase 2 unit orders gated at Month 20 design freeze; USD 84M commitment tested at Month 20
HIGH CF-003  document: self-audit item 5 / canonical pilot_schedule
    canonical: pilot_schedule = First pilot retrofitted Month 5, operating Month 6; units 2-3 by about Month 9-12
    observed:  containers 12-18 months, robotics 16+ weeks lead time
MEDIUM CF-004  document: review plan Review 5, Review 9, Review 15
    canonical: required_throughput = ~15,600 items per unit-year through Month 60; ~24,000 (~2,000/unit-month) in Phase 3 (estimate)
    observed:  420K-630K items deferred; 50K-150K items per month per unit; 5-10 units offline at 10-15% downtime
MEDIUM CF-005  document: review plan Review 10, 11, 14
    canonical: opex_per_unit_year = USD 2-3M per active MIU-year; planning value USD 2.5M
    observed:  opex rising to USD 3.5-4.0M if 15-25% in-kind is unavailable
MEDIUM CF-006  document: executive summary / review plan Review 8
    canonical: pilot_schedule = 3 archive agreements signed by Month 6
    observed:  samples from three pilot archives by Month 2
MEDIUM CF-007  document: self-audit items 2 and 9
    canonical: parts_and_mentor_milestones = Parts-depletion model by Month 2 (provisional; validated Month 4-5 per reconciled schedule)
    observed:  MTBF and fabrication tolerance "locked by Month 2"; everything "locked by Month 4"
MEDIUM CF-008  document: self-audit items 4, 10, 16
    canonical: fallback_detached_pod = Detached pre-treatment pod USD 0.5-1.5M each, +4-6 weeks per site
    observed:  approval denied by Month 9 -> detached pod fallback triggers
MEDIUM CF-009  document: pitch
    canonical: end_state_milestones = End-state working group Month 12; transition plan Month 36; successor bodies Month 48
    observed:  "Recovered masters are held ... under federated custody"; "transferred to a successor body ... that retains core units"
MEDIUM CF-010  document: review plan Reviews 2, 3, 5, 12, 13; premortem FM1; self-audit items 6, 20; pitch
    canonical: end_state_milestones = Working group Month 12; transition plan Month 36; bridge facility by Month 3; Phase 3 slip Month 66-72
    observed:  stewardship commitment Month 4 / funding source Month 48; bridge facility Month 2; Phase 3 start Month 66-75; 15 units by Month 120
MEDIUM CF-011  document: review plan Reviews 7 and 10; self-audit items 6, 15; executive summary Overall Takeaway
    canonical: funding_gap_and_source = Unfunded gap ~USD 280M before contingency; Phase 3 gap ~USD 301M (estimate)
    observed:  "USD 280M Phase 3 gap"; "22% budget-to-cost mismatch"; "USD 3-5K each, total USD 20M"
```

### 1. Headline scope stated within the cap vs what the cap can fund (🔴 High) — needs a project decision

- **Project plan goal statement; executive summary Purpose and Goals; pitch overview:** Goal: build 30 MIUs and deliver 3.6M+ items and 200+ PB "within the USD 250M cap".
- **Project plan Achievable; review plan Review 1; self-audit items 3, 7; premortem FM1:** Cap supports ~47% of scope (~14 unit-equivalents, ~1.7M items, ~95 PB); uncapped cost ~USD 530M; unfunded gap ~USD 280M with no committed source. NO-GO triggers (only ~14 units fundable; fewer than 24 units) are already met on these numbers.
- **Why it conflicts:** The target is framed as achievable inside the cap while the same documents show it is about half-funded and that the stated stop conditions are already tripped. Phase 3 capex financing for the 15 final MIUs is also unassigned.
- **Suggested resolution:** State the funded scope (~14 unit-equivalents) as the baseline commitment and show 30 units / 3.6M items as conditional on closing the gap. The decision options are: (a) host or consortium cash cost-share per MIU, (b) new government or consortium funders, (c) rights-holder-approved technology-sector funding, (d) reduced unit count or crew size. The project decision is who finances Phase 2-3 MIU capex (USD 105M at midpoint) and whether the Month 4 lock proceeds at reduced scope.

### 2. Phase 2 long-lead orders before the Phase 2 gate (🔴 High) — needs a project decision

- **Review plan Review 13 item 1 and item 3; project plan/assumptions (design freeze Month 20); premortem FM1 tripwire; self-audit item 6:** Phase 2 designs are frozen "non-negotiably" at Month 20, which "gates Phase 2 unit orders", with 4 months of long-lead procurement and the first Phase 2 unit at Month 28. The >=70% (USD 84M) commitment test is set at Month 20.
- **Canonical phase1_to_2_gate and gate_override_rule; pitch Stakeholder Benefits; review plan Review 15 item 1:** Phase 2 is released only at the Month 24 gate on >=3 months of evidence; "no full override of gates"; canonical commitment threshold applies "before each phase starts". Review 15 tests USD 84M at Month 24.
- **Why it conflicts:** Orders placed at Month 20 commit Phase 2 capex before the gate evidence package exists (compiled at Month 22, decided at Month 24). This is either at-risk spending that weakens the no-override claim, or the Month 28 first-unit date is unattainable if orders wait for Month 24.
- **Suggested resolution:** Decide explicitly: (a) permit limited, capped at-risk long-lead deposits before the gate (state amount and source, e.g. Phase 1 contingency or bridge facility); (b) wait for the Month 24 release and move the first Phase 2 unit later; or (c) use the conditional limited tranche allowed at >=80% of targets. Align the USD 84M test date (Month 20 early-warning vs Month 24 binding).

### 3. First pilot at Month 6 vs stated long-lead procurement times (🔴 High) — needs a project decision

- **Canonical pilot_schedule; executive summary Action Orientation; review plan Review 13 item 3:** First pilot retrofitted by Month 5 and operating Month 6; Phase 1 design locked and budget/staffing locked Month 4; >=50% of Phase 1 committed by Month 3 before procurement begins; container assembly Month 4-5.
- **Self-audit item 5:** "Long-lead procurement (containers 12-18 months, equipment TBD, robotics 16+ weeks) is untethered to firm supplier commitments".
- **Why it conflicts:** Robotics ordered after the Month 3-4 commitment and design lock (16+ weeks) arrives about Month 8, and 12-18 month container lead times cannot support operation at Month 6. The pilot evidence window (Months 6-20) and the Phase 2 gate depend on this date.
- **Suggested resolution:** Either (a) confirm which items truly have long lead times and place LOIs or capped pre-orders at Month 1 (as the self-audit proposes), with a decision on who bears the risk before funding is committed; or (b) re-baseline pilot start and the Months 6-20 evidence window. Do not keep Month 6 and the 12-18 month figure together.

### 4. Items-deferred and downtime figures do not follow from throughput (🟡 Medium)

- **Review plan Review 5 items 2-3, Review 9 item 1, Review 15 item 1:** A 4-9 month Phase 2 slip and 2-3 fewer sites defers 420K-630K items; 10-15% downtime means 5-10 units offline; ~50K-150K items per month lost (per delayed unit).
- **Canonical required_throughput and data_volume_target; review plan Review 6 KPI 1; premortem A9:** Throughput is ~15,600 items per unit-year through Month 60 and ~24,000 (~2,000 per unit-month) in Phase 3; 500 TB is ~9K items at ~56 GB per item; >90% uptime means at most 3 of 30 units offline; Phase 2 target is only 500K items cumulative.
- **Why it conflicts:** 10-15% of 30 units is 3-4.5 units, not 5-10. One unit produces ~2,000 items per month, so 50K-150K items per month per unit is ~25-75x too high. A 4-9 month slip of 12 units defers roughly 60-140K items (estimate), not 420K-630K, which exceeds the whole Phase 2 target. Site-loss figures also imply ~120K items per residency against 6-12 month residencies of ~8-24K items.
- **Suggested resolution:** Recompute all deferred-item figures from ~15,600 and ~24,000 items per unit-year and unit-months lost; correct 10-15% downtime to 3-4.5 units. State whether archives host multiple successive residencies (159.5 unit-years implies far more than 30 residencies) before quoting per-site losses.

### 5. Host in-kind value vs stated opex increase (🟡 Medium)

- **Review plan Review 10 item 3, Review 11 item 3, Review 14 item 2:** Host in-kind contribution is 15-25% of opex per unit (USD 0.375-0.625M per unit-year, USD 60-100M over ~160 unit-years).
- **Same sections:** If in-kind is unavailable, programme opex must rise from USD 2.5M to USD 3.5-4.0M per unit-year (+USD 1.0-1.5M), adding USD 160-240M and lifting the Phase 3 gap to USD 460-540M.
- **Why it conflicts:** Losing a 15-25% share costs USD 0.375-0.625M per unit-year, not USD 1.0-1.5M; the stated USD 160-240M increase is 2-3x the stated in-kind value of USD 60-100M. One of the two figures is wrong.
- **Suggested resolution:** Keep the 15-25% share and the USD 60-100M value and restate the downside as USD 2.875-3.125M per unit-year (about USD 60-100M more, estimate); or, if USD 3.5-4.0M is the real full cost, re-derive the in-kind share as ~USD 1.0-1.5M per unit-year (~40-60% of USD 2.5M) and say so.

### 6. AI validation samples needed before the agreements that permit them (🟡 Medium)

- **Executive summary Month 2 action; review plan Review 8 item 1, Review 10 item 2; self-audit items 2, 4:** Procure 100-200 samples from the three pilot archives by Month 2 and build a labelled gold-standard dataset with 3-5 experts by Month 4.
- **Executive summary Months 3 and 6; canonical pilot_schedule; premortem A6:** Standardized Source-Agreement Addendum and Privacy Review Panel locked at Month 3; the three pilot host agreements are signed at Month 6.
- **Why it conflicts:** Real archive content (including PII) is sampled and labelled before the privacy framework and host agreements that govern its handling exist, and before hosts are committed.
- **Suggested resolution:** Add an explicit interim sample-loan or evaluation agreement under a privacy protocol at Month 1-2, or move sampling to after the Month 3 addendum and shift the Month 4 labelled-dataset date. State which.

### 7. Self-audit claims validation earlier than the plan's schedule (🟡 Medium)

- **Self-audit items 2 and 9:** Item 2: parts-depletion model, MTBF and fabrication tolerance "must be locked by Month 2". Item 9: AI accuracy, parts tolerance, crew composition, insurer approval and cost reconciliation "are all locked by Month 4"; no subsystem deferred.
- **Self-audit item 10; review plan Review 13; premortem FM2, A3, A4:** Provisional model at Month 2, validated at Month 4-5 (item 10 itself: "validated Month 4"); insurer approval Month 6; AI pilot results Month 8; Phase 2 design frozen Month 20.
- **Why it conflicts:** The same document rates these items High because they remain unvalidated, and gives dates up to Month 8, while item 9 claims they are locked by Month 4 and rates the risk Low.
- **Suggested resolution:** Use "provisional Month 2, validated Month 4-5" for parts; insurer approval Month 6; AI Month 8. Rewrite item 9 as: interface contracts and acceptance tests specified by Month 4, validation evidence arriving Months 4-8.

### 8. Insurer/fire-authority failure at Month 9: different consequences (🟡 Medium)

- **Self-audit items 4, 10, 16:** No approval by Month 9 triggers the detached-pod fallback (item 10); or halts all new deployments and re-assesses (items 4 and Global Gate B); or escalates to governance and considers a vendor-operated model (item 16).
- **Premortem FM4 stop rule; canonical fallback_detached_pod; self-audit item 16 (pod approval by Month 8):** No insurer and fire authority approves any pre-treatment design by Month 9 means cancel on-site pre-treatment and pivot to host cold-storage deferral or fixed-site labs. Detached pods are the response to a Month 6 miss (USD 0.5-1.5M each, +4-6 weeks per site).
- **Why it conflicts:** A detached pod needs the same approvals; it cannot be the response to a Month 9 failure of all designs. Each document names a different outcome for the same trigger.
- **Suggested resolution:** Sequence: Month 6 miss -> detached-pod redesign (approval by Month 8); Month 9 miss on any design -> premortem FM4 stop rule (cancel on-site pre-treatment, governance re-assessment). Apply uniformly in items 4, 10, 16.

### 9. Pitch states open decisions and unquantified items as settled (🟡 Medium)

- **Pitch Ethical Considerations, Long-term Vision, Stakeholder Benefits, Collaboration:** Every digitized item is gated behind AI pre-screening and human review; masters held under federated custody with two verified copies; parts warehouse "is transferred" to a successor body that "retains core units"; archives get "phased payment via cost-sharing" and consortium co-funders get joint ownership of fleet and data.
- **Review plan Reviews 3, 9, 11, 14; self-audit items 11, 15; premortem A6; canonical operating_revenue_and_price:** Human review covers flagged items only (~20% flagging hypothesis); custody model, end state and successor body are open decisions (to Month 36); cost-share per MIU is unquantified; fleet ownership is undecided; no tariff is set; host-held masters and no exclusivity are assumed.
- **Why it conflicts:** Items the other documents list as open assumptions or future milestones are written in the pitch as accomplished design facts, and "every digitized item" contradicts flagged-only review with sampled audit.
- **Suggested resolution:** Edit the pitch to say "every flagged item (with sampled audit)", and mark custody model, successor body, cost-sharing and ownership as proposed or subject to the Month 36 and Month 48 decisions.

### 10. Same milestones with different months or garbled labels (🟡 Medium)

- **Review plan Reviews 2, 3, 5, 12, 13; premortem FM1; self-audit items 6, 20; pitch Long-term Vision:** Stewardship commitment from >=1 national archive by Month 4 and funding source by Month 36 (Review 3 item 3), or by Month 36 and Month 48 (Review 2 item 3); bridge facility pre-qualified by Month 2 (Review 5, Review 13, self-audit item 6); cost audit "delivered" by Month 1 (premortem FM1); Phase 3 slip to Month 66-75; Phase 2 start slip Month 28-33 for a 3-6 month delay; "15 units by Month 120" in the baseline scenario (self-audit item 20); pitch label "Month 120, 30 (2036-10-12, 2029-04-12)".
- **Executive summary; canonical end_state_milestones, debt_and_bridge_financing, fallback_design_rework, fleet_ramp_units:** Stewardship commitment and funding mechanism by Month 36 (executive summary, Review 14, pitch); working group Month 12; bridge facility by Month 3; cost audit commissioned Month 1 with findings Month 4; Phase 3 slip to Month 66-72; first Phase 2 unit Month 28 and rework Months 34-37; 15 units by Month 60 and 30 by Month 120.
- **Why it conflicts:** The stewardship commitment cannot precede the working group that is to define it; bridge facility trigger and date differ across documents; slip arithmetic does not match the premise (3-6 months becomes 4-9; Month 66-75 compresses Phase 3 to 45-54 months, not 45-51); the baseline scenario shows half the 30-unit target.
- **Suggested resolution:** Keep Month 36 for stewardship commitment and funding mechanism, Month 3 for the bridge facility (one draw trigger: Phase 2 gate delay >8 weeks), cost audit commissioned Month 1 and findings Month 4, Phase 3 slip Month 66-72, rework Months 34-37, baseline 30 units by Month 120; clean up garbled labels.

### 11. Perpetual-storage cost attributed to optional wideband retention (🟡 Medium)

- **Self-audit item 12:** Wideband retention multiplies storage 3-10x per item and is credited with the USD 600M-1B perpetual-storage liability ("estimated cost ~USD 600M-1B for perpetual wideband storage").
- **Executive summary Risk 4; review plan Review 2 item 3, Review 14 item 1; self-audit items 6, 15:** The USD 600M-1B over 20 years is the liability for the baseline 200+ PB recovered masters, unbudgeted after Month 120.
- **Why it conflicts:** The same figure is the whole baseline obligation in most documents and the cost of the optional wideband feature in item 12. Both cannot be true, and the benefit case for wideband depends on its incremental cost.
- **Suggested resolution:** Treat USD 600M-1B as the baseline liability for 200+ PB. In item 12, require a separately computed incremental cost of wideband retention (estimate) and clarify whether the 200+ PB target already includes wideband data.

### 12. Gap sizing labels and line-item arithmetic (🟡 Medium)

- **Review plan Review 7 item 3, Review 10 item 1; self-audit items 6, 15; executive summary Overall Takeaway:** "Quantifying the USD 280M Phase 3 gap"; "close the ~USD 280M Phase 3 gap"; a "22% budget-to-cost mismatch"; equipment at USD 3-5K each for 300-500 decks, "total USD 20M".
- **Canonical funding_gap_and_source, phase_fit_vs_budget, cap_affordable_scale, phase1_equipment_and_training_budget; project plan Key Risks:** Total unfunded gap is ~USD 280M (~USD 304M with contingency); Phase 3 gap is ~USD 301M; the cap covers ~47% of cost (shortfall ~53%); the USD 20M line is for machines plus parts inventory.
- **Why it conflicts:** USD 280M is the total gap and USD 301M the Phase 3 gap; the two are used interchangeably. A 22% mismatch contradicts ~47% coverage. 300-500 machines at USD 3-5K come to USD 0.9-2.5M, not USD 20M.
- **Suggested resolution:** Label USD 280M as the total unfunded gap and USD 301M as Phase 3 gap; replace "22% mismatch" with "cap covers ~47% of cost"; in Review 10 state that the USD 20M includes parts inventory, refurbishment and warehousing, or restate the unit price.

## Summary

The plan is largely reconciled on its core arithmetic: cost of about USD 530M against the USD 250M cap, payroll of USD 75-126M, the 22% / 34% / 48% escalation cases, Phase 3 affordability, and the AI-review multiple (21-30 reviewers per unit) now agree across documents. The main remaining problems are structural. The headline scope is still presented as achievable within the cap although the plan's own NO-GO triggers are already met. Phase 2 long-lead orders and pilot lead times conflict with the gate and the Month 6 pilot schedule. Several downstream figures (items deferred, downtime, in-kind value, milestone months, wideband cost attribution) still do not follow from the canonical throughput, opex and milestone values. Most are repairable text fixes; three need a project decision (funded scope/capex financing, at-risk long-lead procurement, pilot lead-time handling).