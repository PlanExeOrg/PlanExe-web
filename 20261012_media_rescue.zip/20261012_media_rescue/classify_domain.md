**Primary domain:** Media Preservation

**Secondary domains:** Audiovisual Digitization Engineering, Legacy Equipment Maintenance, Archival Science

**Rationale:** Media Preservation is the only outcome-role candidate and owns the main success criterion of recovering degrading 1950-2000 media. Audiovisual Digitization Engineering, Mobile Container Engineering and the remaining candidates are methods, constraints or stakeholders serving that goal.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Media Preservation | 5 | 5 | outcome | Core goal is digitizing degrading magnetic tape, film and card media for heritage preservation. |
| Audiovisual Digitization Engineering | 5 | 5 | method | Containerized tape, film and card digitization lines with robotic loading and pre-treatment. |
| Mobile Container Engineering | 4 | 5 | method | Retrofitting climate-controlled 40-foot containers with power, connectivity, and processing lines is the core deployment mechanism. |
| Digital Signal Restoration | 4 | 5 | method | AI-driven cleaning, error correction and reconstruction of degraded audio, video and data signals. |
| Legacy Equipment Maintenance | 4 | 4 | constraint | Obsolete decks and scanners require parts inventory, cannibalization and retired-engineer knowledge transfer. |
| Archival Science | 4 | 4 | stakeholder | Partner archives define appraisal, metadata, custody, and access-control requirements for the recovered collections. |
| Copyright And Privacy Law | 4 | 4 | constraint | Source agreements, copyright status, PII, and classified-content review gates govern all uploads. |
| Industrial Robotics | 4 | 4 | method | Robotic arms automate media loading into vintage playback equipment inside each container. |
| Digital Preservation Infrastructure | 4 | 4 | method | Petabyte-scale storage, transmission, and distributed archive formats for long-term data access. |