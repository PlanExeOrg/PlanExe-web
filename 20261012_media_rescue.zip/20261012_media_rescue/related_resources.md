## Suggestion 1 - Indiana University Media Digitization and Preservation Initiative (MDPI)

Indiana University set out to digitize roughly 280,000 audio, video and film items across campus collections before playback equipment and media became unusable, a 'degradation clock' deadline around 2020. Work was done at a purpose-built facility using a commercial vendor (Memnon, Brussels) for audio/video transfer, plus in-house engineering, quality control and long-term storage in the Sustainable Archival Repository. Public reports describe the vintage-equipment sustainment, QC and storage challenges. The scale is approximate; confirm with IU.

### Success Metrics

Several hundred thousand items digitized, about 280,000 targeted (approximate, not verified)
Multi-petabyte preservation repository created (approximate)
Completed ahead of or near the 2020 target (not confirmed in detail)
Open-source tooling (Avalon, AVPreserve-style QC workflows) reused by other institutions

### Risks and Challenges Faced

Obsolete playback equipment scarcity: mitigated by vendor-held stockpiles and in-house engineers
Throughput limited by real-time playback: mitigated by parallel transfer lines and 24/7 shifts
QC at scale: mitigated by automated checks plus sampled human review
Perpetual storage cost: mitigated by institutional repository commitment

### Where to Find More Information

Indiana University MDPI project site (mdpi.iu.edu)
Indiana University Libraries and Media Preservation Initiatives publications
Conference papers from AMIA and IASA on MDPI workflow (search by title)

### Actionable Steps

Contact the MDPI program leadership via Indiana University Libraries (Media Preservation Initiatives office) for lessons on parts, QC and vendor contracts
Request an interview with the former MDPI technical or engineering lead via the IU Libraries directory or LinkedIn
Approach Memnon's business development team for vendor-operated model terms

### Rationale for Suggestion

Closest verifiable analogue to the tape line: a mass transfer program on a fixed deadline with vintage deck sustainment, QC regime and perpetual storage. It informs the parts-depletion model, throughput per unit-year and the vendor-versus-owned equipment decision. It is fixed-site, not mobile, so container logistics must come from other sources. US location matches the Northern Virginia hub.
## Suggestion 2 - Library of Congress National Audio-Visual Conservation Center (Packard Campus, Culpeper, VA)

The Packard Campus houses the Library of Congress's audiovisual collections and a large in-house conservation and digitization operation for film, video, audio and recorded sound, built with Packard Humanities Institute funding and opened 2007. It runs engineering labs that maintain legacy playback equipment and process mass-digitization workloads with automated workflows. Approximate scale: millions of items held (not verified).

### Success Metrics

Millions of AV items stored and cataloged (approximate, not verified)
Large-scale digital preservation of film, video, audio with automated workflows
Sustained in-house vintage equipment maintenance for over a decade

### Risks and Challenges Faced

Maintaining obsolete equipment: mitigated by in-house engineering labs and stockpiled spares
Nitrate/unstable film hazards: mitigated by purpose-built vaults and fire-safe design
Funding continuity: mitigated by public-private partnership structure

### Where to Find More Information

Library of Congress Packard Campus pages (loc.gov/avconservation)
National Recording Preservation Plan documents (loc.gov)
Packard Humanities Institute public materials

### Actionable Steps

Contact the Library of Congress Recorded Sound or Moving Image Section, Packard Campus, through its public inquiry channels
Ask for a technical exchange with the engineering lab leads on vintage deck sustainment
Invite the Packard Campus as a pilot host or advisory board member via the Library's partnership office

### Rationale for Suggestion

Provides the best US precedent for hazard-compliant film and tape handling, retained legacy equipment and in-house engineers, and it sits at the proposed Northern Virginia hub, giving access to the talent pool and a candidate pilot host. It is a fixed campus rather than mobile units, so it informs the Fleet Sunset and retained-core options and fire-containment design.
## Suggestion 3 - British Library Unlocking Our Sound Heritage (UOSH)

A UK National Lottery Heritage Fund-supported program (launched 2017, ran to about 2022-2023) led by the British Library with ten regional hubs to digitize roughly 500,000 at-risk sound recordings, build a national audio preservation network, train practitioners and manage rights and privacy in archive collections. It combined a central digitization facility with regional hub capacity and a shared public access platform.

### Success Metrics

Target of about 500,000 recordings digitized across the network (approximate, not verified)
Ten regional hubs established and staffed
Public access portal launched with rights-cleared content
Training of archive staff across the UK

### Risks and Challenges Faced

Rights and data protection in sensitive recordings: mitigated by rights-assessment workflows and restricted access tiers
Distributed quality consistency: mitigated by shared standards and central QC
Skills gaps in obsolete formats: mitigated by training programs
Funding dependency on one grant: mitigated by partner contributions

### Where to Find More Information

British Library project pages (bl.uk, search 'Unlocking Our Sound Heritage')
National Lottery Heritage Fund project records
British Library annual reports and case studies

### Actionable Steps

Contact the British Library Sound and Vision team via the library's collaboration enquiries
Request the UOSH program manager or rights lead for a lessons-learned session
Review published hub model documents before drafting source-agreement templates

### Rationale for Suggestion

Best precedent for a consortium-funded, multi-site, rights-aware preservation network with shared standards and a training pipeline, matching the plan's governance, review-gate and crew-model decisions. UK location matches the proposed South East England hub and UK GDPR constraints. It is audio only and fixed-site, so film and card lines need other references.
## Suggestion 4 - Secondary: Internet Archive Physical Archive and Scribe digitization centers

The Internet Archive operates distributed scanning centers with purpose-built book scanners ('Scribe') and a physical archive storing originals, processing millions of items with standardized workflows and non-profit funding. Secondary suggestion with fewer details: scale and cost figures are not verified.

### Success Metrics

Millions of items digitized (approximate, not verified)
Standardized per-item workflow and cost reduction

### Risks and Challenges Faced

Copyright litigation on lending and access: shows the legal exposure of access decisions
Storage and custody of petabytes: handled with multi-site replication

### Where to Find More Information

archive.org/about
Internet Archive blog and published legal case documents

### Actionable Steps

Contact the Internet Archive's Digitization or Preservation team via its public contact page
Ask about cost-per-item data and distributed scanning-center operations

### Rationale for Suggestion

Secondary reference for non-profit petabyte-scale custody, per-item cost benchmarking and legal exposure from access decisions. It does not cover obsolete AV equipment or mobile deployment.

## Summary

The CDDIN plan combines mobile containerized digitization, vintage AV equipment sustainment, and human-reviewed rights gating. No identical project is documented, so references are analogues: the Library of Congress Packard Campus (industrial-scale AV preservation), the Indiana University MDPI (mass tape digitization with a hard deadline, vintage-deck sustainment and vendor partnership), and the British Library Unlocking Our Sound Heritage (multi-site, national-scale, rights and privacy handling). Secondary: the Internet Archive's Scribe/Physical Archive operations and the Memnon-style vendor model (Memnon was the MDPI vendor). Figures below are approximate or not verified; confirm with the named organizations. Geographic fit is strong for the US and UK hubs; mobile container digitization specifically has few verified precedents, which is stated in each rationale.