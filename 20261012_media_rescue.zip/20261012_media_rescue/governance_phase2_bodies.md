### 1. Programme Board (Strategic Oversight)

**Rationale for Inclusion:** A USD 250M, 10-year, 30-unit global infrastructure programme with 15+ funders, 30+ partner archives, and concentrated risks (vintage hardware scarcity, unvalidated AI assumptions, handling-loss exposure, phased funding on annual cycles) requires executive-level strategic oversight. The Programme Board approves phase releases, resolves funder and archive conflicts, authorizes variance above 10% and gates major decisions (site selection triage, vendor selections, legal indemnity structures, end-state transitions). Without executive governance, routine escalations fragment and funder confidence erodes.

**Responsibilities:**

- Approve Phase 2 and Phase 3 funding releases based on gate evidence (digitization success >95%, uptime >90%, AI accuracy >75%, zero incidents)
- Authorize budget variance, contingency draws and scope changes exceeding USD 5M or affecting unit counts or staffing
- Resolve conflicts between funders, archives and programme staff on site prioritization, indemnity terms and legal/privacy disputes
- Oversee risk register and approve mitigation add-ons or fallback scenarios (detached pods, design rework, stockpile refresh)
- Monitor cost and schedule variance quarterly; escalate >10% variance to governance re-assessment
- Approve source agreements, indemnity tiers and privacy frameworks; delegate to Legal/Privacy Committee for jurisdiction-specific details
- Review and approve pilot gate criteria by Month 6 (2027-04-12) and published gate-decision evidence before phase releases
- Approve end-state plan (unit transfers, parts inventory dispersal, knowledge base stewardship) by Month 36 (2029-10-12)
- Establish and charter all subsidiary committees (Technical, Site Selection, Legal/Privacy, Finance); define escalation paths

**Initial Setup Actions:**

- Establish Board membership: 8-10 representatives from committed funders, 3-4 partner archives (pilot and Phase 2), programme director, chief technical officer, legal counsel
- Publish and agree decision-authority charter: define which decisions require full Board consensus, which delegate to committees or staff, and escalation criteria
- Schedule monthly meetings Month 1-6 (2026-11-12 to 2027-04-12); quarterly thereafter; maintain written decision log and meeting minutes
- Appoint committee chairs by Month 1 (2026-11-12): Technical Committee, Site Selection & Triage, Legal/Privacy & Compliance, Finance & Variance
- Commission independent cost audit, parts-depletion model and legal mapping by Month 1-2 (2026-11-12 to 2026-12-12)

**Membership:**

- Programme Director (Chair)
- Chief Technical Officer / Engineering Lead
- Chief Legal Officer / Data Protection Lead
- Chief Financial Officer or Finance Lead
- Representative of committed government archive funder
- Representative of committed philanthropic funder
- 2-3 partner archive directors (pilot sites)
- Independent external advisor (heritage infrastructure or conservation expertise, no financial interest)

**Decision Rights:** The Board holds all strategic decisions affecting programme scope, timeline, budget allocation above USD 5M, phase gates, funder and archive conflicts, legal/privacy frameworks, vendor selection for capex >USD 10M, risk escalations and end-state planning. Operational decisions (daily scheduling, crew allocation, site logistics) delegate to committees and programme staff. Gate releases require Board approval with 70%+ committed funding (not pledged) in place; gate variance below 10% and all thresholds met allow release; variance 10-20% or <1 threshold missed allows conditional limited tranche with governance approval; variance >20% or >1 critical threshold missed triggers governance re-assessment (potential phase deferral). Financial authority: approve cumulative budget draws per phase (Phase 1 up to USD 60M, Phase 2 up to USD 120M, etc.); approve contingency draws beyond 10% per phase; approve add-on mitigation spending up to USD 10M per proposal.

**Decision Mechanism:** Consensus-seeking on policy decisions; simple majority (6+ of 8-10) on routine approvals and escalations. Tie-breaker: Programme Director casts deciding vote (or escalates to funder steering group if Programme Director vote is recused). Dissenting Board members may request written rationale and alternative options preserved in decision log. Gate releases require explicit Board sign-off (not delegation); no default approval. Decisions requiring <24-hour turnaround (site emergencies, personnel changes) escalated to Board officers (Director, CFO, General Counsel) with full Board ratification within 5 business days.

**Meeting Cadence:** Monthly meetings Month 1-6 (2026-11-12 to 2027-04-12) during pilot mobilization; quarterly (every 3 months) thereafter through Month 120 (2036-10-12). Additional ad-hoc sessions called by Director or request of 3 Board members within 48 hours for urgent escalations. Standing agenda: cost variance and budget reconciliation, phase-gate evidence review, risk register updates, committee reports, funder and archive stakeholder issues, governance decisions and decision log.

**Typical Agenda Items:**

- Monthly/quarterly cost and schedule variance against budget (actuals vs. plan, forecast at completion, confidence range, inflation impact)
- Pilot metrics and gate-decision evidence (digitization success, reconstruction accuracy, human review flagging rate, uptime, AI precision/recall, zero-incident status)
- Equipment and parts-inventory status (depletion curves, re-manufacture triggers, retired-engineer mentorship progress, expertise-transfer curriculum)
- Risk register review: any risks escalated from Technical or Finance committees, threshold breaches, trigger activations
- Site-readiness and archive-engagement updates (fire authority and insurer approvals, signed agreements, triage-driven scheduling, queue management)
- Legal, privacy and compliance status (source agreements signed, jurisdiction-specific frameworks approved, privacy-review panel decisions, data residency conflicts)
- Funder and stakeholder escalations (conflicting prioritizations, cost-share negotiations, Phase 2/3 commitment status, governance requests)
- Phase-gate decision topics (proposed release criteria, evidence completeness, go/no-go recommendation from Technical and Finance committees)

**Escalation Path:** Decisions requiring recusal (e.g., funder representative voting on their own funder terms) escalate to a Funder Steering Committee (representatives of non-recused funders) to re-adjudicate; final authority rests with Funder Steering Committee or a neutral external arbitrator if stakes exceed USD 10M. Decisions affecting source agreements or privacy compliance escalate to Legal/Privacy Committee for jurisdictional analysis and only return to Board if Committee is deadlocked or outcome affects >3 archives. Decisions affecting equipment design or pilot gates escalate to Technical Committee; Board may overrule Committee only with 80%+ supermajority (7 of 8-10). Unresolved funder conflicts may trigger external mediation funded by the programme (up to USD 100K per incident).
### 2. Technical Committee (Operational & Design Assurance)

**Rationale for Inclusion:** The programme depends on three distinct container line types, pre-treatment hazards (baking, humidity), robotics, AI signal processing, vintage equipment sustainment and multi-site reliability. Unvalidated design assumptions (>95% digitization success, >80% reconstruction accuracy, >75% AI pre-screen precision/recall, >90% uptime) must be tested in pilots before Phase 2 replication. A dedicated Technical Committee oversees design freeze by Month 20 (2028-06-12), pilot validation and gate readiness. It owns the parts-depletion model, equipment refresh strategy and remote-diagnostics architecture. Critical design flaws discovered post-freeze (e.g., thermal management inadequate for hot climates, robotic arm tolerance drift) could force USD 2-5M rework and 6-9 month delays if not caught early.

**Responsibilities:**

- Oversee design of all three MIU line types (Tape, Film, Card/Disk) and subsystems (climate, power, robotics, AI, on-board storage, connectivity)
- Commission and review independent technical assessments (thermal, mechanical, electrical, AI validation) on pilot units by Month 8-12 (2027-06-12 to 2027-10-12)
- Manage Design Review Gate (DRG) process: freeze all designs by Month 20 (2028-06-12); any post-freeze changes require board approval and impact analysis
- Oversee parts-depletion modeling and spares-fabrication program; validate 3D-printing and CNC machining capability on 20+ critical parts by Month 6 (2027-04-12)
- Manage retired-engineer mentoring program: track curriculum completeness, mentee competency assessments, knowledge-transfer documentation
- Establish and operate central fleet-management telemetry and remote-diagnostics system; set uptime targets and alarm thresholds; monitor actual uptime monthly
- Test AI pre-screening and signal-reconstruction models on 100-200 real degraded samples per archive before deployment; validate precision/recall >=75% per format-category
- Oversee pilot-unit stress testing at worst-condition collection; document failure modes and root causes
- Recommend Phase 2 and Phase 3 gate outcomes to Programme Board based on pilot evidence against all technical thresholds

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief technical officer (chair), hardware engineer (tape/film/card specialist), roboticist, AI systems lead, parts and maintenance lead
- Publish preliminary design specifications for all three line types by Month 2 (2026-12-12); commission external review (e.g., university or broadcast-engineering consultant) by Month 3 (2027-01-12)
- Establish DRG process document by Month 2 (2026-12-12): criteria for sign-off, escalation triggers, change-control procedures
- Commission parts-depletion model and feasibility study by Month 2 (2026-12-12); publish preliminary results by Month 4 (2027-02-12)
- Identify and secure commitments from 6-8 retired engineers for mentoring by Month 1 (2026-11-12); begin curriculum development by Month 2 (2026-12-12)
- Procure test samples (100-200 items) from proposed pilot archives by Month 2 (2026-12-12); establish gold-standard labeling and AI test protocol by Month 3 (2027-01-12)

**Membership:**

- Chief Technical Officer (Chair)
- Audiovisual Digitization Engineering Lead (tape/film/card specialist with broadcast or archival background)
- Vintage Equipment Maintenance Engineer (experienced with tape decks and film scanners)
- Robotics and Automation Specialist
- AI / Signal Processing Lead (with experience on degraded audio/video content)
- Digital Infrastructure and Storage Specialist
- Independent external technical expert (broadcast engineering, media preservation or mobile-infrastructure background, non-staff)
- Representative of retired-engineer mentoring pool (one senior mentor, rotating)

**Decision Rights:** The Committee holds all technical design approvals up to the DRG freeze (Month 20 = 2028-06-12), including subsystem architecture, component selection, manufacturing tolerances and performance targets. After freeze, only Programme Board may approve design changes (impacts escalated). The Committee sets technical gate criteria (thresholds for uptime, reconstruction accuracy, AI performance) and validates pilot evidence against those criteria; Committee recommends go/no-go to Board but does not unilaterally release phases. The Committee approves procurement of equipment, robotics, AI systems and test samples up to USD 2M; larger procurements require Board approval. The Committee may require design rework or pilot re-runs if evidence is incomplete; Committee may recommend budget add-ons for design contingency (up to USD 5M Design Contingency Pool) or risk mitigation (detached pods, additional testing, stress scenarios). Parts and maintenance decisions (fabrication priorities, re-manufacture triggers, mentor curriculum) rest with Committee unless costs exceed USD 1M or affect phase gates.

**Decision Mechanism:** Consensus-seeking on design choices and technical thresholds. Simple majority (5 of 7-8) on routine technical approvals and test-result interpretations. Tie-breaker: Chief Technical Officer votes to break ties. Design Review Gate decisions (freeze approval) require unanimous sign-off from CTO, hardware lead and external expert; any dissent triggers additional review or Board escalation. Post-freeze change-control decisions require 80%+ Committee agreement and Board approval. AI and metadata accuracy validation requires agreement of AI Lead and at least one independent validator (external expert or archive representative). Uptime and reliability decisions require agreement of Maintenance Lead and remote-diagnostics system operator.

**Meeting Cadence:** Bi-weekly meetings Month 0-6 (2026-10-12 to 2027-04-12, pilot mobilization); weekly Months 6-20 (2027-04-12 to 2028-06-12, pilot operations and DRG process); monthly thereafter through pilot completion (Month 24 = 2028-10-12); quarterly during Phase 2 and 3 operations. Additional daily standups or ad-hoc meetings during pilot and design-crisis periods (e.g., if uptime drops below 85% or a critical component fails).

**Typical Agenda Items:**

- Design specification review (line-type architecture, subsystem design, component selection, manufacturing and assembly)
- Design Review Gate progress (design-review checklist completion, external review status, freeze readiness)
- Pilot unit status (retrofit progress, equipment integration, pre-deployment testing, issues and rework)
- Pilot operations metrics (uptime, mean time between failures, error rates per subsystem, field failures and root-cause analysis)
- Parts-depletion model and spares planning (consumption curve, re-manufacture schedule, fabrication priority, inventory status)
- Retired-engineer mentoring and knowledge-transfer progress (curriculum modules completed, mentee competencies, expertise retention)
- AI model validation (test-sample results, precision/recall per format-category, retraining needs, deployment readiness)
- Remote-diagnostics and fleet-management system (telemetry completeness, alarm threshold calibration, central-support staffing and response times)
- Post-pilot design-change requests and rework priorities (impact analysis, cost, schedule delay, Board escalation if needed)

**Escalation Path:** Design disagreements requiring >2 weeks of Committee deliberation escalate to Programme Board for strategic decision or external arbitration (hire independent consultant for binding technical opinion, cost up to USD 50K per dispute). Any design change discovered post-freeze escalates directly to Board. Critical field failures (uptime <90%, reconstruction accuracy <75%, AI precision/recall <70%) trigger urgent Committee session within 48 hours and formal root-cause analysis; if failure is due to design flaw, escalate to Board with remediation plan and cost estimate. If parts-depletion modeling shows infeasible spares trajectory (depletion outpacing fabrication capacity by >20% margin), escalate to Board as a risk trigger for Phase 2/3 go/no-go reassessment. Unresolved mentor availability or curriculum gaps escalate to Board as a feasibility warning.
### 3. Site Selection, Triage & Archive Engagement Committee (Operational & Stakeholder Management)

**Rationale for Inclusion:** The programme schedules 30+ archive residencies over 10 years, each requiring months of pre-positioning, approvals and coordination. Site selection depends on the Triage Doctrine decision (condition-first vs. value-first vs. survey-based) and the Host-Site Power and Readiness Compact (who supplies what). Poor scheduling cascades delays: if each site is 2 weeks late on average across 30 residencies, the aggregate loss is 60 weeks (14 months), shrinking delivered capacity by 10-15%. Transparent triage criteria protect archive trust; under-resourced institutions must not be systematically deprioritized. A dedicated Site Selection Committee owns queue management, readiness verification, host-relationship maintenance and dispute resolution.

**Responsibilities:**

- Develop and publish Triage Doctrine: define criteria for site prioritization (condition-degradation scoring, format-vulnerability ranking, research value, archival resources), trade-offs (endangered media vs. high-value collections), and rotation rules
- Maintain Master Schedule and Queue Management System: 5-year rolling forecast of site assignments, residency windows, unit assignments and contingency buffers; update quarterly
- Manage Site-Readiness Workstream: conduct pre-arrival readiness audits (fire-authority approval, insurer coverage, power quality, climate stability, security, staff liaison); track progress on Site Readiness Scorecard; enforce 90% readiness gate before unit dispatch
- Lead archive-engagement and stakeholder relationships: sign multi-year residency agreements (2-3 years, with termination clauses); facilitate funder-archive connections; manage cost-sharing negotiations; resolve prioritization disputes
- Maintain Priority Waitlist of backup sites and surge-buffer contingency (1-2 units in temporary parking) to absorb schedule slips and site withdrawals
- Track archive feedback and lessons-learned; feed insights to Programme Board on equipment performance, crew quality, collection-specific challenges
- Coordinate with Triage, Host Power and Readiness Compact, and Custody decisions: translate triage output into scheduled sites; implement tiered host contributions if adopted
- Escalate site-readiness blockers (fire-authority refusal, insurer exclusions, power instability, security gaps) to Programme Board for remediation or site deferral

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with programme director or head of operations (chair), 2-3 senior archive liaisons, logistics coordinator, host-site manager
- Publish draft Triage Doctrine by Month 3 (2027-01-12); conduct stakeholder workshop with funders and archives to gather input by Month 4 (2027-02-12); finalize by Month 6 (2027-04-12)
- Identify and secure agreements from 3 pilot archives by Month 6 (2027-04-12); identify 15+ Phase 2 archive candidates and begin readiness pre-work by Month 6 (2027-04-12)
- Establish Site-Readiness Workstream with dedicated logistics specialists by Month 2 (2026-12-12); develop and publish Site Readiness Scorecard template by Month 3 (2027-01-12)
- Build Master Schedule and Queue Management System (can be a spreadsheet or dedicated scheduling tool) by Month 4 (2027-02-12); include contingency buffers and surge-pool logic
- Establish Priority Waitlist and surge-buffer guidelines by Month 4 (2027-02-12)

**Membership:**

- Head of Operations or Programme Director (Chair)
- 2-3 Senior Archive Liaisons (deep relationships with major archives; one per geographic region: North America, Europe, etc.)
- Logistics Coordinator / Container Relocation Manager (coordinates trucking, customs, temporary storage)
- Host-Site Manager / Facilities Liaison (leads on-site power, security, space and staff-liaison management)
- Representative from Triage and Host-Readiness working group (ensures linkage to upstream decisions)
- Finance or Budget Liaison (tracks cost-sharing and host contributions; monitors schedule delays' cost impact)

**Decision Rights:** The Committee sets the Triage Doctrine (with Board approval) and interprets it to assign sites to the queue; the Committee prioritizes sites based on published triage criteria and notifies all archives of their scheduled window at least 12 months in advance. The Committee approves site-readiness audits and enforces the 90% gate (sites <90% ready are deferred by 3-6 months or moved down the queue). The Committee negotiates and signs multi-year host agreements (up to 3 years, with terms within Board-approved indemnity and cost-share policy); agreements requiring >USD 2M cost-sharing or non-standard terms escalate to Board. The Committee maintains the Priority Waitlist and can swap a lower-priority site with a higher-priority backup if the scheduled site becomes unavailable or fails readiness gate (decision valid if the change does not affect Board-approved phase-unit count or schedule by >2 months). The Committee owns internal dispute resolution for disputes over triage interpretation or site scheduling; escalations go to Board only if a funder or archive is not satisfied with Committee decision.

**Decision Mechanism:** Consensus-seeking on Triage Doctrine and site assignments. Simple majority (4 of 5-6) on routine scheduling decisions and readiness-gate applications. Tie-breaker: Head of Operations casts deciding vote. Triage Doctrine approval requires Board sanction before finalization. Site prioritization disagreements (e.g., two archives equally urgent, but only one can be scheduled in the same quarter) resolved by published triage criteria first; if criteria are tied, escalate to Board for policy guidance. Site-readiness gate decisions (ready to proceed, conditional proceed, or defer) require agreement of Host-Site Manager and Logistics Coordinator; disagreements between them escalate to Chair for mediation. Cost-sharing negotiations above Board-approved limits require Board amendment.

**Meeting Cadence:** Monthly meetings Month 1-24 (2026-11-12 to 2028-10-12, pilot and Phase 2 ramp); quarterly during Phase 2 and 3 operations. Ad-hoc meetings called by Chair or request of 2 members for urgent site-readiness issues or schedule conflicts.

**Typical Agenda Items:**

- Triage Doctrine interpretation and site-prioritization decisions (which sites in the queue, readiness status, flagged issues)
- Master Schedule review (planned residencies for next 12 months, contingency buffers, surge-pool status, any planned deferrals)
- Site-readiness status updates (fire-authority approval progress, insurer coverage, power audit results, security sign-offs, staff liaison confirmations)
- Archive agreements and negotiations (cost-sharing terms, multi-year commitments, indemnity and consent wording)
- Funder and archive feedback on pilot residencies (lessons learned, equipment performance, crew quality, collection challenges, recommendations)
- Lessons-learned from site visits and relocation logistics (schedule slips, cost overruns, unexpected facility needs, recommendations for future sites)
- Priority Waitlist and surge-buffer contingency (are backup sites ready if a planned site withdraws or fails readiness?)
- Escalations to Programme Board (readiness blockers, site prioritization disputes, cost overruns, phase-schedule impacts)

**Escalation Path:** Site-readiness disagreements (fire authority or insurer refuses approval despite hazard-control design) escalate to Programme Board, which may authorize fallback options (detached pre-treatment pod, site deferral, external consulting to overcome objection). Archive relationship disputes (e.g., funder wants earlier priority than triage criteria warrant) escalate to Board for stakeholder decision. Schedule impacts >2 months due to site delays escalate to Board as a risk trigger affecting phase targets. Systematic triage criteria disagreement from stakeholders (e.g., archives collectively reject condition-first ordering) triggers a stakeholder workshop convened by Board to re-negotiate Triage Doctrine.
### 4. Legal, Privacy & Compliance Committee (Regulatory & Risk Assurance)

**Rationale for Inclusion:** The programme handles unique cultural artifacts and personal data across multiple jurisdictions (GDPR, UK DPA, national privacy laws, data-residency rules). A single privacy breach (leaked personal medical records or classified government content), a handling incident destroying unique media, or a data-transfer violation triggers regulatory fines (GDPR up to 4% of global revenue, estimated USD 5M-20M+), loss of archive partnerships and reputational damage. Pre-upload human review gates require clear legal authority, decision logs and indemnity terms. On-site residencies depend on fire-authority and insurer approval of hazmat and loss-of-item risks. A dedicated Legal/Privacy Committee develops binding source agreements, indemnity tiers, privacy-review protocols, jurisdiction-specific frameworks and incident-response procedures.

**Responsibilities:**

- Develop and maintain standardised source agreements and indemnity structures; create jurisdiction-specific annexes (GDPR, UK DPA, national data-protection laws); template updated quarterly as case law evolves
- Operate Privacy Review Panel (2-3 data-protection experts, rotating per jurisdiction) that reviews all flagged privacy content before archival upload; maintain decision log with rationale; establish appeal process for reviewer disagreements
- Conduct Privacy Impact Assessment (PIA) for each source agreement identifying presence and sensitivity of personal data, transfer restrictions, legal basis for processing and required consent; flag items exceeding acceptable risk tier
- Manage source-agreement signatures: ensure all agreements signed before unit arrives; track expiry and multi-year renewal; identify any archives reluctant to sign and escalate negotiation blockers to Board
- Develop and oversee incident-response protocols (24-hour insurer notification, privacy-breach handling, regulatory-notification requirements per jurisdiction); maintain incident log with outcomes
- Coordinate with Hazmat and Fire-Safety compliance: oversee occupational safety (VOC exposure limits, respiratory protection, hazmat handling), environmental permits and end-of-life disposal of vintage equipment
- Map data-residency rules per jurisdiction and design compliance architecture (federated vs. centralized storage); flag jurisdictions where data cannot be transferred to central archive without breach of law; propose solutions (in-country mirrors, restricted tiers)
- Manage copyright and classification review: establish criteria for identifying copyrighted, government-classified or sensitive content; train reviewers and archivists on flagging and decision-making
- Track regulatory updates and case law; re-assess compliance posture quarterly and recommend policy updates to Programme Board

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief legal officer (chair), data-protection specialist, copyright expert, occupational safety officer
- Commission legal mapping of all planned jurisdictions (GDPR, UK DPA, national laws, data-residency rules) by Month 1 (2026-11-12); publish summary by Month 2 (2026-12-12)
- Develop standardised source-agreement template and tiered indemnity structure by Month 2 (2026-12-12); obtain Board approval by Month 3 (2027-01-12)
- Establish Privacy Review Panel and publish decision criteria (what constitutes personal data, classification markers, copyrighted content) by Month 2 (2026-12-12); train reviewers by Month 4 (2027-02-12)
- Conduct Privacy Impact Assessment template and procedures by Month 2 (2026-12-12)
- Develop incident-response protocol and notification procedures by Month 2 (2026-12-12); brief all staff and archives by Month 6 (2027-04-12)
- Design data-residency compliance architecture (federated vs. centralized, in-country mirrors, restricted tiers) by Month 3 (2027-01-12); present options to Board by Month 4 (2027-02-12)

**Membership:**

- Chief Legal Officer / General Counsel (Chair)
- Data Protection Officer / Privacy Specialist (GDPR and privacy-law expert)
- Copyright and Intellectual Property Specialist
- Occupational Safety and Environmental Compliance Officer
- 2-3 Rotating Privacy Reviewers (multilingual, legal/archival background; one per major jurisdiction or language group)
- Representative from Programme Board or Archive partners (non-voting, for stakeholder perspective)

**Decision Rights:** The Committee develops and Board-approves all binding source-agreement templates, indemnity tiers, privacy-review criteria and incident-response procedures. The Committee maintains Privacy Review Panel and oversees all flagged-content decisions; Panel decisions are binding (no appeal except to full Committee if reviewer is in conflict). The Committee interprets compliance requirements per jurisdiction and publishes guidance; Programme Board must approve any deviations from template agreements (jurisdiction-specific terms, extended indemnity, restricted-data handling). The Committee can halt content upload if flagged privacy or copyright content fails review or if legal risk exceeds acceptable tier; halts escalate to Board if no resolution within 5 business days. The Committee approves workplace safety plans (VOC monitoring, respiratory protection, hazmat handling) and occupational health assessments; unsafe conditions halt unit operations until remedied. The Committee approves incident-response actions (insurer notification, privacy-breach notification, regulator engagement) and publishes incident outcomes (anonymized, to Programme Board and relevant archives). The Committee cannot modify Board-approved indemnity terms or cost-sharing without Board approval.

**Decision Mechanism:** Consensus-seeking on legal frameworks and policy decisions. Privacy Review Panel uses majority voting (2 of 3 reviewers) on flagged-content decisions; disagreements (1 reviewer dissents) escalated to full Committee for re-review or Board guidance. Simple majority (3 of 4-5 core Committee members) on routine compliance decisions and template updates. Tie-breaker: General Counsel votes to break ties. Incident-response decisions (whether to notify regulators, how to handle a breach) require agreement of General Counsel and Data Protection Officer at minimum; if escalated to Board, Board decides. Disagreements on jurisdiction-specific interpretation escalate to external legal counsel for binding opinion (cost up to USD 25K per dispute).

**Meeting Cadence:** Monthly meetings Month 0-12 (2026-10-12 to 2027-10-12, framework development and pilot site agreements); quarterly thereafter. Privacy Review Panel meets as needed (weekly during pilot if content flagging is high, monthly during Phase 2/3). Incident-response team available 24/7 for emergency notification.

**Typical Agenda Items:**

- Source-agreement status (signed agreements, pending signatures, jurisdictions with negotiation blockers, indemnity-tier disputes)
- Privacy Review Panel decisions and trends (flagging rate by content category and archive, appeal requests, systematic bias detection, retraining needs)
- Jurisdiction-specific compliance questions (data-residency rules, transfer restrictions, notification requirements, emerging case law or regulatory changes)
- Incident log and post-mortems (handling losses, privacy breaches, regulatory inquiries, response actions, preventive measures)
- Occupational safety and environmental compliance (VOC monitoring results, respiratory-protection audits, hazmat transport documentation, fire-authority inspections)
- Data-custody and archive-access compliance (federated storage design updates, in-country mirror status, restricted-tier enforcement)
- Copyright and classification criteria and reviewer training (new flagging categories, edge cases, reviewer accuracy validation)
- Regulatory landscape updates (new GDPR guidance, privacy-law changes, archival standards, case law affecting cultural heritage digitization)

**Escalation Path:** Privacy Review Panel disagreements escalate to full Committee; if unresolved, escalate to Board for policy guidance or external mediation. Incident-response escalations: minor incidents (isolated privacy flag, single item loss) handled by Committee with 24-hour Board notification; major incidents (data breach affecting >100 items, regulatory investigation, archive partnership termination risk) escalated immediately to Board and Programme Director with incident-response team activation. Data-residency conflicts (jurisdiction prohibits data transfer) escalate to Board for policy decision (in-country holding, federated architecture, collection deferral). Occupational safety issues (unsafe working conditions, non-compliance with fire or OSHA standards) are immediately halted and escalated to Board for remediation plan and timeline.
### 5. Finance & Variance Monitoring Committee (Financial Governance & Budget Control)

**Rationale for Inclusion:** The USD 250M budget over 10 years is tight: recomputed costs about USD 530M uncapped, forcing Phase 3 to operate on USD 70M vs. USD 301M need (estimate). Phased releases on annual cycles create cash-flow timing risk. Cost escalation (2-3% inflation annually = 20-30% cumulative by Month 120 = 2036-10-12) and recomputed payroll overruns (USD 36-54M annually at full scale vs. USD 25M budget) require active variance monitoring and contingency management. A dedicated Finance Committee tracks monthly actuals, forecasts completion costs, triggers contingency draws, and escalates budget gaps >10% to Board for scope or funding adjustment.

**Responsibilities:**

- Develop and maintain detailed cost accounting by phase and budget line (capex, opex, equipment, parts, training, contingency, inflation reserve, mitigation add-ons); reconcile monthly actuals against budget
- Produce monthly cost-variance reports (current spend, forecast at completion per phase, cumulative variance, confidence range); escalate variance >5% to leadership, >10% to Board
- Model and track inflation impact (baseline 2%, high-case 3%, extreme 4% annually); publish inflation-adjusted budget scenarios quarterly
- Manage contingency reserves (10% per phase = USD 6M/12M/7M = USD 25M total) and mitigation add-ons (Design Pool USD 5M, risk add-ons USD 16-28.5M estimate); approve draws up to USD 1M, escalate >USD 1M to Board
- Manage inflation escalation reserves (proposed 15% per phase = USD 9M/18M/10.5M = USD 37.5M); allocate as inflation materializes (cumulative 2-3% per year)
- Track funder commitments vs. pledges; maintain Commitment Registry showing which funds are binding multi-year contracts vs. annual allocations at risk; flag any funder pullbacks or delays
- Forecast Phase 2 and Phase 3 cash-flow timing; identify any 2-3 month working-capital gaps and approve revolving-credit line draws (up to USD 15-20M proposed threshold) to bridge
- Conduct quarterly reconciliation of staffing and payroll actuals (headcount per unit, salary scales, benefits, travel/visa) against planned opex; flag if actual costs exceed USD 2.5M per unit-year
- Produce quarterly Financial Health Report to Board: budget status, phase-gate financial readiness (are funds committed for next phase?), risk triggers, variance trend

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief financial officer (chair), accountant/controller, programme budget manager, funder liaison
- Commission independent cost audit reconciling stated unit staffing, payroll and USD 250M budget by Month 1 (2026-11-12); publish reconciliation and recommendations by Month 3 (2027-01-12)
- Develop detailed budget model (capex, opex, contingency, inflation, mitigation) by Month 2 (2026-12-12); publish baseline and three inflation-scenario versions by Month 3 (2027-01-12)
- Establish monthly cost-accounting and variance-tracking system (spreadsheet or accounting software) by Month 2 (2026-12-12)
- Build Commitment Registry (funder commitments vs. pledges, payment schedules, conditions) by Month 2 (2026-12-12); target 50%+ Phase 1 committed by Month 3 (2027-01-12)
- Establish Contingency Management Framework by Month 2 (2026-12-12): which draws require Committee approval (up to USD 1M) vs. Board approval (>USD 1M), documentation requirements, drawdown log
- Lock Phase 1 budget and staffing by Month 4 (2027-02-12); lock Phase 2 by Month 20 (2028-06-12); lock Phase 3 by Month 54 (2031-04-12)

**Membership:**

- Chief Financial Officer (Chair)
- Accountant / Controller (monthly accounting, reconciliation, compliance)
- Programme Budget Manager (tracks costs per unit, per phase, per line item)
- Funder Liaison or Programme Director (context on funding commitments and policy decisions)
- Representative from Programme Board or Independent Finance Auditor (external oversight, no financial interest in programme outcomes)

**Decision Rights:** The Committee approves all monthly and quarterly budget reconciliations and variance reports; reports go to Programme Board without Committee veto. The Committee approves contingency draws up to USD 1M; draws above USD 1M require Board approval. The Committee approves inflation-reserve allocation as inflation accrues (tracked quarterly against 2%/3%/4% scenarios). The Committee can recommend phase-gate delays if committed funding for the next phase is <70% by 3 months before the scheduled gate; recommendation escalates to Board for decision. The Committee cannot approve scope changes (reduce units, eliminate line items) but can flag which changes would fit the budget; scope decisions rest with Board. The Committee approves accounting policies, reconciliation procedures and variance-report formats; Board approves the published Financial Health Report to external stakeholders.

**Decision Mechanism:** Consensus on budget model development and accounting standards. Simple majority (3 of 4-5) on routine approvals (monthly variance sign-off, contingency draws up to USD 1M, inflation allocation). Tie-breaker: CFO votes to break ties. Disputed variance interpretations (is a USD 2M equipment delay a true variance or a timing shift?) resolved by CFO judgment with full documentation. Disagreements on cost-to-complete estimates or inflation assumptions escalate to Board if variance impact exceeds USD 5M.

**Meeting Cadence:** Monthly meetings Month 1-120 (2026-11-12 to 2036-10-12) to review cost actuals, variance and forecast. Ad-hoc meetings called by CFO for large draws (>USD 500K), budget gaps or gate-readiness assessment.

**Typical Agenda Items:**

- Monthly cost actuals and cumulative variance (capex spent, opex spent, contingency drawn, expected cost at completion per phase, confidence range)
- Funder-commitment status (funds received, funds pledged but at-risk, Phase 2/3 commitment gap, any funder pullbacks or delays)
- Staffing and payroll reconciliation (headcount per unit, salary actuals vs. budget, benefits, travel/visa costs, any variances >5%)
- Phase-gate financial readiness (committed funding for next phase, contingency and reserves status, any shortfalls or mitigations needed)
- Inflation tracking (cumulative inflation vs. 2%/3%/4% scenarios, reserve depletion rate, impact on phase budgets)
- Contingency and mitigation add-on tracking (Design Pool status, risk-register add-ons drawn, remaining reserves)
- Forecast at completion for each phase (if spending continues at current rate, what is total cost at end of phase?)
- Cash-flow and working-capital forecast (do we have enough cash on hand to cover next 3 months of opex if a funder payment is delayed?)
- Financial risks and stop-loss triggers (what variance triggers a phase halt or scope reduction?)
- Phase-gate go/no-go financial assessment (do we have committed funding and healthy contingency to proceed to next phase?)

**Escalation Path:** Cumulative variance >10% overspend or under-utilization of major line items escalates immediately to Board as a governance re-assessment trigger; potential outcomes include budget replan, scope reduction, phased-gate delay or new-funder engagement. Phase 2 or Phase 3 funding gap >USD 10M with <3 months to gate escalates to Board for contingency-activation decision (activating a USD 15-20M bridge-credit line, deferring phase start, seeking emergency funder commitments, or reducing unit count). Payroll actuals consistently >USD 2.5M per unit-year escalate to Programme Director and Board for crew-composition review. Inflation exceeding 4% annually (extreme scenario) escalates to Board as a budget-viability trigger; potential outcomes include cost-control measures, timeline extension or scope reduction.