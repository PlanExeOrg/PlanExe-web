### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise swaps a solvable shipping problem for a worse one by trucking the scarcest, least replaceable asset (calibrated vintage decks) around the world, while leaving the actual binding limits (working-deck supply, rights and privacy clearance, data egress, a 10-year ramp against a 10-30 year loss window) untouched.**

**Bottom Line:** REJECT: Bringing the machines to the media relocates fragility to the scarcest equipment, cannot move the data it produces, and cannot be funded or legally cleared as described, so the premise does not deserve $250M.


#### Reasons for Rejection

- The stated danger is vibration and thermal shock to fragile media, yet each of 30 containers carrying 10-15 aligned vintage decks is re-trucked every 6-12 months, so the irreplaceable, unmanufactured machines take the shock instead and must be re-calibrated after every move, which makes the >90% uptime target unsupported.
- The data cannot leave the container at the scale claimed: recomputed, 500 TB over an assumed 100 Mbps satellite link takes about 460 days and 200 PB takes roughly 500 link-years, so the satellite and fiber upload step either fails or reintroduces physical drive shipping, the very logistics the design claims to eliminate.
- The budget does not close on the plan's own figures: recomputed, roughly 135+ MIU-years of operation (estimate) at $2-3M each is about $270-410M before the $60-120M of unit builds, against a $250M total, and 1,500-1,800 staff on $2-3M per MIU implies only about $33-60K per head all-in.
- The legal gate is an assumption, not a control: the AI pre-screen routes 80% of content straight to archival upload unreviewed, so 'zero legal/privacy incidents' cannot be shown for 1950-2000 audio, film and card data holding unmarked personal and medical information and unclear copyright, and '<20% needing review' is both the planning input and the success metric.
- The claimed cost advantage is aimed at a straw comparator: a fixed, co-located facility has already delivered roughly $77 per item (recomputed), inside the plan's $50-100 target, so $250M for 3.6M items (about $69 each) buys mobility overhead, not a cost breakthrough.

#### Second-Order Effects

- 0-6 months: Procurement for 300-500 working decks competes directly with existing archives and digitization vendors on auction sites and pushes up prices, while host archives balk at bake ovens and diesel generators parked beside irreplaceable collections and insurers demand site-by-site underwriting.
- 1-3 years: Pilot units lose uptime after their first relocation and spend the schedule on re-alignment and cannibalization, per-item cost misses $50-100, and host archives' own staff are drawn into review queues they were never funded for.
- 5-10 years: Most of the $250M is spent on a stranded fleet of single-purpose containers and a picked-over parts pile, the 70-80-year-old trainers are gone, and the output is a partial corpus of mixed-provenance AI-'reconstructed' signal with unresolved rights status, delivered as the loss window it was meant to beat closes.

#### Evidence

- Case/Incident — Indiana University Media Digitization and Preservation Initiative with Memnon (2015): about 350,000 audio, video and film items preserved for roughly $27M at one fixed co-located facility, about $77 per item (recomputed) with no trucking.
- Law/Standard — General Data Protection Regulation, Regulation (EU) 2016/679 (2016): treats health data as a special category of personal data, so archive holdings in the EU carry exposure that an unreviewed 80% of AI-cleared content cannot be shown to meet.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Wrong Bottleneck: the plan treats transport as the constraint on saving 1950–2000 media, while the real constraints are scarce playback machines, vanishing repair expertise and unresolved rights, and a fleet of 30 trucked containers consumes all three faster than it relieves any of them.**

**Bottom Line:** REJECT: The Wrong Bottleneck makes a $250M fleet out of the one problem that was already solvable, while multiplying demand for the irreplaceable machines, people and legal clearances that actually decide whether this media survives. A truck that shifts fragility from the tape to the last working deck is not a rescue; it is a transfer of loss.


#### Reasons for Rejection

- Rights and consent: the plan sends AI through decades of tapes, film and records that contain medical material, private interviews and family footage of people who never agreed to be digitized, and a pattern-matcher that flags logos and PII strings cannot know who a voice belongs to or who owns it.
- Oversight and jurisdiction: units hop between archives in different countries every 6–12 months (plan figure), each under different copyright, privacy and secrecy rules, and push everything over satellite to an unnamed 'distributed archive network' with no single accountable custodian, so 'AI flags, humans decide' leaves the roughly 80% the AI passes (plan figure) with no human ever looking.
- Irreversible harm: baking a failing tape or humidifying brittle film gets one attempt per unique item, a failure destroys the only copy, and AI-'reconstructed' signal (the plan accepts >80% accuracy) risks becoming the only surviving version of a record, with the invented portion indistinguishable from the real one.
- Value rot: the shipping risk is not eliminated but relocated onto 300–500 hand-scavenged vintage decks (plan figure) that are trucked between sites, vibrated and thermally shocked, with their azimuth alignment broken each time, while the budget does not close (recomputed from plan figures: 30 units at $2–3M a year is $60–90M annually in Phase 3, against $70M allotted for the entire phase) and the 'post-human AI training data' rationale justifies nothing a living archivist could audit.

#### Second-Order Effects

- **Months 0–6 (2026-10-12 to 2027-04-12) — The Cracks Appear:** a sudden buyer for hundreds of broadcast decks and spare heads inflates auction prices and strips parts from the small archives and vendors that currently keep their own machines running (estimate).
- **Months 12–36 (2027-10-12 to 2029-10-12) — The Idle Fleet:** the first privacy complaint or rights dispute at one partner archive freezes uploads, and containers sit in parking lots with 12–15 salaried reviewers each (plan figure) and no releasable output.
- **Months 60–120 (2031-10-12 to 2036-10-12) — Norms Degrade:** archives begin treating the AI-cleaned copy as the record, deprioritize the originals as 'done', and a generation of historians cites synthetic signal as primary evidence.
- **Months 120+ — The Reckoning:** the last working decks are worn out, the engineers who taught the successors are dead, and what remains is a corpus no one can verify, clear for use, or re-digitize from a source that has since rotted.

#### Evidence

- Case/Report — UNESCO's 'Deadline 2025' warning: tape content not digitized by about 2025 will in most cases be lost, driven by tape deterioration, equipment obsolescence and retiring expertise; this project begins at Month 0 (2026-10-12), after that date, and its Phase 2 does not scale until Months 24–60 (2028-10-12 to 2031-10-12) (as reported in public summaries; exact UNESCO wording not verified).
- Case/Report — Memnon (a Sony company) already markets portable, multi-recording digitization units and an 'insourcing' model in which digitization is done at the client's own location, so on-site transfer is an existing commercial service and the unsolved problems remain equipment, expertise and rights, not transport.
- Law/Standard — GDPR Art. 9 (special categories of personal data, including health data, are prohibited from processing unless a listed condition applies), which reaches any unit parked in the EU that scans medical recordings or patient film.
- Narrative — Front-Page Test: 'Archive's wartime interviews run through AI in a parking lot; reconstructed voices say things the dead never said' is the headline the plan's own line 'reconstruct corrupted data' writes on its first day of operation.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The plan cures a misdiagnosed shipping problem by trucking its own irreplaceable vintage machines worldwide, then promises thirty operating units on a budget that cannot even staff them.**

**Bottom Line:** REJECT: A $250M fleet of trucked, scavenged-parts digitization containers solves a shipping problem that was never the real bottleneck and cannot be funded, staffed or legally cleared at the scale it promises.


#### Reasons for Rejection

- Phase 3 allots $70M to build 15 MIUs at $3-4M each ($45-60M) and run up to 30 units for five years, yet $2-3M per MIU annually leaves only $10-25M, roughly $0.07-0.17M per unit-year against the $2-3M it claims to need (recomputed).
- The $500-2,000 per-item 'current methods' baseline is contradicted by Indiana University's Memnon partnership, which committed $27M for about 372,000 objects, roughly $73 each (recomputed), so the container fleet attacks a cost gap that the precedent shows does not exist.
- The plan bans vibration and thermal shock for media yet loads 300-500 vintage decks and scanners, whose azimuth and head calibration are the entire reason for the retired-engineer program, onto trucks for a new site every 6-12 months.
- Only the AI-flagged 20% reaches human eyes, so about 800 of every 1,000 hours flow into the distributed archive unseen, making 'zero legal/privacy incidents' a vow that watermark and PII-pattern matching cannot honor on 1950-2000 recordings of living people.
- A target of >80% signal reconstruction accuracy admits that up to one fifth of 'reconstructed' output may be wrong, yet the plan files it as a 'complete vintage knowledge base' and AI training data, turning machine guesswork into the permanent record.

#### Second-Order Effects

- 0-6 months: The three pilot units start with no named custodian, rights regime or funded long-term home for the 'distributed archive network', and each 500 TB on-board store would take about 46 days to drain over an assumed 1 Gbps uplink (estimate), so storage becomes the first stall point.
- 1-3 years: Phase 1's $60M is consumed by three units ($9-12M), $20M of equipment and $5M of training, leaving about $23-26M (recomputed), while pilots expose per-unit running costs that make the $120M Phase 2 request impossible to defend to government archives and cultural funders.
- 5-10 years: The retired engineers who were 70-80 at the start are largely gone (estimate), Phase 3's $70M cannot sustain 30 units, idle containers sit in car parks, partial petabytes of AI-altered files lack a funded custodian, and the uncopied collections keep degrading on the same 10-30 year clock.

#### Evidence

- Case/Incident — Indiana University Media Digitization and Preservation Initiative with Memnon (2013-2022): $15M plus $12M for film, about 372,000 objects and roughly 23 PB digitized, with the 2020 target slipping into 2021-2022, a conventional benchmark of about $73 per object that undercuts the plan's $500-2,000 baseline.
- Law/Standard — General Data Protection Regulation, Regulation (EU) 2016/679 (2016): applies to personal data in archival recordings and sets fines up to €20M or 4% of global turnover, directly contradicting a 'zero privacy incidents' promise built on unreviewed AI-cleared content.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan treats shipping risk as the binding constraint on dark-media preservation and relocates it instead of removing it: fragile, hand-calibrated 1950s-1990s machines would be trucked across continents every 6-12 months, wrapped in an unproven robotics, AI-review and budget story whose own arithmetic does not close. A deployment model that is a logistics reframing of an engineering, legal and talent problem cannot be fixed by tuning; the premise is mistaken.**

**Bottom Line:** Abandon the premise: 'bring the factory to the media' does not eliminate transit risk, it moves it onto irreplaceable machines, and it leaves the real constraints (obsolete equipment, scarce expertise, rights clearance, unfunded operations) untouched. The containerized model is the source of the failure, not its implementation details.


#### Reasons for Rejection

- The Hauled-Instrument Paradox: the plan bans shipping fragile media, then ships 10-15 vintage tape decks, film scanners and ovens per container (recomputed: 30 containers, each relocated every 6-12 months). Azimuth, head alignment and transport tension on irreplaceable machines with no manufacturer support are exactly the vibration and thermal-shock exposure the plan claims to have 'eliminated'. Every relocation is a recalibration event and a new chance to lose a machine that cannot be replaced.
- The Parking-Lot Vault Fallacy: 'media never leaves the premises' is treated as satisfying insurers, but moving a unique collection from a vault to a 40-foot container with baking ovens (8-24 hour cycles), generators and satellite gear is a new risk class (fire, power surge, theft, humidity excursion, environmental swing at the door). Insurers and archive boards are not obliged to treat a trailer in a car park as 'premises'. The central selling point is an assertion, not a verified coverage position.
- The Robot-Hand Mirage: robotic loading is labelled a 'simple, proven task', but it is proven on uniform, healthy cartridges, not on warped, shedding, vinegar-syndrome, spliced, mixed-gauge, mixed-format media in unknown condition. A 2008-2009 Indiana University survey alone found 569,000 items across 51 physical formats. Each exception needs a human hand, so the 'automation efficiency' of a fixed line collapses into a skilled-technician bottleneck, with the machines in a trailer.
- The Phantom Cost Gap: the budget does not reconcile with itself. Operating costs of $2-3M per MIU per year (plan figure) cannot cover 50-60 staff each (roughly $33-60k per head all-in, recomputed), and the same plan lists only 3-4 engineers plus 12-15 reviewers (about 19 people). Phase 3's $70M must fund 15 new containers (~$52M at $3.5M each, estimate) plus operations for 15-30 units over 5 years (roughly $300M+ at plan rates, estimate). The $500-2,000 per item 'current method' baseline is also contradicted by Indiana's centralized programme (about $77 per item, recomputed from $27M for ~350,000 items).
- The Eighty-Percent Review Illusion: AI pre-screening can find watermarks and PII patterns; it cannot establish copyright status, donor restrictions, third-party privacy or unmarked sensitive content in 1950-2000 recordings. Treating 'flag 200 of 1,000 hours, review at 2x' as a legal gate converts a rights-clearance and liability problem into a throughput number. The plan's 'zero legal/privacy incidents' target is unattainable by construction, and 2x-speed review is not a defensible standard of care for restricted content.
- The Double-Decay Clock: the plan races media degradation (10-30 years, plan claim) with an equipment fleet, parts pool and 70-80-year-old trainers that are decaying on the same clock. Capacitors, pinch rollers and heads age in the warehouse; the engineers age out; the 300-500-unit parts pool is cannibalized to keep fewer units alive. Capacity peaks (Years 6-10) after the plan's own knowledge supply has thinned.

#### Second-Order Effects

- Months 0-6 (2026-10-12 to 2027-04-12): Acquisition of 300-500 vintage units on open markets (eBay, auctions) makes the project the visible buyer, driving prices up and pulling machines away from the small archives and hobbyist repairers that already keep them alive. Insurers and general counsel at pilot archives begin demanding coverage rulings and indemnities for a container in the car park, stalling site agreements.
- Months 6-24 (2027-04-12 to 2028-10-12) (Phase 1): The three pilot containers (tape, film, card) spend most of their time in commissioning, calibration and exception handling rather than throughput. Robotic loaders reject or damage the worst 10-30% of media (estimate), forcing manual handling that breaks the 'zero damage' metric. Recomputed throughput at the plan's own targets (~100 items per unit per day, ~55 GB per item, i.e. several TB/day) is not demonstrated, but the Phase 1 gate is passed on soft metrics to keep funding.
- Months 24-60 (2028-10-12 to 2031-10-12) (Phase 2): Scaling from 3 to 15 units multiplies the parts-cannibalization burden and the dependence on a few key engineers. Each relocation (setup, recalibration, customs and permits for international moves, estimate ~1-2 months lost per move) eats 10-25% of a 6-12 month deployment. The first drive or scanner lost in transit is irreplaceable, and the parts pool becomes the actual capacity limit.
- Months 36-72 (2029-10-12 to 2032-10-12): The first serious rights or privacy dispute (medical, personnel, donor-restricted or classified material uploaded to a 'distributed archive network' before clearance) freezes uploads across all sites. Archives that signed source agreements discover the project cannot guarantee deletion, restriction or jurisdiction, and begin withdrawing. Funders see a cost per item far above $50-100 once the unfunded operating base is recognised.
- Months 72-120 (2032-10-12 to 2036-10-12): The Phase 3 funding gap (hundreds of millions, estimate) forces either fleet shrinkage or a request for renewed capital; stranded containers, an aging parts hoard and an unresolved legal backlog remain. A programme that was meant to pre-empt the loss of dark data instead leaves a partial, unevenly documented corpus, with the remaining original media still degrading, while the engineers who could have restored it have retired.

#### Evidence

- Lunar Orbiter Image Recovery Project (LOIRP): recovering 1960s lunar imagery required finding four Ampex FR-900 tape drives (refrigerator-sized, reported stored in a garage for ~two decades), then setting up in a disused McDonald's building on NASA Ames property in Mountain View with roughly 1,500 14-inch reels. It shows that vintage playback is a bespoke, machine-specific, years-long restoration effort dependent on a handful of people and parts, not a repeatable robotic line. Moving such machines is itself a major risk.
- Indiana University's Media Digitization and Preservation Initiative (MDPI): about $27M (originally $15M for ~325,000 audio and video recordings, plus $12M for ~25,000 film reels) at fixed, centralized facilities, digitizing more than 315,000 recordings in roughly four years (2015-2019). Cost per item is about $77 (recomputed), so the plan's claim that current methods cost $500-2,000 per item and need a mobile fleet to reach $50-100 is not supported by the best-documented large-scale precedent. It also shows that format diversity (51 formats found in a 2008-2009 survey of ~569,000 items) was the dominant challenge.
- Apollo 11 SSTV telemetry tapes: the original recordings were most likely erased and reused in the early 1980s because of a tape shortage and because paperwork described them only generically, with no mission named. The loss was a cataloguing and triage failure, not a logistics failure. A container of decks cannot fix that. It also shows how cheap mislabelling or mishandling of irreplaceable items becomes at scale.
- For the specific combination of a fleet of 30 relocating, robot-loaded, vintage-equipment containers with AI rights-screening and a $250M budget, no verified operating precedent was found; the plan is dangerously unprecedented in its specific folly.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Parking-Lot Factory Fallacy: The plan treats a finite, dying stock of 1950-2000 playback machines, retiring engineers, and unconsented personal content as an industrial input that a fleet of 30 containers can run at scale, and every number it offers rests on that treatment.**

**Bottom Line:** REJECT: The premise of industrializing the rescue of obsolete media with a global container fleet fails on its own arithmetic, consumes the scarce machines and expertise it claims to preserve, and processes the private lives of strangers at a volume no review process can honestly govern. The gate is closed.


#### Reasons for Rejection

- Rights and dignity: the plan ingests interviews, medical records, home recordings, and personnel files of people who never consented to digitization, then relies on AI keyword flagging and a rotating crew to decide what is private. Treating the human subjects of the archive as throughput is a dignity failure that no 'access tag' repairs.
- Accountability and oversight: responsibility is split between archive staff, an MIU crew, a central archive, and a funder consortium across many jurisdictions, with no single owner of a privacy or copyright breach. The success metric 'zero legal/privacy incidents' is an assertion, not a control, and it hides the fact that the review burden is quietly pushed onto host archives.
- Systemic risk and scale: 30 units each needing 10-15 decks (about 300-450 decks in service, recomputed) would consume the entire 300-500 unit vintage inventory with almost no spares, while cannibalization permanently lowers capacity with every repair. The 90% uptime target depends on a parts pool that shrinks every month and cannot be replenished.
- Value-proposition rot: the plan's own figures contradict each other. Operating costs of $2-3M per MIU annually across 30 units come to about $60-90M per year (recomputed), against $70M budgeted for all of Phase 3. A '<20% review' target sits beside 12-15 reviewers per unit and 50-60 staff, and 500TB per unit cannot be sent through a satellite link in any useful time (about 460 days at 100 Mbps, recomputed). The 'proven model' and 'post-human value' claims are rhetoric standing in for evidence.

#### Second-Order Effects

- Months 0-6 (2026-10-12 to 2027-04-12) — The Cracks Appear: Auction demand from a funded buyer spikes prices for broadcast-grade decks and scanners, and rival archives and small digitization shops are outbid for the same machines. The first sticky-tape bake cycles and head failures show that the 'simple, proven' robotic loading cannot handle warped, shedding, and mislabeled media.
- Months 12-36 (2027-10-12 to 2029-10-12) — Copycats Arrive: Competing container fleets, vendors, and national programs chase the same finite parts pool, and cannibalization becomes a scramble. Host archives sign scope-light agreements to get free digitization, and unreviewed content starts flowing to the central archive.
- Months 60-120 (2031-10-12 to 2036-10-12) — Norms Degrade: Review is quietly cut to meet throughput, with AI flags standing in for human judgment, and 'digitized' comes to mean 'ingested' rather than 'verified'. Original media is deprioritized or discarded on the strength of a digital copy nobody has validated, and the retired-engineer pipeline ends with the trainers' deaths, leaving dead skills with no living practitioners.
- Months 120+ — The Reckoning: The network leaves behind a partially processed collection, a depleted pool of working vintage equipment, and a repository carrying unresolved privacy and copyright liabilities. Items that could have been saved by a smaller, targeted effort are gone, and some are lost precisely because the originals were handled, baked, and returned as 'done'.

#### Evidence

- Case/Report — UNESCO and IASA 'Magnetic Tape Alert Project' / Deadline 2025: UNESCO has flagged about 200 million hours of audiovisual content at risk and named the lack of playback devices, spare parts, and trained engineers as the binding constraint, which is the same finite pool the plan proposes to cannibalize at fleet scale.
- Case/Report — Memnon on-premises digitization and DAMsmart mobile units for the AusStage videotape project: on-site digitization already exists in a road-case form factor, which shows that 'bring the line to the media' is a solved niche problem that does not require a 30-container global industrial network.
- Principle/Analogue — Defense logistics, DMSMS (Diminishing Manufacturing Sources and Material Shortages): when a system depends on parts no one manufactures, cannibalization trades future capacity for present uptime, and the fleet's availability decays faster the more it is used.
- Law/Standard — GDPR Article 9: processing special-category personal data, including health data, is prohibited absent a specific legal basis. A bulk 'ingest first, flag by AI, review later' pipeline across jurisdictions is built to violate it.