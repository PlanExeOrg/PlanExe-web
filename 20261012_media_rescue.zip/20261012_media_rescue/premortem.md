A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Funders will convert pledges into binding multi-year contracts, and host or consortium cost-sharing will close the roughly USD 280M gap (estimate), so the USD 250M cap (user constraint) can finance the stated staffing and 30 MIUs. | Survey all 15+ funders and 10 prospective hosts in writing for committed (not pledged) amounts, conditions and cost-share per MIU; reconcile staffing against the cap through an independent cost audit. | Less than USD 30M of Phase 1 is committed by Month 3 (2027-01-12), or the audit shows no funded path beyond about 14 unit-equivalents (estimate). |
| A2 | The finite stock of 300-500 vintage machines, 3D-printed parts and 6-8 retired mentors can sustain more than 90% uptime for a decade without a mid-programme stockpile refresh. | Bench-test 10 reference decks for 8-12 weeks at 16+ hours per day; harvest 20 non-operational machines for yield; build the depletion curve; fabricate 10 priority parts and measure azimuth tolerance. | Modeled spares fall below the 50% trigger before Month 60 (2031-10-12), fabricated parts miss the azimuth tolerance of +/-0.05mm, or fewer than 6 mentors sign contracts. |
| A3 | AI pre-screening on degraded, multilingual 1950-2000 content will flag only about 20% of items at 75% or better precision and recall, keeping reviewers near 12-15 per unit and the review gate affordable and lawful. | Label 100-200 real pilot-archive samples with 3-5 experts, run the pre-screen, then run a review pod on live content and measure flagging rate and review hours per content hour. | Precision or recall under 75% on any category-format pair after retraining, flagging above 25%, or review hours per content hour above 0.5. |
| A4 | Host archives, their insurers and fire authorities will give written approval for baking ovens, humidity chambers and generators in a container beside the host building, and will not demand a detached pod or full indemnity for every item. | Submit the draft Hazard Control Standard to 3 pilot-archive insurers and fire authorities and a specialist broker; request written conditions, exclusions and premium quotes. | Fewer than 1 written approval by Month 6 (2027-04-12), or conditions require detached pods at all 3 pilot sites (USD 1.5-4.5M, +4-6 weeks per site) (estimate). |
| A5 | Containers, vintage equipment, consumables and recovered data can cross borders and be hosted in each jurisdiction under workable temporary-import, e-waste and data-residency rules, with idle time per relocation near 2-4 weeks (estimate). | Commission a customs and data-protection legal opinion for the first 5 target countries covering temporary admission of obsolete electronics, hazmat consumables, and permitted replica locations for recovered masters. | Any of the first 5 target countries blocks temporary admission, classifies vintage equipment as e-waste, or prohibits export of masters, forcing relocation idle time above 6 weeks (proposed threshold). |
| A6 | Archives and rights holders will release originals for on-site digitization and sign multi-year agreements without exclusivity, training-data access or perpetual-storage guarantees that the program cannot fund. | Present the draft source agreement, tiered indemnity and Data-Access Policy to 10 candidate host archives and 3 technology-sector funders; record signature conditions and stewardship demands. | Fewer than 3 archives sign multi-year agreements by Month 6 (2027-04-12), or more than 30% of candidates demand a named perpetual-storage steward or exclusivity terms (proposed threshold). |
| A7 | Retained mentors and recruited successors, reviewers and field crews will stay through the critical period (to Month 48 = 2030-10-12) and can be hired, relocated and retained at the budgeted loaded cost of USD 50-70K per head (estimate). | Run a 3-month pilot staffing pod and post 10 mentor and 10 reviewer offers at budgeted pay; record acceptance, time-to-fill, loaded cost per role and 90-day retention. | Fewer than 6 of 8 mentor contracts accepted by Month 1 (2026-11-12), loaded cost per head exceeds USD 70K (estimate) by more than 15%, or reviewer offer acceptance is below 60% (proposed threshold). |
| A8 | A single Programme Board of 15+ funders and 30+ archives can decide gates, site priority and funder terms within 4 weeks without political capture or deadlock. | Run a simulated decision exercise on 3 contested cases (site priority, technology-funder terms, gate override) with draft Board members and time each decision. | Any contested case takes more than 8 weeks to resolve, or Board members cannot agree a written decision-rights charter by Month 2 (2026-12-12) (proposed threshold). |
| A9 | Recovered output (500 TB buffer per MIU, about 56 GB per item average) can be uploaded, verified and held in two separate copies fast enough that the on-board buffer never forces a unit to stop capturing. | Measure real upload throughput and fixity-verification rates at 3 candidate hosts' links and size the buffer against the 24,000 items per unit-year Phase 3 rate (estimate). | Sustained link throughput cannot clear the daily capture volume, or buffer fill exceeds 80% (proposed threshold) for more than 2 consecutive weeks in pilot operations. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Phantom Pledge Cliff | Process/Financial | A1 | Programme Director and Finance Lead | CRITICAL (25/25) |
| FM2 | The Last Capstan Sleeve | Technical/Logistical | A2 | Vintage Equipment Sustainment Engineer / Parts Manager | CRITICAL (20/25) |
| FM3 | The Leak That Closed the Doors | Market/Human | A3 | AI Signal Processing and Metadata Engineering Lead | CRITICAL (20/25) |
| FM4 | The Insurer's Veto | Process/Financial | A4 | Risk and Legal Lead | CRITICAL (16/25) |
| FM5 | The Container in Customs Limbo | Technical/Logistical | A5 | Site Operations and Logistics Coordinator | HIGH (12/25) |
| FM6 | The Archives That Said No | Market/Human | A6 | Privacy, Rights and Legal Compliance Officer | CRITICAL (16/25) |
| FM7 | The Mentors Who Ran Out of Time | Market/Human | A7 | Vintage Equipment Sustainment Engineer / Parts Manager | CRITICAL (16/25) |
| FM8 | The Board That Could Not Decide | Process/Financial | A8 | Programme Director | HIGH (12/25) |
| FM9 | The Buffer That Filled Overnight | Technical/Logistical | A9 | Central Operations and Fleet Management Officer | HIGH (12/25) |


### Failure Modes

#### FM1 - The Phantom Pledge Cliff

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Programme Director and Finance Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
- Plan lists funders without binding commitment mechanisms.
- Payroll recomputed at USD 75-126M per year at full scale (estimate) against a USD 25M average annual budget.
- Phase 1 procurement locks in headcount and units before reconciliation.
- Phase 2 tranche slips; bridge facility is drained.
- Phase 3 gap of about USD 301M (estimate) has no source; the network stalls near 14 units.

##### Early Warning Signs
- Committed funds below USD 30M at Month 3 (2027-01-12)
- Independent cost audit not delivered by Month 1 (2026-11-12)
- Funders request annual re-approval of multi-year pledges
- Host cost-share letters received from fewer than 5 of 10 surveyed sites

##### Tripwires
- Committed (not pledged) Phase 1 funds < USD 30M at Month 3 (2027-01-12)
- Cumulative cost variance >= 10% overspend in any phase
- Phase 2 commitments < USD 84M (70%) at Month 20 (2028-06-12)

##### Response Playbook
- Contain: Freeze new long-lead procurement and hiring beyond the three pilots; draw only from the contingency and bridge facility under Board signature.
- Assess: Commission the independent audit to rebuild cost per unit-year, quantify the committed-versus-pledged gap, and model 14, 18 and 24 unit scenarios within 4 weeks.
- Respond: Re-baseline scope to the funded unit count, renegotiate gates with funders, and pursue cost-share or new funders before releasing any further capex.


**STOP RULE:** If committed funding covers fewer than 24 units' worth of reconciled cost by Month 24 (2028-10-12), halt Phase 2 and re-scope the programme to the funded unit count.

---

#### FM2 - The Last Capstan Sleeve

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Vintage Equipment Sustainment Engineer / Parts Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- No MTBF model or cannibalization yield exists.
- Continuous 24/7 operation consumes finite heads, transports and motors.
- 3D-printed parts miss azimuth and speed tolerances; a bad part damages a unique tape.
- Mentors aged 70-80 exit before successors are certified.
- Units idle for weeks awaiting parts; uptime falls below 90%; emergency refresh of USD 15-25M (estimate) is unbudgeted.

##### Early Warning Signs
- Parts-depletion model not delivered by Month 2 (2026-12-12)
- Fabricated parts fail playback fidelity tests on reference decks
- Mentor contracts unsigned or a mentor unavailable for over 60 days
- Repeated identical failure signatures across units in one week

##### Tripwires
- Spares inventory <= 50% of baseline for any critical part category
- Trailing 6-month fleet uptime < 90%
- Fewer than 6 signed mentor contracts at Month 1 (2026-11-12)

##### Response Playbook
- Contain: Quarantine suspect fabricated parts, pause affected decks, and move cannibalization of working machines under written sign-off.
- Assess: Re-run the depletion model with measured field MTBF and yield, and rank part categories by weeks of cover remaining.
- Respond: Trigger re-manufacture or vendor sourcing, activate extended mentor consulting contracts, and re-plan unit schedule or request emergency stockpile funding.


**STOP RULE:** If the validated model shows spares exhausted before Month 100 (2035-02-12) at the funded unit count, cancel further unit builds and pivot to the vendor-operated model.

---

#### FM3 - The Leak That Closed the Doors

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: AI Signal Processing and Metadata Engineering Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Assumed 80% review reduction fails on degraded, multilingual content.
- Reviewers burn out under 35-40% flagging; backlog builds.
- Under pressure, thresholds loosen and a false negative uploads personal data.
- Archives and insurers read it as breach of trust.
- Host agreements are suspended; funders question the gates; the network shrinks.

##### Early Warning Signs
- Flagging above 25% in the pilot review pod
- Reviewer turnover above 20% annually
- Backlog exceeds 4 weeks of on-board storage
- Privacy false-negative rate above 5% in audit samples

##### Tripwires
- AI precision or recall < 75% on any category-format pair
- Flagging rate > 25% over 4 consecutive weeks
- Review hours per content hour > 0.5

##### Response Playbook
- Contain: Hold all uploads of affected categories, keep content in the restricted tier, and notify the host archive within 24 hours.
- Assess: Audit a stratified sample of passed items, measure false negatives by format and language, and review decision logs with the Privacy Review Panel.
- Respond: Retrain or redesign the review workflow, rebuild crew sizing, and brief archives, insurers and funders openly before resuming uploads.


**STOP RULE:** If privacy false-negative rate stays above 5% after one retraining cycle, or any reportable privacy incident occurs, suspend uploads and trigger governance re-assessment.

---

#### FM4 - The Insurer's Veto

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Risk and Legal Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Pilot design assumes on-site pre-treatment is insurable.
- Insurer quotes exclude ovens and generators or demand detached pods.
- Pod retrofit (USD 0.5-1.5M each) and 4-6 weeks per site drain the thin contingency.
- Approval delays push Unit 1 past Month 6 (2027-04-12), compressing pilot evidence before the Month 24 (2028-10-12) gate.
- Premiums rise after any incident, and fleet-wide pods (USD 15-45M) (estimate) are unfunded.

##### Early Warning Signs
- No insurer written feedback by Month 3 (2027-01-12)
- Broker quotes list exclusions for thermal or chemical events
- Fire authority requests a separation distance above the host hardstand
- Pooled loss reserve of USD 2-5M (estimate) not funded

##### Tripwires
- No written insurer approval at any pilot site by Month 6 (2027-04-12)
- Approval conditions add >= 4 weeks per site
- Annual premium quote exceeds USD 1M (proposed threshold)

##### Response Playbook
- Contain: Stop site-specific retrofit spending and hold Unit 1 shipment until approval conditions are written down.
- Assess: Cost the detached-pod, reduced-intake and self-insured reserve options per site and per unit with the broker within 3 weeks.
- Respond: Adopt the cheapest approvable option, update the Hazard Control Standard, and re-baseline pilot dates and Phase 1 contingency with the Board.


**STOP RULE:** If no insurer and fire authority approve any pre-treatment design by Month 9 (2027-07-12), cancel on-site pre-treatment and pivot to host-cold-storage deferral or fixed-site conservation labs.

---

#### FM5 - The Container in Customs Limbo

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Site Operations and Logistics Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Temporary-admission paperwork for obsolete electronics and hazmat consumables is untested.
- Vintage decks are classed as e-waste; consumables need hazmat transport.
- A unit idles in port for weeks, losing throughput and host residency windows.
- Host-country residency rules block upload, forcing separate in-country storage.
- Schedule slips cascade across residencies and the 15,600 items per unit-year requirement is missed (estimate).

##### Early Warning Signs
- Customs pathway document not complete by Month 4 (2027-02-12)
- Broker flags e-waste classification for vintage decks
- Regulator will not confirm permitted replica locations in writing
- First relocation paperwork takes longer than 6 weeks

##### Tripwires
- Any unit idle in transit >= 14 days
- Fewer than 3 temporary-import agreements by Month 6 (2027-04-12)
- Share of units blocked by customs holds >= 10% (proposed threshold)

##### Response Playbook
- Contain: Pause cross-border moves and re-route units to domestic or same-bloc hosts while paperwork is cleared.
- Assess: Map each stuck item by classification, regulator and cost per idle day, and test data-residency options with counsel.
- Respond: Concentrate the next 5 residencies in one customs bloc, adopt regional storage with in-country masters, and re-sequence the master schedule.


**STOP RULE:** If more than 2 of the first 5 target countries refuse temporary admission by Month 12 (2027-10-12), restrict the fleet to one customs bloc and re-scope the unit and country targets.

---

#### FM6 - The Archives That Said No

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Privacy, Rights and Legal Compliance Officer
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Archives want guaranteed perpetual storage and no training-data use.
- Technology funders expect research or training access to recover value.
- Source agreements stall; the most endangered collections are not released.
- Rights holders or press frame the program as a data grab.
- Pilot hosts withdraw, funders hesitate, and the fleet lacks enough host sites.

##### Early Warning Signs
- Archive counsel returns agreements with exclusivity or storage clauses
- Technology funder drafts require training-data rights
- Fewer than 10 archives engage in the stakeholder workshop
- Public criticism of data-access terms in sector press

##### Tripwires
- Fewer than 3 signed pilot agreements by Month 6 (2027-04-12)
- More than 30% of candidates request a named storage steward (proposed threshold)
- A funder term conflicts with source-agreement terms at signature

##### Response Playbook
- Contain: Suspend technology-sector funder talks and freeze new data-access commitments until the policy is signed by archives.
- Assess: Interview each declining archive to rank objections by cost, rights, trust and storage, and quantify capacity lost.
- Respond: Publish a research-only, rights-holder-approved Data-Access Policy, offer archive-held masters, and secure a named stewardship commitment.


**STOP RULE:** If fewer than 2 pilot archives sign by Month 9 (2027-07-12) without terms the program cannot honour, halt the pilot build and redesign the partnership model.

---

#### FM7 - The Mentors Who Ran Out of Time

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Vintage Equipment Sustainment Engineer / Parts Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Mentors aged 70-80 are perishable; contracts are unsigned or short.
- Reviewers burn out; turnover forces constant onboarding.
- Successors are under-trained when a mentor exits before Month 18 (2028-04-12).
- Field failures go undiagnosed; consultant fees rise to USD 5-10K per incident (estimate).
- Uptime and review quality fall together.

##### Early Warning Signs
- Mentor contracts unsigned at Month 1 (2026-11-12)
- Successor competency sign-offs behind curriculum plan
- Reviewer attrition above 20% annualised
- Mentor unavailable for over 60 days

##### Tripwires
- Signed mentor contracts < 6 at Month 1 (2026-11-12)
- Reviewer turnover >= 20% annualised
- Successor competency sign-offs < 50% of plan at Month 18 (2028-04-12)

##### Response Playbook
- Contain: Freeze solo repairs by unsigned successors and route all faults to the remaining mentors with written logs.
- Assess: Map competencies per line type against surviving mentors and rank single-points-of-failure within 3 weeks.
- Respond: Extend retention contracts to Month 54 (2031-04-12), recruit backup mentors and add paid cross-training overlap.


**STOP RULE:** If fewer than 2 mentors per line type remain under contract at Month 24 (2028-10-12), halt Phase 2 unit builds until succession is certified.

---

#### FM8 - The Board That Could Not Decide

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Programme Director
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Decision rights across funders and archives are undefined.
- Gate and site-priority decisions take 8-12 weeks each.
- Funders pull terms toward their own collections or data access.
- Tranche releases slip; the bridge facility is drawn.
- Phase 2 starts late and calendar is lost against media decay.

##### Early Warning Signs
- Governance charter not ratified by Month 2 (2026-12-12)
- Repeated deferral of agenda items
- Funder side letters conflicting with Board decisions
- Gate evidence waiting on Board review

##### Tripwires
- Routine decision cycle >= 4 weeks
- Charter unsigned at Month 2 (2026-12-12)
- Phase 2 gate decision pending > 8 weeks after evidence

##### Response Playbook
- Contain: Delegate routine decisions to named committees with a 10-day clock and pause contested items.
- Assess: Log every pending decision, owner, age and funder dependency within 2 weeks.
- Respond: Amend the charter with tie-break rules and publish site-priority criteria agreed in writing by all funders.


**STOP RULE:** If the Phase 2 gate decision is not taken within 12 weeks of complete evidence, trigger an external governance review and suspend new commitments.

---

#### FM9 - The Buffer That Filled Overnight

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Central Operations and Fleet Management Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Capture rate outruns host uplink and verification.
- 500 TB on-board buffer fills; units stop capturing.
- Fixity failures force re-transfer and re-verification.
- Backlog blocks relocation and idles scarce decks.
- Two-copy target is missed and archives lose confidence.

##### Early Warning Signs
- Measured uplink below planned daily volume
- Buffer above 60% for a week
- Fixity-check failures above 1% of files
- Host link outages longer than 24 hours

##### Tripwires
- On-board buffer >= 80% for 14 consecutive days
- Fixity failure rate >= 1% of files
- Upload backlog >= 4 weeks

##### Response Playbook
- Contain: Throttle intake to the verified drain rate and stage derivatives for upload first.
- Assess: Measure link capacity, verification speed and failure causes per site within 2 weeks.
- Respond: Add offline media deposit or a federated copy path, upgrade links, and resize buffer in the Phase 2 design.


**STOP RULE:** If buffer-driven stoppages exceed 10% of unit-months across the pilots, freeze Phase 2 design until the data path is redesigned.
