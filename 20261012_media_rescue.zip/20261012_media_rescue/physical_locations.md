This plan implies one or more physical locations.

## Requirements for physical locations

- Central hub for container retrofit and integration: industrial floor space, heavy crane access, 40-foot container handling, near port or major highway/rail
- Climate-controlled warehouse for vintage equipment parts inventory (300-500 units) with secure storage
- Access to retired broadcast and film engineers and technical universities for training pipeline
- Pilot host archives holding degraded tape, film and card collections, with hardstand, stable power, security and fire-authority approval
- Customs-friendly corridors and mutual recognition blocs for temporary import of containers and vintage equipment
- Reliable fiber or satellite connectivity for uploads and remote diagnostics
- Legal clarity on data residency, privacy and copyright for recovered data
- Proximity to vintage equipment sources (decommissioned broadcasters, auctions, closed facilities)
- Moderate labor and facility costs to fit the $250M (user constraint) budget

## Location 1
United States

Culpeper / Northern Virginia and Washington DC region

Industrial or logistics site near the Library of Congress Packard Campus, Culpeper, VA

**Rationale**: Hosts a major audiovisual preservation campus and a deep talent pool of broadcast and archival engineers. Close to National Archives, Smithsonian and university collections for pilot sites, with highway access for container trucking and nearby East Coast ports.

## Location 2
United Kingdom

Greater London and South East England

Industrial estate near Thamesport or Tilbury port, with pilot sites at archives such as the British Library and BFI National Archive

**Rationale**: Strong archival and broadcast heritage (BBC, BFI, British Library) and a pool of retired engineers. Port access supports container logistics and onward routes into Europe. Deep conservation expertise suits the film and tape lines.

## Location 3
Netherlands / European Union

Hilversum and Rotterdam region

Warehouse or industrial unit near Hilversum (Netherlands Institute for Sound and Vision) with Port of Rotterdam access

**Rationale**: Home to a leading audiovisual archive and broadcast industry with many decommissioned decks. EU single customs area and data rules ease intra-bloc moves, and Rotterdam provides a global shipping gateway.

## Location 4
United States

Los Angeles / Southern California

Industrial district near Burbank or Port of Long Beach

**Rationale**: Dense concentration of studios, film archives and former broadcast facilities supplies vintage equipment and engineers. Port access supports Pacific routes. Film Line pilot can use studio and university film collections.

## Location Summary
The plan is global and mobile, with no fixed site named, but it needs physical bases: a container retrofit and parts hub, a training centre, and pilot host archives. Four suggested regions (Northern Virginia, South East England, Hilversum/Rotterdam, Los Angeles) combine archival density, retired-engineer talent, vintage equipment supply, port or highway access and workable customs corridors. Pilot residencies would then be sited at partner archives in or near these hubs, then expanded worldwide.