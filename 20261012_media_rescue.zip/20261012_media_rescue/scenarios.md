# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Very high. A 10-year, $250M programme (user constraint) to build 30 containerized digitization units worldwide, targeting 3.6M+ items and 200+ PB across 1950-2000 magnetic tape, film and card media. Global footprint, a roughly 1,500-1,800 person workforce at full scale, and a public-interest preservation mission rather than profit.

**Risk and Novelty:** High risk on a few concentrated points. The container-as-factory concept is novel for obsolete media. The plan depends on a finite stockpile of vintage decks and scanners that is consumed by the work, and on perishable expertise held by retired engineers. The assumed 80% AI review reduction is unproven on degraded, multilingual pre-digital content. Legal and privacy exposure and archive trust are existential: on-site residency only works if archives and insurers stay confident. The plan itself bans autonomous legal decisions and assumptions about equipment availability.

**Complexity and Constraints:** Very high operational complexity: three distinct line types, pre-treatment (baking, humidification), robotics, AI pipelines, satellite/fiber upload, climate control and generator power, multi-jurisdiction site logistics, and a parts warehouse with a training pipeline. Constraints: fixed $250M budget in three phases ($60M, $120M, $70M), 3-to-15-to-30 unit ramp, and media degradation clocks of 10-30 years. Recomputed: the stated staffing (50-60 per unit) and opex ($2-3M per unit-year) do not clearly reconcile, and the Phase 1 success metrics can only be trusted if pilot data replaces the assumed review and uptime figures.

**Domain and Tone:** Cultural and heritage preservation infrastructure, institutional and public-interest in tone. Emphasis on custody, insurance compliance, source agreements and human-in-the-loop legal review, with an aspirational long-term 'post-human value' framing.

**Holistic Profile:** A large, mission-driven, safeguard-heavy physical infrastructure programme whose credibility rests on institutional trust, human review of legal and privacy risk, and a vintage-hardware sustainment engine. It is ambitious in scale but conservative in its stated principles (no shipping, no autonomous legal calls, no assumed equipment availability), so it needs a strategy that executes the core concept with its safeguards intact and tests assumptions honestly before replicating units.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Execute the plan's core concept with its safeguards intact: own and cannibalize a stockpile backed by retired-engineer mentoring, gate every item through AI plus human review, and keep dedicated crews for consistent quality. A consortium provides binding co-funding, and a stress-first pilot surfaces failure modes before funder expectations are set, so Phase 2 commitments rest on honest evidence.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Keeps the plan's own architecture and safeguards (stockpile plus mentoring, pre-upload human review, resident crews) and adds consortium co-funding and a stress-first pilot that tests the plan's riskiest assumptions. Weak points are the headcount and budget reconciliation and the depleting spares curve, which still need modeling.

**Key Strategic Decisions:**

- **Vintage Transport Sustainment Strategy:** Buy and cannibalize a large inventory of decommissioned decks and scanners, sustained by retired-engineer mentoring, 3D-printed parts, and an embedded maintenance engineer in each unit.
- **Rights, Privacy, and Review Gate Design:** Gate every item behind AI pre-screening and human review of flagged content before archival upload, with reviewers embedded in each unit as the plan describes.
- **Crew Composition and Review Labor Model:** Deploy a dedicated resident crew of engineers, operators, and reviewers with each unit, rotating whole teams between sites to keep process quality consistent across the fleet.
- **Funding and Ownership Architecture:** Assemble a consortium of national archives and cultural foundations that jointly own the fleet and the data, with cost-sharing contributions from each host institution tied to its residency.
- **Pilot Proof Gates and Scale-Up Cadence:** Deliberately send the first unit to the worst-condition collection available, exposing failure modes under stress before clean-collection results set expectations and funder confidence.

**The Decisive Factors:**

- **Matches the plan's identity:** the stockpile-plus-mentoring sustainment model, embedded reviewers and resident crews are the plan's own design, so the scenario executes it rather than re-engineering it.
- **Honors the safeguards:** pre-upload human review fits the plan's bans on autonomous legal decisions and on underestimating the review bottleneck.
- **Handles the risk honestly:** a stress-first pilot tests the unproven 80% review reduction and the >90% uptime target before Phase 2 commitments.
- **Fits the mission:** consortium ownership suits a public-interest, non-profit programme.
- **Pioneer's Gambit** defers legal review, depends on technology-sector data access and replicates unproven designs, which risks archive trust.
- **Consolidator's Ledger** hands control to vendors and hosts and releases funding slowly, under-delivering on scale against degradation clocks.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Bet on engineering and architecture rather than scarcity: new-build open-specification transports remove dependence on a depleting stockpile, a dark-tier ingest decouples capture speed from rights review, and centralized hubs keep on-site crews lean. Calendar time is bought with parallel procurement and technology-company revenue, accepting rework, legal-exposure and archive-trust risks in exchange for the fastest path to scale.

**Fit Score:** 3/10

**Assessment of this Path:** Optimizes for speed through new-build transports, deferred rights review and technology-company revenue, which directly cuts against the plan's bans on autonomous or deferred legal decisions and its public-interest, archive-trust positioning. Overlapping procurement with pilots would replicate unproven container designs before failure modes are known.

**Key Strategic Decisions:**

- **Vintage Transport Sustainment Strategy:** Fund development of new-build, open-specification transports and heads that replicate vintage playback behavior, using the legacy stockpile only as reference units and short-term spares.
- **Rights, Privacy, and Review Gate Design:** Ingest everything into a restricted dark tier, hold it under embargo with no access, and run rights and privacy review only when a researcher requests an item or an embargo lapses.
- **Crew Composition and Review Labor Model:** Centralize review and quality control in a few remote operations hubs that receive proxy files from all units under strict access controls, leaving only mechanical and transfer operators on site.
- **Funding and Ownership Architecture:** Sell time-limited, non-exclusive research access to recovered corpora to technology companies on terms approved by rights holders, using that revenue to cross-subsidize digitization for archives that cannot pay.
- **Pilot Proof Gates and Scale-Up Cadence:** Overlap scale-up with the pilots by ordering long-lead containers, robotics and power systems for the next units while pilots run, accepting rework risk in exchange for calendar time.

### The Consolidator's Ledger
**Strategic Logic:** Minimize capital at risk and shift exposure to parties best able to carry it: specialist vendors operate and repair the machines, host archives own rights and privacy decisions and staff the work, and fees fund only what is demanded. Phase 2 money is released only when all pilot lines hold published thresholds across more than one site, trading speed and scale for predictability.

**Fit Score:** 5/10

**Assessment of this Path:** Low capital risk and strict gating are sensible, but vendor-operated machines, host-run review and fee-for-service funding diverge from the plan's embedded-engineer and training model and from its mission of reaching under-resourced archives. Slow gating also spends calendar time while media degrades.

**Key Strategic Decisions:**

- **Vintage Transport Sustainment Strategy:** Contract existing specialist digitization vendors and conservation labs to operate and repair the machines inside the containers, in return for guaranteed multi-year throughput volume rather than ownership of the equipment base.
- **Rights, Privacy, and Review Gate Design:** Delegate review to the source archive's own legal and curatorial staff using a shared flagging tool and jurisdiction-specific rule sets, with program staff limited to quality control of the digitization itself.
- **Crew Composition and Review Labor Model:** Embed a small technical core per unit and train the host archive's own staff to run intake, sorting, and review, leaving a skilled local team behind when the container departs.
- **Funding and Ownership Architecture:** Operate the fleet as a non-profit service bureau that charges host institutions per-item or per-collection fees, with grants subsidizing under-resourced archives and unit utilization driving revenue.
- **Pilot Proof Gates and Scale-Up Cadence:** Release Phase 2 funding only after all three pilot lines hold the plan's published success thresholds for a sustained period across more than one host site.
