### 1. Senior leadership and Project Sponsor establish the governance framework vision. Draft a Governance Charter document outlining the role of a Programme Board, subsidiary committees (Technical, Site Selection, Legal/Privacy, Finance), decision authority, and escalation paths. Coordinate with identified funders and partner archives to gather input on preferred governance structure and decision-making principles.

**Responsible Body/Role:** Project Sponsor and Senior Management

**Suggested Timeframe:** Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Draft Governance Charter v0.1
- Stakeholder input summary
- Governance structure diagram
- Committee charter templates (preliminary)

**Dependencies:**

- Project Sponsor identified and committed
- List of potential funder and archive stakeholders available

### 2. Project Manager and General Counsel circulate the draft Governance Charter for feedback from committed funders, partner archives, and programme leadership. Gather consensus on Board size, committee structure, decision rights and meeting cadence. Finalize charter language and obtain Programme Sponsor approval before formal Board establishment.

**Responsible Body/Role:** Project Manager and General Counsel

**Suggested Timeframe:** Week 1–2 of Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Governance Charter v1.0 (finalized)
- Stakeholder feedback summary
- Board member nomination list (8–10 members confirmed)
- Sponsor sign-off on charter

**Dependencies:**

- Draft Governance Charter available
- Confirmed list of committed funders and archive partners
- Project Sponsor approval authority confirmed

### 3. Project Sponsor formally appoints the initial Programme Board Chair and confirms all eight to ten Board members by written appointment letter. Chair should be the Programme Director or senior sponsor representative with clear authority to lead strategic decisions. Provide each member with the finalized Governance Charter, committee charters (draft), and a board-orientation briefing on programme goals, budget, risks and timeline.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Month 0 (2026-10-12), Week 3 (2026-10-12)

**Key Outputs/Deliverables:**

- Board-member appointment letters (8–10 signed)
- Board orientation briefing deck
- Finalized committee charters (Technical, Site Selection, Legal/Privacy, Finance)
- Meeting schedule and calendar invites for first meetings

**Dependencies:**

- Governance Charter v1.0 finalized and approved
- Eight to ten Board members nominated and accepted
- Sponsor authority confirmed

### 4. Interim Governance Coordinator (designated by Project Manager) convenes the first Programme Board meeting. Board Chair leads adoption of the Governance Charter, confirms the decision-authority framework and escalation procedures, and approves the charter for subsidiary committees. Board assigns committee chairs and defines initial workstreams (cost audit, parts-depletion model, legal mapping). Schedule all four subsidiary committees to hold their initial meetings within two weeks.

**Responsible Body/Role:** Programme Board (first meeting, chaired by Programme Director or Board Chair)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 1 week of Board appointment

**Key Outputs/Deliverables:**

- Board Charter adopted (signed)
- Governance Framework approved and published
- Committee chairs assigned (Technical, Site Selection, Legal/Privacy, Finance)
- Initial Board decision log with agenda and action items
- Monthly Board meeting schedule (Months 1–6 = 2026-11-12 to 2027-04-12 confirmed)

**Dependencies:**

- All eight to ten Board members appointed and confirmed
- Governance Charter finalized
- Committee charters drafted

### 5. Chief Technical Officer (designated by Board) leads the initial Technical Committee meeting. Committee adopts the Technical Charter, establishes design-review procedures and DRG criteria (by Month 2 = 2026-12-12). Assigns immediate workstreams: (1) commission independent technical assessments of preliminary designs; (2) issue RFQ for 100–200 real test samples from proposed pilot archives; (3) establish parts-depletion modeling team; (4) begin retired-engineer mentor recruitment. Define committee meeting cadence (bi-weekly Months 0–6 = 2026-10-12 to 2027-04-12, weekly Months 6–20 = 2027-04-12 to 2028-06-12). Publish preliminary design specifications for all three line types.

**Responsible Body/Role:** Technical Committee (chaired by Chief Technical Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Technical Committee Charter adopted
- Design-Review Gate (DRG) procedure document
- Preliminary design specifications for Tape, Film, Card line types
- RFQ issued for test samples (100–200 items)
- Parts-depletion modeling project initiated; team assigned
- Retired-engineer mentor recruitment plan
- Technical-committee meeting schedule (bi-weekly to weekly)

**Dependencies:**

- Technical Committee appointed and chartered by Board
- Preliminary design specifications available (from engineering team)
- Budget allocated for external technical reviews and test-sample procurement

### 6. Chief Legal Officer and General Counsel lead the initial Legal, Privacy & Compliance Committee meeting. Committee adopts the Legal Charter and establishes foundational compliance workstreams: (1) commence legal mapping of all planned jurisdictions (GDPR, UK DPA, national privacy laws, data-residency rules); (2) draft standardised source-agreement template with tiered indemnity structures; (3) define Privacy-Review Panel composition and decision criteria; (4) establish incident-response protocols. Establish monthly meeting cadence. Publish a legal-compliance roadmap and jurisdiction-mapping schedule.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee (chaired by Chief Legal Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Legal/Privacy Committee Charter adopted
- Jurisdiction-mapping project initiated; scope document published
- Source-agreement template draft (preliminary)
- Privacy-Review Panel composition and decision-criteria draft
- Incident-response protocol outline
- Legal-compliance roadmap and timeline
- Committee meeting schedule (monthly)

**Dependencies:**

- Legal, Privacy & Compliance Committee appointed and chartered by Board
- General Counsel and data-protection specialist available
- List of planned pilot and Phase 2 jurisdictions available

### 7. Chief Financial Officer leads the initial Finance & Variance Monitoring Committee meeting. Committee adopts the Finance Charter and establishes budget-governance workstreams: (1) commission independent cost audit reconciling stated staffing (50–60 per unit), opex (USD 2–3M per unit-year) and the USD 250M budget cap; (2) develop detailed cost-accounting model (capex, opex, contingency, inflation); (3) build Funding Commitment Registry translating pledges into binding contracts; (4) establish contingency and mitigation-add-on tracking framework. Publish cost-audit RFQ and budget-model development schedule.

**Responsible Body/Role:** Finance & Variance Monitoring Committee (chaired by Chief Financial Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Finance Committee Charter adopted
- Cost-audit RFQ issued (independent auditor selection by Month 2 = 2026-12-12)
- Detailed budget-model development plan
- Funding Commitment Registry project initiated
- Contingency and mitigation-tracking framework outlined
- Finance-committee meeting schedule (monthly)

**Dependencies:**

- Finance & Variance Monitoring Committee appointed and chartered by Board
- Chief Financial Officer assigned
- Budget allocation available for cost audit (USD 50–100K estimate)
- Preliminary staffing and opex figures available

### 8. Head of Operations and Site-Liaison Lead initiate the Site Selection, Triage & Archive Engagement Committee meeting. Committee adopts the Site Selection Charter and establishes initial workstreams: (1) draft Triage Doctrine (condition-first vs. value-first vs. survey-based prioritization); (2) build Master Schedule and Queue Management System template; (3) identify three pilot archives and begin readiness pre-work; (4) establish Site-Readiness Workstream and Scorecard. Schedule committee meetings (monthly Months 1–24 = 2026-11-12 to 2028-10-12). Publish triage-doctrine consultation schedule (stakeholder workshop by Month 4 = 2027-02-12).

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee (chaired by Head of Operations)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Site Selection Committee Charter adopted
- Draft Triage Doctrine outline and prioritization framework
- Master Schedule and Queue Management System template (spreadsheet or tool identified)
- Pilot-archive identification list (3 target archives)
- Site-Readiness Scorecard template
- Site-Readiness Workstream roles and responsibilities assigned
- Committee meeting schedule (monthly)

**Dependencies:**

- Site Selection Committee appointed and chartered by Board
- Head of Operations assigned
- List of potential pilot and Phase 2 archives available
- Preliminary triage criteria and policy guidance available

### 9. Project Manager commissions independent cost audit to reconcile the stated staffing model (50–60 per unit at 30 units = 1,500–1,800 people) and opex (USD 2–3M per unit-year) against the USD 250M cap. Audit to include detailed line-item cost estimates (capex, equipment, parts, training, staffing/payroll, logistics, utilities, connectivity, contingency, inflation). Deliverable: reconciliation report showing either the plan's full scope is affordable, or which elements (unit count, crew size, timeline) must adjust to fit the cap.

**Responsible Body/Role:** Finance Committee and Project Manager, supported by external auditor

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Cost-audit RFQ released and auditor selected
- Cost reconciliation report (draft) with line-item breakdown
- Three budget scenarios: baseline, high-cost (3% inflation), extreme-cost (4% inflation)
- Recommendations for cost control, scope adjustment or additional funding

**Dependencies:**

- Finance Committee formed
- Budget allocation for audit (USD 50–100K estimate)
- Preliminary design specifications and staffing assumptions available

### 10. General Counsel and Legal Committee commence jurisdiction-by-jurisdiction legal mapping. Analyze GDPR, UK Data Protection Act, national privacy laws, data-residency rules and archival preservation standards for all planned jurisdictions. Produce a jurisdiction-mapping matrix summarizing transfer restrictions, consent requirements, notification obligations, data-residency rules and archival-access legal frameworks. Identify jurisdictions with conflicting requirements or novel compliance needs that require early Board attention.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by external legal counsel (data-protection specialists)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Jurisdiction-mapping matrix (GDPR, UK DPA, national laws, data residency, archival standards)
- Summary of transfer restrictions and consent requirements per jurisdiction
- Risk flags for jurisdictions with novel or conflicting requirements
- External legal-counsel engagement (data-protection specialists identified)

**Dependencies:**

- Legal Committee formed
- List of all planned pilot and Phase 2 jurisdictions confirmed
- Budget for external legal counsel (USD 30–50K estimate)

### 11. Technical Committee commissions detailed parts-depletion modeling study. Study to include: (1) baseline mean time between failures (MTBF) per deck/scanner type, estimated from industry data or similar equipment; (2) cannibalization yield curves as the 300–500-unit stockpile is depleted; (3) 3D-printing and CNC-machining feasibility for 20+ critical replacement parts (azimuth guides, transport rollers, tension springs, etc.), with tolerance analysis and cost estimates; (4) retired-engineer expertise requirements and knowledge-transfer timelines; (5) recommendation on when to trigger emergency stockpile refresh or new-build transports. Deliverable: parts-depletion curve model and risk-trigger thresholds.

**Responsible Body/Role:** Technical Committee, supported by vintage-equipment specialists and 3D-printing/CNC engineers

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Parts-depletion model (spreadsheet or simulation) with MTBF, cannibalization yield and fabrication-capacity curves
- 3D-printing and CNC-machining feasibility study (20+ critical parts; tolerance analysis)
- Risk-trigger thresholds (depletion %, emergency refresh trigger)
- Retired-engineer expertise-transfer timeline and knowledge-loss risk assessment
- Budget estimate for parts-engineering team and contingency stockpile refresh (USD 10–15M proposed)

**Dependencies:**

- Technical Committee formed
- Industry data on tape-deck and scanner MTBF available (or estimates from archival community)
- List of 300–500 acquired vintage machines and their condition available
- Budget for parts-depletion modeling study (USD 20–30K estimate)

### 12. Technical Committee issues Request for Quotation (RFQ) for procurement of 100–200 representative test samples from proposed pilot archives. Samples to span all three formats (tape, film, card), multiple degradation levels (stable, moderately degraded, severely degraded) and content types (English speech, non-English languages, music, technical recordings, handwritten metadata). Target archives identified by Site Selection Committee. Negotiate procurement contracts and delivery schedules; target sample arrival by Month 4 (2027-02-12) to allow AI model testing and pilot review-pod setup.

**Responsible Body/Role:** Technical Committee and Site Selection Committee, supported by archive liaisons

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- RFQ document specifying sample-composition criteria (format, degradation, content diversity)
- Procurement contracts with pilot archives for sample provision
- Sample-delivery schedule (target Month 4 = 2027-02-12)
- Gold-standard labeling protocol for AI training and validation

**Dependencies:**

- Three pilot archives identified and willing to provide samples
- Technical Committee formed
- Sample composition criteria defined (format mix, degradation levels)

### 13. Finance Committee develops detailed cost-accounting model with line-item budgets for capex, opex, contingency, inflation reserves and mitigation add-ons. Model includes three budget scenarios (baseline 2% inflation, high-cost 3%, extreme 4%) and tracks cost per phase and per unit. Establishes contingency framework (10% per phase = USD 25M total; mitigation add-ons from risk register; inflation escalation reserves 15% per phase = USD 37.5M proposed). Publishes preliminary budget reconciliation and cash-flow forecast showing Phase 2 and Phase 3 funding gaps if any. Identifies shortfall amount and proposes mitigation options (host cost-sharing, additional funders, reduced unit count, extended timeline).

**Responsible Body/Role:** Finance & Variance Monitoring Committee, supported by accountant/controller

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Detailed cost-accounting model (baseline + inflation scenarios)
- Phase-by-phase cost forecast and contingency framework
- Cash-flow forecast (Months 0–120 = 2026-10-12 to 2036-10-12)
- Budget reconciliation report identifying any phase funding gaps
- Mitigation options analysis (cost-sharing, additional funders, scope reduction)

**Dependencies:**

- Cost-audit preliminary results available
- Preliminary staffing and opex estimates locked
- Inflation assumptions agreed (baseline 2%, sensitivities 3% and 4%)

### 14. General Counsel and Legal Committee draft standardised source-agreement template and tiered indemnity structures. Template to include: (1) scope of digitization and media handling; (2) copyright and privacy-review protocols; (3) data-transfer and residency terms; (4) tiered indemnity (full indemnity for stable material, documented waiver for high-risk items); (5) incident-response and notification obligations; (6) access-control and use restrictions for recovered data. Include jurisdiction-specific annexes for GDPR, UK DPA and other applicable laws. Circulate template to Board for review and approval before pilot site agreements are signed.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by external copyright and archival-law counsel

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Source-agreement template (master version)
- Tiered indemnity structure (Full, Conditional, Waiver tiers)
- Jurisdiction-specific annexes (GDPR, UK DPA, templates for other jurisdictions)
- Incident-response protocol (24-hour notification, privacy-breach handling)
- Board-approved legal framework document

**Dependencies:**

- Jurisdiction-mapping matrix completed
- Legal Committee formed
- General Counsel and external legal counsel available

### 15. Technical Committee establishes a retired-engineer mentor-recruitment and commitment process. Identify 6–8 retired broadcast and film engineers (aged 70–80) with deep expertise in tape azimuth alignment, film registration, head calibration and mechanical repair. Secure written commitments for intensive 18–24 month mentoring periods, with retention bonuses and consulting-role incentives extending through Month 48 (2030-10-12). Create mentoring contracts that specify: (1) key technical competencies to transfer (50+ modules across three line types); (2) successor engineer assignments (2–3 per mentor); (3) documentation and knowledge-base output; (4) retention milestones. Aim for signed mentoring agreements by Month 1–3 (2026-11-12 to 2027-01-12).

**Responsible Body/Role:** Technical Committee, supported by human resources and programme management

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Retired-engineer identification and recruitment list (6–8 candidates)
- Mentoring contracts (signed, specifying competencies, successors, durations, incentives)
- Mentoring curriculum outline (50+ competencies across Tape, Film, Card)
- Successor-engineer assignment list and commitment letters
- Mentoring schedule and knowledge-transfer milestones

**Dependencies:**

- Technical Committee formed
- Budget allocated for mentor retention bonuses (USD 500K–1M estimate)
- Networks to reach retired broadcast and film engineers established

### 16. Site Selection Committee drafts the Triage Doctrine for site prioritization. Triage Doctrine to define: (1) condition-based scoring (media degradation risk, format vulnerability, storage condition); (2) value-based scoring (research importance, cultural significance, archival prestige); (3) logistics-based scoring (host readiness, power stability, security); (4) weighting and prioritization rule (condition-first, value-first, or hybrid); (5) transparency and appeal process (sites notified of their priority score and rationale; disputes resolved by Committee). Circulate draft to Programme Board and all identified pilot and Phase 2 archives for feedback by Month 3–4 (2027-01-12 to 2027-02-12). Schedule stakeholder workshop for Month 4 (2027-02-12) to gather consensus before finalizing.

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee, supported by archivists and preservation experts

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Draft Triage Doctrine with scoring criteria and prioritization logic
- Condition-degradation assessment framework (media age, storage, format type)
- Site-scoring spreadsheet (preliminary, for 30+ planned archives)
- Stakeholder-workshop agenda and invitation list
- Finalized Triage Doctrine (after Month 4 = 2027-02-12 stakeholder workshop)

**Dependencies:**

- Site Selection Committee formed
- Preliminary list of 30+ planned pilot and Phase 2 archives
- Degradation-assessment criteria and media-condition data available from archives

### 17. Finance Committee establishes Funding Commitment Registry, translating all USD 250M in pledged funds into binding multi-year contracts. Registry to distinguish: (1) committed funds (signed contracts with payment schedules); (2) pledged funds (not yet contracted; subject to annual review or board approval). For each funder, record: commitment amount, payment schedule, conditions for release (phase gates), any exclusivity or data-access terms, and risk of withdrawal. Target: 50%+ of Phase 1 (USD 30M) committed by Month 3 (2027-01-12). Identify funding gaps and propose backup sources or cost-reduction measures to close gaps. Publish quarterly Commitment Status Report to Board.

**Responsible Body/Role:** Finance & Variance Monitoring Committee, supported by funder-liaison officer and contracts administrator

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Funding Commitment Registry (spreadsheet with 15+ funder records)
- Distinction of committed vs. pledged funds by funder and phase
- Risk assessment per funder (withdrawal risk, funding-cycle timing)
- Funding-gap analysis and mitigation options (additional funders, cost-share, scope reduction)
- Commitment Status Report (first quarterly report by Month 3 = 2027-01-12)

**Dependencies:**

- List of 15+ funder organisations and pledges available
- Commitment threshold targets set (50% Phase 1 by Month 3 = 2027-01-12, 70% Phase 2/3 before phases start)
- Finance Committee formed

### 18. Programme Board conducts formal gate-approval for Phase 1 and Phase 2 gates. Board reviews and formally approves the gate criteria (digitization success >95%, uptime >90%, AI accuracy >75%, review flagging <20%, zero incidents), the evidence-collection plan, and the decision mechanism. Board establishes a best-efforts override rule: results at >=80% of targets (flagging <=25%) allow conditional limited Phase 2 tranche with Board approval; results below 80% trigger governance reassessment and potential phase deferral. Document gate criteria in a Board-approved Gate Framework document. Publish gate criteria to all funders and archives for transparency.

**Responsible Body/Role:** Programme Board, advised by Technical and Finance Committees

**Suggested Timeframe:** Month 3–4 (2027-01-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Criteria (approved and published)
- Phase 2 Gate Evidence-Collection Plan
- Best-efforts override rule and conditional-release threshold (>=80% of targets)
- Gate Decision Mechanism document (how evidence is adjudicated; voting threshold for Board release)
- Published Gate Framework (communicated to funders and archives)

**Dependencies:**

- Programme Board formed
- Technical Committee proposals for success metrics available
- Finance Committee readiness assessment available
- Pilot timeline and schedule known

### 19. Finance Committee locks Phase 1 budget and staffing by Month 4 (2027-02-12), incorporating results of the cost audit and reconciliation. If cost audit shows the USD 250M cap is insufficient for full 30-unit scope, Finance Committee recommends to Board: (1) host cost-sharing to close funding gap; (2) new consortium or government funders; (3) phased unit reduction from 30 to 20–22 units; or (4) timeline extension to Month 144–156 (2038-10-12 to 2039-10-12). Board makes strategic decision by Month 4 (2027-02-12). Once scope and budget are locked, establish detailed Phase 1 cost-control plan: monthly cost tracking, 10% contingency reserve (USD 6M for Phase 1), inflation reserve (USD 9M proposed), and design contingency (USD 5M from contingency). Publish locked budget and staffing to all stakeholders.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 3–4 (2027-01-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Phase 1 locked budget (capex, opex, contingency, inflation reserve, mitigation add-ons)
- Phase 1 locked staffing (unit count, crew size per role, total headcount)
- Cost-reconciliation report with Board-approved scope decision
- Mitigation strategy if funding gap exists (cost-sharing, new funders, scope reduction)
- Phase 1 cost-control plan (monthly tracking, reserves, stop-loss triggers)
- Published budget and staffing baseline

**Dependencies:**

- Cost-audit results final
- Finance Committee formed
- Programme Board approval of scope and budget trade-offs

### 20. Project Manager formally appoints the Interim Retrofit and Integration Lead, who will oversee the physical retrofit of the three pilot units (1 Tape Line, 1 Film Line, 1 Card/Disk Line). Interim Lead coordinates with Technical Committee on design finalization and manages the containerized-unit retrofit schedule and budget. Establish a Retrofit Project Team (mechanical engineer, electrical engineer, software integration lead, QA specialist) and define daily standups or weekly build meetings. By Month 4 (2027-02-12), begin procurement of long-lead container retrofit services, equipment (tape decks, film scanners, card readers) and robotics from RFQ responses. Target first unit shipping for retrofit by end of Month 4 (2027-02-12); retrofit completion by Month 5 (2027-03-12).

**Responsible Body/Role:** Project Manager, supported by designated Interim Retrofit and Integration Lead

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Interim Retrofit and Integration Lead appointed and onboarded
- Retrofit Project Team staffed (mechanical, electrical, software, QA)
- Retrofit-schedule and budget plan (Months 4–5 = 2027-02-12 to 2027-03-12)
- Equipment and robotics RFQs issued and responses reviewed
- Long-lead procurements initiated (containers, decks, scanners, robotics)

**Dependencies:**

- Technical Committee design finalized and approved
- Design Contingency Pool (USD 5M) allocated
- Container retrofit services vendors identified

### 21. Technical Committee tests AI pre-screening and signal-reconstruction models on the 100–200 representative test samples (arrived by Month 4 = 2027-02-12). Testing includes: (1) measure precision, recall and false-positive rate per format-category (tape, film, card) and degradation level; (2) measure reconstruction accuracy (audio/video fidelity vs. gold-standard reference); (3) measure metadata accuracy (OCR, speech-to-text) per language and content type; (4) publish results by content category and identify any accuracy shortfalls. If precision/recall is <75% on any category, commission iterative model retraining by Month 6 (2027-04-12). Document all results in AI Validation Report. Use test results to calibrate pilot review-pod staffing and expectations.

**Responsible Body/Role:** Technical Committee (AI Lead) and external AI validation team

**Suggested Timeframe:** Month 4–5 (2027-02-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- AI Validation Report (precision/recall per format-category and degradation level)
- Reconstruction-accuracy measurements vs. gold standard
- Metadata-accuracy results (OCR, speech-to-text) by language and content type
- Any accuracy shortfalls identified; retraining plan if <75%
- AI deployment-readiness assessment for pilot

**Dependencies:**

- Test samples (100–200 items) received from archives
- Gold-standard labeling completed
- AI models trained on representative data available

### 22. Site Selection Committee conducts site-readiness pre-work for three pilot archives. Each site receives: (1) power-quality audit (voltage stability, frequency, generator capacity); (2) fire-authority pre-consultation on pre-treatment ovens and hazmat risks; (3) insurer pre-notification on equipment and media-handling coverage; (4) security and facility audit (hardstand, climate control, access, locking); (5) staff-liaison identification and initial training. Target: written fire-authority and insurer approval by Month 6 (2027-04-12) before unit deployment. If site fails readiness gate at Month 6 (2027-04-12), defer by 3–6 months and move up a backup site from Priority Waitlist. Publish Site Readiness Scorecard for each pilot archive.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager, supported by logistics and facilities specialists

**Suggested Timeframe:** Month 3–6 (2027-01-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Power-quality audit report for each pilot site
- Fire-authority pre-consultation letters and preliminary approval (written)
- Insurer pre-approval letters (equipment and media-handling coverage)
- Facility-readiness assessment (hardstand, climate, security, access)
- Staff-liaison identification and initial training completion
- Site Readiness Scorecard for each pilot site (target 90%+ ready by Month 6 = 2027-04-12)

**Dependencies:**

- Three pilot archives formally agreed to participate
- Site Selection Committee formed
- Preliminary design specifications known (power, footprint, pre-treatment needs)

### 23. Site Selection Committee completes Triage Doctrine (after stakeholder input and Board approval). Publish final Triage Doctrine with condition-degradation scoring, site-prioritization ranking for 30+ planned archives and transparency mechanism (each archive receives its priority score and rationale). Establish Master Schedule and Queue Management System with 5-year rolling forecast showing which units deploy to which sites and in which months. Build in contingency buffers (2–3 month surge-buffer pools) and defer-swap mechanisms for sites that fail readiness or withdraw. Notify all 30+ archives of their scheduled residency windows 12 months in advance (earliest pilot sites notified by Month 6 = 2027-04-12).

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Finalized Triage Doctrine (approved by Board and archives)
- Master Schedule and Queue Management System (5-year rolling forecast)
- Site-prioritization rankings for 30+ archives with scoring and rationale
- Priority Waitlist and surge-buffer contingency guidelines
- 12-month advance notification letters to all archives (pilot sites by Month 6 = 2027-04-12)

**Dependencies:**

- Site Selection Committee formed
- Stakeholder workshop completed (Month 4 = 2027-02-12)
- Board approval of Triage Doctrine
- 30+ planned archives and their characteristics available

### 24. General Counsel and Legal Committee establish Privacy Review Panel with 2–3 data-protection experts (one per major jurisdiction/language group). Panel develops detailed decision criteria for flagging content: (1) personal data types (PII, medical records, financial data); (2) copyright markers (logos, watermarks, broadcast credits); (3) classification markers (government stamps, security labels); (4) sensitivity thresholds (what flagging triggers automatic review vs. lower-risk tiers). Train panel members on decision-making, documentation and appeal processes. Panel begins test runs on pilot-archive samples by Month 6 (2027-04-12) to calibrate flagging rates and reviewer accuracy. Document all decisions in Privacy Review Panel Log, with rationale and appeals.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by Privacy Review Panel members

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Privacy Review Panel composition finalized (2–3 experts, one per jurisdiction)
- Decision-criteria document (personal data types, copyright, classification, thresholds)
- Panel training curriculum and competency checklist
- Privacy Review Panel Log template (decision log with rationale, appeals)
- Test-run results on pilot-archive samples (flagging rates, accuracy)
- Reviewer qualification and ongoing-training plan

**Dependencies:**

- Legal Committee formed
- Data-protection experts identified and available
- Test samples available for trial runs
- Source-agreement templates approved

### 25. Legal Committee engages insurers and fire-authority experts to design hazmat-control and fire-safety standards for pre-treatment pods (baking ovens, humidity chambers). Develop a Pre-Treatment Hazard Control Design Standard specifying: (1) oven thermal management and insulation; (2) VOC capture and ventilation (with monitored exhaust); (3) fire suppression (foam or CO2); (4) separation from main digitization container (detached pod vs. certified-suppressed internal subsystem); (5) occupational safety (respiratory protection, air-quality monitoring); (6) handling of degraded media with asbestos or mercury. By Month 6 (2027-04-12), obtain written insurer and fire-authority approval of the standard at one pilot site. If approval is contingent on detached pods, budget USD 0.5–1.5M per unit for detached-pod retrofit (USD 1.5–4.5M for three pilots).

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by industrial-hygiene and fire-safety consultants

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Pre-Treatment Hazard Control Design Standard (oven, humidity, ventilation, fire suppression)
- VOC monitoring and respiratory-protection protocol
- Occupational Health and Safety (OHS) compliance checklist
- Detached-pod design option (cost estimate: USD 0.5–1.5M each)
- Written fire-authority approval at one pilot site
- Written insurer approval at one pilot site
- Risk-mitigation letter to Hazmat Risk Board Trigger (if approval is conditional)

**Dependencies:**

- Legal Committee formed
- Industrial-hygiene and fire-safety consultants engaged
- One pilot-site fire-authority and insurer pre-consulted
- Preliminary container design specifications available

### 26. Technical Committee completes Design Review Gate (DRG) preparation and schedule. By Month 6 (2027-04-12), finalize all design specifications for the three pilot line types (Tape, Film, Card/Disk). Submit designs to independent external technical review (university engineering department or broadcast-equipment specialist) for sign-off on feasibility, performance, tolerance, reliability and safety. Each major subsystem (climate, power, robotics, AI, on-board storage) undergoes independent review. Target design freeze by Month 20 (2028-06-12). Any post-freeze changes require Programme Board approval and impact analysis.

**Responsible Body/Role:** Technical Committee, supported by external technical reviewer

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Finalized design specifications for Tape, Film, and Card line types
- Submission of designs to external technical reviewer
- DRG sign-off criteria checklist (performance, tolerance, safety, reliability)
- Design-change control procedure (post-freeze authority and approval)
- Design-freeze schedule and gate-readiness timeline (by Month 20 = 2028-06-12)

**Dependencies:**

- Technical Committee formed
- All preliminary specifications finalized (climate, power, robotics, AI, storage)
- External technical reviewer identified and engaged
- Budget for independent review (USD 30–50K estimate)

### 27. Project Manager signs formal, multi-year (2–3 year) residency agreements with the three pilot archives. Agreements incorporate: (1) source-agreement template approved by Legal Committee; (2) tiered indemnity (Full for stable material, Conditional for uncertain condition); (3) cost-sharing or in-kind contributions (power, space, staff liaison); (4) media-handling and copyright-review protocols; (5) incident-response and notification procedures; (6) access controls and use restrictions for recovered data; (7) termination clauses (either party can terminate with 90 days' notice, with wind-down procedures). Signatures to be obtained by Month 6 (2027-04-12) before unit deployment. Legal Committee reviews each agreement for compliance with jurisdiction-specific annexes.

**Responsible Body/Role:** Project Manager and General Counsel

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Executed residency agreements (3 pilot archives, signed)
- Cost-sharing or in-kind contribution details per archive
- Media-handling protocols and copyright-review procedures
- Indemnity tier assignment per collection or media type
- Incident-response contacts and 24-hour notification procedures
- Archive attestation that fire authority and insurer approve unit residency

**Dependencies:**

- Three pilot archives identified and agreed
- Source-agreement template finalized and approved by Board
- Fire-authority and insurer approvals in writing from archives
- Cost-sharing or in-kind contribution negotiations completed

### 28. Interim Retrofit and Integration Lead completes retrofit of the first Mobile Ingest Unit (1 Tape Line). Physical retrofit includes: container base, climate-control systems, power systems (facility connection + 200kW backup generator), on-board storage (500TB buffer), robotics integration, tape-deck mounting and calibration, AI processing workstations, satellite and fiber connectivity, and on-board monitoring (power, climate, equipment status). By Month 5 (2027-03-12), complete all subsystem integration and bench-testing (climate stability ±2°C / ±10% RH, power stability, robotics repeatability, AI processing latency). By end of Month 5 (2027-03-12), container is ready for deployment to first pilot site.

**Responsible Body/Role:** Interim Retrofit and Integration Lead and Retrofit Project Team

**Suggested Timeframe:** Month 4–5 (2027-02-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- Completed Tape-Line retrofit (container, systems, integration)
- Bench-test results (climate, power, robotics, AI, connectivity)
- Subsystem certification (climate ±2°C/±10% RH, power stability, robotics tolerance)
- Unit readiness report (safe to deploy; all systems operational)
- Transportation and deployment logistics plan to first pilot site

**Dependencies:**

- Container and equipment procured
- Retrofit services vendor contracted
- Design freeze approval from Technical Committee
- First pilot site readiness gate passed (fire authority, insurer, power, facility)

### 29. Project Manager and Site Selection Committee coordinate logistics and transport of the first pilot unit (Tape Line) to the first pilot archive. This includes: (1) finalizing trucking or shipping logistics (routing, temporary-import documentation, customs pre-clearance); (2) confirming on-site hardstand and power connection ready; (3) scheduling unit arrival aligned with archive staff availability; (4) coordinating on-site setup (power connection, climate stabilization, safety walkthrough, staff briefing). Target unit arrival at first pilot site by Month 6 (2027-04-12). On-site setup takes 1–2 weeks; begin digitization intake and operations by Month 6 (2027-04-12).

**Responsible Body/Role:** Site Selection Committee and Logistics Coordinator

**Suggested Timeframe:** Month 5–6 (2027-03-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Unit transport logistics plan (trucking/shipping, routing, documentation)
- Temporary-import paperwork and customs pre-clearance
- On-site setup checklist and timeline
- Safety walkthrough and staff-briefing materials
- Unit arrival confirmation and on-site setup completion
- Digitization intake start (Months 6–20 = 2027-04-12 to 2028-06-12)

**Dependencies:**

- First unit retrofit completed and ready to ship
- First pilot site readiness gate passed
- Residency agreement signed
- On-site power, hardstand and climate infrastructure confirmed ready

### 30. Interim Retrofit and Integration Lead completes retrofit and deployment of the second and third pilot units (1 Film Line and 1 Card/Disk Line) in parallel with the first unit's operation. Retrofit schedule targets completion by Month 8–9 (2027-06-12 to 2027-07-12) and deployment to second and third pilot sites by Month 9–12 (2027-07-12 to 2027-10-12). Apply lessons learned from first unit's retrofit and pilot operations (any design tweaks, component substitutions) to units 2 and 3.

**Responsible Body/Role:** Interim Retrofit and Integration Lead and Retrofit Project Team

**Suggested Timeframe:** Month 5–12 (2027-03-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Completed Film-Line and Card/Disk-Line retrofits
- Bench-test results and subsystem certification for both units
- Deployment logistics plans and timelines for sites 2 and 3
- On-site setup and intake-readiness confirmations
- Lessons-learned feedback from first unit incorporated into units 2 and 3

**Dependencies:**

- Design-freeze approval from Technical Committee
- Pilot sites 2 and 3 readiness gates passed
- Residency agreements signed for sites 2 and 3
- Retrofit vendor capacity available for parallel builds

### 31. Technical Committee establishes the Pilot Review Pod: a dedicated team of 5–10 multilingual reviewers embedded with or co-located near the first pilot unit during Months 6–8 (2027-04-12 to 2027-06-12). The Review Pod runs a controlled pilot of the pre-screening and human-review workflow on real content from the first archive. Reviewers flag content per Privacy Review Panel criteria (personal data, copyright, classification) and measure: (1) flagging rate (what % of content is flagged?); (2) review time per content hour; (3) AI pre-screen precision and recall; (4) inter-reviewer agreement on flagged decisions; (5) any systematic bias or accuracy drift. Produce a Pilot Review Pod Report by Month 8 (2027-06-12) showing actual review load and flagging rates. If flagging rate is >25%, escalate to Technical Committee for AI retraining or workflow redesign.

**Responsible Body/Role:** Technical Committee and Pilot Review Pod (5–10 reviewers)

**Suggested Timeframe:** Month 6–8 (2027-04-12 to 2027-06-12)

**Key Outputs/Deliverables:**

- Pilot Review Pod staffed (5–10 reviewers, multilingual)
- Review workflow tested on real content from first archive
- Flagging rate measured (target <20%, investigate if >25%)
- Review time per content hour measured (target 1:2 ratio or better)
- AI precision/recall per content category measured
- Inter-reviewer agreement metrics (Cohen's kappa or similar)
- Pilot Review Pod Report (Month 8 = 2027-06-12), with recommendations for crew composition

**Dependencies:**

- First pilot unit operating with real content intake
- Privacy Review Panel criteria finalized
- AI models tested and deployed in first unit
- Reviewers recruited and trained (Month 4–6 = 2027-02-12 to 2027-04-12)

### 32. Technical Committee monitors the three pilot units' operational metrics during Months 6–20 (2027-04-12 to 2028-06-12). Establish a central Fleet Management Telemetry system that collects data from all three pilots: (1) equipment uptime per subsystem (tape decks, film scanners, robotics, climate, power); (2) mean time between failures (MTBF) and parts consumption; (3) digitization success rate (% of items processed without error); (4) reconstruction accuracy (audio/video/data fidelity); (5) AI metadata accuracy (OCR, speech-to-text); (6) human review flagging rate and reviewer time. Publish monthly telemetry reports to Technical Committee and Board. Set alarm thresholds: if uptime drops <90%, or reconstruction/AI accuracy drops below target, escalate to Committee for root-cause analysis and remediation.

**Responsible Body/Role:** Technical Committee and Central Fleet Management Team

**Suggested Timeframe:** Month 6–20 (2027-04-12 to 2028-06-12)

**Key Outputs/Deliverables:**

- Fleet Management Telemetry System operational (data collection from three pilots)
- Monthly telemetry reports (uptime, MTBF, digitization success, reconstruction accuracy, AI accuracy, flagging rate)
- Alarm thresholds and escalation triggers defined
- Root-cause analysis and remediation tracking for any threshold breaches

**Dependencies:**

- All three pilot units deployed and operating
- On-board monitoring and telemetry hardware/software installed
- Central operations center staffed and ready to receive telemetry

### 33. Technical Committee conducts stress testing of the first pilot unit by deliberately directing it toward the worst-condition collection material available at the first archive site. Stress testing runs for Months 6–12 (2027-04-12 to 2027-10-12) and focuses on: (1) severely degraded media (tapes with layer adhesion, film with shrinkage, cards with fading); (2) non-English speech and handwritten metadata (to stress AI models); (3) media with unknown or uncertain copyright status (to stress privacy review). Document all failure modes, recovery procedures and root causes. Use stress-test results to identify design weaknesses before design freeze (Month 20 = 2028-06-12). This honest failure data informs Phase 2 design decisions and risk mitigations.

**Responsible Body/Role:** Technical Committee and First Pilot Unit Crew

**Suggested Timeframe:** Month 6–12 (2027-04-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Stress-test plan (worst-condition collections and edge cases identified)
- Stress-test execution log (media processed, failure modes encountered)
- Root-cause analysis for each failure mode
- Design-weakness assessment and redesign recommendations
- Stress-test report (Month 12 = 2027-10-12), with lessons for Phase 2 units

**Dependencies:**

- First pilot unit operating
- First archive has challenging, worst-condition collections available
- Technical Committee and engineering team available for real-time problem-solving

### 34. Finance Committee conducts the first quarterly Cost-and-Variance Report (Month 6 = 2027-04-12). Report includes: (1) Phase 1 actual capex and opex spend to date vs. budget; (2) cumulative variance (over/under); (3) forecast at completion for Phase 1; (4) contingency and reserves status; (5) inflation impact (actual YoY cost escalation vs. 2%/3%/4% scenarios); (6) funder-commitment status (funds received, pledged, at-risk). If cumulative variance is >5%, escalate to Board for review. If variance is >10%, Board triggers governance re-assessment. Publish report to Programme Board and all funders quarterly (Months 6, 9, 12, 15 = 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, etc.) through Month 120 (2036-10-12).

**Responsible Body/Role:** Finance & Variance Monitoring Committee

**Suggested Timeframe:** Month 6 (2027-04-12) and quarterly thereafter

**Key Outputs/Deliverables:**

- Quarterly Cost-and-Variance Report (Month 6 = 2027-04-12 first edition)
- Phase 1 actual spend vs. budget (capex, opex, contingency, inflation reserve)
- Cumulative variance and forecast at completion per phase
- Funder-commitment status and funding-gap assessment
- Escalation flags if variance >5% or >10%

**Dependencies:**

- Finance Committee established and monthly accounting in place
- Monthly cost-tracking system operational
- Funder commitment registry maintained

### 35. Technical Committee formally applies Design Review Gate (DRG) criteria to the three pilot units. All major subsystems undergo independent technical review for sign-off. Submission package to external reviewer includes: (1) final design specifications; (2) bench-test and pilot-operations data (climate, power, uptime); (3) stress-test results and failure-mode analysis; (4) lessons-learned and design-improvement recommendations; (5) spare-parts and maintenance protocols. External reviewer independently assesses feasibility, reliability, safety and performance. Target DRG sign-off by Month 20 (2028-06-12).

**Responsible Body/Role:** Technical Committee, supported by external technical reviewer

**Suggested Timeframe:** Month 18–20 (2028-04-12 to 2028-06-12)

**Key Outputs/Deliverables:**

- DRG submission package (finalized designs, test data, lessons learned)
- External reviewer technical assessment (independent report)
- Design sign-off by external reviewer (or conditional sign-off with rework list)
- Design-freeze certification (designs locked; post-freeze changes require Board approval)
- Change-control procedures for Phase 2 and Phase 3 units

**Dependencies:**

- All three pilots operational and generating at least 12 months of telemetry data
- Stress-test and lessons-learned analysis completed
- External reviewer available and ready to assess

### 36. Technical Committee and Privacy Review Panel consolidate all pilot evidence against the Phase 2 Gate Criteria. Evidence package includes: (1) digitization success rate >95% across all three pilots; (2) reconstruction accuracy >80% per format-category; (3) automated metadata accuracy >70% per language/content type; (4) human review flagging rate <20% (or AI retraining plan if >25%); (5) uptime >90% with mean time between failures data; (6) AI pre-screen precision and recall >=75% per category-format (or retraining results showing improvement to >=75%); (7) zero privacy/legal incidents; (8) design-freeze sign-off from external reviewer; (9) parts-depletion model showing feasible spares management; (10) retired-engineer mentoring curriculum >80% complete. By Month 20 (2028-06-12), produce a Phase 2 Gate Evidence Report summarizing all findings. If any metric falls below target, the Committee recommends either: (a) conditional limited Phase 2 tranche (if >=80% of thresholds met, per best-efforts override rule); (b) governance re-assessment (if <80% or if a critical threshold like uptime is missed).

**Responsible Body/Role:** Technical Committee and Privacy Review Panel

**Suggested Timeframe:** Month 18–24 (2028-04-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Evidence Report (Month 20 = 2028-06-12, comprehensive metrics package)
- Digitization success, reconstruction accuracy, metadata accuracy: actual rates per pilot and format-category
- Uptime and MTBF data (monthly trending, alarm thresholds, corrective actions)
- Human review flagging rate: actual % and comparison to <20% target
- AI precision/recall per category-format: results and any retraining outcomes
- Privacy and legal incident log (zero incidents confirmed)
- Design-freeze and external-reviewer sign-off confirmation
- Parts-depletion model and maintenance-readiness assessment
- Retired-engineer mentoring progress (curriculum completion, successor competency assessments)

**Dependencies:**

- All three pilots have >=12 months of operational data (Months 6–20 = 2027-04-12 to 2028-06-12)
- Pilot Review Pod and telemetry system producing consistent data
- External technical reviewer has completed design assessment
- Privacy Review Panel has reviewed all flagged content from pilots

### 37. Finance Committee consolidates Phase 2 Gate Financial Readiness assessment. Checklist includes: (1) Phase 1 cumulative variance <=10% (or Board has approved re-baseline); (2) Phase 2 funding is >=70% committed (not pledged) by Month 24 (2028-10-12); (3) Phase 1 has spent within contingency reserve (10% = USD 6M); (4) Phase 2 locked budget and staffing (unit count, crew size) approved by Board; (5) Phase 3 funding gaps identified and mitigation plan in place (cost-sharing, additional funders, scope reduction); (6) inflation reserves adequate per 2%/3%/4% scenarios. By Month 24 (2028-10-12), produce Phase 2 Gate Financial Readiness Report. If Phase 2 commitment is <70%, Committee recommends governance decision: delay Phase 2 start (contingency funding bridge activated), reduce Phase 2 unit count (12 becomes 8–10), or seek emergency funder commitments.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 24 (2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Financial Readiness Report (Month 24 = 2028-10-12)
- Phase 1 spend summary and final variance (actual vs. budget, contingency usage)
- Phase 2 funding commitment status (% committed, payment schedules, at-risk funders)
- Phase 2 locked budget and staffing (12 units, crew size per role, total headcount)
- Phase 3 funding gap assessment and mitigation options (cost-sharing, new funders, scope reduction)
- Inflation impact summary (cumulative 2% vs. 3% vs. 4%)
- Go/no-go financial recommendation for Phase 2 release

**Dependencies:**

- Phase 1 actual spend finalized and reconciled
- Funding Commitment Registry updated with all pledges and commitments
- Board-approved Phase 2 and Phase 3 budget and staffing locked

### 38. Programme Board holds a formal Phase 2 Release Gate Meeting at Month 24 (2028-10-12). Board reviews the Phase 2 Gate Evidence Report (Technical Committee) and Phase 2 Gate Financial Readiness Report (Finance Committee). Board votes on Phase 2 release using the following decision rule: (a) If all gate criteria met (digitization >95%, uptime >90%, AI accuracy >75%, review flagging <20%, zero incidents, design freeze, Phase 2 funding >=70% committed), Board approves full Phase 2 release and authorizes drawdown of Phase 2 funds (USD 120M). (b) If results are 80–99% of targets (flagging <=25%, at least 1 critical threshold met), Board may approve conditional limited Phase 2 tranche (e.g., USD 30–50M for 4–6 units) with rework and revalidation required. (c) If results are <80% of targets or a critical threshold is missed (uptime <90%, reconstruction accuracy <75%, design not frozen, Phase 2 funding <70% committed), Board triggers governance re-assessment: phase deferral, scope reduction, or emergency mitigation. Board documents decision in a Phase 2 Gate Decision Memo and notifies all funders and archives.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 24 (2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Release Gate Meeting minutes and decision log
- Phase 2 Gate Decision Memo (approved for release, conditional release, or governance re-assessment)
- Authorization to drawdown Phase 2 funds (if approved)
- Escalation triggers or rework plans (if conditional or deferred)
- Notification to funders and archives (scheduled deployment timeline for Phase 2 units)

**Dependencies:**

- Phase 2 Gate Evidence Report completed (Technical Committee)
- Phase 2 Gate Financial Readiness Report completed (Finance Committee)
- Board meeting scheduled and all members present or voting by proxy

### 39. Project Manager and Retrofit Lead begin procurement of long-lead components for Phase 2 units (12 additional Mobile Ingest Units). Procurement includes: (1) 12 containers and retrofit services; (2) tape decks, film scanners, card readers (from RFQ responses); (3) robotics and automation systems; (4) climate-control and power systems; (5) AI processing workstations; (6) on-board storage and connectivity hardware. Order long-lead items (containers, robotics, power supplies) by Month 24 (2028-10-12) to ensure delivery by Months 28–32 (2029-02-12 to 2029-06-12). Retrofit schedule targets completion of Phase 2 units by Months 30–40 (2029-04-12 to 2030-04-12).

**Responsible Body/Role:** Project Manager and Interim Retrofit Lead, supported by procurement team

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- RFQs issued for Phase 2 containers, equipment, robotics and systems
- Vendor selection and contracts executed
- Long-lead procurement orders placed (containers, robotics, power)
- Delivery timeline and retrofit schedule (Months 28–40 = 2029-02-12 to 2030-02-12)
- Retrofit-project plan for 12 units in parallel tracks

**Dependencies:**

- Design freeze approved by Board (from Phase 2 Gate)
- Phase 2 funds authorized for drawdown (USD 120M or conditional tranche)
- Vendor relationships and RFQ responses received

### 40. Site Selection Committee continues site-readiness pre-work for Phase 2 archives (15+ sites). By Month 28 (2029-02-12), complete readiness audits for the first 4–6 Phase 2 sites scheduled to receive units in Months 28–36 (2029-02-12 to 2029-10-12). Obtain fire-authority and insurer written approvals for each site, similar to pilot sites. Sign formal residency agreements (2–3 years, with terms per Legal Committee template). Notify remaining Phase 2 sites (7–10) of their scheduled residency windows and begin readiness pre-work 6 months before scheduled unit arrival.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager

**Suggested Timeframe:** Month 24–28 (2028-10-12 to 2029-02-12)

**Key Outputs/Deliverables:**

- Phase 2 site-readiness audits for first 4–6 sites (power, fire authority, insurer, facility)
- Written fire-authority and insurer approvals for Phase 2 sites
- Executed residency agreements (Phase 2 sites, multi-year terms)
- Notification letters to remaining Phase 2 sites (residency windows and readiness schedule)
- Master Schedule updated with confirmed Phase 2 site assignments and timing

**Dependencies:**

- Site Selection Committee active
- Phase 2 unit deployment timeline known (from Retrofit Lead)
- Triage Doctrine and site prioritization finalized

### 41. Technical Committee continues Retired-Engineer Mentoring Program through Months 24–48 (2028-10-12 to 2030-10-12). Ensure all mentors remain engaged (retention bonuses active), curriculum modules are completed on schedule, and successor engineers (2–3 per mentor) have achieved competency milestones. By Month 36 (2029-10-12), at least 70% of the 50+ critical competencies should be documented in a Digital Knowledge Base (accessible to all engineers). Conduct competency assessments of successors at Months 24, 36 and 48 (2028-10-12, 2029-10-12, 2030-10-12) to ensure knowledge transfer is on track. If a mentor becomes unavailable, activate redundancy (backup mentor identified in advance). By Month 48 (2030-10-12), successors should be able to operate independently or with minimal mentoring.

**Responsible Body/Role:** Technical Committee and Retired-Engineer Mentoring Program Lead

**Suggested Timeframe:** Month 24–48 (2028-10-12 to 2030-10-12), ongoing

**Key Outputs/Deliverables:**

- Mentoring curriculum progress tracking (modules completed, competency assessments)
- Successor-engineer competency milestones met (Month 24, 36, 48 = 2028-10-12, 2029-10-12, 2030-10-12 checkpoints)
- Digital Knowledge Base development (documentation of 50+ competencies; 70% complete by Month 36 = 2029-10-12)
- Mentor retention and availability status (any changes, redundancy activation)
- Knowledge-transfer risk assessment (any gaps identified; remediation plans)

**Dependencies:**

- Mentoring contracts in place with incentives and retention terms
- Successor engineers assigned and in training
- Digital Knowledge Base platform and documentation templates established

### 42. Programme Board convenes a Contingency Funding Panel by Month 24–30 (2028-10-12 to 2029-04-12) if there are indications that Phase 3 funding will not be secured by the target date (Month 48 = 2030-10-12). The Panel identifies alternative funding sources (government supplemental budgets, additional philanthropic foundations, technology-sector non-exclusive licensing, cost-sharing with archives) that can provide a backup USD 15–30M bridge if Phase 3 commitments fall short. By Month 54 (2031-04-12) (before Phase 3 gate at Month 60 = 2031-10-12), finalize contingency funding or implement a scope reduction (Phase 3 unit count reduced from 15 to 10–12).

**Responsible Body/Role:** Programme Board and Finance Committee

**Suggested Timeframe:** Month 24–54 (2028-10-12 to 2031-04-12)

**Key Outputs/Deliverables:**

- Contingency Funding Panel formed (Month 24–30 = 2028-10-12 to 2029-04-12)
- Alternative funding sources identified and vetted (Month 30–48 = 2029-04-12 to 2030-10-12)
- Contingency-funding letters of intent or commitments (by Month 54 = 2031-04-12)
- Scope-reduction plan (if contingency funding is insufficient; reducing Phase 3 units from 15 to 10–12)

**Dependencies:**

- Phase 3 funding commitment status tracked quarterly by Finance Committee
- Programme Board authorized to seek alternative sources

### 43. Technical Committee commissions a Phase 2 design-change and lessons-learned review. By Month 26 (2028-12-12), analyze all pilot-unit issues encountered during Months 6–24 (2027-04-12 to 2028-10-12) and determine which require design changes for Phase 2 units. Examples: if climate control drifted in hot climates, enhance dehumidification; if robotics showed repeatability issues, upgrade arm actuators; if power instability occurred, add voltage regulators. For each design change, estimate cost, schedule impact (delay to Phase 2 deployment) and risk (if change introduces new failure modes). Board approves design changes <USD 2M and <2 month delay by exception; changes >USD 2M or >2 month delay require formal Board approval.

**Responsible Body/Role:** Technical Committee

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- Pilot lessons-learned review and documented issues (Months 6–24 = 2027-04-12 to 2028-10-12)
- Design-change recommendations for Phase 2 units
- Cost and schedule impact analysis per change
- Risk assessment (if change may introduce new issues)
- Board-approved design-change list (approved design modifications for Phase 2)

**Dependencies:**

- Pilot operations complete or mature (at least 18–24 months of data)
- Technical Committee and engineering team available for analysis

### 44. Legal Committee conducts a Phase 2 source-agreement-template refresh. Based on pilot experiences (any incident, dispute or regulatory feedback), review and update the template and tiered-indemnity structure. Ensure jurisdiction-specific annexes reflect any new case law or regulatory guidance (GDPR enforcement actions, UK data-protection decisions, national privacy law updates). By Month 26 (2028-12-12), publish revised source-agreement template v2.0 incorporating lessons from pilot sites. All Phase 2 sites sign the updated template.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- Pilot source-agreement experience review (any disputes, amendments, regulatory feedback)
- Updated source-agreement template v2.0 (revised indemnity, privacy, incident-response terms)
- Updated jurisdiction-specific annexes (reflecting new case law or regulatory guidance)
- Board approval of updated template

**Dependencies:**

- Legal Committee tracking pilot source-agreement experience
- Regulatory updates and case-law research current through Month 24 (2028-10-12)

### 45. Finance Committee locks Phase 2 budget and staffing by Month 26 (2028-12-12). This includes: (1) detailed cost forecast for Phase 2 (capex for 12 units, opex for Months 24–60 = 2028-10-12 to 2031-10-12, contingency and inflation); (2) staffing plan (crew size per unit, total headcount, salary scales, benefits); (3) revised Phase 3 funding-gap estimate incorporating Phase 2 actuals and revised inflation forecasts; (4) revised Phase 3 scope (unit count reduction if Phase 3 funding is insufficient). Publish locked Phase 2 budget and staffing to all stakeholders by Month 26 (2028-12-12). If Phase 2 budget exceeds Phase 2 authorized funds (conditional tranche case), escalate to Board for additional contingency draw or scope reduction decision.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 26 (2028-12-12)

**Key Outputs/Deliverables:**

- Phase 2 locked budget (capex, opex, contingency, inflation reserves)
- Phase 2 locked staffing (12 units, crew size per role, total headcount)
- Revised Phase 3 funding-gap analysis (incorporating Phase 2 actuals)
- Phase 3 scope reduction plan (if needed; reducing from 15 to 10–12 units)
- Published budget and staffing baseline for Phase 2

**Dependencies:**

- Phase 2 unit costs and procurement contracts finalized
- Staffing and payroll actuals from pilot phase reconciled
- Inflation escalation tracked through Month 26 (2028-12-12)

### 46. Programme Board establishes a Fleet Sunset and Equipment Afterlife Working Group by Month 28 (2029-02-12). Working Group tasked with developing an end-state plan for the programme at Month 120 (2036-10-12). End-state plan to address: (1) which units are retained for ongoing operations, transferred to archives/universities, or decommissioned; (2) parts-inventory and warehouse disposition; (3) knowledge-base stewardship and long-term access; (4) transition to post-programme funding or partnerships. Initial deliverable: end-state options paper by Month 36 (2029-10-12). Final plan by Month 48 (2030-10-12). This early planning ensures equipment procurement and depreciation schedules align with end-state strategy.

**Responsible Body/Role:** Programme Board and appointed Fleet Sunset and Equipment Afterlife Working Group

**Suggested Timeframe:** Month 28 (2029-02-12)

**Key Outputs/Deliverables:**

- Fleet Sunset and Equipment Afterlife Working Group formed (members identified)
- End-state options paper (Month 36 = 2029-10-12): unit disposition, parts inventory, knowledge-base stewardship
- Final end-state plan (Month 48 = 2030-10-12): approved by Board; guides Phase 3 operations

**Dependencies:**

- Programme Board active
- Sufficient Phase 2 funding visibility (to estimate Phase 3 unit count and operations duration)

### 47. Technical Committee and Finance Committee coordinate establishment of a Parts Inventory Management System by Month 30 (2029-04-12). System tracks: (1) all 300–500 acquired vintage machines and their status (operational, parts-source, end-of-life); (2) critical parts stock per line type (tape decks, film scanners, card readers); (3) consumption rate and depletion curves; (4) 3D-printing and CNC-fabrication schedule (which parts are re-manufactured, when); (5) re-manufacture triggers (when stock hits 50% depletion threshold). System is accessible to all on-site maintenance engineers and the central Parts Engineering team. Establish a Parts Purchasing and Fabrication Dashboard that auto-triggers orders when stock thresholds approach.

**Responsible Body/Role:** Technical Committee and Finance Committee, supported by Parts Engineering team

**Suggested Timeframe:** Month 30 (2029-04-12)

**Key Outputs/Deliverables:**

- Parts Inventory Management System operational (database or software platform)
- Vintage-machine inventory audit and status documentation
- Critical parts stock tracking (per line type, consumption curves)
- Parts re-manufacture schedule and trigger thresholds (50% depletion)
- Parts Purchasing and Fabrication Dashboard (accessible to all maintenance engineers)

**Dependencies:**

- All 300–500 vintage machines acquired and inventoried
- Parts-depletion model complete
- 3D-printing and CNC-fabrication team established

### 48. Site Selection Committee and Triage working group conduct a mid-programme triage review by Month 36 (2029-10-12). Review whether condition-degradation timelines and actual unit deployment rates allow the programme to reach all priority sites before media failure. If actual deployment is slower than planned (e.g., site-readiness delays, design rework, funding constraints), re-prioritize remaining sites based on urgency (accelerate highest-risk sites, defer lower-risk ones). Update Master Schedule and Priority Waitlist. Notify all archives of any schedule changes 12 months in advance.

**Responsible Body/Role:** Site Selection Committee and Triage working group

**Suggested Timeframe:** Month 36 (2029-10-12)

**Key Outputs/Deliverables:**

- Mid-programme triage review (actual deployment rate vs. plan; degradation timelines assessment)
- Updated site prioritization (any re-ranking based on urgency and actual capacity)
- Updated Master Schedule (5-year rolling forecast revised)
- Notification to all archives (schedule confirmations or changes)

**Dependencies:**

- Phase 2 deployment has been underway (Months 28–36 = 2029-02-12 to 2029-10-12)
- Actual deployment rates and site-readiness data available
- Triage Doctrine and Master Schedule established and operational

### 49. Finance Committee and Programme Board conduct Phase 3 financial assessment by Month 42 (2030-04-12) (6 months before Phase 3 gate at Month 48 = 2030-10-12). Assessment includes: (1) Phase 1 and Phase 2 final spend and variance; (2) Phase 3 funding commitment status (% committed, payment schedules); (3) revised Phase 3 total cost estimate (incorporating inflation to Month 120 = 2036-10-12); (4) funding gap (if any) and mitigation options (contingency draws, cost-sharing, unit reduction). If Phase 3 funding is <70% committed, activate Contingency Funding Panel for emergency fundraising. By Month 48 (2030-10-12), Board must have either (a) 70%+ of Phase 3 funds committed, or (b) Board-approved scope reduction (Phase 3 unit count reduced from 15 to 10–12, or timeline extended to Month 132–144 = 2037-10-12 to 2038-10-12).

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 42–48 (2030-04-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 financial assessment (Phase 1/2 final spend, Phase 3 funding status, cost estimate, gap analysis)
- Phase 3 funding commitment registry (% committed, payment schedules, at-risk funders)
- Contingency Funding Panel activation (if Phase 3 commitment <70%)
- Scope reduction or timeline-extension plan (if needed)
- Board decision on Phase 3 authorization (approved, conditional, or deferred)

**Dependencies:**

- Phase 1 and Phase 2 operations complete or mature enough for final cost reconciliation
- Phase 3 funder pledges and commitments tracked by Finance Committee

### 50. Technical Committee consolidates Phase 3 Gate Evidence against the established gate criteria. By Month 48 (2030-10-12), gather evidence that Phase 2 has achieved: (1) 500K+ items digitized and 25+ PB recovered (cumulative through Phase 2); (2) all 15 cumulative units (3 pilots + 12 Phase 2) with >90% trailing 6-month uptime; (3) digitization success, reconstruction accuracy and AI accuracy targets still met; (4) human review flagging <20%; (5) zero reportable privacy/legal incidents; (6) parts-depletion model showing feasible spares management through Phase 3; (7) retired-engineer mentoring >90% complete; (8) design freeze and post-freeze change control working effectively. Produce Phase 3 Gate Evidence Report. If any critical threshold is missed (uptime <90%, recovery target <500K items / <25 PB, parts model infeasible), escalate to Board for governance decision (Phase 3 approval with conditions, deferral, or scope reduction).

**Responsible Body/Role:** Technical Committee

**Suggested Timeframe:** Month 42–48 (2030-04-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 Gate Evidence Report (Month 48 = 2030-10-12, comprehensive metrics package)
- Cumulative item and data-volume totals (500K+ items, 25+ PB)
- Equipment uptime trending (trailing 6-month data for all 15 units)
- Digitization, reconstruction and AI accuracy results (trending through Phase 2)
- Privacy incident log (zero incidents confirmed)
- Parts-depletion model and spares-management feasibility assessment
- Retired-engineer mentoring completion status (curriculum, successor competency)

**Dependencies:**

- Phase 2 operations mature (18–24 months of data from Phase 2 units)
- All 15 cumulative units deployed and operational or completing residencies
- Technical telemetry system active and producing consistent data

### 51. Programme Board holds formal Phase 3 Release Gate Meeting at Month 48 (2030-10-12). Board reviews Phase 3 Gate Evidence Report (Technical Committee) and Phase 3 Financial Readiness assessment (Finance Committee). Board votes on Phase 3 release using the same decision framework as Phase 2: (a) If all gate criteria met and Phase 3 funding >=70% committed, Board approves full Phase 3 release and authorizes drawdown of Phase 3 funds (USD 70M). (b) If results are 80–99% of targets and Phase 3 funding >=70%, Board may approve conditional Phase 3 tranche with rework and revalidation. (c) If results are <80% of targets, critical thresholds are missed, or Phase 3 funding <70% committed, Board triggers governance re-assessment: phase deferral, scope reduction (reduce from 15 to 10–12 units), or timeline extension. Board documents decision in Phase 3 Gate Decision Memo and notifies all funders and archives.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 48 (2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 Release Gate Meeting minutes and decision log
- Phase 3 Gate Decision Memo (approved for release, conditional release, or governance re-assessment)
- Authorization to drawdown Phase 3 funds (if approved)
- Escalation triggers or remediation plans (if conditional or deferred)
- Notification to funders and archives (Phase 3 deployment timeline)

**Dependencies:**

- Phase 3 Gate Evidence Report completed (Technical Committee)
- Phase 3 Financial Readiness assessment completed (Finance Committee)
- Programme Board meeting scheduled and all members present or voting

### 52. Project Manager and Retrofit Lead begin procurement and retrofit of Phase 3 units (final 15 Mobile Ingest Units). Procurement and retrofit schedule targets completion of all Phase 3 units by Months 90–110 (2034-04-12 to 2035-08-12), allowing 6–10 months of residency at each site before programme close at Month 120 (2036-10-12). By Month 54 (2031-04-12), issue RFQs for Phase 3 containers, equipment and systems. By Month 60 (2031-10-12), begin retrofit of first Phase 3 units (target first Phase 3 unit deployed by Month 64–66 = 2032-02-12 to 2032-04-12).

**Responsible Body/Role:** Project Manager and Retrofit Lead

**Suggested Timeframe:** Month 48–60 (2030-10-12 to 2031-10-12)

**Key Outputs/Deliverables:**

- Phase 3 RFQs issued for 15 containers, equipment, robotics and systems
- Vendor contracts executed
- Long-lead procurement orders placed
- Retrofit schedule (Months 60–110 = 2031-10-12 to 2035-12-12)
- First Phase 3 units deployed to Phase 3 archives by Month 66 (2032-04-12)

**Dependencies:**

- Phase 3 funds authorized for drawdown (from Phase 3 Gate)
- Design freeze and change control working from Phase 2
- Vendor relationships and capacity available

### 53. Site Selection Committee continues Phase 3 site-readiness pre-work. Begin readiness audits for Phase 3 sites (15+ archives) starting at Month 54 (2031-04-12). For each site: (1) power-quality audit; (2) fire-authority and insurer pre-notification; (3) facility and security assessment; (4) staff-liaison identification. Target completion of first 5–7 Phase 3 site audits by Month 60 (2031-10-12), with fire-authority and insurer written approvals by Month 62 (2031-12-12). Sign Phase 3 residency agreements (multi-year, updated source-agreement template v2.0+). Remaining Phase 3 sites (8–10) begin readiness work on a rolling schedule, 6 months before their scheduled unit arrival.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager

**Suggested Timeframe:** Month 54–66 (2031-04-12 to 2032-04-12)

**Key Outputs/Deliverables:**

- Phase 3 site-readiness audits (first 5–7 sites)
- Written fire-authority and insurer approvals for Phase 3 sites
- Executed Phase 3 residency agreements (multi-year terms)
- Notification to remaining Phase 3 sites (residency windows and readiness schedule)
- Master Schedule finalized (all 30+ archives assigned and scheduled through Month 120 = 2036-10-12)

**Dependencies:**

- Phase 3 unit deployment timeline known from Retrofit Lead
- Phase 3 scope finalized (15 units or reduced count if scope reduction approved)
- Site Selection Committee active

### 54. Finance Committee and Programme Board finalize the Fleet Sunset and Equipment Afterlife Plan by Month 54 (2031-04-12). Plan to address: (1) unit disposition (which 30 units are retained, transferred to archives/universities, or decommissioned post-Month 120 = 2036-10-12); (2) parts-warehouse closure or transfer (parts inventory to successors or archives with maintenance capability); (3) knowledge-base handoff (digital knowledge commons, documentation repository, successor training of the preservation community); (4) post-programme funding or partnerships (is there a sustained endowment for retained units, or a successor organization?); (5) equipment depreciation and asset management through Month 120 (2036-10-12). Board approves final end-state plan and communicates strategy to all funders and archives.

**Responsible Body/Role:** Fleet Sunset and Equipment Afterlife Working Group and Programme Board

**Suggested Timeframe:** Month 54 (2031-04-12)

**Key Outputs/Deliverables:**

- Final Fleet Sunset and Equipment Afterlife Plan (approved by Board)
- Unit disposition decision (retained, transferred, decommissioned)
- Parts-warehouse and inventory transition plan
- Knowledge-base stewardship plan (digital commons platform, documentation, successor training)
- Post-programme sustainability plan (endowment, successor organization, funding commitments)
- Equipment-depreciation and asset-management schedule

**Dependencies:**

- Fleet Sunset Working Group active (formed Month 28 = 2029-02-12)
- End-state options paper and interim plan completed (Months 36–48 = 2029-10-12 to 2030-10-12)
- Programme Board authorization

### 55. Finance Committee and Programme Board establish a Post-Programme Continuation Committee by Month 60 (2031-10-12). Committee membership includes: representatives of retained-unit recipients (archives, universities, research centers), knowledge-base stewards, endowment or sustainability partner, Programme Director (outgoing), and 2–3 continuing Board members. Committee tasked with: (1) ensuring smooth transition of units and parts to successors; (2) maintaining knowledge-base and supporting the preservation community; (3) managing any post-Month 120 (2036-10-12) digitization of newly identified collections; (4) securing long-term funding for retained units. First meeting by Month 60 (2031-10-12); ongoing governance through Month 120 (2036-10-12) and beyond.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- Post-Programme Continuation Committee formed (members confirmed)
- Committee charter and responsibilities documented
- Transition-plan timeline (handoff schedule through Month 120 = 2036-10-12)
- Knowledge-base and sustainability-partner relationships formalized
- First continuation-committee meeting held (Month 60 = 2031-10-12)

**Dependencies:**

- Fleet Sunset and Equipment Afterlife Plan finalized
- Programme Board approval
- Identified unit recipients and sustainability partners (from end-state plan)

### 56. Technical Committee conducts final compliance and decommissioning planning by Month 100 (2035-02-12) (4 months before programme close at Month 120 = 2036-10-12). Plan addresses: (1) retirement and safe decommissioning of pilot units (1–3 units that have completed residencies or are due for unit replacement); (2) end-of-life disposal of non-operational equipment and parts (following environmental and e-waste regulations per jurisdiction); (3) final knowledge-base documentation (all 50+ competencies documented, digital commons finalized); (4) certification of all digitized data (verification of two copies per master, fixity checks, format-migration plans for long-term preservation). By Month 120 (2036-10-12), all units are either transferred to successors or safely decommissioned, and all digitized data is in final archive custody with preservation and migration plans.

**Responsible Body/Role:** Technical Committee and Post-Programme Continuation Committee

**Suggested Timeframe:** Month 100–120 (2035-04-12 to 2036-10-12)

**Key Outputs/Deliverables:**

- Decommissioning and retirement plan (unit-by-unit timeline through Month 120 = 2036-10-12)
- Environmental and e-waste disposal compliance plan (per jurisdiction)
- Final knowledge-base documentation (all competencies captured; digital commons published)
- Data-custody verification (two copies per master confirmed; fixity checks passed)
- Format-migration and long-term preservation plans (for 200+ PB archive)
- Final programme report and lessons-learned documentation
- Handoff to Post-Programme Continuation Committee (Month 120 = 2036-10-12)

**Dependencies:**

- All 30 units have completed their residencies (or are completing final residencies by Month 120 = 2036-10-12)
- All digitized data (3.6M+ items, 200+ PB) is in final archive custody
- Post-Programme Continuation Committee ready to assume stewardship (Month 120 = 2036-10-12)
- Legal and compliance sign-offs for final operations (Month 100–120 = 2035-02-12 to 2036-10-12)

### 57. Programme Director formally closes the CDDIN Programme and transitions stewardship to the Post-Programme Continuation Committee by Month 120 (2036-10-12). Deliverables include: (1) final programme close-out report (scope delivered, items digitized, data recovered, lessons learned); (2) certification of all governance transition items (Board dissolved, committees transferred to continuation committee, decision records archived); (3) institutional memory handoff (personnel, documentation, knowledge-base access); (4) celebration and recognition of team, partners and funders. Last Programme Board meeting held at Month 120 (2036-10-12); Post-Programme Continuation Committee assumes ongoing stewardship.

**Responsible Body/Role:** Programme Director and Programme Board

**Suggested Timeframe:** Month 120 (2036-10-12)

**Key Outputs/Deliverables:**

- Final Programme Close-Out Report (scope, items, data, lessons, outcomes)
- Governance transition documentation (Board dissolution, committee handoff, decision records)
- Knowledge-base and institutional memory handoff (files, access, contacts)
- Post-Programme Continuation Committee formally assumes stewardship
- Recognition and celebration event (team, partners, funders)
- Public archive and communication (final outcomes communicated to stakeholders)

**Dependencies:**

- All CDDIN operations completed (units deployed, residencies completed, data archived)
- Post-Programme Continuation Committee established and ready (Month 60 = 2031-10-12 onward)
- All governance and administrative closure tasks completed
- Final report and documentation compiled