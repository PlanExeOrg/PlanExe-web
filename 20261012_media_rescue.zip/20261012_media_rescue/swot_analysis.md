
## Strengths 👍💪🦾
- On-site processing removes shipping risk and fits insurer constraints; media never leaves archive premises (zero shipping damage target).
- Clear problem urgency: 1950-2000 media degrading within 10-30 years, with current methods at USD 500-2,000 per item versus plan USD 50-100 (estimate).
- Safeguard-first design: human-in-the-loop legal review, specialized line types, no assumed equipment availability.
- Phased structure (3 pilots, 15, then 30 MIUs) with explicit gates and stress-first pilot to expose failure modes early.
- Strong hub options: Northern Virginia, UK, Netherlands offer retired engineers, vintage equipment supply and archive partners.
- Analogues exist (Indiana MDPI, Packard Campus, British Library UOSH) for vintage-deck sustainment, QC and rights workflows.

## Weaknesses 👎😱🪫⚠️
- Recomputed unconstrained cost is about USD 530M against the USD 250M cap; cap supports about 47% of scope (~14 unit-equivalents, ~95 PB) (estimate). Phase 3 gap about USD 301M (estimate).
- Staffing of 50-60 per unit does not reconcile with USD 2-3M opex; budget-consistent crew is about 25 per unit (estimate).
- No parts-depletion or MTBF model; >90% uptime target is unsupported while 300-500 machines are consumed by the work.
- 80% AI review reduction and accuracy targets are untested on degraded, multilingual content.
- No committed funding source for the gap; governance structure and source-agreement terms not yet operating.
- Heavy dependence on a few retired engineers aged 70-80 with no secured mentoring contracts yet.
- Mitigation add-ons (about USD 16-28.5M) exceed Phase 1 headroom; inflation not built into the cap.

## Opportunities 🌈🌐
- Host and consortium cost-sharing per MIU (currently unquantified) could close part of the gap; in-kind power, space and liaison do not count against the cap.
- Government archives, cultural foundations and non-exclusive, rights-holder-approved technology-sector funding as additional routes.
- Vendor and conservation-lab partnerships (e.g. Memnon-style) could share equipment sustainment and cut capex.
- Published pilot evidence (recovery rates, cost per item) can build funder confidence and standardize source agreements.
- Knowledge base and open part designs create lasting regional capability and a post-Month 120 (2036-10-12) end-state.
- Triage toward fastest-decaying collections maximizes items rescued per unit-month within a reduced scope.

## Threats ☠️🛑🚨☢︎💩☣︎
- Insurer or fire-authority refusal over ovens, humidity chambers and generators; one handling incident could end partnerships network-wide.
- Privacy or data-residency breach (GDPR, UK DPA) from false negatives in AI pre-screening.
- Finite vintage spares and mentor attrition could push uptime below 90% by Months 36-48 (2029-10-12 to 2030-10-12) (estimate); emergency stockpile refresh USD 15-25M (estimate).
- Funder annual cycles slip gates by 3-6 months (estimate) while media keeps degrading.
- Customs, e-waste and hazmat rules delay container and equipment moves.
- Inflation of about 22% by Month 120 (2036-10-12) at 2% baseline (proposed threshold) erodes Phase 3 purchasing power.
- Technology-sector funding terms on training-data access could breach source agreements and erode archive trust.

## Recommendations 💡✅
- Month 1 (2026-11-12): Programme Board (8-10 members) and independent cost audit reconciling staffing, opex and the USD 250M cap; lock budget and staffing by Month 4 (2027-02-12). Owner: Programme Director and Finance lead.
- Month 1-3 (2026-11-12 to 2027-01-12): Funding Commitment Registry; at least USD 30M of Phase 1 committed (not pledged) by Month 3 (2027-01-12); quantify host cost-share per MIU and open talks with new funders for the gap. Owner: Board and fundraising lead.
- Month 2 (2026-12-12): Parts-depletion and MTBF model, 50% re-manufacture trigger; secure 6-8 mentors by Month 1 (2026-11-12) with retention to Month 48 (2030-10-12). Owner: Chief Engineer.
- Months 2-8 (2026-12-12 to 2027-06-12): Test AI pre-screening on 100-200 real samples (by Month 4 = 2027-02-12), run pilot review pod by Month 8 (2027-06-12); retrain if precision or recall below 75% or flagging above 25%. Owner: AI and Review lead.
- Months 2-6 (2026-12-12 to 2027-04-12): Hazard-control standard and written insurer and fire-authority approval at one pilot site by Month 6 (2027-04-12); tiered indemnity and pooled loss reserve. Owner: Risk and Legal lead.
- Month 3 (2027-01-12): Source-agreement template, privacy panel with decision log and jurisdiction mapping; consider federated custody. Owner: Legal counsel.
- By Month 12 (2027-10-12): Start end-state working group; define reduced-scope scenario (fewer than 24 units triggers re-assessment). Owner: Board.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 4 (2027-02-12), publish a reconciled cost and staffing model and lock the Phase 1 budget, with the funding gap and a funded scope option quantified.
- By Month 3 (2027-01-12), hold at least USD 30M of Phase 1 funds as binding commitments, and by Month 24 (2028-10-12) hold at least 70% (USD 84M) of Phase 2 committed (proposed threshold).
- By Month 6 (2027-04-12), obtain written insurer and fire-authority approval at one pilot site and sign 3 host agreements with zero legal or privacy incidents.
- By Month 24 (2028-10-12), demonstrate on at least 2 host sites for 3 consecutive months: digitization success above 95%, uptime above 90%, flagging below 20%, pre-screen precision and recall at least 75%.
- By Month 60 (2031-10-12), reach 500,000+ items and 25+ PB at 15 units (or the reduced scope agreed) with cost per item reported against the USD 50-100 plan.

## Assumptions 🤔🧠🔍
- The USD 250M cap (constant 2026 dollars) and phase budgets are fixed; the gap must be closed by cost-sharing, new funders or reduced scope.
- Canonical recomputed figures (about USD 530M uncapped, about 25 budget-consistent staff per unit) supersede earlier assumption documents.
- Pilot results will be treated as evidence, replacing assumed 80% review reduction and >90% uptime.
- Host in-kind contributions (power, space, liaison) are available and not charged to the cap.
- Retired engineers can be retained through Month 48 (2030-10-12) with incentives.
- No operating revenue or per-item tariff exists unless decided.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Committed funders, amounts and conditions; host cost-share willingness per MIU.
- Parts inventory condition, depletion curve and MTBF per deck type.
- Real AI pre-screening precision, recall and reviewer hours per content hour on degraded multilingual media.
- Insurer and fire-authority requirements and premium quotes for pre-treatment hazards.
- Jurisdiction-specific data-residency and temporary-import rules for target countries.
- Loaded labor cost by region and verified throughput per unit-year (required about 15,600 items; about 24,000 in Phase 3) (estimate).
- Perpetual storage cost and owner for 200+ PB beyond Month 120 (2036-10-12).
- Which archives hold the most endangered collections and will sign multi-year agreements.

## Questions 🙋❓💬📌
- Which scope reduction, cost-sharing or new funding combination will you accept to close the roughly USD 280M gap, and what would trigger a go/no-go re-assessment?
- What evidence from the pilots would convince archives, insurers and funders that the plan's accuracy, uptime and review figures hold?
- If the review reduction proves 35-40% flagging, would you change the crew model, the gate design or the unit count?
- How will under-resourced but most-endangered archives be reached if host readiness and cost-sharing favour better-resourced ones?
- Who will own, fund and migrate 200+ PB of masters and the remaining equipment after Month 120 (2036-10-12)?