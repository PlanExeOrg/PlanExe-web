# Purpose
` and `

# Domain
# Primary domain: Media Preservation

Secondary domains: Audiovisual Digitization Engineering, Legacy Equipment Maintenance, Archival Science

## Rationale

Media Preservation is the outcome-role candidate and owns the main success criterion of recovering degrading 1950-2000 media. Audiovisual Digitization Engineering, Mobile Container Engineering and remaining candidates are methods, constraints or stakeholders serving that goal.

# Disciplines this project involves

- Media Preservation (importance: 5, specificity: 5, role: outcome). Core goal is digitizing degrading magnetic tape, film and card media for heritage preservation.
- Audiovisual Digitization Engineering (importance: 5, specificity: 5, role: method). Containerized tape, film and card digitization lines with robotic loading and pre-treatment.
- Mobile Container Engineering (importance: 4, specificity: 5, role: method). Retrofitting climate-controlled 40-foot containers with power, connectivity, and processing lines is the core deployment mechanism.
- Digital Signal Restoration (importance: 4, specificity: 5, role: method). AI-driven cleaning, error correction and reconstruction of degraded audio, video and data signals.
- Legacy Equipment Maintenance (importance: 4, specificity: 4, role: constraint). Obsolete decks and scanners require parts inventory, cannibalization and retired-engineer knowledge transfer.
- Archival Science (importance: 4, specificity: 4, role: stakeholder). Partner archives define appraisal, metadata, custody, and access-control requirements for the recovered collections.
- Copyright And Privacy Law (importance: 4, specificity: 4, role: constraint). Source agreements, copyright status, PII, and classified-content review gates govern all uploads.
- Industrial Robotics (importance: 4, specificity: 4, role: method). Robotic arms automate media loading into vintage playback equipment inside each container.
- Digital Preservation Infrastructure (importance: 4, specificity: 4, role: method). Petabyte-scale storage, transmission, and distributed archive formats for long-term data access.


# Plan Type
# Physical Location Requirement

## Explanation

The plan is classified as physical and cannot be executed digitally. It centers on building and deploying 30 mobile digitization units housed in 40-foot shipping containers that are trucked to archives, universities, and storage facilities worldwide.

- Construction and setup: retrofitting containers with tape decks, film scanners, card readers, robotic loading arms, baking ovens, humidity and climate control, power systems, and on-board storage
- Hardware acquisition: purchasing 300-500 vintage machines from decommissioned TV and radio stations, auctions, and closed facilities, and maintaining a physical parts warehouse
- Maintenance and repair: azimuth alignment, head calibration, belt replacement, 3D printing and CNC machining of replacement parts, and training of younger engineers by retired engineers
- Transportation and site operations: trucking containers to archive parking lots and loading docks, connecting to facility power or generators, and relocating units every 6-12 months
- Handling physical media: sorting, pre-treatment (baking sticky tapes, humidifying brittle film), robotic loading, and returning original media to archive storage
- Staffing: engineers and reviewers working on-site, with a large workforce per active unit

AI signal processing, metadata extraction, and cloud archival upload are digital components downstream of physical digitization of analog media, which cannot happen without physical presence, equipment, and handling.

# Physical Locations
# Physical Location Requirements

- Central hub for container retrofit and integration: industrial floor space, heavy crane access, 40-foot container handling, near port or major highway/rail
- Climate-controlled warehouse for vintage equipment parts inventory (300-500 units) with secure storage
- Access to retired broadcast and film engineers and technical universities for training pipeline
- Pilot host archives holding degraded tape, film and card collections, with hardstand, stable power, security and fire-authority approval
- Customs-friendly corridors and mutual recognition blocs for temporary import of containers and vintage equipment
- Reliable fiber or satellite connectivity for uploads and remote diagnostics
- Legal clarity on data residency, privacy and copyright for recovered data
- Proximity to vintage equipment sources (decommissioned broadcasters, auctions, closed facilities)
- Moderate labor and facility costs to fit the $250M (user constraint) budget

## Location 1: United States — Culpeper / Northern Virginia and Washington DC

Industrial or logistics site near the Library of Congress Packard Campus, Culpeper, VA. Major audiovisual preservation campus and talent pool of broadcast and archival engineers. Close to National Archives, Smithsonian and university collections for pilot sites, with highway access for container trucking and nearby East Coast ports.

## Location 2: United Kingdom — Greater London and South East England

Industrial estate near Thamesport or Tilbury port, with pilot sites at archives such as the British Library and BFI National Archive. Strong archival and broadcast heritage (BBC, BFI, British Library) and retired engineers. Port access supports container logistics and onward routes into Europe. Deep conservation expertise suits film and tape lines.

## Location 3: Netherlands / European Union — Hilversum and Rotterdam

Warehouse or industrial unit near Hilversum (Netherlands Institute for Sound and Vision) with Port of Rotterdam access. Leading audiovisual archive and broadcast industry with many decommissioned decks. EU single customs area and data rules ease intra-bloc moves, and Rotterdam provides a global shipping gateway.

## Location 4: United States — Los Angeles / Southern California

Industrial district near Burbank or Port of Long Beach. Dense concentration of studios, film archives and former broadcast facilities supplies vintage equipment and engineers. Port access supports Pacific routes. Film Line pilot can use studio and university film collections.

## Location Summary

Global and mobile operation with physical bases: a container retrofit and parts hub, a training centre, and pilot host archives. Four suggested regions (Northern Virginia, South East England, Hilversum/Rotterdam, Los Angeles) combine archival density, retired-engineer talent, vintage equipment supply, port or highway access and workable customs corridors. Pilot residencies would be sited at partner archives in or near these hubs, then expanded worldwide.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Technical – Hardware Availability and Sustainability

The plan depends on a finite stockpile of 300–500 vintage tape decks, film scanners and card readers. These machines are no longer manufactured and are consumed by continuous operation across 30 units over 10 years. No model of parts-depletion rate, mean time between failures per line type, or refresh capacity exists. Retired engineers (aged 70–80 at start) are the only source of expertise in head alignment, belt replacement and mechanical repair; their availability and lifespan are unpredictable. 3D printing of replacement parts is proposed but unproven for precision tolerances required by tape azimuth or film registration. Cannibalization of non-operational units yields fewer parts as the programme ages. The >90% uptime target is stated but not backed by a reliability model.

Impact: Fleet uptime could drop below 90% by Month 36–48 (2029-10-12 to 2030-10-12) as parts depletion accelerates and retired engineers become unavailable. Units would go offline for weeks or months awaiting parts or expert repair. At 30 units, even 10% unplanned downtime represents 3 units continuously offline, losing 300TB–500TB per month of planned capture. A cascading failure (e.g., all tape decks in a line type develop azimuth drift simultaneously) could force deferral of entire format categories. Replacement cost: acquiring new vintage stockpile mid-programme could cost $15M–$25M unbudgeted. Recovery delay: 6–12 months of lost throughput represents 50,000–100,000 items not rescued from active degradation. At worst, capability collapse by Month 60–72 (2031-10-12 to 2032-10-12) if the machine and expertise base is exhausted.

Likelihood: High

Severity: High

Action: By Month 2 (2026-12-12), commission a detailed parts-depletion curve modelling mean time between failures per deck type, cannibalization yield, 3D-printing capability for precision parts and vendor pricing. Establish a dedicated parts-engineering team to test 3D printing and CNC machining of 20+ critical part categories. Baseline all 300–500 acquired units with comprehensive inspection, parts tagging and documentation. Initiate partnerships with broadcast-equipment restoration specialists and maker-space networks. By Month 6 (2027-04-12), secure written commitments from retired engineers and identify 2–3 younger successor engineers per line type for intensive mentoring. Build a living-inventory system that tracks parts consumption and triggers automatic re-manufacture when thresholds approach 50% depletion. Budget an additional $10M–$15M for parts-engineering capability and contingency stockpile refresh.

# Risk 2 - Technical – AI-Powered Review and Signal Processing Accuracy

The plan assumes AI pre-screening flags 80% of content requiring human review, reducing review load from 1,000 hours to 200 hours per collection. It also assumes >80% signal-reconstruction accuracy and >70% automated metadata accuracy. These targets are stated as success metrics but have not been demonstrated on real degraded, multilingual pre-digital content from the 1950–2000 era. Tape recordings have dropouts, speed variations and layer adhesion issues; film has shrinkage, color fade and optical distortion; card media have wear and fading. AI trained on modern, high-fidelity content may perform poorly on extreme degradation. Copyright, privacy and classification markers are inconsistent across formats and decades; multilingual content, non-English speech and handwritten metadata increase false negatives.

Impact: If the 80% pre-screening accuracy is overstated, reviewers could face 600–800 hours instead of 200, requiring 40–50 per unit instead of 12–15, multiplying payroll by 3–4x. At $50K–$70K per reviewer per year, that is an additional $15M–$25M annually at full scale. False negatives could leak private medical records, personal correspondence or classified government data to the archive, creating regulatory incidents and breach-notification costs. Reconstruction accuracy below 70% leaves artifacts and noise visible to users, undermining digitization value. Delayed detection of accuracy failure (apparent after Month 12–18 = 2027-10-12 to 2028-04-12 of pilot operations) would consume Phase 1 budget before remediation.

Likelihood: High

Severity: High

Action: Before Month 2 (2026-12-12), procure 100–200 representative samples from proposed pilot archives spanning tape, film and card formats, emphasizing degraded items. Build a gold-standard labelled dataset with human-expert review of copyright, privacy and classification markers and reconstruction quality. Test the AI pre-screening pipeline on this dataset and publish precision, recall and false-positive rate separately by format and degradation level. If pre-screening accuracy is below 75% on real content, commission iterative retraining. Reserve 30% of Phase 1 timeline as contingency for AI model revision. By Month 8 (2027-06-12), run a pilot review pod with 5–10 reviewers on flagged and non-flagged content to measure actual review hours per content hour. If the ratio exceeds 1:2, recalibrate crew composition and Phase 2 staffing assumptions. Establish a living benchmark: route 5% of all reviewed content through a secondary expert reviewer to catch systematic drift.

# Risk 3 - Operational – Staffing and Knowledge Transfer

The plan allocates 50–60 staff per active unit (engineers, operators, reviewers, maintenance), scaling to 1,500–1,800 at full scale (30 units). At stated operating costs of $2–3M per unit per year, this implies a payroll of $1.2M–$1.8M per unit per year, or $36M–$54M for 30 units. The $250M ten-year budget totals $25M per year on average; payroll alone at full scale consumes 36–54% of annual spend, leaving $11.5M–$16.5M for equipment, parts, logistics, satellite/fiber connectivity, containerized facilities and consumables across 30 units worldwide. The cost basis does not reconcile visibly. Staffing also depends on knowledge transfer: retired engineers must mentor 2–3 younger engineers per line type before they exit, but no timeline, curriculum or retention guarantee is stated. Reviewer staffing assumes availability of 12–15 fluent multilingual experts per unit willing to relocate; sourcing and retaining this talent across 30 sites globally is uncosted.

Impact: If full-scale payroll is $36M–$54M per year and the budget is $25M per year on average, the plan will either run at reduced staffing (degrading crew consistency and review quality), exceed budget by $11M–$29M annually at scale, or operate at reduced unit deployment (fewer than 30 units). Each choice reduces capacity against the 3.6M-item, 200PB target. Knowledge-transfer failure (retired engineers exit before training is complete, or mentees do not retain expertise) leaves maintenance without expert guidance. Reviewer turnover (high burnout in multilingual review work) forces continuous recruitment and on-boarding, slowing ramp-up at each new site. Estimated impact: 10–20% of staff positions remain unfilled or churned at any given time, reducing effective unit utilization by 5–15%.

Likelihood: High

Severity: High

Action: By Month 1 (2026-11-12), commission an independent cost audit reconciling stated unit staffing (50–60), payroll, and the $250M ten-year budget, accounting for salaries, benefits, travel, visa, relocations and training across three geographic hubs and 30 sites. Publish a credible staffing and payroll model or revise Phase 2 and Phase 3 unit counts to match the budget envelope. Establish a pilot staffing pod at the first hub site with representative crew sizes and roles; measure actual loaded costs and time-to-productivity per position and extrapolate to full scale. For knowledge transfer, by Month 3 (2027-01-12) develop a detailed mentoring curriculum for three line types, identifying the 6–12 most critical repair competencies, and secure written commitments from 4–6 retired engineers to mentor full-time for 24 months. Offer retention bonuses or consulting roles for mentors who stay through Month 36 (2029-10-12). For reviewers, map fluent-speaker availability per language and region by Month 2 (2026-12-12); prioritize sourcing and hire reviewer leads by Month 4 (2027-02-12) who can train and quality-assure secondary reviewers. Budget 20% headcount premium for turnover and training overhead.

# Risk 4 - Regulatory and Legal – Archive Insurer and Fire-Authority Approval

The plan depends on parking containerized units with baking ovens, humidity chambers and climate control on the grounds of partner archives. Archive insurance policies and host fire authorities must approve each site. Baking ovens bring thermal risk; humidity chambers and film stabilization introduce chemical vapors; on-board storage of original media creates fire load; diesel or natural-gas generators introduce fuel and combustion risk. Host facilities may lack sufficient hardstand, electrical capacity, or security infrastructure. Insurance companies may refuse coverage for equipment brought onto premises, or demand hazard-control measures that multiply cost and footprint. Fire authorities may prohibit close proximity to main buildings or demand emergency-response protocols exceeding host capability. The plan assumes 'media never leaves the premises, satisfying insurance requirements,' but does not verify that on-site processing itself is insurable or fire-safe.

Impact: A site rejection or conditional approval delaying deployment by 4–8 weeks per archive multiplies across 30+ planned residencies, consuming 2–4 months of calendar time each year. Cumulative delay: 6–12 months lost throughput over the programme, deferring 50,000–200,000 items. A handling incident destroying a high-value, unique collection triggers liability exposure of $500K–$2M+ per item and reputational damage. Insurance premium increases or policy cancellations could add $1M–$3M annually or force uninsured operation. Worst case: after an incident, multiple archives terminate agreements, the network drops from 30 units to 5–10.

Likelihood: Medium

Severity: High

Action: By Month 2 (2026-12-12), engage a specialized insurance broker and fire-safety consultant to model containerized pre-treatment and digitization hazards, quantify premium costs and exclusions, and develop a host-site hazard-control standard that separates baking/humidity from the main digitization line. Test this standard at one pilot site and obtain written insurer and fire-authority approval by Month 6 (2027-04-12) before scaling. Develop a standardized source agreement and indemnity structure that clearly delineates handling risk, shipping risk and environment-caused loss. Offer tiered indemnity: full coverage for items in stable condition, documented 'attempt at own risk' waiver for fragile items. Create a pooled loss reserve ($2M–$5M) from project funding to cover unique-item losses insurers decline. Establish a mandatory incident-response protocol: notify insurers within 24 hours, freeze the unit for forensic investigation, and use incident data to refine hazard controls before redeployment.

# Risk 5 - Legal and Compliance – Rights, Privacy and Data Sovereignty

The plan gates items behind AI pre-screening and human review before archival upload, but source agreements are described only at a high level. The plan does not detail how privacy breaches are managed, who bears liability, or what happens if a host jurisdiction's privacy or data-protection rules prohibit uploading recovered data outside the country. The EU GDPR, UK Data Protection Act, and other jurisdictions impose transfer restrictions on personal data; transferring a recovered dataset containing PII to a central archive could violate law even with archive permission. Conversely, holding data in-country indefinitely without central backup creates preservation risk. The assumption that 'archive staff or MIU crew review flagged items before archival upload' is not specific about who decides privacy and classification disputes, who holds the decision record, or what appeal process exists.

Impact: A privacy breach triggers GDPR fines of up to 4% of global revenue for organisations, notification obligations to affected individuals, reputational harm and potential criminal liability. Estimated fines: $5M–$20M+ for a technology funder. A data-residency violation could block data transmission and force in-country holding, requiring separate storage and preservation infrastructure per jurisdiction (estimated additional $5M–$10M cost). Regulatory investigation could freeze operations for 2–4 months. An incident that damages archive trust could terminate agreements and prevent scaling.

Likelihood: Medium

Severity: High

Action: By Month 1 (2026-11-12), engage a data-protection and cultural-heritage legal team to map GDPR, UK DPA, and applicable laws in each planned jurisdiction. By Month 2 (2026-12-12), develop a privacy-impact assessment (PIA) template for each source agreement, identifying what personal data is present, what transfer restrictions apply, and what consent or legal basis is needed. Publish a standardised source-agreement template that clearly delineates scope, privacy commitment, storage location and access tier, legal basis for transfer, and indemnity for privacy breach. By Month 3 (2027-01-12), establish a privacy-review panel (2–3 data-protection experts rotating across sites) that oversees flagged privacy decisions and maintains a decision log with rationale. For each jurisdiction, determine whether a federated data model (archives hold masters, central archive receives non-sensitive derivatives or metadata only) meets preservation goals while respecting data residency. Budget an additional $1M–$2M for jurisdiction-specific legal review and compliance infrastructure.

# Risk 6 - Operational – Phased Funding and Gate-Based Release Timing

The plan is divided into three phases: Phase 1 ($60M, Months 0–24 = 2026-10-12 to 2028-10-12, 3 units); Phase 2 ($120M, Months 24–60 = 2028-10-12 to 2031-10-12, 12 additional units); Phase 3 ($70M, Months 60–120 = 2031-10-12 to 2036-10-12, 15 final units). Funding is released in tranches tied to proof-of-concept gates. Most of the 15+ funder organisations operate on annual budget cycles with parliamentary or board approval. A pilot failure or discovery of unmet assumptions at Month 18 (2028-04-12) would occur midway through Phase 1 budget spend but before Phase 2 money is released. Reworking the design or seeking additional Phase 1 funding consumes 4–8 weeks of committee-approval cycles per organisation, slipping the Phase 2 gate by 3–6 months. Media degradation clocks (10–30 year lifespan) mean that each month of calendar delay represents 3–10% of remaining useful lifetime for at-risk collections.

Impact: A Phase 2 gate delay of 6 months reduces the calendar available for Phase 2 operations by 5%, shrinking the Phase 2 30-archive residency target from 30 sites to 28–29. Accumulated delay across three phases reduces total residencies from 30+ to 25–27, shrinking digitized items from 3.6M to 3.0M–3.2M. At the worst case, a critical pilot failure could defer Phase 2 gate by 12 months, reducing capacity by 10–15% and leaving an additional 300,000–500,000 items unrecovered. A single funder withdrawal of $30M–$40M would compress Phase 2 or Phase 3.

Likelihood: Medium

Severity: Medium

Action: By Month 1 (2026-11-12), establish a Funding Commitment Registry that translates all pledges into binding multi-year contracts with milestone-release conditions. Target 50%+ committed (not pledged) by Month 3 (2027-01-12). For committed funds, negotiate a 'best-efforts gate override' clause allowing Phase 2 release to proceed on schedule if pilot metrics meet >80% of targets, with a rework budget of up to $5M deferred from Phase 3. By Month 2 (2026-12-12), establish a Contingency Funding Panel to identify backup sources that can fill a $10M–$20M mid-programme gap without waiting for annual cycles. Structure Phase 1 to achieve observable milestones every 3 months so that gate evidence accumulates gradually. Build a 2–3 month scheduling buffer into each phase transition. Establish a Media Degradation Offset Fund: if calendar delays accumulate, prioritize residencies at collections with the steepest degradation curves.

# Risk 7 - Operational – Border Crossing, Container Logistics and Customs Clearance

The plan assumes containers can be trucked or shipped between archive locations worldwide, with vintage equipment and consumables crossing borders smoothly. Temporary-import regimes (carnets, ATA agreements) require advance paperwork (2–4 weeks per border) and depend on mutual recognition between countries. Vintage equipment may be subject to electronic-waste restrictions or export controls. Consumables face hazmat classification and require special transport documentation. Border delays of 1–2 weeks per crossing are routine for containerized cargo; a stuck container represents a $5K–$10K loss per day in foregone throughput. No jurisdiction-specific temporary-import pathway or dual-documentation system is mentioned.

Impact: Average border delay of 1 week per crossing × 90 moves over 10 years = 90 weeks lost across the fleet, or roughly 2 weeks per unit per year of idle time. At $5K–$10K per day, the cost is $35K–$70K per border crossing, or $3.15M–$6.3M total programme cost. Worst-case customs hold could strand a unit for 2–4 weeks, representing 40TB–70TB of unprocessed content or 500–1,000 items lost to the schedule. By Phase 3 with 30 units, a systematic border-delay problem multiplies across the fleet. Additionally, data sovereignty rules differ by jurisdiction; the plan may discover by Month 12 (2027-10-12) that a key host country prohibits data transfer outside its borders, requiring a redesign of the storage and upload architecture.

Likelihood: Medium

Severity: Medium

Action: By Month 2 (2026-12-12), engage a customs and trade-compliance specialist to document the temporary-import pathway in each planned region. By Month 4 (2027-02-12), pre-negotiate temporary-import agreements with 3–5 key border authorities covering containerized digitization units and vintage equipment. By Month 6 (2027-04-12), establish a Containerized Logistics Coordinator role that tracks all container moves, submits documentation 6 weeks in advance, and monitors clearance status. For data sovereignty, by Month 3 (2027-01-12) map the legal residency rules per planned jurisdiction and design a federated storage model in which masters stay with archives and only anonymized or restricted derivatives transfer centrally. Budget $1M–$2M for legal and customs-compliance resources and $500K–$1M annually for border-clearance contingencies.

# Risk 8 - Technical – Pilot Unit Design and Replication Risk

The plan builds 3 pilot units (one Tape Line, one Film Line, one Card/Disk Line) in Months 0–24 (2026-10-12 to 2028-10-12), then orders 12 additional units for Phase 2 (Months 24–60 = 2028-10-12 to 2031-10-12). A strict gate requires all three pilot lines to meet >95% digitization success, >80% reconstruction accuracy, >70% metadata accuracy and <20% review flagging before Phase 2 funding is released. However, designs are replicated into subsequent units before failure modes are fully discovered. If a critical design flaw is found at Month 18 (2028-04-12) (e.g., humidity control inadequate for film stability, robotic arm repeatability below specification, thermal management failing in hot climates), retrofitting all 12 Phase 2 units incurs rework cost of $2M–$5M and delays Phase 2 deployment by 6–9 months.

Impact: Design rework on Phase 2 units costs $2M–$5M and delays deployment by 6–9 months (Month 30–33 = 2029-04-12 to 2029-07-12 instead of Month 27 = 2029-01-12). This reduces Phase 2 residency capacity by 15–20%, shrinking from 12 units to 10–11 effective units in operation. Rework also reduces funder confidence in the design, making Phase 3 funding contingent on additional gates, potentially deferring Phase 3 start from Month 60 (2031-10-12) to Month 66–72 (2032-04-12 to 2032-10-12). A critical failure on one pilot unit could force redesign of the entire line, scrapping the unit's output and delaying other tape operations.

Likelihood: Medium

Severity: High

Action: By Month 6 (2027-04-12), establish a rigid Design Review Gate (DRG) process: every major design element undergoes independent technical review by a panel of experts who must sign off before design is 'frozen' for Phase 2 procurement. Freeze designs by Month 20 (2028-06-12) at the latest, allowing 4 months for long-lead equipment procurement. Introduce a 'Stress-First Pilot' approach: send the first unit to the worst-condition collection available. Run extended pilot periods (Months 6–20 = 2027-04-12 to 2028-06-12 at minimum) before declaring success metrics. Establish a parallel Design B team tasked with developing alternative approaches to any critical subsystem. Reserve $5M from Phase 1 budget as a Design Contingency Pool. Implement rigorous telemetry and failure logging so root causes are identified early.

# Risk 9 - Operational – Maintenance Skill Availability and Vintage-Equipment Expertise

The plan depends on 4–6 retired broadcast and film engineers (aged 70–80 at start) to mentor younger engineers in techniques that are no longer taught anywhere: tape azimuth alignment, film registration and head calibration on 1970s–1990s equipment. These engineers are a perishable resource: if key mentors become unavailable, the knowledge transfer pipeline breaks. The mentoring must happen over 18–24 months per successor; if mentoring is deferred or incomplete, the programme loses the ability to diagnose and repair failures after Month 30–36 (2029-04-12 to 2029-10-12). The plan also assumes that 3D printing and CNC machining can fabricate precision parts, but tolerance requirements for tape transport (±0.05mm azimuth, ±0.1% speed regulation) are exacting.

Impact: Loss of a key mentor before Month 18 (2028-04-12) delays transfer of critical competencies by 6–12 months, leaving younger engineers under-trained when the mentor would have exited. By Month 36 (2029-10-12), if 2–3 retired engineers have exited and mentoring is incomplete, the programme faces a diagnostic gap. Field failures cannot be reliably diagnosed or repaired, forcing reliance on external consultants (cost: $5K–$10K per incident, vs. $500–$1K if in-house expertise exists). A misfabricated part that damages tapes triggers loss of a unique recording and liability exposure. Fabrication delays (8 weeks per part) mean that a unit waiting for a replacement part sits idle for 2 months, losing 20TB–40TB of throughput.

Likelihood: High

Severity: Medium

Action: By Month 1 (2026-11-12), identify and secure written commitments from 6–8 retired engineers to ensure redundancy and coverage for illness or unavailability. Offer mentoring contracts with retention bonuses extending to at least Month 48 (2030-10-12), ensuring mentors stay active through the critical period. By Month 2 (2026-12-12), develop a detailed competency curriculum for three line types, breaking down 50+ competencies into modules with measurable learning objectives. Document all mentoring in a digital knowledge base accessible to all engineers. By Month 4 (2027-02-12), establish a 3D-Printing and CNC Precision Engineering team (3–5 engineers) dedicated to fabricating replacement parts. Test all designs on reference equipment and measure playback performance before deployment. Develop a library of 30–50 high-priority, pre-engineered part designs with validated fabrication specs and supplier pipelines. Stock 2–3 sets of each critical part ahead of demand. By Month 6 (2027-04-12), establish a parts-ordering dashboard that predicts parts consumption and automatically triggers re-manufacture when stock approaches 50% depletion.

# Risk 10 - Financial – Budget Reconciliation and Phased Cost Control

The plan allocates $250M over 10 years ($25M per year on average): Phase 1 ($60M, Months 0–24 = 2026-10-12 to 2028-10-12), Phase 2 ($120M, Months 24–60 = 2028-10-12 to 2031-10-12), Phase 3 ($70M, Months 60–120 = 2031-10-12 to 2036-10-12). Detailed cost breakdowns are provided, but the full-scale operating model (50–60 staff per unit × 30 units = 1,500–1,800 people at $2–3M opex per unit) implies payroll of $36M–$54M per year at full scale. The $25M annual average leaves $11.5M–$16.5M annually for equipment acquisition, parts, utilities, logistics, satellite/fiber and consumables. No explicit line-item budget reconciling these figures appears in the plan.

Impact: If staffing at full scale exceeds the budget envelope, the programme must choose: reduce unit count from 30 to 20–22, reduce crew sizes below the stated 50–60 per unit, or exceed budget by $11M–$29M annually at scale. A funding shortfall of $50M–$100M over the full 10 years would force the programme to stop at 20 units instead of 30. Working-capital shortfalls (delays in Phase 2 release) force bridging loans or temporary shutdown, costing $100K–$500K per week in lost throughput.

Likelihood: High

Severity: Medium

Action: By Month 1 (2026-11-12), commission a comprehensive budget reconciliation audit that itemizes all costs per unit per year and projects total cost for 3, 15 and 30 units at each phase. Publish the reconciliation openly; if full-scale costs exceed $250M, either reduce unit targets or request budget increase. Build a 10% contingency per phase explicitly identified. By Month 2 (2026-12-12), establish a Finance Workstream reporting monthly to funders and governance with variance analysis. Implement a stop-loss rule: if cumulative variance at any point exceeds 10% overspend, pause Phase 2 or Phase 3 progression and replan. For working-capital, by Month 3 (2027-01-12) secure a $15M–$20M revolving-credit line or bridge-funding commitment that can cover 2–3 months of operating expenses if phase-release tranches slip. Structure funder commitments so that 70%+ of each phase budget is committed (not pledged) before that phase begins.

# Risk 11 - Operational – Multi-Site Deployment Logistics and Scheduling

The plan schedules unit residencies at 30+ partner archives over 10 years, with each unit spending 6–12 months at a site before relocating. No explicit scheduling algorithm or queue-management tool is mentioned. Site selection depends on the Triage Doctrine decision, which determines whether high-risk degrading collections are prioritized or high-value/well-resourced archives receive earlier access. Sites vary in power availability, space, security and staff, requiring different pre-positioning efforts. Unit relocation logistics (trucking, customs, setup) take 2–4 weeks per move; if multiple units are relocating simultaneously and logistics capacity is limited, delays cascade.

Impact: Poor scheduling results in either units idled at sites past their productive lifespan, units relocating before a site is ready, or under-resourced archives deprioritized. Site-readiness delays (e.g., a host archive unable to secure fire-authority approval until Month 6 = 2027-04-12 instead of Month 3 = 2027-01-12) cumulate across 30 sites; if each site is delayed by 2 weeks on average, the aggregate delay across 30 residencies is 60 weeks (14 months), shrinking the programme's effective operating window by 10–15%. A site withdrawal mid-residency forces immediate relocation and orphans partial collections. If 2–3 sites withdraw during Phase 2 or Phase 3, the schedule unravels.

Likelihood: Medium

Severity: Medium

Action: By Month 3 (2027-01-12), develop a Master Schedule and Queue Management System that maps all 30+ partner sites with key attributes. Use an optimization algorithm or decision-support tool to rank sites by media-degradation urgency. Publish a 5-year rolling schedule with site assignments and residency windows; update quarterly. Establish a Site-Readiness Workstream (2–3 logistics specialists) that owns pre-positioning at each archive. Begin readiness work 6 months before unit arrival; establish a Site Readiness Scorecard tracking progress. Introduce a Readiness Gate: a site must be 90% ready before a unit is dispatched. For units in transit, maintain a Surge Buffer Pool of 1–2 units and temporary parking locations to absorb schedule slips. For site withdrawal risk, require multi-year (2–3 year) commitments and maintain a Priority Waitlist of backup sites ready to receive a unit on short notice (4–6 weeks). Budget $500K–$1M annually for logistics-coordination and contingency-relocation costs.

# Risk 12 - Technical – AI Model Validation and Content-Dependent Accuracy Drift

The plan assumes AI pre-screening and signal reconstruction perform consistently across formats, languages, degradation levels and content types. However, AI models trained on one corpus (e.g., English-language broadcast news) may perform poorly on another (e.g., multilingual municipal records, laboratory audio, music). Degradation is also format-dependent. The plan does not specify a model-validation regime that tests accuracy on representative samples from each planned archive before committing to that site's digitization.

Impact: Accuracy drift below 75% on a subset of content (e.g., non-English speech, handwritten annotations) requires retraining, consuming 2–4 weeks of engineering effort and 1–2 weeks of compute time per retraining cycle. A broader accuracy failure discovered at Month 36 (2029-10-12) requires a fundamental redesign of the AI pipeline, consuming $1M–$3M of engineering and compute resources. Reprocessing 10–30 sites' worth of content (500TB–1.5PB) requires 2–4 months of compute time, during which new content is not being processed, delaying downstream archive uploads.

Likelihood: Medium

Severity: Medium

Action: By Month 4 (2027-02-12), establish a Model Validation and Monitoring Pipeline that tests the AI pre-screening and reconstruction models on a curated test set (100–200 items) from each planned archive before that site's unit arrives. Measure precision, recall and false-positive rate per format, language and degradation level. If performance is below 75%, defer that category from processing until model is retrained. Implement a Living Leaderboard: publish model performance metrics monthly; if a site shows 5–10% accuracy drop vs. previous sites, investigate root cause and trigger retraining. Run a Canary Deployment: send an initial batch (10–20 items) from each new site through the full AI and review pipeline. Establish a Model Drift Detection threshold: if accuracy drops more than 5 percentage points between successive sites, pause processing and retrain. Maintain a secondary validation team (2–3 archivists) that spot-checks AI outputs periodically to catch systematic bias. Budget $1M–$2M for model-validation infrastructure and retraining contingency.

# Risk 13 - Regulatory – Antiquated Equipment Handling and Hazmat Compliance

Vintage tape decks, film scanners and card readers may contain hazardous materials (asbestos in tape heads, mercury in some light sources, lead solder, PCB insulation containing chlorofluorocarbons). Handling and storage of this equipment, particularly during baking cycles, requires compliance with environmental regulations. Baking ovens emit fumes from degraded tape binders and adhesives; insufficient ventilation can expose workers to volatile organic compounds. Transporting vintage equipment across borders may trigger electronic-waste regulations.

Impact: A workplace health incident (worker exposure to asbestos or VOC fumes, respiratory illness) triggers OSHA investigation, potential fines ($5K–$50K+) and liability exposure. Ventilation redesign on units mid-deployment costs $100K–$500K per unit and delays operations by 2–4 weeks. E-waste classification of vintage equipment shipments forces hazmat transport, adding $5K–$20K per relocation and delaying border crossings. A health incident at a host site damages archive relationship and potentially halts the unit.

Likelihood: Low

Severity: High

Action: By Month 2 (2026-12-12), conduct a comprehensive hazmat audit of 20–30 representative vintage machines to identify presence and concentration of hazardous materials. By Month 3 (2027-01-12), engage an industrial hygienist to design oven ventilation and on-board air-quality monitoring for each container. By Month 4 (2027-02-12), obtain regulatory approval (EPA, OSHA, local) for the ventilation design and handling protocol for each planned jurisdiction. Classify vintage equipment as 'functional equipment' or 'reference specimens' in customs documentation to avoid e-waste triggers. By Month 6 (2027-04-12), certify all unit crews in hazmat handling and respiratory protection; conduct refresher training annually. Budget $500K–$1M for hazmat compliance, ventilation systems and monitoring.

# Risk 14 - Operational – Review Bottleneck and Human-in-the-Loop Scaling

The plan mandates human review of all flagged items before archival upload, with reviewers embedded in each unit. At 12–15 reviewers per unit and 30 units, that is 360–450 reviewers at full scale. Reviewers must be multilingual, familiar with copyright, privacy and classification markers, and able to make defensible decisions under deadline. Training a new reviewer takes 2–4 weeks; retaining experienced reviewers is difficult due to burnout. The plan assumes <20% of content requires human review, but this assumption is unvalidated on real content.

Impact: If actual flagging is 35–40%, the review load triples to 360–400 hours per 1,000 hours of content, requiring 40–50 reviewers per unit instead of 12–15. At $50K–$70K per reviewer per year, that is an additional $15M–$25M annual payroll at full scale, far exceeding the budget envelope. Reviewer burnout (20–30% annual turnover) requires continuous recruiting and retraining. Backlog accumulation forces temporary off-board storage or slows intake, reducing effective unit throughput by 10–20%.

Likelihood: High

Severity: Medium

Action: By Month 8 (2027-06-12) (after pilot review pod runs for 2–3 months with real content), measure actual review rates and flagging percentages. If actual flagging exceeds 25%, commission AI model retraining or recalibrate pre-screening thresholds. If retraining is unsuccessful and flagging remains >30%, redesign the review workflow: implement tiered review (automated confidence scoring, 15-minute expert check of high-risk items only, escalation for disputes); delegate Category A items (low-risk public content) to automated acceptance without human review; use subject-matter experts at host archives to review Category C items (copyright, privacy, classification). Establish a Reviewer Retention Program: offer career paths, professional development and remote-work flexibility. By Month 12 (2027-10-12), establish a Reviewer Pool and Shared Services model where reviewers rotate or work remotely, allowing flexible scaling. Budget 20–30% additional reviewer headcount as contingency and build a 4-week backlog buffer (temporary storage for 100–200TB) at each site.

# Risk 15 - Strategic – Long-Term Sustainability and Knowledge Persistence

The plan is funded for 10 years (Months 0–120 = 2026-10-12 to 2036-10-12), at which point operations are expected to conclude. The plan does not specify what happens after Month 120 (2036-10-12): are units retained for ongoing deployment? Are they transferred to archives or universities? Is the parts inventory mothballed or handed over? Is the knowledge base maintained and accessible, or archived and forgotten? Without a clear end-state and transition plan, valuable capability may be lost.

Impact: Loss of capability post-Month 120 (2036-10-12) abandons the 30-unit fleet when media degradation timelines extend to Month 150–180 (2039-04-12 to 2041-10-12) (15–30 years), leaving unrecovered collections orphaned. An estimated 500,000–1,000,000 items could remain undigitized beyond Month 120 (2036-10-12). Partial knowledge transfer concentrates expertise with 1–2 people per line type; subsequent retirements or attrition could extinguish that expertise. Transferred units without ongoing support accumulate deferred maintenance and become inoperable within 2–3 years.

Likelihood: Medium

Severity: Medium

Action: By Month 12 (2027-10-12), establish a Fleet Sunset and Equipment Afterlife Working Group tasked with defining the end-state. By Month 36 (2029-10-12), develop a Transition Plan specifying which units are retained, which transferred and to whom, which decommissioned; a parts-inventory dispersal strategy; and a Knowledge Base stewardship model. By Month 48 (2030-10-12), begin forming successor organizations or partnerships that will inherit and operate retained units. Establish an endowment or sustainability model: transition from philanthropic and government funding to cost-sharing with archives or revenue from service operations. Document all mentoring, repairs and improvements in a digital knowledge commons accessible to the preservation community. By Month 90 (2034-04-12), establish a Post-Programme Continuation Committee representing archives, universities and the preservation community to guide the transition. Budget $2M–$5M from Phase 3 for knowledge-base development and platform stewardship.

# Risk 16 - Organizational – Governance and Decision-Making Authority

The plan involves 15+ funder organisations, 30+ partner archives, and a central programme staff. No governance structure, decision-making authority or conflict-resolution process is described. Key decisions (site selection, AI model approval, review thresholds, privacy disputes, hardware refresh) require buy-in from multiple stakeholders with divergent interests. Different jurisdictions may have different legal and ethical standards for digitization consent, privacy handling and data storage; a one-size-fits-all governance model may fail to adapt to local requirements.

Impact: Governance delays (2–4 weeks of decision-making cycles for routine choices) accumulate to significant calendar loss. A critical decision requiring funder agreement taking 8–12 weeks to resolve can slip a unit deployment by a month. Conflicting funder interests create political pressure that distorts scheduling or budget allocation. Privacy and consent disputes escalated to governance without clear authority are resolved late or not at all, blocking a residency.

Likelihood: Medium

Severity: Medium

Action: By Month 1 (2026-11-12), establish a governance structure: a Programme Board (8–10 representatives from funders, archives, staff) with clear decision authority; committees for Site Selection, Technical Decisions, Legal/Privacy, and Finance. Define decision rights: which decisions require full Board consensus, which require committee approval, which are delegated to programme staff. Publish clear criteria for each decision category. By Month 2 (2026-12-12), develop a Decision-Making Charter that specifies escalation paths and timelines. By Month 3 (2027-01-12), establish a Legal Framework that accommodates jurisdiction-specific requirements. Create a Privacy and Consent Committee with legal expertise from multiple jurisdictions. For funder interests, establish transparent cost-sharing and prioritization rules. By Month 4 (2027-02-12), conduct a stakeholder-engagement workshop with all funders and partner archives to align on governance; document consensus in a charter.

# Risk 17 - Financial – Cost Escalation and Inflation Over 10 Years

The $250M budget is allocated over 10 years in three phases. Historical inflation in the US averages 2–3% annually; over 10 years, cumulative inflation of 20–30% is typical. The plan does not adjust for inflation; stated costs ($3–4M per unit, $2–3M annual opex, $50K–$100K per item) are in nominal 2026 dollars. Actual costs in 2035 will be 20–30% higher if not escalated. Labor cost escalation is particularly acute: skilled technical staff and expert reviewers typically see 3–5% annual raises. Equipment sourcing also faces cost pressure: as the programme acquires hundreds of vintage machines, supply scarcity may drive prices up.

Impact: Without inflation adjustment, Phase 3 (Months 60–120 = 2031-10-12 to 2036-10-12) operates at 20–30% budget shortfall: $70M budgeted but $91M–$100M required at 2036 prices. This forces either reduce Phase 3 unit count from 15 to 10–11, defer Phase 3 start by 12–18 months, or absorb cost overrun. Labor cost escalation (3–5% annually) compounds: a reviewer at $60K in 2026 costs $78K–$88K by 2035; across 450 reviewers at full scale, that is an additional $8M–$12M annual cost at Phase 3 unbudgeted.

Likelihood: High

Severity: Medium

Action: By Month 1 (2026-11-12), restate the $250M budget in constant 2026 dollars and separately calculate cumulative inflation adjustments (2% baseline, with sensitivities for 3% and 4% scenarios). Publish three inflation-adjusted budget scenarios. By Month 3 (2027-01-12), establish an Inflation Escalation Reserve: allocate 15–20% of each phase budget as contingency against inflation and cost escalation. Incorporate inflation adjustment clauses into multi-year contracts with vendors, parts suppliers and staff. By Month 12 (2027-10-12), conduct a mid-Phase-1 cost review: measure actual costs against budget and reproject Phase 2 and Phase 3 using observed escalation rates. Establish quarterly cost-tracking and variance reporting to funders with transparent inflation impact analysis.

# Risk 18 - Technical – Metadata Accuracy and Searchability Validation

The plan assumes >70% automated metadata accuracy (speech-to-text, OCR, scene recognition, auto-generated searchable metadata). This is measured as a success metric but not validated on real 1950–2000 content. Tape recordings from the era include poor-quality audio, accents, background noise, non-English speech and technical jargon that confuse modern speech-to-text models. Film has handwritten labels, faded printed text and mixed languages; OCR accuracy on degraded images is often 60–75%, not 90%+. No plan for assessing or validating metadata accuracy post-digitization is mentioned.

Impact: If metadata accuracy averages 55–65% rather than >70%, searchability is severely degraded: users cannot reliably find collections by title, date, speaker or subject. A systematic metadata error affecting 100,000+ items discovered post-upload creates a major remediation effort. Estimated impact: 10–20% of items require metadata re-work, costing $500K–$2M.

Likelihood: Medium

Severity: Medium

Action: By Month 4 (2027-02-12), establish a Metadata Validation Baseline: sample 100–200 items from the pilot collection across all three line types and measure actual metadata accuracy against human-expert gold standard. If accuracy is below 70%, commission iterative model retraining or introduce a verification step. By Month 8 (mid-pilot), run a Metadata Quality Audit: sample 5% of pilot output and have human experts review for accuracy, completeness and usefulness. For disputed or low-confidence metadata, flag items with a confidence score and mark for manual review by archivists if confidence is <70%. Budget $1M–$2M for metadata validation infrastructure and reprocessing contingency.

# Risk 19 - Environmental and Operational – Climate Control and Power Stability

The plan specifies that each containerized unit maintains stable temperature and humidity during processing and requires stable power (either facility power or on-board generation). Climate stability is critical for tape and film processing: temperature fluctuations cause material movement and azimuth/registration errors; humidity variations cause tape expansion/contraction and film warping. Power instability corrupts digitization and damages sensitive electronics. Host sites vary widely in power stability and climate control. The plan's assumption that units can connect to facility power or operate on generators does not account for sites where facility power is intermittent or impossible.

Impact: Poor power quality damages equipment prematurely and corrupts digitization. A site with chronic power instability forces the unit to operate on generators continuously, increasing fuel cost ($500–$1K per day) and limiting on-site residency duration. Climate instability (humidity swings >30% RH) stresses tape and film, reducing yield and fidelity; humidity excursions also trigger mold growth. A site identified too late as unsuitable forces relocation and consumes 4–6 weeks of schedule and logistics cost.

Likelihood: Low

Severity: Medium

Action: By Month 3 (2027-01-12), establish a Site Infrastructure Audit procedure that assesses each planned archive for power quality (voltage stability, frequency, harmonic content), climate characteristics (temperature and humidity ranges, seasonal variation) and security/access. By Month 4 (2027-02-12), specify equipment requirements per site class: standard sites (facility power + 200kW backup generator); unstable-power sites (400–500kW on-site generation + 48-hour fuel tank + voltage regulator); extreme-climate sites (enhanced dehumidification + active humidity control + sealed container). By Month 6 (2027-04-12), pre-position power and climate equipment at sites classified as unstable before unit arrival. For sites with chronic power outages, partner with local utilities or install solar+battery hybrid systems to reduce generator fuel costs. Monitor power and climate continuously using on-board sensors. Budget $500K–$1.5M for site infrastructure audit, power quality remediation and climate monitoring systems.

# Risk 20 - Summary

The CDDIN programme faces concentrated risks around three critical pillars: (1) Vintage Hardware Sustainment—a finite, depleting stockpile of 50-year-old equipment must sustain 30 units for a decade; parts scarcity, expertise loss as retired engineers age, and head/transport calibration drift threaten the >90% uptime target and could halt the fleet mid-decade. (2) Unproven Operational Assumptions—the claimed 80% AI review reduction, >95% successful digitization, and >80% signal-reconstruction accuracy are hypotheses, not validated on degraded multilingual pre-digital content; failed pilot metrics could collapse Phase 2 funding and funder confidence. (3) Legal and Trust Exposure—on-site residencies depend entirely on archive insurer and fire-authority approval; a single handling incident destroying a unique item, a privacy breach in pre-screening, or a data sovereignty objection could terminate partnerships and halt the network. Secondary risks cluster around staffing (1,500–1,800-person workforce at full scale strains the $250M budget), phased funding (annual cycles and gate-based release risk calendar slippage against 10–30-year media degradation timelines), and border logistics (temporary import of vintage equipment and cross-border data residency rules are unresolved). The programme's own design prioritizes safeguards (no autonomous legal decisions, human-in-the-loop review, parts-backed maintenance) but does not model the spares-depletion curve, validate review accuracy on real content, or secure binding commitments from consortium members or funders. Execution success hinges on honest pilot validation and early clarity on hardware refresh, review capacity and legal indemnity.

# Make Assumptions
# Question 1 - Which funders will sign binding multi-year commitments for the $250M (user constraint), and how will the staffing-versus-opex mismatch and inflation be reconciled?

## Assumptions

- At least 50% of Phase 1 ($60M) is committed (not pledged) by Month 3 (2027-01-12), a 10% contingency is held per phase, and the budget is restated in constant 2026 dollars.
- Pledged funds on annual cycles commonly slip; 10% is a typical infrastructure contingency.

## Financial Feasibility Assessment

Tests whether $250M covers 30 units and the stated crews.

50-60 staff per unit at 30 units implies payroll of roughly $36M-$54M per year (estimate), against a $25M average annual budget. Either unit count, crew size or budget must change.

Mitigation:

- Independent cost audit by Month 1 (2026-11-12).
- Binding commitments registry.
- Inflation reserve of 15-20% (proposed).
- Bridge facility for gate delays.

# Question 2 - What gate criteria and durations release Phase 2 (Month 24 = 2028-10-12) and Phase 3 (Month 60 = 2031-10-12), and how long must the stress-first pilot run?

## Assumptions

- Pilots run Months 6-20 (2027-04-12 to 2028-06-12) on at least two host sites.
- Design freeze occurs by Month 20 (2028-06-12).
- Gates are agreed in writing before Month 6 (2027-04-12).
- Media failure modes and review rates need several months of real data.

## Schedule and Gate Assessment

Evaluates pacing from 3 to 15 to 30 units.

Phase 2 slip of 3-6 months is plausible if funder committee cycles apply (estimate). Stress-first pilot exposes failures early but may depress early metrics; pre-agreed thresholds and a best-efforts override (e.g. >80% of targets, proposed) limit this. Build 2-3 month buffers per transition. Quarterly milestones keep evidence continuous.

# Question 3 - How many engineers, reviewers and retired-engineer mentors are needed per phase, and where will they be recruited?

## Assumptions

- 6-8 retired mentors are secured by Month 1 (2026-11-12), each training 2-3 successors over 18-24 months.
- Hubs in Northern Virginia, UK and Netherlands.
- Redundancy covers mentor attrition at ages 70-80.

## Workforce and Expertise Assessment

Reviews crew model and perishable vintage skills.

The 1,500-1,800 headcount is unreconciled with budget. Reviewer load depends on the unvalidated 80% reduction; at 35-40% flagging, reviewers per unit could be 3x (estimate).

Mitigation:

- Pilot review pod by Month 8 (2027-06-12).
- Retention bonuses.
- Documented curricula.
- Shared reviewer pool.

Mentor loss before Month 18 (2028-04-12) would delay transfer by 6-12 months (estimate).

# Question 4 - What governance body, decision rights and source-agreement terms (privacy, copyright, data residency) will apply across jurisdictions?

## Assumptions

- A Programme Board of 8-10 members with site, technical, legal and finance committees is formed by Month 1 (2026-11-12), using a standard source-agreement template with jurisdiction-specific annexes.
- 15+ funders and 30+ archives need clear decision rights.

## Governance and Compliance Assessment

Evaluates decision authority and legal exposure.

Without defined rights, routine decisions can slip 2-4 weeks each (estimate). GDPR and UK DPA transfer limits may force federated storage with masters held in-country.

Mitigation:

- Privacy panel with decision log.
- Privacy Impact Assessment per agreement.
- Tiered consent.
- Legal budget of $1M-$2M (estimate).
- Bar funder terms such as training-data access if they breach source agreements.

# Question 5 - What fire, hazmat and handling-loss controls and insurance terms will host insurers and fire authorities require for ovens, humidity chambers and generators?

## Assumptions

- One pilot site obtains written insurer and fire-authority approval by Month 6 (2027-04-12), using a detached or certified-suppressed pre-treatment design, plus a pooled loss reserve of $2M-$5M (estimate).
- On-site processing removes shipping risk but not handling risk.

## Safety and Risk Assessment

Reviews thermal, chemical and item-loss exposure.

A single incident could terminate partnerships network-wide. Site approvals may add 4-8 weeks each (estimate).

Controls:

- Containment standard.
- VOC air monitoring.
- Hazmat audit of 20-30 machines.
- Incident protocol with 24-hour insurer notice.
- Tiered indemnity.
- Detached pods reduce blast radius but raise footprint and permitting.

# Question 6 - What environmental requirements apply to generator emissions, VOC and fume discharge, e-waste classification, and unstable power or climate at host sites?

## Assumptions

- Each site receives a power and climate audit before arrival.
- Units use facility power first with generator backup.
- Ovens vent through filtered, monitored exhaust.
- Host sites vary widely in grid quality and humidity.

## Environmental Impact Assessment

Covers emissions, waste and site-condition effects.

Generator fuel could cost $500-$1,000 per day at unstable sites (estimate). Vintage equipment may contain asbestos, lead or PCBs, and cross-border shipment may trigger e-waste rules.

Mitigation:

- Hybrid solar-battery where feasible.
- Hazmat protocol.
- Functional-equipment documentation.
- End-of-life disposal plan.

# Question 7 - Which archives, funders, regulators and heritage bodies must commit, and how will under-resourced archives be reached?

## Assumptions

- Three pilot archives sign multi-year agreements by Month 6 (2027-04-12), with a waitlist of backup sites and tiered host in-kind contributions.
- Site withdrawal mid-residency strands units and orphans collections.

## Stakeholder Engagement Assessment

Evaluates trust, commitments and equity of access.

Archive trust is existential; one privacy or loss incident can cascade. Tiered scheduling may favour well-resourced hosts over the most endangered collections.

Mitigation:

- Stakeholder workshop by Month 4 (2027-02-12).
- Transparent prioritisation rules.
- 2-3 year host commitments.
- Published recovery results.
- Technology-sector funding needs non-exclusive, rights-holder-approved terms.

# Question 8 - What operational systems will run scheduling, telemetry, parts tracking, AI validation, storage custody and the post-Month 120 (2036-10-12) end-state?

## Assumptions

- A central operations room with sensors, parts-inventory dashboard, validated AI models and two verified copies of each master is operational by Month 12 (2027-10-12), with an end-state plan by Month 36 (2029-10-12).
- Uptime of >90% (user constraint) needs measured reliability data.

## Operational Systems Assessment

Reviews fleet management, data and sustainment.

Parts-depletion modelling is absent; uptime below 90% by Months 36-48 (2029-10-12 to 2030-10-12) is plausible (estimate).

Needs:

- Telemetry.
- Canary batches of 10-20 items per site.
- Drift thresholds.
- 4-week review backlog buffer.

Custody of 200+ PB (user constraint) creates perpetual storage costs beyond Month 120 (2036-10-12); fund migration and decide unit transfer or retained core early.

# Distill Assumptions
I'm ready to receive the Markdown document that needs to be shortened. Please paste the project planning document, and I will condense it while preserving all topics, structure, and key details as outlined in your instructions.

# Review Assumptions
# Domain of the Expert Reviewer
Large-scale physical infrastructure and heritage preservation project delivery, with focus on phased capital deployment, vintage-equipment sustainment, multi-stakeholder governance, and long-term institutional risk management.

## Domain-specific Considerations

- Finite, depleting stockpile of 50-year-old playback hardware is the core throughput constraint; parts-depletion curve and mean-time-between-failures modeling are absent.
- Assumed 80% AI review reduction and >90% uptime target are unvalidated on real degraded, multilingual pre-digital content; pilot must replace hypothesis with evidence.
- On-site residencies depend entirely on archive insurer and fire-authority approval; a single handling incident could cascade partnership termination across the network.
- Staffing model (1,500–1,800 people at full scale, $36M–$54M annual payroll) does not reconcile visibly with $25M average annual budget; cost structure requires immediate audit.
- Knowledge transfer from retiring mentors (ages 70–80) to successors is perishable asset with no documented curriculum or retention mechanism.
- Phased funding ($60M–$120M–$70M) tied to gates depends on 15+ funders with annual cycles; calendar slippage against 10–30-year media degradation timelines compounds risk.

# Issue 1 - Vintage Hardware Sustainment and Parts-Depletion Modeling

Plan depends on cannibalizing 300–500 decommissioned tape decks and film scanners to sustain 30 units for a decade. No model of parts consumption, mean time between failures, or refresh capacity exists. Retired engineers (aged 70–80) hold irreplaceable expertise in head alignment and mechanical repair. 3D printing of precision parts is proposed but unproven at required tolerances. By Month 36–48 (2029-10-12 to 2030-10-12), parts depletion and expertise loss could reduce fleet uptime below >90% target, causing units to go offline for weeks and losing 300TB–500TB of planned capture per month offline.

## Recommendation

- By Month 2 (2026-12-12), commission detailed parts-depletion curve modeling mean time between failures per deck type, cannibalization yield, and 3D-printing capability for 20+ critical parts.
- Establish dedicated Parts Engineering team to validate fabrication on working reference decks and test tolerance performance on playback fidelity.
- Secure written commitments from 6–8 retired engineers (redundancy for attrition at ages 70–80) for intensive 24-month mentoring by Month 1 (2026-11-12).
- By Month 6 (2027-04-12), publish parts inventory in granular detail, tag all 300–500 acquired units, and integrate parts consumption telemetry into central fleet-management dashboard.
- Budget $10M–$15M for parts-engineering capability, contingency stockpile refresh, and mentor retention bonuses.

## Sensitivity

- Uptime target unachievable without spares modeling. If parts-depletion outpaces fabrication capacity by Month 36 (2029-10-12), 10% fleet downtime (3 units continuously offline) represents 300TB–500TB monthly loss, or 3.6M–7.2M items deferred.
- Recomputed cost of emergency vintage-equipment acquisition mid-programme: $15M–$25M unbudgeted.
- Mentor loss before Month 18 (2028-04-12) delays transfer by 6–12 months, leaving younger engineers under-trained when mentors exit, forcing $5K–$10K per-incident external consultant costs vs. $500–$1K in-house.

# Issue 2 - Unvalidated AI and Review Assumptions; Bottleneck Scaling Risk

Plan assumes 80% of content is filtered by AI pre-screening, reducing review load from 1,000 to 200 hours per collection. It also assumes >80% signal-reconstruction accuracy and >70% metadata accuracy. These metrics are stated as success targets but have not been validated on real degraded, multilingual pre-digital content from 1950–2000 (tape dropouts, film shrinkage, handwritten metadata, non-English speech). If pre-screening accuracy is 65–70% on real content rather than 80%, flagging increases to 30–35%, requiring 400–600 review hours per 1,000 hours of content. At 12–15 reviewers per unit instead of 40–50, this triples headcount and increases payroll by $15M–$25M annually at full scale. Reviewers (multilingual, legal/privacy trained) are scarce; turnover and burnout are high in repetitive review work.

## Recommendation

- By Month 2 (2026-12-12), procure 100–200 representative samples from proposed pilot archives spanning all three formats and degradation levels.
- Build gold-standard labeled dataset with expert review of copyright, privacy and classification markers.
- Test AI pipeline on real content by Month 4 (2027-02-12) and publish precision, recall and false-positive rate by format and degradation level.
- If pre-screening accuracy is below 75%, commission iterative retraining rather than accepting vendor claims.
- By Month 8 (2027-06-12), run pilot review pod with 5–10 reviewers on flagged content and measure actual review hours per content hour.
- If ratio exceeds 1:2, recalibrate crew composition and Phase 2 staffing assumptions.
- Establish Reviewer Retention Program (career paths, professional development, remote work flexibility) and Shared Reviewer Services pool (rotating assignments) to reduce burnout and enable flexible scaling.
- Budget an additional 20–30% reviewer headcount as contingency.

## Sensitivity

- If 80% reduction proves false and actual flagging is 35–40%, review load triples, requiring 40–50 reviewers per unit instead of 12–15. Additional payroll cost at full scale: $15M–$25M annually (at $50K–$70K per reviewer per year).
- Detection of accuracy failure at Month 12–18 (2027-10-12 to 2028-04-12) (pilot midpoint) consumes Phase 1 budget before remediation, forcing Phase 2 deferral and 6–12 months of calendar delay.
- Metadata accuracy below 70% (estimate: 55–65% likely on degraded content) degrades searchability and user value; 10–20% of items require re-work post-upload, costing $500K–$2M in remediation labor.

# Issue 3 - Staffing-to-Budget Reconciliation and Phased-Funding Timing Risk

Plan allocates 50–60 staff per unit at 30 units (1,500–1,800 people at full scale) with annual opex of $2–3M per unit. Recomputed: payroll at $50K–$70K per staff member per year implies $36M–$54M annual labor cost at full scale, against $25M average annual budget. Either unit count, crew size or budget must change. Additionally, phased funding ($60M–$120M–$70M across three phases, Months 0–24 = 2026-10-12 to 2028-10-12, 24–60, 60–120) is tied to gate releases depending on 15+ funders operating on annual budget cycles (4–8 weeks per approval). A Phase 2 gate slip of 3–6 months due to funder committee delays or pilot discovery of unmet assumptions would reduce Phase 2 effective residencies by 5–15%, shrinking digitized items by 50,000–300,000. Inflation of 2–3% annually compounds cost pressure: by Month 120 (2036-10-12), nominal costs are 20–30% higher than budgeted (estimate), forcing Phase 3 to operate at $62.5M–$100M shortfall unbudgeted.

## Recommendation

- By Month 1 (2026-11-12), commission independent cost audit reconciling stated unit staffing, payroll, and $250M budget across all cost categories (salaries, benefits, travel, visa, equipment, parts, logistics, utilities, connectivity).
- Publish three scenarios: baseline budget, high-cost (35% inflation), extreme-cost (45% inflation).
- Establish Funding Commitment Registry translating all pledges into binding multi-year contracts with milestone-release conditions by Month 3 (2027-01-12); target 50%+ committed (not pledged).
- Implement inflation-escalation reserves of 15–20% per phase ($9M Phase 1, $18M Phase 2, $10.5M Phase 3).
- Establish Contingency Funding Panel identifying backup sources ($10M–$20M gap capacity) to avoid mid-programme funding shocks.
- Build 2–3 month scheduling buffers into each phase transition to absorb funding-release delays.
- Implement quarterly cost-tracking with variance reporting to funders.

## Sensitivity

- Budget shortfall at full scale: $11M–$29M annually (payroll overrun) or $62.5M–$100M over Phase 3 alone (inflation unaccounted).
- If full-scale costs exceed $250M and unit count must reduce from 30 to 20–22, digitized items drop from 3.6M to 2.4M–2.64M, and recovery timeline extends 2–3 years, compounding media degradation loss.
- Phase 2 gate slip of 6 months reduces Phase 2 residency target by 5% (2–3 fewer sites), deferring 50,000–200,000 items per month lost.
- A $30M–$40M funder withdrawal (one major technology company or government source) compresses Phase 3 by 25–30%, cutting final unit count by 5–10.

# Review Conclusion

The programme's three most critical issues are: (1) vintage hardware sustainment, where an unmodeled spares-depletion curve and perishable mentor expertise threaten the >90% uptime target and could collapse capacity by mid-decade; (2) unvalidated operational assumptions, where the claimed 80% AI review reduction and high accuracy targets must be replaced by pilot evidence before Phase 2 commitment; and (3) staffing-to-budget reconciliation, where recomputed payroll ($36M–$54M annually at full scale) does not visibly reconcile with $25M average annual budget and inflation compounds the gap. Secondary risks cluster around on-site handling and liability exposure (which could cascade partnership termination across the network after one incident), phased-funding timing (annual committee cycles risk calendar slippage against degradation timelines), and knowledge-transfer perishability (retired mentors at ages 70–80 must transfer expertise to successors on tight 18–24 month window). Execution depends on: (1) immediate parts-depletion and cost modeling (Months 1–2 = 2026-11-12 to 2026-12-12), (2) honest pilot validation with real degraded content (Months 4–8 = 2027-02-12 to 2027-06-12) before Phase 2 design freeze, (3) binding multi-year funder commitments and inflation reserves (Months 1–3 = 2026-11-12 to 2027-01-12), and (4) binding governance structure with clear decision rights, privacy/liability frameworks, and defined post-Month 120 (2036-10-12) end-state (Months 1–3 = 2026-11-12 to 2027-01-12). The plan's own safeguard architecture (no autonomous legal decisions, human-in-the-loop review, parts-backed maintenance) is sound in principle but requires transparent modeling and early testing to earn funder confidence and archive trust.