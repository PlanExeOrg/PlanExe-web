
## Documents to Create

### 1. Project Charter and Strategic Framework

**ID:** 52fc1227-cebb-4932-bfca-fe2871cf8c94

**Description:** High-level charter establishing governance, decision authorities, phase gates, and strategic objectives for the 10-year, USD 250M mobile-ingest containerized digitization programme. Includes scope (3.6M+ items, 200+ PB), phases (3 pilots → 15 → 30 units), and non-negotiable safeguards (no autonomous legal decisions, human-in-the-loop review, media never ships). Intended audience: Programme Board, funders, partner archives, regulatory authorities.

**Responsible Role Type:** Programme Director / Executive Lead

**Primary Template:** PMI Project Charter Template, adapted for non-profit heritage preservation

**Secondary Template:** World Bank Logical Framework (LFA) for development programmes

**Steps:**

- Define programme goals (SMART criteria), scope boundaries (what is in/out of digitization), constraints (USD 250M cap, media never ships, no autonomous legal calls).
- Establish governance structure: 8-10 member Programme Board with defined decision rights per lever (site selection, AI approval, gate releases, escalation triggers).
- Lock phase definitions: Phase 1 (Months 0-24 = 2026-10-12 to 2028-10-12, USD 60M, 3 pilots); Phase 2 (Months 24-60 = 2028-10-12 to 2031-10-12, USD 120M, 12 additional units); Phase 3 (Months 60-120 = 2031-10-12 to 2036-10-12, USD 70M, 15 final units).
- Define gate criteria and evidence thresholds for Phase 2 and Phase 3 release (pilot results: digitization >95%, accuracy >80%, uptime >90%, flagging <20%, zero incidents).
- Obtain written approval from all funders and partner archives by Month 2 (2026-12-12).

**Approval Authorities:** Programme Board (8-10 members), all 15+ funders, legal counsel

### 2. Reconciled Cost and Staffing Model (Phase 1–3 Budget Lock)

**ID:** 65c5b403-615f-4efe-8d61-5575f650be42

**Description:** Independent audit reconciling the USD 250M cap with recomputed staffing (50–60 per unit × 30 units = 1,500–1,800 people; payroll ~USD 75–126M annually at full scale vs. USD 25M average budget envelope). Publishes three scenarios: (A) full scope with host cost-sharing/new funders closing USD 280M gap; (B) cap-constrained reduced scope (~14 units, ~1.7M items); (C) phased contingency funding (Phase 3 deferred). Locks Phase 1 and Phase 2 staffing and opex by Month 4 (2027-02-12). Intended audience: Programme Director, finance lead, Programme Board, all funders.

**Responsible Role Type:** Financial Analyst and Budget Director, with input from Chief Engineer and infrastructure cost auditor

**Primary Template:** Infrastructure Cost Model Template (itemized opex per unit per role and region)

**Secondary Template:** Multi-scenario phased budget with sensitivity analysis (inflation 2%, 3%, 4% escalation)

**Steps:**

- Engage external cost auditor (Month 1 = 2026-11-12) to conduct bottom-up cost build: salary per role and region, benefits and taxes (15–25% loaded), travel and visa costs, equipment and parts, consumables (tape, lubricants, cleaning), utilities, satellite/fiber uplink, insurance, overhead per unit per year.
- Model payroll under three crew scenarios: (A) stated 50–60 per unit; (B) embedded 25–30 per unit (host co-training); (C) centralized 15 on-site + remote hubs.
- Run Pilot Staffing Pod (Months 3–6 = 2027-01-12 to 2027-04-12) at first hub site; measure actual loaded costs and time-to-productivity for all roles; extrapolate to full scale.
- Publish three budget scenarios (baseline, +15% inflation, +30%) to Month 120 (2036-10-12). Calculate cumulative gap: unconstrained cost is ~USD 530M vs. USD 250M cap (gap ~USD 280M before contingency).
- Define adjustment path: host cost-share per MIU, new funder commitments, unit-count reduction or crew-size reduction to fit cap.
- Lock Phase 1 and Phase 2 staffing model by Month 4 (2027-02-12); publish triggers for Phase 3 re-assessment if cost exceeds USD 250M by >10%.

**Approval Authorities:** Financial Analyst, Programme Director, Programme Board, all funders (binding commitment required)

### 3. Vintage Transport Sustainment Strategy and Parts-Depletion Model

**ID:** 1aec9791-3341-496e-85a5-4feb864661fc

**Description:** Quantifies the finite stockpile of 300–500 vintage tape decks, film scanners and card readers: mean-time-between-failures (MTBF) per deck type, cannibalization yield per 10 machines, 3D-printing/CNC fabrication capability for 20+ critical parts (capstan sleeves, azimuth fixtures, pinch rollers), and parts-consumption curves. Establishes re-manufacture trigger at 50% spares depletion. Validates 3D-printed parts against archival playback standards (azimuth ±0.05mm, wow/flutter <0.05%, SNR >50dB). Intended audience: Chief Engineer, Parts Manager, retired-engineer mentors, Programme Board.

**Responsible Role Type:** Vintage Equipment Sustainment Engineer / Parts Manager, with input from broadcast-equipment restoration specialists

**Primary Template:** Reliability and Maintainability (R&M) Analysis template (MTBF modeling, spares optimization)

**Secondary Template:** Engineering tolerance and acceptance-criteria document (archival playback standards)

**Steps:**

- Commission external MTBF specialist (Month 1 = 2026-11-12) to model failure-rate distributions for Tape Line (Ampex, Studer, Otari decks), Film Line (Rank, Oxberry scanners), and Card Line (readers) based on broadcast-industry data and reference machines.
- Conduct condition assessment of all 300–500 acquired machines (Month 6 = 2027-04-12): serial number, format, functional status, head wear (azimuth offset measurement), transport drift, parts-harvest potential per unit.
- Model monthly spares consumption per active unit by format and part category; calculate cumulative depletion curve for 160 unit-years (Phases 1–3). Identify inflection point where remaining spares drop to 50% (re-manufacture trigger).
- Establish Parts Engineering team (3–5 engineers, Month 4 = 2027-02-12) to validate 3D-printing and CNC fabrication of 10 priority parts by testing on reference-grade decks; measure playback fidelity and tolerance conformance.
- Deploy Parts Consumption Telemetry dashboard (Month 10 = 2027-08-12) with automatic re-manufacture order triggers at 50% stock depletion.
- Document all fabrication specs, tolerance ranges and supplier relationships for perpetual post-Month 120 (2036-10-12) reference.

**Approval Authorities:** Chief Engineer, Vintage Equipment Sustainment Engineer, retired-engineer mentors, Programme Board

### 4. Retired-Engineer Mentoring Curriculum and Knowledge-Transfer Plan

**ID:** 424094a1-6b41-4dbe-a4b2-e0d30a835660

**Description:** Formal 24-month knowledge-transfer program pairing 6–8 retired broadcast and film engineers (aged 70–80) with 2–3 younger successors each. Documents 50–80 critical repair competencies per line type (tape azimuth alignment, film registration, head calibration, belt replacement, mechanical troubleshooting). Includes mentoring schedules (minimum 16 hours per month per pair), evaluation criteria, video and written protocols, and retention incentives (consulting role extension to Month 48 = 2030-10-12). Intended audience: retired mentors, successor engineers, Chief Engineer, Programme Board.

**Responsible Role Type:** Chief Engineer, with input from retired-engineer mentors and technical training specialist

**Primary Template:** Adult learning and knowledge-transfer curriculum template (competency mapping, hands-on skill certification)

**Secondary Template:** Oral history and documentation protocol for archival knowledge preservation

**Steps:**

- Conduct competency mapping workshops with 6–8 retired mentors (Month 1 = 2026-11-12) to identify 50–80 critical repair skills per line type; prioritize by frequency-of-use and consequence-of-failure.
- Develop detailed mentoring schedule: weekly hands-on sessions (4 hours), monthly review and evaluation, quarterly curriculum updates. Define competency sign-off criteria.
- Create permanent documentation: high-definition video of demonstrations (tape azimuth procedure, film registration setup), written step-by-step protocols with photographs, troubleshooting flowcharts.
- Establish a digital knowledge repository (wiki, video library, searchable documentation) accessible to all engineers during and after the programme (through Month 120 = 2036-10-12 and beyond).
- Secure binding mentoring contracts (Month 1 = 2026-11-12) with 6–8 mentors: USD 80K retainer + USD 20K per successor trained, with retention bonus (USD 50K–100K) extending to Month 48 (2030-10-12).
- Pair each mentor with 2–3 successors by Month 3 (2027-01-12); begin intensive mentoring by Month 4 (2027-02-12).
- Publish quarterly progress reports to Programme Board tracking mentee competency certification and knowledge-transfer completion.

**Approval Authorities:** Chief Engineer, retired-engineer mentors, Programme Board

### 5. AI Pre-Screening Validation Report and Model Accuracy Assessment

**ID:** 6ffc8e3d-6260-4b5c-9ad8-28860f65d9c5

**Description:** Validates the claimed 80% AI review reduction (20% flagging assumption) on real degraded, multilingual 1950–2000 content. Creates gold-standard labeled dataset (100–200 samples across Tape, Film, Card formats, condition grades 3–4) with 3–5 expert human reviewers (copyright, privacy, archivists); achieves inter-rater agreement Cohen's kappa ≥0.75. Tests AI pre-screening precision, recall and false-positive rates per category (copyright, privacy, classification) and format-degradation pair. Measures actual review hours and flagging percentage during pilot pod operations (Months 6–8 = 2027-04-12 to 2027-06-12). Triggers retraining if precision/recall <75% or flagging >25%. Intended audience: AI engineering team, review team lead, Privacy Review Panel, Programme Board.

**Responsible Role Type:** AI Signal Processing and Metadata Engineering Lead, with independent ML validation specialist

**Primary Template:** Machine-learning model validation and evaluation template (precision, recall, F1-score, confusion matrices)

**Secondary Template:** Labeled dataset documentation and inter-rater agreement analysis (Cohen's kappa, Krippendorff's alpha)

**Steps:**

- Procure 100–200 representative content samples from three pilot archives (Month 2 = 2026-12-12): 50% tape recordings, 40% film, 10% card/disk media; emphasize degradation levels 3–4 (poor azimuth, layer adhesion issues, color fade, fading text).
- Recruit 3–5 independent expert reviewers (copyright specialist, privacy law counsel, archivist, multilingual curator) to label each sample independently for: copyright markers (presence/absence, confidence score 1–5), PII indicators (type: names, medical, financial, communications; presence/absence), classification markers (government, military, proprietary; presence/absence). Calculate Cohen's kappa inter-rater agreement; achieve ≥0.75 threshold.
- Test AI pre-screening pipeline on gold-standard labeled set; compute precision, recall and false-positive rate per category and format-degradation pair. Identify any category-format pair with <75% precision or recall as high-risk.
- Commission iterative retraining if any metric falls below 75%; retrain on domain-specific labeled data and retest by Month 6 (2027-04-12).
- Run pilot review pod (Months 6–8 = 2027-04-12 to 2027-06-12): route all flagged items and 5–10% stratified sample of non-flagged content through review gate; measure actual review hours per content hour and actual flagging percentage.
- Publish go/no-go Evidence Report by Month 8 (2027-06-12) certifying: precision and recall ≥75% per category-format, or governance re-assessment if below; actual flagging rate validated; Phase 2 design lock decision.

**Approval Authorities:** AI Signal Processing Lead, independent ML validator (external), Privacy Review Panel, Programme Board

### 6. Rights, Privacy, and Review Gate Design Specification

**ID:** ea35d46a-9026-4183-bb63-00438c067e70

**Description:** Operationalizes pre-upload human and AI review: specifies AI pre-screening workflow (copyright, privacy, classification detection), human-review workflow (15–20 minutes per flagged item), decision logic per content category, and review-quality assurance. Establishes the Privacy Review Panel (2–3 data-protection experts rotating per site), Privacy Decision Log, and escalation path for disputed items. Defines success metrics: <20% flagging rate, <0.5 hours review per content hour, zero privacy/legal incidents. Addresses multilingual and non-English content. Intended audience: review team leads, privacy panel, archive partners, legal counsel, Programme Board.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer, with input from AI lead and review team lead

**Primary Template:** Workflow process specification template (decision tree, escalation matrix, quality gates)

**Secondary Template:** Legal and compliance control framework (privacy review checklist, incident escalation protocol)

**Steps:**

- Define AI pre-screening workflow: input (audio/video/metadata), detection models (copyright markers, PII patterns, classification keywords), output (flagged/not-flagged, confidence scores), threshold calibration (precision ≥75%, recall ≥75%).
- Define human-review workflow: review-pod structure (12–15 reviewers per unit), triage (high-confidence flags reviewed first, low-confidence flags sampled), review pace (15–20 minutes per item), decision categories (approve, restrict, defer, escalate).
- Establish Privacy Review Panel: 2–3 rotating data-protection experts per site/region; monthly panel meetings to review disputed privacy decisions; maintain Privacy Decision Log with decision rationale, reviewer notes, appeals.
- Design tiered review for efficiency: Tier 1 (automated confidence scoring, accept high-confidence clean items without human review); Tier 2 (15-minute expert check of medium-risk items); Tier 3 (escalation of high-risk or disputed items to Privacy Panel).
- Create quality-assurance mechanism: audit 5% of all reviewed items quarterly by independent expert; flag systematic drift in decision-making; recalibrate thresholds if variance >10%.
- Specify incident escalation: any uploaded item later found to violate copyright or privacy -> 24-hour notification to archive, 48-hour notice to regulator if GDPR threshold met, 5-business-day remediation plan.

**Approval Authorities:** Privacy, Rights and Legal Compliance Officer, Privacy Review Panel, Programme Board

### 7. Custody, Format, and Access Regime for Recovered Data (Perpetual Storage Plan)

**ID:** f40ada10-6b05-4583-b1e6-45b763d8e694

**Description:** Settles where 200+ PB of digitized masters will legally reside, in what preservation formats, how many verified copies exist, and who funds perpetual storage beyond Month 120 (2036-10-12). Recommends hybrid model: archive-held masters on certified storage per jurisdiction, verified secondary copy replicated to federated network of national repositories. Specifies preservation-format standards per line type (FLAC or uncompressed WAV for audio, TIFF or DPX for film, text or PDF for cards), access-derivative formats, and format-migration triggers (every 10 years or when format obsolescence risk rises above threshold). Identifies long-term funding source (national stewardship alliance, government archive consortium, endowment). Intended audience: archives, funders, legal counsel, data-governance office, Programme Board.

**Responsible Role Type:** Data Governance Office (Chief Privacy Officer and legal counsel), with input from archives, preservationists, and IT infrastructure specialists

**Primary Template:** Digital Preservation Policy template (OAIS reference model, ISO 14721)

**Secondary Template:** Data Custodianship and Long-Term Stewardship Agreement template

**Steps:**

- Establish Custody and Stewardship Working Group (Month 3 = 2027-01-12) with 6–8 members: legal counsel, archivists, data-governance lead, funder representative, IT infrastructure specialist.
- Conduct Data-Residency Mapping (Month 3 = 2027-01-12): per the Regulatory Jurisdictional Matrix, identify transfer restrictions and in-country residency rules for each planned deployment country. Create Data-Residency Registry tagging every collection (originating country, restricted-data presence, legal residency requirement, primary steward archive, backup location).
- Model perpetual-storage costs: USD 3–5M per PB over 20 years (~USD 600M–1B for 200+ PB), far exceeding the USD 250M programme budget. Identify funding source: government archive consortium, national digital stewardship alliance, technology-sector endowment, or tiered cost-sharing with partner archives.
- Specify preservation formats: FLAC or uncompressed WAV for audio, TIFF (LZW or uncompressed) or DPX for film, text or PDF for cards. Document metadata schema (Dublin Core, PREMIS for fixity and provenance).
- Define replication architecture: archive-held masters on certified archival storage media, verified secondary copy on geographically separate federated archive network (PREMIS chain-of-custody). Accept no data loss >10^-18 per bit per year (archival standard).
- Secure binding multi-decade stewardship commitment from at least one national or regional archive (written agreement) by Month 24 (2028-10-12).
- Lock Custody Model Choice (archive-held masters vs. central repository vs. offline deposit) by Month 6 (2027-04-12) and publish in gate-release evidence.

**Approval Authorities:** Data Governance Office (Chief Privacy Officer), programme legal counsel, partner archives, Programme Board

### 8. Funding Commitment Registry and Financial Sustainability Plan

**ID:** d17bb111-fa21-4a3a-895d-3aa85f82ef41

**Description:** Translates all 15+ funder pledges into binding multi-year contracts specifying committed amounts, release tranches tied to measurable gates, contingency allowances per phase (15–20%), and override conditions. Targets ≥50% of Phase 1 (USD 30M of USD 60M) committed (not pledged) by Month 3 (2027-01-12), ≥70% of Phase 2 (USD 84M of USD 120M) by Month 20 (2028-06-12), ≥70% of Phase 3 (USD 49M of USD 70M) by Month 48 (2030-10-12). Identifies backup funding sources (host cost-share per MIU, government archives, non-exclusive technology-sector licensing). Establishes Contingency Funding Panel and pre-qualifies USD 15–20M revolving credit facility by Month 3 (2027-01-12) to cover 2–3 months of opex if phase-release tranches slip. Intended audience: Programme Director, finance lead, all funders, Programme Board.

**Responsible Role Type:** Finance Lead / Budget Director, with input from fundraising specialist

**Primary Template:** Multi-party funding agreement template (grant agreements with milestone conditions)

**Secondary Template:** Cash-flow and contingency-funding plan template

**Steps:**

- Conduct outreach to all 15+ funders (Month 1 = 2026-11-12) to understand current pledge status, annual budget cycles, decision timelines, and conditions (gates, co-funding, exclusivity).
- Develop standardized Funder Agreement Terms specifying: committed amount, multi-year commitment window, release tranches (percentage tied to gates), governance approval authority, contingency allowance (15–20% per phase), override clause (best-efforts at ≥80% of targets allows conditional limited tranche).
- Create Funding Commitment Registry (spreadsheet or database) documenting each funder: organization name, pledged amount, commitment status (pledged/intent-to-commit/committed/fully-committed), expected release schedule, contingency terms, co-funding rules. Update monthly.
- Target ≥50% of Phase 1 (USD 30M) committed by Month 3 (2027-01-12); ≥70% of Phase 2 by Month 20 (2028-06-12); ≥70% of Phase 3 by Month 48 (2030-10-12). Escalate to Programme Board if commitment lags behind these thresholds.
- Identify three backup funding sources: (A) host cost-sharing per MIU (quantify in-kind power, space, liaison value), (B) new government or philanthropic consortium members, (C) non-exclusive technology-sector research-access licensing (with source-agreement approval from archives and rights holders).
- Establish Contingency Funding Panel (Programme Director, Finance Lead, funder representatives) to activate backup sources if phase-release tranches slip >4 weeks or cumulative variance exceeds +10% overspend.
- Pre-qualify USD 15–20M revolving credit facility or bridge-lending arrangement by Month 3 (2027-01-12) to cover working-capital gaps between phase releases.

**Approval Authorities:** Finance Lead, all funder organizations, Programme Board

### 9. Pilot Proof Gates and Scale-Up Cadence (Gate-Release Decision Criteria)

**ID:** 4b515f34-e5d3-4cd1-97b5-0c9cd522c0cd

**Description:** Specifies gate evidence thresholds, gate-release decision criteria, and timeline for progressing from 3 pilot units (Phase 1) to 15 units (Phase 2) to 30 units (Phase 3). Phase 1–2 gate (Month 24 = 2028-10-12): all three pilot lines must hold ≥3 consecutive months of digitization success >95%, reconstruction accuracy >80%, metadata accuracy >70%, human review <20%, uptime >90%, AI pre-screen precision and recall ≥75% per category-format, zero incidents at ≥2 host sites. Best-efforts override NOT accepted; results at ≥80% of targets (flagging ≤25%) allow only conditional limited tranche. Phase 2–3 gate (Month 60 = 2031-10-12): ≥500K items and ≥25 PB cumulative, 15 units with >90% trailing 6-month uptime, Phase 1 thresholds still met, ≥70% of Phase 3 funds committed, cumulative variance ≤10%, zero reportable incidents, spares above 50% depletion trigger. Stress-first pilot strategy: send first unit to worst-condition collection to expose failure modes early. Intended audience: Programme Board, all funders, partner archives.

**Responsible Role Type:** Programme Director, with input from Chief Engineer and AI/Review Lead

**Primary Template:** Gate-release decision framework template (evidence criteria, thresholds, escalation triggers)

**Secondary Template:** Pilot test plan and evidence-collection protocol

**Steps:**

- Define Phase 1–2 gate (Month 24 = 2028-10-12) evidence thresholds in writing by Month 1 (2026-11-12); obtain Programme Board approval by Month 3 (2027-01-12).
- Specify gate metrics: digitization success = zero unrecoverable items in 1,000+ item batch; reconstruction accuracy = third-party sampling vs. originals; metadata accuracy = expert spot-check on OCR/speech-to-text; review flagging = actual percentage measured over 3+ months; uptime = trailing 6-month measurement; AI pre-screen = precision and recall >=75% per category-format.
- Publish gate-release charter: ≥3 consecutive months of all metrics met at ≥2 host sites required for Phase 2 release. Best-efforts override NOT accepted; conditional limited tranche only if ≥80% of targets (flagging ≤25%, all others >target). Escalate to governance if variance >10% or any metric <80%.
- Design stress-first pilot: send first unit (Month 6 = 2027-04-12) to worst-condition collection available; intentionally expose failure modes (extreme tape degradation, film shrinkage, difficult-to-read cards, multilingual content) to surface problems before clean-collection results set expectations and funder confidence.
- Establish pilot operating timeline: Months 6–20 (2027-04-12 to 2028-06-12) at ≥2 host sites with 3 consecutive months of gate evidence before Month 24 (2028-10-12) decision. Design freeze for Phase 2 by Month 20 (2028-06-12); long-lead procurement (4 months) before Phase 2 release.
- Specify Phase 2–3 gate (Month 60 = 2031-10-12) criteria: ≥500K items and ≥25 PB cumulative, 15 units at >90% uptime, Phase 1 thresholds sustained, ≥70% of Phase 3 funds committed, zero reportable incidents, spares >50% depletion threshold.
- Document escalation triggers: go/no-go re-assessment if cumulative variance >10%, any gate metric <80%, uptime <90%, or parts model shows infeasible depletion. Publish results and decisions transparently to all funders and archives.

**Approval Authorities:** Programme Board, all funders, independent verification auditors

### 10. Privacy Impact Assessment (PIA) and Jurisdiction-Specific Compliance Framework

**ID:** c63b4a5b-2939-46e8-8264-c6eeb1311b79

**Description:** Maps GDPR, UK Data Protection Act, and jurisdiction-specific privacy and data-transfer rules for all planned deployment countries. Conducts Data Protection Impact Assessment (DPIA per GDPR Article 35) on the full AI pre-screening + human-review + upload pipeline, identifying high-risk processing (automated PII detection, cross-border transfer, restricted-tier storage). Publishes Standardized Source-Agreement Template with jurisdiction-specific annexes (EU GDPR addendum, UK DPA addendum, US state-level addendum). Establishes Privacy Review Panel and decision-log maintenance. Develops tiered data-residency model: in-country hold, federated archive network, or offline deposit per jurisdiction. Intended audience: partner archives, legal counsel, data-protection authorities, Programme Board.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer, with input from data-protection specialists and international law counsel

**Primary Template:** Data Protection Impact Assessment (DPIA) template per GDPR Article 35

**Secondary Template:** Regulatory jurisdictional mapping matrix and source-agreement template library

**Steps:**

- Commission legal mapping (Month 1 = 2026-11-12): for each planned deployment country, identify applicable privacy law (GDPR, UK DPA 2018, national privacy statutes), data-transfer restrictions, personal-data definitions per jurisdiction, legal basis options (consent, public-task, vital-interest), and breach-notification timelines.
- Create Regulatory Jurisdictional Matrix: rows = countries, columns = applicable law, transfer restrictions, PII definitions, legal basis options, breach-notification rules. Publish by Month 2 (2026-12-12).
- Conduct DPIA on AI pre-screening + human-review + upload pipeline (Month 2 = 2026-12-12): identify processing steps (automated copyright/PII detection, human review flagging decisions, data storage, cross-border transfer); assess risks (false negatives permit unlawful processing, false positives delay upload); specify mitigation (retraining if precision <75%, Privacy Review Panel oversight, incident response protocol).
- Develop Standardized Source-Agreement Template (5–10 pages, Month 3 = 2027-01-12) covering: digitization scope, privacy commitment, storage location, access tier (public/restricted/embargoed), copyright status, legal basis for processing, data-subject rights (access, deletion, portability), incident-notification (24-hour to archive, 48-hour to regulator), incident response SLA (investigation within 72 hours).
- Create jurisdiction-specific annexes: EU GDPR addendum (Articles 6, 28, 35, 44–49), UK DPA 2018 addendum (lawful basis, standard contractual clauses), US state-level addendum (California Consumer Privacy Act CCPA if applicable).
- Establish Privacy Review Panel: recruit 2–3 rotating data-protection experts per region (Month 3 = 2027-01-12); schedule monthly panel meetings; maintain Privacy Decision Log documenting all flagged privacy decisions, reviewer notes, rationale, appeals.
- Design tiered data-residency model: Option A (in-country master hold for restricted PII); Option B (federated archive-held masters with non-sensitive derivatives only transferred centrally); Option C (offline deposit with archives, no cross-border transfer). Publish in Custody Plan (Month 6 = 2027-04-12).

**Approval Authorities:** Privacy, Rights and Legal Compliance Officer, data-protection authorities (where required), partner archives, Programme Board

### 11. Hazard Control Standard and Site Safety Compliance Framework

**ID:** a5a6603a-dccf-4c6d-8409-cd75f23c93f1

**Description:** Develops containerized hazard-control design addressing baking ovens (thermal release, fume emission, fire risk), humidity chambers (solvent vapors, chemical exposure), on-board media storage (fire load), and generators (fuel, combustion risk). Specifies sealed oven designs with thermostat accuracy ±2°C, smoke/fume detection and monitoring, filtered VOC (volatile organic compound) exhaust, fire suppression rated for archival materials (not water-based where possible), and thermal/chemical incident isolation. Obtains written approval from at least one pilot archive's fire authority and insurer by Month 6 (2027-04-12); uses approval letter as template for all sites. Develops fallback detached pre-treatment pod design (separate 20-ft container, 50+ meters from archive building) for sites where on-site approval cannot be obtained. Intended audience: host archives, fire authorities, insurers, programme engineers, Programme Board.

**Responsible Role Type:** Chief Engineer, with input from fire-safety consultant and insurance broker

**Primary Template:** Container retrofit and hazard-control design specification (engineering drawings, system diagrams)

**Secondary Template:** Fire-safety compliance and insurance approval template

**Steps:**

- Engage fire-safety consultant and specialized insurance broker (Month 1 = 2026-11-12) to conduct Hazard Analysis: model thermal release from baking cycles, VOC emissions from degraded tape binders, fire load from on-board media storage, diesel/natural-gas generator combustion risk. Estimate incident probability and financial exposure per hazard.
- Develop Sealed Oven Design Specification (Month 3 = 2027-01-12): internal thermostat ±2°C tolerance, sealed chamber with internal air circulation and carbon-activated filters for VOC removal, redundant thermostat cutoff at 65°C (above which tape binder volatilizes), smoke detector and 24/7 thermal monitoring, fire suppression system (dry-chemical or CO2, not water-based to avoid tape damage).
- Specify VOC monitoring: install TVOC (total VOC) sensor in bake enclosure; trigger alarm if TVOC >500 ppb; continuous logging and central dashboard alert.
- Design fire-suppression integration: containerized system rated for Class A (paper, media), B (fuel, oils), and C (electrical) fires; manual override capability; monthly inspection and certification.
- Retrofit first pilot unit with Hazard Control Standard (Month 5 = 2027-03-12); conduct engineering review and sign-off.
- Submit first pilot unit for written approval by one host archive's fire authority and insurer (Month 6 = 2027-04-12). Document approval letter and any required modifications.
- Use approved design as template for all subsequent sites. Develop fallback Detached Pre-Treatment Pod design (separate 20-ft container, ≥50 meters from archive building): same hazard controls but isolated from main digitization unit, reducing blast/fume radius. Budget USD 0.5–1.5M per pod and +4–6 weeks site setup if on-site approval is denied.
- Establish Incident Response Protocol (Month 4 = 2027-02-12): 4-hour internal incident reporting, 24-hour notification to host insurer, 48-hour forensic investigation, 5-business-day remediation plan. Test protocol quarterly with simulated breach scenarios.

**Approval Authorities:** Fire-authority officials (local, per site), insurance underwriters, host archives, Chief Engineer

### 12. Host-Site Power, Security, and Readiness Compact

**ID:** e2f56631-95dc-4802-9b00-1b349122104c

**Description:** Establishes baseline conditions host archives must supply (stable power ≥200kW, level hardstand ≥50m×15m, physical security/perimeter, trained liaison staff, fire-authority and insurer pre-approval). Develops Site Readiness Scorecard assessing each criterion (ready/not-ready/in-progress). Establishes pre-deployment readiness gates: unit dispatch only when all criteria are ready. Coordinates with each archive 6 months before scheduled arrival. Maintains Master Schedule and Queue Management System tracking all 30+ residency windows, readiness milestones, and buffer periods. Manages 2–3 weeks per-site contingency parking for schedule absorption. Intended audience: site-operations coordinators, host archives, infrastructure leads, Programme Board.

**Responsible Role Type:** Site Operations and Logistics Coordinator

**Primary Template:** Site readiness assessment and readiness scorecard template

**Secondary Template:** Master schedule and queue-management system specification (Gantt chart, critical-path analysis)

**Steps:**

- Develop Site Readiness Scorecard by Month 2 (2026-12-12) with mandatory criteria: (A) power (208–240V, ≥200kW stable supply or ≥400–500kW generator + fuel tank); (B) hardstand (level concrete pad, ≥50m×15m, load rating ≥100 psf); (C) security (perimeter fence or guard, access control, 24/7 surveillance); (D) fire-authority written approval of pre-treatment hazards; (E) insurer letter confirming on-site coverage; (F) staff liaison trained and available; (G) data connectivity (fiber or satellite, ≥10 Mbps upload). Score each criterion ready/not-ready/in-progress.
- Coordinate site readiness 6 months pre-arrival (Month 0 = 2026-10-12) with first pilot host (Month 6 = 2027-04-12) to be ready by Month 5 (2027-03-12). Conduct power audit (voltage stability, frequency, harmonic content, total available capacity). Assess hardstand and security. Obtain fire-authority and insurer pre-approval letters on schedule.
- Build Master Schedule and Queue Management System (Month 3 = 2027-01-12) tracking all 30+ planned archives, residency windows (6–12 months each), readiness milestones (power ready by Month X, fire-authority approval by Month Y, staff trained by Month Z), buffer periods (2–3 weeks per site for contingency absorption).
- Manage relocation logistics (Month 0 = 2026-10-12 onward): coordinate trucking (2–4 weeks per move), customs clearance (6-week documentation prep), on-site setup (power/data connection, 1 week), and site hand-off (staff training, intake process definition). Budget USD 5K–10K per day for trucking and contingency parking.
- Publish Site Readiness Dashboard monthly showing all 30+ archives' scorecard status; escalate any criterion not ready 6 months pre-arrival to archive director and propose remediation (e.g., pre-position generator if facility power is unstable).
- Maintain Priority Waitlist of 5–10 backup sites ready to receive unit on short notice (4–6 weeks) to absorb schedule slips from first-choice archives.

**Approval Authorities:** Site Operations Coordinator, Programme Director, host archive directors, Programme Board

### 13. Recovery Assurance and Independent Verification Regime

**ID:** c1c72eb9-f0c4-4fd8-9c4f-35fb660fdd11

**Description:** Defines how recovery claims (successful digitization, reconstruction accuracy, metadata accuracy) are measured and independently verified before Phase 2 and Phase 3 release. Contracts independent third-party auditors to sample recovered items at each pilot site, compare against originals, and publish findings per format and degradation level. Circulates shared reference set of 10–15 calibrated test media among all units; units digitize reference set quarterly; cross-unit variance in playback fidelity indicates systematic drift or equipment-specific bias (detected and remediated). Publishes monthly Verification Dashboard showing unit-by-unit performance (success rate, accuracy, inter-unit drift). Establishes sampling protocol: 2–5% of recovered content per site audited by independent expert against original. Intended audience: Programme Board, funders, partner archives, regulatory bodies.

**Responsible Role Type:** Chief Engineer and independent preservation auditors (external)

**Primary Template:** Quality assurance and independent audit protocol template

**Secondary Template:** Reference-media calibration and inter-unit comparison framework

**Steps:**

- Contract independent auditors (Month 3 = 2027-01-12) specializing in audiovisual preservation, film conservation, or data recovery; specify scope (sampling protocol, measurement standards, reporting frequency).
- Develop sampling protocol (Month 4 = 2027-02-12): every unit samples 2–5% of recovered content at each residency (stratified by format and degradation level) and ships comparison set to independent lab. Lab digitizes sample and compares against original on archival playback equipment (tape deck with azimuth measurement, film scanner with color reference, card reader with OCR validation). Publishes precision/recall results and any quality gaps.
- Establish Reference Media Calibration Set (Month 4 = 2027-02-12): procure 10–15 standard-condition tape reels, film cans, and card batches from known, stable sources (broadcast network archives, film stock suppliers). Baseline each reference item (azimuth, speed regulation, signal-to-noise, color accuracy). At each new unit deployment and quarterly thereafter, digitize reference set and compare against baseline. Publish reference-media fidelity dashboard showing all units' performance; if any unit drifts >5% from baseline, trigger re-calibration or equipment servicing.
- Publish monthly Verification Dashboard (Months 6–120 = 2027-04-12 to 2036-10-12) showing unit-by-unit success rate, reconstruction accuracy, metadata accuracy, inter-unit variance, and incident log. Make publicly available to funders and partner archives.
- Integrate third-party audit results into gate-release evidence: Phase 1–2 gate (Month 24 = 2028-10-12) requires independent audit of 3 pilot units with documented accuracy >80%, zero sampling disagreements on authenticity or condition, and zero incidents.
- Budget USD 1M–2M over 10 years for independent audits, reference-media procurement, and quarterly inter-unit calibration.

**Approval Authorities:** Independent auditors (external), Chief Engineer, Programme Board

### 14. Liability and Loss-Indemnity Structure (Tiered Indemnity, Pooled Reserve, Incident Response)

**ID:** 27fd0e26-e763-4df0-9f34-c5129725c2ed

**Description:** Specifies who bears cost when handling, baking, or playback destroys unique media. Develops Tiered Indemnity Structure: Full Coverage Tier (stable items, programme assumes full liability); Attempt-at-Own-Risk Tier (high-risk degraded items with documented waiver, archives assume risk); Deferred Tier (unsafe items, deferred pending specialist conservation). Establishes Pooled Loss Reserve (USD 2–5M from Phase 1 budget) for unique-item losses insurers decline to underwrite (e.g., irreplaceable cultural artifacts, disputed copyright claims). Develops standardized incident-response protocol: 4-hour internal escalation, 24-hour insurer notification, 48-hour forensic investigation, root-cause analysis within 1 week, 5-business-day claim filing. Creates condition-tiered consent rules: condition grade determines tier assignment before intake. Bundles indemnity into standardized source agreements. Intended audience: programme legal counsel, insurers, host archives, funders, Programme Board.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer, with input from insurance broker and legal counsel

**Primary Template:** Tiered liability and indemnity framework template (condition-based tier assignment, insurance policy terms)

**Secondary Template:** Incident-response and loss-claim procedures manual

**Steps:**

- Develop Tiered Indemnity Structure (Month 2 = 2026-12-12): Define Full Coverage Tier (stable items, condition grade 1–2, programme absorbs 100% liability up to USD 10K–100K per item depending on estimated value); Attempt-at-Own-Risk Tier (high-risk degraded items, condition grade 3–4, archive signs documented waiver assuming liability for damage during handling/baking/playback); Deferred Tier (unsafe items, condition grade 5, held in archive cold storage, never processed). Publish condition-grading rubric and tier-assignment protocol.
- Create Pooled Loss Reserve (Month 3 = 2027-01-12): allocate USD 2–5M from Phase 1 budget (USD 60M) as self-insurance pool for unique-item losses insurers decline (e.g., irreplaceable oral history, classified government records with disputed copyright, one-of-a-kind artifacts). Administer reserve via Finance Lead and Legal Counsel.
- Develop Incident Response Protocol (Month 4 = 2027-02-12): (A) Internal escalation: unit crew discovers damage, logs incident within 4 hours via secure portal to Central Operations; (B) Insurer notification: within 24 hours, notify host insurer and programme legal counsel; (C) Forensic investigation: within 48 hours, begin root-cause analysis (handling error? equipment failure? environmental? item condition?); (D) Remediation: within 1 week, document findings and remediation action (e.g., procedure change, equipment repair, staff retraining); (E) Claim filing: within 5 business days, file loss claim with insurer or draw from Pooled Reserve.
- Integrate tiered indemnity into Standardized Source-Agreement Template (Month 3 = 2027-01-12): explicitly state Full Coverage, Attempt-at-Own-Risk, and Deferred tier terms; specify which items fall into each tier based on condition assessment; include signed waiver for Attempt-at-Own-Risk tier items.
- Conduct pre-deployment incident-response drills (quarterly, Months 3–24 = 2027-01-12 to 2028-10-12): simulate media damage scenarios (tape head crash, film shrinkage damage, card reader jam); test 4-hour escalation, 24-hour insurer notification, and 48-hour investigation procedures. Document lessons learned.
- Establish Loss-Claim Administration: Finance Lead maintains Pooled Reserve account and claim-payment log; legal counsel reviews all claims for eligibility and coverage; Programme Board reviews losses >USD 100K quarterly.

**Approval Authorities:** Privacy, Rights and Legal Compliance Officer, insurance underwriters, host archives, Programme Board

### 15. Border-Crossing and Data-Jurisdiction Pathway (Customs, Temporary Admission, Data Transfer Rules)

**ID:** 419f602e-263e-47a8-b076-b3e98c715df7

**Description:** Maps legal and logistical routes for containerized units, vintage equipment, and recovered data to cross borders. Documents temporary-import regimes (carnets, ATA agreements, mutual-recognition schemes), customs inspection procedures for vintage equipment (e-waste classification avoidance), and hazmat/consumables transport rules. Pre-negotiates temporary-admission agreements with 3–5 key border authorities by Month 6 (2027-04-12). Establishes Customs and Trade Compliance Coordinator role to track container moves, submit documentation 6 weeks in advance, and monitor clearance. Determines data-residency pathways per jurisdiction: in-country hold, federated network replication, or offline deposit per legal restrictions. Manages inter-unit relocation logistics (USD 5–10K per day downtime cost). Intended audience: customs brokers, programme logistics, legal counsel, Programme Board.

**Responsible Role Type:** Site Operations and Logistics Coordinator, with input from customs and trade-compliance specialist

**Primary Template:** Customs and temporary-import documentation template (carnet, ATA agreement, heritage-export waiver)

**Secondary Template:** Data-residency legal compliance checklist per jurisdiction

**Steps:**

- Identify temporary-import pathways (Month 2 = 2026-12-12) for target regions: EU single customs area (no internal borders if domiciled in EU), US–Canada–Mexico USMCA (temporary-admission carnet system), UK post-Brexit (ATA carnet requirement), Australia (temporary importation license), Japan (carnet system). Consult with customs brokers for each region.
- Develop documentation package (Month 3 = 2027-01-12): detailed container contents list (equipment serial numbers, condition, estimated value, vintage equipment vs. consumables), temporary-import duration (6–12 months per residency), designated end-point (return to US, disposal in-country, or transfer to next archive). Classify vintage equipment as 'functional heritage conservation equipment' to avoid e-waste triggers; document with serial numbers and certification of operational status.
- Pre-negotiate temporary-admission agreements (Month 4–6 = 2027-02-12 to 2027-04-12) with customs authorities in 3–5 priority countries (US, UK, Netherlands/EU, Canada, Australia): request single multi-use carnet valid for 5-year duration covering all planned archive deployments. Anticipate 4–8 week approval cycles per jurisdiction.
- Establish Customs and Trade Compliance Coordinator role (Month 3 = 2027-01-12): responsible for submitting all border-crossing documentation 6 weeks in advance, tracking carnet status, coordinating with customs brokers, managing container hold-ups and delays. Maintain border-crossing log (transit dates, processing times, costs, incident notes).
- Map data-residency rules per planned host country (Month 3 = 2027-01-12) as part of Regulatory Jurisdictional Matrix: identify where recovered data may legally reside (in-country, EU-internal, third-country with adequate protections). Design federated data model: masters held by host archives per jurisdiction; cross-border derivatives or metadata transfers only with legal basis (standard contractual clauses, adequacy decisions). Document in Custody and Access Plan (Month 6 = 2027-04-12).
- Budget USD 1M–2M for legal and customs-compliance resources (lawyers, brokers, carnet fees) and USD 500K–1M annually for border-clearance contingencies (fuel, parking, expedited processing if unit is delayed).

**Approval Authorities:** Customs authorities (per jurisdiction), data-protection authorities (per jurisdiction), trade-compliance specialists, Programme Board

### 16. Triage Doctrine for At-Risk Collections (Site Selection and Queue Logic)

**ID:** 9dc91fcf-7e85-4411-9b1c-c700a299f4ea

**Description:** Sets the queue logic for every unit residency: which 30+ archives are selected, in what order, and how much of each collection is processed. Defines two triage strategies: condition-first (rank collections by measured physical degradation and format vulnerability, prioritize fastest-decaying media) vs. value-first (archives nominate by research, cultural, historical importance). Specifies condition-scoring rubric (azimuth drift, layer adhesion, film shrinkage, card fading; 1–5 scale). Establishes rapid condition-and-content survey procedure: lightweight team visits each site, samples holdings, and assigns condition/content scores; decides whether full digitization, selective digitization, or deferral is justified. Publishes triage methodology transparently to funders and archives. Manages tension between rescuing most-endangered media and maintaining partnerships with well-resourced archives that can co-fund. Intended audience: archivists, funders, triage committee, Programme Board.

**Responsible Role Type:** Site Operations and Logistics Coordinator, with input from archival appraisal specialists and preservation scientists

**Primary Template:** Collection condition-assessment and triage decision framework template

**Secondary Template:** Rapid survey protocol and condition-scoring rubric

**Steps:**

- Establish Triage Committee (Month 3 = 2027-01-12) with 5–7 members: Chief Engineer, archivist from partner archive, preservation scientist, Programme Director, and 1–2 funder representatives. Committee meets monthly to score candidate archives and prioritize queue.
- Develop Condition-Scoring Rubric (Month 2 = 2026-12-12): tape degradation (azimuth drift ±0.1mm, speed variation, layer adhesion failure, 1–5 scale); film degradation (vinegar-syndrome advanced, shrinkage >3%, color fade, 1–5 scale); card degradation (edge crumble, fading print, mold, 1–5 scale). Train survey team on consistent assessment.
- Conduct Rapid Survey at each candidate site (Month 0–6 = 2026-10-12 to 2027-04-12): lightweight team (2–3 archivists/engineers) visits, samples 50–100 items across the collection, measures condition scores, documents estimated at-risk timelines (when will condition become unplayable if not digitized?), estimates full-collection hours and cost. Recommend full digitization, selective digitization (high-risk items first), or deferral (insufficient degradation urgency, insufficient resources).
- Publish triage logic (Month 4 = 2027-02-12): condition-first ranking (fastest-decaying items first) or value-first ranking (high research/cultural value first) with explicit rationale. Present to Programme Board and funders; obtain consensus on which archives receive priority.
- Balance equity and urgency: condition-first approach rescues most endangered collections but may deprioritize well-resourced archives; value-first approach eases partnership but fragments queue. Recommend hybrid: schedule small %age (10–20%) of units to under-resourced, highest-risk archives; schedule remainder to balance collection value and resource capacity.
- Publish rolling 5-year residency schedule (Month 6 = 2027-04-12) with site assignments, residency windows (6–12 months each), expected digitization hours and item count per site. Update quarterly as new survey data arrives and collection conditions change.

**Approval Authorities:** Triage Committee, Programme Board, all funders, partner archives

### 17. Fleet Command and Remote Diagnostics Layer (Central Operations, Telemetry, Expert Routing)

**ID:** 88b419d9-1752-4b84-b59b-244d4186b3b9

**Description:** Defines the central nervous system for the geographically scattered fleet of 30 units: sensors, real-time dashboards, remote expert guidance, scheduling, and fallback behavior when connectivity fails. Specifies telemetry sensors per unit (power quality, climate, equipment error rates, on-board storage levels, uptime, parts consumption, media throughput, incident logs). Central operations room monitors all 30 units 24/7 via dashboards; alerts for >90% uptime violations, equipment failures, parts-depletion thresholds trigger automated escalation to specialists. Remote-guidance system routes field failures to appropriate expert (retired-engineer mentor for legacy deck, parts engineer for fabrication, AI specialist for signal issues); target response time 4 hours, resolution within 24 hours or escalation to Central Operations Manager. Fallback: each unit operates autonomous-first with local diagnostic playbooks and batched status reports if connectivity is lost (satellite links intermittent, fiber unreliable). Intended audience: Central Operations Manager, on-site unit crews, specialist engineers, Programme Board.

**Responsible Role Type:** Central Operations and Fleet Management Officer

**Primary Template:** Fleet-management and telemetry dashboard specification (equipment monitoring, remote-guidance system design)

**Secondary Template:** Failure escalation and expert-routing logic (decision tree, SLA targets)

**Steps:**

- Design telemetry architecture (Month 3 = 2027-01-12): specify sensors per unit (electrical: voltage, frequency, harmonic; climate: temperature ±0.5°C, relative humidity ±2%; equipment: error rates per deck, transport status, head wear, mechanical vibration; storage: on-board buffer fill %, archive upload status; uptime: downtime events and duration; parts: consumption by category, re-manufacture trigger events; media: throughput items/day, metadata accuracy, flagging %). Sensors send data to central cloud platform in real-time (satellite or fiber, minimum 10 Mbps uplink).
- Build Central Operations Dashboard (Month 4 = 2027-02-12): real-time map of all 30 units with color-coded health status (green >90% uptime, yellow 85–90%, red <85%); individual unit detail pages (power trends, climate swings, equipment error patterns); fleet-wide analytics (mean uptime, failure clustering, parts-depletion projection); incident log (all failures and near-misses, root-cause analysis status).
- Establish automated alerting (Month 5 = 2027-03-12): if any unit's uptime drops below 90% for 2 consecutive reporting periods (weekly), trigger red alert to Central Operations Manager and relevant specialist; if parts stock falls to 50% threshold, auto-order re-manufacture; if climate excursion >2°C for >2 hours, alert archive liaison and equipment owner.
- Design remote-guidance system (Month 3 = 2027-01-12): field crew logs equipment failure (type, symptom, troubleshooting attempted) via mobile app or secure web form with photos; system auto-routes to appropriate specialist (retired-engineer mentor for tape-deck azimuth, parts engineer for 3D-printed replacements, AI specialist for signal issues); specialist responds via phone/video guidance within 4 hours; if unresolved after 24 hours, escalate to Central Operations Manager. Integrate ticketing system (open-source Jira or similar) to track resolution.
- Specify autonomous-first fallback (Month 4 = 2027-02-12): if satellite/fiber link is down, unit crew operates using local diagnostic playbooks (printed flowcharts), makes maintenance decisions locally (e.g., swap a worn belt without remote guidance), logs events in local database. When link is restored, batched status report and logs upload to central system for asynchronous review and trend analysis.
- Staff Central Operations room (Month 6 = 2027-04-12) with 1–2 full-time FTE (Central Operations Manager + data analyst) managing dashboards, escalation routing, and failure pattern analysis. Budget for 24/7 on-call rotation (central team or regional partners covering time zones).

**Approval Authorities:** Central Operations and Fleet Management Officer, Chief Engineer, Programme Director, Programme Board

### 18. Fleet Sunset and Equipment Afterlife Design (Post-Month 120 = 2036-10-12 End-State Planning)

**ID:** fd513e5e-3ac7-4d14-89b9-d531630ef6fe

**Description:** Defines what happens to the 30-unit fleet, parts warehouse, and knowledge base after Month 120 (2036-10-12). Presents three options: (A) wind-down and unit transfer to national archives or universities with multi-decade stewardship commitments and maintenance funding; (B) retain a core of 5–10 units and central parts warehouse under a standing body with dedicated endowment, enabling ongoing recovery of newly identified collections; (C) convert retired fleet into a licensed equipment-rental pool operated by commercial transfer houses or research institutions, with rental income funding a long-tail recovery fund. Identifies successor organizations (national archives, university media labs, heritage non-profits), secures binding perpetual-stewardship and funding commitments by Month 48 (2030-10-12). Plans knowledge-base stewardship: digital commons (wiki, video library, technical documentation) accessible in perpetuity. Intended audience: Board members, partner archives, technology partners, funding consortia, Programme Board.

**Responsible Role Type:** Programme Director, with input from finance lead, legal counsel, and partner archives

**Primary Template:** Equipment disposition and perpetual-stewardship agreement template (endowment, transfer agreements)

**Secondary Template:** Knowledge-base governance and digital-commons charter

**Steps:**

- Establish End-State Working Group (Month 12 = 2027-10-12) with 6–8 members: Programme Director, legal counsel, funder representatives, partner archive directors, technology partner representatives. Task: define preferred end-state scenario by Month 36 (2029-10-12).
- Develop three end-state scenarios (Months 12–36 = 2027-10-12 to 2029-10-12): (A) Wind-Down: transfer ownership of 30 units to 15–20 national archives or universities (1–2 units each); hand over parts inventory and knowledge base to recipient institutions; execute multi-decade stewardship and maintenance-funding agreements (estimate USD 2–5M per archive for 20-year maintenance and storage). (B) Retained Core: mothball 20 units; retain 5–10 units under a new non-profit stewardship body; endow body with USD 10–20M to cover operations and parts maintenance through 2050; enable ongoing recovery of orphaned collections discovered after Month 120 (2036-10-12). (C) Rental Pool: donate retired fleet to commercial transfer-house or university consortium; establish license-fee sharing (10–20% of rental revenue) dedicated to a long-tail recovery fund; enable scholars and smaller institutions to rent units for short-term projects.
- Secure binding commitments from successor organizations (Months 24–48 = 2028-10-12 to 2030-10-12): if scenario A, negotiate transfer and stewardship agreements with 15–20 archives/universities, specifying maintenance obligations, parts-inventory transfer, and funding (estimated USD 2–5M per site for 20 years). If scenario B, establish a new non-profit stewardship body and secure endowment funding (USD 10–20M) by Month 48 (2030-10-12). If scenario C, identify commercial and research partners; establish license-fee distribution model.
- Plan knowledge-base perpetuation (Months 12–36 = 2027-10-12 to 2029-10-12): develop a Digital Knowledge Commons (wiki, GitHub repository, video archive, technical documentation) accessible in perpetuity; identify long-term host (Internet Archive, university library, national digital stewardship alliance); execute hosting and governance agreement; ensure knowledge base is available under open-access or public-domain license.
- By Month 90 (2034-04-12), transition all units to successor organizations (if wind-down) or complete handover to stewardship body (if retained core). Schedule post-programme continuation committee with archives, universities, and successors to oversee knowledge-base updates and long-tail recovery fund.

**Approval Authorities:** Programme Director, legal counsel, funder representatives, partner archives, Programme Board

### 19. Current State Assessment of 1950–2000 Magnetic Tape, Film, and Card Media Degradation (Baseline Risk and Urgency Analysis)

**ID:** 76e55ace-4cb5-4c6a-a7c0-eea4222c9081

**Description:** Baseline assessment documenting the current state and degradation status of 1950–2000 magnetic tape, film, and card media in target archives, estimating remaining useful lifespans (degradation timelines 10–30 years), and quantifying at-risk collections. Includes tape condition surveys (azimuth drift, layer adhesion failure rates), film condition assessments (vinegar syndrome, shrinkage, color fade), and card/disk degradation (edge crumble, fading print). Estimates that target collections face 10–30 year degradation clocks; if digitized at plan throughput, recovery targets become achievable; if digitization is deferred, cultural/scientific/government records are lost to deterioration. Provides factual foundation for programme urgency and gate-release decision-making. Intended audience: funders, partner archives, programme governance, public stakeholders.

**Responsible Role Type:** Media Preservation Specialist, with input from preservation scientists and archivists

**Primary Template:** Preservation assessment and condition-survey template (ISO 18938 for magnetic tape, ISO 18927 for cellulose-triacetate film)

**Secondary Template:** Degradation-timeline model and at-risk-collection quantification

**Steps:**

- Conduct condition surveys at 10–15 representative archives (Months 2–6 = 2026-12-12 to 2027-04-12): sample tape reels (50–100 per archive), film cans (30–50 per archive), and card batches (10–20 per archive) across 1950–2000 era. Measure tape azimuth offset, speed regulation drift, layer adhesion (ASTM D5026, humidity-accelerated aging), film vinegar smell (ISO 18938 rating), color fade (ΔE >10 on film stock), card-media fading and edge wear.
- Estimate degradation timelines per format and condition grade: tape (condition 1–2 = 15–30 years to unplayable; condition 3–4 = 3–10 years; condition 5 = <3 years). Film (condition 1–2 = 20–50 years to unwatchable; condition 3–4 = 5–15 years; condition 5 = <5 years). Card media (condition 1–2 = 10–30 years; condition 3–5 = 2–10 years).
- Quantify at-risk collections: estimate total hours of tape, film, and card media in target archives (surveys at 15 sites suggest 500,000–3,600,000 items across target scope). Calculate urgency: if 50% of items are at condition grade 3–4 (3–10 years to unplayable), and plan throughput is 15,600 items/unit-year (Phase 1–2) to 24,000 items/unit-year (Phase 3), then recovery of all at-risk media requires 10-year aggressive programme starting now (Month 0 = 2026-10-12). Deferral of 2–3 years results in permanent loss of 5–15% of at-risk items.
- Document baseline by Month 6 (2027-04-12); publish findings in Current State Assessment report to funders and partner archives; use urgency analysis to justify gate criteria and phased deployment strategy. Monitor degradation status at 3–5 benchmark sites annually (Months 12, 24, 36 = 2027-10-12, 2028-10-12, 2029-10-12, etc.) to update timelines and adjust triage priorities.

**Approval Authorities:** Media Preservation Specialist, preservation scientists, partner archives, Programme Board

### 20. Programme Board Charter and Decision-Authority Framework

**ID:** ce29d3ee-09b5-4c32-93af-c5b423e53938

**Description:** Establishes the Programme Board structure (8–10 members representing funders, partner archives, engineering, legal, and finance), meeting cadence (monthly with quarterly formal decisions), decision-rights matrix (which decisions require full consensus, which are delegated to staff, escalation paths), and communications protocol. Defines quorum, voting rules, and escalation triggers (go/no-go gates, budget variances >10%, risk events). Intended audience: all Board members, Programme Director, all funders.

**Responsible Role Type:** Programme Director

**Primary Template:** Governance charter and board operating procedures template

**Secondary Template:** Decision-authority matrix (RACI: Responsible, Accountable, Consulted, Informed)

**Steps:**

- Convene founding Board meeting (Month 1 = 2026-11-12) with 8–10 members: Programme Director (chair), finance lead, chief engineer, legal counsel, 3–4 funder representatives, 1–2 archive representatives.
- Draft charter specifying: meeting schedule (monthly operational, quarterly formal decisions), decision-authority matrix per decision type (gate releases, crew composition, site selection, budget reallocation, risk escalation), quorum rules (≥6 members for binding decision), voting rules (majority for routine, consensus for phases), communication protocols (secure channels, meeting notes).
- Publish decision-making criteria for all major levers (Funding and Ownership, Vintage Transport, Rights and Review Gate, Crew Composition, Pilot Gates, etc.) using RACI matrix or equivalent.
- Obtain written Board approval by Month 2 (2026-12-12).

**Approval Authorities:** All Programme Board members, all funders (binding adoption)

### 21. Quarterly Cost and Variance Tracking Report (Template and Execution Plan)

**ID:** 3e0670bd-ddf9-48c8-ae0d-232e82b87ed1

**Description:** Establishes standard quarterly reporting format (due Month 3, 6, 9, 12 = 2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12 and each quarter thereafter): actuals vs. budget per line item (labor, equipment, consumables, logistics, utilities), variance % per phase and cumulatively, projected outturn to Month 120 (2036-10-12), and escalation recommendations. Identifies variances >5% requiring explanation; >10% requiring governance decision. Intended audience: Finance Lead, Programme Board, all funders.

**Responsible Role Type:** Financial Analyst / Budget Director

**Primary Template:** Financial variance report template (budget, actual, variance %, YTD, forecast)

**Secondary Template:** Line-item cost-tracking dashboard (spreadsheet or BI tool)

**Steps:**

- Establish financial-tracking infrastructure (Month 2 = 2026-12-12): cost-accounting system with detail to line-item level (role-based labor, consumables by type, per-unit costs).
- Develop quarterly reporting template: cover Phase 1, Phase 2 (if active), Phase 3 (if active); report actuals, budget, variance % for each major cost category; calculate new projected outturn to Month 120 (2036-10-12); flag any variance >5% for explanation, >10% for governance escalation.
- Publish first report by Month 3 (2027-01-12); continue quarterly thereafter.
- Integrate inflation sensitivities: show impact of actual vs. planned wage escalation, equipment-price changes, commodity-cost changes (fuel, electricity).

**Approval Authorities:** Finance Lead, Programme Director, Programme Board (quarterly review)

### 22. Master Schedule and Queue Management System Specification and Initial Population

**ID:** 9cacdeeb-94cc-4bd5-adcf-2aa3a60c609c

**Description:** Technical specification and initial data-load for the Master Schedule system: all 30+ planned archive residencies, residency windows (6–12 months each), readiness milestones, buffer periods, critical-path analysis, and resource constraints (unit availability, crew deployment). Specifies system features: Gantt view, critical-path highlighting, readiness-scorecard integration, contingency-parking allocation. Intended audience: Site Operations Coordinator, Programme Board.

**Responsible Role Type:** Site Operations and Logistics Coordinator

**Primary Template:** Project scheduling software specification (Gantt, critical-path, resource-allocation tools; e.g., Microsoft Project, Smartsheet, open-source GanttProject)

**Secondary Template:** Initial schedule database (30+ archive entries, readiness criteria, residency windows)

**Steps:**

- Select scheduling software (Month 2 = 2026-12-12): evaluate Microsoft Project, Smartsheet, Monday.com, open-source GanttProject; select tool that supports Gantt, critical-path analysis, and readiness-status tracking.
- Define data model (Month 3 = 2027-01-12): archive name, location, proposed residency dates, readiness-scorecard fields (power, hardstand, security, fire approval, liaison), estimated digitization hours, estimated item count, contingency buffer.
- Populate initial schedule (Month 4 = 2027-02-12) with 30+ planned archives; insert readiness milestones (power audit Month X, fire-authority approval Month Y, staff training Month Z); flag critical-path items (those that delay Phase 2 or Phase 3 if slipped).
- Establish automatic alerts: any residency >4 weeks pre-arrival must have all readiness criteria marked 'ready'; any criterion still 'in-progress' triggers escalation to Site Operations Coordinator.
- Publish schedule monthly to Programme Board and archives.

**Approval Authorities:** Site Operations Coordinator, Programme Director, Programme Board

### 23. Source Agreement Template Library (Per-Jurisdiction Versions with Tiered-Indemnity Clauses)

**ID:** 7ca0ba37-0428-46f3-b28d-92f3f4efb168

**Description:** Complete library of standardized source-agreement templates customized per jurisdiction (US, UK, EU, Canada, Australia, Japan, etc.), each including: digitization scope, privacy commitment, storage location, access-tier (public/restricted/embargoed), copyright status, legal basis (GDPR Article 6 or equivalent), data-subject rights, breach-notification timelines, tiered-indemnity clauses (Full Coverage, Attempt-at-Own-Risk, Deferred), incident-response obligations, and retention periods. Serves as the master legal document that every host archive signs before a unit arrives. Intended audience: legal counsel, host archives, partner archives, Programme Board.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer

**Primary Template:** Source agreement and legal contract template (5–10 pages per version)

**Secondary Template:** Jurisdiction-specific privacy and indemnity addenda (GDPR annex, UK DPA annex, US state-level annex, etc.)

**Steps:**

- Draft standardized Source Agreement Template (Month 2–3 = 2026-12-12 to 2027-01-12) covering all essential terms: scope, privacy, storage, access, copyright, legal basis, rights, breaches, indemnity, incident response, termination.
- Create jurisdiction-specific annexes (Month 3 = 2027-01-12) for each target country: US template, UK template, EU (GDPR) template, Canada, Australia, Japan. Specify legal basis options per jurisdiction (consent vs. public-task exemption), data-residency requirements, breach-notification rules, applicable law and dispute resolution.
- Integrate tiered-indemnity language per tier (Full Coverage Tier: 'Programme assumes full liability'; Attempt-at-Own-Risk Tier: 'Archive assumes liability via signed waiver'; Deferred Tier: 'Item held in archive cold storage').
- Publish library by Month 4 (2027-02-12); update as needed if legal changes occur (EU Copyright Directive amendments, UK Data Protection Bill updates, etc.).

**Approval Authorities:** Privacy, Rights and Legal Compliance Officer, programme legal counsel, partner archives (must sign agreement before unit arrival)

### 24. AI Model Card and Data Documentation (Model Provenance, Training Data, Limitations, Fairness Assessment)

**ID:** 03f7e92a-db6f-42c2-91e5-44e075cd47ec

**Description:** Formal documentation (machine-learning model card) specifying: AI model versions used (pre-screening, signal reconstruction, metadata extraction), training data provenance and composition (what content the models were trained on, data source, any biases), model accuracy metrics (precision, recall, F1-score per category-format-degradation), known limitations (areas where the model performs poorly), and fairness assessment (does the model have differential accuracy across languages, content types, or demographic groups?). Ensures transparency and accountability for AI decisions and provides basis for model-retraining triggers if performance drops. Intended audience: AI team, review team, privacy panel, Programme Board, researchers.

**Responsible Role Type:** AI Signal Processing and Metadata Engineering Lead

**Primary Template:** Machine-learning model card template (Mitchell et al., 2018 or equivalent)

**Secondary Template:** Data documentation and transparency report

**Steps:**

- Develop initial model card (Month 4 = 2027-02-12) after validation on gold-standard labeled dataset: document model version, training data source, training objectives, accuracy metrics per category-format-degradation, known limitations (e.g., 'precision on handwritten text <70%'), fairness assessment (accuracy variance across languages).
- Update model card quarterly (Months 6, 9, 12, 15 = 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, etc. = 2027-04-12 onward) as models are retrained and accuracy changes.
- Publish model card openly to funders, archives, and preservation community to ensure transparency about how AI flagging decisions are made.
- Use model card as basis for retraining triggers: if any metric drops below acceptable threshold (precision <75%, recall <75%), document in model card and initiate retraining cycle.

**Approval Authorities:** AI Signal Processing Lead, Privacy Review Panel (oversight), Programme Board

### 25. Incident Tracking and Root-Cause Analysis System (Specification and Setup)

**ID:** 0af2702a-5581-4635-8e67-3dce5339025e

**Description:** Technical specification and initial setup for a centralized incident-logging system (web portal or mobile app) where unit crews report failures (equipment, handling, environmental, safety) within 4 hours. System tracks: incident date/time, equipment ID, symptom, troubleshooting attempted, outcome, cost impact, root-cause analysis, remediation. Central Operations Manager aggregates data, detects patterns (e.g., 'all tape decks in North American region show azimuth drift in Months 8–10 = 2027-06-12 to 2027-08-12'), and escalates systematic issues to engineering for investigation. Quarterly incident reports to Programme Board. Intended audience: unit crews, Central Operations Manager, Chief Engineer, Programme Board.

**Responsible Role Type:** Central Operations and Fleet Management Officer, with input from software engineer

**Primary Template:** Incident management system specification (web portal, mobile app, database schema)

**Secondary Template:** Incident-reporting template and escalation logic

**Steps:**

- Select incident-tracking tool (Month 3 = 2027-01-12): evaluate open-source options (Jira, Matomo, custom-built), or build custom web form + database if tools are insufficient.
- Define incident-data schema (Month 3 = 2027-01-12): incident ID, date/time, unit ID, equipment type, symptom classification (e.g., 'electrical', 'mechanical', 'thermal', 'software'), troubleshooting steps taken, outcome (resolved/unresolved/escalated), estimated cost impact, root-cause code (e.g., 'design defect', 'wear', 'environmental', 'human error'), remediation action.
- Develop incident-reporting template: 4-hour reporting window from crew to Central Operations portal; required fields (incident ID, unit, symptom, steps taken); optional fields (photos, video, detailed notes).
- Configure automated alerting: if same failure signature appears >1 time in a week fleet-wide, auto-notify Chief Engineer; if any failure impacts uptime >2% for a unit, alert Programme Director.
- Deploy system by Month 6 (2027-04-12); begin incident collection with first pilot operations (Month 6 = 2027-04-12).
- Publish quarterly Incident Report to Programme Board: summary of failures by type, trend analysis, systematic issues, remediation status.

**Approval Authorities:** Central Operations Manager, Chief Engineer, Programme Director, Programme Board

### 26. Restoration Intervention Ceiling and Reversibility Policy (Raw Capture vs. AI-Enhanced Output)

**ID:** 8f3aa259-01f8-48df-bfdf-972ebe4cc09d

**Description:** Draws the line between faithful capture and AI-enhanced output, specifying what is written to preservation masters and how reversible it stays. Defines preservation master as raw wideband capture or uncompressed transfer (retains all original signal, allows re-processing with future models); specifies AI-restoration layers as versioned derivatives with complete model provenance (model version, parameters, date, confidence scores). Addresses the storage-cost trade-off: keeping raw wideband inflates storage (estimated 10–50x multiplier per item) but preserves re-processability; discarding raw and storing only restored output saves storage but loses re-derivation capability if future models improve. Intended audience: archivists, AI team, preservation community, Programme Board.

**Responsible Role Type:** AI Signal Processing and Metadata Engineering Lead, with input from preservation scientists

**Primary Template:** Preservation format and restoration-versioning policy template

**Secondary Template:** Model-provenance and metadata documentation standard

**Steps:**

- Establish preservation-format policy (Month 4 = 2027-02-12): specify preservation master as either (A) raw wideband head signal (tape) or uncompressed scan (film) with complete metadata, or (B) lossless codec (FLAC, TIFF-LZW) with documented signal chain and error metrics.
- Define AI-restoration versioning: each AI processing step creates a versioned derivative output; retain all versions with complete provenance (model ID, version, parameters, processing date, confidence score per segment). Allow future researchers or archivists to compare versions and re-derive using new models.
- Quantify storage multiplier: estimate per-item storage for raw capture (e.g., 10 GB per hour of tape) vs. compressed preservation master (e.g., 500 MB per hour) vs. full-version history (10 GB original + 5 × 500 MB restoration layers = ~12.5 GB total). Model storage cost over 20 years at USD 3–5M per PB.
- Publish Restoration Intervention Ceiling as a binding policy: specifies that raw captures are retained per this cost model; AI restoration is treated as versioned, reversible derivative; archivists and future researchers can always access raw signal to re-process with improved models.
- Integrate into Custody and Access Regime (Month 6 = 2027-04-12): confirm that preservation masters (raw or lossless) are stored; restoration derivatives are generated on-demand or cached for performance; full version history is available to researchers.

**Approval Authorities:** AI Signal Processing Lead, preservation scientists, Programme Board

### 27. Data-Residency Registry and Federated Custody Mapping

**ID:** a7c6e340-352d-461a-92a5-bdaef08cd540

**Description:** Database documenting every recovered collection: originating archive, collection title, content type (Tape/Film/Card), sensitive data markers (restricted PII, classified documents, disputed copyright, medical records), jurisdiction of origin, applicable data-residency legal requirements, designated primary steward archive (where masters are held), designated backup archive location (federated replication), and storage format. Used to enforce data-residency compliance and to track custody of 200+ PB across multiple archives and jurisdictions. Ensures no restricted personal data crosses jurisdictional boundaries without legal basis; ensures all masters have verified secondary copies in geographically separate locations. Intended audience: legal counsel, data-governance office, partner archives, Programme Board.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer, with input from archivists and IT infrastructure specialists

**Primary Template:** Data residency and custody tracking database (spreadsheet or database schema)

**Secondary Template:** Jurisdiction-specific legal compliance checklist per collection

**Steps:**

- Design Data-Residency Registry schema (Month 3 = 2027-01-12): collection ID, originating archive, content type, sensitive-data markers (yes/no, type), jurisdiction of origin, data-residency legal requirement (in-country hold / EU-internal / third-country with SCC / no restriction), primary steward archive name and location, backup archive name and location, storage format (FLAC/TIFF/PDF), replication status (verified copy count).
- Populate registry as residencies begin (Month 6 onward = 2027-04-12 onward): for each archive, intake assessment assigns sensitive-data markers and residency requirement; registry entry documents designation of steward and backup locations before any data leaves the unit.
- Enforce data-residency compliance: any cross-border data transfer (e.g., uploading derivative metadata or access copy to central archive) only occurs if: (A) data has no sensitive markers, or (B) legal basis exists (SCC, adequacy decision, explicit archive consent), or (C) transfer is to designated backup within same jurisdiction.
- Publish registry quarterly to Programme Board; flag any collection with unresolved residency requirement or missing backup designation as a governance issue requiring escalation.

**Approval Authorities:** Privacy, Rights and Legal Compliance Officer, partner archives, Programme Board

### 28. Design Review Gate (DRG) Process and Change-Control Procedure

**ID:** 8c39c5e1-a951-4c6b-b082-3d9e8b3df629

**Description:** Formal change-control process for any material modification to the containerized MIU design (cooling system, robotic-arm specifications, power system, software components, control logic). Every change is reviewed by independent panel (2–3 subject-matter experts from mentor pool and engineering team); approved, rejected, or requested for testing before being locked into Phase 2 procurement. Design freeze for Phase 2 occurs by Month 20 (2028-06-12); any changes identified after freeze are documented as 'Phase 2.1' and incorporated only in Phase 3. Changes pre-freeze are incorporated into Phase 2 and subsequent units. Prevents cascading rework across the fleet. Intended audience: Chief Engineer, design team, external review panel, Programme Board.

**Responsible Role Type:** Chief Engineer

**Primary Template:** Design review gate and change-control procedure template (engineering change request form, approval workflow)

**Secondary Template:** Technical specification document for each major subsystem (container, climate control, power, robotics, software)

**Steps:**

- Establish DRG process (Month 4 = 2027-02-12): any proposed change requires Engineering Change Request (ECR) form specifying: component, current design, proposed change, technical rationale, testing plan, risk assessment, impact on Phase 2 procurement.
- Convene DRG review panel (Month 4 = 2027-02-12): Chief Engineer + 2–3 external subject-matter experts (retired-engineer mentor, preservation scientist, IT specialist). Panel meets monthly (or as needed) to review pending ECRs.
- Establish decision criteria: changes must be tested on reference equipment or in simulation before approval; impact on cost, schedule, or performance must be quantified; low-risk changes (e.g., filter upgrade, software patch) can be approved; medium/high-risk changes (e.g., new robotic system, thermal redesign) require testing and re-approval before replication.
- Lock design for Phase 2 by Month 20 (2028-06-12): all changes approved by this date are incorporated into Phase 2 procurement; changes identified after Month 20 (2028-06-12) are documented for Phase 2.1 (future retrofit) or Phase 3 incorporation only.
- Publish monthly Design Change Log showing all approved and rejected changes; report to Programme Board quarterly.

**Approval Authorities:** Chief Engineer and external DRG review panel (independent experts)

## Documents to Find

### 1. Existing National and Regional Archive Media Collections Inventories and Condition Surveys

**ID:** 2472bc64-34c4-42af-a792-0f938c4781db

**Description:** Detailed holdings lists, condition assessments, and preservation-risk evaluations from target archives (Library of Congress Packard Campus, British Library, Nederlandse Instituut voor Beeld en Geluid, selected Australian and Asian archives). Specifies format breakdown (tape hours, film reels, card/disk counts), condition grades (azimuth drift, layer adhesion, shrinkage, color fade), and estimated playable lifespan (degradation timelines). Essential for triage doctrine, queue prioritization, and baseline risk assessment.

**Recency Requirement:** Current or within 2 years of project start; archive surveys may be 3–5 years old if degradation rate is modeled and updated annually.

**Responsible Role Type:** Site Operations and Logistics Coordinator, with input from archivists and preservation scientists

**Access Difficulty:** Medium. Archive condition surveys are often internal documents; direct contact with archive heads/preservation officers and written data-sharing agreements (with confidentiality) are required. Published government preservation assessments are open-access. ISO/ASTM standards are published and available through standards bodies.

**Steps:**

- Contact the Library of Congress Packard Campus (Culpeper, VA), British Library Sound and Vision Collection, BFI National Archive (London), and the Netherlands Institute for Sound and Vision (Hilversum) directly to request: recent condition surveys, holdings inventories, media format breakdowns, and degradation-risk assessments.
- Search government heritage organizations' published preservation assessments (e.g., U.S. National Digital Stewardship Alliance reports, UK National Archives Preservation Strategy documents).
- Consult published literature on magnetic-tape degradation rates (ISO 18938, ASTM standards) and apply to estimated holdings to model degradation timelines.
- Conduct rapid on-site surveys at 10–15 proposed pilot and partner archives (Months 2–6 = 2026-12-12 to 2027-04-12) using standardized condition-scoring rubric.

### 2. Existing Tape, Film, and Card Media Equipment Specifications and Repair Documentation (Ampex, Studer, Otari, Rank, Oxberry Technical Manuals and Service Bulletins)

**ID:** b2c976ea-cdee-4d6e-b465-77d1b2ff9e2c

**Description:** Original manufacturer technical manuals, schematic diagrams, and service bulletins for tape decks (Ampex VRX, Studer A80, Otari MTR), film scanners (Rank Cintel, Oxberry), and card readers from 1950–2000 era. Documents azimuth-alignment procedures, head-calibration techniques, parts specifications (capstan sleeves, pinch rollers, azimuth fixtures), tolerance ranges (±0.05mm for azimuth), and mean-time-between-failures (MTBF) for typical components. Essential for vintage-equipment sustainment, parts-depletion modeling, and 3D-printing fabrication validation.

**Recency Requirement:** Original documentation preferred (manufacturer-issued technical manuals, 1960s–1990s publication dates are authentic sources); later digitized versions acceptable.

**Responsible Role Type:** Vintage Equipment Sustainment Engineer / Parts Manager

**Access Difficulty:** Medium. Original manufacturer manuals are out-of-print and scattered; retired engineers and specialized vendors are primary sources. Digitized versions exist but are not comprehensively cataloged. Requires direct networking with preservation community and equipment specialists.

**Steps:**

- Contact retired broadcast and film engineers (identified through professional networks of NPR, PBS, BBC, ARD, RAI, NHK); many retain personal copies of technical manuals and service bulletins.
- Search archives of the Society of Motion Picture and Television Engineers (SMPTE), Audio Engineering Society (AES), and the International Association of Sound and Audiovisual Archives (IASA) for digitized manuals and technical documents.
- Query specialist audiovisual restoration vendors (Memnon, Cube Tapes, Spectra, Arvato) who maintain technical libraries for legacy equipment repair.
- Browse eBay, specialist auction sites (Christie's South Kensington), and equipment salvage yards for physical copies of manuals accompanying used machines.
- Contact broadcast-equipment museums and universities (Indiana University MDPI, Library of Congress Packard Campus, BBC Archive Centre) for reference copies or digitized technical documentation.

### 3. GDPR, UK Data Protection Act 2018, and Jurisdiction-Specific Privacy Laws (Full Text, Official Transposition Documents, Regulatory Guidance)

**ID:** b118d942-a5b3-4103-94e7-66f453000535

**Description:** Complete text of EU General Data Protection Regulation (GDPR), UK Data Protection Act 2018, Canadian Personal Information Protection and Electronic Documents Act (PIPEDA), Australian Privacy Act, and any other applicable privacy and data-residency laws in planned deployment jurisdictions. Includes regulatory guidance documents from Data Protection Authorities (UK ICO, EU EDPB), case law on data-transfer restrictions, and standard contractual clauses (SCCs) for international transfers. Essential for legal compliance framework, source-agreement drafting, and privacy-impact assessment.

**Recency Requirement:** Current as of Month 0 (2026-10-12); GDPR text is stable (no material amendments expected before Month 120 = 2036-10-12); UK DPA 2018 subject to amendment by Data Protection Bill or successor legislation (update required if major changes occur).

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer

**Access Difficulty:** Easy. All referenced laws are publicly available on government and regulatory websites. Regulatory guidance (ICO, EDPB) is also public. No specialized access required.

**Steps:**

- Access GDPR full text via the European Commission official website (commission.europa.eu).
- Download UK Data Protection Act 2018 and amendments from the UK legislation.gov.uk website.
- Consult UK Information Commissioner's Office (ICO) website for regulatory guidance on GDPR, data transfer, and archival collections.
- Consult European Data Protection Board (EDPB) opinions and guidelines on data transfers and archival processing.
- For other jurisdictions (Canada, Australia, Japan, US states), access laws via respective government legislative websites.

### 4. Customs Temporary-Import Regimes and Documentation (ATA Carnet, Mutual Recognition Agreements, Heritage-Equipment Exemptions)

**ID:** f603ce49-0a13-4311-b483-da367b68e5cb

**Description:** Specifications for temporary-import carnets, ATA (Admission Temporaire) carnet systems, EU temporary-admission directives, USMCA temporary-import rules, and any heritage-equipment or conservation-equipment exemptions in target jurisdictions (US, UK, EU, Canada, Australia, Japan). Documents required for containerized equipment to cross borders without permanent importation duties or e-waste classification. Essential for logistics planning, border-clearance documentation, and cost estimates for unit relocation.

**Recency Requirement:** Current trade agreements and carnet rules as of Month 0 (2026-10-12); subject to trade-policy change (note any pending agreements or post-Brexit UK-EU custom rules updates).

**Responsible Role Type:** Site Operations and Logistics Coordinator, with input from customs and trade-compliance specialist

**Access Difficulty:** Medium. Government customs websites provide official procedures; mutual-recognition agreements and heritage-equipment exemptions are specialized and may require consultation with customs brokers or trade lawyers in target jurisdictions.

**Steps:**

- Contact US Customs and Border Protection (CBP) for ATA carnet and temporary-import procedures.
- Contact UK Customs (after Brexit, HMRC—Her Majesty's Revenue and Customs) for UK carnet and heritage-equipment exemptions.
- Contact European Commission (DG TAXUD) for EU temporary-admission directives and mutual-recognition agreements.
- Contact Canadian Border Services Agency (CBSA) for USMCA temporary-import procedures.
- Contact Australian Department of Home Affairs and Australian Customs and Border Force for heritage-equipment and conservation exemptions.
- Consult with specialized customs brokers operating in target jurisdictions for up-to-date carnet procedures and exemption applications.

### 5. Indiana University Media Digitization and Preservation Initiative (MDPI) Final Reports, Cost Accounting, and Vendor Contracts (Memnon, Equipment Sustainment Outcomes)

**ID:** 000c4793-22e5-4395-adb1-aa76290948dc

**Description:** Published and internal reports from Indiana University's large-scale audiovisual digitization project (280,000+ items digitized between ~2008–2020): final-cost accounting per unit, staffing models, vendor-contract terms (Memnon pricing, service levels, equipment sustainment), quality-control procedures, equipment failure analysis, and lessons learned. Provides a proven analogue for parts-depletion modeling, QC at scale, vendor-partnership structures, and per-item cost benchmarking. Most relevant for vintage-tape sustainment strategy and vendor-operated vs. owned-equipment decision.

**Recency Requirement:** MDPI project documents from 2008–2020 (closed project); published final reports or data available by 2021–2026.

**Responsible Role Type:** Chief Engineer, with input from financial analyst and archive partnership manager

**Access Difficulty:** Medium. Indiana University MDPI final reports may be published or available via direct institutional contact. Memnon case studies may be proprietary (request non-disclosure agreement). Published conference papers and journal articles are typically open-access or available via university subscriptions.

**Steps:**

- Contact Indiana University Libraries (Media Preservation Initiatives office) directly via university website; request publicly available final reports, cost accounting, and lessons-learned documents.
- Search Indiana University repository (digital.library.iu.edu or equivalent) for MDPI publications and technical reports.
- Search conference proceedings (American Archive Association, AMIA, IASA) for MDPI presentations and case studies (2015–2022).
- Contact Memnon (Brussels, Belgium) directly for case studies and cost-structure information on archive-scale digitization projects.
- Consult published literature on tape digitization and equipment sustainment: IASA Technical Review, Journal of the Association of Canadian Archivists, peer-reviewed preservation journals.

### 6. British Library Unlocking Our Sound Heritage (UOSH) Program Documentation (2017–2023): Hub Model, Rights-Handling Workflows, Training Curricula, Cost Structures

**ID:** d61dc392-017b-482c-8684-262f1e0b9a1f

**Description:** Detailed documentation from the UK National Lottery Heritage Fund-supported multi-site digitization network (2017–2023): hub organizational structure, rights-assessment and privacy-handling workflows, staff training curricula for archivists and technicians, per-item cost accounting, consortium governance model, lessons learned on scaling across 10 regional hubs, and quality-consistency mechanisms. Most relevant for governance structures, review-gate design, distributed crew models, and partnership sustainability. Shows evidence of how multi-site, consortium-based preservation networks manage review bottlenecks and maintain quality at scale.

**Recency Requirement:** UOSH program documents from 2017–2023 (active and recently closed); final reports and published case studies available by 2023–2025.

**Responsible Role Type:** Archive Partnership Manager and Privacy, Rights, and Legal Compliance Officer

**Access Difficulty:** Medium. National Lottery Heritage Fund reports are published; British Library may require direct institutional contact for detailed internal documentation. Regional hub reports vary in accessibility; some may be published publicly, others held locally.

**Steps:**

- Contact the British Library Sound and Vision team via the library's collaboration enquiries portal; request UOSH documentation and lessons-learned reports.
- Search the National Lottery Heritage Fund website (heritagefund.org.uk) for UOSH project reports, impact assessments, and final evaluations.
- Search British Library repository and publication databases for UOSH case studies and technical reports.
- Contact individual UOSH regional hubs (listed on project website) for local documentation and staff interviews.
- Consult published conference presentations (Archives and Records Association, IASA) featuring UOSH staff describing hub model and governance challenges (2017–2023).

### 7. Library of Congress National Audio-Visual Conservation Center (Packard Campus) Technical and Operational Documentation (2007–2026): Equipment Maintenance Protocols, Vintage Deck Sustainment, Hazard Controls, In-House Engineering Lab Design

**ID:** 66ae9120-4707-46f2-8f08-0ede8126204e

**Description:** Technical and operational documentation from the Library of Congress's Packard Campus (Culpeper, VA), a 19-year-old conservation center housing audiovisual digitization and equipment-maintenance infrastructure: specifications for in-house equipment repairs and maintenance, vintage tape and film playback-equipment calibration procedures, baking protocols for acetate film, head-cleaning and azimuth-alignment standards, hazard-control design (fire containment for archival materials, nitrate film vaults), and workforce training programs. Shows evidence of sustained in-house vintage-equipment maintenance and the engineering competencies required. Most relevant for vintage-transport sustainment strategy, fire-safety compliance, and on-site engineering team design.

**Recency Requirement:** Packard Campus documentation from 2007–2026 (ongoing operations); current technical specifications and protocols as of Month 0 (2026-10-12).

**Responsible Role Type:** Chief Engineer, with input from fire-safety consultant and preservation scientist

**Access Difficulty:** Medium to Hard. Packard Campus is a working government facility; some technical documentation is available publicly, other operational protocols may require authorized on-site access. Direct institutional relationship and request through formal channels (Library of Congress Partnerships or Research office) recommended.

**Steps:**

- Contact Library of Congress Recorded Sound Section or Moving Image Section (preservation.loc.gov) to request Packard Campus technical documentation and operational guides.
- Request an on-site visit or technical exchange with Packard Campus engineering staff (Head of Conservation Lab or equivalent) to observe equipment maintenance and hazard-control design.
- Search Library of Congress website and publications for Packard Campus architectural and engineering specifications.
- Consult published case studies on Packard Campus (Archives Magazine, ALA Publications, IASA Technical Review) describing facility design and conservation practices.
- Request access to Library of Congress Packard Campus public tours or open-access facility documentation via the institution's website.

### 8. Standard Contractual Clauses (SCCs) and International Data-Transfer Legal Frameworks (EU–US Data Privacy Framework, UK Adequacy Decisions, Standard Contractual Clause Recommended Language)

**ID:** 96b6b68e-b996-4928-83b9-15d6dc8b8c7b

**Description:** Complete text of EU Standard Contractual Clauses (Module One: Controller-to-Processor; Module Two: Processor-to-Processor; Module Three: Processor-to-Controller; Module Four: Controller-to-Third Country; EU–US Data Privacy Framework adequacy decision documentation; UK International Data Transfer Agreement (IDTA) templates; and guidance from data-protection authorities on lawful cross-border data transfer in archival contexts. Essential for drafting legally compliant data-transfer addenda to source agreements and ensuring compliance with GDPR and UK DPA when recovering data in one jurisdiction and transferring to archives or storage in another.

**Recency Requirement:** Current as of Month 0 (2026-10-12); SCCs and adequacy decisions are updated periodically by EU and UK authorities; use most recent versions available (2023–2026).

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer, with input from international data-protection counsel

**Access Difficulty:** Easy. EU and UK regulatory documents are publicly available on official government and regulatory websites. Published guidance and law-firm resources are also widely available. No specialized access required.

**Steps:**

- Access EU Standard Contractual Clauses (latest versions) via the European Commission official website (ec.europa.eu/info/law/law-topic/data-protection).
- Access UK Data Adequacy Decisions and IDTA template via UK Information Commissioner's Office (ICO) website (ico.org.uk).
- Consult EDPB Guidance on Data Transfers and use of SCCs (published opinions and recommendations, 2023–2026).
- Access EU–US Data Privacy Framework adequacy decision and renewal status via the European Commission.
- Consult published guidance from law firms and data-protection consultancies on SCCs and archival data transfers (e.g., articles in Privacy Laws & Business, International Data Protection Reports).

### 9. Cost-of-Living and Wage-Index Data (US, UK, EU, Australia, Japan) for 2026–2036 Regional Salary Modeling

**ID:** 6df34c81-1e6d-4316-9445-e89adec68f11

**Description:** Regional salary data for skilled technical and professional roles (broadcast engineers, archivists, software engineers, data analysts, compliance specialists) across planned deployment regions (Northern Virginia, UK, Netherlands/EU, Los Angeles, Australia, Japan). Includes historical wage escalation rates (2016–2026) to project 2026–2036 salary inflation. Essential for opex modeling per unit and per region, cost-audit reconciliation, and budget escalation sensitivities.

**Recency Requirement:** Most recent available (2024–2026 actual data preferred); historical data 2016–2025 for escalation-rate modeling; forecasts to 2036 acceptable if based on published economic models.

**Responsible Role Type:** Financial Analyst

**Access Difficulty:** Easy. Government statistical agencies (BLS, ONS, Eurostat, ABS) publish wage data freely online. Private salary surveys are also public and require no login for basic data. Economic forecasts are published by international organizations and central banks.

**Steps:**

- Consult U.S. Bureau of Labor Statistics (BLS) Occupational Employment Statistics for US wages; search for 'audiovisual technicians,' 'archivists,' 'software engineers,' 'data analysts' per region (Northern Virginia, California).
- Consult UK Office for National Statistics (ONS) for UK wage data by profession and region; search 'Annual Survey of Hours and Earnings' (ASHE).
- Consult Eurostat (eu.europa.eu/eurostat) for EU member-state wage data by occupation and region (Netherlands, Germany, France comparative data).
- Consult Australian Bureau of Statistics (ABS) for Australian professional wages by occupation.
- Consult Japanese Ministry of Health, Labour and Welfare and Statistics Bureau for Japanese wage data.
- Consult private salary-survey organizations (Glassdoor, Indeed, LinkedIn Salary, PayScale) for aggregated, anonymized role-specific salary ranges by region (less authoritative but more current).
- Consult published economic and inflation-forecast models (IMF, World Bank, national central banks) for 2026–2036 wage-escalation projections (2–4% annually typical).

### 10. Magnetic Tape, Film, and Card-Media Degradation Research and Standards (ISO 18938, ISO 18927, ASTM Standards; Acid Hydrolysis and Vinegar Syndrome Literature)

**ID:** bc1c430a-7fff-43ad-a2b9-9817b00a30a3

**Description:** Published technical standards and scientific literature on degradation mechanisms for magnetic tape (azimuth drift, layer adhesion failure, oxide shedding, binder hydrolysis), cellulose-triacetate film (vinegar syndrome, plasticizer loss, shrinkage, color fade), and card-media (oxidation, edge crumble, print fading). Includes ISO 18938 (magnetic tape storage lifetime), ISO 18927 (cellulose triacetate film permanence), ASTM D5026 (accelerated aging of tape), and peer-reviewed preservation science literature quantifying degradation rates and playable-lifespan estimates for items in different condition grades. Essential for baseline risk assessment, degradation-timeline modeling, and triage-doctrine justification.

**Recency Requirement:** Published standards valid as of Month 0 (2026-10-12); published research within 5 years of Month 0 (2026-10-12) (2021–2026) preferred; classical references acceptable if standards have not changed.

**Responsible Role Type:** Media Preservation Specialist

**Access Difficulty:** Medium. ISO and ASTM standards are paid publications (typically USD 100–300 per standard); institutional access may be available through universities or technical libraries. Peer-reviewed journal articles are available via institutional subscriptions or open-access repositories (ResearchGate, Google Scholar, institutional repositories). Conference proceedings are often open-access or available through professional societies.

**Steps:**

- Purchase or access ISO standards (ISO 18938, ISO 18927) via the International Organization for Standardization (iso.org) or through technical libraries (university, government, professional societies may provide institutional access).
- Purchase or access ASTM standards (ASTM D5026, ASTM D7618) via the American Society for Testing and Materials (astm.org).
- Search peer-reviewed preservation science literature via: Journal of the Association of Canadian Archivists, American Archivist, Preservation Digital Technology (OCLC), Archives and Records (Taylor & Francis), and archival science databases (A-MAS, ArchivesHub).
- Consult technical reports from the Library of Congress, National Archives (US and UK), and Smithsonian Institution on tape and film degradation.
- Search conference proceedings (IASA, SAA, ALA) for presentations on tape and film degradation research (2015–2025).

### 11. Fire-Authority and Insurance Requirements for Containerized Hazardous-Materials Handling (Baking Ovens, Humidity Chambers, Generators in Shipping Containers)

**ID:** e865bc99-c953-4df0-a8c9-5065ec3922df

**Description:** Technical requirements and approval checklists from fire authorities (NFPA—National Fire Protection Association, UK Fire and Rescue Service, equivalent EU/Australian bodies) and insurance underwriters specifying hazard controls for containerized equipment with thermal, chemical, and fire risk. Includes baking-oven thermal-management and fire-suppression standards, VOC-monitoring and ventilation requirements, on-board generator fuel-handling and emissions specifications, and archival-material fire-suppression compatibility (dry-chemical, CO2 vs. water-based systems). Essential for hazard-control standard development and site fire-authority pre-approval.

**Recency Requirement:** Current standards as of Month 0 (2026-10-12); NFPA and fire-safety standards updated annually; consult most recent published versions (2025–2026).

**Responsible Role Type:** Chief Engineer, with input from fire-safety consultant and insurance broker

**Access Difficulty:** Medium. NFPA standards are paid publications; institutional access through universities or technical libraries may be available. Fire-safety authority requirements are often publicly available through government websites or may require direct institutional contact. Insurance requirements vary by underwriter; specialized heritage-sector insurance brokers can provide guidance.

**Steps:**

- Contact NFPA (National Fire Protection Association) to access standards: NFPA 70 (electrical), NFPA 30 (flammable liquids), NFPA 59A (natural gas).
- Contact UK Fire and Rescue Service (via local authorities) for fire-safety requirements in the UK.
- Contact equivalent fire-safety authorities in target jurisdictions (Australia Fire Services, European fire-safety bodies).
- Consult insurance underwriters specializing in heritage and archival organizations to request hazard-control checklists and approval criteria.
- Search published guidance from archival and preservation organizations (Society of American Archivists, International Council of Archives) on fire-safety for containerized digitization projects.
- Consult specialized fire-safety consultancies operating in the heritage and archival sector for best-practice recommendations.

### 12. Copyright Status and Rights Information on 1950–2000 Recordings, Films, and Documents (Published Copyright Duration Laws, Orphan-Work Databases, Publisher and Rights-Holder Contacts)

**ID:** 2f170123-9880-4223-85ce-ade8ccf35da4

**Description:** Published copyright-duration laws and rules in target jurisdictions (US, UK, EU, Canada, Australia, Japan) specifying copyright term for works created 1950–2000 (typically life + 50–70 years, or publication year + fixed term for works made for hire). Includes orphan-work registry databases, rights-holder directories, and contact information for publishers, broadcasters, and music rights organizations (ASCAP, BMI, PRS, SACEM, APRA, JASRAC). Necessary for determining copyright status of items pre-upload, identifying rights holders to notify of digitization, and designing source agreements that specify copyright handling per jurisdiction.

**Recency Requirement:** Copyright law as of Month 0 (2026-10-12); subject to amendment (EU Copyright Directive 2019 recent; UK implementing post-Brexit changes; US Copyright Term Extension Act 1998, no recent amendments). Consult most current published versions of national copyright codes.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer

**Access Difficulty:** Easy. National copyright offices and intellectual-property websites are public. Rights-holder directories are also public or available via institutional queries. Orphan-work registries are published online.

**Steps:**

- Access U.S. Copyright Office website (copyright.gov) for US copyright-duration rules and orphan-work registry.
- Access UK Intellectual Property Office (IPO) website for UK copyright law and rules.
- Access EUIPO (European Union Intellectual Property Office) and national European copyright offices for EU member-state rules (harmonized under EU Copyright Directive 2019).
- Access national copyright offices in other target jurisdictions (Canadian Intellectual Property Office, Australian Copyright Agency, Japanese Agency for Cultural Affairs).
- Consult rights-holder directories: ASCAP, BMI, PRS (UK), SACEM (France), APRA (Australia), JASRAC (Japan), etc., for music and performer rights.
- Search orphan-work registries and databases (U.S. Copyright Office, UK IPO, EU Orphan Works Directive compliance registries).

### 13. Satellite and Fiber-Optic Broadband Availability and Service Pricing (10+ Mbps Upload Capability) in Target Archive Locations (2026–2036)

**ID:** 882c5150-115b-451c-85f4-6c94d6e5ac76

**Description:** Current and projected availability of satellite (Viasat, Starlink, Intelsat) and fiber-optic broadband connectivity meeting the plan's minimum upload specification (≥10 Mbps, ≤100 ms latency preferred for real-time remote support) in 30+ planned archive locations across Northern Virginia, UK, Netherlands, California, Australia, and Japan. Includes service-level agreements (SLAs), uptime guarantees (≥99% typical for satellite, ≥99.5% for fiber), and monthly cost per 10 Mbps+ service. Essential for remote-diagnostics system feasibility and budget planning for satellite/fiber uplink costs per unit.

**Recency Requirement:** Current service availability and pricing as of Month 0 (2026-10-12); projections to 2036 acceptable based on carrier expansion plans.

**Responsible Role Type:** Chief Engineer and Site Operations Coordinator

**Access Difficulty:** Easy. Satellite and fiber-optic providers maintain public coverage maps and online service locators. Pricing information is available via direct contact or public websites. Regional broadband statistics are published by government and international organizations.

**Steps:**

- Contact satellite-service providers (Viasat, Starlink, Intelsat) directly for coverage maps and service quotes in target locations.
- Contact fiber-optic providers in target regions (Comcast, Verizon in US; Virgin Media, BT in UK; KPN, Ziggo in Netherlands; major carriers in other regions) for availability and pricing.
- Use online coverage checkers (e.g., Viasat coverage map, Starlink availability checker, Comcast/Verizon service locators) to query each planned archive location.
- Consult service-pricing databases (TeleGeography, Eurostat broadband-access statistics) for regional broadband-cost comparisons.
- Contact archive facilities management directly to determine current broadband infrastructure and upgrade costs.

### 14. Broadcast-Industry Vintage Equipment Decommissioning and Salvage Records (2010–2026)

**ID:** d904b2f4-64db-4255-bab9-70b4672111bc

**Description:** Records and inventories from broadcast station consolidations, digital-transition closures, and equipment-decommissioning projects across North America, Europe, and Japan (2010–2026). Documents which specific tape decks, film scanners, and card readers have been decommissioned; condition at decommission; current location (salvage yards, equipment brokers, storage facilities); and estimated acquisition cost per unit. Examples: NPR station closures and equipment dispersal, BBC digital-transition decommissioning, RAI (Italian broadcasting) equipment surplus, NHK (Japan) archive refreshes. Essential for parts-stockpile acquisition planning and cost estimation.

**Recency Requirement:** Decommissioning records from 2010–2026 (recent salvage facilities most important); current location and condition as of Month 0 (2026-10-12).

**Responsible Role Type:** Vintage Equipment Sustainment Engineer / Parts Manager

**Access Difficulty:** Medium. Broadcast stations and networks may not readily publish decommissioning records; direct institutional contact required. Equipment salvage records are often transient (sales records purged after transaction). Specialist vendors may share information under confidentiality. Trade publications are archived and searchable.

**Steps:**

- Contact broadcast-station archives and administrative offices (NPR, PBS, BBC, ARD, RAI, NHK) to inquire about decommissioned equipment location and dispersal history.
- Query equipment salvage and auction companies (eBay, Surplus.com, Equipment Disposition Services) for historical listings of vintage broadcast equipment (2010–2026).
- Contact specialized broadcast-equipment restoration vendors (Memnon, Cube Tapes, Spectra, Arvato) who may maintain supplier relationships and know where decommissioned machines end up.
- Consult trade publications (Broadcast Engineering, Television Engineering, Studio Sound archives) for articles on broadcast station closures and equipment dispersal.
- Network with retired broadcast engineers and technical societies (AES, SMPTE) who may have personal knowledge of equipment decommissioning and current locations.

### 15. Cost-of-Ownership and Total-Cost-of-Operation Studies from Comparable Large-Scale Digitization Projects (Indiana MDPI, British Library UOSH, Library of Congress Packard Campus, Europeana Digitization Programs)

**ID:** d103f813-652f-4a81-a854-d91bf378f651

**Description:** Published or obtainable cost accounting from large-scale heritage digitization programs documenting: per-item cost, per-unit opex (broken down by labor, consumables, utilities, storage), staffing models (headcount per unit, per format), per-format cost variation, and cost evolution over project lifetime. Includes Indiana University MDPI cost per tape hour, British Library UOSH cost per digitized item, Library of Congress Packard Campus annual opex, and Europeana framework-partner cost accounting. Essential for validating budget and opex assumptions and for cost-audit benchmarking.

**Recency Requirement:** Final-cost accounting or mid-project cost reports from 2015–2026 (programs with 5–10 year duration overlapping with current period).

**Responsible Role Type:** Financial Analyst

**Access Difficulty:** Medium. Final cost accounting is often held by institutions or funders; direct contact and formal data-request required. Published cost studies exist but may not be comprehensive. Some cost data is proprietary or sensitive (staff salaries, vendor contracts). Archival and professional networks can provide benchmarking context through informal exchange.

**Steps:**

- Contact Indiana University Libraries for MDPI cost accounting and published cost-per-item and cost-per-unit reports.
- Contact British Library for UOSH cost analysis and project financial reports (likely published in grant reports to National Lottery Heritage Fund).
- Contact Library of Congress for Packard Campus annual operations budgets and cost per item digitized (may require FOIA request or direct institutional contact).
- Search Europeana project reports and partner-organization publications for aggregated cost data across multiple digitization programs.
- Consult published research on digital preservation cost models (e.g., Preservation Cost Modeling Template from the Library of Congress, DPSP—Digital Preservation Small Projects grants research).
- Contact professional societies (American Archive Association, IASA, SAA) for members' experience sharing on per-item costs.

### 16. Existing Data-Residency and Data-Transfer Case Law and Data-Protection Authority Decisions (EDPB Opinions, ICO Guidance, Court Rulings on Cross-Border Data Transfer)

**ID:** 6aba13c9-cbc0-463a-9665-eacb0f6d61a9

**Description:** Published legal decisions and regulatory guidance (Data Protection Authority opinions, court rulings, EDPB guidelines) addressing personal-data transfer and residency requirements in archival and cultural-heritage contexts. Includes: EDPB Opinions on Standard Contractual Clauses (SCC) validity post-Schrems II, UK ICO guidance on archival-data processing, EU Court of Justice rulings on data transfers, and any case law on handling of cultural artifacts containing personal data. Essential for drafting jurisdiction-specific source agreements and privacy-impact assessments.

**Recency Requirement:** EDPB opinions and regulatory guidance from 2020–2026 (post-Schrems II era); court rulings from 2015–2026.

**Responsible Role Type:** Privacy, Rights and Legal Compliance Officer

**Access Difficulty:** Easy. EDPB and ICO publications are freely available. Court decisions are published online via official EU and national court websites. Legal analysis articles are available via academic databases or law-firm publications.

**Steps:**

- Access EDPB official website (edpb.ec.europa.eu) for published opinions and guidelines on data transfers and archival processing.
- Access UK Information Commissioner's Office (ICO) website (ico.org.uk) for guidance on archival-data processing and UK data-transfer rules post-Brexit.
- Search EU Court of Justice (curia.europa.eu) for published rulings related to data transfers, archival rights, and cultural-heritage data.
- Consult legal databases (Google Scholar, national court websites) for archival-related data-protection case law.
- Consult published law-review articles and legal-analysis documents on archival data-protection and cross-border transfers (in Privacy Laws & Business, International Data Protection Reports, etc.).