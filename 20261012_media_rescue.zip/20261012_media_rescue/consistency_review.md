## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Are at least 6 retired-engineer mentors under contract (Month 1 = 2026-11-12) and does the parts-depletion model show spares staying above the 50% re-manufacture trigger through Month 60 (2031-10-12) with 3D-printed parts holding the ±0.05mm azimuth tolerance? | ≥6 signed mentor contracts (min 2 per line type) by Month 1 (2026-11-12); model delivered Month 2 (2026-12-12) and validated by Month 4 (2027-02-12); spares >50% of baseline through Month 60 (2031-10-12); fabricated parts within ±0.05mm azimuth tolerance; stop rule if spares are exhausted before Month 100 (2035-02-12) at the funded unit count. | Signed mentor contracts (Month 1 = 2026-11-12); provisional depletion curve (Month 2 = 2026-12-12); 8–12 week bench test of 10 reference decks and 10 fabricated parts measured against reference playback (validated by Month 4–5 = 2027-02-12 to 2027-03-12). | Month 1 (2026-11-12) NO: add backup mentors and extend retention contracts before any hardware spend. Model or tolerance NO: fund re-manufacture or a stockpile refresh (USD 15–25M unbudgeted, estimate), reduce planned unit count, or cancel further unit builds and pivot to a vendor-operated model. |
| 2 | Is at least USD 30M (50%) of Phase 1 committed in binding contracts, not pledged, and a USD 15–20M bridge facility pre-qualified, by Month 3 (2027-01-12)? | ≥USD 30M of USD 60M committed (not pledged) by Month 3 (2027-01-12); USD 15–20M revolving/bridge facility pre-qualified by Month 3 (2027-01-12) (proposed thresholds); host cost-share letters received from ≥5 of 10 surveyed sites. | Funding Commitment Registry (Month 1 = 2026-11-12) showing committed versus pledged amounts, and signed funder contracts (Month 3 = 2027-01-12). | Freeze long-lead procurement and hiring beyond the three pilots, re-run the programme at the funded scope, and move to governance re-assessment. Delay Phase 1 capex by 4–8 weeks per funder cycle, or downsize to pilots only. |
| 3 | Does the independent cost audit produce a reconciled staffing and cost model that fits a funded unit count of at least 24, or has a named, committed source for the gap of about USD 280M? | Reconciled cost within the USD 250M cap, or committed funding that does not force more than a 20% unit reduction (fewer than 24 units). The plan's own recomputation is about USD 530M and ~14 unit-equivalents at the cap (estimate); budget-consistent crew is about 25 staff per unit, not 50–60. | Cost audit (commissioned Month 1 = 2026-11-12), three scenarios and locked staffing model and Phase 1 design (Month 4 = 2027-02-12), host cost-share and in-kind commitments (Months 3–4 = 2027-01-12 to 2027-02-12). | Re-baseline targets to the funded scope (about 14 unit-equivalents, ~1.7M items, ~95 PB, estimate), or split the programme so only the pilots and Phase 2 are released. Halt Phase 1 procurement until a decision is taken on who finances MIUs 4–30. |
| 4 | Is written insurer and fire-authority approval in hand at one pilot site, and are three host-archive agreements signed, by Month 6 (2027-04-12)? | ≥1 written insurer and fire-authority approval of the pre-treatment design and 3 signed pilot agreements by Month 6 (2027-04-12); stop rules: no approval of any pre-treatment design by Month 9 (2027-07-12), or fewer than 2 pilot archives signed by Month 9 (2027-07-12). | Approval letters from insurer and fire authority, broker quotes (premium ≤USD 1M/yr, proposed threshold) and countersigned source agreements with tiered indemnity (Month 6 = 2027-04-12). | Switch to the detached pre-treatment pod (USD 0.5–1.5M each, +4–6 weeks per site, estimate) and re-baseline pilot dates. If still no approval by Month 9 (2027-07-12), cancel on-site pre-treatment and pivot to host cold-storage deferral or fixed-site labs, or halt the pilot build and redesign the host partnership model. |
| 5 | Does AI pre-screening on real degraded content meet the review gate in the pilot review pod by Month 8 (2027-06-12)? | Precision and recall ≥75% per category-format pair; flagging ≤25% (gate requires <20%); privacy false-negative <5%; review hours per content hour ≤0.5. Retrain below 75% or above 25% flagging; redesign the workflow above 30%; governance re-assessment below 70% after retraining. | Gold-standard labelled set of 100–200 samples (Month 4 = 2027-02-12) and pilot review pod results on live content (Month 8 = 2027-06-12), re-measured quarterly and audited by Month 12 (2027-10-12). | Retrain (2–4 weeks engineering plus 1–2 weeks compute) and recalibrate crew size before the design freeze at Month 20 (2028-06-12). If flagging stays above 30%, redesign the review workflow and reprice reviewers, which delays the Phase 2 gate by 3–6 months or reduces the unit count. |
| 6 | Is the Phase 2 gate met at Month 24 (2028-10-12): all pilot thresholds held for at least 3 consecutive months on at least 2 host sites, and at least USD 84M (70%) of Phase 2 committed? | Digitization >95%, reconstruction >80%, metadata >70%, human review <20%, uptime >90%, AI precision/recall ≥75%, zero privacy/legal incidents, for ≥3 consecutive months on ≥2 sites; cumulative variance ≤10%; ≥USD 84M of Phase 2 committed. | Evidence package compiled by Month 22 (2028-08-12), third-party audit sampling, and a Board vote at Month 24 (2028-10-12). | Release no Phase 2 funds beyond a conditional limited tranche (only if results are ≥80% of targets, with governance approval). Otherwise hold Phase 2 for rework (design rework USD 2–5M and 6–9 months, estimate), re-scope to the funded unit count, or stop. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: project_plan Goal Statement and executive_summary Purpose and Goals
    canonical: cap_affordable_scale = At USD 250M the plan's costs support about 47% of scope: ~14 unit-equivalents, ~1.7M items, ~95 PB (estimate)
    observed:  30 units, 3.6M+ items, 200+ PB "within the USD 250M cap"
HIGH CF-002  document: review_plan Review 2 item 2 and Review 3 item 1
    canonical: payroll_recomputed = 1,500-1,800 staff = USD 75-126M per year at full scale (estimate)
    observed:  USD 11-29M annual overspend
HIGH CF-003  document: review_plan Review 10 item 3, Review 11 item 3, Review 14 item 2
    canonical: unit_years_baseline = About 160 active unit-years (159.5); opex planning value USD 2.5M per unit-year
    observed:  USD 50M additional cost across 160 unit-years; USD 11.25–18.75M in-kind total
HIGH CF-004  document: review_plan Review 13 and assumptions Risk 8 (design-freeze/procurement sequencing)
    canonical: phase1_to_2_gate = Release of Phase 2 at Month 24 (2028-10-12) only if thresholds held ≥3 consecutive months on ≥2 host sites; first Phase 2 unit operational Month 28 (2029-02-12)
    observed:  Design freeze and long-lead procurement at Month 20 (2028-06-12), four months before the gate
MEDIUM CF-005  document: review_plan Review 8 item 3, Review 11 item 1; self_audit item 6
    canonical: phase3_affordability = USD 17.5M = 7 unit-years of opex; with no new MIUs it funds 28 unit-years (15 units for ~22 months, to about Month 82 = 2033-08-12)
    observed:  USD 17.5M for ~28 unit-years; 15 units operate ~22 months with 15 new MIUs
MEDIUM CF-006  document: review_plan Reviews 1–3, 8; self_audit items 4 and 20
    canonical: reviewers_per_unit = 12-15 reviewers per active MIU; 360-450 fleet-wide; review load 20% flagged (80% reduction), a hypothesis (estimate)
    observed:  40–50 reviewers per unit at 35–40% flagging, with +USD 15–25M per year
MEDIUM CF-007  document: pitch Risks; review_plan Review 2/3; self_audit items 6 and 7
    canonical: inflation_reserve = 2%/yr baseline with 3% and 4% sensitivities, about 22% / 34% / 48% cumulative by Month 120 (2036-10-12) (proposed threshold)
    observed:  baseline, +15%, +30% inflation scenarios
MEDIUM CF-008  document: pitch
    canonical: end_state_milestones = End-state working group Month 12 (2027-10-12); transition plan Month 36 (2029-10-12); successor bodies Month 48 (2030-10-12); two verified separate copies per master (proposed threshold)
    observed:  "Format-migration funding is endowed"; "proven partnerships"
MEDIUM CF-009  document: premortem A2/FM2 and review_plan Reviews 5/8
    canonical: parts_and_mentor_milestones = Parts-depletion model by Month 2 (2026-12-12); re-manufacture trigger at 50% spares depletion (proposed threshold)
    observed:  Bench test 8–12 weeks and 3D-print tolerance by Month 4 (2027-02-12), validated Month 4 (2027-02-12)
MEDIUM CF-010  document: self_audit items 2, 4 and 20
    canonical: ai_and_review_triggers = Precision/recall <75% -> retrain; <70% after retraining -> governance re-assessment; flagging >25% -> retrain/recalibrate; >30% -> redesign (proposed threshold)
    observed:  NO-GO at <75% / flagging >25%; halt if <3 archive agreements by Month 6 (2027-04-12)
LOW CF-011  document: review_plan Reviews 5, 12, 13; self_audit item 6; pitch Long-term Vision
    canonical: fallback_design_rework = first Phase 2 unit at Months 34–37 (2029-08-12 to 2029-11-12); Phase 3 start could slip to Month 66–72 (2032-04-12 to 2032-10-12) (estimate)
    observed:  Month 32–36 (2029-06-12 to 2029-10-12); Month 66–75 (2032-04-12 to 2033-01-12) with mismatched dates; revolving line by Month 2 (2026-12-12)
```

### 1. Stated target scope vs what the USD 250M cap can fund (🔴 High) — needs a project decision

- **project_plan Goal Statement; executive_summary Focus and Purpose and Goals:** Goal: build 30 MIUs and recover 3.6M+ items and 200+ PB "within the USD 250M cap"; "Deliver 3.6M+ items and 200+ PB ... via 30 containerized units" within USD 250M.
- **project_plan Achievable; executive_summary Timeline and Budget; review_plan Review 1; self_audit items 6/7:** "the cap supports about 47% of scope (estimate)": ~14 unit-equivalents, ~1.7M items, ~95 PB; unconstrained cost ~USD 530M, unfunded gap ~USD 280M (about USD 301M in Phase 3 alone); only ~14 units fundable is also a NO-GO trigger in self_audit and premortem A1.
- **Why it conflicts:** The headline goal is presented as achievable within the cap, while the same documents show it is about half-funded with no committed source for the remainder. The plan's own NO-GO triggers (only ~14 units fundable, cost above cap by >10%) are already met on the recomputed numbers.
- **Suggested resolution:** State the target as conditional: 30 MIUs / 3.6M items only if ~USD 280M (about USD 304M with the contingency) is committed; otherwise the cap-funded baseline is ~14 unit-equivalents / ~1.7M items / ~95 PB. The Programme Board must choose among host cost-share, new consortium or government funders, non-exclusive technology-sector funding, or re-baselined targets. Use "USD 280M total gap" and "USD 301M Phase 3 gap" consistently; they are different quantities.

### 2. Payroll overspend figure follows the superseded payroll estimate (🔴 High)

- **review_plan Review 2 item 2; executive_summary Risks (1):** "Recomputed payroll (USD 75-126M annually at full scale) versus USD 25M average annual budget"
- **review_plan Review 2 item 2 and Review 3 item 1:** The same item concludes the choice is "inadequate staffing ... or USD 11-29M annual overspend"; repeated in Review 3 item 1 ("~USD 11-29M annual overspend").
- **Why it conflicts:** USD 75–126M minus USD 25M is a USD 50–101M annual gap, not USD 11–29M. The USD 11–29M comes from the pre-reconciliation payroll of USD 36–54M, so the figure understates the gap by about 4x.
- **Suggested resolution:** Replace USD 11–29M with the arithmetic from the canonical payroll: about USD 50–101M per year above the USD 25M average budget at full scale (estimate), noting that part of the opex line is non-payroll. Keep the ~25 staff per unit budget-consistent crew as the alternative.

### 3. Host in-kind and opex-increase arithmetic over 160 unit-years (🔴 High)

- **review_plan Review 14 item 2:** In-kind contribution of 15–25% of opex = "USD 0.375–0.625M per unit × 30 units = USD 11.25–18.75M total over 160 unit-years"
- **review_plan Review 10 item 3, Review 11 item 3, Review 14 item 2:** If unavailable, opex rises from USD 2.5M to USD 3.5–4.0M per unit-year, "adding ~USD 50M across 160 unit-years"; Phase 3 gap grows from USD 301M to USD 351M; in-kind threshold USD 25M.
- **Why it conflicts:** USD 0.375–0.625M per unit-year × ~160 unit-years = USD 60–100M, not USD 11–19M. An increase of USD 1.0–1.5M per unit-year × ~160 = USD 160–240M, not USD 50M. The 15–25% share, the USD 3.5–4.0M opex and the USD 50M cannot all hold.
- **Suggested resolution:** Recompute from 159.5 unit-years × USD 2.5M: the in-kind value at 15–25% is USD 60–100M (estimate), and the opex-increase case adds about USD 160–240M (estimate), not USD 50M. Restate the Phase 3 gap sensitivity and the "USD 25M aggregate in-kind" threshold accordingly, and keep in-kind outside the cap as in the canonical facts.

### 4. Perpetual-storage cost: USD 30–50M per decade vs USD 600M–1B over 20 years (🔴 High)

- **self_audit item 17 (mitigation, data stewardship failover):** Annual format-migration funding mechanism "estimated USD 30–50M per decade for 200+ PB"
- **executive_summary Risks (4); review_plan Review 2 item 3, Reviews 8, 14; self_audit items 6, 12, 15:** Perpetual-storage liability USD 600M–1B (over 20 years), unbudgeted post-Month 120 (2036-10-12)
- **Why it conflicts:** The two figures differ by roughly 10–20x for the same 200+ PB obligation, which decides whether a stewardship commitment is feasible. Self_audit item 12 additionally attributes the whole USD 600M–1B to optional wideband retention, while other documents attribute it to the baseline masters.
- **Suggested resolution:** Keep USD 600M–1B over 20 years (estimate) as the working figure, since it appears in the executive summary and most reviews, until a costed custody model exists. Remove or restate the USD 30–50M per decade figure, and describe wideband retention as an incremental multiplier (3–10x storage) rather than the source of the whole liability.

### 5. Long-lead Phase 2 procurement at Month 20 (2028-06-12) vs gate release at Month 24 (2028-10-12) (🔴 High) — needs a project decision

- **project_plan Mitigation Plans; canonical phase1_to_2_gate; review_plan Review 13 item 2; pitch Call to Action:** Phase 2 is released at Month 24 (2028-10-12) only if all pilot thresholds are held for ≥3 months on ≥2 sites; "no full override of gates"; evidence compiled by Month 22 (2028-08-12).
- **assumptions Risk 8; review_plan Review 13 item 1; canonical phase2_first_unit_timing:** Design freeze at Month 20 (2028-06-12) "allowing 4 months for long-lead equipment procurement"; Month 20 (2028-06-12) "gates Phase 2 unit orders"; first Phase 2 unit operational at Month 28 (2029-02-12).
- **Why it conflicts:** Phase 2 unit orders are placed 4 months before the gate decision and before the evidence package exists. Either capex is committed at risk before the gate, which weakens the "no override" claim, or a Month 28 (2029-02-12) first unit is unattainable if orders wait for Month 24 (2028-10-12).
- **Suggested resolution:** A project decision is required. Options: (a) authorise a bounded at-risk long-lead tranche before Month 24 (2028-10-12), with the exposure and funder consent stated; (b) hold orders until the gate and accept a later first Phase 2 unit; (c) use the conditional limited tranche (≥80% of targets) for early orders. Document the choice in the gate charter before Month 6 (2027-04-12).

### 6. Phase 3 affordability: 22 months of opex assumed while also building 15 new MIUs (🟡 Medium)

- **review_plan Review 8 item 3 and Review 11 item 1 (first clause); canonical phase3_affordability:** USD 70M less USD 52.5M for 15 new MIUs leaves USD 17.5M, i.e. 7 unit-years of opex.
- **review_plan Review 8 item 3, Review 11 item 1; self_audit item 6:** "Phase 3 can fund only ~15 units for 22 months (to ~Month 82 = 2033-08-12)"; "USD 17.5M for ~28 unit-years"; "15 units for ~22 months before budget exhaustion"
- **Why it conflicts:** 28 unit-years and 22 months are the no-new-MIU case. With 15 new MIUs only 7 unit-years remain, which covers 15 units for about 5–6 months (to roughly Month 66 = 2032-04-12, estimate). The text mixes the two cases within a single sentence.
- **Suggested resolution:** State both cases separately: with 15 new MIUs, 7 unit-years (about 5–6 months of 15-unit operation, estimate); with no new MIUs, 28 unit-years (15 units to about Month 82 = 2033-08-12). Both are before the USD 7M contingency.

### 7. Reviewer headcount multiple vs added payroll cost (🟡 Medium)

- **review_plan Review 1 item 3, Review 2 item 2; self_audit items 4, 20:** At 35–40% flagging, reviewer headcount "triples from 12–15 to 40–50 per unit"
- **review_plan Review 1 item 3, Review 8 item 1; self_audit item 4:** The same text gives additional payroll of "USD 15–25M annual" at full scale; flagging rises from 20% to 35–40%, which is 1.75–2x the review load.
- **Why it conflicts:** A rise from 20% to 35–40% flagging scales review load by 1.75–2x, i.e. about 21–30 reviewers per unit, not 40–50. 40–50 per unit at 30 units is 1,200–1,500 reviewers, about USD 38–80M more per year than the 360–450 baseline (at USD 50–70K), not USD 15–25M. The "triples" claim and the cost figure cannot both follow from 35–40% flagging.
- **Suggested resolution:** Scale proportionally: 35–40% flagging is about 1.75–2x, giving roughly 21–30 reviewers per unit and +USD 14–32M per year at full scale (estimate). Use 40–50 per unit only for a stated flagging level of about 60–80%, with the corresponding cost.

### 8. Inflation scenarios differ from the canonical escalation range (🟡 Medium)

- **pitch Risks; review_plan Review 2 item 2 and Review 3 item 1; self_audit items 6, 7:** Model three scenarios "baseline, +15%, +30%" inflation
- **canonical inflation_reserve; assumptions Risk 17:** Baseline escalation 2%/yr with 3% and 4% sensitivities, about 22% / 34% / 48% cumulative by Month 120 (2036-10-12); inflation reserve proposed at 15% per phase
- **Why it conflicts:** +15% and +30% are not the canonical 22% / 34% / 48% cumulative outcomes. The "+15%" also resembles the 15% reserve, so it is unclear whether it is a price scenario or a reserve size. The stated scenarios understate the 4% case by about 18 points.
- **Suggested resolution:** Define the three audit scenarios as 2%, 3% and 4% annual escalation (about 22% / 34% / 48% cumulative by Month 120 = 2036-10-12), and treat the 15% reserve (USD 9M / 18M / 10.5M) as a separate, proposed provision.

### 9. Pitch states open items as facts (🟡 Medium)

- **pitch Project Overview, Stakeholder Benefits, Ethical Considerations, Collaboration, Long-term Vision:** "proven partnerships"; "Format-migration funding is endowed"; funders get "Joint ownership of fleet and recovered data"; archives get "phased payment via cost-sharing"; "Every digitized item is gated behind ... human review".
- **executive_summary; review_plan Reviews 9, 11, 14; assumptions Risk 14; canonical miu_financing_open_decision:** No archive agreement is signed (3 targeted by Month 6 = 2027-04-12); no steward or funding for perpetual storage (commitment targeted Month 36 = 2029-10-12); masters stay in host or federated custody; cash host cost-share is unquantified; only flagged items (~20%) get human review, with automated acceptance of low-risk content considered.
- **Why it conflicts:** The pitch presents commitments and funding as accomplished or guaranteed when other documents list them as unresolved assumptions or future milestones. The ownership and review claims also conflict with host-held masters and with flagged-only human review.
- **Suggested resolution:** Reword as targets with dates: "partnerships to be signed by Month 6 (2027-04-12)"; "format-migration funding to be secured by Month 36 (2029-10-12)"; "human review of every flagged item, with sampled audit of unflagged items"; ownership and cost-share "subject to agreement".

### 10. Parts-depletion model due Month 2 (2026-12-12) before its inputs exist (🟡 Medium)

- **canonical parts_and_mentor_milestones; executive_summary; project_plan; premortem FM2:** Parts-depletion model delivered by Month 2 (2026-12-12) (including MTBF per deck type, cannibalization yield and 3D-printing capability).
- **premortem A2; review_plan Reviews 5 and 8; executive_summary Month 4 (2027-02-12) actions; self_audit item 10:** Model inputs: 8–12 week bench test of 10 decks at 16+ hours/day; harvest 20 machines; 3D-printing tolerance validated by Month 4 (2027-02-12); "MTBF ... validated Month 4 (2027-02-12)"
- **Why it conflicts:** An 8–12 week test commissioned in Month 1–2 (2026-11-12 to 2026-12-12) completes at about Month 4–5 (2027-02-12 to 2027-03-12), and the fabrication tolerance result is scheduled for Month 4 (2027-02-12), so a validated Month 2 (2026-12-12) model depends on prerequisites that arrive later. Self_audit item 10 itself says "commissioned Month 1 (2026-11-12), validated Month 4 (2027-02-12)".
- **Suggested resolution:** Keep Month 2 (2026-12-12) for a provisional model (literature MTBF and inventory baseline) and Month 4–5 (2027-02-12 to 2027-03-12) for the validated model, with the 50% re-manufacture trigger confirmed only then. Say so in the milestone list and in tripwire FM2.

### 11. NO-GO thresholds differ between self-audit, premortem and canonical triggers (🟡 Medium)

- **canonical ai_and_review_triggers; premortem FM6 tripwires and stop rule:** Pre-screen precision/recall <75% -> retrain; <70% after retraining -> governance re-assessment; flagging >25% -> retrain, >30% -> redesign; <3 agreements by Month 6 (2027-04-12) is a tripwire, stop rule is <2 pilot archives by Month 9 (2027-07-12).
- **self_audit item 2 (Global NO-GO B), item 4, item 20:** NO-GO if precision/recall <75% or flagging >25%; elsewhere NO-GO if flagging >30%; "<3 archive agreements signed by Month 6 (2027-04-12)" halts all new deployments.
- **Why it conflicts:** The same metrics have a different consequence in each document: 25% is a retrain trigger in one place and a NO-GO in another, and 30% is a NO-GO in item 20. Missing 3 agreements at Month 6 (2027-04-12) is a tripwire in the premortem but a halt in the self-audit.
- **Suggested resolution:** Use the canonical ladder: retrain at <75% or >25%; redesign at >30%; governance re-assessment at <70% after retraining. For hosts, use tripwire <3 by Month 6 (2027-04-12) and stop <2 by Month 9 (2027-07-12). Align self_audit items 2, 4 and 20.

### 12. Milestone months and dates differ from canonical values (⚪ Low)

- **canonical fallback_design_rework, phase2_first_unit_timing, debt_and_bridge_financing:** Rework case: first Phase 2 unit at Months 34–37 (2029-08-12 to 2029-11-12); Phase 3 start could slip to Month 66–72 (2032-04-12 to 2032-10-12); bridge facility pre-qualified by Month 3 (2027-01-12).
- **review_plan Review 5 item 3, Review 12 items 1–2, Review 13 item 1; self_audit item 6; executive_summary Action Orientation:** Phase 2 unit delivery "Month 32–36 (2029-06-12 to 2029-10-12)"; Phase 3 start "Month 66–75 (2031-10-12 to 2032-09-12)" and "(2032-04-12 to 2033-09-12)"; revolving line "by Month 2 (2026-12-12)"; Director appointed "by Month 0 (2026-10-12)" vs Month 1 (2026-11-12).
- **Why it conflicts:** The same milestones carry different month numbers, and the parenthetical dates do not match the month offsets (Month 66 = 2032-04-12, Month 75 = 2033-01-12). Elsewhere month and date labels are garbled (e.g. "Month 120, 30 (2036-10-12, 2029-04-12)" in the pitch).
- **Suggested resolution:** Use canonical values: Phase 2 rework Months 34–37 (2029-08-12 to 2029-11-12), Phase 3 slip Months 66–72 (2032-04-12 to 2032-10-12), bridge pre-qualification Month 3 (2027-01-12), Director appointed at Month 1 (2026-11-12) as in the executive summary (or move all documents to Month 0 = 2026-10-12). Regenerate the date labels from the month offsets.

## Summary

The plan is coherent in structure: phase budgets, unit ramp, gate criteria and early milestones are largely aligned with the canonical facts, and it openly shows that the headline scope exceeds the cap. The main inconsistencies are (1) the headline goal of 30 units within USD 250M versus the plan's own finding that the cap funds about 14 unit-equivalents, (2) several downstream figures that still follow superseded estimates or contain arithmetic errors (payroll overspend, host in-kind, reviewer scaling, Phase 3 months of operation, perpetual-storage cost), and (3) gate and procurement sequencing that is not fully settled. Items such as items-lost-per-delayed-unit (50–150K per month vs ~2,000 per unit-month) and the USD 20M equipment line against USD 3–5K per machine are also loose and need cleanup. Several of these need a funding decision, not just text repair.