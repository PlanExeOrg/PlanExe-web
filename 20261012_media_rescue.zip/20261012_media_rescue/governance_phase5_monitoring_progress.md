### 1. Core Operational Metrics and Fleet Health Monitoring (KPI Tracking)
**Monitoring Tools/Platforms:**

  - Central Fleet Management Telemetry System (on-board sensors per MIU collecting uptime, MTBF, equipment status)
  - Monthly Telemetry Reports Dashboard (uptime %, digitization success %, reconstruction accuracy %, metadata accuracy %)
  - Equipment Performance Log (per-unit tracking of subsystem failures, parts consumption, maintenance hours)

**Frequency:** Monthly reporting to Technical Committee and Board; real-time alarm thresholds for critical failures (uptime <90%, reconstruction <80%, AI accuracy <75%)

**Responsible Role:** Technical Committee and Central Fleet Management Team; escalation to Programme Board if alarm triggered

**Adaptation Process:** Technical Committee convenes emergency session within 48 hours if threshold breached. Root-cause analysis conducted; corrective actions (design change, parts refresh, crew retraining, unit deployment adjustment) assigned with timeline. Board informed of remediation plan within 5 business days. If root cause indicates systemic design flaw, escalate to Board for Phase 2/3 impact assessment and authorization of rework (up to USD 2M / <2 months delay approved by exception; larger impacts require full Board approval).

**Adaptation Trigger:** Alarm threshold breach: uptime <90%, digitization success <95%, reconstruction accuracy <80%, automated metadata accuracy <70%, or human review flagging >25% (indicating AI pre-screen <75% accuracy); sustained for 2 consecutive months or single month critical failure.

### 2. Vintage Hardware Sustainment and Parts-Depletion Monitoring
**Monitoring Tools/Platforms:**

  - Parts Inventory Management System (database tracking all 300–500 acquired vintage machines, condition status, critical parts stock, consumption curves)
  - Parts Purchasing and Fabrication Dashboard (auto-triggers re-manufacture orders when stock approaches 50% depletion threshold)
  - Mean Time Between Failures (MTBF) Tracking per Line Type (tape decks, film scanners, card readers)
  - 3D-Printing and CNC Fabrication Status Log (scheduled re-manufacture, delivery timeline, tolerance validation results)

**Frequency:** Monthly Parts Inventory audit and depletion-curve update; weekly Parts Engineering team status meeting; quarterly Board report on spares trajectory and risk triggers

**Responsible Role:** Technical Committee (Parts and Maintenance Lead); Parts Engineering team daily operations; escalation to Programme Board if depletion outpaces fabrication by >20%

**Adaptation Process:** Monthly dashboard review identifies depletion rate and compares against fabrication capacity. If depletion is 15–20% faster than forecast, Parts Engineering increases re-manufacture scheduling and sources additional vintage machines or contract external repair capability. If depletion exceeds fabrication by >20% margin, Technical Committee escalates to Board with two mitigation options: (1) emergency vintage stockpile refresh (USD 15M–25M unbudgeted, requires contingency draw and Board approval), or (2) reduce fleet operating tempo or unit count to match sustainable spares consumption rate. Board authorizes remedy within 10 business days.

**Adaptation Trigger:** Parts-depletion model shows actual consumption rate exceeding forecast by >15%; trigger escalation to Parts Engineering. If depletion exceeds fabrication capacity by >20% margin by Month 36–48 (2029-10-12 to 2030-10-12), activate emergency Board decision: approve contingency draw, reduce unit count, or defer Phase 3. Specific trigger: projected parts stockpile exhaustion within 18 months of current rate.

### 3. AI Pre-Screening and Review Workflow Validation (Unproven Assumption Testing)
**Monitoring Tools/Platforms:**

  - Pilot Review Pod Test Results (flagging rate, review hours per content hour, precision/recall per content category)
  - AI Model Validation Report (precision, recall, false-positive rate per format-category and degradation level; published by Month 5 = 2027-03-12)
  - Privacy Review Panel Decision Log (decisions per item, rationale, inter-reviewer agreement metrics, systematic bias detection)
  - Content Accuracy Audit (5% monthly spot-check sample reviewed by secondary expert; Cohen's kappa or similar for agreement)

**Frequency:** Pilot Review Pod runs Months 6–8 (2027-04-12 to 2027-06-12), producing Phase 2 Gate Evidence by Month 20 (2028-06-12); thereafter monthly flagging-rate and accuracy audits through full programme

**Responsible Role:** Technical Committee (AI Lead); Privacy Review Panel; AI validation team; escalation to Programme Board if accuracy thresholds missed

**Adaptation Process:** Pilot Review Pod report (Month 8 = 2027-06-12) measures actual flagging rate and review hours per content hour against targets (<20% flagging, 1:2 ratio). If flagging is 25–30%, Technical Committee recommends AI model retraining or flagging-threshold adjustment; retraining consumes 2–4 weeks engineering and 1–2 weeks compute time. Results re-validated by Month 12 (2027-10-12). If retraining does not improve accuracy to >=75%, or if flagging remains >25% after retraining, Committee escalates to Board for workflow redesign (tiered review model: automated acceptance for Category A low-risk items, expert review for Category C high-risk, with escalation for disputes). If review hours exceed 1:2 ratio significantly (>0.5 hours per content hour), crew composition recalibrated: increase reviewers per unit from 12–15 to 20–25 and escalate payroll impact to Finance Committee for Phase 2 budget re-planning.

**Adaptation Trigger:** Pilot Review Pod flagging rate >25% (indicating AI pre-screen accuracy <75%); or measured review time per content hour >0.5 (instead of target <=0.5 for 1:2 ratio); or inter-reviewer agreement (Cohen's kappa) <0.6, indicating systematic bias or training gap. Any trigger at Month 8 (2027-06-12) must be remediated and re-validated before Phase 2 Gate (Month 24 = 2028-10-12).

### 4. Staffing Model and Budget Reconciliation Monitoring
**Monitoring Tools/Platforms:**

  - Monthly Cost and Variance Report (actual vs. budgeted capex, opex, contingency usage; cumulative variance per phase)
  - Quarterly Payroll Reconciliation Report (headcount per unit, salary actuals, benefits, travel/visa, loaded cost per staff member)
  - Funding Commitment Registry (committed vs. pledged funds per funder; payment schedule; at-risk funders)
  - Cost-at-Completion Forecast (per-phase projections, inflation impact, gap analysis vs. USD 250M cap)

**Frequency:** Monthly cost actuals and variance tracking; quarterly Cost and Variance Report to Board; headcount and payroll audit quarterly

**Responsible Role:** Finance Committee (CFO, controller, budget manager); escalation to Programme Board if cumulative variance >5% (monitor) or >10% (governance re-assessment)

**Adaptation Process:** Monthly cost actuals are reconciled against budget by Finance Committee. If cumulative variance is 5–10%, Finance Committee flags trend and recommends monitoring intensification; no immediate action. If cumulative variance exceeds 10% overspend, Finance Committee produces detailed variance analysis identifying root causes (cost escalation, scope creep, inefficient staffing, inflation) and recommends one of three Board decisions: (1) contingency draw (up to the phase-contingency reserve), (2) cost-control measures (crew right-sizing, logistics optimization, vendor renegotiation), or (3) scope reduction (defer or cancel lower-priority sites, reduce unit count). Board votes within 5 business days; decision documented in Board meeting minutes. Payroll reconciliation each quarter compares loaded costs (salary + benefits + travel) against the USD 2.5M per-unit-year opex assumption. If actual payroll exceeds USD 2.5M per unit per year by >5%, Finance Committee escalates to Programme Director for crew-composition review and Board decision on whether to right-size crews (reduce from stated 50–60 per unit to actual sustainable level) or increase opex budget allocation (which may require cost-sharing negotiation with hosts or new funder engagement).

**Adaptation Trigger:** Cumulative variance >5% per phase triggers enhanced monitoring (Finance Committee weekly check-ins); >10% cumulative overspend triggers Board governance re-assessment and authorization of cost-control action. Payroll exceeds USD 2.5M per unit-year by >5% sustained (2+ consecutive quarters) triggers crew-composition audit and Board decision on staffing adjustment. Phase 3 funding gap identified before Month 54 (2031-04-12) (6 months before Phase 3 gate) triggers activation of Contingency Funding Panel for emergency fundraising; if gap remains >USD 10M by Month 54 (2031-04-12), Board approves scope reduction (Phase 3 unit count reduced from 15 to 10–12) or timeline extension beyond Month 120 (2036-10-12).

### 5. Privacy, Copyright and Legal Compliance Gate Monitoring
**Monitoring Tools/Platforms:**

  - Privacy Review Panel Decision Log (decisions per flagged item, rationale, jurisdiction-specific legal basis, appeal outcomes)
  - Source Agreement Tracking System (multi-year residency agreements signed, custody terms, indemnity tier assignment, incident-notification contacts)
  - Jurisdiction-Specific Compliance Checklist (GDPR, UK DPA, national privacy laws, data-residency rules per planned site; status of jurisdiction-specific annexes)
  - Incident Response Log (privacy breaches, data-transfer violations, handling losses, regulatory inquiries; 24-hour notification register to insurers/regulators)

**Frequency:** Privacy Review Panel meets weekly during pilot (Months 6–8 = 2027-04-12 to 2027-06-12), monthly thereafter; monthly incident log review; quarterly compliance status report to Board

**Responsible Role:** Legal, Privacy & Compliance Committee (General Counsel, data-protection officer); Privacy Review Panel (2–3 rotating experts); escalation to Programme Board for major incidents or jurisdictional conflicts

**Adaptation Process:** Privacy Review Panel maintains a decision log documenting flagged-content decisions with rationale (personal data type identified, legal basis for handling, consent status, storage restrictions). Panel decisions are binding; disputes between reviewers escalated to full Committee for re-review or external legal mediation. Monthly Committee review identifies systematic patterns: if a specific content category shows consistently high flagging rate (e.g., >30% of items with handwritten metadata flagged as privacy-sensitive), Committee may recommend workflow adjustment (additional reviewer training, revised flagging criteria, or delegation to archive's own curatorial staff for jurisdiction-specific judgment). Incident response: any privacy breach (personal data leaked post-upload), data-transfer violation (content uploaded to central archive despite country data-residency prohibition), or handling loss (item destroyed during digitization) triggers 24-hour notification to insurers and regulator (per GDPR, UK DPA or national law requirements). Legal Committee activates incident-response team; Board informed immediately for major incidents (affecting >100 items, regulatory investigation, archive partnership at risk). Committee recommends containment, breach notification, remediation (policy change, system redesign, retraining), and relationship repair. Jurisdictional conflicts (archive's privacy attorney disagrees with programme's classification of an item as personal data) escalate to Board for policy guidance and external mediation (up to USD 25K per dispute).

**Adaptation Trigger:** Privacy Review Panel flagging rate systematically high (>25% of items flagged as sensitive); zero incidents required, but major incident (breach affecting >100 items, regulatory fine, archive termination threat) immediately escalates to Board. Jurisdictional rule change or case law affecting data-transfer rules (e.g., new EU court ruling on GDPR transfers) triggers re-assessment of data-residency compliance architecture and potential workflow redesign. New source agreement required with any archive not yet signed (target all agreements signed by Month 6 = 2027-04-12 for pilots, Month 28 = 2029-02-12 for Phase 2 first-wave sites).

### 6. Fire Safety, Hazmat and Host Insurer Approval Tracking (On-Site Handling Risk Monitoring)
**Monitoring Tools/Platforms:**

  - Site Readiness Scorecard (per-archive power, fire authority, insurer, facility, security status; tracks 90%+ readiness gate before unit dispatch)
  - Pre-Treatment Hazard Control Compliance Checklist (oven insulation, VOC monitoring, fire suppression, respiratory protection, occupational health assessments)
  - Insurer and Fire-Authority Approval Letters (written pre-approval per site; conditional approvals flagged for remediation)
  - Incident and Near-Miss Log (handling losses, fire-safety violations, VOC exposure events; 24-hour incident notification to insurers)

**Frequency:** Site Readiness Scorecard updated quarterly during site-prep phase (6 months pre-arrival); fire-authority and insurer approval obtained by Month 6 (2027-04-12) for pilots, by Month 28 (2029-02-12) for Phase 2 first-wave; monthly incident log review

**Responsible Role:** Site Selection Committee (Host-Site Manager); Legal Committee (occupational safety officer); escalation to Programme Board if site fails readiness gate or incident occurs

**Adaptation Process:** Site Selection Committee conducts power-quality audit, fire-authority pre-consultation, and insurer pre-notification 6 months before scheduled unit arrival. Results captured in Site Readiness Scorecard tracking progress on power stability, hardstand preparation, security, staff liaison confirmation. If scorecard shows <90% readiness 3 months pre-arrival, Committee escalates to Board decision: (1) proceed with conditional approval and remediation plan (e.g., install voltage regulator, finalize fire-authority paperwork), or (2) defer unit by 3–6 months and promote backup site from Priority Waitlist. Fire-authority and insurer written approvals required before unit dispatch; if conditional approval is received (e.g., insurer requires detached pre-treatment pod, fire authority requires additional ventilation), Technical Committee assesses retrofit cost (USD 0.5–1.5M for detached pod) and schedule impact (+4–6 weeks); Board approves retrofit if justified or defers site. Occupational safety: VOC monitoring and respiratory-protection audits at unit site monthly during residency; air-quality results reviewed by occupational health officer; if VOC concentrations exceed threshold (per industrial hygiene standard), unit operations halt until ventilation is improved or work protocols are redesigned. Incident log tracked monthly; any handling loss (item destroyed during processing) reported to insurer within 24 hours and recorded in incident log; pattern of losses triggers review of handling procedures and crew retraining.

**Adaptation Trigger:** Site Readiness Scorecard <90% three months before scheduled arrival triggers Board decision (defer or remediate). Fire-authority or insurer refusal of pre-approval unless design modified (e.g., detached pod required) escalates to Board; approval of detached pod retrofit and budget (USD 0.5–1.5M each) must be pre-authorized. VOC or occupational-health violation during residency (exposure exceeding threshold, respiratory protection non-compliance) halts unit operations until corrected; Board informed within 24 hours. Handling loss incident (item destroyed, estimated value >USD 100K, or unique/irreplaceable) triggers incident response and insurer notification; pattern of losses (>1 per unit per year) triggers remedial Board decision (crew retraining, handling-protocol redesign, or reduced digitization tempo).

### 7. Pilot-to-Phase-Transition Gate Monitoring and Evidence Consolidation
**Monitoring Tools/Platforms:**

  - Phase 2 Gate Evidence Report (Month 20 = 2028-06-12: consolidates all pilot metrics against gate criteria—digitization success >95%, reconstruction accuracy >80%, AI accuracy >75%, flagging <20%, uptime >90%, AI precision/recall >=75%, zero incidents)
  - Phase 2 Gate Financial Readiness Report (Month 24 = 2028-10-12: Phase 1 variance <=10%, Phase 2 funding >=70% committed, contingency and reserves status, Phase 3 gap identified)
  - Design Review Gate Sign-Off (Month 20 = 2028-06-12: external reviewer certification that all designs meet performance and safety thresholds; post-freeze change-control procedures locked)
  - Parts-Depletion and Mentoring Progress Report (Month 20 = 2028-06-12: spares trajectory shows feasible management; retired-engineer curriculum >80% complete; successor competency assessments on schedule)

**Frequency:** Evidence consolidated by Month 20 (2028-06-12) for Phase 2 Gate; final evidence package reviewed at Month 24 (2028-10-12) Board gate-release meeting; same cadence for Phase 3 Gate at Months 48 (2030-10-12) and Phase 3 release at Month 60 (2031-10-12)

**Responsible Role:** Technical Committee (consolidates pilot evidence); Finance Committee (financial readiness); Programme Board (gate-release decision)

**Adaptation Process:** By Month 20 (2028-06-12), Technical Committee produces Phase 2 Gate Evidence Report comparing all pilot metrics against agreed gate criteria. Report rated traffic-light: all thresholds met = green (proceed to full Phase 2 release); >=80% of thresholds met = yellow (conditional limited tranche, with Board-approved rework and re-validation); <80% or critical threshold missed = red (governance re-assessment: potential phase deferral, scope reduction, or design rework). Finance Committee independently assesses Phase 2 financial readiness: Phase 1 variance <=10%?, Phase 2 funding >=70% committed?, contingency intact?. By Month 24 (2028-10-12), Programme Board convenes gate-release meeting. If both Technical and Financial reports are green, Board votes to approve full Phase 2 release (authorization to drawdown full USD 120M). If reports are yellow, Board votes to approve conditional limited tranche (e.g., USD 30–50M for 4–6 units) with Board-mandated rework (e.g., AI retraining, crew redesign) and Phase 2B gate at Month 30–32 (2029-04-12 to 2029-06-12) for full tranche release. If reports are red, Board triggers governance re-assessment: defer Phase 2 start (e.g., to Month 30 = 2029-04-12), reduce unit count from 12 to 8–10, reduce budget by USD 20–40M, or extend timeline to spread costs.

**Adaptation Trigger:** Gate Evidence Report traffic-light: green (proceed), yellow (conditional), or red (re-assessment). Specific triggers: any critical metric <threshold (digitization <95%, reconstruction <80%, uptime <90%, zero incidents not achieved); or cumulatively <80% of targets met. Design freeze not signed off = automatic red. Phase 2 funding <70% committed by Month 24 (2028-10-12) = automatic financial red, activating Contingency Funding Panel.