# Governance Audit


## Audit - Corruption Risks

- Kickbacks or favoritism in vintage equipment acquisition: procurement of 300-500 decommissioned decks and scanners from eBay, auctions and direct sales involves informal sourcing where undisclosed payments or preferential vendor selection could inflate equipment costs or reduce quality, particularly where equipment condition is hard to verify remotely and retired engineers recommend suppliers.
- Nepotism or favoritism in reviewer and crew recruitment: selection of 12-15 multilingual reviewers per unit and 50-60 total staff per active MIU across 30 sites creates opportunity for preferential hiring of relatives or associates, particularly where language and expertise requirements allow subjective justification of unqualified candidates.
- Conflict of interest in AI model validation and pre-screening decisions: internal teams developing and validating the AI pre-screening pipeline may have incentive to overstate accuracy (>75% precision/recall) to avoid expensive model retraining or workforce expansion; lack of independent validation creates risk of systematic bias favoring low-flagging thresholds that underdetect privacy or copyright violations.
- Misuse of on-board storage and data access: on-board 500TB storage buffers at each unit could be accessed for unauthorized data export, training-data extraction, or copying of sensitive archival content to external parties before upload controls are enforced, particularly if unit crews have unrestricted access and centralized monitoring is weak.
- Bribery of fire authorities or insurance representatives: site permitting and hazmat approval from local fire authorities and insurance inspectors creates opportunity for facilitation payments or undisclosed inducements to accelerate approval timelines or waive hazard-control requirements, particularly in under-resourced jurisdictions where inspection standards are inconsistent.
- Theft or diversion of vintage equipment and parts inventory: 300-500 acquired vintage machines plus on-site parts warehouse create high-value physical assets vulnerable to theft, unauthorized sale or cannibalization for personal gain, particularly during storage, transport between sites or handling by maintenance crews with access to parts stock.

## Audit - Misallocation Risks

- Budget overruns on vintage equipment acquisition: procurement of 300-500 decommissioned decks and scanners allocated USD 20M may face cost inflation if equipment condition is worse than expected or if redundancy purchasing inflates inventory beyond planned 300-500 units, consuming unbudgeted spares from Phase 2 or Phase 3 allocations.
- Inefficient or duplicative parts inventory management: lack of real-time parts-consumption telemetry and inventory dashboard could result in over-purchasing of some components (excess stock consuming warehouse space and capital) while critical parts remain depleted, causing unit downtime and inefficient spares utilization across 30 sites.
- Misalignment of crew size and operational budget: stated 50-60 staff per unit (USD 2.5-4.2M payroll per unit-year) does not reconcile with USD 2-3M total opex per unit; actual payroll at lower effective crew sizes (~25 per unit) leaves unaccounted-for labour costs or understaffing that reduces quality and throughput.
- Inefficient reviewer and legal review workflow: if actual content flagging for human review exceeds 20% (estimate: 25-35% likely), review hours per unit could consume 400-600 hours per 1,000 hours of content instead of budgeted 200 hours, forcing either understaffing (quality loss) or unbudgeted reviewer expansion (USD 15-25M annually at full scale).
- Uncontrolled AI model retraining and compute costs: iterative retraining of pre-screening and reconstruction models on unanticipated content categories (non-English speech, multilingual handwritten metadata, extreme degradation) could consume unbudgeted engineering time and cloud-compute resources, particularly if triggered late in Phase 1 or Phase 2 after initial budgets are exhausted.
- Double-charging or misreporting of Phase-transition costs: migration of units between sites involves relocation logistics, temporary storage and customs clearance costing USD 5-10K per border crossing; unclear cost allocation could result in charging the same crossing cost to multiple phases or to both programme and host budgets without deduplication.

## Audit - Procedures

- Quarterly reconciliation of budget and staffing actuals against plan: at Months 3, 6, 9, 12 (2027-01-12, 2027-04-12, 2027-07-12, 2027-10-12) and quarterly thereafter, audit cumulative spend across capex (MIU retrofit, equipment acquisition, training), opex (payroll, utilities, logistics, consumables) and contingency draw, comparing to phase budgets; flag variance >10% overspend or under-utilization of budgeted line items for governance re-assessment.
- Equipment acquisition and parts inventory audit: at Month 4 (2027-02-12) and every 6 months thereafter, verify that all 300-500 acquired vintage machines are physically inventoried, tagged with condition and parts-yield assessments, and reconciled against procurement records; conduct a forensic parts-consumption analysis comparing budgeted vs. actual depletion rates per deck type and identify suppliers, unit costs and any duplicate or unauthorized purchases.
- Crew composition and payroll verification: audit staffing rosters monthly at each active MIU against signed contracts and approved headcount authorizations; verify that 12-15 reviewers per unit and total 50-60 staff per MIU are on payroll (not volunteers or undeclared contingent labour), that salaries match published scales (USD 50-70K range), and that no individuals are double-counted across multiple sites; cross-check reviewer qualifications (language certification, legal training) against hiring criteria.
- AI model validation and pre-screening accuracy testing: at Month 4 (2027-02-12), Month 8 (2027-06-12) and every 3 months during pilots, audit AI model performance by testing on curated representative samples (100-200 items per archive) and measuring precision, recall and false-positive rate per format and degradation level; if accuracy falls below 75%, require documented retraining plan and re-test; maintain a Living Leaderboard of model performance per site.
- Site-readiness and hazmat compliance inspection: before each MIU deployment, conduct pre-arrival audit of host site verifying: fire-authority written approval of pre-treatment hazards, insurer coverage and any exclusions, power stability (voltage, frequency, harmonic content) and generator sizing, climate control adequacy (temperature, humidity range), security perimeter and access controls, and OSHA/environmental hazmat handling protocols; document all findings in a Site Readiness Scorecard.
- Review bottleneck and flagging-rate sampling: audit human review workflow monthly by sampling flagged and non-flagged content (5% of monthly intake) and measuring actual review hours per content hour; track flagging percentage by category (copyright, privacy, classification) and format; if actual review load exceeds 0.25 hours per content hour (1:4 ratio), trigger retraining or workflow redesign and recalibrate crew projections.

## Audit - Transparency Measures

- Quarterly budget and variance dashboard: publish monthly or quarterly reports to Programme Board and funders detailing cumulative spend (capex, opex, contingency), variance from phase budget, projected cost at completion for each phase, and confidence range; identify cost drivers and early-warning indicators (e.g., parts-depletion acceleration, reviewer hours exceeding plan); include inflation-adjusted scenarios (2%, 3%, 4% annual rates).
- Published pilot metrics and gate-decision evidence: at Month 20 (2028-06-12) and before Phase 2 release at Month 24 (2028-10-12), publish audited pilot results against all gate criteria (digitization success >95%, reconstruction accuracy >80%, metadata accuracy >70%, human review <20%, uptime >90%, AI precision/recall >75%, zero incidents) broken down by line type, archive site and content category; include methodology, sample sizes and any outliers; clearly distinguish pass/fail outcomes.
- Equipment and parts inventory registry: maintain and publish quarterly (or upon request) a detailed register of the 300-500 vintage machines acquired, including serial number, condition assessment, parts yield, location (in-warehouse, deployed unit, retired), acquisition date, purchase cost and depreciation; track parts consumption per unit per month and publish forward-looking depletion projections; identify any equipment or parts transfers between units or sites.
- Site-readiness and compliance matrix: publish a master table listing all planned host archives with readiness status (fire-authority approval date, insurer coverage tier, power audit status, climate readiness, access controls signed-off, hazmat protocols approved); update quarterly; clearly mark any site with conditional or deferred approval and include remediation timelines.
- AI model and review-workflow performance leaderboard: publish monthly dashboard showing per-site model performance (precision, recall, false-positive rate by content category), flagging rates and trends, actual review hours per content hour, reviewer turnover, and accuracy variance from baseline; flag any site or model version performing >5 percentage points below fleet average and identify root cause.
- Governance meeting minutes and decision log: publish (or make available to committed funders and partner archives) meeting minutes from Programme Board and key committees (Site Selection, Technical, Legal/Privacy, Finance) within 4 weeks of each meeting, including decision topics, alternatives considered, rationale, any dissenting views, and assignment of action items; maintain a decision-precedent log clarifying how similar disputes are resolved.

# Internal Governance Bodies

### 1. Programme Board (Strategic Oversight)

**Rationale for Inclusion:** A USD 250M, 10-year, 30-unit global infrastructure programme with 15+ funders, 30+ partner archives, and concentrated risks (vintage hardware scarcity, unvalidated AI assumptions, handling-loss exposure, phased funding on annual cycles) requires executive-level strategic oversight. The Programme Board approves phase releases, resolves funder and archive conflicts, authorizes variance above 10% and gates major decisions (site selection triage, vendor selections, legal indemnity structures, end-state transitions). Without executive governance, routine escalations fragment and funder confidence erodes.

**Responsibilities:**

- Approve Phase 2 and Phase 3 funding releases based on gate evidence (digitization success >95%, uptime >90%, AI accuracy >75%, zero incidents)
- Authorize budget variance, contingency draws and scope changes exceeding USD 5M or affecting unit counts or staffing
- Resolve conflicts between funders, archives and programme staff on site prioritization, indemnity terms and legal/privacy disputes
- Oversee risk register and approve mitigation add-ons or fallback scenarios (detached pods, design rework, stockpile refresh)
- Monitor cost and schedule variance quarterly; escalate >10% variance to governance re-assessment
- Approve source agreements, indemnity tiers and privacy frameworks; delegate to Legal/Privacy Committee for jurisdiction-specific details
- Review and approve pilot gate criteria by Month 6 (2027-04-12) and published gate-decision evidence before phase releases
- Approve end-state plan (unit transfers, parts inventory dispersal, knowledge base stewardship) by Month 36 (2029-10-12)
- Establish and charter all subsidiary committees (Technical, Site Selection, Legal/Privacy, Finance); define escalation paths

**Initial Setup Actions:**

- Establish Board membership: 8-10 representatives from committed funders, 3-4 partner archives (pilot and Phase 2), programme director, chief technical officer, legal counsel
- Publish and agree decision-authority charter: define which decisions require full Board consensus, which delegate to committees or staff, and escalation criteria
- Schedule monthly meetings Month 1-6 (2026-11-12 to 2027-04-12); quarterly thereafter; maintain written decision log and meeting minutes
- Appoint committee chairs by Month 1 (2026-11-12): Technical Committee, Site Selection & Triage, Legal/Privacy & Compliance, Finance & Variance
- Commission independent cost audit, parts-depletion model and legal mapping by Month 1-2 (2026-11-12 to 2026-12-12)

**Membership:**

- Programme Director (Chair)
- Chief Technical Officer / Engineering Lead
- Chief Legal Officer / Data Protection Lead
- Chief Financial Officer or Finance Lead
- Representative of committed government archive funder
- Representative of committed philanthropic funder
- 2-3 partner archive directors (pilot sites)
- Independent external advisor (heritage infrastructure or conservation expertise, no financial interest)

**Decision Rights:** The Board holds all strategic decisions affecting programme scope, timeline, budget allocation above USD 5M, phase gates, funder and archive conflicts, legal/privacy frameworks, vendor selection for capex >USD 10M, risk escalations and end-state planning. Operational decisions (daily scheduling, crew allocation, site logistics) delegate to committees and programme staff. Gate releases require Board approval with 70%+ committed funding (not pledged) in place; gate variance below 10% and all thresholds met allow release; variance 10-20% or <1 threshold missed allows conditional limited tranche with governance approval; variance >20% or >1 critical threshold missed triggers governance re-assessment (potential phase deferral). Financial authority: approve cumulative budget draws per phase (Phase 1 up to USD 60M, Phase 2 up to USD 120M, etc.); approve contingency draws beyond 10% per phase; approve add-on mitigation spending up to USD 10M per proposal.

**Decision Mechanism:** Consensus-seeking on policy decisions; simple majority (6+ of 8-10) on routine approvals and escalations. Tie-breaker: Programme Director casts deciding vote (or escalates to funder steering group if Programme Director vote is recused). Dissenting Board members may request written rationale and alternative options preserved in decision log. Gate releases require explicit Board sign-off (not delegation); no default approval. Decisions requiring <24-hour turnaround (site emergencies, personnel changes) escalated to Board officers (Director, CFO, General Counsel) with full Board ratification within 5 business days.

**Meeting Cadence:** Monthly meetings Month 1-6 (2026-11-12 to 2027-04-12) during pilot mobilization; quarterly (every 3 months) thereafter through Month 120 (2036-10-12). Additional ad-hoc sessions called by Director or request of 3 Board members within 48 hours for urgent escalations. Standing agenda: cost variance and budget reconciliation, phase-gate evidence review, risk register updates, committee reports, funder and archive stakeholder issues, governance decisions and decision log.

**Typical Agenda Items:**

- Monthly/quarterly cost and schedule variance against budget (actuals vs. plan, forecast at completion, confidence range, inflation impact)
- Pilot metrics and gate-decision evidence (digitization success, reconstruction accuracy, human review flagging rate, uptime, AI precision/recall, zero-incident status)
- Equipment and parts-inventory status (depletion curves, re-manufacture triggers, retired-engineer mentorship progress, expertise-transfer curriculum)
- Risk register review: any risks escalated from Technical or Finance committees, threshold breaches, trigger activations
- Site-readiness and archive-engagement updates (fire authority and insurer approvals, signed agreements, triage-driven scheduling, queue management)
- Legal, privacy and compliance status (source agreements signed, jurisdiction-specific frameworks approved, privacy-review panel decisions, data residency conflicts)
- Funder and stakeholder escalations (conflicting prioritizations, cost-share negotiations, Phase 2/3 commitment status, governance requests)
- Phase-gate decision topics (proposed release criteria, evidence completeness, go/no-go recommendation from Technical and Finance committees)

**Escalation Path:** Decisions requiring recusal (e.g., funder representative voting on their own funder terms) escalate to a Funder Steering Committee (representatives of non-recused funders) to re-adjudicate; final authority rests with Funder Steering Committee or a neutral external arbitrator if stakes exceed USD 10M. Decisions affecting source agreements or privacy compliance escalate to Legal/Privacy Committee for jurisdictional analysis and only return to Board if Committee is deadlocked or outcome affects >3 archives. Decisions affecting equipment design or pilot gates escalate to Technical Committee; Board may overrule Committee only with 80%+ supermajority (7 of 8-10). Unresolved funder conflicts may trigger external mediation funded by the programme (up to USD 100K per incident).
### 2. Technical Committee (Operational & Design Assurance)

**Rationale for Inclusion:** The programme depends on three distinct container line types, pre-treatment hazards (baking, humidity), robotics, AI signal processing, vintage equipment sustainment and multi-site reliability. Unvalidated design assumptions (>95% digitization success, >80% reconstruction accuracy, >75% AI pre-screen precision/recall, >90% uptime) must be tested in pilots before Phase 2 replication. A dedicated Technical Committee oversees design freeze by Month 20 (2028-06-12), pilot validation and gate readiness. It owns the parts-depletion model, equipment refresh strategy and remote-diagnostics architecture. Critical design flaws discovered post-freeze (e.g., thermal management inadequate for hot climates, robotic arm tolerance drift) could force USD 2-5M rework and 6-9 month delays if not caught early.

**Responsibilities:**

- Oversee design of all three MIU line types (Tape, Film, Card/Disk) and subsystems (climate, power, robotics, AI, on-board storage, connectivity)
- Commission and review independent technical assessments (thermal, mechanical, electrical, AI validation) on pilot units by Month 8-12 (2027-06-12 to 2027-10-12)
- Manage Design Review Gate (DRG) process: freeze all designs by Month 20 (2028-06-12); any post-freeze changes require board approval and impact analysis
- Oversee parts-depletion modeling and spares-fabrication program; validate 3D-printing and CNC machining capability on 20+ critical parts by Month 6 (2027-04-12)
- Manage retired-engineer mentoring program: track curriculum completeness, mentee competency assessments, knowledge-transfer documentation
- Establish and operate central fleet-management telemetry and remote-diagnostics system; set uptime targets and alarm thresholds; monitor actual uptime monthly
- Test AI pre-screening and signal-reconstruction models on 100-200 real degraded samples per archive before deployment; validate precision/recall >=75% per format-category
- Oversee pilot-unit stress testing at worst-condition collection; document failure modes and root causes
- Recommend Phase 2 and Phase 3 gate outcomes to Programme Board based on pilot evidence against all technical thresholds

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief technical officer (chair), hardware engineer (tape/film/card specialist), roboticist, AI systems lead, parts and maintenance lead
- Publish preliminary design specifications for all three line types by Month 2 (2026-12-12); commission external review (e.g., university or broadcast-engineering consultant) by Month 3 (2027-01-12)
- Establish DRG process document by Month 2 (2026-12-12): criteria for sign-off, escalation triggers, change-control procedures
- Commission parts-depletion model and feasibility study by Month 2 (2026-12-12); publish preliminary results by Month 4 (2027-02-12)
- Identify and secure commitments from 6-8 retired engineers for mentoring by Month 1 (2026-11-12); begin curriculum development by Month 2 (2026-12-12)
- Procure test samples (100-200 items) from proposed pilot archives by Month 2 (2026-12-12); establish gold-standard labeling and AI test protocol by Month 3 (2027-01-12)

**Membership:**

- Chief Technical Officer (Chair)
- Audiovisual Digitization Engineering Lead (tape/film/card specialist with broadcast or archival background)
- Vintage Equipment Maintenance Engineer (experienced with tape decks and film scanners)
- Robotics and Automation Specialist
- AI / Signal Processing Lead (with experience on degraded audio/video content)
- Digital Infrastructure and Storage Specialist
- Independent external technical expert (broadcast engineering, media preservation or mobile-infrastructure background, non-staff)
- Representative of retired-engineer mentoring pool (one senior mentor, rotating)

**Decision Rights:** The Committee holds all technical design approvals up to the DRG freeze (Month 20 = 2028-06-12), including subsystem architecture, component selection, manufacturing tolerances and performance targets. After freeze, only Programme Board may approve design changes (impacts escalated). The Committee sets technical gate criteria (thresholds for uptime, reconstruction accuracy, AI performance) and validates pilot evidence against those criteria; Committee recommends go/no-go to Board but does not unilaterally release phases. The Committee approves procurement of equipment, robotics, AI systems and test samples up to USD 2M; larger procurements require Board approval. The Committee may require design rework or pilot re-runs if evidence is incomplete; Committee may recommend budget add-ons for design contingency (up to USD 5M Design Contingency Pool) or risk mitigation (detached pods, additional testing, stress scenarios). Parts and maintenance decisions (fabrication priorities, re-manufacture triggers, mentor curriculum) rest with Committee unless costs exceed USD 1M or affect phase gates.

**Decision Mechanism:** Consensus-seeking on design choices and technical thresholds. Simple majority (5 of 7-8) on routine technical approvals and test-result interpretations. Tie-breaker: Chief Technical Officer votes to break ties. Design Review Gate decisions (freeze approval) require unanimous sign-off from CTO, hardware lead and external expert; any dissent triggers additional review or Board escalation. Post-freeze change-control decisions require 80%+ Committee agreement and Board approval. AI and metadata accuracy validation requires agreement of AI Lead and at least one independent validator (external expert or archive representative). Uptime and reliability decisions require agreement of Maintenance Lead and remote-diagnostics system operator.

**Meeting Cadence:** Bi-weekly meetings Month 0-6 (2026-10-12 to 2027-04-12, pilot mobilization); weekly Months 6-20 (2027-04-12 to 2028-06-12, pilot operations and DRG process); monthly thereafter through pilot completion (Month 24 = 2028-10-12); quarterly during Phase 2 and 3 operations. Additional daily standups or ad-hoc meetings during pilot and design-crisis periods (e.g., if uptime drops below 85% or a critical component fails).

**Typical Agenda Items:**

- Design specification review (line-type architecture, subsystem design, component selection, manufacturing and assembly)
- Design Review Gate progress (design-review checklist completion, external review status, freeze readiness)
- Pilot unit status (retrofit progress, equipment integration, pre-deployment testing, issues and rework)
- Pilot operations metrics (uptime, mean time between failures, error rates per subsystem, field failures and root-cause analysis)
- Parts-depletion model and spares planning (consumption curve, re-manufacture schedule, fabrication priority, inventory status)
- Retired-engineer mentoring and knowledge-transfer progress (curriculum modules completed, mentee competencies, expertise retention)
- AI model validation (test-sample results, precision/recall per format-category, retraining needs, deployment readiness)
- Remote-diagnostics and fleet-management system (telemetry completeness, alarm threshold calibration, central-support staffing and response times)
- Post-pilot design-change requests and rework priorities (impact analysis, cost, schedule delay, Board escalation if needed)

**Escalation Path:** Design disagreements requiring >2 weeks of Committee deliberation escalate to Programme Board for strategic decision or external arbitration (hire independent consultant for binding technical opinion, cost up to USD 50K per dispute). Any design change discovered post-freeze escalates directly to Board. Critical field failures (uptime <90%, reconstruction accuracy <75%, AI precision/recall <70%) trigger urgent Committee session within 48 hours and formal root-cause analysis; if failure is due to design flaw, escalate to Board with remediation plan and cost estimate. If parts-depletion modeling shows infeasible spares trajectory (depletion outpacing fabrication capacity by >20% margin), escalate to Board as a risk trigger for Phase 2/3 go/no-go reassessment. Unresolved mentor availability or curriculum gaps escalate to Board as a feasibility warning.
### 3. Site Selection, Triage & Archive Engagement Committee (Operational & Stakeholder Management)

**Rationale for Inclusion:** The programme schedules 30+ archive residencies over 10 years, each requiring months of pre-positioning, approvals and coordination. Site selection depends on the Triage Doctrine decision (condition-first vs. value-first vs. survey-based) and the Host-Site Power and Readiness Compact (who supplies what). Poor scheduling cascades delays: if each site is 2 weeks late on average across 30 residencies, the aggregate loss is 60 weeks (14 months), shrinking delivered capacity by 10-15%. Transparent triage criteria protect archive trust; under-resourced institutions must not be systematically deprioritized. A dedicated Site Selection Committee owns queue management, readiness verification, host-relationship maintenance and dispute resolution.

**Responsibilities:**

- Develop and publish Triage Doctrine: define criteria for site prioritization (condition-degradation scoring, format-vulnerability ranking, research value, archival resources), trade-offs (endangered media vs. high-value collections), and rotation rules
- Maintain Master Schedule and Queue Management System: 5-year rolling forecast of site assignments, residency windows, unit assignments and contingency buffers; update quarterly
- Manage Site-Readiness Workstream: conduct pre-arrival readiness audits (fire-authority approval, insurer coverage, power quality, climate stability, security, staff liaison); track progress on Site Readiness Scorecard; enforce 90% readiness gate before unit dispatch
- Lead archive-engagement and stakeholder relationships: sign multi-year residency agreements (2-3 years, with termination clauses); facilitate funder-archive connections; manage cost-sharing negotiations; resolve prioritization disputes
- Maintain Priority Waitlist of backup sites and surge-buffer contingency (1-2 units in temporary parking) to absorb schedule slips and site withdrawals
- Track archive feedback and lessons-learned; feed insights to Programme Board on equipment performance, crew quality, collection-specific challenges
- Coordinate with Triage, Host Power and Readiness Compact, and Custody decisions: translate triage output into scheduled sites; implement tiered host contributions if adopted
- Escalate site-readiness blockers (fire-authority refusal, insurer exclusions, power instability, security gaps) to Programme Board for remediation or site deferral

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with programme director or head of operations (chair), 2-3 senior archive liaisons, logistics coordinator, host-site manager
- Publish draft Triage Doctrine by Month 3 (2027-01-12); conduct stakeholder workshop with funders and archives to gather input by Month 4 (2027-02-12); finalize by Month 6 (2027-04-12)
- Identify and secure agreements from 3 pilot archives by Month 6 (2027-04-12); identify 15+ Phase 2 archive candidates and begin readiness pre-work by Month 6 (2027-04-12)
- Establish Site-Readiness Workstream with dedicated logistics specialists by Month 2 (2026-12-12); develop and publish Site Readiness Scorecard template by Month 3 (2027-01-12)
- Build Master Schedule and Queue Management System (can be a spreadsheet or dedicated scheduling tool) by Month 4 (2027-02-12); include contingency buffers and surge-pool logic
- Establish Priority Waitlist and surge-buffer guidelines by Month 4 (2027-02-12)

**Membership:**

- Head of Operations or Programme Director (Chair)
- 2-3 Senior Archive Liaisons (deep relationships with major archives; one per geographic region: North America, Europe, etc.)
- Logistics Coordinator / Container Relocation Manager (coordinates trucking, customs, temporary storage)
- Host-Site Manager / Facilities Liaison (leads on-site power, security, space and staff-liaison management)
- Representative from Triage and Host-Readiness working group (ensures linkage to upstream decisions)
- Finance or Budget Liaison (tracks cost-sharing and host contributions; monitors schedule delays' cost impact)

**Decision Rights:** The Committee sets the Triage Doctrine (with Board approval) and interprets it to assign sites to the queue; the Committee prioritizes sites based on published triage criteria and notifies all archives of their scheduled window at least 12 months in advance. The Committee approves site-readiness audits and enforces the 90% gate (sites <90% ready are deferred by 3-6 months or moved down the queue). The Committee negotiates and signs multi-year host agreements (up to 3 years, with terms within Board-approved indemnity and cost-share policy); agreements requiring >USD 2M cost-sharing or non-standard terms escalate to Board. The Committee maintains the Priority Waitlist and can swap a lower-priority site with a higher-priority backup if the scheduled site becomes unavailable or fails readiness gate (decision valid if the change does not affect Board-approved phase-unit count or schedule by >2 months). The Committee owns internal dispute resolution for disputes over triage interpretation or site scheduling; escalations go to Board only if a funder or archive is not satisfied with Committee decision.

**Decision Mechanism:** Consensus-seeking on Triage Doctrine and site assignments. Simple majority (4 of 5-6) on routine scheduling decisions and readiness-gate applications. Tie-breaker: Head of Operations casts deciding vote. Triage Doctrine approval requires Board sanction before finalization. Site prioritization disagreements (e.g., two archives equally urgent, but only one can be scheduled in the same quarter) resolved by published triage criteria first; if criteria are tied, escalate to Board for policy guidance. Site-readiness gate decisions (ready to proceed, conditional proceed, or defer) require agreement of Host-Site Manager and Logistics Coordinator; disagreements between them escalate to Chair for mediation. Cost-sharing negotiations above Board-approved limits require Board amendment.

**Meeting Cadence:** Monthly meetings Month 1-24 (2026-11-12 to 2028-10-12, pilot and Phase 2 ramp); quarterly during Phase 2 and 3 operations. Ad-hoc meetings called by Chair or request of 2 members for urgent site-readiness issues or schedule conflicts.

**Typical Agenda Items:**

- Triage Doctrine interpretation and site-prioritization decisions (which sites in the queue, readiness status, flagged issues)
- Master Schedule review (planned residencies for next 12 months, contingency buffers, surge-pool status, any planned deferrals)
- Site-readiness status updates (fire-authority approval progress, insurer coverage, power audit results, security sign-offs, staff liaison confirmations)
- Archive agreements and negotiations (cost-sharing terms, multi-year commitments, indemnity and consent wording)
- Funder and archive feedback on pilot residencies (lessons learned, equipment performance, crew quality, collection challenges, recommendations)
- Lessons-learned from site visits and relocation logistics (schedule slips, cost overruns, unexpected facility needs, recommendations for future sites)
- Priority Waitlist and surge-buffer contingency (are backup sites ready if a planned site withdraws or fails readiness?)
- Escalations to Programme Board (readiness blockers, site prioritization disputes, cost overruns, phase-schedule impacts)

**Escalation Path:** Site-readiness disagreements (fire authority or insurer refuses approval despite hazard-control design) escalate to Programme Board, which may authorize fallback options (detached pre-treatment pod, site deferral, external consulting to overcome objection). Archive relationship disputes (e.g., funder wants earlier priority than triage criteria warrant) escalate to Board for stakeholder decision. Schedule impacts >2 months due to site delays escalate to Board as a risk trigger affecting phase targets. Systematic triage criteria disagreement from stakeholders (e.g., archives collectively reject condition-first ordering) triggers a stakeholder workshop convened by Board to re-negotiate Triage Doctrine.
### 4. Legal, Privacy & Compliance Committee (Regulatory & Risk Assurance)

**Rationale for Inclusion:** The programme handles unique cultural artifacts and personal data across multiple jurisdictions (GDPR, UK DPA, national privacy laws, data-residency rules). A single privacy breach (leaked personal medical records or classified government content), a handling incident destroying unique media, or a data-transfer violation triggers regulatory fines (GDPR up to 4% of global revenue, estimated USD 5M-20M+), loss of archive partnerships and reputational damage. Pre-upload human review gates require clear legal authority, decision logs and indemnity terms. On-site residencies depend on fire-authority and insurer approval of hazmat and loss-of-item risks. A dedicated Legal/Privacy Committee develops binding source agreements, indemnity tiers, privacy-review protocols, jurisdiction-specific frameworks and incident-response procedures.

**Responsibilities:**

- Develop and maintain standardised source agreements and indemnity structures; create jurisdiction-specific annexes (GDPR, UK DPA, national data-protection laws); template updated quarterly as case law evolves
- Operate Privacy Review Panel (2-3 data-protection experts, rotating per jurisdiction) that reviews all flagged privacy content before archival upload; maintain decision log with rationale; establish appeal process for reviewer disagreements
- Conduct Privacy Impact Assessment (PIA) for each source agreement identifying presence and sensitivity of personal data, transfer restrictions, legal basis for processing and required consent; flag items exceeding acceptable risk tier
- Manage source-agreement signatures: ensure all agreements signed before unit arrives; track expiry and multi-year renewal; identify any archives reluctant to sign and escalate negotiation blockers to Board
- Develop and oversee incident-response protocols (24-hour insurer notification, privacy-breach handling, regulatory-notification requirements per jurisdiction); maintain incident log with outcomes
- Coordinate with Hazmat and Fire-Safety compliance: oversee occupational safety (VOC exposure limits, respiratory protection, hazmat handling), environmental permits and end-of-life disposal of vintage equipment
- Map data-residency rules per jurisdiction and design compliance architecture (federated vs. centralized storage); flag jurisdictions where data cannot be transferred to central archive without breach of law; propose solutions (in-country mirrors, restricted tiers)
- Manage copyright and classification review: establish criteria for identifying copyrighted, government-classified or sensitive content; train reviewers and archivists on flagging and decision-making
- Track regulatory updates and case law; re-assess compliance posture quarterly and recommend policy updates to Programme Board

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief legal officer (chair), data-protection specialist, copyright expert, occupational safety officer
- Commission legal mapping of all planned jurisdictions (GDPR, UK DPA, national laws, data-residency rules) by Month 1 (2026-11-12); publish summary by Month 2 (2026-12-12)
- Develop standardised source-agreement template and tiered indemnity structure by Month 2 (2026-12-12); obtain Board approval by Month 3 (2027-01-12)
- Establish Privacy Review Panel and publish decision criteria (what constitutes personal data, classification markers, copyrighted content) by Month 2 (2026-12-12); train reviewers by Month 4 (2027-02-12)
- Conduct Privacy Impact Assessment template and procedures by Month 2 (2026-12-12)
- Develop incident-response protocol and notification procedures by Month 2 (2026-12-12); brief all staff and archives by Month 6 (2027-04-12)
- Design data-residency compliance architecture (federated vs. centralized, in-country mirrors, restricted tiers) by Month 3 (2027-01-12); present options to Board by Month 4 (2027-02-12)

**Membership:**

- Chief Legal Officer / General Counsel (Chair)
- Data Protection Officer / Privacy Specialist (GDPR and privacy-law expert)
- Copyright and Intellectual Property Specialist
- Occupational Safety and Environmental Compliance Officer
- 2-3 Rotating Privacy Reviewers (multilingual, legal/archival background; one per major jurisdiction or language group)
- Representative from Programme Board or Archive partners (non-voting, for stakeholder perspective)

**Decision Rights:** The Committee develops and Board-approves all binding source-agreement templates, indemnity tiers, privacy-review criteria and incident-response procedures. The Committee maintains Privacy Review Panel and oversees all flagged-content decisions; Panel decisions are binding (no appeal except to full Committee if reviewer is in conflict). The Committee interprets compliance requirements per jurisdiction and publishes guidance; Programme Board must approve any deviations from template agreements (jurisdiction-specific terms, extended indemnity, restricted-data handling). The Committee can halt content upload if flagged privacy or copyright content fails review or if legal risk exceeds acceptable tier; halts escalate to Board if no resolution within 5 business days. The Committee approves workplace safety plans (VOC monitoring, respiratory protection, hazmat handling) and occupational health assessments; unsafe conditions halt unit operations until remedied. The Committee approves incident-response actions (insurer notification, privacy-breach notification, regulator engagement) and publishes incident outcomes (anonymized, to Programme Board and relevant archives). The Committee cannot modify Board-approved indemnity terms or cost-sharing without Board approval.

**Decision Mechanism:** Consensus-seeking on legal frameworks and policy decisions. Privacy Review Panel uses majority voting (2 of 3 reviewers) on flagged-content decisions; disagreements (1 reviewer dissents) escalated to full Committee for re-review or Board guidance. Simple majority (3 of 4-5 core Committee members) on routine compliance decisions and template updates. Tie-breaker: General Counsel votes to break ties. Incident-response decisions (whether to notify regulators, how to handle a breach) require agreement of General Counsel and Data Protection Officer at minimum; if escalated to Board, Board decides. Disagreements on jurisdiction-specific interpretation escalate to external legal counsel for binding opinion (cost up to USD 25K per dispute).

**Meeting Cadence:** Monthly meetings Month 0-12 (2026-10-12 to 2027-10-12, framework development and pilot site agreements); quarterly thereafter. Privacy Review Panel meets as needed (weekly during pilot if content flagging is high, monthly during Phase 2/3). Incident-response team available 24/7 for emergency notification.

**Typical Agenda Items:**

- Source-agreement status (signed agreements, pending signatures, jurisdictions with negotiation blockers, indemnity-tier disputes)
- Privacy Review Panel decisions and trends (flagging rate by content category and archive, appeal requests, systematic bias detection, retraining needs)
- Jurisdiction-specific compliance questions (data-residency rules, transfer restrictions, notification requirements, emerging case law or regulatory changes)
- Incident log and post-mortems (handling losses, privacy breaches, regulatory inquiries, response actions, preventive measures)
- Occupational safety and environmental compliance (VOC monitoring results, respiratory-protection audits, hazmat transport documentation, fire-authority inspections)
- Data-custody and archive-access compliance (federated storage design updates, in-country mirror status, restricted-tier enforcement)
- Copyright and classification criteria and reviewer training (new flagging categories, edge cases, reviewer accuracy validation)
- Regulatory landscape updates (new GDPR guidance, privacy-law changes, archival standards, case law affecting cultural heritage digitization)

**Escalation Path:** Privacy Review Panel disagreements escalate to full Committee; if unresolved, escalate to Board for policy guidance or external mediation. Incident-response escalations: minor incidents (isolated privacy flag, single item loss) handled by Committee with 24-hour Board notification; major incidents (data breach affecting >100 items, regulatory investigation, archive partnership termination risk) escalated immediately to Board and Programme Director with incident-response team activation. Data-residency conflicts (jurisdiction prohibits data transfer) escalate to Board for policy decision (in-country holding, federated architecture, collection deferral). Occupational safety issues (unsafe working conditions, non-compliance with fire or OSHA standards) are immediately halted and escalated to Board for remediation plan and timeline.
### 5. Finance & Variance Monitoring Committee (Financial Governance & Budget Control)

**Rationale for Inclusion:** The USD 250M budget over 10 years is tight: recomputed costs about USD 530M uncapped, forcing Phase 3 to operate on USD 70M vs. USD 301M need (estimate). Phased releases on annual cycles create cash-flow timing risk. Cost escalation (2-3% inflation annually = 20-30% cumulative by Month 120 = 2036-10-12) and recomputed payroll overruns (USD 36-54M annually at full scale vs. USD 25M budget) require active variance monitoring and contingency management. A dedicated Finance Committee tracks monthly actuals, forecasts completion costs, triggers contingency draws, and escalates budget gaps >10% to Board for scope or funding adjustment.

**Responsibilities:**

- Develop and maintain detailed cost accounting by phase and budget line (capex, opex, equipment, parts, training, contingency, inflation reserve, mitigation add-ons); reconcile monthly actuals against budget
- Produce monthly cost-variance reports (current spend, forecast at completion per phase, cumulative variance, confidence range); escalate variance >5% to leadership, >10% to Board
- Model and track inflation impact (baseline 2%, high-case 3%, extreme 4% annually); publish inflation-adjusted budget scenarios quarterly
- Manage contingency reserves (10% per phase = USD 6M/12M/7M = USD 25M total) and mitigation add-ons (Design Pool USD 5M, risk add-ons USD 16-28.5M estimate); approve draws up to USD 1M, escalate >USD 1M to Board
- Manage inflation escalation reserves (proposed 15% per phase = USD 9M/18M/10.5M = USD 37.5M); allocate as inflation materializes (cumulative 2-3% per year)
- Track funder commitments vs. pledges; maintain Commitment Registry showing which funds are binding multi-year contracts vs. annual allocations at risk; flag any funder pullbacks or delays
- Forecast Phase 2 and Phase 3 cash-flow timing; identify any 2-3 month working-capital gaps and approve revolving-credit line draws (up to USD 15-20M proposed threshold) to bridge
- Conduct quarterly reconciliation of staffing and payroll actuals (headcount per unit, salary scales, benefits, travel/visa) against planned opex; flag if actual costs exceed USD 2.5M per unit-year
- Produce quarterly Financial Health Report to Board: budget status, phase-gate financial readiness (are funds committed for next phase?), risk triggers, variance trend

**Initial Setup Actions:**

- Form committee by Month 1 (2026-11-12) with chief financial officer (chair), accountant/controller, programme budget manager, funder liaison
- Commission independent cost audit reconciling stated unit staffing, payroll and USD 250M budget by Month 1 (2026-11-12); publish reconciliation and recommendations by Month 3 (2027-01-12)
- Develop detailed budget model (capex, opex, contingency, inflation, mitigation) by Month 2 (2026-12-12); publish baseline and three inflation-scenario versions by Month 3 (2027-01-12)
- Establish monthly cost-accounting and variance-tracking system (spreadsheet or accounting software) by Month 2 (2026-12-12)
- Build Commitment Registry (funder commitments vs. pledges, payment schedules, conditions) by Month 2 (2026-12-12); target 50%+ Phase 1 committed by Month 3 (2027-01-12)
- Establish Contingency Management Framework by Month 2 (2026-12-12): which draws require Committee approval (up to USD 1M) vs. Board approval (>USD 1M), documentation requirements, drawdown log
- Lock Phase 1 budget and staffing by Month 4 (2027-02-12); lock Phase 2 by Month 20 (2028-06-12); lock Phase 3 by Month 54 (2031-04-12)

**Membership:**

- Chief Financial Officer (Chair)
- Accountant / Controller (monthly accounting, reconciliation, compliance)
- Programme Budget Manager (tracks costs per unit, per phase, per line item)
- Funder Liaison or Programme Director (context on funding commitments and policy decisions)
- Representative from Programme Board or Independent Finance Auditor (external oversight, no financial interest in programme outcomes)

**Decision Rights:** The Committee approves all monthly and quarterly budget reconciliations and variance reports; reports go to Programme Board without Committee veto. The Committee approves contingency draws up to USD 1M; draws above USD 1M require Board approval. The Committee approves inflation-reserve allocation as inflation accrues (tracked quarterly against 2%/3%/4% scenarios). The Committee can recommend phase-gate delays if committed funding for the next phase is <70% by 3 months before the scheduled gate; recommendation escalates to Board for decision. The Committee cannot approve scope changes (reduce units, eliminate line items) but can flag which changes would fit the budget; scope decisions rest with Board. The Committee approves accounting policies, reconciliation procedures and variance-report formats; Board approves the published Financial Health Report to external stakeholders.

**Decision Mechanism:** Consensus on budget model development and accounting standards. Simple majority (3 of 4-5) on routine approvals (monthly variance sign-off, contingency draws up to USD 1M, inflation allocation). Tie-breaker: CFO votes to break ties. Disputed variance interpretations (is a USD 2M equipment delay a true variance or a timing shift?) resolved by CFO judgment with full documentation. Disagreements on cost-to-complete estimates or inflation assumptions escalate to Board if variance impact exceeds USD 5M.

**Meeting Cadence:** Monthly meetings Month 1-120 (2026-11-12 to 2036-10-12) to review cost actuals, variance and forecast. Ad-hoc meetings called by CFO for large draws (>USD 500K), budget gaps or gate-readiness assessment.

**Typical Agenda Items:**

- Monthly cost actuals and cumulative variance (capex spent, opex spent, contingency drawn, expected cost at completion per phase, confidence range)
- Funder-commitment status (funds received, funds pledged but at-risk, Phase 2/3 commitment gap, any funder pullbacks or delays)
- Staffing and payroll reconciliation (headcount per unit, salary actuals vs. budget, benefits, travel/visa costs, any variances >5%)
- Phase-gate financial readiness (committed funding for next phase, contingency and reserves status, any shortfalls or mitigations needed)
- Inflation tracking (cumulative inflation vs. 2%/3%/4% scenarios, reserve depletion rate, impact on phase budgets)
- Contingency and mitigation add-on tracking (Design Pool status, risk-register add-ons drawn, remaining reserves)
- Forecast at completion for each phase (if spending continues at current rate, what is total cost at end of phase?)
- Cash-flow and working-capital forecast (do we have enough cash on hand to cover next 3 months of opex if a funder payment is delayed?)
- Financial risks and stop-loss triggers (what variance triggers a phase halt or scope reduction?)
- Phase-gate go/no-go financial assessment (do we have committed funding and healthy contingency to proceed to next phase?)

**Escalation Path:** Cumulative variance >10% overspend or under-utilization of major line items escalates immediately to Board as a governance re-assessment trigger; potential outcomes include budget replan, scope reduction, phased-gate delay or new-funder engagement. Phase 2 or Phase 3 funding gap >USD 10M with <3 months to gate escalates to Board for contingency-activation decision (activating a USD 15-20M bridge-credit line, deferring phase start, seeking emergency funder commitments, or reducing unit count). Payroll actuals consistently >USD 2.5M per unit-year escalate to Programme Director and Board for crew-composition review. Inflation exceeding 4% annually (extreme scenario) escalates to Board as a budget-viability trigger; potential outcomes include cost-control measures, timeline extension or scope reduction.

# Governance Implementation Plan

### 1. Senior leadership and Project Sponsor establish the governance framework vision. Draft a Governance Charter document outlining the role of a Programme Board, subsidiary committees (Technical, Site Selection, Legal/Privacy, Finance), decision authority, and escalation paths. Coordinate with identified funders and partner archives to gather input on preferred governance structure and decision-making principles.

**Responsible Body/Role:** Project Sponsor and Senior Management

**Suggested Timeframe:** Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Draft Governance Charter v0.1
- Stakeholder input summary
- Governance structure diagram
- Committee charter templates (preliminary)

**Dependencies:**

- Project Sponsor identified and committed
- List of potential funder and archive stakeholders available

### 2. Project Manager and General Counsel circulate the draft Governance Charter for feedback from committed funders, partner archives, and programme leadership. Gather consensus on Board size, committee structure, decision rights and meeting cadence. Finalize charter language and obtain Programme Sponsor approval before formal Board establishment.

**Responsible Body/Role:** Project Manager and General Counsel

**Suggested Timeframe:** Week 1–2 of Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Governance Charter v1.0 (finalized)
- Stakeholder feedback summary
- Board member nomination list (8–10 members confirmed)
- Sponsor sign-off on charter

**Dependencies:**

- Draft Governance Charter available
- Confirmed list of committed funders and archive partners
- Project Sponsor approval authority confirmed

### 3. Project Sponsor formally appoints the initial Programme Board Chair and confirms all eight to ten Board members by written appointment letter. Chair should be the Programme Director or senior sponsor representative with clear authority to lead strategic decisions. Provide each member with the finalized Governance Charter, committee charters (draft), and a board-orientation briefing on programme goals, budget, risks and timeline.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Month 0 (2026-10-12), Week 3 (2026-10-12)

**Key Outputs/Deliverables:**

- Board-member appointment letters (8–10 signed)
- Board orientation briefing deck
- Finalized committee charters (Technical, Site Selection, Legal/Privacy, Finance)
- Meeting schedule and calendar invites for first meetings

**Dependencies:**

- Governance Charter v1.0 finalized and approved
- Eight to ten Board members nominated and accepted
- Sponsor authority confirmed

### 4. Interim Governance Coordinator (designated by Project Manager) convenes the first Programme Board meeting. Board Chair leads adoption of the Governance Charter, confirms the decision-authority framework and escalation procedures, and approves the charter for subsidiary committees. Board assigns committee chairs and defines initial workstreams (cost audit, parts-depletion model, legal mapping). Schedule all four subsidiary committees to hold their initial meetings within two weeks.

**Responsible Body/Role:** Programme Board (first meeting, chaired by Programme Director or Board Chair)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 1 week of Board appointment

**Key Outputs/Deliverables:**

- Board Charter adopted (signed)
- Governance Framework approved and published
- Committee chairs assigned (Technical, Site Selection, Legal/Privacy, Finance)
- Initial Board decision log with agenda and action items
- Monthly Board meeting schedule (Months 1–6 = 2026-11-12 to 2027-04-12 confirmed)

**Dependencies:**

- All eight to ten Board members appointed and confirmed
- Governance Charter finalized
- Committee charters drafted

### 5. Chief Technical Officer (designated by Board) leads the initial Technical Committee meeting. Committee adopts the Technical Charter, establishes design-review procedures and DRG criteria (by Month 2 = 2026-12-12). Assigns immediate workstreams: (1) commission independent technical assessments of preliminary designs; (2) issue RFQ for 100–200 real test samples from proposed pilot archives; (3) establish parts-depletion modeling team; (4) begin retired-engineer mentor recruitment. Define committee meeting cadence (bi-weekly Months 0–6 = 2026-10-12 to 2027-04-12, weekly Months 6–20 = 2027-04-12 to 2028-06-12). Publish preliminary design specifications for all three line types.

**Responsible Body/Role:** Technical Committee (chaired by Chief Technical Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Technical Committee Charter adopted
- Design-Review Gate (DRG) procedure document
- Preliminary design specifications for Tape, Film, Card line types
- RFQ issued for test samples (100–200 items)
- Parts-depletion modeling project initiated; team assigned
- Retired-engineer mentor recruitment plan
- Technical-committee meeting schedule (bi-weekly to weekly)

**Dependencies:**

- Technical Committee appointed and chartered by Board
- Preliminary design specifications available (from engineering team)
- Budget allocated for external technical reviews and test-sample procurement

### 6. Chief Legal Officer and General Counsel lead the initial Legal, Privacy & Compliance Committee meeting. Committee adopts the Legal Charter and establishes foundational compliance workstreams: (1) commence legal mapping of all planned jurisdictions (GDPR, UK DPA, national privacy laws, data-residency rules); (2) draft standardised source-agreement template with tiered indemnity structures; (3) define Privacy-Review Panel composition and decision criteria; (4) establish incident-response protocols. Establish monthly meeting cadence. Publish a legal-compliance roadmap and jurisdiction-mapping schedule.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee (chaired by Chief Legal Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Legal/Privacy Committee Charter adopted
- Jurisdiction-mapping project initiated; scope document published
- Source-agreement template draft (preliminary)
- Privacy-Review Panel composition and decision-criteria draft
- Incident-response protocol outline
- Legal-compliance roadmap and timeline
- Committee meeting schedule (monthly)

**Dependencies:**

- Legal, Privacy & Compliance Committee appointed and chartered by Board
- General Counsel and data-protection specialist available
- List of planned pilot and Phase 2 jurisdictions available

### 7. Chief Financial Officer leads the initial Finance & Variance Monitoring Committee meeting. Committee adopts the Finance Charter and establishes budget-governance workstreams: (1) commission independent cost audit reconciling stated staffing (50–60 per unit), opex (USD 2–3M per unit-year) and the USD 250M budget cap; (2) develop detailed cost-accounting model (capex, opex, contingency, inflation); (3) build Funding Commitment Registry translating pledges into binding contracts; (4) establish contingency and mitigation-add-on tracking framework. Publish cost-audit RFQ and budget-model development schedule.

**Responsible Body/Role:** Finance & Variance Monitoring Committee (chaired by Chief Financial Officer)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Finance Committee Charter adopted
- Cost-audit RFQ issued (independent auditor selection by Month 2 = 2026-12-12)
- Detailed budget-model development plan
- Funding Commitment Registry project initiated
- Contingency and mitigation-tracking framework outlined
- Finance-committee meeting schedule (monthly)

**Dependencies:**

- Finance & Variance Monitoring Committee appointed and chartered by Board
- Chief Financial Officer assigned
- Budget allocation available for cost audit (USD 50–100K estimate)
- Preliminary staffing and opex figures available

### 8. Head of Operations and Site-Liaison Lead initiate the Site Selection, Triage & Archive Engagement Committee meeting. Committee adopts the Site Selection Charter and establishes initial workstreams: (1) draft Triage Doctrine (condition-first vs. value-first vs. survey-based prioritization); (2) build Master Schedule and Queue Management System template; (3) identify three pilot archives and begin readiness pre-work; (4) establish Site-Readiness Workstream and Scorecard. Schedule committee meetings (monthly Months 1–24 = 2026-11-12 to 2028-10-12). Publish triage-doctrine consultation schedule (stakeholder workshop by Month 4 = 2027-02-12).

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee (chaired by Head of Operations)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12), within 2 weeks of Board approval

**Key Outputs/Deliverables:**

- Site Selection Committee Charter adopted
- Draft Triage Doctrine outline and prioritization framework
- Master Schedule and Queue Management System template (spreadsheet or tool identified)
- Pilot-archive identification list (3 target archives)
- Site-Readiness Scorecard template
- Site-Readiness Workstream roles and responsibilities assigned
- Committee meeting schedule (monthly)

**Dependencies:**

- Site Selection Committee appointed and chartered by Board
- Head of Operations assigned
- List of potential pilot and Phase 2 archives available
- Preliminary triage criteria and policy guidance available

### 9. Project Manager commissions independent cost audit to reconcile the stated staffing model (50–60 per unit at 30 units = 1,500–1,800 people) and opex (USD 2–3M per unit-year) against the USD 250M cap. Audit to include detailed line-item cost estimates (capex, equipment, parts, training, staffing/payroll, logistics, utilities, connectivity, contingency, inflation). Deliverable: reconciliation report showing either the plan's full scope is affordable, or which elements (unit count, crew size, timeline) must adjust to fit the cap.

**Responsible Body/Role:** Finance Committee and Project Manager, supported by external auditor

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Cost-audit RFQ released and auditor selected
- Cost reconciliation report (draft) with line-item breakdown
- Three budget scenarios: baseline, high-cost (3% inflation), extreme-cost (4% inflation)
- Recommendations for cost control, scope adjustment or additional funding

**Dependencies:**

- Finance Committee formed
- Budget allocation for audit (USD 50–100K estimate)
- Preliminary design specifications and staffing assumptions available

### 10. General Counsel and Legal Committee commence jurisdiction-by-jurisdiction legal mapping. Analyze GDPR, UK Data Protection Act, national privacy laws, data-residency rules and archival preservation standards for all planned jurisdictions. Produce a jurisdiction-mapping matrix summarizing transfer restrictions, consent requirements, notification obligations, data-residency rules and archival-access legal frameworks. Identify jurisdictions with conflicting requirements or novel compliance needs that require early Board attention.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by external legal counsel (data-protection specialists)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Jurisdiction-mapping matrix (GDPR, UK DPA, national laws, data residency, archival standards)
- Summary of transfer restrictions and consent requirements per jurisdiction
- Risk flags for jurisdictions with novel or conflicting requirements
- External legal-counsel engagement (data-protection specialists identified)

**Dependencies:**

- Legal Committee formed
- List of all planned pilot and Phase 2 jurisdictions confirmed
- Budget for external legal counsel (USD 30–50K estimate)

### 11. Technical Committee commissions detailed parts-depletion modeling study. Study to include: (1) baseline mean time between failures (MTBF) per deck/scanner type, estimated from industry data or similar equipment; (2) cannibalization yield curves as the 300–500-unit stockpile is depleted; (3) 3D-printing and CNC-machining feasibility for 20+ critical replacement parts (azimuth guides, transport rollers, tension springs, etc.), with tolerance analysis and cost estimates; (4) retired-engineer expertise requirements and knowledge-transfer timelines; (5) recommendation on when to trigger emergency stockpile refresh or new-build transports. Deliverable: parts-depletion curve model and risk-trigger thresholds.

**Responsible Body/Role:** Technical Committee, supported by vintage-equipment specialists and 3D-printing/CNC engineers

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Parts-depletion model (spreadsheet or simulation) with MTBF, cannibalization yield and fabrication-capacity curves
- 3D-printing and CNC-machining feasibility study (20+ critical parts; tolerance analysis)
- Risk-trigger thresholds (depletion %, emergency refresh trigger)
- Retired-engineer expertise-transfer timeline and knowledge-loss risk assessment
- Budget estimate for parts-engineering team and contingency stockpile refresh (USD 10–15M proposed)

**Dependencies:**

- Technical Committee formed
- Industry data on tape-deck and scanner MTBF available (or estimates from archival community)
- List of 300–500 acquired vintage machines and their condition available
- Budget for parts-depletion modeling study (USD 20–30K estimate)

### 12. Technical Committee issues Request for Quotation (RFQ) for procurement of 100–200 representative test samples from proposed pilot archives. Samples to span all three formats (tape, film, card), multiple degradation levels (stable, moderately degraded, severely degraded) and content types (English speech, non-English languages, music, technical recordings, handwritten metadata). Target archives identified by Site Selection Committee. Negotiate procurement contracts and delivery schedules; target sample arrival by Month 4 (2027-02-12) to allow AI model testing and pilot review-pod setup.

**Responsible Body/Role:** Technical Committee and Site Selection Committee, supported by archive liaisons

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- RFQ document specifying sample-composition criteria (format, degradation, content diversity)
- Procurement contracts with pilot archives for sample provision
- Sample-delivery schedule (target Month 4 = 2027-02-12)
- Gold-standard labeling protocol for AI training and validation

**Dependencies:**

- Three pilot archives identified and willing to provide samples
- Technical Committee formed
- Sample composition criteria defined (format mix, degradation levels)

### 13. Finance Committee develops detailed cost-accounting model with line-item budgets for capex, opex, contingency, inflation reserves and mitigation add-ons. Model includes three budget scenarios (baseline 2% inflation, high-cost 3%, extreme 4%) and tracks cost per phase and per unit. Establishes contingency framework (10% per phase = USD 25M total; mitigation add-ons from risk register; inflation escalation reserves 15% per phase = USD 37.5M proposed). Publishes preliminary budget reconciliation and cash-flow forecast showing Phase 2 and Phase 3 funding gaps if any. Identifies shortfall amount and proposes mitigation options (host cost-sharing, additional funders, reduced unit count, extended timeline).

**Responsible Body/Role:** Finance & Variance Monitoring Committee, supported by accountant/controller

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Detailed cost-accounting model (baseline + inflation scenarios)
- Phase-by-phase cost forecast and contingency framework
- Cash-flow forecast (Months 0–120 = 2026-10-12 to 2036-10-12)
- Budget reconciliation report identifying any phase funding gaps
- Mitigation options analysis (cost-sharing, additional funders, scope reduction)

**Dependencies:**

- Cost-audit preliminary results available
- Preliminary staffing and opex estimates locked
- Inflation assumptions agreed (baseline 2%, sensitivities 3% and 4%)

### 14. General Counsel and Legal Committee draft standardised source-agreement template and tiered indemnity structures. Template to include: (1) scope of digitization and media handling; (2) copyright and privacy-review protocols; (3) data-transfer and residency terms; (4) tiered indemnity (full indemnity for stable material, documented waiver for high-risk items); (5) incident-response and notification obligations; (6) access-control and use restrictions for recovered data. Include jurisdiction-specific annexes for GDPR, UK DPA and other applicable laws. Circulate template to Board for review and approval before pilot site agreements are signed.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by external copyright and archival-law counsel

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Source-agreement template (master version)
- Tiered indemnity structure (Full, Conditional, Waiver tiers)
- Jurisdiction-specific annexes (GDPR, UK DPA, templates for other jurisdictions)
- Incident-response protocol (24-hour notification, privacy-breach handling)
- Board-approved legal framework document

**Dependencies:**

- Jurisdiction-mapping matrix completed
- Legal Committee formed
- General Counsel and external legal counsel available

### 15. Technical Committee establishes a retired-engineer mentor-recruitment and commitment process. Identify 6–8 retired broadcast and film engineers (aged 70–80) with deep expertise in tape azimuth alignment, film registration, head calibration and mechanical repair. Secure written commitments for intensive 18–24 month mentoring periods, with retention bonuses and consulting-role incentives extending through Month 48 (2030-10-12). Create mentoring contracts that specify: (1) key technical competencies to transfer (50+ modules across three line types); (2) successor engineer assignments (2–3 per mentor); (3) documentation and knowledge-base output; (4) retention milestones. Aim for signed mentoring agreements by Month 1–3 (2026-11-12 to 2027-01-12).

**Responsible Body/Role:** Technical Committee, supported by human resources and programme management

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Retired-engineer identification and recruitment list (6–8 candidates)
- Mentoring contracts (signed, specifying competencies, successors, durations, incentives)
- Mentoring curriculum outline (50+ competencies across Tape, Film, Card)
- Successor-engineer assignment list and commitment letters
- Mentoring schedule and knowledge-transfer milestones

**Dependencies:**

- Technical Committee formed
- Budget allocated for mentor retention bonuses (USD 500K–1M estimate)
- Networks to reach retired broadcast and film engineers established

### 16. Site Selection Committee drafts the Triage Doctrine for site prioritization. Triage Doctrine to define: (1) condition-based scoring (media degradation risk, format vulnerability, storage condition); (2) value-based scoring (research importance, cultural significance, archival prestige); (3) logistics-based scoring (host readiness, power stability, security); (4) weighting and prioritization rule (condition-first, value-first, or hybrid); (5) transparency and appeal process (sites notified of their priority score and rationale; disputes resolved by Committee). Circulate draft to Programme Board and all identified pilot and Phase 2 archives for feedback by Month 3–4 (2027-01-12 to 2027-02-12). Schedule stakeholder workshop for Month 4 (2027-02-12) to gather consensus before finalizing.

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee, supported by archivists and preservation experts

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Draft Triage Doctrine with scoring criteria and prioritization logic
- Condition-degradation assessment framework (media age, storage, format type)
- Site-scoring spreadsheet (preliminary, for 30+ planned archives)
- Stakeholder-workshop agenda and invitation list
- Finalized Triage Doctrine (after Month 4 = 2027-02-12 stakeholder workshop)

**Dependencies:**

- Site Selection Committee formed
- Preliminary list of 30+ planned pilot and Phase 2 archives
- Degradation-assessment criteria and media-condition data available from archives

### 17. Finance Committee establishes Funding Commitment Registry, translating all USD 250M in pledged funds into binding multi-year contracts. Registry to distinguish: (1) committed funds (signed contracts with payment schedules); (2) pledged funds (not yet contracted; subject to annual review or board approval). For each funder, record: commitment amount, payment schedule, conditions for release (phase gates), any exclusivity or data-access terms, and risk of withdrawal. Target: 50%+ of Phase 1 (USD 30M) committed by Month 3 (2027-01-12). Identify funding gaps and propose backup sources or cost-reduction measures to close gaps. Publish quarterly Commitment Status Report to Board.

**Responsible Body/Role:** Finance & Variance Monitoring Committee, supported by funder-liaison officer and contracts administrator

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Funding Commitment Registry (spreadsheet with 15+ funder records)
- Distinction of committed vs. pledged funds by funder and phase
- Risk assessment per funder (withdrawal risk, funding-cycle timing)
- Funding-gap analysis and mitigation options (additional funders, cost-share, scope reduction)
- Commitment Status Report (first quarterly report by Month 3 = 2027-01-12)

**Dependencies:**

- List of 15+ funder organisations and pledges available
- Commitment threshold targets set (50% Phase 1 by Month 3 = 2027-01-12, 70% Phase 2/3 before phases start)
- Finance Committee formed

### 18. Programme Board conducts formal gate-approval for Phase 1 and Phase 2 gates. Board reviews and formally approves the gate criteria (digitization success >95%, uptime >90%, AI accuracy >75%, review flagging <20%, zero incidents), the evidence-collection plan, and the decision mechanism. Board establishes a best-efforts override rule: results at >=80% of targets (flagging <=25%) allow conditional limited Phase 2 tranche with Board approval; results below 80% trigger governance reassessment and potential phase deferral. Document gate criteria in a Board-approved Gate Framework document. Publish gate criteria to all funders and archives for transparency.

**Responsible Body/Role:** Programme Board, advised by Technical and Finance Committees

**Suggested Timeframe:** Month 3–4 (2027-01-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Criteria (approved and published)
- Phase 2 Gate Evidence-Collection Plan
- Best-efforts override rule and conditional-release threshold (>=80% of targets)
- Gate Decision Mechanism document (how evidence is adjudicated; voting threshold for Board release)
- Published Gate Framework (communicated to funders and archives)

**Dependencies:**

- Programme Board formed
- Technical Committee proposals for success metrics available
- Finance Committee readiness assessment available
- Pilot timeline and schedule known

### 19. Finance Committee locks Phase 1 budget and staffing by Month 4 (2027-02-12), incorporating results of the cost audit and reconciliation. If cost audit shows the USD 250M cap is insufficient for full 30-unit scope, Finance Committee recommends to Board: (1) host cost-sharing to close funding gap; (2) new consortium or government funders; (3) phased unit reduction from 30 to 20–22 units; or (4) timeline extension to Month 144–156 (2038-10-12 to 2039-10-12). Board makes strategic decision by Month 4 (2027-02-12). Once scope and budget are locked, establish detailed Phase 1 cost-control plan: monthly cost tracking, 10% contingency reserve (USD 6M for Phase 1), inflation reserve (USD 9M proposed), and design contingency (USD 5M from contingency). Publish locked budget and staffing to all stakeholders.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 3–4 (2027-01-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Phase 1 locked budget (capex, opex, contingency, inflation reserve, mitigation add-ons)
- Phase 1 locked staffing (unit count, crew size per role, total headcount)
- Cost-reconciliation report with Board-approved scope decision
- Mitigation strategy if funding gap exists (cost-sharing, new funders, scope reduction)
- Phase 1 cost-control plan (monthly tracking, reserves, stop-loss triggers)
- Published budget and staffing baseline

**Dependencies:**

- Cost-audit results final
- Finance Committee formed
- Programme Board approval of scope and budget trade-offs

### 20. Project Manager formally appoints the Interim Retrofit and Integration Lead, who will oversee the physical retrofit of the three pilot units (1 Tape Line, 1 Film Line, 1 Card/Disk Line). Interim Lead coordinates with Technical Committee on design finalization and manages the containerized-unit retrofit schedule and budget. Establish a Retrofit Project Team (mechanical engineer, electrical engineer, software integration lead, QA specialist) and define daily standups or weekly build meetings. By Month 4 (2027-02-12), begin procurement of long-lead container retrofit services, equipment (tape decks, film scanners, card readers) and robotics from RFQ responses. Target first unit shipping for retrofit by end of Month 4 (2027-02-12); retrofit completion by Month 5 (2027-03-12).

**Responsible Body/Role:** Project Manager, supported by designated Interim Retrofit and Integration Lead

**Suggested Timeframe:** Month 3 (2027-01-12)

**Key Outputs/Deliverables:**

- Interim Retrofit and Integration Lead appointed and onboarded
- Retrofit Project Team staffed (mechanical, electrical, software, QA)
- Retrofit-schedule and budget plan (Months 4–5 = 2027-02-12 to 2027-03-12)
- Equipment and robotics RFQs issued and responses reviewed
- Long-lead procurements initiated (containers, decks, scanners, robotics)

**Dependencies:**

- Technical Committee design finalized and approved
- Design Contingency Pool (USD 5M) allocated
- Container retrofit services vendors identified

### 21. Technical Committee tests AI pre-screening and signal-reconstruction models on the 100–200 representative test samples (arrived by Month 4 = 2027-02-12). Testing includes: (1) measure precision, recall and false-positive rate per format-category (tape, film, card) and degradation level; (2) measure reconstruction accuracy (audio/video fidelity vs. gold-standard reference); (3) measure metadata accuracy (OCR, speech-to-text) per language and content type; (4) publish results by content category and identify any accuracy shortfalls. If precision/recall is <75% on any category, commission iterative model retraining by Month 6 (2027-04-12). Document all results in AI Validation Report. Use test results to calibrate pilot review-pod staffing and expectations.

**Responsible Body/Role:** Technical Committee (AI Lead) and external AI validation team

**Suggested Timeframe:** Month 4–5 (2027-02-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- AI Validation Report (precision/recall per format-category and degradation level)
- Reconstruction-accuracy measurements vs. gold standard
- Metadata-accuracy results (OCR, speech-to-text) by language and content type
- Any accuracy shortfalls identified; retraining plan if <75%
- AI deployment-readiness assessment for pilot

**Dependencies:**

- Test samples (100–200 items) received from archives
- Gold-standard labeling completed
- AI models trained on representative data available

### 22. Site Selection Committee conducts site-readiness pre-work for three pilot archives. Each site receives: (1) power-quality audit (voltage stability, frequency, generator capacity); (2) fire-authority pre-consultation on pre-treatment ovens and hazmat risks; (3) insurer pre-notification on equipment and media-handling coverage; (4) security and facility audit (hardstand, climate control, access, locking); (5) staff-liaison identification and initial training. Target: written fire-authority and insurer approval by Month 6 (2027-04-12) before unit deployment. If site fails readiness gate at Month 6 (2027-04-12), defer by 3–6 months and move up a backup site from Priority Waitlist. Publish Site Readiness Scorecard for each pilot archive.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager, supported by logistics and facilities specialists

**Suggested Timeframe:** Month 3–6 (2027-01-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Power-quality audit report for each pilot site
- Fire-authority pre-consultation letters and preliminary approval (written)
- Insurer pre-approval letters (equipment and media-handling coverage)
- Facility-readiness assessment (hardstand, climate, security, access)
- Staff-liaison identification and initial training completion
- Site Readiness Scorecard for each pilot site (target 90%+ ready by Month 6 = 2027-04-12)

**Dependencies:**

- Three pilot archives formally agreed to participate
- Site Selection Committee formed
- Preliminary design specifications known (power, footprint, pre-treatment needs)

### 23. Site Selection Committee completes Triage Doctrine (after stakeholder input and Board approval). Publish final Triage Doctrine with condition-degradation scoring, site-prioritization ranking for 30+ planned archives and transparency mechanism (each archive receives its priority score and rationale). Establish Master Schedule and Queue Management System with 5-year rolling forecast showing which units deploy to which sites and in which months. Build in contingency buffers (2–3 month surge-buffer pools) and defer-swap mechanisms for sites that fail readiness or withdraw. Notify all 30+ archives of their scheduled residency windows 12 months in advance (earliest pilot sites notified by Month 6 = 2027-04-12).

**Responsible Body/Role:** Site Selection, Triage & Archive Engagement Committee

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Finalized Triage Doctrine (approved by Board and archives)
- Master Schedule and Queue Management System (5-year rolling forecast)
- Site-prioritization rankings for 30+ archives with scoring and rationale
- Priority Waitlist and surge-buffer contingency guidelines
- 12-month advance notification letters to all archives (pilot sites by Month 6 = 2027-04-12)

**Dependencies:**

- Site Selection Committee formed
- Stakeholder workshop completed (Month 4 = 2027-02-12)
- Board approval of Triage Doctrine
- 30+ planned archives and their characteristics available

### 24. General Counsel and Legal Committee establish Privacy Review Panel with 2–3 data-protection experts (one per major jurisdiction/language group). Panel develops detailed decision criteria for flagging content: (1) personal data types (PII, medical records, financial data); (2) copyright markers (logos, watermarks, broadcast credits); (3) classification markers (government stamps, security labels); (4) sensitivity thresholds (what flagging triggers automatic review vs. lower-risk tiers). Train panel members on decision-making, documentation and appeal processes. Panel begins test runs on pilot-archive samples by Month 6 (2027-04-12) to calibrate flagging rates and reviewer accuracy. Document all decisions in Privacy Review Panel Log, with rationale and appeals.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by Privacy Review Panel members

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Privacy Review Panel composition finalized (2–3 experts, one per jurisdiction)
- Decision-criteria document (personal data types, copyright, classification, thresholds)
- Panel training curriculum and competency checklist
- Privacy Review Panel Log template (decision log with rationale, appeals)
- Test-run results on pilot-archive samples (flagging rates, accuracy)
- Reviewer qualification and ongoing-training plan

**Dependencies:**

- Legal Committee formed
- Data-protection experts identified and available
- Test samples available for trial runs
- Source-agreement templates approved

### 25. Legal Committee engages insurers and fire-authority experts to design hazmat-control and fire-safety standards for pre-treatment pods (baking ovens, humidity chambers). Develop a Pre-Treatment Hazard Control Design Standard specifying: (1) oven thermal management and insulation; (2) VOC capture and ventilation (with monitored exhaust); (3) fire suppression (foam or CO2); (4) separation from main digitization container (detached pod vs. certified-suppressed internal subsystem); (5) occupational safety (respiratory protection, air-quality monitoring); (6) handling of degraded media with asbestos or mercury. By Month 6 (2027-04-12), obtain written insurer and fire-authority approval of the standard at one pilot site. If approval is contingent on detached pods, budget USD 0.5–1.5M per unit for detached-pod retrofit (USD 1.5–4.5M for three pilots).

**Responsible Body/Role:** Legal, Privacy & Compliance Committee, supported by industrial-hygiene and fire-safety consultants

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Pre-Treatment Hazard Control Design Standard (oven, humidity, ventilation, fire suppression)
- VOC monitoring and respiratory-protection protocol
- Occupational Health and Safety (OHS) compliance checklist
- Detached-pod design option (cost estimate: USD 0.5–1.5M each)
- Written fire-authority approval at one pilot site
- Written insurer approval at one pilot site
- Risk-mitigation letter to Hazmat Risk Board Trigger (if approval is conditional)

**Dependencies:**

- Legal Committee formed
- Industrial-hygiene and fire-safety consultants engaged
- One pilot-site fire-authority and insurer pre-consulted
- Preliminary container design specifications available

### 26. Technical Committee completes Design Review Gate (DRG) preparation and schedule. By Month 6 (2027-04-12), finalize all design specifications for the three pilot line types (Tape, Film, Card/Disk). Submit designs to independent external technical review (university engineering department or broadcast-equipment specialist) for sign-off on feasibility, performance, tolerance, reliability and safety. Each major subsystem (climate, power, robotics, AI, on-board storage) undergoes independent review. Target design freeze by Month 20 (2028-06-12). Any post-freeze changes require Programme Board approval and impact analysis.

**Responsible Body/Role:** Technical Committee, supported by external technical reviewer

**Suggested Timeframe:** Month 6 (2027-04-12)

**Key Outputs/Deliverables:**

- Finalized design specifications for Tape, Film, and Card line types
- Submission of designs to external technical reviewer
- DRG sign-off criteria checklist (performance, tolerance, safety, reliability)
- Design-change control procedure (post-freeze authority and approval)
- Design-freeze schedule and gate-readiness timeline (by Month 20 = 2028-06-12)

**Dependencies:**

- Technical Committee formed
- All preliminary specifications finalized (climate, power, robotics, AI, storage)
- External technical reviewer identified and engaged
- Budget for independent review (USD 30–50K estimate)

### 27. Project Manager signs formal, multi-year (2–3 year) residency agreements with the three pilot archives. Agreements incorporate: (1) source-agreement template approved by Legal Committee; (2) tiered indemnity (Full for stable material, Conditional for uncertain condition); (3) cost-sharing or in-kind contributions (power, space, staff liaison); (4) media-handling and copyright-review protocols; (5) incident-response and notification procedures; (6) access controls and use restrictions for recovered data; (7) termination clauses (either party can terminate with 90 days' notice, with wind-down procedures). Signatures to be obtained by Month 6 (2027-04-12) before unit deployment. Legal Committee reviews each agreement for compliance with jurisdiction-specific annexes.

**Responsible Body/Role:** Project Manager and General Counsel

**Suggested Timeframe:** Month 4–6 (2027-02-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Executed residency agreements (3 pilot archives, signed)
- Cost-sharing or in-kind contribution details per archive
- Media-handling protocols and copyright-review procedures
- Indemnity tier assignment per collection or media type
- Incident-response contacts and 24-hour notification procedures
- Archive attestation that fire authority and insurer approve unit residency

**Dependencies:**

- Three pilot archives identified and agreed
- Source-agreement template finalized and approved by Board
- Fire-authority and insurer approvals in writing from archives
- Cost-sharing or in-kind contribution negotiations completed

### 28. Interim Retrofit and Integration Lead completes retrofit of the first Mobile Ingest Unit (1 Tape Line). Physical retrofit includes: container base, climate-control systems, power systems (facility connection + 200kW backup generator), on-board storage (500TB buffer), robotics integration, tape-deck mounting and calibration, AI processing workstations, satellite and fiber connectivity, and on-board monitoring (power, climate, equipment status). By Month 5 (2027-03-12), complete all subsystem integration and bench-testing (climate stability ±2°C / ±10% RH, power stability, robotics repeatability, AI processing latency). By end of Month 5 (2027-03-12), container is ready for deployment to first pilot site.

**Responsible Body/Role:** Interim Retrofit and Integration Lead and Retrofit Project Team

**Suggested Timeframe:** Month 4–5 (2027-02-12 to 2027-03-12)

**Key Outputs/Deliverables:**

- Completed Tape-Line retrofit (container, systems, integration)
- Bench-test results (climate, power, robotics, AI, connectivity)
- Subsystem certification (climate ±2°C/±10% RH, power stability, robotics tolerance)
- Unit readiness report (safe to deploy; all systems operational)
- Transportation and deployment logistics plan to first pilot site

**Dependencies:**

- Container and equipment procured
- Retrofit services vendor contracted
- Design freeze approval from Technical Committee
- First pilot site readiness gate passed (fire authority, insurer, power, facility)

### 29. Project Manager and Site Selection Committee coordinate logistics and transport of the first pilot unit (Tape Line) to the first pilot archive. This includes: (1) finalizing trucking or shipping logistics (routing, temporary-import documentation, customs pre-clearance); (2) confirming on-site hardstand and power connection ready; (3) scheduling unit arrival aligned with archive staff availability; (4) coordinating on-site setup (power connection, climate stabilization, safety walkthrough, staff briefing). Target unit arrival at first pilot site by Month 6 (2027-04-12). On-site setup takes 1–2 weeks; begin digitization intake and operations by Month 6 (2027-04-12).

**Responsible Body/Role:** Site Selection Committee and Logistics Coordinator

**Suggested Timeframe:** Month 5–6 (2027-03-12 to 2027-04-12)

**Key Outputs/Deliverables:**

- Unit transport logistics plan (trucking/shipping, routing, documentation)
- Temporary-import paperwork and customs pre-clearance
- On-site setup checklist and timeline
- Safety walkthrough and staff-briefing materials
- Unit arrival confirmation and on-site setup completion
- Digitization intake start (Months 6–20 = 2027-04-12 to 2028-06-12)

**Dependencies:**

- First unit retrofit completed and ready to ship
- First pilot site readiness gate passed
- Residency agreement signed
- On-site power, hardstand and climate infrastructure confirmed ready

### 30. Interim Retrofit and Integration Lead completes retrofit and deployment of the second and third pilot units (1 Film Line and 1 Card/Disk Line) in parallel with the first unit's operation. Retrofit schedule targets completion by Month 8–9 (2027-06-12 to 2027-07-12) and deployment to second and third pilot sites by Month 9–12 (2027-07-12 to 2027-10-12). Apply lessons learned from first unit's retrofit and pilot operations (any design tweaks, component substitutions) to units 2 and 3.

**Responsible Body/Role:** Interim Retrofit and Integration Lead and Retrofit Project Team

**Suggested Timeframe:** Month 5–12 (2027-03-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Completed Film-Line and Card/Disk-Line retrofits
- Bench-test results and subsystem certification for both units
- Deployment logistics plans and timelines for sites 2 and 3
- On-site setup and intake-readiness confirmations
- Lessons-learned feedback from first unit incorporated into units 2 and 3

**Dependencies:**

- Design-freeze approval from Technical Committee
- Pilot sites 2 and 3 readiness gates passed
- Residency agreements signed for sites 2 and 3
- Retrofit vendor capacity available for parallel builds

### 31. Technical Committee establishes the Pilot Review Pod: a dedicated team of 5–10 multilingual reviewers embedded with or co-located near the first pilot unit during Months 6–8 (2027-04-12 to 2027-06-12). The Review Pod runs a controlled pilot of the pre-screening and human-review workflow on real content from the first archive. Reviewers flag content per Privacy Review Panel criteria (personal data, copyright, classification) and measure: (1) flagging rate (what % of content is flagged?); (2) review time per content hour; (3) AI pre-screen precision and recall; (4) inter-reviewer agreement on flagged decisions; (5) any systematic bias or accuracy drift. Produce a Pilot Review Pod Report by Month 8 (2027-06-12) showing actual review load and flagging rates. If flagging rate is >25%, escalate to Technical Committee for AI retraining or workflow redesign.

**Responsible Body/Role:** Technical Committee and Pilot Review Pod (5–10 reviewers)

**Suggested Timeframe:** Month 6–8 (2027-04-12 to 2027-06-12)

**Key Outputs/Deliverables:**

- Pilot Review Pod staffed (5–10 reviewers, multilingual)
- Review workflow tested on real content from first archive
- Flagging rate measured (target <20%, investigate if >25%)
- Review time per content hour measured (target 1:2 ratio or better)
- AI precision/recall per content category measured
- Inter-reviewer agreement metrics (Cohen's kappa or similar)
- Pilot Review Pod Report (Month 8 = 2027-06-12), with recommendations for crew composition

**Dependencies:**

- First pilot unit operating with real content intake
- Privacy Review Panel criteria finalized
- AI models tested and deployed in first unit
- Reviewers recruited and trained (Month 4–6 = 2027-02-12 to 2027-04-12)

### 32. Technical Committee monitors the three pilot units' operational metrics during Months 6–20 (2027-04-12 to 2028-06-12). Establish a central Fleet Management Telemetry system that collects data from all three pilots: (1) equipment uptime per subsystem (tape decks, film scanners, robotics, climate, power); (2) mean time between failures (MTBF) and parts consumption; (3) digitization success rate (% of items processed without error); (4) reconstruction accuracy (audio/video/data fidelity); (5) AI metadata accuracy (OCR, speech-to-text); (6) human review flagging rate and reviewer time. Publish monthly telemetry reports to Technical Committee and Board. Set alarm thresholds: if uptime drops <90%, or reconstruction/AI accuracy drops below target, escalate to Committee for root-cause analysis and remediation.

**Responsible Body/Role:** Technical Committee and Central Fleet Management Team

**Suggested Timeframe:** Month 6–20 (2027-04-12 to 2028-06-12)

**Key Outputs/Deliverables:**

- Fleet Management Telemetry System operational (data collection from three pilots)
- Monthly telemetry reports (uptime, MTBF, digitization success, reconstruction accuracy, AI accuracy, flagging rate)
- Alarm thresholds and escalation triggers defined
- Root-cause analysis and remediation tracking for any threshold breaches

**Dependencies:**

- All three pilot units deployed and operating
- On-board monitoring and telemetry hardware/software installed
- Central operations center staffed and ready to receive telemetry

### 33. Technical Committee conducts stress testing of the first pilot unit by deliberately directing it toward the worst-condition collection material available at the first archive site. Stress testing runs for Months 6–12 (2027-04-12 to 2027-10-12) and focuses on: (1) severely degraded media (tapes with layer adhesion, film with shrinkage, cards with fading); (2) non-English speech and handwritten metadata (to stress AI models); (3) media with unknown or uncertain copyright status (to stress privacy review). Document all failure modes, recovery procedures and root causes. Use stress-test results to identify design weaknesses before design freeze (Month 20 = 2028-06-12). This honest failure data informs Phase 2 design decisions and risk mitigations.

**Responsible Body/Role:** Technical Committee and First Pilot Unit Crew

**Suggested Timeframe:** Month 6–12 (2027-04-12 to 2027-10-12)

**Key Outputs/Deliverables:**

- Stress-test plan (worst-condition collections and edge cases identified)
- Stress-test execution log (media processed, failure modes encountered)
- Root-cause analysis for each failure mode
- Design-weakness assessment and redesign recommendations
- Stress-test report (Month 12 = 2027-10-12), with lessons for Phase 2 units

**Dependencies:**

- First pilot unit operating
- First archive has challenging, worst-condition collections available
- Technical Committee and engineering team available for real-time problem-solving

### 34. Finance Committee conducts the first quarterly Cost-and-Variance Report (Month 6 = 2027-04-12). Report includes: (1) Phase 1 actual capex and opex spend to date vs. budget; (2) cumulative variance (over/under); (3) forecast at completion for Phase 1; (4) contingency and reserves status; (5) inflation impact (actual YoY cost escalation vs. 2%/3%/4% scenarios); (6) funder-commitment status (funds received, pledged, at-risk). If cumulative variance is >5%, escalate to Board for review. If variance is >10%, Board triggers governance re-assessment. Publish report to Programme Board and all funders quarterly (Months 6, 9, 12, 15 = 2027-04-12, 2027-07-12, 2027-10-12, 2028-01-12, etc.) through Month 120 (2036-10-12).

**Responsible Body/Role:** Finance & Variance Monitoring Committee

**Suggested Timeframe:** Month 6 (2027-04-12) and quarterly thereafter

**Key Outputs/Deliverables:**

- Quarterly Cost-and-Variance Report (Month 6 = 2027-04-12 first edition)
- Phase 1 actual spend vs. budget (capex, opex, contingency, inflation reserve)
- Cumulative variance and forecast at completion per phase
- Funder-commitment status and funding-gap assessment
- Escalation flags if variance >5% or >10%

**Dependencies:**

- Finance Committee established and monthly accounting in place
- Monthly cost-tracking system operational
- Funder commitment registry maintained

### 35. Technical Committee formally applies Design Review Gate (DRG) criteria to the three pilot units. All major subsystems undergo independent technical review for sign-off. Submission package to external reviewer includes: (1) final design specifications; (2) bench-test and pilot-operations data (climate, power, uptime); (3) stress-test results and failure-mode analysis; (4) lessons-learned and design-improvement recommendations; (5) spare-parts and maintenance protocols. External reviewer independently assesses feasibility, reliability, safety and performance. Target DRG sign-off by Month 20 (2028-06-12).

**Responsible Body/Role:** Technical Committee, supported by external technical reviewer

**Suggested Timeframe:** Month 18–20 (2028-04-12 to 2028-06-12)

**Key Outputs/Deliverables:**

- DRG submission package (finalized designs, test data, lessons learned)
- External reviewer technical assessment (independent report)
- Design sign-off by external reviewer (or conditional sign-off with rework list)
- Design-freeze certification (designs locked; post-freeze changes require Board approval)
- Change-control procedures for Phase 2 and Phase 3 units

**Dependencies:**

- All three pilots operational and generating at least 12 months of telemetry data
- Stress-test and lessons-learned analysis completed
- External reviewer available and ready to assess

### 36. Technical Committee and Privacy Review Panel consolidate all pilot evidence against the Phase 2 Gate Criteria. Evidence package includes: (1) digitization success rate >95% across all three pilots; (2) reconstruction accuracy >80% per format-category; (3) automated metadata accuracy >70% per language/content type; (4) human review flagging rate <20% (or AI retraining plan if >25%); (5) uptime >90% with mean time between failures data; (6) AI pre-screen precision and recall >=75% per category-format (or retraining results showing improvement to >=75%); (7) zero privacy/legal incidents; (8) design-freeze sign-off from external reviewer; (9) parts-depletion model showing feasible spares management; (10) retired-engineer mentoring curriculum >80% complete. By Month 20 (2028-06-12), produce a Phase 2 Gate Evidence Report summarizing all findings. If any metric falls below target, the Committee recommends either: (a) conditional limited Phase 2 tranche (if >=80% of thresholds met, per best-efforts override rule); (b) governance re-assessment (if <80% or if a critical threshold like uptime is missed).

**Responsible Body/Role:** Technical Committee and Privacy Review Panel

**Suggested Timeframe:** Month 18–24 (2028-04-12 to 2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Evidence Report (Month 20 = 2028-06-12, comprehensive metrics package)
- Digitization success, reconstruction accuracy, metadata accuracy: actual rates per pilot and format-category
- Uptime and MTBF data (monthly trending, alarm thresholds, corrective actions)
- Human review flagging rate: actual % and comparison to <20% target
- AI precision/recall per category-format: results and any retraining outcomes
- Privacy and legal incident log (zero incidents confirmed)
- Design-freeze and external-reviewer sign-off confirmation
- Parts-depletion model and maintenance-readiness assessment
- Retired-engineer mentoring progress (curriculum completion, successor competency assessments)

**Dependencies:**

- All three pilots have >=12 months of operational data (Months 6–20 = 2027-04-12 to 2028-06-12)
- Pilot Review Pod and telemetry system producing consistent data
- External technical reviewer has completed design assessment
- Privacy Review Panel has reviewed all flagged content from pilots

### 37. Finance Committee consolidates Phase 2 Gate Financial Readiness assessment. Checklist includes: (1) Phase 1 cumulative variance <=10% (or Board has approved re-baseline); (2) Phase 2 funding is >=70% committed (not pledged) by Month 24 (2028-10-12); (3) Phase 1 has spent within contingency reserve (10% = USD 6M); (4) Phase 2 locked budget and staffing (unit count, crew size) approved by Board; (5) Phase 3 funding gaps identified and mitigation plan in place (cost-sharing, additional funders, scope reduction); (6) inflation reserves adequate per 2%/3%/4% scenarios. By Month 24 (2028-10-12), produce Phase 2 Gate Financial Readiness Report. If Phase 2 commitment is <70%, Committee recommends governance decision: delay Phase 2 start (contingency funding bridge activated), reduce Phase 2 unit count (12 becomes 8–10), or seek emergency funder commitments.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 24 (2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Gate Financial Readiness Report (Month 24 = 2028-10-12)
- Phase 1 spend summary and final variance (actual vs. budget, contingency usage)
- Phase 2 funding commitment status (% committed, payment schedules, at-risk funders)
- Phase 2 locked budget and staffing (12 units, crew size per role, total headcount)
- Phase 3 funding gap assessment and mitigation options (cost-sharing, new funders, scope reduction)
- Inflation impact summary (cumulative 2% vs. 3% vs. 4%)
- Go/no-go financial recommendation for Phase 2 release

**Dependencies:**

- Phase 1 actual spend finalized and reconciled
- Funding Commitment Registry updated with all pledges and commitments
- Board-approved Phase 2 and Phase 3 budget and staffing locked

### 38. Programme Board holds a formal Phase 2 Release Gate Meeting at Month 24 (2028-10-12). Board reviews the Phase 2 Gate Evidence Report (Technical Committee) and Phase 2 Gate Financial Readiness Report (Finance Committee). Board votes on Phase 2 release using the following decision rule: (a) If all gate criteria met (digitization >95%, uptime >90%, AI accuracy >75%, review flagging <20%, zero incidents, design freeze, Phase 2 funding >=70% committed), Board approves full Phase 2 release and authorizes drawdown of Phase 2 funds (USD 120M). (b) If results are 80–99% of targets (flagging <=25%, at least 1 critical threshold met), Board may approve conditional limited Phase 2 tranche (e.g., USD 30–50M for 4–6 units) with rework and revalidation required. (c) If results are <80% of targets or a critical threshold is missed (uptime <90%, reconstruction accuracy <75%, design not frozen, Phase 2 funding <70% committed), Board triggers governance re-assessment: phase deferral, scope reduction, or emergency mitigation. Board documents decision in a Phase 2 Gate Decision Memo and notifies all funders and archives.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 24 (2028-10-12)

**Key Outputs/Deliverables:**

- Phase 2 Release Gate Meeting minutes and decision log
- Phase 2 Gate Decision Memo (approved for release, conditional release, or governance re-assessment)
- Authorization to drawdown Phase 2 funds (if approved)
- Escalation triggers or rework plans (if conditional or deferred)
- Notification to funders and archives (scheduled deployment timeline for Phase 2 units)

**Dependencies:**

- Phase 2 Gate Evidence Report completed (Technical Committee)
- Phase 2 Gate Financial Readiness Report completed (Finance Committee)
- Board meeting scheduled and all members present or voting by proxy

### 39. Project Manager and Retrofit Lead begin procurement of long-lead components for Phase 2 units (12 additional Mobile Ingest Units). Procurement includes: (1) 12 containers and retrofit services; (2) tape decks, film scanners, card readers (from RFQ responses); (3) robotics and automation systems; (4) climate-control and power systems; (5) AI processing workstations; (6) on-board storage and connectivity hardware. Order long-lead items (containers, robotics, power supplies) by Month 24 (2028-10-12) to ensure delivery by Months 28–32 (2029-02-12 to 2029-06-12). Retrofit schedule targets completion of Phase 2 units by Months 30–40 (2029-04-12 to 2030-04-12).

**Responsible Body/Role:** Project Manager and Interim Retrofit Lead, supported by procurement team

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- RFQs issued for Phase 2 containers, equipment, robotics and systems
- Vendor selection and contracts executed
- Long-lead procurement orders placed (containers, robotics, power)
- Delivery timeline and retrofit schedule (Months 28–40 = 2029-02-12 to 2030-02-12)
- Retrofit-project plan for 12 units in parallel tracks

**Dependencies:**

- Design freeze approved by Board (from Phase 2 Gate)
- Phase 2 funds authorized for drawdown (USD 120M or conditional tranche)
- Vendor relationships and RFQ responses received

### 40. Site Selection Committee continues site-readiness pre-work for Phase 2 archives (15+ sites). By Month 28 (2029-02-12), complete readiness audits for the first 4–6 Phase 2 sites scheduled to receive units in Months 28–36 (2029-02-12 to 2029-10-12). Obtain fire-authority and insurer written approvals for each site, similar to pilot sites. Sign formal residency agreements (2–3 years, with terms per Legal Committee template). Notify remaining Phase 2 sites (7–10) of their scheduled residency windows and begin readiness pre-work 6 months before scheduled unit arrival.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager

**Suggested Timeframe:** Month 24–28 (2028-10-12 to 2029-02-12)

**Key Outputs/Deliverables:**

- Phase 2 site-readiness audits for first 4–6 sites (power, fire authority, insurer, facility)
- Written fire-authority and insurer approvals for Phase 2 sites
- Executed residency agreements (Phase 2 sites, multi-year terms)
- Notification letters to remaining Phase 2 sites (residency windows and readiness schedule)
- Master Schedule updated with confirmed Phase 2 site assignments and timing

**Dependencies:**

- Site Selection Committee active
- Phase 2 unit deployment timeline known (from Retrofit Lead)
- Triage Doctrine and site prioritization finalized

### 41. Technical Committee continues Retired-Engineer Mentoring Program through Months 24–48 (2028-10-12 to 2030-10-12). Ensure all mentors remain engaged (retention bonuses active), curriculum modules are completed on schedule, and successor engineers (2–3 per mentor) have achieved competency milestones. By Month 36 (2029-10-12), at least 70% of the 50+ critical competencies should be documented in a Digital Knowledge Base (accessible to all engineers). Conduct competency assessments of successors at Months 24, 36 and 48 (2028-10-12, 2029-10-12, 2030-10-12) to ensure knowledge transfer is on track. If a mentor becomes unavailable, activate redundancy (backup mentor identified in advance). By Month 48 (2030-10-12), successors should be able to operate independently or with minimal mentoring.

**Responsible Body/Role:** Technical Committee and Retired-Engineer Mentoring Program Lead

**Suggested Timeframe:** Month 24–48 (2028-10-12 to 2030-10-12), ongoing

**Key Outputs/Deliverables:**

- Mentoring curriculum progress tracking (modules completed, competency assessments)
- Successor-engineer competency milestones met (Month 24, 36, 48 = 2028-10-12, 2029-10-12, 2030-10-12 checkpoints)
- Digital Knowledge Base development (documentation of 50+ competencies; 70% complete by Month 36 = 2029-10-12)
- Mentor retention and availability status (any changes, redundancy activation)
- Knowledge-transfer risk assessment (any gaps identified; remediation plans)

**Dependencies:**

- Mentoring contracts in place with incentives and retention terms
- Successor engineers assigned and in training
- Digital Knowledge Base platform and documentation templates established

### 42. Programme Board convenes a Contingency Funding Panel by Month 24–30 (2028-10-12 to 2029-04-12) if there are indications that Phase 3 funding will not be secured by the target date (Month 48 = 2030-10-12). The Panel identifies alternative funding sources (government supplemental budgets, additional philanthropic foundations, technology-sector non-exclusive licensing, cost-sharing with archives) that can provide a backup USD 15–30M bridge if Phase 3 commitments fall short. By Month 54 (2031-04-12) (before Phase 3 gate at Month 60 = 2031-10-12), finalize contingency funding or implement a scope reduction (Phase 3 unit count reduced from 15 to 10–12).

**Responsible Body/Role:** Programme Board and Finance Committee

**Suggested Timeframe:** Month 24–54 (2028-10-12 to 2031-04-12)

**Key Outputs/Deliverables:**

- Contingency Funding Panel formed (Month 24–30 = 2028-10-12 to 2029-04-12)
- Alternative funding sources identified and vetted (Month 30–48 = 2029-04-12 to 2030-10-12)
- Contingency-funding letters of intent or commitments (by Month 54 = 2031-04-12)
- Scope-reduction plan (if contingency funding is insufficient; reducing Phase 3 units from 15 to 10–12)

**Dependencies:**

- Phase 3 funding commitment status tracked quarterly by Finance Committee
- Programme Board authorized to seek alternative sources

### 43. Technical Committee commissions a Phase 2 design-change and lessons-learned review. By Month 26 (2028-12-12), analyze all pilot-unit issues encountered during Months 6–24 (2027-04-12 to 2028-10-12) and determine which require design changes for Phase 2 units. Examples: if climate control drifted in hot climates, enhance dehumidification; if robotics showed repeatability issues, upgrade arm actuators; if power instability occurred, add voltage regulators. For each design change, estimate cost, schedule impact (delay to Phase 2 deployment) and risk (if change introduces new failure modes). Board approves design changes <USD 2M and <2 month delay by exception; changes >USD 2M or >2 month delay require formal Board approval.

**Responsible Body/Role:** Technical Committee

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- Pilot lessons-learned review and documented issues (Months 6–24 = 2027-04-12 to 2028-10-12)
- Design-change recommendations for Phase 2 units
- Cost and schedule impact analysis per change
- Risk assessment (if change may introduce new issues)
- Board-approved design-change list (approved design modifications for Phase 2)

**Dependencies:**

- Pilot operations complete or mature (at least 18–24 months of data)
- Technical Committee and engineering team available for analysis

### 44. Legal Committee conducts a Phase 2 source-agreement-template refresh. Based on pilot experiences (any incident, dispute or regulatory feedback), review and update the template and tiered-indemnity structure. Ensure jurisdiction-specific annexes reflect any new case law or regulatory guidance (GDPR enforcement actions, UK data-protection decisions, national privacy law updates). By Month 26 (2028-12-12), publish revised source-agreement template v2.0 incorporating lessons from pilot sites. All Phase 2 sites sign the updated template.

**Responsible Body/Role:** Legal, Privacy & Compliance Committee

**Suggested Timeframe:** Month 24–26 (2028-10-12 to 2028-12-12)

**Key Outputs/Deliverables:**

- Pilot source-agreement experience review (any disputes, amendments, regulatory feedback)
- Updated source-agreement template v2.0 (revised indemnity, privacy, incident-response terms)
- Updated jurisdiction-specific annexes (reflecting new case law or regulatory guidance)
- Board approval of updated template

**Dependencies:**

- Legal Committee tracking pilot source-agreement experience
- Regulatory updates and case-law research current through Month 24 (2028-10-12)

### 45. Finance Committee locks Phase 2 budget and staffing by Month 26 (2028-12-12). This includes: (1) detailed cost forecast for Phase 2 (capex for 12 units, opex for Months 24–60 = 2028-10-12 to 2031-10-12, contingency and inflation); (2) staffing plan (crew size per unit, total headcount, salary scales, benefits); (3) revised Phase 3 funding-gap estimate incorporating Phase 2 actuals and revised inflation forecasts; (4) revised Phase 3 scope (unit count reduction if Phase 3 funding is insufficient). Publish locked Phase 2 budget and staffing to all stakeholders by Month 26 (2028-12-12). If Phase 2 budget exceeds Phase 2 authorized funds (conditional tranche case), escalate to Board for additional contingency draw or scope reduction decision.

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 26 (2028-12-12)

**Key Outputs/Deliverables:**

- Phase 2 locked budget (capex, opex, contingency, inflation reserves)
- Phase 2 locked staffing (12 units, crew size per role, total headcount)
- Revised Phase 3 funding-gap analysis (incorporating Phase 2 actuals)
- Phase 3 scope reduction plan (if needed; reducing from 15 to 10–12 units)
- Published budget and staffing baseline for Phase 2

**Dependencies:**

- Phase 2 unit costs and procurement contracts finalized
- Staffing and payroll actuals from pilot phase reconciled
- Inflation escalation tracked through Month 26 (2028-12-12)

### 46. Programme Board establishes a Fleet Sunset and Equipment Afterlife Working Group by Month 28 (2029-02-12). Working Group tasked with developing an end-state plan for the programme at Month 120 (2036-10-12). End-state plan to address: (1) which units are retained for ongoing operations, transferred to archives/universities, or decommissioned; (2) parts-inventory and warehouse disposition; (3) knowledge-base stewardship and long-term access; (4) transition to post-programme funding or partnerships. Initial deliverable: end-state options paper by Month 36 (2029-10-12). Final plan by Month 48 (2030-10-12). This early planning ensures equipment procurement and depreciation schedules align with end-state strategy.

**Responsible Body/Role:** Programme Board and appointed Fleet Sunset and Equipment Afterlife Working Group

**Suggested Timeframe:** Month 28 (2029-02-12)

**Key Outputs/Deliverables:**

- Fleet Sunset and Equipment Afterlife Working Group formed (members identified)
- End-state options paper (Month 36 = 2029-10-12): unit disposition, parts inventory, knowledge-base stewardship
- Final end-state plan (Month 48 = 2030-10-12): approved by Board; guides Phase 3 operations

**Dependencies:**

- Programme Board active
- Sufficient Phase 2 funding visibility (to estimate Phase 3 unit count and operations duration)

### 47. Technical Committee and Finance Committee coordinate establishment of a Parts Inventory Management System by Month 30 (2029-04-12). System tracks: (1) all 300–500 acquired vintage machines and their status (operational, parts-source, end-of-life); (2) critical parts stock per line type (tape decks, film scanners, card readers); (3) consumption rate and depletion curves; (4) 3D-printing and CNC-fabrication schedule (which parts are re-manufactured, when); (5) re-manufacture triggers (when stock hits 50% depletion threshold). System is accessible to all on-site maintenance engineers and the central Parts Engineering team. Establish a Parts Purchasing and Fabrication Dashboard that auto-triggers orders when stock thresholds approach.

**Responsible Body/Role:** Technical Committee and Finance Committee, supported by Parts Engineering team

**Suggested Timeframe:** Month 30 (2029-04-12)

**Key Outputs/Deliverables:**

- Parts Inventory Management System operational (database or software platform)
- Vintage-machine inventory audit and status documentation
- Critical parts stock tracking (per line type, consumption curves)
- Parts re-manufacture schedule and trigger thresholds (50% depletion)
- Parts Purchasing and Fabrication Dashboard (accessible to all maintenance engineers)

**Dependencies:**

- All 300–500 vintage machines acquired and inventoried
- Parts-depletion model complete
- 3D-printing and CNC-fabrication team established

### 48. Site Selection Committee and Triage working group conduct a mid-programme triage review by Month 36 (2029-10-12). Review whether condition-degradation timelines and actual unit deployment rates allow the programme to reach all priority sites before media failure. If actual deployment is slower than planned (e.g., site-readiness delays, design rework, funding constraints), re-prioritize remaining sites based on urgency (accelerate highest-risk sites, defer lower-risk ones). Update Master Schedule and Priority Waitlist. Notify all archives of any schedule changes 12 months in advance.

**Responsible Body/Role:** Site Selection Committee and Triage working group

**Suggested Timeframe:** Month 36 (2029-10-12)

**Key Outputs/Deliverables:**

- Mid-programme triage review (actual deployment rate vs. plan; degradation timelines assessment)
- Updated site prioritization (any re-ranking based on urgency and actual capacity)
- Updated Master Schedule (5-year rolling forecast revised)
- Notification to all archives (schedule confirmations or changes)

**Dependencies:**

- Phase 2 deployment has been underway (Months 28–36 = 2029-02-12 to 2029-10-12)
- Actual deployment rates and site-readiness data available
- Triage Doctrine and Master Schedule established and operational

### 49. Finance Committee and Programme Board conduct Phase 3 financial assessment by Month 42 (2030-04-12) (6 months before Phase 3 gate at Month 48 = 2030-10-12). Assessment includes: (1) Phase 1 and Phase 2 final spend and variance; (2) Phase 3 funding commitment status (% committed, payment schedules); (3) revised Phase 3 total cost estimate (incorporating inflation to Month 120 = 2036-10-12); (4) funding gap (if any) and mitigation options (contingency draws, cost-sharing, unit reduction). If Phase 3 funding is <70% committed, activate Contingency Funding Panel for emergency fundraising. By Month 48 (2030-10-12), Board must have either (a) 70%+ of Phase 3 funds committed, or (b) Board-approved scope reduction (Phase 3 unit count reduced from 15 to 10–12, or timeline extended to Month 132–144 = 2037-10-12 to 2038-10-12).

**Responsible Body/Role:** Finance & Variance Monitoring Committee and Programme Board

**Suggested Timeframe:** Month 42–48 (2030-04-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 financial assessment (Phase 1/2 final spend, Phase 3 funding status, cost estimate, gap analysis)
- Phase 3 funding commitment registry (% committed, payment schedules, at-risk funders)
- Contingency Funding Panel activation (if Phase 3 commitment <70%)
- Scope reduction or timeline-extension plan (if needed)
- Board decision on Phase 3 authorization (approved, conditional, or deferred)

**Dependencies:**

- Phase 1 and Phase 2 operations complete or mature enough for final cost reconciliation
- Phase 3 funder pledges and commitments tracked by Finance Committee

### 50. Technical Committee consolidates Phase 3 Gate Evidence against the established gate criteria. By Month 48 (2030-10-12), gather evidence that Phase 2 has achieved: (1) 500K+ items digitized and 25+ PB recovered (cumulative through Phase 2); (2) all 15 cumulative units (3 pilots + 12 Phase 2) with >90% trailing 6-month uptime; (3) digitization success, reconstruction accuracy and AI accuracy targets still met; (4) human review flagging <20%; (5) zero reportable privacy/legal incidents; (6) parts-depletion model showing feasible spares management through Phase 3; (7) retired-engineer mentoring >90% complete; (8) design freeze and post-freeze change control working effectively. Produce Phase 3 Gate Evidence Report. If any critical threshold is missed (uptime <90%, recovery target <500K items / <25 PB, parts model infeasible), escalate to Board for governance decision (Phase 3 approval with conditions, deferral, or scope reduction).

**Responsible Body/Role:** Technical Committee

**Suggested Timeframe:** Month 42–48 (2030-04-12 to 2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 Gate Evidence Report (Month 48 = 2030-10-12, comprehensive metrics package)
- Cumulative item and data-volume totals (500K+ items, 25+ PB)
- Equipment uptime trending (trailing 6-month data for all 15 units)
- Digitization, reconstruction and AI accuracy results (trending through Phase 2)
- Privacy incident log (zero incidents confirmed)
- Parts-depletion model and spares-management feasibility assessment
- Retired-engineer mentoring completion status (curriculum, successor competency)

**Dependencies:**

- Phase 2 operations mature (18–24 months of data from Phase 2 units)
- All 15 cumulative units deployed and operational or completing residencies
- Technical telemetry system active and producing consistent data

### 51. Programme Board holds formal Phase 3 Release Gate Meeting at Month 48 (2030-10-12). Board reviews Phase 3 Gate Evidence Report (Technical Committee) and Phase 3 Financial Readiness assessment (Finance Committee). Board votes on Phase 3 release using the same decision framework as Phase 2: (a) If all gate criteria met and Phase 3 funding >=70% committed, Board approves full Phase 3 release and authorizes drawdown of Phase 3 funds (USD 70M). (b) If results are 80–99% of targets and Phase 3 funding >=70%, Board may approve conditional Phase 3 tranche with rework and revalidation. (c) If results are <80% of targets, critical thresholds are missed, or Phase 3 funding <70% committed, Board triggers governance re-assessment: phase deferral, scope reduction (reduce from 15 to 10–12 units), or timeline extension. Board documents decision in Phase 3 Gate Decision Memo and notifies all funders and archives.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 48 (2030-10-12)

**Key Outputs/Deliverables:**

- Phase 3 Release Gate Meeting minutes and decision log
- Phase 3 Gate Decision Memo (approved for release, conditional release, or governance re-assessment)
- Authorization to drawdown Phase 3 funds (if approved)
- Escalation triggers or remediation plans (if conditional or deferred)
- Notification to funders and archives (Phase 3 deployment timeline)

**Dependencies:**

- Phase 3 Gate Evidence Report completed (Technical Committee)
- Phase 3 Financial Readiness assessment completed (Finance Committee)
- Programme Board meeting scheduled and all members present or voting

### 52. Project Manager and Retrofit Lead begin procurement and retrofit of Phase 3 units (final 15 Mobile Ingest Units). Procurement and retrofit schedule targets completion of all Phase 3 units by Months 90–110 (2034-04-12 to 2035-08-12), allowing 6–10 months of residency at each site before programme close at Month 120 (2036-10-12). By Month 54 (2031-04-12), issue RFQs for Phase 3 containers, equipment and systems. By Month 60 (2031-10-12), begin retrofit of first Phase 3 units (target first Phase 3 unit deployed by Month 64–66 = 2032-02-12 to 2032-04-12).

**Responsible Body/Role:** Project Manager and Retrofit Lead

**Suggested Timeframe:** Month 48–60 (2030-10-12 to 2031-10-12)

**Key Outputs/Deliverables:**

- Phase 3 RFQs issued for 15 containers, equipment, robotics and systems
- Vendor contracts executed
- Long-lead procurement orders placed
- Retrofit schedule (Months 60–110 = 2031-10-12 to 2035-12-12)
- First Phase 3 units deployed to Phase 3 archives by Month 66 (2032-04-12)

**Dependencies:**

- Phase 3 funds authorized for drawdown (from Phase 3 Gate)
- Design freeze and change control working from Phase 2
- Vendor relationships and capacity available

### 53. Site Selection Committee continues Phase 3 site-readiness pre-work. Begin readiness audits for Phase 3 sites (15+ archives) starting at Month 54 (2031-04-12). For each site: (1) power-quality audit; (2) fire-authority and insurer pre-notification; (3) facility and security assessment; (4) staff-liaison identification. Target completion of first 5–7 Phase 3 site audits by Month 60 (2031-10-12), with fire-authority and insurer written approvals by Month 62 (2031-12-12). Sign Phase 3 residency agreements (multi-year, updated source-agreement template v2.0+). Remaining Phase 3 sites (8–10) begin readiness work on a rolling schedule, 6 months before their scheduled unit arrival.

**Responsible Body/Role:** Site Selection Committee and Host-Site Manager

**Suggested Timeframe:** Month 54–66 (2031-04-12 to 2032-04-12)

**Key Outputs/Deliverables:**

- Phase 3 site-readiness audits (first 5–7 sites)
- Written fire-authority and insurer approvals for Phase 3 sites
- Executed Phase 3 residency agreements (multi-year terms)
- Notification to remaining Phase 3 sites (residency windows and readiness schedule)
- Master Schedule finalized (all 30+ archives assigned and scheduled through Month 120 = 2036-10-12)

**Dependencies:**

- Phase 3 unit deployment timeline known from Retrofit Lead
- Phase 3 scope finalized (15 units or reduced count if scope reduction approved)
- Site Selection Committee active

### 54. Finance Committee and Programme Board finalize the Fleet Sunset and Equipment Afterlife Plan by Month 54 (2031-04-12). Plan to address: (1) unit disposition (which 30 units are retained, transferred to archives/universities, or decommissioned post-Month 120 = 2036-10-12); (2) parts-warehouse closure or transfer (parts inventory to successors or archives with maintenance capability); (3) knowledge-base handoff (digital knowledge commons, documentation repository, successor training of the preservation community); (4) post-programme funding or partnerships (is there a sustained endowment for retained units, or a successor organization?); (5) equipment depreciation and asset management through Month 120 (2036-10-12). Board approves final end-state plan and communicates strategy to all funders and archives.

**Responsible Body/Role:** Fleet Sunset and Equipment Afterlife Working Group and Programme Board

**Suggested Timeframe:** Month 54 (2031-04-12)

**Key Outputs/Deliverables:**

- Final Fleet Sunset and Equipment Afterlife Plan (approved by Board)
- Unit disposition decision (retained, transferred, decommissioned)
- Parts-warehouse and inventory transition plan
- Knowledge-base stewardship plan (digital commons platform, documentation, successor training)
- Post-programme sustainability plan (endowment, successor organization, funding commitments)
- Equipment-depreciation and asset-management schedule

**Dependencies:**

- Fleet Sunset Working Group active (formed Month 28 = 2029-02-12)
- End-state options paper and interim plan completed (Months 36–48 = 2029-10-12 to 2030-10-12)
- Programme Board authorization

### 55. Finance Committee and Programme Board establish a Post-Programme Continuation Committee by Month 60 (2031-10-12). Committee membership includes: representatives of retained-unit recipients (archives, universities, research centers), knowledge-base stewards, endowment or sustainability partner, Programme Director (outgoing), and 2–3 continuing Board members. Committee tasked with: (1) ensuring smooth transition of units and parts to successors; (2) maintaining knowledge-base and supporting the preservation community; (3) managing any post-Month 120 (2036-10-12) digitization of newly identified collections; (4) securing long-term funding for retained units. First meeting by Month 60 (2031-10-12); ongoing governance through Month 120 (2036-10-12) and beyond.

**Responsible Body/Role:** Programme Board

**Suggested Timeframe:** Month 60 (2031-10-12)

**Key Outputs/Deliverables:**

- Post-Programme Continuation Committee formed (members confirmed)
- Committee charter and responsibilities documented
- Transition-plan timeline (handoff schedule through Month 120 = 2036-10-12)
- Knowledge-base and sustainability-partner relationships formalized
- First continuation-committee meeting held (Month 60 = 2031-10-12)

**Dependencies:**

- Fleet Sunset and Equipment Afterlife Plan finalized
- Programme Board approval
- Identified unit recipients and sustainability partners (from end-state plan)

### 56. Technical Committee conducts final compliance and decommissioning planning by Month 100 (2035-02-12) (4 months before programme close at Month 120 = 2036-10-12). Plan addresses: (1) retirement and safe decommissioning of pilot units (1–3 units that have completed residencies or are due for unit replacement); (2) end-of-life disposal of non-operational equipment and parts (following environmental and e-waste regulations per jurisdiction); (3) final knowledge-base documentation (all 50+ competencies documented, digital commons finalized); (4) certification of all digitized data (verification of two copies per master, fixity checks, format-migration plans for long-term preservation). By Month 120 (2036-10-12), all units are either transferred to successors or safely decommissioned, and all digitized data is in final archive custody with preservation and migration plans.

**Responsible Body/Role:** Technical Committee and Post-Programme Continuation Committee

**Suggested Timeframe:** Month 100–120 (2035-04-12 to 2036-10-12)

**Key Outputs/Deliverables:**

- Decommissioning and retirement plan (unit-by-unit timeline through Month 120 = 2036-10-12)
- Environmental and e-waste disposal compliance plan (per jurisdiction)
- Final knowledge-base documentation (all competencies captured; digital commons published)
- Data-custody verification (two copies per master confirmed; fixity checks passed)
- Format-migration and long-term preservation plans (for 200+ PB archive)
- Final programme report and lessons-learned documentation
- Handoff to Post-Programme Continuation Committee (Month 120 = 2036-10-12)

**Dependencies:**

- All 30 units have completed their residencies (or are completing final residencies by Month 120 = 2036-10-12)
- All digitized data (3.6M+ items, 200+ PB) is in final archive custody
- Post-Programme Continuation Committee ready to assume stewardship (Month 120 = 2036-10-12)
- Legal and compliance sign-offs for final operations (Month 100–120 = 2035-02-12 to 2036-10-12)

### 57. Programme Director formally closes the CDDIN Programme and transitions stewardship to the Post-Programme Continuation Committee by Month 120 (2036-10-12). Deliverables include: (1) final programme close-out report (scope delivered, items digitized, data recovered, lessons learned); (2) certification of all governance transition items (Board dissolved, committees transferred to continuation committee, decision records archived); (3) institutional memory handoff (personnel, documentation, knowledge-base access); (4) celebration and recognition of team, partners and funders. Last Programme Board meeting held at Month 120 (2036-10-12); Post-Programme Continuation Committee assumes ongoing stewardship.

**Responsible Body/Role:** Programme Director and Programme Board

**Suggested Timeframe:** Month 120 (2036-10-12)

**Key Outputs/Deliverables:**

- Final Programme Close-Out Report (scope, items, data, lessons, outcomes)
- Governance transition documentation (Board dissolution, committee handoff, decision records)
- Knowledge-base and institutional memory handoff (files, access, contacts)
- Post-Programme Continuation Committee formally assumes stewardship
- Recognition and celebration event (team, partners, funders)
- Public archive and communication (final outcomes communicated to stakeholders)

**Dependencies:**

- All CDDIN operations completed (units deployed, residencies completed, data archived)
- Post-Programme Continuation Committee established and ready (Month 60 = 2031-10-12 onward)
- All governance and administrative closure tasks completed
- Final report and documentation compiled

# Decision Escalation Matrix

**Budget Variance or Cost Overrun Exceeding 10% of Phase Budget**
Escalation Level: Programme Board (Strategic Oversight)
Approval Process: Finance Committee presents variance analysis; Programme Board votes on governance re-assessment: halt phase pending remediation plan, approve contingency draw, reduce unit count, extend timeline, or seek emergency funder commitments. 70%+ Board consensus required; tie-breaker Programme Director.
Rationale: Cumulative overspend >10% per phase (e.g., Phase 1 exceeds USD 66M, Phase 2 exceeds USD 132M, Phase 3 exceeds USD 77M) indicates cost-control failure that threatens the overall USD 250M cap and phase-gate timeline. Finance Committee alone cannot authorize spending above Board-approved phase budgets; exceeding 10% variance requires strategic re-assessment of scope, funding, or timeline.
Negative Consequences: Uncontrolled cost overruns at Phase 1 or Phase 2 consume contingency reserves (USD 25M total) and force mid-programme choices: halting a phase costs schedule delay (3–6 months slip per phase = 50,000–300,000 items deferred); reducing units below 30 lowers total recovery from 3.6M+ items to 2.4M–3.2M; extending timeline beyond Month 120 (2036-10-12) leaves media undigitized as degradation clocks continue (10–30 year lifespan). At Phase 3, USD 70M budget and estimated USD 371M need creates >400% gap unfunded; failure to secure contingency funding forces abandonment of 5–15 units (net 15–20 instead of 30) and 1.8M–2.7M items unrecovered.

**Critical Equipment Design Flaw Discovered Post-Freeze or During Pilot Operations**
Escalation Level: Programme Board (with recommendation from Technical Committee)
Approval Process: Technical Committee conducts root-cause analysis and impact assessment; Committee recommends design rework or alternate approach. Board approves design-change cost and schedule impact: minor changes (<USD 2M, <2 months delay) may be approved by exception; major changes (>USD 2M or >2 months delay) require full Board vote. Post-freeze changes to locked designs (Month 20 = 2028-06-12 onward) always require Board escalation and approval.
Rationale: The Design Review Gate (Month 20 = 2028-06-12) locks all three pilot line-type designs to prevent replication of flawed units into Phase 2 and Phase 3 (12 Phase 2 units, 15 Phase 3 units). A critical flaw discovered post-freeze (e.g., climate control inadequate for hot climates, robotics repeatability below specification, thermal management failing, power instability causing corruption) discovered during pilot operations (Months 6–20 = 2027-04-12 to 2028-06-12) or early Phase 2 (Months 28–36 = 2029-02-12 to 2029-10-12) requires immediate Board decision: pursue retrofit of all affected units (cost USD 2M–5M, delay 6–9 months) or accept performance risk (uptime <90%, digitization success <95%).
Negative Consequences: Design rework on Phase 2 units (already ordered) costs USD 2M–5M retrofit and delays Phase 2 deployment by 6–9 months: first Phase 2 unit arrives Month 34–37 (2029-08-12 to 2029-11-12) instead of Month 28 (2029-02-12), reducing Phase 2 effective residencies by 15–20% (from 12 units to 10–11). Phase 3 start could slip to Month 66–72 (2032-04-12 to 2032-10-12), cutting Phase 3 from 15 to 10–12 units and total recovery from 3.6M to 3.0M–3.2M items. Failure to address a design flaw (e.g., continuing with flawed units) risks fleet uptime dropping below 90% target by Months 36–48 (2029-10-12 to 2030-10-12), cascading into maintenance backlog and trust erosion with archive partners.

**Pilot Gate Evidence Below Threshold: Digitization Success <95%, Reconstruction Accuracy <80%, AI Pre-Screen Precision/Recall <75%, or Human Review Flagging >25%**
Escalation Level: Programme Board (with evidence review from Technical and Finance Committees)
Approval Process: Technical Committee produces Phase 2 Gate Evidence Report by Month 20 (2028-06-12) summarizing all pilot metrics. If any critical threshold is missed, Committee recommends governance re-assessment. Board votes on three outcomes: (a) conditional limited Phase 2 tranche (if >=80% of targets met; e.g., USD 30–50M for 4–6 units instead of full USD 120M) with rework and revalidation required; (b) full governance re-assessment (if <80% of targets), triggering phase deferral, unit-count reduction, or timeline extension; (c) reject Phase 2 release entirely and rework entire pilot design before proceeding. 70%+ Board consensus required.
Rationale: The five core operational assumptions are unproven on degraded multilingual pre-digital content (1950–2000 era): >95% digitization success, >80% reconstruction accuracy, >70% automated metadata accuracy, <20% human-review flagging, and >90% uptime. Pilot operations (Months 6–20 = 2027-04-12 to 2028-06-12) on three line types at two sites must validate these before Phase 2 replicates units (and costs) across 12 additional units. If flagging exceeds 25% (indicating <75% pre-screen accuracy), reviewer headcount required per unit jumps from 12–15 to 40–50, multiplying payroll by 3–4x and pushing opex from USD 2.5M to USD 5M–6M per unit-year—incompatible with USD 250M cap.
Negative Consequences: If flagging is 30–35% instead of 20%, review load per unit triples: requires 40–50 reviewers per unit (vs. 12–15 planned), adding USD 15M–25M annual payroll at full scale unbudgeted. Phase 2 and Phase 3 become financially infeasible without scope reduction (fewer units) or timeline extension (spreading costs across more years). AI accuracy below 75% requires model retraining (2–4 weeks engineering, 1–2 weeks compute) and delays gate evidence by 1–3 months. Detection at Month 18–20 (2028-04-12 to 2028-06-12) defers Phase 2 from Month 24 (2028-10-12) to Month 30–36 (2029-04-12 to 2029-10-12), losing 6–12 months of Phase 2 capacity and cascading 50,000–200,000 items into the undigitized backlog. Failure to gate release (approving Phase 2 despite evidence <80% of targets) risks replicating a flawed design across 12 Phase 2 units, compounding rework cost to USD 24M–60M mid-programme.

**Parts-Depletion Model Shows Infeasible Spares Trajectory: Depletion Outpacing Fabrication Capacity by >20% Margin**
Escalation Level: Programme Board (with recommendation from Technical Committee)
Approval Process: Technical Committee monitors parts-depletion curve monthly (via Parts Inventory Management System). If depletion rate exceeds fabrication capacity by >20% margin (e.g., consuming spares 25% faster than 3D printing can replenish), Committee escalates to Board with risk assessment: emergency stockpile refresh (USD 15M–25M unbudgeted), new-build transports (requires engineering effort and cost), or reduced fleet size and operating tempo. Board authorizes remediation: approve contingency fund draw, activate emergency procurement, or reduce unit count from 30 to 20–25.
Rationale: The plan depends on 300–500 decommissioned tape decks and film scanners as a finite, depleting inventory. Mean time between failures (MTBF) and cannibalization yield are modeled (milestone Month 2 = 2026-12-12), but actual field failure rates may exceed estimates. 3D printing of precision parts (tape transport azimuth guides, film registration rollers, tension springs) is proposed but unproven at required tolerances. By Months 36–48 (2029-10-12 to 2030-10-12), if spares depletion accelerates (e.g., all tape decks in a line type develop azimuth drift simultaneously due to age), fleet uptime could drop below 90% target unless emergency refresh is activated.
Negative Consequences: Failure to address spares shortage allows fleet uptime to fall below 90% target by Month 36–48 (2029-10-12 to 2030-10-12). At 30 units, 10% unplanned downtime means 3 units offline continuously, losing 300TB–500TB per month of planned capture (36TB–60TB per unit × 3 = 5,400–18,000 items per month deferred). Cascading maintenance backlog forces extended unit outages (weeks or months awaiting parts or expert repair), compounding losses. Emergency stockpile refresh at USD 15M–25M mid-programme (Months 36–48 = 2029-10-12 to 2030-10-12) consumes contingency reserves and diverts funds from other Phase 2 or Phase 3 operations. Worst case: capability collapse by Month 60–72 (2031-10-12 to 2032-10-12) if machine and expertise base is exhausted, forcing program to halt Phase 3 or reduce from 30 to 10–15 units.

**Privacy Breach, Data-Residency Violation, or Regulatory Incident During Content Review or Upload**
Escalation Level: Programme Board (with incident-response activation by Legal Committee)
Approval Process: Legal Committee receives incident report (24-hour notification requirement). Committee assesses severity: minor (isolated privacy flag on single item, manually corrected) -> Committee documents in incident log and notifies Board monthly; major (data breach affecting 100+ items, regulatory investigation triggered, archive partnership at risk) -> Committee escalates immediately to Board and Programme Director with incident-response team activation. Board authorizes containment (halt processing if needed), regulator notification (GDPR fines up to 4% of global revenue for technology funders = USD 5M–20M+), breach notification to affected individuals, remediation plan (policy change, retraining, system redesign), and archive relationship repair.
Rationale: The programme handles unique cultural artifacts and personal data (medical records, government documents, private correspondence) across multiple jurisdictions with conflicting legal rules (GDPR, UK DPA, national privacy laws, data-residency restrictions). A single privacy breach (leaked personal medical records discovered in archive after upload) or data-transfer violation (uploading content to central archive despite country prohibition on outbound data transfer) triggers regulatory investigation, fines, mandatory breach notification, reputational damage and potential archive partnership termination. On-site human-review gates (pre-upload decision) are designed to catch sensitive content, but no review process is 100% accurate; false-negative risk requires incident-response readiness.
Negative Consequences: GDPR regulatory fine: up to 4% of global revenue for a technology-company funder (estimated USD 5M–20M+). Mandatory breach notification to affected individuals and regulators within 30 days (cost USD 500K–2M in legal and notification services, plus reputational damage). Archive partnership termination: if incident occurs at a pilot site, that archive withdraws; cascading effect if incident is widespread (e.g., systematic metadata error exposing PII across 100,000 items), 3–5 partner archives may terminate simultaneously, reducing Phase 2 residency capacity by 20–40% (from 12 sites to 7–10). Operational halt: regulatory investigation could freeze digitization operations for 2–4 months during forensic review, deferring 30,000–100,000 items. Source-agreement amendments: all remaining archive agreements may require renegotiation with stricter privacy terms, slowing site onboarding by 4–8 weeks per site.

**Host Archive Insurer or Fire Authority Refuses Pre-Treatment Unit Approval; Hazmat or Safety Compliance Violation Discovered**
Escalation Level: Programme Board (with remediation recommendation from Legal Committee and Technical Committee)
Approval Process: Site Selection Committee detects insurer/fire-authority objection during site-readiness audit (target Month 3–6 = 2027-01-12 to 2027-04-12 for pilot sites). Legal Committee and Technical Committee jointly assess: is objection due to insufficient hazmat-control design, or is site infrastructure inadequate? Board authorizes remediation: (a) deploy detached pre-treatment pod (USD 0.5–1.5M retrofit, +4–6 weeks per site) to address design concerns; (b) defer site (move to backup site from Priority Waitlist); (c) negotiate site-specific exemptions or waivers (with insurer and regulator approval); (d) reduce or redirect unit deployment. Board decision within 5 business days of Committee escalation.
Rationale: On-site residencies depend entirely on archive insurer and fire-authority approval of baking ovens, humidity chambers, generators and combustible media. Baking ovens bring thermal risk (fire initiation if oven insulation fails); humidity chambers introduce chemical vapors (volatile organic compounds from degrading tape binders and film adhesives); diesel generators create fuel and exhaust hazards; original media on-site creates fire load. If a host's insurer declines coverage or fire authority prohibits unit placement due to insufficient containment design, that site cannot proceed, stranding the unit and orphaning the collection. The plan assumes on-site processing eliminates shipping risk but does not guarantee that on-site handling is insurable or fire-safe without design changes.
Negative Consequences: Site-readiness delay of 4–8 weeks per archive (typical for insurer/fire-authority pre-consultation and permitting) × 30+ planned residencies = 120 weeks (23 months) cumulative delay across the programme, shrinking effective operating capacity by 15–20%. Cascading schedule slip delays Phase 2 start from Month 24 (2028-10-12) to Month 30–32 (2029-04-12 to 2029-06-12), forcing Phase 2 unit deferral and reducing residencies from 12 to 10–11 sites. Detached-pod retrofit (USD 0.5–1.5M each) applied fleet-wide (30 units) costs USD 15M–45M unbudgeted, straining contingency reserves (USD 25M total) and forcing USD 10M–20M deficit. Site deferral orphans a collection indefinitely: a deferred archive may never receive a unit, and its degrading media is lost to time. Incident-driven policy change (one archive suffers a thermal incident destroying unique items) cascades across network: all other archives may demand enhanced safety measures, extending site-readiness timelines and retrofit costs industry-wide.

# Monitoring Progress

### 1. Core Operational Metrics and Fleet Health Monitoring (KPI Tracking)
**Monitoring Tools/Platforms:**

  - Central Fleet Management Telemetry System (on-board sensors per MIU collecting uptime, MTBF, equipment status)
  - Monthly Telemetry Reports Dashboard (uptime %, digitization success %, reconstruction accuracy %, metadata accuracy %)
  - Equipment Performance Log (per-unit tracking of subsystem failures, parts consumption, maintenance hours)

**Frequency:** Monthly reporting to Technical Committee and Board; real-time alarm thresholds for critical failures (uptime <90%, reconstruction <80%, AI accuracy <75%)

**Responsible Role:** Technical Committee and Central Fleet Management Team; escalation to Programme Board if alarm triggered

**Adaptation Process:** Technical Committee convenes emergency session within 48 hours if threshold breached. Root-cause analysis conducted; corrective actions (design change, parts refresh, crew retraining, unit deployment adjustment) assigned with timeline. Board informed of remediation plan within 5 business days. If root cause indicates systemic design flaw, escalate to Board for Phase 2/3 impact assessment and authorization of rework (up to USD 2M / <2 months delay approved by exception; larger impacts require full Board approval).

**Adaptation Trigger:** Alarm threshold breach: uptime <90%, digitization success <95%, reconstruction accuracy <80%, automated metadata accuracy <70%, or human review flagging >25% (indicating AI pre-screen <75% accuracy); sustained for 2 consecutive months or single month critical failure.

### 2. Vintage Hardware Sustainment and Parts-Depletion Monitoring
**Monitoring Tools/Platforms:**

  - Parts Inventory Management System (database tracking all 300–500 acquired vintage machines, condition status, critical parts stock, consumption curves)
  - Parts Purchasing and Fabrication Dashboard (auto-triggers re-manufacture orders when stock approaches 50% depletion threshold)
  - Mean Time Between Failures (MTBF) Tracking per Line Type (tape decks, film scanners, card readers)
  - 3D-Printing and CNC Fabrication Status Log (scheduled re-manufacture, delivery timeline, tolerance validation results)

**Frequency:** Monthly Parts Inventory audit and depletion-curve update; weekly Parts Engineering team status meeting; quarterly Board report on spares trajectory and risk triggers

**Responsible Role:** Technical Committee (Parts and Maintenance Lead); Parts Engineering team daily operations; escalation to Programme Board if depletion outpaces fabrication by >20%

**Adaptation Process:** Monthly dashboard review identifies depletion rate and compares against fabrication capacity. If depletion is 15–20% faster than forecast, Parts Engineering increases re-manufacture scheduling and sources additional vintage machines or contract external repair capability. If depletion exceeds fabrication by >20% margin, Technical Committee escalates to Board with two mitigation options: (1) emergency vintage stockpile refresh (USD 15M–25M unbudgeted, requires contingency draw and Board approval), or (2) reduce fleet operating tempo or unit count to match sustainable spares consumption rate. Board authorizes remedy within 10 business days.

**Adaptation Trigger:** Parts-depletion model shows actual consumption rate exceeding forecast by >15%; trigger escalation to Parts Engineering. If depletion exceeds fabrication capacity by >20% margin by Month 36–48 (2029-10-12 to 2030-10-12), activate emergency Board decision: approve contingency draw, reduce unit count, or defer Phase 3. Specific trigger: projected parts stockpile exhaustion within 18 months of current rate.

### 3. AI Pre-Screening and Review Workflow Validation (Unproven Assumption Testing)
**Monitoring Tools/Platforms:**

  - Pilot Review Pod Test Results (flagging rate, review hours per content hour, precision/recall per content category)
  - AI Model Validation Report (precision, recall, false-positive rate per format-category and degradation level; published by Month 5 = 2027-03-12)
  - Privacy Review Panel Decision Log (decisions per item, rationale, inter-reviewer agreement metrics, systematic bias detection)
  - Content Accuracy Audit (5% monthly spot-check sample reviewed by secondary expert; Cohen's kappa or similar for agreement)

**Frequency:** Pilot Review Pod runs Months 6–8 (2027-04-12 to 2027-06-12), producing Phase 2 Gate Evidence by Month 20 (2028-06-12); thereafter monthly flagging-rate and accuracy audits through full programme

**Responsible Role:** Technical Committee (AI Lead); Privacy Review Panel; AI validation team; escalation to Programme Board if accuracy thresholds missed

**Adaptation Process:** Pilot Review Pod report (Month 8 = 2027-06-12) measures actual flagging rate and review hours per content hour against targets (<20% flagging, 1:2 ratio). If flagging is 25–30%, Technical Committee recommends AI model retraining or flagging-threshold adjustment; retraining consumes 2–4 weeks engineering and 1–2 weeks compute time. Results re-validated by Month 12 (2027-10-12). If retraining does not improve accuracy to >=75%, or if flagging remains >25% after retraining, Committee escalates to Board for workflow redesign (tiered review model: automated acceptance for Category A low-risk items, expert review for Category C high-risk, with escalation for disputes). If review hours exceed 1:2 ratio significantly (>0.5 hours per content hour), crew composition recalibrated: increase reviewers per unit from 12–15 to 20–25 and escalate payroll impact to Finance Committee for Phase 2 budget re-planning.

**Adaptation Trigger:** Pilot Review Pod flagging rate >25% (indicating AI pre-screen accuracy <75%); or measured review time per content hour >0.5 (instead of target <=0.5 for 1:2 ratio); or inter-reviewer agreement (Cohen's kappa) <0.6, indicating systematic bias or training gap. Any trigger at Month 8 (2027-06-12) must be remediated and re-validated before Phase 2 Gate (Month 24 = 2028-10-12).

### 4. Staffing Model and Budget Reconciliation Monitoring
**Monitoring Tools/Platforms:**

  - Monthly Cost and Variance Report (actual vs. budgeted capex, opex, contingency usage; cumulative variance per phase)
  - Quarterly Payroll Reconciliation Report (headcount per unit, salary actuals, benefits, travel/visa, loaded cost per staff member)
  - Funding Commitment Registry (committed vs. pledged funds per funder; payment schedule; at-risk funders)
  - Cost-at-Completion Forecast (per-phase projections, inflation impact, gap analysis vs. USD 250M cap)

**Frequency:** Monthly cost actuals and variance tracking; quarterly Cost and Variance Report to Board; headcount and payroll audit quarterly

**Responsible Role:** Finance Committee (CFO, controller, budget manager); escalation to Programme Board if cumulative variance >5% (monitor) or >10% (governance re-assessment)

**Adaptation Process:** Monthly cost actuals are reconciled against budget by Finance Committee. If cumulative variance is 5–10%, Finance Committee flags trend and recommends monitoring intensification; no immediate action. If cumulative variance exceeds 10% overspend, Finance Committee produces detailed variance analysis identifying root causes (cost escalation, scope creep, inefficient staffing, inflation) and recommends one of three Board decisions: (1) contingency draw (up to the phase-contingency reserve), (2) cost-control measures (crew right-sizing, logistics optimization, vendor renegotiation), or (3) scope reduction (defer or cancel lower-priority sites, reduce unit count). Board votes within 5 business days; decision documented in Board meeting minutes. Payroll reconciliation each quarter compares loaded costs (salary + benefits + travel) against the USD 2.5M per-unit-year opex assumption. If actual payroll exceeds USD 2.5M per unit per year by >5%, Finance Committee escalates to Programme Director for crew-composition review and Board decision on whether to right-size crews (reduce from stated 50–60 per unit to actual sustainable level) or increase opex budget allocation (which may require cost-sharing negotiation with hosts or new funder engagement).

**Adaptation Trigger:** Cumulative variance >5% per phase triggers enhanced monitoring (Finance Committee weekly check-ins); >10% cumulative overspend triggers Board governance re-assessment and authorization of cost-control action. Payroll exceeds USD 2.5M per unit-year by >5% sustained (2+ consecutive quarters) triggers crew-composition audit and Board decision on staffing adjustment. Phase 3 funding gap identified before Month 54 (2031-04-12) (6 months before Phase 3 gate) triggers activation of Contingency Funding Panel for emergency fundraising; if gap remains >USD 10M by Month 54 (2031-04-12), Board approves scope reduction (Phase 3 unit count reduced from 15 to 10–12) or timeline extension beyond Month 120 (2036-10-12).

### 5. Privacy, Copyright and Legal Compliance Gate Monitoring
**Monitoring Tools/Platforms:**

  - Privacy Review Panel Decision Log (decisions per flagged item, rationale, jurisdiction-specific legal basis, appeal outcomes)
  - Source Agreement Tracking System (multi-year residency agreements signed, custody terms, indemnity tier assignment, incident-notification contacts)
  - Jurisdiction-Specific Compliance Checklist (GDPR, UK DPA, national privacy laws, data-residency rules per planned site; status of jurisdiction-specific annexes)
  - Incident Response Log (privacy breaches, data-transfer violations, handling losses, regulatory inquiries; 24-hour notification register to insurers/regulators)

**Frequency:** Privacy Review Panel meets weekly during pilot (Months 6–8 = 2027-04-12 to 2027-06-12), monthly thereafter; monthly incident log review; quarterly compliance status report to Board

**Responsible Role:** Legal, Privacy & Compliance Committee (General Counsel, data-protection officer); Privacy Review Panel (2–3 rotating experts); escalation to Programme Board for major incidents or jurisdictional conflicts

**Adaptation Process:** Privacy Review Panel maintains a decision log documenting flagged-content decisions with rationale (personal data type identified, legal basis for handling, consent status, storage restrictions). Panel decisions are binding; disputes between reviewers escalated to full Committee for re-review or external legal mediation. Monthly Committee review identifies systematic patterns: if a specific content category shows consistently high flagging rate (e.g., >30% of items with handwritten metadata flagged as privacy-sensitive), Committee may recommend workflow adjustment (additional reviewer training, revised flagging criteria, or delegation to archive's own curatorial staff for jurisdiction-specific judgment). Incident response: any privacy breach (personal data leaked post-upload), data-transfer violation (content uploaded to central archive despite country data-residency prohibition), or handling loss (item destroyed during digitization) triggers 24-hour notification to insurers and regulator (per GDPR, UK DPA or national law requirements). Legal Committee activates incident-response team; Board informed immediately for major incidents (affecting >100 items, regulatory investigation, archive partnership at risk). Committee recommends containment, breach notification, remediation (policy change, system redesign, retraining), and relationship repair. Jurisdictional conflicts (archive's privacy attorney disagrees with programme's classification of an item as personal data) escalate to Board for policy guidance and external mediation (up to USD 25K per dispute).

**Adaptation Trigger:** Privacy Review Panel flagging rate systematically high (>25% of items flagged as sensitive); zero incidents required, but major incident (breach affecting >100 items, regulatory fine, archive termination threat) immediately escalates to Board. Jurisdictional rule change or case law affecting data-transfer rules (e.g., new EU court ruling on GDPR transfers) triggers re-assessment of data-residency compliance architecture and potential workflow redesign. New source agreement required with any archive not yet signed (target all agreements signed by Month 6 = 2027-04-12 for pilots, Month 28 = 2029-02-12 for Phase 2 first-wave sites).

### 6. Fire Safety, Hazmat and Host Insurer Approval Tracking (On-Site Handling Risk Monitoring)
**Monitoring Tools/Platforms:**

  - Site Readiness Scorecard (per-archive power, fire authority, insurer, facility, security status; tracks 90%+ readiness gate before unit dispatch)
  - Pre-Treatment Hazard Control Compliance Checklist (oven insulation, VOC monitoring, fire suppression, respiratory protection, occupational health assessments)
  - Insurer and Fire-Authority Approval Letters (written pre-approval per site; conditional approvals flagged for remediation)
  - Incident and Near-Miss Log (handling losses, fire-safety violations, VOC exposure events; 24-hour incident notification to insurers)

**Frequency:** Site Readiness Scorecard updated quarterly during site-prep phase (6 months pre-arrival); fire-authority and insurer approval obtained by Month 6 (2027-04-12) for pilots, by Month 28 (2029-02-12) for Phase 2 first-wave; monthly incident log review

**Responsible Role:** Site Selection Committee (Host-Site Manager); Legal Committee (occupational safety officer); escalation to Programme Board if site fails readiness gate or incident occurs

**Adaptation Process:** Site Selection Committee conducts power-quality audit, fire-authority pre-consultation, and insurer pre-notification 6 months before scheduled unit arrival. Results captured in Site Readiness Scorecard tracking progress on power stability, hardstand preparation, security, staff liaison confirmation. If scorecard shows <90% readiness 3 months pre-arrival, Committee escalates to Board decision: (1) proceed with conditional approval and remediation plan (e.g., install voltage regulator, finalize fire-authority paperwork), or (2) defer unit by 3–6 months and promote backup site from Priority Waitlist. Fire-authority and insurer written approvals required before unit dispatch; if conditional approval is received (e.g., insurer requires detached pre-treatment pod, fire authority requires additional ventilation), Technical Committee assesses retrofit cost (USD 0.5–1.5M for detached pod) and schedule impact (+4–6 weeks); Board approves retrofit if justified or defers site. Occupational safety: VOC monitoring and respiratory-protection audits at unit site monthly during residency; air-quality results reviewed by occupational health officer; if VOC concentrations exceed threshold (per industrial hygiene standard), unit operations halt until ventilation is improved or work protocols are redesigned. Incident log tracked monthly; any handling loss (item destroyed during processing) reported to insurer within 24 hours and recorded in incident log; pattern of losses triggers review of handling procedures and crew retraining.

**Adaptation Trigger:** Site Readiness Scorecard <90% three months before scheduled arrival triggers Board decision (defer or remediate). Fire-authority or insurer refusal of pre-approval unless design modified (e.g., detached pod required) escalates to Board; approval of detached pod retrofit and budget (USD 0.5–1.5M each) must be pre-authorized. VOC or occupational-health violation during residency (exposure exceeding threshold, respiratory protection non-compliance) halts unit operations until corrected; Board informed within 24 hours. Handling loss incident (item destroyed, estimated value >USD 100K, or unique/irreplaceable) triggers incident response and insurer notification; pattern of losses (>1 per unit per year) triggers remedial Board decision (crew retraining, handling-protocol redesign, or reduced digitization tempo).

### 7. Pilot-to-Phase-Transition Gate Monitoring and Evidence Consolidation
**Monitoring Tools/Platforms:**

  - Phase 2 Gate Evidence Report (Month 20 = 2028-06-12: consolidates all pilot metrics against gate criteria—digitization success >95%, reconstruction accuracy >80%, AI accuracy >75%, flagging <20%, uptime >90%, AI precision/recall >=75%, zero incidents)
  - Phase 2 Gate Financial Readiness Report (Month 24 = 2028-10-12: Phase 1 variance <=10%, Phase 2 funding >=70% committed, contingency and reserves status, Phase 3 gap identified)
  - Design Review Gate Sign-Off (Month 20 = 2028-06-12: external reviewer certification that all designs meet performance and safety thresholds; post-freeze change-control procedures locked)
  - Parts-Depletion and Mentoring Progress Report (Month 20 = 2028-06-12: spares trajectory shows feasible management; retired-engineer curriculum >80% complete; successor competency assessments on schedule)

**Frequency:** Evidence consolidated by Month 20 (2028-06-12) for Phase 2 Gate; final evidence package reviewed at Month 24 (2028-10-12) Board gate-release meeting; same cadence for Phase 3 Gate at Months 48 (2030-10-12) and Phase 3 release at Month 60 (2031-10-12)

**Responsible Role:** Technical Committee (consolidates pilot evidence); Finance Committee (financial readiness); Programme Board (gate-release decision)

**Adaptation Process:** By Month 20 (2028-06-12), Technical Committee produces Phase 2 Gate Evidence Report comparing all pilot metrics against agreed gate criteria. Report rated traffic-light: all thresholds met = green (proceed to full Phase 2 release); >=80% of thresholds met = yellow (conditional limited tranche, with Board-approved rework and re-validation); <80% or critical threshold missed = red (governance re-assessment: potential phase deferral, scope reduction, or design rework). Finance Committee independently assesses Phase 2 financial readiness: Phase 1 variance <=10%?, Phase 2 funding >=70% committed?, contingency intact?. By Month 24 (2028-10-12), Programme Board convenes gate-release meeting. If both Technical and Financial reports are green, Board votes to approve full Phase 2 release (authorization to drawdown full USD 120M). If reports are yellow, Board votes to approve conditional limited tranche (e.g., USD 30–50M for 4–6 units) with Board-mandated rework (e.g., AI retraining, crew redesign) and Phase 2B gate at Month 30–32 (2029-04-12 to 2029-06-12) for full tranche release. If reports are red, Board triggers governance re-assessment: defer Phase 2 start (e.g., to Month 30 = 2029-04-12), reduce unit count from 12 to 8–10, reduce budget by USD 20–40M, or extend timeline to spread costs.

**Adaptation Trigger:** Gate Evidence Report traffic-light: green (proceed), yellow (conditional), or red (re-assessment). Specific triggers: any critical metric <threshold (digitization <95%, reconstruction <80%, uptime <90%, zero incidents not achieved); or cumulatively <80% of targets met. Design freeze not signed off = automatic red. Phase 2 funding <70% committed by Month 24 (2028-10-12) = automatic financial red, activating Contingency Funding Panel.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmed: All core governance components requested appear generated. Stage 2 (Internal Governance Bodies) specifies four committees with charters, membership, decision rights, and escalation paths. Stage 3 (Implementation Plan) provides 29 detailed sequential steps spanning Months 0–120 (2026-10-12 to 2036-10-12) with responsible roles, timelines, deliverables and dependencies. Stage 4 (Decision Escalation Matrix) maps 5 critical issue types (budget variance, equipment design, pilot gates, parts depletion, privacy incidents) to Programme Board with approval processes. Stage 5 (Monitoring Progress) defines five monitoring approaches with tools, frequency, adaptation triggers and responsible roles.
2. Internal Consistency Check—Qualified Pass with Noted Asymmetries: (a) Bodies and Implementation: The four committees chartered in Stage 2 (Technical, Site Selection, Legal/Privacy, Finance) align with implementation workstreams in Stage 3 (Technical Committee establishes DRG process Month 2 = 2026-12-12, Site Selection maintains Master Schedule Month 4 = 2027-02-12, Legal/Privacy develops source agreements Month 2 = 2026-12-12, Finance commissions cost audit Month 1 = 2026-11-12). (b) Escalation Matrix and Committees: The five escalation triggers in Stage 4 (budget variance >10%, design flaws post-freeze, pilot gate failure, parts-depletion infeasibility, privacy breach) correctly route to Programme Board; Committee recommendations feed Board decisions per Stage 2 decision-rights definitions. (c) Monitoring and Adaptation: Stage 5 monitoring thresholds (uptime <90%, flagging >25%, variance >5%) align with gate criteria and stop-loss rules stated elsewhere. (d) Asymmetry Noted: The Programme Board's meeting cadence (monthly Months 1–6 = 2026-11-12 to 2027-04-12, then quarterly) tapers as programme matures, yet Phase 3 scope may contract sharply and funder composition may shift (government funders may withdraw mid-programme); governance structure does not explicitly adjust for reduced Board size or shifted priorities at Months 60–120 (2031-10-12 to 2036-10-12), creating potential governance-friction risk late-programme.
3. Potential Gaps and Areas for Enhancement: (1) Independence and Conflict of Interest: Stage 2 specifies only one 'Independent external advisor' on the Programme Board (heritage or conservation expert), but does not address: (a) when funder representatives must recuse themselves (e.g., if a government funder votes on whether to give its own contribution early vs. defer it), (b) whether an independent audit function exists separate from programme staff (Finance Committee is chaired by CFO with internal accounting; no external auditor is appointed to validate cost reports before Board sees them), (c) who adjudicates disputes when a funder and an archive disagree over site prioritization (Stage 4 states disputes escalate to Board, but no tie-breaker rule exists if Board is split). (2) Project-Level Operational Authority: Stages 2–3 define committee roles but leave ambiguous the day-to-day operational authority of the Programme Director, Project Manager, and Site Manager below the Board and committee level. Examples: (a) Can the Programme Director approve a site-readiness delay of 2 weeks without Site Selection Committee escalation? (b) What is the Project Manager's authority to approve a vendor substitution if the preferred vendor delays delivery by 4 weeks? (c) If a unit arrives on-site and the host's power system is unstable, who decides whether to proceed, defer, or relocate the unit? These operational micro-decisions accumulate and can slip schedules by weeks; no governance layer captures them. (3) Clarity on Advisor and Independent-Role Contributions: The source-agreement template (Legal Committee) and design-review process (Technical Committee) both mention 'external experts' and 'independent validators,' but Stage 2 does not specify: (a) their authority relative to committee chairs (advisory only, or co-decision-making?), (b) their liability and conflict-of-interest rules (are they contractors hired for specific reviews, or standing committee members?), (c) their availability and cost (no budget allocated for external audits, legal reviews, or expert witnesses). (4) Privacy Review Panel Escalation Incomplete: The Privacy Review Panel is described as 2–3 rotating experts with 'binding' decisions (Stage 2), yet no clear appeal mechanism is defined: can an archive challenge a Panel decision labeling content as 'personal data'? Does the archive have the right to refuse the Panel's classification and halt processing? Stage 4 mentions 'external mediation' for data-protection disputes up to USD 25K, but Stage 2 does not pre-authorize this. (5) Phased Governance Transition (Months 60–120 = 2031-10-12 to 2036-10-12): Stages 2–3 establish a Programme Board and four committees for Months 0–24 (2026-10-12 to 2028-10-12) (pilot phase). By Month 48 (2030-10-12), a Fleet Sunset and Equipment Afterlife Working Group is formed (proposed). By Month 60 (2031-10-12), a Post-Programme Continuation Committee is formed. But Stage 2 does not clarify: (a) does the original Programme Board continue through Month 120 (2036-10-12), or is it formally wound down? (b) if Phase 3 scope contracts (e.g., 15 units reduced to 10–12 due to funding constraints), does the Board shrink and funder composition change? (c) if a funder withdraws and a new funder joins mid-programme, what is the Board-amendment process? This lack of clarity on mid-life governance changes creates risk of power vacuums or competing boards late-programme. (6) Monitoring Integration Loose: Stage 5 specifies five monitoring approaches (KPI tracking, parts management, AI validation, budget reconciliation, compliance), each with 'escalation to Programme Board' thresholds. However, no unified escalation dashboard or command centre is defined: (a) when five independent monitoring streams all breach thresholds in the same month, who synthesizes the risks and alerts the Board? (b) is there a governance-impact assessor who cross-references risks (e.g., 'budget overspend AND parts-depletion trigger occurring simultaneously')? (c) who convenes emergency Board sessions (within 48 hours for technical failures per Stage 4), and by what authority? (7) Source-Agreement Template Authority: Stage 3 directs Legal Committee to draft source agreements and Stage 2 states the Committee 'approves' them, but Stage 4 indicates 'Board approval' is required for any terms outside Board-approved policy. This creates potential friction: can Legal Committee and a host archive agree to a modified indemnity tier, or must every amendment go to Board? The approval chain is ambiguous. (8) Contingency and Reserve Administration: Stage 3 allocates USD 25M contingency (10% per phase) and USD 37.5M inflation reserves. Stage 4 allows Finance Committee to approve contingency draws up to USD 1M; Stage 3 mentions a 'Design Contingency Pool' (USD 5M) managed by Technical Committee, and Contingency Funding Panel (Month 24 = 2028-10-12). But no unified reserve-management governance exists: if Phase 1 Design Pool consumes USD 3M and Phase 1 contingency is only USD 6M, is the remaining USD 3M earmarked for Phase 1 or rolled to Phase 2? Can Finance Committee re-allocate contingency between phases? This ambiguity creates risk of double-counting or over-commitment.

## Tough Questions

1. By Month 3 (2027-01-12), what percentage of the USD 250M budget is committed (signed, multi-year contracts) vs. pledged (subject to annual review or conditional on undisclosed contingencies)? If committed funding is <50% of Phase 1 or <70% of Phase 2/3, what are the Board-approved fallback triggers to reduce unit count, defer phases, or extend timeline? Name the specific funders providing binding commitments and their payment schedules.
2. Show evidence that the claimed 80% AI pre-screening reduction and <20% human-review flagging rate have been tested on representative degraded, multilingual content from the three planned pilot archives. If pilot Review Pod data (Months 6–8 = 2027-04-12 to 2027-06-12) shows actual flagging >25%, what is the Board-pre-approved remediation timeline and cost? What is the stopping threshold where flagging rate triggers redesign of the entire review workflow?
3. What is the detailed parts-depletion model showing mean time between failures per tape-deck type, cannibalization yield curve, 3D-printing feasibility (tolerance validation results) and trigger point where emergency stockpile refresh is activated? Is this model complete and Board-approved by Month 2 (2026-12-12)? What is the probability-weighted forecast for uptime by Month 36 (2029-10-12) and Month 60 (2031-10-12), assuming the plan's baseline MTBF and fabrication capacity?
4. What is the reconciled total cost of the programme (capex, opex, contingency, inflation) for Months 0–120 (2026-10-12 to 2036-10-12)? If recomputed cost exceeds USD 250M by >USD 50M, which scopes (unit count, timeline, crew size per unit, or archive residency count) are explicitly authorized to contract to fit the cap? What is the Board decision threshold for activating each scope-reduction option?
5. Document the fire-authority and insurer written approvals (dated) for the Pre-Treatment Hazard Control Design Standard at one pilot site by Month 6 (2027-04-12). If approvals are conditional (e.g., requiring detached pre-treatment pod retrofit costing USD 0.5–1.5M each), what is the Board-authorized budget to retrofit all three pilots, Phase 2 units (12), and Phase 3 units (15), and what is the schedule impact (delay to Phase 2 and Phase 3 deployments)? If approvals cannot be obtained, what is the fallback (site deferral, equipment redesign, or unit deployment reduction)?
6. For each planned jurisdiction (North America, UK, EU, and others identified by Month 3 = 2027-01-12), show the jurisdiction-specific legal analysis of data-residency rules, transfer restrictions, and consent requirements under GDPR, national privacy laws, and archival-access standards. If any jurisdiction prohibits outbound data transfer or mandates in-country storage, what is the custody and archive architecture (federated, in-country mirrors, restricted tiers)? Is this analysis Board-approved before Phase 1 pilot site agreements are signed?

## Summary

This USD 250M, 10-year containerized digitization programme relies on four integrated governance layers: a Programme Board providing strategic oversight and gate-release authority; four subsidiary committees (Technical, Site Selection, Legal/Privacy, Finance) managing operational domain-specific risks; a detailed implementation roadmap spanning Months 0–120 (2026-10-12 to 2036-10-12) with explicit milestones and escalation triggers; and a decision-escalation matrix mapping 5 critical issue types to Board-level resolution. The framework prioritizes early transparency (gate criteria pre-agreed by Month 6 = 2027-04-12), honest pilot validation (stress-first approach; 80% threshold for conditional release rather than override), and three-layer escalation (Committee → Board → External Mediation). Strengths include clear decision rights (Board ≥70% consensus, programme director tie-breaker), binding commitment targets (50% Phase 1 by Month 3 = 2027-01-12), and quarterly variance reporting. Critical gaps centre on: (1) absence of defined roles for independent external validators or an audit function separate from programme staff; (2) vagueness on conflict-of-interest recusal and voting procedures when funders or archives dispute their own priorities; (3) lack of day-to-day operational governance below committee level (no defined Project Manager or Site Manager authority boundaries); (4) post-Month 60 (2031-10-12) governance transition to Phase 3 not clearly articulated (Programme Board continues unchanged, but scope may reduce and funder composition may shift); (5) integration with monitoring thresholds loose (Technical Committee receives telemetry monthly, but no published escalation dashboard or real-time alert distribution to non-Board stakeholders).