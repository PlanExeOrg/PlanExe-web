## 1. Hardware Sustainment and Parts-Depletion Validation

The plan depends on a finite, depleting stockpile of 300-500 vintage machines to sustain 30 containerized units and >90% uptime for a decade. Without validated MTBF per deck type, cannibalization yield, and 3D-printing fabrication specs, the uptime target is speculative. Parts inventory will approach critical depletion by Months 36-48 (2029-10-12 to 2030-10-12) if consumption is not modeled. Retired mentors (aged 70-80 at start) are perishable; knowledge transfer must be documented and validated before mentors exit. This is the single largest operational-feasibility risk and must be addressed before Phase 2 design is locked.

### Data to Collect

- Mean time between failures (MTBF) per vintage deck type (Tape, Film, Card) under 24/7 operational loads
- Parts-harvest yield per 10 decommissioned machines by category (heads, transports, motors, optical assemblies)
- 3D-printing and CNC fabrication specifications and tolerance validation (azimuth ±0.05mm, playback fidelity) for 20+ critical part types
- Condition assessment of all 300-500 acquired vintage machines (serial, functional status, head wear, parts-harvest potential)
- Mentor knowledge transfer curriculum: 50-80 critical repair competencies per line type documented in video and written protocols

### Simulation Steps

- Use broadcast-industry MTBF literature and bench-test 10 reference tape decks and film scanners under continuous operation (16+ hrs/day) for 8-12 weeks to measure time-to-failure distribution
- Run cannibalization simulation: harvest parts from 20 non-operational machines; categorize by condition and usability; calculate yield percentage per part type
- Test 3D-printing and CNC fabrication using CAD models of critical parts; measure fabricated samples on a precision metrology lab (azimuth fixtures, capstan sleeves, pinch rollers); validate playback fidelity on reference decks using ISO tape standards
- Create a parts-depletion curve model (spreadsheet or simulation software): inputs MTBF per deck, unit-years of operation, cannibalization yield, re-manufacture trigger at 50% depletion; output: spares inventory over 120 months; identify inflection point where spares become critical
- Document condition of all 300-500 acquired machines using a standardized intake form: serial number, format, functional status, measured head azimuth offset, transport speed drift, layer-adhesion risk score; photograph and tag each unit

### Expert Validation Steps

- Engage a broadcast equipment restoration engineer (e.g., from Ampex/Studer legacy community, or a senior technician from NPR/PBS stations) to review MTBF estimates and parts-harvest methodology against real-world experience and published specs
- Have a precision metrology lab (e.g., a university engineering department or third-party QC firm certified in ISO 10012) measure fabricated parts and validate tolerance compliance and playback fidelity on archival-standard reference decks
- Consult the retained 6-8 retired-engineer mentors (secured by Month 1 = 2026-11-12) to validate the parts-depletion model against their experience with equipment failure patterns and repair frequency; request written sign-off on MTBF and re-manufacture assumptions
- Commission an independent audit of the Vintage Transport Sustainment Strategy by a heritage preservation engineer (e.g., from IU MDPI, Library of Congress Packard Campus, or equivalent) to confirm that the plan's 300-500 stockpile and 50% re-manufacture trigger are realistic for 30 units over 10 years

### Responsible Parties

- Vintage Equipment Sustainment Engineer (Chief Parts Manager)
- Parts Engineering team (3-5 fabrication and testing engineers)
- Retired-engineer mentors (6-8 contractors, Months 1-48 = 2026-11-12 to 2030-10-12)
- Independent broadcast-equipment restoration expert (external consultant)
- Precision metrology lab (third-party QC firm)

### Assumptions

- **High:** Mean time between failures per deck type can be estimated from broadcast-industry literature and 8-12 weeks of bench testing; actual field MTBF will not differ >20% from controlled-lab estimates.
- **High:** 3D-printing and CNC fabrication can achieve azimuth tolerance ±0.05mm and playback fidelity comparable to original parts, validated on reference-grade decks.
- **High:** At least 6-8 retired broadcast engineers (aged 70-80) are available and willing to commit to 24-month mentoring contracts with retention bonuses (USD 50-100K each) extending to Month 48 (2030-10-12).
- **Medium:** Cannibalization yield (usable parts per 10 non-operational machines) averages 40-60% per part category; degraded machines yield fewer parts.
- **Medium:** A 50% spares-depletion trigger is operationally conservative; fleet uptime remains >90% if re-manufacture is triggered at 50% and completed within 8 weeks.

### SMART Validation Objective

By Month 2 (2026-12-12), commission parts-depletion model with MTBF per deck type and re-manufacture yields. By Month 4 (2027-02-12), validate 3D-printing specs on 10 priority parts; measure azimuth tolerance ±0.05mm and playback fidelity on reference decks. By Month 6 (2027-04-12), complete condition assessment of all 300-500 machines. By Month 10 (2027-08-12), deploy parts-consumption telemetry dashboard with 50% depletion trigger; confirm no unplanned stockouts in first 12 months of operations.

### Notes

- Parts model is critical to uptime target credibility; without it, Phase 2 gates cannot assess feasibility.
- Mentor knowledge loss between Months 24-48 (2028-10-12 to 2030-10-12) leaves Phase 3 operating with partially-trained engineers; curriculum documentation must be complete by Month 4 (2027-02-12).
- 3D-printing tolerance validation is the largest technical risk in fabrication; failure to meet ±0.05mm azimuth specs forces reliance on external vendors or emergency stockpile refresh (USD 15-25M unbudgeted).
- Spares depletion curve, if unfavorable, may trigger governance re-assessment of unit count or timeline by Month 36 (2029-10-12).
- Fallback: if fabrication fails, contingency stockpile refresh budget USD 15-25M must be identified or unit count reduced.


## 2. AI Pre-Screening Accuracy and Review Bottleneck Validation

The plan assumes AI pre-screening reduces human-review load by 80% (only 20% of content flagged for human review), driving crew composition (12-15 reviewers per unit). This assumption is untested on real degraded, multilingual pre-digital content and is the largest cost driver. If actual flagging is 35-40%, reviewer headcount triples from 12-15 to 40-50 per unit, adding USD 15-25M annual payroll at full scale and exceeding the USD 25M average annual budget. Pilot validation by Month 8 (2027-06-12) is critical; if accuracy falls below 75% precision/recall or flagging exceeds 25%, crew composition and Phase 2 design must be redesigned before replication.

### Data to Collect

- Precision, recall and false-positive rate of AI pre-screening for copyright, privacy and classification markers on degraded, multilingual 1950-2000 content
- Actual human-review hours per content hour measured on pilot operations (flagging percentage and review-cycle throughput)
- Inter-rater agreement (Cohen's kappa) on copyright, privacy and classification marker detection among 3-5 expert human reviewers using gold-standard labeled dataset
- Metadata extraction accuracy (speech-to-text confidence, OCR accuracy on degraded images, automated field extraction) per format and degradation level
- AI model training-data provenance, model-card documentation, and versioning for regulatory compliance and reproducibility

### Simulation Steps

- Procure 100-200 representative samples from three proposed pilot archives (Tape, Film, Card formats); balance across degradation levels (condition scores 1-5) and languages (English, French, Spanish, others present in collections); emphasize heavily degraded items (scores 3-4)
- Use CVAT (Computer Vision Annotation Tool) or similar open-source labeling platform to have 3-5 expert human reviewers independently annotate each sample for: copyright markers (presence/absence, confidence 1-5), privacy indicators (PII types: names, medical, financial, personal correspondence; presence/absence; confidence), classification markers (government, military, proprietary; presence/absence). Calculate inter-rater agreement using Cohen's kappa metric; threshold >=0.75
- Run the AI pre-screening pipeline on the labeled dataset; for each category-format pair, compute precision (correct flags / all flags), recall (detected flags / all present flags), false-positive rate (incorrect flags / negatives). Document results in a results matrix (rows: format × degradation; columns: copyright precision/recall/FP, privacy precision/recall/FP, classification precision/recall/FP)
- Pilot-review pod (Months 6-8 = 2027-04-12 to 2027-06-12): route all AI-flagged items and a stratified 5-10% random sample of non-flagged content through human review; measure: (a) actual flagging percentage (flagged items / total items processed), (b) mean review time per item (hours), (c) total review hours per 1,000 content hours. Compare actual vs. assumed (20% flagging, 0.2 review hours per content hour)
- Test metadata extraction accuracy: extract a sample of speech-to-text transcripts, OCR'd text from film, catalog fields; have archivists rate accuracy on 1-5 scale; measure aggregate confidence and error categories (false insertions, deletions, substitutions per 1,000 words)

### Expert Validation Steps

- Engage a copyright and cultural-heritage legal expert to review AI flagging accuracy on copyright markers; verify that detected watermarks, broadcast metadata, and restricted-content indicators match legal definitions of copyright infringement under relevant jurisdictions
- Involve a data-protection officer or privacy lawyer (familiar with GDPR, UK DPA, multilingual content) to validate AI privacy-marker detection; test false-negative rate on de-identification and PII masking
- Have an independent ML validation specialist (not the AI development team) audit the pre-screening pipeline and retraining process; verify that the labeled dataset is representative, inter-rater agreement is defensible, and retraining improves metrics without overfitting
- Commission an archival standards consultant (e.g., from SAA, IASA, or a national archive) to validate metadata accuracy against preservation standards; confirm that automated metadata meets archival discovery and access requirements

### Responsible Parties

- AI Signal Processing and Metadata Engineering Lead (2-3 engineers)
- AI validation specialist (independent external consultant)
- Privacy Review Panel (2-3 data-protection experts)
- Copyright and cultural-heritage legal expert (external consultant)
- Multilingual review team (12-15 reviewers per unit in pilots)

### Assumptions

- **High:** AI pre-screening achieves >=75% precision and >=75% recall on copyright, privacy and classification markers across all format-degradation pairs; if below, retraining on domain-specific labeled data will achieve the threshold.
- **High:** Actual human-review load (flagging rate and hours per content hour) measured on pilot content will not exceed the assumed 20% flagging by more than 25% (i.e., actual flagging <=25%); if >30%, workflow redesign is required.
- **Medium:** Inter-rater agreement (Cohen's kappa) on expert labeling of copyright, privacy and classification markers will achieve >=0.75 on a representative 100-200 sample, indicating reliable ground truth.
- **Medium:** Metadata extraction accuracy (speech-to-text, OCR) will average >70% confidence on degraded content; archivists will accept this for discovery, with provision for manual correction of low-confidence fields.
- **Low:** False-positive rate (non-relevant items flagged as copyright/privacy/classified) will be <15%; archivists accept this as review overhead.

### SMART Validation Objective

By Month 4 (2027-02-12), procure samples and build gold-standard labeled dataset; test AI pipeline and publish precision/recall/FP rates per category-format. By Month 6 (2027-04-12), begin pilot-review pod. By Month 8 (2027-06-12), measure actual flagging percentage and review hours; if any metric (precision, recall, flagging) falls outside acceptable range, trigger immediate retraining or workflow redesign. Ensure results are published to Programme Board as go/no-go evidence for Phase 2 gate by Month 8 (2027-06-12).

### Notes

- AI accuracy is the largest cost assumption risk; validation must complete before Phase 2 design freeze (Month 20 = 2028-06-12).
- False-negative rate (PII not detected, leading to unlawful upload) is more critical than false-positive rate; must be measured explicitly and kept <5% if possible.
- If flagging >30% and crew scaling is infeasible within budget, alternative review models (tiered review, delegation to host archives, remote hubs) must be designed and piloted.
- Metadata accuracy <70% will degrade user discoverability and may be unacceptable to archives; escalate if observed in pilot.
- Retraining adds 2-4 weeks of engineering time and 1-2 weeks of compute; must be budgeted and risk-managed before Phase 1 design freeze.


## 3. Budget Reconciliation and Staffing Model Validation

The plan states 50-60 staff per unit at USD 2-3M opex per unit-year, but recomputation shows payroll alone equals USD 2.5-4.2M, implying total opex of USD 3-5M per unit-year. At full scale (1,500-1,800 staff), annual payroll is USD 75-126M against a USD 25M average annual budget. This critical mismatch must be reconciled by Month 4 (2027-02-12) before Phase 1 procurement is locked. Either staffing or budget assumptions must change, or host cost-sharing must materialize. The USD 280M funding gap and inflationary pressure on Phase 3 (USD 70M allocated but approximately USD 301M needed) must be resolved upfront, not discovered mid-phase.

### Data to Collect

- Itemized opex per MIU over 12 months: labor (headcount and loaded cost per role, by geography), equipment consumables, depreciation, parts, utilities, satellite/fiber connectivity, logistics, insurance
- Actual loaded labor costs from pilot staffing pod (Months 3-6 = 2027-01-12 to 2027-04-12): payroll, benefits, taxes, travel, visa, relocation per position and region
- Recomputed total unconstrained cost for 30 units over 10 years, broken down by phase (capex, equipment, training, opex)
- Budget variances and cost drivers: what line items exceed initial assumptions by >10%
- Host institution cost-sharing contributions per MIU (in-kind power, space, liaison; cash co-funding if any); quantify value of in-kind contributions

### Simulation Steps

- Conduct a line-item cost-buildup audit: interview program staff, review vendor quotes, and benchmark against comparable digitization programs (Indiana University MDPI, Library of Congress Packard Campus, British Library UOSH). Create a detailed opex spreadsheet for one representative MIU (mid-scale host site, moderate labor costs) covering 12 months of operations: staff roles (engineers, operators, reviewers, maintenance, logistics, QC), loaded costs per region (Northern Virginia, UK, Netherlands, Australia—if international), equipment consumables (tapes, cleaning supplies, parts for replacement), depreciation on containerized equipment, utilities (power, climate control, connectivity), insurance, and overhead allocation
- Run the pilot staffing pod (Months 3-6 = 2027-01-12 to 2027-04-12) at the first hub site with a representative crew (2-3 engineers, 2-3 junior operators, 5 reviewers, 1-2 logistics staff). Measure and record: actual monthly payroll (wages + benefits + taxes), hours worked per role, training ramp-up time to full productivity, travel and visa costs, relocation expenses. Extrapolate loaded cost per unit-year and per full-scale fleet (1,500-1,800 staff at 30 units)
- Create three budget scenarios in a spreadsheet: (A) baseline (USD 250M cap, staffing 50-60 per unit as stated, opex USD 2-3M per unit-year), (B) +15% inflation scenario (materials and labor costs increase 15% by Month 120 = 2036-10-12, cumulative ~22% escalation at 2%/year), (C) +30% inflation scenario (cumulative ~34% escalation at 3%/year). Project each phase's total cost (capex, opex, contingency, reserves) and compare against phase budgets. Identify shortfalls and surpluses per phase
- Model three staffing alternatives: (A) full resident (50-60 per unit, payroll-heavy), (B) embedded core + host training (25-30 per unit, moderate payroll), (C) centralized review hubs (15 on-site + 20 remote, payroll-light). For each, calculate opex and crew composition, and assess operational impact (uptime, review latency, knowledge transfer)

### Expert Validation Steps

- Engage an independent infrastructure cost auditor (consulting firm with large-project experience in digitization, preservation or similar capital programs) to review the line-item budget, validate assumptions against industry benchmarks, and provide a reconciled opex model with confidence intervals
- Have a human-resources consultant (familiar with international staffing, labor costs per region, benefits loading per country) validate the loaded-cost assumptions per role and geography; confirm that salaries are competitive for talent retention
- Commission a financial analyst or project management office to model the three budget scenarios, sensitivity-test key assumptions (labor escalation, parts costs, logistics rates), and provide projected outturn against the USD 250M cap with Monte Carlo confidence ranges
- Consult with host institution representatives (from three pilot archives) to quantify in-kind contributions (power, space, liaison hours) and confirm willingness and capacity to provide cost-sharing per MIU residency

### Responsible Parties

- Finance Lead and Budget Manager
- Independent cost auditor (external consulting firm)
- Human-resources consultant (external)
- Financial analyst or PMO (internal or external)
- Pilot staffing pod supervisors (Months 3-6 = 2027-01-12 to 2027-04-12)

### Assumptions

- **High:** Loaded labor cost (salary + benefits + taxes + overhead) per staff member averages USD 50-70K globally; regional variation (Northern Virginia 10% higher, Netherlands 5% lower, Australia 5% higher) is accounted for in the opex model.
- **High:** Stated opex of USD 2-3M per unit-year can be reconciled with staffing of 50-60 per unit if in-kind host contributions (power, space, liaison) are valued and counted outside the program cap.
- **High:** At least 50% of Phase 1 (USD 30M of USD 60M) can be secured as binding commitments (not pledges) by Month 3 (2027-01-12); Phase 2 and Phase 3 follow at >=70% committed before release.
- **Medium:** Host institution in-kind cost-sharing (power, space, liaison) will average 15-25% of unit opex per residency; cash co-funding (if any) is unquantified but candidate (proposed threshold).
- **Medium:** Annual cost escalation (labor, parts, logistics) averages 2-3% per year; 15% contingency per phase and explicit inflation reserves (15% of phase budget) will cover increases through Month 120 (2036-10-12).

### SMART Validation Objective

By Month 1 (2026-11-12), commission independent cost audit. By Month 3 (2027-01-12), run pilot staffing pod for 3 months; measure actual loaded costs per role. By Month 4 (2027-02-12), publish reconciled budget and three scenarios (baseline, +15%, +30% inflation); lock one scenario and publish binding decision on staffing model (50-60, 25-30, or 15-20 per unit). Ensure Phase 1 procurement cannot begin until budget and staffing are signed off by Programme Board.

### Notes

- Budget reconciliation is prerequisite for credible Phase 1 design; without it, all downstream cost and schedule forecasts are suspect.
- Funding gap (~USD 280M before reserves) must be addressed via host cost-sharing, new funders, or unit-count reduction; no single lever exists.
- Inflation modeling is essential: 2% annual escalation compounds to ~22% by Month 120 (2036-10-12); Phase 3 especially vulnerable to cost overrun if not reserved.
- Contingency and inflation reserves proposed (USD 25M contingency + USD 37.5M inflation = USD 62.5M total inside the cap) leave only USD 0-10M headroom after risks.
- Fallback: if reconciliation forces unit count <24, trigger governance re-assessment of scope and timeline.


## 4. Privacy Compliance and Data-Residency Framework Validation

The plan processes degraded 1950-2000 multilingual content containing personal data, medical records, classified government records and copyright-restricted works across multiple jurisdictions. Privacy or data-residency breach (GDPR fines up to 4% of global revenue for organizations) could halt the network; false negatives in AI pre-screening of sensitive items create unlawful processing risk. Source agreements, Privacy Review Panel decisions and custody framework must be legally defensible and jurisdictionally compliant before pilot operations begin. A single GDPR breach triggered by inadequate pre-screening could result in fines of USD 5-20M+ for program funders, regulatory investigation freezing operations for months, and archive partnerships terminating network-wide.

### Data to Collect

- Jurisdiction-specific data-protection laws and data-transfer restrictions for all planned host countries (GDPR, UK DPA, national privacy acts, data-residency rules)
- Source-agreement legal templates customized per jurisdiction, covering digitization scope, privacy commitment, legal basis for processing, data-residency requirement, breach-notification protocol, and indemnity terms
- Privacy Impact Assessment (DPIA per GDPR Article 35) for the entire AI pre-screening + human review + archival upload pipeline, identifying high-risk processing and mitigation measures
- Custody model choice and perpetual-storage funding commitment (post-Month 120 = 2036-10-12) from at least one national or regional archive partner
- Incident-response protocol and test results: 24-hour insurer notification, 72-hour regulatory notification, 10-day root-cause analysis for GDPR-level breaches

### Simulation Steps

- Create a Regulatory Jurisdictional Matrix: for each planned host country (USA, UK, Canada, Australia, Netherlands, Germany, France, others), list applicable data-protection laws (GDPR, UK DPA 2018, provincial/state acts), personal-data definitions (what constitutes PII, medical data, classified records), data-transfer restrictions (prohibited transfers, Standard Contractual Clauses, adequacy decisions), legal-basis options (consent, public-task, vital interest), and breach-notification thresholds (GDPR 72 hours vs. others)
- Draft a Standardized Source-Agreement Addendum (5-10 pages) covering: (a) digitization scope and data processing (what content types, formats, languages); (b) privacy commitment (categories of personal data identified, restricted-tier handling); (c) legal basis for collection, processing and archival (e.g., consent vs. public-interest exemption); (d) data-residency requirement (in-country storage, federated archive, central backup with encryption); (e) data-subject rights (access, deletion, portability per GDPR Articles 15-20); (f) breach-notification obligations (to regulatory authority within 72 hours if GDPR; to host archive within 24 hours; public notification if high-risk); (g) retention period (perpetual archival vs. timed deletion); (h) indemnity and liability allocation. Create jurisdiction-specific annexes (EU GDPR addendum, UK DPA addendum, US state-level variations)
- Conduct a Preliminary Data Protection Impact Assessment (DPIA): document all processing steps (AI pre-screening of content, PII detection, human review flagging, upload to central archive, restricted-tier assignment). For each step, identify: processing purpose, legal basis, data types involved (PII, medical, classified), retention period, third parties with access (reviewers, archivists, data-governance staff), and risk level (high-risk automated flagging, cross-border transfer of restricted data, etc.). Propose mitigation: encryption, access controls, audit logging, data-minimization (e.g., anonymization where feasible)
- Model three custody scenarios: (A) Archive-held masters (host archive keeps encrypted master copy; central program receives only anonymized metadata and access derivatives). (B) Federated network (masters replicated to 2-3 geographically separate national repositories per PREMIS standards; restricted data stored only in-country per residency rules). (C) Offline deposit (masters written to archival media—LTO tape or M-DISC—and physically stored with each archive; central program receives non-identifying manifest only). For each scenario, estimate storage cost, data-recovery time, and compliance with data-residency rules per jurisdiction. Secure written commitment from at least one national or regional archive to assume stewardship of masters and fund perpetual storage
- Test the incident-response protocol on paper and via simulation: trigger a simulated privacy breach (e.g., PII discovered in uploaded content); document internal escalation (within 4 hours to Privacy Review Panel and Data Governance Office), archive notification (within 24 hours), regulatory notification (within 72 hours for GDPR, or required timeline per local law), and root-cause analysis (within 10 business days). Record decision log and remediation steps

### Expert Validation Steps

- Engage a GDPR and UK Data Protection Act specialist (e.g., a barrister or in-house counsel at a UK cultural-heritage institution) to review the Standardized Source-Agreement Addendum and Jurisdictional Matrix; confirm legal compliance with GDPR Articles 6 (lawful basis), 9 (special categories), 17 (right to erasure), 35 (DPIA) and UK DPA Schedule 1 equivalents
- Have a data-protection officer (DPO) or privacy counsel from each planned host jurisdiction (e.g., Netherlands for EU, Canada, Australia) review the jurisdiction-specific annexes and confirm that the legal basis, data-residency, and breach-notification terms align with local law
- Commission an independent audit of the DPIA: have a third-party privacy consultant review the high-risk processing steps (AI pre-screening, cross-border transfer of restricted data) and validate that proposed mitigations (encryption, access controls, audit logging) are sufficient and aligned with GDPR Recital 75 (data protection by design)
- Consult with national archives (e.g., UK National Archives, National Archives of Australia, Library of Congress Packard Campus) to validate the proposed custody models and secure binding stewardship commitments for post-Month 120 (2036-10-12) perpetual storage

### Responsible Parties

- Privacy, Rights and Legal Compliance Officer (1-2 legal counsel, full-time)
- Data Governance Office (Chief Privacy Officer, 1-2 specialists)
- Privacy Review Panel (2-3 data-protection experts rotating per site, volunteer or contracted)
- GDPR and DPA legal experts (external barristers or in-house counsel, per jurisdiction)
- Independent privacy consultant for DPIA audit (external)

### Assumptions

- **High:** A Standardized Source-Agreement Addendum customized per jurisdiction can be negotiated and signed by all three pilot archives by Month 6 (2027-04-12), with no fundamental objections to privacy commitment or data-residency terms.
- **High:** Data-residency rules per jurisdiction (e.g., GDPR restrict cross-border transfer without Standard Contractual Clauses; some countries prohibit personal data export) can be satisfied by a federated or archive-held custody model; centralized storage of all data is infeasible.
- **High:** At least one national or regional archive (e.g., Library of Congress, British Library, Nationaal Archief) will commit in writing to perpetual stewardship of masters and fund long-term storage and format migration beyond Month 120 (2036-10-12).
- **Medium:** Privacy Review Panel (2-3 rotating data-protection experts) can process flagged-item decisions within 2-4 hours per item without creating an upload bottleneck; tier-1 reviews (low-risk public content) can be automated.
- **Medium:** Incident-response protocol (24-hour insurer notification, 72-hour regulatory notification) can be executed reliably across all sites; all staff will be trained and tested annually on breach-response procedures.

### SMART Validation Objective

By Month 1 (2026-11-12), establish Data Governance Office and begin legal mapping. By Month 2 (2026-12-12), complete Jurisdictional Matrix and begin DPIA. By Month 3 (2027-01-12), publish Standardized Source-Agreement Addendum with jurisdiction-specific annexes; establish Privacy Review Panel. By Month 4 (2027-02-12), finalize three custody model scenarios and identify lead stewardship archive. By Month 6 (2027-04-12), obtain signed source agreements from all three pilot archives with zero legal/privacy objections. Deploy incident-response protocol test and confirm all staff trained by Month 6 (2027-04-12).

### Notes

- Privacy compliance is existential risk; a single GDPR breach or data-residency violation can halt the network and trigger fines exceeding USD 5-20M.
- Source-agreement legal review per jurisdiction is time-consuming (4-8 weeks per jurisdiction); must begin immediately in Month 1 (2026-11-12).
- Custody model choice (archive-held vs. federated vs. offline) is interdependent with data-residency rules; must be locked before Archive Stewardship commitments are sought.
- Perpetual-storage funding (post-Month 120 = 2036-10-12) must be explicitly committed by stewardship archive; vague 'best-efforts' pledges are insufficient.
- Fallback: if stewardship commitment cannot be secured, consider depositing masters as offline media with each host archive (eliminates central storage but complicates access and format migration).


## 5. Pilot Host-Archive Partnerships and Fire-Authority/Insurer Approvals

On-site residencies depend entirely on archive insurers and fire authorities approving containerized pre-treatment. A single handling incident destroying a unique collection, a thermal event, chemical exposure, or privacy breach during pre-screening could trigger incident escalation, insurer policy cancellation, and partnership termination. Binding written approvals from at least one insurer and fire authority must be secured by Month 6 (2027-04-12) before the first unit is placed on-site; this approval letter serves as a template for all subsequent sites. Without approvals, deployments are blocked and schedule slips 3-6 months. The tiered-indemnity structure and pooled loss reserve (USD 2-5M) distribute risk between the program and host archives, enabling signing of source agreements.

### Data to Collect

- Written approval letters from insurers and fire authorities at each pilot host archive authorizing on-site containerized pre-treatment (baking ovens, humidity chambers, on-board media storage, generators)
- Executed multi-year host-archive agreements (3 pilot sites) specifying residency duration, media intake criteria, scope of digitization, pre-treatment protocols, on-site liaison role, power/hardstand/security provision, source-agreement and indemnity terms, and incident-escalation procedures
- Site readiness assessments: power capacity (kW stable or generator backup), hardstand condition (level concrete, drainage), security access (perimeter, guard or camera), fire-authority sign-off documentation, insurer coverage letter
- Hazard Control Standard document specifying sealed oven designs, thermostat tolerances, smoke/fume detection, fire suppression, and VOC exhaust filtration, validated by fire-safety consultant
- Tiered indemnity structure agreements: Full Coverage tier (stable items, full indemnity), Attempt-at-Own-Risk tier (high-risk items, signed waiver), Deferred tier (unsafe items for later conservation), with condition-grading criteria per format

### Simulation Steps

- Conduct a pre-deployment hazard analysis at one representative pilot site: document thermal, chemical and fire hazards from baking ovens (peak temperature, duration, time to thermal equilibrium), humidity chambers (desiccant or active humidity control, range ±5% RH), media storage on-site (fire load, combustibility of tape reels and film cans), and diesel or natural-gas generators (fuel type, volume, emission profile, noise level). Model thermal and chemical-release scenarios using worst-case assumptions (oven thermostat fails high, humidity chamber vents without containment, generator fuel leaks). Estimate incident probability (low/medium/high) and financial exposure per scenario
- Retrofit one pilot container to specification (sealed oven with internal temp sensor ±2°C, thermostat with upper-limit alarm, VOC exhaust through activated-charcoal filter and monitored outlet, fire suppression rated for archival materials per NFPA standards). Test the oven on non-archival materials; verify thermal stability and venting. Document design changes and certification
- Prepare for submission to insurer and fire authority: compile technical drawings (container layout, oven schematic, electrical single-line, generator placement), MSDS data for consumables (cleaning solvents, preservation chemicals), emergency-response plan (evacuation, fire-suppression activation, emergency contact tree), insurance-claim history (if any) from comparable operations. Identify a professional consultant (fire engineer or insurer's loss-prevention specialist) to shepherd approval through local authority review cycles (typically 2-4 weeks per submission)
- Develop tiered-indemnity structure and condition-grading intake form: for each item received, assess condition (azimuth drift, layer adhesion, shrinkage, color fade, readability) and assign to Full Coverage (stable, safe to handle), Attempt-at-Own-Risk (high-risk but valuable, signed waiver by archive), or Deferred (too fragile for current processing, hold for future conservation). Test grading criteria on 20-30 sample items with archive curators; measure inter-rater agreement on tier assignment; refine thresholds if disagreement >10%
- Prepare incident-response protocol: document escalation path (crew lead -> Central Operations -> Archive Director -> Insurer -> Data Governance Office -> Programme Director, all within 4 hours), 24-hour insurer notification template, 72-hour regulatory notification (if GDPR/DPA breach or environmental violation), forensic-investigation scope (photograph damage, preserve evidence, interview staff within 48 hours), 5-business-day claim filing. Test protocol with simulated scenarios; time each step

### Expert Validation Steps

- Engage a certified fire-safety engineer (PE or equivalent) to review the Hazard Control Standard design, verify that thermal, chemical and fire-suppression specs meet NFPA 72 (smoke detection), NFPA 2001 (clean-agent fire suppression), EPA VOC emissions limits, and local fire codes. Obtain written sign-off on design safety
- Have an insurance broker specializing in cultural institutions (archives, museums, libraries) review the tiered-indemnity structure and loss-reserve allocation; confirm that loss-reserve funding (USD 2-5M) is adequate for first-loss coverage and that premium costs are reasonable
- Commission an industrial-hygiene consultant to validate VOC exhaust design and monitor air quality during pilot baking cycles; ensure worker exposure is below OSHA limits (e.g., formaldehyde <0.1 ppm, acetic acid <10 ppm per OSHA PEL)
- Consult with archives' legal counsel (at each of the three pilot sites) to review the source-agreement template and tiered-indemnity terms; obtain archive sign-off that privacy, copyright, liability and data-residency terms are acceptable

### Responsible Parties

- Privacy, Rights and Legal Compliance Officer (source agreements)
- Fire-safety engineer (external consultant)
- Insurance broker (external)
- Site Operations and Logistics Coordinator (site readiness)
- Central Risk and Compliance Manager (incident response, indemnity)
- Archive partners (3 pilot sites; host legal counsel)

### Assumptions

- **High:** Written approval from at least one archive's insurer and fire authority can be obtained by Month 6 (2027-04-12) for the Hazard Control Standard design; this letter is transferable to other sites as a template.
- **High:** Multi-year host-archive agreements (minimum 2-3 years of residency options) can be signed by Month 6 (2027-04-12) with clear terms on media handling, indemnity, breach notification and incident escalation.
- **High:** A Tiered Indemnity Structure (Full Coverage, Attempt-at-Own-Risk, Deferred) and Pooled Loss Reserve (USD 2-5M) will be accepted by archives and insurers as adequate risk allocation; no archive will demand 100% indemnity for all items.
- **Medium:** One archive's insurer and fire authority approval can be secured by Month 6 (2027-04-12) without requiring detached pre-treatment pod fallback (which would add USD 1.5-4.5M and 4-6 weeks per site).
- **Medium:** Incident-response protocol can be executed within stated timelines (4-hour escalation, 24-hour insurer notification, 72-hour regulatory notification) across all sites without procedural failures or delays.

### SMART Validation Objective

By Month 2 (2026-12-12), commission fire-safety and hazard analysis. By Month 4 (2027-02-12), develop Hazard Control Standard and retrofit one pilot container. By Month 6 (2027-04-12), obtain written fire-authority and insurer approval at one pilot site; sign multi-year host agreements with all three pilot archives; publish approval letter as template. Deploy incident-response protocol test. Measure: zero site-approval delays beyond Month 6 (2027-04-12); all legal/privacy terms accepted without fundamental objections; incident-response test completed within stated timelines.

### Notes

- Fire-authority and insurer approvals are gatekeeping for pilot operations; without them, Unit 1 cannot be deployed by Month 6 (2027-04-12).
- Approval timelines vary by jurisdiction and local fire codes; should anticipate 4-8 weeks per submission; start outreach in Month 2 (2026-12-12).
- Detached pre-treatment pod fallback (USD 1.5-4.5M, 4-6 weeks delay per site) is triggered if on-site approval cannot be obtained; must be budgeted but not assumed.
- Incident-response protocol must be tested with archive staff and insurers before pilot operations; dry-run simulations recommended.
- Fallback: if approval cannot be secured at pilot sites, consider fixed-facility alternatives (relocating pre-treatment to archive's own facilities or to a regional conservation lab).


## 6. Phased Funding and Funder Commitment Validation

The plan's three phases depend on 15+ funder organizations operating on annual budget cycles, with Phase 2 and Phase 3 releases tied to gate criteria. If any major funder delays commitment or pledges fall short of binding contract levels, gate releases slip 3-6 months while media continues degrading. The USD 250M cap is tight; any cost overrun or schedule delay that forces Phase 3 to extend past Month 120 (2036-10-12) exceeds media degradation timelines and abandons the most endangered collections. Binding commitments and a contingency funding facility must be in place by Month 3 (2027-01-12) to credibly release Phase 1 procurement. Host cost-sharing (if materialized) reduces program-budget pressure but requires explicit quantification and written commitment upfront.

### Data to Collect

- Binding, multi-year funding commitments from all 15+ funder organizations (government archives, cultural foundations, technology companies), translated from pledges into legal contracts with milestone-release conditions
- Commitment Registry matrix: funder name, pledged amount, commitment status (pledged vs. intent-to-commit vs. committed-with-conditions vs. fully-committed), expected release schedule (tranches tied to gates), contingency conditions (milestones, variance limits), and override clauses
- Identified backup and contingency funding sources (USD 15-20M facility) to cover 2-3 months of opex if Phase 2 or Phase 3 release tranches slip due to gate delays
- Actual cost performance in Phase 1 (Months 0-24 = 2026-10-12 to 2028-10-12): cumulative variance per line item (labor, equipment, parts, logistics), projected outturn for Phase 2 and Phase 3, monthly cost-tracking reports
- Host institution cost-sharing contributions per MIU residency (in-kind power, space, liaison hours; quantified in dollar equivalent), and any cash co-funding from consortium members

### Simulation Steps

- Create a Funding Commitment Registry spreadsheet: for each of the 15+ identified funder organizations, list: organization name, pledged amount (USD), commitment status (pledged, intent-to-commit, committed-with-conditions, fully-committed-with-binding-contract), conditions tied to commitment (gate criteria met, milestones achieved, variance limit), release schedule (Phase 1 tranches, Phase 2 conditional on Phase 1 gates, Phase 3 conditional on Phase 2 gates), and legal status (verbal, letter of intent, signed contract). By Month 3 (2027-01-12), convert at least 50% of Phase 1 (USD 30M of USD 60M) from pledged to committed (binding contract) status. Document the conversion process: legal language exchanged, negotiation of milestone-release conditions, sign-off by funder finance and program leadership
- Model three funding scenarios: (A) baseline, all funder pledges materialize on time, no mid-phase delays; (B) 20% slippage, 3-4 funders delay commitment by 3-6 months, requiring bridge facility or deferral of Phase 2 start; (C) 30% loss, two major funders (e.g., government archive, large foundation) withdraw or reduce pledges mid-programme, forcing scope reduction or Phase 3 deferral. For each scenario, calculate impact on Phase 2 release date, unit count, and cash-flow requirements
- Establish a Funding Variance Tracking dashboard: measure actual spend per phase (payroll, equipment, parts, logistics, utilities) against budget per line item monthly. Calculate cumulative variance and project total outturn for each phase. If cumulative variance exceeds +10% overspend, flag for governance escalation. If Phase 1 spending is tracking 15%+ under budget (indicating slower ramp-up or scope reduction), adjust Phase 2 funding release schedule accordingly
- Quantify host institution cost-sharing potential: for each of the three pilot archives and planned Phase 2 host sites, assess in-kind contributions—electrical power supply (kW × months of residency × utility rate), facility space (hardstand rental equivalent), staff liaison hours (FTE × months × loaded wage). Aggregate across all sites (e.g., 30 residencies × average 8 months = 240 unit-months). Model sensitivity: if host cost-sharing averages 15-25% of opex per unit (USD 0.375-0.625M per unit × 30 units = USD 11.25-18.75M total), do host commitments materialize as promised?

### Expert Validation Steps

- Engage a nonprofit/foundation relations specialist to review funder terms and identify any exclusivity, training-data, or intellectual-property restrictions that might conflict with archive trust or source-agreement terms; negotiate modifications if necessary
- Have a financial analyst or project controls officer (PMO) review cost-tracking methodology and validate variance projections; confirm that the dashboard metrics align with approved budget and funder reporting requirements
- Consult with host archive finance directors (at least three pilot sites) to confirm in-kind cost-share valuations (power rates, facility rental, staff FTE) and secure written commitments to provide contributions at specified levels
- Commission a contingency-funding advisor (infrastructure finance consultant) to identify and pre-qualify backup funding sources (additional government funders, emergency endowment draws, short-term bridge loans); confirm that USD 15-20M facility can be activated within 4-6 weeks if needed

### Responsible Parties

- Finance Lead and Budget Manager
- Programme Director (funder negotiations)
- Nonprofit/foundation relations specialist (external consultant)
- Financial analyst or PMO (cost tracking)
- Host archive finance directors (cost-sharing commitments)

### Assumptions

- **High:** At least 50% of Phase 1 (USD 30M of USD 60M) can be converted from pledges to binding multi-year contracts by Month 3 (2027-01-12); remaining pledges commit by Month 6 (2027-04-12).
- **High:** Phase 2 funding (at least 70% = USD 84M of USD 120M) is committed (bound contract) before Phase 2 starts at Month 24 (2028-10-12); Phase 3 at >=70% (USD 49M of USD 70M) committed before Month 60 (2031-10-12).
- **High:** A USD 15-20M revolving credit facility or bridge-funding arrangement can be secured by Month 3 (2027-01-12) to cover 2-3 months of opex if tranches slip; terms allow 4-6 week drawdown and repayment within 3 months of tranche receipt.
- **Medium:** Host institution in-kind cost-sharing will average 15-25% of opex per unit (USD 0.375-0.625M per unit-year); all 30 host sites will honor cost-sharing commitments.
- **Medium:** Cumulative cost variance will not exceed +10% overspend by Month 24 (2028-10-12); if it does, governance escalation and rework are triggered before Phase 2 release.

### SMART Validation Objective

By Month 1 (2026-11-12), establish Funding Commitment Registry and funder outreach. By Month 3 (2027-01-12), secure 50% of Phase 1 as binding commitments (USD 30M); identify and pre-qualify USD 15-20M contingency facility. By Month 6 (2027-04-12), secure 100% of Phase 1 committed. Deploy cost-tracking dashboard by Month 2 (2026-12-12); report monthly variance to Programme Board. By Month 24 (2028-10-12), secure 70% of Phase 2 (USD 84M) as binding commitment before Phase 2 starts. Measure: zero delay to Phase 2 start due to funding shortfall; cumulative cost variance <=10% at all phase gates.

### Notes

- Funder commitment conversion (pledge to binding contract) is the single largest gating risk for gate releases; must begin immediately in Month 1 (2026-11-12).
- Phased funding is a double-edged sword: ties releases to credible gates (beneficial) but requires each funder to recommit annually (risky if political priorities shift).
- Contingency facility (USD 15-20M) is essential insurance against 2-3 month cash-flow gaps; without it, operations halt, equipment sits idle, and schedule cascades.
- Host cost-sharing promises are often soft; explicit quantification and written multi-year commitment are required to count on the contribution.
- Fallback: if Phase 2 commitment cannot reach 70% by Month 20 (2028-06-12) (4 months before Phase 2 start), governance decision to defer Phase 2 start or reduce unit count.

## Summary

This plan targets digitization of 3.6M+ items and 200+ PB of degraded 1950-2000 magnetic tape, film and card media across 30 mobile containerized units deployed to 30+ archives over 10 years (Months 0-120 = 2026-10-12 to 2036-10-12), within a USD 250M cap. The six most critical data-collection areas address the plan's highest-consequence assumptions: (1) Hardware Sustainment and Parts-Depletion Validation—the >90% uptime target depends on a finite, depleting stockpile of 300-500 vintage machines modeled and validated by Month 2 (2026-12-12); (2) AI Pre-Screening Accuracy and Review Bottleneck Validation—the assumed 80% review reduction is untested on real degraded content and drives crew headcount; if actual flagging is 35-40%, reviewer payroll triples, exceeding budget by USD 15-25M annually; this must be validated by Month 8 (2027-06-12) before Phase 2 design; (3) Budget Reconciliation and Staffing Model Validation—recomputed payroll (USD 75-126M annually at full scale) does not reconcile with the stated USD 25M average annual budget; an independent audit must lock a credible model by Month 4 (2027-02-12) or all downstream forecasts are suspect; (4) Privacy Compliance and Data-Residency Framework Validation—processing multilingual content containing personal data across multiple jurisdictions creates GDPR and data-sovereignty risk; source agreements, Privacy Review Panel governance and custody models must be legally defensible and jurisdictionally compliant by Month 3 (2027-01-12); (5) Pilot Host-Archive Partnerships and Fire-Authority/Insurer Approvals—on-site residencies depend entirely on binding written approvals from insurers and fire authorities; a single handling incident or privacy breach could cascade network termination; approvals must be secured by Month 6 (2027-04-12) or deployment is blocked; (6) Phased Funding and Funder Commitment Validation—the plan's three phases depend on 15+ funder organizations; binding commitments of 50% Phase 1 (USD 30M of USD 60M) must be secured by Month 3 (2027-01-12), and a USD 15-20M contingency facility must be in place to cover cash-flow gaps if tranches slip. Immediate actionable tasks: (A) By Month 1 (2026-11-12), establish Programme Board (8-10 members), engage independent cost auditor, secure retired-engineer mentoring contracts (6-8 people), and begin legal mapping for privacy/data residency compliance. (B) By Month 2 (2026-12-12), commission parts-depletion model, fire-safety hazard analysis, and procure 100-200 representative samples for AI validation. (C) By Month 3 (2027-01-12), publish reconciled budget (three scenarios), establish Funding Commitment Registry, and finalize source-agreement templates with jurisdiction-specific annexes. (D) By Month 4 (2027-02-12), lock Phase 1 budget and staffing model; validate AI pre-screening on labeled dataset; sign first host-archive agreements. (E) By Month 6 (2027-04-12), obtain written insurer and fire-authority approval at one pilot site; deploy first pilot unit; begin cost and variance tracking. (F) By Month 8 (2027-06-12), measure actual AI flagging rate and review hours from pilot operations; publish go/no-go evidence for Phase 2 gate. Success depends on replacing unvalidated assumptions with evidence by Month 8 (2027-06-12), before Phase 2 design is frozen (Month 20 = 2028-06-12) and Phase 2 funding is released (Month 24 = 2028-10-12). The unfunded gap (~USD 280M after contingency) and inflationary pressure on Phase 3 must be resolved upfront via host cost-sharing, new funders, or reduced unit count—deferral to Month 60 (2031-10-12) risks governance deadlock while media degradation accelerates.