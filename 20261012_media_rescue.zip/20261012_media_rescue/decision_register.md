**3 open decisions: 3 high severity.** The most urgent decisions are pilot lead-time handling (Month 1 = 2026-11-12) and funded scope and MIU capex financing (before the Month 3-4 = 2027-01-12 to 2027-02-12 gates); the Phase 2 at-risk ordering choice can wait until about Month 18 (2028-04-12). Before they are made, the plan can safely start the cost audit, Programme Board setup, mentor contracts, parts-depletion model and legal mapping, which are independent of those decisions.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Funded scope and MIU capex financing | 🔴 High | Programme Board (8-10 members; 70%+ consensus), with Finance Committee analysis | Month 4 (2027-02-12), when budget and staffing lock and the cost audit reports. | Month 3 (2027-01-12) funding commitment gate, Month 4 (2027-02-12) budget/staffing lock and cost-audit gate; Phase 2-3 capex. |
| 2 | At-risk Phase 2 long-lead orders | 🔴 High | Programme Board | Month 18 (2028-04-12), before the Month 20 (2028-06-12) design freeze and order lead times. | Month 20 (2028-06-12) design freeze, Month 24 (2028-10-12) Phase 2 gate, Month 28 (2029-02-12) first Phase 2 unit. |
| 3 | Pilot start vs long-lead procurement | 🔴 High | Programme Board with Technical Committee advice | Month 1 (2026-11-12), since pre-orders must precede the Month 3 (2027-01-12) commitment. | Month 5 (2027-03-12) retrofit, Month 6 (2027-04-12) first pilot operation, Months 6-20 (2027-04-12 to 2028-06-12) evidence window. |

## 1. Funded scope and MIU capex financing (🔴 High)

**Decision:** Who finances the Phase 2-3 MIU capex (USD 105M at midpoint) and does the Month 4 (2027-02-12) lock proceed at the ~14 unit-equivalent funded scope or wait for new funding?

**Why it is open:** Headline goal (30 MIUs, 3.6M+ items 'within the cap') conflicts with cap-affordable scale (~14 unit-equivalents, ~1.7M items). Budget lines finance all MIUs from program money; host cash cost-share is unquantified; the ~USD 280M gap has no committed source.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Lock funded scope (~14 unit-equivalents) as the baseline; 30 units conditional on closing the gap. | Honest baseline of ~1.7M items and ~95 PB (estimate); 24-unit stop trigger is formally tripped; pilots proceed. | Goal statement, cap_affordable_scale, fleet_ramp_units, items_target_total, pitch and executive summary. |
| B. Require host/consortium cash cost-share per MIU (quantified) before Phase 2 orders. | Reduces program capex; needs a per-MIU amount; may slow host onboarding and risk archive trust. | miu_financing_open_decision, phase budgets, source agreements, funding_gap_and_source. |
| C. Seek new government/consortium or rights-holder-approved technology-sector funders for the gap. | Keeps 30-unit ambition; no committed source today; Phase 1 may proceed with Phase 2-3 conditional. | funding_gap_and_source, operating_revenue_and_price, commitment thresholds. |
| D. Reduce unit count or crew size permanently to fit the cap. | Fewer items and PB; unit count below 24 triggers governance re-assessment. | fleet_ramp_units, staff_per_unit, items and PB targets. |

- **If nobody decides:** The cost audit fails the funded-path gate at Month 4 (2027-02-12); Phase 1 procurement beyond the pilots is halted and scope is re-baselined to ~14 unit-equivalents.
- **Owner:** Programme Board (8-10 members; 70%+ consensus), with Finance Committee analysis
- **Decide by:** Month 4 (2027-02-12), when budget and staffing lock and the cost audit reports.
- **Blocks:** Month 3 (2027-01-12) funding commitment gate, Month 4 (2027-02-12) budget/staffing lock and cost-audit gate; Phase 2-3 capex.

## 2. At-risk Phase 2 long-lead orders (🔴 High)

**Decision:** May capped long-lead deposits for Phase 2 units be placed before the Month 24 (2028-10-12) gate, and from what source?

**Why it is open:** Review plan gates Phase 2 unit orders at the Month 20 (2028-06-12) design freeze and tests USD 84M at Month 20 (2028-06-12); canonical gate releases Phase 2 only at Month 24 (2028-10-12) with no full override. First Phase 2 unit at Month 28 (2029-02-12) requires about 4 months of long-lead procurement.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Permit capped at-risk deposits from Phase 1 contingency or the bridge facility. | Preserves the Month 28 (2029-02-12) first unit; weakens no-override claim; loss exposure equals the deposits. | gate_override_rule wording, contingency_per_phase, debt_and_bridge_financing. |
| B. Wait for the Month 24 (2028-10-12) release and move the first Phase 2 unit later. | Clean gate; first Phase 2 unit slips beyond Month 28 (2029-02-12) (about 4 months, estimate); fewer Phase 2 unit-years. | phase2_first_unit_timing, unit_years_baseline, Reviews 13 and 15. |
| C. Use the conditional limited tranche at >=80% of targets. | Orders limited to 4-6 units (USD 30-50M); depends on evidence arriving by Month 20 (2028-06-12). | phase1_to_2_gate, Phase 2 budget phasing. |

- **If nobody decides:** No orders before the Month 24 (2028-10-12) gate; first Phase 2 unit slips past Month 28 (2029-02-12).
- **Owner:** Programme Board
- **Decide by:** Month 18 (2028-04-12), before the Month 20 (2028-06-12) design freeze and order lead times.
- **Blocks:** Month 20 (2028-06-12) design freeze, Month 24 (2028-10-12) Phase 2 gate, Month 28 (2029-02-12) first Phase 2 unit.

## 3. Pilot start vs long-lead procurement (🔴 High)

**Decision:** Keep the Month 6 (2027-04-12) first-pilot date by placing LOIs or capped pre-orders at Month 1 (2026-11-12), or re-baseline the pilot start and the Months 6-20 (2027-04-12 to 2028-06-12) evidence window?

**Why it is open:** Canonical pilot_schedule has container assembly at Months 4-5 (2027-02-12 to 2027-03-12) and operation at Month 6 (2027-04-12) after the Month 3-4 (2027-01-12 to 2027-02-12) commitment and lock. Self-audit cites containers at 12-18 months and robotics at 16+ weeks lead time. Both cannot hold.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Place LOIs/capped pre-orders at Month 1 (2026-11-12) before funding is committed. | Month 6 (2027-04-12) start feasible if lead times allow; the program bears pre-commitment risk if the Month 3 (2027-01-12) gate fails. | pilot_schedule, early_compliance_milestones, commitment_thresholds. |
| B. Re-baseline pilot start to match confirmed lead times. | Month 6 (2027-04-12) slips; evidence window and Month 24 (2028-10-12) gate shift; Phase 2 and 3 timing move. | pilot_schedule, phase1_to_2_gate, phase2_first_unit_timing, schedule across plan. |
| C. Use refurbished or existing containers for the pilots to shorten lead time. | Meets Month 6 (2027-04-12) if available; needs a supplier check and may change unit cost. | miu_capex_each, pilot design spec. |

- **If nobody decides:** Procurement waits for the Month 3 (2027-01-12) commitment gate, so Month 6 (2027-04-12) operation is missed.
- **Owner:** Programme Board with Technical Committee advice
- **Decide by:** Month 1 (2026-11-12), since pre-orders must precede the Month 3 (2027-01-12) commitment.
- **Blocks:** Month 5 (2027-03-12) retrofit, Month 6 (2027-04-12) first pilot operation, Months 6-20 (2027-04-12 to 2028-06-12) evidence window.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Vintage transport sustainment | Buy and cannibalize a vintage stockpile with retired-engineer mentoring, 3D-printed parts and embedded maintenance engineers. | Fund new-build open-specification transports (Pioneer's Gambit). | Sets spares risk, uptime and potential USD 15-25M stockpile refresh exposure. | Month 4-5 (2027-02-12 to 2027-03-12) parts model validation |
| Rights, privacy and review gate | Every item gated by AI pre-screening and human review of flagged content before upload. | Ingest to a dark tier and review on request (Pioneer's Gambit), or host-delegated review (Consolidator's Ledger). | Drives reviewer headcount, privacy risk and archive trust. | Month 8 (2027-06-12) pilot AI results |
| Crew composition | Dedicated resident crew of engineers, operators and reviewers rotating with each unit. | Centralized review hubs, or a small core with host staff trained to run intake and review. | Determines staffing, which drives opex against the USD 2.5M per unit-year planning value. | Month 4 (2027-02-12) budget and staffing lock |
| Funding and ownership | Consortium of national archives and foundations jointly owning fleet and data, with host cost-sharing. | Non-profit service bureau charging per-item fees (Consolidator's Ledger). | Determines who closes the ~USD 280M gap and who holds the assets. | Month 12 (2027-10-12) end-state working group |
| Pilot proof gates and cadence | Stress-first pilot on the worst-condition collection; Phase 2 released only on gate evidence. | Overlap scale-up by ordering long-lead items during pilots (Pioneer's Gambit). | Trades schedule against rework risk and funder confidence. | Month 20 (2028-06-12) evidence package, Month 24 (2028-10-12) gate |
