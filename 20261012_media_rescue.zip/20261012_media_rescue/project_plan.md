**Goal Statement:** Build and deploy a network of containerized Mobile Ingest Units (3 pilots, then 15 by Month 60 = 2031-10-12 and 30 by Month 120 = 2036-10-12) to digitize degrading 1950-2000 tape, film and card media on-site at host archives, targeting 3.6M+ items and 200+ PB within the USD 250M cap, with staged gates controlling scale-up.

## SMART Criteria

- **Specific:** Digitize at-risk 1950-2000 magnetic tape, film and card collections on-site at host archives using containerized units, with media never leaving the premises and AI pre-screening plus human review before archival upload.
- **Measurable:** 3.6M+ items and 200+ PB recovered by Month 120 (2036-10-12); 500K+ items and 25+ PB by Month 60 (2031-10-12); digitization success >95%, reconstruction accuracy >80%, metadata accuracy >70%, human review <20%, uptime >90%, zero shipping damage, zero legal/privacy incidents.
- **Achievable:** The core design is proven in parts, but recomputed costs (about USD 529M uncapped) exceed the USD 250M cap; the cap supports about 47% of scope (estimate) unless cost-sharing, added funders or a reduced scope close the gap. Hardware spares and the AI review reduction remain unvalidated.
- **Relevant:** Media from 1950-2000 is degrading and may be lost within 10-30 years. On-site processing removes shipping and insurance barriers and preserves cultural, scientific and government records.
- **Time-bound:** Program runs Months 0-120 (2026-10-12 to 2036-10-12). Phase 1 (Months 0-24 = 2026-10-12 to 2028-10-12): 3 pilots, first operating Month 6 (2027-04-12). Phase 2 (Months 24-60 = 2028-10-12 to 2031-10-12): 15 units cumulative. Phase 3 (Months 60-120 = 2031-10-12 to 2036-10-12): 30 units cumulative. Start ASAP.

## Dependencies

- Reconciled cost and staffing model and binding funder commitments (at least USD 30M of Phase 1 committed by Month 3 = 2027-01-12), including resolution of the unfunded gap
- Parts-depletion model and committed retired-engineer mentors for vintage equipment sustainment
- Pilot host archive agreements with insurer and fire-authority approval of pre-treatment hazards
- Validated AI pre-screening and review workflow with privacy, copyright and data-residency framework
- Pilot gate evidence before Phase 2 and Phase 3 releases

## Resources Required

- Retrofitted 40-ft containers with processing lines, robotics, climate and power systems
- Vintage tape, film and card equipment plus parts warehouse and 3D printing/CNC capability
- AI processing and review software, plus on-board storage and satellite/fiber connectivity
- Engineers, retired-engineer mentors and multilingual reviewers
- Legal, insurance and customs-compliance advisers

## Related Goals

- Preserve 1950-2000 cultural, scientific and government records
- Build a vintage-equipment maintenance knowledge base
- Establish durable custody and access for recovered data
- Define a post-Month 120 (2036-10-12) end-state for units and parts

## Tags

- media preservation
- digitization
- mobile container
- vintage equipment
- archives

## Risk Assessment and Mitigation Strategies


### Key Risks

- Budget gap: recomputed cost about USD 529M against the USD 250M cap, with Phase 3 gap about USD 301M (estimate)
- Finite vintage spares and ageing mentors threaten the >90% uptime target
- Unvalidated 80% AI review reduction could multiply reviewer headcount
- Insurer or fire-authority refusal, or a handling incident, could end host partnerships
- Privacy and data-residency breaches across jurisdictions

### Diverse Risks

- Staffing of 50-60 per unit does not reconcile with USD 2-3M opex per unit-year
- Funding tranches on annual cycles delay gates
- Border and customs delays for containers and vintage equipment
- Pilot design flaws replicated into Phase 2 units
- Governance delays among many funders and archives

### Mitigation Plans

- Independent cost audit by Month 1 (2026-11-12); lock budget and staffing by Month 4 (2027-02-12); pursue host cost-sharing, new funders or a reduced unit count; hold 10% contingency per phase
- Parts-depletion model by Month 2 (2026-12-12); re-manufacture trigger at 50% spares depletion; 6-8 mentors committed by Month 1 (2026-11-12) and retained to Month 48 (2030-10-12)
- Test AI on 100-200 real samples; pilot review pod by Month 8 (2027-06-12); retrain if precision or recall <75% or flagging >25%
- Hazard-control standard and written insurer and fire-authority approval at one pilot site by Month 6 (2027-04-12); detached pod fallback; tiered indemnity and pooled loss reserve
- Stress-first pilots Months 6-20 (2027-04-12 to 2028-06-12) with pre-agreed gates; no full override of gates; escalate to governance if variance >10% or uptime <90%

## Stakeholder Analysis


### Primary Stakeholders

- Programme Board
- Programme and engineering team including maintenance engineers
- Review and quality-control staff
- Retired-engineer mentors and successor engineers
- Pilot host archives

### Secondary Stakeholders

- Funders (government archives, cultural foundations, technology companies)
- Insurers and fire authorities
- Customs and data-protection regulators
- Vintage equipment suppliers
- Researchers and public users of recovered data

### Engagement Strategies

- Programme Board of 8-10 members by Month 1 (2026-11-12) with defined decision rights and monthly reporting
- Quarterly cost and variance reports to funders, with gate evidence published
- Written multi-year host agreements with tiered indemnity, transparent site prioritisation and a stakeholder workshop by Month 4 (2027-02-12)
- Early and ongoing engagement of insurers, fire authorities and customs bodies before each deployment
- Mentor contracts with retention incentives and documented curricula

## Regulatory and Compliance Requirements


### Permits and Licenses

- Fire-authority and insurer written approval per host site
- Temporary import admission for containers and vintage equipment
- Hazardous materials handling and transport permits
- Generator and emissions permits where required
- Local building or hardstand permits at host sites

### Compliance Standards

- GDPR, UK Data Protection Act and other jurisdictional privacy rules
- Copyright and source-agreement terms
- Workplace safety and VOC exposure limits
- E-waste and hazmat classification of vintage equipment
- Archival preservation format and fixity standards

### Regulatory Bodies

- Local fire authorities
- Data-protection authorities
- Customs and trade authorities
- Occupational safety regulators
- Environmental protection agencies

### Compliance Actions

- Legal mapping of jurisdictions and standard source-agreement template by Month 1-3 (2026-11-12 to 2027-01-12)
- Privacy review panel with decision log by Month 3 (2027-01-12)
- Hazmat audit of 20-30 machines and ventilation design with industrial hygienist by Months 2-4 (2026-12-12 to 2027-02-12)
- Customs pathway documentation and pre-negotiated temporary import by Month 4 (2027-02-12)
- Incident protocol with 24-hour insurer notification