69 explicit calculations found in the documents re-computed without an LLM; 9 do not match their stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | 1 MIU = 1 x 40-ft container | 1 | 40 |
| Canonical Facts | Plan figure (100 man-hours/day review at 2x speed / 8 h = ~12.5 reviewers | 12.5 | 0.25 |
| Canonical Facts | 500K / 32 unit-years (4+28) = 15.6K | 15.6K | 32 |
| Canonical Facts | 6M / 12M / 7M = USD 25M | 25M | 7.143e-08 |
| Canonical Facts | 9M / 18M / 10.5M = USD 37.5M | 37.5M | 4.762e-08 |
| Governance | - Manage contingency reserves (10% per phase = USD 6M/12M/7M = USD 25M total) | 25M | 7.143e-08 |
| Governance | - Manage inflation escalation reserves (proposed 15% per phase = USD 9M/18M/10.5M = USD 37.5M) | 37.5M | 4.762e-08 |
| Documents to Create and Find | hold 10% contingency per phase (USD 6M/12M/7M = USD 25M inside cap) | 25M | 7.143e-08 |
| Documents to Create and Find | 15% inflation reserve (USD 9M/18M/10.5M = USD 37.5M) as proposed (not yet approved) | 37.5M | 4.762e-08 |
