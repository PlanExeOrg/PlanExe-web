This plan involves money.

## Currencies

- **USD:** Primary currency for the $250M budget, phased funding ($60M/$120M/$70M), capital costs ($3-4M per unit), operating costs ($2-3M per unit-year), equipment acquisition ($20M), training programme ($5M), and international procurement. US-based primary hub (Northern Virginia) and major pilot site (Los Angeles). International funding and cost-sharing typically denominated in USD.
- **GBP:** Required for UK-based hub operations (Greater London/South East England), pilot sites at British Library and BFI National Archive, vintage equipment sourcing from decommissioned BBC and UK broadcasters, staff payroll and facility costs, and host-archive cost-sharing contributions in the United Kingdom.
- **EUR:** Required for European hub operations (Hilversum, Netherlands and Port of Rotterdam), intra-EU container logistics and customs operations, EU pilot sites and partner archives, staff payroll across multiple EU member states, parts inventory and equipment sourcing within the EU single customs area, and host-institution cost-sharing in European nations.

**Primary currency:** USD

**Currency strategy:** Establish USD as the primary currency for consolidated budgeting, reporting to funders and phased funding tranches. Maintain separate cost centres in GBP for the UK hub and in EUR for the Netherlands/EU hub, with monthly or quarterly exchange-rate hedging against GBP and EUR movements to protect the fixed $250M budget envelope. Use local currencies for on-site operational expenses (staff, consumables, utilities) at each host archive, with fixed-rate procurement contracts for equipment and parts to minimise price volatility. Implement centralised treasury management to hedge currency exposure on cross-border payments (USD to GBP/EUR for hub establishment and staffing) and to lock USD rates for multi-year phase budgets released to regional teams.