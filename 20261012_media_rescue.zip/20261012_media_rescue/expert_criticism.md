# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Vintage Media Equipment Engineer

**Knowledge**: Magnetic tape decks, film scanners, card readers, mechanical repair, azimuth alignment, head calibration, 3D printing fabrication, parts inventory management

**Why**: The plan depends on a finite, depleting stockpile of 300-500 vintage machines and retired-engineer mentoring to sustain >90% uptime for a decade. A parts-depletion model and re-manufacture capability must be validated by Month 2 (2026-12-12) before Phase 1 capex is locked.

**What**: Model mean-time-between-failures per deck type, cannibalization yield, 3D-printing fabrication specs for 20+ critical parts (capstan sleeves, pinch rollers, azimuth fixtures), and spares-consumption curves. Validate fabrication quality against archival playback standards. Advise on mentor recruitment and knowledge-transfer curriculum.

**Skills**: Mechanical design, reverse engineering, tolerance metrology, materials characterization, production testing, archival standards compliance, knowledge documentation, training curriculum design

**Search**: broadcast equipment engineer vintage tape deck repair, film scanner maintenance, mechanical parts fabrication archival standards, 3D printing for legacy media equipment

## 1.1 Primary Actions

- Commission a Parts Depletion Curve model (MTBF per deck type, cannibalization yield, 3D-printing capacity) by Month 2 (2026-12-12), and validate 3D-printed parts on reference decks by Month 4 (2027-02-12). Establish a Parts Consumption Telemetry dashboard with automatic re-manufacture triggers at 50% spares depletion by Month 10 (2027-08-12).
- Validate AI pre-screening accuracy on 100–200 real degraded, multilingual samples from pilot archives by Month 4 (2027-02-12). Measure precision, recall and false-positive rate by category-format-degradation. If any metric <75%, commission retraining before Phase 1 reaches full operations. By Month 8 (2027-06-12), measure actual review rates during pilot operations; if flagging >25%, retrain or redesign review workflow.
- Commission an independent cost audit by Month 1 (2026-11-12) reconciling staffing (headcount and loaded cost per role) with opex ($2–3M per unit-year). By Month 4 (2027-02-12), lock a credible staffing model and publish a binding commitment: if actual costs exceed baseline >10%, adjust Phase 2–3 unit count or seek additional funding. Do not proceed with Phase 1 procurement until reconciliation is complete.
- Secure written approval from at least one pilot archive's insurer and fire authority for pre-treatment hazards (ovens, humidity chambers, on-board media storage) by Month 6 (2027-04-12). Develop a standardized Hazard Control Standard and obtain binding approval letter as a template for all subsequent sites. If approval cannot be obtained, implement a detached pre-treatment pod (separate 20-foot container, 50+ meters from archive building) and add $1.5–4.5M and +4–6 weeks per site to the schedule.
- Secure binding mentoring contracts with 6–8 retired broadcast and film engineers (aged 70–80), minimum 2 per line type, by Month 1 (2026-11-12). Offer retention bonuses ($50K–$100K per mentor) and consulting roles extending to Month 48 (2030-10-12). Develop a formal mentoring curriculum documenting 50–80 critical repair competencies per line by Month 3 (2027-01-12) and pair each mentor with 2–3 successor engineers by Month 4 (2027-02-12) for 16+ hours per month of documented mentoring.
- Establish a Funding Commitment Registry by Month 1 (2026-11-12) translating each pledge into binding multi-year contract language tied to measurable gates. Secure ≥50% of Phase 1 ($30M of $60M) as committed (not pledged) funds by Month 3 (2027-01-12). Identify backup sources or pre-qualify a $15–20M revolving-credit line by Month 2 (2026-12-12) to cover mid-programme cash-flow gaps without waiting for annual funder cycles.
- Develop a Privacy Impact Assessment (PIA) template and jurisdiction-specific data-residency mapping by Month 2 (2026-12-12). Publish a standardized Source-Agreement Template with privacy, copyright, indemnity and jurisdiction-specific annexes by Month 3 (2027-01-12). Establish a Privacy Review Panel by Month 3 (2027-01-12) with a decision log recording all privacy flagging decisions; audit 5% of decisions quarterly for consistency.
- Develop a Tiered Indemnity Structure (Full Coverage, Attempt-at-Own-Risk, Deferred) by Month 2 (2026-12-12) with condition-based tier assignment. Create a Pooled Loss Reserve of $2–5M from Phase 1 budget ($60M) and an Incident Response Protocol by Month 4 (2027-02-12). Obtain legal review per jurisdiction and include binding indemnity schedules in all source agreements by Month 4 (2027-02-12).

## 1.2 Secondary Actions

- Establish a Programme Board (8–10 members) with defined decision rights and escalation criteria by Month 1 (2026-11-12). Institute monthly reporting with quarterly Variance and Cost-Tracking reports to all funders. Define stop-and-escalation triggers: cumulative variance >10% overspend, unit reduction forcing <24 units, parts model showing infeasible depletion, or uptime <90%.
- By Month 3 (2027-01-12), publish three budget scenarios (baseline, +15% inflation, +30% inflation) covering Months 0–120 (2026-10-12 to 2036-10-12). Restate entire budget in constant 2026 dollars and separately model 2%, 3%, 4% annual escalation sensitivities. Allocate explicit Inflation Escalation Reserves: Phase 1 +$9M, Phase 2 +$18M, Phase 3 +$10.5M.
- Conduct a comprehensive condition assessment of all 300–500 acquired machines by Month 6 (2027-04-12): document serial number, format, functional status, head wear (azimuth offset ±0.05mm tolerance), transport drift and parts-harvest potential per unit. Tag all parts in a central inventory database and photograph each machine for condition baseline.
- Establish a Hazmat audit and industrial-hygiene review of the baking-oven design by Month 3 (2027-01-12). Model thermal-release and chemical-vapor scenarios (formaldehyde, acetic acid); estimate incident probability and financial exposure. Develop ventilation, thermal-monitoring, and fire-suppression specs meeting archival and occupational-safety standards.
- Develop a Customs and Border Pathway by Month 4 (2027-02-12) specifying temporary-import procedures, e-waste classification, hazardous-materials handling and data-residency rules for the first 3–5 target countries. Pre-negotiate temporary-admission agreements with customs authorities to minimize transit delays.
- By Month 4 (2027-02-12), sign written multi-year host agreements with at least three pilot archives specifying: residency duration (6–12 months), media-condition intake criteria, pre-treatment and digitization scope, insurer and fire-authority approvals in place, on-site liaison and power/hardstand provision, source-agreement and indemnity terms, and zero-incident commitments.
- By Month 12 (2027-10-12), establish an End-State Working Group tasked with defining post-Month 120 (2036-10-12) outcomes: unit transfer or pooling, parts-warehouse disposition, knowledge-base publication, and durable custody of 200+ PB masters. Develop a reduced-scope scenario and trigger: if reconciled cost forces fewer than 24 units, initiate governance re-assessment and end-state replanning.
- Prepare for a Stress-First Pilot by Month 5 (2027-03-12): identify the worst-condition collection at the first host archive (highest degradation rate, complex formats, known preservation failures). Plan to run pilots Months 6–20 (2027-04-12 to 2028-06-12) on ≥2 host sites, measuring digitization success, uptime, AI pre-screening accuracy and reviewer hours per content hour against published targets. Do not override gates; publish results honestly.

## 1.3 Follow Up Consultation

Next consultation (Month 4 = 2027-02-12) will review: (1) parts-depletion model and fabrication validation results; (2) AI pre-screening accuracy on pilot content and retrain recommendations; (3) cost-audit reconciliation and binding staffing model; (4) mentoring curriculum progress and successor-engineer pairing; (5) insurer and fire-authority approval status at one pilot site; (6) funding commitment registry and Phase 1 cash-flow timeline; (7) privacy panel decisions and source-agreement execution at first three archives; (8) indemnity reserve funding and incident protocol sign-off. Escalation trigger: if any of items 1–3 remain unvalidated or unreconciled, governance decision point to pause Phase 1 full procurement or reset start date.

## 1.4.A Issue - Parts Depletion Curve and Hardware Sustainment Model Are Speculative, Not Validated

The plan assumes a finite stockpile of 300–500 vintage tape decks and film scanners will sustain 30 units over a decade at >90% uptime. No parts-depletion curve, mean-time-between-failures (MTBF) model, or 3D-printing fabrication validation exists. Without this modeling by Month 2 (2026-12-12), the uptime target is speculative. By Months 36–48 (2029-10-12 to 2030-10-12), parts inventory may approach critical depletion while retired mentors (aged 70–80) age further, risking cascade failures across the fleet. The $250M cap absorbs no emergency stockpile refresh (estimated $15–25M unbudgeted).

### 1.4.B Tags

- hardware_sustainment_risk
- parts_inventory_modeling
- uptime_target_unsupported
- mentor_attrition_risk
- budget_gap

### 1.4.C Mitigation

By Month 2 (2026-12-12), commission a Parts Depletion Curve model: specify MTBF per deck type, cannibalization yield per 10 units, and 3D-printing capacity for 20+ critical parts. By Month 4 (2027-02-12), validate fabrication of 10 priority parts on reference decks, measuring playback fidelity against archival standards. By Month 6 (2027-04-12), conduct comprehensive condition assessment of all 300–500 machines and establish a Parts Consumption Telemetry dashboard by Month 10 (2027-08-12) to trigger re-manufacture orders at 50% depletion. This prevents surprise stockouts and provides credible evidence for Phase 2 gates.

### 1.4.D Consequence

Without modeling, the fleet risks dropping below 90% uptime by Months 36–48 (2029-10-12 to 2030-10-12) as parts inventory depletes and mentors exit. This cascades into missed digitization targets and forced operational pauses. An unbudgeted emergency stockpile refresh ($15–25M) would breach the $250M cap or trigger phase delays while media continues degrading. Archive partnerships may terminate if uptime falls and collections are left unprocessed.

### 1.4.E Root Cause

Empty

## 1.5.A Issue - Claimed 80% AI Review Reduction Is Unproven on Real Degraded, Multilingual Content

The plan assumes AI pre-screening flags only 20% of content, reducing human review from 1,000 to 200 hours per collection. This is the single largest cost driver in crew composition and is untested on 1950–2000 degraded, multilingual media. If actual flagging is 35–40% instead of 20%, reviewer headcount required per unit triples from 12–15 to 40–50, adding $15M–$25M annual payroll at full scale—far exceeding the $25M average annual budget. The assumption must be validated on representative pilot content by Month 8 (2027-06-12), not after Phase 2 design is locked.

### 1.5.B Tags

- ai_accuracy_unvalidated
- review_load_assumption
- crew_composition_risk
- budget_reconciliation
- operational_model_untested

### 1.5.C Mitigation

By Month 2 (2026-12-12), procure 100–200 representative samples (heavily degraded tape, film, card media) from three pilot archives. By Month 4 (2027-02-12), develop a gold-standard labeled dataset with inter-rater agreement ≥0.75 (kappa). Test AI pre-screening and publish precision, recall and false-positive rate by category and degradation level. If precision or recall <75% on any category-format pair, commission iterative retraining. By Month 8 (2027-06-12), measure actual review rates during pilot operations. If flagging exceeds 25%, retrain or recalibrate thresholds; if exceeds 30%, redesign review workflow (tiered review, delegation to hosts, remote hubs) and adjust Phase 2 crew composition.

### 1.5.D Consequence

If AI accuracy is lower than claimed, reviewer headcount must triple to maintain quality assurance, breaching the budget. Alternatively, review quality drops, leading to privacy or copyright breaches that cascade partnership termination across the network. Pilot metrics become unreliable evidence for Phase 2 gates, and the entire operational model collapses. Media degradation continues while the programme scrambles to replan.

### 1.5.E Root Cause

Empty

## 1.6.A Issue - Staffing Model (50–60 per Unit) Does Not Reconcile with Operating Budget ($2–3M Per Unit-Year)

The plan states 50–60 staff per active MIU at $2–3M opex per unit-year. Recomputed: 50–60 staff × $50–70K loaded cost = $2.5–4.2M payroll alone per unit-year. At 30 units, this implies $75–126M annual payroll (estimate) versus $25M average annual budget (250M ÷ 10 years). Budget-consistent crew is ~25 staff per unit. The discrepancy is not addressed. Either staffing, budget or unit count must change. Without reconciliation by Month 4 (2027-02-12), Phase 1 procurement locks in a crew model that cannot be sustained or funded through Phase 2 and 3.

### 1.6.B Tags

- budget_reconciliation
- staffing_unsustainable
- opex_modeling
- cost_audit_missing
- crew_composition_undefined

### 1.6.C Mitigation

By Month 1 (2026-11-12), commission an independent cost audit itemizing all opex per MIU: labor (headcount and loaded cost per role, by region), equipment, consumables, depreciation and parts. By Month 2 (2026-12-12), publish three budget scenarios (baseline, +15%, +30% inflation). By Month 3 (2027-01-12), run a Pilot Staffing Pod at the first hub site; measure actual loaded costs per position over 3 months and extrapolate to full scale. By Month 4 (2027-02-12), lock the staffing model and publish a binding commitment: if actual costs exceed baseline by >10%, adjust Phase 2–3 unit count or seek additional funding. This prevents Phase 1 procurement from locking in unsustainable crew levels.

### 1.6.D Consequence

If staffing and budget are not reconciled before Phase 1 procurement, the programme will either (a) deploy with half the planned crew, degrading quality and risking review bottleneck collapse, or (b) overspend and exhaust the $250M cap before Month 60 (2031-10-12), forcing Phase 3 deferral or cancellation. Archive partnerships suffer due to longer residencies (understaffed units process slowly). Media degradation accelerates while the programme is underfunded.

### 1.6.E Root Cause

Empty

---

# 2 Expert: Cultural Heritage and Archive Partnership Manager

**Knowledge**: Archives and cultural institutions, multi-stakeholder partnerships, source agreements, on-site digitization programs, institutional trust models, legal custody frameworks

**Why**: The plan's success depends entirely on archive partnerships and institutional trust. Rights, Privacy, and Review Gate Design and Liability and Loss-Indemnity Structure require deep understanding of archive insurer requirements, fire-authority approvals, and source-agreement terms. On-site residencies will fail if a single incident or privacy breach cascades termination across the network.

**What**: Develop and negotiate standardized source agreements with tiered indemnity by condition grade. Establish the Hazard Control Standard document with written insurer and fire-authority approval at one pilot site by Month 6 (2027-04-12). Design a Liability Structure—Full Coverage Tier for stable items, Attempt-at-Own-Risk Tier for fragile items—backed by a USD 2-5M pooled loss reserve. Create a Privacy Impact Assessment template and incident-response protocol for each jurisdiction.

**Skills**: Contract negotiation, institutional governance, risk communication, insurance compliance, multi-jurisdiction privacy frameworks, source-agreement drafting, incident management, stakeholder engagement

**Search**: archive partnership digitization program, cultural heritage source agreement, collections insurance liability, institutional trust building media preservation

## 2.1 Primary Actions

- By Month 1 (2026-11-12): Commission independent cost audit (by infrastructure consulting firm) reconciling staffing model (50-60 per unit vs. budget-consistent ~25), opex assumptions (USD 2-3M per unit-year vs. recomputed USD 2.5-4.2M payroll alone), and unit count viability within USD 250M cap. Publish three scenarios by Month 2 (2026-12-12): Baseline (16-18 units within cap), Funded Gap (identify new funders for 24-30 units), Deferred Phase 3 (commit USD 180M to Phases 1-2, treat Phase 3 as dependent on new sources by Month 48 = 2030-10-12). Lock budget and staffing by Month 4 (2027-02-12).
- By Month 2 (2026-12-12): Commission Parts Depletion Curve and Mean-Time-Between-Failures (MTBF) model specifying spares consumption per deck type, cannibalization yield per 10 machines, and 3D-printing/CNC capacity for 20 priority part categories. By Month 4 (2027-02-12), validate fabrication of 10 priority parts on reference decks; build Parts Consumption Telemetry dashboard with re-manufacture triggers at 50% depletion by Month 10 (2027-08-12). Conduct comprehensive condition assessment of all 300-500 acquired machines by Month 6 (2027-04-12); create central parts inventory database with serial numbers, functional status, head wear, and harvest potential per unit.
- By Month 1 (2026-11-12): Secure written 24-month mentoring contracts (with retention bonuses USD 50K-100K per mentor) from 6-8 retired broadcast and film engineers, aged 70-80, distributed across Tape, Film, and Card formats (minimum 2 per line type for redundancy). By Month 3 (2027-01-12), develop formal mentoring curriculum documenting 50-80 critical repair competencies per line type with video and written protocols. By Month 4 (2027-02-12), pair each mentor with 2-3 designated successors; schedule 16 hours per month per pair; document in shared knowledge repository. Offer extended part-time consulting contracts to Month 48 (2030-10-12) for mentors completing knowledge transfer.
- By Month 4 (2027-02-12): Procure 100-200 representative samples from three pilot archives (balanced across Tape, Film, Card; heavily degraded items condition 3-4/5). Develop gold-standard labeled dataset with 3-5 expert reviewers per sample (copyright, privacy, archival specialists); achieve inter-rater agreement Cohen's kappa >=0.75. Test AI pre-screening pipeline; publish precision, recall, false-positive rate by category, format, and degradation level. If any category-format pair is <75% precision or recall, commission retraining before real-collection deployment. By Month 8 (2027-06-12), measure actual flagging rates from pilot review operations; if >=25%, trigger AI retraining or workflow redesign; lock flagging assumption for Phase 2 crew composition.
- By Month 2 (2026-12-12): Engage specialized insurance broker and fire-safety consultant; conduct Hazard Analysis of baking ovens, humidity chambers, media storage, generators; model thermal and chemical scenarios; estimate incident probability and financial exposure. By Month 4 (2027-02-12), develop Hazard Control Standard specifying sealed oven designs, thermostat accuracy ±2°C, smoke/fume detection, filtered VOC exhaust, fire suppression rated for archival materials. By Month 6 (2027-04-12), obtain written approval from one pilot site's insurer and fire authority for containerized pre-treatment; use approval letter as template for all sites. If approval cannot be obtained, implement detached pre-treatment pod fallback; budget USD 1.5-4.5M and accept +4-6 week site setup delays.
- By Month 3 (2027-01-12): Develop Standardized Source-Agreement Template (5-10 pages) covering digitization scope, privacy commitment, storage location, access tier, copyright status, legal basis, indemnity terms, and incident-notification protocol. Create jurisdiction-specific annexes (EU GDPR, UK DPA, US state-level). Establish Privacy Review Panel (2-3 data-protection experts per jurisdiction, rotating); maintain Privacy Decision Log. Develop Tiered Indemnity Structure: Full Coverage for stable items; Attempt-at-Own-Risk waivers for extreme-risk items; Deferred Tier for unsafe items. Allocate USD 2-5M from Phase 1 budget as Pooled Loss Reserve. Establish Incident Response Protocol with 4-hour incident reporting, 24-hour insurer notification, 48-hour forensic investigation, 5-business-day claim filing.
- By Month 1 (2026-11-12): Establish Programme Board (8-10 members) with defined decision rights; appoint Programme Director, Finance Lead, Chief Engineer, Legal Counsel, AI/Review Lead, Risk/Compliance Lead. By Month 3 (2027-01-12), convene Funding Commitment Registry with all 15+ funder organizations; convert pledges to binding multi-year contracts specifying committed amounts, release tranches tied to measurable gates, contingency allowances (15-20% per phase), and override clauses. Target >=50% of Phase 1 (USD 30M of USD 60M) committed by Month 3 (2027-01-12). Establish Contingency Funding Panel; pre-qualify 2-3 alternative funders or commit to USD 15-20M revolving credit line by Month 3 (2027-01-12). Allocate explicit Inflation Escalation Reserves: Phase 1 +USD 9M (15%), Phase 2 +USD 18M (15%), Phase 3 +USD 10.5M (15%). Institute quarterly Cost-Tracking and Variance Reporting; if cumulative variance exceeds +10% overspend, trigger governance go/no-go re-assessment.

## 2.2 Secondary Actions

- By Month 4 (2027-02-12): Run Pilot Staffing Pod at Northern Virginia or UK hub site with representative crew sizes and roles; measure actual loaded costs and ramp-to-productivity over 3 months (Months 3-6 = 2027-01-12 to 2027-04-12); extrapolate to full scale and correct Phase 2/3 budgets if actual costs exceed baseline by >10%.
- By Month 4 (2027-02-12): Develop and validate Vintage Transport Sustainment Strategy via parts model outputs; specify equipment acquisition targets (300-500 machines), MTBF per deck type, cannibalization targets, 3D-printing part categories, and maintenance staffing model per unit. Establish mean-time-between-failures targets consistent with >90% uptime goal at 30 units (allow <=3 units offline simultaneously).
- By Month 6 (2027-04-12): Sign three pilot host-archive agreements (Tape, Film, Card formats) with binding multi-year terms, written insurer and fire-authority approvals, and defined incident-resolution escalation. Define site selection criteria and publish transparent triage doctrine (condition-first or value-first ranking) that hosts and funders accept.
- By Month 3 (2027-01-12): Map jurisdiction-specific data-residency, transfer, and privacy rules (GDPR, UK DPA, state-level US rules, regional export controls) for all planned deployment countries. Deliver jurisdiction mapping to legal counsel; publish summary of storage location options (in-country hold, federated archive network, central backup) per jurisdiction to inform Custody and Access Regime decision by Month 6 (2027-04-12).
- By Month 5 (2027-03-12): Design detailed pre-treatment workflow (intake screening, baking protocol, humidity conditioning) including condition-grading gate to route extreme-risk items to Deferred Tier. Document baking temperature profiles, humidity curves, cycle times, and item condition acceptance criteria per format (tape, film, card). Pilot the workflow on 20-30 sample items before containerized operations.
- By Month 6 (2027-04-12): Establish Recovery Assurance and Independent Verification Regime: (a) contract independent auditors to sample recovered items at each pilot site against originals and publish findings; (b) circulate shared reference set of calibrated test media among all pilot units to detect systematic drift in equipment performance; (c) publish inter-unit variance and failure rates quarterly to Programme Board.
- By Month 10 (2027-08-12): Deploy first pilot Mobile Ingest Unit (Tape Line) to Northern Virginia or UK hub site; begin 6-12 month residency with stress-first pilot design (worst-condition collection, high-risk formats, heavy degradation). Measure digitization success >95%, reconstruction accuracy >80%, metadata accuracy >70%, AI flagging rate, human review hours per content hour, and equipment uptime >90%. Report monthly results to Programme Board.
- By Month 12 (2027-10-12): Establish End-State Working Group tasked with defining post-Month 120 (2036-10-12) scenario: which units remain operational, where parts warehouse and knowledge base are retained, who owns and funds 200+ PB of masters and perpetual storage, what revenue models or endowments sustain capability after programme funding ends. Draft three options (transferred units to national archives, retained core with endowment, rental equipment pool) by Month 36 (2029-10-12).
- Months 6-20 (2027-04-12 to 2028-06-12): Conduct stress-first pilot operations at >=2 host sites with >=3 consecutive months per gate evidence. Measure all published success metrics (digitization >95%, reconstruction >80%, metadata >70%, flagging <20%, uptime >90%, AI precision/recall >=75%, zero incidents). Hold Phase 2 funding release conditional on >=80% of targets achieved; escalate to governance if variance >10% or any target falls below 80%.
- By Month 24 (2028-10-12): Document all pilot findings, cost actuals, staffing variances, and validation results (AI accuracy, review rates, parts depletion, uptime). Publish Phase 2 Design Lock: 12 additional MIUs with finalized crew composition, equipment specs, and cost per unit. Secure >=70% of Phase 2 funding (USD 84M of USD 120M) as binding commitments before release. Go/no-go decision: Phase 2 release only if cumulative variance <=10% and all three highest-consequence risks (budget, AI, institutional trust) are mitigated to governance satisfaction.

## 2.3 Follow Up Consultation

"In the follow-up consultation (propose Month 6 = 2027-04-12 after pilot host agreements are signed and insurer/fire-authority approvals are obtained), we should discuss: (1) Reconciled cost and staffing audit results (due Month 4 = 2027-02-12) and whether the baseline, funded-gap, or deferred-phase3 scenario is formally adopted by the Programme Board and funder consortium; (2) Parts Depletion Curve and MTBF model output, mentor retention agreements secured, and any gaps in spare-fabrication capacity that trigger emergency stockpile budget; (3) AI pre-screening validation results on gold-standard pilot samples and any retraining or workflow redesign required before real-collection deployment; (4) Written insurer and fire-authority approvals at one pilot site and whether detached pod fallback is triggered by approval denial; (5) Privacy Review Panel composition, source-agreement template feedback from pilot archives, and any jurisdiction-specific compliance blockers; (6) Pilot host-archive agreements signed with clear incident-escalation, indemnity, and partnership-termination terms; (7) Actual vs. budgeted spending for Pilot Staffing Pod and whether labor costs exceed baseline assumptions; (8) Explicit decision on Triage Doctrine (condition-first vs. value-first) and how under-resourced, most-endangered archives will be reached; (9) Funder Commitment Registry status: whether >=50% of Phase 1 (USD 30M) is committed (not pledged) by Month 3 (2027-01-12), and what contingency funding or bridge facilities are in place for 2-3 month opex cycles; (10) Preliminary end-state planning options for Month 120 (2036-10-12) and perpetual storage funding model for 200+ PB."


## 2.4.A Issue - Budget and Staffing Model Does Not Reconcile; Phase 3 Is Unfunded by ~USD 301M

The recomputed total unconstrained cost is approximately USD 530M against the USD 250M cap (constant 2026 dollars). Stated staffing of 50-60 per unit implies USD 75-126M annual payroll at full scale (30 units); this alone exceeds the USD 250M total budget in 2-3 years. Phase 1 and Phase 2 are marginally viable; Phase 3 has no funding path. Contingency and inflation reserves proposed inside the cap further reduce headroom. Unless the cap is lifted, unit count is cut to ~14-16, crew size drops to ~25 per unit, or new funders close the gap, the programme cannot deliver 30 units and 3.6M items as specified.

### 2.4.B Tags

- budget_gap
- staffing_reconciliation
- phase3_affordability
- financial_viability

### 2.4.C Mitigation

By Month 4 (2027-02-12), lock a reconciled budget and staffing model via independent audit. Publish three credible scenarios: (a) Baseline: 16-18 units, ~1.8M items, ~100 PB, crew ~25 per unit within USD 250M cap; (b) Funded Gap: identify new funders, host cost-sharing or revenue for USD 280M gap (opening 24-30 units); (c) Deferred Phase 3: commit USD 180M to Phases 1-2 (15 units), treat Phase 3 as dependent on new funding by Month 48 (2030-10-12). Lock Phase 1 and Phase 2 funding at >=50% committed by Month 3 (2027-01-12); hold Phase 3 release conditional on new committed sources. Document assumptions on regional wage variation, on-site vs. remote crew mix, and operations overhead; run a Pilot Staffing Pod at one hub (Month 3-6 = 2027-01-12 to 2027-04-12) to validate loaded cost per role.

### 2.4.D Consequence

If staffing and budget are not reconciled by Month 4 (2027-02-12), funder confidence erodes when Phase 2 is proposed at Month 24 (2028-10-12) and promised unit scaling cannot be delivered. Funders may demand a go/no-go re-assessment, halting Phase 2 start. Alternatively, if Phase 2 proceeds without reconciliation, cost overruns accumulate and Phase 3 is abandoned mid-way, leaving a half-built network. Archives may withdraw partnerships if announced unit deployments slip due to budget exhaustion.

### 2.4.E Root Cause

The plan was initially designed without constraint modeling. The USD 250M cap and stated staffing (50-60 per unit at USD 2-3M opex) were set independently without reconciliation. Recomputation reveals the staffing assumption is 2-3x the budget-consistent crew size (~25 per unit). The programme has not been re-planned to fit the cap.

## 2.5.A Issue - Unvalidated AI Pre-Screening Assumption (80% Review Reduction) Is the Largest Cost Driver; Pilot Must Measure Real Flagging Rate

The plan assumes AI pre-screening reduces human review load by 80% (only 20% of content flagged). This assumption drives crew composition: 12-15 reviewers per unit at 30 units = 360-450 total. If actual flagging is 35-40% (a plausible alternative based on difficulty of recognizing privacy markers and copyright in degraded, multilingual pre-digital content), reviewer headcount triples to 40-50 per unit, adding USD 15-25M annual payroll at full scale—far exceeding opex budget. The claim is untested on real degraded, multilingual content from actual archives and is stated as a success metric, not a validated input.

### 2.5.B Tags

- ai_validation
- review_bottleneck
- cost_assumption
- operational_feasibility

### 2.5.C Mitigation

By Month 2 (2026-12-12), procure 100-200 representative samples from three proposed pilot archives, balanced across Tape, Film, and Card formats, emphasizing heavily degraded items. By Month 4 (2027-02-12), develop a gold-standard labeled dataset: have 3-5 expert reviewers (copyright, privacy, archival specialists) independently mark each sample for copyright markers, PII, classification markers; calculate inter-rater agreement (Cohen's kappa >=0.75 threshold). Test the AI pre-screening pipeline and publish precision, recall, and false-positive rate per category and format. If precision or recall is <75%, commission iterative retraining before deployment on real collections. By Month 8 (2027-06-12), after 3 months of pilot operations, measure actual flagging rates: route flagged and a stratified sample of non-flagged items through the review pod; if actual flagging exceeds 25%, trigger AI retraining or redesign review workflow (tiered review, delegated review to host archives, remote review hubs) and adjust Phase 2 crew assumptions accordingly.

### 2.5.D Consequence

If the AI assumption is not validated before Phase 2 design, crew composition and opex budgets will be based on false precision. Discovery at Month 8 (2027-06-12) or Month 20 (2028-06-12) that flagging is 35-40% forces either (a) budget overspend, (b) crew reduction (lower review quality and higher privacy/legal risk), or (c) late pivot to alternative review models. This directly impacts the gate decision for Phase 2 release; if uptime and accuracy targets are met but crew costs have overrun by USD 15-25M, Phase 2 funding cannot be released as planned. Archives may question the programme's cost-per-item claims if true crew sizes are understated.

### 2.5.E Root Cause

The plan was designed with an optimistic AI assumption without pilot validation. The 80% reduction figure appears to be aspirational rather than evidence-based. No test data on degraded, handwritten, multilingual, mixed-format 1950-2000 content exists in the documents. The plan bans assumptions about equipment but does not ban assumptions about AI accuracy.

## 2.6.A Issue - Institutional Trust and Legal Risk Are Concentrated in Three Unresolved Approvals; a Single Incident Could Cascade Network Failure

On-site processing depends entirely on archive insurers and fire authorities approving containerized pre-treatment (baking ovens, humidity chambers, on-board media storage, generators). A single handling incident destroying a unique collection, a thermal event damaging the host building, or a privacy breach during AI pre-screening could trigger incident escalation, insurer policy cancellation, and partnership termination. The plan acknowledges this risk but has not secured binding approvals from any insurer or fire authority at any proposed pilot site. Tiered indemnity, pooled loss reserves, and source-agreement templates are designed but not tested. Privacy and data-residency compliance across jurisdictions is mapped but not enforced.

### 2.6.B Tags

- institutional_trust
- legal_risk
- insurer_approval
- fire_authority
- privacy_compliance
- incident_cascade

### 2.6.C Mitigation

By Month 2 (2026-12-12), engage a specialized insurance broker and fire-safety consultant to conduct Hazard Analysis of baking ovens, humidity chambers, media storage, and generators; model thermal and chemical-release scenarios; estimate incident probability and financial exposure. By Month 4 (2027-02-12), develop Hazard Control Standard specifying sealed, monitored oven designs with internal thermostat accuracy, smoke/fume detection, filtered VOC exhaust, and fire suppression rated for archival materials. Retrofit one pilot container with certified design; submit for written approval by at least one archive's insurer and fire authority by Month 6 (2027-04-12). Use approval letter as template for all subsequent sites. If approval cannot be obtained, implement detached pre-treatment pod fallback (separate 20-ft container, 50m from main building), accept +4-6 week site setup delay, and budget USD 1.5-4.5M for 3 pilots (fallback cost). By Month 3 (2027-01-12), develop Standardized Source-Agreement Template covering scope, privacy commitment, storage location, access tier, copyright status, indemnity terms, and incident-notification protocol; customize per jurisdiction (EU GDPR annex, UK DPA annex, US state-level annexes). By Month 3 (2027-01-12), establish Privacy Review Panel (2-3 data-protection experts) to oversee flagged privacy decisions before upload; maintain Privacy Decision Log. By Month 3 (2027-01-12), develop Tiered Indemnity Structure: Full Coverage for stable items; Attempt-at-Own-Risk waivers for extreme-risk items; Deferred Tier for items unsafe to handle. Allocate USD 2-5M from Phase 1 as Pooled Loss Reserve for self-insurance. Establish Incident Response Protocol with 4-hour incident reporting, 24-hour insurer notification, 48-hour forensic investigation, and claim filing within 5 business days.

### 2.6.D Consequence

Without written insurer and fire-authority approvals by Month 6 (2027-04-12), the first pilot cannot be placed on-site, delaying operational start by 3-6 months. If approvals cannot be obtained, fallback to detached pods adds USD 1.5-4.5M capex and 4-6 weeks per site, reducing throughput and consuming contingency. If a handling incident occurs without pre-agreed indemnity, insurer refusal or policy cancellation could trigger partnership termination. A privacy breach (e.g., PII inadvertently uploaded due to false-negative AI flagging) could expose the programme to GDPR fines (4% of global revenue for organizations) or regulatory action in multiple jurisdictions, cascading termination across the entire network and forcing media return to archives. Legal and reputational damage could end the programme before Phase 2 release.

### 2.6.E Root Cause

The plan assumes on-site acceptance without first obtaining written approvals or testing indemnity structures. Archive partnerships are not yet signed; fire and insurer requirements are stated as design criteria but not negotiated with real counterparties. Privacy compliance is planned but not anchored to specific jurisdictions or tested on real content flagging.

---

# 3 Expert: Budget and Cost Reconciliation Analyst

**Knowledge**: Large-scale infrastructure cost modeling, staffing economics, phased budgeting, contingency and reserve planning, cost variance tracking, international project finance

**Why**: The plan has an unresolved USD 280M funding gap and a critical staffing reconciliation failure: 50-60 staff per unit at USD 2-3M opex does not reconcile with recomputed payroll of USD 75-126M annually at full scale. The independent cost audit must be commissioned by Month 1 (2026-11-12) and budget locked by Month 4 (2027-02-12), or Phase 1 capex commitments will be invalid.

**What**: Commission independent cost audit itemizing labor costs per role and region, equipment and consumables, depreciation and parts refresh, and site overhead for one MIU over 12 months. Publish three budget scenarios (baseline, +15%, +30%). Run a Pilot Staffing Pod for 3 months measuring actual loaded costs and time-to-productivity; extrapolate to full scale. Lock staffing model and publish a binding commitment that Phase 2 unit count will adjust if costs exceed the USD 250M cap.

**Skills**: Cost estimation, labor modeling, scenario analysis, variance analysis, contingency planning, inflation modeling, phased funding structures, international wage comparison

**Search**: infrastructure cost audit staffing model reconciliation, large-scale digitization project budgeting, contingency reserve planning, project cost variance tracking

## 3.1 Primary Actions

- By Month 1 (2026-11-12), commission an independent cost audit and establish a Programme Board (8-10 members). The audit must reconcile stated staffing (50-60 per unit) against opex budget (USD 2-3M/year), model Phase 1 contingency and Phase 3 funding gap, and publish three scenarios (full scope with extended timeline, cap-constrained scope of ~14 units, phased contingency funding). Lock the chosen scenario and staffing model by Month 4 (2027-02-12).
- By Month 1 (2026-11-12), secure written contracts with 6-8 retired-engineer mentors (min 2 per line type: Tape, Film, Card/Disk), aged 70-80, with 24-month retention bonuses (USD 50K-100K each). Concurrently, by Month 3 (2027-01-12), establish a Funding Commitment Registry documenting all funder pledges and convert at least 50% of Phase 1 budget (USD 30M of USD 60M) to binding commitments by Month 3 (2027-01-12). Identify three backup funding sources (host cost-share, government archives, technology-sector licensing) to close the USD 280M gap.
- By Month 2 (2026-12-12), commission a Parts Depletion Curve model specifying mean time between failures (MTBF) per deck type, cannibalization yield, and 3D-printing/CNC capacity for 20+ critical parts. By Month 6 (2027-04-12), conduct condition assessment of all 300-500 acquired vintage machines and establish a parts-consumption telemetry dashboard (deployed by Month 10 = 2027-08-12). Set re-manufacture trigger at 50% spares depletion to prevent stockouts.
- By Month 2 (2026-12-12), engage a specialized insurance broker and fire-safety consultant to model hazards (baking ovens, humidity chambers, on-board media storage, generators). By Month 4 (2027-02-12), develop a Hazard Control Standard and retrofit one pilot container to specification. By Month 6 (2027-04-12), obtain written fire-authority and insurer approval at one pilot site; use this letter as the template for all subsequent sites. If approval cannot be obtained, accept a detached pre-treatment pod fallback (USD 0.5-1.5M each, +4-6 weeks per site).
- By Month 2 (2026-12-12), procure 100-200 representative samples from three pilot archives (Tape/Film/Card, degradation levels 3-4). By Month 4 (2027-02-12), build gold-standard labeled dataset with 3-5 expert reviewers; test AI pre-screening and publish precision, recall and false-positive rate by category and format. By Month 8 (2027-06-12), run pilot review pod and measure actual flagging percentage and review hours per content hour. If flagging >25%, retrain AI or redesign review workflow; adjust Phase 2 crew. If any metric falls below 75% precision/recall, escalate to governance before replicating design into Phase 2.

## 3.2 Secondary Actions

- By Month 1 (2026-11-12), engage a data-protection and cultural-heritage legal team to map jurisdiction-specific transfer, personal-data and data-residency rules (GDPR, UK DPA, local export controls). Create a jurisdiction × data type matrix. By Month 3 (2027-01-12), publish a Standardized Source-Agreement Template (5-10 pages) covering digitization scope, privacy commitment, storage location, access tiers, copyright status, legal basis, indemnity and incident-notification protocol. Establish a Privacy Review Panel (2-3 experts rotating across sites) by Month 3 (2027-01-12) to oversee flagged privacy decisions before upload.
- By Month 2 (2026-12-12), develop a Tiered Indemnity Structure: Full Coverage Tier (stable items, full indemnity), Attempt-at-Own-Risk Tier (high-risk items with signed waiver), and Deferred Tier (unsafe items held for future specialist conservation). By Month 3 (2027-01-12), create a Pooled Loss Reserve (USD 2-5M from Phase 1 budget) for first-loss claims insurers decline (unique copyright disputes, classified records). By Month 4 (2027-02-12), establish an Incident Response Protocol with 24-hour insurer notification, forensic investigation (48-72 hours), and root-cause analysis (1 week).
- By Month 2 (2026-12-12), develop formal mentoring curricula documenting 50-80 critical repair competencies per line type (tape azimuth alignment, film registration calibration, card-reader maintenance) with video and written protocols. By Month 3 (2027-01-12), pair each mentor with 2-3 designated successor engineers; schedule intensive 1-on-1 sessions (min 16 hours/month per pair) documented in shared knowledge repository. Extend mentoring contracts to Month 48 (2030-10-12) by offering consulting roles.
- By Month 3 (2027-01-12), establish quarterly Cost-Tracking and Variance Reporting to funders by line item (labor, equipment, parts, logistics, utilities). Publish projected outturn per phase and alert governance if cumulative variance exceeds +10% overspend. By Month 4 (2027-02-12), publish three inflation scenarios (2%, 3%, 4% annual escalation) and allocate explicit Inflation Escalation Reserves per phase (Phase 1 +USD 9M, Phase 2 +USD 18M, Phase 3 +USD 10.5M).
- By Month 4 (2027-02-12), sign pilot host agreements (3 sites) with tiered indemnity, transparent site prioritization and defined readiness compacts (power, hardstand, security, liaison). Establish a Stakeholder Workshop to review source agreements, indemnity terms, privacy frameworks and incident protocols with all three pilot archives. By Month 6 (2027-04-12), confirm zero legal or privacy incidents at pilot sites and document all processes for Phase 2 replication.
- By Month 4 (2027-02-12), develop a Pre-Treatment Intake Screening Checklist that assigns each item to Full Coverage, Attempt-at-Own-Risk, or Deferred tier based on condition assessment (azimuth drift, layer adhesion, brittle-point, shrinkage). Record all decisions in a Condition Assessment Database and publish tier assignment statistics monthly. By Month 8 (2027-06-12), audit 5% of tier assignments for consistency and recalibrate thresholds if variance exceeds 10%.
- By Month 6 (2027-04-12), establish a Parts Engineering team (3-5 engineers) tasked with validating 3D-printing and CNC fabrication of 10 priority parts by testing on reference-grade decks. Measure playback fidelity against archival standards (azimuth ±0.05mm, wow/flutter <0.05%, signal-to-noise >50dB). If fabricated parts do not meet standards, source alternatives or negotiate extended vendor support. By Month 10 (2027-08-12), deploy parts-consumption telemetry dashboard with automatic re-manufacture order triggers at 50% stock depletion.
- By Month 12 (2027-10-12), convene an End-State Working Group (Board + legal + archive partners + technology advisors) to define post-Month 120 (2036-10-12) outcomes: which units transfer to archives, which parts are retained, how 200+ PB of masters are stewarded, and what knowledge-base form survives. By Month 36 (2029-10-12), publish a transition plan. By Month 90 (2034-04-12), identify successor bodies and secure endowments or post-programme funding commitments for continuation committee.

## 3.3 Follow Up Consultation

At Month 1 review (2026-11-12): Present cost audit findings, staffing reconciliation, and three budget scenarios. Confirm Programme Board membership and funder commitment targets. At Month 4 review (2027-02-12): Lock staffing model, budget scenario and Phase 1 operating plan. Confirm mentor contracts executed and parts-depletion model commissioned. At Month 8 review (2027-06-12): Present AI pre-screening validation results, actual review hours and flagging percentage. Decide whether to proceed with Phase 2 design or redesign review workflow. At Month 24 gate (2028-10-12): Validate pilot results against 80% thresholds; approve Phase 2 release or impose conditions. At Month 60 gate (2031-10-12): Confirm 15 units operational, 500K+ items recovered, 70% of Phase 3 funding committed; escalate if spares depletion is unsustainable.

## 3.4.A Issue - Critical Budget-to-Scope Mismatch Unresolved; Phase 3 Unfunded

The USD 250M cap supports ~47% of scope (~14 unit-equivalents, ~1.7M items, ~95 PB). Unconstrained cost is ~USD 530M. Phase 3 (USD 70M allocated) faces a ~USD 301M gap after capex for 15 new MIUs (USD 52.5M). No committed funding source exists for this gap. The plan cannot proceed to full scale without either (a) closing USD 280M via host cost-sharing or new funders, (b) accepting reduced scope (~14 units instead of 30), or (c) extending Phase 3 beyond Month 120 (2036-10-12). This decision is deferred and creates a go/no-go risk at Month 60 (2031-10-12).

### 3.4.B Tags

- budget_cap_violation
- phase_3_infeasibility
- funding_source_undefined
- scope_vs_budget_mismatch

### 3.4.C Mitigation

By Month 1 (2026-11-12), commission a three-scenario budget model: (a) full scope with extended timeline, (b) cap-constrained scope (14 units, 1.7M items), (c) phased contingency funding (USD 15-20M revolving facility by Month 3 = 2027-01-12). By Month 4 (2027-02-12), lock one scenario and publish the chosen scope. By Month 3 (2027-01-12), establish a Funding Commitment Registry documenting all pledges and identify three backup funding routes (host cost-share per unit, government archives consortium, non-exclusive technology-sector licensing). Escalate to governance if Phase 2 commitment falls below 70% (USD 84M) by Month 20 (2028-06-12).

### 3.4.D Consequence

Without a committed funding source or locked scope decision, the programme risks halting at Month 60 (2031-10-12) when Phase 3 cannot be funded. Media continues degrading during governance delays. Funders and archives lose confidence if the plan's scope and budget are not reconciled before Phase 1 completion. Staff and mentors cannot be retained if Phase 2 and Phase 3 are uncertain.

### 3.4.E Root Cause

Empty

## 3.5.A Issue - Staffing Model (50-60 per Unit) Does Not Reconcile with Opex Budget (USD 2-3M/Year)

Stated crew of 50-60 per unit implies USD 2.5-4.2M payroll alone (at USD 50-70K loaded cost per person); full fleet at 30 units = USD 75-126M annual payroll. But total opex is USD 2-3M per unit-year, leaving USD 0-0.5M for logistics, utilities, parts and consumables. Either (a) staffing must drop to ~25 per unit (budget-consistent), (b) opex must rise to USD 4-5M per unit-year, or (c) host cost-sharing must cover the gap. The plan cannot staff pilots at stated levels without clarifying this trade-off or identifying host/funder co-payroll contributions. This affects crew composition, review capacity, and maintenance capability.

### 3.5.B Tags

- staffing_budget_mismatch
- opex_underfunded
- payroll_not_reconciled
- crew_capacity_unclear

### 3.5.C Mitigation

By Month 1 (2026-11-12), engage a third-party infrastructure cost auditor to itemize opex by role, region and scenario (resident 50-60 staff, embedded 25-30, or centralized 15-20 core). By Month 2 (2026-12-12), model three crew compositions: (a) full resident (50-60 staff per unit, ~3M payroll + 0.5M other = 3.5M opex, requires budget increase), (b) embedded core + host training (~25 staff, ~1.5M payroll + 0.5M other = 2M opex), (c) centralized review hubs (~15 on-site + 20 remote, ~1.2M payroll + 0.5M = 1.7M opex). Lock one model by Month 4 (2027-02-12). Publish which roles are programme-funded, which are host-contributed, and whether host cost-sharing is mandatory or optional.

### 3.5.D Consequence

If staffing is not reconciled, Phase 1 pilots will either deploy under-staffed (threatening uptime and review quality targets) or overspend opex by USD 0.5-1.5M per unit-year (USD 1.5-4.5M across three pilots), creating a budget variance that signals poor cost control and undermines funder confidence.

### 3.5.E Root Cause

Empty

## 3.6.A Issue - Unproven AI Review Assumptions (80% Reduction Unvalidated) Create Hidden Reviewer Headcount Risk

The plan assumes AI pre-screening reduces human review from 1,000 to 200 hours per collection (80% reduction), requiring 12-15 reviewers per unit. This assumption is untested on degraded, multilingual, pre-digital 1950-2000 content. If actual flagging is 35-40% instead of 20%, reviewer headcount triples to 40-50 per unit, adding USD 15-25M annual payroll at full scale and exceeding budget envelope. Pilot validation by Month 8 (2027-06-12) is critical; if flagging exceeds 25%, the review workflow, crew model and Phase 2 design must be redesigned. Deferring this test until after Phase 1 units are built risks replicating an unproven design across 15 Phase 2 units.

### 3.6.B Tags

- ai_assumption_unvalidated
- review_load_uncertainty
- hidden_cost_driver
- pilot_gate_risk

### 3.6.C Mitigation

By Month 2 (2026-12-12), procure 100-200 representative samples from three pilot archive sites, balanced across Tape/Film/Card formats and degradation levels (condition scores 3-4). By Month 4 (2027-02-12), build gold-standard labeled dataset with 3-5 expert reviewers (copyright, privacy, archivists); achieve inter-rater agreement (Cohen's kappa ≥0.75). Test AI pre-screening pipeline and publish precision, recall and false-positive rate by category (copyright, privacy, classification) and format-degradation pair. If precision or recall <75%, commission iterative retraining. By Month 8 (2027-06-12), measure actual review rates on first pilot collection: route flagged and sampled non-flagged items through review pod; record mean hours per content hour and flagging percentage. If flagging >25%, trigger AI retraining or redesign review workflow (tiered review, delegated to host, remote hubs); adjust Phase 2 crew assumptions. Publish results to gates.

### 3.6.D Consequence

If the 80% review reduction does not hold and actual flagging is 35-40%, the programme is forced to choose between (a) deploying under-resourced review pods (missing 15-20% of sensitive content, creating privacy/legal risk), (b) hiring additional reviewers mid-programme (USD 15-25M unbudgeted payroll), or (c) redesigning the review gate post-deployment (disrupting all active units). Any choice creates schedule slippage, budget variance or legal exposure.

### 3.6.E Root Cause

Empty

---

# 4 Expert: Data Governance and Privacy Compliance Officer

**Knowledge**: GDPR, UK Data Protection Act, multi-jurisdiction privacy law, data residency requirements, personal data classification, privacy impact assessment, data breach response protocols

**Why**: The plan processes degraded 1950-2000 multilingual content containing personal data, medical records, classified government records and copyright-restricted works across multiple jurisdictions. Privacy or data-residency breach (GDPR fines up to 4% of global revenue) could halt the network; false negatives in AI pre-screening of sensitive items are a critical institutional-trust risk.

**What**: Map jurisdiction-specific transfer restrictions and data-residency requirements by country and data type (PII, medical, classified, copyright). Develop standardized Privacy Impact Assessment template for each source agreement and jurisdiction-specific annexes (EU, UK, US). Establish Privacy Review Panel (2-3 experts per cycle) with decision log for flagged items before archival upload. Design data-residency pathway: federated archive-held masters versus central repository versus offline deposit.

**Skills**: GDPR and DPA compliance, privacy impact assessment, data classification, breach notification, jurisdiction-specific legal mapping, cross-border data transfer frameworks, incident response, audit logging

**Search**: GDPR data residency digitization archives, privacy impact assessment cultural heritage, personal data classification degraded media, cross-border data transfer compliance

## 4.1 Primary Actions

- By Month 1 (2026-11-12 at 09:00), establish a Data Governance Office with a Chief Privacy Officer and 1–2 legal counsel experienced in GDPR, UK DPA 2018, and international data-transfer law; assign responsibility for all privacy, legal and compliance deliverables through Month 120 (2036-10-12).
- By Month 2 (2026-12-12 at 10:00), complete a Regulatory Jurisdictional Matrix and begin Data Protection Impact Assessment (DPIA) on the entire AI pre-screening + upload pipeline; identify high-risk processing and legal-basis options per jurisdiction before any pilot site agreement is signed.
- By Month 2 (2026-12-12 at 10:00), commission an independent AI-validation study: procure 100–200 representative degraded samples from proposed pilot archives and have expert reviewers label for copyright, privacy and classification markers; test AI pre-screening precision and recall against the labeled set, flagging any category-format pair with <75% accuracy as high-risk for retraining.
- By Month 4 (2027-02-12 at 14:00), publish three deliverables before pilot operations begin: (1) Standardized Source-Agreement Addendum per jurisdiction with explicit GDPR/UK DPA/local-law compliance language and breach-notification protocols; (2) updated AI pre-screening validation report with precision, recall, and false-positive rates per category-format; (3) Custody and Stewardship Working Group charter and preliminary modeling of 200+ PB perpetual-storage costs and funding mechanisms.
- By Month 6 (2027-04-12 at 14:00), execute pilot-review pod operations (Months 6–8 = 2027-04-12 to 2027-06-12): route all AI-flagged and a stratified sample of non-flagged content through the review gate; measure actual flagging percentage and review hours per content hour; if flagging ≥25%, trigger immediate AI retraining or workflow redesign before Phase 2 crew is hired.
- By Month 8 (2027-06-12 at 09:00), publish the go/no-go Evidence Report for Phase 2 gate, certifying: (1) AI pre-screening precision and recall ≥75% per category-format, or governance re-assessment if below; (2) actual human-review load validated on pilot content (flagging rate confirmed); (3) all source-agreement legal templates signed by pilot archives with zero legal or privacy objections; (4) Data-Residency Registry and Custody Model Choice locked; (5) perpetual-storage funder identified or endowment path committed.

## 4.2 Secondary Actions

- By Month 3 (2027-01-12), establish a Privacy Review Panel (2–3 data-protection experts per region, rotating per site) tasked with reviewing all AI-flagged privacy/copyright decisions before upload and maintaining a Privacy Decision Log for audit and incident response.
- By Month 3 (2027-01-12), publish guidance on archive curatorial review of AI flagging: provide templates and training so archive staff can validate AI pre-screening accuracy on their own collections before content leaves the container, building archive confidence in the process.
- By Month 4 (2027-02-12), develop a Breach Notification and Incident Response Protocol specifying: (1) internal escalation path (within 4 hours) if privacy-flagged content is inadvertently uploaded or personal data is exposed; (2) 24-hour notification to host archive and program governance; (3) 72-hour regulatory notification if GDPR or local DPA breach threshold is met; (4) root-cause analysis and remediation within 10 business days; (5) testing of the protocol quarterly with simulated breach scenarios.
- By Month 6 (2027-04-12), establish a Data-Subject Rights Request Handler: designate 1–2 staff to manage data-subject access, deletion and portability requests (per GDPR Articles 15–20) from individuals whose personal data appears in recovered collections; develop standard response templates and timelines (<30 days for GDPR requests).
- By Month 12 (2027-10-12), commission an independent audit of the AI pre-screening pipeline and privacy decision-making: have an external firm sample 100–200 flagged and non-flagged items across all pilot units and verify that the AI, privacy panel and human reviewers applied the source-agreement and jurisdiction-specific rules consistently; publish findings and remediation plans.
- By Month 18 (2028-04-12), establish a Rights-Holder Notification Framework: for collections with known copyright, identify and notify copyright holders of digitization; offer opt-out or restricted-access tiers; document consent or public-domain determination before archival upload.
- Implement quarterly Data-Governance Assurance Reporting to the Program Board and funders, covering: privacy complaints and incidents, AI flagging accuracy trends, source-agreement compliance rate, data-residency enforcement, perpetual-storage funding commitments, and format-migration readiness. Report any variance >5% from planned privacy/legal metrics as a governance escalation.
- Develop and maintain a Data-Governance Playbook (living document, updated quarterly) documenting: jurisdiction-specific source-agreement templates, privacy decision flowcharts, incident-response protocols, data-subject-rights procedures, breach-notification timelines, and lessons learned from each site deployment. Use this to ensure consistent privacy handling across 30 units and 30+ jurisdictions.

## 4.3 Follow Up Consultation

"At the Month 8 (2027-06-12) governance decision point (Phase 2 gate), we must assess: (1) Has the AI pre-screening pipeline achieved ≥75% precision and recall on privacy/copyright/classification categories across all format-degradation pairs? If not, does retraining or redesign align with Phase 2 timeline? (2) Are actual human-review loads (flagging rate, hours per content hour) within 10% of the plan's 20% flagging assumption? If flagging is 30%+, does crew restructuring and Phase 2 budget adjust accordingly? (3) Have all three pilot archives and their insurers/fire authorities approved the source agreements and pre-treatment hazard controls with zero legal/privacy objections? (4) Is the Custody and Stewardship Model chosen, and has at least one national/regional archive committed (in writing) to perpetual stewardship of masters? (5) What is the identified funding path for 200+ PB perpetual storage and format migration beyond Month 120 (2036-10-12)? Second consultation (Month 24 = 2028-10-12, Phase 2 authorization): Confirm that Phase 2 unit deployments implement the locked source-agreement templates and privacy decision-log protocols from all three pilot sites. Verify that the Data-Residency Registry is populated for all planned host archives and that no Phase 2 unit is scheduled for a jurisdiction where legal-basis issues remain unresolved. Third consultation (Month 60 = 2031-10-12, Phase 3 gate): Conduct a retrospective audit of privacy and legal incidents across the fleet; measure the incident rate per unit-year; identify systemic gaps and remediation. Assess whether perpetual-storage commitments have been secured and format-migration funding is funded through 2046. Determine whether any required custody or access-tier changes are needed before Phase 3 deployment into new jurisdictions."


## 4.4.A Issue - Privacy and Data-Residency Framework Severely Underspecified for Cross-Border Operations

The plan assumes on-site processing and federated data custody but lacks binding legal pathways for 30+ jurisdictions. GDPR, UK DPA, and regional data-residency rules (e.g., Canada Personal Information Protection and Electronic Documents Act, Australia Privacy Act) demand that personal data be processed, stored and transferred only with explicit legal basis. The source-agreement template and jurisdiction-mapping matrix are due Month 3 (2027-01-12), but pilot operations start Month 6 (2027-04-12)—a 3-month compliance debt. The AI pre-screening pipeline flags PII but has no tested accuracy on multilingual 1950-2000 content, risking false negatives that permit unlawful upload. No mention of data-transfer impact assessments (DPIA per GDPR Article 35) or Standard Contractual Clauses for third-country transfers.

### 4.4.B Tags

- GDPR-compliance-gap
- data-residency-risk
- PII-detection-untested
- jurisdiction-coverage-incomplete
- legal-basis-undefined

### 4.4.C Mitigation

By Month 1 (2026-11-12 at 09:00), establish a Data Governance Office staffed by a Chief Privacy Officer and 1-2 legal counsel with expertise in GDPR, UK DPA 2018, and target jurisdictions' transfer restrictions. By Month 2 (2026-12-12), complete a Regulatory Jurisdictional Matrix listing: each target country, applicable law (GDPR, UK DPA, national privacy law), data-transfer restrictions, personal-data definitions per jurisdiction, and legal basis options (consent, public-task exemption, vital-interest). Conduct a Preliminary Data Protection Impact Assessment (DPIA) on the entire AI pre-screening + human-review + upload pipeline; identify high-risk processing (automated PII detection, cross-border transfer, restricted-tier storage). By Month 3 (2027-01-12 at 14:00), publish a Standardized Source-Agreement Addendum per jurisdiction, specifying: (a) legal basis for collection and processing; (b) PII handling and restricted-tier designation; (c) data-residency requirement (in-country hold, federated archive, or central backup); (d) data-subject rights (access, deletion) and timelines; (e) breach notification (48-72 hour to authority, 24-hour to archive); (f) retention period (archive forever vs. timed deletion). Lock this before any pilot site agreement is signed.

### 4.4.D Consequence

Without pre-negotiated legal pathways, each archive creates ad-hoc source agreements, fragmenting privacy handling across 30+ sites and inviting regulatory challenge. A single GDPR-reportable breach (e.g., upload of personal data without consent, unauthorized cross-border transfer) to a Competent Authority can trigger: fines up to €20M or 4% of global revenue (whichever higher) for organizations; reputational damage halting partnerships network-wide; archives revoking permissions and demanding data destruction; loss of funder confidence and government archive participation. The plan's pre-upload human review gate cannot scale if PII-flagging precision is untested: false negatives permit unlawful processing; false positives delay upload and inflate reviewer load. At full scale (1,500–1,800 staff across 30 units), a single sustained privacy breach could expose the entire program to regulatory action.

### 4.4.E Root Cause

The plan prioritizes operational speed and archive partnerships over regulatory mapping. Custody and Access Regime (Decision 7) defers storage location choice, but cross-border transfers and restricted-data handling demand upfront legal settlement. The Privacy Impact Assessment template is a deliverable, not a completed artifact. No Data Protection Impact Assessment (DPIA) process exists; no Competent Authority notification plan for GDPR-level breaches. Risk is distributed across 30 units and dozens of archives, multiplying exposure.

## 4.5.A Issue - AI Pre-Screening Accuracy Validation Missing; Flagship Cost Assumption Unproven

The entire crew-composition and budget model rests on the claim that AI pre-screening reduces human-review load by 80%, meaning 20% of content is flagged. No pilot data supports this; the assumption is a planning input, not a validated metric. The AI must detect copyright markers (watermarks, logos, broadcast metadata), privacy indicators (PII patterns, medical jargon, personal correspondence), and classification markers (government stamps, security labels) on degraded, multilingual content from 1950-2000. If actual flagging is 35-40% instead of 20%, reviewer headcount required per unit triples from 12–15 to 40–50, adding USD 15–25M annual payroll at full scale—far exceeding the USD 2–3M opex budget. The plan bans 'autonomous legal/privacy decisions,' yet the AI pre-screening gate is itself an autonomous triage that, if it misses 25–30% of flaggable items, creates unlawful processing downstream. No cross-validation with archive curatorial staff on the AI's flagging accuracy. No published training-data provenance or model-card documentation.

### 4.5.B Tags

- AI-accuracy-unvalidated
- cost-assumption-fragile
- PII-detection-precision-unknown
- crew-headcount-sensitive
- autonomous-review-risk

### 4.5.C Mitigation

Immediately (Month 2 = 2026-12-12 at 10:00), commission an independent AI-validation study: (1) Procure 100–200 representative samples from three proposed pilot archives (50% tape, 40% film, 10% card), balanced across degradation levels (condition scores 1–5 per ISO standards). Emphasize heavily degraded items (scores 3–4). (2) By Month 4 (2027-02-12 at 14:00), have 3–5 independent expert reviewers (copyright specialist, privacy lawyer, archivist, multilingual curator) label each sample for: copyright markers (presence/absence, confidence 1–5), privacy indicators (PII type: names, medical, financial, communications; presence/absence; confidence), classification markers (government, military, proprietary; presence/absence). Calculate inter-rater agreement (Cohen's kappa ≥0.75 threshold). (3) Test the AI pre-screening pipeline on the labeled set; publish precision, recall, and false-positive rate per category and per format-degradation pair. If precision or recall <75% on any category-format, record as high-risk; flag for retraining before pilot use. (4) Pilot-review pod (Months 6–8 = 2027-04-12 to 2027-06-12): route all flagged items and a stratified 5–10% sample of non-flagged content through the review gate; measure actual review hours per content hour and actual flagging percentage (vs. assumed 20%). If flagging ≥25%, immediately trigger: retraining with domain-specific labeled data, or recalibration of detection thresholds, or redesign of review workflow (e.g., tiered review with archive delegation). If flagging exceeds 30%, escalate to governance and prepare crew restructuring (potential +USD 5–15M Phase 1 cost). Publish results by Month 8 (2027-06-12) as go/no-go evidence for Phase 2.

### 4.5.D Consequence

If the AI flagging rate is 35–40% instead of 20%, reviewer headcount per unit increases 2.5× (from 12–15 to 35–50). At 30 units and USD 60K loaded cost per reviewer per year, this adds USD 36–60M annual payroll—USD 360–600M over the 10-year program—far exceeding the USD 250M total budget cap. The program would need to reduce unit count to ~14 (cutting scope to ~1.7M items, ~95 PB) or abandon the embedded-reviewer model entirely. If AI precision on privacy is <70%, false negatives permit unlawful processing of personal data (PII exposure, GDPR breach), cascading fines and partnership loss. If false-positive rate is high (>30% of flagged items don't require review), reviewer time is wasted and upload latency increases, delaying recovery of degrading media. The plan's safeguard (human review before upload) becomes operationally infeasible if unvalidated assumptions prove false.

### 4.5.E Root Cause

The plan treats the 80% review reduction as a design goal, not a hypothesis. The AI pipeline is designed but not tested on real content. Reviewer headcount (12–15 per unit) is calculated backward from the assumed 20% flagging rate, not forward from measured content hours and required review pace (e.g., 2 hours of review per 1 content hour for copyright/privacy checks). Rights, Privacy, and Review Gate Design (Decision 2) acknowledges that 'AI pre-screening for copyright, personal data, and classification markers on degraded, multilingual, pre-digital content has no demonstrated accuracy yet,' but the mitigation offered is to test it in the pilot—by which time 3 units are already built and crew hired. No contingency for retraining or crew restructuring if accuracy is below threshold.

## 4.6.A Issue - Custody, Access and Perpetual-Storage Liability Undefined; Post-Month 120 (2036-10-12) Stewardship Gap Unresolved

The plan targets 200+ PB of digitized content by Month 120 (2036-10-12) but defers the central decision: who owns the masters, where they legally reside, how they are migrated into future formats, and who funds perpetual storage and preservation after the 10-year program closes. Custody, Format, and Access Regime for Recovered Data (Decision 7) offers three routes: program-managed central repository, archive-held masters with federated copies, or offline masters deposited with archives. None is chosen. Data-residency rules (GDPR, UK DPA, national restrictions) vary per jurisdiction, so the same dataset cannot be held in one central location if it contains restricted personal data from multiple countries. Perpetual storage of 200+ PB demands a funded steward beyond Month 120 (2036-10-12); no commitments exist. Format migration (keeping data readable across format obsolescence) is not budgeted. Access-tier management (restricted/embargoed/public) requires ongoing governance and staff long after the units close.

### 4.6.B Tags

- custody-undefined
- data-residency-fragmented
- perpetual-storage-unfunded
- format-migration-unbudgeted
- post-program-stewardship-gap

### 4.6.C Mitigation

By Month 3 (2027-01-12 at 10:00), establish a Custody and Stewardship Working Group (6–8 members: legal counsel, archivists, data-governance lead, funder representative) tasked with resolving: (1) Custody Model Choice: decide among the three Decision 7 options. Recommendation: hybrid model—archive-held masters on certified storage, with a verified secondary copy replicated to a federated network of national repositories (per PREMIS standards). This keeps original-archive trust and satisfies data-residency rules. (2) Data-Residency Enforcement: per the Jurisdictional Matrix (Feedback 1), restricted personal data must reside in-country or under Standard Contractual Clauses. Implement a Data-Residency Registry tagging every collection (originating country, restricted-data presence, legal residency requirement, primary steward archive, backup archive location). (3) Perpetual-Storage and Format-Migration Funding: by Month 12 (2027-10-12), commission an independent cost estimate for: (a) storage of 200+ PB on certified archival media (estimate: USD 3–5M per PB over 20 years = USD 600M–1B, far exceeding the USD 250M program budget); (b) format migration every 10 years to prevent obsolescence (estimate: USD 50–100M per decade per 100 PB = USD 100–200M per decade fleet-wide). Identify a long-term funder (e.g., National Digital Stewardship Alliance, European Open Science Cloud) or endowment committed to perpetual preservation. By Month 24 (2028-10-12), secure binding commitments from at least one national or regional archive to assume stewardship of masters and fund perpetual storage. (4) Technology-Sector Funding Terms: publish a Data-Access Policy specifying that research-access rights to recovered data are granted only with explicit written consent from rights holders and source archives. Prohibit algorithm-training on restricted personal data; restrict commercial re-use of cultural artifacts. Use this policy in all source agreements so archives and funders know what 'research access' means before they commit.

### 4.6.D Consequence

If custody is not settled before pilots launch, archive agreements will fragment: some archives demand masters remain in-country; others allow replication to a central hub; technology-sector funders demand training-data access; rights holders sue for unauthorized licensing. This creates legal liability and blocks uploads, halting recovery. If perpetual-storage funding is not secured by Month 24 (2028-10-12), the program accumulates a 200+ PB data liability with no funded steward. At program close (Month 120 = 2036-10-12), the digital masters either remain in temporary program storage (expensive, unsustainable) or are transferred to archives that cannot afford perpetual preservation (media degraded, inaccessible within 10 years). Format migration must begin before formats become obsolete; if no funding or governance exists, 200+ PB of 2030s-era encoded video becomes unplayable by 2050. Archive trust erodes: archives that provided originals for on-site digitization will demand guarantees that the output is perpetually preserved; failure to provide that guarantee ends partnerships. The post-Month-120 gap is a legacy liability that consumes USD 600M–2B+ in perpetuity, shifting burden to archives or governments without their consent.

### 4.6.E Root Cause

The plan optimizes for recovery speed and volume during the 10-year window but treats the exit strategy (custody, storage, migration, access control) as a late decision. Custody, Format, and Access Regime (Decision 7) is rated 'High' importance but remains open; no funding is allocated for perpetual preservation beyond Month 120 (2036-10-12). The program budget ends Month 120 (2036-10-12); storage and migration costs persist indefinitely. Archives asked to host original media during residencies may refuse if they cannot be guaranteed a copy of the digital masters in perpetuity. Technology sector funders may demand research-access rights to training data, conflicting with source-agreement restrictions and archive trust. No legal model is defined for cross-border data custody when restricted personal data cannot leave its jurisdiction of origin.

---

# 5 Expert: AI and Quality Assurance Validation Specialist

**Knowledge**: Signal reconstruction and AI model accuracy, validation methodologies, archival standards testing, metadata extraction accuracy, false-negative and false-positive analysis, model retraining workflows

**Why**: The claimed 80% AI review reduction is untested on degraded, multilingual pre-digital content and is the single largest cost driver. If actual flagging is 35-40% instead of 20%, reviewer headcount triples from 12-15 to 40-50 per unit, adding USD 15-25M annual payroll at full scale and exceeding the USD 250M cap. Validation must complete by Month 8 (2027-06-12) before Phase 2 design freeze, with precision and recall >=75% per category-format as the gate threshold.

**What**: Procure 100-200 representative degraded samples (Tape, Film, Card lines) balanced by condition grade and language. Create gold-standard labeled dataset via independent expert review: copyright, privacy and classification markers with inter-rater agreement (Cohen's kappa >=0.75). Test AI pre-screening pipeline against labeled set; publish precision, recall and false-positive rate by category, format and degradation level. After 3 months of pilot operations, measure actual review hours per content hour and flagging percentage; trigger retraining if precision/recall <75% or flagging >25%.

**Skills**: Machine learning validation, accuracy metrics (precision, recall, F1), labeled dataset creation, inter-rater agreement analysis, model retraining, statistical testing, archival standards compliance, signal fidelity measurement

**Search**: AI model validation degraded media content, precision recall metadata extraction accuracy, machine learning quality assurance digitization, classification accuracy false-negative testing

## 5.1 Primary Actions

- By Month 1 (2026-11-12): Commission independent cost audit reconciling staffing, opex and the USD 250M cap; establish Programme Board (8-10 members); convene Funding Commitment Registry to translate pledges into binding multi-year contracts; secure 6-8 retired-engineer mentoring contracts with retention incentives through Month 48 (2030-10-12). Engage data-protection and cultural-heritage legal counsel to map jurisdiction-specific rules and draft standardized source-agreement template.
- By Month 2 (2026-12-12): Commission parts-depletion curve and MTBF model (external specialist) for each line type; specify cannibalization yield and re-manufacture trigger at 50% spares depletion. Engage fire-safety consultant and insurance broker to conduct hazard analysis of baking ovens, humidity chambers and on-board generators; develop hazard-control standard document. Procure 100-200 representative content samples (degraded Tape, Film, Card items) from three proposed pilot archives for AI validation.
- By Month 3 (2027-01-12): Run pilot staffing pod (3-month measurement) to validate loaded costs per role and time-to-productivity. Publish three budget scenarios (baseline, +15% inflation, +30% inflation) to Month 120 (2036-10-12). Create gold-standard labeled dataset (100-200 samples) with 3-5 expert human reviewers; measure inter-rater agreement (Cohen's kappa ≥0.75). Establish Privacy Review Panel; publish standardized source-agreement template with jurisdiction-specific annexes (GDPR, UK DPA, state-level). Develop tiered-indemnity structure and establish pooled loss reserve (USD 2-5M) for damage to unique items.
- By Month 4 (2027-02-12): Lock Phase 1 budget and staffing model; publish funding gap quantification (approximately USD 280M before contingency) and three path options (host cost-sharing, unit-count reduction, crew-size reduction). Validate 3D-printing and CNC fabrication on ≥10 priority part types; measure playback fidelity against archival standards. Test AI pre-screening pipeline on labeled dataset; publish precision, recall and false-positive rates by category-format-degradation. Secure written multi-year host agreements for three pilot sites (Months 6-9 = 2027-04-12 to 2027-07-12) with insurer and fire-authority approval letters attached.
- By Month 6 (2027-04-12): Obtain written insurer and fire-authority approval at one pilot site; publish approval letter as template for remaining sites. Retrofit first pilot unit and confirm hazard controls. Operationalize Parts Consumption Telemetry dashboard and Privacy Decision Log. Begin pilot unit operations (Month 6 = 2027-04-12) on stress-first collection (worst-condition site). By Month 8 (2027-06-12): Measure actual review rates from pilot operations (flagging %, mean hours per content hour). If flagging >25% or precision <75%, trigger AI retraining and crew-model redesign before proceeding to Phase 2.

## 5.2 Secondary Actions

- Convene an independent verification regime (external auditors, circulating reference-media sets) by Month 3 (2027-01-12); establish sampling protocol and cross-unit drift detection by Month 6 (2027-04-12).
- Establish end-state working group by Month 12 (2027-10-12) to plan what remains after Month 120 (2036-10-12): retained core units, transferred units, parts archive, knowledge base handover, endowment or rental-pool options. Define reduced-scope trigger: if reconciled cost forces <24 units, convene governance re-assessment.
- Develop customs pathway documentation (temporary import, heritage export, data-residency) for target jurisdictions by Month 3 (2027-01-12); pre-negotiate temporary-admission agreements with customs bodies in 3-5 priority countries by Month 6 (2027-04-12).
- Build incident-response protocol and maintain central incident log (handling damage, contamination, equipment failure) by Month 3 (2027-01-12); establish 24-hour insurer notification and 4-week forensic investigation standard by Month 4 (2027-02-12).
- Create quarterly cost-tracking and variance-reporting dashboard; measure actual spend vs. budget by line item and publish projected outturn by Month 6 (2027-04-12); flag overspend >10% for governance decision-point by Month 12 (2027-10-12).
- Secure binding Phase 2 funding commitments (≥USD 84M = 70% of Phase 2 budget) by Month 24 (2028-10-12); model host cost-share contributions per MIU residency and quantify in-kind power, space, liaison value by Month 6 (2027-04-12).
- Commission independent ML validation specialist (not the AI team) to audit pre-screening results by Month 8 (2027-06-12); conduct retraining if any precision/recall <75% and publish updated metrics before Phase 2 design freeze at Month 20 (2028-06-12).
- Establish 24-month, sustained mentoring curriculum (50-80 critical repair competencies per line type, documented in permanent video and written protocols) by Month 4 (2027-02-12); pair each mentor with 2-3 successor engineers by Month 3 (2027-01-12) and schedule minimum 16 hours/month paired sessions through Month 48 (2030-10-12).

## 5.3 Follow Up Consultation

At Month 6 (2027-04-12), reconvene to assess: (1) Pilot unit operational status—uptime, digitization success %, signal-reconstruction accuracy %, actual review flagging % vs. the assumed 20%; (2) Parts inventory health—first depletion events, any MTBF surprises, re-manufacture validation on reference decks; (3) Budget recomputation—actual opex from pilot staffing pod, cost audit findings, revised Phase 2 and Phase 3 funding requirements; (4) AI pre-screening pilot results—precision, recall, false-positive rates by category-format, any retraining triggered; (5) Compliance status—insurer and fire-authority approval letters in hand, host agreements signed, privacy review panel operationalized, zero incidents. If pilot uptime <90%, flagging >25%, precision <75%, or recomputed costs show >10% overspend, convene governance decision-point before releasing Phase 2 funding. If all thresholds hold at Month 6 (2027-04-12), provisionally release Phase 2 funding tranches conditional on sustained performance (≥3 consecutive months at ≥80% of targets per the gate criteria). Plan Phase 2 unit procurement and site schedule for Months 6-24 (2027-04-12 to 2028-10-12).

## 5.4.A Issue - Unvalidated AI Pre-Screening Accuracy Drives Crew Headcount and Budget—Test Real Content Immediately

The plan assumes 80% review reduction (20% content flagged) as a cost-driver anchor, but this is untested on degraded, multilingual, pre-digital content. If actual flagging is 35-40%, reviewer headcount triples from 12-15 to 40-50 per unit, adding USD 15-25M annual payroll at full scale—far exceeding the USD 25M average annual budget envelope. The claim rests on AI precision and recall thresholds (≥75%) that have never been measured on the target dataset. Pilot data by Month 8 (2027-06-12) cannot be deferred; crew composition and Phase 2 approval hinge on this evidence.

### 5.4.B Tags

- ai_accuracy_unvalidated
- review_bottleneck_unproven
- budget_reconciliation_broken
- crew_headcount_fragile

### 5.4.C Mitigation

By Month 4 (2027-02-12), create a gold-standard labeled dataset: 100-200 samples across Tape, Film and Card lines, heavily degraded items, multiple languages. Have 3-5 expert human reviewers independently flag copyright, PII and classification markers; measure inter-rater agreement (Cohen's kappa ≥0.75). Test the AI pre-screening pipeline; publish precision, recall and false-positive rates by category-format-degradation. If any metric <75%, commission iterative retraining before touching real collections. By Month 8 (2027-06-12), measure actual review rates in the pilot pod: flagging percentage and mean hours per content hour. If flagging exceeds 25% or precision <75%, redesign crew model or retrain AI before Phase 2 scale-up. Engage an independent ML validation specialist (not the AI team) to audit results.

### 5.4.D Consequence

If this validation is deferred or skipped: Phase 2 crew composition will be miscalibrated. If actual flagging is 35-40%, the program will either underfund reviewers (leading to quality failures and privacy incidents) or overfund them (consuming USD 15-25M above budget, forcing unit-count reduction to ≤18 across all phases). Either path breaks the 3.6M-item target or the USD 250M cap. A privacy or copyright false-negative on degraded content could destroy archive partnerships network-wide. Pilot results will lack credibility with funders and archives if this evidence is missing.

### 5.4.E Root Cause

The plan was designed around an operational assumption (80% review reduction) rather than measured ground truth. No labeled validation dataset from real 1950-2000 content exists; no baseline precision, recall or false-positive rates per content category (copyright, PII, classification) and degradation level have been established. The assumption was never tested and was never meant to be a planning input per the assessment notes, yet it was used as one.

## 5.5.A Issue - Hardware Sustainment Model Lacks Depletion Curve—Finite Spares Will Exhaust by Month 36-48 (2029-10-12 to 2030-10-12) Without Modeling

The plan depends on a 300-500 vintage-deck stockpile, sustained by cannibalization, to keep 30 units running at >90% uptime for 10 years. Yet no parts-depletion curve, mean-time-between-failures (MTBF) model per deck type, or re-manufacture yield exists. Without this modeling, the uptime target is speculative. Spares will be consumed by continuous operation; once depletion crosses 50%, MTBF and availability worsen sharply. Retired mentors (aged 70-80 now) cannot be held beyond Month 48 (2030-10-12), so knowledge and repair capacity exit before Phase 3 reaches full scale at Month 90-120 (2034-04-12 to 2036-10-12). A mid-program emergency re-purchase of vintage machines (USD 15-25M) may be unavoidable but unbudgeted.

### 5.5.B Tags

- spares_depletion_unmapped
- uptime_target_unsupported
- mentor_attrition_risk
- mtbf_not_modeled
- phase3_feasibility_fragile

### 5.5.C Mitigation

By Month 2 (2026-12-12), commission a Parts Depletion Model (external specialist, not internal team): for each of the 3 line types, document at least 10 reference machines' MTBF distributions (time-to-failure curves), measured or sourced from broadcast-industry literature. Model spares yield: how many usable parts per 10 machines cannibalized, by part category (heads, transports, motors, belts, optical assemblies). Estimate monthly consumption per active unit and cumulative depletion curve for 160 unit-years (Phase 1-3). Identify the inflection point where remaining spares drop to 50% (the re-manufacture trigger). By Month 4 (2027-02-12), validate 3D-printing and CNC fabrication on at least 10 priority part types by testing on reference-grade decks; measure playback fidelity (azimuth offset, dropout rate, signal-to-noise) against archival standards. By Month 1 (2026-11-12), secure written contracts with 6-8 retired mentors; offer 24-month engagement through Month 24 (2028-10-12), with extension incentive (consulting role, part-time contract) through Month 48 (2030-10-12). Document all mentor knowledge in permanent video and written protocols by Month 4 (2027-02-12). By Month 10 (2027-08-12), deploy a Parts Consumption Telemetry dashboard: each unit logs parts usage monthly; central system triggers re-manufacture orders at 50% depletion threshold. If the depletion model shows infeasible exhaustion (spares fully consumed before Month 100 = 2035-02-12), escalate to governance for go/no-go re-assessment.

### 5.5.D Consequence

Without a depletion model, the program will experience unplanned stockouts, causing MIU downtime and uptime <90% by Months 36-48 (2029-10-12 to 2030-10-12). This will trigger emergency vintage re-purchase (USD 15-25M unbudgeted), reducing Phase 3 scope or requiring new funding that may not materialize on-time. Mentor knowledge will be lost between Months 24-48 (2028-10-12 to 2030-10-12) as mentors age out or become unavailable; Phase 3 repairs will rely on partially-trained younger engineers, increasing repair time and reducing uptime further. Archive partners will lose confidence if uptime drops below 90%; partnerships could terminate. The stress-first pilot (first unit on worst-condition collection) will expose this risk by Month 12-18 (2027-10-12 to 2028-04-12), but late discovery wastes time and capital.

### 5.5.E Root Cause

The sustainment strategy was designed conceptually (buy stockpile, cannibalize, retrain engineers) without engineering rigor. No quantitative model of consumption was created. MTBF per deck type and line (Tape, Film, Card) vary widely; some units will fail within 6 months of continuous use, others within 3 years. The yield of usable parts per cannibalized machine is unknown. The 3D-printing and CNC capability is acknowledged but not validated for critical parts (azimuth fixtures, capstan sleeves, pinch rollers). Retired mentors, once engaged, have limited availability windows (18-24 months of intensive work); their exit by Month 48 (2030-10-12) leaves Phase 3 (Months 60-120 = 2031-10-12 to 2036-10-12) operating with younger engineers trained by now-absent mentors.

## 5.6.A Issue - Budget Reconciliation Unresolved—Recomputed Costs USD 530M vs. Cap USD 250M; Staffing Model Internally Inconsistent

The plan states 50-60 staff per unit at USD 2-3M opex per unit-year. Recomputation shows: payroll alone at 50-60 staff × USD 50-70K loaded cost = USD 2.5-4.2M per unit annually. At full scale (1,500-1,800 staff), annual payroll alone is USD 75-126M, dwarfing the USD 25M average annual budget envelope. Total unconstrained cost is approximately USD 530M (capex USD 105M + equipment USD 20M + training USD 5M + opex 160 unit-years × USD 2.5M = USD 398.75M). This leaves an unfunded gap of approximately USD 280M before contingency and risk add-ons. The Phase 1 and Phase 2 budgets have marginal headroom; Phase 3 is severely underfunded. No reconciliation path is clear: either unit count must drop to ~14-18 (breaking the 3.6M-item target), staffing per unit must halve (breaking quality and training promises), host cost-sharing must materialize (unquantified), or new funders must cover USD 280M+ (uncertain).

### 5.6.B Tags

- budget_gap_enormous
- staffing_model_inconsistent
- cost_audit_missing
- phase3_unaffordable
- scope_target_at_risk

### 5.6.C Mitigation

By Month 1 (2026-11-12), commission an independent cost audit (external infrastructure or systems consultant, not program staff): item-by-item opex per MIU over 12 months, specifying labor roles and loaded costs per region (Northern Virginia, UK, Netherlands, Australia, Japan—weighted average), equipment consumables per line type, satellite/fiber uplink, depreciation, contingency. Publish three scenarios (baseline, +15% inflation, +30% inflation) for Months 0-120 (2026-10-12 to 2036-10-12). By Month 3 (2027-01-12), run a pilot staffing pod (first hub site, representative crew) and measure actual loaded costs over 3 months; extrapolate to full scale. By Month 4 (2027-02-12), publish a reconciled budget and staffing model locked for Phase 1: specify the funding gap (approximately USD 280M, before reserves) and present three path options: (A) host cost-sharing + new funders close gap; (B) reduce unit count to 14-18 (Phase 3 only ~8-12 units), revise targets to 1.7M items and ~95 PB, replan phases; (C) reduce crew per unit to 25-30 (budget-consistent), accept lower review coverage or longer residencies. Present trigger thresholds: if cost audit shows gap >USD 300M or reconciled staffing forces <20 units, escalate to governance for go/no-go re-assessment. By Month 3 (2027-01-12), establish a Funding Commitment Registry: translate each funder pledge into binding multi-year contract language; target ≥USD 30M committed (not pledged) for Phase 1 and ≥USD 84M (70%) for Phase 2 before that phase launches.

### 5.6.D Consequence

If this reconciliation is deferred or glossed over, Phase 1 will be underfunded (estimated ~USD 14.5M headroom against ~USD 16-28.5M in risk add-ons and inflation), forcing cost cuts mid-execution. Staffing will be inadequate relative to crew-role promises, leading to quality failures, mentor overload, and burnout. Phase 2 approval gates will not hold credibly if the budget arithmetic is visibly broken; funders will demand answers before releasing tranches. Phase 3 will be wholly unaffordable without material changes (fewer units, reduced scope, or new funding); media degradation will continue while governance re-assesses. The plan will lose strategic credibility with archives, insurers and government partners if budget and staffing are perceived as unresolved assumptions rather than realistic plans. Pilot evidence will be discounted if the financial base is unstable.

### 5.6.E Root Cause

The plan was architected on two untested assumptions: (1) the stated staffing of 50-60 per unit would fit USD 2-3M opex, and (2) the USD 250M cap was sufficient to deliver 30 units and 3.6M items. Neither assumption was cost-modeled at origination. When recomputed, the figures do not reconcile: staffing is undersized relative to the stated crew roles (3-4 engineers + maintenance, 12-15 reviewers, logistics liaison = ~20 minimum operational core; adding pre-treatment, robotics, QC, data-transmission staff yields 40+ easily). Equally, the cap was set as a policy constraint, not derived from bottom-up cost buildup. The two constraints are now in collision.