
## Question 1 - Which funders will sign binding multi-year commitments for the $250M (user constraint), and how will the staffing-versus-opex mismatch and inflation be reconciled?

**Assumptions:** Assumption: At least 50% of Phase 1 ($60M) is committed (not pledged) by Month 3 (2027-01-12), a 10% contingency is held per phase, and the budget is restated in constant 2026 dollars. Rationale: pledged funds on annual cycles commonly slip; 10% is a typical infrastructure contingency.

**Assessments:** Title: Financial Feasibility Assessment
Description: Tests whether $250M covers 30 units and the stated crews.
Details: Recomputed: 50-60 staff per unit at 30 units implies payroll of roughly $36M-$54M per year (estimate), against a $25M average annual budget. Either unit count, crew size or budget must change. Mitigation: independent cost audit by Month 1 (2026-11-12), binding commitments registry, inflation reserve of 15-20% (proposed), bridge facility for gate delays. Benefit: credible numbers raise funder confidence.

## Question 2 - What gate criteria and durations release Phase 2 (Month 24 = 2028-10-12) and Phase 3 (Month 60 = 2031-10-12), and how long must the stress-first pilot run?

**Assumptions:** Assumption: Pilots run Months 6-20 (2027-04-12 to 2028-06-12) on at least two host sites, design freeze occurs by Month 20 (2028-06-12), and gates are agreed in writing before Month 6 (2027-04-12). Rationale: media failure modes and review rates need several months of real data.

**Assessments:** Title: Schedule and Gate Assessment
Description: Evaluates pacing from 3 to 15 to 30 units.
Details: Phase 2 slip of 3-6 months is plausible if funder committee cycles apply (estimate). Stress-first pilot exposes failures early but may depress early metrics; pre-agreed thresholds and a best-efforts override (e.g. >80% of targets, proposed) limit this. Build 2-3 month buffers per transition. Quarterly milestones keep evidence continuous.

## Question 3 - How many engineers, reviewers and retired-engineer mentors are needed per phase, and where will they be recruited?

**Assumptions:** Assumption: 6-8 retired mentors are secured by Month 1 (2026-11-12), each training 2-3 successors over 18-24 months, with hubs in Northern Virginia, UK and Netherlands. Rationale: redundancy covers mentor attrition at ages 70-80.

**Assessments:** Title: Workforce and Expertise Assessment
Description: Reviews crew model and perishable vintage skills.
Details: The 1,500-1,800 headcount is unreconciled with budget. Reviewer load depends on the unvalidated 80% reduction; at 35-40% flagging, reviewers per unit could be 3x (estimate). Mitigate with pilot review pod by Month 8 (2027-06-12), retention bonuses, documented curricula, and a shared reviewer pool. Mentor loss before Month 18 (2028-04-12) would delay transfer by 6-12 months (estimate).

## Question 4 - What governance body, decision rights and source-agreement terms (privacy, copyright, data residency) will apply across jurisdictions?

**Assumptions:** Assumption: A Programme Board of 8-10 members with site, technical, legal and finance committees is formed by Month 1 (2026-11-12), using a standard source-agreement template with jurisdiction-specific annexes. Rationale: 15+ funders and 30+ archives need clear decision rights.

**Assessments:** Title: Governance and Compliance Assessment
Description: Evaluates decision authority and legal exposure.
Details: Without defined rights, routine decisions can slip 2-4 weeks each (estimate). GDPR and UK DPA transfer limits may force federated storage with masters held in-country. Mitigation: privacy panel with decision log, PIA per agreement, tiered consent. Legal budget of $1M-$2M (estimate). Funder terms such as training-data access must be barred if they breach source agreements.

## Question 5 - What fire, hazmat and handling-loss controls and insurance terms will host insurers and fire authorities require for ovens, humidity chambers and generators?

**Assumptions:** Assumption: One pilot site obtains written insurer and fire-authority approval by Month 6 (2027-04-12), using a detached or certified-suppressed pre-treatment design, plus a pooled loss reserve of $2M-$5M (estimate). Rationale: on-site processing removes shipping risk but not handling risk.

**Assessments:** Title: Safety and Risk Assessment
Description: Reviews thermal, chemical and item-loss exposure.
Details: A single incident could terminate partnerships network-wide. Site approvals may add 4-8 weeks each (estimate). Controls: containment standard, VOC air monitoring, hazmat audit of 20-30 machines, incident protocol with 24-hour insurer notice, tiered indemnity. Detached pods reduce blast radius but raise footprint and permitting.

## Question 6 - What environmental requirements apply to generator emissions, VOC and fume discharge, e-waste classification, and unstable power or climate at host sites?

**Assumptions:** Assumption: Each site receives a power and climate audit before arrival, units use facility power first with generator backup, and ovens vent through filtered, monitored exhaust. Rationale: host sites vary widely in grid quality and humidity.

**Assessments:** Title: Environmental Impact Assessment
Description: Covers emissions, waste and site-condition effects.
Details: Generator fuel could cost $500-$1,000 per day at unstable sites (estimate). Vintage equipment may contain asbestos, lead or PCBs, and cross-border shipment may trigger e-waste rules. Mitigation: hybrid solar-battery where feasible, hazmat protocol, functional-equipment documentation, end-of-life disposal plan. Benefit: compliance protects archive relationships.

## Question 7 - Which archives, funders, regulators and heritage bodies must commit, and how will under-resourced archives be reached?

**Assumptions:** Assumption: Three pilot archives sign multi-year agreements by Month 6 (2027-04-12), with a waitlist of backup sites and tiered host in-kind contributions. Rationale: site withdrawal mid-residency strands units and orphans collections.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluates trust, commitments and equity of access.
Details: Archive trust is existential; one privacy or loss incident can cascade. Tiered scheduling may favour well-resourced hosts over the most endangered collections. Mitigation: stakeholder workshop by Month 4 (2027-02-12), transparent prioritisation rules, 2-3 year host commitments, published recovery results. Technology-sector funding needs non-exclusive, rights-holder-approved terms.

## Question 8 - What operational systems will run scheduling, telemetry, parts tracking, AI validation, storage custody and the post-Month 120 (2036-10-12) end-state?

**Assumptions:** Assumption: A central operations room with sensors, parts-inventory dashboard, validated AI models and two verified copies of each master is operational by Month 12 (2027-10-12), with an end-state plan by Month 36 (2029-10-12). Rationale: uptime of >90% (user constraint) needs measured reliability data.

**Assessments:** Title: Operational Systems Assessment
Description: Reviews fleet management, data and sustainment.
Details: Parts-depletion modelling is absent; uptime below 90% by Months 36-48 (2029-10-12 to 2030-10-12) is plausible (estimate). Needs telemetry, canary batches of 10-20 items per site, drift thresholds, and a 4-week review backlog buffer. Custody of 200+ PB (user constraint) creates perpetual storage costs beyond Month 120 (2036-10-12); fund migration and decide unit transfer or retained core early.