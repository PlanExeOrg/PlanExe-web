## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers cluster around the project's core tensions: speed versus risk (Pilot Proof Gates, Triage), cost versus control (Funding, Crew Composition, Review Gate), and feasibility versus hardware scarcity (Vintage Transport, Fleet Command). Legal reach (Border-Crossing, Liability, Custody) forms the second tier. Missing dimensions: explicit AI model validation and a dedicated schedule or throughput capacity lever tied to real-time playback limits.

### Decision 1: Vintage Transport Sustainment Strategy
**Lever ID:** `68f53e86-428b-43e0-881b-56b4dd4825b8`

**The Core Decision:** Determines whether the playback hardware, which is the program's real throughput constraint, remains serviceable for roughly a decade. It covers spares sourcing, head and transport repair capability, and the retention of retired-engineer expertise. Key metrics are parts-depletion rate, mean time between failures per line, uptime against the plan's >90% target, and playback fidelity accepted by archivists. A modeled spares curve is essential.

**Why It Matters:** Governs whether obsolete decks and scanners can keep running for a decade of continuous use. Cannibalizing a stockpile is cheap to start but depletes finite spares, and expertise held by retired engineers is a perishable asset. Building new transports addresses scarcity but adds engineering risk and may lose the playback characteristics archivists trust.

**Strategic Choices:**

1. Buy and cannibalize a large inventory of decommissioned decks and scanners, sustained by retired-engineer mentoring, 3D-printed parts, and an embedded maintenance engineer in each unit.
2. Fund development of new-build, open-specification transports and heads that replicate vintage playback behavior, using the legacy stockpile only as reference units and short-term spares.
3. Contract existing specialist digitization vendors and conservation labs to operate and repair the machines inside the containers, in return for guaranteed multi-year throughput volume rather than ownership of the equipment base.

**Trade-Off / Risk:** A finite stockpile of aging machines is consumed by the very work it enables, so the plan's uptime target is only credible if the parts-depletion curve is modeled rather than assumed away.

**Strategic Connections:**

**Synergy:** Strengthens Recovery Assurance and Independent Verification Regime by keeping playback characteristics stable and documented, and supports Fleet Sunset and Equipment Afterlife Design by defining what remains of the equipment base at end of life.

**Conflict:** Competes with Fleet Command and Remote Diagnostics Layer and Crew Composition and Review Labor Model for scarce specialist engineers; a new-build or vendor-contracted route also raises capital and shifts control away from Funding and Ownership Architecture assumptions.

**Justification:** *Critical*, Playback hardware is the real throughput constraint and a finite, depleting asset. Connects to Fleet Command, Crew Composition, Recovery Assurance, Sunset, and Funding. Controls the core feasibility of the >90% uptime target over a decade.

### Decision 2: Rights, Privacy, and Review Gate Design
**Lever ID:** `cdae2cdf-d555-4314-9782-27d873a39732`

**The Core Decision:** Fixes where legal, privacy and classification judgement sits in the pipeline and who bears it. The design governs reviewer headcount, upload latency, the wording of source agreements, and the incident exposure carried by the program. Metrics include flagged-content rate, reviewer hours per content hour, false-negative rate on sensitive items, and zero reportable incidents. Pilot data should replace the assumed 80% review reduction.

**Why It Matters:** Defines when legal and privacy judgement happens relative to ingest, and so how large the human review bottleneck becomes. A pre-upload gate protects against incidents but makes reviewer headcount scale with content hours. Deferring review shifts workload to access time and changes what a source agreement must promise.

**Strategic Choices:**

1. Gate every item behind AI pre-screening and human review of flagged content before archival upload, with reviewers embedded in each unit as the plan describes.
2. Ingest everything into a restricted dark tier, hold it under embargo with no access, and run rights and privacy review only when a researcher requests an item or an embargo lapses.
3. Delegate review to the source archive's own legal and curatorial staff using a shared flagging tool and jurisdiction-specific rule sets, with program staff limited to quality control of the digitization itself.

**Trade-Off / Risk:** AI pre-screening for copyright, personal data, and classification markers on degraded, multilingual, pre-digital content has no demonstrated accuracy yet, so the claimed review reduction is a hypothesis the pilot must test, not a planning input.

**Strategic Connections:**

**Synergy:** Pairs with Custody, Format, and Access Regime for Recovered Data, since access tiers and embargoes enforce whatever the gate decides, and with Border-Crossing and Data-Jurisdiction Pathway, which supplies jurisdiction-specific rule sets.

**Conflict:** A strict pre-upload gate drives headcount and conflicts with Crew Composition and Review Labor Model cost limits; deferred or delegated review reduces staffing but loosens assurance sought by Liability and Loss-Indemnity Structure.

**Justification:** *Critical*, Determines the human review bottleneck, reviewer headcount, upload latency, and incident exposure. Hub linking Crew Composition, Custody and Access, Border-Crossing, Liability, and Funding. The assumed 80% review reduction is untested, so this choice drives cost and legal risk.

### Decision 3: Crew Composition and Review Labor Model
**Lever ID:** `4220610f-e633-48dd-96e1-39a7ac2e7831`

**The Core Decision:** Defines who staffs each unit, from engineers and operators to reviewers, and where review work physically occurs. It drives payroll, travel and visa burden, ramp-up speed at each new site, and the capability left with host archives. Success is measured by loaded cost per unit-year, time to productive operation after arrival, quality consistency across sites, and staff retention. Recomputed: 50-60 staff at $2-3M annual opex implies thin per-head budgets.

**Why It Matters:** Decides how the staffing burden per unit is met and how portable the operation is across countries. A large resident crew per unit gives control but multiplies headcount and travel costs. Local cross-training lowers cost and builds archive capability but varies in quality and slows ramp-up.

**Strategic Choices:**

1. Deploy a dedicated resident crew of engineers, operators, and reviewers with each unit, rotating whole teams between sites to keep process quality consistent across the fleet.
2. Embed a small technical core per unit and train the host archive's own staff to run intake, sorting, and review, leaving a skilled local team behind when the container departs.
3. Centralize review and quality control in a few remote operations hubs that receive proxy files from all units under strict access controls, leaving only mechanical and transfer operators on site.

**Trade-Off / Risk:** A resident crew of 50-60 people per unit across 30 units implies a workforce of over a thousand, and the plan's budget lines may not reconcile with that headcount (recomputed from stated figures).

**Strategic Connections:**

**Synergy:** Works with Rights, Privacy, and Review Gate Design when reviewers are embedded or centralised under one workflow, and with Vintage Transport Sustainment Strategy by anchoring maintenance skills in the unit crew.

**Conflict:** Large resident crews strain the operating budget in Funding and Ownership Architecture, while host-staff or remote-hub models complicate Border-Crossing and Data-Jurisdiction Pathway through local labor rules and cross-border proxy file transfers.

**Justification:** *Critical*, Largest operating-cost driver, with a resident-crew headcount that may not reconcile with the budget. Interacts with review gate, vintage maintenance, Fleet Command, Restoration, and jurisdiction rules. Controls the cost-versus-control trade-off and ramp-up speed at each site.

### Decision 4: Funding and Ownership Architecture
**Lever ID:** `145bde02-01a2-4876-9993-fa02ed223a1d`

**The Core Decision:** Establishes who finances the fleet, who legally holds units and recovered data, and what strings accompany each funding source. It shapes cash-flow timing against the phase budgets, host contribution rules, and the program's public-interest standing. Metrics include committed versus pledged funds, share of cost covered by hosts, funding continuity across annual cycles, and absence of exclusivity terms that undermine archive trust.

**Why It Matters:** Determines who pays, who holds the recovered data, and what obligations accompany the money. Public and philanthropic funding aligns with the preservation mission but moves slowly and in annual cycles. Technology-sector funding can speed deployment but creates pressure around training-data access and exclusivity that archives and rights holders may reject.

**Strategic Choices:**

1. Assemble a consortium of national archives and cultural foundations that jointly own the fleet and the data, with cost-sharing contributions from each host institution tied to its residency.
2. Operate the fleet as a non-profit service bureau that charges host institutions per-item or per-collection fees, with grants subsidizing under-resourced archives and unit utilization driving revenue.
3. Sell time-limited, non-exclusive research access to recovered corpora to technology companies on terms approved by rights holders, using that revenue to cross-subsidize digitization for archives that cannot pay.

**Trade-Off / Risk:** The plan lists funders without a binding commitment mechanism, and any revenue route involving AI training access risks breaching source agreements or eroding the archive trust on which on-site residencies depend.

**Strategic Connections:**

**Synergy:** Enables Pilot Proof Gates and Scale-Up Cadence by tying tranches of money to demonstrated results, and underpins Fleet Sunset and Equipment Afterlife Design by clarifying who owns the units and data when operations end.

**Conflict:** Technology-sector revenue models conflict with Rights, Privacy, and Review Gate Design and Custody, Format, and Access Regime for Recovered Data, since training-data access pressures can breach source agreements and archive trust.

**Justification:** *Critical*, Central hub: appears in conflicts and synergies of nearly every other lever. Decides who pays, who owns units and data, and whether funder terms (e.g. training-data access) erode archive trust. Foundational to phased cash flow and mission integrity.

### Decision 5: Pilot Proof Gates and Scale-Up Cadence
**Lever ID:** `6f0ad5c5-2bc2-42a8-8375-5673b9b87314`

**The Core Decision:** Governs when the programme earns permission to grow from 3 pilot units to 15 and then 30, and how much unproven design is copied in the meantime. It defines gate evidence, minimum duration, number of host sites and who adjudicates. Key metrics: pilot defect rate carried into Phase 2 builds, calendar months consumed per gate, rework cost after replication, and funder confidence at each release.

**Why It Matters:** The plan moves from 3 pilot units to 15 and then 30, with money released in phases. The gate criteria define how much design risk is replicated across the fleet before it is discovered. Strict gates protect the budget but spend calendar time while media keeps degrading; loose gates risk copying a flawed container design many times over.

**Strategic Choices:**

1. Release Phase 2 funding only after all three pilot lines hold the plan's published success thresholds for a sustained period across more than one host site.
2. Overlap scale-up with the pilots by ordering long-lead containers, robotics and power systems for the next units while pilots run, accepting rework risk in exchange for calendar time.
3. Deliberately send the first unit to the worst-condition collection available, exposing failure modes under stress before clean-collection results set expectations and funder confidence.

**Trade-Off / Risk:** The adversarial pilot yields the most honest failure data, but its poor early metrics may trigger funder doubt just when the plan needs Phase 2 commitments, so gate criteria must be agreed in advance.

**Strategic Connections:**

**Synergy:** Works with Recovery Assurance and Independent Verification Regime, which supplies credible pass/fail evidence for gates, and with Fleet Command and Remote Diagnostics Layer, whose telemetry yields the uptime data gates depend on.

**Conflict:** Conflicts with Triage Doctrine for At-Risk Collections, since strict gates delay capacity while media degrades, and with Funding and Ownership Architecture, where phased releases tied to gates complicate committed multi-year funder pledges.

**Justification:** *Critical*, Controls the speed-versus-risk trade-off of replicating 3 pilots into 15 and then 30 units. Hub receiving evidence from Verification and Fleet Command and tied to Funding tranches. Prevents copying flawed design across the fleet.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Triage Doctrine for At-Risk Collections
**Lever ID:** `bb399094-c1a5-4fc9-b605-591eb5b2b795`

**The Core Decision:** Sets the queue logic for every unit residency: which sites receive a container, in what order, and how much of each collection is processed. Its scope covers condition scoring, format-vulnerability ranking and deferral rules. Success is measured by value rescued per unit-month, share of at-risk items captured before failure, and idle time between residencies. It also determines how defensible site selection is to funders and partner archives.

**Why It Matters:** Sets which items are digitized first and therefore how much cultural value is rescued before degradation outpaces the fleet. Condition-driven triage can save the most endangered media but may deprioritize high-value holdings that are still stable. Archive-driven priorities ease partnership but fragment the queue across formats and sites.

**Strategic Choices:**

1. Rank every collection by measured physical condition and known format vulnerability, then route units to the sites with the fastest-decaying media first regardless of subject matter.
2. Let partner archives and scholarly panels nominate collections by research, historical, and cultural importance, scheduling unit residencies to fit that ranked list.
3. Run a rapid condition-and-content survey of each site with a lightweight inspection team before committing a container, sampling holdings to decide whether full digitization, selective digitization, or deferral is justified.

**Trade-Off / Risk:** Triage choices decide whether the program rescues the most endangered media or the most valued media, and a survey stage adds lead time that real-time playback and degradation timelines may not tolerate.

**Strategic Connections:**

**Synergy:** Feeds Pilot Proof Gates and Scale-Up Cadence with a defined first-site list and rescue metric, and lets Host-Site Power, Security, and Readiness Compact prioritise readiness work for sites already ranked first.

**Conflict:** Condition-first ordering can clash with Funding and Ownership Architecture when funders or hosts expect their own collections early, and a survey stage delays Fleet Command and Remote Diagnostics Layer utilisation targets.

**Justification:** *High*, Sets queue logic for every residency and so the value rescued per unit-month. Feeds Pilot Proof Gates and Host-Site Readiness, but conflicts with Funding, Host-Site, and Hazard levers over who goes first. Governs the rescue-versus-partnership trade-off.

### Decision 7: Custody, Format, and Access Regime for Recovered Data
**Lever ID:** `72d631ec-4c4f-4369-96d0-1543ca9e2ce8`

**The Core Decision:** Defines where recovered masters live, in which open preservation formats, how many verified copies exist, and who may reach them, effectively the program's exit strategy. Success metrics include the share of masters with two verified, geographically separate copies, fixity-check pass rate, funded format-migration plans extending beyond Month 120 (2036-10-12), and partner access satisfaction. It also decides who pays for perpetual storage once the units are retired.

**Why It Matters:** Sets where the digitized output lives, in what formats, and who can reach it, which determines whether the work outlives the program. Central hosting simplifies fleet operations but concentrates risk and raises sovereignty objections. Archive-held copies respect custody but demand sustained storage commitments from partners with limited budgets.

**Strategic Choices:**

1. Upload all output to a single program-managed central repository in open preservation formats, with partner archives receiving access copies and metadata exports.
2. Leave the master copy with each host archive on certified storage supplied by the program, and replicate only a verified secondary copy to a federated network of national repositories.
3. Keep the on-board 500TB storage as a short-term buffer only, then write preservation masters to durable offline media for deposit with each archive, using the network upload for access derivatives.

**Trade-Off / Risk:** Treating transmitted data as preserved ignores that 200 petabytes of masters create their own long-term storage, migration, and funding obligations that outlast the 10-year program and the units themselves.

**Strategic Connections:**

**Synergy:** Amplifies Border-Crossing and Data-Jurisdiction Pathway, because choosing archive-held or federated masters settles where data legally resides, and enables Funding and Ownership Architecture by clarifying which party must finance perpetual storage and migration.

**Conflict:** Trades off against Restoration Intervention Ceiling, since retaining raw wideband captures inflates storage and egress under any custody model, and against Rights, Privacy, and Review Gate Design, since broader access widens the restricted-content review burden.

**Justification:** *High*, Defines where masters live and who pays for perpetual storage, which is the program's exit strategy. Connects to jurisdiction, review gate, restoration ceiling, and funding. Governs the storage-cost versus sovereignty and access trade-off.

### Decision 8: Restoration Intervention Ceiling
**Lever ID:** `6dfc5e1b-c234-4331-ac82-b393ff2db906`

**The Core Decision:** Draws the line between faithful capture and AI-enhanced output, fixing what is written as the preservation master and how reversible it stays. Success metrics include the share of items retaining raw captures, completeness of model-provenance records for each restoration layer, measured storage multiplier per item, and defensibility of the record to historians and legal users when later models disagree with earlier ones.

**Why It Matters:** This sets how far AI signal reconstruction may alter what the heads, scanners and readers capture before anything is written to the archive. A low ceiling keeps the record defensible and re-processable as models improve, but leaves noise and dropouts that users will see. A high ceiling produces cleaner outputs quickly, but bakes in model artifacts that cannot be undone once the source media degrades further.

**Strategic Choices:**

1. Capture and store only preservation-grade raw transfers on site, and defer every AI enhancement to separate derivative copies produced later outside the container.
2. Run AI cleanup inline inside each container and store only the restored output, minimizing storage per item and review effort at the cost of irreversibility.
3. Retain the wideband head signal or unprocessed scan alongside versioned, reversible restoration layers with model provenance, so future decoders can re-derive better results from the same capture.

**Trade-Off / Risk:** Keeping raw wideband captures multiplies storage and egress demand on a plan already stressed at petabyte scale, while inline-only restoration saves bytes but forfeits the ability to correct tomorrow's model errors.

**Strategic Connections:**

**Synergy:** Amplifies Recovery Assurance and Independent Verification Regime, because retained raw captures and versioned layers let auditors compare restored output against the source, and informs Custody, Format, and Access Regime by defining which masters must be preserved.

**Conflict:** Conflicts with Custody, Format, and Access Regime, since keeping raw wideband data multiplies storage and egress demand, and with Crew Composition and Review Labor Model, since layered outputs add reviewer and engineer workload.

**Justification:** *Medium*, Sets reversibility of AI restoration and the storage multiplier per item. Important for record defensibility, but its effects are largely absorbed through Custody and Crew levers rather than being an independent hub.

### Decision 9: Pre-Treatment Hazard and Fire Containment Design
**Lever ID:** `d1e84e50-9bbc-492c-b5d4-367ed666e9ed`

**The Core Decision:** Specifies how baking ovens, humidity chambers, and unstable film are physically isolated and suppressed so host insurers and fire authorities will approve a unit on site. Success metrics include time from site proposal to fire-authority and insurer sign-off, zero thermal or chemical incidents, the share of intake items refused or deferred for hazard, and added footprint and power per site.

**Why It Matters:** Baking ovens, humidity chambers, and chemically decaying film bring heat, solvent vapors, and combustibility into a shipping container parked beside a host's building. The containment design determines whether the host's insurer and fire authority will accept the unit on its premises at all. A stricter design adds cost and floor space, while a lax one risks a single incident that halts the whole network.

**Strategic Choices:**

1. Integrate pre-treatment inside the main container with standard fire suppression, ventilation, and an intake condition screen that rejects the most hazardous items.
2. Place ovens and film stabilization in a separate detached pre-treatment pod positioned away from the host building, so a thermal or chemical event cannot reach the digitization line.
3. Introduce a condition-grading gate at intake that routes hazardous or highly unstable media to the host's own cold storage and defers them until specialist handling can be arranged on site.

**Trade-Off / Risk:** A detached pod reduces blast radius but doubles the footprint, power, and permitting each host must approve, which can slow site acceptance more than the incident risk it removes.

**Strategic Connections:**

**Synergy:** Enables Liability and Loss-Indemnity Structure, since documented containment supports insurable terms and indemnity limits, and reinforces Host-Site Power, Security, and Readiness Compact by giving hosts a clear safety standard to accept.

**Conflict:** Trades off against Pilot Proof Gates and Scale-Up Cadence, since detached pods add permitting and footprint that slow site acceptance, and against Triage Doctrine for At-Risk Collections, since rejecting hazardous items may exclude the most endangered media.

**Justification:** *Medium*, Gates host insurer and fire-authority acceptance and could halt the network after one incident. Primarily a design and compliance matter with limited reach beyond Liability, Host-Site, and Triage levers.

### Decision 10: Host-Site Power, Security, and Readiness Compact
**Lever ID:** `852dbca5-ed3e-48c4-86fd-6d039bb20341`

**The Core Decision:** Sets the baseline conditions a host must supply versus what each unit carries, governing site eligibility, uptime, and logistics burden. Success metrics include unit utilization rate, days lost to power or access failures, setup time per arrival, and the share of deployments reaching under-resourced archives. It is the main mechanism for balancing productivity against equitable reach across the network.

**Why It Matters:** Each unit is only productive if the host supplies stable power, a level hardstand, physical security, and a trained liaison. Setting these prerequisites high protects uptime but narrows the pool of eligible archives to better-resourced institutions. Making units self-sufficient widens the pool but raises per-unit cost and shifts logistics burden onto the network.

**Strategic Choices:**

1. Require hosts to meet written prerequisites for power, hardstand, perimeter security, and staff liaison before a unit is scheduled, and defer sites that fall short.
2. Equip every unit to be self-sufficient with its own generation, battery buffering, and security monitoring so any site with road access qualifies regardless of infrastructure.
3. Offer a tiered compact in which hosts earn earlier scheduling by contributing in-kind power, space, and staff time, with remaining gaps covered by the network.

**Trade-Off / Risk:** Tiered scheduling rewards well-resourced institutions with earlier access, which may steer scarce capacity away from the smaller, poorer archives whose collections are most likely to be lost first.

**Strategic Connections:**

**Synergy:** Amplifies Fleet Command and Remote Diagnostics Layer, since stable power and security monitoring yield reliable telemetry, and supports Pilot Proof Gates and Scale-Up Cadence by making site readiness a measurable scheduling criterion.

**Conflict:** Conflicts with Triage Doctrine for At-Risk Collections, since readiness prerequisites steer scheduling toward better-resourced hosts rather than the most endangered collections, and with Funding and Ownership Architecture, since self-sufficient units raise per-unit cost.

**Justification:** *Medium*, Balances unit uptime against equitable site reach and per-unit cost. Supports Fleet Command and scheduling, but is operational optimization that is subordinate to Triage and Funding choices.

### Decision 11: Recovery Assurance and Independent Verification Regime
**Lever ID:** `0252851b-f01b-4c49-891d-94f1214333a3`

**The Core Decision:** Defines how recovery claims are measured, by whom, and against which standard definitions of success, before dozens of units begin reporting. Success metrics include audit sampling coverage, inter-unit variance on calibrated reference media, published failure rates, and donor and archive confidence in reported figures. It converts the plan's headline targets into evidence that can be compared across sites and years.

**Why It Matters:** The plan's targets, such as successful digitization, reconstruction accuracy, and metadata accuracy, are only meaningful if measured consistently across dozens of units and sites. Self-reporting is cheap but invites optimistic definitions, while independent verification costs money and slows delivery. The regime chosen also determines whether donors and archives can trust claims of what was actually recovered.

**Strategic Choices:**

1. Rely on internal quality dashboards that each unit reports centrally against the plan's published targets, with periodic management review.
2. Contract independent auditors to sample recovered items against originals at each site and publish findings, accepting added cost and some schedule friction.
3. Circulate a shared reference set of calibrated test media among all units and partner labs, so cross-unit drift and equipment-specific bias is detected by comparison.

**Trade-Off / Risk:** A circulating reference set catches systematic drift between units, but it cannot reveal item-level failures on real collections, so it complements rather than replaces independent sampling against the actual originals.

**Strategic Connections:**

**Synergy:** Amplifies Pilot Proof Gates and Scale-Up Cadence, since independent evidence makes gate decisions credible, and strengthens Funding and Ownership Architecture because verified recovery results sustain donor and government-archive confidence.

**Conflict:** Trades off against Pilot Proof Gates and Scale-Up Cadence through added audit schedule friction, and against Crew Composition and Review Labor Model, since sampling and reference-media runs consume scarce unit time and staff capacity.

**Justification:** *Medium*, Makes plan targets credible and supplies evidence to gates and donors. Valuable but largely serves Pilot Proof Gates and Funding, so it is a supporting mechanism rather than a foundational pillar.

### Decision 12: Border-Crossing and Data-Jurisdiction Pathway
**Lever ID:** `f1e07af6-c492-4a8e-b4ce-89a1bfcc2a3b`

**The Core Decision:** Sets the legal and logistical route by which containers, vintage equipment, consumables and recovered data cross borders. Scope covers temporary-import regimes, customs inspection of obsolete electronics and baking or humidity consumables, heritage-export rules, and data-residency terms. Key metrics: countries reachable by Month 24 (2028-10-12), average transit idle days per relocation, share of units blocked by customs holds, and proportion of recovered data lawfully replicated to the central archive.

**Why It Matters:** The plan assumes containers move freely between archives worldwide, yet each border crossing brings temporary-import rules, inspection of vintage equipment and consumables, and local rules on exporting heritage data. The pathway chosen decides how many countries are reachable in the first years and how long units sit idle in transit. Downstream, jurisdiction rules also decide where recovered data may be stored and replicated.

**Strategic Choices:**

1. Concentrate the first 15 units inside a few regional customs and legal blocs with mutual recognition, deferring intercontinental moves until temporary-admission paperwork has been proven on short hops.
2. Pre-negotiate temporary-admission and data-residency terms through a single heritage-body-sponsored framework agreement before any unit crosses an ocean, accepting a slower start for smoother later moves.
3. Establish regional legal entities that own and register containers locally, so units are built or domiciled in each region and only engineers, software and parts kits cross borders.

**Trade-Off / Risk:** Regional domiciling avoids customs delays but multiplies legal entities, vintage-equipment duplication and parts stocks, while a single framework agreement depends on governments moving faster than heritage diplomacy usually allows.

**Strategic Connections:**

**Synergy:** Amplifies Custody, Format, and Access Regime for Recovered Data by fixing where data may legally reside, and supports Pilot Proof Gates and Scale-Up Cadence by allowing relocations to be sequenced through proven corridors.

**Conflict:** Trades off against Funding and Ownership Architecture, since regional domiciling multiplies entities and asset ownership structures, and against Fleet Sunset and Equipment Afterlife Design, because locally registered units complicate later transfer or pooled rental.

**Justification:** *High*, Determines how many countries are reachable early and where data may legally reside. Ties to Custody, Funding structure, Sunset, and review rules. Controls the worldwide-mobility assumption that the plan treats as given.

### Decision 13: Liability and Loss-Indemnity Structure
**Lever ID:** `b4859973-1ed2-440b-a69a-90fa810e9e35`

**The Core Decision:** Determines who bears the cost when handling, baking or playback destroys a unique item, and therefore which archives will sign source agreements. Scope spans insurance purchasing, condition-tiered consent, waivers and any self-insured reserve. Key metrics: median time from first approach to signed agreement, share of target archives accepting the schedule, premium trend per incident, and size of unfunded contingent liability carried by funders.

**Why It Matters:** Eliminating shipping risk does not remove handling risk: baking, tensioning and playing unique media on 50-year-old decks can destroy an item, and archives will ask who pays. How loss is allocated determines how quickly source agreements are signed and which archives will participate at all. Broad indemnity makes the programme attractive but concentrates contingent liability on funders.

**Strategic Choices:**

1. Purchase a programme-wide professional liability and media-in-care policy and offer every partner archive the same indemnity schedule, standardizing contracts at the price of premiums that rise with each incident.
2. Tier consent by item condition, so partners sign a documented attempt-at-own-risk waiver for items judged beyond safe handling and receive full indemnity only for stable material.
3. Create a pooled self-insurance reserve funded by partner contributions and funder set-asides to cover unique-item loss in categories that commercial insurers decline to underwrite.

**Trade-Off / Risk:** A pooled reserve sidesteps insurers' refusals but exposes funders to an uncapped first loss, while waivers speed contracts yet risk alienating exactly the archives holding the most fragile, highest-value collections.

**Strategic Connections:**

**Synergy:** Enables Triage Doctrine for At-Risk Collections by giving archives a defined basis for releasing fragile items, and strengthens Rights, Privacy, and Review Gate Design by bundling indemnity into standardized source agreements.

**Conflict:** Constrains Restoration Intervention Ceiling, because broader indemnity makes aggressive interventions costly, and pulls against Funding and Ownership Architecture, since pooled reserves and premiums draw on funder money that could otherwise buy units.

**Justification:** *High*, Decides whether archives sign source agreements at all, since handling risk replaces shipping risk. Enables Triage, bundles with the review gate, and competes with Funding for money. Governs contingent liability carried by funders.

### Decision 14: Fleet Command and Remote Diagnostics Layer
**Lever ID:** `6920a764-81fd-408d-a2b7-52e280f223fb`

**The Core Decision:** Defines the central nervous system for a geographically scattered fleet: sensors, remote expert guidance, scheduling and fallback behaviour when links fail. It decides whether one on-site maintenance engineer per container can sustain the >90% uptime target (user constraint). Key metrics: mean time to repair, unplanned downtime hours per unit, central support staffing ratio, and expert-hours delivered per retired engineer.

**Why It Matters:** With units spread across continents and one maintenance engineer per container, the central support team decides whether the plan's uptime target is reachable. Telemetry, remote guidance and fleet scheduling can stretch a thin pool of scarce vintage expertise further, but they create a dependency on connectivity and a central team that itself must be staffed and funded.

**Strategic Choices:**

1. Instrument every deck and scanner with tension, vibration, temperature and error-rate sensors feeding a central operations room that schedules maintenance before failures occur.
2. Equip each unit with live video and shared-view tooling so a small pool of senior retired engineers can guide on-site technicians remotely, spreading their expertise across the whole fleet.
3. Operate each unit in autonomous-first mode with local diagnostic playbooks and batched status reports, so sites with weak satellite or fiber links are not dependent on live central support.

**Trade-Off / Risk:** Remote guidance multiplies the reach of a few senior engineers, but it concentrates single points of failure in the very people the plan says are aging out, and cannot replace hands on a seized transport.

**Strategic Connections:**

**Synergy:** Amplifies Vintage Transport Sustainment Strategy by stretching scarce deck expertise and focusing parts use, and feeds Pilot Proof Gates and Scale-Up Cadence with objective reliability evidence before replication.

**Conflict:** Depends on connectivity assured by Host-Site Power, Security, and Readiness Compact and strains Crew Composition and Review Labor Model, as central operations staff add cost and compete for the same scarce engineers.

**Justification:** *High*, Determines whether one on-site engineer per container can sustain uptime by stretching scarce expertise. Amplifies Vintage Transport, feeds Pilot Gates telemetry, and depends on Host-Site connectivity. A key multiplier, though dependent on upstream levers.

### Decision 15: Fleet Sunset and Equipment Afterlife Design
**Lever ID:** `01a4d967-9fa4-4eb7-bb2f-ade462d07b54`

**The Core Decision:** Decides what survives after the 10-year programme: transferred units, a retained core, or a rentable equipment pool, together with parts stock, manuals and the knowledge base. Because working vintage decks stay scarce and orphaned media persist, the end-state sets whether capability endures. Key metrics: units still operational at Month 120 (2036-10-12), post-programme funding secured, collections recovered after close, and parts and documentation completeness at handover.

**Why It Matters:** The 10-year plan ends with up to 30 units, a parts warehouse and a knowledge base, but does not say what remains. Working vintage decks will still be scarce afterward and unrecovered media will persist, so the end-state decides whether the capability endures. Keeping capacity alive costs money after funding ends, while dispersal returns value but loses coherence.

**Strategic Choices:**

1. Plan a funded wind-down in which units are loaned or transferred to national archives and universities together with parts stock and manuals, converting the fleet into permanent regional capacity.
2. Retain a core of units and the central parts warehouse under a standing body with a dedicated endowment, so newly identified collections can still be recovered after the main programme closes.
3. Convert the retired fleet into a licensed equipment pool rented to commercial transfer houses and researchers, with rental income financing a long-tail recovery fund for orphaned collections.

**Trade-Off / Risk:** Defining the end-state early shapes equipment choices and contracts now, yet a standing body or rental pool may drift from the public-interest mission once the original funders step back.

**Strategic Connections:**

**Synergy:** Reinforces Vintage Transport Sustainment Strategy by giving parts inventory and training a lasting destination, and complements Custody, Format, and Access Regime for Recovered Data by planning durable stewardship of outputs alongside equipment.

**Conflict:** Competes with Funding and Ownership Architecture, because endowments or wind-down budgets divert money from build and operations, and with Border-Crossing and Data-Jurisdiction Pathway, where cross-border transfers of aged equipment face export and ownership constraints.

**Justification:** *Low*, Addresses the end-state beyond the 10-year horizon and is mostly dependent on Funding, Vintage Transport, and Custody decisions. Can be settled later without constraining near-term delivery.
