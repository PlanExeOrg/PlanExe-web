
## Question 1 - What is the specific breakdown of the €200M budget allocation across the major contract lots (Sensor/Algorithm A/B/C, Integration/Edge/Network, IV&V) to inform risk management for the Phase 1 (€50M) vs. Phase 2 (€150M) expenditures?

**Assumptions:** Assumption: The budget distribution aligns with the strategic decision to defer complex sensor fusion (RF/Acoustic - Team C) until Phase 2. Therefore, Phase 1 (€50M) will be allocated 70% to A/B sensor integration and calibration tooling, 20% to Integration/Edge fixed costs for pilot sites (CPH/AAL), and 10% to essential PDR/CDR IV&V activities.

**Assessments:** Title: Financial Allocation Risk Assessment
Description: Evaluation of budget distribution alignment with the phased delivery strategy.
Details: If 70% of Phase 1 is committed to Teams A/B integration, the primary financial risk shifts to component procurement lead times for high-end PTZ/Thermal units. Opportunity exists to pre-negotiate bulk pricing for Team C sensors during Phase 1 planning, leveraging the M+4 PDR gate to lock in better Phase 2 pricing, mitigating Risk 3 (Financial).

## Question 2 - Given the fixed gap between CDR (M+10) and Pilot Acceptance (M+18), what specific software version and KPI verification dataset mapping (EUROCONTROL/ASTERIX vs. internal EDXP) is mandated for the M+18 demonstration?

**Assumptions:** Assumption: Based on the 'Builder' strategic choice, the M+18 Pilot Acceptance will only require the core tracking KPIs (Pd, 3D Accuracy, Latency) verified against the internal EDXP v0.9 format, with compliance to a *simulated* ASTERIX schema only, deferring full NATO/STANAG mapping verification until the FOC (M+24) milestone.

**Assessments:** Title: Timeline Constraint Compliance Assessment
Description: Assessment of deliverable scope required for the 8-month window between CDR and Pilot Acceptance.
Details: Deferring full standard certification to FOC significantly de-risks the M+18 gate (reducing Risk 1: Regulatory delay impact). However, latency KPI validation must immediately focus on the edge-to-bus component (≤200ms), as this is intrinsically linked to tracking performance, not the eventual export format conversion latency.

## Question 3 - Which specific personnel roles (e.g., Geodesy Lead, Cyber Assurance Engineer, Sensor Fusion Architect) are required during Q4-2025 mobilization to ensure the PTP synchronization (≤1 ms error) and initial DLT geometry setup (≥6 control points) are achieved before the M+4 PDR gate?

**Assumptions:** Assumption: To meet the PTP/GPSDO synchronization target and initial geometry setup pre-PDR, mobilization in Q4-2025 must immediately secure one dedicated Senior Geodesy Engineer and one Network Synchronization Specialist to begin site surveying and PTP grandmaster procurement/installation alongside the initial procurement RFPs.

**Assessments:** Title: Resources and Personnel Readiness Assessment
Description: Evaluation of resource staffing critical for foundational engineering compliance.
Details: Failing to staff the Geodesy role immediately directly threatens the 3D accuracy KPI (Risk 2: Technical). Opportunity exists to cross-train existing infrastructure staff in IEEE-1588 maintenance to reduce Reliance on external RTK flight crews required in Decision 2, mitigating scheduling dependency risks.

## Question 4 - What is the formal process for obtaining EASA waiver/approval for the initial deployment of PTZ clusters at 30–40m height, and which national aviation authority at CPH/AAL holds primary jurisdiction for the MVFR/poor weather performance acceptance testing?

**Assumptions:** Assumption: EASA regulation requires an initial Type Certificate deviation or operational waiver for non-standard sensor heights (30–40m). Jurisdiction for operational testing at CPH defaults to Danish CAA (for CPH) and Hungarian CAA (for AAL), overseen by the EASA Steering Committee for consistency.

**Assessments:** Title: Governance and Regulatory Compliance Assessment
Description: Analysis of regulatory entry barriers for physical installation and operational certification.
Details: Risk 1 (Regulatory Delay) is high due to non-standard sensor mounting heights and the need for two distinct national CAAs for Phase 1 sign-off. Mitigation requires creating a unified 'SkyNet Sentinel Operational Compliance Document' referenced by both CAAs, centralized through the EASA Steering Committee before M+4.

## Question 5 - Detail the 'weekly drift checks via landmark resection and RTK-GNSS reference flights' procedure, specifying the required flight hours/cost profile to ensure this does not create a high-likelihood schedule dependency conflict (per Decision 2) with integration testing?

**Assumptions:** Assumption: To maintain the weekly cadence without conflict, a 'Low-Intensity Calibration Profile' will be adopted post-PDR (M+4), requiring 4 hours of dedicated RTK-GNSS flight time per airport cluster pair (CPH/AAL combined) weekly, sourced via a dedicated, pre-booked local aviation contractor, limiting budget expansion beyond the initial contingency.

**Assessments:** Title: Safety and Risk Management for Geometric Maintenance
Description: Evaluation of the process required to maintain 3D accuracy KPIs against schedule threats.
Details: The scheduled weekly flights introduce non-trivial operational risk (Risk 6: Supply Chain/Access). If the outsourced charter fails to meet the 4-hour slot due to other airport traffic, geometric alignment drifts, directly impacting the P90 accuracy KPI. Opportunity: Use RTK data logging to create high-fidelity training scenarios (linking to Decision 9).

## Question 6 - How does the 'metadata-first' transport strategy, combined with the mandated ≤30-day retention policy and auto-redaction upon export, interface with the broader data requirements for Phase 2 NATO/Member-State feeds verification?

**Assumptions:** Assumption: The system architecture supports two distinct data paths: an immutable, short-term operational log (≤30 days) for core tracking/security functions, and a fully processed, standardized archive copy (EUROCONTROL/STANAG mapped, retaining full resolution media references) for long-term legal/training purposes, which must be finalized by M+18.

**Assessments:** Title: Environmental and Data Stewardship Assessment
Description: Analysis of data lifecycle management balance between regulatory retention, privacy, and functional output standards.
Details: The short retention window (≤30 days) aids the 'Environmental Impact' vector by minimizing long-term data storage carbon footprint and compliance burden. However, if the long-term archive standardization (STANAG mapping) falls behind the PDR/CDR schedule, Phase 2 data sharing becomes non-compliant, creating friction with Member-State agreements.

## Question 7 - Since the operational CONOPS uses ADVISORY/WARNING/CRITICAL states (Decision 6) but the optimized strategy bypasses ADVISORY/WARNING for countermeasure activation, how are conflicts resolved when an operator needs to manually intervene based on an ADVISORY state alert?

**Assumptions:** Assumption: Operational procedures mandate that even if countermeasures are automated only on CRITICAL, the ADVISORY state invokes mandatory, real-time media pull-on-demand for operator context via the UI, ensuring human review capability via the ≤750ms latency path, even if automated action is disabled.

**Assessments:** Title: Stakeholder Involvement and CONOPS Validation Assessment
Description: Review of how operator interaction protocols align with automated triage logic.
Details: The deliberate simplification of automated response (Decision 5) relies heavily on operator readiness (Risk 5). Stakeholder involvement must focus extensive M+18 testing on the 'manual escalation loop' from ADVISORY to CRITICAL to ensure the system supports, rather than impedes, expert decision-making, validating the high availability KPI (≥99.5%).

## Question 8 - What operational system requirements (e.g., processing latency budget for DLT fusion, required keypoint density) are tied directly from the 3D Accuracy KPI (P50 <1.0 m) to the computational capacity of the Edge Nodes (GPU/TPM) to ensure the Edge Processing Heterogeneity Mandate does not create a performance ceiling pre-CDR?

**Assumptions:** Assumption: Achieving P50 <1.0m requires the JPDA/MHT-lite fusion step (including covariance propagation) to complete within 70ms on the edge node, leaving a 130ms budget for detection, tracking, and 2D keypoint extraction to satisfy the 200ms edge-to-bus latency KPI.

**Assessments:** Title: Operational Systems Performance Threshold Assessment
Description: Linking required algorithmic output quality to underlying hardware performance budgets.
Details: The 70ms fusion budget is tight for DLT processing across three asynchronous sensor inputs (if A/B are fused by M+10). If the standardized edge hardware (Decision 4) cannot achieve this, accuracy KPIs will fail before CDR. The 'immutable edge OS' requirement must be proven to introduce zero runtime overhead compared to baseline Linux to meet this hard computational constraint.