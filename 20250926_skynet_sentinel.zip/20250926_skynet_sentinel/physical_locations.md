This plan implies one or more physical locations.

## Requirements for physical locations

- Ability to install sensor clusters at 10–40 m height
- Space available for 300–800 m sensor baselines
- Access to secure physical space for edge nodes (GPU/TPM)
- Proximity/access to RTK-GNSS reference flight support
- Must be a major airport location (for Phase 1: CPH, AAL)

## Location 1
Denmark

Copenhagen Airport (CPH)

Designated perimeter or secure rooftop zones, Copenhagen, Denmark

**Rationale**: Mandated Phase 1 pilot location for 2026 (€50M tranche). Requires installation of 12-18 clusters and fulfillment of all KPI acceptance tests.

## Location 2
Hungary

Budapest Ferenc Liszt International Airport (AAL)

Designated perimeter or secure rooftop zones, Budapest, Hungary

**Rationale**: The second mandated Phase 1 pilot location for 2026. This location will be essential for initial geometry qualification and proving cluster deployment viability on a European airport.

## Location 3
European Union

Tier 1 European Hub Airport (Hypothetical)

A major, high-traffic EU airport not currently selected as a finalist.

**Rationale**: To prepare for the Phase 2 rollout targeting 30 airports, establishing a third reference site allows for diversification of environmental baseline data (weather, air traffic profile) prior to mass procurement.

## Location 4
Germany

Frankfurt Airport (FRA) or Munich Airport (MUC)

Rooftop infrastructure or adjacent testing ranges accessible from the main airport facilities.

**Rationale**: As a major hub central to EUROCONTROL operations, a major German airport provides a robust environment to stress-test the NATO/ASTERIX data mapping and connectivity required for Phase 2 validation, especially concerning high-density air traffic.

## Location Summary
The plan explicitly names Copenhagen (CPH) and Budapest (AAL) as mandatory physical locations for the initial 2026 pilot phase, requiring significant vertical infrastructure (10-40m height) for sensor cluster deployment. Two additional major European airport types are suggested to diversify readiness testing for the 30-airport Phase 2 rollout.