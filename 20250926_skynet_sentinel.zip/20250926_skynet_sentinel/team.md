*Roles Needed & Example People*

# Roles

## 1. Program Governance & EASA Liaison Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Program Governance Lead is central to enforcing the rigid, non-negotiable EASA governance gates (PDR/CDR/FOC) across the 24-month timeline. This role requires deep integration with the PMO and continuous liaison with EASA, making a dedicated, loyal employee essential.

**Explanation**:
Responsible for navigating the EASA governance structure, securing all mandatory waivers (e.g., 30-40m sensor height), driving the PMO functions, and ensuring all PDR/CDR/Acceptance gates are prepared for clearance.

**Consequences**:
Immediate threats to schedule due to regulatory slippage (Risk 1), failure to secure necessary site access waivers, and inability to enforce disciplined adherence to governance gates.

**People Count**:
min 1, max 2, depending on regulatory workload across EU states

**Equipment Needs**:
Access to secure conferencing/collaboration tools (e.g., compliant document repositories, video conferencing with necessary certification levels) for EASA Steering Committee meetings and PMO synchronization across multiple legal jurisdictions.

**Facility Needs**:
Office space for PMO activity, dedicated secure room for classified governance documentation review (Zero-Trust compliance records, audit reports).

## 2. Senior Geodesy & Synchronization Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Senior Geodesy Architect owns the DLT geometry qualification, PTP synchronization network (≤1ms error), and manages weekly RTK-GNSS flights. This core technical responsibility, tied directly to the critical 3D accuracy KPI and long-term system stability (Issue 2 Review), necessitates a tightly controlled, full-time resource.

**Explanation**:
The core technical expert responsible for DLT geometry qualification, PTP (IEEE-1588) implementation (targeting ≤1ms sync error), GPSDO management, and overseeing weekly RTK-GNSS drift checks. Directly owns the 3D accuracy KPI.

**Consequences**:
Catastrophic failure to meet the P50/P90 3D accuracy KPIs. Geometric instability will corrupt triangulation results, rendering the entire system unusable for precision localization.

**People Count**:
1

**Equipment Needs**:
High-precision geodetic surveying equipment (Total Stations, Laser Scanners), dedicated RTK-GNSS receivers (compatible with GPSDO reference), PTP (IEEE-1588) Grandmaster system with dedicated GPSDO, access to contracted specialized aviation assets for weekly RTK-GNSS flights.

**Facility Needs**:
Access to surveyed control points on airport surfaces, secure workspace for maintaining the PTP Grandmaster system requiring clear sky visibility for GPSDO reference calibration.

## 3. Sensor Fusion & Algorithm Lead (Teams A/B Focus)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Sensor Fusion Lead (Teams A/B focus) is responsible for stabilizing the core JPDA/MHT-lite algorithms and meeting the tight 70ms edge fusion budget. This level of algorithmic development and performance tuning, critical for achieving Phase 1 KPIs, requires deep, sustained internal expertise.

**Explanation**:
Leads the core engineering effort for integrating the Optical (A) and Thermal (B) pipelines, focusing on stabilizing the JPDA/MHT-lite fusion engine and ensuring the 70ms edge fusion budget is met to achieve daytime Pd/Accuracy KPIs for M+18.

**Consequences**:
Failure to meet the primary Pd KPI during daylight operations; inability to stabilize covariance propagation necessary for accurate 3D positioning.

**People Count**:
min 1, max 3, based on complexity of data alignment across A/B streams

**Equipment Needs**:
High-performance computational cluster (e.g., dedicated GPU workstations) for off-line DLT and JPDA/MHT-lite algorithm development and regression testing; access to synchronized sensor data streams (Optical/Thermal feeds) mirroring edge node output for fusion testing.

**Facility Needs**:
Secure laboratory environment with environmental chambers (for thermal testing) and dedicated network infrastructure for simulating the 200ms edge-to-bus latency targets.

## 4. Cybersecurity & Zero-Trust Compliance Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Cybersecurity Engineer must implement and validate specific, high-assurance standards (Zero-Trust, SLSA-3+, accelerated Red-Teaming). While Zero-Trust requires deep knowledge, specialized security validation services (like accelerated red-teaming) are often best sourced via specialized independent contractors/consultancies to maintain the necessary independence for rigorous auditing (Decision 11).

**Explanation**:
Designs, implements, and validates the Zero-Trust architecture across all edge nodes (TPM, Secure Boot, SLSA-3+). Responsible for accelerating the Red-Team cadence and ensuring patch SLOs (≤7 days) are manageable.

**Consequences**:
Introduction of critical security vulnerabilities into the operational system, potentially leading to data breaches or loss of stakeholder trust, violating essential governance requirements.

**People Count**:
1

**Equipment Needs**:
Hardware security modules (HSM), specialized hardware testers capable of verifying TPM functionality and secure boot integrity; access pre-release hardware containing target TPM/Secure Boot features; budget allocation for external Red Team contractor utilization (quarterly basis).

**Facility Needs**:
Isolated, high-security (SCIF-like) testing environment for validating Zero-Trust key provisioning, mTLS pinning implementation, and immutable OS lockdown procedures across edge nodes.

## 5. Data Standardization & Interoperability Architect

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Data Standardization Architect manages the complex dual-protocol mapping (EUROCONTROL/STANAG) and the temporary wrapper solution, a highly specialized task that may involve specific knowledge of these legacy aviation protocols. This can be effectively sourced via a specialized technical contractor/consultant for the duration of the mapping effort (post-M+18).

**Explanation**:
Responsible for defining the internal EDXP format, managing the temporary ASTERIX wrapper for Phase 1, and driving the complex dual-standard mapping effort for NATO/STANAG and EUROCONTROL, mitigating the risk of technical debt post-M+18.

**Consequences**:
Failure to meet NATO/Member-State data feed verification requirements during Phase 2, jeopardizing interoperability and the ultimate goal of the program.

**People Count**:
1

**Equipment Needs**:
Development environment for protocol mapping tools (e.g., schema validators), access to reference implementations/simulators for EUROCONTROL/ASTERIX and NATO/STANAG message structures; specialized software licenses for data serialization/deserialization libraries.

**Facility Needs**:
Dedicated workstation environment for developing and validating the EDXP wrapper solution during Phase 1, requiring high network uptime for interoperability testing post-M+18.

## 6. Physical Deployment & Logistics Coordinator

**Contract Type**: `agency_temp`

**Contract Type Justification**: The Physical Deployment Coordinator role is intensive during mobilization (Q4-2025) and Phase 1 pilot rollout (2026) across CPH/AAL, involving site access, logistics scheduling, and managing supply chain buffers. This logistical surge capacity is ideally suited for temporary agency support rather than adding permanent FTE headcount.

**Explanation**:
Manages all site-specific build-out logistics at CPH, AAL, and the 30 Phase 2 airports, specifically coordinating the installation of 10-40m sensor masts, managing supply chain buffers for GPU/TPM hardware, and scheduling RTK-GNSS flight resources.

**Consequences**:
Significant project delays stemming from installation bottlenecks, site access issues, environmental assessment failures, or inventory shortages for edge hardware.

**People Count**:
min 2, max 4, due to simultaneous deployment across many sites

**Equipment Needs**:
Procurement management system linked to buffer stock monitoring for GPUs, TPMs, and camera components; access scheduling software for managing installation crews and RTK-GNSS flight windows across CPH/AAL/Phase 2 sites (logistical coordination).

**Facility Needs**:
Secure, geographically distributed warehousing facilities for storing hardware buffer stock; site office access at CPH and AAL for deployment coordination (including access for 10-40m mast installation scaffolding/cranes).

## 7. Operator CONOPS & Training Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The CONOPS and Training Specialist must develop the complex tri-state operator model and the Integrated Training Program (Decision 9), which is foundational for M+18 Pilot Acceptance. This requires continuous, integrated work closely tied to the core product development iteration.

**Explanation**:
Designs the ADVISORY/WARNING/CRITICAL operator workflow and develops the Integrated Training and Simulation Program. Ensures required operator proficiency is achieved before the M+18 Pilot Acceptance gate.

**Consequences**:
Insufficient personnel readiness (Risk 5), leading to poor operational performance, excessive false alerts, or failure to validate the required human-machine interaction during live exercises.

**People Count**:
1

**Equipment Needs**:
High-fidelity simulation platform capable of replicating multi-view geometry, sensor noise profiles (Optical/Thermal), and network latency characteristics; operator consoles matching the final Operator UI specification.

**Facility Needs**:
Dedicated training facility/classroom for operator cohorts, equipped with high-bandwidth connectivity to the simulation environment to support drills validating the ADVISORY/WARNING/CRITICAL state transitions.

## 8. Performance Monitoring & KPI Feedback Engineer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Performance Monitoring Engineer builds and maintains the internal KPI feedback system (Decision 10), which is essential for rapid tuning and proving latency compliance. This infrastructure requires continuous maintenance and iteration integral to the software development lifecycle.

**Explanation**:
Implements the Real-Time Performance Monitoring System, responsible for aggregating KPI data (especially edge-to-bus latency, <200ms) across all clusters and establishing the feedback loop necessary for continuous algorithmic tuning and KPI validation.

**Consequences**:
Inability to prove adherence to latency KPIs, inhibiting rapid iterative refinement, and making objective measurement against performance success criteria impossible.

**People Count**:
1

**Equipment Needs**:
Real-time data ingest pipelines and monitoring tools (e.g., Grafana/ELK stack) configured to track KPI metrics (latency, Pd confidence, covariance) from distributed edge nodes; network analyzers capable of measuring edge-to-bus latency (<200ms).

**Facility Needs**:
Centralized data integration/monitoring center (SOC interface) to visualize the health and performance dashboards derived from the KPI streams, ensuring continuous monitoring aligned with cyber SLOs.

---

# Omissions

## 1. Missing Dedicated Test & Evaluation (T&E) Manager

The project relies heavily on passing rigid, quantifiable KPIs (Pd, 3D accuracy, Latency) across critical governance gates (PDR, CDR, M+18). While IV&V performs audits, a dedicated internal T&E role is required to manage the integrated test campaign, schedule the 4 hours/week RTK-GNSS flights, coordinate live exercises at CPH/AAL, and synthesize data for the PMO against the required 10+ KPIs. This function spans infrastructure integration, software validation, and operator training sign-off.

**Recommendation**:
Add a dedicated 'Test & Evaluation Coordinator' (potentially FTE or long-term contractor) to own the Gantt chart execution for testing milestones, manage the RTK-GNSS flight contracts, and serve as the primary interface between the Engineering Leads (Team A/B/C) and the IV&V partner prior to gate reviews.

## 2. Missing RF/Acoustic (Team C) Integration Lead

The team structure explicitly identifies Teams A, B, and C, but the provided roles only detail a 'Sensor Fusion & Algorithm Lead (Teams A/B Focus)'. Since Team C (RF/Acoustic) is critical for the 'confirm/veto' function and poor-weather Pd targets (even if deferred), its integration pathway needs dedicated ownership. Deferring integration does not mean deferring design and hardware qualification.

**Recommendation**:
Create a role, 'Sensor Modality Lead - RF/Acoustic (Team C)', responsible for designing the interface requirements, managing procurement selection for Lot C sensors, and preparing the deferred algorithms. This ensures Team C deliverables remain tracked toward the post-IOC integration schedule.

## 3. Missing Field Maintenance & On-Site Support Structure

The plan involves deploying 12-18 clusters at CPH/AAL immediately (2026) and scaling to 30+ airports. There is no defined role for Level 1/Level 2 on-site troubleshooting, break/fix for GPU failures, TPM resets, or managing the physical aspects of sensor calibration checks once the deployment teams leave. This undermines the ≥99.5% availability KPI.

**Recommendation**:
For Phase 1, assign the 'Physical Deployment & Logistics Coordinator' the interim task of establishing a Level 1 'On-Call Support Matrix' with CPH/AAL site contacts. For Phase 2 preparation, budget for establishing small, locally contracted Field Maintenance Teams (or internal site technicians) for rapid response (SLO adherence).

## 4. Missing Dedicated Protocol Architect for Legacy Mapping

The review found that deferring full NATO/STANAG mapping via a 'wrapper' solution until Post-M+18 creates significant technical debt and governance risk (Issue 3 in review notes). The 'Data Standardization Architect' is defined, but the immediate, high-friction work of ensuring the wrapper correctly translates EDXP to BOTH ASTERIX (simulated) AND STANAG (mandatory for M+18 partner feeds) requires dedicated protocol expertise, not just architectural oversight.

**Recommendation**:
Re-title 'Data Standardization & Interoperability Architect' to 'Protocol Architect & Mapping Specialist,' emphasizing the immediate requirement to develop and validate the STANAG translation layer artifact required by M+14, even if the *full* operational feed isn't live until FOC.

---

# Potential Improvements

## 1. Clarify PTP/RTK Dependency Management

The 'Senior Geodesy & Synchronization Architect' owns PTP (timing) and RTK (geometry). These are deeply interconnected but distinct disciplines. A failure in PTP (timing sync) directly impacts triangulation covariance, making the boundary between the network specialist and the geodesist fuzzy, risking the ≤1ms error requirement and the 3D accuracy KPI.

**Recommendation**:
Split the Synchronisation function entirely: Make the Architect responsible for the *geometry* (DLT, control points, RTK flights) and delegate PTP/IEEE-1588/GPSDO implementation entirely to the 'Performance Monitoring & KPI Feedback Engineer,' leveraging their strong network/latency focus. This aligns PTP control with the latency feedback loop.

## 2. Streamline Operator Model Simplification

Decision 5 bypassed ADVISORY/WARNING states for automated countermeasures, aiming to simplify operator flow to meet latency KPIs. However, the CONOPS Specialist still has to develop the complex tri-state model (Decision 6) and the CONOPS document, creating potential friction/confusion if development tracks diverge from operational reality.

**Recommendation**:
Require the 'Operator CONOPS & Training Specialist' to immediately coordinate with the 'Sensor Fusion & Algorithm Lead' to formally document which states (Advisory/Warning) will *not* trigger auto-response, explicitly defining the manual intervention threshold required, and capturing this documented simplified flow for M+18 acceptance testing.

## 3. Integrate Cyber SLO Monitoring into Performance Feedback Loop

The 'Cybersecurity Engineer' owns security patching (≤7-day SLO), while the 'Performance Monitoring Engineer' tracks system KPIs (latency, availability). These are linked: a late critical patch or an insecure edge OS configuration can cause functional degradation that manifests as a performance KPI failure, without triggering a dedicated security alert.

**Recommendation**:
Mandate that the Real-Time Performance Monitoring System (Decision 10) must incorporate a 'Critical Patch Compliance Telemetry' metric, allowing the PMO to immediately correlate any availability or latency degradation against the patching status of the affected edge nodes.

## 4. Formalize Management of Deferred Team C Requirements

Team C (RF/Acoustic) is deferred. While hardware procurement may be delayed, the design specifications (e.g., power draw, expected data rates, security profile for those RF devices) must be finalized by PDR (M+4) to lock in Lot C pricing and ensure hardware compatibility with the standardized edge nodes (Decision 4). This needs explicit ownership.

**Recommendation**:
Assign the 'Sensor Modality Lead - RF/Acoustic (Team C)' (once created as per Omission #2) the explicit deliverable of finalizing the Team C hardware specifications and interface requirements document (IRD) for Lots A/B/C consolidation review by M+4 PDR, ensuring that deferred complexity does not become procurement friction in Phase 2.