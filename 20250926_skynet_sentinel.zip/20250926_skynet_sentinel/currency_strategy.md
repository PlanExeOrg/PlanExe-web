This plan involves money.

## Currencies

- **EUR:** The program budget is stated as €200M, and core oversight is EASA, making the Euro the operational and budgeting standard.
- **DKK:** Local currency (Danish Krone) for expenditures at Copenhagen Airport (CPH).
- **HUF:** Local currency (Hungarian Forint) for expenditures at Budapest Airport (AAL).
- **USD:** Relevant for procuring specialized, high-end sensor components (PTZ optics, GPU/TPM hardware, GPSDO units) which are often globally priced in USD.

**Primary currency:** EUR

**Currency strategy:** The primary budget and all high-level procurement contracts are denominated in EUR, aligning with the EASA oversight and the stated €200M budget. Local expenditures at CPH and AAL must be managed in DKK and HUF, respectively, requiring operational budgets converted from EUR, hedging against minor intra-Eurozone exchange fluctuations.