**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** The request outlines a technical project plan for developing an air traffic surveillance system, which touches on critical infrastructure and surveillance technologies; discussion must remain high-level and focused on governance, feasibility, and compliance.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |