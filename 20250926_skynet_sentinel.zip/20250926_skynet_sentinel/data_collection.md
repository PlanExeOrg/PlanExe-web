## 1. Sensor Modality Integration Viability (Team A/B Fusion & Team C Feasibility)

This data directly validates the core strategic choice of delaying Team C to meet the M+18 gate. If A+B alone cannot meet core KPIs, or if the platform ceiling prevents viable post-IOC integration of C, the entire project viability is questioned.

### Data to Collect

- Simulation results proving Pd and 3D Accuracy KPIs achievable using only Optical (A) and Thermal (B) fusion by M+10 CDR.
- Quantified performance margin remaining on the standardized edge compute platform for future Team C (RF/Acoustic) integration.
- IV&V-certified simulation environment proof that adverse weather Pd (Team C dependency) can be met by M+24, accepting current deferral.

### Simulation Steps

- Use MATLAB/Simulink to model JPDA/MHT-lite fusion outputs for combined A+B streams under simulated daytime/clear air conditions.
- Run stress tests on the standardized edge hardware reference design (e.g., using high-throughput benchmarks on a target GPU) to quantify maximum processing headroom remaining for Team C algorithms (target must be >20% headroom).

### Expert Validation Steps

- Consult the Sensor Integration Engineer (Expert 2) to review the mathematical models for coordinate transformation stability between A/B data streams.
- Consult the Cybersecurity Auditor (Expert 3) and ask how deferred security hardening for Team C components will impact the overall Zero-Trust verification timeline post-IOC.

### Responsible Parties

- Sensor Fusion & Algorithm Lead (FTE)
- Program Governance & EASA Liaison Lead (FTE)

### Assumptions

- **High:** The performance achievable by the A+B fusion path, tuned specifically for daytime KPIs, is sufficient to pass the M+18 acceptance gate without requiring Team C input for the initial sign-off.
- **Medium:** The standardized edge hardware platform (Decision 4) has sufficient residual capacity to integrate the specialized RF/Acoustic processing pipeline during the IOC to FOC transition window.

### SMART Validation Objective

Achieve documented proof (simulation fidelity >95%) via Sensor Fusion Lead review that daytime Pd/Accuracy KPIs are met by Team A/B fusion alone by M+10 CDR, by 2026-05-20.

### Notes

- High risk: Failure here invalidates the core premise of the 'Builder' strategy.
- Must confirm if EASA will accept 'proof of concept' for Team C capability closure at M+18, or if physical demonstration is required.


## 2. Geometric Stability Model and Drift Threshold

The geometric stability is the foundation of the 3D accuracy KPI. Accepting degradation post-M+18 is a critical risk (Review Issue 2) that must be quantified immediately to prevent catastrophic KPI failure before FOC.

### Data to Collect

- Quantified degradation curve modeling 3D accuracy (P90) over 36 months based only on the initial six control points.
- Established internal 'Geometric Health Check' KPI (e.g., 1.5x variance of PDR performance baseline) that mandates a full re-survey.
- Cost and schedule estimate for executing a full geometric re-survey charter commencing M+18.

### Simulation Steps

- Geospatial Metrology Expert simulation environment (hypothetical tool/software suite) to model covariance propagation error growth over time based on fixed survey network constraints.
- Analyze recorded RTK-GNSS weekly flight data (post-PDR) to identify the real-world drift rate for use in predictive modeling.

### Expert Validation Steps

- Consult the Geospatial Metrology Expert (Expert 5) to validate the derived degradation curve and confirm the proposed re-survey trigger metric against P90 SLA requirements.
- Consult the Senior Geodesy & Synchronization Architect (FTE) on the feasibility and cost of the M+18 re-survey charter.

### Responsible Parties

- Senior Geodesy & Synchronization Architect (FTE)
- Program Governance & EASA Liaison Lead (FTE)

### Assumptions

- **High:** The weekly RTK-GNSS flight charter (4 hours/airport/week) is secured and executed reliably post-PDR to generate sufficient data for drift modeling.
- **High:** The initial six control points provide sufficient geometric stability such that the derived tolerable drift rate will not cause KPI failure before M+28, allowing re-survey deferral.

### SMART Validation Objective

The Senior Geodesy Architect must deliver a signed, quantitative Geometric Risk Model defining the M+12 Re-Survey Trigger Metric by M+6 (March 2026).

### Notes

- This directly addresses Review Issue 2 concerning long-term accuracy assurance.
- Cost estimate for M+18 re-survey must be secured from Logistics Coordinator (Temp role) for inclusion in Phase 2 budget planning.


## 3. Protocol Interoperability Path Validation (ASTERIX/STANAG)

The 'Builder' strategy relies on a wrapper solution that Review Issue 3 flags as a major point of debt and regulatory friction. We must accelerate the delivery of a true STANAG layer to de-risk Phase 2 interoperability.

### Data to Collect

- Specification of the definitive, non-wrapper STANAG translation layer required for M+14 delivery.
- Formal documentation from NATO/EUROCONTROL detailing non-acceptance criteria for simulated ASTERIX validation at M+18.
- Resource allocation audit showing engineering hours successfully re-directed from edge hardening to the STANAG translation layer development (M+14 target).

### Simulation Steps

- Use a dedicated protocol analysis tool (e.g., Wireshark with custom dissectors or specialized protocol emulation software) to validate the EDXP wrapper output against the ASTERIX schema requirements.
- Develop and execute unit tests for the initial STANAG translation logic against the internal EDXP v0.9 definition.

### Expert Validation Steps

- Consult the Data Standardization & Interoperability Architect (FTE/Contractor) to confirm the viability of the M+14 STANAG delivery plan.
- Consult the Defense Interoperability Protocol Analyst (Expert 6) regarding the political/technical risk of submitting simulated ASTERIX data for M+18 Pilot Acceptance.

### Responsible Parties

- Data Standardization & Interoperability Architect (IC)
- Program Governance & EASA Liaison Lead (FTE)

### Assumptions

- **High:** Full NATO/STANAG compliance can be achieved by M+14 (Dec 2026) by re-allocating 2 months of non-essential edge hardening optimization engineering hours.
- **Medium:** EUROCONTROL will accept a simulated ASTERIX message validation result at the M+18 Pilot Acceptance gate, provided the core tracking KPIs are met.

### SMART Validation Objective

Deliver the first authenticated, non-wrapper translation layer for the core STANAG message structure, validated by Expert 6, by M+14 (2026-12-20).

### Notes

- This action directly addresses Review Issue 3.


## 4. Cybersecurity Cadence Funding Assurance

Accelerated security validation (Decision 11) is considered high-priority but creates an immediate, unbudgeted cost pressure against the fixed Phase 1 budget (Review Issue 1). Funding must be secured or an equivalent scope trade made immediately.

### Data to Collect

- Firm budgetary quote from the IV&V partner covering the cost delta between bi-annual and quarterly Red-Teaming for the first 18 months.
- Formal scope reduction proposal (alternative security feature downgrade) if the budget delta cannot be covered by contingency.
- Updated IV&V contract amendment reflecting the accelerated Red-Team schedule commencing pre-CDR.

### Simulation Steps

- N/A - This is a financial and contractual data collection task.

### Expert Validation Steps

- Consult the Regulatory Compliance Specialist (Expert 1) to confirm the legality and governance implications of the proposed scope reduction, should budgetary remediation fail.
- Consult the Cybersecurity & Zero-Trust Compliance Engineer (FTE) to confirm that the remaining security baseline (if scope is reduced) remains compliant with SLSA-3+ ingress requirements.

### Responsible Parties

- Program Governance & EASA Liaison Lead (FTE)
- Physical Deployment & Logistics Coordinator (Temp)

### Assumptions

- **Medium:** The accelerated Red-Teaming schedule is feasible for the IV&V provider without compromising the quality of the audit results for the Zero-Trust architecture.

### SMART Validation Objective

Secure formal budget sign-off covering the Q1-Q4 2026 incremental IV&V costs, or approve an equivalent scope trade, by M+2 (Dec 2025).

### Notes

- This addresses Review Issue 1 urgently as it impacts Phase 1 funding integrity.

## Summary

The project relies on the 'Builder' strategy to pass the M+18 Pilot Acceptance by deferring complex cross-sensor fusion (Team C) and full protocol standardization (STANAG). Data collection must immediately prioritize validating the high-sensitivity assumptions underpinning this high-risk trade-off: 1) Confirming A+B sensor performance is sufficient alone (Data 1), 2) Quantifying the long-term geometric drift risk associated with accepting degradation (Data 2), and 3) Actively mitigating the technical debt created by the protocol wrapper by accelerating STANAG development (Data 3). Finally, the unbudgeted cost of accelerated cybersecurity validation (Data 4) must be resolved instantly to protect the Sensor Integration funding. **Immediate Actionable Tasks:** 1. Task Senior Geodesy Architect to produce the Geometric Risk Model trigger point by M+6 (Data 2). 2. Obtain a firm cost quote for quarterly Red-Teaming and finalize its funding source or corresponding scope reduction by M+2 (Data 4). 3. Initiate the non-wrapper STANAG translation layer development (Data 3) targeting M+14.