# Governance Audit


## Audit - Corruption Risks

- Kickbacks or bribery during the Procurement Phase (Q4-2025 RFPs) in exchange for awarding Lots A/B/C (sensors/algorithms) or the Integration/Edge/Network contract, especially where competitive pressure might be intentionally reduced by consolidation.
- Nepotism or undue influence in selecting the 4-hour weekly RTK-GNSS charter contractor (critical to geometric KPI maintenance), potentially leading to inflated rates or substandard service.
- Conflicts of interest where PMO personnel or EASA Steering Committee members own stakes in component suppliers (e.g., specialized PTZ manufacturers or GPU vendors) influencing procurement decisions (Lots A/B/C).
- Trading favors with local regulators (Danish CAA or Hungarian CAA) to expedite difficult operational waivers required for the non-standard 10–40m sensor mounting heights, bypassing official safety scrutiny.
- Misuse of proprietary PTP synchronization network setup knowledge or GPSDO information (a high-value asset) shared with external system integrators in exchange for favorable contractual terms or expedited deliverables (kickbacks).

## Audit - Misallocation Risks

- Misallocation of Phase 1 budget (€50M), specifically overspending the 70% allocated to Teams A/B integration to compensate for underperforming algorithms or hardware selected based on biased vendor selection, leading to scope reduction elsewhere in the pilot.
- Double spending or inefficient use of resources related to maintaining the DLT geometry; failure to aggregate RTK-GNSS flight data effectively across CPH and AAL, resulting in paying for redundant flight hours or failing to use logged data for training.
- Unauthorized use of specialized personnel (Senior Geodesy Engineer/Sync Specialist) dedicated for Q4-2025 mobilization on non-critical tasks (e.g., developing training material instead of site surveying), directly threatening the M+4 PDR gate.
- Misreporting progress on the deferred Team C (RF/Acoustic) integration; current resources dedicated to A/B stabilization might be incorrectly logged as progress toward the full system integration timeline required for FOC (M+24).
- Budget misuse via over-specifying edge hardware purchased under the standardized GPU/TPM stack mandate, selecting overly powerful or expensive components when less costly hardware could meet the tight 70ms fusion budget.

## Audit - Procedures

- Conduct quarterly, independent financial audits focused on expenditure related to Procurement Lots A/B/C and IV&V contracts, verifying costs against established framework agreement mini-competition thresholds, starting Q1-2026.
- Perform technical/system audits immediately post-PDR (M+4) and CDR (M+10) to verify that the implementation of the 'Builder' strategy aligns with stated deferrals (e.g., confirm Team C code base is truly parked and not consuming integration resources).
- Mandatory third-party forensic review of PTP synchronization logs and GPSDO attestations monthly during Phase 1, verifying end-to-end error remains ≤1 ms before allowing integration testing activities to proceed.
- Periodic (e.g., semi-annual, pre-IOC) audit of data handling workflows to confirm operational logs are retained for ≤30 days, and that auto-redaction based on privacy zones is functioning correctly *before* media is pulled on demand or exported.
- Detailed review of the RTK-GNSS flight vendor contract and log files post-PDR (M+4) to ensure the 4 hours/week workload requirement is met for CPH/AAL without conflicting with core software integration milestones, linking flight costs back to the Contingency Budget.

## Audit - Transparency Measures

- Publish the EASA Steering Committee meeting minutes quarterly (as required) detailing all decisions related to waiver grants for 10–40m mounting heights and KPI acceptance results from the M+18 Pilot Acceptance gate.
- Maintain a publicly accessible, read-only dashboard tracking the hard schedule gates (PDR, CDR, IOC, FOC) and the primary KPI scores (Pd, 3D Accuracy P90, Availability) updated following each governance gate review.
- Document and publicly share the formal criteria used for down-selecting the standardized edge node hardware (GPU/TPM stack) proving it meets the 70ms fusion budget requirement, to validate the Edge Processing Heterogeneity Mandate.
- Establish an anonymous, formally chartered whistleblower mechanism overseen directly by the independent IV&V partner to report conflicts of interest or deviations from competitive Lot procurement procedures.
- Publish the M+18 acceptance documentation, including the coverage/accuracy heatmaps and the Calibration Handbook, to ensure transparency on the achieved performance baseline before Phase 2 commitments are finalized.

# Internal Governance Bodies

### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Mandated by the plan and required by EASA oversight. This body handles the high-level strategic direction, gate approvals (PDR, CDR, IOC, FOC), and provides executive oversight for the €200M budget and regulatory compliance (e.g., EASA Type Deviation Waivers for mounting height).

**Responsibilities:**

- Approve/Reject movement between mandatory governance gates (PDR M+4, CDR M+10, Pilot Acceptance M+18, FOC M+24).
- Approve strategic redirection based on KPI failure or major shifts in strategic decisions (e.g., scope change vs. Deferral decisions).
- Provide final authorization for capital expenditure exceeding €5M or critical contractual amendments.
- Oversee high-level regulatory liaison and grant final operational waivers.
- Resolve escalations from the PMO regarding strategic risk exposure or cross-functional conflicts.

**Initial Setup Actions:**

- Formalize and approve the PSC Terms of Reference (ToR), specifically defining authorized financial thresholds.
- Appoint the EASA Chair and secure commitment from all key oversight owners.
- Establish data classification and distribution policy for PSC meeting minutes and gate reports.

**Membership:**

- EASA Executive Sponsor (Chair)
- Head of Program Management Office (PMO)
- Lead of Independent Verification & Validation (IV&V) Partner (Non-voting Assurance Role)
- Senior Legal/Regulatory Counsel (Internal Expert)

**Decision Rights:** All strategic direction, gate progression decisions, budget authority > €5M, and final approval on Phase 1 to Phase 2 resource allocation shifts.

**Decision Mechanism:** Consensus required, with the EASA Chair holding the final casting vote in case of irreconcilable strategic deadlock. Decisions must be formally minuted.

**Meeting Cadence:** Monthly for the first 6 months (Mobilization/PDR); then tied to major gate reviews (PDR M+4, CDR M+10, Pilot Acceptance M+18, etc.).

**Typical Agenda Items:**

- Status of Critical Path Milestones vs. Schedule Gates.
- Review of Strategic Risk Register top 5 entries (focusing on timeline/budget risks).
- Formal Gate Review Presentation and Go/No-Go Recommendation.
- Escalation review from the PMO.

**Escalation Path:** N/A (Highest internal oversight body). Conflict resolution outside this body requires appeal to the relevant EASA Director General or relevant Ministerial body if regulatory scope is exceeded.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Required to manage the day-to-day €200M execution, enforce the rigid 24-month schedule, coordinate procurement across three specialized lots, and integrate the outputs of the Core Technical Teams against demanding KPIs (e.g., 70ms fusion budget, PTP sync).

**Responsibilities:**

- Manage consolidated schedule, budget (€200M total, €50M Phase 1), and resource allocation.
- Coordinate execution between A/B/C integration teams and the Core Integration/Edge Team.
- Own the KPI measurement dashboard (Decision 10) and report deviations to the PSC.
- Manage procurement framework agreements and mini-competitions details.
- Own the real-time compliance monitoring (Patch SLOs, Latency reporting).

**Initial Setup Actions:**

- Finalize the detailed 24-month integrated Gantt chart compliant with all mandated gates.
- Establish the PMO operational cadence meetings and KPI reporting structure.
- Recruit and assign the Senior Geodesy Engineer and Network Synchronization Specialist (per assumptions).

**Membership:**

- Program Director (PMO Lead/Chair)
- Lead Project Scheduler/Controller
- Lead Technical Architect (Interface Manager)
- Lead Cybersecurity/Compliance Manager
- Core Technical Team Leads (A, B, Integration)

**Decision Rights:** All operational decisions, tactical risk management (below €500k cost impact), assignment of engineering tasks, approval of schedule adjustments within contingency boundaries, and management of the weekly RTK-GNSS flight charter schedules.

**Decision Mechanism:** Simple majority vote among PMO leadership, with the Program Director holding authority to approve low-risk operational deviation or enforce mandatory schedule adherence.

**Meeting Cadence:** Daily synchronization stand-ups (Core Teams Focus); Bi-weekly full PMO operational review.

**Typical Agenda Items:**

- Review of KPI performance (Latency/Availability) vs. Decision 10 Monitoring.
- Procurement Lot status and vendor slippage reports.
- Resolution of technical integration conflicts between sensor pipelines.
- Review of asset utilization (e.g., RTK flight time compliance).

**Escalation Path:** Issues exceeding €500k financial impact, risks threatening M+4 PDR or M+10 CDR progress by >2 weeks, or disputes over strategic execution mandate are escalated immediately to the Project Steering Committee (PSC).
### 3. Technical Integrity & Verification Group (TIVG)

**Rationale for Inclusion:** Given the extreme technical novelty (DLT, PTP sync <1ms, custom fusion algorithms) and high accuracy requirements (<1.0m P50), an internal technical assurance body is vital to enforce engineering rigor before the external IV&V partner certifies readiness. This group specifically validates the complex geometric and synchronization requirements.

**Responsibilities:**

- Perform detailed review of DLT resection/bundle adjustment results and uncertainty propagation models.
- Audit PTP synchronization logs (IEEE-1588/GPSDO) monthly to verify sub-1ms error budget adherence.
- Verify that the standardized edge node meets the 70ms DLT fusion budget requirement.
- Oversee the creation and maintenance of the Calibration Handbook and Test Cards.
- Validate that the 'wrapper-based conversion service' for EDXP is functionally sound for M+18 testing.

**Initial Setup Actions:**

- Define the technical specification required for the Senior Geodesy Engineer and Network Sync Specialist.
- Establish the audit cadence and data formats for PTP log review.
- Define the pass/fail criteria for the edge node 70ms fusion test.

**Membership:**

- Lead System Architect (Chair)
- Senior Geodesy Engineer (Assumed Q4-2025 Hire)
- Network Synchronization Specialist (Assumed Q4-2025 Hire)
- Lead Software Engineer (Fusion/Algorithm Focus)

**Decision Rights:** Can issue 'Hold Orders' on integration testing if PTP sync errors exceed 1ms or if geometric reconstruction indicates potential drift greater than 10% outside model projections. Recommends technical gates to PMO.

**Decision Mechanism:** Unanimous technical agreement is required on certification artifacts; failure to agree mandates immediate escalation of the specific technical failure to the PSC for strategic adjudication.

**Meeting Cadence:** Weekly until CDR (M+10); Bi-weekly post-CDR focusing on drift characterization and KPI verification.

**Typical Agenda Items:**

- PTP Synchronization Health Check Report (Error analysis).
- DLT Extrinsics Stability Review (Control Point vs. Landmark Resection).
- Edge Node Performance Benchmarks (70ms Fusion Test results).
- Review of status of RTK-GNSS flight data utilization.

**Escalation Path:** Failure to reach internal technical consensus regarding geometry or sync stability that threatens the M+18 Pilot Acceptance KPIs is escalated directly to the PSC for strategic decision on technical trade-offs (e.g., funding a full re-survey or accepting lower accuracy).
### 4. Cyber, Privacy, and Compliance Board (CPCB)

**Rationale for Inclusion:** The project has extensive, front-loaded security and privacy mandates (Zero-Trust, SLSA-3+, GDPR, metadata retention ≤30 days). An independent board is necessary to ensure adherence to these non-functional requirements are verified quarterly, not just at final gates, especially given the plan to accelerate independent red-teaming quarterly.

**Responsibilities:**

- Oversee the quarterly external security red-teaming results and PMO remediation plans.
- Certify adherence to GDPR/Privacy Zone implementation and successful auto-redaction functionality.
- Audit the immutable edge OS/Secure Boot/SBOM/mTLS implementation at the edge.
- Ensure the data retention policy (≤30 days operational log) is enforced across all ingestion points.
- Ensure compliance review of NATO/STANAG mapping drafts (even if deferred) against security protocols.

**Initial Setup Actions:**

- Contract the independent IV&V partner to begin quarterly red-teaming starting immediately post-mobilization (Q4-2025 / Pre-PDR).
- Mandate the Cybersecurity/Compliance Manager to produce the initial Zero-Trust Architecture document for review.
- Define the formal process for reviewing the required Privacy Zones configuration across CPH/AAL.

**Membership:**

- Lead Cybersecurity/Compliance Manager (Chair)
- Independent IV&V Partner Security Lead (Assurance Role)
- Legal Counsel (Privacy/Regulatory Focus)
- SOC Monitoring Lead (Operational Feedback)

**Decision Rights:** Can mandate a 'Cyber Security Stop Work Order' on any Phase 1 integration stream (A, B, or Edge Hardware) if a critical vulnerability (leading to breach or loss of integrity) is confirmed by red-teaming, pending PSC review within 7 days.

**Decision Mechanism:** Unanimous agreement required, especially when issuing Stop Work Orders. Chair casts tie-breaking vote on procedural compliance issues only.

**Meeting Cadence:** Bi-weekly during mobilization and integration phases; Quarterly post-Pilot Acceptance.

**Typical Agenda Items:**

- Review of Open Vulnerabilities and Patch Remediation SLO adherence (Crit ≤7d).
- GDPR/Privacy Zone Audit Report.
- Status of SLSA-3+ provenance tracking implementation.
- Review of M+18 mandatory security and privacy audit checklist status.

**Escalation Path:** Critical security findings or sustained failure to adhere to Patch SLOs that directly undermine Zero-Trust integrity are escalated immediately, regardless of cadence, to the PSC for mandate enforcement.

# Governance Implementation Plan

### 1. Mobilize Q4-2025: Secure dedicated facilities and finalize EASA-chaired Project Steering Committee (PSC) scope, timeline, and financial authorizations (>€5M).

**Responsible Body/Role:** EASA Executive Sponsor

**Suggested Timeframe:** Project Week 1 (Q4-2025)

**Key Outputs/Deliverables:**

- Confirmed PSC Charter/Scope Document
- Authorized initial Phase 1 Budget Release (€50M tranche initiation)

**Dependencies:**

- Project Kickoff Decision
- Program Budget (€200M) Allocation Defined

### 2. Mobilize Q4-2025: Recruit and on-board required specialized personnel: Senior Geodesy Engineer and Network Synchronization Specialist.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 2-4

**Key Outputs/Deliverables:**

- Senior Geodesy Engineer On-boarded
- Network Synchronization Specialist On-boarded

**Dependencies:**

- Confirmed PSC Charter/Scope Document

### 3. PMO drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating financial thresholds and gate approval mandates.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Confirmed PSC Charter/Scope Document

### 4. PSC reviews and formally approves its ToR, confirming EASA Executive Sponsor as Chair and affirming the governance structure (PSC, PMO, TIVG, CPCB).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Formal appointment of PSC member roles

**Dependencies:**

- Draft PSC ToR v0.1

### 5. PMO drafts initial ToR for the Project Management Office (PMO), Technical Integrity & Verification Group (TIVG), and Cyber, Privacy, and Compliance Board (CPCB).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1
- Draft TIVG ToR v0.1
- Draft CPCB ToR v0.1

**Dependencies:**

- Approved PSC ToR v1.0

### 6. PMO circulates Draft ToRs to nominated PSC members for immediate review (focusing on decision rights alignment).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Circulated Draft Governance ToRs

**Dependencies:**

- Draft PMO ToR v0.1
- Draft TIVG ToR v0.1
- Draft CPCB ToR v0.1

### 7. PSC reviews and approves the finalized ToRs for the PMO, TIVG, and CPCB, authorizing their formal establishment.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved PMO ToR v1.0 (PMO formally established)
- Approved TIVG ToR v1.0 (TIVG formally established)
- Approved CPCB ToR v1.0 (CPCB formally established)

**Dependencies:**

- Circulated Draft Governance ToRs

### 8. PMO initiates competitive Lot A/B/C (Sensors/Algorithms) and Lot 'Integration/Edge/Network' RFPs, prioritizing Lot A/B procurement execution.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Issued RFP for Lots A/B/C (Sensor/Algorithm)
- Issued RFP for Integration/Edge/Network

**Dependencies:**

- Approved PSC ToR v1.0

### 9. CPCB contracts the independent IV&V partner, mandating quarterly Red-Teaming cadence starting pre-PDR.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- IV&V Partner Contract Signed (including quarterly Red-Team schedule)
- Initial Zero-Trust Architecture Document Drafted

**Dependencies:**

- Approved CPCB ToR v1.0
- Authorized initial IV&V budget release

### 10. PMO finalizes the integrated 24-month Gantt chart, incorporating the planned deferral of Team C (RF/Acoustic) integration until Post-IOC.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Integrated Gantt Chart v1.0 (Phase 1 focus on A/B)

**Dependencies:**

- Approved PSC ToR v1.0
- Strategic Decision: Sensor Modality Integration Strategy implemented

### 11. TIVG defines the mandatory technical baseline specifications for PTP synchronization error (≤1ms) and DLT control points (≥6 surveyed points) required for M+4 PDR.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- PTP Synchronization Specification Document
- Geodesy Requirements Specification for Initial Control Survey

**Dependencies:**

- Senior Geodesy Engineer On-boarded
- Network Synchronization Specialist On-boarded

### 12. PMO establishes the 'metadata-first' EDXP data schema baseline (pre-wrapper) and defines the temporary ASTERIX simulation requirements for M+18 testing.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- EDXP Specification v0.1 (Internal Baseline)
- ASTERIX Simulation Validation Plan

**Dependencies:**

- Strategic Decision: Standardization and Data Export Strategy enacted (Wrapper path)

### 13. PMO coordinates with CPH/AAL site leads to submit the unified Operational Compliance Document seeking EASA/CAA waivers for 10-40m mounting heights.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Formal EASA/CAA Waiver Submission Package

**Dependencies:**

- Integrated Gantt Chart v1.0
- Approved PSC ToR v1.0 (Regulatory oversight)

### 14. PMO finalizes framework agreements for Lots A/B/C and Integration/Edge, locking in standardized edge node hardware (GPU/TPM) to meet logistical SLO requirements.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 14 (M+1 Month Approx.)

**Key Outputs/Deliverables:**

- Signed Framework Agreements for Sensor Lots and Integration/Edge Procurement
- Standardized Edge Node Hardware Specification locked

**Dependencies:**

- Issued RFP for Lots A/B/C (Sensor/Algorithm)
- Strategic Decision: Edge Processing Heterogeneity Mandate enacted (Standardization)

### 15. TIVG oversees the initial site survey (CPH/AAL) utilizing the Geodesy Engineer to establish the initial six surveyed control points and deploy the PTP Grandmaster.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 14-18

**Key Outputs/Deliverables:**

- Six Verified Control Points established at CPH and AAL per site
- PTP Grandmaster operational and confirming sub-1ms sync error across initial network segment

**Dependencies:**

- Geodesy Requirements Specification for Initial Control Survey
- Network Synchronization Specialist On-boarded

### 16. PMO deploys the Real-Time Performance Monitoring System infrastructure (Dashboard, Sensor Integration) capable of receiving preliminary EDXP data feeds for readiness monitoring.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 18

**Key Outputs/Deliverables:**

- RT Performance Monitoring System (Dashboard) operational baseline

**Dependencies:**

- Standardized Edge Node Hardware Specification locked
- EDXP Specification v0.1 (Internal Baseline)

### 17. CPCB conducts initial audit verifying CPH/AAL edge node images adhere to Zero-Trust primitives (Secure Boot, TPM identity configuration) ahead of sensor integration.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 20

**Key Outputs/Deliverables:**

- Initial Edge Hardening Audit Report
- Confirmation of TPM identity assignment

**Dependencies:**

- Initial Edge Hardening Audit Report
- Standardized Edge Node Hardware Specification locked

### 18. PMO coordinates with Sensor Lots A/B vendors to begin integrating the initial optical/thermal payloads onto the standardized edge nodes, beginning feature extraction testing.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 20-24

**Key Outputs/Deliverables:**

- Functional Optical/Thermal data stream from prototype edge node

**Dependencies:**

- Signed Framework Agreements for Sensor Lots
- Standardized Edge Node Hardware Specification locked

### 19. TIVG executes initial DLT resection and JPDA/MHT-lite fusion testing on integrated A/B streams, targeting margin validation against the 70ms edge budget and DLT accuracy KPIs.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 25-28 (Leading to M+4 PDR)

**Key Outputs/Deliverables:**

- Edge Fusion Benchmark Report (70ms budget validation)
- Initial 3D Accuracy Projections Report

**Dependencies:**

- Functional Optical/Thermal data stream from prototype edge node
- PTP Synchronization Specification Document

### 20. CPCB contracts and initiates the first external, quarterly Red-Teaming exercise against the integrated A/B edge hardware/software baseline.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 28 (Pre-PDR)

**Key Outputs/Deliverables:**

- Initial Red-Team Execution Report

**Dependencies:**

- IV&V Partner Contract Signed

### 21. Formal Project Definition Review (PDR) Gate: PSC reviews technical progress (A/B only), budget alignment, and regulatory waiver status before authorizing full cluster procurement and Site Integration Phase.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 4 (M+4)

**Key Outputs/Deliverables:**

- PDR Gate Approval/Rejection
- Authorized release of funds for Phase 1 Cluster procurement

**Dependencies:**

- Edge Fusion Benchmark Report (70ms budget validation)
- Formal EASA/CAA Waiver Submission Package received (even if pending)
- Initial Red-Team Execution Report

### 22. PMO initiates delivery and site integration of the first batch of certified Optical/Thermal Sensor Clusters (Team A/B) at CPH and AAL, immediately establishing weekly RTK-GNSS flight charter.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 5-8 (Post-PDR)

**Key Outputs/Deliverables:**

- Cluster Installation Begins at CPH/AAL
- Weekly RTK-GNSS Flight Charter operational

**Dependencies:**

- PDR Gate Approval/Rejection
- Authorized release of funds for Phase 1 Cluster procurement

### 23. TIVG begins utilizing weekly RTK-GNSS data to feed dedicated Landmark Resection/Drift Check mechanism, focusing on predictive modeling for geometric stability (Decision 2 implementation).

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 5 onwards

**Key Outputs/Deliverables:**

- Weekly Geometric Health Check Reports
- Predictive Drift Model v0.1

**Dependencies:**

- Weekly RTK-GNSS Flight Charter operational

### 24. PMO finalizes procurement for the specialized edge hardware (Lot C components) intended for RF/Acoustic processing, but holds integration until Post-IOC/M+18 clearance.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 7

**Key Outputs/Deliverables:**

- Team C Hardware Contract Awarded

**Dependencies:**

- PDR Gate Approval/Rejection

### 25. CPCB audits the implementation of the simplified Countermeasure Synchronization Policy (bypass ADVISORY/WARNING for auto-action) and verifies auto-slew verification readiness based on CRITICAL state linkage.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 9

**Key Outputs/Deliverables:**

- Countermeasure Automation Validation Report

**Dependencies:**

- Strategic Decision: Countermeasure Synchronization Triggering Policy enacted (Bypass policy)

### 26. Integration Teams begin work on preliminary EDXP to ASTERIX wrapper translation (simulated validation path) required for basic M+18 compliance.

**Responsible Body/Role:** Lead Technical Architect (Interface Manager, under PMO)

**Suggested Timeframe:** Project Month 9-10

**Key Outputs/Deliverables:**

- EDXP-ASTERIX Wrapper v0.5 ready for integration testing

**Dependencies:**

- EDXP Specification v0.1 (Internal Baseline)
- Strategic Decision: Standardization Strategy enacted (Wrapper path)

### 27. Formal Critical Design Review (CDR) Gate: PSC reviews integrated performance (A/B only), final hardware designs, and readiness for operational CONOPS validation setups.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 10 (M+10)

**Key Outputs/Deliverables:**

- CDR Gate Approval/Rejection
- Go/No-Go decision on EDXP Wrapper viability for Pilot Acceptance

**Dependencies:**

- Weekly Geometric Health Check Reports
- Countermeasure Automation Validation Report
- EDXP-ASTERIX Wrapper v0.5 ready for integration testing

### 28. PMO formalizes the Operational Handover CONOPS Model training materials (ADVISORY/WARNING/CRITICAL states) based on the finalized response policy.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 11-13

**Key Outputs/Deliverables:**

- CONOPS Training Package v1.0 (Tri-State Model)

**Dependencies:**

- CDR Gate Approval/Rejection
- Strategic Decision: Operational Handover CONOPS Model (Tri-State)

### 29. TIVG oversees the completion of the Calibration Handbook and Test Cards utilizing consolidated A+B cluster data from CPH/AAL pilot sites.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 13-16

**Key Outputs/Deliverables:**

- Final Calibration Handbook v1.0
- Full Test Card Matrix Completion

**Dependencies:**

- Weekly Geometric Health Check Reports

### 30. CPCB executes the second Quarterly Red-Teaming exercise, focusing specifically on the data pipeline security and the metadata retention/auto-redaction controls.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 15

**Key Outputs/Deliverables:**

- Q2 Red-Team Report (Privacy/Data Focus)

**Dependencies:**

- Initial Edge Hardening Audit Report

### 31. PMO initiates the Integrated Training and Simulation Program, developing scenarios specifically focused on the M+18 acceptance environment (A/B sensor validation, CRITICAL state response).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Month 16-17

**Key Outputs/Deliverables:**

- Simulation Environment Ready for Operator Trials
- Integrated Training Plan v1.0

**Dependencies:**

- CONOPS Training Package v1.0 (Tri-State Model)

### 32. PMO conducts system-level stress tests against all core KPIs (Pd, Accuracy, Latency, Availability) using the simulated environment and operator task tracking.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 17-18

**Key Outputs/Deliverables:**

- Pre-Acceptance KPI Test Report (Pass/Fail assessment)

**Dependencies:**

- Final Calibration Handbook v1.0
- Simulation Environment Ready for Operator Trials

### 33. Formal Pilot Acceptance Gate (M+18): PSC reviews KPI pass status (A/B fusion only), documentation completeness (Handbook, Heatmaps), and confirmation of operator proficiency/live exercise completion.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 18 (Mid-2027)

**Key Outputs/Deliverables:**

- Pilot Acceptance Gate Approval/Rejection
- Decision to Fund Phase 2 (Release of €150M tranche)

**Dependencies:**

- Pre-Acceptance KPI Test Report (Pass/Fail assessment)
- Confirmation of Pilot Site Live Exercises Completed

### 34. Upon Pilot Acceptance, PMO authorizes integration of Team C (RF/Acoustic) components onto the standardized edge nodes, initiating necessary firmware updates for heterogeneity adaptation.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 19

**Key Outputs/Deliverables:**

- Team C Hardware Integration Commenced
- Edge Node Firmware Update Rollout v1.1

**Dependencies:**

- Pilot Acceptance Gate Approval/Rejection
- Team C Hardware Contract Awarded

### 35. CPCB mandates the start of full NATO/STANAG protocol translation engineering effort, utilizing the PMO resources liberated by deferring geometric re-survey post-M+18.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 19

**Key Outputs/Deliverables:**

- Formal NATO/STANAG Translation Project Initiation

**Dependencies:**

- Pilot Acceptance Gate Approval/Rejection

### 36. PMO signs framework agreements for Phase 2 rollout (30 airports), focusing initial deployments on sites requiring NATO/STANAG feeds validation.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 20

**Key Outputs/Deliverables:**

- Phase 2 Procurement Contracts Finalized and Initiated

**Dependencies:**

- Decision to Fund Phase 2 (Release of €150M tranche)

### 37. Formal Down-select / Production Readiness Review (PRR) Gate: PSC reviews integrated A/B/C performance (initial Team C integration) and readiness for wide-scale rollout, including updated security posture.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 20 (M+20)

**Key Outputs/Deliverables:**

- PRR Gate Approval/Rejection

**Dependencies:**

- Team C Hardware Integration Commenced
- Q2 Red-Team Report (Privacy/Data Focus) remediation closure

### 38. TIVG begins quality checks on the NATO/STANAG translation layer based on initial output from the dedicated translation engineers, aiming for M+22 verification.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 20-22

**Key Outputs/Deliverables:**

- NATO/STANAG Translation Layer Functional Test Results

**Dependencies:**

- Formal NATO/STANAG Translation Project Initiation

### 39. Formal Interim Operational Capability (IOC) Gate: PSC verifies successful ingestion of real-time data feeds by NATO/Member-State systems using the developing translation layer at initial Phase 2 sites.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 22 (M+22)

**Key Outputs/Deliverables:**

- IOC Gate Approval/Rejection

**Dependencies:**

- NATO/STANAG Translation Layer Functional Test Results (Initial Link Verified)

### 40. PMO, supported by CPCB, ensures all 30 Phase 2 sites meet Zero-Trust hardening (Immutable OS, mTLS) and SOC monitoring is active across the expanded cluster footprint.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 23

**Key Outputs/Deliverables:**

- Full SOC Monitoring Activation Across All Nodes

**Dependencies:**

- PRR Gate Approval/Rejection
- IOC Gate Approval/Rejection

### 41. Final comprehensive Cyber Red-Team exercise conducted across the integrated A/B/C system running on Phase 2 infrastructure to confirm system resilience prior to FOC.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 23

**Key Outputs/Deliverables:**

- Final Pre-FOC Security Clearance Report

**Dependencies:**

- IOC Gate Approval/Rejection

### 42. Formal Full Operational Capability (FOC) Gate: PSC reviews final acceptance criteria, including full KPI demonstration (A/B/C fusion, full latency), final NATO/STANAG interface sign-off, and Cyber Clearance.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 24 (M+24)

**Key Outputs/Deliverables:**

- FOC Gate Approval (Program Completion)
- Final Program Closure Report

**Dependencies:**

- Final Pre-FOC Security Clearance Report
- All 30 Phase 2 sites provisioned and reporting continuity/availability KPIs

# Decision Escalation Matrix

**Request for major scope change impacting baseline (e.g., integrating RF/Acoustic Team C sensors before M+18 Pilot Acceptance)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC Vote requiring consensus or Chair's casting vote.
Rationale: Alters the core strategy chosen for de-risking the M+18 gate (Decision 1), affecting technical feasibility and schedule adherence.
Negative Consequences: Mandatory schedule slip (likely threatening M+18/M+20 gates) and budget overrun from integrating complex, deferred sensor modalities early.

**Technical Deadlock: PTP Sync Error exceeds 1ms tolerance or DLT Fusion Budget (70ms) failure reported by TIVG.**
Escalation Level: Technical Integrity & Verification Group (TIVG)
Approval Process: Unanimous technical agreement required within TIVG; failure escalates automatically.
Rationale: Threatens the fundamental engineering requirements for 3D accuracy KPI (<1.0m P50), which is a non-negotiable technical dependency for acceptance.
Negative Consequences: Inability to certify geometric fidelity, leading to potential M+4 PDR failure or guaranteed failure of the 3D accuracy KPI validation at M+18.

**Materialization of Critical Security Vulnerability: External Red-Teaming identifies a critical exploit invalidating Zero-Trust architecture before M+10 CDR.**
Escalation Level: Cyber, Privacy, and Compliance Board (CPCB)
Approval Process: Unanimous agreement required on issuing a 'Cyber Security Stop Work Order'; immediate notification to PSC.
Rationale: Direct violation of the front-loaded security governance mandate, risking stakeholder trust and regulatory non-compliance before IOC.
Negative Consequences: Mandatory Stop Work Order on integration streams, potential regulatory fine, and significant cost overrun for emergency remediation (Risk 7 amplification).

**Budget Request exceeding PMO financial authority (e.g., securing an unfunded, mandatory RTK-GNSS re-survey projected >€3.0M post-M+18).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC approval required based on review of justification linking necessity to KPI adherence, affecting the unapproved Phase 2 budget tranche.
Rationale: Requires allocation of strategic contingency budget or re-prioritization of Phase 2 funding, directly impacting the long-term viability of the program past M+18.
Negative Consequences: If unapproved, geometric drift persists, leading to guaranteed KPI failure (<2.0m P90) and jeopardizing IOC/FOC sign-off.

**Conflict regarding implementation of Countermeasure Policy: Requires delay in automated slew verification to ensure human decision safety exceeds 750ms latency KPI.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must adjudicate the trade-off between the human safety assurance policy and the mandated latency KPI constraint (Decision 5).
Rationale: Represents a direct conflict between operational safety/CONOPS rigor and a hard, non-negotiable performance target (≤750ms UI latency).
Negative Consequences: Failure to resolve cleanly results in either sacrificing core latency KPI compliance or creating an unacceptably risky automated response chain that violates governmental safety expectation for manual intervention.

**Material delay (>2 weeks) in essential Phase 1 procurement lot delivery (e.g., GPU/TPM hardware from Lot A/B/C) threatening M+10 CDR progress.**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO leadership holds authority to enforce vendor contractual recovery plans below the financial threshold, but must escalate schedule threat.
Rationale: Operational risk requiring immediate schedule enforcement and resource reassignment below the PSC's strategic decision threshold, per PMO responsibilities.
Negative Consequences: If the PMO cannot enforce schedule recovery, the technical integration timelines leading into CDR will fail deadlines, requiring PSC intervention for scope adjustment post-M+10.

# Monitoring Progress

### 1. KPI Dashboard Monitoring (Real-Time Performance System)
**Monitoring Tools/Platforms:**

  - RT Performance Monitoring System (Dashboard)
  - Edge Node Telemetry Logs (for Latency/Availability)
  - JIDA/MHT-lite Fusion Output Data Stream

**Frequency:** Continuous / Real-time aggregation

**Responsible Role:** Project Management Office (PMO)

**Adaptation Process:** PMO uses immediate deviation alerts to assign corrective engineering tasks to relevant integration teams (under PMO authority) or requests immediate review by TIVG if deviation is systematic.

**Adaptation Trigger:** Latency (edge-to-bus) > 200ms for 5 consecutive seconds OR Availability drops below 99.5% for any airport cluster OR False Alerts exceed 5/hour (P95 trigger).

### 2. Geometric Health Check and Drift Monitoring (Critical Success Factor: 3D Accuracy)
**Monitoring Tools/Platforms:**

  - Weekly Geometric Health Check Reports (from TIVG)
  - RTK-GNSS Flight Data Logs
  - Predictive Drift Model

**Frequency:** Weekly

**Responsible Role:** Technical Integrity & Verification Group (TIVG)

**Adaptation Process:** TIVG determines the rate of drift; if drift exceeds 50% of the margin toward the P90 SLA, TIVG formally flags the issue to the PSC for a strategic decision on initiating an emergency re-survey budget allocation (escalation path).

**Adaptation Trigger:** Weekly drift analysis shows projected P90 3D accuracy exceeding 2.0m within 6 months OR Landmark Resection failure rate increases by 15% over the last measurement.

### 3. Sensor Modality Performance Verification (Tracking Pd/Classification)
**Monitoring Tools/Platforms:**

  - Scenario-based KPI Test Reports (Day/Night/Adverse Weather Scenarios)
  - Integrated Gantt Chart milestone verification points

**Frequency:** Post-Scenario Completion (leading up to CDR and Pilot Acceptance)

**Responsible Role:** Project Management Office (PMO) supported by IV&V

**Adaptation Process:** If Phase 1 (A/B fusion) fails to achieve Pd ≥90% (Day) or Pd ≥80% (Night/Poor Wx) by M+18, the PSC must adjudicate between scope reduction (accepting lower Pd) or allocating Phase 2 contingency budget for accelerated Team C integration and testing (Decision 1 conflict resolution).

**Adaptation Trigger:** Failure to meet target Pd or Accuracy KPIs during formal M+18 Pilot Acceptance testing using A/B sensor data.

### 4. Cybersecurity & Zero-Trust Compliance Cadence (Major Risk: Security)
**Monitoring Tools/Platforms:**

  - Quarterly Red-Team Execution Reports (IV&V)
  - CPCB Audit Reports (SLSA/TPM/Patch SLO adherence)
  - SOC Monitoring Logs

**Frequency:** Quarterly (Red-Teaming) / Bi-weekly (Internal Audit)

**Responsible Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Adaptation Process:** Any critical finding (escalated by CPCB) triggers an immediate Security Stop Work Order on the relevant stream until remediation is validated by CPCB and confirmed closed by the next Red-Team report. Non-critical findings result in remediation tasks tracked against the 7-day critical patch SLO.

**Adaptation Trigger:** Identification of a critical vulnerability in the Zero-Trust implementation or failure to close a critical finding within the mandatory 7-day Patch SLO.

### 5. Governance Gate Progress Review and Schedule Adherence
**Monitoring Tools/Platforms:**

  - Integrated Gantt Chart (v1.0)
  - PSC Meeting Minutes and Gate Approval Records

**Frequency:** Tied to Mandated Gates (M+4 PDR, M+10 CDR, M+18 Pilot Acceptance, M+20 PRR, M+22 IOC, M+24 FOC)

**Responsible Role:** Project Steering Committee (PSC)

**Adaptation Process:** If critical path items threaten any governance gate by more than 2 weeks, the PSC convenes an emergency session to authorize schedule reallocation, contingency spending (from PSC authority), or scope modification (e.g., formally accepting the deferred approach of Decision 3).

**Adaptation Trigger:** Notification from PMO that any major milestone defining a future governance gate is greater than 14 days behind schedule baseline.

### 6. Protocol Standardization Compliance (EDXP Mapping)
**Monitoring Tools/Platforms:**

  - NATO/STANAG Translation Layer Functional Test Results
  - ASTERIX Simulation Validation Plan status

**Frequency:** Monthly (Post-M+18)

**Responsible Role:** Technical Integrity & Verification Group (TIVG)

**Adaptation Process:** If M+22 IOC verification of NATO feed connectivity fails due to protocol mapping issues (despite the wrapper use), the PSC must execute the decision escalation matrix to reallocate resources immediately from Phase 2 rollout stabilization to the TIVG/Translation effort.

**Adaptation Trigger:** Failure to demonstrate valid, authenticated data exchange with NATO test systems by M+22 IOC milestone.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core components of the governance framework appear to be generated, including internal governance bodies, implementation plans, decision escalation matrix, and monitoring progress plans.
2. Internal Consistency Check: The governance bodies align with the implementation plan, ensuring that the Project Steering Committee (PSC) oversees the PMO and TIVG, and that the decision escalation matrix reflects the appropriate escalation paths for issues identified in the monitoring progress plan.
3. Potential Gaps / Areas for Enhancement: 1) Clarity of roles: The responsibilities of the independent IV&V partner need to be explicitly defined to ensure accountability in the governance structure. 2) Process Depth: The conflict of interest management process should be detailed, including specific steps for reporting and addressing conflicts. 3) Integration: The relationship between the monitoring progress plan and the decision escalation matrix could be better articulated to ensure that monitoring results directly inform escalation decisions. 4) Specificity: The thresholds for escalation in the decision escalation matrix should be more clearly defined, particularly regarding what constitutes a 'material delay' or 'critical vulnerability.' 5) Delegation: There should be more granular delegation of authority within the PMO for operational decisions below the PSC level to enhance responsiveness.

## Tough Questions

1. What specific measures are in place to ensure that the independent IV&V partner's findings are acted upon promptly, and how will their effectiveness be evaluated?
2. Can you provide evidence of how conflicts of interest will be managed, particularly regarding procurement decisions that could impact the project's integrity?
3. What contingency plans are in place if the monitoring progress reveals that KPIs are not being met, particularly regarding the 3D accuracy and latency requirements?
4. How will the governance bodies ensure that the project remains compliant with EASA regulations throughout the lifecycle, especially in light of potential regulatory changes?
5. What specific criteria will be used to determine if a budget request exceeding PMO authority is justified, and who will make that determination?
6. How will the project handle a situation where a critical vulnerability is identified during a red-team exercise, and what are the timelines for remediation?
7. What processes are in place to ensure that the results of the quarterly audits by the CPCB are transparently communicated to all stakeholders?

## Summary

The governance framework for the SkyNet Sentinel project is robust, incorporating multiple oversight bodies and a detailed implementation plan to ensure compliance with EASA regulations and project objectives. Key strengths include a clear decision escalation matrix and a comprehensive monitoring progress plan. However, there are areas for enhancement, particularly in clarifying roles, detailing processes for conflict management, and ensuring that escalation thresholds are specific and actionable. The proactive approach to risk management and accountability will be crucial for navigating the complexities of this high-stakes project.