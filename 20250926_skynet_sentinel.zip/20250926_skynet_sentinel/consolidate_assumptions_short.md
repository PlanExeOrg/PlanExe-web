# Purpose
# Project Plan: EASA Real-Time Small UAS Localization Program

## Purpose

- Large-scale, multi-year, multi-hundred-million-euro infrastructure and technology deployment program.
- Aimed at national/international safety, security, and air traffic management (societal/governmental initiative).
- Complex engineering, strict performance KPIs, phased rollout across multiple airports, procurement, governance.
- Technical standardization (mapping to EUROCONTROL/ASTERIX and NATO/STANAG).
- Major societal/commercial project.

## Topic

- Development and deployment of an EASA program for real-time unauthorized small UAS (sUAS) localization.


# Plan Type
# SkyNet Sentinel Deployment Plan

## Infrastructure Requirements

- Requires one or more physical locations.
- Cannot be executed digitally.

## Deployment Scope

- Full lifecycle deployment of physical surveillance and tracking infrastructure ('SkyNet Sentinel').
- Involves tangible physical elements at multiple airports.

## Key Physical Activities

- Installing and calibrating irregular PTZ camera clusters (heights: 10–40 m; baselines: 300–800 m).
- Site preparation.
- Sensor integration.
- Running RTK-GNSS reference flights.
- Conducting live exercises at airports.
- Deploying edge nodes with hardware security features (TPM/GPU).

## Locations

- Rollout across multiple physical airport locations: CPH, AAL, and 30 others.


# Physical Locations
# Requirements for physical locations

- Ability to install sensor clusters at 10–40 m height
- Space for 300–800 m sensor baselines
- Access to secure physical space for edge nodes (GPU/TPM)
- Proximity/access to RTK-GNSS reference flight support
- Must be a major airport location (Phase 1: CPH, AAL)

## Location 1
Denmark
Copenhagen Airport (CPH)
Designated perimeter or secure rooftop zones.
Rationale: Mandated Phase 1 pilot location for 2026 (€50M tranche). Requires 12-18 clusters and KPI acceptance tests.

## Location 2
Hungary
Budapest Ferenc Liszt International Airport (AAL)
Designated perimeter or secure rooftop zones.
Rationale: Second mandated Phase 1 pilot location for 2026. Essential for initial geometry qualification and proving cluster deployment viability on a European airport.

## Location 3
European Union
Tier 1 European Hub Airport (Hypothetical)
A major, high-traffic EU airport not currently selected.
Rationale: Establish a third reference site to diversify environmental baseline data (weather, air traffic profile) prior to Phase 2 rollout targeting 30 airports.

## Location 4
Germany
Frankfurt Airport (FRA) or Munich Airport (MUC)
Rooftop infrastructure or adjacent testing ranges accessible from main airport facilities.
Rationale: As a major EUROCONTROL hub, a German airport provides a robust environment to stress-test NATO/ASTERIX data mapping and connectivity required for Phase 2 validation under high-density air traffic.

## Location Summary
CPH and AAL are mandatory for the initial 2026 pilot phase, requiring 10-40m vertical infrastructure for sensors. Two additional major EU airports are suggested to diversify readiness testing for the 30-airport Phase 2 rollout.

# Currency Strategy
# Project Plan

## Currencies

- EUR: Program budget (€200M), core oversight (EASA). Operational/budgeting standard.
- DKK: Local expenditures (Copenhagen Airport - CPH).
- HUF: Local expenditures (Budapest Airport - AAL).
- USD: Procurement (specialized sensors: PTZ optics, GPU/TPM hardware, GPSDO units).

Primary currency: EUR

Currency strategy: Budget/contracts in EUR (EASA aligned). Local budgets (DKK at CPH, HUF at AAL) converted from EUR. Manage minor fluctuations.

# Identify Risks
## Risk 1 - Regulatory & Permitting

- Delays in obtaining EASA/local approvals threaten timelines, especially acceptance gates.
- Impact: 4–8 week delay; €1M–€2M increased cost.
- Likelihood: Medium
- Severity: High
- Action: Engage regulatory bodies early; schedule regular check-ins.

## Risk 2 - Technical

- Integration challenges between sensor modalities (optical, thermal, RF/acoustic) cause performance issues in adverse weather.
- Impact: 2–4 week delay if detection KPI of ≥80% fails; €500,000–€1M re-engineering cost.
- Likelihood: High
- Severity: High
- Action: Prioritize optical/thermal integration first; defer RF/acoustic; conduct thorough testing.

## Risk 3 - Financial

- Procurement delays or price increases in critical components (GPUs, sensors) cause cost overruns.
- Impact: €5M–€10M additional cost; potential scope reduction.
- Likelihood: Medium
- Severity: High
- Action: Establish fixed-price contracts; maintain 10% contingency budget.

## Risk 4 - Environmental

- Installation may face scrutiny regarding wildlife impacts and local regulations.
- Impact: 2–3 month installation delay; €100,000–€500,000 fines.
- Likelihood: Medium
- Severity: Medium
- Action: Conduct thorough environmental impact assessments early; engage local groups.

## Risk 5 - Operational

- Insufficient personnel readiness to manage new systems delays KPI achievement in the pilot phase.
- Impact: 1–2 month operational readiness delay; €200,000–€400,000 additional training cost.
- Likelihood: Medium
- Severity: High
- Action: Implement comprehensive training program early; use simulation exercises.

## Risk 6 - Supply Chain

- Disruptions in critical component supply delay timelines and increase costs.
- Impact: 4–6 week delivery delay; €1M–€3M costs from expedited shipping/sourcing.
- Likelihood: High
- Severity: Medium
- Action: Diversify suppliers; maintain buffer stock.

## Risk 7 - Security

- Cybersecurity vulnerabilities may cause data breaches or operational failures (Zero-Trust architecture).
- Impact: €2M–€5M remediation cost; loss of stakeholder trust; regulatory fines.
- Likelihood: Medium
- Severity: High
- Action: Conduct regular security audits and penetration testing; ensure compliance.

## Risk summary

- Significant risks: technical integration, regulatory approvals, cybersecurity.
- Critical risks: sensor integration impacting KPIs, regulatory timeline delays.
- Mitigation focuses: early stakeholder engagement, prioritizing critical integrations, robust training/security protocols.


# Make Assumptions
## Budget Allocation Breakdown (€200M)

### Sensor/Algorithm A/B/C, Integration/Edge/Network, IV&V

*   Assumptions: Budget aligns with deferring Team C (RF/Acoustic) to Phase 2.
    *   Phase 1 (€50M) allocation: 70% to A/B integration/calibration, 20% to Integration/Edge (pilot CPH/AAL), 10% to essential PDR/CDR IV&V.
*   Assessments: Financial Allocation Risk Assessment
    *   Risk shifts to component procurement lead times (PTZ/Thermal) if 70% Phase 1 commits to A/B.
    *   Opportunity: Pre-negotiate Team C sensor pricing using M+4 PDR gate to lock Phase 2 pricing, mitigating Risk 3 (Financial).

## M+18 Demonstration Mandate (CDR M+10 to Pilot M+18)

### Software Version and KPI Verification Dataset Mapping

*   Assumptions: M+18 Pilot Acceptance requires only core tracking KPIs (Pd, 3D Accuracy, Latency) verified against internal EDXP v0.9 format. Compliance to a *simulated* ASTERIX schema only; full NATO/STANAG mapping deferred to FOC (M+24).
*   Assessments: Timeline Constraint Compliance Assessment
    *   Deferring standard certification to FOC de-risks M+18 gate (reducing Risk 1: Regulatory delay).
    *   Latency KPI validation must focus on edge-to-bus component (≤200ms).

## Q4-2025 Mobilization Requirements (PTP Sync ≤1 ms, DLT Geometry ≥6 points Pre-M+4 PDR)

### Required Personnel Roles

*   Assumptions: Q4-2025 mobilization requires one dedicated Senior Geodesy Engineer and one Network Synchronization Specialist for site surveying/PTP grandmaster setup, concurrent with initial RFPs.
*   Assessments: Resources and Personnel Readiness Assessment
    *   Failing to staff Geodesy role threatens 3D accuracy KPI (Risk 2: Technical).
    *   Opportunity: Cross-train infrastructure staff in IEEE-1588 maintenance to reduce reliance on external RTK flight crews (Decision 2 scheduling dependency).

## EASA Waiver Process and National Jurisdiction (CPH/AAL 30–40m Deployment)

### Waiver Process and Testing Authority

*   Assumptions: EASA requires Type Certificate deviation/operational waiver for 30–40m sensor heights. Jurisdiction defaults to Danish CAA (CPH) and Hungarian CAA (AAL), overseen by EASA Steering Committee.
*   Assessments: Governance and Regulatory Compliance Assessment
    *   Risk 1 (Regulatory Delay) is high due to non-standard mounting and dual national CAAs.
    *   Mitigation: Create unified 'SkyNet Sentinel Operational Compliance Document' centralized via EASA Steering Committee before M+4.

## Weekly Drift Checks (Landmark Resection/RTK-GNSS) vs. Integration Testing Conflict

### Procedure Detail and Flight Profile

*   Assumptions: Post-PDR (M+4) adopts 'Low-Intensity Calibration Profile': 4 hours dedicated RTK-GNSS flight time weekly per airport cluster pair (CPH/AAL combined), sourced via local contractor, within contingency budget.
*   Assessments: Safety and Risk Management for Geometric Maintenance
    *   Weekly flights introduce operational risk (Risk 6: Supply Chain/Access). Failure to secure 4-hour slot impacts geometric alignment/accuracy KPIs.
    *   Opportunity: Use RTK data logging to create high-fidelity training scenarios (linking to Decision 9).

## 'Metadata-First' Transport (≤30-day Retention/Auto-Redaction) Interface with Phase 2 NATO Feeds

### Data Retention and Phase 2 Verification

*   Assumptions: System supports two paths: immutable operational log (≤30 days) and fully processed, standardized archive copy (STANAG mapped) finalized by M+18.
*   Assessments: Environmental and Data Stewardship Assessment
    *   Short retention aids reduced storage footprint/compliance burden.
    *   Risk: If STANAG mapping standardization lags PDR/CDR, Phase 2 data sharing becomes non-compliant with Member-State agreements.

## CONOPS Conflict Resolution (ADVISORY State Manual Intervention vs. Automated Countermeasure Bypass)

### Conflict Resolution Mechanism

*   Assumptions: ADVISORY triggers mandatory, real-time media pull-on-demand for operator context via UI (≤750ms latency path), despite automated countermeasures bypassing ADVISORY/WARNING states.
*   Assessments: Stakeholder Involvement and CONOPS Validation Assessment
    *   Automated response simplification (Decision 5) relies heavily on operator readiness (Risk 5).
    *   M+18 testing must focus on the 'manual escalation loop' to ensure system supports expert decision-making, validating high availability KPI (≥99.5%).

## Edge Node Requirements (DLT Fusion Latency, Keypoint Density) Tied to 3D Accuracy KPI (<1.0 m)

### System Requirements vs. Edge Processing Heterogeneity

*   Assumptions: P50 <1.0m requires JPDA/MHT-lite fusion (including covariance) within 70ms on the edge node, leaving 130ms budget for detection/tracking/keypoint extraction (to meet 200ms edge-to-bus KPI).
*   Assessments: Operational Systems Performance Threshold Assessment
    *   70ms fusion budget is tight if A/B sensors fuse by M+10. Failure stalls accuracy KPIs pre-CDR.
    *   'Immutable edge OS' must prove zero runtime overhead vs. baseline Linux to meet this hard constraint.

# Distill Assumptions
# Project Plan Summary

## Phase 1 & Budget

- Phase 1 (€50M): 70% to Teams A/B integration and calibration tooling.
- Budget: Primary financial risk is Phase 1 due to high-end PTZ/Thermal procurement lead times.
- Procurement: Merges Sensor Lots A/B/C into one contract, concentrating technical risk until Phase 2.

## Timeline & Acceptance

- M+18 acceptance: Uses internal EDXP v0.9; ASTERIX simulation required; STANAG deferred to FOC.
- Countermeasure integration isolated until FOC (M+24) to de-risk M+18.
- Deferring protocol certification to FOC de-risks M+18 Timeline Constraint Compliance Assessment.

## Technical Requirements & Performance

- P50 accuracy (<1.0m) mandates JPDA/MHT-lite fusion completes within 70ms on the standardized edge node.
- Edge fusion budget (70ms) is tight for DLT processing across asynchronous sensor inputs.
- Edge nodes standardize on a single GPU/TPM stack to control logistics and patch SLOs.
- Standardized edge compute simplifies logistics but may cap performance for specialized pipelines.

## Strategy & Integration Sequencing

- Strategy prioritizes Teams A/B fusion; RF/Acoustic (Team C) integration deferred until post-IOC.
- Deferring Team C sensor integration until Phase 2 simplifies M+18 acceptance testing.
- DLT geometry maximizes initial six control points; accepting drift degradation post-M+18.
- Maximizing initial control points accepts post-M+18 geometric drift degradation.

## Data Handling & Logging

- System uses short-term operational log (≤30 days) and a separate STANAG archive finalized by M+18.
- EDXP format uses wrapper conversion for initial KPI testing; delays complex STANAG adherence until FOC.
- Temporary EDXP wrapper delays full STANAG adherence, focusing M+18 on core tracking KPIs.
- Short metadata retention aids environmental impact; archive standardization delays Phase 2 data sharing.

## Operational & Compliance Constraints

- Countermeasure activation bypasses ADVISORY/WARNING states, triggering only on maximum confidence CRITICAL.
- ADVISORY state mandates real-time media pull-on-demand, even if automated countermeasure action is disabled.
- Bypassing ADVISORY states in automation simplifies operator flow but requires robust manual escalation paths.
- Simplified countermeasure automation relies heavily on operator readiness during M+18 testing.
- EASA waiver required for 30–40m PTZ heights; CPH/AAL testing jurisdiction defaults to national CAAs.
- Non-standard mounting height requires unified operational compliance document signed by two CAAs.

## Verification & Resourcing

- Q4-2025 mobilization secures one Senior Geodesy Engineer and one Sync Specialist pre-PDR.
- Failing to staff Geodesy role immediately threatens the 3D accuracy KPI deadline pre-PDR.
- Weekly drift checks require 4 dedicated RTK-GNSS flight hours per airport cluster pair post-PDR.
- Outsourced RTK charter failure risks schedule, impacting weekly geometric alignment checks.
- Accelerated Quarterly red-teaming increases independent IV&V budget significantly before IOC.
- Increased red-teaming frequency dramatically lowers MTTD but strains specialized contractor budget.


# Review Assumptions
## Domain of the expert reviewer
Critical Infrastructure & Mission-Critical Software/Sensor Fusion Project Planning

## Domain-specific considerations

- Adherence to EASA/NATO/STANAG standards
- Precision Geodesy and PTP Synchronization (<1ms error)
- Sensor Fusion (Optical, Thermal, RF, Acoustic) timeline management
- High-Assurance Cyber Security (Zero Trust, SLSA-3+)
- Physical deployment logistics on active international airports

## Issue 1 - Critical Missing Assumption: Long-Term Funding and Full-Program Viability (M+18 to FOC)

- Plan focuses on M+18 Pilot Acceptance; lacks guaranteed funding/mandate for FOC (M+24) sustainment.
- RF/Acoustic fusion (Team C), full STANAG adherence, and geometric re-survey deferred post-IOC/FOC.
- Risk: Funding tranche 2 (€150M) reduction/delay causes partial success but ultimate security objective failure.
- Recommendation: Ratify Assumption for committed M+18 to M+36 funding. Establish Go/No-Go trigger at M+18 for post-acceptance workstreams (Team C, STANAG), tying budget disbursement to M+20 integration sign-off.
- Sensitivity: 6-month delay in €150M tranche post-M+18 incurs penalties/suspension; increases final cost by 15-25% (€22.5M - €37.5M) or forces performance ceiling downgrade.

## Issue 2 - Fragile Reliance on Deferred Geometric Fidelity (DLT Geometry Qualification Velocity)

- 'Builder' strategy accepts geometric drift post-M+18 using only six control points.
- Risk: Gradual drift causes catastrophic failure against high-precision tracking KPI (<1.0m P50, <2.0m P90) over multi-year deployment (30+ sites).
- Recommendation: Quantify max tolerable drift against P90 SLA. Institute mandatory 'Geometric Health Check' KPI by M+12, forcing pre-M+18 re-survey budget review. Re-evaluate RTK flight assumption (Assumption 5) to prioritize predictive drift modeling data collection.
- Sensitivity: 1% cumulative error growth/quarter post-M+18 exceeds P90 KPI by M+28. Correction without dedicated re-survey costs €1.5M-€3.0M, reducing ROI by 3-6%.

## Issue 3 - Unrealistic Risk Mitigation for Dual Standardization Conflict (ASTERIX/STANAG)

- Strategy uses Wrapper solution (Assumption 2), validating only against simulated ASTERIX, deferring full NATO/STANAG mapping to FOC (M+24).
- Risk: Stakeholders will not accept simulated validation for dual-standard mandates; deferred friction becomes legacy debt.
- Recommendation: Immediately assign senior 'Protocol Architect' role (per Assumption 3). KPI: Deliver first authenticated, non-wrapper translation layer for mandatory standard (STANAG) by M+14, utilizing small portion of Integration budget (de-scope edge hardening 2 months).
- Sensitivity: Doubled complexity in dual protocol translation (current estimate: 10% effort deferred) causes mandatory 6-month delay in NATO partner site deployment post-M+24, resulting in -20% NPV impact on M+24 figures.

## Review conclusion
Plan tactically survives M+18 Pilot Acceptance by deferring complexity (Team C, protocol maturity), creating three strategic vulnerabilities: 1) Unknown viability of Phase 2 (€150M) post-M+18 cliff edge. 2) Geometric drift acceptance threatens core accuracy KPI. 3) Wrapper reliance concentrates technical risk into M+18 to FOC window, threatening interoperability. Immediate action needed to validate long-term funding and establish interim geometric stability checks.