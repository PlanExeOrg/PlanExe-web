### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Mandated by the plan and required by EASA oversight. This body handles the high-level strategic direction, gate approvals (PDR, CDR, IOC, FOC), and provides executive oversight for the €200M budget and regulatory compliance (e.g., EASA Type Deviation Waivers for mounting height).

**Responsibilities:**

- Approve/Reject movement between mandatory governance gates (PDR M+4, CDR M+10, Pilot Acceptance M+18, FOC M+24).
- Approve strategic redirection based on KPI failure or major shifts in strategic decisions (e.g., scope change vs. Deferral decisions).
- Provide final authorization for capital expenditure exceeding €5M or critical contractual amendments.
- Oversee high-level regulatory liaison and grant final operational waivers.
- Resolve escalations from the PMO regarding strategic risk exposure or cross-functional conflicts.

**Initial Setup Actions:**

- Formalize and approve the PSC Terms of Reference (ToR), specifically defining authorized financial thresholds.
- Appoint the EASA Chair and secure commitment from all key oversight owners.
- Establish data classification and distribution policy for PSC meeting minutes and gate reports.

**Membership:**

- EASA Executive Sponsor (Chair)
- Head of Program Management Office (PMO)
- Lead of Independent Verification & Validation (IV&V) Partner (Non-voting Assurance Role)
- Senior Legal/Regulatory Counsel (Internal Expert)

**Decision Rights:** All strategic direction, gate progression decisions, budget authority > €5M, and final approval on Phase 1 to Phase 2 resource allocation shifts.

**Decision Mechanism:** Consensus required, with the EASA Chair holding the final casting vote in case of irreconcilable strategic deadlock. Decisions must be formally minuted.

**Meeting Cadence:** Monthly for the first 6 months (Mobilization/PDR); then tied to major gate reviews (PDR M+4, CDR M+10, Pilot Acceptance M+18, etc.).

**Typical Agenda Items:**

- Status of Critical Path Milestones vs. Schedule Gates.
- Review of Strategic Risk Register top 5 entries (focusing on timeline/budget risks).
- Formal Gate Review Presentation and Go/No-Go Recommendation.
- Escalation review from the PMO.

**Escalation Path:** N/A (Highest internal oversight body). Conflict resolution outside this body requires appeal to the relevant EASA Director General or relevant Ministerial body if regulatory scope is exceeded.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Required to manage the day-to-day €200M execution, enforce the rigid 24-month schedule, coordinate procurement across three specialized lots, and integrate the outputs of the Core Technical Teams against demanding KPIs (e.g., 70ms fusion budget, PTP sync).

**Responsibilities:**

- Manage consolidated schedule, budget (€200M total, €50M Phase 1), and resource allocation.
- Coordinate execution between A/B/C integration teams and the Core Integration/Edge Team.
- Own the KPI measurement dashboard (Decision 10) and report deviations to the PSC.
- Manage procurement framework agreements and mini-competitions details.
- Own the real-time compliance monitoring (Patch SLOs, Latency reporting).

**Initial Setup Actions:**

- Finalize the detailed 24-month integrated Gantt chart compliant with all mandated gates.
- Establish the PMO operational cadence meetings and KPI reporting structure.
- Recruit and assign the Senior Geodesy Engineer and Network Synchronization Specialist (per assumptions).

**Membership:**

- Program Director (PMO Lead/Chair)
- Lead Project Scheduler/Controller
- Lead Technical Architect (Interface Manager)
- Lead Cybersecurity/Compliance Manager
- Core Technical Team Leads (A, B, Integration)

**Decision Rights:** All operational decisions, tactical risk management (below €500k cost impact), assignment of engineering tasks, approval of schedule adjustments within contingency boundaries, and management of the weekly RTK-GNSS flight charter schedules.

**Decision Mechanism:** Simple majority vote among PMO leadership, with the Program Director holding authority to approve low-risk operational deviation or enforce mandatory schedule adherence.

**Meeting Cadence:** Daily synchronization stand-ups (Core Teams Focus); Bi-weekly full PMO operational review.

**Typical Agenda Items:**

- Review of KPI performance (Latency/Availability) vs. Decision 10 Monitoring.
- Procurement Lot status and vendor slippage reports.
- Resolution of technical integration conflicts between sensor pipelines.
- Review of asset utilization (e.g., RTK flight time compliance).

**Escalation Path:** Issues exceeding €500k financial impact, risks threatening M+4 PDR or M+10 CDR progress by >2 weeks, or disputes over strategic execution mandate are escalated immediately to the Project Steering Committee (PSC).
### 3. Technical Integrity & Verification Group (TIVG)

**Rationale for Inclusion:** Given the extreme technical novelty (DLT, PTP sync <1ms, custom fusion algorithms) and high accuracy requirements (<1.0m P50), an internal technical assurance body is vital to enforce engineering rigor before the external IV&V partner certifies readiness. This group specifically validates the complex geometric and synchronization requirements.

**Responsibilities:**

- Perform detailed review of DLT resection/bundle adjustment results and uncertainty propagation models.
- Audit PTP synchronization logs (IEEE-1588/GPSDO) monthly to verify sub-1ms error budget adherence.
- Verify that the standardized edge node meets the 70ms DLT fusion budget requirement.
- Oversee the creation and maintenance of the Calibration Handbook and Test Cards.
- Validate that the 'wrapper-based conversion service' for EDXP is functionally sound for M+18 testing.

**Initial Setup Actions:**

- Define the technical specification required for the Senior Geodesy Engineer and Network Sync Specialist.
- Establish the audit cadence and data formats for PTP log review.
- Define the pass/fail criteria for the edge node 70ms fusion test.

**Membership:**

- Lead System Architect (Chair)
- Senior Geodesy Engineer (Assumed Q4-2025 Hire)
- Network Synchronization Specialist (Assumed Q4-2025 Hire)
- Lead Software Engineer (Fusion/Algorithm Focus)

**Decision Rights:** Can issue 'Hold Orders' on integration testing if PTP sync errors exceed 1ms or if geometric reconstruction indicates potential drift greater than 10% outside model projections. Recommends technical gates to PMO.

**Decision Mechanism:** Unanimous technical agreement is required on certification artifacts; failure to agree mandates immediate escalation of the specific technical failure to the PSC for strategic adjudication.

**Meeting Cadence:** Weekly until CDR (M+10); Bi-weekly post-CDR focusing on drift characterization and KPI verification.

**Typical Agenda Items:**

- PTP Synchronization Health Check Report (Error analysis).
- DLT Extrinsics Stability Review (Control Point vs. Landmark Resection).
- Edge Node Performance Benchmarks (70ms Fusion Test results).
- Review of status of RTK-GNSS flight data utilization.

**Escalation Path:** Failure to reach internal technical consensus regarding geometry or sync stability that threatens the M+18 Pilot Acceptance KPIs is escalated directly to the PSC for strategic decision on technical trade-offs (e.g., funding a full re-survey or accepting lower accuracy).
### 4. Cyber, Privacy, and Compliance Board (CPCB)

**Rationale for Inclusion:** The project has extensive, front-loaded security and privacy mandates (Zero-Trust, SLSA-3+, GDPR, metadata retention ≤30 days). An independent board is necessary to ensure adherence to these non-functional requirements are verified quarterly, not just at final gates, especially given the plan to accelerate independent red-teaming quarterly.

**Responsibilities:**

- Oversee the quarterly external security red-teaming results and PMO remediation plans.
- Certify adherence to GDPR/Privacy Zone implementation and successful auto-redaction functionality.
- Audit the immutable edge OS/Secure Boot/SBOM/mTLS implementation at the edge.
- Ensure the data retention policy (≤30 days operational log) is enforced across all ingestion points.
- Ensure compliance review of NATO/STANAG mapping drafts (even if deferred) against security protocols.

**Initial Setup Actions:**

- Contract the independent IV&V partner to begin quarterly red-teaming starting immediately post-mobilization (Q4-2025 / Pre-PDR).
- Mandate the Cybersecurity/Compliance Manager to produce the initial Zero-Trust Architecture document for review.
- Define the formal process for reviewing the required Privacy Zones configuration across CPH/AAL.

**Membership:**

- Lead Cybersecurity/Compliance Manager (Chair)
- Independent IV&V Partner Security Lead (Assurance Role)
- Legal Counsel (Privacy/Regulatory Focus)
- SOC Monitoring Lead (Operational Feedback)

**Decision Rights:** Can mandate a 'Cyber Security Stop Work Order' on any Phase 1 integration stream (A, B, or Edge Hardware) if a critical vulnerability (leading to breach or loss of integrity) is confirmed by red-teaming, pending PSC review within 7 days.

**Decision Mechanism:** Unanimous agreement required, especially when issuing Stop Work Orders. Chair casts tie-breaking vote on procedural compliance issues only.

**Meeting Cadence:** Bi-weekly during mobilization and integration phases; Quarterly post-Pilot Acceptance.

**Typical Agenda Items:**

- Review of Open Vulnerabilities and Patch Remediation SLO adherence (Crit ≤7d).
- GDPR/Privacy Zone Audit Report.
- Status of SLSA-3+ provenance tracking implementation.
- Review of M+18 mandatory security and privacy audit checklist status.

**Escalation Path:** Critical security findings or sustained failure to adhere to Patch SLOs that directly undermine Zero-Trust integrity are escalated immediately, regardless of cadence, to the PSC for mandate enforcement.