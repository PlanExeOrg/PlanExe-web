**Request for major scope change impacting baseline (e.g., integrating RF/Acoustic Team C sensors before M+18 Pilot Acceptance)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC Vote requiring consensus or Chair's casting vote.
Rationale: Alters the core strategy chosen for de-risking the M+18 gate (Decision 1), affecting technical feasibility and schedule adherence.
Negative Consequences: Mandatory schedule slip (likely threatening M+18/M+20 gates) and budget overrun from integrating complex, deferred sensor modalities early.

**Technical Deadlock: PTP Sync Error exceeds 1ms tolerance or DLT Fusion Budget (70ms) failure reported by TIVG.**
Escalation Level: Technical Integrity & Verification Group (TIVG)
Approval Process: Unanimous technical agreement required within TIVG; failure escalates automatically.
Rationale: Threatens the fundamental engineering requirements for 3D accuracy KPI (<1.0m P50), which is a non-negotiable technical dependency for acceptance.
Negative Consequences: Inability to certify geometric fidelity, leading to potential M+4 PDR failure or guaranteed failure of the 3D accuracy KPI validation at M+18.

**Materialization of Critical Security Vulnerability: External Red-Teaming identifies a critical exploit invalidating Zero-Trust architecture before M+10 CDR.**
Escalation Level: Cyber, Privacy, and Compliance Board (CPCB)
Approval Process: Unanimous agreement required on issuing a 'Cyber Security Stop Work Order'; immediate notification to PSC.
Rationale: Direct violation of the front-loaded security governance mandate, risking stakeholder trust and regulatory non-compliance before IOC.
Negative Consequences: Mandatory Stop Work Order on integration streams, potential regulatory fine, and significant cost overrun for emergency remediation (Risk 7 amplification).

**Budget Request exceeding PMO financial authority (e.g., securing an unfunded, mandatory RTK-GNSS re-survey projected >€3.0M post-M+18).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC approval required based on review of justification linking necessity to KPI adherence, affecting the unapproved Phase 2 budget tranche.
Rationale: Requires allocation of strategic contingency budget or re-prioritization of Phase 2 funding, directly impacting the long-term viability of the program past M+18.
Negative Consequences: If unapproved, geometric drift persists, leading to guaranteed KPI failure (<2.0m P90) and jeopardizing IOC/FOC sign-off.

**Conflict regarding implementation of Countermeasure Policy: Requires delay in automated slew verification to ensure human decision safety exceeds 750ms latency KPI.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC must adjudicate the trade-off between the human safety assurance policy and the mandated latency KPI constraint (Decision 5).
Rationale: Represents a direct conflict between operational safety/CONOPS rigor and a hard, non-negotiable performance target (≤750ms UI latency).
Negative Consequences: Failure to resolve cleanly results in either sacrificing core latency KPI compliance or creating an unacceptably risky automated response chain that violates governmental safety expectation for manual intervention.

**Material delay (>2 weeks) in essential Phase 1 procurement lot delivery (e.g., GPU/TPM hardware from Lot A/B/C) threatening M+10 CDR progress.**
Escalation Level: Project Management Office (PMO)
Approval Process: PMO leadership holds authority to enforce vendor contractual recovery plans below the financial threshold, but must escalate schedule threat.
Rationale: Operational risk requiring immediate schedule enforcement and resource reassignment below the PSC's strategic decision threshold, per PMO responsibilities.
Negative Consequences: If the PMO cannot enforce schedule recovery, the technical integration timelines leading into CDR will fail deadlines, requiring PSC intervention for scope adjustment post-M+10.