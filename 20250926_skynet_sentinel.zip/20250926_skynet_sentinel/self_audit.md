Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 20 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the feasibility check (Decision 4) that assumes residual compute headroom for deferred Team C processing is fundamentally unverified. The plan notes: "The rigidity of this mandate directly conflicts with Sensor Modality Integration Strategy if the RF/Acoustic pipeline (Team C) requires sensor processing capabilities unavailable on the standardized platform."

**Mitigation**: Sensor Fusion & Algorithm Lead: Deliver quantified performance mapping confirming >20% headroom on standardized edge hardware for Team C workload by M+10 CDR.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project hinges on a novel system combination (DLT-based high-precision geodesy integrated with high-assurance cyber standards and dual international protocol mapping) without established, concurrent precedent at this scale. This is explicitly flagged by the 'Builder' strategy deferring the complex RF/Acoustic sensor integration (Team C) necessary for full capability.

**Mitigation**: Program Governance & EASA Liaison Lead: Initiate parallel validation tracks covering Technical, Legal/IP, and Operations, delivering NO-GO validation reports by M+10 CDR based on empirical validity and compliance clearance.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the core strategic concept underlying the M+18 success, 'Builder: Pragmatic Phase-In,' is defined only by its tactical choices (e.g., deferring Team C) rather than a business-level mechanism-of-action detailing value hypotheses, clear ownership for long-term FOC success, or objective metrics beyond the initial gate criteria.

**Mitigation**: Program Governance & EASA Liaison Lead: Produce a one-pager defining M+24 FOC value hypothesis, success metrics, and decision hooks for securing Phase 2 funding by M+6 (Mar 2026).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly trades comprehensive hazard coverage for schedule velocity, deferring the RF/Acoustic modality (Team C) which is necessary for adverse weather performance. This creates a likely failure mode post-M+18. Quote: "Rejecting the RF/Acoustic input risks failing the night/poor weather Pd requirement when operating in real-world environments."

**Mitigation**: EASA Steering Committee: Formally document acceptable interim certification metrics for adverse weather Pd KPI (Team C capability) sufficient for M+18 sign-off by M+10 CDR.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the schedule relies on deferring complex requirements (permits, long-lead procurement, predecessors) without providing an authoritative permit/approval matrix or explicitly detailing lead times against current allocations. The 'premortem' flags Regulatory Approval Nightmare (FM3/FM6/FM9) as a critical failure mode dependent on timely regulatory engagement (Assumption A3).

**Mitigation**: Program Governance & EASA Liaison Lead: Submit the Unified Operational Compliance Document for the sensor height waiver to EASA/CAAs within 30 days (by 2025-Oct-26) to lock in the approval timeline.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan critically omits commitment status for the €200M budget's second tranche (€150M) necessary for work post-M+18. Review Issue #1 notes: "Plan focuses on M+18 Pilot Acceptance; lacks guaranteed funding/mandate for FOC (M+24) sustainment." Financing gates/covenants are entirely undefined.

**Mitigation**: Program Governance & EASA Liaison Lead: Secure conditional funding commitment for the €150M Phase 2 tranche, tied to M+20 integration sign-off, by the next EASA review checkpoint.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction demands citing specific benchmarks/quotes and per-area math to support the budget realism assessment, but the plan provides no baseline budget figures, area/footprint size, or normalization data to perform the required cost realism check against benchmarks. The document mentions a €200M budget but no breakdown or area figures.

**Mitigation**: Physical Deployment & Logistics Coordinator: Generate a standardized cost estimate worksheet (EUR/m²) using industry benchmarks for comparable sensor/edge infrastructure to validate the €200M program budget against stated scope.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key milestones and KPIs (e.g., M+18 Pilot Acceptance, P90 3D Accuracy ≤2.0m) as single definite outcomes without providing confidence intervals, worst-case/conservative scenarios, or acknowledging the risks quantified in the premortem or expert review.

**Mitigation**: Program Governance & EASA Liaison Lead: Deliver a Sensitivity Analysis report quantifying the impact of KPI failures (e.g., 3D accuracy drift) on the total project NPV by M+4 PDR.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the evaluation criteria require specific engineering artifacts for build-critical components, and the plan only mentions high-level decisions without listing detailed engineering specs, interface contracts, or acceptance tests. For example, Decision 1 discusses prioritizing sensors but lacks the interface contract for data fusion. The WBS task 'Issue critical LLI procurement RFPs' is too low-level to substitute for detailed specs.

**Mitigation**: Sensor Fusion & Algorithm Lead: Produce technical specifications and interface contracts for the A/B sensor fusion pipeline, along with acceptance tests for the M+10 CDR milestone, by M+6.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains several critical technical claims lacking verifiable documentation IDs, particularly concerning the DLT Geometry Qualification. Decision 2 claims: "This lever enforces rigorous geometric maintenance via continuous surveying and weekly RTK-GNSS flights." The actual artifact proving this chartered activity is missing, which is a high-risk operational dependence.

**Mitigation**: Physical Deployment & Logistics Coordinator: Execute and archive signed Service Level Agreements (SLAs) for the weekly RTK-GNSS flight charter required post-PDR by M+4.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Decision 3 mandates immediate efforts to map internal data to NATO/STANAG and EUROCONTROL/ASTERIX by M+10, but the strategic choice adopted is to use a temporary wrapper/simulated ASTERIX for M+18, deferring full STANAG adherence to post-M+18. This abstract commitment to future compliance without immediate, verifiable progress on the complex STANAG layer is poorly defined. Quote: "Delaying formal publication of the EDXP format (and its mapping) until post-FOC (M+24), focusing only on internal data structures during the design phase."

**Mitigation**: Data Standardization & Interoperability Architect: Deliver the first authenticated, non-wrapper translation layer for the core STANAG message structure, validated by Expert 6, by M+14, reallocating engineering resources as planned.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the feature 'Standardization and Data Export Strategy' mandates dual protocol mapping (NATO/STANAG) while the chosen option defers complex STANAG adherence until post-M+18/FOC. The core goal is establishing a secure system, and this decision sacrifices immediate interoperability assurance for schedule velocity. Quote: "Attempting to satisfy both NATO and EUROCONTROL interface standards during the initial development cycle consumes critical M+10 engineering effort, risking performance regression against the core Pd target to satisfy future interoperability needs."

**Mitigation**: Data Standardization & Interoperability Architect: Deliver the first authenticated, non-wrapper translation layer for the core STANAG message structure, validated by Expert 6, by M+14 (2026-12-20).


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the Senior Geodesy & Synchronization Architect as the definitive expert needed to maintain the 3D accuracy KPI, a core technical constraint. This role is specialized, combining PTP synchronization and geospatial metrology, and its dedicated pursuit is only assumed, not confirmed.

**Mitigation**: Program Governance & EASA Liaison Lead: Confirm permanent FTE placement or long-term contractor engagement for the Senior Geodesy & Synchronization Architect role by M+1 (2025-Nov-30).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on an unmapped pathway for granting regulatory approval for non-standard physical installations (30-40m sensor mast height) across two national jurisdictions (Danish CAA/Hungarian CAA). Expert 1 identifies this as a critical risk: "The PMO must present a binding financial remediation plan to the Steering Committee within 30 days that explicitly funds the accelerated quarterly security Red-Teaming cadence without impacting the €50M Phase 1 budget."

**Mitigation**: Program Governance & EASA Liaison Lead: Submit the Unified Operational Compliance Document for the 10-40m sensor height waiver to EASA/CAAs within 30 days (by 2025-Oct-26) for formal sign-off.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any discussion or commitment regarding ongoing operational costs, revenue models, or long-term maintenance funding post-FOC (M+24), which is a critical evaluation point for sustainability. The review noted: "Plan focuses on M+18 Pilot Acceptance; lacks guaranteed funding/mandate for FOC (M+24) sustainment."

**Mitigation**: Program Governance & EASA Liaison Lead: Develop and present a dedicated 36-month Operational Sustainability Model outlining maintenance resource strategy and Phase 3 budget projection by M+12.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the success of the project hinges on securing non-waivable approvals (EASA/CAA waivers for 30-40m sensor heights) and adhering to mandated governance gates, which are explicitly flagged as a critical dependency and high risk (Risk 1). The plan notes the requirement for waivers: "Securing operational waiver approvals for 10–40m PTZ cluster heights."

**Mitigation**: Program Governance & EASA Liaison Lead: Submit the Unified Operational Compliance Document for the 10-40m sensor height waiver to EASA/CAAs within 30 days (by 2025-Oct-26) for formal sign-off.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any committed Service Level Agreements (SLAs) or contractual redress for the critical weekly RTK-GNSS flight charter dependency required for geometric stability. Decision 2 notes this creates a scheduling dependency that "directly competes with the software stability timeline," and Review 10 highlights the failed assumption of reliable charter availability.

**Mitigation**: Physical Deployment & Logistics Coordinator: Secure performance-based SLAs with cancellation penalties for the mandatory weekly RTK-GNSS flight charter provider by M+4 PDR.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Finance Department' (incentive: budget adherence, evidenced by 'Phase 1 (€50M) allocation: 70% to A/B integration') conflicts with the 'R&D Team' (incentive: long-term innovation/performance, evidenced by accelerating quarterly Red-Teaming to prove Zero-Trust by CDR). Accelerated cyber testing costs budget needed for sensor integration.

**Mitigation**: Program Governance & EASA Liaison Lead: Define a shared OKR by M+2: Fund accelerated quarterly IV&V without impacting Lot A/B integration spend, or formally reduce SLSA-3+ verification scope.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a formal feedback loop mechanism tied to measurable thresholds for course correction beyond basic governance gates. Decision 10 defines the Real-Time Performance Monitoring System, but there are no specified KPIs, review cadences owned by specific roles, or defined change-control thresholds (re-plan/stop).

**Mitigation**: Program Governance & EASA Liaison Lead: Establish a monthly Executive Review with a mandatory KPI dashboard (Pd, Accuracy, Latency) and charter a lightweight Change Control Board by M+2.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan shows strong coupling between Critical Risks FM2/FM8 (RF/Acoustic Integration Failure) and FM5/FM8 (Regulatory Approval Nightmare) via dependency on the fixed M+18 gate. Deferring RF/Acoustic integration (Team C) risks failing adverse weather Pd, yet the 'Builder' strategy relies on succeeding the M+18 gate which the Expert Review states may require proof of concept for this deferred capability.

**Mitigation**: EASA Steering Committee: Formally document acceptable interim certification metrics for the adverse weather Pd KPI (Team C capability) sufficient for M+18 sign-off by M+10 CDR.