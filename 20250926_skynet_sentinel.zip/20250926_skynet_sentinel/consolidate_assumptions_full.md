# Purpose

**Purpose:** business

**Purpose Detailed:** This plan outlines a large-scale, multi-year, multi-hundred-million-euro infrastructure and technology deployment program aimed at national/international safety, security, and air traffic management (societal/governmental initiative). It involves complex engineering, strict performance KPIs, phased rollout across multiple airports, procurement, governance structures, and technical standardization (mapping to EUROCONTROL/ASTERIX and NATO/STANAG), clearly classifying it as a major societal/commercial project.

**Topic:** Development and deployment of an EASA program for real-time unauthorized small UAS (sUAS) localization.

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan describes the full lifecycle of deploying a complex, physical surveillance and tracking infrastructure called 'SkyNet Sentinel'. This involves tangible physical elements at multiple airports, including installing and calibrating irregular PTZ camera clusters at specific heights (10–40 m) with defined baselines (300–800 m). It requires physical actions such as site preparation, sensor integration, running RTK-GNSS reference flights, conducting live exercises at airports, and deploying edge nodes with hardware security features (TPM/GPU). Furthermore, the rollout is spread across multiple physical airport locations (CPH, AAL, and 30 others). This is an extensive physical deployment plan.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Ability to install sensor clusters at 10–40 m height
- Space available for 300–800 m sensor baselines
- Access to secure physical space for edge nodes (GPU/TPM)
- Proximity/access to RTK-GNSS reference flight support
- Must be a major airport location (for Phase 1: CPH, AAL)

## Location 1
Denmark

Copenhagen Airport (CPH)

Designated perimeter or secure rooftop zones, Copenhagen, Denmark

**Rationale**: Mandated Phase 1 pilot location for 2026 (€50M tranche). Requires installation of 12-18 clusters and fulfillment of all KPI acceptance tests.

## Location 2
Hungary

Budapest Ferenc Liszt International Airport (AAL)

Designated perimeter or secure rooftop zones, Budapest, Hungary

**Rationale**: The second mandated Phase 1 pilot location for 2026. This location will be essential for initial geometry qualification and proving cluster deployment viability on a European airport.

## Location 3
European Union

Tier 1 European Hub Airport (Hypothetical)

A major, high-traffic EU airport not currently selected as a finalist.

**Rationale**: To prepare for the Phase 2 rollout targeting 30 airports, establishing a third reference site allows for diversification of environmental baseline data (weather, air traffic profile) prior to mass procurement.

## Location 4
Germany

Frankfurt Airport (FRA) or Munich Airport (MUC)

Rooftop infrastructure or adjacent testing ranges accessible from the main airport facilities.

**Rationale**: As a major hub central to EUROCONTROL operations, a major German airport provides a robust environment to stress-test the NATO/ASTERIX data mapping and connectivity required for Phase 2 validation, especially concerning high-density air traffic.

## Location Summary
The plan explicitly names Copenhagen (CPH) and Budapest (AAL) as mandatory physical locations for the initial 2026 pilot phase, requiring significant vertical infrastructure (10-40m height) for sensor cluster deployment. Two additional major European airport types are suggested to diversify readiness testing for the 30-airport Phase 2 rollout.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The program budget is stated as €200M, and core oversight is EASA, making the Euro the operational and budgeting standard.
- **DKK:** Local currency (Danish Krone) for expenditures at Copenhagen Airport (CPH).
- **HUF:** Local currency (Hungarian Forint) for expenditures at Budapest Airport (AAL).
- **USD:** Relevant for procuring specialized, high-end sensor components (PTZ optics, GPU/TPM hardware, GPSDO units) which are often globally priced in USD.

**Primary currency:** EUR

**Currency strategy:** The primary budget and all high-level procurement contracts are denominated in EUR, aligning with the EASA oversight and the stated €200M budget. Local expenditures at CPH and AAL must be managed in DKK and HUF, respectively, requiring operational budgets converted from EUR, hedging against minor intra-Eurozone exchange fluctuations.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Delays in obtaining necessary regulatory approvals from EASA and local authorities could hinder project timelines, especially for the mandatory acceptance gates.

**Impact:** A delay of 4–8 weeks in project timelines, potentially leading to increased costs of €1M–€2M due to extended project duration and resource allocation.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage with regulatory bodies early in the process to ensure all requirements are understood and met. Schedule regular check-ins to monitor progress on approvals.

## Risk 2 - Technical
Integration challenges between the various sensor modalities (optical, thermal, RF/acoustic) could lead to performance issues, particularly in adverse weather conditions.

**Impact:** Failure to meet the detection performance KPI of ≥80% in poor weather could result in a project delay of 2–4 weeks and additional costs of €500,000–€1M for re-engineering.

**Likelihood:** High

**Severity:** High

**Action:** Prioritize the integration of optical and thermal sensors first, deferring RF/acoustic integration until after initial KPIs are validated. Conduct thorough testing in varied conditions.

## Risk 3 - Financial
Unexpected cost overruns due to procurement delays or price increases in critical components (e.g., GPUs, sensors) could strain the project budget.

**Impact:** An additional cost of €5M–€10M if procurement issues arise, potentially leading to budget reallocation or project scope reduction.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish fixed-price contracts with suppliers where possible and maintain a contingency budget of at least 10% of the total project cost.

## Risk 4 - Environmental
Installation of sensor clusters at airports may face environmental scrutiny, particularly regarding wildlife impacts and local regulations.

**Impact:** Delays of 2–3 months in installation timelines and potential fines of €100,000–€500,000 if environmental assessments are not favorable.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Conduct thorough environmental impact assessments early in the project and engage with local environmental groups to mitigate concerns.

## Risk 5 - Operational
Operational readiness of personnel to manage the new systems may be insufficient, leading to delays in achieving KPIs during the pilot phase.

**Impact:** A delay of 1–2 months in achieving operational readiness, resulting in additional training costs of €200,000–€400,000.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement a comprehensive training program early in the project timeline, including simulation exercises to prepare operators for real-world scenarios.

## Risk 6 - Supply Chain
Disruptions in the supply chain for critical components could delay project timelines and increase costs.

**Impact:** Delays of 4–6 weeks in component delivery, leading to potential costs of €1M–€3M due to expedited shipping or alternative sourcing.

**Likelihood:** High

**Severity:** Medium

**Action:** Diversify suppliers and maintain a buffer stock of critical components to mitigate supply chain disruptions.

## Risk 7 - Security
Cybersecurity vulnerabilities in the system could lead to data breaches or operational failures, particularly given the Zero-Trust architecture requirements.

**Impact:** A potential breach could lead to costs of €2M–€5M for remediation and loss of stakeholder trust, along with regulatory fines.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct regular security audits and penetration testing, and ensure compliance with all cybersecurity standards throughout the project lifecycle.

## Risk summary
The project faces significant risks primarily in technical integration, regulatory approvals, and cybersecurity. The most critical risks include integration challenges with sensor modalities, which could jeopardize performance KPIs, and regulatory delays that could impact the project timeline. Mitigation strategies focus on early engagement with stakeholders, prioritizing critical integrations, and maintaining robust training and security protocols.

# Make Assumptions


## Question 1 - What is the specific breakdown of the €200M budget allocation across the major contract lots (Sensor/Algorithm A/B/C, Integration/Edge/Network, IV&V) to inform risk management for the Phase 1 (€50M) vs. Phase 2 (€150M) expenditures?

**Assumptions:** Assumption: The budget distribution aligns with the strategic decision to defer complex sensor fusion (RF/Acoustic - Team C) until Phase 2. Therefore, Phase 1 (€50M) will be allocated 70% to A/B sensor integration and calibration tooling, 20% to Integration/Edge fixed costs for pilot sites (CPH/AAL), and 10% to essential PDR/CDR IV&V activities.

**Assessments:** Title: Financial Allocation Risk Assessment
Description: Evaluation of budget distribution alignment with the phased delivery strategy.
Details: If 70% of Phase 1 is committed to Teams A/B integration, the primary financial risk shifts to component procurement lead times for high-end PTZ/Thermal units. Opportunity exists to pre-negotiate bulk pricing for Team C sensors during Phase 1 planning, leveraging the M+4 PDR gate to lock in better Phase 2 pricing, mitigating Risk 3 (Financial).

## Question 2 - Given the fixed gap between CDR (M+10) and Pilot Acceptance (M+18), what specific software version and KPI verification dataset mapping (EUROCONTROL/ASTERIX vs. internal EDXP) is mandated for the M+18 demonstration?

**Assumptions:** Assumption: Based on the 'Builder' strategic choice, the M+18 Pilot Acceptance will only require the core tracking KPIs (Pd, 3D Accuracy, Latency) verified against the internal EDXP v0.9 format, with compliance to a *simulated* ASTERIX schema only, deferring full NATO/STANAG mapping verification until the FOC (M+24) milestone.

**Assessments:** Title: Timeline Constraint Compliance Assessment
Description: Assessment of deliverable scope required for the 8-month window between CDR and Pilot Acceptance.
Details: Deferring full standard certification to FOC significantly de-risks the M+18 gate (reducing Risk 1: Regulatory delay impact). However, latency KPI validation must immediately focus on the edge-to-bus component (≤200ms), as this is intrinsically linked to tracking performance, not the eventual export format conversion latency.

## Question 3 - Which specific personnel roles (e.g., Geodesy Lead, Cyber Assurance Engineer, Sensor Fusion Architect) are required during Q4-2025 mobilization to ensure the PTP synchronization (≤1 ms error) and initial DLT geometry setup (≥6 control points) are achieved before the M+4 PDR gate?

**Assumptions:** Assumption: To meet the PTP/GPSDO synchronization target and initial geometry setup pre-PDR, mobilization in Q4-2025 must immediately secure one dedicated Senior Geodesy Engineer and one Network Synchronization Specialist to begin site surveying and PTP grandmaster procurement/installation alongside the initial procurement RFPs.

**Assessments:** Title: Resources and Personnel Readiness Assessment
Description: Evaluation of resource staffing critical for foundational engineering compliance.
Details: Failing to staff the Geodesy role immediately directly threatens the 3D accuracy KPI (Risk 2: Technical). Opportunity exists to cross-train existing infrastructure staff in IEEE-1588 maintenance to reduce Reliance on external RTK flight crews required in Decision 2, mitigating scheduling dependency risks.

## Question 4 - What is the formal process for obtaining EASA waiver/approval for the initial deployment of PTZ clusters at 30–40m height, and which national aviation authority at CPH/AAL holds primary jurisdiction for the MVFR/poor weather performance acceptance testing?

**Assumptions:** Assumption: EASA regulation requires an initial Type Certificate deviation or operational waiver for non-standard sensor heights (30–40m). Jurisdiction for operational testing at CPH defaults to Danish CAA (for CPH) and Hungarian CAA (for AAL), overseen by the EASA Steering Committee for consistency.

**Assessments:** Title: Governance and Regulatory Compliance Assessment
Description: Analysis of regulatory entry barriers for physical installation and operational certification.
Details: Risk 1 (Regulatory Delay) is high due to non-standard sensor mounting heights and the need for two distinct national CAAs for Phase 1 sign-off. Mitigation requires creating a unified 'SkyNet Sentinel Operational Compliance Document' referenced by both CAAs, centralized through the EASA Steering Committee before M+4.

## Question 5 - Detail the 'weekly drift checks via landmark resection and RTK-GNSS reference flights' procedure, specifying the required flight hours/cost profile to ensure this does not create a high-likelihood schedule dependency conflict (per Decision 2) with integration testing?

**Assumptions:** Assumption: To maintain the weekly cadence without conflict, a 'Low-Intensity Calibration Profile' will be adopted post-PDR (M+4), requiring 4 hours of dedicated RTK-GNSS flight time per airport cluster pair (CPH/AAL combined) weekly, sourced via a dedicated, pre-booked local aviation contractor, limiting budget expansion beyond the initial contingency.

**Assessments:** Title: Safety and Risk Management for Geometric Maintenance
Description: Evaluation of the process required to maintain 3D accuracy KPIs against schedule threats.
Details: The scheduled weekly flights introduce non-trivial operational risk (Risk 6: Supply Chain/Access). If the outsourced charter fails to meet the 4-hour slot due to other airport traffic, geometric alignment drifts, directly impacting the P90 accuracy KPI. Opportunity: Use RTK data logging to create high-fidelity training scenarios (linking to Decision 9).

## Question 6 - How does the 'metadata-first' transport strategy, combined with the mandated ≤30-day retention policy and auto-redaction upon export, interface with the broader data requirements for Phase 2 NATO/Member-State feeds verification?

**Assumptions:** Assumption: The system architecture supports two distinct data paths: an immutable, short-term operational log (≤30 days) for core tracking/security functions, and a fully processed, standardized archive copy (EUROCONTROL/STANAG mapped, retaining full resolution media references) for long-term legal/training purposes, which must be finalized by M+18.

**Assessments:** Title: Environmental and Data Stewardship Assessment
Description: Analysis of data lifecycle management balance between regulatory retention, privacy, and functional output standards.
Details: The short retention window (≤30 days) aids the 'Environmental Impact' vector by minimizing long-term data storage carbon footprint and compliance burden. However, if the long-term archive standardization (STANAG mapping) falls behind the PDR/CDR schedule, Phase 2 data sharing becomes non-compliant, creating friction with Member-State agreements.

## Question 7 - Since the operational CONOPS uses ADVISORY/WARNING/CRITICAL states (Decision 6) but the optimized strategy bypasses ADVISORY/WARNING for countermeasure activation, how are conflicts resolved when an operator needs to manually intervene based on an ADVISORY state alert?

**Assumptions:** Assumption: Operational procedures mandate that even if countermeasures are automated only on CRITICAL, the ADVISORY state invokes mandatory, real-time media pull-on-demand for operator context via the UI, ensuring human review capability via the ≤750ms latency path, even if automated action is disabled.

**Assessments:** Title: Stakeholder Involvement and CONOPS Validation Assessment
Description: Review of how operator interaction protocols align with automated triage logic.
Details: The deliberate simplification of automated response (Decision 5) relies heavily on operator readiness (Risk 5). Stakeholder involvement must focus extensive M+18 testing on the 'manual escalation loop' from ADVISORY to CRITICAL to ensure the system supports, rather than impedes, expert decision-making, validating the high availability KPI (≥99.5%).

## Question 8 - What operational system requirements (e.g., processing latency budget for DLT fusion, required keypoint density) are tied directly from the 3D Accuracy KPI (P50 <1.0 m) to the computational capacity of the Edge Nodes (GPU/TPM) to ensure the Edge Processing Heterogeneity Mandate does not create a performance ceiling pre-CDR?

**Assumptions:** Assumption: Achieving P50 <1.0m requires the JPDA/MHT-lite fusion step (including covariance propagation) to complete within 70ms on the edge node, leaving a 130ms budget for detection, tracking, and 2D keypoint extraction to satisfy the 200ms edge-to-bus latency KPI.

**Assessments:** Title: Operational Systems Performance Threshold Assessment
Description: Linking required algorithmic output quality to underlying hardware performance budgets.
Details: The 70ms fusion budget is tight for DLT processing across three asynchronous sensor inputs (if A/B are fused by M+10). If the standardized edge hardware (Decision 4) cannot achieve this, accuracy KPIs will fail before CDR. The 'immutable edge OS' requirement must be proven to introduce zero runtime overhead compared to baseline Linux to meet this hard computational constraint.

# Distill Assumptions

- Phase 1 (€50M) dedicates 70% to Teams A/B integration and calibration tooling.
- M+18 acceptance uses internal EDXP v0.9; ASTERIX simulation required; STANAG deferred to FOC.
- Q4-2025 mobilization secures one Senior Geodesy Engineer and one Sync Specialist pre-PDR.
- EASA waiver required for 30–40m PTZ heights; CPH/AAL testing jurisdiction defaults to national CAAs.
- Weekly drift checks require 4 dedicated RTK-GNSS flight hours per airport cluster pair post-PDR.
- System uses short-term operational log (≤30 days) and a separate STANAG archive finalized by M+18.
- ADVISORY state mandates real-time media pull-on-demand, even if automated countermeasure action is disabled.
- P50 accuracy (<1.0m) mandates JPDA/MHT-lite fusion completes within 70ms on the standardized edge node.
- Strategy prioritizes Teams A/B fusion; RF/Acoustic (Team C) integration deferred until post-IOC.
- DLT geometry maximizes initial six control points; accepting drift degradation post-M+18.
- EDXP format uses wrapper conversion for initial KPI testing; delays complex STANAG adherence until FOC.
- Edge nodes standardize on a single GPU/TPM stack to control logistics and patch SLOs.
- Countermeasure activation bypasses ADVISORY/WARNING states, triggering only on maximum confidence CRITICAL.
- Procurement merges Sensor Lots A/B/C into one contract, concentrating technical risk until Phase 2.
- Accelerated Quarterly red-teaming increases independent IV&V budget significantly before IOC.
- High-end PTZ/Thermal procurement lead times create primary financial risk in Phase 1 budgeting.
- Deferring protocol certification to FOC de-risks M+18 Timeline Constraint Compliance Assessment.
- Failing to staff Geodesy role immediately threatens the 3D accuracy KPI deadline pre-PDR.
- Non-standard mounting height requires unified operational compliance document signed by two CAAs.
- Outsourced RTK charter failure risks schedule, impacting weekly geometric alignment checks.
- Short metadata retention aids environmental impact; archive standardization delays Phase 2 data sharing.
- Simplified countermeasure automation relies heavily on operator readiness during M+18 testing.
- 70ms edge fusion budget is tight for DLT processing across asynchronous sensor inputs.
- Deferring Team C sensor integration until Phase 2 simplifies M+18 acceptance testing requirements.
- Maximizing initial control points accepts post-M+18 geometric drift degradation.
- Temporary EDXP wrapper delays full STANAG adherence, focusing M+18 on core tracking KPIs.
- Standardized edge compute simplifies logistics but may cap performance for specialized pipelines.
- Bypassing ADVISORY states in automation simplifies operator flow but requires robust manual escalation paths.
- Increased red-teaming frequency dramatically lowers MTTD but strains specialized contractor budget.
- Consolidating sensor lots concentrates integration risk, threatening the fixed 2026 Phase 1 schedule.
- Delivering capability isolates countermeasure integration until FOC (M+24) to de-risk M+18.

# Review Assumptions

## Domain of the expert reviewer
Critical Infrastructure & Mission-Critical Software/Sensor Fusion Project Planning

## Domain-specific considerations

- Adherence to EASA/NATO/STANAG standards
- Precision Geodesy and PTP Synchronization (<1ms error)
- Sensor Fusion (Optical, Thermal, RF, Acoustic) timeline management
- High-Assurance Cyber Security (Zero Trust, SLSA-3+)
- Physical deployment logistics on active international airports

## Issue 1 - Critical Missing Assumption: Long-Term Funding and Full-Program Viability (M+18 to FOC)
The provided analysis and decisions heavily focus on de-risking the immediate M+18 Pilot Acceptance gate (Phase 1 objectives). A critical missing assumption is the **guaranteed funding, political mandate, and resource allocation necessary to transition from Pilot Acceptance (M+18) to Full Operational Capability (FOC, M+24) and sustainment.** Specifically, the plan defers significant components—RF/Acoustic fusion (Team C), full STANAG adherence, and comprehensive geometric re-survey—to post-IOC/FOC. If political winds shift or funding tranche 2 (€150M) is reduced or delayed, the project succeeds partially (M+18) but fails its ultimate security objective by M+24.

**Recommendation:** Immediately develop an explicit, ratified Assumption confirming committed funding for Phases 2 and 3 (M+18 to M+36) contingent upon M+18 success. Furthermore, establish a clear Go/No-Go trigger tied to the M+18 gate for *initiating* the complex post-acceptance workstreams (Team C integration, STANAG finalization), possibly tying subsequent budget disbursement to critical milestones like the M+20 integration sign-off for Team C.

**Sensitivity:** If the follow-on funding tranche (baseline: €150M) is delayed by 6 months post-M+18, sustaining the specialized RTK flight crews (4 hrs/week) and core engineering staff required for Team C integration will incur contractual penalties or necessitate contract suspension, potentially increasing the final M+24 cost by 15-25% (€22.5M - €37.5M increase on the residual budget) or forcing a permanent downgrade in the performance ceilings (ROI reduction).

## Issue 2 - Fragile Reliance on Deferred Geometric Fidelity (DLT Geometry Qualification Velocity)
The 'Builder' strategy (chosen path) assumes that accepting geometric drift post-M+18 is acceptable, relying only on the initial six surveyed control points. For a high-precision tracking system (P50 <1.0m, P90 <2.0m) deployed across large baselines (300-800m) over multiple years across 30+ sites, accumulated minor drift leads to catastrophic failure against the core accuracy KPI over time. Accepting this drift implicitly assumes either that hardware alignment remains perfectly stable without intervention or that a full re-survey budget/schedule will materialize exactly when needed post-M+18.

**Recommendation:** Quantify the maximum tolerable drift degradation against the P90 SLA (e.g., 10% failure rate increase) and calculate the corresponding time-to-failure based on the baseline six control points. Based on this, institute a mandatory 'Geometric Health Check' KPI track starting at M+12, forcing a funding allocation review for the re-survey budget *before* M+18, rather than simply accepting the risk post-acceptance. Re-evaluate the 4-hour weekly RTK flight assumption (Assumption 5) to prioritize data collection for creating predictive drift models instead of pure real-time check.

**Sensitivity:** If the environment introduces unexpected ground motion or PTP timing jitter causes 1% cumulative error growth per quarter post-M+18 (baseline: 0.5% error growth), the system will exceed the <2.0m P90 accuracy KPI by M+28 (2 years post-pilot). Correcting this without a dedicated re-survey could require €1.5M-€3.0M in specialized engineering effort, reducing the projected ROI by 3-6% spread over the final operational period.

## Issue 3 - Unrealistic Risk Mitigation for Dual Standardization Conflict (ASTERIX/STANAG)
The chosen strategy (Wrapper solution, Assumption 2) simplifies M+18 testing by validating only against a *simulated* ASTERIX schema and deferring full NATO/STANAG mapping to FOC (M+24). Given that this is a large governmental safety/security project, it is highly unrealistic to assume that NATO/STANAG compliance requirements will remain static or that stakeholders will accept a 'simulated' validation for a system built under dual-standard mandates. The integration friction deferred to FOC often becomes the greatest legacy technical debt.

**Recommendation:** Immediately assign a dedicated, senior 'Protocol Architect' role (as recommended in Assumption 3) whose sole KPI is delivering the first authenticated, non-wrapper translation layer for the primary mandatory standard (likely STANAG for NATO partners) by M+14, even if it requires leveraging a small portion of the general Integration budget (de-scoping non-critical edge hardening for 2 months). This moves away from the deferred risk model and establishes early compliance proof points.

**Sensitivity:** Assuming the actual complexity of the dual protocol translation doubles the estimated integration effort (current estimation implies 10% of integration effort deferred), failure to resolve this by M+24 will lead to a mandatory 6-month delay in operational deployment across NATO partner sites, halting the planned international Phase 2 expansion. This delay on the primary security benefit equates to an immediate negative impact of -20% NPV on the M+24 projected revenue/asset utilization figures.

## Review conclusion
The project plan exhibits astute tactical planning for surviving the rigid M+18 Pilot Acceptance gate by strategically deferring complexity (Team C sensors, full protocol maturity). However, this creates three critical strategic vulnerabilities. **First, the viability of the expensive Phase 2 (€150M) is assumed but not secured, creating a cliff edge post-M+18.** Secondly, the deliberate acceptance of geometric drift post-pilot is a ticking time bomb for the core accuracy KPI. Finally, the reliance on a temporary wrapper solution for international standards (STANAG/ASTERIX) concentrates massive technical risk into the M+18 to FOC window, threatening interoperability. Immediate action is required to validate long-term political/financial buy-in and to establish interim performance checks for geometric stability.