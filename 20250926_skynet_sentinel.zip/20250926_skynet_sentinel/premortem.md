A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The supply chain for critical components will remain stable throughout the project. | Monitor supplier performance and delivery timelines weekly. | Any supplier delays exceed 2 weeks or cost increases exceed 10%. |
| A2 | The integration of the RF/Acoustic sensor modality can be deferred without impacting overall system performance. | Conduct simulations to assess performance without RF/Acoustic integration. | Simulation results show that performance metrics drop below acceptable thresholds. |
| A3 | The project will secure all necessary regulatory approvals on time. | Engage with regulatory bodies to confirm timelines and requirements. | Any regulatory approval delays exceed 4 weeks. |
| A4 | The technology used for sensor fusion will perform as expected under all operational conditions. | Conduct extensive field tests under varying environmental conditions. | Field tests show performance degradation beyond acceptable limits in specific conditions. |
| A5 | The project team will maintain high morale and productivity throughout the project duration. | Implement regular team surveys to assess morale and productivity levels. | Survey results indicate morale drops below 60% or productivity decreases significantly. |
| A6 | Stakeholder engagement will remain positive and supportive throughout the project lifecycle. | Schedule regular stakeholder meetings to gather feedback and address concerns. | Any stakeholder feedback indicates dissatisfaction or withdrawal of support. |
| A7 | The complexity of the multi-modal sensor fusion algorithm is mathematically tractable within the allocated edge processing budget. | Conduct a formal analysis with the Geospatial Metrology Expert on covariance stability thresholds for A+B+C fusion. | The required computational load exceeds 80% of the standardized edge hardware's proven capacity headroom. |
| A8 | The project’s budget contingency is sufficient to cover unforeseen scope changes or mandatory acceleration mandates. | Conduct an immediate triage analysis comparing anticipated costs for accelerated IV&V against the current contingency reserve ceiling. | The required cost to absorb immediate mandates exceeds the retained contingency buffer by 5%. |
| A9 | External standards bodies (NATO/EUROCONTROL) will agree to the staged certification approach proposed for M+18. | Initiate formal consultation with Defense Interoperability Protocol Analyst (Expert 6) to secure written acceptance of simulated ASTERIX validation at M+18. | Stakeholders refuse to sign off on the M+18 Pilot Acceptance documentation without a non-wrapper STANAG feed. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Supply Chain Collapse | Process/Financial | A1 | Supply Chain Manager | CRITICAL (20/25) |
| FM2 | The RF/Acoustic Integration Failure | Technical/Logistical | A2 | Sensor Integration Lead | CRITICAL (25/25) |
| FM3 | The Regulatory Approval Nightmare | Market/Human | A3 | Regulatory Affairs Lead | CRITICAL (20/25) |
| FM4 | The Supply Chain Collapse | Process/Financial | A1 | Supply Chain Manager | CRITICAL (20/25) |
| FM5 | The RF/Acoustic Integration Failure | Technical/Logistical | A2 | Sensor Integration Lead | CRITICAL (25/25) |
| FM6 | The Regulatory Approval Nightmare | Market/Human | A3 | Regulatory Affairs Lead | CRITICAL (20/25) |
| FM7 | The Supply Chain Collapse | Process/Financial | A1 | Supply Chain Manager | CRITICAL (20/25) |
| FM8 | The RF/Acoustic Integration Failure | Technical/Logistical | A2 | Sensor Integration Lead | CRITICAL (25/25) |
| FM9 | The Regulatory Approval Nightmare | Market/Human | A3 | Regulatory Affairs Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Critical components are delayed due to supplier issues, leading to project timeline slippage. Financial penalties arise from missed deadlines. The project incurs additional costs from expedited shipping and alternative sourcing.

##### Early Warning Signs
- Supplier delivery timelines exceed 2 weeks.
- Cost increases from suppliers exceed 10%.
- Supplier performance ratings drop below 70%.

##### Tripwires
- Supplier delays exceed 2 weeks.
- Cost increases exceed 10%.

##### Response Playbook
- Contain: Stop all non-essential orders to minimize financial exposure.
- Assess: Review all supplier contracts and performance metrics.
- Respond: Identify alternative suppliers and negotiate expedited contracts.


**STOP RULE:** Any critical component delay exceeds 4 weeks.

---

#### FM2 - The RF/Acoustic Integration Failure

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Sensor Integration Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
Deferring RF/Acoustic integration leads to inadequate performance in adverse weather conditions. The system fails to meet the required detection KPIs, resulting in project failure at the M+18 acceptance gate.

##### Early Warning Signs
- Simulation results indicate performance metrics drop below acceptable thresholds.
- Feedback from testing shows significant detection failures in adverse conditions.

##### Tripwires
- Simulation results show performance metrics drop below 80% detection rate.

##### Response Playbook
- Contain: Halt further integration of non-critical components.
- Assess: Conduct a thorough review of simulation results and performance metrics.
- Respond: Develop a rapid integration plan for RF/Acoustic sensors.


**STOP RULE:** Detection KPIs fail to meet 80% in adverse conditions.

---

#### FM3 - The Regulatory Approval Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Regulatory Affairs Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Delays in securing regulatory approvals lead to project stalling. The project faces financial penalties and reputational damage, jeopardizing future funding and stakeholder trust.

##### Early Warning Signs
- Regulatory feedback indicates potential delays.
- Stakeholder concerns about compliance arise.

##### Tripwires
- Regulatory approval delays exceed 4 weeks.

##### Response Playbook
- Contain: Communicate with stakeholders about potential delays.
- Assess: Review all regulatory requirements and timelines.
- Respond: Engage with regulatory bodies to expedite approvals.


**STOP RULE:** Any regulatory approval delay exceeds 8 weeks.

---

#### FM4 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Critical components are delayed due to supplier issues, leading to project timeline slippage. Financial penalties arise from missed deadlines. The project incurs additional costs from expedited shipping and alternative sourcing.

##### Early Warning Signs
- Supplier delivery timelines exceed 2 weeks.
- Cost increases from suppliers exceed 10%.
- Supplier performance ratings drop below 70%.

##### Tripwires
- Supplier delays exceed 2 weeks.
- Cost increases exceed 10%.

##### Response Playbook
- Contain: Stop all non-essential orders to minimize financial exposure.
- Assess: Review all supplier contracts and performance metrics.
- Respond: Identify alternative suppliers and negotiate expedited contracts.


**STOP RULE:** Any critical component delay exceeds 4 weeks.

---

#### FM5 - The RF/Acoustic Integration Failure

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Sensor Integration Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
Deferring RF/Acoustic integration leads to inadequate performance in adverse weather conditions. The system fails to meet the required detection KPIs, resulting in project failure at the M+18 acceptance gate.

##### Early Warning Signs
- Simulation results indicate performance metrics drop below acceptable thresholds.
- Feedback from testing shows significant detection failures in adverse conditions.

##### Tripwires
- Simulation results show performance metrics drop below 80% detection rate.

##### Response Playbook
- Contain: Halt further integration of non-critical components.
- Assess: Conduct a thorough review of simulation results and performance metrics.
- Respond: Develop a rapid integration plan for RF/Acoustic sensors.


**STOP RULE:** Detection KPIs fail to meet 80% in adverse conditions.

---

#### FM6 - The Regulatory Approval Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Regulatory Affairs Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Delays in securing regulatory approvals lead to project stalling. The project faces financial penalties and reputational damage, jeopardizing future funding and stakeholder trust.

##### Early Warning Signs
- Regulatory feedback indicates potential delays.
- Stakeholder concerns about compliance arise.

##### Tripwires
- Regulatory approval delays exceed 4 weeks.

##### Response Playbook
- Contain: Communicate with stakeholders about potential delays.
- Assess: Review all regulatory requirements and timelines.
- Respond: Engage with regulatory bodies to expedite approvals.


**STOP RULE:** Any regulatory approval delay exceeds 8 weeks.

---

#### FM7 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Critical components are delayed due to supplier issues, leading to project timeline slippage. Financial penalties arise from missed deadlines. The project incurs additional costs from expedited shipping and alternative sourcing.

##### Early Warning Signs
- Supplier delivery timelines exceed 2 weeks.
- Cost increases from suppliers exceed 10%.
- Supplier performance ratings drop below 70%.

##### Tripwires
- Supplier delays exceed 2 weeks.
- Cost increases exceed 10%.

##### Response Playbook
- Contain: Stop all non-essential orders to minimize financial exposure.
- Assess: Review all supplier contracts and performance metrics.
- Respond: Identify alternative suppliers and negotiate expedited contracts.


**STOP RULE:** Any critical component delay exceeds 4 weeks.

---

#### FM8 - The RF/Acoustic Integration Failure

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Sensor Integration Lead
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
Deferring RF/Acoustic integration leads to inadequate performance in adverse weather conditions. The system fails to meet the required detection KPIs, resulting in project failure at the M+18 acceptance gate.

##### Early Warning Signs
- Simulation results indicate performance metrics drop below acceptable thresholds.
- Feedback from testing shows significant detection failures in adverse conditions.

##### Tripwires
- Simulation results show performance metrics drop below 80% detection rate.

##### Response Playbook
- Contain: Halt further integration of non-critical components.
- Assess: Conduct a thorough review of simulation results and performance metrics.
- Respond: Develop a rapid integration plan for RF/Acoustic sensors.


**STOP RULE:** Detection KPIs fail to meet 80% in adverse conditions.

---

#### FM9 - The Regulatory Approval Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Regulatory Affairs Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Delays in securing regulatory approvals lead to project stalling. The project faces financial penalties and reputational damage, jeopardizing future funding and stakeholder trust.

##### Early Warning Signs
- Regulatory feedback indicates potential delays.
- Stakeholder concerns about compliance arise.

##### Tripwires
- Regulatory approval delays exceed 4 weeks.

##### Response Playbook
- Contain: Communicate with stakeholders about potential delays.
- Assess: Review all regulatory requirements and timelines.
- Respond: Engage with regulatory bodies to expedite approvals.


**STOP RULE:** Any regulatory approval delay exceeds 8 weeks.
