### 1. Mobilize Q4-2025: Secure dedicated facilities and finalize EASA-chaired Project Steering Committee (PSC) scope, timeline, and financial authorizations (>€5M).

**Responsible Body/Role:** EASA Executive Sponsor

**Suggested Timeframe:** Project Week 1 (Q4-2025)

**Key Outputs/Deliverables:**

- Confirmed PSC Charter/Scope Document
- Authorized initial Phase 1 Budget Release (€50M tranche initiation)

**Dependencies:**

- Project Kickoff Decision
- Program Budget (€200M) Allocation Defined

### 2. Mobilize Q4-2025: Recruit and on-board required specialized personnel: Senior Geodesy Engineer and Network Synchronization Specialist.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 2-4

**Key Outputs/Deliverables:**

- Senior Geodesy Engineer On-boarded
- Network Synchronization Specialist On-boarded

**Dependencies:**

- Confirmed PSC Charter/Scope Document

### 3. PMO drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating financial thresholds and gate approval mandates.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Confirmed PSC Charter/Scope Document

### 4. PSC reviews and formally approves its ToR, confirming EASA Executive Sponsor as Chair and affirming the governance structure (PSC, PMO, TIVG, CPCB).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Formal appointment of PSC member roles

**Dependencies:**

- Draft PSC ToR v0.1

### 5. PMO drafts initial ToR for the Project Management Office (PMO), Technical Integrity & Verification Group (TIVG), and Cyber, Privacy, and Compliance Board (CPCB).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1
- Draft TIVG ToR v0.1
- Draft CPCB ToR v0.1

**Dependencies:**

- Approved PSC ToR v1.0

### 6. PMO circulates Draft ToRs to nominated PSC members for immediate review (focusing on decision rights alignment).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Circulated Draft Governance ToRs

**Dependencies:**

- Draft PMO ToR v0.1
- Draft TIVG ToR v0.1
- Draft CPCB ToR v0.1

### 7. PSC reviews and approves the finalized ToRs for the PMO, TIVG, and CPCB, authorizing their formal establishment.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved PMO ToR v1.0 (PMO formally established)
- Approved TIVG ToR v1.0 (TIVG formally established)
- Approved CPCB ToR v1.0 (CPCB formally established)

**Dependencies:**

- Circulated Draft Governance ToRs

### 8. PMO initiates competitive Lot A/B/C (Sensors/Algorithms) and Lot 'Integration/Edge/Network' RFPs, prioritizing Lot A/B procurement execution.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Issued RFP for Lots A/B/C (Sensor/Algorithm)
- Issued RFP for Integration/Edge/Network

**Dependencies:**

- Approved PSC ToR v1.0

### 9. CPCB contracts the independent IV&V partner, mandating quarterly Red-Teaming cadence starting pre-PDR.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- IV&V Partner Contract Signed (including quarterly Red-Team schedule)
- Initial Zero-Trust Architecture Document Drafted

**Dependencies:**

- Approved CPCB ToR v1.0
- Authorized initial IV&V budget release

### 10. PMO finalizes the integrated 24-month Gantt chart, incorporating the planned deferral of Team C (RF/Acoustic) integration until Post-IOC.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Integrated Gantt Chart v1.0 (Phase 1 focus on A/B)

**Dependencies:**

- Approved PSC ToR v1.0
- Strategic Decision: Sensor Modality Integration Strategy implemented

### 11. TIVG defines the mandatory technical baseline specifications for PTP synchronization error (≤1ms) and DLT control points (≥6 surveyed points) required for M+4 PDR.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- PTP Synchronization Specification Document
- Geodesy Requirements Specification for Initial Control Survey

**Dependencies:**

- Senior Geodesy Engineer On-boarded
- Network Synchronization Specialist On-boarded

### 12. PMO establishes the 'metadata-first' EDXP data schema baseline (pre-wrapper) and defines the temporary ASTERIX simulation requirements for M+18 testing.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- EDXP Specification v0.1 (Internal Baseline)
- ASTERIX Simulation Validation Plan

**Dependencies:**

- Strategic Decision: Standardization and Data Export Strategy enacted (Wrapper path)

### 13. PMO coordinates with CPH/AAL site leads to submit the unified Operational Compliance Document seeking EASA/CAA waivers for 10-40m mounting heights.

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Formal EASA/CAA Waiver Submission Package

**Dependencies:**

- Integrated Gantt Chart v1.0
- Approved PSC ToR v1.0 (Regulatory oversight)

### 14. PMO finalizes framework agreements for Lots A/B/C and Integration/Edge, locking in standardized edge node hardware (GPU/TPM) to meet logistical SLO requirements.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 14 (M+1 Month Approx.)

**Key Outputs/Deliverables:**

- Signed Framework Agreements for Sensor Lots and Integration/Edge Procurement
- Standardized Edge Node Hardware Specification locked

**Dependencies:**

- Issued RFP for Lots A/B/C (Sensor/Algorithm)
- Strategic Decision: Edge Processing Heterogeneity Mandate enacted (Standardization)

### 15. TIVG oversees the initial site survey (CPH/AAL) utilizing the Geodesy Engineer to establish the initial six surveyed control points and deploy the PTP Grandmaster.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 14-18

**Key Outputs/Deliverables:**

- Six Verified Control Points established at CPH and AAL per site
- PTP Grandmaster operational and confirming sub-1ms sync error across initial network segment

**Dependencies:**

- Geodesy Requirements Specification for Initial Control Survey
- Network Synchronization Specialist On-boarded

### 16. PMO deploys the Real-Time Performance Monitoring System infrastructure (Dashboard, Sensor Integration) capable of receiving preliminary EDXP data feeds for readiness monitoring.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 18

**Key Outputs/Deliverables:**

- RT Performance Monitoring System (Dashboard) operational baseline

**Dependencies:**

- Standardized Edge Node Hardware Specification locked
- EDXP Specification v0.1 (Internal Baseline)

### 17. CPCB conducts initial audit verifying CPH/AAL edge node images adhere to Zero-Trust primitives (Secure Boot, TPM identity configuration) ahead of sensor integration.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 20

**Key Outputs/Deliverables:**

- Initial Edge Hardening Audit Report
- Confirmation of TPM identity assignment

**Dependencies:**

- Initial Edge Hardening Audit Report
- Standardized Edge Node Hardware Specification locked

### 18. PMO coordinates with Sensor Lots A/B vendors to begin integrating the initial optical/thermal payloads onto the standardized edge nodes, beginning feature extraction testing.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 20-24

**Key Outputs/Deliverables:**

- Functional Optical/Thermal data stream from prototype edge node

**Dependencies:**

- Signed Framework Agreements for Sensor Lots
- Standardized Edge Node Hardware Specification locked

### 19. TIVG executes initial DLT resection and JPDA/MHT-lite fusion testing on integrated A/B streams, targeting margin validation against the 70ms edge budget and DLT accuracy KPIs.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Week 25-28 (Leading to M+4 PDR)

**Key Outputs/Deliverables:**

- Edge Fusion Benchmark Report (70ms budget validation)
- Initial 3D Accuracy Projections Report

**Dependencies:**

- Functional Optical/Thermal data stream from prototype edge node
- PTP Synchronization Specification Document

### 20. CPCB contracts and initiates the first external, quarterly Red-Teaming exercise against the integrated A/B edge hardware/software baseline.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Week 28 (Pre-PDR)

**Key Outputs/Deliverables:**

- Initial Red-Team Execution Report

**Dependencies:**

- IV&V Partner Contract Signed

### 21. Formal Project Definition Review (PDR) Gate: PSC reviews technical progress (A/B only), budget alignment, and regulatory waiver status before authorizing full cluster procurement and Site Integration Phase.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 4 (M+4)

**Key Outputs/Deliverables:**

- PDR Gate Approval/Rejection
- Authorized release of funds for Phase 1 Cluster procurement

**Dependencies:**

- Edge Fusion Benchmark Report (70ms budget validation)
- Formal EASA/CAA Waiver Submission Package received (even if pending)
- Initial Red-Team Execution Report

### 22. PMO initiates delivery and site integration of the first batch of certified Optical/Thermal Sensor Clusters (Team A/B) at CPH and AAL, immediately establishing weekly RTK-GNSS flight charter.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 5-8 (Post-PDR)

**Key Outputs/Deliverables:**

- Cluster Installation Begins at CPH/AAL
- Weekly RTK-GNSS Flight Charter operational

**Dependencies:**

- PDR Gate Approval/Rejection
- Authorized release of funds for Phase 1 Cluster procurement

### 23. TIVG begins utilizing weekly RTK-GNSS data to feed dedicated Landmark Resection/Drift Check mechanism, focusing on predictive modeling for geometric stability (Decision 2 implementation).

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 5 onwards

**Key Outputs/Deliverables:**

- Weekly Geometric Health Check Reports
- Predictive Drift Model v0.1

**Dependencies:**

- Weekly RTK-GNSS Flight Charter operational

### 24. PMO finalizes procurement for the specialized edge hardware (Lot C components) intended for RF/Acoustic processing, but holds integration until Post-IOC/M+18 clearance.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 7

**Key Outputs/Deliverables:**

- Team C Hardware Contract Awarded

**Dependencies:**

- PDR Gate Approval/Rejection

### 25. CPCB audits the implementation of the simplified Countermeasure Synchronization Policy (bypass ADVISORY/WARNING for auto-action) and verifies auto-slew verification readiness based on CRITICAL state linkage.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 9

**Key Outputs/Deliverables:**

- Countermeasure Automation Validation Report

**Dependencies:**

- Strategic Decision: Countermeasure Synchronization Triggering Policy enacted (Bypass policy)

### 26. Integration Teams begin work on preliminary EDXP to ASTERIX wrapper translation (simulated validation path) required for basic M+18 compliance.

**Responsible Body/Role:** Lead Technical Architect (Interface Manager, under PMO)

**Suggested Timeframe:** Project Month 9-10

**Key Outputs/Deliverables:**

- EDXP-ASTERIX Wrapper v0.5 ready for integration testing

**Dependencies:**

- EDXP Specification v0.1 (Internal Baseline)
- Strategic Decision: Standardization Strategy enacted (Wrapper path)

### 27. Formal Critical Design Review (CDR) Gate: PSC reviews integrated performance (A/B only), final hardware designs, and readiness for operational CONOPS validation setups.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 10 (M+10)

**Key Outputs/Deliverables:**

- CDR Gate Approval/Rejection
- Go/No-Go decision on EDXP Wrapper viability for Pilot Acceptance

**Dependencies:**

- Weekly Geometric Health Check Reports
- Countermeasure Automation Validation Report
- EDXP-ASTERIX Wrapper v0.5 ready for integration testing

### 28. PMO formalizes the Operational Handover CONOPS Model training materials (ADVISORY/WARNING/CRITICAL states) based on the finalized response policy.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 11-13

**Key Outputs/Deliverables:**

- CONOPS Training Package v1.0 (Tri-State Model)

**Dependencies:**

- CDR Gate Approval/Rejection
- Strategic Decision: Operational Handover CONOPS Model (Tri-State)

### 29. TIVG oversees the completion of the Calibration Handbook and Test Cards utilizing consolidated A+B cluster data from CPH/AAL pilot sites.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 13-16

**Key Outputs/Deliverables:**

- Final Calibration Handbook v1.0
- Full Test Card Matrix Completion

**Dependencies:**

- Weekly Geometric Health Check Reports

### 30. CPCB executes the second Quarterly Red-Teaming exercise, focusing specifically on the data pipeline security and the metadata retention/auto-redaction controls.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 15

**Key Outputs/Deliverables:**

- Q2 Red-Team Report (Privacy/Data Focus)

**Dependencies:**

- Initial Edge Hardening Audit Report

### 31. PMO initiates the Integrated Training and Simulation Program, developing scenarios specifically focused on the M+18 acceptance environment (A/B sensor validation, CRITICAL state response).

**Responsible Body/Role:** Program Director (PMO Lead)

**Suggested Timeframe:** Project Month 16-17

**Key Outputs/Deliverables:**

- Simulation Environment Ready for Operator Trials
- Integrated Training Plan v1.0

**Dependencies:**

- CONOPS Training Package v1.0 (Tri-State Model)

### 32. PMO conducts system-level stress tests against all core KPIs (Pd, Accuracy, Latency, Availability) using the simulated environment and operator task tracking.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 17-18

**Key Outputs/Deliverables:**

- Pre-Acceptance KPI Test Report (Pass/Fail assessment)

**Dependencies:**

- Final Calibration Handbook v1.0
- Simulation Environment Ready for Operator Trials

### 33. Formal Pilot Acceptance Gate (M+18): PSC reviews KPI pass status (A/B fusion only), documentation completeness (Handbook, Heatmaps), and confirmation of operator proficiency/live exercise completion.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 18 (Mid-2027)

**Key Outputs/Deliverables:**

- Pilot Acceptance Gate Approval/Rejection
- Decision to Fund Phase 2 (Release of €150M tranche)

**Dependencies:**

- Pre-Acceptance KPI Test Report (Pass/Fail assessment)
- Confirmation of Pilot Site Live Exercises Completed

### 34. Upon Pilot Acceptance, PMO authorizes integration of Team C (RF/Acoustic) components onto the standardized edge nodes, initiating necessary firmware updates for heterogeneity adaptation.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 19

**Key Outputs/Deliverables:**

- Team C Hardware Integration Commenced
- Edge Node Firmware Update Rollout v1.1

**Dependencies:**

- Pilot Acceptance Gate Approval/Rejection
- Team C Hardware Contract Awarded

### 35. CPCB mandates the start of full NATO/STANAG protocol translation engineering effort, utilizing the PMO resources liberated by deferring geometric re-survey post-M+18.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 19

**Key Outputs/Deliverables:**

- Formal NATO/STANAG Translation Project Initiation

**Dependencies:**

- Pilot Acceptance Gate Approval/Rejection

### 36. PMO signs framework agreements for Phase 2 rollout (30 airports), focusing initial deployments on sites requiring NATO/STANAG feeds validation.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 20

**Key Outputs/Deliverables:**

- Phase 2 Procurement Contracts Finalized and Initiated

**Dependencies:**

- Decision to Fund Phase 2 (Release of €150M tranche)

### 37. Formal Down-select / Production Readiness Review (PRR) Gate: PSC reviews integrated A/B/C performance (initial Team C integration) and readiness for wide-scale rollout, including updated security posture.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 20 (M+20)

**Key Outputs/Deliverables:**

- PRR Gate Approval/Rejection

**Dependencies:**

- Team C Hardware Integration Commenced
- Q2 Red-Team Report (Privacy/Data Focus) remediation closure

### 38. TIVG begins quality checks on the NATO/STANAG translation layer based on initial output from the dedicated translation engineers, aiming for M+22 verification.

**Responsible Body/Role:** Technical Integrity & Verification Group (TIVG)

**Suggested Timeframe:** Project Month 20-22

**Key Outputs/Deliverables:**

- NATO/STANAG Translation Layer Functional Test Results

**Dependencies:**

- Formal NATO/STANAG Translation Project Initiation

### 39. Formal Interim Operational Capability (IOC) Gate: PSC verifies successful ingestion of real-time data feeds by NATO/Member-State systems using the developing translation layer at initial Phase 2 sites.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 22 (M+22)

**Key Outputs/Deliverables:**

- IOC Gate Approval/Rejection

**Dependencies:**

- NATO/STANAG Translation Layer Functional Test Results (Initial Link Verified)

### 40. PMO, supported by CPCB, ensures all 30 Phase 2 sites meet Zero-Trust hardening (Immutable OS, mTLS) and SOC monitoring is active across the expanded cluster footprint.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Month 23

**Key Outputs/Deliverables:**

- Full SOC Monitoring Activation Across All Nodes

**Dependencies:**

- PRR Gate Approval/Rejection
- IOC Gate Approval/Rejection

### 41. Final comprehensive Cyber Red-Team exercise conducted across the integrated A/B/C system running on Phase 2 infrastructure to confirm system resilience prior to FOC.

**Responsible Body/Role:** Cyber, Privacy, and Compliance Board (CPCB)

**Suggested Timeframe:** Project Month 23

**Key Outputs/Deliverables:**

- Final Pre-FOC Security Clearance Report

**Dependencies:**

- IOC Gate Approval/Rejection

### 42. Formal Full Operational Capability (FOC) Gate: PSC reviews final acceptance criteria, including full KPI demonstration (A/B/C fusion, full latency), final NATO/STANAG interface sign-off, and Cyber Clearance.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Month 24 (M+24)

**Key Outputs/Deliverables:**

- FOC Gate Approval (Program Completion)
- Final Program Closure Report

**Dependencies:**

- Final Pre-FOC Security Clearance Report
- All 30 Phase 2 sites provisioned and reporting continuity/availability KPIs