
## Audit - Corruption Risks

- Kickbacks or bribery during the Procurement Phase (Q4-2025 RFPs) in exchange for awarding Lots A/B/C (sensors/algorithms) or the Integration/Edge/Network contract, especially where competitive pressure might be intentionally reduced by consolidation.
- Nepotism or undue influence in selecting the 4-hour weekly RTK-GNSS charter contractor (critical to geometric KPI maintenance), potentially leading to inflated rates or substandard service.
- Conflicts of interest where PMO personnel or EASA Steering Committee members own stakes in component suppliers (e.g., specialized PTZ manufacturers or GPU vendors) influencing procurement decisions (Lots A/B/C).
- Trading favors with local regulators (Danish CAA or Hungarian CAA) to expedite difficult operational waivers required for the non-standard 10–40m sensor mounting heights, bypassing official safety scrutiny.
- Misuse of proprietary PTP synchronization network setup knowledge or GPSDO information (a high-value asset) shared with external system integrators in exchange for favorable contractual terms or expedited deliverables (kickbacks).

## Audit - Misallocation Risks

- Misallocation of Phase 1 budget (€50M), specifically overspending the 70% allocated to Teams A/B integration to compensate for underperforming algorithms or hardware selected based on biased vendor selection, leading to scope reduction elsewhere in the pilot.
- Double spending or inefficient use of resources related to maintaining the DLT geometry; failure to aggregate RTK-GNSS flight data effectively across CPH and AAL, resulting in paying for redundant flight hours or failing to use logged data for training.
- Unauthorized use of specialized personnel (Senior Geodesy Engineer/Sync Specialist) dedicated for Q4-2025 mobilization on non-critical tasks (e.g., developing training material instead of site surveying), directly threatening the M+4 PDR gate.
- Misreporting progress on the deferred Team C (RF/Acoustic) integration; current resources dedicated to A/B stabilization might be incorrectly logged as progress toward the full system integration timeline required for FOC (M+24).
- Budget misuse via over-specifying edge hardware purchased under the standardized GPU/TPM stack mandate, selecting overly powerful or expensive components when less costly hardware could meet the tight 70ms fusion budget.

## Audit - Procedures

- Conduct quarterly, independent financial audits focused on expenditure related to Procurement Lots A/B/C and IV&V contracts, verifying costs against established framework agreement mini-competition thresholds, starting Q1-2026.
- Perform technical/system audits immediately post-PDR (M+4) and CDR (M+10) to verify that the implementation of the 'Builder' strategy aligns with stated deferrals (e.g., confirm Team C code base is truly parked and not consuming integration resources).
- Mandatory third-party forensic review of PTP synchronization logs and GPSDO attestations monthly during Phase 1, verifying end-to-end error remains ≤1 ms before allowing integration testing activities to proceed.
- Periodic (e.g., semi-annual, pre-IOC) audit of data handling workflows to confirm operational logs are retained for ≤30 days, and that auto-redaction based on privacy zones is functioning correctly *before* media is pulled on demand or exported.
- Detailed review of the RTK-GNSS flight vendor contract and log files post-PDR (M+4) to ensure the 4 hours/week workload requirement is met for CPH/AAL without conflicting with core software integration milestones, linking flight costs back to the Contingency Budget.

## Audit - Transparency Measures

- Publish the EASA Steering Committee meeting minutes quarterly (as required) detailing all decisions related to waiver grants for 10–40m mounting heights and KPI acceptance results from the M+18 Pilot Acceptance gate.
- Maintain a publicly accessible, read-only dashboard tracking the hard schedule gates (PDR, CDR, IOC, FOC) and the primary KPI scores (Pd, 3D Accuracy P90, Availability) updated following each governance gate review.
- Document and publicly share the formal criteria used for down-selecting the standardized edge node hardware (GPU/TPM stack) proving it meets the 70ms fusion budget requirement, to validate the Edge Processing Heterogeneity Mandate.
- Establish an anonymous, formally chartered whistleblower mechanism overseen directly by the independent IV&V partner to report conflicts of interest or deviations from competitive Lot procurement procedures.
- Publish the M+18 acceptance documentation, including the coverage/accuracy heatmaps and the Calibration Handbook, to ensure transparency on the achieved performance baseline before Phase 2 commitments are finalized.