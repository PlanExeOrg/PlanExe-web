**Purpose:** business

**Purpose Detailed:** This plan outlines a large-scale, multi-year, multi-hundred-million-euro infrastructure and technology deployment program aimed at national/international safety, security, and air traffic management (societal/governmental initiative). It involves complex engineering, strict performance KPIs, phased rollout across multiple airports, procurement, governance structures, and technical standardization (mapping to EUROCONTROL/ASTERIX and NATO/STANAG), clearly classifying it as a major societal/commercial project.

**Topic:** Development and deployment of an EASA program for real-time unauthorized small UAS (sUAS) localization.