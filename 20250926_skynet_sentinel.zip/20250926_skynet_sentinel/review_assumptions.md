## Domain of the expert reviewer
Critical Infrastructure & Mission-Critical Software/Sensor Fusion Project Planning

## Domain-specific considerations

- Adherence to EASA/NATO/STANAG standards
- Precision Geodesy and PTP Synchronization (<1ms error)
- Sensor Fusion (Optical, Thermal, RF, Acoustic) timeline management
- High-Assurance Cyber Security (Zero Trust, SLSA-3+)
- Physical deployment logistics on active international airports

## Issue 1 - Critical Missing Assumption: Long-Term Funding and Full-Program Viability (M+18 to FOC)
The provided analysis and decisions heavily focus on de-risking the immediate M+18 Pilot Acceptance gate (Phase 1 objectives). A critical missing assumption is the **guaranteed funding, political mandate, and resource allocation necessary to transition from Pilot Acceptance (M+18) to Full Operational Capability (FOC, M+24) and sustainment.** Specifically, the plan defers significant components—RF/Acoustic fusion (Team C), full STANAG adherence, and comprehensive geometric re-survey—to post-IOC/FOC. If political winds shift or funding tranche 2 (€150M) is reduced or delayed, the project succeeds partially (M+18) but fails its ultimate security objective by M+24.

**Recommendation:** Immediately develop an explicit, ratified Assumption confirming committed funding for Phases 2 and 3 (M+18 to M+36) contingent upon M+18 success. Furthermore, establish a clear Go/No-Go trigger tied to the M+18 gate for *initiating* the complex post-acceptance workstreams (Team C integration, STANAG finalization), possibly tying subsequent budget disbursement to critical milestones like the M+20 integration sign-off for Team C.

**Sensitivity:** If the follow-on funding tranche (baseline: €150M) is delayed by 6 months post-M+18, sustaining the specialized RTK flight crews (4 hrs/week) and core engineering staff required for Team C integration will incur contractual penalties or necessitate contract suspension, potentially increasing the final M+24 cost by 15-25% (€22.5M - €37.5M increase on the residual budget) or forcing a permanent downgrade in the performance ceilings (ROI reduction).

## Issue 2 - Fragile Reliance on Deferred Geometric Fidelity (DLT Geometry Qualification Velocity)
The 'Builder' strategy (chosen path) assumes that accepting geometric drift post-M+18 is acceptable, relying only on the initial six surveyed control points. For a high-precision tracking system (P50 <1.0m, P90 <2.0m) deployed across large baselines (300-800m) over multiple years across 30+ sites, accumulated minor drift leads to catastrophic failure against the core accuracy KPI over time. Accepting this drift implicitly assumes either that hardware alignment remains perfectly stable without intervention or that a full re-survey budget/schedule will materialize exactly when needed post-M+18.

**Recommendation:** Quantify the maximum tolerable drift degradation against the P90 SLA (e.g., 10% failure rate increase) and calculate the corresponding time-to-failure based on the baseline six control points. Based on this, institute a mandatory 'Geometric Health Check' KPI track starting at M+12, forcing a funding allocation review for the re-survey budget *before* M+18, rather than simply accepting the risk post-acceptance. Re-evaluate the 4-hour weekly RTK flight assumption (Assumption 5) to prioritize data collection for creating predictive drift models instead of pure real-time check.

**Sensitivity:** If the environment introduces unexpected ground motion or PTP timing jitter causes 1% cumulative error growth per quarter post-M+18 (baseline: 0.5% error growth), the system will exceed the <2.0m P90 accuracy KPI by M+28 (2 years post-pilot). Correcting this without a dedicated re-survey could require €1.5M-€3.0M in specialized engineering effort, reducing the projected ROI by 3-6% spread over the final operational period.

## Issue 3 - Unrealistic Risk Mitigation for Dual Standardization Conflict (ASTERIX/STANAG)
The chosen strategy (Wrapper solution, Assumption 2) simplifies M+18 testing by validating only against a *simulated* ASTERIX schema and deferring full NATO/STANAG mapping to FOC (M+24). Given that this is a large governmental safety/security project, it is highly unrealistic to assume that NATO/STANAG compliance requirements will remain static or that stakeholders will accept a 'simulated' validation for a system built under dual-standard mandates. The integration friction deferred to FOC often becomes the greatest legacy technical debt.

**Recommendation:** Immediately assign a dedicated, senior 'Protocol Architect' role (as recommended in Assumption 3) whose sole KPI is delivering the first authenticated, non-wrapper translation layer for the primary mandatory standard (likely STANAG for NATO partners) by M+14, even if it requires leveraging a small portion of the general Integration budget (de-scoping non-critical edge hardening for 2 months). This moves away from the deferred risk model and establishes early compliance proof points.

**Sensitivity:** Assuming the actual complexity of the dual protocol translation doubles the estimated integration effort (current estimation implies 10% of integration effort deferred), failure to resolve this by M+24 will lead to a mandatory 6-month delay in operational deployment across NATO partner sites, halting the planned international Phase 2 expansion. This delay on the primary security benefit equates to an immediate negative impact of -20% NPV on the M+24 projected revenue/asset utilization figures.

## Review conclusion
The project plan exhibits astute tactical planning for surviving the rigid M+18 Pilot Acceptance gate by strategically deferring complexity (Team C sensors, full protocol maturity). However, this creates three critical strategic vulnerabilities. **First, the viability of the expensive Phase 2 (€150M) is assumed but not secured, creating a cliff edge post-M+18.** Secondly, the deliberate acceptance of geometric drift post-pilot is a ticking time bomb for the core accuracy KPI. Finally, the reliance on a temporary wrapper solution for international standards (STANAG/ASTERIX) concentrates massive technical risk into the M+18 to FOC window, threatening interoperability. Immediate action is required to validate long-term political/financial buy-in and to establish interim performance checks for geometric stability.