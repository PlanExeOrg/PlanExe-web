## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers address the core engineering trade-offs between **Performance Fidelity vs. Schedule Realization** and **Security Assurance vs. Operational Latency**. Critical levers are Sensor Modality Integration (performance viability), DLT Geometry Qualification (accuracy KPI), and Countermeasure Synchronization Policy (latency trade-off). High levers manage the foundational constraints: Edge Processing (performance ceiling), Procurement Structure (schedule risk), Cyber Cadence (governance assurance), and Real-Time Monitoring (latency validation).

### Decision 1: Sensor Modality Integration Strategy
**Lever ID:** `87ba1cbe-db48-4bda-acc6-72cab844b863`

**The Core Decision:** This strategy governs sensor selection for initial validation, prioritizing Optical (A) and Thermal (B) data fusion for core 3D tracking capabilities to accelerate the M+18 gate. Success is measured by achieving daytime Pd/accuracy KPIs swiftly. The critical risk is deferring the RF/Acoustic (C) modality, which jeopardizes accurate classification and poor-weather performance needed for full system success.

**Why It Matters:** Choosing to prioritize the fusion of data from only the long-range optical (Team A) and thermal (Team B) sensors for the initial KPI demonstration allows for faster delivery of the core 3D tracking capabilities. However, this intentionally defers integration of the RF/Acoustic team (Team C), meaning the crucial 'confirm/veto' function for classifying low-profile threats in adverse weather will be unavailable during the M+18 Pilot Acceptance gate, potentially exposing a fatal weakness in the Pd target for poor weather scenarios.

**Strategic Choices:**

1. Aggressively prioritize and stabilize the Team A (Optical) and Team B (Thermal) payload pipelines, deferring Team C (RF/Acoustic) integration until post-IOC to simplify M+18 acceptance testing requirements.
2. Treat all three sensor modalities (A, B, C) as system-critical requirements from PDR onward, accepting substantial schedule slippage on the M+10 CDR due to the complexity of fusing heterogeneous, asynchronous sensor reports into the JPDA/MHT-lite tracker.
3. Implement a sensor fallback mode where only the most reliable single modality (determined by site-specific environmental analysis) is utilized for initial detection, delaying the 3D triangulation fuse requirement until robust co-sensing can be proven, simplifying the initial P50 accuracy KPI demonstration.

**Trade-Off / Risk:** Forcing all three sensor modalities into the initial acceptance phase guarantees schedule overruns due to integration friction, but rejecting the RF/Acoustic input risks failing the night/poor weather Pd requirement when operating in real-world environments.

**Strategic Connections:**

**Synergy:** Synergizes with DLT Geometry Qualification Velocity by stabilizing input data quality early, allowing geometry teams to focus on fewer, more reliable sensor pipelines first.

**Conflict:** Conflicts with Edge Processing Heterogeneity Mandate by potentially causing an imbalance, sacrificing optimized processing for the deferred RF/Acoustic pipeline to maintain a singular edge standard.

**Justification:** *Critical*, This lever controls project viability by determining which KPIs (especially poor weather Pd) can be met. Deferring Team C (RF/Acoustic) risks failing essential performance mandates, making it central to the risk/reward profile.

### Decision 2: DLT Geometry Qualification Velocity
**Lever ID:** `f2c02d26-3b88-42dd-9f82-be43619dbd39`

**The Core Decision:** This lever enforces rigorous geometric maintenance via continuous surveying and weekly RTK-GNSS flights to guarantee the P50/P90 3D accuracy KPIs across the distributed sensor network. While crucial for trust, this demands dedicated high-value air assets, creating a scheduling dependency that directly threatens the M+10 CDR if flight availability is constrained by integration milestones.

**Why It Matters:** By enforcing the use of ground-surveyed control points and weekly RTK-GNSS flights for drift checks, the system guarantees the required sub-2.0m 3D accuracy under stable conditions. This high-fidelity geometric maintenance, however, necessitates dedicating specialized RTK teams and aircraft availability throughout the rollout period, potentially creating a critical dependency bottleneck that delays the software deployment schedule by delaying the geometric readiness step necessary before the M+18 gate.

**Strategic Choices:**

1. Maximize the utilization of the DLT resection/bundle adjustment process using only the initial six surveyed control points, accepting drift degradation post-M+18 until a full re-survey can be funded and executed.
2. Establish a fixed, dedicated RTK-GNSS calibration flight crew operating on a parallel schedule to the software integration teams, servicing geometry validation for the initial 12 clusters concurrently to meet the weekly drift check requirement.
3. Replace the explicit ground survey requirement with a fully automated, AI-driven feature-matching process leveraging common environmental static objects for extrinsics estimation, treating geometric stability as a runtime software problem.

**Trade-Off / Risk:** The weekly RTK-GNSS check ensures geometric fidelity critical for the 3D accuracy KPI, but scheduling dedicated flight time directly competes with the software stability timeline needed to pass the M+10 CDR.

**Strategic Connections:**

**Synergy:** Directly enables the success of Sensor Modality Integration Strategy by ensuring that whatever data is fused—optical, thermal, or RF—its spatial coordinates meet strict M+18 acceptance standards.

**Conflict:** Conflicts with Operational Handover CONOPS Model as intense, frequent geometric validation needs (flight time) compete with the schedule allowance necessary for thorough operator training and CONOPS validation.

**Justification:** *Critical*, Controls the fundamental 3D accuracy KPI (<2.0m P90). The intensive requirement for weekly RTK-GNSS checks creates a high-friction dependency that directly challenges the M+10 CDR and M+18 acceptance gates.

### Decision 3: Standardization and Data Export Strategy
**Lever ID:** `8c140900-18f3-4723-bda7-2be2aaf4f0ea`

**The Core Decision:** This strategy mandates immediate efforts to map the internal EDXP data structure to both NATO/STANAG and EUROCONTROL/ASTERIX protocols by M+10. Its success hinges on defining a robust, dual-standard interface early, providing interoperability for Phase 2 rollout, but it pulls significant engineering resources away from tuning core tracking algorithms for the initial pilot phase.

**Why It Matters:** Committing to immediate mapping of the EDXP output format to both EUROCONTROL/ASTERIX and NATO/STANAG standards at M+4 ensures rapid interoperability for the Phase 2 rollout. This dual standardization effort significantly increases the M+10 CDR complexity, requiring immediate translation layers and validation against two distinct legacy messaging protocols which fragments early development bandwidth away from core tracking performance tuning.

**Strategic Choices:**

1. Prioritize full NATO/STANAG mapping during Phase 1 development (CPH/AAL) as the primary acceptance requirement for government stakeholders, deferring EUROCONTROL/ASTERIX compatibility until the Phase 2 contract scope.
2. Delay formal publication of the EDXP format (and its mapping) until post-FOC (M+24), focusing only on internal data structures during the design phase to rapidly iterate features without external protocol validation overhead.
3. Develop a temporary, wrapper-based conversion service where the internal EDXP format is validated only against a simulated, simplified ASTERIX schema for initial KPI testing, delaying the complex STANAG adherence until final integration.

**Trade-Off / Risk:** Attempting to satisfy both NATO and EUROCONTROL interface standards during the initial development cycle consumes critical M+10 engineering effort, risking performance regression against the core Pd target to satisfy future interoperability needs.

**Strategic Connections:**

**Synergy:** Amplifies the importance of Standardization and Data Export Strategy by ensuring the quality of delivered data, as Cyber Security Verification Cadence must validate the security stamps across both standards.

**Conflict:** Trades off against Real-Time Performance Monitoring System, as mandatory protocol translation and validation consumes edge and bus bandwidth better spent delivering low-latency EDXP updates required by latency KPIs.

**Justification:** *High*, Mandating early dual standardization (ASTERIX/STANAG) consumes critical M+10 engineering resources needed for core algorithm tuning. It governs interoperability success for the large Phase 2 rollout.

### Decision 4: Edge Processing Heterogeneity Mandate
**Lever ID:** `bceadf90-e194-43a8-b600-a6e68e6319fe`

**The Core Decision:** This mandates using homogenous hardware across all sensor pipelines (A, B, C) at the edge to simplify logistics, lifecycle management, and adherence to critical patch SLOs (≤7 days). The trade-off is potential underperformance in specialized tasks, risking the adverse weather Pd goals because custom workloads must fit a standardized, potentially suboptimal compute environment.

**Why It Matters:** Choosing a highly homogeneous edge compute platform across all teams (A, B, C) simplifies procurement and patching SLOs significantly, reducing system integration complexity upfront. However, this forces an inefficient mapping of specialized sensor pipelines (e.g., high-frame-rate MWIR processing vs. RF signature correlation) onto standardized hardware, potentially sacrificing the required ≥80% Pd in adverse weather conditions to maintain patch compliance.

**Strategic Choices:**

1. Standardize edge nodes universally on a single, pre-qualified GPU/TPM stack procured via the main sensor procurement lot to enforce stricter supply chain control and patching SLOs.
2. Allow Teams A, B, and C to select bespoke processing hardware based solely on pipeline efficiency benchmarks, while isolating operational environments to manage divergent firmware and security update coordination.
3. Implement a two-tier edge architecture where initial feature extraction occurs on low-cost FPGAs for time-critical tasks, deferring complex decision fusion to centralized, hardened GPU servers over a high-bandwidth link.

**Trade-Off / Risk:** Mandating standardized edge compute simplifies logistics but may cap real-time performance by forcing algorithm specialization onto inadequately sized or mismatched general hardware, trading implementation velocity for necessary detection robustness.

**Strategic Connections:**

**Synergy:** Strongly supports Cyber Security Verification Cadence by simplifying the attack surface management and ensuring uniform application of Zero-Trust hardening across all deployed nodes.

**Conflict:** The rigidity of this mandate directly conflicts with Sensor Modality Integration Strategy if the RF/Acoustic pipeline (Team C) requires sensor processing capabilities unavailable on the standardized platform.

**Justification:** *High*, This lever forces a key trade-off between logistical simplicity (patch SLOs, SOC) and algorithmic efficiency. It risks limiting performance on specialized pipelines, potentially preventing the system from meeting adverse weather KPIs.

### Decision 5: Countermeasure Synchronization Triggering Policy
**Lever ID:** `c2395535-5736-4d2e-b84d-5f687ff6356b`

**The Core Decision:** This lever governs the automated response framework, specifically linking sensor outputs (ADVISORY/WARNING/CRITICAL) to non-kinetic countermeasures and slew verification, aiming to balance speed against safety assurance. Success metrics relate to controlled responses without violating the 750ms UI latency KPI. The core challenge is managing the trade-off between rapid automated action and mandatory human validation prior to countermeasure deployment.

**Why It Matters:** The system only advises on non-kinetic countermeasures under national authority; integrating the ADVISORY/WARNING/CRITICAL state transitions with an automated slew verification loop impacts the crucial ≤750 ms operator UI latency KPI. Introducing a mandatory 5-second verification pause between the CRITICAL alert and auto-slew initiation drastically improves human decision validation but adds latency to the response chain during high-risk, low-altitude events.

**Strategic Choices:**

1. Implement the full automated slew verification sequence only for CRITICAL states, but allow immediate, manual override activation of non-kinetic countermeasures based solely on the WARNING state.
2. Require all automatic countermeasure actions to queue for external, human sign-off via a secondary, physically separate terminal to enforce absolute separation between detection and kinetic actuation triggers.
3. Bypass the ADVISORY/WARNING states entirely, only permitting system interaction when the target classification confidence exceeds the maximum threshold required for the Pd ≥90% KPI, simplifying the operator flow.

**Trade-Off / Risk:** Pausing automated slew verification in the CRITICAL state enhances safety by adding human oversight, although this intentional delay directly challenges the aggressive sub-second maximum latency required for operator responsiveness.

**Strategic Connections:**

**Synergy:** Synergizes with Countermeasure Integration Posture by directly governing its automated activation logic, and relies on the Real-Time Performance Monitoring System to track associated latency KPIs.

**Conflict:** Directly conflicts with the Real-Time Performance Monitoring System requirement for latency ≤750ms to the operator UI due to necessary human validation pauses introduced by this policy.

**Justification:** *Critical*, This forces the fundamental trade-off between latency KPI (≤750ms to UI) and human safety assurance (auto-slew verification). Governing this tension is key to satisfying both operational speed and regulatory responsibility.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Operational Handover CONOPS Model
**Lever ID:** `44dabe99-db9e-44a7-ad33-c30374f2f88a`

**The Core Decision:** This defines the operator interaction model using three distinct threat states (ADVISORY/WARNING/CRITICAL) linked to automated verification routines, aiming to optimize human response speed and accuracy. Its primary metric is successful system adoption and secure escalation during stress tests, but complexity risks delaying the M+18 Pilot Acceptance due to extended UX testing requirements.

**Why It Matters:** Committing to the tri-state CONOPS (ADVISORY → WARNING → CRITICAL) requires training operators on immediate auto-slew verification procedures, which increases the complexity of the M+18 Pilot Acceptance scenario testing due to the need to validate human-machine interaction under stress. Adopting a simpler two-state model (Alert/Action) would speed operator training and UX validation, but might fail to meet the necessary nuance required to prevent false positives from triggering kinetic countermeasures under national authority oversight.

**Strategic Choices:**

1. Develop and validate the full ADVISORY, WARNING, and CRITICAL state logic, including the auto-slew verification loop, as a mandatory pre-condition for the M+18 Pilot Acceptance demonstration.
2. Streamline the initial operational release to a binary Alert/No-Alert state, deferring the complex warning logic and associated training packages until the post-IOC operational refinement cycle.
3. Develop a configurable handover protocol that defaults to Advisory mode regardless of system confidence, requiring operator confirmation to elevate the state, shifting risk mitigation burden onto the human subject matter expert sooner.

**Trade-Off / Risk:** Implementing the full tri-state CONOPS early increases the complexity of the M+18 user acceptance testing, yet simplifying the states risks operator hesitation when confirming tracking data needed for critical responses.

**Strategic Connections:**

**Synergy:** Directly benefits from the Integrated Training and Simulation Program, as the detailed, multi-state CONOPS provides the necessary structure for high-fidelity simulation scenarios.

**Conflict:** Creates tension with Countermeasure Synchronization Triggering Policy; a complex warning state may delay the final authorization required to initiate automated non-kinetic responses mandated by the CRITICAL state.

**Justification:** *Medium*, Governs operator UX and state management. While important for adoption, its complexity primarily impacts the M+18 acceptance schedule rather than the core technical feasibility defined by sensor or geometry.

### Decision 7: Countermeasure Integration Posture
**Lever ID:** `6df5ff30-2e68-474f-859e-1be7430158ec`

**The Core Decision:** This lever governs the timing of integrating non-kinetic countermeasure control systems with the core localization output. The default strategy isolates these for simplicity until FOC (M+24), prioritizing achieving core tracking KPIs for acceptance. Success is measured by avoiding integration linkage causing failure in the M+18 Pilot Acceptance testing, ensuring a clean tracking certification path.

**Why It Matters:** Fully decoupling the non-kinetic countermeasure control systems from the core SkyNet Sentinel localization bus until after FOC (M+24) simplifies the initial security perimeter and focuses exclusively on achieving the stringent tracking and availability KPIs. This delays realizing the primary security outcome of the system, but it prevents the high-stakes integration of kinetic/non-kinetic arbitration logic from corrupting the critical, mandatory M+18 Pilot Acceptance testing criteria.

**Strategic Choices:**

1. Isolate non-kinetic trigger pathways entirely until M+24 FOC, treating the synchronization and tracking functionality as a standalone certification target divorced from immediate effect chain implementation.
2. Integrate a low-fidelity, read-only 'advisory' signal path to the countermeasures by CDR (M+10) that only validates message format compliance, preventing execution but ensuring necessary data mapping is validated early.
3. Treat countermeasure integration as the primary workstream, requiring physical verification and go/no-go decision at PDR (M+4) based on the operational viability of the end-to-end kill-chain architecture.

**Trade-Off / Risk:** Delaying countermeasure integration minimizes immediate system complexity for acceptance testing but effectively postpones the project's ultimate security benefit by two years, creating a gap between surveillance capability and actionable response.

**Strategic Connections:**

**Synergy:** Synergizes with Operational Handover CONOPS Model by establishing clear operational boundaries; it also leverages Countermeasure Synchronization Triggering Policy readiness later for full integration.

**Conflict:** Directly conflicts with Countermeasure Synchronization Triggering Policy by delaying the workstream; isolating integration also increases complexity for the final FOC security audit post-M+24.

**Justification:** *Low*, Decoupling countermeasures until FOC (M+24) simplifies initial testing, making it a tactical choice to de-risk the M+18 gate. It postpones the ultimate goal but avoids immediate technical friction.

### Decision 8: Adaptive Privacy Protocols
**Lever ID:** `dcf00746-6661-4522-8259-b2c7d46fb41f`

**The Core Decision:** This lever defines how privacy controls are adjusted across different operational contexts, balancing regulatory compliance against operational necessity. Success relies on maintaining data consistency despite dynamic changes. The scope covers metadata handling, retention policies, and auto-redaction thresholds defined in the plan, aiming for compliance without compromising necessary data resolution for tracking KPIs.

**Why It Matters:** Adopting adaptive privacy protocols allows for tailored data handling based on specific operational contexts, enhancing compliance with privacy regulations. However, this may lead to inconsistencies in data management practices across different operational scenarios.

**Strategic Choices:**

1. Implement tiered data access levels based on operational urgency and threat assessment to balance privacy and security needs.
2. Create a real-time privacy impact assessment tool that adjusts data handling protocols dynamically during operations.
3. Engage stakeholders in developing context-specific privacy guidelines that can adapt to varying operational environments.

**Trade-Off / Risk:** Adaptive privacy protocols enhance compliance but may create challenges in maintaining uniform data management standards across operations.

**Strategic Connections:**

**Synergy:** Strongly supports Adaptive Privacy Protocols by providing the policy framework for context-specific data handling; it enables adherence to the metadata-first mandate while managing exceptions.

**Conflict:** Adopting too much context-specificity could conflict with Standardization and Data Export Strategy by leading to varied EDXP messaging formats or interpretation rules across different sites.

**Justification:** *Medium*, Addresses mandatory cyber/privacy requirements by customizing handling. It is necessary for compliance but is a refinement layer on top of data acquisition, secondary to the core tracking performance drivers.

### Decision 9: Integrated Training and Simulation Program
**Lever ID:** `394be296-a2af-48db-aef7-0bd0edbc9cb1`

**The Core Decision:** This program focuses on developing scenario-based training for operators and maintenance teams covering the entire system stack, from sensor calibration routines (RTK-GNSS flights) to high-stakes CONOPS execution. Success is measured by operator proficiency scores and successful drill completions aligned with the operational states (ADVISORY to CRITICAL) ahead of the IOC milestone.

**Why It Matters:** Launching an integrated training and simulation program can enhance operator readiness and system familiarity, leading to improved performance during real-world scenarios. However, the resource allocation for extensive training may divert funds from other critical project areas.

**Strategic Choices:**

1. Develop a comprehensive simulation environment that replicates real-world conditions for operator training and system testing.
2. Incorporate scenario-based training modules that focus on high-stress situations to prepare operators for unexpected challenges.
3. Establish a mentorship program pairing experienced operators with new recruits to facilitate knowledge transfer and skill development.

**Trade-Off / Risk:** An integrated training program boosts operator preparedness but may strain budget allocations and extend timelines for other project components.

**Strategic Connections:**

**Synergy:** Crucially amplifies the Operational Handover CONOPS Model by ensuring personnel are proficient in the defined states and verification steps; it also leverages Real-Time Performance Monitoring System data for scenario fidelity.

**Conflict:** Resource expenditure for high-fidelity simulation environments can conflict with the budget required to execute the phased rollout timeline, potentially delaying hardware deployment in Phase 2.

**Justification:** *Low*, Crucial for adoption (linked to CONOPS), but it is an enabling function. Successful sensor and geometry performance (Critical levers) must precede meaningful simulation fidelity.

### Decision 10: Real-Time Performance Monitoring System
**Lever ID:** `7d2f388b-805d-42b0-8a83-17650e6486dc`

**The Core Decision:** This system focuses on aggregating KPI data (Pd, accuracy, latency, availability) in real-time from diverse edge nodes and sensor clusters into a centralized view accessible to the PMO. Its purpose is to enable immediate validation against the mandated performance targets, driving rapid iterative refinement, evidenced by low edge/UI latency monitoring feedback loops.

**Why It Matters:** Implementing a real-time performance monitoring system can provide immediate feedback on system efficacy, allowing for rapid adjustments to improve outcomes. However, the complexity of data integration may require significant upfront investment in technology and training.

**Strategic Choices:**

1. Deploy a centralized dashboard that aggregates performance metrics from all operational units for real-time analysis and decision-making.
2. Utilize IoT sensors to continuously monitor system performance and alert operators to deviations from established KPIs.
3. Create a feedback loop where operators can report performance issues directly, enabling swift corrective actions.

**Trade-Off / Risk:** Real-time performance monitoring enhances responsiveness but may necessitate substantial investments in technology and operator training.

**Strategic Connections:**

**Synergy:** Directly feeds crucial data into the Real-Time Performance Monitoring System to validate the low latency goals (≤200/750ms); it proves the effectiveness of Sensor Modality Integration Strategy's output fidelity.

**Conflict:** The implementation overhead of this monitoring infrastructure may delay the initial deployment timeline required to meet the Phase 1 date at CPH and AAL, creating schedule pressure.

**Justification:** *High*, This system is the direct feedback loop on latency KPIs (≤200ms). Its implementation complexity competes directly with the timeline for initial rollout, making it a central scheduling tension point.

### Decision 11: Cyber Security Verification Cadence
**Lever ID:** `c08f5818-7123-48e4-81e3-016159f0bf21`

**The Core Decision:** This lever dictates the frequency of external security auditing, specifically red-teaming, against the deployed Zero-Trust architecture. Increasing the cadence from bi-annual to quarterly aims to aggressively shorten MTTD and prove the robustness of security primitives like TPM, secure boot, and immutable OS prior to widespread rollout.

**Why It Matters:** The plan requires bi-annual red-teaming and ongoing SOC monitoring for the Zero-Trust architecture. Accelerating the independent red-team exercises to every quarter significantly increases the external IV&V budget and consumes high-security personnel hours, but it dramatically lowers the Mean Time To Detect (MTTD) critical vulnerabilities before or during live operations.

**Strategic Choices:**

1. Contract the independent IV&V partner to perform security red-teaming quarterly instead of bi-annually, utilizing pre-approved Tier 1 vulnerability scenarios based on prior aerospace DLT system incidents.
2. Shift all security verification responsibility internally to the project's integrated SOC team, eliminating the external red-team budget line but removing the independence required by the governance structure.
3. Limit Zero-Trust enforcement only to the communications plane (mTLS pinning) while relaxing the requirements for immutable edge OS and SLSA-3 conformance to simplify baseline platform maintenance.

**Trade-Off / Risk:** Increasing red-teaming frequency guarantees faster vulnerability identification, but it imposes a substantial, upfront increase in specialized contractor costs that strains the overall Program Management Office budget envelope.

**Strategic Connections:**

**Synergy:** Complements Cyber Security Verification Cadence by providing the independent, high-assurance validation necessary for the Zero-Trust implementation; it ensures SLSA-3+ requirements are met continuously.

**Conflict:** Accelerating security verification significantly increases the IV&V budget requirement, creating budgetary friction with the overall Program Procurement Lot Management Structure funding allocations.

**Justification:** *High*, Accelerating verification (red-teaming) directly addresses the front-loaded security governance constraint. It impacts the budget significantly but is essential for proving the Zero-Trust architecture prior to IOC.

### Decision 12: Program Procurement Lot Management Structure
**Lever ID:** `eeda2503-80cb-4268-b95c-81900e98350b`

**The Core Decision:** This lever defines how the project segments its €200M scope into manageable procurement contracts, specifically for sensors/algorithms (Lots A/B/C), integration, and IV&V. The chosen structure dictates the distribution of technical risk and integration complexity. Success lies in achieving competitive pressure while ensuring the disparate components integrate seamlessly to meet multi-view tracking KPIs.

**Why It Matters:** The plan defines competitive Lots A/B/C (sensors/algorithms), Integration/Edge/Network, and IV&V. Consolidating Lots A/B/C into a single 'System Integrator' contract simplifies vendor management and fosters tighter supply chain control, but it concentrates technical risk, making slippage in any sensor modality immediately bottleneck the entire deployment schedule.

**Strategic Choices:**

1. Combine Lots A/B/C (sensors/algorithms) into a single, sole-source framework agreement with the leading platform vendor, ensuring full vertical integration compatibility at the cost of competitive pricing pressure.
2. Maintain three separate, competitive Lot A/B/C procurement streams, but enforce extremely narrow, non-negotiable interface compatibility standards (hardware form factor, power delivery) to mitigate cross-vendor integration friction.
3. Decouple the Algorithm development (Lot C) entirely from the Sensor procurement (Lots A/B) by running the algorithm selection via a 'Hardware Agnostic' API competition until after the Pilot Acceptance gate.

**Trade-Off / Risk:** Consolidating sensor and algorithm lots streamlines vendor coordination, yet it critically concentrates technical failure risk onto one entity, potentially stalling the entire Phase 1 schedule if that prime vendor underperforms.

**Strategic Connections:**

**Synergy:** Amplifies the Sensor Modality Integration Strategy by structuring the contracts that deliver those components, and enables the Cyber Security Verification Cadence by separating the IV&V lot.

**Conflict:** Concentrating risk by merging Lots A/B/C conflicts with the schedule stability required for the timeline compliance of the Phase 1 pilot at CPH and AAL in 2026.

**Justification:** *High*, This structure determines how technical risk is distributed. Consolidating sensor/algorithm lots concentrates technical risk, which directly threatens the fixed timeline for Phase 1 pilot acceptance at CPH/AAL.
