**Goal Statement:** Successfully complete the 24-month EASA SkyNet Sentinel program, achieving all specified performance KPIs (Pd, 3D Accuracy, Latency, Availability) and deploying localized sUAS tracking via DLT triangulation across Phase 1 pilots (CPH, AAL) by M+18 and achieving Full Operational Capability (FOC) by M+24.

## SMART Criteria

- **Specific:** Launch, stabilize, and secure a real-time, localized sUAS detection and 3D triangulation system using irregular PTZ clusters, ensuring passage of all mandatory governance gates (PDR, CDR, Pilot Acceptance, IOC, FOC) and meeting all non-negotiable engineering KPIs and security mandates.
- **Measurable:** Completion is measured by passing the FOC gate (M+24) with required KPI metrics met (Pd ≥90% day, Latency ≤750 ms UI, 3D Accuracy P90 ≤2.0 m) and successful completion of all required acceptance documentation (calibration handbooks, heatmaps, live exercises).
- **Achievable:** The strategy of prioritizing Teams A/B fusion and deferring Team C/full STANAG standardization simplifies the M+18 Pilot Acceptance, making the initial schedule achievable, leveraging an expert EASA governance framework and a €200M budget.
- **Relevant:** The project is relevant as a high-priority governmental/societal security infrastructure initiative aimed at localizing and managing unauthorized drone activity across European airports, directly improving airport availability metrics.
- **Time-bound:** The final commitment (FOC) must be achieved within 24 months of mobilization (Q4-2025), with Phase 1 pilots completed by M+18 (mid-2027).

## Dependencies

- Mobilization and RFP issuance completed by Q4-2025.
- Procurement Lots A/B/C, Integration/Edge/Network, and IV&V framework agreements established.
- EASA oversight and PMO established for gate enforcement.
- Securing operational waiver approvals for 10–40m PTZ cluster heights.
- Completion of initial sensor/algorithm design review to support M+4 PDR gate.
- Successful establishment of the PTP IEEE-1588 synchronization network with GPSDO support (≤1ms error) prior to integration testing.
- Completion of initial environmental and privacy impact assessments prior to physical deployment.
- Staffing of critical roles: Senior Geodesy Engineer and Network Synchronization Specialist by Q4-2025 (pre-PDR).

## Resources Required

- €200M Program Budget (split €50M Phase 1, €150M Phase 2)
- Irregular PTZ Camera Clusters (Optical, MWIR/LWIR Thermal sensors)
- RF/Acoustic Sensor Payloads (For Team C, deferred integration)
- Edge Nodes with GPU, Secure Boot, and TPM hardware
- RTK-GNSS Reference Equipment and dedicated flight charter hours (4 hrs/week/airport post-PDR)
- Software stack incorporating DLT, JPDA/MHT-lite fusion, covariance propagation.
- Third-party Independent Verification & Validation (IV&V) services (with accelerated quarterly Red-Teaming).

## Related Goals

- Achieving NATO/STANAG and EUROCONTROL/ASTERIX compliance for data export (Post-IOC/FOC).
- Developing and certifying national authority controlled non-kinetic countermeasure activation.
- Establishing and maturing the long-term maintenance and drift correction charter for 30+ airports post-FOC.

## Tags

- UAS
- sUAS
- Localization
- DLT
- Triangulation
- Sensor Fusion
- EASA
- Cybersecurity
- Zero Trust
- PTP Synchronization

## Risk Assessment and Mitigation Strategies


### Key Risks

- Failure to meet M+18 Pilot Acceptance KPIs due to complexity of sensor fusion (Optical/Thermal only for Phase 1).
- Geometric instability causing 3D accuracy KPIs (P50 <1.0m) failure due to reliance on initial control points over time.
- Critical timeline breach due to complex regulatory approval process for non-standard mounting heights (10-40m).
- Data integrity failure due to reliance on temporary EDXP wrapper solution instead of full STANAG/ASTERIX mapping by required gates.

### Diverse Risks

- Cyber vulnerability exploiting initial Zero-Trust implementation before twice-yearly red-teaming can identify flaws (MTTD too high).
- Procurement delays for high-end GPU/TPM edge hardware impacting the Q4-2025 mobilization timeline.
- Scheduling conflict where geometric RTK-GNSS flight time competes directly with critical sensor integration testing.

### Mitigation Plans

- Implement Sensor Modality Integration Strategy: Defer RF/Acoustic (Team C) integration until post-IOC to focus engineering resources solely on achieving Pd/Accuracy KPIs with Optical/Thermal fusion for M+18.
- Implement DLT Geometry Qualification Velocity strategy: Mandate weekly RTK-GNSS flights coupled with landmark resection checks post-PDR to immediately detect and characterize geometric drift, informing a re-survey budget decision by M+12.
- Front-load Regulatory Engagement: Immediately schedule meetings with EASA and CAAs (Danish/Hungarian) in Q4-2025 to present the Unified Operational Compliance Document required for the non-standard 30-40m mounting height waiver.
- Isolate Protocol Standardization: Utilize a temporary wrapper for EDXP format validation against simulated ASTERIX during Phase 1/Pilot, deferring complex NATO/STANAG adherence until M+20/FOC to de-risk the M+18 acceptance gate.
- Accelerate Security Verification: Increase independent security red-teaming cadence to quarterly (starting pre-CDR) to drastically reduce MTTD for Zero-Trust/SLSA-3+ architecture flaws, even if it increases IV&V budget.
- Secure Critical Hardware Early: Finalize competitive Lot selections for high-value hardware (GPU/TPM) by M+4 PDR to lock in pricing and supply chain visibility, mitigating financial/supply chain risks.

## Stakeholder Analysis


### Primary Stakeholders

- EASA (Program Regulator and Governance Chair)
- Program Management Office (PMO)
- Team A/B/C Sensor/Algorithm Integrators (Procurement Winners)
- System Integration & Edge/Network Teams (Procurement Winners)
- IV&V Partner (Independent Verification & Validation)

### Secondary Stakeholders

- National Aviation Authorities (Danish CAA, Hungarian CAA, other Member-State authorities)
- EUROCONTROL / NATO Standardization Bodies (Protocol consumers)
- Airport Operators (CPH, AAL, 30 other sites)
- National Security/Countermeasure Authorities

### Engagement Strategies

- EASA Steering Committee: Monthly progress review against governance gates (PDR, CDR, etc.) and empowered mandate enforcement.
- PMO: Bi-weekly technical synchronization meetings with all Integration leads to track KPI performance against Decision 10 monitoring output.
- National Aviation Authorities: Formal presentation and required waiver application submission by M+4, followed by mandatory bi-monthly updates regarding sensor mounting and operational safety assurance documents.
- NATO/EUROCONTROL: Deliver EDXP v0.9 specification review package by M+10 CDR, followed by required interface validation inputs by M+18 Pilot Acceptance.
- Airport Operators: Quarterly updates detailing site integration schedules, access requirements for cluster installation (10-40m), and scheduling of RTK-GNSS flight windows.

## Regulatory and Compliance Requirements


### Permits and Licenses

- EASA Certification/Type Deviation Waiver for non-standard 10–40m sensor mast installation height.
- Site Access and Construction Permits (CPH and AAL local authorities).
- Frequency Spectrum Licensing for RF payloads (Team C, deferred but requires planning).
- International Data Transfer Approvals for NATO/STANAG feeds (Phase 2).

### Compliance Standards

- Cybersecurity: Zero-Trust architecture adherence, TPM identity management, SBOM generation, SLSA-3+ provenance.
- Data Export: Mapping adherence to EUROCONTROL/ASTERIX and NATO/STANAG data format specifications.
- Synchronization: PTP IEEE-1588 compliance with GPSDO referenced synchronization error ≤1 ms.
- Data Privacy: GDPR compliance regarding metadata-first transport, privacy zones, auto-redaction, and retention ≤30 days.

### Regulatory Bodies

- European Union Aviation Safety Agency (EASA) - Primary oversight and gate enforcement.
- Danish Civil Aviation Authority (Danish CAA)
- Hungarian Civil Aviation Authority (Hungarian CAA)
- National Competent Authorities (for countermeasure deployment authorization)

### Compliance Actions

- Submit initial EASA waiver request for sensor height deviation by M+1 (Nov 2025).
- Complete security hardening audit (TPM, Secure Boot, mTLS pinning) for edge nodes by CDR (M+10).
- Schedule Privacy Impact Assessment sign-off (including auto-redaction validation) before Pilot Acceptance (M+18).
- Implement and audit critical patch SLO adherence (≤7 days) monitored by SOC starting from M+4.