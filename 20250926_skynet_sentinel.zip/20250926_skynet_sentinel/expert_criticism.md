# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Regulatory Compliance Specialist

**Knowledge**: aviation regulations, EASA compliance, project governance

**Why**: Essential for navigating EASA's regulatory landscape and securing necessary waivers for sensor heights.

**What**: Review and refine the operational compliance document for EASA submission.

**Skills**: regulatory analysis, compliance documentation, stakeholder engagement

**Search**: EASA compliance consultant, aviation regulatory expert, project governance specialist

## 1.1 Primary Actions

- Immediately convene the EASA Steering Committee to formally resolve the inherent conflict between 'The Builder' strategy's deferred Team C integration and the mandatory poor-weather Pd KPI requirements for M+18.
- Elevate the Senior Geodesy Engineer (or assign a high-level expert immediately) to model the P90 3D accuracy degradation based on weekly RTK data, establishing a clear, data-driven 'Go/No-Go' trigger for mandatory geometric re-surveying before M+18.
- The PMO must present a binding financial remediation plan to the Steering Committee within 30 days that explicitly funds the accelerated quarterly security Red-Teaming cadence without impacting the €50M Phase 1 budget slated for Sensor Integration (Lots A/B).

## 1.2 Secondary Actions

- Finalize and submit the Unified Operational Compliance Document for the 10-40m sensor mounting height waiver request to EASA, Danish CAA, and Hungarian CAA within the next 30 days (by 2025-Oct-26).
- Task the IV&V partner to define the success criteria for the interim certification of the adverse weather Pd KPI based on high-fidelity simulation/Team C proof-of-concept by M+10 CDR.
- Establish immediate engineering task forces to rigorously map the performance ceiling imposed by the mandated homogeneous edge compute hardware on the specialized requirements of the deferred Team C pipeline, quantifying the feasibility margin.

## 1.3 Follow Up Consultation

We must review the Steering Committee's formal decision on the M+18 acceptability of deferred sensor modalities (Team C) versus the stated performance envelope. Secondarily, review the Geometric Risk Model output to confirm the validity of the 'accept drift degradation' trade-off and verify that the contingency budget for re-surveying is provisioned post-PDR.

## 1.4.A Issue - Fundamental Conflict Between Strategy and Non-Negotiable Constraints

The chosen strategy, 'The Builder: Pragmatic Phase-In,' explicitly accepts deferring critical components (Team C, full protocol standardization) to achieve the M+18 Pilot Acceptance Gate. However, the initial plan (initial-plan.txt) mandates absolute failure conditions if specific KPIs are not met, such as Pd ≥80% night/poor wx, and requires dual protocol mapping validation *before* acceptance gates in several implied areas. By deferring Team C (RF/Acoustic) — the key component for poor weather classification — the project bets its entire FOC success on a post-IOC integration that may fail, yet the M+18 gate will likely require proof that *all* advertised capabilities are feasible, not just the daytime ones. Furthermore, the decision to use a temporary EDXP wrapper/simulated ASTERIX skips full NATO/STANAG proofing until M+20/FOC, which directly contradicts the intent of front-loading interoperability for Phase 2.

### 1.4.B Tags

- Strategic_Inconsistency
- KPI_Risk
- Regulatory_Exposure

### 1.4.C Mitigation

Immediately task the EASA Steering Committee to formally document acceptable interim certification metrics for the adverse weather Pd KPI (Team C capability) at M+18. The project must define a 'Minimum Viable Proof' of Team C feasibility (e.g., simulation results validated by IV&V) by CDR (M+10). Crucially, review the M+18 Pilot Acceptance criteria: if it requires physical demonstration of poor-weather Pd, the 'Builder' strategy fails immediately. Consult the EASA framework guidance on phased regulatory acceptance for multi-modal systems. Provide data showing simulation fidelity for Team C performance.

### 1.4.D Consequence

The M+24 FOC will be unreachable because the system certified at M+18 will be fundamentally incomplete regarding its weather performance envelope, leading to a hard regulatory block on operational deployment or immediate demands for costly parallel development post-IOC.

### 1.4.E Root Cause

Empty

## 1.5.A Issue - Unsustainable Geometric Maintenance Dependency and Drift Risk

The plan mandates weekly RTK-GNSS flights for drift checks (DLT Geometry Qualification Velocity) but the chosen strategy (Option 1) seeks to maximize utilization of these initial flights by only using the 'initial six surveyed control points' and accepting degradation post-M+18. This is incompatible with the hard constraint of maintaining P90 3D accuracy ≤2.0m at 1.5 km. Highly precise PTP synchronization (≤1ms) implies extreme sensitivity to platform movement relative to control points. Weekly checks are insufficient if the degradation curve is steep, and relying solely on initial static points for dynamic extrusion correction is a recipe for calibration collapse. The required schedule velocity is directly threatened by the scheduled flight time competing with integration tasks, as noted in the documents.

### 1.5.B Tags

- Geodetic_Fragility
- Schedule_Conflict
- KPI_Saturation

### 1.5.C Mitigation

Immediately elevate the Senior Geodesy Engineer (identified as required in 'Missing Information') to the leadership track. Task them to produce a quantified Geometric Risk Model by M+4 (PDR). This model must define the exact P90 degradation rate (m/year) if no re-survey is conducted, and establish a hard engineering 'trigger' (e.g., 1.2x PDR variance) mandating an immediate, funded re-survey charter, independent of budget debates. Consult the RTK-GNSS equipment vendor specs regarding long-term baseline stability under vibration/thermal load.

### 1.5.D Consequence

Failure to transition from weekly checks to a predictive drift model (triggered by tangible KPIs) will result in verifiable 3D accuracy KPI failure leading up to IOC/FOC, forcing a mandatory, high-cost system recall/re-survey cycle just as Phase 2 is rolling out.

### 1.5.E Root Cause

Empty

## 1.6.A Issue - Budget/Scope Conflict: Accelerated Cyber Cadence vs. Phase 1 Fixed Cost

The plan mandates accelerating the Cyber Security Verification Cadence—moving from bi-annual to quarterly Red-Teaming—which is a high-assurance necessity for a Zero-Trust mandate. However, this carries a substantial, immediate increase in external IV&V costs (Decision 11). Simultaneously, the project has a fixed budget of €50M for Phase 1 (M+18), and the 'Builder' strategy diverted engineering effort away from core tracking to simplify the M+18 gate. There is no clear funding mechanism identified to absorb the accelerated, mandatory quarterly cybersecurity verification cost without impacting the sensor integration (Lots A/B) workstream that *must* meet its KPIs for M+18 success. This indicates an unbudgeted expenditure risk immediately post-PDR.

### 1.6.B Tags

- Budget_Risk
- Scope_Creep
- Governance_Cost

### 1.6.C Mitigation

The PMO must immediately provide the Steering Committee with a dedicated funding source or scope reduction proposal to cover the delta cost of quarterly Red-Teaming vs. bi-annual baseline for the first 18 months. Consult the Procurement Lot Manager against the IV&V framework agreement immediately to obtain firm quotes on the accelerated cadence. If funding cannot be secured, the project must formally downgrade the robustness of *another* high-assurance requirement (e.g., extend Patch SLO from 7 days to 15 days, or scale back the Scope of SLSA-3+ verification) to offset the cybersecurity cost. Do not let this erode sensor integration funding.

### 1.6.D Consequence

If remediation is not taken, the engineering effort for critical Lots A/B will be prematurely de-scoped in favor of funding the mandatory, accelerated IV&V activities, guaranteeing failure on the Pd and 3D accuracy KPIs at the M+18 Pilot Acceptance gate.

### 1.6.E Root Cause

Empty

---

# 2 Expert: Sensor Integration Engineer

**Knowledge**: sensor fusion, optical systems, thermal imaging

**Why**: Critical for establishing and managing sensor integration teams to meet KPI targets.

**What**: Develop integration plans and timelines for Teams A and B to ensure timely KPI achievement.

**Skills**: project management, technical integration, team leadership

**Search**: sensor integration engineer, optical systems engineer, thermal imaging specialist

## 2.1 Primary Actions

- Reassess the integration timeline for Team C and explore options for parallel development.
- Implement a dedicated RTK-GNSS calibration flight crew to ensure timely drift checks.
- Schedule an immediate meeting with EASA and local CAAs to secure necessary waivers.

## 2.2 Secondary Actions

- Engage RF/Acoustic experts to identify quick wins for integration.
- Consider automating drift checks using AI-driven feature matching.
- Prepare alternative plans for sensor deployment to mitigate potential delays.

## 2.3 Follow Up Consultation

Discuss the revised integration timeline for Team C, the status of drift checks, and the outcomes of the regulatory engagement meetings.

## 2.4.A Issue - Integration Complexity Risks

The decision to defer the RF/Acoustic sensor integration (Team C) poses significant risks to the overall system performance, particularly in adverse weather conditions. This could lead to failure in meeting the ≥80% detection KPI at FOC, jeopardizing the project's credibility.

### 2.4.B Tags

- integration
- risk
- performance

### 2.4.C Mitigation

Reassess the integration timeline for Team C and explore options for parallel development or early prototyping to ensure that RF/Acoustic capabilities can be validated before the M+18 gate. Engage with RF/Acoustic experts to identify potential quick wins that can be integrated without significant delays.

### 2.4.D Consequence

Failure to address this could result in a critical shortfall in detection capabilities during adverse weather, leading to project delays and potential regulatory non-compliance.

### 2.4.E Root Cause

The prioritization of optical and thermal sensors over RF/Acoustic integration without a clear fallback strategy.

## 2.5.A Issue - Geometric Drift Management

The reliance on weekly RTK-GNSS checks for geometric stability creates a scheduling bottleneck that could delay integration testing and ultimately impact the M+18 acceptance gate. If drift checks are not timely, the accuracy KPIs may not be met.

### 2.5.B Tags

- geometric
- scheduling
- drift

### 2.5.C Mitigation

Implement a dedicated RTK-GNSS calibration flight crew that operates in parallel with software integration teams. Additionally, consider automating some aspects of drift checks using AI-driven feature matching to reduce reliance on manual checks.

### 2.5.D Consequence

If drift checks are delayed, the project risks failing to meet the P50 accuracy KPI, leading to potential regulatory issues and project delays.

### 2.5.E Root Cause

High dependency on manual processes for geometric validation without a robust backup plan.

## 2.6.A Issue - Regulatory Engagement Delays

The timeline for engaging with EASA and local CAAs regarding the necessary waivers for sensor heights is too tight. Delays in securing these waivers could lead to significant project delays and impact the overall schedule.

### 2.6.B Tags

- regulatory
- engagement
- timing

### 2.6.C Mitigation

Schedule an immediate meeting with EASA and local CAAs to present the Unified Operational Compliance Document. Follow up bi-weekly until all approvals are secured. Additionally, prepare alternative plans for sensor deployment that could mitigate the impact of any delays.

### 2.6.D Consequence

Failure to secure waivers in time could halt the project, leading to missed deadlines and increased costs.

### 2.6.E Root Cause

Insufficient early engagement with regulatory bodies and lack of a proactive approach to compliance.

---

# The following experts did not provide feedback:

# 3 Expert: Cybersecurity Auditor

**Knowledge**: Zero-Trust architecture, cybersecurity protocols, risk assessment

**Why**: Vital for validating the cybersecurity framework and ensuring compliance with Zero-Trust principles.

**What**: Conduct a cybersecurity audit to validate compliance with established protocols and identify vulnerabilities.

**Skills**: risk management, security auditing, compliance verification

**Search**: cybersecurity auditor, Zero-Trust consultant, security compliance expert

# 4 Expert: Environmental Impact Consultant

**Knowledge**: environmental assessments, regulatory compliance, stakeholder engagement

**Why**: Necessary for conducting environmental impact assessments to mitigate potential delays.

**What**: Initiate environmental impact assessments for CPH and AAL locations focusing on wildlife and regulations.

**Skills**: environmental analysis, regulatory compliance, community engagement

**Search**: environmental impact consultant, regulatory compliance specialist, environmental assessments expert

# 5 Expert: Geospatial Metrology Expert

**Knowledge**: RTK-GNSS, geodesy, 3D triangulation accuracy, spatial data uncertainty

**Why**: Directly addresses the high-friction dependency of weekly RTK-GNSS checks and geometric degradation risk for the 3D accuracy KPI.

**What**: Analyze the geometric drift risk post-M+18 and propose criteria for a mandatory geometric re-survey.

**Skills**: metrology, error propagation, geospatial analysis, GNSS surveying

**Search**: geospatial metrology expert, DLT resection specialist, RTK-GNSS calibration

# 6 Expert: Defense Interoperability Protocol Analyst

**Knowledge**: NATO STANAG, EUROCONTROL ASTERIX, data standardization

**Why**: Crucial for managing the deferred/wrapper strategy for EDXP mapping to NATO/EUROCONTROL standards ahead of Phase 2.

**What**: Assess the long-term viability and friction points of the temporary EDXP wrapper solution versus full STANAG integration.

**Skills**: protocol translation, data standards compliance, ATC messaging

**Search**: NATO STANAG analyst, EUROCONTROL ASTERIX expert, data protocol harmonization

# 7 Expert: High-Assurance Hardware Procurement Specialist

**Knowledge**: TPM hardware, secure boot systems, supply chain risk management

**Why**: Needed to mitigate procurement risk associated with high-end, specialized edge hardware (GPU/TPM).

**What**: Develop an accelerated procurement strategy for critical lots (GPU/TPM) to secure supply by PDR (M+4).

**Skills**: vendor management, hardware specification, supply chain security

**Search**: high assurance hardware procurement, TPM integration specialist, defense electronics sourcing

# 8 Expert: UX/CONOPS Design Specialist

**Knowledge**: Human-machine interface, operational workflow, cognitive load reduction

**Why**: Required to validate the complex ADVISORY/WARNING/CRITICAL states against operator performance and latency KPIs.

**What**: Review the proposed three-state CONOPS model against the 750ms latency KPI to optimize operator cognitive load.

**Skills**: human factors engineering, control room design, operational workflow modeling

**Search**: cognitive systems engineer, CONOPS design specialist, HMI security compliance