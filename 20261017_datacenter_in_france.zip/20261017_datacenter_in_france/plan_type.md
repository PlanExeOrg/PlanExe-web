This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is a feasibility study and phased development plan for a 9 GW, 161 km² hyperscale AI data center campus in Hauts-de-France, France. It is classified as physical. It cannot be executed online, and nearly every workstream depends on real-world locations, construction and on-site activity. Examples:

- Land assembly: assembling about 161 km² across Cambrai / E-Valley, Valenciennes / Denain / Escaudain, Dunkirk and Saint-Omer needs site visits, parcel surveys, negotiations with landowners and farmers, and brownfield investigation and remediation.
- Environmental baselines: ecology, hydrology, soil contamination and water-system studies must be measured in the field.
- Grid and power: RTE and EDF engagement leads to dedicated substations, transmission upgrades, BESS and limited backup generation. These are physical infrastructure.
- Construction: 50-100+ data halls, liquid-cooling loops, an optional 50-100 MW immersion pilot, heat-reuse infrastructure, roads and logistics, and stormwater works all need construction labor, heavy equipment and materials.
- Hardware: GPU/TPU and networking hardware must be procured, shipped, installed and tested in physical halls.
- Connectivity: diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea routes requires trenching, route surveys and physical interconnection.
- Security: a hardened perimeter, anti-drone systems and sabotage resilience are on-site measures. National-security and permitting reviews involve in-person processes with prefectural and state authorities.
- People: community engagement, public consultation, workforce training programs and stakeholder meetings happen in person. Tenant validation involves site tours and negotiations.
- Workspace: the 180-day action plan needs project offices and physical travel in the region.

Any financial modeling, document drafting or tenant analysis within the plan is a supporting activity. It cannot stand alone, because the plan's outcome is a physical campus or a physical decision about land, grid and communities. Physical activity benefits every major part of the plan, so "digital" does not apply.