A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | RTE will give a written preliminary feasibility letter for at least 500 MW within 36 months by Month 6 (2027-04-17), and a conditional pass is acceptable to lenders and tenants. | File a written pre-engineering request at Month 0 (2026-10-17) for 500 MW, 1 GW and 2 GW tranches. Ask RTE for its response timeline in writing. Commission the independent grid audit. | RTE declines a written date before Month 6 (2027-04-17), indicates under 500 MW per node, or cites competing industrial loads that saturate Nord 400 kV capacity. |
| A2 | Anchor tenants will sign binding take-or-pay terms with reservation fees for at least 150 MW by Month 9 (2027-07-17), before EDF energy pricing is fixed. | Offer the reservation-fee term sheet (EUR 10M-50M per 100 MW, proposed) to 4-6 named prospects by Month 2 (2026-12-17). Record who pays fees into escrow versus who only gives LOIs. | By Month 5 (2027-03-17) no prospect agrees to escrowed fees, or prospects make signing conditional on firm energy pricing above EUR 75/MWh (estimate). |
| A3 | The independent investment committee will enforce numeric kill thresholds against sponsor and co-investor momentum after EUR 400M-600M of sunk Phase 0 spend. | Draft the charter with lenders and co-investors before tranche 1 release. Test whether each party accepts tranche escrow, lender consent on dissent and a two-thirds override rule (proposed). | Sponsor or co-investors refuse tranche release tied to committee sign-off, or insist on sponsor-board override rights, before Month 1 (2026-11-17). |
| A4 | Land parcels in the Cambrai/E-Valley zone can be optioned non-coercively at no more than 15% above benchmark land value (proposed threshold), with lease-and-continue farming accepted by most owners. | Commission the parcel and holdout survey in Month 1 (2026-11-17). Open option talks with 20 owners and the farm unions by Month 2 (2026-12-17). Record asking prices against EUR 15,000-25,000/ha (estimate). | By Month 3 (2027-01-17) under 70% of the target parcel is optionable at no more than 15% above benchmark, or holdouts ask above 2.0x benchmark (estimate). |
| A5 | Closed-loop dry cooling with no evaporative water will hold a modelled PUE of at most 1.30 on a 35°C design day, and the water authority will accept it in writing. | Commission the independent thermal audit and hydrology study in Month 1 (2026-11-17). Send the written water-authority request in Month 1 (2026-11-17). Model 100, 150 and 200 W/m² scenarios using vendor curves. | Modelled PUE exceeds 1.30 at 35°C by Month 5 (2027-03-17), or the water authority requires evaporative backup or drought load-shedding that tenants reject. |
| A6 | ANSSI/DGSI and foreign-investment screening will let the co-investor structure and mixed tenant base proceed, with formal review starting at Month 13 (2027-11-17) and no blocking concern. | Hold the confidential pre-submission meeting in Months 0-1 (2026-10-17 to 2026-11-17) with the security white paper. Ask in writing for the review scope and timeline. | By Month 6 (2027-04-17) the informal opinion names a blocking concern on foreign equity or tenant mix, or signals clearance beyond Month 31 (2029-05-17). |
| A7 | Senior lenders will commit at least EUR 3B for the 500 MW tranche at about benchmark +200 bps with a tenor of at least 12 years by Month 12 (2027-10-17), even with only 30% of Phase 1 signed and a conditional RTE position. | Send a shadow term sheet and DSCR model (1.34x base, 1.15x at a 10% lease discount) to 3 lenders by Month 3 (2027-01-17). Ask each for written credit-committee conditions. | By Month 6 (2027-04-17) fewer than 2 lenders indicate EUR 3B at the stated terms, or they require more than 50% of Phase 1 signed or leverage below 53%. |
| A8 | Phase 1 can be built with prefabricated halls and the regional trades pool without trade wage inflation above 20-40% (estimate) or delays from shortages of electricians and cooling technicians. | Request binding indicative bids and labour plans from 2 large EPC firms by Month 4 (2027-02-17). Survey regional technical colleges and unions on available capacity by Month 3 (2027-01-17). | EPC bids price trades above 40% inflation (estimate), or firms cannot staff the 8-10 halls (estimate) within the Months 12-36 (2027-10-17 to 2029-10-17) window. |
| A9 | Farm unions, NGOs and at least 2 of the 3 most affected municipalities will accept the community-benefit package of EUR 50M-150M (estimate) and Phase 1 jobs claims once the 50-150 FTE (not verified) headcount is disclosed. | Run the social-impact survey in Month 1 (2026-11-17) and publish the real operations headcount at the first liaison meeting. Record each municipality's stated position in writing. | By Month 6 (2027-04-17) fewer than 2 of 3 municipalities are neutral or supportive in writing, or farm unions announce legal challenge plans. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Momentum Override | Process/Financial | A3 | Independent Investment Committee Chair | CRITICAL (20/25) |
| FM2 | The Sub-Gigawatt Grid | Technical/Logistical | A1 | Grid Connection and Power Infrastructure Strategist | CRITICAL (20/25) |
| FM3 | The Letter-of-Intent Mirage | Market/Human | A2 | Anchor-Tenant and Market Development Lead | CRITICAL (16/25) |
| FM4 | The Holdout Premium Spiral | Process/Financial | A4 | Land Assembly and Real Estate Strategist | CRITICAL (16/25) |
| FM5 | The Heat-Day Derate | Technical/Logistical | A5 | Thermal, Cooling and Hydrology Engineer | HIGH (12/25) |
| FM6 | The Sovereignty Squeeze | Market/Human | A6 | National Security and Regulatory Affairs Lead | CRITICAL (15/25) |
| FM7 | The Debt That Never Closed | Process/Financial | A7 | Infrastructure Finance and Capital Structure Lead | CRITICAL (20/25) |
| FM8 | The Empty Crane Yard | Technical/Logistical | A8 | Phase 0 Program Manager and Red Team Lead | HIGH (12/25) |
| FM9 | The Jobs Promise Backlash | Market/Human | A9 | Community Engagement and Social License Manager | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Momentum Override

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Independent Investment Committee Chair
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- The EUR 750M cap front-loads EUR 400M by Month 6 (2027-04-17), before RTE's letter arrives.
- The Month 4 (2027-02-17) topology default forces split-campus rework (EUR 100M-250M, estimate).
- Sponsor and co-investors reframe failed thresholds as 'conditional passes'.
- Phase 1 FID proceeds on weak evidence, with stacked add-ons of EUR 1.55B-4.2B (estimate) unfunded.
- Result: a stranded Phase 0 plus covenant stress (DSCR 1.15x under a 10% discount).

##### Early Warning Signs
- Committee charter unsigned at Month 1 (2026-11-17)
- Tranche 2 requested before a written topology decision
- Cumulative spend above plan at Month 6 (2027-04-17)
- Thresholds reworded as 'targets' in board papers

##### Tripwires
- Charter not signed by lenders by Month 1 (2026-11-17)
- Cumulative Phase 0 spend >= EUR 400M before the Month 4 (2027-02-17) topology decision
- Any tranche overspend >= 15%
- Override vote proposed on a failed numeric threshold

##### Response Playbook
- Contain: Freeze the next tranche in escrow and halt discretionary Phase 0 spend above EUR 5M until the committee votes.
- Assess: Red team scores every threshold pass/fail within 10 business days and publishes the dissent record to lenders.
- Respond: Downsize to 250 MW, pause or cancel per the pre-agreed decision matrix. Do not renegotiate thresholds.


**STOP RULE:** Cancel or pause Phase 1 if any locked numeric threshold fails at Month 12 (2027-10-17) and the two-thirds override is not obtained.

---

#### FM2 - The Sub-Gigawatt Grid

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Grid Connection and Power Infrastructure Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- RTE answers late or offers under 500 MW per node because steel, hydrogen and refinery loads saturate the Nord 400 kV network.
- The topology locks to split campus by calendar at Month 4 (2027-02-17), before the Month 6 (2027-04-17) letter.
- Reinforcement co-funding reaches EUR 500M-1.5B (estimate), and hot-weather PUE of 1.35-1.5 adds 5-15% peak load.
- Curtailment above 15% breaks tenant SLAs.
- Energization slips to Months 48-60 (2030-10-17 to 2031-10-17).

##### Early Warning Signs
- No RTE written date by Month 3 (2027-01-17)
- Independent audit shows under 500 MW per node
- Modelled PUE above 1.30 at 35C
- Reinforcement scope estimate above EUR 1.0B

##### Tripwires
- No RTE written preliminary letter by Month 6 (2027-04-17)
- RTE indicates < 500 MW at any candidate node
- Required curtailment >= 15% annually
- Reinforcement co-funding estimate >= EUR 1.0B

##### Response Playbook
- Contain: Pause new land option spend and at-risk pre-engineering above EUR 10M until RTE evidence arrives.
- Assess: Audit firm re-models each node for 250, 500 and 750 MW and prices reinforcement, BESS and PUE-driven peak load.
- Respond: Re-baseline Phase 1 to the MW RTE can support, switch to split campus or delay per the committee decision matrix.


**STOP RULE:** Cancel Phase 1 if RTE confirms under 500 MW within 36 months across all candidate nodes by Month 12 (2027-10-17).

---

#### FM3 - The Letter-of-Intent Mirage

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Anchor-Tenant and Market Development Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Hyperscalers hold LOIs across 8-12 European sites and commit only 6-12 months before power-on.
- Sovereign procurement runs 18-36 months.
- Tenants decline to sign without firm EDF pricing; a +EUR 30/MWh shock cuts DSCR to 0.96x without pass-through.
- Farm unions and mayors see no firm demand and harden opposition.
- Signed demand stays under 150 MW and debt of EUR 3B fails.

##### Early Warning Signs
- Prospects decline escrowed reservation fees
- Requests to defer signing until energy pricing is fixed
- No site visits or technical questions from named prospects
- EDF indicative price above EUR 70/MWh

##### Tripwires
- Binding signed MW < 150 at Month 9 (2027-07-17)
- No escrowed reservation fees by Month 6 (2027-04-17)
- EDF indicative price > EUR 70/MWh by Month 6 (2027-04-17)
- Fewer than 2 prospects at BBB- or parent-guaranteed by Month 7 (2027-05-17)

##### Response Playbook
- Contain: Stop pre-construction commitments and treat all LOIs as zero demand in gate reporting.
- Assess: Interview each prospect on the blocking condition (price, latency, sovereignty, timing) and rescore the pipeline.
- Respond: Resize Phase 1 to signed MW (250 MW), add price-shock clauses and defer Phase 2, or exit.


**STOP RULE:** Do not take Phase 1 FID if signed binding take-or-pay with fees paid is under 30% of Phase 1 size at Month 12 (2027-10-17).

---

#### FM4 - The Holdout Premium Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Land Assembly and Real Estate Strategist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Option talks leak and owners learn the buyer is a hyperscale sponsor.
- Asking prices pass 2.0x benchmark (estimate), so the 70% option gate fails.
- Cash spent on options and surveys is stranded when the topology flips to split campus.
- Split-from-start work adds EUR 100M-250M (estimate) and breaches the EUR 750M cap.
- Land cost rises from EUR 0.24B-0.40B, and lenders see weak site control.

##### Early Warning Signs
- Fewer than 40% of owners reply to option offers by Month 2 (2026-12-17)
- Asking prices above 1.5x benchmark on key parcels
- Farm unions publicly reject lease-and-continue
- Option spend running ahead of the tranche 1 plan

##### Tripwires
- Optioned share < 70% of target parcel at Month 3 (2027-01-17)
- Average premium > 15% above benchmark
- Holdout count >= 25 on core parcels
- Land and option spend >= EUR 60M before the Month 4 (2027-02-17) topology decision

##### Response Playbook
- Contain: Freeze new option payments and stop public statements naming parcels.
- Assess: Rebuild the parcel map, re-price each zone and cost the split-campus alternative per node.
- Respond: Switch to split campus on parcels at 80% or more optioned, or drop the zone if none qualify.


**STOP RULE:** Drop a topology if under 70% of its parcel (80% per split node) is optioned within 15% of benchmark at Month 12 (2027-10-17).

---

#### FM5 - The Heat-Day Derate

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Thermal, Cooling and Hydrology Engineer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Vendor curves are optimistic, and fouling and part-load losses are missed.
- Modelled PUE on a 35°C day reaches 1.35-1.5 (estimate), adding 5-15% peak grid load.
- The load exceeds the RTE offer or the curtailment cap, and tenants face derates against 99.5% SLAs.
- The water authority refuses dry-only cooling, or a drought rule forces load-shedding.
- Hybrid retrofit costs EUR 50M-100M (estimate) and reopens permitting.

##### Early Warning Signs
- Vendors refuse performance guarantees at 35°C
- Hydrology study shows drought declarations in recent summers
- Water authority asks for evaporative backup
- Cooler area per MW exceeds the parcel layout

##### Tripwires
- Modelled PUE > 1.30 on the 35°C design day at Month 5 (2027-03-17)
- No written water-authority opinion by Month 6 (2027-04-17)
- Peak load uplift >= 10% over the RTE request
- Drought load-shedding clause >= 20% demanded

##### Response Playbook
- Contain: Freeze cooler procurement and hall layouts that fix the dry-only design.
- Assess: Rerun the thermal model with measured fouling, then price hybrid cooling and BESS peak cover.
- Respond: Adopt hybrid cooling with capped non-potable water, or cut Phase 1 density or size, then update RTE and lenders.


**STOP RULE:** Pivot or downsize if the modelled PUE stays above 1.30 and no written water opinion exists at Month 6 (2027-04-17).

---

#### FM6 - The Sovereignty Squeeze

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: National Security and Regulatory Affairs Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Screening of sovereign-adjacent co-investors or US tenants turns hostile.
- ANSSI asks for data-residency zones, state observers or limits on foreign equity.
- Hyperscalers read the limits as lost control and compare other sites.
- Sovereign buyers wait for clearance before signing.
- Press reports of a militarised site harden local opposition, and clearance slips past Month 31 (2029-05-17).

##### Early Warning Signs
- ANSSI meeting not granted by Month 1 (2026-11-17)
- Request for state observer or equity cap
- Prospects make signing conditional on clearance
- Local media raise foreign-control questions

##### Tripwires
- No ANSSI informal opinion by Month 6 (2027-04-17)
- Foreign equity cap below the planned co-investor share
- Review timeline signalled > 18 months
- Fewer than 2 prospects willing to sign before clearance by Month 9 (2027-07-17)

##### Response Playbook
- Contain: Pause new foreign co-investor commitments and tenant disclosures beyond the white paper.
- Assess: Map each restriction to its effect on tenant mix, equity structure, security capex and schedule.
- Respond: Restructure to non-controlling EU-domiciled co-investors and sovereign-led halls, or shrink the tenant pool and resize Phase 1.


**STOP RULE:** Pause Phase 1 if ANSSI signals a blocking concern, or no written confirmation of formal review start exists at Month 12 (2027-10-17).

---

#### FM7 - The Debt That Never Closed

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Infrastructure Finance and Capital Structure Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Lenders see a conditional RTE position and only 150 MW signed.
- Debt is drawn pro-rata to contracted MW, so uncontracted capacity becomes equity.
- A 10% lease discount gives DSCR 1.15x against a 1.30x minimum (proposed).
- Leverage falls toward 53%, or spreads widen.
- The sponsor faces an equity gap; FID slips 12-24 months, with EUR 750M Phase 0 stranded.

##### Early Warning Signs
- Lenders request more than 50% signed before credit committee
- No written lender conditions by Month 6 (2027-04-17)
- Equity partners hesitate to cover the uncontracted share
- Quoted margins above benchmark +200 bps

##### Tripwires
- Fewer than 2 lenders with written terms by Month 6 (2027-04-17)
- Quoted margin >= benchmark +300 bps
- Offered leverage <= 53%
- Firm commitment < EUR 3B at Month 11 (2027-09-17)

##### Response Playbook
- Contain: Freeze lender fee commitments and any Phase 1 procurement tied to debt closing.
- Assess: Rerun DSCR at 10% discount, EUR 30/MWh shock and lower leverage, and size the equity gap.
- Respond: Resize Phase 1 to the debt the signed MW supports (250 MW), or seek an equity cure from co-investors, or defer FID.


**STOP RULE:** No Phase 1 FID if firm debt of at least EUR 3B (or pro-rata for a downsized tranche) is not committed at Month 12 (2027-10-17).

---

#### FM8 - The Empty Crane Yard

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Phase 0 Program Manager and Red Team Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Competing regional projects absorb electricians and cooling trades.
- Wage inflation exceeds 40% (estimate) and EPC firms decline fixed prices.
- Modular supply slots for coolers, transformers and BESS slip.
- Hall delivery misses Months 12-36 (2027-10-17 to 2029-10-17).
- Carrying cost of EUR 300M-600M accrues and tenants test other sites.

##### Early Warning Signs
- EPC bids come back with price escalation clauses
- Technical colleges cannot commit graduates
- Long-lead items quoted beyond 18 months
- Fewer than 2 qualified EPC bidders

##### Tripwires
- Wage inflation in EPC bids > 40% (estimate)
- Fewer than 2 EPC bidders at Month 4 (2027-02-17)
- Transformer or cooler lead time >= 24 months
- Training academy enrolment < 50 per year by Month 9 (2027-07-17)

##### Response Playbook
- Contain: Hold long-lead orders and hall starts until EPC capacity is confirmed in writing.
- Assess: Rebaseline the schedule and cost using bid data, and identify trades that can be prefabricated or imported.
- Respond: Phase hall delivery, widen EPC and supplier pool, or cut Phase 1 to fewer halls and renegotiate tenant dates.


**STOP RULE:** Reduce Phase 1 to 250 MW if no EPC commits to a fixed-price, dated delivery for 500 MW by Month 12 (2027-10-17).

---

#### FM9 - The Jobs Promise Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Engagement and Social License Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- The disclosed 50-150 FTE (not verified) contrasts with a multi-billion project.
- Mayors and unions call the benefit package token, and the offer reads as window-dressing.
- Farm unions reject lease-and-continue and file appeals.
- Municipal letters stall below 2 of 3.
- Permits slip 12-36 months (estimate) and the social-license gate fails.

##### Early Warning Signs
- Liaison meetings show falling attendance
- Mayors defer signing the benefit agreement
- Unions publish opposition statements
- Media coverage focuses on farmland loss

##### Tripwires
- Fewer than 2 of 3 municipalities supportive in writing at Month 6 (2027-04-17)
- Survey shows >= 50% of farmers opposed
- Legal challenge announced before Month 9 (2027-07-17)
- No signed benefit agreement at Month 9 (2027-07-17)

##### Response Playbook
- Contain: Stop jobs and revenue claims, and publish only validated headcount and benefit terms.
- Assess: Map each municipality and union objection to a specific term and cost the fixes.
- Respond: Rework the package toward farmland, ecology and regional supply terms, or shift to nodes with supportive municipalities.


**STOP RULE:** Pause Phase 1 if fewer than 2 of the 3 most affected municipalities have given written support, or a major legal challenge is pending, at Month 12 (2027-10-17).
