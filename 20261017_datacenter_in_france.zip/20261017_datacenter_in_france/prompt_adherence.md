**Overall Adherence: 88%**

```
IMPORTANCE_ADHERENCE_SUM = (5×4 + 5×5 + 5×4 + 4×5 + 5×5 + 4×3 + 4×4 + 3×4 + 3×5 + 4×4 + 5×5 + 5×4 + 5×5 + 5×5 + 5×4) = 296
IMPORTANCE_SUM = 5 + 5 + 5 + 4 + 5 + 4 + 4 + 3 + 3 + 4 + 5 + 5 + 5 + 5 + 5 = 67
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 296 / 335 = 88%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Planning envelope 12.7 km × 12.7 km (161 km²); notional, not fixed. Must stress-test single square against split-campus model and recommend the feasible option. | Constraint | 5/5 | 4/5 | Partially honored |
| 2 | Full buildout target 9 GW over 10–15+ years. Phase 0 Months 0–12 (2026-10-17 to 2027-10-17), Phase 1 Months 12–36 (2027-10-17 to 2029-10-17) (500 MW–1 GW), Phase 2 Months 36–84 (2029-10-17 to 2033-10-17) (1–3 GW), Phase 3 Months 84–132 (2033-10-17 to 2037-10-17) (3–6 GW), Phase 4 Months 132–180 (2037-10-17 to 2041-10-17)+ (9 GW only if demand, grid, financing, permits, social license hold). | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Phase 0 budget EUR 250M–750M (hard cap EUR 750M); no committed capital until Phase 0 gate Month 12 (2027-10-17). Phase 1 EUR 5B–10B. Track USD GPU/TPU/networking separately. Budget throughout in EUR for capex, land, labor, grid, power, permitting, taxes, financing. | Constraint | 5/5 | 4/5 | Partially honored |
| 4 | Sponsor is private hyperscale data-center developer, infrastructure-fund consortium backing with sovereign-adjacent co-investment discussions. Phase 0 high exploratory risk appetite, no committed capital until Phase 0 gate. | Stated fact | 4/5 | 5/5 | Fully honored |
| 5 | Location: Hauts-de-France only, industrial AI belt (Cambrai/E-Valley, Valenciennes/Denain/Escaudain, Dunkirk, Saint-Omer, brownfield land). Rationale: strong industrial redevelopment/reindustrialization, logistics, port, rail, steel, refinery, military context, better cooling climate than south, low latency to Paris/London/Brussels/Frankfurt, geopolitically safer than Russia-adjacent. | Requirement | 5/5 | 5/5 | Fully honored |
| 6 | Do not assume most of 161 km² are buildings. Build full land-use model: data halls, substations, BESS, backup generation, roads, fiber corridors, stormwater, biodiversity buffers, heat-reuse, security, expansion reserve, community buffers, agricultural/ecological zones, brownfield remediation. | Requirement | 4/5 | 3/5 | Partially honored |
| 7 | Campus serves GPU/TPU clusters (AI training, fine-tuning, batch inference, sovereign AI, enterprise inference). PUE target 1.15–1.25. Direct-to-chip liquid cooling default; optional 50–100 MW immersion pilot. Zero or ultra-low-water cooling preferred; freshwater/evaporative as high risk. | Requirement | 4/5 | 4/5 | Partially honored |
| 8 | Buildings 14–20 m tall (max 25–30 m), 20,000–100,000 m² each (some above 150,000 m²), 50–100+ halls at full buildout. Explain why taller buildings unsuitable for AI-scale data centers. | Requirement | 3/5 | 4/5 | Partially honored |
| 9 | Do not assume most of 161 km² are developed as buildings. Do not assume tall (above 25–30 m) data centers are suitable. | Banned | 3/5 | 5/5 | Fully honored |
| 10 | Power strategy: French low-carbon grid, nuclear-backed contracts, EDF/RTE coordination, PPAs, BESS, grid flexibility, limited backup. Connectivity: diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille; subsea/transatlantic. Security: national-security review, hardened perimeter, cyber/OT separation, anti-drone, supply-chain, resilience. | Requirement | 4/5 | 4/5 | Partially honored |
| 11 | Never invent binding commitments from RTE, EDF, DGSI, ANSSI, tenants, municipalities, or prefectural authorities. Treat all external approvals and commitments as uncertain; mark milestones as 'uncontrolled' unless backed by contract, permit, formal decision, or signed term sheet. | Requirement | 5/5 | 5/5 | Fully honored |
| 12 | Analyze: can 161 km² be assembled? Is single square realistic? Is split-campus superior? Grid and transmission feasibility, power procurement and price risk, cooling and water risk, heat-reuse opportunity, fiber latency/route diversity, brownfield remediation, agricultural displacement, permitting, national-security review, local political support, public opposition, tenant demand, financing credibility, scalability 1 GW to 3 GW to 9 GW. | Requirement | 5/5 | 4/5 | Partially honored |
| 13 | Stay skeptical and red-team. Identify explicitly what would make project infeasible and what must be proven before serious capital is committed. Treat downsizing, splitting campus, delaying expansion, or cancelling as legitimate recommendations if feasibility fails. | Intent | 5/5 | 5/5 | Fully honored |
| 14 | Define success explicitly: completing Phase 0 and Phase 1 within budget with credible tenants and Phase 2 FID backed by signed anchor-tenant commitments. Define failure explicitly: no grid hosting above ~1 GW, no adequate parcel, no creditworthy anchors, sustained opposition, unstructurable financing, or unmitigable water/grid/ecology constraints. | Requirement | 5/5 | 5/5 | Fully honored |
| 15 | Produce complete plan: executive summary, site rationale, land-use model, single vs split analysis, phased roadmap, budget, power, cooling, connectivity, permitting, stakeholders, environmental/water strategy, community/social-license strategy, security, tenant strategy, workforce, public benefit, risk register, decision gates, kill criteria, open questions, first 180-day action plan. | Requirement | 5/5 | 4/5 | Partially honored |

## Issues

### Issue 6 - Do not assume most of 161 km² are buildings. Build full land-use model: data halls, substations, BESS, backup generation, roads, fiber corridors, stormwater, biodiversity buffers, heat-reuse, security, expansion reserve, community buffers, agricultural/ecological zones, brownfield remediation.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** Plan acknowledges that 'built area is about 30–50% of the envelope (estimate)' and mentions 'data halls, substations, BESS, backup generation, roads, fiber corridors, stormwater, biodiversity buffers, heat-reuse, security, expansion reserve, community buffers.' However, a detailed quantified land-use model mapping specific km² allocations to each use is not provided.
- **Explanation:** Directive asks for a full land-use model covering all stated uses. The plan lists the uses but does not present a detailed model showing acreage or percentage allocations. For example, how many km² for BESS, backup generation, fiber corridors, security setbacks, continuation zones? The model exists as a concept but not as a detailed breakdown.

### Issue 1 - Planning envelope 12.7 km × 12.7 km (161 km²); notional, not fixed. Must stress-test single square against split-campus model and recommend the feasible option.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan acknowledges '161 km² contiguous assembly is doubtful (not verified)' and proposes split-campus comparison. Topology decision at Month 4 (2027-02-17), comparing single vs. 2-3 node models. However, detailed split-campus designs and per-node capex are not included in the final artifacts.
- **Explanation:** The plan commits to stress-testing single-square against split-campus and making a topologyDecision, but the actual side-by-side feasibility comparison and recommendation of which is superior is not present. The recommendation should explicitly state which topology is feasible and why. Split-campus cost premium (€250M–€500M, 5–10% of Phase 1 base) is mentioned in feedback but not in the main plan.

### Issue 3 - Phase 0 budget EUR 250M–750M (hard cap EUR 750M); no committed capital until Phase 0 gate Month 12 (2027-10-17). Phase 1 EUR 5B–10B. Track USD GPU/TPU/networking separately. Budget throughout in EUR for capex, land, labor, grid, power, permitting, taxes, financing.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Phase 0 capped at €750M in four tranches (€150M/€250M/€200M/€150M). Phase 1 EUR 5B–10B mentioned. USD hardware of €1.5B–€2.3B is noted as 'tracked separately' but the final decision 'whether the user's EUR 5B–10B includes it' is marked OPEN DECISION.
- **Explanation:** Budget ranges are provided and Phase 0 hard cap is enforced, but the critical clarification of whether Phase 1 capex figures (EUR 5B–10B) include or exclude USD hardware is left unresolved. This was flagged in feedback as needing upfront resolution for credibility. The plan does not lock the definition.

### Issue 12 - Analyze: can 161 km² be assembled? Is single square realistic? Is split-campus superior? Grid and transmission feasibility, power procurement and price risk, cooling and water risk, heat-reuse opportunity, fiber latency/route diversity, brownfield remediation, agricultural displacement, permitting, national-security review, local political support, public opposition, tenant demand, financing credibility, scalability 1 GW to 3 GW to 9 GW.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan includes analysis sections on: 'can 161 km² be assembled? (answer: doubtful, pivot to split); single square realistic? (topology decision Month 4 = 2027-02-17); split superior? (two/three node models); grid and transmission feasibility (RTE gate primary).' Risk register covers: land assembly, grid, water, heating, fiber, remediation, permitting, opposition, tenants, financing, scalability.
- **Explanation:** All analysis topics are addressed but with varying depth. Scalability from 1 GW to 9 GW is assumed rather than challenged; the plan does not model technology-refresh risk or lock-in constraints that could derail Phase 3–4. Financial sensitivity to power-cost overruns and tenant-demand shifts is outlined but not quantified at the 3 GW and 9 GW milestones. Explicit feasibility bottleneck ranking would strengthen this.

### Issue 15 - Produce complete plan: executive summary, site rationale, land-use model, single vs split analysis, phased roadmap, budget, power, cooling, connectivity, permitting, stakeholders, environmental/water strategy, community/social-license strategy, security, tenant strategy, workforce, public benefit, risk register, decision gates, kill criteria, open questions, first 180-day action plan.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Plan includes: executive summary, site rationale, (implied) land-use model, single vs. split analysis, phased roadmap, budget, power, cooling, connectivity, permitting, stakeholders (stakeholder analysis section), environmental/water strategy, community/social-license strategy, security, tenant strategy, workforce, public benefit, risk register (21 risks), decision gates, kill criteria (proposed thresholds), open questions (USD hardware scope, contract finalization timing), and first 180-day action plan (Months 0–6 = 2026-10-17 to 2027-04-17).
- **Explanation:** All required sections are present. However, the land-use model is conceptual rather than quantified; the single vs. split comparison lacks a clear recommendation with cost/benefit trade-off; and some sections (e.g., workforce strategy) are brief. The 180-day plan is embedded in the executive summary and project plan but not presented as a standalone detailed milestone checklist. A separate 'First 180-Day Action Plan' section with weekly/monthly granularity would strengthen compliance.

### Issue 7 - Campus serves GPU/TPU clusters (AI training, fine-tuning, batch inference, sovereign AI, enterprise inference). PUE target 1.15–1.25. Direct-to-chip liquid cooling default; optional 50–100 MW immersion pilot. Zero or ultra-low-water cooling preferred; freshwater/evaporative as high risk.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Plan specifies 'PUE target 1.15–1.25. Direct-to-chip liquid cooling default; optional 50–100 MW immersion pilot. Zero or ultra-low-water cooling preferred; freshwater/evaporative as high risk.' Cooling strategy uses 'closed-loop direct-to-chip with dry coolers, no evaporative water.'
- **Explanation:** Cooling approach and PUE target are fully specified. However, the plan does not explicitly discuss the tension between zero-water design and summer peak performance degradation (PUE may reach 1.35–1.5 at 35°C, vs. target 1.15–1.25). This risk is mentioned in the risk register but not integrated into the cooling strategy narrative.

### Issue 10 - Power strategy: French low-carbon grid, nuclear-backed contracts, EDF/RTE coordination, PPAs, BESS, grid flexibility, limited backup. Connectivity: diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille; subsea/transatlantic. Security: national-security review, hardened perimeter, cyber/OT separation, anti-drone, supply-chain, resilience.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Power strategy mentions 'French low-carbon grid, nuclear-backed contracts, EDF/RTE coordination, PPAs, BESS, grid flexibility, limited backup.' Connectivity requires '2 physically separate routes (no shared duct, bridge or landing) to each of Paris, London, Brussels, Amsterdam, Frankfurt.' Security includes 'hardened perimeter, anti-drone systems, cyber-OT separation, supply-chain security, resilience.'
- **Explanation:** All elements are present but not always deeply detailed. For example, BESS capacity (50–200 MWh proposed) and backup-generation scope are not quantified in the main narrative. Subsea routes and resilience against fiber landing-point concentration are flagged in the risk register but not embedded in the main connectivity strategy.

### Issue 8 - Buildings 14–20 m tall (max 25–30 m), 20,000–100,000 m² each (some above 150,000 m²), 50–100+ halls at full buildout. Explain why taller buildings unsuitable for AI-scale data centers.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 3/5
- **Evidence:** Plan states 'Halls 14–20 m tall (max 25–30 m), 20,000–100,000 m² each (some above 150,000 m²), 50–100+ buildings at 9 GW.' However, the explanation of why taller buildings (above 25–30 m) are unsuitable for AI-scale data centers is absent.
- **Explanation:** Building dimensions are specified, but the directive explicitly asks to 'explain why taller buildings are usually less suitable.' This explanation is missing. The plan should discuss factors such as cooling distribution complexity, structural cost, seismic/wind load, cable-routing overhead, and emergency egress constraints at scale.
