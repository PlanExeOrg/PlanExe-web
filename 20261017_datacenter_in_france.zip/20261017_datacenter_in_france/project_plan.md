**Goal Statement:** Complete a 12-month, gate-driven Phase 0 feasibility program (capped at EUR 750M) to decide whether a 9 GW, 161 km² (notional) AI campus in Hauts-de-France is feasible, and deliver a 500 MW Phase 1 base case at Cambrai/E-Valley only if grid, land, tenant, financing, permit and social-license gates pass; otherwise split, downsize, delay or cancel.

## SMART Criteria

- **Specific:** Test whether Hauts-de-France can host a 9 GW, 161 km² (notional) AI campus without overwhelming grid, land, water, permitting, communities or ecology. Compare the single square against a split campus and recommend the feasible option, including downsizing or cancellation.
- **Measurable:** Phase 0 is measured by pass/fail evidence at Month 12 (2027-10-17): RTE letter for at least 500 MW, at least 70% of the chosen topology's target parcel optioned, binding tenant term sheets for at least 30% of Phase 1, firm debt of at least EUR 3B, and written support from 2 of 3 key municipalities (all proposed thresholds). Spend stays within EUR 750M.
- **Achievable:** Achievable as a staged feasibility test with four milestone tranches and no committed capital before the gate. Key outcomes (RTE, ANSSI, prefecture, EDF, tenants) are uncontrolled until signed, so a conditional pass and early exit are built in.
- **Relevant:** The project tests an extreme-scale reindustrialization proposition before serious capital (Phase 1 EUR 5B–10B) is committed. It protects investors from sunk-cost momentum and gives authorities, communities and tenants evidence-based decisions.
- **Time-bound:** Project starts now (Month 0, 2026-10-17). Phase 0 runs Months 0–12 (2027-10-17), with the topology decision at Month 4 (2027-02-17) and the gate review at Month 12 (2027-10-17). Phase 1 (Months 12–36 = 2027-10-17 to 2029-10-17) follows only on a pass; the full 9 GW buildout spans about Months 0–180 (2026-10-17 to 2041-10-17)+ and is conditional.

## Dependencies

- Charter an independent investment committee, red team and numeric kill thresholds (Months 1–2 = 2026-11-17 to 2026-12-17)
- Secure RTE grid hosting feasibility, EDF power-supply pathway and BESS/curtailment terms
- Assemble land by non-coercive options and bound brownfield liability via Phase I/II surveys
- Obtain signed anchor-tenant term sheets, debt commitments and ANSSI/DGSI review pathway
- Validate dry-cooling and water feasibility, fiber route diversity, and municipal and community support

## Resources Required

- Funding: EUR 750M Phase 0 cap in four milestone tranches
- Specialist advisers: grid, hydrology, ecology, legal, land, security
- Survey and audit services: Phase II soil/groundwater, fiber route audit, thermal modelling
- Regional offices at Cambrai and Dunkirk
- Independent red team and RTE hosting-capacity audit

## Related Goals

- Reindustrialization of brownfield land in Hauts-de-France
- French and European sovereign AI compute capacity
- Regional workforce training academy and community-benefit programs
- Heat-reuse and shared grid and fiber infrastructure for regional industry
- Split-campus or reduced-scale alternative if the single square fails

## Tags

- hyperscale data center
- AI campus
- Hauts-de-France
- feasibility gating
- grid and power

## Risk Assessment and Mitigation Strategies


### Key Risks

- RTE hosting capacity above ~1 GW unconfirmed (primary kill test); reinforcement co-funding EUR 500M–1.5B (estimate)
- 161 km² contiguous assembly doubtful; holdouts and farmland displacement of 10,000–15,000+ ha (estimate)
- No signed creditworthy anchor tenants; letters of intent do not count
- Multi-GW nuclear-backed power at EUR 50–70/MWh (not verified); +EUR 30/MWh adds about EUR 112M/yr at 500 MW (estimate)
- Permitting of 18–30 months plus appeals of 24–48 months (estimate), and uncontrolled ANSSI/DGSI review

### Diverse Risks

- Sunk-cost pressure overriding kill criteria; stacked add-ons EUR 1.55B–4.2B on 500 MW overlap and are unfunded
- Brownfield contamination of EUR 100M–400M if found late (estimate)
- Dry-cooling PUE of 1.35–1.5 in hot weather (estimate) and fiber or landing-point shared failures
- DSCR falls to 1.15x under a 10% lease discount for curtailment; USD hardware FX of EUR 150M–230M per 10% move
- Community, farm-union and political opposition; modest operations headcount (50–150 FTE, not verified) undermines jobs claims

### Mitigation Plans

- Independent committee with two-thirds override and published dissent; EUR 750M cap with four tranches (150/250/200/150 EUR M); conditional pass allowed where authorities have not answered
- Split campus as default at Month 4 (2027-02-17) unless at least 70% optioned and RTE written evidence for 1 GW; tranche-based RTE request with curtailment at most 10% (walk-away 15%) and BESS
- Only binding term sheets count (at least 30% by Month 9 = 2027-07-17); reservation fees; USD hardware held by tenants or lessor, forwards only against signed leases; pass-through energy indexation
- Phase II surveys with remediation bounded to EUR 0–100M per site, seller or public indemnities, written water opinion, thermal modelling at 35°C, and physical fiber audits
- Early ANSSI/DGSI and DREAL dialogue, liaison committee with published minutes, voluntary consultation, lease-and-continue farming, and a community-benefit package of EUR 50M–150M (estimate) contingent on permits

## Stakeholder Analysis


### Primary Stakeholders

- Sponsor hyperscale developer and infrastructure-fund consortium (including sovereign-adjacent co-investors)
- Independent investment committee and external red team
- Phase 0 core team (40–60, estimate) and specialist advisers
- Anchor tenants (hyperscalers, sovereign AI users, or a tenant-backed lessor)
- Campus lenders and equity sources

### Secondary Stakeholders

- RTE, EDF and DREAL
- Prefecture, ANSSI and DGSI
- Municipalities (Cambrai, Dunkirk, Valenciennes area), farm unions and NGOs
- Landowners, port authorities and public remediation bodies
- Fiber carriers, regional contractors, training institutions and competing industrial users

### Engagement Strategies

- Committee and red team: monthly pass/fail reports; quarterly dissent disclosures to lenders and co-investors
- RTE, EDF and security authorities: formal written requests from Month 0 (2026-10-17); treat all outcomes as uncontrolled until signed
- Municipalities, farmers and NGOs: liaison committee from Months 1–3 (2026-11-17 to 2027-01-17) with published minutes, consultation, and a community-benefit agreement drafted by Month 5 (2027-03-17)
- Tenants and lenders: standard take-or-pay term sheets by Month 2 (2026-12-17), binding sheets by Month 9 (2027-07-17), lender criteria discussed from Month 3 (2027-01-17)
- Landowners, carriers and contractors: option agreements, indemnity negotiations, route-diversity disclosure and early certification of regional firms

## Regulatory and Compliance Requirements


### Permits and Licenses

- ICPE authorization and environmental authorization per node
- Planning and construction permits (permit file submitted Months 8–9 = 2027-06-17 to 2027-07-17)
- Water abstraction or discharge authorizations and stormwater approvals
- RTE connection agreement and substation authorizations
- Biodiversity, protected-species and EIA approvals (DREAL screening opinion by Month 9 = 2027-07-17)

### Compliance Standards

- French environmental and ICPE regulations and EIA avoid-reduce-compensate sequence
- EU energy-efficiency and data-center reporting rules
- ANSSI security and cyber-OT separation standards
- Brownfield and contamination management standards (Phase I/II assessments)
- Foreign-investment screening and data-residency requirements

### Regulatory Bodies

- RTE (grid operator)
- DREAL and the Nord/Pas-de-Calais prefectures
- ANSSI and DGSI
- Agence de l'Eau Artois-Picardie and DDT/DDTM
- Grand Port Maritime de Dunkerque and municipal planning authorities

### Compliance Actions

- Open pre-submission dialogue with RTE, DREAL, ANSSI and DGSI in Months 0–1 (2026-10-17 to 2026-11-17)
- Obtain RTE letter, water-authority and informal ANSSI opinions by Month 6 (2027-04-17)
- Submit permit file(s) at Months 8–9 (2027-06-17 to 2027-07-17), one per node, and run a permit check at Month 18 (2028-04-17)
- Obtain DREAL screening opinion by Month 9 (2027-07-17) and ANSSI confirmation that formal review can start at Month 13 (2027-11-17)
- Monitor policy changes (fast-track permitting, export controls) as a gate trigger; fast-track not assumed