This plan involves money.

## Currencies

- **EUR:** Primary currency for all infrastructure, land acquisition, labor, grid services, power procurement, cooling systems, fiber and connectivity, permitting, and community obligations in Hauts-de-France. Phase 0–4 capex and opex budgeted entirely in EUR (€35M–€174.6B total project cost).
- **USD:** Secondary currency for GPU/TPU accelerators, international networking hardware, and select software procurement from US and global vendors. Phase 1 hardware capex €1.5B–€2.3B denominated in USD. FX exposure hedged via forward contracts matched to tenant take-or-pay lease revenue. Separate hardware vehicle recommended to isolate USD risk from infrastructure debt.

**Primary currency:** EUR

**Currency strategy:** EUR is the base for all infrastructure financing, budgeting, and reporting. USD exposure is tracked separately for hardware procurement and isolated in a separate vehicle to shield infrastructure company debt from FX volatility and vendor allocation risk. Forward-contract FX hedging is assumed for hardware costs matched to signed tenant take-or-pay leases, at estimated 0.5–2% annual cost of hedged notional. Power contracts in EUR; tenant leases in EUR with optional inflation escalation. No other currencies are material to the project. Phase 0 assume 2027–2030 EUR/USD rates in 1.08–1.12 range (placeholder; actual rates to be hedged as commitments are made).