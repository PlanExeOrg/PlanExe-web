### 1. Project Sponsor formally authorizes Phase 0 governance structure and delegates authority for committee establishment to the Project Director. Sponsor issues a written mandate defining the scope of Phase 0 (Months 0–12 = 2026-10-17 to 2027-10-17), the EUR 750M cap, the four governance bodies, and the decision-making framework. This authorization establishes the legal and organizational foundation for all subsequent governance activities.

**Responsible Body/Role:** Project Sponsor (or Senior Steering Body Pre-Governance)

**Suggested Timeframe:** Month 0 (2026-10-17), within 1 week of project kickoff

**Key Outputs/Deliverables:**

- Signed Project Authorization Mandate
- Phase 0 Scope and Budget (EUR 750M cap, four tranches, no committed capital before gate)
- Governance Structure Charter (four bodies, roles, responsibilities)
- Delegation of Authority to Project Director for Committee Setup

**Dependencies:**

- Project sponsor board approval
- Infrastructure-fund consortium alignment on governance framework
- Co-investor agreement to the governance model

### 2. Project Director establishes the Project Steering Committee Charter and identifies initial membership. The charter documents: composition (Sponsor CEO/CFO, Consortium Lead, at least one Independent External Director, Lender Observer, Project Director); voting rules (3-of-5 majority for most decisions, 2-of-3 alignment requirement for Phase 1 FID); decision thresholds (EUR 50M and above escalate); meeting cadence (monthly); and escalation protocol. The Project Director solicits and formalizes commitments from all five designated members.

**Responsible Body/Role:** Project Director (in consultation with Sponsor and Consortium)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2 weeks of project authorization

**Key Outputs/Deliverables:**

- Project Steering Committee Charter (signed by all five members)
- Committee composition and member role descriptions
- Voting and decision-making rules (3-of-5 majority, 2-of-3 FID alignment, EUR 50M threshold)
- Quarterly and monthly meeting schedules
- Escalation protocol and dissent recording procedures

**Dependencies:**

- Project Authorization Mandate (step 1)
- Identification and agreement of Independent External Director (no financial ties)
- Lender and consortium appointments confirmed

### 3. Project Steering Committee holds its first kick-off meeting. The committee reviews the Phase 0 roadmap, confirms the four governance bodies and their responsibilities, validates the EUR 750M four-tranche budget structure (EUR 150M / 250M / 200M / 150M), and assigns the Project Director responsibility for Phase 0 execution. The committee establishes its monthly meeting agenda template and approves the engagement approach for external authorities (RTE, EDF, DREAL, ANSSI).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-17), within 1 week of charter signature

**Key Outputs/Deliverables:**

- Steering Committee Kick-Off Meeting Minutes
- Approved Phase 0 Roadmap and Milestone Schedule
- Confirmed governance-body roles and responsibilities
- Monthly agenda template and decision-preparation procedures
- First Tranche Authorization (EUR 150M Months 0–2 = 2026-10-17 to 2026-12-17)

**Dependencies:**

- Project Steering Committee Charter signed (step 2)

### 4. Project Director establishes the Gate Review and Kill Authority Committee. The Project Director recruits and formally appoints: at least 2 Independent External Directors (infrastructure or energy expertise, no financial ties to sponsor or consortium), 1 Lender Representative (non-voting, advisory), and 1 Infrastructure-Sector Expert (non-voting). The Project Director commissions an external red team (proposed EUR 2M–5M budget) to deliver independent monthly pass/fail opinions on the five gate criteria (grid, land, tenants, financing, social license). The committee chair is appointed by mutual consent of sponsor and consortium.

**Responsible Body/Role:** Project Director (in consultation with Sponsor, Consortium and Steering Committee)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2–3 weeks of kickoff

**Key Outputs/Deliverables:**

- Gate Review and Kill Authority Committee Charter (signed)
- Committee composition and member roles
- External red team engagement letter and scope (monthly pass/fail reports)
- Committee chair appointment letter
- Draft numeric kill thresholds (to be finalized at step 6)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee First Meeting completed (step 3)
- Budget allocation for red team (EUR 2M–5M from Phase 0 tranche 1)

### 5. Project Director establishes the Compliance, Environmental & Social License Committee. The Project Director recruits and appoints six functional leads: ICPE/Environmental Lead, National-Security and GDPR Counsel, Ecology and Biodiversity Manager, Water Resources Manager, Community and Stakeholder Lead, and Brownfield and Remediation Counsel. Each lead is tasked with commissioning Phase I environmental site assessments (desktop) on all candidate parcels, initiating formal pre-submission dialogues with DREAL and ANSSI, and establishing the municipal liaison committee. The PMO Controller reports monthly to this committee on compliance-workstream spend and deliverable status.

**Responsible Body/Role:** Project Director (in consultation with Steering Committee PMO Lead)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2–3 weeks of kickoff

**Key Outputs/Deliverables:**

- Compliance, Environmental & Social License Committee Charter (signed)
- Six functional-lead role descriptions and contact persons
- Engagement letters with ICPE counsel, environmental counsel, ANSSI/security counsel, GDPR counsel, land counsel
- Phase I ESA commission instructions (all candidate parcels) by end of Month 1 (2026-11-17)
- Pre-submission dialogue openings with DREAL, ANSSI, prefecture by Month 0–1 (2026-10-17 to 2026-11-17)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee First Meeting (step 3)
- Budget allocation for compliance-workstream specialists and Phase I surveys

### 6. Gate Review and Kill Authority Committee formally fixes numeric kill thresholds in writing and publishes them to lenders, co-investors and the Steering Committee. Thresholds are: (i) RTE grid hosting capacity at least 500 MW within 36 months (first written evidence due Month 6 = 2027-04-17); (ii) at least 70% of chosen topology's target parcel optioned non-coercively at no more than 15% above benchmark land value; (iii) signed anchor-tenant take-or-pay agreements for at least 30% of Phase 1 size by Month 9 (2027-07-17); (iv) firm debt commitment of at least EUR 3B with acceptable terms by Month 12 (2027-10-17); (v) written support from at least 2 of 3 most-affected municipalities by Month 12 (2027-10-17). The committee also publishes the decision protocol: if any threshold is breached by its deadline, the committee issues a formal gate-status report within 5 working days and recommends phase advance, conditional approval, downsizing, deferral or cancellation.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (chaired by Independent External Director)

**Suggested Timeframe:** Month 2 (2026-12-17), by end of Month 2 (2026-12-17)

**Key Outputs/Deliverables:**

- Published Numeric Kill Thresholds Document (signed by committee chair and all members)
- Gate Criterion Definitions: grid (RTE letter by Month 6 = 2027-04-17), land (70% by Month 4 = 2027-02-17), tenants (30% signed by Month 9 = 2027-07-17), debt (EUR 3B by Month 12 = 2027-10-17), social license (2 municipalities by Month 12 = 2027-10-17)
- Decision protocol and gate-status-report template
- Distribution list for dissemination to lenders, co-investors, Steering Committee
- Red team engagement and first pass/fail report instructions

**Dependencies:**

- Gate Review and Kill Authority Committee Charter signed (step 4)
- Committee chair appointed
- Steering Committee aware of and endorses thresholds

### 7. Project Management Office (PMO) is established and staffed with a core team of 40–60 people across eight functional workstreams: Grid and Power, Land Assembly, Permitting and Environmental, Tenancy and Revenue, Finance and Lender Relations, Security and National-Security, Community and Stakeholder, and PMO Administration (Controller). Each workstream lead is assigned and given a Phase 0 detailed plan (deliverables, timelines, success criteria, escalation triggers). The PMO establishes weekly standup meetings (all leads), monthly full-team reviews, and a risk-register maintenance process. Regional offices are established in Cambrai and Dunkirk.

**Responsible Body/Role:** Project Director (appoints PMO Lead/Project Manager)

**Suggested Timeframe:** Month 1 (2026-11-17), within 3 weeks of authorization

**Key Outputs/Deliverables:**

- PMO Charter and organization structure (8 workstreams, 40–60 FTE core team)
- Workstream lead job descriptions and accountability
- Detailed Phase 0 workplan by workstream (timelines, deliverables, success criteria)
- Risk register template and maintenance protocol (monthly updates, escalations for High+High risks)
- Weekly standup and monthly review meeting schedules
- Regional office setup plan (Cambrai and Dunkirk address, staff, office equipment)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee charter signed (step 2)
- Project Director appointed
- Budget authority for 40–60 FTE salaries and regional offices

### 8. PMO commissions specialized advisers and survey firms across critical Phase 0 workstreams: (i) RTE hosting-capacity auditor (independent third-party), (ii) hydrologist and water-resource consultant, (iii) environmental and EIA counsel, (iv) ICPE specialist, (v) land-assembly and real-estate counsel, (vi) Phase I/II ESA and contamination surveyors (one team per geographic zone: Cambrai, Dunkirk, Valenciennes, Saint-Omer), (vii) security and ANSSI liaison counsel, (viii) fiber-route auditor (telecom specialist). Each adviser is tasked with delivering specific Phase 0 gate-critical outputs by agreed deadlines (e.g., RTE audit by Month 9 = 2027-07-17, Phase II surveys by Month 3 = 2027-01-17).

**Responsible Body/Role:** PMO Lead (Project Director) and Workstream Leads

**Suggested Timeframe:** Month 1 (2026-11-17), engagement letters issued by end of Month 1 (2026-11-17)

**Key Outputs/Deliverables:**

- Signed engagement letters with each adviser/surveyor
- Scope of work and deliverable specifications for each adviser
- Budget allocation and fee schedules
- Timeline alignment with Phase 0 gate milestones (Month 4, 6, 9, 12 = 2027-02-17, 2027-04-17, 2027-07-17, 2027-10-17)
- Contact and escalation protocols (who reports to whom, monthly status meetings)

**Dependencies:**

- PMO established and workstream leads appointed (step 7)
- Budget approved for specialist advisers (Phase 0 tranche 1, EUR 150M)

### 9. PMO initiates formal pre-submission dialogue with external authorities: RTE (grid hosting-capacity assessment, connection-offer timeline, tranche availability), DREAL and prefecture (permit pathway, ICPE classification, environmental-authorization scope, fast-track status if any), ANSSI and DGSI (national-security review scope, timeline, data-residency and foreign-investment scrutiny, security-governance expectations). All dialogue is documented in writing; responses are classified as gate-critical. A formal written request is sent to each authority by Month 0–1 (2026-10-17 to 2026-11-17), with follow-up meetings scheduled by Month 2 (2026-12-17).

**Responsible Body/Role:** PMO Leads: Grid and Power (RTE), Permitting and Environmental (DREAL/Prefecture), Security and National-Security (ANSSI/DGSI); with support from Project Director and specialist counsel

**Suggested Timeframe:** Month 0–1 (2026-10-17 to 2026-11-17), dialogue initiated

**Key Outputs/Deliverables:**

- Written pre-submission request letters to RTE, DREAL, ANSSI, prefecture (with project overview, siting rationale, key technical parameters, timeline expectations)
- Meeting schedules and participant lists (internal team + authority representatives)
- Documentation log of all authority responses (emails, letters, meeting minutes)
- Summary of preliminary authority feedback (if any) by Month 2 (2026-12-17)
- Gate-critical response tracking (target RTE letter Month 6 = 2027-04-17, water opinion Month 6 = 2027-04-17, ANSSI opinion Month 6 = 2027-04-17, DREAL opinion Month 9 = 2027-07-17)

**Dependencies:**

- PMO established (step 7)
- Specialist advisers identified (step 8)

### 10. Compliance, Environmental & Social License Committee establishes the municipal liaison committee and launches early voluntary public consultation. The committee contacts representatives from at least the three most-affected municipalities (Cambrai, Dunkirk, Valenciennes or equivalent in chosen topology), invites them to join a monthly liaison dialogue, and publishes the consultation launch with a transparent project overview, siting rationale, technical specifications (power, cooling, fiber, security), environmental and social-impact scope, and a 4-week comment period. Consultation feedback is recorded and a response summary is published by Month 5 (2027-03-17).

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), liaison committee established by Month 2 (2026-12-17), consultation launched by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Municipal liaison committee charter (members, meeting schedule, published minutes protocol)
- First municipal liaison committee meeting (Month 2 = 2026-12-17)
- Public consultation launch package (project overview, siting rationale, technical specs, environmental and social scope, 4-week comment period)
- Published meeting minutes from at least two liaison-committee meetings
- Public consultation feedback summary and project response (published by Month 5 = 2027-03-17)

**Dependencies:**

- Compliance, Environmental & Social License Committee established (step 5)
- Project location and topology (or alternative topologies) defined

### 11. PMO Land Assembly Lead and specialist real-estate counsel conduct a parcel-by-parcel option survey across all candidate sites (Cambrai, Dunkirk, Valenciennes, Saint-Omer) to assess: ownership chains (public vs. private), known holdout or activist groups, fragmentation, above-market-value expectations, and option-agreement feasibility. A preliminary go/no-go assessment is produced by Month 3 (2027-01-17) answering whether at least 70% of the single-square target parcel (or the split-campus node targets) can be optioned non-coercively at less than 15% above benchmark land value. If the single-square falls short of 70%, the assessment recommends a split-campus topology; if both fail, a further downsize or site substitution is flagged.

**Responsible Body/Role:** PMO Land Assembly Lead (with real-estate counsel and municipal/registry liaison)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), assessment by end of Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Parcel-by-parcel survey report (ownership, fragmentation, holdout risk, land-value benchmarks)
- Land-assembly feasibility assessment: single-square vs. split-campus viability
- Topology recommendation (single square if ≥70% optionable, split campus if single square fails)
- Phase II environmental site assessment commission instructions (identify highest-priority sites)
- Option-agreement strategy and initial-approach outreach list

**Dependencies:**

- PMO established (step 7)
- Municipal liaison dialogue initiated (step 10) for municipal-registry and ownership-chain access
- Candidate site map and land-use boundaries defined

### 12. Compliance, Environmental & Social License Committee commissions Phase II intrusive environmental site assessments (soil boring, groundwater sampling, asbestos survey) on the top 2–3 candidate sites in each geographic zone. Assessments are targeted to close by Month 3 (2027-01-17) so that contamination findings can feed the land-assembly topology decision (Month 4 = 2027-02-17). Remediation-liability estimates are produced per site; sites with bounded remediation costs below EUR 100M are shortlisted; sites exceeding this threshold are either excluded or flagged for further negotiation with the landowner or public remediation authority.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Brownfield and Remediation Counsel) and PMO Environmental/Permitting Lead

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), surveys commissioned Month 1 (2026-11-17), reports closed by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Phase II ESA engagement letters and scope (soil, groundwater, asbestos, baseline survey per site)
- Phase II ESA reports (one per high-priority site, estimated cost EUR 1.5M–3M per zone)
- Remediation-liability estimate per site (bounded to EUR 0–100M range preferred)
- Site-shortlist decision (include, exclude, or conditional on seller indemnity)
- Indemnity negotiation strategy with landowners or public remediation authorities

**Dependencies:**

- Land-assembly parcel survey completed (step 11)
- Compliance committee established (step 5)
- Budget allocated for Phase II surveys (Phase 0 tranche 1–2)

### 13. PMO Grid and Power Lead commissions an independent RTE hosting-capacity assessment (third-party auditor) to estimate available 400 kV substation connection capacity at Hauts-de-France, assess transmission-reinforcement timelines and cost-sharing requirements, and model phased tranches (500 MW, 1 GW, 2+ GW). The auditor liaises with RTE to understand queue position, multi-tranche allocation policy, firm vs. conditional connection-offer timelines, and curtailment/flexibility requirements. A detailed hosting-capacity audit report is delivered by Month 9 (2027-07-17) and published to the Gate Review Committee, lenders and co-investors.

**Responsible Body/Role:** PMO Grid and Power Lead (with independent RTE hosting-capacity auditor)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), audit engagement Month 1 (2026-11-17), report Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- RTE hosting-capacity auditor engagement letter and scope
- Hosting-capacity audit report (Month 9 = 2027-07-17): capacity estimates per node, transmission reinforcement scope and cost-share, queue position, connection-offer timeline by tranche
- Grid reinforcement cost estimate (EUR 500M–1.5B range, propose risk allocation)
- Phased connection-offer model (500 MW first tranche, pathway to 1 GW, assumptions on flexibility and curtailment)
- Published audit summary distributed to Gate Review Committee, Steering Committee, lenders

**Dependencies:**

- PMO Grid Lead appointed (step 7)
- RTE pre-submission dialogue initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so the auditor can focus on the chosen node(s)

### 14. PMO Permitting and Environmental Lead, in coordination with environmental counsel, develops detailed ICPE and environmental-authorization permit-file roadmap. The roadmap specifies: required expert reports (ecological baseline, hydrological assessment, air-quality and noise modeling, contamination survey, thermal plume modeling if water-cooling), EIA scope (avoidance-reduction-compensation hierarchy for ecological impact, biodiversity net-positive targets, farmland displacement mitigation), baseline data collection timelines, DREAL feedback integration, and targeted permit-file submission date (Months 8–9 = 2027-06-17 to 2027-07-17). This roadmap feeds into the Compliance committee's permitting-file production schedule.

**Responsible Body/Role:** PMO Permitting and Environmental Lead (with ICPE specialist counsel, environmental counsel, EIA specialist)

**Suggested Timeframe:** Months 1–2 (2026-11-17 to 2026-12-17), roadmap completed by Month 2 (2026-12-17)

**Key Outputs/Deliverables:**

- ICPE and environmental-authorization permit-file roadmap (required components, baseline data, expert reports, timelines)
- EIA scope and avoidance-reduction-compensation strategy
- Permit-file production schedule (targeting filing Months 8–9 = 2027-06-17 to 2027-07-17)
- Expert-report commission plan and budget allocation
- DREAL pre-submission feedback integration plan

**Dependencies:**

- Compliance committee established (step 5)
- Pre-submission dialogue with DREAL initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so the scope is clear

### 15. PMO Security and National-Security Lead, in coordination with security and GDPR counsel, prepares a confidential security governance white paper for ANSSI pre-submission. The white paper covers: tenant selection and vetting process, data-residency and national-security data-handling policies, perimeter hardening and anti-drone specifications, cyber-OT separation architecture, personnel-clearance requirements, supply-chain assurance, co-investor governance and control provisions, and alignment with French AI and sovereignty strategy. The white paper is submitted to ANSSI in advance of the formal pre-submission meeting (target Month 1–2 = 2026-11-17 to 2026-12-17) to solicit informal guidance on the anticipated review scope and any early concerns.

**Responsible Body/Role:** PMO Security and National-Security Lead (with security counsel and GDPR counsel)

**Suggested Timeframe:** Months 0–2 (2026-10-17 to 2026-12-17), white paper drafted and submitted by Month 1–2 (2026-11-17 to 2026-12-17)

**Key Outputs/Deliverables:**

- Confidential security governance white paper (tenant vetting, data residency, perimeter security, cyber-OT separation, supply-chain assurance, co-investor control provisions)
- Pre-submission meeting request to ANSSI (Months 0–1 = 2026-10-17 to 2026-11-17)
- ANSSI confidential preliminary feedback (due Month 6 = 2027-04-17, proposed)
- GDPR data-processing and data-residency compliance framework

**Dependencies:**

- PMO Security Lead appointed (step 7)
- Security and GDPR counsel engaged (step 8)
- Project technical specifications defined (power, cooling, fiber, topology)

### 16. PMO Grid and Power Lead, in coordination with independent power-market advisers, commences multi-party power-procurement negotiations with EDF and coordinates with RTE on flexibility and BESS requirements. Negotiations target a non-binding letter of intent from EDF by Month 6 (2027-04-17) confirming willingness to discuss a multi-year baseload contract for at least 500 MW at a capped EUR/MWh price (proposed range EUR 50–70/MWh, not verified). A formal term sheet (non-binding but detailed) is targeted for Month 9 (2027-07-17). Energy pricing and curtailment assumptions are modeled in parallel; grid curtailment at or below 10% is the base assumption, with a walk-away threshold of 15%.

**Responsible Body/Role:** PMO Grid and Power Lead (with independent power-market adviser and EDF liaison)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), EDF dialogue ongoing, LOI by Month 6 (2027-04-17), term sheet by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Power-market study and pricing assessment (EUR/MWh forecast, multi-GW contract feasibility, hedging options)
- EDF non-binding letter of intent (Month 6 = 2027-04-17): 500 MW baseload, minimum 10-year tenor, price range to be confirmed in term sheet
- EDF formal term sheet (Month 9 = 2027-07-17): capacity, price, tenor, indexation, curtailment/flexibility terms
- BESS and demand-flexibility modeling (50–200 MWh, grid-stress mitigation, cost estimate)
- Power-cost sensitivity model (base case vs. +EUR 30/MWh shock scenario, impact on tenant lease pricing and project returns)

**Dependencies:**

- PMO Grid and Power Lead appointed (step 7)
- RTE pre-submission dialogue initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so capacity targets are clear

### 17. Steering Committee holds a formal topology-decision meeting at Month 4 (2027-02-17). The committee reviews evidence from three sources: (i) land-assembly feasibility (% parcel optioned, contamination findings, holdout risk), (ii) RTE grid-capacity signals (preliminary letter received or timeline credible by Month 6 = 2027-04-17?), and (iii) permitting and social-license risk (single-square vs. split-campus complexity). The committee votes on single-square vs. split-campus, documents the rationale, and publishes the topology decision to lenders and co-investors. If RTE has not yet delivered a letter (due Month 6 = 2027-04-17), the split-campus default is applied; the single square can only be chosen if RTE written evidence of at least 1 GW capacity is already in hand.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 4 (2027-02-17), topology-decision meeting

**Key Outputs/Deliverables:**

- Topology Decision Document (single square vs. split campus, rationale, evidence cited)
- Land-assembly feasibility summary (% parcel optioned, contamination bounded, holdout risk)
- RTE grid-capacity evidence (if in hand) or pathway statement (letter due Month 6 = 2027-04-17)
- Detailed capex and timeline per topology option (single square EUR 5B–10B, split campus EUR 5.5B–9.2B, schedule difference)
- Published topology decision distributed to PMO, Gate Review Committee, lenders, co-investors

**Dependencies:**

- Land-assembly feasibility assessment (step 11)
- Phase II ESA reports (step 12)
- RTE pre-submission dialogue completed (step 9); letter not yet due, but dialogue status assessed

### 18. PMO Tenancy and Revenue Lead develops standardized high-commitment take-or-pay lease term sheets (5–10 year proposed tenor) and capacity-reservation fee structures (EUR 10M–50M per 100 MW proposed, credited against future lease revenue). Templates are finalized by Month 3 (2027-01-17) and distributed to the project's anchor-tenant acquisition team. Target anchor tenants include 2–3 global hyperscalers or AI labs (hyperscaler pool) and 2–3 sovereign-AI or European-consortium anchors (sovereign pool). Initial outreach and non-binding letter of intent collection begins in Month 3 (2027-01-17); conversion of LOIs to binding term sheets is targeted by Month 9 (2027-07-17) for at least 30% of Phase 1 capacity.

**Responsible Body/Role:** PMO Tenancy and Revenue Lead (with real-estate counsel and commercial advisers)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), templates by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Standardized take-or-pay lease term sheet (5–10 year tenor, capacity reserved, force-majeure exceptions, SLA carve-outs for grid curtailment, annual escalation)
- Capacity-reservation fee schedule (EUR 10M–50M per 100 MW, payment timeline before construction start)
- Tenant acquisition targeting roadmap (2–3 hyperscalers, 2–3 sovereign anchors, outreach timeline, LOI targets)
- Tenant due-diligence criteria (credit rating BBB− minimum or parent guarantee, compute-cluster workload requirements, latency tolerance for split campus, security/data-residency requirements)
- LOI template and non-binding engagement plan

**Dependencies:**

- PMO Tenancy Lead appointed (step 7)
- Real-estate and commercial counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so capacity targets and node specifications are clear
- Power-procurement and grid-hosting timeline understood (so lease terms can reference power reliability and curtailment)

### 19. Gate Review and Kill Authority Committee implements monthly monitoring of gate-criterion achievement. Starting Month 1 (2026-11-17), the external red team delivers a monthly pass/fail opinion on each of the five gate criteria: (i) grid hosting-capacity status (RTE letter received or timeline credible?), (ii) land assembly (% parcel optioned, remediation findings), (iii) anchor-tenant pipeline (LOI vs. binding breakdown, credit validation), (iv) debt-financing status (lender interest, term-sheet progress), (v) social license (municipal support, opposition escalation). The red-team reports are reviewed by the committee in monthly gate-status sessions; any criterion showing a High-likelihood breach is flagged to the Steering Committee within 5 working days.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (with External Red Team)

**Suggested Timeframe:** Monthly, starting Month 1 (2026-11-17), through Month 12 (2027-10-17)

**Key Outputs/Deliverables:**

- External red-team monthly pass/fail reports (5 criteria assessed against numeric thresholds, evidence presented, risks flagged)
- Monthly gate-status summary for the Steering Committee (which criteria on track, which at risk, recommended actions)
- Quarterly formal gate-assessment meetings (Months 3, 6, 9, 12 = 2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17) with detailed written gate-status reports
- Escalation alerts (high-risk breaches within 5 working days to Steering Committee and PMO)
- Published dissent log (committee disagreements on threshold achievement recorded and disclosed to lenders)

**Dependencies:**

- Gate Review and Kill Authority Committee chartered (step 4)
- External red team engaged (step 4)
- Numeric kill thresholds published (step 6)

### 20. Compliance, Environmental & Social License Committee oversees the completion of hydrological study and water-authority engagement. A hydrologist assesses regional water stress, validates dry-cooler feasibility at a 35°C design-day ambient temperature, and projects the annual freshwater withdrawal (proposed target: zero evaporative water, closed-loop direct-to-chip cooling only). By Month 6 (2027-04-17), a written opinion is secured from the regional water authority (Agence de l'Eau Artois-Picardie) confirming that closed-loop cooling is permissible and that no additional water-use permits are required beyond standard stormwater management. If the water authority raises concerns, design review and cooling-technology alternatives are triggered.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Water Resources Manager)

**Suggested Timeframe:** Months 1–6 (2026-11-17 to 2027-04-17), study by Month 4 (2027-02-17), authority opinion by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Hydrological and water-stress assessment study (regional drought risk, competitor water demand, seasonal variation, dry-cooler performance at 35°C ambient, PUE impact modeling)
- Water-authority consultation and engagement (letters, meetings with Agence de l'Eau Artois-Picardie by Month 3 = 2027-01-17)
- Water-authority written preliminary opinion (due Month 6 = 2027-04-17): feasibility of closed-loop cooling, permit requirements, conditions
- Thermal-design-day modeling (PUE at 35°C ambient, peak grid load during hot weather, grid curtailment interaction)
- Risk triggers: if PUE exceeds 1.30 or water authority raises concerns, design review and contingency cooling options (hybrid with limited evaporative water) are activated

**Dependencies:**

- Compliance committee established (step 5)
- Water-resources counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so water-demand per node is clear

### 21. Compliance, Environmental & Social License Committee commissions and coordinates ecological-baseline fieldwork and develops a campus-wide ecological master plan. Botanical, avian, bat and invertebrate surveys are conducted across candidate sites; Natura 2000 designations and protected-species presence are mapped. The master plan identifies: (i) avoidance zones (no-build areas protecting key habitats or protected species), (ii) reduction measures (hall siting and design to minimize impacts), and (iii) compensation strategy (offsite habitat restoration, on-site continuation zones kept in semi-natural state or agricultural production, net-biodiversity target at least 1:1 ratio, stretch target net-positive). The master plan is completed and published by Month 6 (2027-04-17) and serves as the baseline for EIA content and DREAL permitting.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Ecology and Biodiversity Manager)

**Suggested Timeframe:** Months 1–6 (2026-11-17 to 2027-04-17), fieldwork Months 2–5 (2026-12-17 to 2027-03-17), plan finalized by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Ecological baseline surveys (botanical, avian, bat, invertebrate; desktop plus field assessment across all candidate sites)
- Natura 2000 and protected-species mapping
- Campus-wide ecological master plan (avoidance zones, reduced-impact hall siting, biodiversity-compensation strategy, net-positive target)
- Biodiversity offsetting options (on-site continuation zones, off-site habitat creation/restoration, cost estimate EUR 200M–500M for 9 GW, Phase 1 share EUR 50M–150M estimate)
- DREAL consultation and feedback integration

**Dependencies:**

- Compliance committee established (step 5)
- Ecology and biodiversity counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so the envelope and impact scope are defined

### 22. PMO Finance and Lender Relations Lead engages debt capital providers (European Investment Bank, KfW, French banks, infrastructure funds) to establish lending criteria, debt capacity, and preliminary non-binding term-sheet conditions for Phase 1. Lenders are invited to review the Phase 0 gating framework and to signal which gate achievements unlock debt commitments (typically: RTE firm connection offer, signed anchor-tenant take-or-pay for ≥30% of capacity, bounded environmental and remediation liability, firm power-supply contract or LOI, debt-service-coverage ratio above 1.30x). Lender feedback is incorporated into the PMO financial model and gate-review process. A formal debt non-binding LOI or term sheet is targeted by Month 9 (2027-07-17), conditional on gate achievements.

**Responsible Body/Role:** PMO Finance and Lender Relations Lead (with infrastructure finance counsel and arranger)

**Suggested Timeframe:** Months 2–9 (2026-12-17 to 2027-07-17), lender outreach Month 2–3 (2026-12-17 to 2027-01-17), preliminary feedback Month 6 (2027-04-17), term sheet Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Debt-financing strategy and lender-pool assessment (EIB, KfW, French banks, infrastructure funds)
- Lender-engagement plan and term-sheet discussion schedule
- Debt-financing criteria document (gate achievements required: RTE, tenants, liability, power, DSCR, tenor, spreads, covenants)
- Preliminary financial model (EUR 5B Phase 1 capex base, debt capacity scenarios 50%/60%/70% leverage, DSCR under base and stress cases)
- Non-binding debt term sheet or LOI (Month 9 = 2027-07-17): proposed debt size (EUR 3B–3.5B for 500 MW), tenor, pricing (benchmark + 200 bps estimate), gate conditions for final commitment

**Dependencies:**

- PMO Finance Lead appointed (step 7)
- Finance and infrastructure counsel engaged (step 8)
- Phase 0 gating framework and gate criteria defined (step 6)
- Topology and capacity targets defined (Month 4 = 2027-02-17)

### 23. PMO Permitting and Environmental Lead submits the formal ICPE and environmental-authorization permit application(s) to DREAL and the prefecture. One unified permit file is submitted for a single-square topology; if split-campus is chosen, one permit file per node is submitted to isolate legal-challenge risk. The filing date targets Months 8–9 (2027-06-17 to 2027-07-17) to align with the DREAL opinion gate due Month 9 (2027-07-17). The filing includes: expert reports (ecological baseline, hydrological assessment, contamination survey if remediation needed), EIA (avoidance-reduction-compensation analysis, biodiversity net-positive targets, farmland-displacement mitigation, community-benefit commitments), thermal and noise modeling, and security/resilience specifications. An electronic copy is provided to the Compliance committee and PMO for ongoing tracking.

**Responsible Body/Role:** PMO Permitting and Environmental Lead (with ICPE and environmental counsel)

**Suggested Timeframe:** Months 7–9 (2027-05-17 to 2027-07-17), target filing Months 8–9 (2027-06-17 to 2027-07-17)

**Key Outputs/Deliverables:**

- Completed ICPE permit-application file (technical specification, process description, environmental protection measures, monitoring plan)
- Completed environmental-authorization file (EIA summary, avoidance-reduction-compensation strategy, biodiversity assessment, farmland mitigation, community-benefit terms)
- Supporting expert reports and modeling (ecology, hydrology, contamination, thermal, noise, security)
- Letter to DREAL with filing date and timeline expectations (decision targeted 18–30 months from filing, appeal risk to be managed)
- PMO permit-tracking protocol (application reference number, case officer contact, decision timeline milestones)

**Dependencies:**

- PMO Permitting and Environmental Lead appointed (step 7)
- Environmental and ICPE counsel engaged (step 8)
- Ecological master plan completed (step 20)
- Water-authority opinion received (step 19)
- Topology decision finalized (step 17)
- Community consultation closed and feedback integrated (step 10)

### 24. Compliance, Environmental & Social License Committee completes negotiations on a draft community-benefit agreement with municipalities and farm-sector representatives. The agreement specifies: (i) labor and training commitments (regional training academy, local hiring targets, apprenticeship programs); (ii) ecological restoration (EUR 50M–150M Phase 1 estimate, habitat creation, hedgerow establishment, wetland restoration); (iii) farm-sector support (compensation for displaced land, relocation assistance, revenue-sharing on continuation zones, long-term lease options); (iv) municipal infrastructure upgrades (water, roads, utilities); (v) monitoring and oversight roles (municipal and community observers on an environmental or operations monitoring committee). The draft is circulated by Month 4 (2027-02-17) and negotiations close by Month 6 (2027-04-17) so the agreement can be published and appended to the permit file as evidence of community support.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead)

**Suggested Timeframe:** Months 2–6 (2026-12-17 to 2027-04-17), draft by Month 4 (2027-02-17), signed by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Community-benefit agreement (scope: labor, training, ecology, farm-sector support, municipal infrastructure, monitoring roles)
- Signatory list (municipalities, farm unions, regional council, environmental NGOs as appropriate)
- Benefit value summary (EUR 50M–150M Phase 1–2 estimate, labor commitment FTE or hours, ecological hectares, training cohorts)
- Signed community-benefit agreement (or detailed term sheet if final signatures pending)
- Published agreement and fact sheet (distributed to municipalities, press, lenders, co-investors as evidence of social license)

**Dependencies:**

- Municipal liaison committee established (step 10)
- Public consultation completed (step 10)
- Ecological master plan completed (step 20)
- Topology decision finalized (step 17) so parcel and impact scope are defined

### 25. PMO Tenancy and Revenue Lead closes anchor-tenant acquisition and binding term-sheet signature targets. By Month 9 (2027-07-17), signed take-or-pay lease agreements covering at least 30% of Phase 1 capacity are in hand. Acceptable anchors include: (i) global hyperscalers (NVIDIA, Meta, Google, Microsoft, Amazon, or similar, requiring A−/A+ credit rating), (ii) sovereign AI users (French State, EU consortiums, requiring sovereign guarantee or ministerial commitment), or (iii) European enterprise-AI anchors (requiring A−/BBB+ minimum). Capacity-reservation fees (EUR 10M–50M per 100 MW) are collected upfront by Month 6–9 (2027-04-17 to 2027-07-17) and credited to future lease revenue. If less than 30% signed by Month 9 (2027-07-17), the Gate Review Committee flags a threshold breach and recommends Phase 1 downsizing.

**Responsible Body/Role:** PMO Tenancy and Revenue Lead (with commercial advisers and legal counsel)

**Suggested Timeframe:** Months 3–9 (2027-01-17 to 2027-07-17), LOI collection Month 3–6 (2027-01-17 to 2027-04-17), binding term sheets by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Anchor-tenant engagement log (target list, meeting dates, LOI dates, term-sheet negotiation timeline)
- Signed take-or-pay lease agreements (at least 30% of Phase 1 capacity, ≥300 MW on 1 GW base; ≥150 MW on 500 MW base)
- Tenant credit-rating validation and security assessment (BBB− minimum or parent guarantee)
- Capacity-reservation fee receipts (EUR 10M–50M per 100 MW, received by Month 9 = 2027-07-17, credited to future lease revenue)
- Tenant workload and compute-cluster specifications (used to validate latency tolerance for split campus and power/cooling requirements)

**Dependencies:**

- PMO Tenancy Lead appointed (step 7)
- Take-or-pay lease templates finalized (step 16)
- Topology decision (Month 4 = 2027-02-17) so capacity targets and node specifications are clear
- Power-procurement and grid-hosting timeline understood (so lease terms can reference reliability)

### 26. PMO Security and National-Security Lead receives ANSSI confidential preliminary feedback on the security governance white paper (due Month 6 = 2027-04-17, proposed). If ANSSI raises no blocking concerns and indicates a formal security review can commence at Month 13 (2027-11-17) after Phase 0 gate, the security pathway is on track for Phase 1. If ANSSI signals concerns (e.g., foreign co-investor involvement, data-residency restrictions, tenant-access limitations), design review and governance restructuring are triggered. The PMO documents ANSSI findings in a confidential memo for the Steering Committee and Gate Review Committee; the security gate for Phase 1 FID is confirmed (formal review starts Month 13 = 2027-11-17, clearance targeted Month 25–31 = 2028-11-17 to 2029-05-17).

**Responsible Body/Role:** PMO Security and National-Security Lead (with ANSSI liaison and security counsel)

**Suggested Timeframe:** Months 6–7 (2027-04-17 to 2027-05-17), ANSSI feedback receipt and documentation

**Key Outputs/Deliverables:**

- ANSSI confidential preliminary opinion (due Month 6 = 2027-04-17): anticipated formal-review scope, timeline, no-go concerns (if any), tenant-access or data-residency constraints, security-design feedback
- PMO Security Governance Roadmap (updated based on ANSSI feedback, formal-review start date Month 13 = 2027-11-17, clearance target Month 25–31 = 2028-11-17 to 2029-05-17)
- Confidential summary memo for Steering Committee and Gate Review Committee (ANSSI findings, any design implications, security gate status)

**Dependencies:**

- Security governance white paper submitted to ANSSI (step 15)
- ANSSI pre-submission dialogue initiated (step 9)

### 27. PMO Grid and Power Lead distributes the published RTE hosting-capacity audit report to the Gate Review Committee, Steering Committee, lenders and co-investors by Month 9 (2027-07-17). The report summarizes RTE's assessed capacity at Hauts-de-France, the proposed connection timelines by tranche (500 MW, 1 GW, 2+ GW), transmission-reinforcement requirements and cost-sharing, queue position, and assumptions on grid flexibility and curtailment. The audit provides the Gate Review Committee with the evidence needed to assess the grid-hosting gate threshold (RTE preliminary feasibility letter for ≥500 MW within 36 months). If RTE's assessment is negative or capacity is below 500 MW, the grid gate fails and Phase 1 cannot proceed at planned scale.

**Responsible Body/Role:** PMO Grid and Power Lead (with RTE hosting-capacity auditor)

**Suggested Timeframe:** Month 9 (2027-07-17), report completion and distribution

**Key Outputs/Deliverables:**

- Published RTE hosting-capacity audit report (capacity estimates per node and topology, reinforcement scope and cost, queue position, phased connection timelines, curtailment and flexibility assumptions)
- Executive summary for lenders and co-investors (key findings on hosting capacity, transmission risk, cost-share exposure)
- Distribution list confirmation (Gate Review Committee, Steering Committee, lenders, co-investors, PMO)
- RTE letter or signed agreement (firm preliminary feasibility for ≥500 MW within 36 months, if secured by this date)

**Dependencies:**

- RTE hosting-capacity audit commissioned (step 13)
- Topology decision finalized (Month 4 = 2027-02-17) so the audit scope is focused
- RTE pre-submission dialogue ongoing (step 9)

### 28. Compliance, Environmental & Social License Committee receives DREAL's screening opinion on the environmental authorization scope and EIA requirements by Month 9 (2027-07-17), proposed deadline. DREAL confirms whether an EIA is required, specifies the scope of impact assessment (ecology, hydrology, air quality, noise, contamination remediation, heat-reuse potential), and provides preliminary guidance on ICPE classification and fast-track status availability (if any, but fast-track is not assumed). Any DREAL feedback is integrated into the Phase 1 permitting plan, and permit-filing timelines are updated if needed. If DREAL raises new scope requirements, a revised permit-file timeline and cost estimate are issued.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Permitting and Environmental Lead)

**Suggested Timeframe:** Month 9 (2027-07-17), DREAL opinion due

**Key Outputs/Deliverables:**

- DREAL screening opinion (EIA required/not required, scope of assessment, ICPE classification, fast-track availability assessment)
- Permit-file scope update (confirmed EIA sections, expert-report list, DREAL comment integration)
- Updated permit timeline and decision pathway (months from filing to decision, appeal risk, ICPE authorization timeline)

**Dependencies:**

- Compliance committee established (step 5)
- Permit-file roadmap completed (step 14)
- Pre-submission dialogue with DREAL initiated (step 9)
- DREAL pre-submission meeting conducted (Month 2–3 = 2026-12-17 to 2027-01-17)

### 29. Compliance, Environmental & Social License Committee completes fiber-route auditing and confirms that at least 2 physically separate, audited routes (no shared duct, bridge or landing facility) are available to each of Paris, London, Brussels, Amsterdam and Frankfurt, with at least 100 Tbps redundant capacity and ≤25% of cross-border capacity per landing point. Fiber carriers are engaged to provide detailed physical-route maps; an independent fiber auditor verifies true diversity. If independent routes are not available from carriers within cost and timeline, the PMO budgets for a developer-owned or co-funded route and negotiates rights-of-way and duct access. A written confirmation from carriers or a commitment to build/co-invest is secured by Month 9 (2027-07-17).

**Responsible Body/Role:** PMO Grid and Power Lead and/or Tenancy and Revenue Lead (with independent fiber-route auditor and carrier liaisons)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), audits and confirmations by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Fiber-route audit (independent auditor confirms physical-path diversity, no shared conduits/bridges/landings for claimed independent routes)
- Carrier capacity commitments or letters of intent (at least 2 routes per destination, capacity reserved, lit timeline before Phase 1 energization)
- Developer-built/co-invested fiber option (if carrier routes unavailable, budget EUR 100M–500M per 100–200 km route, rights-of-way plan, construction timeline)
- Landing-point diversity confirmation (at least 2 independent UK landings, 2 FR/BE landings, no single landing carries >25% cross-border capacity)
- Published fiber-routing summary for lenders and co-investors

**Dependencies:**

- PMO Grid and Power Lead appointed (step 7)
- Fiber auditor commissioned (step 8)
- Topology decision finalized (Month 4 = 2027-02-17) so routing endpoints are defined

### 30. Gate Review and Kill Authority Committee convenes for the formal Phase 0 gate review at Month 12 (2027-10-17). The committee assesses all five numeric gate thresholds: (i) RTE grid hosting capacity (firm offer or credible pathway for ≥500 MW within 36 months?), (ii) land assembly (≥70% of chosen topology's parcel optioned?), (iii) anchor-tenant take-or-pay (≥30% of Phase 1 signed?), (iv) debt financing (EUR 3B+ commitment confirmed?), (v) social license (2 of 3 municipalities' written support?). For each criterion, the committee reviews the latest red-team pass/fail opinion, supporting evidence, and any expert audits (RTE, fiber, environmental, security). The committee issues a formal Phase 0 Gate Summary report within 10 working days, recommending: (i) Phase 1 FID approval (all gates closed), (ii) conditional approval (gate(s) deferred with specific conditions, Phase 1 start pushed), (iii) Phase 1 downsizing (e.g., 250 MW instead of 500 MW if tenants <30%), (iv) Phase 0 completion with no Phase 1 (project paused or cancelled). The recommendation is published to the Steering Committee, lenders and co-investors.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (Independent Chair, Committee Members, with External Red Team)

**Suggested Timeframe:** Month 12 (2027-10-17), gate review and decision by Month 12–13 (2027-10-17 to 2027-11-17)

**Key Outputs/Deliverables:**

- Phase 0 Gate Summary Report (formal assessment of all five thresholds, evidence presented, pass/fail determination, risks and mitigants)
- Red-team final pass/fail opinion (all five criteria evaluated against published thresholds, updated evidence, risks highlighted)
- Phase 1 FID Recommendation (approve, conditional, downsize, or cancel) with rationale
- Dissent Log (any committee member disagreements on threshold achievement recorded and disclosed to lenders)
- Distribution to Steering Committee, lenders, co-investors within 2 working days of issuance

**Dependencies:**

- Gate Review and Kill Authority Committee chartered and numeric thresholds published (step 6)
- All Phase 0 workstreams closed or approaching closure (grid audit, land surveys, tenant term sheets, debt discussions, permit file submission, ANSSI/DREAL feedback)
- Monthly red-team reports completed (step 18)
- PMO Phase 0 dashboard and deliverable completion status

### 31. Project Steering Committee convenes within 5 working days of the Gate Review and Kill Authority Committee's recommendation to decide on Phase 1 FID. If the committee recommends approval and all gates are closed, the Steering Committee votes to proceed with Phase 1 FID (two-of-three alignment required: sponsor, consortium, independent director). If the committee recommends conditional approval or downsizing, the Steering Committee reviews the conditions and vote accordingly. If the committee recommends cancellation and the Steering Committee votes to override, the override decision and full dissent are published to lenders and co-investors within 2 working days. A Phase 1 FID approval letter is issued by the Sponsor within 3 working days, authorizing Phase 1 budget drawdown and construction start. Phase 0 closure activities (team transition, archives, post-gate reporting) begin.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 12–13 (2027-10-17 to 2027-11-17), decision and approval letter

**Key Outputs/Deliverables:**

- Steering Committee Phase 1 FID Decision Meeting (recorded minutes, voting results, dissent if any)
- Phase 1 FID Approval Letter (from Sponsor, authorizing Phase 1 budget and construction start, conditions if any)
- Phase 1 Financial Close Package (debt-financing documentation, equity commitments, tenant lease executions, power-supply agreements, RTE connection agreement)
- Phase 0 Closure Report (lessons learned, deliverable summary, cost reconciliation, gate achievements and gaps)
- Published Phase 1 FID announcement to media, authorities, stakeholders

**Dependencies:**

- Gate Review and Kill Authority Committee Phase 0 Gate Summary Report (step 30)
- All five gates assessed and recommendations issued

### 32. If Phase 1 FID is approved, the Project Steering Committee authorizes the transition to Phase 1 governance. The Steering Committee remains in place but expands its composition to include Phase 1 operational leads (VP Engineering, VP Operations, VP Community). The Gate Review and Kill Authority Committee's charter is updated to focus on Phase 1 expansion gates: Phase 2 FID (Months 48–54 = 2030-10-17 to 2031-04-17) will require signed take-or-pay for ≥50% of Phase 2 capacity, plus demonstration of Phase 1 operational performance (PUE ≤1.28, power reliability, security compliance). The PMO transitions to Phase 1 construction and operations mode, with Phase 1-specific workstreams (engineering, procurement, construction, commissioning, tenant onboarding). A Phase 1 Governance Roadmap is published, defining decision authorities, escalation thresholds and committee cadences for the 36-month Phase 1 build (Months 12–48 = 2027-10-17 to 2030-10-17).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 13 (2027-11-17), within 2 weeks of Phase 1 FID approval

**Key Outputs/Deliverables:**

- Phase 1 Governance Charter (updated Steering Committee composition, Phase 1 operational leads, committee focus shift to operational milestones)
- Phase 2 Gate Criteria Definition (≥50% demand signed, Phase 1 operational data, PUE ≤1.28, security/community targets met)
- Phase 1 Governance Roadmap (decision authorities, escalation thresholds, committee cadences for 36-month Phase 1)
- Phase 1 PMO Charter and organization structure (engineering, procurement, construction, commissioning, operations, community, safety)
- Stakeholder communication (published Phase 1 Governance Roadmap distributed to lenders, co-investors, authorities, tenants)

**Dependencies:**

- Phase 1 FID approved (step 31)
- Phase 0 gates closed or conditionally passed

### 33. If Phase 1 is conditionally approved or deferred, the Gate Review and Kill Authority Committee defines a Time-Bound Contingency Plan specifying when and how the deferred gate condition(s) will be resolved. For example, if RTE delays issuing a firm connection offer beyond Month 12 (2027-10-17), the plan specifies a target resolution date (e.g., Month 18 = 2028-04-17) and a Phase 1 start date contingent on RTE's response. The committee sets a decision deadline (e.g., Month 18 = 2028-04-17): if the gate condition is not resolved by then, Phase 1 FID is automatically cancelled and the project exits. Alternatively, if gate conditions are resolved before the deadline, the Steering Committee reconvenes and votes on Phase 1 FID. The contingency plan is published to lenders, co-investors and the Sponsor.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (if conditional approval), or Project Steering Committee (if deferral)

**Suggested Timeframe:** Month 12–13 (2027-10-17 to 2027-11-17), if Phase 1 is conditional or deferred

**Key Outputs/Deliverables:**

- Time-Bound Contingency Plan (deferred gate condition, resolution pathway, target resolution date, automatic-exit trigger date)
- Monitoring protocol (who tracks resolution, reporting frequency, escalation if deadline is missed)
- Phase 1 start-date contingency scenarios (if condition resolved by Date X, Phase 1 starts Month Y; if not, project exits)
- Published Contingency Plan distributed to Steering Committee, lenders, co-investors

**Dependencies:**

- Phase 1 is conditionally approved or deferred (Month 12 = 2027-10-17 gate review)

### 34. If Phase 0 gates fail and Phase 1 is cancelled, the PMO executes Phase 0 closure and asset preservation. Land options are extended (2–3 year renewal strategy negotiated with landowners). Grid pre-engineering reports are archived for future reference. Permit-file and community-engagement documentation are preserved. Tenant-term-sheet templates and demand-signal archives are retained. Security governance framework and ANSSI feedback are documented. The Sponsor and consortium evaluate strategic alternatives: (i) downsize and restart Phase 0 with a smaller 250 MW base, (ii) pivot to split-campus model and validate 2–3 node topology separately, (iii) defer indefinitely pending external-condition improvement (grid capacity, tenant demand, permitting regime), or (iv) cancel the project entirely. A Phase 0 Completion and Strategic-Alternatives Report is published documenting the gate failures, sunk costs, preserved assets and recommended path forward.

**Responsible Body/Role:** Project Sponsor, Steering Committee and PMO

**Suggested Timeframe:** Month 12–18 (2027-10-17 to 2028-04-17), if Phase 1 is cancelled

**Key Outputs/Deliverables:**

- Phase 0 Completion and Closure Report (gate failures documented, sunk costs reconciled, preserved assets inventoried)
- Land-option extension agreements (2–3 years, renewal strategy)
- Strategic-alternatives analysis (downsize to 250 MW, split-campus pivot, deferral, cancellation) with pros/cons and cost implications
- Sponsor decision and strategic-direction memo (if any path is chosen)
- Stakeholder communication (published closure report and strategic direction to lenders, co-investors, authorities, communities)

**Dependencies:**

- Phase 0 gates assessed at Month 12 (2027-10-17)
- Phase 1 FID is not approved