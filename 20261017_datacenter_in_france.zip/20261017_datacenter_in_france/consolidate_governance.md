# Governance Audit


## Audit - Corruption Risks

- Selective vendor allocation and GPU/TPU procurement favoritism: preferential allocation to related parties, undisclosed markup on hardware purchase, or side agreements with accelerator suppliers bypassing competitive processes and inflating Phase 1 capex beyond the EUR 5B–10B budget.
- Collusion between grid-connection advisers and RTE pre-engineering consultants to overstate required reinforcement scope or timeline, inflating estimated co-funding obligations and deterring competing bids for the project while benefiting consulting firms through extended engagement.
- Land optioning scheme with insider knowledge: project representatives using confidential topology and zoning information to acquire adjacent parcels ahead of public announcement, or paying family members or related entities above-market fees for option agreements and easements.
- Tenant selection bias in favor of foreign hyperscalers with sovereign-fund backing: steering toward tenants that benefit co-investors or parent companies, accepting below-market lease rates or forgiving SLA penalties in exchange for future capital commitments or board seats.
- Permitting authority capture: offering planning authority or DREAL officials expedited reviews, consulting contracts, or post-employment opportunities in exchange for fast-tracked approvals or overlooking permit conditions that would extend timelines or increase compliance cost.
- Security clearance withholding or conditioning: leveraging unclassified ANSSI feedback informally to exclude competitors or tenants, or conditioning national-security approval on non-binding co-investment terms that give the developer indirect control over downstream capacity allocation.

## Audit - Misallocation Risks

- Phase 0 sunk cost burden-shifting: encumbering EUR 150M–250M of Phase 0 feasibility spend (surveys, permits, land options) to a shell entity or joint venture, then abandoning the entity if the project fails, stranding sunk cost outside the developer's consolidated accounts and obscuring true Phase 0 spend to lenders and co-investors.
- Double spending on grid and power studies: contracting independent RTE hosting-capacity audits and EDF power-market studies to different advisers without coordination, resulting in overlapping scope, duplicate site visits, and inflated advisory fees (EUR 5M–15M exposure) that could have been consolidated.
- Land-option premium inflation without due diligence: paying EUR 15M–50M in option fees to secure parcels during Phase 0 without rigorous Phase I/II environmental or contamination surveys, leading to stranded option premiums if parcels are subsequently ruled out by DREAL or water authorities.
- Unbudgeted community-benefit commitments: making verbal or preliminary written promises of EUR 50M–150M in social-benefit spending (training academy, municipal infrastructure, ecological restoration) without formal approval from the investment committee or capture in Phase 0 contingency reserves, exposing Phase 1 capex to unfunded add-ons.
- Misclassified capex versus opex in pilot-hall validation: charging pilot 2–5 MW cooling system validation (EUR 10M–30M hardware and testing cost) to Phase 0 feasibility rather than Phase 1 capex, artificially constraining Phase 0 spend and deferring cost recognition to a later tranche.
- Contingency reserve misallocation: allocating Phase 0 EUR 750M budget contingency to external party bonuses, consulting markup, or project-overhead allocations rather than reserving it for gate-critical activities (surveys, RTE pre-engineering, legal challenge defense, remediation indemnities), exposing gate achievements to under-resourcing.

## Audit - Procedures

- Monthly Phase 0 spend reconciliation and gate-milestone tracking: reconcile all Phase 0 expenditure (EUR 750M cap) against the four approved milestone tranches (EUR 150M, 250M, 200M, 150M), verify that drawdowns match gate-stage completion (Months 0–2 = 2026-10-17 to 2026-12-17, 3–6, 7–9, 10–12), and publish a variance report to the investment committee and external red team by Month 13 (2027-11-17). Require that no tranche is drawn without signed evidence of progress on grid, land, tenant and permitting gates.
- Quarterly independent RTE and power-procurement verification: engage an external grid engineer and power-market analyst (separate from the development team) to audit all correspondence with RTE and EDF, confirm that hosted capacity, connection timelines and supply contract terms are accurately reported, and validate that any assumed hosting capacity above ~1 GW is backed by written preliminary feasibility letters or firm connection offers (not just verbal or internal notes).
- Anchor-tenant commitment classification and signature audit: conduct a quarterly review of all tenant correspondence (LOIs, term sheets, reservation agreements, take-or-pay leases) by independent counsel to distinguish binding from non-binding commitments, confirm that only signed take-or-pay agreements are counted toward the 30–50% phase-gate threshold, and verify that counterparty credit ratings and parent guarantees are current (updated no less than semi-annually).
- Phase I and Phase II environmental survey completion and remediation-liability mapping: track completion of Phase I desktop assessments (Target Month 1 = 2026-11-17) and Phase II intrusive surveys (Target Month 3 = 2027-01-17) across all candidate sites, and maintain a remediation-liability register mapping each parcel to bounded cost estimates (proposed EUR 0–100M) backed by ESA findings and seller/public indemnity agreements; audit the register quarterly for consistency with permit-application assumptions.
- Topology decision gate audit at Month 4 (2027-02-17): conduct an independent verification that the topology decision (single square versus split campus) is based on documented evidence (land optioning status ≥70%, RTE written letter for ≥1 GW received, or neither), that the decision is recorded in writing with supporting rationale, and that any divergence from the proposed decision framework (e.g., proceeding with single square without RTE letter) is flagged to the investment committee with risk acknowledgment.
- Post-gate financial and scheduling impact review at Phase 0 closure (Month 12 = 2027-10-17) and Phase 1 FID (Month 12–13 = 2027-10-17 to 2027-11-17): audit all Phase 0 gate outcomes (RTE connection offer, land assembly, tenant commitments, debt terms, permitting file status, ANSSI clearance pathway) against pre-agreed thresholds, quantify any shortfall (e.g., anchors 20% instead of 30%) and its impact on Phase 1 viability (debt capacity, lease revenue, energization timeline), and formally recommend to the investment committee whether Phase 1 should proceed, be downsized, be deferred, or be cancelled.

## Audit - Transparency Measures

- Monthly investment committee pass/fail and dissent disclosure: publish a monthly summary (public or to lenders/co-investors) documenting progress on the five Phase 0 gates (grid, land, tenants, financing, social license), marking each gate as 'on track', 'at risk' or 'failed'. Require the committee to publish dissenting opinions and minority votes, so lenders and co-investors can see when there is disagreement on gate status or Phase 1 FID recommendation.
- Quarterly published red-team audit reports: commission an independent red team (Months 1–12 = 2026-11-17 to 2027-10-17) to issue standalone pass/fail opinions on each gate at Months 3, 6, 9 and 12 (2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17), with no edit or veto by the development sponsor. Publish the reports (in redacted form as needed for confidential negotiations) to lenders and co-investors within 10 working days of issue.
- RTE hosting-capacity letter and grid audit publication: publish a summary of RTE's preliminary feasibility assessment and final connection offer (if received by Phase 0 gate) to lenders and major stakeholders, indicating the committed MW, connection timeline, curtailment terms and estimated reinforcement cost. Publish a third-party grid engineer's audit report verifying the RTE assessment by Month 9 (2027-07-17).
- Anchor-tenant commitment register with credit-rating and execution dates: maintain a public or lender-only register of all tenant engagements, showing (i) counterparty name, (ii) LOI or term-sheet signature date, (iii) binding status (Y/N), (iv) capacity reserved (MW), (v) credit rating or parent-guarantee status, (vi) lease term and price, and (vii) reservation-fee payment date and amount. Update quarterly and disclose the register to debt providers.
- Permitting file and environmental baseline public posting: publish the permit application file(s) (ICPE, environmental authorization, EIA dossier) on the project website or a designated public portal as soon as filed (proposed Months 8–9 = 2027-06-17 to 2027-07-17), including the Phase I/II environmental site assessments, hydrological studies, biodiversity surveys, and remediation plans. Maintain an updated register of regulatory authority decisions and comments with resolution timelines.
- Community engagement and public consultation minutes: publish all meeting minutes and feedback from the municipal liaison committee, public consultation, and any formal local hearings within 15 working days. Disclose the draft and final community-benefit agreement and any material changes in response to public input, along with cost estimates and funding commitments per Phase 1 and Phase 2.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** The 9 GW, 161 km², €750M Phase 0 budget is a strategic infrastructure venture with multi-billion euro Phase 1 exposure and extreme feasibility uncertainty. The sponsor, consortium co-investors, and debt/equity sources require a body that sets strategic direction, approves milestone decisions (topology, anchor-tenant strategy, permitting approach), and owns the Phase 0/Phase 1 FID recommendation. This committee harmonizes sponsor intent with co-investor expectations and coordinates responses to RTE, EDF, ANSSI and local authorities.

**Responsibilities:**

- Approve Phase 0 strategy, milestone roadmap and tranche-drawdown schedules within the EUR 750M cap
- Oversee topology decision at Month 4 (2027-02-17): single square vs. split campus
- Review and approve anchor-tenant sourcing strategy and lease-term frameworks
- Approve power-procurement strategy and EDF/RTE engagement approach
- Monitor co-investor alignment and resolve conflicts between sponsor and consortium expectations
- Recommend Phase 1 FID approval or deferral/downsizing at Month 12 (2027-10-17) gate

**Initial Setup Actions:**

- Establish committee charter at Month 1 (2026-11-17) defining roles, decision rules, and escalation protocol
- Assign sponsor CEO/CFO, infrastructure-fund lead, and at least one independent external director
- Set three-way decision rule: sponsor, consortium co-investor and independent director must all approve Phase 1 FID
- Publish committee composition and voting rules to lenders and equity sources by Month 1 (2026-11-17)
- Establish quarterly meeting cadence with standing agenda items: gate status, risk register, sunk-cost assessment
- Commission external red team to provide independent pass/fail opinions before each milestone vote

**Membership:**

- Sponsor hyperscale-developer CEO and CFO
- Infrastructure-fund consortium representative (capital and governance authority)
- Independent external director (infrastructure or energy sector, no financial ties to sponsor or consortium)
- Lender representative (observer, non-voting, to track debt covenants and Phase 1 financing triggers)
- Project Director (voting, operational accountability)

**Decision Rights:** The committee approves all strategic decisions above EUR 50M spend (Phase 0 tranches and gate recommendations), topology choice, tenant acquisition targets, power and grid strategies, and Phase 1 FID. Below EUR 50M operational decisions delegate to the PMO. The committee's Phase 1 FID recommendation is binding if supported by 2 of 3 core votes (sponsor, consortium, independent director); if split 1–2, the decision escalates to a supermajority vote of all members.

**Decision Mechanism:** Decisions by majority vote (3 of 5 members minimum), with sponsor, consortium and independent director each holding one bloc vote. Phase 1 FID requires explicit two-of-three alignment among sponsor, consortium and independent director. Tie-breaker: independent director casts the deciding vote; dissent recorded and published to lenders. Monthly red-team pass/fail opinions inform but do not override committee votes.

**Meeting Cadence:** Monthly (Months 0–12 = 2026-10-17 to 2027-10-17) for Phase 0, with standing agenda: gate-criterion status, tranche drawdown authorization, risk escalations, red-team findings, external-authority responses (RTE, DREAL, ANSSI, EDF). Ad-hoc meetings if a gate criterion is breached or sunk-cost pressure emerges.

**Typical Agenda Items:**

- RTE, EDF, ANSSI and DREAL engagement status (written evidence, preliminary opinions, timeline slippage)
- Land assembly and topology validation (% parcel optioned, Phase II survey findings, holdout issues)
- Anchor-tenant pipeline status (LOI vs. binding term-sheet progress, credit validation, reservation-fee timing)
- Phase 0 spend reconciliation and tranche-drawdown authorization (actual vs. budget, next-tranche triggers)
- Risk register update (grid, land, tenants, permitting, financing, social license) and mitigation actions
- Red-team independent pass/fail opinions and committee response or dissent

**Escalation Path:** Phase 1 FID recommendation (approve, defer, downsize or cancel) escalates to the sponsor board and consortium investment committee if the Steering Committee is split or if a gate threshold is unmet. Kill criteria for Phase 1 cancellation or downsizing are formally triggered by the Gate Review and Kill Authority Committee (see below); the Steering Committee must respect those triggers unless overridden by supermajority sponsor/consortium vote with documented dissent to lenders.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Phase 0 spans 12 months across grid, land, permitting, environmental, security, tenant and financing workstreams, with tight interdependencies and external milestones (RTE, DREAL, ANSSI). A dedicated PMO is essential to track parallel workstreams, manage deliverable timelines, reconcile Phase 0 spend against the EUR 750M cap, and escalate gate-critical risks. The PMO is operationally accountable for Phase 0 execution and reportable to the Steering Committee monthly.

**Responsibilities:**

- Manage Phase 0 workstreams: grid (RTE engagement), land (options, surveys), permitting (file prep), tenants (sourcing, term sheets), financing (lender criteria), security (ANSSI dialogue), community (liaison, consultation)
- Reconcile Phase 0 spend monthly against four milestone tranches (EUR 150M, 250M, 200M, 150M) and seek tranche authorization from the Steering Committee
- Track external-authority milestones (RTE letter, DREAL opinion, ANSSI confirmation, EDF LOI) and escalate slippages
- Execute Phase I/II environmental and contamination surveys, fiber audits, thermal modelling and RTE hosting-capacity audit
- Maintain risk register (23 identified risks plus emergent risks) and escalate high-likelihood, high-severity risks to the Steering Committee
- Coordinate Phase 0 deliverables: topology decision document (Month 4 = 2027-02-17), permitting file (Months 8–9 = 2027-06-17 to 2027-07-17), anchor-tenant term sheets (Month 9 = 2027-07-17), Phase 0 gate summary (Month 12 = 2027-10-17)

**Initial Setup Actions:**

- Establish PMO with at least 40–60 FTE core team (estimate) across grid, land, permitting, environmental, tenant and finance workstreams by Month 0 (2026-10-17)
- Commission specialist advisers: RTE hosting-capacity auditor, hydrologist, ecologist, ICPE counsel, land assembly, security liaison
- Establish regional offices in Cambrai and Dunkirk for land, permitting and community engagement
- Develop detailed Phase 0 workplan with weekly milestone tracking and monthly reporting to the Steering Committee
- Establish a risk-register review cadence (monthly) and escalation protocol to the Steering Committee for risks scoring above a threshold (e.g., High likelihood + High severity)
- Create a financial tracking system reconciling Phase 0 spend by workstream and tranche, with monthly variance reporting

**Membership:**

- Project Director (overall accountability)
- Grid and Power Lead (RTE engagement, hosting-capacity strategy, EDF coordination)
- Land Assembly Lead (parcel acquisition, option agreements, brownfield surveys)
- Permitting and Environmental Lead (ICPE, EIA, DREAL dialogue, ecological master plan)
- Tenant and Revenue Lead (anchor-tenant sourcing, term-sheet negotiation, lease economics)
- Finance and Lender Relations Lead (debt-financing criteria, Phase 0 drawdown management, cost reconciliation)
- Security and National-Security Lead (ANSSI/DGSI dialogue, security governance framework)
- Community and Stakeholder Lead (municipal liaison, public consultation, community-benefit agreement)
- PMO Controller (spend reconciliation, milestone tracking, variance analysis)

**Decision Rights:** PMO approves operational decisions within Phase 0 tranche budgets (EUR 50M monthly run-rate, estimate). Workstream leads make day-to-day procurement and engagement decisions. Decisions exceeding EUR 50M spend, involving strategic trade-offs (e.g., split-campus pivot, tenant-acquisition priority shift), or affecting gate milestones escalate to the Steering Committee. All external-authority responses (RTE, DREAL, ANSSI, EDF) are classified as gate-critical and immediately escalated if they change feasibility assumptions.

**Decision Mechanism:** PMO Lead (Project Director) approves sub-EUR 50M decisions by workstream-lead consensus. Decisions involving workstream conflicts (e.g., land-assembly cost vs. timeline, permitting file scope vs. environmental scope) are escalated to the Steering Committee. Monthly PMO leadership review (all leads) validates milestone status and flags risks. Red-team opinions are reviewed monthly and factored into decision rationale.

**Meeting Cadence:** Weekly internal PMO standup (all leads, 1 hour) to track workstream progress and remove blockers. Monthly PMO review with external advisers (grid auditor, environmental counsel, security liaison) to validate milestone deliverables. Monthly steering-committee report (formal presentation to the Steering Committee).

**Typical Agenda Items:**

- RTE, EDF, DREAL and ANSSI engagement milestones and timeline slippages (e.g., RTE letter due Month 6 = 2027-04-17, any delays flagged)
- Land assembly: % parcel optioned, Phase II survey progress, holdouts or legal challenges, remediation-liability findings
- Tenant pipeline: LOI vs. binding term-sheet conversions, credit validation, reservation-fee payment schedules
- Phase 0 spend reconciliation: actual vs. planned by tranche, next-tranche authorization request to Steering Committee
- Permitting file status: draft completion, content issues, filing date (targeted Months 8–9 = 2027-06-17 to 2027-07-17)
- Risk register: new risks, escalations, mitigation actions, red-team findings

**Escalation Path:** Gate-critical risks (e.g., RTE denial of 500 MW hosting capacity, inability to option 70% of parcel, no anchor tenants by Month 9 = 2027-07-17) escalate immediately to the Steering Committee and the Gate Review and Kill Authority Committee. PMO operational decisions involving workstream conflicts or cost trade-offs escalate to the Project Director, then to the Steering Committee if unresolved. External-authority responses that change feasibility assumptions trigger a formal gate-status review within 1 week.
### 3. Gate Review and Kill Authority Committee

**Rationale for Inclusion:** The plan explicitly states that kill criteria and downsizing are legitimate outcomes, and that sunk-cost pressure typically overrides stated gate thresholds unless kill authority is vested in a body independent of the development team. This committee is chartered to enforce numeric kill thresholds—grid hosting capacity ≥1 GW (cumulative), land assembly ≥70%, anchor-tenant take-or-pay ≥30% by Month 9 (2027-07-17), debt financing ≥EUR 3B, and social license (2 of 3 municipalities). If any threshold fails by the deadline, this committee triggers a formal gate review and recommends cancellation, downsizing, deferral or split-campus pivot, with decisions published to lenders and co-investors.

**Responsibilities:**

- Enforce numeric Phase 0 gate thresholds (grid ≥1 GW, land ≥70%, tenants ≥30% by Month 9 = 2027-07-17, debt ≥EUR 3B, social license ≥2 municipalities) at the Month 12 (2027-10-17) Phase 0 gate
- Review RTE preliminary feasibility letter (or lack thereof) at Month 6 (2027-04-17) and determine whether the grid gate is on track; if not in hand, assess split-campus viability
- Review Phase II environmental and Phase I ESA findings at Month 3 (2027-01-17) to validate land-assembly feasibility; if remediation costs exceed EUR 100M per site or contamination blocks parcels, recommend site substitution or split campus
- Review anchor-tenant pipeline at Month 9 (2027-07-17): quantify signed take-or-pay vs. LOI, credit validation, confirm ≥30% binding commitments; if <30%, trigger Phase 1 downsizing to 250–500 MW
- Publish monthly red-team audit opinions (independent consultants), documenting pass/fail on each gate criterion; dissent from development team opinions recorded and disclosed
- Recommend Phase 1 FID approval, conditional approval with specific conditions, deferral pending gate resolution, downsizing, or cancellation; recommendation is binding unless overridden by supermajority Steering Committee vote with dissent published

**Initial Setup Actions:**

- Charter the committee at Month 1 (2026-11-17) with composition: at least 2 independent external directors (no financial ties to sponsor or consortium), 1 lender representative, 1 infrastructure-sector expert
- Commission an independent red team (EUR 2M–5M) to deliver monthly pass/fail opinions on each of five gate criteria (grid, land, tenants, financing, social license) from Month 1 (2026-11-17) through Month 12 (2027-10-17)
- Fix numeric kill thresholds in writing by Month 2 (2026-12-17): grid ≥1 GW cumulative (or ≥500 MW single node + credible path to 1 GW), land ≥70% optioned at <15% above benchmark, tenants ≥30% (≥300 MW on 1 GW base, ≥150 MW on 500 MW base) signed by Month 9 (2027-07-17), debt ≥EUR 3B committed, social license ≥2 of 3 municipalities, all published to lenders
- Establish meeting and decision protocol: monthly red-team report review + quarterly gate-status assessment (Months 3, 6, 9, 12 = 2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17)
- Define escalation protocol: if any gate threshold is breached, committee has 10 working days to issue a formal gate-status report and recommendation; recommendation is binding on the Steering Committee unless overridden by supermajority vote (2 of 3: sponsor, consortium, independent director) with full dissent disclosure
- Appoint a dedicated chair (independent external director) with authority to call unscheduled gate reviews if red-team findings indicate threshold breach

**Membership:**

- Independent External Chair (infrastructure, energy or finance sector, no affiliation with sponsor, consortium or lenders; appointed by mutual consent of sponsor and consortium at Month 1 = 2026-11-17)
- Independent External Director 2 (technical or environmental expertise; project feasibility validation)
- Lender Representative (debt-financing criteria and Phase 1 FID conditions, non-voting but advisory input)
- Infrastructure-Sector Expert (independent adviser on grid, power and major-project feasibility; non-voting but provides technical opinion on RTE and EDF outcomes)
- External Red Team Lead (independent consultant, monthly pass/fail reports, no voting role but directly inputs to committee deliberation)

**Decision Rights:** The committee's scope is confined to gate-threshold validation and kill/downsize/defer recommendations. It does not approve strategy (delegated to Steering Committee) or direct operations (delegated to PMO). The committee's recommendations are binding on the Steering Committee unless the Steering Committee explicitly overrides by supermajority vote (2 of 3: sponsor, consortium, independent director) with recorded dissent and public disclosure to lenders within 5 working days. If the committee recommends cancellation and the Steering Committee overrides, the override decision and dissent are disclosed to all debt and equity sources.

**Decision Mechanism:** Consensus where possible. If disagreement arises on gate-threshold achievement (e.g., whether a preliminary RTE letter satisfies the grid gate or whether provisional anchors qualify as 'signed'), the committee documents both positions and escalates to the Steering Committee with a recommendation of which position is more credible. Tie-breaker: the independent chair casts the deciding opinion. Red-team pass/fail opinions are advisory input, not votes.

**Meeting Cadence:** Monthly gate-status review (1st working day of each month, Months 1–12 = 2026-11-17 to 2027-10-17) of red-team reports and PMO milestone updates. Formal gate-assessment meetings at Months 3, 6, 9 and 12 (2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17) to validate threshold achievement and issue gate-status reports to the Steering Committee and lenders.

**Typical Agenda Items:**

- Red-team monthly pass/fail opinion on each of five gate criteria: grid (RTE letter received? timing on track?), land (% optioned, remediation findings), tenants (LOI vs. binding breakdown, credit validation), financing (debt commitment status, pricing acceptable?), social license (municipal letters of support in hand?)
- External-authority milestone tracking: RTE letter (due Month 6 = 2027-04-17), DREAL opinion (due Month 9 = 2027-07-17), ANSSI confirmation (due Month 12 = 2027-10-17), EDF LOI (due Month 6 = 2027-04-17, term sheet Month 9 = 2027-07-17)
- Phase II environmental and contamination survey findings: any sites ruled out, remediation costs exceeding EUR 100M per site, holdout issues affecting ≥30% of target parcel
- Anchor-tenant term-sheet status: number of signed agreements, total MW, credit ratings, reservation-fee payment receipts; conversion of LOIs to binding documents
- Debt-financing status: lender interest, term-sheet negotiations, required gate achievements for debt final commitment
- Community-engagement and municipal-support status: liaison-committee minutes, consultation feedback, municipal letters of support in hand or on schedule

**Escalation Path:** If the committee determines that a gate threshold is breached (e.g., RTE letter not received by Month 6 = 2027-04-17, land optioning <70% by Month 4 = 2027-02-17, tenants <30% signed by Month 9 = 2027-07-17, debt commitment not in hand by Month 12 = 2027-10-17), the committee issues a formal gate-status report within 5 working days and recommends one of: (i) Phase 1 proceeds (all thresholds met), (ii) Phase 1 conditional approval pending specific condition (e.g., RTE letter expected by Month 18 = 2028-04-17), (iii) Phase 1 downsized (e.g., 250 MW instead of 500 MW if tenants <30%), (iv) Phase 1 deferred (6–12 months pending gate resolution), or (v) Phase 0 completion with no Phase 1 FID (project paused or cancelled). The Steering Committee may override the committee's recommendation by supermajority vote with full dissent recording and disclosure to lenders. If lenders or co-investors invoke debt covenants or capital-call conditions triggered by a failed gate, the Kill Authority Committee's recommendation is published to those parties within 2 working days of issue.
### 4. Compliance, Environmental & Social License Committee

**Rationale for Inclusion:** The project faces complex, interconnected constraints: ICPE and environmental authorization (18–30 months + 24–48 months appeal risk), ANSSI/DGSI national-security review (6–12 months, uncontrolled), GDPR and data-residency compliance (foreign co-investor, sovereign tenants, AI workloads), ecological compensation (net-biodiversity, farmland displacement of 10,000+ ha, estimated EUR 200M–500M cost), water-resource constraints (closed-loop cooling required, water-authority approval), brownfield remediation (legacy contamination EUR 0–100M+ per site, liability allocation disputes), and community social license (municipal support, farm-sector engagement, public consultation). No single person can credibly oversee all five domains (permitting, security, ecology, water, community). A dedicated committee ensures compliance risks do not fall between workstreams and that gate-critical environmental and social-license conditions are not overlooked in pursuit of schedule or cost targets.

**Responsibilities:**

- Oversee ICPE and environmental authorization process, including EIA scope, file content, DREAL engagement, permit conditions and post-permit compliance monitoring
- Manage national-security review (ANSSI, DGSI) including confidential security governance framework, tenant-vetting criteria, data-residency policies, and alignment with foreign-co-investor requirements
- Ensure GDPR compliance for data processing at multi-tenant data center; define data-residency and sovereignty requirements with legal counsel and authorities
- Implement ecological master plan (submitted Month 6 = 2027-04-17), manage biodiversity offsetting and compensation, coordinate with environmental NGOs and conservation authorities on net-biodiversity targets
- Manage water-resource compliance: secure written water-authority opinion on closed-loop cooling feasibility (due Month 6 = 2027-04-17), track permitting conditions tied to water use, monitor groundwater contamination from brownfield sites
- Oversee brownfield remediation and contamination liability: track Phase I/II ESA findings, bound liability per parcel, negotiate seller indemnities and public-remediation arrangements, escalate unexpected contamination discoveries
- Lead community engagement and social-license strategy: establish municipal liaison committee, run early voluntary consultation (Months 1–3 = 2026-11-17 to 2027-01-17), draft and negotiate community-benefit agreement (EUR 50M–150M, due Month 6 = 2027-04-17), track farm-sector and NGO opposition, escalate legal-challenge risk
- Coordinate integration of compliance requirements into Phase 1 permitting conditions and Phase 1 capex budget (e.g., ecological compensation cost, security hardening cost, community-benefit spend)

**Initial Setup Actions:**

- Charter the committee at Month 1 (2026-11-17) with roles: ICPE/Environmental Lead, National-Security and GDPR Counsel, Ecology and Biodiversity Manager, Water Resources Manager, Community and Stakeholder Lead
- Engage specialized counsel: ICPE expert, environmental and EIA counsel, ANSSI/security law specialist, GDPR and data-protection counsel, environmental NGO liaison, water-law specialist, land and remediation counsel
- Commission Phase I (desktop) environmental site assessments on all candidate parcels by Month 1 (2026-11-17)
- Commission Phase II intrusive surveys (soil, groundwater, asbestos) on top 2–3 sites per zone by Month 3 (2027-01-17), EST 1.5M–3M per zone
- Establish ICPE and environmental file content roadmap (Month 1 = 2026-11-17): identify required studies, expert reports, baseline data, modeling and conditions
- Initiate DREAL and prefecture pre-submission dialogue (Month 0–1 = 2026-10-17 to 2026-11-17): outline project scope, receive preliminary guidance on permit pathway, ICPE classification and fast-track status (if any)
- Establish confidential ANSSI pre-submission engagement (Month 0–1 = 2026-10-17 to 2026-11-17): present security governance framework, understand anticipated review scope, timeline and authorities' concerns
- Commission hydrological study and water-authority consultation (Months 1–4 = 2026-11-17 to 2027-02-17): validate closed-loop cooling feasibility, obtain water-authority preliminary opinion by Month 6 (2027-04-17)
- Establish municipal liaison committee (Month 2 = 2026-12-17): invite mayors and representatives from at least 3 most-affected municipalities; establish monthly dialogue protocol and published meeting minutes
- Develop draft community-benefit agreement (Months 2–4 = 2026-12-17 to 2027-02-17) covering labor, training, ecological restoration, farm relocation, and local infrastructure; bind terms by Month 6 (2027-04-17)

**Membership:**

- Compliance and Regulatory Lead (overall committee accountability, ICPE and permitting authority interface)
- National-Security and GDPR Counsel (ANSSI/DGSI liaison, security governance, data-residency requirements, foreign-co-investor compliance)
- Ecology and Biodiversity Manager (environmental baseline, EIA content, biodiversity offsetting, NGO coordination)
- Water Resources Manager (hydrological assessment, water-authority liaison, cooling-feasibility validation, groundwater contamination tracking)
- Community and Stakeholder Engagement Lead (municipal liaison, public consultation, community-benefit agreement, farm-sector engagement, opposition escalation)
- Brownfield and Remediation Counsel (Phase I/II ESA management, liability allocation, seller/public indemnities, contamination-discovery protocol)

**Decision Rights:** The committee advises the Steering Committee and PMO on compliance and social-license requirements, and makes day-to-day decisions on engagement with authorities, environmental consultants, municipalities and communities within the framework established by the Steering Committee. The committee has veto authority over permit-file content if it believes a proposed approach creates unacceptable legal or reputational risk; such vetoes escalate to the Steering Committee. Community-benefit agreement terms up to EUR 50M in Phase 0 pre-commitment are approved by the committee in consultation with the Steering Committee; terms above EUR 50M or with material operational implications escalate to the Steering Committee for approval.

**Decision Mechanism:** Decisions within the committee by consensus among the six leads. If disagreement arises (e.g., whether to pursue fast-track permitting vs. standard ICPE, whether to offer a municipal veto on certain design elements), the committee documents both positions and escalates to the Steering Committee or PMO for decision. Authority over community-benefit terms up to EUR 20M per tranche is delegated to the Stakeholder Lead in consultation with the Regulatory Lead; above EUR 20M, committee consensus is required.

**Meeting Cadence:** Bi-weekly workstream coordination (each lead with their specialists and external advisers) to track permitting, environmental, security and community milestones. Monthly full-committee meetings (all six leads) to integrate findings across domains and escalate material risks or changes to the Steering Committee. Ad-hoc meetings if authorities issue new guidance, legal challenges are filed, or community opposition escalates.

**Typical Agenda Items:**

- ICPE and environmental authorization: file-content draft status, expert reports completion timeline, DREAL feedback, permit-application date (targeted Months 8–9 = 2027-06-17 to 2027-07-17)
- National-security review: ANSSI pre-submission feedback (Month 6 = 2027-04-17 target), security governance framework refinement, tenant-vetting and data-residency policy drafting, anticipated formal-review start date
- Ecological master plan: EIA scope (habitat types, species surveys), biodiversity-impact model, compensation measures (on-site and off-site), NGO consultation feedback, DREAL opinion timeline (due Month 9 = 2027-07-17)
- Water and cooling: hydrological baseline findings, dry-cooler modelling at 35°C design day, water-authority preliminary opinion status (due Month 6 = 2027-04-17), any grounds for regulatory water-use restrictions
- Brownfield and contamination: Phase I ESA findings, Phase II survey progress, remediation-liability estimates per parcel, site-shortlist refinement, indemnity negotiations with sellers or public authorities
- Community engagement and social license: municipal liaison-committee meeting minutes (published), public consultation feedback, draft community-benefit agreement, farm-sector union engagement, opposition tracking and escalation
- Permit-check at Month 18 (2028-04-17): assessment of whether initial ICPE and EIA decisions are on schedule for approval by target window (Months 26–39 = 2028-12-17 to 2030-01-17); if slippage is material (>6 months), recommend Phase 1 FID contingency

**Escalation Path:** Material compliance risks (e.g., ANSSI blocks the project pending data-residency restructuring, DREAL requires additional ecological compensation exceeding EUR 300M, communities block permits, water authority denies cooling feasibility) escalate to the Steering Committee within 5 working days of identification. Contamination discoveries exceeding the bounded remediation threshold (EUR 100M per site) trigger immediate PMO and Steering Committee escalation. Legal challenges to permits that could extend timelines beyond Month 26 (2028-12-17) are escalated to gate-review assessment. ANSSI findings that restrict foreign tenants or co-investor involvement are escalated immediately to the Steering Committee, as they may affect tenant strategy and financing. Community opposition that reaches organized legal challenge or formal municipal objection escalates to the Steering Committee as a social-license gate threat.

# Governance Implementation Plan

### 1. Project Sponsor formally authorizes Phase 0 governance structure and delegates authority for committee establishment to the Project Director. Sponsor issues a written mandate defining the scope of Phase 0 (Months 0–12 = 2026-10-17 to 2027-10-17), the EUR 750M cap, the four governance bodies, and the decision-making framework. This authorization establishes the legal and organizational foundation for all subsequent governance activities.

**Responsible Body/Role:** Project Sponsor (or Senior Steering Body Pre-Governance)

**Suggested Timeframe:** Month 0 (2026-10-17), within 1 week of project kickoff

**Key Outputs/Deliverables:**

- Signed Project Authorization Mandate
- Phase 0 Scope and Budget (EUR 750M cap, four tranches, no committed capital before gate)
- Governance Structure Charter (four bodies, roles, responsibilities)
- Delegation of Authority to Project Director for Committee Setup

**Dependencies:**

- Project sponsor board approval
- Infrastructure-fund consortium alignment on governance framework
- Co-investor agreement to the governance model

### 2. Project Director establishes the Project Steering Committee Charter and identifies initial membership. The charter documents: composition (Sponsor CEO/CFO, Consortium Lead, at least one Independent External Director, Lender Observer, Project Director); voting rules (3-of-5 majority for most decisions, 2-of-3 alignment requirement for Phase 1 FID); decision thresholds (EUR 50M and above escalate); meeting cadence (monthly); and escalation protocol. The Project Director solicits and formalizes commitments from all five designated members.

**Responsible Body/Role:** Project Director (in consultation with Sponsor and Consortium)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2 weeks of project authorization

**Key Outputs/Deliverables:**

- Project Steering Committee Charter (signed by all five members)
- Committee composition and member role descriptions
- Voting and decision-making rules (3-of-5 majority, 2-of-3 FID alignment, EUR 50M threshold)
- Quarterly and monthly meeting schedules
- Escalation protocol and dissent recording procedures

**Dependencies:**

- Project Authorization Mandate (step 1)
- Identification and agreement of Independent External Director (no financial ties)
- Lender and consortium appointments confirmed

### 3. Project Steering Committee holds its first kick-off meeting. The committee reviews the Phase 0 roadmap, confirms the four governance bodies and their responsibilities, validates the EUR 750M four-tranche budget structure (EUR 150M / 250M / 200M / 150M), and assigns the Project Director responsibility for Phase 0 execution. The committee establishes its monthly meeting agenda template and approves the engagement approach for external authorities (RTE, EDF, DREAL, ANSSI).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 1 (2026-11-17), within 1 week of charter signature

**Key Outputs/Deliverables:**

- Steering Committee Kick-Off Meeting Minutes
- Approved Phase 0 Roadmap and Milestone Schedule
- Confirmed governance-body roles and responsibilities
- Monthly agenda template and decision-preparation procedures
- First Tranche Authorization (EUR 150M Months 0–2 = 2026-10-17 to 2026-12-17)

**Dependencies:**

- Project Steering Committee Charter signed (step 2)

### 4. Project Director establishes the Gate Review and Kill Authority Committee. The Project Director recruits and formally appoints: at least 2 Independent External Directors (infrastructure or energy expertise, no financial ties to sponsor or consortium), 1 Lender Representative (non-voting, advisory), and 1 Infrastructure-Sector Expert (non-voting). The Project Director commissions an external red team (proposed EUR 2M–5M budget) to deliver independent monthly pass/fail opinions on the five gate criteria (grid, land, tenants, financing, social license). The committee chair is appointed by mutual consent of sponsor and consortium.

**Responsible Body/Role:** Project Director (in consultation with Sponsor, Consortium and Steering Committee)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2–3 weeks of kickoff

**Key Outputs/Deliverables:**

- Gate Review and Kill Authority Committee Charter (signed)
- Committee composition and member roles
- External red team engagement letter and scope (monthly pass/fail reports)
- Committee chair appointment letter
- Draft numeric kill thresholds (to be finalized at step 6)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee First Meeting completed (step 3)
- Budget allocation for red team (EUR 2M–5M from Phase 0 tranche 1)

### 5. Project Director establishes the Compliance, Environmental & Social License Committee. The Project Director recruits and appoints six functional leads: ICPE/Environmental Lead, National-Security and GDPR Counsel, Ecology and Biodiversity Manager, Water Resources Manager, Community and Stakeholder Lead, and Brownfield and Remediation Counsel. Each lead is tasked with commissioning Phase I environmental site assessments (desktop) on all candidate parcels, initiating formal pre-submission dialogues with DREAL and ANSSI, and establishing the municipal liaison committee. The PMO Controller reports monthly to this committee on compliance-workstream spend and deliverable status.

**Responsible Body/Role:** Project Director (in consultation with Steering Committee PMO Lead)

**Suggested Timeframe:** Month 1 (2026-11-17), within 2–3 weeks of kickoff

**Key Outputs/Deliverables:**

- Compliance, Environmental & Social License Committee Charter (signed)
- Six functional-lead role descriptions and contact persons
- Engagement letters with ICPE counsel, environmental counsel, ANSSI/security counsel, GDPR counsel, land counsel
- Phase I ESA commission instructions (all candidate parcels) by end of Month 1 (2026-11-17)
- Pre-submission dialogue openings with DREAL, ANSSI, prefecture by Month 0–1 (2026-10-17 to 2026-11-17)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee First Meeting (step 3)
- Budget allocation for compliance-workstream specialists and Phase I surveys

### 6. Gate Review and Kill Authority Committee formally fixes numeric kill thresholds in writing and publishes them to lenders, co-investors and the Steering Committee. Thresholds are: (i) RTE grid hosting capacity at least 500 MW within 36 months (first written evidence due Month 6 = 2027-04-17); (ii) at least 70% of chosen topology's target parcel optioned non-coercively at no more than 15% above benchmark land value; (iii) signed anchor-tenant take-or-pay agreements for at least 30% of Phase 1 size by Month 9 (2027-07-17); (iv) firm debt commitment of at least EUR 3B with acceptable terms by Month 12 (2027-10-17); (v) written support from at least 2 of 3 most-affected municipalities by Month 12 (2027-10-17). The committee also publishes the decision protocol: if any threshold is breached by its deadline, the committee issues a formal gate-status report within 5 working days and recommends phase advance, conditional approval, downsizing, deferral or cancellation.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (chaired by Independent External Director)

**Suggested Timeframe:** Month 2 (2026-12-17), by end of Month 2 (2026-12-17)

**Key Outputs/Deliverables:**

- Published Numeric Kill Thresholds Document (signed by committee chair and all members)
- Gate Criterion Definitions: grid (RTE letter by Month 6 = 2027-04-17), land (70% by Month 4 = 2027-02-17), tenants (30% signed by Month 9 = 2027-07-17), debt (EUR 3B by Month 12 = 2027-10-17), social license (2 municipalities by Month 12 = 2027-10-17)
- Decision protocol and gate-status-report template
- Distribution list for dissemination to lenders, co-investors, Steering Committee
- Red team engagement and first pass/fail report instructions

**Dependencies:**

- Gate Review and Kill Authority Committee Charter signed (step 4)
- Committee chair appointed
- Steering Committee aware of and endorses thresholds

### 7. Project Management Office (PMO) is established and staffed with a core team of 40–60 people across eight functional workstreams: Grid and Power, Land Assembly, Permitting and Environmental, Tenancy and Revenue, Finance and Lender Relations, Security and National-Security, Community and Stakeholder, and PMO Administration (Controller). Each workstream lead is assigned and given a Phase 0 detailed plan (deliverables, timelines, success criteria, escalation triggers). The PMO establishes weekly standup meetings (all leads), monthly full-team reviews, and a risk-register maintenance process. Regional offices are established in Cambrai and Dunkirk.

**Responsible Body/Role:** Project Director (appoints PMO Lead/Project Manager)

**Suggested Timeframe:** Month 1 (2026-11-17), within 3 weeks of authorization

**Key Outputs/Deliverables:**

- PMO Charter and organization structure (8 workstreams, 40–60 FTE core team)
- Workstream lead job descriptions and accountability
- Detailed Phase 0 workplan by workstream (timelines, deliverables, success criteria)
- Risk register template and maintenance protocol (monthly updates, escalations for High+High risks)
- Weekly standup and monthly review meeting schedules
- Regional office setup plan (Cambrai and Dunkirk address, staff, office equipment)

**Dependencies:**

- Project Authorization Mandate (step 1)
- Steering Committee charter signed (step 2)
- Project Director appointed
- Budget authority for 40–60 FTE salaries and regional offices

### 8. PMO commissions specialized advisers and survey firms across critical Phase 0 workstreams: (i) RTE hosting-capacity auditor (independent third-party), (ii) hydrologist and water-resource consultant, (iii) environmental and EIA counsel, (iv) ICPE specialist, (v) land-assembly and real-estate counsel, (vi) Phase I/II ESA and contamination surveyors (one team per geographic zone: Cambrai, Dunkirk, Valenciennes, Saint-Omer), (vii) security and ANSSI liaison counsel, (viii) fiber-route auditor (telecom specialist). Each adviser is tasked with delivering specific Phase 0 gate-critical outputs by agreed deadlines (e.g., RTE audit by Month 9 = 2027-07-17, Phase II surveys by Month 3 = 2027-01-17).

**Responsible Body/Role:** PMO Lead (Project Director) and Workstream Leads

**Suggested Timeframe:** Month 1 (2026-11-17), engagement letters issued by end of Month 1 (2026-11-17)

**Key Outputs/Deliverables:**

- Signed engagement letters with each adviser/surveyor
- Scope of work and deliverable specifications for each adviser
- Budget allocation and fee schedules
- Timeline alignment with Phase 0 gate milestones (Month 4, 6, 9, 12 = 2027-02-17, 2027-04-17, 2027-07-17, 2027-10-17)
- Contact and escalation protocols (who reports to whom, monthly status meetings)

**Dependencies:**

- PMO established and workstream leads appointed (step 7)
- Budget approved for specialist advisers (Phase 0 tranche 1, EUR 150M)

### 9. PMO initiates formal pre-submission dialogue with external authorities: RTE (grid hosting-capacity assessment, connection-offer timeline, tranche availability), DREAL and prefecture (permit pathway, ICPE classification, environmental-authorization scope, fast-track status if any), ANSSI and DGSI (national-security review scope, timeline, data-residency and foreign-investment scrutiny, security-governance expectations). All dialogue is documented in writing; responses are classified as gate-critical. A formal written request is sent to each authority by Month 0–1 (2026-10-17 to 2026-11-17), with follow-up meetings scheduled by Month 2 (2026-12-17).

**Responsible Body/Role:** PMO Leads: Grid and Power (RTE), Permitting and Environmental (DREAL/Prefecture), Security and National-Security (ANSSI/DGSI); with support from Project Director and specialist counsel

**Suggested Timeframe:** Month 0–1 (2026-10-17 to 2026-11-17), dialogue initiated

**Key Outputs/Deliverables:**

- Written pre-submission request letters to RTE, DREAL, ANSSI, prefecture (with project overview, siting rationale, key technical parameters, timeline expectations)
- Meeting schedules and participant lists (internal team + authority representatives)
- Documentation log of all authority responses (emails, letters, meeting minutes)
- Summary of preliminary authority feedback (if any) by Month 2 (2026-12-17)
- Gate-critical response tracking (target RTE letter Month 6 = 2027-04-17, water opinion Month 6 = 2027-04-17, ANSSI opinion Month 6 = 2027-04-17, DREAL opinion Month 9 = 2027-07-17)

**Dependencies:**

- PMO established (step 7)
- Specialist advisers identified (step 8)

### 10. Compliance, Environmental & Social License Committee establishes the municipal liaison committee and launches early voluntary public consultation. The committee contacts representatives from at least the three most-affected municipalities (Cambrai, Dunkirk, Valenciennes or equivalent in chosen topology), invites them to join a monthly liaison dialogue, and publishes the consultation launch with a transparent project overview, siting rationale, technical specifications (power, cooling, fiber, security), environmental and social-impact scope, and a 4-week comment period. Consultation feedback is recorded and a response summary is published by Month 5 (2027-03-17).

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), liaison committee established by Month 2 (2026-12-17), consultation launched by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Municipal liaison committee charter (members, meeting schedule, published minutes protocol)
- First municipal liaison committee meeting (Month 2 = 2026-12-17)
- Public consultation launch package (project overview, siting rationale, technical specs, environmental and social scope, 4-week comment period)
- Published meeting minutes from at least two liaison-committee meetings
- Public consultation feedback summary and project response (published by Month 5 = 2027-03-17)

**Dependencies:**

- Compliance, Environmental & Social License Committee established (step 5)
- Project location and topology (or alternative topologies) defined

### 11. PMO Land Assembly Lead and specialist real-estate counsel conduct a parcel-by-parcel option survey across all candidate sites (Cambrai, Dunkirk, Valenciennes, Saint-Omer) to assess: ownership chains (public vs. private), known holdout or activist groups, fragmentation, above-market-value expectations, and option-agreement feasibility. A preliminary go/no-go assessment is produced by Month 3 (2027-01-17) answering whether at least 70% of the single-square target parcel (or the split-campus node targets) can be optioned non-coercively at less than 15% above benchmark land value. If the single-square falls short of 70%, the assessment recommends a split-campus topology; if both fail, a further downsize or site substitution is flagged.

**Responsible Body/Role:** PMO Land Assembly Lead (with real-estate counsel and municipal/registry liaison)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), assessment by end of Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Parcel-by-parcel survey report (ownership, fragmentation, holdout risk, land-value benchmarks)
- Land-assembly feasibility assessment: single-square vs. split-campus viability
- Topology recommendation (single square if ≥70% optionable, split campus if single square fails)
- Phase II environmental site assessment commission instructions (identify highest-priority sites)
- Option-agreement strategy and initial-approach outreach list

**Dependencies:**

- PMO established (step 7)
- Municipal liaison dialogue initiated (step 10) for municipal-registry and ownership-chain access
- Candidate site map and land-use boundaries defined

### 12. Compliance, Environmental & Social License Committee commissions Phase II intrusive environmental site assessments (soil boring, groundwater sampling, asbestos survey) on the top 2–3 candidate sites in each geographic zone. Assessments are targeted to close by Month 3 (2027-01-17) so that contamination findings can feed the land-assembly topology decision (Month 4 = 2027-02-17). Remediation-liability estimates are produced per site; sites with bounded remediation costs below EUR 100M are shortlisted; sites exceeding this threshold are either excluded or flagged for further negotiation with the landowner or public remediation authority.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Brownfield and Remediation Counsel) and PMO Environmental/Permitting Lead

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), surveys commissioned Month 1 (2026-11-17), reports closed by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Phase II ESA engagement letters and scope (soil, groundwater, asbestos, baseline survey per site)
- Phase II ESA reports (one per high-priority site, estimated cost EUR 1.5M–3M per zone)
- Remediation-liability estimate per site (bounded to EUR 0–100M range preferred)
- Site-shortlist decision (include, exclude, or conditional on seller indemnity)
- Indemnity negotiation strategy with landowners or public remediation authorities

**Dependencies:**

- Land-assembly parcel survey completed (step 11)
- Compliance committee established (step 5)
- Budget allocated for Phase II surveys (Phase 0 tranche 1–2)

### 13. PMO Grid and Power Lead commissions an independent RTE hosting-capacity assessment (third-party auditor) to estimate available 400 kV substation connection capacity at Hauts-de-France, assess transmission-reinforcement timelines and cost-sharing requirements, and model phased tranches (500 MW, 1 GW, 2+ GW). The auditor liaises with RTE to understand queue position, multi-tranche allocation policy, firm vs. conditional connection-offer timelines, and curtailment/flexibility requirements. A detailed hosting-capacity audit report is delivered by Month 9 (2027-07-17) and published to the Gate Review Committee, lenders and co-investors.

**Responsible Body/Role:** PMO Grid and Power Lead (with independent RTE hosting-capacity auditor)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), audit engagement Month 1 (2026-11-17), report Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- RTE hosting-capacity auditor engagement letter and scope
- Hosting-capacity audit report (Month 9 = 2027-07-17): capacity estimates per node, transmission reinforcement scope and cost-share, queue position, connection-offer timeline by tranche
- Grid reinforcement cost estimate (EUR 500M–1.5B range, propose risk allocation)
- Phased connection-offer model (500 MW first tranche, pathway to 1 GW, assumptions on flexibility and curtailment)
- Published audit summary distributed to Gate Review Committee, Steering Committee, lenders

**Dependencies:**

- PMO Grid Lead appointed (step 7)
- RTE pre-submission dialogue initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so the auditor can focus on the chosen node(s)

### 14. PMO Permitting and Environmental Lead, in coordination with environmental counsel, develops detailed ICPE and environmental-authorization permit-file roadmap. The roadmap specifies: required expert reports (ecological baseline, hydrological assessment, air-quality and noise modeling, contamination survey, thermal plume modeling if water-cooling), EIA scope (avoidance-reduction-compensation hierarchy for ecological impact, biodiversity net-positive targets, farmland displacement mitigation), baseline data collection timelines, DREAL feedback integration, and targeted permit-file submission date (Months 8–9 = 2027-06-17 to 2027-07-17). This roadmap feeds into the Compliance committee's permitting-file production schedule.

**Responsible Body/Role:** PMO Permitting and Environmental Lead (with ICPE specialist counsel, environmental counsel, EIA specialist)

**Suggested Timeframe:** Months 1–2 (2026-11-17 to 2026-12-17), roadmap completed by Month 2 (2026-12-17)

**Key Outputs/Deliverables:**

- ICPE and environmental-authorization permit-file roadmap (required components, baseline data, expert reports, timelines)
- EIA scope and avoidance-reduction-compensation strategy
- Permit-file production schedule (targeting filing Months 8–9 = 2027-06-17 to 2027-07-17)
- Expert-report commission plan and budget allocation
- DREAL pre-submission feedback integration plan

**Dependencies:**

- Compliance committee established (step 5)
- Pre-submission dialogue with DREAL initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so the scope is clear

### 15. PMO Security and National-Security Lead, in coordination with security and GDPR counsel, prepares a confidential security governance white paper for ANSSI pre-submission. The white paper covers: tenant selection and vetting process, data-residency and national-security data-handling policies, perimeter hardening and anti-drone specifications, cyber-OT separation architecture, personnel-clearance requirements, supply-chain assurance, co-investor governance and control provisions, and alignment with French AI and sovereignty strategy. The white paper is submitted to ANSSI in advance of the formal pre-submission meeting (target Month 1–2 = 2026-11-17 to 2026-12-17) to solicit informal guidance on the anticipated review scope and any early concerns.

**Responsible Body/Role:** PMO Security and National-Security Lead (with security counsel and GDPR counsel)

**Suggested Timeframe:** Months 0–2 (2026-10-17 to 2026-12-17), white paper drafted and submitted by Month 1–2 (2026-11-17 to 2026-12-17)

**Key Outputs/Deliverables:**

- Confidential security governance white paper (tenant vetting, data residency, perimeter security, cyber-OT separation, supply-chain assurance, co-investor control provisions)
- Pre-submission meeting request to ANSSI (Months 0–1 = 2026-10-17 to 2026-11-17)
- ANSSI confidential preliminary feedback (due Month 6 = 2027-04-17, proposed)
- GDPR data-processing and data-residency compliance framework

**Dependencies:**

- PMO Security Lead appointed (step 7)
- Security and GDPR counsel engaged (step 8)
- Project technical specifications defined (power, cooling, fiber, topology)

### 16. PMO Grid and Power Lead, in coordination with independent power-market advisers, commences multi-party power-procurement negotiations with EDF and coordinates with RTE on flexibility and BESS requirements. Negotiations target a non-binding letter of intent from EDF by Month 6 (2027-04-17) confirming willingness to discuss a multi-year baseload contract for at least 500 MW at a capped EUR/MWh price (proposed range EUR 50–70/MWh, not verified). A formal term sheet (non-binding but detailed) is targeted for Month 9 (2027-07-17). Energy pricing and curtailment assumptions are modeled in parallel; grid curtailment at or below 10% is the base assumption, with a walk-away threshold of 15%.

**Responsible Body/Role:** PMO Grid and Power Lead (with independent power-market adviser and EDF liaison)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), EDF dialogue ongoing, LOI by Month 6 (2027-04-17), term sheet by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Power-market study and pricing assessment (EUR/MWh forecast, multi-GW contract feasibility, hedging options)
- EDF non-binding letter of intent (Month 6 = 2027-04-17): 500 MW baseload, minimum 10-year tenor, price range to be confirmed in term sheet
- EDF formal term sheet (Month 9 = 2027-07-17): capacity, price, tenor, indexation, curtailment/flexibility terms
- BESS and demand-flexibility modeling (50–200 MWh, grid-stress mitigation, cost estimate)
- Power-cost sensitivity model (base case vs. +EUR 30/MWh shock scenario, impact on tenant lease pricing and project returns)

**Dependencies:**

- PMO Grid and Power Lead appointed (step 7)
- RTE pre-submission dialogue initiated (step 9)
- Topology decision (Month 4 = 2027-02-17) so capacity targets are clear

### 17. Steering Committee holds a formal topology-decision meeting at Month 4 (2027-02-17). The committee reviews evidence from three sources: (i) land-assembly feasibility (% parcel optioned, contamination findings, holdout risk), (ii) RTE grid-capacity signals (preliminary letter received or timeline credible by Month 6 = 2027-04-17?), and (iii) permitting and social-license risk (single-square vs. split-campus complexity). The committee votes on single-square vs. split-campus, documents the rationale, and publishes the topology decision to lenders and co-investors. If RTE has not yet delivered a letter (due Month 6 = 2027-04-17), the split-campus default is applied; the single square can only be chosen if RTE written evidence of at least 1 GW capacity is already in hand.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 4 (2027-02-17), topology-decision meeting

**Key Outputs/Deliverables:**

- Topology Decision Document (single square vs. split campus, rationale, evidence cited)
- Land-assembly feasibility summary (% parcel optioned, contamination bounded, holdout risk)
- RTE grid-capacity evidence (if in hand) or pathway statement (letter due Month 6 = 2027-04-17)
- Detailed capex and timeline per topology option (single square EUR 5B–10B, split campus EUR 5.5B–9.2B, schedule difference)
- Published topology decision distributed to PMO, Gate Review Committee, lenders, co-investors

**Dependencies:**

- Land-assembly feasibility assessment (step 11)
- Phase II ESA reports (step 12)
- RTE pre-submission dialogue completed (step 9); letter not yet due, but dialogue status assessed

### 18. PMO Tenancy and Revenue Lead develops standardized high-commitment take-or-pay lease term sheets (5–10 year proposed tenor) and capacity-reservation fee structures (EUR 10M–50M per 100 MW proposed, credited against future lease revenue). Templates are finalized by Month 3 (2027-01-17) and distributed to the project's anchor-tenant acquisition team. Target anchor tenants include 2–3 global hyperscalers or AI labs (hyperscaler pool) and 2–3 sovereign-AI or European-consortium anchors (sovereign pool). Initial outreach and non-binding letter of intent collection begins in Month 3 (2027-01-17); conversion of LOIs to binding term sheets is targeted by Month 9 (2027-07-17) for at least 30% of Phase 1 capacity.

**Responsible Body/Role:** PMO Tenancy and Revenue Lead (with real-estate counsel and commercial advisers)

**Suggested Timeframe:** Months 1–3 (2026-11-17 to 2027-01-17), templates by Month 3 (2027-01-17)

**Key Outputs/Deliverables:**

- Standardized take-or-pay lease term sheet (5–10 year tenor, capacity reserved, force-majeure exceptions, SLA carve-outs for grid curtailment, annual escalation)
- Capacity-reservation fee schedule (EUR 10M–50M per 100 MW, payment timeline before construction start)
- Tenant acquisition targeting roadmap (2–3 hyperscalers, 2–3 sovereign anchors, outreach timeline, LOI targets)
- Tenant due-diligence criteria (credit rating BBB− minimum or parent guarantee, compute-cluster workload requirements, latency tolerance for split campus, security/data-residency requirements)
- LOI template and non-binding engagement plan

**Dependencies:**

- PMO Tenancy Lead appointed (step 7)
- Real-estate and commercial counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so capacity targets and node specifications are clear
- Power-procurement and grid-hosting timeline understood (so lease terms can reference power reliability and curtailment)

### 19. Gate Review and Kill Authority Committee implements monthly monitoring of gate-criterion achievement. Starting Month 1 (2026-11-17), the external red team delivers a monthly pass/fail opinion on each of the five gate criteria: (i) grid hosting-capacity status (RTE letter received or timeline credible?), (ii) land assembly (% parcel optioned, remediation findings), (iii) anchor-tenant pipeline (LOI vs. binding breakdown, credit validation), (iv) debt-financing status (lender interest, term-sheet progress), (v) social license (municipal support, opposition escalation). The red-team reports are reviewed by the committee in monthly gate-status sessions; any criterion showing a High-likelihood breach is flagged to the Steering Committee within 5 working days.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (with External Red Team)

**Suggested Timeframe:** Monthly, starting Month 1 (2026-11-17), through Month 12 (2027-10-17)

**Key Outputs/Deliverables:**

- External red-team monthly pass/fail reports (5 criteria assessed against numeric thresholds, evidence presented, risks flagged)
- Monthly gate-status summary for the Steering Committee (which criteria on track, which at risk, recommended actions)
- Quarterly formal gate-assessment meetings (Months 3, 6, 9, 12 = 2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17) with detailed written gate-status reports
- Escalation alerts (high-risk breaches within 5 working days to Steering Committee and PMO)
- Published dissent log (committee disagreements on threshold achievement recorded and disclosed to lenders)

**Dependencies:**

- Gate Review and Kill Authority Committee chartered (step 4)
- External red team engaged (step 4)
- Numeric kill thresholds published (step 6)

### 20. Compliance, Environmental & Social License Committee oversees the completion of hydrological study and water-authority engagement. A hydrologist assesses regional water stress, validates dry-cooler feasibility at a 35°C design-day ambient temperature, and projects the annual freshwater withdrawal (proposed target: zero evaporative water, closed-loop direct-to-chip cooling only). By Month 6 (2027-04-17), a written opinion is secured from the regional water authority (Agence de l'Eau Artois-Picardie) confirming that closed-loop cooling is permissible and that no additional water-use permits are required beyond standard stormwater management. If the water authority raises concerns, design review and cooling-technology alternatives are triggered.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Water Resources Manager)

**Suggested Timeframe:** Months 1–6 (2026-11-17 to 2027-04-17), study by Month 4 (2027-02-17), authority opinion by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Hydrological and water-stress assessment study (regional drought risk, competitor water demand, seasonal variation, dry-cooler performance at 35°C ambient, PUE impact modeling)
- Water-authority consultation and engagement (letters, meetings with Agence de l'Eau Artois-Picardie by Month 3 = 2027-01-17)
- Water-authority written preliminary opinion (due Month 6 = 2027-04-17): feasibility of closed-loop cooling, permit requirements, conditions
- Thermal-design-day modeling (PUE at 35°C ambient, peak grid load during hot weather, grid curtailment interaction)
- Risk triggers: if PUE exceeds 1.30 or water authority raises concerns, design review and contingency cooling options (hybrid with limited evaporative water) are activated

**Dependencies:**

- Compliance committee established (step 5)
- Water-resources counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so water-demand per node is clear

### 21. Compliance, Environmental & Social License Committee commissions and coordinates ecological-baseline fieldwork and develops a campus-wide ecological master plan. Botanical, avian, bat and invertebrate surveys are conducted across candidate sites; Natura 2000 designations and protected-species presence are mapped. The master plan identifies: (i) avoidance zones (no-build areas protecting key habitats or protected species), (ii) reduction measures (hall siting and design to minimize impacts), and (iii) compensation strategy (offsite habitat restoration, on-site continuation zones kept in semi-natural state or agricultural production, net-biodiversity target at least 1:1 ratio, stretch target net-positive). The master plan is completed and published by Month 6 (2027-04-17) and serves as the baseline for EIA content and DREAL permitting.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Ecology and Biodiversity Manager)

**Suggested Timeframe:** Months 1–6 (2026-11-17 to 2027-04-17), fieldwork Months 2–5 (2026-12-17 to 2027-03-17), plan finalized by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Ecological baseline surveys (botanical, avian, bat, invertebrate; desktop plus field assessment across all candidate sites)
- Natura 2000 and protected-species mapping
- Campus-wide ecological master plan (avoidance zones, reduced-impact hall siting, biodiversity-compensation strategy, net-positive target)
- Biodiversity offsetting options (on-site continuation zones, off-site habitat creation/restoration, cost estimate EUR 200M–500M for 9 GW, Phase 1 share EUR 50M–150M estimate)
- DREAL consultation and feedback integration

**Dependencies:**

- Compliance committee established (step 5)
- Ecology and biodiversity counsel engaged (step 8)
- Topology decision (Month 4 = 2027-02-17) so the envelope and impact scope are defined

### 22. PMO Finance and Lender Relations Lead engages debt capital providers (European Investment Bank, KfW, French banks, infrastructure funds) to establish lending criteria, debt capacity, and preliminary non-binding term-sheet conditions for Phase 1. Lenders are invited to review the Phase 0 gating framework and to signal which gate achievements unlock debt commitments (typically: RTE firm connection offer, signed anchor-tenant take-or-pay for ≥30% of capacity, bounded environmental and remediation liability, firm power-supply contract or LOI, debt-service-coverage ratio above 1.30x). Lender feedback is incorporated into the PMO financial model and gate-review process. A formal debt non-binding LOI or term sheet is targeted by Month 9 (2027-07-17), conditional on gate achievements.

**Responsible Body/Role:** PMO Finance and Lender Relations Lead (with infrastructure finance counsel and arranger)

**Suggested Timeframe:** Months 2–9 (2026-12-17 to 2027-07-17), lender outreach Month 2–3 (2026-12-17 to 2027-01-17), preliminary feedback Month 6 (2027-04-17), term sheet Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Debt-financing strategy and lender-pool assessment (EIB, KfW, French banks, infrastructure funds)
- Lender-engagement plan and term-sheet discussion schedule
- Debt-financing criteria document (gate achievements required: RTE, tenants, liability, power, DSCR, tenor, spreads, covenants)
- Preliminary financial model (EUR 5B Phase 1 capex base, debt capacity scenarios 50%/60%/70% leverage, DSCR under base and stress cases)
- Non-binding debt term sheet or LOI (Month 9 = 2027-07-17): proposed debt size (EUR 3B–3.5B for 500 MW), tenor, pricing (benchmark + 200 bps estimate), gate conditions for final commitment

**Dependencies:**

- PMO Finance Lead appointed (step 7)
- Finance and infrastructure counsel engaged (step 8)
- Phase 0 gating framework and gate criteria defined (step 6)
- Topology and capacity targets defined (Month 4 = 2027-02-17)

### 23. PMO Permitting and Environmental Lead submits the formal ICPE and environmental-authorization permit application(s) to DREAL and the prefecture. One unified permit file is submitted for a single-square topology; if split-campus is chosen, one permit file per node is submitted to isolate legal-challenge risk. The filing date targets Months 8–9 (2027-06-17 to 2027-07-17) to align with the DREAL opinion gate due Month 9 (2027-07-17). The filing includes: expert reports (ecological baseline, hydrological assessment, contamination survey if remediation needed), EIA (avoidance-reduction-compensation analysis, biodiversity net-positive targets, farmland-displacement mitigation, community-benefit commitments), thermal and noise modeling, and security/resilience specifications. An electronic copy is provided to the Compliance committee and PMO for ongoing tracking.

**Responsible Body/Role:** PMO Permitting and Environmental Lead (with ICPE and environmental counsel)

**Suggested Timeframe:** Months 7–9 (2027-05-17 to 2027-07-17), target filing Months 8–9 (2027-06-17 to 2027-07-17)

**Key Outputs/Deliverables:**

- Completed ICPE permit-application file (technical specification, process description, environmental protection measures, monitoring plan)
- Completed environmental-authorization file (EIA summary, avoidance-reduction-compensation strategy, biodiversity assessment, farmland mitigation, community-benefit terms)
- Supporting expert reports and modeling (ecology, hydrology, contamination, thermal, noise, security)
- Letter to DREAL with filing date and timeline expectations (decision targeted 18–30 months from filing, appeal risk to be managed)
- PMO permit-tracking protocol (application reference number, case officer contact, decision timeline milestones)

**Dependencies:**

- PMO Permitting and Environmental Lead appointed (step 7)
- Environmental and ICPE counsel engaged (step 8)
- Ecological master plan completed (step 20)
- Water-authority opinion received (step 19)
- Topology decision finalized (step 17)
- Community consultation closed and feedback integrated (step 10)

### 24. Compliance, Environmental & Social License Committee completes negotiations on a draft community-benefit agreement with municipalities and farm-sector representatives. The agreement specifies: (i) labor and training commitments (regional training academy, local hiring targets, apprenticeship programs); (ii) ecological restoration (EUR 50M–150M Phase 1 estimate, habitat creation, hedgerow establishment, wetland restoration); (iii) farm-sector support (compensation for displaced land, relocation assistance, revenue-sharing on continuation zones, long-term lease options); (iv) municipal infrastructure upgrades (water, roads, utilities); (v) monitoring and oversight roles (municipal and community observers on an environmental or operations monitoring committee). The draft is circulated by Month 4 (2027-02-17) and negotiations close by Month 6 (2027-04-17) so the agreement can be published and appended to the permit file as evidence of community support.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead)

**Suggested Timeframe:** Months 2–6 (2026-12-17 to 2027-04-17), draft by Month 4 (2027-02-17), signed by Month 6 (2027-04-17)

**Key Outputs/Deliverables:**

- Community-benefit agreement (scope: labor, training, ecology, farm-sector support, municipal infrastructure, monitoring roles)
- Signatory list (municipalities, farm unions, regional council, environmental NGOs as appropriate)
- Benefit value summary (EUR 50M–150M Phase 1–2 estimate, labor commitment FTE or hours, ecological hectares, training cohorts)
- Signed community-benefit agreement (or detailed term sheet if final signatures pending)
- Published agreement and fact sheet (distributed to municipalities, press, lenders, co-investors as evidence of social license)

**Dependencies:**

- Municipal liaison committee established (step 10)
- Public consultation completed (step 10)
- Ecological master plan completed (step 20)
- Topology decision finalized (step 17) so parcel and impact scope are defined

### 25. PMO Tenancy and Revenue Lead closes anchor-tenant acquisition and binding term-sheet signature targets. By Month 9 (2027-07-17), signed take-or-pay lease agreements covering at least 30% of Phase 1 capacity are in hand. Acceptable anchors include: (i) global hyperscalers (NVIDIA, Meta, Google, Microsoft, Amazon, or similar, requiring A−/A+ credit rating), (ii) sovereign AI users (French State, EU consortiums, requiring sovereign guarantee or ministerial commitment), or (iii) European enterprise-AI anchors (requiring A−/BBB+ minimum). Capacity-reservation fees (EUR 10M–50M per 100 MW) are collected upfront by Month 6–9 (2027-04-17 to 2027-07-17) and credited to future lease revenue. If less than 30% signed by Month 9 (2027-07-17), the Gate Review Committee flags a threshold breach and recommends Phase 1 downsizing.

**Responsible Body/Role:** PMO Tenancy and Revenue Lead (with commercial advisers and legal counsel)

**Suggested Timeframe:** Months 3–9 (2027-01-17 to 2027-07-17), LOI collection Month 3–6 (2027-01-17 to 2027-04-17), binding term sheets by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Anchor-tenant engagement log (target list, meeting dates, LOI dates, term-sheet negotiation timeline)
- Signed take-or-pay lease agreements (at least 30% of Phase 1 capacity, ≥300 MW on 1 GW base; ≥150 MW on 500 MW base)
- Tenant credit-rating validation and security assessment (BBB− minimum or parent guarantee)
- Capacity-reservation fee receipts (EUR 10M–50M per 100 MW, received by Month 9 = 2027-07-17, credited to future lease revenue)
- Tenant workload and compute-cluster specifications (used to validate latency tolerance for split campus and power/cooling requirements)

**Dependencies:**

- PMO Tenancy Lead appointed (step 7)
- Take-or-pay lease templates finalized (step 16)
- Topology decision (Month 4 = 2027-02-17) so capacity targets and node specifications are clear
- Power-procurement and grid-hosting timeline understood (so lease terms can reference reliability)

### 26. PMO Security and National-Security Lead receives ANSSI confidential preliminary feedback on the security governance white paper (due Month 6 = 2027-04-17, proposed). If ANSSI raises no blocking concerns and indicates a formal security review can commence at Month 13 (2027-11-17) after Phase 0 gate, the security pathway is on track for Phase 1. If ANSSI signals concerns (e.g., foreign co-investor involvement, data-residency restrictions, tenant-access limitations), design review and governance restructuring are triggered. The PMO documents ANSSI findings in a confidential memo for the Steering Committee and Gate Review Committee; the security gate for Phase 1 FID is confirmed (formal review starts Month 13 = 2027-11-17, clearance targeted Month 25–31 = 2028-11-17 to 2029-05-17).

**Responsible Body/Role:** PMO Security and National-Security Lead (with ANSSI liaison and security counsel)

**Suggested Timeframe:** Months 6–7 (2027-04-17 to 2027-05-17), ANSSI feedback receipt and documentation

**Key Outputs/Deliverables:**

- ANSSI confidential preliminary opinion (due Month 6 = 2027-04-17): anticipated formal-review scope, timeline, no-go concerns (if any), tenant-access or data-residency constraints, security-design feedback
- PMO Security Governance Roadmap (updated based on ANSSI feedback, formal-review start date Month 13 = 2027-11-17, clearance target Month 25–31 = 2028-11-17 to 2029-05-17)
- Confidential summary memo for Steering Committee and Gate Review Committee (ANSSI findings, any design implications, security gate status)

**Dependencies:**

- Security governance white paper submitted to ANSSI (step 15)
- ANSSI pre-submission dialogue initiated (step 9)

### 27. PMO Grid and Power Lead distributes the published RTE hosting-capacity audit report to the Gate Review Committee, Steering Committee, lenders and co-investors by Month 9 (2027-07-17). The report summarizes RTE's assessed capacity at Hauts-de-France, the proposed connection timelines by tranche (500 MW, 1 GW, 2+ GW), transmission-reinforcement requirements and cost-sharing, queue position, and assumptions on grid flexibility and curtailment. The audit provides the Gate Review Committee with the evidence needed to assess the grid-hosting gate threshold (RTE preliminary feasibility letter for ≥500 MW within 36 months). If RTE's assessment is negative or capacity is below 500 MW, the grid gate fails and Phase 1 cannot proceed at planned scale.

**Responsible Body/Role:** PMO Grid and Power Lead (with RTE hosting-capacity auditor)

**Suggested Timeframe:** Month 9 (2027-07-17), report completion and distribution

**Key Outputs/Deliverables:**

- Published RTE hosting-capacity audit report (capacity estimates per node and topology, reinforcement scope and cost, queue position, phased connection timelines, curtailment and flexibility assumptions)
- Executive summary for lenders and co-investors (key findings on hosting capacity, transmission risk, cost-share exposure)
- Distribution list confirmation (Gate Review Committee, Steering Committee, lenders, co-investors, PMO)
- RTE letter or signed agreement (firm preliminary feasibility for ≥500 MW within 36 months, if secured by this date)

**Dependencies:**

- RTE hosting-capacity audit commissioned (step 13)
- Topology decision finalized (Month 4 = 2027-02-17) so the audit scope is focused
- RTE pre-submission dialogue ongoing (step 9)

### 28. Compliance, Environmental & Social License Committee receives DREAL's screening opinion on the environmental authorization scope and EIA requirements by Month 9 (2027-07-17), proposed deadline. DREAL confirms whether an EIA is required, specifies the scope of impact assessment (ecology, hydrology, air quality, noise, contamination remediation, heat-reuse potential), and provides preliminary guidance on ICPE classification and fast-track status availability (if any, but fast-track is not assumed). Any DREAL feedback is integrated into the Phase 1 permitting plan, and permit-filing timelines are updated if needed. If DREAL raises new scope requirements, a revised permit-file timeline and cost estimate are issued.

**Responsible Body/Role:** Compliance, Environmental & Social License Committee (Permitting and Environmental Lead)

**Suggested Timeframe:** Month 9 (2027-07-17), DREAL opinion due

**Key Outputs/Deliverables:**

- DREAL screening opinion (EIA required/not required, scope of assessment, ICPE classification, fast-track availability assessment)
- Permit-file scope update (confirmed EIA sections, expert-report list, DREAL comment integration)
- Updated permit timeline and decision pathway (months from filing to decision, appeal risk, ICPE authorization timeline)

**Dependencies:**

- Compliance committee established (step 5)
- Permit-file roadmap completed (step 14)
- Pre-submission dialogue with DREAL initiated (step 9)
- DREAL pre-submission meeting conducted (Month 2–3 = 2026-12-17 to 2027-01-17)

### 29. Compliance, Environmental & Social License Committee completes fiber-route auditing and confirms that at least 2 physically separate, audited routes (no shared duct, bridge or landing facility) are available to each of Paris, London, Brussels, Amsterdam and Frankfurt, with at least 100 Tbps redundant capacity and ≤25% of cross-border capacity per landing point. Fiber carriers are engaged to provide detailed physical-route maps; an independent fiber auditor verifies true diversity. If independent routes are not available from carriers within cost and timeline, the PMO budgets for a developer-owned or co-funded route and negotiates rights-of-way and duct access. A written confirmation from carriers or a commitment to build/co-invest is secured by Month 9 (2027-07-17).

**Responsible Body/Role:** PMO Grid and Power Lead and/or Tenancy and Revenue Lead (with independent fiber-route auditor and carrier liaisons)

**Suggested Timeframe:** Months 1–9 (2026-11-17 to 2027-07-17), audits and confirmations by Month 9 (2027-07-17)

**Key Outputs/Deliverables:**

- Fiber-route audit (independent auditor confirms physical-path diversity, no shared conduits/bridges/landings for claimed independent routes)
- Carrier capacity commitments or letters of intent (at least 2 routes per destination, capacity reserved, lit timeline before Phase 1 energization)
- Developer-built/co-invested fiber option (if carrier routes unavailable, budget EUR 100M–500M per 100–200 km route, rights-of-way plan, construction timeline)
- Landing-point diversity confirmation (at least 2 independent UK landings, 2 FR/BE landings, no single landing carries >25% cross-border capacity)
- Published fiber-routing summary for lenders and co-investors

**Dependencies:**

- PMO Grid and Power Lead appointed (step 7)
- Fiber auditor commissioned (step 8)
- Topology decision finalized (Month 4 = 2027-02-17) so routing endpoints are defined

### 30. Gate Review and Kill Authority Committee convenes for the formal Phase 0 gate review at Month 12 (2027-10-17). The committee assesses all five numeric gate thresholds: (i) RTE grid hosting capacity (firm offer or credible pathway for ≥500 MW within 36 months?), (ii) land assembly (≥70% of chosen topology's parcel optioned?), (iii) anchor-tenant take-or-pay (≥30% of Phase 1 signed?), (iv) debt financing (EUR 3B+ commitment confirmed?), (v) social license (2 of 3 municipalities' written support?). For each criterion, the committee reviews the latest red-team pass/fail opinion, supporting evidence, and any expert audits (RTE, fiber, environmental, security). The committee issues a formal Phase 0 Gate Summary report within 10 working days, recommending: (i) Phase 1 FID approval (all gates closed), (ii) conditional approval (gate(s) deferred with specific conditions, Phase 1 start pushed), (iii) Phase 1 downsizing (e.g., 250 MW instead of 500 MW if tenants <30%), (iv) Phase 0 completion with no Phase 1 (project paused or cancelled). The recommendation is published to the Steering Committee, lenders and co-investors.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (Independent Chair, Committee Members, with External Red Team)

**Suggested Timeframe:** Month 12 (2027-10-17), gate review and decision by Month 12–13 (2027-10-17 to 2027-11-17)

**Key Outputs/Deliverables:**

- Phase 0 Gate Summary Report (formal assessment of all five thresholds, evidence presented, pass/fail determination, risks and mitigants)
- Red-team final pass/fail opinion (all five criteria evaluated against published thresholds, updated evidence, risks highlighted)
- Phase 1 FID Recommendation (approve, conditional, downsize, or cancel) with rationale
- Dissent Log (any committee member disagreements on threshold achievement recorded and disclosed to lenders)
- Distribution to Steering Committee, lenders, co-investors within 2 working days of issuance

**Dependencies:**

- Gate Review and Kill Authority Committee chartered and numeric thresholds published (step 6)
- All Phase 0 workstreams closed or approaching closure (grid audit, land surveys, tenant term sheets, debt discussions, permit file submission, ANSSI/DREAL feedback)
- Monthly red-team reports completed (step 18)
- PMO Phase 0 dashboard and deliverable completion status

### 31. Project Steering Committee convenes within 5 working days of the Gate Review and Kill Authority Committee's recommendation to decide on Phase 1 FID. If the committee recommends approval and all gates are closed, the Steering Committee votes to proceed with Phase 1 FID (two-of-three alignment required: sponsor, consortium, independent director). If the committee recommends conditional approval or downsizing, the Steering Committee reviews the conditions and vote accordingly. If the committee recommends cancellation and the Steering Committee votes to override, the override decision and full dissent are published to lenders and co-investors within 2 working days. A Phase 1 FID approval letter is issued by the Sponsor within 3 working days, authorizing Phase 1 budget drawdown and construction start. Phase 0 closure activities (team transition, archives, post-gate reporting) begin.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 12–13 (2027-10-17 to 2027-11-17), decision and approval letter

**Key Outputs/Deliverables:**

- Steering Committee Phase 1 FID Decision Meeting (recorded minutes, voting results, dissent if any)
- Phase 1 FID Approval Letter (from Sponsor, authorizing Phase 1 budget and construction start, conditions if any)
- Phase 1 Financial Close Package (debt-financing documentation, equity commitments, tenant lease executions, power-supply agreements, RTE connection agreement)
- Phase 0 Closure Report (lessons learned, deliverable summary, cost reconciliation, gate achievements and gaps)
- Published Phase 1 FID announcement to media, authorities, stakeholders

**Dependencies:**

- Gate Review and Kill Authority Committee Phase 0 Gate Summary Report (step 30)
- All five gates assessed and recommendations issued

### 32. If Phase 1 FID is approved, the Project Steering Committee authorizes the transition to Phase 1 governance. The Steering Committee remains in place but expands its composition to include Phase 1 operational leads (VP Engineering, VP Operations, VP Community). The Gate Review and Kill Authority Committee's charter is updated to focus on Phase 1 expansion gates: Phase 2 FID (Months 48–54 = 2030-10-17 to 2031-04-17) will require signed take-or-pay for ≥50% of Phase 2 capacity, plus demonstration of Phase 1 operational performance (PUE ≤1.28, power reliability, security compliance). The PMO transitions to Phase 1 construction and operations mode, with Phase 1-specific workstreams (engineering, procurement, construction, commissioning, tenant onboarding). A Phase 1 Governance Roadmap is published, defining decision authorities, escalation thresholds and committee cadences for the 36-month Phase 1 build (Months 12–48 = 2027-10-17 to 2030-10-17).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 13 (2027-11-17), within 2 weeks of Phase 1 FID approval

**Key Outputs/Deliverables:**

- Phase 1 Governance Charter (updated Steering Committee composition, Phase 1 operational leads, committee focus shift to operational milestones)
- Phase 2 Gate Criteria Definition (≥50% demand signed, Phase 1 operational data, PUE ≤1.28, security/community targets met)
- Phase 1 Governance Roadmap (decision authorities, escalation thresholds, committee cadences for 36-month Phase 1)
- Phase 1 PMO Charter and organization structure (engineering, procurement, construction, commissioning, operations, community, safety)
- Stakeholder communication (published Phase 1 Governance Roadmap distributed to lenders, co-investors, authorities, tenants)

**Dependencies:**

- Phase 1 FID approved (step 31)
- Phase 0 gates closed or conditionally passed

### 33. If Phase 1 is conditionally approved or deferred, the Gate Review and Kill Authority Committee defines a Time-Bound Contingency Plan specifying when and how the deferred gate condition(s) will be resolved. For example, if RTE delays issuing a firm connection offer beyond Month 12 (2027-10-17), the plan specifies a target resolution date (e.g., Month 18 = 2028-04-17) and a Phase 1 start date contingent on RTE's response. The committee sets a decision deadline (e.g., Month 18 = 2028-04-17): if the gate condition is not resolved by then, Phase 1 FID is automatically cancelled and the project exits. Alternatively, if gate conditions are resolved before the deadline, the Steering Committee reconvenes and votes on Phase 1 FID. The contingency plan is published to lenders, co-investors and the Sponsor.

**Responsible Body/Role:** Gate Review and Kill Authority Committee (if conditional approval), or Project Steering Committee (if deferral)

**Suggested Timeframe:** Month 12–13 (2027-10-17 to 2027-11-17), if Phase 1 is conditional or deferred

**Key Outputs/Deliverables:**

- Time-Bound Contingency Plan (deferred gate condition, resolution pathway, target resolution date, automatic-exit trigger date)
- Monitoring protocol (who tracks resolution, reporting frequency, escalation if deadline is missed)
- Phase 1 start-date contingency scenarios (if condition resolved by Date X, Phase 1 starts Month Y; if not, project exits)
- Published Contingency Plan distributed to Steering Committee, lenders, co-investors

**Dependencies:**

- Phase 1 is conditionally approved or deferred (Month 12 = 2027-10-17 gate review)

### 34. If Phase 0 gates fail and Phase 1 is cancelled, the PMO executes Phase 0 closure and asset preservation. Land options are extended (2–3 year renewal strategy negotiated with landowners). Grid pre-engineering reports are archived for future reference. Permit-file and community-engagement documentation are preserved. Tenant-term-sheet templates and demand-signal archives are retained. Security governance framework and ANSSI feedback are documented. The Sponsor and consortium evaluate strategic alternatives: (i) downsize and restart Phase 0 with a smaller 250 MW base, (ii) pivot to split-campus model and validate 2–3 node topology separately, (iii) defer indefinitely pending external-condition improvement (grid capacity, tenant demand, permitting regime), or (iv) cancel the project entirely. A Phase 0 Completion and Strategic-Alternatives Report is published documenting the gate failures, sunk costs, preserved assets and recommended path forward.

**Responsible Body/Role:** Project Sponsor, Steering Committee and PMO

**Suggested Timeframe:** Month 12–18 (2027-10-17 to 2028-04-17), if Phase 1 is cancelled

**Key Outputs/Deliverables:**

- Phase 0 Completion and Closure Report (gate failures documented, sunk costs reconciled, preserved assets inventoried)
- Land-option extension agreements (2–3 years, renewal strategy)
- Strategic-alternatives analysis (downsize to 250 MW, split-campus pivot, deferral, cancellation) with pros/cons and cost implications
- Sponsor decision and strategic-direction memo (if any path is chosen)
- Stakeholder communication (published closure report and strategic direction to lenders, co-investors, authorities, communities)

**Dependencies:**

- Phase 0 gates assessed at Month 12 (2027-10-17)
- Phase 1 FID is not approved

# Decision Escalation Matrix

**RTE Grid Hosting Capacity Threshold Breach**
Escalation Level: Gate Review and Kill Authority Committee
Approval Process: Monthly red-team assessment against numeric threshold (at least 500 MW within 36 months). If preliminary RTE letter not received by Month 6 (2027-04-17) or hosting capacity drops below 500 MW, committee issues formal gate-status report within 5 working days and recommends split-campus topology pivot or Phase 1 downsize. Recommendation binds the Steering Committee unless overridden by supermajority (sponsor, consortium, independent director) with published dissent to lenders.
Rationale: Grid hosting above ~1 GW is the primary kill condition and a critical uncontrolled external dependency. RTE's connection offer directly gates Phase 1 scale and topology choice. Breach of the 500 MW first-tranche threshold makes the project infeasible at planned MW or requires architectural redesign. Early escalation to an independent committee ensures sunk-cost pressure does not override this core feasibility test.
Negative Consequences: If grid hosting fails and Phase 1 proceeds anyway, the campus cannot energize on schedule (12+ month delay likely), carrying costs of EUR 200M–400M accumulate, and lenders may withdraw financing commitments. Loss of RTE queue position to competing industrial users may render the site permanently infeasible. Forced pivot to split-campus topology late in Phase 0 costs EUR 250M–500M in design rework and extends Phase 1 FID decision by 6–12 months.

**Anchor-Tenant Take-or-Pay Commitment Shortfall Below 30 Percent**
Escalation Level: Gate Review and Kill Authority Committee
Approval Process: Monthly red-team pipeline assessment compares binding lease term sheets (not letters of intent) against the 30% capacity threshold. At Month 9 (2027-07-17), if signed take-or-pay covers less than 300 MW (on 1 GW base) or 150 MW (on 500 MW base), committee issues formal gate-status report recommending Phase 1 downsizing to match actual committed demand or Phase 1 FID deferral pending tenant consolidation. Steering Committee decides within 5 working days; override requires supermajority with dissent disclosed to lenders.
Rationale: Credible anchor-tenant demand is the foundation for debt financing and Phase 1 FID approval. Binding commitments (not non-binding LOIs) prove tenant credit quality and workload certainty. A 30% minimum ensures sufficient revenue visibility for lenders to underwrite the project and protects equity from stranded capacity risk. Absence of committed anchors at the Month 9 (2027-07-17) deadline signals demand has not materialized and Phase 1 must be resized or deferred.
Negative Consequences: If Phase 1 proceeds without 30% signed take-or-pay, lenders refuse debt or demand higher spreads (+200–300 bps), raising annual debt service by EUR 140M–280M and eroding returns by 2–4 percentage points. Tenant pipeline failure often cascades: once lenders signal reluctance, other tenants become hesitant to commit, accelerating the shortfall. Phase 1 energization with <30% pre-leased capacity risks uncontrolled vacancy (100+ MW idle), revenue loss of EUR 50M–100M annually, and potential covenant breaches or tenant lease terminations.

**Land Assembly and Parcel Option Failure (Less Than 70 Percent Optioned)**
Escalation Level: Gate Review and Kill Authority Committee
Approval Process: Land-assembly feasibility assessments (Month 3 = 2027-01-17 and Month 4 = 2027-02-17 to 2027-02-17) measure the percentage of target parcel under non-coercive option at benchmark-aligned pricing. If at least 70% is not secured by Month 4 (2027-02-17) (proposed threshold), the committee recommends split-campus topology as the default, triggering detailed feasibility studies for 2–3 nodes. If split-campus node targets also fall short of 70–80%, committee escalates to the Steering Committee with a recommendation to downsize Phase 1 or cancel the project.
Rationale: Contiguous assembly of a large envelope tests feasibility; inability to secure land non-coercively signals market resistance or high displacement costs that undermine the social-license strategy. A 70% threshold is a credibility floor: below this level, holdout risk, legal challenge exposure, and relocation premium costs spike. The topology decision (single vs. split) depends on land-assembly success; escalation ensures the decision is not deferred.
Negative Consequences: Failure to assemble a contiguous parcel forces a costly late-phase pivot to split-campus topology (EUR 250M–500M capex rework, 6–12 month delay). Holdout negotiations and litigation can extend land acquisition by 12–24 months, eroding RTE queue position and permitting timelines. Elevated land-acquisition costs (paying holdouts 20–40% above market) reduce project margin by EUR 100M–300M. Forced reliance on compulsory acquisition (public-interest designation) invites political backlash and legal appeals extending land control by 24–36 months and cancelling Phase 1 risk.

**Permitting Delay or Legal Challenge Blocking Schedule**
Escalation Level: Compliance, Environmental & Social License Committee (escalates to Steering Committee if delay exceeds 6 months from target)
Approval Process: Compliance committee tracks permit-file submission (targeted Month 8–9 = 2027-06-17 to 2027-07-17) and authority decision timelines. Formal DREAL opinion due Month 9 (2027-07-17); permission filing timeline tracks decision target (18–30 months from filing = Months 26–39 = 2028-12-17 to 2030-01-17). If DREAL decision slips >6 months beyond target or a major legal challenge is filed, committee escalates to Steering Committee with revised Phase 1 timeline and cost implications. Steering Committee decides whether to defer Phase 1 FID pending permit clarity or proceed with contingent Phase 1 start date.
Rationale: Permitting delay erodes the RTE queue position and extends carrying costs on Phase 0 assets (EUR 200M–500M estimated). Standard ICPE timelines are 18–30 months; appeals add 24–48 months. Early escalation allows the Steering Committee to trigger contingency options (split-campus pivot, Phase 1 deferral, reduced scope) before sunk cost becomes irreversible. A 6-month slip is the threshold because it shifts first-block energization from target Months 42–48 (2030-04-17 to 2030-10-17) into Months 48–60 (2030-10-17 to 2031-10-17), materially affecting funding costs.
Negative Consequences: Unmanaged permit delay of 12–24 months directly delays Phase 1 start 12–24 months, extending carrying costs by EUR 200M–500M and pushing energization to Month 54–66 (2031-04-17 to 2032-04-17). Tenant commitments signed in Month 9 (2027-07-17) may lapse if Phase 1 cannot start by Month 36 (2029-10-17) as planned, forcing tenant re-negotiation or replacement. RTE queue position erodes if other users fill available transmission capacity during a permitting stall. Legal challenges to permits can force design rework, adding EUR 250M–1.5B capex and invalidating prior environmental assessments.

**ANSSI National-Security Review Blocks or Materially Restricts Foreign Co-Investor or Tenant Access**
Escalation Level: Steering Committee (with Gate Review and Kill Authority Committee advisory)
Approval Process: PMO Security and National-Security Lead conducts confidential pre-submission dialogue with ANSSI (Months 0–1 = 2026-10-17 to 2026-11-17). Informal opinion due Month 6 (2027-04-17); Month 12 (2027-10-17) written confirmation that formal review can start with no blocking concerns. If ANSSI signals a blocking concern (e.g., foreign co-investor capital must be capped or excluded, foreign tenants prohibited, mandatory state observer roles, extended review timeline >18 months), the Steering Committee convenes within 5 working days to reassess the financing and tenant strategy. Committee votes on restructuring (e.g., reduce foreign equity, pivot to sovereign-only anchors, accept state oversight) or defer Phase 1 pending ANSSI clarity.
Rationale: National-security review outcome is uncontrolled until ANSSI formally clears the project. Foreign co-investors and hyperscaler tenants trigger heightened scrutiny; restrictions on either can materially alter the financing structure and tenant pool. Early escalation to Steering Committee ensures governance and financing decisions are not locked in before security constraints are known. ANSSI findings that constrain tenants or co-investors affect Phase 1 FID viability and must trigger strategic recalibration.
Negative Consequences: If ANSSI blocks foreign co-investor equity, the project loses EUR 1B–3B of consortium backing, forcing a 6–12 month equity restructuring and raising cost of capital by 200–300 bps (EUR 140M–280M extra annual interest). If foreign hyperscaler tenants are prohibited, the addressable customer pool shrinks to EU and sovereign users only, reducing anchor-tenant demand and forcing Phase 1 downsize to 250–500 MW. ANSSI review delays of 12+ months beyond Month 12 (2027-10-17) deadline push Phase 1 FID to Month 24–30 (2028-10-17 to 2029-04-17), extending Phase 0 and eroding tenant and lender commitments.

**Debt Financing Unavailable or Below EUR 3 Billion Commitment at Acceptable Terms**
Escalation Level: Gate Review and Kill Authority Committee (escalates to Steering Committee for Phase 1 FID decision)
Approval Process: PMO Finance Lead engages lenders (Month 2–3 = 2026-12-17 to 2027-01-17) to establish debt-capacity and gate criteria. Non-binding term sheet targeted Month 9 (2027-07-17); final commitment due Month 12 (2027-10-17). If lenders offer less than EUR 3B or impose unacceptable terms (spreads >300 bps, covenant DSCR >1.40x, equity cushion >40%), Kill Authority Committee issues formal report recommending Phase 1 downsizing to 250 MW (EUR 2.5B capex, 50% debt = EUR 1.25B) or Phase 1 deferral pending equity restructuring. Steering Committee votes on downsizing, deferral or override.
Rationale: Debt financing is a gate precondition for Phase 1 FID. Lenders require specific evidence: firm RTE connection offer, signed tenant take-or-pay, bounded environmental liability, firm power contract. Absence of debt at acceptable cost means equity must fund EUR 4B–5B out of EUR 5B–10B capex, far above the proposed 40% equity cap. Early escalation to Kill Authority Committee ensures financing reality is assessed before the Steering Committee votes on Phase 1 FID. Unacceptable debt terms signal market skepticism and require Phase 1 resizing.
Negative Consequences: Debt financing failure forces Phase 1 downsize from 1 GW to 500 MW (losing EUR 2.5B–5B revenue growth), or Phase 1 deferral 6–12 months pending equity restructuring. If equity raises EUR 4B–5B instead of EUR 2B–4B, returns compress by 3–5 percentage points (IRR falls from 10–12% target to 5–7%), eroding co-investor appetite and extending equity close by 6–12 months. Inability to close debt in Month 12–13 (2027-10-17 to 2027-11-17) window pushes Phase 1 FID to Month 18–24 (2028-04-17 to 2028-10-17), causing tenant and lender commitments to expire and requiring costly re-engagement.

**Sunk-Cost Pressure on Investment Committee to Override Kill Criteria**
Escalation Level: Project Steering Committee (with Gate Review and Kill Authority Committee oversight and published dissent)
Approval Process: Investment Committee Charter (Month 1 = 2026-11-17) establishes veto authority and numeric kill thresholds. At Month 12 (2027-10-17) Phase 0 gate, if one or more thresholds are unmet but the Steering Committee pressures a Phase 1 FID approval, the Gate Review and Kill Authority Committee documents formal dissent and publishes it to lenders and co-investors within 2 working days. Lenders have 10 working days to invoke debt covenants or capital-call conditions; co-investors may demand governance restructuring or capital-return options. Escalation ensures sunk cost (EUR 250M–750M Phase 0) does not override stated kill criteria.
Rationale: Stated kill criteria (grid >1 GW, land 70%, tenants 30%, debt EUR 3B, social license 2 municipalities) only constrain behavior if someone with no stake in continuing can enforce them. Without independent authority and transparency, sunk-cost momentum routinely overrides gates. An independent committee with veto power and published dissent makes override decisions visible to debt and equity sources, creating accountability. Published dissent also protects individual committee members from blame if Phase 1 later fails due to unmet gate criteria.
Negative Consequences: If kill criteria are overridden and Phase 1 proceeds despite unmet thresholds, the project enters Phase 1 with known feasibility gaps (e.g., no firm RTE offer, <30% tenant demand, no debt financing). Phase 1 construction delays, cost overruns and potential cancellation are likely, stranding EUR 5B–10B capex and destroying equity value. Lenders who discover override decisions after the fact may invoke cross-default clauses or accelerate debt, forcing emergency equity rescue or insolvency. Co-investors may sue the developer for breach of governance, demanding return of capital or loss compensation.

**Unexpected Brownfield Contamination or Remediation Cost Exceeding Bounded Estimate (>EUR 100 Million Per Site)**
Escalation Level: Compliance, Environmental & Social License Committee (escalates to Steering Committee and Kill Authority Committee if exceeding Phase 0 budget or Phase 1 contingency)
Approval Process: Phase I desktop assessments completed Month 1 (2026-11-17); Phase II intrusive surveys Month 3 (2027-01-17) identify contamination and bound remediation to EUR 0–100M per site (proposed threshold). If Phase II findings show remediation exceeding EUR 100M for a primary site, committee escalates immediately with a site-exclusion recommendation or a renegotiation strategy with the landowner/public remediation body. If cumulative remediation across shortlisted sites exceeds the Phase 0 reserve (EUR 100M–300M estimate), the committee recommends parcel substitution or Phase 1 contingency drawdown authorization from the Steering Committee.
Rationale: Brownfield contamination is the least quantifiable Phase 0 cost and carries lender and equity risk if discovered late in Phase 1. Bounding liability in Phase 0 via intrusive surveys and seller indemnities protects the project from cost escalation and schedule slippage during Phase 1. A EUR 100M per-site ceiling is realistic for legacy industrial contamination; above this, remediation becomes a project-level feasibility constraint and justifies site substitution or downsize.
Negative Consequences: Contamination discovery during Phase 1 construction triggers health-and-safety work stoppages, regulatory enforcement, and unbudgeted remediation of EUR 100M–400M+. Cost overrun forces Phase 1 capex to exceed the EUR 10B ceiling, triggering debt-covenant breaches or equity restructuring. Schedule delay from remediation (6–18 months) erodes RTE queue timing and extends carrying costs by EUR 200M–500M. Liability disputes between the developer and landowner/public authority can tie up capital in escrow or litigation for 2–4 years, starving Phase 1 construction of cash flow.

**Municipal or Community Opposition Blocks Permits or Forces Unacceptable Design Compromises**
Escalation Level: Compliance, Environmental & Social License Committee (escalates to Steering Committee if support from 2 of 3 municipalities not obtained by Month 12 = 2027-10-17)
Approval Process: Community and Stakeholder Lead establishes municipal liaison committee (Month 2 = 2026-12-17) and conducts early public consultation (Month 3 = 2027-01-17, 4-week feedback). Draft community-benefit agreement (EUR 50M–150M Phase 1–2 estimate) negotiated by Month 6 (2027-04-17). Written support from at least 2 of 3 most-affected municipalities targeted by Month 12 (2027-10-17). If opposition escalates to formal municipal refusal or organized legal challenge by Month 6 (2027-04-17), committee immediately escalates to Steering Committee with revised feasibility and cost-impact assessment. Committee recommends split-campus pivot (site substitution), Phase 1 scope reduction or project deferral.
Rationale: Social license from municipalities and communities is a gate condition for permitting viability. Organized opposition can sustain legal appeals extending permitting by 24–48 months, eroding feasibility. Early, transparent engagement with municipalities and structured community-benefit agreements reduce opposition risk and build political support. Escalation of opposition at Month 6 (2027-04-17) halfway through Phase 0 allows the Steering Committee to trigger topology or scope changes before permitting investment is committed.
Negative Consequences: Sustained municipal opposition or formal refusal can block permits indefinitely, rendering a chosen site infeasible. Forced pivot to alternative site mid-Phase 0 triggers EUR 100M–250M additional Phase 0 spend on surveys and permitting preparation. Legal appeals to permits can extend authorization timelines by 24–48 months, pushing Phase 1 energization from target Months 42–48 (2030-04-17 to 2030-10-17) to Months 66–84 (2032-04-17 to 2033-10-17), outside the project's feasibility window. Unacceptable design compromises (reduced hall density, ecological setbacks, farmland compensation) force capex escalation of EUR 500M–1.5B or capacity reduction of 20–30%.

# Monitoring Progress

### 1. Gate Criterion Status Tracking and Numeric Threshold Validation
**Monitoring Tools/Platforms:**

  - Gate Review and Kill Authority Committee monthly pass/fail reports
  - External red-team assessment dashboard (grid, land, tenants, financing, social license)
  - Phase 0 milestone tracking spreadsheet (gate deadlines, evidence receipt dates)
  - RTE hosting-capacity audit and preliminary letter repository

**Frequency:** Monthly (Months 0–12 = 2026-10-17 to 2027-10-17), formal gate assessment Months 3, 6, 9, 12 (2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17)

**Responsible Role:** Gate Review and Kill Authority Committee (Independent Chair, independent external directors, with External Red Team providing pass/fail opinions); escalates to Project Steering Committee if threshold breach occurs

**Adaptation Process:** Monthly red-team reports assess each of five gate criteria (grid hosting ≥1 GW cumulative, land ≥70% optioned, tenants ≥30% signed, debt ≥EUR 3B, social license ≥2 municipalities) against published numeric thresholds. If any criterion shows High-likelihood breach, the committee issues a formal gate-status report within 5 working days to the Steering Committee and recommends one of: (i) Phase 1 FID approval (all thresholds met), (ii) conditional approval pending resolution, (iii) Phase 1 downsizing (e.g., 250 MW if tenants <30%), (iv) Phase 1 deferral, or (v) project exit. The Steering Committee votes within 5 working days; approval requires two-of-three alignment (sponsor, consortium, independent director). Override of the Kill Authority Committee's recommendation triggers mandatory dissent disclosure to lenders and co-investors within 2 working days.

**Adaptation Trigger:** Specific numeric breaches at defined deadlines: (i) RTE preliminary feasibility letter not received or hosting capacity <500 MW by Month 6 (2027-04-17); (ii) <70% of chosen parcel optioned non-coercively at <15% above benchmark by Month 4 (2027-02-17); (iii) <30% signed anchor-tenant take-or-pay by Month 9 (2027-07-17); (iv) debt commitment <EUR 3B or unacceptable terms by Month 12 (2027-10-17); (v) <2 of 3 municipalities' written support by Month 12 (2027-10-17). Any single breach triggers formal escalation; multiple breaches may recommend Phase 1 cancellation or major restructuring.

### 2. Grid Hosting Capacity and RTE Connection Engagement Tracking
**Monitoring Tools/Platforms:**

  - RTE pre-submission dialogue log (letters, meeting minutes, submitted requests)
  - Independent RTE hosting-capacity audit report (Month 9 = 2027-07-17 deliverable)
  - Grid reinforcement cost-estimate tracker (phase reinforcement, substation siting, timeline impact)
  - Connection-offer timeline and queue-position monitoring spreadsheet

**Frequency:** Bi-weekly PMO Grid and Power Lead + RTE liaison; monthly summary to Steering Committee; formal RTE letter or written evidence due Month 6 (2027-04-17); audit published Month 9 (2027-07-17)

**Responsible Role:** PMO Grid and Power Lead, with Independent RTE Hosting-Capacity Auditor, RTE liaison counsel; reports to Gate Review Committee monthly and Steering Committee quarterly

**Adaptation Process:** Grid hosting capacity findings feed directly into topology decision (Month 4 = 2027-02-17): single square only if RTE written evidence confirms ≥1 GW to that node; otherwise split-campus default. If RTE's preliminary letter (due Month 6 = 2027-04-17) shows hosting below 500 MW, the Kill Authority Committee recommends split-campus topology pivot or Phase 1 capacity downsize to 250 MW. If RTE offers favorable tranche-based terms (500 MW + 1 GW pathway), power-procurement strategy (EDF negotiations) and tenant-acquisition targets are confirmed as achievable; if terms are restrictive (>15% curtailment, extended connection timelines), lease pricing and BESS strategy are adjusted. If transmission-reinforcement cost-share exceeds budget (EUR 1.5B threshold), the Steering Committee decides whether to accept the cost as Phase 1 capex or request RTE cost-share under a co-development agreement.

**Adaptation Trigger:** RTE preliminary feasibility letter not received or capacity <500 MW by Month 6 (2027-04-17) → kill criterion breached, recommend split-campus or downsize. RTE timeline slips >6 months beyond Month 6 (2027-04-17) → Steering Committee reassesses Phase 0 and Phase 1 schedule, triggers deferral or topology re-evaluation. Transmission reinforcement cost >EUR 1.5B or timeline >48 months (2030-10-17) → cost-share negotiation or Phase 1 capacity reduction. Curtailment requirement >15% annual → walk-away trigger per power-strategy framework, Phase 1 reduced to 500–750 MW or less.

### 3. Land Assembly and Parcel Acquisition Feasibility Validation
**Monitoring Tools/Platforms:**

  - Parcel-by-parcel land survey and ownership-chain map (Phase 0 Month 3 = 2027-01-17 deliverable)
  - Option agreement tracking spreadsheet (% parcels optioned, expiry dates, holdout locations)
  - Phase I and Phase II environmental site assessment reports (contamination findings, remediation-cost bounds)
  - Land-assembly feasibility assessment report (Month 3 = 2027-01-17 and Month 4 = 2027-02-17 and 2027-02-17 decisions)

**Frequency:** Monthly land-assembly lead updates to PMO; formal feasibility assessments Month 3 (2027-01-17) and Month 4 (2027-02-17); Phase II ESA findings by Month 3 (2027-01-17); topology decision locked Month 4 (2027-02-17)

**Responsible Role:** PMO Land Assembly Lead (with real-estate counsel), supported by Phase II ESA survey teams and municipal land-registry liaisons; escalates to PMO and Steering Committee if >30% of target parcel cannot be optioned or remediation exceeds EUR 100M per site

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17) land survey ranks candidate sites by assemblability, holdout risk and land cost. By Month 3 (2027-01-17), if ≥70% of the single-square parcel is optioned non-coercively at <15% above benchmark, the single square remains viable and Phase I ESA focuses on that core. If single-square assemblability falls short of 70%, split-campus topology is developed as the default: Cambrai ~500 MW node validated at ≥80% optioned, Dunkirk ~250 MW, Valenciennes ~250 MW each assessed separately. Phase II contamination findings (Month 3 = 2027-01-17) rule out sites with remediation >EUR 100M (propose bounding); shortlisted parcels have seller indemnity or public-remediation-body liability assumption negotiated. If holdout clusters (e.g., families refusing to relocate) block >20% of a primary site, the parcel is substituted or the node capacity is reduced. If Phase II finds unexpected contamination during Phase 1 construction, remediation costs exceeding the Phase 1 contingency (EUR 100M–300M) trigger debt-covenant escalation.

**Adaptation Trigger:** <70% of single-square parcel optioned or remediation >EUR 100M per site by Month 4 (2027-02-17) → split-campus topology forced, Phase 0 extended 3–6 months, Phase 0 spend escalates to EUR 750M. >20% of target parcel blocked by holdouts → parcel substitution or node-capacity downsize. Phase II contamination discovery after Phase 0 gate (Phase 1 construction) exceeding contingency → litigation risk, remediation delay 6–18 months, carrying cost EUR 200M–500M, Phase 1 FID contingent on revised liability allocation.

### 4. Anchor-Tenant Demand and Take-or-Pay Acquisition Tracking
**Monitoring Tools/Platforms:**

  - Tenant pipeline dashboard (LOI vs. binding term sheet status, credit validation, reservation-fee receipts)
  - Take-or-pay lease term sheets and capacity reservations log (signed agreements, MW reserved, tenor, price)
  - Tenant workload and cluster-size specifications (used to validate latency tolerance for split-campus architecture)
  - Reservation-fee payment tracking (EUR 10M–50M per 100 MW, crediting against future rent)

**Frequency:** Bi-weekly tenant sourcing updates; monthly pipeline status to PMO and Steering Committee; formal binding term-sheet deadline Month 9 (2027-07-17); reservation-fee payment confirmation by Month 12 (2027-10-17)

**Responsible Role:** PMO Tenancy and Revenue Lead (with commercial advisers and legal counsel); escalates to Gate Review Committee if signed take-or-pay falls below 30% of Phase 1 target by Month 9 (2027-07-17)

**Adaptation Process:** Tenant sourcing targets 2–3 global hyperscalers (A−/A+ credit) and 2–3 sovereign/European anchors (sovereign guarantee or A−/BBB+ parent) in parallel. Non-binding LOIs collected Month 3–6 (2027-01-17 to 2027-04-17) are tracked for engagement momentum but not counted toward the 30% gate criterion. Binding term sheets (5–10 year lease, capacity reserved, reservation fee EUR 10M–50M per 100 MW paid upfront) are required by Month 9 (2027-07-17); only signed agreements count. If signed take-or-pay reaches only 20% of Phase 1 (200 MW on 1 GW base) by Month 9 (2027-07-17), the Kill Authority Committee recommends Phase 1 downsize to 250–500 MW matching actual committed demand, extending Phase 1 FID to Month 18–24 (2028-04-17 to 2028-10-17) pending demand maturation. Lease price (EUR 1.1M per MW-year, non-energy) and SLA terms (99.5% uptime, curtailment carve-out to 10% annual) are confirmed in term sheets; pass-through energy indexation anchors tenants to realized EUR/MWh cost. If a committed anchor tenant requests a 10% price discount (e.g., to offset perceived curtailment risk), debt service coverage falls from 1.34x to 1.15x, requiring equity cure or debt reduction (proposed structural adaptation: negotiate curtailment exclusion rather than price discount).

**Adaptation Trigger:** <30% signed take-or-pay (i.e., <150 MW on 500 MW base, <300 MW on 1 GW base) by Month 9 (2027-07-17) → Phase 1 downsize to 250–500 MW or Phase 1 FID deferral 6–12 months. >20% anchor-tenant lease-price-discount requests → DSCR <1.30x, triggers debt restructuring or Phase 1 downsize. Any anchor-tenant non-renewal or early-termination signal during Phase 1 construction → revenue risk flagged, replacement-tenant sourcing accelerated, potential phase-advance slippage if replacement not secured within 6 months.

### 5. Power Procurement and EDF Supply Contract Negotiation Tracking
**Monitoring Tools/Platforms:**

  - EDF engagement log and LOI/term-sheet tracker (non-binding LOI by Month 6 = 2027-04-17, term sheet by Month 9 = 2027-07-17)
  - Power-market study and EUR/MWh pricing forecast (assumed EUR 50–70/MWh range, stress test at +EUR 30/MWh)
  - BESS and demand-flexibility feasibility assessment (50–200 MWh, cost estimate, grid-interaction modeling)
  - Energy cost pass-through agreement templates and pricing-indexation schedule (annual CPI+X% formula)

**Frequency:** Monthly Grid and Power Lead updates to PMO; EDF LOI due Month 6 (2027-04-17); term sheet and pricing locked Month 9 (2027-07-17); binding contract not before Phase 1 FID (Month 12 = 2027-10-17 conditional)

**Responsible Role:** PMO Grid and Power Lead (with independent power-market adviser, EDF liaison); escalates to Steering Committee if EDF terms are unavailable or pricing exceeds EUR 100/MWh (proposed stress threshold)

**Adaptation Process:** Weeks 1–8 of Phase 0 (Months 0–1 = 2026-10-17 to 2026-11-17), PMO initiates EDF negotiations for a non-binding letter of intent confirming willingness to discuss 500 MW+ baseload at a capped price range. By Month 6 (2027-04-17), EDF LOI targets ≥500 MW, ≥10-year tenor, price EUR 50–70/MWh (assumed, not verified). Phase 0 power-market study models energy cost impact: if delivered cost rises above EUR 70/MWh (e.g., EUR 80–100 due to policy shifts or grid constraints), NOI per MW falls from EUR 800k to EUR 600k (500 MW case), DSCR drops below 1.30x lender minimum, triggering either (i) lease price escalation (EUR 1.1M → EUR 1.2M+/MW-year), (ii) debt reduction from EUR 3B to EUR 2.5B (60% → 50% leverage), or (iii) Phase 2 expansion deferral. By Month 9 (2027-07-17), a detailed term sheet from EDF confirms capacity, price, tenor, curtailment/flexibility obligations and indexation formula (proposed: CPI + 50 bps indexed annually). Energy risk is passed through to tenants via indexed lease pass-through, so developer carries no volume risk beyond grid curtailment. BESS (50–200 MWh, cost EUR 20M–80M estimate) is evaluated for arbitrage value and grid-stress mitigation; if BESS ROI is positive (>5% IRR), it is funded from Phase 1 capex; otherwise optional and tenant-funded.

**Adaptation Trigger:** EDF LOI not received or pricing >EUR 100/MWh by Month 6 (2027-04-17) → power-gate criterion at risk, Steering Committee considers Phase 1 downsize or delay pending EDF clarity. EDF term-sheet pricing ≥EUR 80/MWh and non-indexable (fixed contract) → debt capacity drops EUR 500M–1B, equity raises required, Phase 1 FID contingent on restructured lease pricing or equity injection. Competing industrial-load requests to EDF saturate capacity <500 MW available → topology must pivot to split-campus with smaller per-node power contracts, or Phase 1 downsize to 250 MW.

### 6. Permitting and Environmental Authorization Timeline and Compliance Tracking
**Monitoring Tools/Platforms:**

  - ICPE and environmental-authorization permit-file roadmap and completion tracker (expert reports due, DREAL feedback incorporation)
  - Permit-file submission checklist and filing-date confirmation (targeted Month 8–9 = 2027-06-17 to 2027-07-17)
  - DREAL screening opinion request and timeline tracker (opinion due Month 9 = 2027-07-17)
  - Legal-challenge and appeal escalation log (none expected in Phase 0; Phase 1 monitoring plan established)

**Frequency:** Monthly Permitting and Environmental Lead updates; permit-file roadmap completed by Month 2 (2026-12-17); DREAL opinion due Month 9 (2027-07-17); permit-check gate at Month 18 (2028-04-17) assessing compliance with decision timeline

**Responsible Role:** Compliance, Environmental & Social License Committee (Permitting and Environmental Lead), with environmental and ICPE counsel; escalates to Steering Committee if DREAL timeline slips >6 months or new scope requirements emerge

**Adaptation Process:** Phase 0 Month 1–2 (2026-11-17 to 2026-12-17): permit-file roadmap is finalized specifying required components (ecological baseline, hydrological assessment, contamination survey, thermal modeling, security specs, community-benefit commitments). Phase I desktop ESAs and hydrological study are completed Month 1–3 (2026-11-17 to 2027-01-17); Phase II intrusive surveys (if triggered) are closed Month 3 (2027-01-17) with remediation-liability findings incorporated into permit file. Ecological master plan (completed Month 6 = 2027-04-17) provides EIA avoidance-reduction-compensation strategy. Community-benefit agreement (signed Month 6 = 2027-04-17) is appended to show local support. Permit file (single file for single-square topology, one file per node for split-campus) is submitted Month 8–9 (2027-06-17 to 2027-07-17); filing date is confirmed and tracked. DREAL screening opinion (due Month 9 = 2027-07-17) confirms EIA requirements and ICPE classification. If DREAL requires additional studies or wider EIA scope, permit-file completion date shifts from Month 9 (2027-07-17) to Month 12 (2027-10-17) and decision timeline extends from target Months 26–39 (2028-12-17 to 2030-01-17) to Months 39–52 (2030-01-17 to 2031-04-17), pushing Phase 1 energization to Month 54+ (2031-04-17+) and eroding Phase 1 schedule. Permit-check gate at Month 18 (2028-04-17): if no decision is in sight (authority response pending, legal challenge filed), Phase 1 FID becomes contingent on permit pathway clarity.

**Adaptation Trigger:** DREAL opinion not received or requires expanded EIA scope by Month 9 (2027-07-17) → permit timeline extends beyond target, Phase 1 decision deferred. Legal challenge to permit filed by Month 18 (2028-04-17) → appeal timeline adds 12–36 months, Phase 1 energization shifts Months 54–66 (2031-04-17 to 2032-04-17)+ (2031-04-17 to 2032-04-17+). Permit-file roadmap additions cost >EUR 20M or extend timeline >3 months → Steering Committee informed, Phase 0 tranche 4 (EUR 150M final allocation) decision may defer permitting accelerants or design refinements. ICPE classification changes to more restrictive category → Phase 1 capex +EUR 100M–300M for additional mitigation, or Phase 1 downsize if mitigation cost is unacceptable.

### 7. National Security Review and ANSSI Clearance Pathway Tracking
**Monitoring Tools/Platforms:**

  - ANSSI pre-submission confidential security governance white paper (submitted Month 1 = 2026-11-17)
  - ANSSI preliminary opinion request and timeline tracker (due Month 6 = 2027-04-17, uncontrolled)
  - Security-design framework and compliance checklist (cyber-OT separation, anti-drone systems, personnel vetting, supply-chain assurance)
  - ANSSI formal-review start confirmation (targeted Month 13 = 2027-11-17, clearance Month 25–31 = 2028-11-17 to 2029-05-17)

**Frequency:** Monthly Security and National-Security Lead updates to PMO; pre-submission dialogue ongoing Months 0–1 (2026-10-17 to 2026-11-17); informal ANSSI opinion due Month 6 (2027-04-17); formal review start confirmation by Month 12 (2027-10-17)

**Responsible Role:** PMO Security and National-Security Lead (with security and GDPR counsel, ANSSI liaison); escalates to Steering Committee immediately if ANSSI signals blocking concerns (foreign co-investor cap, tenant-access restrictions, data-residency mandates)

**Adaptation Process:** Phase 0 Month 0–1 (2026-10-17 to 2026-11-17): confidential pre-submission engagement with ANSSI and DGSI outlines project scope, tenant strategy (hyperscalers, sovereign AI users), foreign co-investor governance, data-residency policy, and security posture (perimeter hardening, cyber-OT separation, personnel vetting). ANSSI informal opinion due Month 6 (2027-04-17) indicates anticipated review scope, timeline and any early blocking concerns (e.g., 'foreign equity above X% is not permissible', 'non-EU tenants restricted to non-sovereign workloads'). If no blocking concerns are signaled, security gate is on track: formal ANSSI review starts Month 13 (2027-11-17, post-FID), clearance targeted Month 25–31 (2028-11-17 to 2029-05-17). If ANSSI signals blocking concerns (e.g., foreign co-investor must be limited to ≤20% equity, non-EU hyperscalers cannot access sovereign partitions), the Steering Committee convenes within 5 working days to reassess financing (consortium co-investor may need replacement) and tenant strategy (hyperscaler pool may contract). A revised security governance framework is negotiated with ANSSI; clearance pathway and timeline may extend. If ANSSI indicates formal review will take >18 months (beyond Month 31 = 2029-05-17), Phase 1 FID is contingent on ANSSI confirmation that clearance will be complete by Month 42 (2030-04-17, energization start date) or Phase 1 energization is delayed.

**Adaptation Trigger:** ANSSI preliminary opinion signals blocking concern (foreign co-investor cap, tenant-access restriction, data-residency mandate) by Month 6 (2027-04-17) → Steering Committee reassesses within 5 working days, may trigger financing or tenant-strategy pivot. ANSSI indicates formal-review timeline >18 months (projected clearance beyond Month 31 = 2029-05-17) by Month 12 (2027-10-17) → Phase 1 FID contingent on security-review completion by Month 42 (2030-04-17) or Phase 1 energization delayed 6–12 months. ANSSI issues final clearance restrictions on tenants or co-investor control → governance restructuring required post-FID, Phase 1 capex for security hardening may increase EUR 50M–200M if additional restrictions require design changes.

### 8. Community Engagement, Social License and Municipal Support Validation
**Monitoring Tools/Platforms:**

  - Municipal liaison committee meeting minutes (published, ongoing monthly Months 2–12 = 2026-12-17 to 2027-10-17)
  - Public consultation feedback summary and project response log (4-week comment period, feedback integrated by Month 5 = 2027-03-17)
  - Community-benefit agreement draft and final signatures (signed by Month 6 = 2027-04-17, covers labor, training, ecology, farm-sector support, municipal infrastructure)
  - Opposition escalation tracker (NGO legal challenge risk, farm-union organized action, municipal formal objection log)

**Frequency:** Monthly municipal liaison committee meetings (published minutes); public consultation launched Month 3 (2027-01-17), feedback closed Month 4 (2027-02-17), response published Month 5 (2027-03-17); written municipal support tracked through Month 12 (2027-10-17); legal-challenge monitoring ongoing

**Responsible Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead), with municipal and farm-sector liaisons; escalates to Steering Committee if organized opposition or formal municipal refusal emerges by Month 6 (2027-04-17)

**Adaptation Process:** Phase 0 Month 1–2 (2026-11-17 to 2026-12-17): municipal liaison committee is established with representatives from ≥3 most-affected municipalities; monthly dialogue is scheduled, meeting agendas and minutes are published. Month 3 (2027-01-17): public consultation is launched with transparent project overview, siting rationale, technical specs (power, cooling, footprint), environmental/social-impact scope, and 4-week comment period. Month 4–5 (2027-02-17 to 2027-03-17): feedback is compiled, project responses are drafted and published. Months 2–6 (2026-12-17 to 2027-04-17): community-benefit agreement is negotiated with municipalities, farm unions (FNSEA, Confédération Paysanne) and environmental NGOs, addressing labor/training targets (regional academy, local hiring), ecological restoration (EUR 50M–150M Phase 1–2 estimate), farm-sector support (displacement compensation, land-swap schemes, revenue-sharing on continuation zones), and municipal infrastructure upgrades. By Month 6 (2027-04-17), draft agreement is signed or a binding term sheet is in place; EUR 50M–150M Phase 1–2 commitment is contingent on permits (not Phase 0 spend). Month 9 (2027-07-17): written support letters are requested from at least 2 of 3 most-affected municipalities, indicating municipal endorsement of the project (non-binding but political signal). Month 12 (2027-10-17): formal written support (municipal council resolution or mayor letter) from ≥2 municipalities is confirmed as the social-license gate criterion. If organized opposition emerges (farm-sector legal action, environmental NGO challenge, mayor public refusal) by Month 6 (2027-04-17), the Steering Committee is informed within 5 working days and assesses whether to pivot topology (substitute site), reduce phase scope or defer permitting and land assembly.

**Adaptation Trigger:** Organized opposition or major legal challenge filed by a farm union or NGO by Month 6 (2027-04-17) → Steering Committee reassesses Phase 0, may trigger topology pivot or Phase 1 defer. Formal municipal refusal (mayor or council resolution against the project) in ≥2 of 3 target municipalities by Month 9 (2027-07-17) → social-license gate fails, Phase 1 FID cannot proceed, project deferral or site substitution required. Written municipal support from <2 municipalities by Month 12 (2027-10-17) → social-license gate criterion unmet, Phase 1 FID recommendation is 'conditional on achieving 2 municipal letters within 6 months' or 'project deferred'. Any municipal request for unacceptable design compromises (e.g., reduce capacity 30%, relocate all halls outside municipality) → cost escalation EUR 250M–1.5B, triggers Steering Committee scope-trade decision.

### 9. Phase 1 Debt Financing Credibility and Lender Engagement Tracking
**Monitoring Tools/Platforms:**

  - Lender outreach and engagement log (EIB, KfW, French banks, infrastructure funds, Month 2–9 = 2026-12-17 to 2027-07-17)
  - Debt-financing term sheet and non-binding LOI tracker (due Month 9 = 2027-07-17, with gate-success conditions specified)
  - Financial model and debt-service coverage sensitivity spreadsheet (DSCR base case 1.34x, stress case 1.15x)
  - Lender covenant and gate-trigger documentation (debt covenants tied to RTE, tenant, permitting gate achievements)

**Frequency:** Monthly PMO Finance Lead updates; lender outreach Month 2–3 (2026-12-17 to 2027-01-17), preliminary feedback Month 6 (2027-04-17), non-binding term sheet Month 9 (2027-07-17), lender final-commitment decision contingent on all Phase 0 gates Month 12–13 (2027-10-17 to 2027-11-17)

**Responsible Role:** PMO Finance and Lender Relations Lead (with infrastructure finance counsel and arranger); escalates to Kill Authority Committee if debt commitment <EUR 3B or terms (spread >300 bps, DSCR covenant >1.40x) are unacceptable

**Adaptation Process:** Phase 0 Month 2–3 (2026-12-17 to 2027-01-17): PMO Finance Lead engages prospective lenders (EIB, KfW, French banks, infrastructure funds) to present the Phase 0 gating framework and to understand debt-capacity and term-sheet conditions. Lender feedback (Month 6 = 2027-04-17) typically requires: (i) RTE firm connection offer, (ii) signed tenant take-or-pay for ≥30% of capacity, (iii) bounded environmental liability, (iv) firm power-supply contract or LOI, (v) DSCR >1.30x on stabilized assumptions. A preliminary financial model is developed (Month 4 = 2027-02-17) modeling 500 MW (EUR 5B capex, 60% debt = EUR 3B, annual debt service EUR 299M) and stress cases (tenure reduction, lease-price discount, cost overrun). Non-binding lender term sheet due Month 9 (2027-07-17) confirms debt capacity (EUR 3B–3.5B for 500 MW), tenor (12–15 years), pricing (benchmark + 200 bps estimate), and gate conditions for final commitment. If lenders signal debt <EUR 3B (capacity constraint) or spreads >300 bps (cost of capital increase), the Kill Authority Committee flags a financing-gate breach and recommends Phase 1 downsize to 250 MW (EUR 2.5B capex, EUR 1.5B debt) or Phase 1 FID deferral pending equity restructuring. Phase 1 FID approval (Month 12 = 2027-10-17) triggers final debt-commitment close (Month 13–18 = 2027-11-17 to 2028-04-17), with lenders requiring confirmations of all Phase 0 gates and post-FID financial close conditions (tenant lease executions, RTE connection agreement, power-supply contract, environmental permits on track).

**Adaptation Trigger:** Lender feedback (Month 6 = 2027-04-17) indicates debt capacity <EUR 3B for 500 MW → Phase 1 downsize to 250 MW or Phase 1 defer 6–12 months. Lender spreads >300 bps (raised cost of capital 2–3 pcts annually) → project economics erode, IRR falls 1–2 percentage points, Phase 1 FID contingent on equity injection or lease price escalation. Lender term sheet (Month 9 = 2027-07-17) gates final commitment on Phase 0 gate achievements not met by Month 12 (2027-10-17) (e.g., RTE letter missing, tenants <30%, ANSSI blocking) → lender commitment is void, debt unavailable, Phase 1 FID fails, project exits or defers pending gate resolution.

### 10. Water Resource Feasibility and Cooling Design Validation
**Monitoring Tools/Platforms:**

  - Hydrological and water-stress assessment study (completed Month 4 = 2027-02-17, estimate)
  - Regional water-authority consultation and preliminary opinion (due Month 6 = 2027-04-17)
  - Dry-cooler thermal-design-day modelling at 35°C ambient (PUE sensitivity, peak grid load impact)
  - Water-permitting pathway documentation (closed-loop cooling confirmed feasible, zero evaporative-water rule validated)

**Frequency:** Monthly water-resources management by Compliance committee; hydrology study due Month 4 (2027-02-17); water-authority opinion due Month 6 (2027-04-17); thermal modelling integrated into design reviews by Month 6 (2027-04-17); ongoing monitoring through Phase 1 permitting

**Responsible Role:** Compliance, Environmental & Social License Committee (Water Resources Manager), with hydrologist and water-law counsel; escalates to Steering Committee if water authority denies closed-loop feasibility or imposes restrictive abstraction limits

**Adaptation Process:** Phase 0 Month 1–4 (2026-11-17 to 2027-02-17): hydrological study assesses regional water stress (drought frequency and severity), competing water users (agricultural, municipal, industrial), and dry-cooler performance at extreme ambient temperatures (35°C design day). Modeling projects PUE under hot-weather scenarios (base case 1.15–1.25, hot-weather stress 1.35–1.5) and electrical load impact (peak load increase 5–15% during summer stress events). Month 3–4 (2027-01-17 to 2027-02-17): regional water authority (Agence de l'Eau Artois-Picardie) is formally consulted on closed-loop direct-to-chip cooling feasibility, water-abstraction impacts (none expected, zero freshwater withdrawal), and any permits required (stormwater management, groundwater protection). By Month 6 (2027-04-17), water authority provides written preliminary opinion confirming closed-loop cooling is permissible and no water-abstraction permits are required beyond standard stormwater authorization. If water authority raises concerns (drought vulnerability, groundwater interaction, competing demand), design review is triggered: options include hybrid cooling with limited evaporative water (risky in permitting), BESS expansion to reduce summer peak load, or capacity reduction. Thermal-design-day modeling validates PUE <1.30 at 35°C; if modelling shows PUE >1.30, design cost escalates (EUR 200M–500M for enhanced cooling or campus downsizing 20–30%) or grid peak-load impact triggers RTE curtailment negotiations.

**Adaptation Trigger:** Water authority opinion (Month 6 = 2027-04-17) denies closed-loop cooling feasibility or imposes water-abstraction restrictions → design review triggered, hybrid cooling option evaluated (if permissible), Phase 1 capacity downsize or site substitution. Thermal modelling shows PUE >1.30 at 35°C design day (Month 6 = 2027-04-17) → cooling-cost escalation EUR 200M–500M or Phase 1 downsize to 250 MW. Grid peak-load impact (5–15%) during summer stress exceeds RTE capacity buffer → curtailment obligation rises above 10% target, power-gate criterion at risk, Phase 1 capacity constrained by grid thermal limits rather than developer choice.

### 11. Fiber Connectivity and Route Diversity Validation
**Monitoring Tools/Platforms:**

  - Fiber-route audit by independent telecom auditor (physical path maps, duct-separation verification, landing-point analysis)
  - Carrier capacity commitment and letters of intent (at least 2 independent routes per destination, lit by Phase 1 energization Month 42–48 = 2030-04-17 to 2030-10-17)
  - Developer-built fiber cost and rights-of-way estimate (EUR 100M–500M per 100–200 km route, if carrier routes unavailable)
  - Landing-point concentration risk assessment (subsea cable pinch points, redundancy targets ≥2 UK, ≥2 FR/BE landings, no single landing >25% capacity)

**Frequency:** Monthly fiber-sourcing lead updates; independent audits Month 1–9 (2026-11-17 to 2027-07-17); carrier LOI and route confirmations by Month 9 (2027-07-17)

**Responsible Role:** PMO Grid and Power Lead or Tenancy and Revenue Lead (with independent fiber-route auditor, carrier liaisons); escalates to Steering Committee if <2 independent routes are available or landing-point concentration risk is unmitigated

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17): independent fiber auditor is commissioned to map physical-route claims from all candidate carriers (e.g., 'route A and route B are independent') and to audit actual duct paths, bridge crossings, subterranean shared facilities and landing stations. Auditor delivers detailed physical-path verification by Month 9 (2027-07-17). Month 3–9 (2027-01-17 to 2027-07-17): carriers are approached for capacity commitments (≥100 Tbps redundant capacity per route, available at Phase 1 energization). If independent carrier routes are not available (e.g., all carriers share a single landing station, rendering claimed diversity false), developer commits to build or co-invest in a separate route (EUR 100M–500M per 100–200 km), with rights-of-way negotiated along rail, canal or pipeline corridors. Subsea landings near Dunkirk or Channel access are assessed for concentration risk; if all routes funnel through one landing facility, geographic redundancy is compromised and subsea co-investment is evaluated. By Month 9 (2027-07-17), carrier LOIs or written capacity commitments confirm at least 2 independent routes to each of Paris, London, Brussels, Amsterdam, Frankfurt with ≥100 Tbps capacity and <25% per-landing concentration. If routes are not confirmed, Phase 1 design includes developer-built fiber as capex (cost EUR 100M–500M) or Phase 1 connectivity is contingent on carrier delivery by Phase 1 energization (risk of delay if carrier construction slips).

**Adaptation Trigger:** Fiber audit reveals claimed-independent routes share landing station or conduit (Month 9 = 2027-07-17) → latency or resilience risk exposed, developer commits to build separate route or Phase 1 FID contingent on new fiber investment (EUR 100M–500M capex, 6–12 month construction). Carrier capacity commitments not in hand by Month 9 (2027-07-17) → Phase 1 connectivity delayed 6–12 months unless developer-built route is pre-contracted. Subsea landing-point concentration (all routes through 1 facility) not mitigated → sabotage or natural-disaster risk to all cross-border traffic, Phase 1 FID contingent on additional landing or subsea-cable co-investment.

### 12. Topology Decision and Feasibility Trade-Off Validation
**Monitoring Tools/Platforms:**

  - Topology-decision package (single-square vs. split-campus comparison, prepared Month 3–4 = 2027-01-17 to 2027-02-17)
  - Land-assemblability assessment per topology (% parcel optioned, holdout clusters, cost impact)
  - Grid-capacity per-node estimates (RTE preliminary advice per site, phased connection timelines)
  - Split-campus fiber and latency analysis (inter-node dark-fiber cost, round-trip latency vs. workload tolerance)
  - Detailed capex and per-MW cost by topology (single-square EUR 5B–10B vs. split EUR 5.5B–9.2B, schedule impact)

**Frequency:** Topology decision locked at Month 4 (2027-02-17); supporting analysis and evidence compiled Months 1–4 (2026-11-17 to 2027-02-17); formal vote and publication by Steering Committee at Month 4 (2027-02-17)

**Responsible Role:** PMO Land Assembly, Grid, and Tenancy leads (collaborative analysis); Steering Committee votes; Kill Authority Committee monitors for compliance with documented decision criteria

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17): preliminary land-assemblability assessment (Month 3 = 2027-01-17) measures single-square's viability (% parcel optioned) and split-campus nodes' individual viability (Cambrai 80%+, Dunkirk 80%+, Valenciennes 80%+). RTE pre-submission dialogue (Month 1–3 = 2026-11-17 to 2027-01-17) gathers preliminary grid-capacity signals per site; written RTE preliminary letter is not due until Month 6 (2027-04-17), but early informal guidance informs topology choice. Phase 0 Month 4 (2027-02-17): topology-decision meeting is held. Single-square is selected ONLY if (i) at least 70% of target parcel is optioned, AND (ii) RTE written evidence of at least 1 GW capacity is already in hand (not due until Month 6 = 2027-04-17, so this criterion is rarely met by Month 4 = 2027-02-17). If single-square does not meet both criteria, split-campus is the default. Split-campus nodes are ranked by grid capacity per node and land-assemblability per node; typically Cambrai ~500 MW (most assemblable, largest grid offer), Dunkirk ~250 MW (heavy industrial, Gravelines nuclear nearby), Valenciennes ~250 MW (second brownfield, Brussels proximity). Latency tolerance for split-campus is assessed via tenant workload inputs (cluster sizes, inter-node communication frequency); if latent-critical training workloads are >50% of demand, split-campus becomes operationally risky and single-square is preferred if land permits. Phase 1 capex and schedule differ: single-square USD 1.0 GW centralized, ~12 months construction, energization Month 48 (2030-10-17); split-campus 2–3 nodes sequenced (Cambrai first Month 42–48 = 2030-04-17 to 2030-10-17, then Dunkirk Month 54+ = 2031-04-17+), total build 24+ months, per-MW capex higher 5–10% due to duplication. Decision is documented in a topology-decision paper, published to PMO, Steering Committee, lenders, co-investors and Kill Authority Committee.

**Adaptation Trigger:** Land-assemblability fails for single-square (<70% optioned by Month 4 = 2027-02-17) → split-campus forced, Phase 0 extended 3–6 months for node-level feasibility studies (EUR 100M–250M additional spend). RTE preliminary advice suggests grid capacity <1 GW total (Month 3–4 = 2027-01-17 to 2027-02-17 informal signals) → split-campus becomes default to de-risk capacity via multiple smaller nodes. Tenant workload analysis shows >50% latency-critical training workloads by Month 3 (2027-01-17) → single-square preferred on operational grounds, land-assemblability and grid must be forced to support it or Phase 1 capacity downsize. Late topology change (Month 9 = 2027-07-17 or later) → capex rework EUR 250M–500M, Phase 0 gate deferred, Phase 1 FID pushed to Month 18+ (2028-04-17+).

# Governance Extra

## Governance Validation Checks

1. Completeness: All four Phase 0 governance bodies are chartered (Steering Committee, PMO, Kill Authority, Compliance Committee) with defined roles, responsibilities, and decision authorities. Phase 1 transition and Phase 2+ expansion gates are outlined. However, missing are: (1) explicit legal-entity and liability-allocation framework (who is ultimately accountable if a gate is overridden and Phase 1 fails?), (2) third-party adviser escalation protocols (how do RTE, DREAL, ANSSI findings flow back into committee decisions?), (3) conflict-of-interest and revolving-door policies for committee members and advisers, and (4) post-gate closure handoff procedures (what happens to Phase 0 governance bodies once Phase 1 begins?).
2. Consistency: Major internal inconsistency between the Kill Authority Committee's stated veto power and the Steering Committee's stated supermajority override authority. The framework says 'recommendation is binding unless overridden by supermajority' but does not clarify: what happens if the Kill Authority recommends 'cancel' and the Sponsor/Consortium/Independent Director vote 2-1 to override? Does the Kill Authority's published dissent to lenders automatically trigger debt-covenant review? Who decides whether the override is within governance authority or a breach? This ambiguity will materialize at Month 12 (2027-10-17) if any gate fails.
3. Gaps in decision rights and escalation: The framework allocates decisions to committees at the €50M threshold, but does not specify how the PMO resolves workstream-level conflicts below €50M (e.g., if Land Assembly and Permitting both claim limited Phase 0 tranche 2 funds [€250M], who arbitrates?). Further, PMO operational decisions triggering gate-critical outcomes (e.g., deciding not to commission a Phase II survey on a key site, deferring fiber-route audit, reducing EDA survey scope to save cost) should escalate to the Kill Authority for gate-impact review, but the framework does not mandate this. Similarly, the Compliance Committee's authority to 'veto' permit-file content for 'legal or reputational risk' is undefined—does this override the PMO Director or escalate to Steering Committee?
4. Gaps in external-party engagement and escalation: The framework treats RTE, DREAL, ANSSI, EDF and lenders as information sources (written letters, opinions, term sheets), but does not define how preliminary or negative feedback escalates. For example, if RTE issues a preliminary feasibility letter at Month 6 (2027-04-17) saying 'capacity above 500 MW is uncertain pending further study,' does this pass or fail the grid gate? If ANSSI indicates in Month 6 (2027-04-17) that formal review will take 24 months (vs. target 12–18), is this a kill trigger or a 'conditional pass' with Phase 1 contingency? The framework lacks decision rules for ambiguous external outcomes, forcing ad-hoc Steering Committee judgment at the gate.
5. Gaps in contingency and conditional-pass pathways: The framework allows 'conditional approval' if a gate is deferred (e.g., RTE letter due Month 6 = 2027-04-17 but Phase 0 gate at Month 12 = 2027-10-17, so a conditional pass assumes RTE will deliver by Month 18 = 2028-04-17). However, it does not define: (1) what happens if the condition is not met by the target (automatic Phase 1 cancellation?), (2) how Phase 0 team and capital are held or run down during a deferral, (3) whether land options, grid pre-engineering, and tenant term sheets remain valid or must be renewed/re-negotiated, and (4) how lender and co-investor capital commitments are structured for a conditional close (draw down tranches as conditions resolve, or wait for all conditions before any draw?). This gap is material because external authorities (RTE, DREAL, ANSSI) will almost certainly slip beyond their Month 6–9 (2027-04-17 to 2027-07-17) informal-opinion deadlines.
6. Gaps in kill-criteria enforcement when sunk cost pressures override: The framework vests kill authority in an independent committee and mandates dissent disclosure, but does not specify the remedy if override occurs anyway. For example, if the Sponsor/Consortium vote to proceed with Phase 1 FID despite a failed grid gate (RTE offering only 250 MW vs. 500 MW minimum), and the Kill Authority publishes dissent to lenders within 2 working days, what happens next? Do lenders have a contractual right to withdraw financing, or is withdrawal optional? If lenders withdraw, does the Sponsor have 10 working days to replace them, or is Phase 1 automatically stalled? This gap leaves the framework dependent on lender discipline rather than governance structure to enforce kill criteria.

## Tough Questions

1. What specific performance metrics and evidence will the Gate Review and Kill Authority Committee require to confirm that the RTE grid-hosting threshold (at least 500 MW within 36 months) is met at Month 6 (2027-04-17)? A 'preliminary feasibility letter' is vague; does this require a signed non-binding offer, a detailed transmission-reinforcement cost-share agreement, or just written acknowledgment that the site is under study?
2. If the Land Assembly Lead determines by Month 3 (2027-01-17) that less than 70% of the single-square parcel can be optioned non-coercively at below 15% above benchmark, who decides the topology pivot to split campus, and does Phase 0 automatically extend by 3–6 months and the budget to €750M, or can the Sponsor force a single-square continuation at higher cost/risk? What is the decision-maker's accountability if the forced single-square later fails to assemble?
3. By Month 9 (2027-07-17), the PMO Tenancy Lead must show binding take-or-pay leases for at least 30% of Phase 1 capacity. What evidence of 'binding' satisfies the gate? Signed leases with all terms locked? Executed term sheets with only pricing indexed to be finalized at Phase 1 FID? Reservation-fee payments received? If a tenant signs but then exercises an early-termination or renegotiation clause during Phase 0, does the signed commitment count toward the 30%, or must the Kill Authority re-assess at the gate?
4. The framework assumes EDF will provide a non-binding LOI by Month 6 (2027-04-17) and a term sheet by Month 9 (2027-07-17), but does not state what happens if EDF declines (citing policy uncertainty, competing load, or pricing volatility). What is the PMO's fallback: pursue a portfolio of smaller PPAs and spot exposure, and accept higher energy cost variance? If energy cost escalates from €50–70/MWh to €80–100/MWh and cannot be hedged, how much does Phase 1 downsize or delay, and who decides?
5. At Month 12 (2027-10-17), if the Gate Review Committee finds that ANSSI has not issued a preliminary opinion (target Month 6 = 2027-04-17), does Phase 1 FID proceed as 'conditional on ANSSI clearance by Month 18 (2028-04-17),' or is the security gate failed and Phase 1 deferred? If conditional, what is the cost and schedule contingency for Phase 1 construction-start delay if ANSSI clears late or imposes design-change requirements?
6. The Compliance Committee and PMO Permitting Lead must submit permit files by Months 8–9 (2027-06-17 to 2027-07-17) and receive a DREAL screening opinion by Month 9 (2027-07-17). If DREAL responds with a request for additional environmental studies or a wider EIA scope (pushing the permit-file completion to Month 12 = 2027-10-17 or beyond), does this automatically fail the permitting gate, defer Phase 1, or trigger a contingent pass? Who decides the schedule impact on Phase 1 energization (slippage from Month 48 = 2030-10-17 to Month 60 = 2031-10-17)?
7. How will the Steering Committee or Kill Authority resolve a conflict if the PMO's red-team adviser (independent consultant) disagrees with the PMO Director on whether a gate threshold is met? For example, if the red-team says 'RTE's preliminary letter meets the 500 MW grid criterion' but the PMO Director argues 'the language is too conditional,' who has final authority, and is the dissent disclosed to lenders before the Phase 0 gate vote?
8. If Phase 1 is conditionally approved at Month 12 (2027-10-17) pending resolution of one or more deferred gates (e.g., RTE full connection offer, DREAL permitting file decision), what is the governance cadence during Phase 1 design and early procurement (Months 12–24 = 2027-10-17 to 2028-10-17) to monitor gate-condition progress? Does the Kill Authority Committee still meet monthly, or only when a condition is resolved? If a condition fails during Phase 1 design (e.g., DREAL denies the permit), what is the authorization to stop design or procurement, and who has the authority to demand a €500M–1.5B capex write-off?
9. The framework caps Phase 0 sunk cost at €750M in four tranches, but does not explicitly address reallocation between tranches if a workstream over-runs. For example, if the Permitting workstream needs an additional €50M for environmental studies (straining Tranche 3), can the PMO Controller reallocate from the Tenancy or Grid workstreams, or must the Steering Committee approve tranche reallocation? What is the process to avoid Phase 0 spend delays or scope cuts that trigger gate failures?
10. What happens to the Phase 0 team, governance bodies and advisers if Phase 0 gates fail and Phase 1 is not approved at Month 12 (2027-10-17)? Does the Kill Authority Committee dissolve, or remain active to monitor deferral conditions? Are advisers (RTE auditor, ANSSI counsel, land surveyor) retained on contract or released, and what is the cost of re-engagement if Phase 1 is deferred to Month 18–24 (2028-04-17 to 2028-10-17) or cancelled?

## Summary

This Phase 0 governance framework establishes a skeptical, gate-driven feasibility program (Months 0–12 = 2026-10-17 to 2027-10-17, €750M cap) with five core bodies: Steering Committee (strategy and FID approval), PMO (execution), Kill Authority Committee (numeric gate enforcement), Compliance Committee (permitting, security, environment, social license), and four tranches capping sunk cost before each gate. The framework's strength lies in separating authority (Kill Authority independent of Sponsor), publishing dissent, and binding gates to specific external milestones (RTE grid letter by Month 6 = 2027-04-17, tenants 30% signed by Month 9 = 2027-07-17, debt €3B+ committed, 2 of 3 municipalities supporting). Critical weaknesses include: vagueness on the Kill Authority's override-veto process and enforcement when the Sponsor pressures FID despite failed thresholds; incomplete specification of how advisers and external parties (RTE, DREAL, ANSSI, lenders) escalate findings back into the decision process; absent decision-rights clarity for sub-€50M workstream conflicts and operational trade-offs; and underdeveloped remediation protocols when uncontrolled external dependencies (grid, permitting, tenant credit) slip beyond gate deadlines. The framework correctly identifies the primary kill test (grid hosting ~1 GW) and anchors expansion gates to operational evidence (PUE ≤1.28, signed 30–50% demand, security and community targets), but lacks granular delegation protocols for day-to-day PMO decisions and contingency pathways for conditional Phase 1 passes when external authorities have not answered by the gate date.