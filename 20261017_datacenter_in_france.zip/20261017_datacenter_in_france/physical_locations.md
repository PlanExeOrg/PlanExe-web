This plan implies one or more physical locations.

## Requirements for physical locations

- Grid access: nearby 400 kV RTE lines and room for dedicated substations; hosting capacity above ~1 GW is the primary kill test and is uncontrolled until RTE signs a connection offer
- Large assemblable parcels (brownfield or industrial preferred) with limited holdouts; 161 km² contiguous assembly is doubtful (not verified)
- Low water stress; dry or closed-loop cooling feasible with no evaporative water
- Bounded brownfield contamination (soil, groundwater, munitions, slag) via surveys and indemnities
- Diverse fiber routes to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea landings, with audited duct-level diversity
- Proximity to district heating or industrial heat users (heat reuse treated as unpriced upside)
- Zoning and permit compatibility (ICPE, environmental authorization); manageable community and farmland opposition
- Road, rail, canal and port access for heavy equipment and logistics
- Security setbacks and defensible perimeter; national-security review feasibility
- Skilled trades availability (electrical, mechanical, cooling) and housing capacity
- Low-latency links between nodes if a split-campus model is adopted (limit to be set from tenant cluster needs)

## Location 1
France, Hauts-de-France

Cambrai / E-Valley, Nord department

E-Valley redevelopment zone and former Cambrai-Épinoy airbase surroundings, plus adjacent agricultural land

**Rationale**: Named in the plan as a large redevelopment zone. It is the best candidate for a primary node with the largest contiguous parcels. Farmland displacement, 400 kV capacity and a single contiguous 161 km² remain unproven and must be tested. Suited to Phase 1 (500 MW–1 GW) as a reversible option.

## Location 2
France, Hauts-de-France

Dunkirk industrial-port area, Nord department

Grand Port Maritime de Dunkerque industrial zones and heavy-industry brownfield and port land

**Rationale**: Heavy-industry and port hub with existing high-voltage infrastructure, nearby nuclear generation at Gravelines, and subsea and UK connectivity potential. Candidate for a split-campus node. Constraints: land scarcity, Seveso and industrial-risk zoning, competition for grid capacity from industrial decarbonization projects, and coastal ecology.

## Location 3
France, Hauts-de-France

Valenciennes / Denain / Escaudain, Nord department

Former steel and coal brownfield sites around Denain and Escaudain, Valenciennes industrial zones

**Rationale**: Brownfield redevelopment narrative, existing rail, canal and road access, and proximity to Brussels and Paris. A second or third split-campus node, with reuse of industrial land and a fiber ring to Cambrai. Main risks are contamination, fragmented ownership and a dense population requiring a community buffer.

## Location 4
France, Hauts-de-France

Saint-Omer area, Pas-de-Calais

Industrial and logistics zones around Saint-Omer, near canal and A26 corridors

**Rationale**: Named satellite option for smaller inference or sovereign nodes. Offers proximity to the UK and Channel fiber routes and lower land pressure in places. Constraints: water-sensitive wetlands (Marais Audomarois), smaller parcels and limited grid capacity (not verified).

## Location Summary
The plan is tied to Hauts-de-France. Cambrai / E-Valley is the leading candidate for a primary node because of its large redevelopment land. Dunkirk and Valenciennes / Denain / Escaudain are candidate split-campus nodes. Saint-Omer is a possible satellite. Each site is hypothetical until grid, land, water, permit and tenant evidence exists. The single 12.7 km square is to be stress-tested against a split model, and downsizing or cancellation remain legitimate outcomes.