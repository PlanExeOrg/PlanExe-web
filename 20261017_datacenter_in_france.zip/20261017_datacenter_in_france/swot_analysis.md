
## Strengths 👍💪🦾
- Hauts-de-France offers brownfield and industrial land (Cambrai/E-Valley, Dunkirk, Denain/Escaudain), rail, canal and port access, and a reindustrialization narrative that is stronger than a greenfield story.
- Low-carbon French grid and nearby nuclear generation (Gravelines) support a credible clean-power story, though supply terms are uncontrolled until signed.
- The plan is gate-driven and skeptical: Phase 0 is capped at EUR 750M (user constraint) in four tranches (150/250/200/150 EUR M), with no committed capital before Month 12 (2027-10-17).
- Kill criteria are numeric (proposed thresholds): RTE letter for at least 500 MW, at least 70% of the parcel optioned, binding tenant term sheets for at least 30% of Phase 1.
- An independent investment committee and red team are designed in, with override only by two-thirds supermajority and published dissent.
- The 500 MW Cambrai base case, with an option to reach 1 GW, and a split-campus default at Month 4 (2027-02-17) keep the plan flexible and let downsizing count as a legitimate result.
- A zero-evaporative-water design basis and a 35°C design-day test simplify the water and permitting story.
- USD hardware (EUR 1.5B–2.3B) is ring-fenced with tenants or a lessor, so the campus company holds no unhedged USD.
- Cooler climate and low latency to Paris, London, Brussels, Amsterdam and Frankfurt suit batch inference and sovereign workloads.

## Weaknesses 👎😱🪫⚠️
- The headline scale (9 GW, 161 km²) has no precedent, and its EUR 100B–140B+ cost is unvalidated and credible only per tranche (estimate).
- Contiguous assembly of 161 km² is doubtful. Farmland displacement of 10,000–15,000+ ha (estimate) would be contentious, and the sponsor has no land control yet.
- No signed anchor tenants exist, and demand evidence so far is only announcements, which are not commitments.
- Operations headcount is small (50–150 FTE, not verified), so a jobs-based social-license story is weak.
- Stabilized 500 MW economics are thin: DSCR 1.34x against a 1.30x lender minimum (estimate). A 10% curtailment discount cuts it to 1.15x, and without energy pass-through it falls to 0.96x.
- Stacked contingent add-ons of EUR 1.55B–4.2B on the 500 MW base are unfunded and overlap. Other cost lines could push the total to EUR 10.35B, above the EUR 10B ceiling.
- Gate dates assume authority answers (RTE, ANSSI, DREAL) that the sponsor cannot control. A firm RTE offer by Month 12 (2027-10-17) is unlikely.
- The Month 4 (2027-02-17) topology decision falls before the RTE written letter (Month 6 = 2027-04-17), so split campus becomes the default by timing rather than evidence.
- Split-from-the-start would breach the Phase 0 cap by up to EUR 250M and slip the gate.
- It is an open decision whether the user's EUR 5B–10B includes USD hardware.

## Opportunities 🌈🌐
- Staged 500 MW tranches with BESS and curtailment at most 10% (proposed) can earn later RTE tranches and avoid looking speculative.
- Learning from the Dunkirk grid-queue programme and the Irish CRU flexibility policy can shape realistic connection terms.
- Split-campus nodes (Cambrai 500 MW, Dunkirk 250 MW, Valenciennes/Denain 250 MW) allow independent permits, grid offers and legal isolation.
- Redeployable substations and open fiber leave regional value if the campus is downsized.
- Sovereign AI zones with segregated halls could anchor demand if ANSSI sets clear expectations.
- Reservation fees (EUR 10M–50M per 100 MW, proposed) test demand early and fund pre-construction work.
- Lease-and-continue farming, brownfield restoration and a regional training academy can win municipal support.
- Heat reuse is unpriced upside (EUR 0 until a binding offtake exists).
- Co-investing with regional industry and fiber carriers could share reinforcement cost and lift regional connectivity.
- A 2–5 MW pilot hall can validate PUE and cooling before scaling.

## Threats ☠️🛑🚨☢︎💩☣︎
- RTE hosting capacity above ~1 GW is the primary kill test. Competing steel, hydrogen and refinery loads may saturate the Nord 400 kV network, and reinforcement co-funding could cost EUR 500M–1.5B (estimate).
- Multi-GW nuclear-backed supply at EUR 50–70/MWh is not verified. A +EUR 30/MWh shock adds about EUR 112M per year at 500 MW and about EUR 2.0B per year at 9 GW.
- Standard permitting takes 18–30 months plus 24–48 months for appeals (estimates). Fast-track is not assumed, and delay erodes queue position and adds EUR 200M–500M carrying cost.
- ANSSI/DGSI and foreign-investment review may restrict tenants or foreign equity, and its timeline is uncontrolled.
- Farm unions, NGOs and mayors can delay permits by 12–36 months (estimate).
- Tenants may use LOIs to compare 10+ European sites without committing, and AI demand or hyperscaler capex may soften.
- Late-found contamination (EUR 100M–400M) and shared fiber ducts or landings are hidden single points of failure.
- Hot-weather dry-cooling PUE of 1.35–1.5 raises peak grid load by 5–15%, and drought rules could restrict water.
- US export-control changes and EUR/USD moves (EUR 150M–230M per 10%) could disrupt tenant hardware.
- Financing could be refused or priced higher if grid, tenant or liability evidence is weak.
- Sunk cost (up to EUR 750M) pressures sponsors to override gates.

## Recommendations 💡✅
- Month 1 (2026-11-17) (owner: sponsor board and consortium): sign the investment committee charter with at least 2 external directors, a two-thirds override rule and published dissent. Commission the red team (EUR 2M–5M). Fix numeric kill thresholds in writing by Month 2 (2026-12-17).
- Months 0–1 (2026-10-17 to 2026-11-17) (owner: grid lead): file written pre-engineering requests with RTE and DREAL for 500 MW, 1 GW and 2 GW tranches, and commission an independent hosting-capacity audit. Target the RTE preliminary letter by Month 6 (2027-04-17) and treat it as uncontrolled until received.
- Months 1–3 (2026-11-17 to 2027-01-17) (owner: land lead): run parcel and holdout surveys in all four zones. At Month 3 (2027-01-17), test whether at least 70% can be optioned at no more than 15% above benchmark. At Month 4 (2027-02-17), default to split campus unless RTE written evidence for 1 GW is in hand.
- Months 1–9 (2026-11-17 to 2027-07-17) (owner: commercial lead): issue standard take-or-pay and reservation-fee term sheets by Month 2 (2026-12-17). Target binding sheets for at least 150 MW of a 500 MW tranche by Month 9 (2027-07-17). Count only binding sheets, and test the offer with a reservation-fee presale.
- Months 1–6 (2026-11-17 to 2027-04-17) (owner: environment lead): commission Phase I and II brownfield surveys, a hydrology and 35°C thermal study, and a fiber audit. Obtain the written water opinion by Month 6 (2027-04-17) and shortlist parcels with remediation bounded to EUR 0–100M.
- Months 0–6 (2026-10-17 to 2027-04-17) (owner: security and legal lead): hold confidential ANSSI/DGSI pre-submission dialogue and seek an informal opinion by Month 6 (2027-04-17).
- Months 1–5 (2026-11-17 to 2027-03-17) (owner: community lead): set up a liaison committee with published minutes and draft the community-benefit agreement by Month 5 (2027-03-17), aiming for signatures from 2 of 3 municipalities by Month 9 (2027-07-17).
- Month 1 (2026-11-17) (owner: finance lead): resolve whether USD hardware sits inside the EUR 5B–10B. Fund the stacked add-on exposure explicitly, or reduce Phase 1 scope to 250 MW if it cannot be funded.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 2 (2026-12-17), charter the independent investment committee and red team and lock numeric kill thresholds in writing, with Phase 0 spend held within the EUR 750M cap and its four tranches.
- By Month 4 (2027-02-17), publish the topology decision (single square or split campus) based on at least 70% optioned parcel evidence and per-node grid timelines. Obtain the RTE written 500 MW preliminary letter by Month 6 (2027-04-17) (uncontrolled).
- By Month 9 (2027-07-17), obtain binding tenant term sheets covering at least 30% of Phase 1 size (150 MW of 500 MW), with investment-grade or guaranteed counterparties, and executed agreements with reservation fees by Month 12 (2027-10-17).
- By Month 12 (2027-10-17), hold the gate review with a firm debt commitment of at least EUR 3B (12-year tenor or longer), written support from 2 of 3 municipalities, and bounded brownfield liability. Pass, conditionally pass, downsize, split or cancel on evidence.
- By Month 9 (2027-07-17), confirm in writing at least 2 audited diverse fiber routes per core hub, and by Month 6 (2027-04-17) a water-authority opinion and a modelled PUE of at most 1.30 on a 35°C design day.

## Assumptions 🤔🧠🔍
- The sponsor is a private developer backed by an infrastructure-fund consortium. Phase 0 spend is exploratory, with no committed capital before the Month 12 (2027-10-17) gate.
- The 161 km² square is a notional envelope, and split campus is the default at Month 4 (2027-02-17) unless RTE written evidence exists.
- Phase 1 base case is 500 MW at Cambrai/E-Valley; 1 GW only against signed demand and a grid offer.
- All RTE, EDF, ANSSI/DGSI, prefecture and tenant outcomes are uncontrolled until backed by a contract, permit, formal decision or signed term sheet.
- Financing: 60% debt and 40% equity at 5.5% over 15 years (estimates). Lease price is EUR 1.1M per MW-year, excluding energy (estimate).
- Energy is EUR 60/MWh (range 50–70, not verified) and passed through to tenants.
- Fast-track permitting is not assumed.
- USD hardware is financed by tenants or a lessor, and EUR/USD planning is 1.08–1.12 (not verified).

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Actual RTE hosting capacity, queue position and competing load requests at Cambrai, Dunkirk and Valenciennes substations.
- Delivered power cost, including network tariffs and taxes, and whether EDF will contract multi-GW volumes to a private developer.
- Which tenants exist, their cluster-size and latency needs, and what early evidence would reveal a compelling reason to choose this site (for example which prospects pay reservation fees or return for site tours, and what they ask for first).
- Parcel ownership maps, holdout counts and benchmark land values in each zone.
- Phase II contamination results and the creditworthiness of sellers and public bodies offering indemnities.
- ANSSI/DGSI expectations and foreign-investment screening limits for sovereign-adjacent co-investors.
- Local water-authority position on dry cooling and drought rules.
- Whether the EUR 5B–10B includes USD hardware, and how the EUR 1.55B–4.2B contingent add-ons are funded.
- Fiber duct-level route data, and lender and co-investor appetite and terms.
- Status of French AI campus precedents (Fluidstack, State site list), not verified.

## Questions 🙋❓💬📌
- If RTE offers only 250–500 MW per node, would the project still be worth building, and who decides that?
- What evidence would persuade the investment committee to cancel after EUR 400M–750M of spend, and is that threshold already agreed in writing?
- Which tenant would pay a reservation fee today, and what specific advantage of this site (power, latency, sovereignty, price) drives that choice?
- Can the thin 500 MW economics (DSCR 1.34x against a 1.30x minimum) survive curtailment discounts, energy price shocks and the unfunded add-ons?
- Which municipalities, farm groups and competing industrial users can block the project, and what would each need to see before supporting it?