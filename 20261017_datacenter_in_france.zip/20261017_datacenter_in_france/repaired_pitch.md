Persuasive elevator pitch.

# AI Compute Campus: Hauts-de-France Sovereign Scale Initiative

## Project Overview

A **500 MW AI compute campus in Hauts-de-France** offers Europe a credible path to sovereign AI scale without speculation or stranded capital. The project is structured as a staged, gate-driven model that protects investors from sunk-cost momentum while enabling authorities and communities to make evidence-based decisions.

Phase 0 (Months 0–12 = 2026-10-17 to 2027-10-17) gates the 9 GW ambition on hard evidence: RTE hosting capacity, parcel assembly, signed anchor tenants, debt binding, and social license. Hosting capacity above ~1 GW (cumulative, any topology) is the primary kill test for the 9 GW ambition, while a written ≥500 MW RTE letter is the Phase 1 gate (conditional pass allowed). This feasibility phase commits EUR 750M (hard cap, planning range EUR 250M–750M) with no committed capital before the Phase 0 gate.

If Phase 0 passes, Phase 1 delivers 500 MW by Months 12–36 (2027-10-17 to 2029-10-17) with predictable economics: EUR 550M annual revenue, EUR 150M annual opex, 1.34x DSCR, and EUR 101M annual surplus on EUR 5B capex. The project positions the campus as a **reindustrialization anchor** for Hauts-de-France industrial heritage, creating jobs (40–60 Phase 0 FTE; 50–150+ Phase 1 operations) and establishing a benchmark for evidence-gated scaling across the EU.

## Target Audience

The pitch addresses:

- Private hyperscale developer and infrastructure-fund consortium (including sovereign-adjacent co-investors)
- Senior debt lenders (EUR-denominated, investment-grade bias)
- Equity co-investors (family offices, strategic industrial groups)
- Hyperscaler and sovereign-AI anchor tenants
- Decision-making authorities (RTE, DREAL, ANSSI, municipalities)
- Project lenders and external red-team advisers

The project positions the developer as a **feasibility partner**, not a promoter, addressing acute skepticism that any 9 GW single-site campus will face.

## Risks and Mitigation Strategies

### Primary Risk: Grid Hosting Capacity

**Risk:** RTE hosting capacity above ~1 GW (cumulative, any topology) is unconfirmed and represents the kill test.

**Mitigation:**

- Independent third-party grid audit
- Tranche-based connection requests
- Curtailment and battery-energy-storage (BESS) commitments
- Written preliminary letter from RTE for ≥500 MW by Month 6 (2027-04-17)

### Secondary Risks and Mitigations

**Land Fragmentation (170% unproven):**

- At least 70% of chosen topology's target parcel under non-coercive option by Month 4 (2027-02-17)
- Split campus default (2–3 nodes of 250–500 MW) unless RTE written evidence is in hand
- First shortlist of low-liability brownfield and industrial parcels by Month 6 (2027-04-17)

**Anchor-Tenant Credit:**

- Binding term sheets required by Month 9 (2027-07-17) (LOIs do not count)
- Investment-grade counterparty or parent guarantee required
- Reservation fee EUR 10M–50M per 100 MW, paid before construction
- At least 30% of Phase 1 size signed by FID

**Permitting Delay:**

- Standard ICPE plus environmental authorization 18–30 months from filing
- Appeals add 24–48 months; fast-track not assumed
- Filing targeted Months 8–9 (2027-06-17 to 2027-07-17); permit check at Month 18 (2028-04-17)
- Base-case energization Months 42–48 (2030-04-17 to 2030-10-17); downside Months 48–60 (2030-10-17 to 2031-10-17)

**Sunk-Cost Override:**

- Kill criteria locked in writing by Month 2 (2026-12-17)
- Supermajority override only (proposed two-thirds threshold)
- Dissent published to lenders

**Stacked Contingent Add-Ons:**

- Grid reinforcement EUR 500M–1.5B
- Split-campus premium EUR 250M–500M
- Ecological remediation and expansion EUR 200M–500M
- Fiber and subsea connectivity EUR 100M–300M
- Carrying costs and contingency EUR 300M–600M
- Stack total EUR 1.55B–4.2B (EUR 6.55B–9.2B with the EUR 5B base); outside-stack lines (ecology, security, community, firm connection) add EUR 0.5B–1.15B, giving EUR 7.05B–10.35B in total (maximum breach EUR 0.35B); Phase 1 ceiling fixed at EUR 10B

**FX Exposure:**

- EUR 1.5B–2.3B hardware (estimated) sits with tenants, not campus company
- Campus holds zero unhedged USD
- Forward hedges allowed only against signed take-or-pay contracts (hedge ratio 0.5–1.0, cost 0.5–2% per year)

## Metrics for Success

### Phase 0 (Month 12 = 2027-10-17)

Success requires all of the following:

- RTE written preliminary letter for ≥500 MW (written, not verbal)
- ≥70% of target parcel optioned (split campus ≥80% per node)
- Binding term sheets for ≥30% of Phase 1 (150 MW of 500 MW)
- Firm debt ≥EUR 3B committed
- Written municipal support from ≥2 of 3 key municipalities
- Total Phase 0 spend ≤EUR 750M

### Phase 1 Baseline (Months 12–36 = 2027-10-17 to 2029-10-17)

- 500 MW energized, 8–10 halls online
- PUE ≤1.28 across commissioned halls
- 99.5% uptime
- Zero national-security blocks
- Stabilized demand ≥500 MW by Months 54–60 (2031-04-17 to 2031-10-17)

### Phase 2 FID Gate

- ≥50% of next tranche signed (take-or-pay)
- ≥12 months of Phase 1 operating data validating PUE and reliability
- ≥2 municipalities sustained support

## Stakeholder Benefits

**For Developers and Equity:**

- Capped Phase 0 spend (EUR 750M) and enforceable exit (downsizing/cancellation if gates fail)
- **Infrastructure-company upside** (heat reuse, fiber, grid assets)
- 9 GW optionality if demand and grid hold

**For Lenders:**

- Milestone-based drawdowns tied to auditable gates
- Pre-agreed abandonment conditions and Phase 1 ceiling at EUR 10B
- DSCR 1.34x at stabilized 500 MW; proposed lender minimum 1.30x
- 15-year tenor; senior position ahead of USD hardware risk (ring-fenced to tenants)

**For Anchor Tenants:**

- Reserved capacity with binding term sheets
- Indexed energy pass-through (EUR 60/MWh base case, estimate)
- 99.5–99.95% uptime SLA
- Early-commitment discount (reservation fee EUR 10M–50M per 100 MW, credited to rent)

**For Municipalities and Farmers:**

- **Community-benefit package** EUR 50M–150M (estimate) over Phases 1–2: training academy, farm relocation, ecological restoration, heat-reuse partnerships
- Lease-and-continue farming arrangements, keeping farmers as stakeholders at 15% premium above benchmark land value
- Written support from 2 of 3 municipalities as a gate (not a veto) and a binding community-benefit agreement signed by Month 9 (2027-07-17), with payments conditioned on permits and budgeted as a defined Phase 1–2 cost (estimate)

**For France and EU:**

- Sovereign AI capacity (500 MW–9 GW gated on evidence)
- Industrial reindustrialization (Hauts-de-France brownfield and heritage sites)
- Jobs and skills development (40–60 Phase 0; 50–150+ Phase 1 operations; training academy for 200–500 technicians)
- Benchmark model for **evidence-gated scaling** across the EU

## Ethical Considerations

**Transparent Gate Governance:**

- Independent investment committee chartered at Month 1 (2026-11-17) (at least 2 external directors, lender/co-investor observers)
- Numeric kill thresholds locked in writing by Month 2 (2026-12-17)
- Published dissent to lenders; override only by supermajority (proposed two-thirds)
- External red team (EUR 2M–5M) with monthly pass/fail opinions

**Farmland Displacement and Community Impact:**

- Farmland displacement for the full 9 GW square estimated at 10,000–15,000+ hectares; Phase 1 node about 900 hectares
- Non-coercive options: lease-and-continue arrangements at ≤15% premium above benchmark land value
- Keeps farmers as stakeholders, not opponents

**Ecological Impact Management:**

- "Avoid, reduce, compensate" ledger tied to campus-wide master plan by Month 6 (2027-04-17)
- No parcel-by-parcel ad hoc remediation; coherent ecological strategy
- DREAL screening opinion by Month 9 (2027-07-17)
- Compensation budget EUR 200M–300M (exposure up to EUR 500M, not verified)

**Brownfield Liability:**

- Phase I desktop assessments by Month 1 (2026-11-17)
- Phase II intrusive surveys by Month 3 (2027-01-17) on top 2–3 sites per zone
- Shortlist only parcels with remediation bounded to EUR 0–100M per site by Month 6 (2027-04-17)
- Seller/public indemnity or escrow EUR 50M–250M
- Phase 1 reserve EUR 100M–300M

**Community Engagement:**

- Published liaison committee starts Month 1 (2026-11-17)
- Voluntary consultation and binding community-benefit agreement by Month 9 (2027-07-17), with payments contingent on permits
- Heat-reuse partnerships with district heating and local industry

**National Security:**

- Confidential ANSSI/DGSI pre-submission Months 0–1 (2026-10-17 to 2026-11-17); informal opinion Month 6 (2027-04-17)
- Month 12 (2027-10-17) written confirmation that formal review can start (Month 13 = 2027-11-17) with no blocking concern
- Formal clearance planned 12–18 months after formal review starts (about Months 25–31 = 2028-11-17 to 2029-05-17)
- No binding foreign co-investor commitment beyond Phase 0 funding without a favorable informal ANSSI opinion (Month 6 = 2027-04-17) and written confirmation at Month 12 (2027-10-17); formal clearance remains an uncontrolled later condition, and foreign co-investor equity cannot be bound at FID before that clearance
- Formal process uncontrolled but transparency locked within security constraints

**Uncontrolled External Outcomes:**

- All uncontrolled external outcomes (RTE, permits, security clearance) are labeled as such
- The project succeeds only if those actors choose to sign

## Collaboration Opportunities

**RTE (Grid Operator):**

- Co-funded grid-reinforcement structure (EUR 500M–1.5B, estimate)
- Shared cost-benefit if a regional industrial consortium (steel decarbonization, batteries, data centres) anchors the 400 kV expansion
- Tranche-based connection requests to manage risk

**EDF (Utility):**

- Nuclear-backed baseload supply ≥500 MW, 10-year tenor at capped price
- Creates a **benchmark for EU AI-campus energy procurement**
- Binding contract not before Phase 1 FID; LOI and term sheet gates at Months 6 and 9 (2027-04-17, 2027-07-17)

**Municipalities and Regional Bodies:**

- Community-benefit package EUR 50M–150M (training academy, farm relocation, ecological restoration)
- Heat-reuse partnerships with district heating and local industry
- Regional labor pools shared across Phases 1–3

**Fiber Carriers and Subsea Consortiums:**

- Co-investment in diverse landing routes (dark fiber, 100+ Tbps redundant capacity)
- At least 2 physically separate, audited routes to each of Paris, London, Brussels, Amsterdam and Frankfurt
- At least 2 independent UK landings and 2 FR/BE landings
- Any single landing carries at most 25% of cross-border capacity
- Anchors the campus as a regional connectivity hub

**Anchor Tenants (Hyperscalers and Sovereign-AI Users):**

- Capacity-reservation agreements with option to co-fund accelerator procurement
- Tenant-backed lessor isolates FX and export-control risk
- Binding term sheets required by Month 9 (2027-07-17) for ≥30% of Phase 1 (150 MW)

**Land Agencies and Farmers:**

- Lease-and-continue working landscapes
- Preserves agricultural production in buffer and ecological zones
- Built footprint sits on brownfield or premium industrial plots
- Premium of 15% above benchmark land value, non-coercive

## Long-term Vision

**Phase 1 (500 MW by Months 12–36 = 2027-10-17 to 2029-10-17):**
Establishes Hauts-de-France as a credible, **gated AI-compute anchor** with transparent governance and evidence-based expansion criteria.

**Phase 2 (1–3 GW, Months 36–84 = 2029-10-17 to 2033-10-17):**
If Phase 1 performance meets all metrics (PUE ≤1.28, 99.5% uptime, ≥500 MW contracted), Phase 2 expands to a second and third node. Shared grid reinforcement, water and cooling infrastructure, and regional labor pools reduce per-MW costs and accelerate deployment.

**Phase 3–4 (3–9 GW, Months 84–180 = 2033-10-17 to 2041-10-17):**
Tests whether the region can sustain:

- Heat export (district heating, industrial partnerships, immersion-cooling pilots at 50–100 MW)
- Cross-border fiber hubs anchoring European data-sovereignty routing
- Federated node topology avoiding a single-point-of-failure campus footprint

**Contingency Path:**
If any gate fails, the plan downsizes or splits: a 250–500 MW node can stand alone, and redeployed grid assets, fiber infrastructure, and ecological land become public reindustrialization wins. The full 9 GW vision remains contingent on sustained demand (signed take-or-pay at each gate), unencumbered grid capacity, and social license (farmland partners, municipalities).

## Call to Action

**By Month 1 (2026-11-17), commit one of the following:**

- **Advisory:** EUR 3–5M (provides observer seat on investment committee and red-team access)
- **Consortium Co-Investment:** EUR 75M–150M (Phase 0 and/or Phase 1 equity)
- **Lender Pre-Commitment:** EUR 75M–150M (senior debt binding, conditional on gates)

**Immediate Actions (Months 0–1 = 2026-10-17 to 2026-11-17):**

- Independent investment committee chartered; at least 2 external directors and lender/co-investor observers appointed
- RTE pre-engineering audit, grid-hosting study, and preliminary connection-feasibility assessment commissioned
- Specialist advisers engaged: hydrology, brownfield and environmental liability, fiber routing, security (ANSSI pre-submission), and legal/permitting
- Land and parcel agents shortlisting non-coercive options in the notional planning envelope

**Key Milestones:**

- **Month 2 (2026-12-17):** Numeric kill thresholds and override rules locked in writing; monthly reports and published dissent protocols begin
- **Month 4 (2027-02-17):** Topology decision (single square vs. split campus) based on grid capacity and land assembly evidence
- **Month 6 (2027-04-17):** RTE written preliminary letter, water-authority opinion, ANSSI informal opinion, ecology master plan, EDF LOI, brownfield shortlist
- **Month 9 (2027-07-17):** Binding anchor-tenant term sheets (≥30% of Phase 1), DREAL opinion, fiber confirmations, municipal votes
- **Month 12 (2027-10-17):** Phase 0 gate decision: pass/fail on 9 GW ambition and fundable Phase 1 base case (500 MW) or downsized/split alternative

Success unlocks Phase 1 FID and construction on a credible, evidence-validated timeline toward first energization at Months 42–48 (2030-04-17 to 2030-10-17) (downside Months 48–60 = 2030-10-17 to 2031-10-17).