
## Question 1 - What maximum sunk cost is acceptable before the Phase 0 gate, who funds it, and how is USD hardware exposure kept separate from EUR infrastructure capital?

**Assumptions:** Assumption: Phase 0 is capped at €750M (user-constraint upper bound), drawn in milestone tranches from the consortium with abandonment conditions. USD hardware sits in a separate tenant-backed vehicle. Forwards are used only against signed take-or-pay, at a hedge cost of 0.5–2% a year (estimate). Rationale: staged drawdown is common in infrastructure finance and limits stranded capital.

**Assessments:** Title: Financial Feasibility Assessment
Description: Tests whether staged capital limits sunk cost and isolates FX.
Details: Phase 0 of €250M–€750M is an estimate to challenge. Phase 1 hardware of €1.5B–€2.3B in USD moves about €150M–€230M per 10% FX swing (estimate). Risk: sunk-cost pressure overrides the gate. Mitigation: an independent investment committee, drawdowns tied to grid, land and tenant evidence, and hedges only against signed leases. Opportunity: a ring-fenced hardware vehicle widens the lender pool. Full-buildout cost of €100B–€140B+ is unvalidated and credible only per tranche.

## Question 2 - What is the realistic sequence and duration of Phase 0 gates, and which milestones depend on external authorities (RTE, prefecture, ANSSI) and so are uncontrolled?

**Assumptions:** Assumption: Phase 0 runs Months 0–12 (2026-10-17 to 2027-10-17) with a topology decision at Month 4 (2027-02-17), land and water checks by Month 6 (2027-04-17), and tenant term sheets by Month 9 (2027-07-17). The gate review is at Month 12 (2027-10-17). RTE, prefectural and ANSSI milestones are labelled uncontrolled until a signed offer or formal decision exists. Rationale: external processes in France typically take 12–24 months (estimate).

**Assessments:** Title: Schedule Feasibility Assessment
Description: Tests whether the Phase 0 schedule is achievable given external dependencies.
Details: A firm RTE connection offer within 12 months is unlikely (estimate). Permitting is 24+ months and the ~1 GW grid test may resolve only after Month 12 (2027-10-17). Risk: gate dates are set before authorities answer. Mitigation: a gate can pass with 'conditional' status, and Phase 1 FID shifts with RTE timing rather than forcing a decision. Opportunity: early topology and land checks (Months 3–4 = 2027-01-17 to 2027-02-17) can kill the single-square option cheaply, saving up to €100M–€250M (estimate).

## Question 3 - What team and external advisers are needed in Phase 0, and which scarce skills (grid engineering, remediation, security, trades) are the bottleneck?

**Assumptions:** Assumption: Phase 0 needs a core team of about 40–60 people (estimate) plus specialist advisers for grid, hydrology, ecology, legal, land and security. An independent investment committee and red team sit apart from development. Regional offices are opened at Cambrai and Dunkirk. Rationale: comparable large-site development programmes use multidisciplinary teams of this size.

**Assessments:** Title: Resource Capacity Assessment
Description: Evaluates availability of skills for Phase 0 and the Phase 1 build.
Details: Electrical and cooling trades are scarce; wage inflation of 20–40% on trades is a risk (estimate from the risk register). Operations headcount is small (50–150 FTE for Phase 1, not verified), so employment claims must be modest. Mitigation: early framework contracts with large EPC firms, a regional training academy (€10M–€30M, estimate), and prefabricated halls. Opportunity: remediation and civil firms from the region can be certified early. Key-person dependence on the grid and permitting leads should be covered by deputies.

## Question 4 - Which authorisations and reviews apply (ICPE, environmental authorisation, urban planning, national-security review, foreign-investment screening), and is fast-track status assumed?

**Assumptions:** Assumption: The standard route applies: ICPE and environmental authorisation take about 18–30 months, with appeal risk adding 24–48 months (estimates). Fast-track status is not assumed because it is not confirmed. National-security and foreign-investment reviews run in parallel and are uncontrolled until formal decisions exist. Rationale: a standard route avoids dependence on legislation still in progress.

**Assessments:** Title: Regulatory Pathway Assessment
Description: Evaluates permit sequence, review burden and legal-challenge exposure.
Details: Permit delay erodes RTE queue position and adds carrying cost of €200M–€500M (estimate). Foreign co-investor scrutiny could cap foreign equity or restrict tenants. Mitigation: pre-submission dialogue with DREAL, the prefecture and security authorities in Months 0–1, early voluntary consultation, and one permit file per node so a challenge does not stall all sites. A split campus multiplies files but isolates legal risk. Policy change is a gate trigger.

## Question 5 - What are the principal safety and risk exposures (sabotage, grid or fiber disruption, contamination, fire, cooling failure) and what kill thresholds apply?

**Assumptions:** Assumption: Numeric kill thresholds are proposed in Phase 0: firm RTE offer of at least 500 MW within 36 months, at least 70% of the target parcel optioned non-coercively, and signed take-or-pay for at least 30% of Phase 1. Security is baseline campus-wide with hardened enclaves funded by sovereign tenants. Rationale: thresholds are drawn from the risk register and are proposals to be fixed by the committee.

**Assessments:** Title: Safety and Risk Assessment
Description: Evaluates operational, security and liability risks and the strength of kill criteria.
Details: Highest risks: grid below ~1 GW, land fragmentation, no creditworthy anchors (all High likelihood). Contamination can cost €100M–€400M if found late (estimate); intrusive surveys before commitment bound this. Fiber diversity often collapses at shared ducts; audit before relying on it. Single-site concentration raises sabotage and grid-loss impact; a split campus reduces it. Thresholds only bind if the committee is independent of the development team.

## Question 6 - What environmental limits (water, ecology, farmland, carbon, noise, heat) cap the buildable share of the 161 km² and the tolerable cooling approach?

**Assumptions:** Assumption: Cooling is closed-loop direct-to-chip with dry coolers and no evaporative water. Built area is a minority of the envelope (about 30–50%, estimate), with the rest as buffers, ecology and continuing farmland. Heat reuse is valued at zero until offtake is signed. Rationale: a zero-water rule simplifies permitting; the share is a placeholder for the land-use model.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluates water, ecology, land and thermal constraints on scale.
Details: Dry cooling in 30–35°C weather may push PUE to 1.35–1.5 against the 1.15–1.25 target, raising peak grid load by 5–15% (estimate). Farmland loss of 10,000+ ha is politically contentious. Ecological compensation may cost €200M–€500M (estimate) and compete for farmland. Mitigation: ecological master plan by Month 6 (2027-04-17), written water-authority opinion, and reserving contaminated zones for energy or restoration. Opportunity: brownfield reuse and heat export strengthen the narrative if contracted.

## Question 7 - Which stakeholders can enable or block the project (municipalities, farm unions, NGOs, RTE/EDF, prefecture, lenders, tenants), and what level of local support is required to proceed?

**Assumptions:** Assumption: Support from at least 2 of the 3 most affected municipalities is the Phase 1 gate (proposed threshold). A liaison committee and public consultation start in Months 1–3 (2026-11-17 to 2027-01-17). A community-benefit package of €50M–€150M over Phases 1–2 (estimate) is contingent on permits. A binding local veto is not adopted, but refusal by a key municipality triggers reassessment.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluates opposition risk and the legitimacy strategy.
Details: Farm unions (FNSEA, Confédération Paysanne), NGOs and mayors can delay permits by 12–36 months (estimate). Benefits built on jobs lack credibility given small operations headcount. Mitigation: published minutes, lease-and-continue farming arrangements, transparent siting rationale, and funded monitoring roles for municipalities. Competing industrial users (steel, hydrogen) may contest grid capacity. Opportunity: a reindustrialisation narrative with shared infrastructure can win support.

## Question 8 - What operating model will run the campus (tenant contracts, power procurement, grid flexibility, fiber, security operations, node management) and how is it tested before expansion?

**Assumptions:** Assumption: Capacity is sold under take-or-pay leases of 5–10 years (proposed) with reservation fees of €10M–€50M per 100 MW (proposed). Power is a blend of nuclear-linked contracts, PPAs and BESS, with curtailment at or below 10% (proposed, to be negotiated). A 2–5 MW pilot hall validates PUE before scaling. Rationale: pilot-then-scale limits systemic design errors.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluates demand contracts, power, cooling and connectivity operations.
Details: Multi-GW nuclear-backed supply at the assumed €50–70/MWh is not verified; a 20–40% cost overrun would hit the economics hard. Curtailment of 15% on 1 GW could cost €150M–€300M over 10 years (estimate) and conflicts with 99.5%+ tenant SLAs. Mitigation: pass-through indexation, BESS and interruptible workloads. Expansion gate: PUE at or below 1.28 across commissioned halls, power reliability met, and signed take-or-pay for 30–50% of the next tranche. Letters of intent do not count.