# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: RTE Grid Interconnection and Transmission Capacity Specialist

**Knowledge**: French grid infrastructure, RTE connection procedures, 400 kV substation engineering, transmission reinforcement cost-sharing, grid queue positioning, curtailment terms and BESS requirements

**Why**: Grid hosting capacity above ~1 GW is the primary kill condition for this project. Decision 1 and the gate criteria hinge on RTE's written feasibility letter and connection offer. An RTE specialist can audit the pre-engineering dialogue, validate the hosting assumptions, and structure realistic tranche-based connection requests that avoid speculation perception.

**What**: Review the RTE engagement timeline and connection-request strategy. Validate whether the 500 MW–1 GW tranche approach is credible with RTE, assess the reinforcement co-funding exposure (EUR 500M–1.5B estimate), and confirm whether a written letter by Month 6 (2027-04-17) is realistic or if a conditional pass is the only viable gate outcome.

**Skills**: Grid modelling, substation pre-engineering, connection-offer negotiation, curtailment and BESS arbitrage, French regulatory framework for grid access, competitive tendering for reinforcement

**Search**: RTE grid capacity engineering, French transmission substation, connection offer negotiation, 400kV interconnection

## 1.1 Primary Actions

- Charter an independent investment committee by Month 1 (2026-11-17) with written governance binding the sponsor board to a two-thirds supermajority override rule, external director appointments by lenders/co-investors (not sponsor), and lender consent required for Phase 1 capital drawdown if the committee issues a dissent opinion. Tie Phase 0 tranche releases to committee sign-off and publish dissent monthly to all lenders. Without economic leverage, the committee is advisory theater and kill criteria will be overridden under sunk-cost pressure.
- Realign RTE grid hosting capacity timeline with topology gate: immediately file a written pre-engineering request to RTE (Month 0, 2026-10-17) requesting preliminary feasibility on 500 MW, 1 GW and 2 GW single-site and split tranches by Month 5 (2027-03-17), not Month 6 (2027-04-17). If RTE cannot commit to Month 5 (2027-03-17), default to split-campus topology at Month 2 (2026-12-17) and abandon single-square. Commission an independent RTE hosting-capacity auditor to parallel-test RTE's claims and publish findings by Month 5 (2027-03-17). Move the topology gate to Month 5 or 6 (2027-03-17, 2027-04-17), not Month 4 (2027-02-17), to align with RTE evidence.
- Produce and gate a unified capex model by Month 2 (2026-12-17) reconciling all cost lines (infrastructure EUR 5B–10B, grid co-funding EUR 0–1.5B, split-campus premium EUR 250M–500M, ecological EUR 200M–300M, security EUR 50M–200M, community EUR 50M–150M, connection terms EUR 200M–500M) and explicitly allocate funding sources or identify what will be cut if total exceeds EUR 10B. Test whether the 1 GW case (EUR 10B base, zero add-on headroom) is financeable given realistic grid, ecological and carrying-cost contingencies; if not, commit in writing that Phase 1 base case is 500 MW unless grid reinforcement cost is confirmed below EUR 300M and split-campus is not required.
- Execute a binding governance charter (Month 1, 2026-11-17) with lenders and co-investors specifying: (i) automatic gate review if any numeric threshold is breached; (ii) 10-day cure-or-escalate mechanism; (iii) lender veto over Phase 1 drawdown if committee dissent is published; (iv) dissent published monthly with 30-day comment period before override. Make this charter a condition of Phase 0 funding; without it, lenders will view the kill criteria as non-binding and price Phase 1 debt at a 200–300 bps premium (EUR 600M–1.2B cost over 15 years).
- Secure signed anchor-tenant term sheets (not LOIs) covering at least 150 MW (30% of 500 MW) of Phase 1 capacity by Month 9 (2027-07-17), with counterparty credit at BBB− or better and reservation fees paid before construction (EUR 10M–50M per 100 MW). If fewer than 150 MW is signed by Month 9 (2027-07-17), reduce the Phase 1 target to match committed capacity (e.g., 250 MW) and defer Phase 2 FID. Document this as a gate rule in writing by Month 2 (2026-12-17) so tenants understand that LOIs do not count toward FID and only binding leases secure Phase 1 expansion.

## 1.2 Secondary Actions

- Conduct independent third-party RTE hosting-capacity audit (EUR 1M–2M) in parallel with RTE's own feasibility work, with findings published by Month 5 (2027-03-17). This provides objective evidence if RTE delays or gives weak commitments, and signals to lenders that grid risk is being actively stress-tested.
- Initiate formal ANSSI/DGSI pre-submission dialogue (Month 0, 2026-10-17) with a structured white paper (10–15 pages) on project scope, tenant types, foreign co-investor involvement, data-residency policies and proposed security architecture. Seek informal guidance by Month 6 (2027-04-17) and written confirmation that formal review can start within one month of formal application submission. If ANSSI signals a timeline beyond Month 18 (2028-04-17) or blocking concerns unresolvable by Phase 1 FID, flag this as a gate risk and escalate to the investment committee.
- Commission Phase II intrusive brownfield surveys (soil boring, groundwater sampling) by Month 3 (2027-01-17) on the top 2–3 candidate sites per zone (EUR 1.5M–3M per zone). Shortlist only parcels with bounded remediation liability (EUR 0–100M) backed by seller indemnities or public certification. Do not proceed to Phase 1 land commitments on parcels with unquantified contamination exposure.
- Validate dry-cooler performance via site-specific thermal modelling by Month 5 (2027-03-17) under a 35°C ambient design day, assuming 1 GW compute at 150 W/m² and available cooler area. If modelled PUE exceeds 1.30, trigger a design review and document the peak-load impact on RTE for grid-reserve calculations. Obtain written water-authority opinion by Month 6 (2027-04-17) confirming that closed-loop dry cooling is permissible with no impact on drinking-water supply during normal and drought years.
- Establish a municipal and community liaison committee by Month 1 (2026-11-17) with formal representation from affected municipalities, farm groups, environmental NGOs and a third-party facilitator. Commission a social-impact study (EUR 300K–600K) to identify stakeholder concerns. Draft a binding community-benefit agreement by Month 5 (2027-03-17) with committed funding (EUR 50M–150M over Phases 1–2) and ecological/employment terms. Target signatures from 2 of 3 municipalities by Month 9 (2027-07-17); absent signatures, escalate to the investment committee as a gate failure.
- Audit fiber route diversity by Month 9 (2027-07-17): obtain written confirmation from at least 2 carriers that two physically separate routes (no shared duct, bridge or landing) exist to each of Paris, London, Brussels, Amsterdam and Frankfurt, with at least 100 Tbps redundant capacity. Require duct-level physical surveys (not carrier marketing maps) to verify diversity claims. Any single landing facility carrying >25% of cross-border capacity is a gate failure.
- By Month 2 (2026-12-17), resolve the open decision on USD hardware scope: clarify whether the user's EUR 5B–10B includes GPU/TPU and networking hardware (EUR 1.5B–2.3B) or not. If not included, show how this EUR 1.5B–2.3B will be financed (tenant leasing, equipment financing, or developer forward). If included, adjust the capex model to show that hardware is ring-fenced outside the campus-company balance sheet (held by tenants or a lessor) and make clear what the EUR 5B–10B covers.
- Hire a parcel-fragmentation and optionability surveyor (EUR 200K–400K) to produce detailed ownership maps and holdout counts for all candidate zones by Month 3 (2027-01-17). Test the 70% optionability threshold at no more than 15% above benchmark land value; if <70% appears achievable on a single square, document the holdout names, parcel counts and negotiation barriers. Use this to calibrate topology risk by Month 4 (2027-02-17).

## 1.3 Follow Up Consultation

Next consultation should address: (1) Governance charter execution (Month 1 = 2026-11-17 deadline) and lender consent-rights structure—clarify whether dissent publication is binding or advisory, and what happens if the committee votes to kill but the sponsor overrides; (2) RTE timeline realism: confirm whether RTE will respond by Month 5 (2027-03-17) or if single-square must default to split-campus at Month 2 (2026-12-17); (3) Unified capex model reconciliation and funding gaps—quantify which EUR 1.55B–4.2B contingencies are funded and which create headroom collapse; (4) Anchor-tenant demand velocity: identify which 2–3 tenants are most likely to sign term sheets by Month 9 (2027-07-17) and what specific advantage drives their choice of this site; (5) Gate discipline enforcement post-Month 6 (2027-04-17): if RTE capacity, water feasibility or ANSSI clearance pathway show negative signals, what triggers a kill/downsize decision at Month 12 (2027-10-17) versus a forced continuation under sunk-cost pressure.

## 1.4.A Issue - Phase 0 Gate Authority and Kill-Criteria Enforcement Remain Dangerously Vague

The plan states an independent investment committee will hold kill thresholds, but does not specify: (i) who appoints the external directors and red team (sponsor or lenders?), (ii) what triggers a forced gate review if thresholds are breached (automatic at Month 12 = 2027-10-17, or on demand?), (iii) what happens if the committee votes to kill the project but the sponsor board overrides (dissent publication is not enforcement), (iv) how dissent is 'published to lenders'—in what form, frequency, and with what lender veto right? Without these details, the stated two-thirds supermajority override and published dissent collapse into advisory theater. Sunk-cost pressure will override stated thresholds unless the committee has real economic leverage (e.g., veto over Phase 1 capital drawdown or lender consent rights).

### 1.4.B Tags

- governance_gap
- gate_credibility
- sunk_cost_risk
- override_mechanism

### 1.4.C Mitigation

By Month 1 (2026-11-17), execute a formal governance charter signed by the sponsor board and lenders, specifying: (i) external directors appointed jointly by lenders and co-investors, not sponsor; (ii) automatic gate review triggered if any threshold breach is detected, with 10 business days to cure or escalate; (iii) lender consent required for Phase 1 capital drawdown if the committee publishes a dissent opinion; (iv) dissent published monthly to all lenders and co-investors in writing, with a 30-day comment period before override. Tie Phase 0 tranche releases to committee sign-off, not sponsor discretion. Without economic leverage, the committee is theater.

### 1.4.D Consequence

Without enforceable gate authority, Phase 0 spend will reach EUR 600M–750M by Month 9 (2027-07-17), creating sunk-cost pressure to override the Month 12 (2027-10-17) kill criteria. A false-positive gate (e.g., RTE gives only 500 MW per node but Phase 1 proceeds anyway) locks EUR 5B–10B into a constrained, high-risk project. Lenders will refuse to fund Phase 1 without a credible kill mechanism, or demand a 200–300 bps risk premium, raising debt cost by EUR 600M–1.2B over 15 years.

### 1.4.E Root Cause

The plan inherits the sponsor's optimism bias: stating kill criteria is easier than designing the enforcing mechanism. The governance section assumes lender oversight without formalizing lender veto rights or committee independence. Standard mega-project gating fails when the developer controls the gate and gate breaches carry no consequence.

## 1.5.A Issue - RTE Grid Hosting Capacity Timeline is Misaligned with Topology and Capital Gates

The topology decision is locked at Month 4 (2027-02-17), requiring evidence that 'at least 70% of the parcel is optioned' AND that 'RTE gives at least 1 GW to that node in writing.' The RTE preliminary letter is not due until Month 6 (2027-04-17), two months after the topology gate. This means single-square topology is forced into 'default' split-campus status by calendar, not evidence. Even if RTE sends a letter at Month 6 (2027-04-17), a two-month lag to re-open single-square at Month 8 (2027-06-17) breaks capital and permitting timelines. The plan then compounds this by proposing that split-campus from the start costs EUR 100M–250M extra and adds 3–6 months, breaching the EUR 750M Phase 0 cap and Month 12 (2027-10-17) gate. The plan says 'split-campus is the default at Month 4 (2027-02-17) but can be kept alive only if RTE written evidence is already in hand'—but no mechanism exists to force RTE to answer by Month 4 (2027-02-17).

### 1.5.B Tags

- timeline_misalignment
- rte_uncontrolled
- topology_default_conflict
- gate_sequencing

### 1.5.C Mitigation

Immediately (Month 0, 2026-10-17) file a formal written RTE pre-engineering request specifying: 'Preliminary feasibility opinion on 500 MW, 1 GW and 2 GW single-site and split-campus tranches due by Month 5 (2027-03-17).' If RTE cannot commit to a Month 5 (2027-03-17) date, assume single-square is infeasible and lock split-campus topology at Month 2 (2026-12-17). Hire an independent RTE hosting-capacity auditor (EUR 1M–2M) to parallel-test RTE's claims and publish findings by Month 5 (2027-03-17), giving the topology gate real evidence rather than a calendar default. Revise the topology gate to Month 5 (2027-03-17) or Month 6 (2027-04-17) to align with RTE response, and accept a 4–6 week permitting delay as the cost of evidence-based decision.

### 1.5.D Consequence

If topology is forced to split-campus by calendar, the plan incurs EUR 100M–250M of extra capex and 3–6 months of delay within a EUR 750M Phase 0 cap and Month 12 (2027-10-17) gate. This breaks the stated cap and gate. Alternatively, if single-square is kept alive pending the Month 6 (2027-04-17) RTE letter, the land option and permitting work done in Months 2–5 (2026-12-17 to 2027-03-17) for split-campus nodes is stranded. Either way, the plan oscillates between two topologies without a clear decision rule, wasting EUR 100M–250M and 6–12 months.

### 1.5.E Root Cause

The plan treats RTE's response as exogenous ('uncontrolled until signed') but then designs the topology gate to depend on that response two months after the gate date. RTE has no incentive to answer quickly, and the plan has no fallback if RTE delays. Real projects either accept split-campus as the baseline and keep single-square as a contingency, or they delay the topology gate until RTE responds, accepting the calendar slip as the cost of evidence.

## 1.6.A Issue - Phase 0 Budget Cap of EUR 750M and Stacked Contingent Add-Ons Create Headroom Collapse Risk at Phase 1 Gate

The plan caps Phase 0 spend at EUR 750M and Phase 1 at EUR 5B–10B (EUR 10B hard ceiling per user constraint). Separately, the plan identifies 'stacked contingent add-ons' of EUR 1.55B–4.2B on the 500 MW base (grid co-funding EUR 500M–1.5B, split-campus overhead EUR 250M–500M, carrying cost EUR 300M–600M, Phase 1 brownfield reserve EUR 100M–300M, fiber EUR 200M–400M, others). Adding these to the EUR 5B base gives EUR 6.55B–9.2B, leaving headroom of EUR 0.8B–3.45B. However, other cost lines sit outside this stack: ecological compensation EUR 200M–300M (estimate), Phase 1 security EUR 50M–200M, community benefit EUR 50M–150M, and 'firm no-flexibility connection' EUR 200M–500M. When these are added, total capex reaches EUR 7.05B–10.35B, possibly breaching the EUR 10B ceiling and leaving EUR 2.95B to −EUR 0.35B headroom. The plan does not clarify which add-ons are inside or outside the EUR 5B base, does not specify which are funded, and does not explain how a 1 GW Phase 1 (EUR 10B base, no add-ons) leaves room for any contingencies.

### 1.6.B Tags

- budget_ambiguity
- stacked_contingencies
- headroom_collapse
- 1gw_unaffordable

### 1.6.C Mitigation

Immediately (Month 0, 2026-10-17) produce a detailed capex model reconciling all cost lines: (i) shell/power/cooling/fiber infrastructure (EUR 5B for 500 MW, EUR 10B for 1 GW); (ii) grid reinforcement co-funding as line item (separate from infrastructure, EUR 0–1.5B); (iii) split-campus cost premium if triggered (EUR 250M–500M, funded where?); (iv) Phase 1 contingency (typically 10–15% of capex = EUR 500M–1.5B); (v) ecological, security, community and connection-terms add-ons as separate budget sections with sources. Publish this model by Month 2 (2026-12-17) and make it a gate condition: if contingencies exceed EUR 10B in aggregate, reduce Phase 1 to 250–500 MW or 'downsize' becomes the default outcome. Explicitly state that a 1 GW Phase 1 (EUR 10B base) leaves zero headroom for grid co-funding or split-campus premium, and document this as a financing constraint that will force phase-down if grid reinforcement costs are discovered to be above EUR 0.5B.

### 1.6.D Consequence

At Month 12 (2027-10-17) gate, if grid reinforcement is discovered to be EUR 1.2B, ecological compensation is EUR 300M and a split-campus is required (adding EUR 300M), the Phase 1 total reaches EUR 6.8B, still under EUR 10B but with no margin. A 10% cost escalation (normal risk) pushes total to EUR 7.48B. If Phase 1 slips 12 months, carrying cost (interest, land holding, workforce retention) adds EUR 600M–800M, giving EUR 7.08B–8.28B—still feasible but now consuming all contingency. A financing gap or lender covenant breach appears likely, and debt pricing rises 200+ bps, adding EUR 600M–1.2B in interest cost over the debt tenor. The plan then either gets downsized post-gate (costly, unpopular) or Phase 1 proceeds with inadequate contingency (risky).

### 1.6.E Root Cause

The plan aggregates costs from multiple sources (RTE, EDF, ecology, fiber, remediation) without reconciling them into a single capex model. The EUR 5B–10B range and the EUR 1.55B–4.2B contingency stack are treated as separate layers rather than as a unified budget. The plan does not test whether the 1 GW case is economically feasible once all contingencies are added, and it does not pre-commit which cost line will be cut if total spend exceeds EUR 10B.

---

# 2 Expert: Sovereign and Defense-Adjacent AI Procurement Lead

**Knowledge**: French and European sovereign AI initiatives, ANSSI/DGSI security clearance timelines, foreign-investment screening, data-residency compliance, segregated compute partitions for classified workloads, national-security review procedures

**Why**: The Anchor-Tenant model (Decision 3) and national-security review (Decision 5) depend on clarity about sovereign demand, foreign co-investor acceptability, and the timeline for ANSSI clearance. A specialist in sovereign procurement can validate whether the proposed 2–3 sovereign anchors plus hyperscaler tenants is achievable, and whether the 12–18 month formal security review timeline is credible.

**What**: Engage ANSSI/DGSI to clarify blocking concerns on foreign co-investment, outline the formal security review pathway starting Month 13 (2027-11-17), and identify specific sovereign AI use cases (e.g., defence modelling, critical-infrastructure AI) that could anchor Phase 1. Validate whether segregated high-security halls justify the security cost and complexity, and whether sovereign demand can commit 30% of Phase 1 capacity by Month 9 (2027-07-17).

**Skills**: National-security review facilitation, sovereign data classification, foreign-ownership vetting, segregated compute architecture, French AI and defence procurement, ANSSI liaison

**Search**: ANSSI security review data center, French sovereign AI procurement, foreign investment screening DGSI, classified compute partition

## 2.1 Primary Actions

- Sign the investment committee charter, red-team engagement and numeric kill thresholds in writing by Month 1 (2026-11-17). Include at least 2 external independent directors, lender/co-investor observers, supermajority override rule, monthly red-team pass/fail opinions (direct to committee, not filtered by development staff), and quarterly dissent publication to lenders naming failed thresholds and remediation options (continue, pivot, or kill). Escrow the first EUR 150M tranche and release only on committee authorization.
- File the RTE pre-engineering request (500 MW, 1 GW, 2 GW tranches per topology option) in writing by Month 0 (2026-10-17, Hour 1) and demand a preliminary feasibility letter by Month 4 (2027-02-17)—not Month 6 (2027-04-17). If RTE cannot deliver by Month 4 (2027-02-17), move the topology decision to Month 6 (2027-04-17) and slip all downstream milestones. Simultaneously, design a worst-case split-campus topology (3 nodes × 250 MW) independent of RTE's answer, and confirm with RTE that a preliminary letter does not reserve queue position (formal request filed later does not lose priority).
- Identify 3–5 anchor-tenant candidates by Month 1 (2026-11-17) (2–3 hyperscalers, 2–3 sovereign/EU users) and pre-brief them under NDA. By Month 3 (2027-01-17), test the reservation-fee offer (EUR 10M–50M per 100 MW, paid before construction, credited to rent) with the top 1–2 candidates. By Month 9 (2027-07-17), target at least 150 MW of binding take-or-pay term sheets signed, with fees paid into escrow. Distinguish in writing between LOIs (non-exclusive, site-comparison tool—do not count toward gates) and binding sheets (exclusive, payment obligation, SLA-subject—count for gates). If only LOIs exist by Month 9 (2027-07-17), explicitly flag as a gate failure and trigger Phase 1 downsize.
- Commission Phase I environmental site assessments (desktop) on all four candidate zones by Month 1 (2026-11-17); Phase II intrusive surveys (soil boring, groundwater, asbestos) by Month 3 (2027-01-17) on top 2–3 sites per zone (EUR 1.5M–3M per zone). By Month 6 (2027-04-17), shortlist only parcels with remediation bounded to EUR 0–100M and seller/public indemnities of EUR 50M–250M backed by escrow. Any site discovered to have remediation exposure >EUR 100M drops from consideration and resets Phase 1 cost planning.
- Obtain written water-authority (DDT/DDTM and Agence de l'Eau) opinion by Month 6 (2027-04-17) confirming that closed-loop direct-to-chip liquid cooling with dry coolers is permissible at 1 GW scale with no impact on drinking-water supply during normal and drought years. Conduct thermal modelling at 35°C ambient design day by Month 5 (2027-03-17); if modelled PUE exceeds 1.30, trigger design review and budget hybrid cooling as contingency. Do not permit evaporative cooling due to the explicit zero-water constraint.
- Schedule confidential pre-submission dialogue with ANSSI and DGSI by Month 0 (2026-10-17, Hour 2) with the sponsor CEO/legal. Obtain written preliminary opinion by Month 6 (2027-04-17) confirming that formal security review can start within 1 month of formal application with a 12–18 month timeline, or identifying blocking concerns (foreign co-investment unacceptable, data-residency requirements unmet). If ANSSI signals a timeline beyond Month 18 (2028-04-17) or identifies fundamental blocking concerns unresolvable by Phase 1 FID (Month 12 = 2027-10-17), trigger the investment committee to pause Phase 1 and reassess sovereign co-investor involvement.

## 2.2 Secondary Actions

- Commission a parcel-level land-assembly feasibility study by Month 0 (2026-10-17) covering all four candidate zones (Cambrai, Dunkirk, Valenciennes, Saint-Omer), mapping parcel count, owner type (public/private/agricultural), known holdout groups, and the percentage of target area optionable non-coercively at ≤15% above benchmark value. At Month 3 (2027-01-17), confirm whether at least 70% of the chosen topology's target parcel meets this test; if not, default to split campus by Month 4 (2027-02-17).
- Commission a regional hydrological and vendor dry-cooler study by Month 1 (2026-11-17) documenting surface/groundwater availability, drought frequency, and cooler performance at 15–35°C ambient (three leading manufacturers). By Month 4 (2027-02-17), deliver site-specific thermal modelling showing PUE at peak conditions; if above 1.30, budget hybrid cooling or capacity reduction as contingency.
- Establish a municipal and community liaison committee by Month 1 (2026-11-17) with formal representation from mayors, regional councils, farm unions (FNSEA/Confédération Paysanne), environmental NGOs (at least 2), and an independent community facilitator. Commit to quarterly published minutes. Commission a social-impact study (interviews with 100+ farmers, survey of 500+ residents, engagement with NGOs) by Month 1 (2026-11-17); deliver findings by Month 4 (2027-02-17).
- Draft a binding community-benefit agreement by Month 5 (2027-03-17) specifying: (i) EUR 50M–150M direct-income transfers to affected municipalities (formula: EUR 10M per 100 MW Years 1–5, EUR 15M per 100 MW Years 6–10, indexed to inflation); (ii) farm-relocation packages at 1.5–2.0× benchmark value (EUR 15,000–25,000/ha); (iii) ecological restoration with co-management and monitoring; (iv) ≥50% Phase 1 construction labor from Hauts-de-France, ≥30% from within 50 km, wage standards at or above union rates; (v) EUR 10M–30M infrastructure upgrades to affected municipalities. Obtain signatures from at least 2 of 3 key municipalities by Month 9 (2027-07-17); absent signatures, the investment committee reassesses Phase 1 feasibility on social-license grounds.
- Test fiber-route diversity by Month 1 (2026-11-17); commission physical route audits confirming at least 2 separate, non-shared-duct paths to each of Paris, London, Brussels, Amsterdam, Frankfurt by Month 9 (2027-07-17). Confirm independent UK and FR/BE landings and that any single landing carries ≤25% of cross-border capacity. Any shared duct or landing concentration triggers network redesign and cost review.
- Develop detailed cost-line reconciliation by Month 2 (2026-12-17) for the Phase 1 ceiling (EUR 10B user constraint) broken down as: (i) campus-company EUR infrastructure (EUR 5.0B base for 500 MW); (ii) stacked contingent add-ons (grid co-funding, split premium, carrying, remediation, fiber, subsea: EUR 1.55B–4.2B, overlapping, to be prioritized); (iii) ecological compensation (EUR 0.2B–0.3B); (iv) security (EUR 0.05B–0.2B); (v) community benefit (EUR 0.05B–0.15B); (vi) USD hardware (EUR 1.5B–2.3B, ring-fenced outside campus company). Total headroom to EUR 10B: verify at least EUR 0.5B contingency remains unassigned. If headroom falls below EUR 0.5B, trigger Phase 1 downsize to 300–400 MW or split the USD hardware and EUR infrastructure into separate vehicles with separate funding.
- Commission a red-team hosting-capacity audit by Month 1 (2026-11-17) (EUR 1M–2M, independent grid specialist with no financial interest) to verify RTE's claims through network modeling and site surveys. Publish findings anonymized to lenders by Month 9 (2027-07-17). Any audit finding of RTE capacity <500 MW per node triggers topology review and potential Phase 1 downsize.
- Establish deal-team accountability: (i) grid lead responsible for RTE letter by Month 6 (2027-04-17); (ii) land lead for 70% optionability by Month 4 (2027-02-17); (iii) commercial lead for 150 MW signed take-or-pay by Month 9 (2027-07-17); (iv) finance lead for EUR 3B debt commitment by Month 12 (2027-10-17); (v) community lead for 2+ municipal signatures by Month 9 (2027-07-17); (vi) security lead for ANSSI clearance pathway confirmation by Month 6 (2027-04-17). Monthly steering committees with outcome transparency; flag any lead in red (at-risk) status by Month 3 (2027-01-17) and escalate to the investment committee.

## 2.3 Follow Up Consultation


At the next consultation, advise on: (i) Investment committee composition and charter completion (have independent directors been identified and do they accept the supermajority override rule?); (ii) RTE response timeline and content (what has RTE said about 500 MW, 1 GW, 2 GW feasibility and queue position?); (iii) Anchor-tenant conversations (which tenants have expressed interest, and has any reservation-fee offer been tabled or accepted?); (iv) Land-assembly feasibility results (what percentage of each candidate zone can be optioned non-coercively at ≤15% above benchmark?); (v) Brownfield Phase II results and liability allocation agreements signed with sellers/public bodies; (vi) Water-authority and ANSSI preliminary opinions, and any blocking concerns identified; (vii) Municipal liaison-committee feedback and draft community-benefit terms; (viii) Topology decision: single square or split campus, and cost/timeline implications of the choice. Review all numeric gate thresholds at Month 6 (2027-04-17) mid-point gate (informal checkpoint before the Month 12 = 2027-10-17 formal decision) and adjust Phase 1 scope (500 MW base, 1 GW option, or downsize to 250–300 MW) based on evidence at that point.


## 2.4.A Issue - Independence and Authority of the Investment Committee Is Not Yet Hardened—Risk of Sunk-Cost Override

The plan calls for an independent committee with 'two-thirds override' authority and 'published dissent,' but no charter has been signed and no numeric kill thresholds have been formalized in writing. Without Month 1 (2026-11-17) charter completion and Month 2 (2026-12-17) threshold lock, the stated gates are aspirational only. Sunk-cost pressure routinely overrides board-level discipline once EUR 250M–400M is spent. The red team must report directly to the committee (not to development staff) and dissent must be published to lenders quarterly, not at the gate. Current plan treats this as a sequential action rather than a parallel, parallel-to-Day-1 priority.

### 2.4.B Tags

- governance-enforcement-gap
- sunk-cost-momentum
- gate-credibility
- external-authority-missing

### 2.4.C Mitigation

Before any Phase 0 spend is authorized, sign an investment committee charter (Month 0, 2026-10-17, Week 1) specifying: (i) composition (at least 2 external, independent directors with veto authority; no conflicts of interest; lender and co-investor observers); (ii) numeric kill thresholds in table form (RTE ≥500 MW letter by Month 6 = 2027-04-17, ≥70% parcel optioned by Month 4 = 2027-02-17, ≥150 MW signed take-or-pay by Month 9 = 2027-07-17, ANSSI clearance pathway confirmed by Month 6 = 2027-04-17, ≥EUR 3B debt by Month 12 = 2027-10-17); (iii) voting rule (simple majority to continue, supermajority [two-thirds] to override a failed threshold); (iv) red team reporting (monthly pass/fail, direct to committee, zero development-team filtering); (v) dissent publication (quarterly to lenders, naming threshold failures and remediation options—continue, pivot, or kill). Escrow the first tranche (EUR 150M) in a trustee account and release only on committee authorization. This move costs zero capital but makes gates enforceable.

### 2.4.D Consequence

Without hardened governance, the project will burn through the EUR 750M Phase 0 budget despite unmet RTE, land, or tenant gates, because sunk cost and board inertia override stated conditions. The final decision at Month 12 (2027-10-17) will be to 'proceed with a smaller Phase 1' or 'pivot to split campus with revised timelines' rather than an honest kill. The result is either a stranded EUR 750M or a forced Phase 1 FID on inadequate evidence, risking an unfinanceable or operationally deficient 500 MW campus.

### 2.4.E Root Cause

The charter has not yet been drafted or signed. Development momentum and board inertia habitually override stated gates when USD billions are pending. The plan acknowledges this risk but does not move the committee formalization and threshold lock to Month 0 (2026-10-17), Hour 0 (today), where they belong. Current structure allows Month 12 (2027-10-17) gate to be renegotiated if USD 400M–750M of Phase 0 spend has already been committed.

## 2.5.A Issue - RTE Grid Hosting Capacity Remains Uncontrolled and Timing Misaligned with Topology Decision

The plan calls for an RTE preliminary letter by Month 6 (2027-04-17), but the topology decision (single square vs. split campus) is locked at Month 4 (2027-02-17)—two months before RTE answers. This creates a structural sequencing flaw: the decision to pursue a single 1 GW tranche depends on RTE written evidence of 1 GW capacity, yet that letter is not due until after topology is fixed. The default is forced to be split campus because RTE evidence will not exist, regardless of whether RTE actually supports 1 GW. Furthermore, RTE's response is entirely uncontrolled; no guarantee exists that RTE will commit above ~500 MW per node, making the ~1 GW kill threshold the primary feasibility risk.

### 2.5.B Tags

- gate-sequencing-error
- uncontrolled-external-decision
- grid-hosting-primary-kill-condition
- timeline-mismatch

### 2.5.C Mitigation

(i) File the RTE pre-engineering request in writing on Day 1 (Month 0, 2026-10-17, Hour 1) with explicit request for preliminary feasibility by Month 4 (2027-02-17)—not Month 6 (2027-04-17)—and pressure RTE to deliver within 8 weeks by citing national-strategic AI deployment importance (ANSSI/DGSI backing helps). (ii) If RTE cannot commit to Month 4 (2027-02-17) delivery, move the topology decision to Month 6 (2027-04-17) and accept a 2-month slip in all downstream milestones (land option letters, tenant conversations, permitting prep). (iii) Simultaneously, run a parallel worst-case plan: assume RTE offers only 250–500 MW per node and design the split-campus topology (3 nodes × 250 MW = 750 MW, with Cambrai as the anchor) independent of RTE's response. This removes the binary outcome (1 GW or fail) and gives the topology decision evidence of 'minimum viable grid' per node. (iv) Obtain signed commitment from RTE that any preliminary letter issued in Month 4–6 (2027-02-17 to 2027-04-17) is not binding on queue position, so a formal connection request filed later does not lose priority.

### 2.5.D Consequence

Without RTE written evidence, the topology decision will default to split campus by procedural default rather than technical merit. If RTE then offers 1 GW to a single Cambrai node in Month 6 (2027-04-17), the project will have already committed to a split-campus design and permitting structure, adding EUR 200M–500M redesign cost and 6–12 month schedule slip. Alternatively, RTE may offer <500 MW (the primary kill condition), and the topology lock at Month 4 (2027-02-17) will have created committed costs for single-site land options and environmental baseline work that cannot be redeployed to other nodes. Either way, premature topology commitment costs EUR 150M–300M of Phase 0 spend and blows the 12-month gate timeline.

### 2.5.E Root Cause

The project assumed Month 4 (2027-02-17) topology decision based on 70% land optionability, but did not account for the fact that RTE's technical feasibility (the other topology driver) will not be available until Month 6 (2027-04-17). RTE is a slow, process-driven bureaucratic actor; preliminary opinions require 3–4 months of network modeling and stakeholder discussion. The plan treats RTE as if it will prioritize this project and respond within an 8-week initial phase.

## 2.6.A Issue - Anchor-Tenant Demand Validation Relies on Letters of Intent, Not Binding Take-or-Pay—No Real Proof of Revenue

The plan correctly states that 'LOIs do not count' and requires 'signed take-or-pay' for ≥30% of Phase 1 by Month 9 (2027-07-17). However, the strategic-decisions document and the feasibility assessment show no mechanism to distinguish between an LOI (non-exclusive, site-comparison tool) and a binding term sheet (exclusive, payment obligation, subject to SLA performance). Global hyperscalers and sovereign entities use LOIs to compare 10–20 European sites without disclosure. The plan has no evidence that any tenant exists with a signed LOI, let alone a binding term sheet. The gate requires 150 MW of signed 500 MW by Month 9 (2027-07-17); if only LOIs materialize, the project cannot proceed to Phase 1 FID, yet Phase 0 will have spent EUR 400M–600M on RTE, land, ANSSI, and permitting work.

### 2.6.B Tags

- demand-validation-gap
- binding-commitment-missing
- tenant-credit-risk
- phase0-spend-without-demand-proof

### 2.6.C Mitigation

(i) By Month 1 (2026-11-17), identify 3–5 anchor-tenant candidates (2–3 global hyperscalers with published capex plans in 2025–2028, 2–3 sovereign or EU-consortium users such as French State AI offices) and pre-brief them on the project via NDA-protected site overview. Record the outcome: 'expressed interest,' 'exploring further,' 'not interested,' or 'requesting specific terms.' (ii) For candidates showing 'exploring' or better, conduct a Month 2–3 (2026-12-17 to 2027-01-17) competitive-alternative survey: which other EU sites are they considering, what are the offered terms (power price, uptime SLA, latency), and what would lock this site ahead of rivals? (iii) Develop reservation-fee mechanics (propose EUR 10M–50M per 100 MW, paid before construction, credited to rent) and test the offer with the 1–2 most-credible tenants by Month 3 (2027-01-17). Record whether any tenant pays a reservation fee (hard evidence) or only agrees to an LOI (no commitment). (iv) For binding term sheets, specify in writing: capacity reserved (MW), lease term (5–10 years), power price (indexed or capped EUR/MWh), uptime SLA (99.5–99.95%, force-majeure carve-outs for curtailment/cooling outages), take-or-pay clause (tenant pays for reserved MW even if unused, except during force-majeure events). Get three law firms to confirm enforceability by Month 3 (2027-01-17). (v) By Month 9 (2027-07-17), target at least 150 MW of binding sheets signed, with reservation fees paid into escrow (further evidence of commitment). If only LOIs exist, explicitly flag this as a gate failure and trigger Phase 1 downsize (reduce Phase 1 target to match committed demand, e.g., 250 MW if only 250 MW is signed).

### 2.6.D Consequence

If only LOIs materialize by Month 9 (2027-07-17), lenders will refuse to underwrite Phase 1 EUR 5B–10B capex without proof of contracted revenue. The investment committee will face a choice: (i) downsize Phase 1 to 250–300 MW and wait for demand to grow, (ii) proceed to Phase 1 FID with 500 MW capacity but only 100–150 MW contracted (leaving 300–400 MW on-spec, at developer financial risk), or (iii) pause Phase 1 and re-market the campus. Options (ii) and (iii) are economically deficient and delay returns by 12–24 months. Phase 0 will have spent EUR 400M–750M on infrastructure without revenue certainty, risking a stranded asset if demand does not materialize.

### 2.6.E Root Cause

No anchor tenants have been pre-identified or pre-engaged. The plan assumes that 'parallel anchor-tenant conversations' will occur Months 1–9 (2026-11-17 to 2027-07-17), but provides no evidence that any tenant has expressed interest or agreed to even an LOI. The commercial-lead action is to 'issue standard term sheets by Month 2 (2026-12-17),' but term sheets are templates offered by the developer, not evidence of tenant appetite. Tenants respond to term sheets only when (i) they have a credible power or latency need, (ii) competitive alternatives are limited, and (iii) the site offers terms better than rivals. None of these have been established for this project.

---

# 3 Expert: Brownfield Remediation and Environmental Liability Counsel

**Knowledge**: Phase I and II environmental site assessments, soil and groundwater contamination (heavy metals, hydrocarbons, asbestos), liability allocation and seller indemnities, French environmental codes and ICPE permitting, escrow structures and long-term indemnity enforceability

**Why**: Brownfield liability is the least quantifiable cost exposure (EUR 100M–400M if discovered late). Decision 8 and the Phase 0 milestones depend on bounding remediation exposure and allocating liability credibly between the developer, land seller and public bodies. A remediation specialist can design intrusive survey sequencing, validate whether the EUR 0–100M per-parcel cap is realistic, and structure indemnities that lenders will accept.

**What**: Commission and oversee Phase II intrusive surveys (Months 1–3 = 2026-11-17 to 2027-01-17) to bound remediation cost on shortlisted parcels at Cambrai, Dunkirk and Valenciennes. Negotiate liability-transfer agreements with private owners and public bodies (Months 2–4 = 2026-12-17 to 2027-02-17), and establish a EUR 100M–300M Phase 1 reserve that is independently audited. Identify any historical contamination (ordnance, mining, asbestos) that could trigger long remediation timelines and cost overruns.

**Skills**: Phase I/II environmental assessment, soil and groundwater remediation design, ICPE contamination reporting, liability indemnity drafting, escrow administration, French environmental regulation

**Search**: Phase II environmental site assessment France, soil remediation data center, brownfield liability allocation, ICPE contamination

## 3.1 Primary Actions

- Lock the RTE topology decision mechanism by Month 2 (2026-12-17): Issue a dated, formal RTE pre-engineering request by Month 0 (2026-10-17); commission an independent RTE hosting-capacity audit (Month 1 = 2026-11-17); schedule a formal in-person RTE pre-submission meeting by Month 3 (2027-01-17) to obtain a written preliminary-feasibility opinion before the Month 4 (2027-02-17) topology gate. If RTE has not delivered a written opinion by Month 3 (2027-01-17), default to split-campus topology at Month 4 (2027-02-17) and reschedule the RTE recheck to Month 5 (2027-03-17). Document the RTE response and the investment committee's topology choice in writing; do not allow topology to shift during Phase 1 without a formal committee vote and lender dissent notification.
- Develop a complete brownfield liability-allocation framework and template agreements by Month 2 (2026-12-17): Commission a French environmental law specialist to draft template indemnity and escrow agreements for both private sellers and public landowners. Define the 'Remediation Specification and Cost Cap (RSC)' process (Phase II data → site-specific remediation design → cost cap agreed and signed before title transfer). For public landowners, require a 'Certification of Remediation Responsibility (CRR)' allocating all pre-existing contamination to the public body. Fund a dedicated Phase 1 remediation reserve (EUR 100M–200M) held in third-party escrow. By Month 4 (2027-02-17), confirm that at least 70% of optioned parcels have either a signed RSC (private) or CRR (public) with a documented remediation cost ceiling; make this a hard Phase 0 gate requirement at Month 12 (2027-10-17). Do not proceed to Phase 1 FID unless remediation liability is fully allocated and funded.
- Commission a rigorous thermal-design validation and PUE stress test by Month 0 (2026-10-17); lock the cooling-design decision by Month 4 (2027-02-17): Engage a thermal-engineering specialist immediately to model PUE vs. ambient temperature (range 15–35°C) using vendor dry-cooler performance curves and Hauts-de-France July–August weather normals. Test three rack-density scenarios (100, 150, 200 W/m²). If modelled PUE at 35°C exceeds 1.30 in the baseline scenario (150 W/m², typical AI density), trigger an immediate design review (Month 2–3 = 2026-12-17 to 2027-01-17): hybrid cooling with capped water use, density reduction to 100 W/m², or immersion-pilot cost accrual. Require lenders to approve the PUE forecast by Month 9 (2027-07-17); if lenders demand margin uplift or efficiency upgrades, fund those upgrades or reduce Phase 1 capacity and rework the financing model. Set a binding cooling gate at Month 12 (2027-10-17): forecast stabilized PUE must be at most 1.30 (or lenders must have pre-approved a higher PUE with margin adjustment), and Phase 1 DSCR must remain above 1.30x under the worst-case PUE scenario. Do not advance to Phase 1 FID if cooling performance is unvalidated or if DSCR falls below 1.30x.

## 3.2 Secondary Actions

- Clarify the USD hardware financing scope and FX hedge strategy by Month 1 (2026-11-17): The canonical facts note 'OPEN DECISION: whether the user's EUR 5B–10B includes' USD GPU/TPU and networking hardware (EUR 1.5B–2.3B). Resolve this immediately: either exclude hardware from the EUR 5B–10B cap and finance it separately through tenants or a lessor (preferred, per the canonical facts), or include it and commit to a separate FX-hedging budget. If hardware is financed by tenants/lessor, develop standardized rack-interface specifications (power density, liquid-loop coupling) by Month 2 (2026-12-17) and include them in take-or-pay lease templates. If developer-side hardware procurement is required, lock a tenant-matched forward-contract and FX-hedge strategy by Month 3 (2027-01-17); hedge ratio 0.5–1.0, cost 0.5–2% per annum. Do not allow hardware to be purchased ahead of signed take-or-pay commitments.
- Establish a formal contingency-decision framework if grid capacity or land assembly falls short by Month 3 (2027-01-17): Define in writing what the investment committee will do if (a) RTE offers only 250 MW at Cambrai, (b) at least 70% of single-square parcels cannot be optioned non-coercively, or (c) BrownField liability on >30% of candidate parcels exceeds EUR 100M per site. Specific scenarios: 500 MW single-node at Cambrai, 750 MW split-campus (Cambrai 500 MW + Dunkirk 250 MW), 500 MW split (250 MW Cambrai + 250 MW Dunkirk), or 250 MW pilot (single node, Cambrai). For each scenario, prepare a capex and schedule estimate and a financing assumption. At Month 12 (2027-10-17) gate, the committee votes on which scenario to pursue for Phase 1; do not allow cost overruns or timeline slips to drive an unplanned downsize.
- Develop a parallel ANSSI/DGSI engagement roadmap and security-design baseline by Month 1 (2026-11-17): Do not wait for Phase 1 FID to engage national-security authorities. Schedule the Month 0 (2026-10-17) confidential pre-submission meeting with ANSSI/DGSI; have the sponsor CEO and legal/security leads present a 10–15 page white paper covering tenant types, data residency, foreign co-investor structure, anticipated security posture and governance. Request ANSSI's initial reading by Month 1 (2026-11-17). Commission a French security consultant to draft a high-assurance security-design roadmap (baseline perimeter, cyber-OT separation, supply-chain vetting, personnel clearance) by Month 2 (2026-12-17); cost EUR 500K–1.5M. Share the roadmap informally with ANSSI by Month 3 (2027-01-17) to gather feedback. At Month 6 (2027-04-17), obtain a written ANSSI preliminary opinion confirming that formal security review can begin within 1 month of Phase 1 FID submission, with a target 12–18 month clearance timeline. If ANSSI signals a timeline >18 months or blocking concerns, escalate to the investment committee at Month 6 (2027-04-17); do not lock anchor-tenant demand (which may be contingent on security clearance) until ANSSI confirms the pathway is viable.
- Lock anchor-tenant take-or-pay mechanics and demand-validation process by Month 2 (2026-12-17): Develop standardized take-or-pay lease templates covering capacity (50–500 MW), term (5–10 years), reservation fee (EUR 10M–50M per 100 MW, credited to rent), power price (indexed or capped), SLAs (99.5–99.95% uptime), and curtailment exceptions. Distinguish binding term sheets from non-binding LOIs in writing; only binding sheets count toward the Phase 0 gate. Launch parallel conversations with 2–3 hyperscalers and 2–3 sovereign/EU anchors by Month 1 (2026-11-17). By Month 7 (2027-05-17), collect LOIs as market signals (do not announce them as demand commitments). By Month 9 (2027-07-17), execute binding term sheets for at least 300 MW (30% of 1 GW) with investment-grade or parent-guaranteed counterparties. If fewer than 300 MW is signed by Month 9 (2027-07-17), reduce Phase 1 target and defer Phase 2 until demand strengthens; do not proceed to Phase 1 FID with unmatched capacity.
- Finalize the community-benefit agreement and stakeholder endorsement by Month 6 (2027-04-17): Establish a municipal liaison committee by Month 1 (2026-11-17) with mayors, regional councillors, farm representatives and NGOs; meet quarterly. Commission a social-impact study (Month 1 = 2026-11-17; EUR 300K–600K) interviewing farmers, residents and NGOs to identify and prioritize concerns. Draft the community-benefit agreement by Month 5 (2027-03-17) with specific EUR commitments (EUR 50M–150M to municipalities over Phases 1–2, EUR 15,000–25,000/ha relocation for displaced farmers, ecological restoration EUR 200M–300M, local employment EUR 10M–30M training, infrastructure upgrades EUR 10M–30M). Target signatures from 2 of 3 key municipalities by Month 9 (2027-07-17); make these signatures a Phase 0 gate requirement at Month 12 (2027-10-17). If 2 of 3 municipalities do not sign, escalate to the investment committee; social-license failure is a valid kill criterion.
- Establish a water-authority engagement and dry-cooling validation pathway by Month 1 (2026-11-17): Commission a regional hydrological study (Month 1 = 2026-11-17; EUR 500K–1.2M) covering surface/groundwater availability, drought frequency, current industrial use and summer low-flow periods at candidate sites. By Month 4 (2027-02-17), obtain published dry-cooler performance curves from at least 4 vendors; conduct site-specific thermal modelling (Month 5 = 2027-03-17). By Month 6 (2027-04-17), obtain a written water-authority opinion from the DDT/DDTM and Agence de l'Eau Artois-Picardie confirming that closed-loop liquid cooling with dry coolers is permissible at 1 GW scale with no material impact on drinking water or drought response. If water authorities express concerns, budget remediation (sound barriers, cooler relocation) or trigger a hybrid-cooling design pivot (Month 7 = 2027-05-17 onward). Make the water opinion a Phase 0 gate requirement at Month 12 (2027-10-17).

## 3.3 Follow Up Consultation

Next consultation should address: (1) RTE's actual connection-queue position and preliminary-feasibility timeline at candidate Hauts-de-France substations (Cambrai, Dunkirk, Valenciennes); (2) vendor dry-cooler performance curves and first-pass thermal-model output for the 35°C design-day scenario; (3) Phase II soil/groundwater contamination results from the top 2–3 candidate parcels and preliminary seller/public indemnity feedback; (4) anchor-tenant feedback from the Month 7–9 (2027-05-17 to 2027-07-17) binding-sheet negotiations (which tenants are moving toward commitment, and what specific conditions are blocking others); (5) municipal and farm-sector response to the draft community-benefit agreement (any blocking objections, desired EUR adjustments, or additional conditions); (6) ANSSI's informal feedback on the security-design roadmap and preliminary opinion on whether the foreign co-investor structure requires modification; (7) preliminary fiber-route audit results confirming at least 2 audited diverse paths per hub; (8) lender pre-commitments (debt appetite, margin, tenor, conditions) from at least 2 senior lenders by Month 9 (2027-07-17). At Month 12 (2027-10-17), the investment committee will vote on Phase 1 FID or pivot based on these eight domains; each domain must have clear evidence (pass/fail, not ambiguous) to support the decision.


## 3.4.A Issue - Brownfield liability allocation is under-scoped and dangerously deferred

The plan treats brownfield liability as a Phase 0 gate item (Month 6 = 2027-04-17) with Phase II surveys by Month 3 (2027-01-17), but does not specify how liability is actually allocated or enforced across Hauts-de-France's complex parcel matrix. The canonical facts state 'seller/public indemnity or escrow EUR 50M–250M' and 'Phase 1 reserve EUR 100M–300M', but do not address: (i) which counterparties will sign 10–15-year indemnities backing that escrow, (ii) creditworthiness of public bodies offering indemnities, (iii) what triggers remediation commencement and who pays if it overruns, (iv) how Phase I and Phase II data are reconciled into a final liability cap per parcel before option/purchase commitment, and (v) mechanism for handling contamination discovered during construction at depths below the surveyed 2-meter boundary.

### 3.4.B Tags

- liability_allocation_incomplete
- escrow_enforceability_uncertain
- post_survey_discovery_protocol_missing
- public_body_credit_unvetted

### 3.4.C Mitigation

By Month 2 (2026-12-17), commission a French environmental law specialist to draft a template liability-allocation agreement for both private sellers and public bodies. For private sellers: purchase-and-sale with recapture (if remediation exceeds Phase II estimate by >20%, seller adds funds up to 1.5× estimate). Require Phase II data reconciliation into a final 'Remediation Specification and Cost Cap' (RSC) document signed by both parties before title transfer. For public bodies: written 'Certification of Remediation Responsibility' (CRR) allocating all pre-existing contamination to the public authority and requiring their written approval of any new remediation methods before Phase 1 construction. Fund a dedicated Phase 1 remediation reserve (EUR 100M–200M) in a third-party-controlled escrow. By Month 4 (2027-02-17), have final RSC or CRR on at least 70% of optioned parcels, tied to the environmental gate.

### 3.4.D Consequence

Without clear, signed liability allocation and a funded escrow, Phase 1 construction halts 3–6 months after discovery of unexpected contamination (e.g., deeper groundwater plume, asbestos in utility corridors, munitions residue). Remediation costs of EUR 100M–400M (per the canonical facts risk estimate) become a lender covenant breach, triggering acceleration and equity cure demands. Disputes with sellers or public bodies over 'pre-existing' vs. 'newly discovered' contamination consume 1–2 years of executive bandwidth and consume EUR 10M–50M in legal fees. Tenants delay capacity commitments pending remediation certainty. Phase 1 energization slips from Month 42 (2030-04-17) to Month 48+ (2030-10-17+), adding EUR 200M–500M in carrying cost and eroding RTE queue position.

### 3.4.E Root Cause

The plan conflates Phase 0 survey completion with Phase 0 liability gate closure, but does not detail the contractual path from 'Phase II complete' to 'indemnity signed and funded.' Public landowners (Dunkirk port, Cambrai municipal land) may resist binding indemnities or may have statutory limits on their ability to honor them. Sellers on private parcels may require insurance backstop or recapture clauses that conflict with the developer's long-term hold. The plan names the reserve (EUR 100M–300M) but leaves the allocation mechanism (holdback, escrow, third-party insurance) blank.

## 3.5.A Issue - Dry-cooler PUE stress test is absent; hot-weather cooling failure is the hidden cost driver

The plan states a PUE target of 1.15–1.25 and commits to 'Phase 0: modelled PUE above 1.30 on a 35°C design day triggers design review,' but the Phase 0 schedule (canonical facts) does not resource a rigorous thermal model until Month 5 (2027-03-17), and the water-authority opinion due Month 6 (2027-04-17) provides no guarantee that dry-cooler performance will be acceptable to lenders or tenants. The plan notes that 'hot-weather PUE may reach 1.35–1.5,' adding '5–15% peak grid load,' but does not quantify the revenue or DSCR impact, nor does it address what triggers the design pivot if this threshold is breached late.

### 3.5.B Tags

- cooling_pue_unvalidated
- hot_weather_stress_case_missing
- lender_requirement_undefined
- thermal_design_review_late

### 3.5.C Mitigation

By Month 0 (2026-10-17), engage a thermal-engineering firm (e.g., CLR Consulting, Thermal Design Group) to conduct a pre-Phase-0 PUE sensitivity model using historical Hauts-de-France weather (July–August peaks 32–35°C, 40–60% relative humidity) and published dry-cooler performance curves from at least 4 manufacturers (Thermax, Hydac, Modine, SPX Cooling). Test three scenarios: (i) 150 W/m² nominal rack density (typical AI), (ii) 200 W/m² aggressive packing, (iii) 100 W/m² conservative. Output: PUE vs. ambient temperature and vs. cooler area footprint. Set a hard design gate (Month 4 = 2027-02-17): if baseline scenario yields modelled PUE >1.30 at 35°C, immediately explore hybrid cooling (indirect evaporative + dry, capped at 5 mm/yr water) or reduce Phase 1 density to 100 W/m² and recalculate capex. Require lenders to confirm (Month 9 = 2027-07-17) that forecast PUE of 1.28–1.32 is acceptable for debt tenor, or trigger a EUR 500M–1B cost mitigation plan (efficiency upgrade, density reduction, or hybrid cooling pilot cost).

### 3.5.D Consequence

If thermal validation is deferred to Month 5 (2027-03-17) and PUE is found to be 1.35–1.40 at 35°C, the design-review pivot (Month 6 = 2027-04-17 onward) consumes 2–4 months and adds EUR 200M–500M capex (hybrid-cooler retrofit, land acquisition for larger cooler area, or immersion-pilot sunk cost). Peak electrical load forecast rises by 5–15%, straining RTE curtailment assumptions and triggering load-shedding risk in hot years. Lenders demand a 100–150 bps margin uplift (EUR 100M–150M NPV cost) or refuse to advance unless efficiency measures are proven and funded. Tenants downgrade uptime SLAs from 99.95% to 99.5% or demand curtailment-discount pass-through that reduces lease revenue by EUR 50M–100M/yr. Phase 1 DSCR falls below the 1.30x lender minimum.

### 3.5.E Root Cause

Dry-cooler performance in Hauts-de-France's summer peak (35°C ambient, typical inland France in July–August) is dominated by air-side heat-exchanger approach temperature and fan power consumption. The plan assumes three-vendor benchmarking and site-specific modelling (Month 5 = 2027-03-17), but does not specify: (i) what vendor performance curves will be tested (only three manufacturers named: Thermax, Hydac, Modine; no confirmation they have committed demo units), (ii) tolerance for PUE >1.30 before design reversal is required (the canonical facts say 'triggers review,' not 'triggers pivot'), and (iii) how lenders will underwrite debt if stabilized PUE is forecast at 1.28–1.30 when the project target is 1.15–1.25. Immersion cooling (50–100 MW pilot) is treated as 'optional' upside, but pilot failure costs EUR 50M–100M against uncertain demand.

## 3.6.A Issue - RTE grid-hosting capacity gate is technically fragile and lacks contingency mechanics

The plan designates RTE hosting capacity above ~1 GW as 'the primary kill test,' with the Phase 0 gate requiring 'RTE written preliminary feasibility letter for at least 500 MW within 36 months of the connection request, due by Month 6 (2027-04-17).' However, the canonical facts note that the RTE letter is 'uncontrolled until RTE signs' and that the topology decision must lock by Month 4 (2027-02-17)—two months before the RTE written evidence is due. This contradiction makes the topology choice (single square vs. split campus) a timing accident rather than evidence-based. Additionally, the plan does not address: (i) what happens if RTE offers only 250 MW at Cambrai and mandates a split-campus topology, (ii) how 'preliminary feasibility' differs from a firm connection offer and whether preliminary letters carry schedule or price commitments, (iii) the cost and timeline of grid-reinforcement co-funding (EUR 500M–1.5B, unquantified scope).

### 3.6.B Tags

- topology_gate_timing_incoherent
- rte_preliminary_vs_firm_undefined
- grid_reinforcement_cost_scope_open
- contingency_if_rte_refuses_missing

### 3.6.C Mitigation

By Month 0 (2026-10-17), issue a formal, dated RTE pre-engineering request (not email; certified mail with receipt) specifying: (i) 500 MW, 1 GW, 2 GW and 3 GW scenarios, each with maximum PUE and average load profile, (ii) desired energization windows (Months 42–48 = 2030-04-17 to 2030-10-17 for 500 MW Phase 1), and (iii) request for a preliminary feasibility response by Month 2 (2026-12-17) and a full prefeasibility study (including substation siting and network reinforcement scope/cost) by Month 5 (2027-03-17). Commission an independent RTE hosting-capacity audit (canonical facts: EUR 1M–2M) with a grid specialist who will verify RTE's claims through third-party network modelling. At Month 3 (2027-01-17), hold a formal RTE pre-submission meeting in person (RTE's primary grid office in Lille), presenting the Phase 0 topology scenarios and requesting a written preliminary opinion (not LOI, but a signed technical memo) on: (a) which node(s) can support 500 MW, (b) estimated timeline from connection request to energization per node, (c) annual curtailment allowance (propose max 10%, walk-away 15%), (d) developer's cost share for substation and transmission reinforcement, and (e) any conditions (BESS, demand-side flexibility, interruptible contracts) required. At Month 4 (2027-02-17), lock topology only if: RTE has provided the written preliminary opinion (if not, default split campus and set Month 5 = 2027-03-17 as the recheck date), and at least 70% of the chosen topology's parcels are optioned. Set a binding RTE gate at Month 12 (2027-10-17): a firm connection offer for at least 500 MW must be signed, or Phase 1 is reduced to the contracted MW RTE offers, or the project is paused until RTE capacity improves.

### 3.6.D Consequence

If RTE delivers a preliminary-feasibility response at Month 4 (2027-02-17) stating that only 250 MW can be accommodated at Cambrai (due to competing industrial loads or network constraints), and recommends a three-node split topology (Cambrai 250 MW, Dunkirk 250 MW, Valenciennes 250 MW), the single-square topology is retroactively invalidated. The investment committee faces a choice: (i) downsize Phase 1 to 250 MW at Cambrai (halving revenue and breaching tenant demand expectations), (ii) embrace the three-node split (adding EUR 250M–500M capex, 6–12 months to first energization, and splitting operations across three grid connections), or (iii) pivot to a different location entirely. If the choice is a split campus, Phase 0 has already consumed EUR 250M–400M in parcel options, surveys, and design work based on a single-square assumption that is now invalidated. The investment committee must choose between sunk-cost losses (write off EUR 200M–300M) or capital addendum (commit additional EUR 250M–500M). Without a pre-agreed contingency decision framework, this becomes a paralysis point that delays Phase 1 FID by 3–6 months and erodes RTE queue position to later applicants.

### 3.6.E Root Cause

The plan's internal timeline is misaligned: it locks the topology decision at Month 4 (2027-02-17) based on parcel optionability and a RTE written letter that is not due until Month 6 (2027-04-17). The resolution is to default to split campus at Month 4 (2027-02-17) and keep single-square alive 'only if RTE written evidence is already in hand,' but this presumes RTE will deliver its letter by Month 3 (2027-01-17)—a 3-month acceleration with no contingency if RTE's pre-engineering studies are incomplete. Moreover, the plan conflates 'preliminary feasibility' (an informal opinion that RTE can accommodate the load) with a 'firm connection offer' (a contract that locks capacity, price, curtailment terms and timeline). RTE standard timelines for multi-GW pre-engineering and network modelling often run 6–12 months beyond the initial request, and RTE's published queue position requests (e.g., at Haut-Picardie 400 kV substations) may already include competing loads from steel, refinery, hydrogen and data-center applicants.

---

# 4 Expert: Independent Investment Committee and Gate-Governance Architect

**Knowledge**: Megaproject investment gating, sunk-cost governance, numerical kill criteria and override procedures, lender and co-investor reporting, red-team commissioning, independent decision-making under uncertainty

**Why**: Decision 5 (Gate Governance) is the structural lynch-pin that enforces the plan's skeptical tone and prevents sunk-cost pressure from overriding stated kill criteria. Without an independent investment committee and credible kill thresholds, the project will revert to speculative momentum. A governance specialist can charter the committee, lock numeric thresholds in writing by Month 2 (2026-12-17), and design the dissent-reporting and override procedure that makes gates enforceable rather than negotiable.

**What**: Design and charter the independent investment committee (at least 2 external directors, lender and co-investor observers) by Month 1 (2026-11-17). Lock numeric kill thresholds for RTE, land assembly, anchor tenants, ANSSI, water and financing in writing by Month 2 (2026-12-17). Commission an external red team (EUR 2M–5M) to publish monthly pass/fail opinions independent of the development team, with findings reported directly to the committee and dissent disclosed to lenders.

**Skills**: Megaproject governance, risk-committee charter and bylaws, numerical gate criteria design, sunk-cost discipline, lender/investor reporting, red-team management, independent decision authority

**Search**: megaproject investment committee governance, kill criteria framework, independent gate authority, sunk cost override procedure

## 4.1 Primary Actions

- By Month 1 (2026-11-17), execute a signed investment committee charter specifying composition (≥2 external independent directors, lender observer, red-team lead), voting rules (two-thirds supermajority for override, single external-director veto power), numeric kill thresholds locked in writing (RTE ≥500 MW by Month 6 = 2027-04-17, ≥70% land optioned by Month 4 = 2027-02-17, ≥30% anchor-tenant take-or-pay by Month 9 = 2027-07-17, ANSSI pathway by Month 6 = 2027-04-17), and mandatory dissent-publication protocol to all lenders and co-investors within 5 business days of any gate vote with dissent recorded. Have external counsel and chief lenders review and approve the charter before signature. This is the enforcement mechanism that makes kill criteria binding rather than advisory.
- Resequence the topology decision from Month 4 (2027-02-17) to Month 6.5 (2027-05-02), timed to land one week after RTE's written letter arrives (Month 6 = 2027-04-17). At Month 4 (2027-02-17), hold an 'interim topology check' confirming ≥70% of both single-square and split-campus parcel geometries are optionable in parallel; do not force a default pivot. When RTE's letter arrives at Month 6 (2027-04-17), use it as the decisive input for the Month 6.5 (2027-05-02) formal topology lock. If RTE's response is delayed beyond Month 6 (2027-04-17), extend the decision gate to Month 8 (2027-06-17) rather than guessing. Document the decision and rationale in writing to the investment committee before any design commitment is made.
- By Month 9 (2027-07-17), deliver a detailed Phase 1 cost build-up that assigns every identified cost line (grid reinforcement, remediation, ecology, fiber, security, subsea) to either the EUR 5.0B base case, a contingency reserve with stated probability, or a risk-transfer mechanism (insurance, seller indemnity, public grant). Revise the Phase 1 ceiling upward to EUR 8.0B (for 500 MW) or downsize the scope to stay within EUR 10B total. Do not proceed to FID (Month 12 = 2027-10-17) without written agreement from lenders and co-investors on the full cost stack and its funding sources. If revised cost exceeds EUR 10B, propose a 375–450 MW downsized Phase 1 to fit within the ceiling.

## 4.2 Secondary Actions

- Commission an independent RTE hosting-capacity audit by Month 1 (2026-11-17) from a grid-engineering specialist with no financial interest in the project. Require the auditor to verify RTE's technical feasibility claims through network modelling and to publish findings (anonymized for confidentiality if needed) by Month 9 (2027-07-17). This provides the investment committee with third-party validation of RTE's estimates and reduces reliance on RTE's self-assessment.
- Draft and circulate the investment committee kill-threshold document by Month 2 (2026-12-17), specifying the exact decision rule for each threshold: e.g., 'RTE must provide a written preliminary feasibility letter confirming ≥500 MW available within 36 months of connection request; if the letter does not arrive by Month 6 (2027-04-17), the committee will request a formal status from RTE and, if no response by Month 7 (2027-05-17), will default to split-campus topology.' This removes ambiguity about what constitutes a 'pass' and when the trigger is pulled.
- Establish a red-team monthly reporting cadence by Month 1 (2026-11-17), with the red-team lead reporting directly to the investment committee (not through the sponsor's project office). Require the red team to publish a one-page monthly summary for each gate criterion: (i) RTE hosting capacity status, (ii) land-optionability progress, (iii) anchor-tenant demand signal, (iv) permitting and ANSSI timeline status, (v) financing market appetite, (vi) overall risk trajectory. Each report should carry an explicit pass/fail or conditional-pass assessment. Disseminate these reports to lenders and co-investors monthly.
- By Month 3 (2027-01-17), prepare a formal fallback and downsizing scenario analysis for each topology outcome: (i) single square stays viable if RTE confirms ≥1 GW and ≥70% parcel optioned; (ii) split-campus becomes the base case if RTE offers <1 GW or <70% of single-square parcel is optionable; (iii) 250–375 MW downsized Phase 1 is triggered if grid capacity, tenant demand or financing fall short of the 500 MW assumptions. For each scenario, calculate revised capex, timeline, and Phase 2 FID conditions. Present these scenarios to the investment committee by Month 4 (2027-02-17) so that Month 6.5 (2027-05-02) topology decision can reference pre-agreed downsizing rules rather than making them up under pressure.
- Schedule formal gate-review meetings at Month 6 (2027-04-17), Month 9 (2027-07-17), and Month 12 (2027-10-17) with the full investment committee, lenders, and co-investors in attendance. At each meeting, present: (i) the red team's pass/fail opinion on each criterion, (ii) any dissent from external directors, (iii) revised cost and timeline estimates, (iv) trigger decisions (proceed, proceed conditionally, pause, downsize, cancel). Document the decision and any dissent in writing within 5 business days, and require all dissenting opinions to be shared with lenders. This creates a formal record of gate discipline and prevents post-hoc reinterpretation of threshold breaches.
- Negotiate a formal standstill agreement with the primary lender by Month 3 (2027-01-17) that commits the lender to a written term sheet by Month 12 (2027-10-17), provided that all four gate criteria (RTE, land, tenants, ANSSI) receive a pass or conditional-pass. If any criterion receives an explicit fail (e.g., RTE cannot offer >250 MW), the lender agrees to either downsize the loan to fit reduced scope or release the sponsor from commitment. This binds the lender to the gate discipline and prevents late-stage financing surprises.
- Engage the co-investor consortium by Month 2 (2026-12-17) to confirm that each co-investor understands and accepts the kill thresholds and downsizing scenarios. Obtain written acknowledgment from each co-investor that Phase 1 equity will not be committed ahead of a formal pass from the investment committee, and that a conditional pass (e.g., RTE ≥500 MW but ≥1 GW unconfirmed) will trigger downsizing to fit available capacity, not force-feeding of contingency. This prevents political pressure from co-investors to override thresholds.

## 4.3 Follow Up Consultation

In the next consultation, plan to discuss: (1) the final investment-committee charter and its approval by lenders and co-investors (target Month 1 = 2026-11-17); (2) the Month 4 (2027-02-17) interim topology check results and the evidence stack approaching the Month 6.5 (2027-05-02) topology lock; (3) the detailed Phase 1 cost build-up and revised ceiling, with lender and co-investor sign-off on the full cost stack by Month 9 (2027-07-17); (4) any RTE, ANSSI, tenant or financing surprises that emerge during Phase 0 and how they are being managed against the pre-agreed kill thresholds. If any gate criterion breaches the threshold between now and Month 12 (2027-10-17), escalate immediately to the investment committee and prepare a downsizing or cancellation recommendation, rather than allowing sunk-cost pressure to override the gates.


## 4.4.A Issue - Investment Committee Charter and Gate Authority Are Not Yet Binding; Sunk-Cost Override Risk Is Unmitigated

The plan calls for 'an independent investment committee separate from the development team' (Decision 5) with 'numeric kill thresholds' by Month 2 (2026-12-17), but the charter document does not exist and no external directors, voting rules, or dissent-reporting obligation has been signed. Without a formal, pre-signed charter with explicit override authority rules before capital drawdown begins, board-level inertia, sponsor momentum and sunk-cost pressure will routinely override stated thresholds. This is the single most common failure mode in mega-project gating.

### 4.4.B Tags

- gate-governance-not-binding
- sunk-cost-discipline-missing
- override-authority-undefined
- charter-not-signed

### 4.4.C Mitigation

Draft and sign the investment committee charter document before Month 1 (2026-11-17) first drawdown, specifying: (i) composition (minimum 2 external directors with no sponsor financial interest, chief lender representative, external red-team lead, observer role for co-investor); (ii) voting rule (simple majority for continuation, explicit two-thirds supermajority required for any gate override); (iii) numeric kill thresholds locked in writing (RTE ≥500 MW, ≥70% land optioned, ≥30% anchor-tenant take-or-pay, ANSSI pathway confirmed); (iv) veto right: any single external director can require a hold on drawdown pending written committee opinion; (v) dissent protocol: any gate vote with dissent is published to all lenders and co-investors within 5 business days, including the dissenting director's opinion in full; (vi) red-team reporting: monthly pass/fail opinions delivered directly to the committee, not to the sponsor's office. Have external counsel and lenders review the charter before signature. This is non-negotiable for credible gating.

### 4.4.D Consequence

If the committee charter is not signed before Month 1 (2026-11-17) drawdown (EUR 150M tranche 1), the sponsor and co-investors retain de facto control over gate decisions. When evidence at Month 12 (2027-10-17) is ambiguous (e.g., RTE letter says '500 MW possible but with 20% curtailment'), the board pressure to proceed with Phase 1 will override the stated 10% curtailment threshold, and lenders and co-investors will discover too late that they have no enforceable kill authority. A Phase 1 FID forced through weak gates risks EUR 2B–5B loss if demand or grid fails post-commitment.

### 4.4.E Root Cause

The plan assumes gate discipline will be self-enforcing once stated, but does not require the committee charter, voting rules, or dissent protocols to be drafted, negotiated and signed before Phase 0 capital is released. Sponsors routinely treat 'kill criteria' as guidelines rather than law. The investment committee exists in the plan but not yet in reality, and its authority to block Phase 1 FID depends on external directors and supermajority override rules that have not been written or agreed.

## 4.5.A Issue - Topology Decision Timing Flaw: Month 4 (2027-02-17) Decision Locked Before Month 6 (2027-04-17) RTE Letter Arrives

The plan calls for the topology decision (single 161 km² square vs. split-campus) to be locked at Month 4 (2027-02-17), but the RTE written preliminary feasibility letter (the decisive input) is not due until Month 6 (2027-04-17). This timing is backwards: the decision is forced two months before the main evidence arrives. The plan acknowledges this weakness ('split campus is the default at Month 4 = 2027-02-17 and the single square can be kept alive only if RTE written evidence is already in hand'), but does not fix it. In practice, if RTE has not replied by Month 4 (2027-02-17), the default to split-campus forces Phase 0 redesign and replanning without evidence that a single square was truly infeasible.

### 4.5.B Tags

- topology-decision-premature
- evidence-timeline-misaligned
- rte-response-uncontrolled
- default-pivot-untested

### 4.5.C Mitigation

Resequence the topology decision gate: push the formal topology lock to Month 6.5 (2027-05-02), timed to land one week after the RTE letter is due (Month 6 = 2027-04-17). Call the Month 4 (2027-02-17) event a 'topology interim check' only, where parcel optionability (≥70% non-coercive assembly) is confirmed for both single-square and split-campus geometries in parallel. Do not force a default; instead, issue a statement: 'Single-square design continues at risk pending RTE response; split-campus designs in parallel.' When RTE's written letter arrives at Month 6 (2027-04-17), use it immediately to inform the Month 6.5 (2027-05-02) formal decision. This preserves flexibility and avoids a false commitment to split-campus before the evidence is in hand. If RTE response is delayed beyond Month 6 (2027-04-17), extend the decision gate to Month 7 (2027-05-17) or Month 8 (2027-06-17) rather than guessing.

### 4.5.D Consequence

If RTE delays or sends a conditional response (e.g., '500 MW yes, but 1 GW contingent on the 2028 reinforcement'), the Month 4 (2027-02-17) decision rule forces a split-campus pivot without evidence that a single square would have been rejected. This adds EUR 250M–500M capex and 6–12 months of redesign cost at a point when land options and permitting pre-work are already underway, increasing sunk cost before the real gate (Month 12 = 2027-10-17) closes. Worse, if RTE's letter does arrive on time with firm 1 GW confirmation, the split-campus default may have already been announced, politicizing the reversal and eroding credibility with municipalities and landowners.

### 4.5.E Root Cause

The Month 4 (2027-02-17) date was set to allow Phase 0 cost containment and design lock, but the RTE response timeline (which is uncontrolled and often takes 4–8 months for preliminary hosting-capacity opinions) was not built into the decision gate. The plan treats RTE's written letter as a binary pass/fail, but utilities rarely issue firm letters on schedule. A conditional or partial response (e.g., 'we can study 500 MW but full 1 GW is in the queue and unresolved') will force ambiguous judgment at Month 4 (2027-02-17), and the default-to-split-campus rule may trigger prematurely.

## 4.6.A Issue - Phase 1 Budget Ceiling Headroom Is Overcommitted; Stacked Contingent Add-Ons Total EUR 1.55B–4.2B Against Only EUR 5B Available Headroom

The Phase 1 budget plan assumes EUR 5B–10B total envelope, with the 500 MW base case at EUR 5.0B. However, identified contingent cost lines (grid co-funding EUR 0.5B–1.5B, brownfield remediation EUR 0.1B–0.4B, ecological compensation EUR 0.2B–0.3B, fiber build-out and submarine EUR 0.2B–0.6B, split-campus premium EUR 0.25B–0.5B, permitting and ANSSI review delay carrying cost EUR 0.2B–0.5B) total EUR 1.55B–4.2B. These overlap and are not fully funded. If the stacked add-ons land in the middle (EUR 2.8B), the 500 MW case rises to EUR 7.8B—still under EUR 10B, but it consumes the entire headroom and leaves zero contingency for hard-cost overruns, financing cost inflation, or security upgrades. The plan shows awareness of this ('stacked contingent add-ons on 500 MW are EUR 1.55B–4.2B, giving EUR 6.55B–9.2B, still under EUR 10B but overlapping and unfunded') but has not funded the exposure.

### 4.6.B Tags

- budget-headroom-overcommitted
- contingency-unfunded
- cost-line-overlap-unresolved
- ceiling-breach-risk

### 4.6.C Mitigation

By Month 9 (2027-07-17), deliver a detailed Phase 1 cost build-up that separates the EUR 5.0B campus company base into: (i) committed cost lines with ≤5% uncertainty (shell, power connection, main cooling loops, primary fiber to campus edge, perimeter fence): target EUR 4.0B–4.5B; (ii) contingent-but-likely cost lines (grid reinforcement co-share, Phase II remediation, main substation upgrade, secondary fiber routes, ecological mitigation): target EUR 0.8B–1.5B with a 60% probability of occurrence; (iii) low-probability, high-impact exposures (contamination discovery, ANSSI security retrofit, long-haul subsea build, major permitting delay): target EUR 0.2B–0.5B with a 20–30% probability. Assign each line a funding source: base capex (lender + equity), contingency reserve (equity only), or risk transfer (insurance, seller indemnity, public-body grant). Fix a revised Phase 1 ceiling at Month 9 (2027-07-17) (proposed: EUR 8.0B for 500 MW to cover committed + 60% of contingent, still leaving headroom within the EUR 10B user ceiling). Do not proceed to FID without this clarity; if the revised ceiling exceeds EUR 10B, downsize Phase 1 to EUR 7B–8B total (375–450 MW) rather than proceeding with unfunded cost.

### 4.6.D Consequence

If the Phase 1 FID decision is made at Month 12 (2027-10-17) with lenders and co-investors assuming EUR 5B + a small contingency, but the actual cost stack during Phase 1 execution rises to EUR 7B–8B due to RTE reinforcement demands, subsurface surprises, and fiber route complications, the project will face a funding gap mid-construction. This triggers either (i) value-destructive cost cuts (delayed substation upgrades, reduced security, deferred fiber redundancy), (ii) equity top-ups (diluting returns and straining co-investor patience), or (iii) delay and refinancing (pushing energization by 12–24 months and raising carrying cost). A Phase 1 FID that does not account for the full cost stack is not credible to lenders or co-investors.

### 4.6.E Root Cause

The EUR 5B–10B envelope was set in the user constraints as a top-line budget, but the Phase 0 feasibility work has identified many cost items that are not in the EUR 5.0B base (which covers shell, power, cooling, fiber to the campus perimeter, hardened perimeter). Grid reinforcement co-funding, contamination remediation, ecological compensation, and build-out of submarine or long-haul fiber are real costs that are treated as contingent but not explicitly funded. The plan accounts for them in ranges ('EUR 500M–1.5B' for grid; 'EUR 200M–300M' for ecology) but does not assign them to a funding source or decide whether they sit inside or outside the EUR 5B base.

---

# 5 Expert: Fiber and Digital Infrastructure Route Strategist

**Knowledge**: Long-haul fiber deployment, route-diversity auditing, subsea-cable consortia, dark-fiber economics, cross-border interconnect landing points, latency modeling for tightly coupled training clusters

**Why**: Fiber route diversity (Decision 12) is the hidden single point of failure for a distributed campus. Hidden shared ducts, bridges or landings can collapse claimed resilience. The plan requires at least 2 audited physically separate routes per hub by Month 9 (2027-07-17), and landing-point concentration is a specific risk. A fiber specialist can audit carrier claims, model inter-node dark-fiber cost and latency, and validate whether the 50 ms round-trip tolerance for training workloads is realistic.

**What**: Audit the physical routes of candidate carriers' offers to Paris, London, Brussels, Amsterdam and Frankfurt, confirming true duct-level separation and no shared bridges or landing facilities. Estimate developer cost per route-km for owned dark fiber along rail, canal or pipeline corridors (propose EUR 500K–2M per km). Model 50 ms maximum round-trip latency between Cambrai, Dunkirk and Valenciennes nodes and confirm whether tightly coupled training spanning multiple nodes is feasible or if workloads must be node-local.

**Skills**: Fiber route auditing, subsea-cable landing negotiation, dark-fiber procurement and ownership, cross-border interconnect design, latency and jitter modeling, carrier SLA enforcement

**Search**: long-haul dark fiber France UK Belgium, subsea cable consortium Europe, landing point resilience, fiber route audit

## 5.1 Primary Actions

- By Month 1 (2026-11-17), commission a detailed third-party fiber-route audit (Telegeography or equivalent) covering duct-level diversity, shared-facility inventory, and alternative-corridor availability for all routes from Cambrai and Dunkirk to Paris, London, Brussels, Amsterdam, Frankfurt, and Calais subsea landing; budget EUR 100K–200K and require final report by Month 3 (2027-01-17).
- By Month 1 (2026-11-17), launch parallel subsea-cable-consortium audit and non-binding capacity inquiry to at least 2 consortia serving Calais, Dunkirk, and cross-Channel UK landings; identify data-residency constraints for sovereign tenants; target binding capacity reservation (20–40 Tbps for Phase 1) by Month 6 (2027-04-17) to match first-block energization timeline.
- By Month 2 (2026-12-17), conduct detailed tenant-requirements interviews with target hyperscalers and sovereign-AI cohort (Microsoft, Google, Meta, French State AI, CEPI) documenting cluster-size, intra-cluster latency tolerance, and federation feasibility; publish binding latency envelope (10 ms for training, 50 ms for inference, force-majeure >4 hours) in the tenant term-sheet template by Month 2 (2026-12-17).
- By Month 4 (2027-02-17), tie the topology decision (single square vs. split campus) to a formal latency and landing-point feasibility assessment; if split campus is chosen and anchor-tenant latency requirement is <10 ms, escalate to the investment committee with a revenue-adjustment note (estimated 20–30% reduction from inference-only positioning) and a EUR 300M–500M inter-node dark-fiber or subsea-hop contingency cost.
- By Month 9 (2027-07-17), deliver verified fiber-route maps and subsea-capacity confirmations (not just LOIs) to the investment committee as binding evidence for the Month 12 (2027-10-17) fiber gate; include contractual clauses in all carrier agreements requiring disclosure of shared facilities and annual audit rights; if landing-point concentration exceeds 25% on any single facility, trigger a design review and budget a backup dark-fiber route.

## 5.2 Secondary Actions

- Model latency and packet-loss implications for each split-campus pair (Cambrai–Dunkirk, Cambrai–Valenciennes, both simultaneously) under normal operation and under single-route-failure scenarios; share results with anchor-tenant engineering teams during Month 2–3 (2026-12-17 to 2027-01-17) conversations to validate the 50 ms tolerance.
- Negotiate long-term dark-fiber options (not owned, but reserved with build-out rights) along existing transport corridors (rail, canal, pipeline) from Cambrai and Dunkirk to Paris, London, and Benelux hubs; secure corridor access agreements by Month 6 (2027-04-17) so the campus is not dependent on carrier-controlled ducts.
- Establish a fiber-route contingency reserve of EUR 150M–300M (estimate) in the Phase 1 budget cap to cover unplanned dark-fiber builds or subsea-hop costs if carrier-provided diversity is found to be unacceptable during final design (Month 18–24 = 2028-04-17 to 2028-10-17).
- Create a cross-functional fiber-working group (campus operator, carriers, subsea consortia, tenants) by Month 2 (2026-12-17) to meet quarterly and review actual duct-utilization, shared-facility risks, and backup-route feasibility; publish a monthly fiber-status report to the investment committee.
- Audit all carrier-provided SLAs (uptime, restoration time, force-majeure clauses) for consistency with tenant requirements; if a carrier SLA specifies >4 hours restoration time or includes carrier-wide shared-duct force-majeure, require backup capacity (dark fiber or secondary carrier) or accept a lease-price discount (EUR 5M–20M per 100 MW annually, estimate) to reflect the reduced reliability.

## 5.3 Follow Up Consultation


At the next consultation (Month 2 = 2026-12-17), bring the completed tenant-requirements table (latency tolerance vs. workload type, cluster-size range, federation feasibility) and the preliminary subsea-consortium findings (landing points, capacity, booking timelines, data-residency constraints). Review the draft fiber-route audit for completeness and duct-level detail; confirm that at least two independent carrier-neutral landing points are being evaluated for each cross-border route. Discuss the topology-latency trade-off: if anchor tenants need <10 ms intra-cluster connectivity, assess whether a single-node Cambrai-only design is preferable to a split campus, or whether the project should accept inference-only revenue and adjust the financial model. Clarify the subsea-capacity-booking timeline: if consortia slots fill up 18–36 months in advance, the capacity inquiry must be filed no later than Month 3 (2027-01-17) to secure Phase 1 activation. Finally, review the fiber-contingency budget and confirm that EUR 150M–300M is available in the Phase 1 cap to cover unplanned dark-fiber or subsea-hop costs without breaching lender covenants.


## 5.4.A Issue - Fiber route diversity strategy lacks physical audit rigor and landing-point concentration risk is underestimated

The plan assumes 'at least 2 physically separate, audited routes' by Month 9 (2027-07-17) but does not specify how that audit is conducted or who certifies duct-level separation. Carrier marketing claims of 'diverse routes' routinely collapse at shared conduits, river crossings, bridges or landing facilities—a single backhoe cut near Brussels or Calais eliminates the claimed diversity. The landing-point gate (at most 25% per landing) is reasonable but unenforceable without contractual commitment. The plan names Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea routes but does not address the latency or fiber-cut probability between Hauts-de-France and each hub, nor does it define which route serves which tenant class (hyperscaler, sovereign, inference).

### 5.4.B Tags

- fiber-route-diversity
- landing-point-risk
- single-point-of-failure
- carrier-audit-gap

### 5.4.C Mitigation

By Month 1 (2026-11-17), commission a detailed fiber-route audit from a neutral third party (propose Telegeography or equivalent) covering: (i) duct-level maps and shared-facility inventory for routes from Cambrai and Dunkirk to Paris, London, Brussels, Amsterdam, Frankfurt and Calais subsea landing; (ii) probability of joint-trench or shared-bridge sections; (iii) availability of alternative conduits or fiber-lay corridors for each route pair. By Month 3 (2027-01-17), produce a route-diversity map showing which route serves which tenant and what failure modes (cut, landing outage, carrier bankruptcy) reduce capacity below tenant SLAs. Include a contractual clause in carrier agreements requiring disclosure of all shared facilities and annual audit rights. Consider co-investing in 1–2 dedicated dark-fiber builds (e.g., Cambrai–Paris along rail, Dunkirk–Brussels along canal) if carrier audit reveals unacceptable shared-duct risk. Document all route dependencies in the risk register, with contingency fiber-build cost (EUR 100M–300M per 500 km route, estimate) and timeline (18–30 months, estimate).

### 5.4.D Consequence

Without duct-level audit and contractual enforcement, the project risks a single subsea-landing outage (e.g., cable cut near Calais, carrier facility failure) that silences a significant tenant cluster for 6–24 hours. For tightly coupled AI training, even a few hours of latency loss or packet loss forces job replication and can lose a week of training progress. Tenants will refuse to sign take-or-pay unless the fiber SLA is 99.99%+ uptime with restoration <4 hours; a shared-duct failure preventing that forces penalty clauses (EUR 20M–100M annual, estimate) or triggers lease termination. Lenders similarly demand proof of route diversity before debt close. Late discovery of shared conduits during Phase 1 design forces costly reroutes and delays first-block energization by 6–12 months. The plan's Month 9 (2027-07-17) fiber gate is unenforceable without this.

### 5.4.E Root Cause

Fiber connectivity is treated as a secondary lever in the strategic-decisions list, below grid and tenant anchors, so the plan defers detailed route engineering to Phase 1. However, fiber diversity is a prerequisite for multi-gigabit clusters and for resilience claims that tenants and lenders expect. Carriers do not volunteer duct separation data, and shared failures (conduit, bridge, landing) are the most common outage cause in European data-center interconnect. The plan's audit specification is vague ('no shared duct, bridge or landing') but lacks the contractual, physical and operational teeth to enforce it.

## 5.5.A Issue - Inter-node dark-fiber and subsea-cable landing dependencies are not evaluated against cluster-size tolerance and latency envelope is unvalidated

The plan proposes a 50 ms maximum round-trip latency tolerance for split-campus training workloads (Cambrai–Dunkirk or Cambrai–Valenciennes), but this tolerance is not derived from tenant specifications. Published AI training clusters (NVIDIA, Azure, Google TPU) tolerate 1–5 ms intra-rack and 10–20 ms intra-zone latency for synchronous training; 50 ms is typical only for batch inference or fine-tuning, not for large-scale distributed training. If the plan's anchor tenants require <10 ms for training, split campus becomes infeasible without dedicated subsea repeater hops or private-network switching, adding EUR 200M–500M (estimate) and extending Phase 0 by 6–12 months. The plan also does not specify which landing (e.g., Calais vs. UK east coast) serves which inter-node path, or what happens if a subsea-landing facility is unavailable during peak tenant demand.

### 5.5.B Tags

- inter-node-latency
- subsea-landing-dependency
- cluster-size-validation
- training-vs-inference-mismatch

### 5.5.C Mitigation

By Month 2 (2026-12-17), conduct detailed tenant-requirements interviews with the target hyperscaler and sovereign-AI cohort (Microsoft, Google, Meta, French State AI office, EU CEPIs), documenting: (i) largest single-cluster size and intra-cluster latency requirement (propose table of latency tolerance vs. training workload type); (ii) whether split-campus federation is acceptable or whether tenants require contiguous infrastructure; (iii) preferred inter-site link capacity and failover expectations. By Month 3 (2027-01-17), publish a latency and topology-feasibility table showing which split-campus pairs (Cambrai–Dunkirk, Cambrai–Valenciennes, both pairs simultaneously) meet which tenants' cluster requirements, and mark any pairing that requires <15 ms as high-risk (dependent on dedicated subsea or private-network hops). Lock a binding latency envelope (proposed: 10 ms for training, 50 ms for inference, force-majeure exceptions for landing outages >4 hours, estimate) into the tenant term-sheet template by Month 2 (2026-12-17). If anchor-tenant latency is <10 ms and split campus is the default at Month 4 (2027-02-17), escalate to the investment committee with a feasibility note: either revert to single square (if land and RTE support it) or accept that split campus supports inference-dominant tenants only (lower revenue and valuation, estimate 20–30% reduction).

### 5.5.D Consequence

If anchor tenants require <10 ms intra-cluster latency and split campus is imposed at Month 4 (2027-02-17), the project's revenue assumption changes from EUR 550M/year (mixed training and inference) to EUR 385M–440M/year (inference only, estimate 20–30% discount). Debt service on EUR 3B remains EUR 299M, so DSCR falls from 1.34x (stable) to 1.20x–1.28x, below the lender minimum of 1.30x. A second scenario: inter-node dark fiber or subsea-hop costs EUR 300M–500M (estimate) and extends Phase 0 by 6–12 months, breaching the EUR 750M Phase 0 cap and the Month 12 (2027-10-17) gate. Tenants may refuse to commit take-or-pay if latency SLA is uncertain, pushing them to competing European sites (Ireland, Netherlands, Germany) with established subsea-landing diversity. Late discovery that 50 ms is infeasible forces a downsize to a single-node 500 MW (Cambrai or Dunkirk only) and eliminates the 1–3 GW growth plan, capping the addressable market to about EUR 550M/year.

### 5.5.E Root Cause

The topology decision (single square vs. split campus) was chosen at Month 4 (2027-02-17) before tenant cluster-size and latency requirements are known from signed leases (Month 9 = 2027-07-17). The plan assumes 50 ms round-trip is acceptable but does not validate this with hyperscaler engineering teams or with the sovereign-AI anchor consortium. Subsea-cable routing and landing-point capacity planning require 12–18 months of consortium negotiation and capacity booking, so a late latency requirement change forces topology redesign and subsea-contract renegotiation at high cost.

## 5.6.A Issue - Subsea-cable consortium participation and landing-point capacity are treated as passive and uncontrolled; the plan lacks a proactive subsea-cable strategy

The strategic-decisions document briefly mentions 'co-invest with regional operators and a subsea-cable consortium' as an option, but the main plan does not detail which subsea-cable consortia or landing facilities are relevant to Hauts-de-France, or what capacity is currently available on routes to UK, Ireland, Scandinavia and transatlantic hubs. The region's primary landing points are Calais (France Telecom) and possibly Dunkirk (industrial port), but the plan does not audit which consortia serve them, what their capacity-booking timelines are (typically 18–36 months for new consortiums), or what happens if capacity is unavailable during Phase 1 energization. The plan also does not address cross-border landing dependencies: a London-bound route needs both a French landing and a UK landing, and if one is saturated, the entire route fails regardless of the other. Sovereign-AI tenants may require subsea cables with data-residency guarantees (no US-jurisdiction landing) that limit the available consortia to EU–EU or EU–UK pairs only.

### 5.6.B Tags

- subsea-cable-consortium
- landing-point-capacity
- cross-border-gateway
- capacity-booking-timeline

### 5.6.C Mitigation

By Month 1 (2026-11-17), commission a subsea-cable-consortium audit (propose TeleGeography or equivalent) covering: (i) all active and planned consortia landing at Calais, Dunkirk, Marseille and cross-Channel UK points (Dover, Folkestone, Shetland); (ii) available capacity per landing and pre-booking timeline (propose 18–36 months standard); (iii) data-residency clauses and routing restrictions for sovereign tenants; (iv) cost per Tbps and per landing; (v) European competition on London, Amsterdam and Frankfurt routes, with pricing benchmarks. By Month 4 (2027-02-17), submit a non-binding capacity inquiry (NBCI) to at least 2 subsea consortia serving the target landing points, confirming the campus as a potential anchor customer for Phases 1–2 (at least 100 Tbps total capacity by Phase 2). By Month 6 (2027-04-17), negotiate a binding capacity reservation (not a contract, but a booked slot) for Phase 1 (20–40 Tbps proposed, estimate) with a target activation date aligned to first-block energization (about Months 42–48 = 2030-04-17 to 2030-10-17). If no consortium landing is available at Calais or Dunkirk before Phase 1 energization, default to leasing capacity from existing carrier landings (TeleGeography, for example, shows several France–UK pairs at Calais and Marseille) and accept a 20–50% cost premium (estimate) and a shared-duct risk that reduces the fiber gate score.

### 5.6.D Consequence

If subsea-capacity booking is delayed to Phase 1 design (Month 12 = 2027-10-17 or later), the project risks missing a consortium pre-booking window and forcing a 12–18 month wait for the next available slot. This delays first-block cross-border traffic by 18–30 months and forces tenants to route via existing carrier facilities (lower capacity, higher cost, shared-duct risk), reducing the tenant value proposition and lease prices by an estimated EUR 10M–30M per year (estimate 2–5% of lease revenue). For a split-campus design, a second independent subsea route (e.g., Dunkirk–Benelux) is required; the absence of a proactive consortium strategy means the Dunkirk node operates in isolation for 12–24 months post-energization, limiting its tenant pool to those not needing immediate international connectivity (inference and batch processing only, lower revenue). A sovereign-AI tenant with data-residency requirements (e.g., no US-jurisdiction landing) may find that the only compliant routes (EU–EU and EU–UK via non-US operators) are oversubscribed, forcing the tenant to a competing site (Germany, Ireland). The Phase 1 fiber gate (Month 9 = 2027-07-17) cannot be passed without confirmed subsea capacity, so delay of the consortium inquiry to Month 6 (2027-04-17) puts the entire gate at risk 6 weeks before the deadline.

### 5.6.E Root Cause

Subsea-cable capacity planning is delegated to Phase 1 design ('Marseille and subsea added by Phase 2'), treating it as secondary infrastructure. However, subsea capacity booking is the longest-lead item in the fiber strategy: consortia are pre-committed 18–36 months before activation, and landing-point permits can take 12–24 months. A split-campus design with Dunkirk as a secondary node may need an independent subsea route (Dunkirk–UK, Dunkirk–Benelux), which is not included in any current consortium. The plan also does not distinguish between carrier-neutral landings (competitive capacity, lower cost) and carrier-owned landings (restrictive terms, higher cost), so the final subsea-cost assumption remains unvalidated.

---

# 6 Expert: Regional Stakeholder and Municipal Finance Facilitator

**Knowledge**: French municipal and prefectural governance, land-use negotiations with elected bodies, community-benefit agreement structuring, farm-sector engagement (FNSEA, Confédération Paysanne), industrial redevelopment narratives in post-steel regions, cultural and social-license risk in industrial transitions

**Why**: Permitting and social license (Decision 4) and land assembly (Decision 9) require sustained engagement with municipalities, farm unions, NGOs and residents. The plan targets written support from 2 of 3 key municipalities by Month 12 (2027-10-17), and a community-benefit package of EUR 50M–150M must be structured and signed. A municipal-relations specialist can orchestrate the liaison committee, manage farm-sector concerns and validate whether the proposed benefit package is credible and sufficient to overcome organized opposition.

**What**: Establish and chair the municipal liaison committee by Month 1 (2026-11-17) with mayors, farm representatives and NGOs. Commission and present the social-impact study (Month 4 = 2027-02-17). Draft and negotiate the community-benefit agreement (Months 5–9 = 2027-03-17 to 2027-07-17) with binding EUR commitments. Target signatures from 2 of 3 municipalities by Month 9 (2027-07-17). Identify organized opposition risks (e.g., specific farm holdouts or NGOs) and mitigation strategies.

**Skills**: Municipal consensus-building, agricultural-sector negotiation, community-benefit structuring, cultural narrative and reindustrialization messaging, NGO engagement, social-impact assessment facilitation

**Search**: French municipal land negotiations, FNSEA agricultural compensation, community benefit agreement industrial project, regional reindustrialization

## 6.1 Primary Actions

- By Month 1 (2026-11-17), issue formal written RFP to RTE for a phase-of-life hosting-capacity assessment covering 250 MW, 500 MW, 1 GW and 2 GW tranches at Cambrai, Dunkirk, Valenciennes and Saint-Omer substations, with committed timeline (target Month 5 = 2027-03-17) for RTE's preliminary opinion. Simultaneously commission an independent RTE-audit firm (EUR 1M–2M) to validate RTE's findings, so the investment committee has an external check on RTE's claims by Month 6 (2027-04-17).
- By Month 2 (2026-12-17), reschedule the topology decision from Month 4 (2027-02-17) to Month 6.5 (2027-05-02), explicitly dependent on RTE's written 500+ MW letter. Between Months 2–6 (2026-12-17 to 2027-04-17), run parallel land surveys for both single-square (Cambrai 161 km² envelope) and split-campus nodes (Cambrai, Dunkirk, Valenciennes; 8–10 km² each). Budget EUR 20M–30M for dual survey scope. Lock land commitment only after Month 6 (2027-04-17) RTE evidence arrives, not before.
- By Month 2 (2026-12-17), redefine the anchor-tenant 'binding' commitment to require: (i) reservation-fee cash deposit of at least EUR 10M–20M per 100 MW held in escrow and non-refundable after Month 9 (2027-07-17); (ii) liquidated-damages clause of 10–15% of first-year lease revenue if tenant exits between Phase 1 FID and first-block energization; (iii) parent-company guarantee or letter of credit for any tenant rated below BBB−. Identify 2–3 specific anchor tenants by name by Month 5 (2027-03-17) (not generic 'hyperscalers'), conduct cluster-size and latency validation during Phase 0 via a technical benchmark, and execute term sheets with only those anchors whose technical fit is proven. Target cash deposits in escrow by Month 9 (2027-07-17) for no fewer than 200 MW; if only 100–150 MW is committed with cash and guarantees, accept Phase 1 downsize to 250–300 MW rather than forcing a 500 MW build on weak demand.
- By Month 1 (2026-11-17), segregate Phase 0 budget into: (i) EUR 750M base for single-square Cambrai case (as user constraint), and (ii) EUR 250M–500M contingency held separately, approved by co-investors and lenders before spend, for topology pivots or remediation surprises. Require investment-committee sign-off on any contingency drawdown exceeding EUR 25M, with published reason and timeline to gate re-review. If contingency is exceeded, trigger an automatic FID pause and re-baseline decision.
- By Month 6 (2027-04-17), require written sign-off from the investment committee on each of four uncontrolled external gates: (1) RTE 500+ MW preliminary letter (accept conditional 'we will study this further' as a pass, not an absolute yes), (2) water-authority opinion on dry-cooler feasibility at 35°C (accept 'subject to final permitting' as a pass), (3) ANSSI preliminary-review pathway and no-blocking-concern letter (accept 'formal review can begin by Month 13 = 2027-11-17' as a pass), (4) EDF non-binding LOI for at least 500 MW at a capped EUR/MWh or indexed formula (accept 'term sheet by Month 12 = 2027-10-17' as a pass). Publish outcomes to lenders and co-investors within one week. For each gate, define what constitutes a 'conditional pass' (allows Phase 1 FID subject to mitigation) vs a 'fail' (Phase 1 pause or downsize).

## 6.2 Secondary Actions

- Commission a formal grid-reinforcement cost study by an independent transmission consultant by Month 1 (2026-11-17), estimating developer co-funding exposure for 500 MW, 1 GW and 2 GW tranches at each candidate substation. Bound the estimate to +/- 20% by Month 6 (2027-04-17) and publish to lenders as part of the Phase 1 cost model. If RTE's co-funding demand exceeds EUR 1.0B for the first 1 GW, pause Phase 1 and reassess whether Phase 1 should be downsized to 250–500 MW or whether split-campus nodes reduce per-node reinforcement cost.
- By Month 3 (2027-01-17), publish a detailed land-assembly roadmap for each candidate topology, mapping: (i) parcel ID and owner, (ii) estimated acquisition cost at benchmark, premium (if any), and hold-out risk, (iii) option-agreement timeline and conditions, (iv) percentage already optioned and percentage at-risk. For single-square Cambrai, target at least 70% optioned by Month 4 (2027-02-17); for split nodes, target at least 80% optioned by Month 12 (2027-10-17). Flag any parcel or owner where acquisition cost exceeds 2.0× benchmark land value (suggesting holdout leverage); escalate to the municipal liaison committee for negotiation support or parcel substitution.
- By Month 3 (2027-01-17), retain a specialized data-center thermal consultant to model dry-cooler performance on the top three candidate sites under measured summer weather data (daily high temperatures 25–35°C, humidity, wind speed) from the past 20 years. Produce PUE curves for Phase 1 (500 MW, 150 W/m² power density) and Phase 2 (1–2 GW) scenarios. Flag any scenario where modeled PUE exceeds 1.30 on a 35°C design day; if found, redesign with hybrid dry+indirect-evaporative cooling and re-engage water authorities for non-potable water approval. Publish findings by Month 5 (2027-03-17) to lenders and DREAL for permitting confidence.
- By Month 2 (2026-12-17), develop a written playbook defining the investment committee's authority to pause, downsize, split or cancel Phase 1 at each gate, with specific numeric triggers: (i) RTE < 500 MW available → Phase 1 reduced to 250 MW or cancelled; (ii) land assembly < 70% single-square or < 80% split by Month 12 (2027-10-17) → Phase 1 cancelled or delayed to Month 24 (2028-10-17); (iii) anchor-tenant cash deposits < 200 MW by Month 9 (2027-07-17) → Phase 1 downsized to 250 MW, matching committed demand; (iv) debt commitment < EUR 2.5B → Phase 1 paused, fundraising extended to Month 18 (2028-04-17); (v) ANSSI blocking concern → Phase 1 paused pending foreign-equity restructuring. Obtain lender and co-investor written acceptance of this playbook by Month 3 (2027-01-17).
- By Month 5 (2027-03-17), conduct a sensitivity analysis on Phase 1 economics (500 MW base case) showing DSCR outcomes under stress scenarios: (i) 10% lease discount (curtailment or delay to ramp), (ii) EUR 30/MWh energy-price shock, (iii) 15–20% grid-reinforcement cost overrun, (iv) Phase 1 capex 15% above EUR 5B estimate. For each scenario, show the tenant, lender and equity impact, identify which scenarios trigger covenant breach, and propose mitigation (revenue enhancement, cost reduction, equity top-up, Phase 1 scope cut). Share results with lenders by Month 6 (2027-04-17) to set realistic Phase 1 financing terms and prove the sponsor understands downside risk.
- By Month 4 (2027-02-17), establish a formal dispute-resolution protocol for the independent investment committee, defining: (i) how a tie vote (if two external directors disagree with one sponsor nominee) is broken, (ii) conditions under which a lender or co-investor can request a re-vote on a gate decision, (iii) timeline for a gate re-review if new material evidence arrives within 30 days of a decision, (iv) how dissent is documented and communicated to all co-investors. Ensure the external red team publishes its monthly pass/fail opinions before each gate decision, not after.

## 6.3 Follow Up Consultation

In the next consultation (Months 1–3 = 2026-11-17 to 2027-01-17), we should discuss: (1) which specific anchor tenants (by name and company) have shown genuine interest (site visits, technical questions, not just LOI flattery), and what specific technical or commercial requirement would lock them to this site vs a competitor; (2) realistic RTE hosting-capacity and co-funding expectations based on the current Nord 400 kV network load, competing industrial projects (steel, hydrogen, refinery expansion), and RTE's stated grid-reinforcement roadmap; (3) municipal-liaison-committee feedback on landowner attitudes and holdout risk in each zone, and what community-benefit package (beyond EUR 50M–150M estimate) would move mayors from neutral to actively supporting permits; (4) whether Phase 0 budget discipline is real or whether the sponsor has pre-identified contingency funding sources (co-investor equity lines, infrastructure-fund drawdown facilities) that would allow a EUR 250M–500M topology-pivot spend without a formal re-baseline. We should also clarify whether the user intends the EUR 5B–10B Phase 1 ceiling to include USD GPU/TPU hardware (currently outside the campus-company cap) and, if so, how FX hedging and vendor lead-time risk are being managed.

## 6.4.A Issue - Topology Decision Timing Trap: Month 4 (2027-02-17) Gate Precedes Evidence

The topology decision is locked at Month 4 (2027-02-17), but RTE's written hosting-capacity letter—the decisive evidence for single-square vs split—is not due until Month 6 (2027-04-17). This inverts causality: the plan defaults to split campus at Month 4 (2027-02-17) because the RTE evidence is not yet in hand, then receives RTE's answer two months later. If RTE then offers 1+ GW to the single-square node, the plan is already committed to split, incurring EUR 250M–500M redesign cost and 6–12 month slippage. Conversely, if RTE offers only 250 MW to a split node, the Month 4 (2027-02-17) split decision looks prescient but was driven by timing, not evidence.

### 6.4.B Tags

- gate-sequencing-inversion
- RTE-dependency-uncontrolled
- sunk-cost-trap
- topology-lock-premature

### 6.4.C Mitigation

Reverse the gate sequence: make RTE's written 500+ MW letter (Month 6 = 2027-04-17 target) the necessary precondition for the topology decision, which should move to Month 6.5 (2027-05-02) or Month 7 (2027-05-17 to 2027-05-17). Until Month 6 (2027-04-17), conduct both single-square and split-campus land surveys in parallel (cost: EUR 20M–30M extra), but lock parcel commitment only after RTE's answer. Explicitly authorize a 'topology open' condition at Month 4 (2027-02-17) if RTE is delayed, so Month 4 (2027-02-17) becomes a 'topology hold' gate, not a lock. Commission RTE pre-engineering as a paid service (EUR 50M–150M Phase 0 exposure) to accelerate the hosting-capacity opinion to Month 5 (2027-03-17), not Month 6 (2027-04-17).

### 6.4.D Consequence

Without mitigation, a late RTE offer (Month 10+) or a disappointing offer (250 MW vs 1 GW expected) forces costly rework of land assembly, permitting and grid-connection design. More subtly, the Month 4 (2027-02-17) default-to-split decision plants the psychology that single-square is the 'optimistic case' and split is the 'prudent case', which biases stakeholders toward split even if RTE later supports single-square. This undermines evidence-based gating and locks in a less-optimal topology.

### 6.4.E Root Cause

The Month 4 (2027-02-17) topology decision was set to run in parallel with other Phase 0 work (land surveys, ANSSI dialogue, permitting prep) for schedule efficiency, but RTE hosting-capacity assessment cannot be compressed below 4–6 months. The plan treats topology as a discrete binary choice, when in fact it should remain fluid until RTE's evidence arrives. Sponsor momentum and the desire to lock land assembly early override the dependency logic.

## 6.5.A Issue - Anchor Tenant Gate Masquerades as Demand Signal but Tests Nothing Binding

The plan requires binding term sheets for 'at least 30% of Phase 1 size' (150 MW of 500 MW) by Month 9 (2027-07-17) to unlock Phase 1 FID at Month 12 (2027-10-17). However, the anchors are not identified, their specific power-density, latency or sovereignty requirements are not stated, and the take-or-pay templates are drafted only by Month 2 (2026-12-17)—giving only 7 months of negotiation. In practice, global hyperscalers are comparing 8–12 European sites, and LOIs from multiple sites cost them nothing. A 'binding term sheet' signed in Month 9 (2027-07-17) often contains so many conditions (final security clearance, fiber routing, energy indexation caps, curtailment carve-outs) that it collapses to a non-binding commitment once Phase 1 detailed design reveals surprises. The plan treats term-sheet signatures as proof of demand but does not define what makes a term sheet 'binding' (cash reservation fees paid by Month 9 = 2027-07-17? signed lease actually effective on energization? parent-company guarantee?). Without cash in escrow or a liquidated-damages clause, a tenant can walk by Month 14–15 (2027-12-17 to 2028-01-17) (post-FID, pre-energization) if the economics or site conditions shift.

### 6.5.B Tags

- demand-validation-weak
- term-sheet-ambiguity
- LOI-masquerading-as-binding
- fid-gate-illusory

### 6.5.C Mitigation

Redefine 'binding' by three hard criteria: (1) reservation fee of EUR 10M–50M per 100 MW must be paid in full and held in escrow by Month 9 (2027-07-17), not promised; (2) term sheet must include a liquidated-damages provision of at least 10–15% of first-year lease revenue if the tenant exits between FID and energization; (3) counterparty must post a parent-company guarantee or letter of credit equal to 1–2 years of lease payments if credit rating is below BBB−. Additionally, target only 2–3 actual anchor tenants, not a generic 'at least 30%'—identify them by name by Month 6 (2027-04-17) and conduct site-specific cluster-size and latency testing during Phase 0 to validate their technical fit. If fewer than two A-rated or parent-guaranteed tenants execute term sheets with cash deposits by Month 9 (2027-07-17), downsize Phase 1 to 250 MW (matched to credible demand) rather than forcing a 500 MW build on speculative anchors.

### 6.5.D Consequence

Without mitigation, Phase 1 breaks ground (Month 16–18 = 2028-04-17 to 2028-06-17) with 150 MW of signed 'binding' leases that evaporate once detailed design reveals EUR 200M of grid co-funding or curtailment clauses the tenant negotiated away in Month 9 (2027-07-17). By Month 24–30 (2028-10-17 to 2029-04-17), the campus is 40–60% built with only 75 MW of actual committed revenue, forcing a DSCR collapse to below 1.1x and covenant breach. Lenders issue a cure notice; the sponsor equity is trapped; equity investors lose USD 500M–1B. This is a repeatable mega-project failure pattern.

### 6.5.E Root Cause

The plan conflates contractual form (term sheet executed) with economic commitment (capital at risk). Hyperscaler behavior—especially for GPU-heavy AI training workloads—is to keep options open across multiple geographies until 6–12 months before power-on. Tenant discounting for curtailment, water scarcity, latency uncertainty or delayed fiber arrival is standard. The plan's FID gate depends on a signed term sheet but does not require (i) reservation-fee cash deposit, (ii) liquidated damages on tenant exit, or (iii) a credit-quality parent guarantee. The 30% threshold is also arbitrary and not validated by any anchor's actual need statement.

## 6.6.A Issue - Phase 0 Budget Trap: EUR 750M Cap Incompatible with Four-Tranche Sequence and Topology Uncertainty

The phase0_tranche_caps define four milestone tranches: EUR 150M (Months 0–2 = 2026-10-17 to 2026-12-17), EUR 250M (Months 3–6 = 2027-01-17 to 2027-04-17), EUR 200M (Months 7–9 = 2027-05-17 to 2027-07-17), EUR 150M (Months 10–12 = 2027-08-17 to 2027-10-17). However, the canonical facts also define a split-campus default at Month 4 (2027-02-17) if single-square contiguity fails, and split campus incurs EUR 250M–500M additional capex (5–10% of EUR 5B Phase 1) plus EUR 300M–600M carrying cost. The Phase 0 cap of EUR 750M does not account for a mid-Phase-0 pivot to split-campus topology, which would require EUR 100M–250M of design rework, parcel surveys and grid-connection engineering for multiple nodes. If the Month 4 (2027-02-17) topology decision pivots to split campus, the Months 3–6 (2027-01-17 to 2027-04-17) tranche is overspent by EUR 100M–200M on single-square land assembly and permitting prep that must be abandoned. The plan offers no contingency funding source, no decision rule for tranches, and no explicit authorization to exceed EUR 750M if split campus is chosen.

### 6.6.B Tags

- budget-cap-unrealistic
- contingency-funding-missing
- tranche-discipline-illusory
- split-cost-not-provisioned

### 6.6.C Mitigation

Redefine Phase 0 budget as EUR 750M for the 'base' single-square Cambrai case, with an explicit contingency reserve of EUR 250M–500M held outside that cap for topology pivots or remediation surprises. Obtain co-investor and lender sign-off on the contingency budget at Month 1 (2026-11-17)—do not ask for it after overspend is discovered. Alternatively, cap Phase 0 at EUR 750M firm and allow no topology pivot after Month 2 (2026-12-17)—i.e., if single-square contiguity is not achieved by Month 3 (2027-01-17), Phase 0 is abandoned (kill) rather than pivoted to split. A third option: commit to split-campus design at Month 0 (2026-10-17) as the base case, budget EUR 800M–900M (single tranches of 250 MW each incur less land-assembly and grid-study overhead than a 1.6 GW single square), lock land and grid in parallel for two nodes by Month 6 (2027-04-17), and keep a single-square bolt-on as the upside if RTE or land evidence surprises to the good.

### 6.6.D Consequence

Without mitigation, Phase 0 runs into a budget shortfall in Month 4–6 (2027-02-17 to 2027-04-17) when either (1) land assembly or grid pre-engineering for a split-campus pivot is approved after Month 4 (2027-02-17) and exceeds the original EUR 750M cap, forcing a sponsor equity top-up and a loss of budget discipline, or (2) the sponsor decides to stay with single-square despite weak evidence because it is cheaper to proceed than to abandon Phase 0 sunk cost. Either way, the numerical gate becomes a negotiated target rather than an enforceable threshold.

### 6.6.E Root Cause

The EUR 750M cap was set as a user constraint for Phase 0 'feasibility, site control, land assembly, grid hosting capacity' work, but the plan did not model the cost of a topology pivot at Month 4 (2027-02-17). The assumption was that Phase 0 would produce a clear go/no-go answer on single-square contiguity by Month 3 (2027-01-17), allowing a clean topology lock by Month 4 (2027-02-17) within budget. However, the plan itself acknowledges that RTE hosting-capacity evidence (the deciding factor) arrives in Month 6 (2027-04-17), two months after the topology lock. This gap creates a choice: either delay the topology decision to Month 6 (2027-04-17) (missing the Month 4 = 2027-02-17 schedule), or proceed with Month 4 (2027-02-17) topology lock before RTE's answer (inverting evidence). If Month 4 (2027-02-17) defaults to split campus because RTE's evidence is missing, the Phase 0 sponsor is committed to a costlier topology on a time-constraint gamble, not evidence.

---

# 7 Expert: Lender and Debt-Financing Structuralist

**Knowledge**: Senior debt securitization, project-finance covenants and triggers, DSCR and leverage ratios for infrastructure, multi-tranche term-loan structuring, covenant waiver negotiation, cross-default and acceleration clauses, lender reporting and monitoring, debt tenor matching and refinancing risk

**Why**: Capital Staging (Decision 2) and the financing gate depend on securing EUR 3B senior debt for the 500 MW case by Month 12 (2027-10-17). The plan's thin 500 MW economics (DSCR 1.34x against a 1.30x lender floor, and falling to 1.15x under curtailment stress) and the stacked contingent add-ons (EUR 1.55B–4.2B) leave little headroom. A debt-finance specialist can validate lender appetite at these metrics, structure multi-tranche drawdowns tied to stage gates, and identify which add-ons are fundable within the EUR 10B ceiling.

**What**: Engage 2–3 lead lenders (propose EIB, development banks, infrastructure funds) from Month 3 (2027-01-17) onward with a shadow-debt model, testing whether 500 MW DSCR 1.34x and 1 GW leverage 60% are acceptable at 5.5% all-in cost over 15 years (estimates). Model curtailment discounts, energy price shocks and phase contingencies. Confirm whether EUR 3B firm commitment is achievable by Month 12 (2027-10-17) given the RTE, tenant and authority dependencies. Identify which cost add-ons (grid co-funding, split-campus premium, remediation contingency, fiber, security) can sit outside the EUR 5B base or must be cut to stay under EUR 10B.

**Skills**: Project-finance structuring, leverage and DSCR stress-testing, multi-tranche term-loan design, covenant and trigger drafting, lender due diligence facilitation, refinancing and debt-maturity matching

**Search**: project finance DSCR infrastructure, term loan covenants triggers, EIB data center financing, senior debt structuring large capex

## 7.1 Primary Actions

- By Month 0.5 (2026-11-01): Establish a tri-party binding agreement (sponsor, lenders, infrastructure fund) that vests Phase 1 drawdown approval in the investment committee with written numeric kill thresholds (RTE ≥500 MW, ≥70% land assembly, ≥30% anchor tenants signed, ANSSI pathway confirmed). Specify that a threshold breach automatically halts the next tranche unless a supermajority override is recorded to lenders in writing.
- By Month 2 (2026-12-17): Obtain an interim RTE feasibility opinion (email/call, not formal letter) for ≥500 MW per candidate node within 36 months from connection request. Use this to make the Month 4 (2027-02-17) topology decision conditional: single square only if RTE interim opinion confirms ≥1 GW feasibility at one node; otherwise default to split campus and replan. Require a firm RTE written letter by Month 9 (2027-07-17) to lock the grid connection design.
- By Month 6 (2027-04-17): Execute a binding energy supply agreement with EDF/RTE (all-in EUR 55–75/MWh, 10-year tenor, ±3% annual indexation cap) and revise the anchor-tenant gate to require ≥50% of Phase 1 signed (250 MW of 500 MW) by Month 9 (2027-07-17), with reservation fees paid before construction. If energy pricing cannot be confirmed by Month 6 (2027-04-17), escalate to the investment committee to defer Phase 1 FID or reduce Phase 1 to committed capacity only.
- By Month 1 (2026-11-17): Commission the independent red team (EUR 2M–5M) with a written charter requiring monthly pass/fail certification of each gate threshold (RTE, land, tenants, ANSSI, financing) and a public dissent report at Month 12 (2027-10-17) that names suppressed or disputed findings. Ensure the red team reports directly to the investment committee and lenders, not through the sponsor.
- By Month 9 (2027-07-17): Publish the Phase 0 red-team findings on RTE hosting capacity (interim audit), land assembly fragmentation, brownfield liability bounds, and tenant credit quality. If any threshold shows >20% risk of failure by Month 12 (2027-10-17), trigger the investment committee to flag a conditional pass or a Phase 1 downsize (e.g., 250 MW) as the likely gate outcome.

## 7.2 Secondary Actions

- By Month 3 (2027-01-17): Commission Phase II intrusive brownfield surveys (EUR 1.5M–3M per site zone) on the top 2–3 candidate parcels in each topology node. Shortlist only parcels with remediation bounded to EUR 0–100M; obtain written indemnities or public-body liability allocations covering pre-existing contamination. Publish the Phase II findings by Month 6 (2027-04-17) to lenders and the investment committee, with liability-allocation agreements in place by Month 4 (2027-02-17).
- By Month 4 (2027-02-17): Finalize the land-assembly strategy per chosen topology with a non-coercive option agreement covering ≥70% of the target parcel (proposed threshold). If contiguous assembly is <70% feasible, document the holdout-fragmentation risk and default to split-campus topology per the Month 4 (2027-02-17) rule.
- By Month 6 (2027-04-17): Obtain written water-authority opinion (DDT/DDTM and Agence de l'Eau) confirming that closed-loop dry-cooler cooling with zero evaporative water is permissible at 1 GW scale with no material impact on drinking-water supply during drought years. If water authorities express concern, budget remediation (cooler relocation, sound barriers) as contingency cost or trigger the investment committee to reduce Phase 1 size.
- By Month 6 (2027-04-17): Secure an informal ANSSI/DGSI opinion confirming that formal national-security review can commence at Month 13 (2027-11-17) with no blocking concerns on foreign co-investor involvement or data-residency policies. If ANSSI signals a review timeline >18 months or identifies fundamental blocking concerns, escalate to the investment committee to pause Phase 1 or restructure the co-investor base.
- By Month 9 (2027-07-17): Publish the fiber-route audit confirming at least 2 physically separate, audited routes (no shared duct, bridge or landing) to each hub (Paris, London, Brussels, Amsterdam, Frankfurt). Obtain written confirmation from at least one carrier that dark-fiber capacity can be lit before Phase 1 energization (by Months 42–48 = 2030-04-17 to 2030-10-17).
- By Month 9 (2027-07-17): Secure written support (signatures) from at least 2 of the 3 most-affected municipalities on a binding community-benefit agreement (EUR 50M–150M over Phases 1–2, farm relocation at 1.5–2.0× land value, ecological restoration, local hiring). If signatures are not obtained, flag as a social-license risk to the investment committee at the Month 12 (2027-10-17) gate.
- By Month 12 (2027-10-17): Obtain a firm debt commitment of at least EUR 3B for the 500 MW Phase 1 tranche (60% leverage), 12-year tenor, all-in rate 5.5%±50 bps. If debt is available only at higher cost or shorter tenor, document the terms and recalculate DSCR stress (10% curtailment discount, energy price upside). If DSCR falls below 1.15x, trigger a Phase 1 downsize contingency (e.g., 250 MW on all-equity basis).
- Throughout Phase 0 (Months 0–12 = 2026-10-17 to 2027-10-17): Track the EUR 750M Phase 0 budget cap against four milestone tranches (EUR 150/250/200/150 EUR M). If any tranche overspends by >15%, or if cumulative spend reaches EUR 600M by Month 9 (2027-07-17), escalate to the investment committee to reduce subsequent Phase 0 scope or defer discretionary work (e.g., immersion-cooling pilot studies) to Phase 1.

## 7.3 Follow Up Consultation

At the Month 12 (2027-10-17) gate review, revisit the three core failure risks: (1) If RTE offers <500 MW, decide whether to proceed with a downsized Phase 1 (250 MW) or pause; (2) if land assembly is <70% complete, confirm the split-campus pivot and reset the grid and permitting designs; (3) if anchor tenants total <30% signed, determine whether the investment committee accepts a conditional FID (debt contingent on post-energization marketing) or delays Phase 1 to build demand. Assess whether the stacked contingent add-ons (grid co-funding EUR 500M–1.5B, split-campus premium EUR 250M–500M, remediation EUR 100M–300M, ecological compensation EUR 200M–300M) fit within the EUR 10B Phase 1 ceiling; if total capex forecast exceeds EUR 10B, downsize Phase 1 to 250 MW or restructure financing (higher leverage, longer tenor) within lender appetite.

## 7.4.A Issue - Phase 0 Gate Thresholds Are Incompletely Enforceable and Risk Sponsor Override

The investment committee charter, red-team engagement, and numeric kill thresholds are planned for Month 1–2 (2026-11-17 to 2026-12-17) but lack a binding commitment mechanism. The proposal states 'supermajority override with published dissent,' yet dissent publication does not prevent Phase 1 continuation. No mechanism ties debt drawdown or capital release to explicit committee pass/fail votes. Sunk cost (EUR 400M–750M by Month 12 = 2027-10-17) creates momentum pressure to override stated thresholds. Without contractually embedded gate authority—such as a lender-controlled drawdown veto or a third-party fiduciary trustee—the committee remains advisory, not enforceable.

### 7.4.B Tags

- gate_governance_risk
- sunk_cost_momentum
- sponsor_override
- enforcement_mechanism_missing

### 7.4.C Mitigation

By Month 0.5 (2026-11-01), embed gate authority in a binding tri-party agreement (sponsor, lenders, infrastructure fund) that vests Phase 1 drawdown approval in the investment committee or lender-designated trustee, with written numeric thresholds tied to capital tranches. Specify that a threshold breach (e.g., RTE <500 MW by Month 6 = 2027-04-17) automatically halts the next tranche drawdown unless a supermajority votes to override in writing, with the override recorded to all lenders. Require the external red team to certify gate evidence monthly, with a public dissent report at Month 12 (2027-10-17) that names any suppressed or disputed findings.

### 7.4.D Consequence

Without enforceable authority, Phase 1 will proceed despite unfavorable RTE hosting (<500 MW), land assembly failure (<70%), or weak tenant commitments (<30% signed). This commits EUR 5B–10B capex against unproven grid, demand and land, replicating the 'momentum override' failure mode that plagues mega-projects. Cost overruns of EUR 1B–3B and 12–24 month delays become likely.

### 7.4.E Root Cause

The plan treats gate governance as a process (committee meetings, red-team reports) rather than a structural control. Sponsor momentum and board-level inertia routinely override stated thresholds when sunk cost exceeds pre-agreed abandonment budgets. The proposed governance does not separate gate decision-making authority from the sponsor, so it lacks independence.

## 7.5.A Issue - RTE Grid Hosting Capacity Remains Uncontrolled Until Month 6 (2027-04-17) at Earliest; Topology Locks at Month 4 (2027-02-17) on No Evidence

The canonical rules state: topology decision Month 4 (2027-02-17) requires at least 70% parcel optioned AND RTE written evidence for ≥1 GW. However, RTE's written preliminary letter is not due until Month 6 (2027-04-17). This creates a logical impossibility: Month 4 (2027-02-17) topology lock cannot rely on Month 6 (2027-04-17) RTE evidence. The plan acknowledges this ('split campus is the default at Month 4 = 2027-02-17') but offers no contingency for the likely case that RTE provides no written evidence by Month 4 (2027-02-17). This inverts the stated kill test (grid hosting >~1 GW is the primary kill condition) into a default split-campus commit made before evidence exists.

### 7.5.B Tags

- timeline_inversion
- uncontrolled_external_dependency
- topology_premature_lock
- grid_kill_test_not_applied

### 7.5.C Mitigation

Reorder gates: Month 3 (2027-01-17), request RTE written preliminary opinion (not final letter, but interim feasibility) for ≥500 MW per node within 36 months, with specific grid reinforcement scope and cost allocation. Target Month 4 (2027-02-17) interim RTE opinion (informally, by call/email, not formal letter) to inform the Month 4 (2027-02-17) topology decision. Require the Month 4 (2027-02-17) topology lock to be conditional: 'single square locked if RTE interim feasibility suggests ≥1 GW is possible; if RTE suggests <1 GW per node, pivot to split campus and replan grid-connection sequencing.' Firm RTE written letter and final connection offer targeted Month 9 (2027-07-17); if missed, Phase 1 size is reduced to RTE's confirmed offer.

### 7.5.D Consequence

Month 4 (2027-02-17) topology locked against a split-campus default (not evidence) risks committing to a single-square footprint that RTE cannot support. Phase 1 design (substations, fiber, land assembly) proceeds for 1+ GW scale but RTE offers only 500 MW, forcing a costly redesign in Months 6–9 (2027-04-17 to 2027-07-17). Alternatively, the split-campus lock at Month 4 (2027-02-17) consumes EUR 200M–500M in Months 4–9 (2027-02-17 to 2027-07-17) on split-campus designs that the RTE June 6 letter might have made unnecessary, or consumes EUR 300M–600M in carrying and design rework when topology flips post-gate.

### 7.5.E Root Cause

The plan assumes RTE evidence will arrive before Phase 1 design locks, but the gate schedule compresses RTE's decision window (typically 8–12 weeks for a preliminary opinion) into a 4-week slot (Month 3 = 2027-01-17 to Month 4 = 2027-02-17). RTE's internal governance and competing requests may slow the response. No explicit contingency accommodates a delayed RTE response or a negative or partial offer.

## 7.6.A Issue - Anchor-Tenant Binding Commitments at Month 9 (2027-07-17) (30% of Phase 1) Do Not Match Phase 1 FID Timeline or Energy Price Uncertainty

The canonical threshold requires binding term sheets for ≥30% of Phase 1 by Month 9 (2027-07-17). However, debt underwriting for EUR 5B Phase 1 capex typically requires ≥50–70% signed long-term capacity, not 30%, to support DSCR >1.30x under stress. At 30% signed, the remaining 70% is either equity-funded (worsening leverage) or relies on unsold capacity being marketed post-energization (revenue risk). Additionally, tenant take-or-pay terms assume an energy price (EUR 60/MWh, range 50–70, not verified) that EDF/RTE will not confirm until Month 9–12 (2027-07-17 to 2027-10-17). If energy costs escalate to EUR 100/MWh, tenant willingness to sign drops sharply. The 30% threshold may meet a gate but does not meet financing credibility.

### 7.6.B Tags

- insufficient_tenant_commitment
- lender_underwriting_gap
- energy_price_uncontrolled
- financing_credibility_weak

### 7.6.C Mitigation

Revise the anchor-tenant gate: by Month 9 (2027-07-17), secure binding term sheets for ≥50% of Phase 1 size (250 MW of 500 MW) from investment-grade or parent-guaranteed counterparties, with reservation fees (EUR 10M–50M per 100 MW) paid before construction. For the remaining 30% (150 MW), obtain non-binding letters of intent with a 90-day go/no-go clause, conditional on final energy pricing. Simultaneously, by Month 6 (2027-04-17), lock EDF/RTE energy supply terms in writing (all-in EUR 55–75/MWh, 10-year tenor, annual indexation capped at ±3%) to give tenants cost certainty for their commitment. If EDF cannot confirm pricing by Month 6 (2027-04-17), escalate to the investment committee: defer Phase 1 FID by 3 months or reduce Phase 1 size to the committed demand that is insensitive to energy price (e.g., 250 MW at a higher lease rate).

### 7.6.D Consequence

At 30% signed, debt financing is undersubscribed: either debt caps at EUR 2.0B–2.5B (forcing EUR 2.5B–3.0B equity, above the infrastructure-fund appetite), or debt at EUR 3.0B leaves unsold capacity for post-energization marketing (revenue risk >EUR 200M if lease prices must drop to attract late tenants). Energy price surprise (EUR 30/MWh increase) makes unsigned 70% capacity unmarkettable post-energization and strands investor returns. Financing credit rating drops from speculative to junk, lender margins widen from +200 bps to +500+ bps, or financing is withdrawn.

### 7.6.E Root Cause

The 30% threshold was set to meet a gate (pass-through demand evidence) but not aligned to lender underwriting standards or energy-cost certainty. Debt structures for data centers typically require 60%+ signed baseload; the plan underfunds this. Energy cost is an external, uncontrolled factor (EDF negotiation) that the gate does not condition on.

---

# 8 Expert: Thermal, Cooling and Hydrology Engineer

**Knowledge**: Data-center PUE benchmarking and direct-to-chip liquid-cooling design, dry-cooler performance curves and hot-weather degradation, immersion cooling pilots, thermal modelling under ambient extremes, groundwater and surface-water hydrology, water-authority permitting and drought rules, heat-rejection sizing and reclaimed-water feasibility

**Why**: Cooling and water (Decision 7) are the least predictable variables: the plan targets PUE 1.15–1.25 but risks 1.35–1.5 on 35°C design days (raising peak grid load 5–15%), and a zero-evaporative-water constraint simplifies permitting but may be unachievable on a dry-cooler budget. A thermal specialist can validate PUE assumptions via site-specific modelling, size dry coolers and heat-rejection area, and work with water authorities to confirm the zero-water design is feasible or what hybrid cooling requires.

**What**: Conduct Phase 0 thermal modelling (Months 1–5 = 2026-11-17 to 2027-03-17) on the 35°C design day using vendor dry-cooler curves from three manufacturers (Thermax, Hydac, Modine), for 500 MW average power density 150 W/m² and inlet water 30–35°C. If modelled PUE exceeds 1.30, recommend hybrid cooling with capped non-potable water or accept the 1.35–1.5 PUE penalty. Obtain written water-authority opinion by Month 6 (2027-04-17). Size dry coolers and heat-rejection area on each candidate parcel; validate whether immersion-pilot feasibility is credible.

**Skills**: Thermal design and PUE modelling, dry-cooler and immersion-cooling engineering, hydrology and water-balance analysis, water-authority permitting, French drinking-water and drought rules, heat-reuse feasibility and design

**Search**: data center PUE dry cooler design, thermal modelling 35 degrees, immersion cooling pilot, groundwater hydrology France drought

## 8.1 Primary Actions

- By Month 1 (2026-11-17), commission an independent thermal-design audit (EUR 300K–600K) to model dry-cooler performance at 35°C, 38°C and 40°C ambient using measured vendor data (Thermax, Hydac, Modine), with fouling and part-load curves. Lock a hard PUE gate at Month 5 (2027-03-17): if >1.28, commit in writing to hybrid cooling, load-shedding (curtailment), or capacity downsize, and publish the decision to lenders by Month 6 (2027-04-17).
- By Month 1 (2026-11-17), formally request written guidance from the prefectural water board (DDT/DDTM) and Agence de l'Eau Artois-Picardie on: zero-evaporative dry cooling acceptability at 500 MW, availability of industrial wastewater or recycled water as backup, and a pre-agreed drought-response protocol for load shedding. Obtain a draft water-authority letter or conditional opinion by Month 4 (2027-02-17), and lock the thermal design against it by Month 6 (2027-04-17). Budget EUR 50M–100M contingency for water infrastructure or hybrid-cooler retrofit.
- By Month 2 (2026-12-17), commission a heat-demand study (EUR 400K–800K) mapping district-heating networks and industrial heat users within 5 km of each candidate node. By Month 7 (2027-05-17), require binding term sheets from at least one heat partner committing to minimum 15–30 MW offtake and heat price. If no offtake is signed by Month 9 (2027-07-17), treat as zero heat-reuse (EUR 0 revenue) and remove infrastructure from Phase 1 capex. Publish offtake status to lenders by Month 9 (2027-07-17).

## 8.2 Secondary Actions

- Commission a parallel hydrology study (EUR 800K–1.5M) modeling groundwater availability, historical drought frequency and climate projections to 2035, to inform the water-authority dialogue and contingency planning for hybrid cooling.
- Embed a drought-response clause in all tenant leases: tenants accept defined load reduction (e.g., 20%) in a drought-declared state in exchange for lease-price credit (e.g., 5–10%). Publish the drought protocol to lenders by Month 6 (2027-04-17) so they can model the SLA and DSCR impact.
- Allocate EUR 100M–200M contingency reserve (outside the EUR 5B capex base) for dry-cooler PUE upside or hybrid-cooler retrofit if Phase 0 or Phase 1 thermal modelling shows >1.30 PUE. Lock this contingency in the Phase 0 financing structure by Month 3 (2027-01-17).
- Engage the investment committee by Month 3 (2027-01-17) to pre-agree on what thermal, water-authority or heat-offtake outcomes trigger Phase 1 capacity reduction (e.g., 500 MW to 350 MW if PUE >1.30 and water authority restricts expansion) or scope cuts (e.g., delete heat infrastructure if no offtake). Document the decision rules in writing so they are enforceable under sunk-cost pressure.
- By Month 5 (2027-03-17), publish a consolidated thermal, water and heat-reuse strategy document to the investment committee and lenders, integrating: modelled PUE at design-day ambient, water-authority conditional opinions, drought-response SLA terms, and heat-offtake status. Treat this as a funding gate: debt and equity sources should confirm they can underwrite the project under the thermal and water assumptions stated in this document.

## 8.3 Follow Up Consultation


By Month 3 (2027-01-17), we should schedule a 2–3 day hydro-thermal workshop with the investment committee, key lenders, and the Phase 1 engineering team to align on: (i) acceptable PUE ranges and grid-load volatility under the RTE curtailment and BESS budget, (ii) water-authority expectations and drought-response triggers for load shedding, (iii) heat-offtake commercial models (developer funds infrastructure vs. customer, or third-party heat operator), and (iv) contingency funding and scope-reduction decision rules if thermal or water findings diverge from current assumptions. This workshop should produce a signed 'Thermal and Water Design Basis Memo' that binds financing, scheduling and capacity decisions. Additionally, by Month 6 (2027-04-17), I recommend a peer review of the Phase 0 thermal modelling and water-authority letters by an independent hydrology and cooling specialist (not the original design team) to stress-test the assumptions and confirm they are realistic for Hauts-de-France climate and water conditions.


## 8.4.A Issue - Dry-cooler 35°C design-day validation is incomplete and PUE risk is underestimated

The plan commits to a 1.15–1.25 PUE target and flags a 35°C design-day as the validation gate, but the thermal modelling scope (Month 5 = 2027-03-17) is too late and too narrow. Dry-cooler performance at 35°C ambient with 30–35°C inlet water is non-linear and vendor curves often hide parasitic load, fan degradation, and part-load efficiency cliffs. A 10-point PUE escalation (1.20 to 1.30) adds 150–200 MW peak electrical load on a hot day, which RTE may refuse to accept without curtailment or BESS. The plan accepts up to 1.35–1.50 PUE in hot weather as an estimate, but does not tie the thermal modelling results to a decision gate or a cost reserve. If Phase 0 modelling shows PUE >1.30, the plan says 'trigger design review' but does not define what happens next: does the project pivot to hybrid water cooling (reopening permitting and water-authority risk)? Does capacity get cut? Is the cost overrun absorbed? The lack of a hard gate makes this a drifting technical risk.

### 8.4.B Tags

- thermal-design-gate-missing
- dry-cooler-performance-nonlinear
- pue-upside-risk-unpriced
- peak-grid-load-volatility
- design-review-no-action

### 8.4.C Mitigation

By Month 3 (2027-01-17), commission a Phase 0 thermal design audit by an independent thermal engineer (EUR 300K–600K) who will model dry-cooler performance using measured vendor data (not marketing curves) at 35°C, 38°C and 40°C ambient, across multiple cooler makes (Thermax, Hydac, Modine minimum), with fouling factors and part-load curves. Impose a hard gate at Month 5 (2027-03-17): if modelled PUE exceeds 1.28 (2-point upside margin), commit to either (i) hybrid cooling (capped, non-potable water, re-opens water-authority engagement), (ii) load shedding (commit 10–15% curtailment to RTE), or (iii) capacity downsize (reduce Phase 1 target from 500 MW to 400 MW, resizing capex from EUR 5.0B to EUR 4.0B). Publish the decision to the investment committee and lenders by Month 6 (2027-04-17) so BESS and grid-reinforcement scope can be adjusted. Allocate EUR 100M–200M contingency reserve for hybrid-cooler retrofit or peak-load BESS if hot-weather operation shows upside.

### 8.4.D Consequence

Without a hard thermal gate, the 1.15–1.25 PUE target becomes negotiable under schedule and cost pressure in Phase 1. A 1.35–1.40 PUE at 500 MW means 75–100 MW of unexpected peak load, which strains a grid already constrained by competing industrial loads (Dunkirk refinery, steel mills, hydrogen). RTE may issue a curtailment notice mid-summer, forcing load shedding on tenants and triggering lease SLA breaches. Alternatively, late discovery of PUE upside forces a Phase 1 retrofit to water-cooled or immersion systems (EUR 300M–500M, 6–12 month delay, re-opens contamination and water-authority risk). Tenants discover their power density assumptions are wrong, demand lease discounts, and DSCR falls from 1.34x to 1.15x or below, triggering lender covenant breaches. This is a credibility and financing failure.

### 8.4.E Root Cause

The plan treats dry-cooler validation as a design question rather than a cost, schedule and grid-capacity decision gate. Vendor curves supplied by manufacturers are typically optimistic, tested at controlled conditions, and do not account for fouling, fan bearing friction, or the interaction with warm inlet water from immersion-cooled or high-density racks. Hauts-de-France summer peaks (36–38°C on rare days) and the low cloud cover mean dry coolers run at the edge of their capability. The plan does not budget a contingency for PUE upside or reserve capacity at RTE for grid headroom to absorb 100–150 MW of unexpected peak load on a hot day.

## 8.5.A Issue - Water-authority permitting pathway and drought-rule interaction are unvalidated and water-cooling pivot is not resourced

The plan specifies a zero-evaporative-water design but assigns water-authority engagement to Month 6 (2027-04-17) written opinion, which is after the topology decision (Month 4 = 2027-02-17). This sequence inverts the right order: a water-authority blocking opinion (e.g., 'dry coolers acceptable only if PUE stays at 1.25 or below') must inform the topology and thermal design choices, not follow them. Hauts-de-France sits in the Artois-Picardie catchment, which is stressed in summer and has a history of drought declaration and industrial water-use curtailment (2022, 2023). The plan assumes dry cooling will avoid water-authority friction, but a 50,000–100,000 m² dry-cooler farm with 150–300 MW thermal load creates air-release heat that affects microclimate and triggers scrutiny under French environmental law. The plan does not address: (i) whether the water authority will permit zero-water design at 500 MW and restrict any future expansion to hybrid or evaporative cooling, (ii) what happens if drought rules (décrets de crise) restrict industrial water-use to 50–75% in a dry summer, forcing load-shedding on non-essential tenants, (iii) whether 'non-potable' industrial water (e.g., treated wastewater, recycled process water) is available at this scale, or if dry cooling is the only option.

### 8.5.B Tags

- water-authority-sequencing-inverted
- drought-rule-exposure
- indirect-water-impact-unaddressed
- zero-water-assumption-unvalidated
- contingency-for-water-pivot-missing

### 8.5.C Mitigation

By Month 1 (2026-11-17), formally request written guidance from the prefectural water board (DDT/DDTM) and Agence de l'Eau Artois-Picardie on: (i) acceptability of zero-evaporative dry cooling at 500 MW with a stated PUE range (1.20–1.30), (ii) whether industrial wastewater or recycled process water can supplement dry cooling if PUE exceeds thresholds, (iii) pre-agreed drought-response protocol (e.g., is 20% load shedding acceptable in a 50-year drought event?), and (iv) timeline and process for issuing a formal water-authority letter of no objection (typically 3–6 months). Commission a parallel hydrology study (EUR 800K–1.5M) to model: groundwater availability, historical drought frequency and duration in the catchment, and whether a 500 ML/year indirect-use allowance (for cooler air release) is sustainable under climate projections to 2035. By Month 4 (2027-02-17), obtain a draft water-authority letter or conditional opinion, and lock the thermal design against it (PUE, cooler sizing, contingency water source). Budget EUR 50M–100M contingency for water-treatment infrastructure or a hybrid-cooling retrofit if water authority requires it. Embed a drought-response clause in tenant leases: tenants accept X% load reduction in a drought-declared state in exchange for Y% lease-price credit (propose 20% load reduction for 5–10% price credit). Publish the water-authority letter and drought protocol to lenders by Month 6 (2027-04-17).

### 8.5.D Consequence

A late water-authority blocking opinion or a surprise drought-management decree in Year 1 of Phase 1 construction forces either: (i) a costly and time-consuming retrofit to hybrid or water-cooled systems (EUR 200M–400M, 9–18 month delay, re-opens environmental and permitting risk); (ii) capacity reduction (e.g., 500 MW cut to 350 MW) and a redesign of power, cooling and hall distribution (EUR 500M–1B sunk cost loss); or (iii) a force-majeure suspension of construction mid-phase, triggering lender covenant breach and equity write-down. Tenants, seeing project delays and load-shedding risk, withdraw LOI or demand lease discounts to cover their own PUE and cooling upside. Phase 1 financing fails because debt capacity depends on stable, enforceable SLAs; if a drought decree can unilaterally curtail load, lenders will not fund at the assumed DSCR. This is a hidden single point of failure in the plan's water and environmental case.

### 8.5.E Root Cause

The plan treats water as a permitting checkbox rather than a regional hydrological constraint. Dry-cooler thermal rejection means hot air release, which affects local humidity, cloud formation and microclimate, and the water authority views this as an indirect water impact. A preemptive water-authority letter stating 'dry cooling acceptable only at this PUE' gives legal cover; absence of such a letter means a Phase 1 permitting challenge can force retrofit or capacity cut mid-construction. The plan also does not engage with French drought-management law (article L.211-1 Code de l'environnement), which can declare industrial water-use restrictions within weeks if summer precipitation is <25% of normal. Without a pre-agreed drought-response plan, a Phase 1 or 2 summer curtailment of 20–40% load (forced by decree, not RTE choice) breaks tenant leases and crashes DSCR.

## 8.6.A Issue - Heat-reuse design and offtake-agreement gate are missing; heat is priced at EUR 0 and exposure is unmanaged

The plan mentions heat reuse as an optional upside and explicitly states 'treat the heat offtake agreement as a condition of site selection' (Decision 7). However, no heat-offtake gate, no partner engagement, and no contingency for heat-reuse failure are built into the Phase 0 roadmap. A 500 MW data center with 1.20–1.25 PUE rejects about 60–100 MW of waste heat at 35–45°C, enough to serve district heating for 5,000–15,000 homes or industrial process heat for a food, brewing or paper mill. The plan does not specify: (i) which heat users (district-heating networks, industrial partners, or third-party heat traders) are within 2–5 km of candidate sites, (ii) whether those users have signed letters of interest or binding offtake agreements, (iii) what the heat-delivery infrastructure cost is (insulated pipelines, heat exchangers, pump stations, EUR 50M–200M, estimate), (iv) what happens if no credible heat offtake is found (is the EUR 50M–200M infrastructure sunk cost written off?), or (v) how heat-reuse revenue is modelled in the project economics (the plan says EUR 0 until offtake is signed, but does not show what happens when it is signed—does revenue flow to tenants, the campus company, or a third-party heat operator?).

### 8.6.B Tags

- heat-offtake-gate-undefined
- heat-partner-engagement-missing
- heat-infrastructure-cost-unmanaged
- heat-revenue-unclear
- contingency-for-no-offtake-missing

### 8.6.C Mitigation

By Month 2 (2026-12-17), commission a heat-demand study (EUR 400K–800K) that: (i) maps all district-heating networks, industrial process-heat users and food/beverage/paper/refining facilities within 5 km of each candidate node (Cambrai, Dunkirk, Valenciennes), (ii) estimates their thermal demand profile (MW, temperature, seasonality), (iii) calculates pipeline and heat-exchanger costs to connect each prospect, and (iv) engages 2–3 heat customers at each site to collect non-binding expressions of interest. By Month 4 (2027-02-17), filter candidate sites to those with at least one credible heat offtake prospect (public utility or industrial with investment-grade or municipal credit, required >10 MW offtake for economic viability, estimate). By Month 7 (2027-05-17), require binding term sheets from at least one heat partner committing to (i) minimum thermal offtake (propose 15–30 MW, or 15–30% of total), (ii) heat price (propose EUR 30–60/MWh, or indexed to natural-gas costs), and (iii) infrastructure cost split (propose developer funds heat-delivery pipelines and exchangers, customer funds integration into their system). If no heat offtake is signed by Month 9 (2027-07-17), treat the project as zero heat-reuse (EUR 0 revenue) and remove heat infrastructure from Phase 1 capex (saves EUR 50M–100M). If a binding offtake is signed, reserve infrastructure capex in the Phase 1 budget and price heat revenue conservatively (EUR 10M–30M per year at 20–25 MW offtake, or EUR 5M–15M if prices are lower). Publish the heat-demand study and offtake status to lenders by Month 9 (2027-07-17) so financing assumptions can be locked.

### 8.6.D Consequence

If heat infrastructure is built without a signed offtake, EUR 50M–200M is sunk and the campus is left with a dormant heat loop that generates operating cost (maintenance, insurance) with no revenue. Alternatively, if heat is promised as part of the permitting and environmental story ('this project will heat 10,000 homes') but no offtake materializes, it damages credibility with municipalities, NGOs and lenders, and creates grounds for permit appeals (false environmental claims). If heat is discovered late in Phase 1 to be feasible with a strong customer, but infrastructure design and routing were not done in Phase 0, a retrofit adds 6–12 months and EUR 100M–300M cost, derailing the Phase 1 schedule. Most critically, a failed heat-reuse strategy removes a key public-benefit narrative that supports the social-license and permitting case. Communities and municipalities are more likely to support a data center if it heats homes or powers local industry; without that co-benefit, opposition hardens.

### 8.6.E Root Cause

Heat reuse is treated as a public-narrative asset and a permitting advantage (it can help the project's environmental story) rather than as a commercial and technical decision gate. This is a common oversight in data-center planning: waste heat is abundant and has positive public perception, but turning it into signed contracts and cash flow is difficult. Industrial heat customers (breweries, food processors, paper mills) are capital-constrained, slow to move, and often skeptical of relying on a data center's thermal output. District-heating networks (réseaux de chaleur) exist mainly in large urban areas (Dunkerque has one), and extending a new network to the campus requires years of pilot studies, municipal coordination and EUR 20M–50M capex. The plan does not engage with the fact that heat-reuse viability is a Cambrai-vs-Dunkirk-vs-Valenciennes topology question: Dunkirk has existing district heating and industrial heat users; Cambrai does not. By deferring heat-offtake discovery to Phase 1 or beyond, the plan risks sinking EUR 50M–200M in heat infrastructure that no one will buy from, or forcing a topology pivot too late to recover Phase 0 sunk cost.