_Consistency: first pass found 1 high / 6 medium / 0 low contradictions, and the arithmetic check found 1 wrong calculation. Repair: round 1: 35 edits → 3 high / 4 medium; round 2: 39 edits → 0 high / 4 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 4 medium / 2 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Can at least 70% of the chosen topology's target parcel be optioned non-coercively at no more than 15% above benchmark land value? | At least 70% optioned at no more than 15% above benchmark (proposed threshold); each split node at least 80% by the Month 12 gate. Land benchmark EUR 15,000-25,000/ha (estimate). First check Month 3, confirmed Month 4. | GIS-linked parcel and option register, signed option agreements and the holdout survey, reported Month 3 and confirmed at the Month 4 topology decision. Land and option spend stays below EUR 60M before Month 4. | Drop the single square and default to split campus (2-3 nodes of 250-500 MW). Drop any zone that cannot reach 80% optioned. If no zone qualifies, pause land spend and move toward downsize or cancellation. |
| 2 | Has RTE given a written preliminary feasibility letter for at least 500 MW within 36 months at the lead node, with curtailment at or below 10%, and a documented path to more than ~1 GW cumulative hosting in any topology? | Written letter for at least 500 MW within 36 months by Month 6. Curtailment target at most 10% (walk-away 15%). Reinforcement co-funding below EUR 1.0B for the early-warning tripwire (EUR 500M-1.5B estimate). Hosting above ~1 GW cumulative is the 9 GW kill test (user constraint). | RTE written letter (Month 6), interim RTE estimate and independent grid audit findings (Month 3), audit published Month 9. Firm connection offer targeted Month 12 but unlikely, so a conditional pass is allowed. All uncontrolled until signed. | Below 500 MW at the lead node: re-baseline Phase 1 to 250 MW or split campus. No path to ~1 GW in any topology: end the 9 GW ambition and cap the project at a single node or cancel. Which of these applies must be decided (see contradictions). |
| 3 | Do the modelled cooling design and a written water-authority opinion show closed-loop dry cooling is feasible without evaporative water? | Modelled PUE at most 1.30 on a 35C design day (above 1.30 triggers design review). Written water-authority opinion by Month 6. Expansion-gate PUE at most 1.28 later. | Independent thermal model and vendor performance guarantees (Month 5), written water-authority opinion (Month 6), hydrology study. | Redesign: hybrid cooling with capped non-potable water (reopens permitting and costs EUR 50M-100M, estimate), reduce density, or downsize Phase 1. Pivot or downsize if PUE stays above 1.30 and no written opinion exists at Month 6. |
| 4 | Have creditworthy anchor tenants signed binding take-or-pay terms, with fees paid, for at least 30% of Phase 1, against a credible EDF energy pathway? | Binding term sheets for at least 150 MW of 500 MW (300 MW of 1 GW) by Month 9, executed take-or-pay or reservation agreements with fees paid (EUR 10M-50M per 100 MW) by Month 12. Counterparty BBB- or better, or parent guarantee/letter of credit. LOIs do not count. EDF non-binding LOI by Month 6 and term sheet by Month 9; binding contract not before FID. | Signed term sheets and escrowed reservation fees (Month 9), executed agreements (Month 12), EDF LOI (Month 6) and term sheet (Month 9). | Resize Phase 1 to signed MW (250 MW, about EUR 2.5B) or pause 12-24 months. No Phase 1 FID below 30% signed. Defer Phase 2 until at least 50% of the next tranche is signed. |
| 5 | Is a unified Phase 1 cost stack reconciled and funded inside the EUR 10B ceiling, with firm debt of at least EUR 3B and equity sources bound? | Firm senior debt of at least EUR 3B for the 500 MW tranche, tenor at least 12 years, margin about benchmark +200 bps, DSCR 1.34x base against a 1.30x proposed lender minimum, equity of about EUR 2.0B bound. Stack of EUR 1.55B-4.2B plus outside-stack lines of EUR 0.5B-1.15B (total EUR 7.05B-10.35B) must be assigned funded, deferred or cut. | Published cost reconciliation with lender and committee sign-off (Month 9), written lender conditions (Month 6), firm debt and equity commitments (Month 12). Hardware inclusion in the ceiling is settled at the committee charter (Month 1). | Downsize to the debt the signed MW supports (250 MW), seek an equity cure, or defer FID 12-24 months. With a 10% lease discount the DSCR is 1.15x (gap about EUR 44M a year), which means cutting debt to about EUR 2.66B or an equity cure. |
| 6 | Does the Month 12 gate show written support from at least 2 of 3 key municipalities, no major legal challenge pending, and ANSSI written confirmation that formal review can start with no blocking concern? | Written support from at least 2 of 3 municipalities (signatures targeted Month 9), no major legal challenge pending, ANSSI written confirmation at Month 12 that formal review can start in Month 13 with no blocking concern. Formal clearance is expected 12-18 months after review start, which is uncontrolled. | Municipal resolutions or letters, litigation search, ANSSI informal opinion (Month 6) and written confirmation (Month 12), DREAL screening opinion (Month 9). | Pause Phase 1 and reassess. Shift to nodes with supportive municipalities, restructure to non-controlling EU-domiciled co-investors and sovereign-led halls, or cancel if a key municipality formally refuses. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: pitch (Project Overview and Phase 1 Baseline) and executive summary (Timeline)
    canonical: phase_schedule_and_capacity = Phase 1 Months 12-36 (500 MW-1 GW)
    observed:  500 MW energized, 8-10 halls online in Months 12-36, alongside energization at Months 42-48
HIGH CF-002  document: review plan (Review 1, Review 4) and premortem FM1/FM4
    canonical: phase0_budget_cap = EUR 750M hard cap; split from the start needs a new funding decision
    observed:  Split premium of EUR 250M-500M booked as a Phase 0 cap problem; tranche 2 released 'after Month 4 topology lock'
HIGH CF-003  document: executive summary (Focus, Overall Takeaway) and review plan (Review 5 #1)
    canonical: grid_kill_test = Hosting above ~1 GW cumulative (any topology) is the primary kill test; Phase 1 gate is a 500 MW written letter
    observed:  ~1 GW kill test without defined scope; 750 MW downsize trigger; 500 MW gate
MEDIUM CF-004  document: premortem FM2 and project plan Goal Statement
    canonical: phase1_base_case = 500 MW first RTE tranche at one node (Cambrai/E-Valley)
    observed:  Per-node RTE tripwire of <500 MW applied to 250 MW nodes; split Phase 1 composition undefined
MEDIUM CF-005  document: review plan (Review 14 #3)
    canonical: land_option_gate = At least 70% optioned at no more than 15% above benchmark
    observed:  Relocation cost at 1.5-2.0x benchmark
MEDIUM CF-006  document: pitch (Stacked Contingent Add-Ons) and review plan (Reviews 1, 3, 11, 12)
    canonical: phase1_ceiling_headroom_500mw = Stack EUR 1.55B-4.2B; outside-stack EUR 0.5B-1.15B; total EUR 7.05B-10.35B
    observed:  Ecology and security inside the stack; pitch lines sum to EUR 1.35B-3.4B; 'EUR 6.5B-7.5B'
MEDIUM CF-007  document: review plan (Review 11 #2, Review 8 #2)
    canonical: usd_hardware_scope_open_decision = Hardware EUR 1.5B-2.3B ring-fenced outside the campus company; inclusion in the EUR 5B-10B is an open decision
    observed:  EUR 2.7B-3.5B 'remains for infrastructure'
MEDIUM CF-008  document: pitch (National Security) vs executive summary gate (4)
    canonical: debt_financing_gate = Equity sources bound for Phase 1 by Month 12
    observed:  Foreign equity cannot be bound at FID
MEDIUM CF-009  document: review plan (Reviews 1, 4, 5, 6), premortem, self-audit
    canonical: energy_price_shock = +EUR 30/MWh adds about EUR 112M per year at 500 MW; without pass-through DSCR 0.96x
    observed:  Triggers at 70, 75 and 80 EUR/MWh; pass-through and NOI hit mixed
MEDIUM CF-010  document: review plan (Reviews 6, 14, 16)
    canonical: permitting_and_schedule_realism = First-block energization Months 42-48
    observed:  Energization at Month 36; Phase 1 start Month 24
LOW CF-011  document: executive summary (Timeline and Budget)
    canonical: ecology_and_farmland = DREAL screening opinion by Month 9
    observed:  DREAL screening by Month 6
LOW CF-012  document: review plan (Review 4 #3, Reviews 8 and 13)
    canonical: power_procurement_edf = Binding contract not before FID
    observed:  Binding contract target Month 9
```

### 1. Phase 1 window (Months 12-36) vs energization, permits and ANSSI clearance (🔴 High) — needs a project decision

- **Pitch (Project Overview, Metrics for Success); executive summary (Timeline); project plan (Time-bound):** Pitch: "Phase 1 delivers 500 MW by Months 12-36" and "Phase 1 Baseline (Months 12-36): 500 MW energized, 8-10 halls online". Project plan and executive summary also give Phase 1 as Months 12-36.
- **Pitch (Key Milestones, Risk section); executive summary; canonical permitting_and_schedule_realism:** First-block energization at Months 42-48 (downside 48-60). Permit decisions are expected at Months 26-39 and ANSSI formal clearance at about Months 25-31. Stabilized demand is reached only at Months 54-60.
- **Why it conflicts:** The Phase 1 window closes before the base-case energization, and the Months 54-60 stabilization falls outside it too. Build starts at Month 12, before the permit decision and ANSSI clearance. The pitch states both 'energized within Months 12-36' and 'energization at Months 42-48'. The user's success definition (Phase 2 FID backed by anchors) cannot be reached inside Phase 1 either.
- **Suggested resolution:** Decide how Phase 1 is defined. Preferred: Phase 1 runs from FID (Month 12) to first-block energization (Months 42-48), with Months 12-36 as the construction-start window. Success is then tested at the Phase 2 FID (about Months 54-60), after 12 months of operating data. Make permit-dependent works conditional on the permit decision and ANSSI review. Remove 'energized' from the Months 12-36 pitch bullet.

### 2. EUR 750M hard cap vs split-campus default and tranche calendar (🔴 High) — needs a project decision

- **Executive summary (Timeline and Budget); canonical phase0_budget_cap and phase0_tranche_caps:** Phase 0 is a "EUR 750M hard cap (no overspend)" in four tranches of 150/250/200/150, with tranche 2 covering Months 3-6.
- **Review 1 (#1); premortem FM1 and FM4; self-audit #13 and #18; Review 4 (#2):** Review 1 treats the split pivot (EUR 250M-500M) plus design rework (EUR 100M-250M) as a Phase 0 cap problem. Premortem FM4 says split-from-start adds EUR 100M-250M and breaches the cap. Self-audit #13 calls EUR 250M-500M 'Phase 0 sunk cost'. Review 4 releases tranche 2 'after the Month 4 topology lock'.
- **Why it conflicts:** The calendar default to split at Month 4 is the likely outcome, yet it needs Phase 0 money above a cap called hard, and no source is named. The EUR 250M-500M premium is Phase 1 capex (5-10% of EUR 5B), not a Phase 0 cost. Tranche 2 starts at Month 3, before the topology decision. Tranche 3 spans Months 7-9 and cannot sit in escrow until the Month 9 gates have been decided.
- **Suggested resolution:** Keep the EUR 250M-500M premium in Phase 1 capex and remove it from Phase 0 cap discussions. For split-from-start Phase 0 work (up to EUR 250M over the cap, canonical) the committee must decide the funding source: a lender and co-investor approved cap increase, scope cuts within EUR 750M, or doing per-node validation after the gate. Split tranche 2 into a Month 3-4 part and a part released after the topology decision.

### 3. Meaning of the ~1 GW grid kill test vs the 500 MW gate and the shortfall response (🔴 High) — needs a project decision

- **Executive summary (Focus, Purpose); premortem FM2; canonical grid_kill_test and rte_phase1_gate:** "RTE grid hosting capacity above ~1 GW is the primary kill test"; gate (1) is only 500 MW within 36 months. FM2 stop rule: cancel Phase 1 only if RTE gives under 500 MW at all nodes and there is no path to ~1 GW cumulative by Month 12.
- **Review 5 (#1); executive summary (Feedback 3); premortem FM2:** Review 5 triggers a 250 MW downsize if the interim RTE estimate is below 750 MW per topology. Executive summary feedback says grid below 500 MW means a 250 MW downsize. FM2 says under 500 MW at the lead node means a 250 MW re-baseline or a split.
- **Why it conflicts:** A project can pass the Month 12 gate with 500-999 MW and still meet the user's failure definition (no hosting above ~1 GW). The executive summary never says what 'kill' ends: the 9 GW ambition, the single square or Phase 1. A Month 6 letter for 500 MW cannot answer a >1 GW question. A 750 MW trigger appears nowhere else, and the same shortfall is met with downsize, split, re-baseline or cancel depending on the document.
- **Suggested resolution:** Separate the two tests. (1) Phase 1 gate: written letter for at least 500 MW at the lead node (Month 6), firm offer targeted at Month 12. (2) 9 GW ambition test: documented path to more than ~1 GW cumulative in any topology; failure ends the Phase 2+ ambition (single node or cancel), not necessarily Phase 1. Drop the 750 MW trigger or label it a proposed early-warning level. State one consequence table.

### 4. What 'Phase 1' is under a split campus (MW unit) (🟡 Medium) — needs a project decision

- **Project plan (Goal Statement); canonical topology_decision_rule and phase1_base_case:** Goal: "deliver a 500 MW Phase 1 base case at Cambrai/E-Valley"; canonical nodes: Cambrai 500 MW, Dunkirk 250 MW, Valenciennes 250 MW.
- **Pitch (Land Fragmentation); premortem FM2; executive summary (Key Deliverables):** Split campus is the default at Month 4 ("2-3 nodes of 250-500 MW", "at least 80% per node"); FM2 tripwire: "RTE indicates < 500 MW at any candidate node". Executive summary: "500 MW at Cambrai or split-campus topology".
- **Why it conflicts:** The documents do not say whether a split Phase 1 is 500 MW in total (for example 250+250), Cambrai 500 MW plus other nodes, or Cambrai only. The 30% tenant gate, the EUR 3B debt gate, the RTE letter, the EUR 250M-500M premium and the EUR 10B ceiling each depend on that answer. A 250 MW node cannot satisfy a 500 MW per-node RTE tripwire.
- **Suggested resolution:** Decide whether Phase 1 is a fixed 500 MW total (split across nodes) or one 500 MW node (Cambrai) with other nodes as Phase 2 candidates. Then restate each gate (RTE letter per node or total, 30% denominator, debt, premium) on that basis.

### 5. Land gate: parcel basis and acquisition premium (🟡 Medium) — needs a project decision

- **Project plan (Measurable); canonical land_option_gate and ecology_and_farmland; premortem FM4:** Gate: "at least 70% of the chosen topology's target parcel" optioned at no more than 15% above benchmark (first check Month 3, confirmed Month 4). Phase 1 node is about 900 ha; land for the full square is EUR 0.24B-0.40B for 16,100 ha.
- **Review 14 (#3):** Farmland relocation priced "at 1.5-2.0x benchmark value (EUR 15,000-25,000/ha for ~900 ha per 500 MW node = EUR 13.5M-45M per node)".
- **Why it conflicts:** A 1.5-2.0x price fails the 15% non-coercive option gate, so it cannot be a budgeted Phase 1 cost under the same plan. The arithmetic mixes 1.0x (EUR 13.5M) and 2.0x (EUR 45M). It is also unclear whether the 70% test applies to the full 161 km² square or the roughly 900 ha Phase 1 node, which are very different tasks to complete by Month 3-4.
- **Suggested resolution:** Define 'target parcel' (Phase 1 node plus option on expansion reserve, versus the full square) in the topology rule. Cost land at no more than 1.15x benchmark (EUR 15.5M-25.9M per 900 ha node, recomputed). Treat 1.5-2.0x as the gate-failure scenario that triggers the split.

### 6. Phase 1 cost stack composition, totals and headroom (🟡 Medium)

- **Canonical fallbacks_vs_budget_and_dates and phase1_ceiling_headroom_500mw:** Stack of EUR 1.55B-4.2B covers grid, split premium, carrying, remediation and fiber/subsea. Ecology, security, community and firm connection sit outside it (EUR 0.5B-1.15B), giving EUR 7.05B-10.35B in total.
- **Review 1 (#3), Review 3 (#3), Review 11 (#3), Review 12 (#3); pitch (Stacked Contingent Add-Ons):** Reviews 1, 11 and 12 put ecology, security and community inside the stack. The pitch lists 'Ecological remediation and expansion EUR 200M-500M' inside the stack and ecology again outside it. The pitch line items sum to about EUR 1.35B-3.4B (recomputed), not EUR 1.55B-4.2B. Review 3 states 'likely EUR 6.5B-7.5B for 500 MW'.
- **Why it conflicts:** The same lines are counted inside and outside the stack, so totals and headroom cannot be reproduced. The EUR 6.5B-7.5B estimate is not supported by EUR 6.55B-9.2B or EUR 7.05B-10.35B.
- **Suggested resolution:** Publish a single line-item table using the canonical split: stack lines (grid, split premium, carrying, remediation, fiber/subsea) summing to EUR 1.55B-4.2B, and outside-stack lines (ecology, security, community, firm connection). Remove the EUR 6.5B-7.5B claim. Keep the ceiling at EUR 10B and the maximum breach at EUR 0.35B.

### 7. USD hardware inside the ceiling: what the EUR 2.7B-3.5B represents (🟡 Medium)

- **Review 11 (#2); Review 8 (#2):** "If hardware is included in the EUR 10B ceiling and funded by the campus company ... about EUR 2.7B-3.5B remains for infrastructure". Review 8: hardware inclusion "leaving about EUR 2.7B-3.5B for infrastructure at the 500 MW base".
- **Canonical phase1_budget_range, usd_hardware_scope_open_decision, phase1_ceiling_headroom_500mw:** Infrastructure base for 500 MW is EUR 5.0B. Hardware is EUR 1.5B-2.3B. 10 - 5.0 - (1.5 to 2.3) = EUR 3.5B-2.7B, which is headroom above the base, not an infrastructure budget.
- **Why it conflicts:** EUR 2.7B-3.5B is the headroom left if hardware sits inside the ceiling. Calling it the infrastructure budget implies the EUR 5B base is cut roughly in half, and the forced 'scope reduction' follows from that misreading. The open decision (is hardware inside the EUR 5B-10B) stays open.
- **Suggested resolution:** Reword: if hardware is inside the EUR 10B ceiling, headroom above the EUR 5.0B base falls from EUR 5.0B to EUR 2.7B-3.5B (before the stack), so the stack of up to EUR 4.2B can breach the ceiling. If outside, headroom is unchanged. Keep the inclusion question as a Month 1 committee decision.

### 8. Foreign co-investor equity cannot be bound at FID vs equity-binding gate (🟡 Medium) — needs a project decision

- **Pitch (Ethical Considerations - National Security):** "foreign co-investor equity cannot be bound at FID before that clearance"; no binding foreign commitment beyond Phase 0 without a favorable informal ANSSI opinion and Month 12 written confirmation.
- **Executive summary (Purpose, Key Deliverables); canonical debt_financing_gate; review plan (Review 7):** Month 12 gate requires equity sources bound for Phase 1 (EUR 2B+ equity commitments); the investor profile is a consortium with sovereign-adjacent co-investors.
- **Why it conflicts:** If sovereign-adjacent or other foreign capital supplies a material share of the EUR 2.0B equity, the equity-binding gate cannot be met at Month 12, because formal clearance comes at about Months 25-31. The documents do not say how much equity is foreign or who covers a gap.
- **Suggested resolution:** State the foreign share of the EUR 2.0B equity and decide who backstops it: EU-domiciled non-controlling co-investors or sponsor equity (premortem FM6 option), or a conditional commitment that the gate accepts. Otherwise treat the Month 12 equity gate as conditional on clearance.

### 9. Energy shock sensitivities, pass-through framing and trigger levels (🟡 Medium)

- **Review 6 (KPI 2); executive summary (Feedback 5); canonical energy_volume_and_price:** Energy (EUR 60/MWh) is "passed through to tenants", yet a +EUR 30/MWh move 'adds about EUR 112M annual opex' and takes DSCR to 0.96x.
- **Premortem; self-audit; Reviews 1, 4, 5, 6:** Early-warning triggers differ for the same event: above EUR 70/MWh (premortem A2, FM3, Review 6), above EUR 75/MWh (self-audit #15, #20), EUR 80/MWh lease-revision level (Reviews 4 and 5), with a +/-EUR 5 collar (Review 6). Review 1 describes +EUR 30 as '50-70 to 100'.
- **Why it conflicts:** With pass-through the shock is a tenant-affordability and demand risk, not an NOI loss. The 0.96x DSCR applies only without pass-through (canonical). Three thresholds for one trigger confuse escalation. EUR 112M corresponds to +EUR 30 (for example 70 to 100); 50 to 100 is +EUR 50 (about EUR 186M, recomputed).
- **Suggested resolution:** Use one trigger (keep EUR 70/MWh as the proposed escalation level, since the premortem gates use it) and one lease-revision level. State that the DSCR 0.96x result is the no-pass-through stress, and that under pass-through the effect is tenant demand and lease discount. Correct the '50-70 to 100' wording.

### 10. Energization and Phase 1 start dates cited in the reviews (🟡 Medium)

- **Review 6 (KPI 3); Review 16 (#1); Review 14 (#2):** "If only 250 MW is signed by Month 36 energization"; "go live by Month 36 energization"; Phase 1 ramp tests framed from "Month 24 Phase 1 start".
- **Canonical phase_schedule_and_capacity and permitting_and_schedule_realism; executive summary:** Phase 1 starts at Month 12; first-block energization is Months 42-48 (downside 48-60).
- **Why it conflicts:** The same milestone carries Month 36 in the reviews and Months 42-48 elsewhere, and Phase 1 start is given as Month 12 and Month 24.
- **Suggested resolution:** Replace with Months 42-48 energization and Month 12 Phase 1 start; set the dashboard go-live and the ramp test dates to match.

### 11. DREAL screening opinion: Month 6 vs Month 9 (⚪ Low)

- **Executive summary (Timeline and Budget):** "RTE letter, water opinion, ANSSI preliminary and DREAL screening by Month 6".
- **Project plan (Permits, Compliance Actions); pitch; canonical ecology_and_farmland:** DREAL screening opinion by Month 9; permit file submitted Months 8-9. The executive summary's own Month 6 action list omits DREAL.
- **Why it conflicts:** The same milestone has two dates, and a Month 6 screening would come before the permit-file submission.
- **Suggested resolution:** Keep Month 9 (canonical) and delete DREAL from the executive summary's Month 6 list.

### 12. EDF 'binding contract' timing and the claimed EDF/tenant deadlock (⚪ Low)

- **Review 4 (#3):** "EDF's binding contract (target Month 9 or later)".
- **Canonical power_procurement_edf; executive summary; Reviews 5, 6 and 13:** EDF non-binding LOI by Month 6, term sheet by Month 9, binding contract not before FID; indicative price range requested by Month 4.
- **Why it conflicts:** A binding contract at Month 9 contradicts the plan. The 'both gates depend on each other' deadlock in Reviews 8 and 13 also overlooks that the Month 4 indicative price and Month 6 LOI come before tenant term sheets at Month 9.
- **Suggested resolution:** Keep 'LOI Month 6, term sheet Month 9, binding at or after FID'. Describe the deadlock risk as only the case where the Month 4 and Month 6 EDF items slip.

## Summary

Most canonical numbers (budget caps, tranches, DSCR, financing, gate thresholds) are used consistently, and many earlier conflicts have been fixed. Substantive problems remain in how Phase 1 is defined against energization, permitting and ANSSI clearance. The documents also do not say who funds a split-from-start overrun above the EUR 750M cap, what the ~1 GW kill test ends, or what a split-campus Phase 1 comprises in MW. The rest is repairable: cost-stack composition, hardware headroom wording, energy triggers, stray Month 36 energization dates and a DREAL date.