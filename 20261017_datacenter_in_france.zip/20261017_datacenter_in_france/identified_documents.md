
## Documents to Create

### 1. Investment Committee Charter and Governance Protocol

**ID:** 1dd7e8cb-6bf6-477d-a5fc-598a99eea13e

**Description:** Formal charter establishing the independent investment committee's composition (≥2 external directors, lender/co-investor observers), voting rules (supermajority two-thirds override, published dissent), numeric kill thresholds locked in writing (RTE ≥500 MW, ≥70% land optioned, ≥30% anchor-tenant take-or-pay, ANSSI pathway, ≥EUR 3B debt by Month 12 = 2027-10-17), red-team reporting protocols (direct to committee, monthly pass/fail), and dissent-publication mechanics to lenders within 5 business days. Primary audience: sponsor board, lenders, co-investors, investment committee members. Enforces gate discipline and prevents sunk-cost override.

**Responsible Role Type:** Independent Investment Committee Chair and Governance Officer

**Primary Template:** Project Finance Investment Committee Charter Template (Project Management Institute or World Bank Project Finance Handbook)

**Secondary Template:** Megaproject Gate Governance Protocol (Infrastructure UK / Crossrail lessons-learned documents)

**Steps:**

- Engage external counsel to draft charter language compliant with French law and lender expectations.
- Define numeric kill thresholds in table form with explicit pass/fail and conditional-pass criteria.
- Establish voting mechanics: simple majority for continuation, supermajority for override, single external-director veto authority.
- Specify red-team reporting line (direct to committee, not to sponsor), confidentiality protocols, and dissent-publication cadence (monthly to lenders, quarterly to co-investors).
- Obtain written signatures from all sponsors, lenders and co-investors before Phase 0 Tranche 1 (EUR 150M) is drawn.

**Approval Authorities:** Sponsor board, Chief Lenders (EIB, KfW or equivalent), Infrastructure Fund Co-Investors, External Committee Chair

### 2. Phase 0 Feasibility and Gate Summary Report

**ID:** fde5db7d-5045-45fa-8d3d-997e0e58113c

**Description:** Comprehensive Phase 0 findings document (Month 12 = 2027-10-17 gate deliverable) certifying pass/fail status for each of five gates: (1) RTE grid hosting capacity ≥500 MW with written preliminary letter, (2) land assembly ≥70% of target parcel optioned non-coercively, (3) anchor-tenant binding term sheets for ≥30% of Phase 1 capacity with cash fees in escrow, (4) ANSSI security clearance pathway confirmed with formal-review start date, (5) firm debt commitment ≥EUR 3B. Includes red-team independent opinion, any dissent from investment committee members, cost-baseline reconciliation (EUR 750M Phase 0 spend vs. budget), topology decision (single square or split campus), remediation liability allocation, and kill/downsize/pivot recommendations. Primary audience: lenders, co-investors, investment committee, phase 1 decision-makers.

**Responsible Role Type:** Phase 0 Program Manager and Red Team Lead

**Primary Template:** World Bank Project Appraisal Document (PAD) Gate Summary

**Secondary Template:** Major Project Review Board Decision Memorandum (UK Cabinet Office)

**Steps:**

- Compile evidence for each gate criterion from workstream leads (grid, land, commercial, security, finance).
- Commission independent red team to certify pass/fail on each threshold; publish any dissent or disputed findings.
- Reconcile Phase 0 budget execution (EUR 150M + EUR 250M + EUR 200M + EUR 150M = EUR 750M cap) against actual spend by tranche.
- Publish topology decision rationale: single square (if ≥1 GW confirmed by RTE and ≥70% land optioned) vs. split campus (default if either criterion fails).
- Model Phase 1 sensitivity under stress scenarios (10% lease discount, EUR 30/MWh energy shock, 15% capex overrun, grid reinforcement >EUR 1B).
- Define Phase 1 FID condition: proceed only if all five gates pass or conditional-pass (e.g., RTE ≥500 MW but ≥1 GW unconfirmed → reduce Phase 1 to 250 MW).
- Obtain signed approval from the investment committee, with any dissenting opinions appended and published to lenders.

**Approval Authorities:** Investment Committee, External Red Team Lead, Chief Lenders, Infrastructure Fund Co-Investors

### 3. RTE Grid Hosting Capacity and Transmission Reinforcement Assessment

**ID:** 1b81d8f7-4801-4c3a-a7e8-f021b2aa11e6

**Description:** Technical feasibility report from RTE (preliminary opinion Month 6 = 2027-04-17, firm offer Month 12 = 2027-10-17) certifying available grid connection capacity at candidate substations (Cambrai, Dunkirk, Valenciennes, Saint-Omer) for 250 MW, 500 MW, 1 GW and 2 GW tranches. Specifies required transmission reinforcement scope, cost allocation (RTE vs. developer), timeline to energization per tranche, annual curtailment allowance (proposed ≤10%, walk-away ≤15%), BESS and demand-flexibility commitments, and queue position vs. competing industrial load. Also includes independent third-party RTE hosting-capacity audit (EUR 1M–2M) published by Month 9 (2027-07-17) to validate RTE claims via parallel network modeling. Primary audience: investment committee, finance team, Phase 1 grid-design lead.

**Responsible Role Type:** Grid Connection and Power Infrastructure Strategist

**Primary Template:** RTE Connection Offer Template and Technical Feasibility Letter

**Secondary Template:** Independent Grid Audit Report (e.g., by Tractebel Engineering or equivalent)

**Steps:**

- File formal, dated RTE pre-engineering request (Month 0 = 2026-10-17) specifying four tranches, maximum PUE, average load profile, desired energization windows.
- Request RTE preliminary opinion by Month 4 (2027-02-17) and firm preliminary letter by Month 6 (2027-04-17).
- Commission independent RTE hosting-capacity auditor (Month 1 = 2026-11-17) to parallel-verify RTE claims using third-party network modeling tools (PSSE, DIgSILENT).
- Obtain written confirmation from RTE of: available MW per node, reinforcement scope and cost split, timeline to energization, curtailment terms and BESS requirements.
- Reconcile RTE letter with topology decision: if RTE offers <500 MW per node, document implications for split-campus default.
- Publish auditor findings (anonymized if needed) to investment committee and lenders by Month 9 (2027-07-17).

**Approval Authorities:** RTE (Réseau de Transport d'Électricité), Independent RTE Auditor, Investment Committee

### 4. Land Assembly Feasibility and Parcel Optionability Report

**ID:** f83b19d2-fe4f-48e6-a256-6ae760f00996

**Description:** Detailed land-assembly roadmap (deliverable Month 4 = 2027-02-17 for topology decision) documenting parcel-by-parcel ownership, fragmentation, holdout risk, valuation benchmarks, and option-agreement status for single-square Cambrai (161 km² notional envelope) and split-campus nodes (Cambrai 500 MW ~8.9 km², Dunkirk 250 MW, Valenciennes 250 MW). Certifies whether ≥70% of target parcel is optionable non-coercively at ≤15% above benchmark land value. Identifies known holdouts, activist farm groups (FNSEA, Confédération Paysanne), and municipal land-availability (port authorities, public owners). Includes Phase II ESA results bounding remediation liability (EUR 0–100M per site). Primary audience: investment committee, Phase 1 land-acquisition team, lenders.

**Responsible Role Type:** Land Assembly and Real Estate Strategist

**Primary Template:** Geographic Information Systems (GIS) Parcel Map with Land Ownership Overlay (ArcGIS or QGIS)

**Secondary Template:** Phase I/II Environmental Site Assessment Summary Report (ESA format per USEPA or French BRGM standards)

**Steps:**

- Commission GIS parcel surveys and ownership-chain research (Month 0 = 2026-10-17) across all four zones.
- Map public vs. private vs. agricultural ownership; identify FNSEA or union presence per parcel.
- Benchmark land values (EUR/ha) via DDT/DDTM registries and recent sales comps; document 15% above-benchmark threshold.
- Count optionable vs. at-risk parcels; flag holdouts and municipal/port authority dependencies.
- Commission Phase II intrusive surveys (soil boring, groundwater, asbestos) on top 2–3 parcels per zone by Month 3 (2027-01-17); publish Phase II ESA results by Month 6 (2027-04-17).
- Draft option-agreement terms and timeline; obtain non-binding expressions of interest from landowners by Month 3 (2027-01-17).
- By Month 4 (2027-02-17), certify ≥70% optionability or recommend split-campus topology pivot.

**Approval Authorities:** Land Assembly Lead, French Real Estate Counsel, Investment Committee

### 5. Anchor-Tenant Term-Sheet Template and Demand Validation Framework

**ID:** 81dcdb35-531f-4ec4-a728-fecfbd5ab50d

**Description:** Standardized take-or-pay lease template (deliverable Month 2 = 2026-12-17) specifying capacity reservation (50–500 MW per tenant), lease term (5–10 years), reservation fee (EUR 10M–50M per 100 MW, paid before construction and credited to rent), power price (indexed or capped EUR/MWh with ±3% annual escalation cap proposed), uptime SLA (99.5–99.95%, force-majeure carve-outs for curtailment and cooling outages >4 hours), take-or-pay clause, and liquidated-damages provision (10–15% of first-year lease revenue if tenant exits post-FID). Document distinguishes binding term sheets (exclusive, payment commitment) from non-binding LOIs (site-comparison tool, do not count toward gates). Includes process for securing cash reservation-fee deposits in escrow, parent-company guarantees for sub-investment-grade tenants, and credit-rating monitoring (S&P, Moody's quarterly updates). Primary audience: commercial development team, anchor tenants, lenders.

**Responsible Role Type:** Anchor-Tenant and Market Development Lead

**Primary Template:** Master Service Agreement (MSA) Template for Data Center Capacity Leases (AWS, Microsoft or equivalent precedent)

**Secondary Template:** Take-or-Pay Lease Agreement with SLA and Force-Majeure Carve-Outs (project-finance standard form)

**Steps:**

- Engage commercial counsel to draft term-sheet language covering capacity, pricing, term, SLAs, take-or-pay mechanics, and exit penalties.
- Define what constitutes 'binding' (reservation-fee cash, liquidated damages, parent guarantee if credit <BBB−).
- Specify force-majeure carve-outs: RTE curtailment >15% annual, cooling outage >4 hours, ANSSI clearance delay >X months.
- Develop power-price pass-through mechanics: indexed to EDF/RTE settlement price with tenant cap (e.g., ±3% escalation).
- Create tenant credit-monitoring protocol: counterparty rating downgrade >1 notch triggers collateral posting (12-month lease escrow).
- By Month 3 (2027-01-17), identify 2–3 anchor-tenant prospects by name and pre-brief on terms.
- By Month 9 (2027-07-17), execute binding term sheets with ≥150 MW (30% of Phase 1) and confirm reservation-fee cash deposits in escrow.
- Document tenant credit quality (A− to BB+ minimum) and any parent-company guarantees.

**Approval Authorities:** Anchor-Tenant Lead, General Counsel, Investment Committee (for gate approval)

### 6. National Security and Foreign Investment Screening Assessment

**ID:** 15ad112b-b9b8-4ca8-9541-acfa10700686

**Description:** Confidential white paper and formal assessment (Month 6 = 2027-04-17 informal opinion, Month 12 = 2027-10-17 clearance-pathway confirmation) documenting: project scope, tenant types and data-residency requirements, foreign co-investor shareholding and governance, proposed security architecture (perimeter hardening, anti-drone, cyber-OT separation, personnel vetting), and anticipated national-security review scope and timeline with ANSSI, DGSI and DGSE. Identifies potential blocking concerns (foreign equity restrictions, data-residency zones, state observer roles) and proposes mitigation (governance restructuring, data policies). Includes confidential ANSSI/DGSI pre-submission meeting summary (Month 0–1 = 2026-10-17 to 2026-11-17) and formal preliminary opinion letter confirming that security review can start (Month 13 = 2027-11-17) with 12–18 month target clearance. Primary audience: ANSSI/DGSI, foreign co-investors, investment committee, Phase 1 security design team.

**Responsible Role Type:** National Security and Regulatory Affairs Lead

**Primary Template:** ANSSI/DGSI Pre-Submission White Paper (confidential, French government format)

**Secondary Template:** Foreign Investment Screening Impact Assessment (CFIUS precedent or EU equivalent)

**Steps:**

- Draft white paper (10–15 pages) covering tenant mix, foreign co-investor details, data-residency policies, security design baseline.
- Schedule confidential pre-submission meetings with ANSSI, DGSI and DGSE (Month 0 = 2026-10-17).
- Commission high-assurance security-design roadmap (EUR 500K–1.5M, Month 2 = 2026-12-17) covering perimeter, OT separation, supply-chain vetting, personnel clearance standards.
- Share roadmap informally with ANSSI (Month 3 = 2027-01-17) for preliminary feedback.
- Obtain written ANSSI preliminary opinion (Month 6 = 2027-04-17) confirming review timeline and blocking concerns (if any).
- By Month 12 (2027-10-17), secure written confirmation that formal security review can start (Month 13 = 2027-11-17) with no fundamental blocking concerns.
- Coordinate with foreign co-investor legal counsel on governance and investment-screening mitigation.

**Approval Authorities:** ANSSI, DGSI, DGSE (French national-security agencies), Foreign Co-Investor Legal Counsel, Investment Committee

### 7. Environmental Baseline Assessment and EIA Strategy

**ID:** 7d3dc740-7c95-43a7-a7f1-7d4c818e85a5

**Description:** Comprehensive environmental assessment (Phase 0 deliverable, with DREAL screening opinion by Month 9 = 2027-07-17) covering Phase I/II ESA, hydrology and water-balance, ecology and biodiversity (Natura 2000, protected species, habitat surveys), soil and groundwater contamination, and stormwater/drainage. Produces a campus-wide ecological master plan (due Month 6 = 2027-04-17) with avoidance-reduction-compensation strategy; remediation liability allocation (private sellers, public bodies, escrow); water-authority opinion on dry-cooling feasibility at zero evaporative water; and preliminary EIA scope for one or more permit filings (single application for integrated campus vs. per-node filings). Identifies any contamination or ecological constraints that would trigger topology pivot or Phase 1 downsize. Primary audience: DREAL, prefecture, water authority (Agence de l'Eau), lenders, permitting counsel.

**Responsible Role Type:** Environmental and Permitting Counsel

**Primary Template:** Phase I/II Environmental Site Assessment Report (French BRGM or USEPA format)

**Secondary Template:** EIA Scoping Document and Ecological Compensation Master Plan (per French Code de l'environnement Articles R.181 et seq.)

**Steps:**

- Commission Phase I desktop assessments (Month 1 = 2026-11-17) on all candidate parcels.
- Commission Phase II intrusive surveys (Month 1 = 2026-11-17, delivered Month 3 = 2027-01-17, EUR 1.5M–3M per zone) covering soil boring, groundwater sampling, asbestos inventory, ordnance risk.
- Engage environmental baseline team (ecology, hydrology, soil specialists) to conduct summer field surveys (botanical, avian, invertebrate, bat) across all candidate sites; deliver by Month 4 (2027-02-17).
- Commission hydrological study (EUR 800K–1.5M) covering water balance, drought frequency, and cooler performance at 35°C; deliver by Month 5 (2027-03-17).
- Draft ecological master plan (Month 5 = 2027-03-17) with avoidance zones (no-build areas protecting Natura 2000), mitigation (landscaping, habitat creation), and compensation parcels (offsite restoration); due Month 6 (2027-04-17).
- Obtain written water-authority opinion (Month 6 = 2027-04-17) on dry-cooler feasibility at zero evaporative water.
- Prepare preliminary EIA file for DREAL screening (Month 6 = 2027-04-17); obtain formal screening opinion by Month 9 (2027-07-17).
- Identify any Phase II results (contamination >EUR 100M, protected-species conflict, water-authority restriction) that would trigger topology pivot or capacity downsize; escalate to investment committee.

**Approval Authorities:** DREAL (Directions Régionales de l'Environnement, de l'Aménagement et du Logement), Regional Water Authority (Agence de l'Eau Artois-Picardie), Environmental Counsel

### 8. Brownfield Liability Allocation Framework and Indemnity Agreements

**ID:** c5aa5aba-6292-446b-95d1-26254c4d7234

**Description:** Template legal documents and allocation strategy (deliverable Month 2 = 2026-12-17, with execution by Month 6 = 2027-04-17) specifying: Remediation Specification and Cost Cap (RSC) agreements for private sellers capping liability per parcel at EUR 0–100M with recapture clause if overruns exceed 20%; Certification of Remediation Responsibility (CRR) for public landowners allocating all pre-existing contamination to the public body with written certification of safe release before title transfer; escrow structure for Phase 0 and Phase 1 (third-party held, released on certified remediation completion); and long-term indemnity terms (proposed 10–15 years) with annual audit rights. Includes Phase II ESA summary and site-specific remediation scope per parcel. Primary audience: private landowners, public land managers, escrow trustee, Phase 1 construction and remediation teams, lenders.

**Responsible Role Type:** Brownfield Remediation and Environmental Liability Counsel

**Primary Template:** Environmental Indemnity and Liability Allocation Agreement (French environmental law / Code de l'environnement Article L.512-17)

**Secondary Template:** Remediation Specification and Cost Cap Template (project-finance precedent)

**Steps:**

- Engage French environmental counsel to draft RSC and CRR templates compliant with French law and bankable by lenders.
- Define 'pre-existing contamination' per Phase II ESA baseline; establish cost cap and recapture mechanics (seller contributes if overrun >20%).
- For public bodies, negotiate written CRR allocating legacy liability and requiring pre-site-release certification.
- Establish escrow trustee (proposed independent bank or insurance provider) to hold remediation reserve (EUR 100M–200M Phase 1 estimate).
- By Month 3 (2027-01-17), finalize Phase II surveys and generate site-specific remediation designs.
- By Month 4 (2027-02-17), obtain signed RSC (private) or CRR (public) on ≥70% of targeted parcels.
- By Month 6 (2027-04-17), confirm escrow funding and indemnity agreements are in place for all Phase 1 parcels.
- Include indemnity audit-rights clause: annual technical review of seller/public-body's remediation completion and financial backing.

**Approval Authorities:** Private Landowners, Public Land Managers, Escrow Trustee, Environmental Counsel, Lenders

### 9. Power Procurement and Energy Supply Agreement

**ID:** 3afc753c-18fd-4533-9510-2bf2ef6627de

**Description:** Non-binding LOI (Month 6 = 2027-04-17 preliminary, target) and binding term sheet (Month 12 = 2027-10-17 for Phase 1 FID) with EDF and RTE specifying baseload supply (nuclear-backed or equivalent), renewable PPAs, BESS and demand-flexibility commitments. Covers: at least 500 MW base supply for Phase 1, all-in delivered price (EUR 50–75/MWh, estimate, with ±3% annual indexation cap proposed), 10-year minimum tenor, pass-through mechanics to tenants (indexed price or fixed price with escalation clause), BESS size (50–200 MWh) and arbitrage revenue sharing, and curtailment and BESS dispatch protocols with RTE. Non-binding preliminary agreement by Month 6 (2027-04-17) allows pricing uncertainty to inform anchor-tenant negotiations; binding contract not before Phase 1 FID (Month 12 = 2027-10-17). Primary audience: lenders (debt service coverage depends on stable power cost), anchor tenants (lease pricing indexed to power), investment committee (energy cost is a financial gate).

**Responsible Role Type:** Grid Connection and Power Infrastructure Strategist

**Primary Template:** Master Power Purchase Agreement (MPPA) Template (EDF or Électricité de France standard form)

**Secondary Template:** Energy Supply Agreement with Indexed Price and BESS Dispatch Clauses (project-finance precedent)

**Steps:**

- Initiate EDF and RTE power-supply discussions (Month 1 = 2026-11-17) specifying Phase 1 volume (500 MW average, ~3.7 TWh/year), pricing window (EUR 50–75/MWh), and tenor requirements (≥10 years).
- Commission independent power-market study (Month 2 = 2026-12-17, EUR 200K–400K) projecting European wholesale and baseload prices, renewable-PPA costs, and nuclear availability for data centers.
- Develop term-sheet template (Month 2 = 2026-12-17) covering: capacity and energy components, indexed or fixed pricing with escalation caps, BESS size and dispatch rights, curtailment and frequency-support obligations.
- Submit non-binding LOI to EDF (Month 4 = 2027-02-17); target preliminary agreement by Month 6 (2027-04-17).
- Use preliminary agreement to inform anchor-tenant term-sheet pricing (energy pass-through at EDF price + campus markup).
- Finalize binding term sheet with EDF (Month 12 = 2027-10-17) contingent on Phase 1 FID; secure commitment for BESS charging/discharging terms.
- Publish energy cost and indexation assumptions to lenders for DSCR stress-testing (10% energy price shock scenario).

**Approval Authorities:** EDF (Électricité de France), RTE (Réseau de Transport d'Électricité), Lenders (DSCR covenant depends on power cost stability)

### 10. Thermal Design Basis and Cooling System Validation Report

**ID:** dc9d3403-593e-4846-adfc-f522a9c7ffc9

**Description:** Phase 0 deliverable (Month 5 = 2027-03-17) from independent thermal consultant documenting: vendor dry-cooler performance curves (Thermax, Hydac, Modine minimum) at 35–40°C ambient, modeled PUE vs. ambient temperature and rack power density (100–200 W/m²), thermal load profile (peak summer, average annual), fouling and part-load degradation, and forced contingency decision tree (if PUE >1.30, commit to hybrid cooling or load shedding). Includes site-specific thermal modeling for Cambrai, Dunkirk and Valenciennes nodes, heat-rejection area sizing, immersion-cooling pilot feasibility assessment (10–50 MW optional scale), and heat-offtake opportunity mapping (district heating, industrial users within 5 km). Cooling gate at Month 5 (2027-03-17): if modeled PUE exceeds 1.28, triggers design review and investment committee decision (hybrid pivot, curtailment acceptance, or capacity downsize). Primary audience: lenders (PUE affects peak grid load and curtailment risk), RTE (grid-reserve planning), Phase 1 design team, investment committee.

**Responsible Role Type:** Thermal, Cooling and Hydrology Engineer

**Primary Template:** Data Center Thermal Modeling Report (ASHRAE or equivalent standard)

**Secondary Template:** PUE Sensitivity Analysis and Design-Day Stress Test (vendor cooling software output, e.g., TRNSYS, EnergyPlus)

**Steps:**

- Commission independent thermal consultant (EUR 300K–600K) by Month 1 (2026-11-17).
- Obtain detailed dry-cooler performance curves from vendors (Thermax, Hydac, Modine, SPX) covering full ambient range (15–40°C), fouling factors, and part-load curves.
- Conduct site-specific thermal modeling for each candidate node using measured summer weather data (July–August peaks, humidity, wind); model three scenarios (100 W/m², 150 W/m², 200 W/m² rack density).
- Generate PUE vs. ambient chart; identify 35°C design-day PUE; if >1.28, flag for design review.
- Model immersion-cooling pilot (10–50 MW) as an alternative if dry-cooler PUE is marginal; document inlet temperature, dielectric fluid, waste-heat temperature and parasitic load.
- Identify heat-offtake opportunities: district-heating networks and industrial users within 5 km; estimate heat potential (MWth) and rough pipeline costs.
- By Month 5 (2027-03-17), deliver report to investment committee; if PUE threshold breached, commit to hybrid cooling, BESS contingency (for grid-load smoothing), or capacity downsize.
- By Month 6 (2027-04-17), confirm final PUE assumption and water-authority alignment.

**Approval Authorities:** Independent Thermal Consultant, Investment Committee, Lenders (debt service coverage depends on forecast PUE), RTE (grid-load projections)

### 11. Municipal Liaison Committee Charter and Community-Benefit Agreement

**ID:** 38413a9c-71db-49ea-8398-972aeb35bdab

**Description:** Formal charter (Month 1 = 2026-11-17) and binding agreement (executed by Month 9 = 2027-07-17) specifying: municipal liaison committee composition (mayors, regional councillors, farm unions FNSEA/Confédération Paysanne, environmental NGOs, independent facilitator), quarterly meeting schedule with published minutes, and structured community-benefit package (EUR 50M–150M over Phases 1–2) including direct income transfers to affected municipalities (EUR 10M–15M per 100 MW), farm relocation compensation (1.5–2.0× benchmark land value), ecological restoration co-management, local employment and training commitments (≥50% construction labor from region, ≥30% within 50 km), and infrastructure upgrades (EUR 10M–30M). Gate: written signatures from at least 2 of 3 key municipalities by Month 9 (2027-07-17) required for Phase 0 gate closure (Month 12 = 2027-10-17). Absence of signatures triggers investment committee reassessment of Phase 1 feasibility on social-license grounds. Primary audience: municipalities, farm unions, environmental groups, investment committee, lenders.

**Responsible Role Type:** Community Engagement and Social License Manager

**Primary Template:** Community Benefit Agreement Template (International Association for Public Participation / IAP2 standard form)

**Secondary Template:** Municipal Liaison Committee Charter and Terms of Reference (French local-government precedent)

**Steps:**

- Establish liaison committee by Month 1 (2026-11-17) with formal representation from affected municipalities (Cambrai, Dunkirk, Valenciennes area), farm unions, NGOs, and independent facilitator.
- Commission social-impact study (EUR 300K–600K) covering farmer interviews (100+), resident survey (500+), NGO engagement (identify key groups and concerns); deliver by Month 4 (2027-02-17).
- Conduct early voluntary public consultation (Month 3 = 2027-01-17) with published project overview, environmental commitments, and benefit package outline; 4-week comment period, published responses.
- Draft binding community-benefit agreement (Month 5 = 2027-03-17) with specific EUR amounts (not ranges) and implementation timeline: direct municipal income, farm relocation scale and rates, ecological restoration sites and co-management structure, training academy targets, and infrastructure upgrades list.
- Present draft to liaison committee for negotiation (Months 5–8 = 2027-03-17 to 2027-06-17); target signatures from 2 of 3 municipalities by Month 9 (2027-07-17).
- Lock implementation schedule and escrow for benefit-package funding.
- Publish liaison-committee minutes quarterly and track benefit-package progress during Phase 1.

**Approval Authorities:** Mayors of Affected Municipalities, Regional Prefectures, Farm Union Leaders, Environmental Group Signatories, Investment Committee (gate approval)

### 12. Fiber Connectivity and Route-Diversity Audit Report

**ID:** 397b2344-bbcf-4b3c-847d-e8c3970e6c44

**Description:** Technical audit (deliverable Month 9 = 2027-07-17) certifying physical duct-level separation for at least 2 independent routes to each hub (Paris, London, Brussels, Amsterdam, Frankfurt, Marseille, subsea). Includes carrier-by-carrier duct maps, shared-facility inventory, alternative-corridor analysis, and written confirmation from carriers on disclosure of shared infrastructure and annual audit rights. Subsea-cable landing-point audit confirms ≥2 independent UK landings and ≥2 FR/BE landings, with no single landing carrying >25% of cross-border capacity. Identifies any gaps requiring developer-owned or co-invested dark fiber (EUR 500K–2M per km, budget EUR 100M–300M contingency). Binding capacity reservations or LOIs from at least 1 carrier per route by Month 9 (2027-07-17) confirming Phase 1 activation (by Month 42–48 = 2030-04-17 to 2030-10-17). Primary audience: investment committee (fiber gate), Phase 1 design and procurement team, lenders (connectivity SLA affects debt covenants).

**Responsible Role Type:** Fiber and Digital Infrastructure Route Strategist

**Primary Template:** Fiber Route Audit Report with Duct-Level Diversity Verification (TeleGeography or equivalent)

**Secondary Template:** Subsea Cable Consortium Capacity Reservation Agreement (non-binding LOI format)

**Steps:**

- Commission third-party fiber-route auditor (EUR 100K–200K, Month 1 = 2026-11-17) to produce detailed duct maps and shared-facility inventory for all candidate routes.
- Request carrier-provided duct-separation documentation and physical-route surveys confirming true diversity (not just carrier marketing claims).
- Map subsea-cable consortia landing at Calais, Dunkirk, Marseille, and cross-Channel UK points; document capacity booking timelines (typically 18–36 months).
- By Month 4 (2027-02-17), issue subsea-cable consortium capacity inquiries (non-binding, 100+ Tbps total Phase 1–2 aggregate) to at least 2 consortia; target preliminary responses by Month 6 (2027-04-17).
- By Month 9 (2027-07-17), publish audit findings to investment committee and lenders.
- Obtain written confirmation that at least 2 independent routes per hub and at least 2 separate subsea landings are available, with no single landing >25% of capacity.
- If gap exists (e.g., Dunkirk no independent subsea route), budget developer dark-fiber build (EUR 100M–300M, 18–30 months) or identify third-party co-investment opportunity.

**Approval Authorities:** Independent Fiber Auditor, Telecom Carriers, Subsea Cable Consortia, Investment Committee (fiber gate approval)

### 13. Phase 1 Cost Baseline and Budget Reconciliation Model

**ID:** f61c6bf5-e1b8-4289-b590-5df88ab6a3cd

**Description:** Detailed financial model (deliverable Month 9 = 2027-07-17) reconciling all Phase 1 cost lines against the EUR 10B user ceiling (user constraint) for the 500 MW base case. Breaks down capex into: (i) committed cost lines with ≤5% uncertainty (shell, power, primary cooling, main fiber, perimeter) estimated EUR 4.0B–4.5B; (ii) contingent-but-likely costs (grid co-funding EUR 0.5B–1.5B, remediation EUR 0.1B–0.3B, secondary fiber EUR 0.2B–0.6B, ecological compensation EUR 0.2B–0.3B) at 60% probability of occurrence; (iii) low-probability exposures (contamination discovery, ANSSI retrofit, subsea build, long-delay carrying cost) EUR 0.2B–0.5B at 20–30% probability. Maps each cost line to funding source (debt EUR 3.0B, equity EUR 2.0B, or risk transfer via insurance/indemnity). Identifies which stacked-contingent add-ons (grid reinforcement, split-campus premium, ecological, fiber, subsea) must be cut if total exceeds EUR 10B. Tests DSCR under stress (10% lease discount, EUR 30/MWh energy shock, 15% capex overrun) and shows Phase 1 downsize trigger if DSCR falls below 1.15x. Primary audience: lenders (debt underwriting), investment committee (budget gate), Phase 1 FID decision-makers.

**Responsible Role Type:** Infrastructure Finance and Capital Structure Lead

**Primary Template:** Project Finance Cost Estimate and Contingency Analysis (PMI Project Management Body of Knowledge / PMBOK)

**Secondary Template:** Risk-Adjusted Capex Model with Sensitivity Analysis (infrastructure-fund precedent)

**Steps:**

- Compile bottom-up capex estimates from all workstream leads (grid EUR 50M–500M, cooling EUR 400M–800M, security EUR 50M–200M, etc.); reconcile into base case.
- Stratify cost lines by uncertainty: committed (design-complete, vendor quotes locked) vs. contingent (scoped but not finalized) vs. exploratory (optional, low probability).
- Map contingencies to probability-weighted cost ranges; consolidate overlapping exposures (e.g., grid co-funding and split-campus both trigger on RTE capacity shortfall).
- For each contingency, identify funding source: debt (constrained by covenant), equity (subject to co-investor approval), or third-party transfer (insurance, seller indemnity, public grant).
- Model DSCR sensitivity: base case 1.34x at 500 MW EUR 550M lease revenue, EUR 60/MWh energy; stress scenarios with 10% lease discount (1.15x), 20% energy shock (1.04x), 15% capex overrun (1.28x).
- Define Phase 1 downsize rules: if total capex forecast reaches EUR 8.0B (300 MW budget remaining), reduce Phase 1 target to 375 MW or defer expansion.
- Publish model to lenders and investment committee by Month 9 (2027-07-17) with assumptions and risk ratings.
- Lock revised Phase 1 ceiling (proposed EUR 8.0B for 500 MW, leaving EUR 2.0B contingency within the EUR 10B ceiling) by Month 12 (2027-10-17).

**Approval Authorities:** Finance Lead, Lenders, Investment Committee, Phase 1 FID Board

### 14. Debt Financing Framework and Term-Sheet Template

**ID:** 7da4f58a-af0c-490c-8539-a83ab5722a72

**Description:** Non-binding debt-financing study (Month 4 = 2027-02-17, EUR 200K–400K) and lender-engagement roadmap defining Phase 0 pre-screening (Month 3 = 2027-01-17) with 2–3 lead lenders (proposed EIB, KfW, French banks), lending criteria, leverage targets (60% for 500 MW, EUR 3B senior debt), tenor requirements (minimum 12 years, proposed 15 years), pricing benchmarks (proposed benchmark +200 bps all-in at 5.5% estimate), and covenant framework (DSCR floor 1.30x, leverage ceiling 60% LTV). Includes DSCR stress model under key-risk scenarios and identifies which cost lines and tensor reductions trigger debt-cap enforcement. Non-binding term-sheet from lead lender(s) targeted Month 9 (2027-07-17); firm commitment by Month 12 (2027-10-17) contingent on Phase 0 gates closing. Specifies drawdown tranches tied to Phase 1 milestones (grid connection signed, first hall operational, stabilized PUE). Primary audience: lenders, investment committee, Phase 1 FID sponsor.

**Responsible Role Type:** Infrastructure Finance and Capital Structure Lead

**Primary Template:** Project Finance Term Sheet Template (EIB or World Bank precedent)

**Secondary Template:** Debt Covenant and Financial-Ratio Monitoring Framework (project-finance standard form)

**Steps:**

- Engage 2–3 lead lenders (Month 1 = 2026-11-17) with preliminary project overview and financing requirements.
- Commission independent debt-structuring study (Month 3 = 2027-01-17) modeling leverage, tenor and cost-of-capital for 500 MW and 1 GW cases at various certainty levels (100% demand, 70% demand, 50% demand).
- Develop term-sheet template (Month 2 = 2026-12-17) specifying: loan amount (EUR 3.0B for 500 MW), tenor (15 years proposed), pricing (benchmark +200 bps, 5.5% all-in estimate), financial covenants (DSCR ≥1.30x, leverage ≤60%), drawdown conditions (grid connection, minimum anchors signed, first-hall energization), and other-debt restrictions.
- By Month 6 (2027-04-17), brief lenders on Phase 0 findings (RTE letter, land assembly, ANSSI clearance path, water authority opinion) to signal project maturity.
- Distribute non-binding NBCE (non-binding credit estimate) from lenders by Month 9 (2027-07-17), committing to term-sheet finalization by Month 12 (2027-10-17).
- Lock covenants with lenders: DSCR floor 1.30x (1.15x emergency waiver clause with 12-month cure), leverage ceiling 60%, and annual debt-service reserve-account minimum equal to 1.5× upcoming annual debt service.
- Require lender sign-off on Phase 1 capex budget reconciliation (Month 9 = 2027-07-17) before term sheet can be finalized.

**Approval Authorities:** Lead Lenders (EIB, KfW, French Banks), Infrastructure Fund Co-Investors, Investment Committee

### 15. Topology Decision Framework and Scenario Modeling

**ID:** 25c38ece-c23c-45e8-b4bb-2c4e55284993

**Description:** Decision framework (due Month 4 = 2027-02-17) documenting single-square vs. split-campus evaluation against numeric criteria: (1) RTE grid-hosting capacity (≥1 GW = single-square viable; <1 GW = split-campus default); (2) land assemblability (≥70% optionable non-coercively at ≤15% above benchmark = single-square viable; <70% = split-campus); (3) capex and schedule impact (single-square EUR 5.0B over Months 12–36 = 2027-10-17 to 2029-10-17; split-campus 2 nodes EUR 6.5B–7.5B over Months 12–42 = 2027-10-17 to 2030-04-17 phased). Includes detailed split-campus node designs for (Cambrai 500 MW + Dunkirk 250 MW), (Cambrai 500 MW + Valenciennes 250 MW), and (all three 250 MW each), with per-node capex, grid-connection timelines, permitting parallelization, and inter-node fiber-latency constraints. Model shows topology lock cannot be final until RTE evidence (due Month 6 = 2027-04-17) arrives, so Month 4 (2027-02-17) decision is conditional unless RTE preliminary-feasibility is already in hand. Primary audience: investment committee, Phase 1 design team, lenders.

**Responsible Role Type:** Phase 0 Program Manager and Red Team Lead

**Primary Template:** Multi-Scenario Infrastructure Design Comparison (World Bank or OECD project appraisal precedent)

**Secondary Template:** Topology and Scaling Analysis (data-center feasibility template)

**Steps:**

- Model single-square scenario: Cambrai/E-Valley 161 km² envelope, 500 MW Phase 1 infrastructure, EUR 5.0B capex, grid timeline dependent on RTE offer, permitting single coordinated application.
- Model split-campus scenario: Cambrai primary (500 MW), Dunkirk secondary (250 MW), Valenciennes tertiary (250 MW optional); independent grid connections, parallel permitting, inter-node dark fiber (EUR 200M–300M estimated), per-node operations team.
- For each scenario, map: required RTE tranches, land-assembly complexity per node, per-node capex and schedule, inter-node latency (model against 50 ms training tolerance and 10 ms inference tolerance), fiber-route requirements, and cumulative permitting risk.
- Develop decision logic: single-square requires BOTH RTE ≥1 GW written evidence AND ≥70% land optionable; if either fails by Month 4 (2027-02-17) hard stop (or Month 6 = 2027-04-17 if conditional), pivot to split-campus.
- Quantify cost and schedule impact of topology pivot mid-Phase-0: redesign costs EUR 100M–250M, schedule slip 6–12 months, stranded Phase 0 work on abandoned single-square parcel/grid studies.
- Document in writing what evidence from RTE (preliminary-feasibility letter by Month 4 = 2027-02-17) would allow single-square to remain viable if land assembly is also on track.
- By Month 4 (2027-02-17), publish topology recommendation to investment committee with pass/fail on each criterion.

**Approval Authorities:** Investment Committee, Grid Connection Lead, Land Assembly Lead

### 16. Phase 0 Risk Register and Red-Team Monthly Status Reports

**ID:** eff08abf-5ab6-49d8-8c08-ae2eba2558b1

**Description:** Living risk register (initiated Month 1 = 2026-11-17, updated monthly through Month 12 = 2027-10-17) tracking 23 material risks across regulatory, technical, financial, environmental, social and operational domains (per canonical facts risk taxonomy). Each risk entry specifies: title, description, impact/likelihood/severity, current status (red/yellow/green), actions taken, responsible owner, and escalation trigger. Red-team monthly status reports (1-page pass/fail summary per gate criterion: RTE, land, tenants, ANSSI, water, ecology, permitting, financing) published to investment committee and lenders by the 15th of each month, with any trend toward threshold breach flagged as yellow (>20% failure risk) or red (>50% failure risk). Month 12 (2027-10-17) final red-team opinion (signed) summarizes evidence for each gate and any dissent. Primary audience: investment committee, lenders, Phase 1 FID decision-makers.

**Responsible Role Type:** Phase 0 Program Manager and Red Team Lead

**Primary Template:** Project Risk Register (PMI PMBOK or Infrastructure UK Standard)

**Secondary Template:** Monthly Project Health Report (traffic-light scoring per gate criterion)

**Steps:**

- Initialize risk register in Month 1 (2026-11-17) with 23 canonical risks from risk-assessment documents.
- For each risk, define: trigger indicator (how to measure if risk is materializing), owner (workstream lead responsible for mitigation), action plan (specific steps and timeline), and escalation path (to investment committee if risk status turns yellow or red).
- Commission external red team (EUR 2M–5M contract, Month 1 = 2026-11-17) to publish monthly pass/fail assessments independent of development team.
- Red team delivers 1-page monthly summary by 15th of each month (Months 1–12 = 2026-11-17 to 2027-10-17) covering: RTE status (confidence in 500 MW letter by Month 6 = 2027-04-17?), land assembly (% optioned, holdout risk), tenant commitments (MW signed, cash deposited), ANSSI clearance (timeline credible?), permitting (filing on track for Month 9 = 2027-07-17?), water-authority opinion (received?), financing (lender appetite confirmed?). Each item rated green (on track), yellow (at risk), or red (threshold breach likely).
- Escalate any red-status item immediately to investment committee with recommended action (proceed, pause, downsize, kill).
- Month 12 (2027-10-17): red team delivers signed final opinion on all five Phase 0 gates, with any dissent or contested assumptions appended.

**Approval Authorities:** External Red Team Lead, Investment Committee, Lenders (observers)

### 17. Phase 1 FID Decision Memorandum and Gate Closure Report

**ID:** 415cfdc8-0393-4029-9209-e2d59c1790a5

**Description:** Formal decision document (Month 12 = 2027-10-17) signed by the investment committee authorizing Phase 1 Final Investment Decision or recommending Phase 1 pause/downsize/cancellation. Certifies pass or conditional-pass status on all five gates (RTE, land, tenants, ANSSI, financing), summarizes red-team findings and any dissent, models Phase 1 financial outcomes (DSCR, NPV, IRR) under base and stress scenarios, and specifies Phase 1 scope: 500 MW single-node or 750 MW split-campus (if topology pivots). Includes signed attestation from committee members regarding gate evidence quality, any override votes with dissenting opinions appended, and post-FID conditions (e.g., debt drawdown only after grid connection signed, first anchor tenant mobilization confirmed). Primary audience: Phase 1 board authorization, lenders (commitment confirmation), co-investors (capital call timing).

**Responsible Role Type:** Investment Committee Chair

**Primary Template:** Project Finance FID Decision Memorandum (World Bank or EIB precedent)

**Secondary Template:** Megaproject Gate-Review Summary (UK Major Projects Review Board format)

**Steps:**

- Compile evidence for each gate from workstream leads (grid letter, land survey, tenant term sheets, ANSSI opinion, debt commitment letter).
- Red team provides signed pass/fail opinion on each gate with any contested findings highlighted.
- Investment committee votes: all five gates must pass (or conditional-pass with defined mitigation) for FID authorization.
- If any gate fails outright (e.g., RTE <250 MW, no anchor tenants signed), committee recommends Phase 1 pause/downsize and specifies conditions for restart.
- Document any dissenting votes and the dissenting director's rationale; publish to lenders within 5 business days.
- Specify Phase 1 scope and financing terms: 500 MW EUR 5.0B (EUR 3.0B debt, EUR 2.0B equity) vs. 750 MW split EUR 6.5B–7.5B vs. 250 MW downsize EUR 2.5B.
- Define post-FID conditions for debt drawdown: Tranche 1 release (Month 13–14 = 2027-11-17 to 2027-12-17) upon grid connection agreement signed, Tranche 2 (Month 18–24 = 2028-04-17 to 2028-10-17) upon first anchor tenant mobilization, Tranche 3 (Month 24–36 = 2028-10-17 to 2029-10-17) upon first hall operational.
- Publish FID memo to lenders (commitment confirmation), co-investors (capital-call notice), and Phase 1 team (design authorization).

**Approval Authorities:** Investment Committee (supermajority vote), Chief Lenders (debt-commitment confirmation), Co-Investors (equity commitment confirmation)

### 18. Heat-Demand and Heat-Offtake Opportunity Study

**ID:** 38d71843-b208-403b-9e37-5aca4a907fb1

**Description:** Commercial analysis (EUR 400K–800K, deliverable Month 2 = 2026-12-17) mapping thermal-demand sources within 5 km of each candidate node: district-heating networks (Dunkirk), industrial heat users (breweries, food processing, paper mills), and greenhouse operations. For each prospect, estimates: thermal-demand profile (MWth, seasonal variation, operating hours), heat-offtake probability, willingness to pay (EUR/MWh or indexed to natural gas), and pipeline-delivery cost (EUR 50M–200M estimated per node). By Month 7 (2027-05-17), secures non-binding letters of intent from at least one heat customer per node; by Month 9 (2027-07-17), targets a binding offtake agreement (minimum 15–30 MW, 10-year term) or confirms zero heat-reuse revenue. Primary audience: thermal engineer, commercial development lead, and investment committee (heat-reuse gate).

**Responsible Role Type:** Thermal, Cooling and Hydrology Engineer

**Primary Template:** District-Heating or Industrial Heat-Supply Feasibility Study Template (International Energy Agency / IEA guidelines)

**Secondary Template:** Heat-Offtake Agreement Template (European Heat Pump Association or equivalent precedent)

**Steps:**

- Commission heat-demand study by Month 1 (2026-11-17) targeting delivery by Month 4 (2027-02-17).
- Map district-heating networks, industrial parks, and known heat-intensive users (breweries, paper mills, greenhouses) within 5 km radius of each candidate node.
- For each prospect, develop heat-offtake business case: estimated thermal load (MW), temperature range (35–50°C), annual load factor, and heat-delivery cost per MWh.
- Identify 2–3 most-credible prospects per node and conduct preliminary engagement (Month 4–5 = 2027-02-17 to 2027-03-17) to gather non-binding expressions of interest.
- By Month 7 (2027-05-17), present findings to investment committee and recommend which nodes have viable heat-offtake.
- For viable nodes, draft standardized heat-offtake agreement (15–30 MW minimum, EUR 30–60/MWh price or indexed to natural gas, infrastructure cost-sharing) and target binding signatures by Month 9 (2027-07-17).
- If no binding offtake is signed by Month 9 (2027-07-17), confirm heat-reuse revenue = EUR 0 and remove heat infrastructure from Phase 1 capex.

**Approval Authorities:** Heat-offtake Customer or Public Utility, Investment Committee (gate approval on heat viability)

### 19. Topology Decision and Scenario Financial Model (Single-Square vs. Split-Campus Detailed Comparison)

**ID:** fc41fbf4-c35a-4ded-b709-12a2d6589489

**Description:** Comprehensive financial and scheduling comparison (due Month 4 = 2027-02-17) of single-square (Cambrai/E-Valley 161 km² envelope, 500 MW–1 GW) vs. split-campus (2–3 nodes, 250 MW each) topologies. For each scenario, models: capex per node (grid, land, permits, cooling, fiber), schedule and timeline to first energization per node, per-MW capex, operational complexity (staffing, security, inter-node fiber latency), financing structure (debt per node, shared vs. independent lenders). Quantifies topology-pivot costs if the decision changes mid-Phase-0 (abandoned surveys, redesign spend, schedule slip). Primary audience: investment committee (topology gate), Phase 1 design team, lenders.

**Responsible Role Type:** Phase 0 Program Manager and Red Team Lead

**Primary Template:** Multi-Scenario Infrastructure Design Comparison (World Bank PAD precedent)

**Secondary Template:** Net-Present-Value (NPV) Sensitivity Analysis by Topology (project-finance standard model)

**Steps:**

- Develop bottom-up capex estimates for single-square and 2–3 split-campus node scenarios (Month 1–2 = 2026-11-17 to 2026-12-17).
- For each scenario, build detailed timeline: Phase 0 gate (Month 12 = 2027-10-17), Phase 1 design and procurement (Months 12–24 = 2027-10-17 to 2028-10-17), Phase 1 build (Months 24–36 = 2028-10-17 to 2029-10-17), energization (Months 36–48 = 2029-10-17 to 2030-10-17 for single square; Months 36–54 = 2029-10-17 to 2031-04-17 for split with staggered node energization).
- Model NPV and IRR for each scenario under base and stress cases (demand uncertainty, cost escalation, timeline slip).
- Quantify topology-pivot costs: if single-square fails at Month 4 (2027-02-17) gate and split-campus becomes default, calculate stranded Phase 0 work, redesign spend, and schedule impact.
- Document key sensitivities: grid capacity per node (affects MW per Phase 1 tranche), land assemblability (affects topology choice), and inter-node fiber latency (affects training-vs-inference workload mix).
- Present to investment committee by Month 3 (2027-01-17) to frame the Month 4 (2027-02-17) topology decision; publish final recommendation at Month 4 (2027-02-17).

**Approval Authorities:** Investment Committee, Finance Lead, Grid Connection Lead, Land Assembly Lead

### 20. Community-Benefit Agreement Implementation Plan and Monitoring Framework

**ID:** 05b13425-7857-4623-a310-77f16bdcb7b6

**Description:** Detailed operational plan (due Month 9 = 2027-07-17) specifying: governance structure for benefit-agreement administration (community-benefit officer, local steering committee, quarterly reporting), funding escrow and release mechanisms (tied to Phase 1 milestones), performance metrics for each commitment (farm relocations processed per quarter, training-academy graduate outcomes, ecological restoration hectares per year), dispute-resolution process, and annual third-party audit. Primary audience: municipalities, farm unions, community-engagement manager, lenders (social-license oversight).

**Responsible Role Type:** Community Engagement and Social License Manager

**Primary Template:** Community-Benefit Agreement Implementation and Monitoring Framework (Harvard Kennedy School Center for Public Leadership precedent)

**Secondary Template:** Escrow Agreement and Milestone-Release Schedule (project-finance standard form)

**Steps:**

- Draft governance structure specifying: community-benefit officer (dedicated staff, funded by campus), local steering committee (mayors, farm representatives, NGOs, independent chair), quarterly progress reporting, and published annual audit.
- Design escrow funding: EUR 50M–150M total over Phases 1–2, released in tranches tied to Phase 1 milestones (permits granted, first hall energized, operations year 1).
- Define performance metrics: farm relocations (# farms, average compensation paid, hectares transitioned), training academy (# graduates per year, job-placement rate, wage tracking), ecological restoration (hectares restored, species outcomes, monitoring reports).
- Establish dispute-resolution process: local steering committee mediation, independent arbitrator escalation, annual audit firm review.
- Publish framework to municipalities and lenders for approval before agreements are finalized (Month 6 = 2027-04-17).

**Approval Authorities:** Municipalities, Farm Union Leaders, Environmental NGOs, Investment Committee, Community-Benefit Officer

### 21. Security-Design Baseline and Hardening Roadmap (Campus-Wide Perimeter, OT Separation, Personnel Vetting)

**ID:** cc0eb45f-4088-4d2f-ac8e-598d939e1bf2

**Description:** Technical specification (EUR 500K–1.5M consulting, due Month 2 = 2026-12-17) documenting baseline security architecture for Phase 1: perimeter fencing (height, material, intrusion detection), anti-drone systems (radar, electronic countermeasures), cyber-OT separation (air-gap or two-factor-authentication design), supply-chain vetting (vendor security assessment), and personnel-clearance requirements (background checks, SB-Défense security clearance if applicable). Cost estimate EUR 50M–200M for Phase 1 implementation (estimate). Also specifies optional hardened enclaves (segregated halls) for sovereign or defense-adjacent tenants, with incremental cost (EUR 20M–50M per 10 MW, estimate). Shared with ANSSI/DGSI (Month 2–3 = 2026-12-17 to 2027-01-17) for informal feedback and integrated into Phase 1 design. Primary audience: ANSSI/DGSI (national-security review input), Phase 1 security design team, lenders.

**Responsible Role Type:** National Security and Regulatory Affairs Lead

**Primary Template:** Data Center Security Design Specification (US Department of Energy / DOE or European data-center precedent)

**Secondary Template:** ANSSI/DGSI High-Assurance Security Baseline (Critère de Sécurité Informatique Template, if available)

**Steps:**

- Engage French security consultant with ANSSI experience (EUR 500K–1.5M budget) by Month 0 (2026-10-17).
- Develop baseline specification: perimeter (fencing height, setbacks, lighting, CCTV), anti-drone (radar type, coverage area, electronic countermeasures), OT network separation (air-gap or MFA design), supply-chain vetting (vendor assessment questionnaire), and personnel vetting (background check scope, security-clearance integration).
- Cost and schedule baseline architecture across all buildings; identify optional enclaves for sovereign or defense tenants.
- Share roadmap informally with ANSSI (Month 2–3 = 2026-12-17 to 2027-01-17) and incorporate feedback.
- Publish final baseline (Month 2 = 2026-12-17) to investment committee and Phase 1 design team.
- Integrate into Phase 1 FID cost model and permitting package.

**Approval Authorities:** ANSSI/DGSI (informal feedback), French Security Consultant, Investment Committee, Phase 1 Security Team

### 22. Regional Training Academy Charter and Workforce Development Program (Phase 0–Phase 1 Transition)

**ID:** 76e32932-ea24-4461-a0b5-2fdcbb772ca3

**Description:** Detailed program design (EUR 500K–1M consulting, due Month 3 = 2027-01-17) for a regional data-center trades training academy: partnership agreements with technical colleges and unions (CFDT electrical workers, plumbers), curriculum design (liquid-cooling systems, electrical distribution, security systems), enrollment targets (50–100 graduates per year for 5 years = 250–500 total), funding mechanism (EUR 10M–30M over Phases 1–2), and Phase 1 hiring commitments (at least 200 academy graduates in Phase 1 operations and maintenance). Includes labor-market survey of trade availability, current wage rates, and inflation projections. Primary audience: community-engagement manager, Phase 1 HR lead, regional education authorities, lenders (job-creation validation).

**Responsible Role Type:** Regional Labor, Contractor and Supplier Ecosystem Strategist

**Primary Template:** Workforce Development and Community Training Program Charter (US Department of Labor or equivalent precedent)

**Secondary Template:** Technical Skills Curriculum Development Template (ASHRAE or equivalent)

**Steps:**

- Survey regional technical colleges and trade unions to identify partners and curriculum gaps (Month 1–2 = 2026-11-17 to 2026-12-17).
- Draft curriculum for data-center cooling, electrical, and security trades; negotiate delivery with partners by Month 2 (2026-12-17).
- Define enrollment targets: 50–100 per year, minimum 3-year commitment (Phase 0 start = Month 2 = 2026-12-17, Phase 1 ramp = Month 12 = 2027-10-17 onward).
- Secure funding commitments from EU or French employment programs (EUR 5M–10M estimated public funding), campus company to fund balance (EUR 5M–20M).
- Publish charter and hiring commitments by Month 3 (2027-01-17); lock partnerships by Month 6 (2027-04-17).
- Track outcomes quarterly: graduate numbers, job placements, wage tracking (to validate social-benefit narrative).

**Approval Authorities:** Regional Education Authorities, Trade Unions, Technical Colleges, Investment Committee (job-creation validation)

## Documents to Find

### 1. RTE Grid Connection Queue and Hosting-Capacity Data (Hauts-de-France 400 kV Substations)

**ID:** 320bfa48-cbfd-409a-8177-b8aa7e1c02af

**Description:** Published RTE grid-connection queue positions and available hosting capacity at candidate Hauts-de-France substations (Cambrai/E-Valley, Dunkirk, Valenciennes, Saint-Omer zones). Includes existing and committed loads, queue-position timeline, and RTE's published grid-development roadmap (S3REnR: Schéma Régional de Raccordement au Réseau des Énergies Renouvelables). Critical for validating the primary kill test (grid hosting >~1 GW) and informing topology and grid-reinforcement cost assumptions. Intended audience for analysis: grid-connection lead and investment committee.

**Recency Requirement:** Current (updated quarterly by RTE); historical queue positions from 2024–2026 helpful to show trend.

**Responsible Role Type:** Grid Connection and Power Infrastructure Strategist

**Access Difficulty:** Medium. RTE maintains a public connection-request portal, but detailed hosting-capacity data for specific substations requires direct dialogue with RTE's regional office or a request under French freedom-of-information rules (CADA: Commission d'Accès aux Documents Administratifs). Response timeline typically 4–8 weeks. A formal pre-engineering request from the sponsor to RTE (filed in Month 0 = 2026-10-17) is the standard path.

**Steps:**

- Access RTE's GARE (Guichet d'Accès au Réseau pour les EnR) online portal or contact RTE's Nord regional customer-connection office directly (Rue du Faubourg de Roubaix, Lille) for current queue data and connection-request status.
- Request RTE's published S3REnR roadmap for Hauts-de-France (covers renewable-energy integration and industrial transmission reinforcement plans through 2030).
- Consult DREAL's environmental or grid-infrastructure databases for regional industrial load-growth projections (steel, hydrogen, refinery decarbonization projects competing for capacity).

### 2. Hauts-de-France Regional Land Ownership and Agricultural Land-Value Benchmark Data

**ID:** c753ec15-8b01-435b-a4d1-702eb2d2bfeb

**Description:** Cadastre (official land registry) maps and land-value statistics for candidate zones (Cambrai/E-Valley, Dunkirk industrial area, Valenciennes/Denain/Escaudain, Saint-Omer). Includes parcel-level ownership (public/private/agricultural), recent sales-price comps (EUR/ha), and municipal zoning (industrial, agricultural, protected). Benchmark land value needed to evaluate the 70% optionability test (non-coercive options at ≤15% above benchmark). Intended audience for analysis: land-assembly lead and investment committee.

**Recency Requirement:** Most recent available (2024–2025 land-value benchmarks from SAFER France or DDT/DDTM local registries); historical 3–5 year trend helpful.

**Responsible Role Type:** Land Assembly and Real Estate Strategist

**Access Difficulty:** Easy to Medium. Cadastre.gouv.fr is freely accessible online. Municipal zoning maps are public. Agricultural land-value benchmarks require contact with SAFER (typically responsive within 2–4 weeks) and the Chamber of Agriculture.

**Steps:**

- Contact the Chambre d'Agriculture Hauts-de-France (regional agricultural chamber) for land-value benchmarks per zone and known FNSEA member interests.
- Access the French cadastre online (cadastre.gouv.fr) to search parcel ownership by commune and assess fragmentation.
- Request municipal planning documents (Plans d'Urbanisme Local, PULs) from each affected municipality (Cambrai, Dunkirk, Valenciennes, Saint-Omer) showing current zoning and land-use plans.
- Contact the regional SAFER (Société d'Aménagement Foncier et d'Établissement Rural) to understand agricultural-conservation policies and land-transfer procedures for the region.

### 3. French Phase I and Phase II Environmental Site Assessment Standards and Template Guidance

**ID:** b80cda5f-14a9-416c-900f-9b41fec15293

**Description:** Official guidance on Phase I and Phase II intrusive environmental surveys (soil boring, groundwater, asbestos) per French BRGM (Bureau de Recherches Géologiques et Minières) or equivalent standards. Includes soil-contamination thresholds for heavy metals (lead, cadmium, mercury), petroleum hydrocarbons, and hazardous-waste indicators relevant to industrial brownfield sites. Needed to scope Phase II surveys and bound remediation-liability estimates. Intended audience for analysis: environmental counsel and remediation lead.

**Recency Requirement:** Current French environmental standards (AFNOR NF X31-600 or equivalent) and BRGM guidance on soil thresholds (Valeurs de Fond Géochimique and Valeurs de Référence).

**Responsible Role Type:** Brownfield Remediation and Environmental Liability Counsel

**Access Difficulty:** Medium. BRGM publishes standards freely; AFNOR standards may require a subscription. Regional DREAL/DDT guidance is typically provided on request (2–4 week response).

**Steps:**

- Consult BRGM online portal (brgm.fr) for published soil-contamination reference values and methodology for Phase I/II assessments.
- Access AFNOR standards via French environmental or geological societies (Société Géologique de France).
- Contact regional DREAL or DDT offices for local contamination histories and known industrial-legacy sites in candidate zones.

### 4. EDF Nuclear Generation Capacity and Multi-GW Supply Contract Precedents

**ID:** eb720230-98ec-47b6-94b9-7cae50e3dba2

**Description:** Published EDF capacity portfolio, current multi-year supply commitments to large industrial or data-center customers, and available baseload-contract terms (price ranges, tenor, take-or-pay mechanics, indexation clauses). Includes any public announcements on AI-data-center power commitments or exclusivity agreements in France and Europe (e.g., Microsoft, Google, Meta power deals disclosed in earnings or press releases). Needed to validate power-procurement assumptions (EUR 50–75/MWh, 10+ year tenor, nuclear-backed baseload available at multi-GW scale). Intended audience for analysis: power-procurement lead and investment committee.

**Recency Requirement:** Current (2025–2026); EDF historical contract terms from 2020–2025 helpful.

**Responsible Role Type:** Grid Connection and Power Infrastructure Strategist

**Access Difficulty:** Medium. EDF investor relations is responsive (1–2 week typical response); publicly available data is limited on specific contract terms (often confidential), so a direct request to EDF is necessary for binding guidance.

**Steps:**

- Access EDF's published financial reports and investor presentations (edf.fr/investors) for supply-contract disclosures and capacity guidance.
- Review EDF press releases and industry news (Reuters, Bloomberg) on large-customer power agreements.
- Contact EDF's commercial team or business-development office for preliminary supply-contract term-sheet templates and pricing guidance (typically non-binding initial discussions).
- Review energy-market reports from Bloomberg New Energy Finance (BNEF) or Wood Mackenzie on European data-center power costs and EDF's market positioning.

### 5. ANSSI/DGSI National-Security Review Process and Timelines for Foreign Co-Investment in Critical Infrastructure

**ID:** b0118f36-31f7-4cfd-9323-f5a530d8c0ba

**Description:** Published ANSSI and DGSI procedures for national-security assessment of foreign investment in data centers, telecoms, or energy infrastructure. Includes review scope, timeline (typically 6–12 months estimated, not confirmed), and blocking criteria (e.g., restrictions on non-EU or US-origin funding). Needed to validate the ANSSI gate (Month 6 = 2027-04-17 preliminary opinion, Month 12 = 2027-10-17 clearance-pathway confirmation) and to structure foreign-co-investor governance to minimize review friction. Intended audience for analysis: national-security lead and investment committee.

**Recency Requirement:** Current ANSSI/DGSI procedures (2024–2025); note that procedures are being revised under emerging EU critical-infrastructure rules (NIS2), so recent guidance is important.

**Responsible Role Type:** National Security and Regulatory Affairs Lead

**Access Difficulty:** Hard. ANSSI procedures are not fully public; confidential pre-submission meetings are the only reliable way to understand actual review scope and timeline. A request typically requires high-level government or industry sponsorship. Response timeline typically 4–12 weeks for a preliminary meeting.

**Steps:**

- Request ANSSI website (ssi.gouv.fr) for published national-security review procedures (Procédure de Contrôle Étrangère en Matière de Sécurité Informatique et Télécommunications).
- Contact ANSSI's office directly via a formal inquiry (typically requiring a meeting with the sponsor CEO or general counsel) for confidential pre-submission guidance.
- Monitor French government announcements on foreign-investment screening (Ministère de l'Économie, Bercy) for updates to the procedure.
- Consult recent case studies or confidential legal briefings on foreign-investment reviews in data centers or telecoms (not publicly available, may require a law firm with ANSSI experience).

### 6. French ICPE (Installations Classées pour l'Environnement) and Environmental Authorization Permitting Timeline and EIA Scope

**ID:** ab1b6923-81c8-4e90-9ca6-58b33abca732

**Description:** Official DREAL guidance on ICPE classification for data centers (power consumption thresholds triggering 'Autorisation' vs. 'Déclaration' vs. 'Enregistrement'), environmental-authorization scoping (EIA mandatory scope per Article L.122-1 to L.122-3 Code de l'environnement), and published permitting timelines (18–30 months for Authorization route, +24–48 months for appeals). Includes case studies or examples of recent industrial permits (refinery, power plant expansions) to benchmark timeline realism. Needed to validate Phase 0 permitting schedule (file submission Month 8–9 = 2027-06-17 to 2027-07-17, decision Month 26–39 = 2028-12-17 to 2030-01-17 estimated). Intended audience for analysis: environmental-permitting counsel and Phase 0 program manager.

**Recency Requirement:** Current ICPE and EIA rules (updated 2022 under French environmental law reforms); typical permitting timelines from 2023–2025 cases.

**Responsible Role Type:** Environmental and Permitting Counsel

**Access Difficulty:** Medium to Easy. DREAL is responsive to pre-filing inquiries (2–4 week turnaround); published case law and scoping templates are freely available online.

**Steps:**

- Access DREAL Hauts-de-France website (dreal.hauts-de-france.gouv.fr) for published ICPE guidance, EIA scoping templates, and recent permit decisions (anonymized).
- Request a pre-filing scoping meeting with DREAL (standard practice, Month 1–2 = 2026-11-17 to 2026-12-17) to clarify EIA scope and likely permitting timeline.
- Review published French court decisions (Conseil d'État) on environmental permit appeals to understand typical delay patterns and legal-challenge grounds.
- Consult recent environmental-impact assessments for comparable industrial projects in the region (available in DREAL public databases).

### 7. Regional Hydrological Data and Drought-Management Rules (Agence de l'Eau Artois-Picardie)

**ID:** 7ed527c3-1d5d-4d03-be83-716ab22a45f2

**Description:** Water-balance data for Hauts-de-France (surface-water and groundwater availability, summer stress, drought frequency and severity from 2000–2025). Includes French drought-management decree (décrets de crise) triggering industrial water-use curtailment (e.g., 50–75% reduction in dry years) and water-authority pre-agreed protocols for large industrial users. Needed to validate cooling-design assumptions (dry-cooler feasibility at zero evaporative water, PUE impact under 35–40°C ambient) and to set tenant-lease drought-response clauses. Intended audience for analysis: thermal engineer and environmental counsel.

**Recency Requirement:** Current water-balance data (2024–2025 Agence de l'Eau surveys); drought-decree templates from 2022–2024 dry years.

**Responsible Role Type:** Thermal, Cooling and Hydrology Engineer

**Access Difficulty:** Easy to Medium. Agence de l'Eau publishes annual water-balance reports; drought decrees are published by prefectures; pre-agreed protocols may require a direct request (2–4 week response).

**Steps:**

- Contact Agence de l'Eau Artois-Picardie directly (agence-eau-artois-picardie.fr) for published water-availability summaries, drought frequency, and pre-agreed industrial-use protocols.
- Request prefectural water-management documents (DDT/DDTM for Nord and Pas-de-Calais) covering drought-decree procedures and industrial-curtailment triggers.
- Access BRGM hydrogeological databases for groundwater-level trends and aquifer-stress data relevant to candidate sites.

### 8. Dry-Cooler Vendor Performance Data and Thermal-Design Specifications (Thermax, Hydac, Modine, SPX)

**ID:** 4191f7bb-2525-4cbe-9d0d-33e6e569a1ec

**Description:** Published and vendor-provided dry-cooler performance curves (capacity vs. ambient temperature, 15–40°C range), fan power curves, fouling factors, and minimum approach temperature (dT) specifications. Needed to validate Phase 0 thermal modeling and PUE-target feasibility (1.15–1.25 target, 1.35–1.5 hot-weather upside risk). Intended audience for analysis: thermal engineer and investment committee.

**Recency Requirement:** Current (2024–2025 vendor datasheets); historical curves (2020–2023) acceptable for trend analysis.

**Responsible Role Type:** Thermal, Cooling and Hydrology Engineer

**Access Difficulty:** Easy. Manufacturers typically provide datasheets freely to qualified customers; case-study data may require registration or industry-forum access.

**Steps:**

- Request detailed performance datasheets from dry-cooler manufacturers (Thermax, Hydac, Modine, SPX Cooling) via their sales/technical teams; typical response 2–4 weeks.
- Consult ASHRAE (American Society of Heating, Refrigerating and Air-Conditioning Engineers) data or design guides on cooler-performance modeling (available via ASHRAE membership or subscription).
- Review thermal-design case studies from published data-center projects or industry benchmarks (Data Center Journal, Uptime Institute) for PUE vs. cooler-size examples.

### 9. Existing Fiber-Route Maps and Carrier Duct-Diversity Information (TeleGeography, Orange Telecom, Vodafone, BT, KPN, Deutsche Telekom, Telecom Italia)

**ID:** 92b5dbc9-0df0-476a-9b60-07dacaaa77ef

**Description:** Published or carrier-provided fiber-route maps, duct-level diversity documentation, and landing-point information for routes from Hauts-de-France to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille, and subsea. Critical for validating the fiber gate (≥2 separate audited routes per hub, no shared landing >25% of capacity). Intended audience for analysis: fiber-connectivity lead and investment committee.

**Recency Requirement:** Current (2025) carrier-provided route maps and diversity information; published TeleGeography route atlases (updated quarterly).

**Responsible Role Type:** Fiber and Digital Infrastructure Route Strategist

**Access Difficulty:** Medium. Carrier-provided information is typically freely available as non-binding guidance; detailed duct-level maps may require carrier agreement to disclose. TeleGeography is commercial subscription. A formal fiber audit (commissioned to an independent consultant) is the standard Phase 0 approach.

**Steps:**

- Access TeleGeography's fiber-route database (subscription required; typical cost EUR 5K–15K/year) or request a custom report on route diversity.
- Contact major European carriers (Orange Telecom, Vodafone, BT, KPN, Deutsche Telekom, Telecom Italia) directly for non-binding route and capacity information.
- Consult published subsea-cable landing-point maps and consortium details (TeleGeography, SubTel Forum) to identify Calais, Dunkirk and Channel-crossing options.

### 10. NATURA 2000 and Protected-Species Maps (Regional Ecological Designation)

**ID:** 8b5a8e6d-c401-416a-83fc-45cfdbb31eb6

**Description:** Published maps of Natura 2000 sites, protected wetlands (RAMSAR), and listed species occurrences (orchids, amphibians, birds of prey) in candidate zones (Cambrai, Dunkirk, Valenciennes, Saint-Omer). Needed to scope ecological baseline surveys, identify avoidance zones, and estimate biodiversity-compensation cost. Intended audience for analysis: environmental counsel and ecological master-plan team.

**Recency Requirement:** Current (2024–2025 DREAL Natura 2000 inventory); species surveys 2023–2025 if available.

**Responsible Role Type:** Environmental and Permitting Counsel

**Access Difficulty:** Easy. DREAL publishes Natura 2000 maps and species data freely online; museum databases and university research are accessible (2–4 week response for custom inquiries).

**Steps:**

- Access DREAL online Natura 2000 maps and species-inventory database (dreal.hauts-de-france.gouv.fr).
- Consult the French natural-history museum (Muséum National d'Histoire Naturelle) or regional universities for species-distribution data (GBIF France portal).
- Request prefectural ecological surveys or biotic-diversity assessments from DDT/DDTM if recently completed.

### 11. French Municipal Planning and Zoning Maps (Plan d'Urbanisme Local, PUL) for Candidate Zones

**ID:** f405791f-1cb0-47be-b972-220b20f5ac34

**Description:** Current municipal zoning, land-use designations (industrial, agricultural, protected, urban), and any municipal development plans or restrictions that would affect data-center siting (height limits, setback requirements, industrial-use restrictions). Needed for Phase 1 permitting strategy and social-license assessment. Intended audience for analysis: environmental counsel, land-assembly lead, and community-engagement manager.

**Recency Requirement:** Current (2025) PLU or equivalent planning documents; recent municipal approvals (2023–2025) if available.

**Responsible Role Type:** Environmental and Permitting Counsel

**Access Difficulty:** Easy. Municipal planning documents are public and freely available from town halls or municipal websites.

**Steps:**

- Request PLU documents from each affected municipality (Cambrai, Dunkirk, Valenciennes, Saint-Omer) via municipal town halls (mairie) or online municipal websites.
- Consult DREAL for regional planning context and any prefectural directives affecting industrial zoning.

### 12. Industrial Heat-User Directory and District-Heating Network Maps (Cambrai, Dunkirk, Valenciennes)

**ID:** 65e2513f-a349-4795-8e44-be79667323f9

**Description:** Inventory of industrial process-heat users (food processing, brewing, paper, refining, chemicals) and municipal district-heating networks within 5 km of candidate sites. Needed to scope heat-reuse opportunities, estimate pipeline costs, and identify binding heat-offtake prospects. Intended audience for analysis: thermal engineer and commercial development lead.

**Recency Requirement:** Current (2024–2025 industrial directories and district-heating network plans); 3–5 year trend on user expansion helpful.

**Responsible Role Type:** Thermal, Cooling and Hydrology Engineer

**Access Difficulty:** Medium. Chamber of commerce typically provides free directories; district-heating operator information may require direct contact (2–4 week response).

**Steps:**

- Contact regional chambers of commerce (Chambres de Commerce et d'Industrie Hauts-de-France) for industrial-user directories.
- Request district-heating network maps and operator contact information from municipal utilities (Gaz de France / GRDF, local district-heating operators).
- Consult industrial-park or business-zone development agencies (e.g., Dunkerque Port, Cambrai Industrial Zone) for tenant lists and heat-demand information.

### 13. SAFER (Société d'Aménagement Foncier et d'Établissement Rural) Agricultural-Land Policy and Transfer Procedures

**ID:** 78808621-7b9c-4bb9-8b5d-4b60250bc4d4

**Description:** SAFER documentation on agricultural-land conservation, pre-emptive-purchase rights for farms, and land-transfer procedures for non-agricultural use (data centers, industrial parks). Needed to scope farmland-displacement strategy, compensation mechanisms (lease-and-continue farming, revenue-sharing), and potential SAFER pre-emption risk if large contiguous parcels are being assembled. Intended audience for analysis: land-assembly lead and community-engagement manager.

**Recency Requirement:** Current SAFER regional policies (2024–2025).

**Responsible Role Type:** Land Assembly and Real Estate Strategist

**Access Difficulty:** Medium. SAFER is responsive to official inquiries (2–4 week response); regional guidance is not always published online.

**Steps:**

- Contact the regional SAFER office (Hauts-de-France SAFER, typically within the Chamber of Agriculture) for guidance on agricultural-land transfer and FNSEA engagement.
- Consult published SAFER precedents or case studies on industrial-zone development on farmland (typically available from SAFER offices or municipal planning archives).

### 14. Global Hyperscaler (Microsoft, Google, Meta) and Sovereign-AI Consortium Data-Center Announcements and Capacity Plans (2024–2025)

**ID:** 38ebdf54-9a0e-4019-809a-5fe3af8a12e9

**Description:** Published announcements, earnings disclosures, and press releases from global hyperscalers and European sovereign-AI initiatives on data-center capacity expansions, location preferences, and power requirements in France and Europe. Needed to validate anchor-tenant market demand and competitive positioning (Ireland, Netherlands, Germany alternatives). Intended audience for analysis: commercial development lead and investment committee.

**Recency Requirement:** Current (2025); news and announcements from 2024–2025.

**Responsible Role Type:** Anchor-Tenant and Market Development Lead

**Access Difficulty:** Easy. SEC filings are freely available online; industry news is accessible via subscription or free publication archives; analyst reports may require registration.

**Steps:**

- Monitor SEC filings (Microsoft, Google/Alphabet, Meta earnings releases and 10-Q forms) for data-center capex guidance and location disclosures.
- Track industry news (Reuters, Bloomberg, Data Center Journal, Uptime Institute publications) for announcements of new data-center projects and tenant commitments.
- Research French government announcements on Campus IA (national AI campus program) and EU-sovereign data-center initiatives.
- Contact industry analysts (Gartner, IDC, TeleGeography) for market-size and competitive-positioning reports on European data centers.

### 15. French Regional and Municipal Population and Labor Statistics (INSEE, French Statistical Office)

**ID:** f40e677e-97bd-4d5b-8c55-ba996210ee35

**Description:** Current employment, trade/skill levels, wage rates (electricians, mechanical engineers, cooling technicians), and housing availability in Hauts-de-France. Needed to scope Phase 0 and Phase 1 labor-strategy assessment, training-academy feasibility, and realistic wage-inflation projections. Intended audience for analysis: regional-labor lead and community-engagement manager.

**Recency Requirement:** Current (2024–2025 INSEE census and labor-force survey data); 5-year trend (2020–2025) helpful for wage inflation.

**Responsible Role Type:** Regional Labor, Contractor and Supplier Ecosystem Strategist

**Access Difficulty:** Easy. INSEE data is freely accessible online; Pôle Emploi data may require a formal request (1–2 week response).

**Steps:**

- Access INSEE online (insee.fr) for published regional employment, wages, and labor-force statistics by occupation and region.
- Contact regional labor boards (Directions de l'Emploi, Pôle Emploi) for real-time job-vacancy and wage data.

### 16. Dunkirk Port (Grand Port Maritime de Dunkerque) Industrial-Decarbonization and Grid-Connection Programme Data

**ID:** 86af4a63-1cdd-4be5-a070-15684918392a

**Description:** Published information on Dunkirk port's industrial-decarbonization roadmap, grid-connection planning, and any competing data-center or industrial-load requests (steel, hydrogen, refinery electrification). Critical for assessing RTE grid-capacity competition and Dunkirk node feasibility. Intended audience for analysis: grid-connection lead and investment committee.

**Recency Requirement:** Current (2024–2025 Dunkirk port strategy and RTE coordination plans).

**Responsible Role Type:** Grid Connection and Power Infrastructure Strategist

**Access Difficulty:** Easy to Medium. Port authority is responsive to business inquiries (1–2 week response); RTE regional plans may require a formal request (2–4 weeks).

**Steps:**

- Access Grand Port Maritime de Dunkerque website (dunkerque-port.fr) for industrial and infrastructure development plans.
- Contact Dunkirk port business development or land allocation for information on data-center site availability and grid infrastructure.
- Consult RTE's regional development plans (Nord departmental RTE office) for published Dunkirk substation reinforcement roadmap.

### 17. EIB (European Investment Bank) and KfW (German Development Bank) Data-Center Financing Precedents and Lending Criteria (2023–2025)

**ID:** a8c39014-d123-45e6-be74-fdd70805a8f6

**Description:** Published EIB and KfW project appraisals, project summaries, or financing frameworks for large data-center or infrastructure projects in Europe. Needed to validate debt-financing assumptions (EUR 3B senior debt, 60% leverage, 5.5% all-in cost, 15-year tenor) and to understand lender expectations for gate discipline and DSCR covenants. Intended audience for analysis: finance lead and investment committee.

**Recency Requirement:** Current (2024–2025 EIB and KfW project summaries and financing criteria); historical 2020–2024 precedents.

**Responsible Role Type:** Infrastructure Finance and Capital Structure Lead

**Access Difficulty:** Easy. EIB and KfW publish summaries of many projects; detailed financing terms may be confidential, but comparable precedent case studies are often available in trade publications.

**Steps:**

- Access EIB project-appraisal documents and financing frameworks online (eib.org), which are often published in summary form.
- Review KfW annual reports and project examples (kfw.de) for data-center or large-infrastructure financing cases.
- Consult project-finance case studies from major deal databases (LPC, Refinitiv, Bloomberg) on comparable data-center or industrial financings.

### 18. French Export-Control Rules and CFIUS (Committee on Foreign Investment in the US) Screening Precedents for Data Centers

**ID:** 43ca44d8-093d-4a43-951c-b93fe9e58f3c

**Description:** French and EU export-control regulations affecting GPU/TPU and high-performance computing hardware (if US origin), and US CFIUS screening thresholds for foreign investment in data centers with potential national-security implications. Needed to validate USD-hardware-financing strategy and to inform foreign-co-investor governance structure. Intended audience for analysis: national-security lead and finance lead.

**Recency Requirement:** Current (2025 export-control and CFIUS rules); updates from 2024–2025 reflecting EU and US policy changes.

**Responsible Role Type:** National Security and Regulatory Affairs Lead

**Access Difficulty:** Medium. Export-control classifications are public; CFIUS thresholds are published but case-specific guidance requires expert counsel (2–4 week response).

**Steps:**

- Consult French government or EU trade/export-control websites (Direction Générale des Douanes, European Commission trade directorate) for current GPU/TPU export classifications.
- Review CFIUS guidance (US Treasury Department website) on foreign investment in data centers and critical infrastructure.
- Engage specialized trade counsel with expertise in US and EU export controls for detailed risk assessment.

### 19. FNSEA (Fédération Nationale des Syndicats d'Exploitants Agricoles) and Confédération Paysanne Regional Agricultural Interests and Land-Assembly Precedents

**ID:** 805d3c03-ba4e-4f2c-afeb-3704332f3cc2

**Description:** Documentation of farm-sector union positions on industrial land-use conversion in Hauts-de-France, any precedent industrial-development projects (airports, motorways, power plants) in the region, and the farm unions' typical negotiation stance on compensation, relocation, and lease-and-continue arrangements. Needed to scope farm-union engagement strategy and estimate likelihood of organized opposition to a 161 km² or split-node land assembly. Intended audience for analysis: land-assembly lead and community-engagement manager.

**Recency Requirement:** Current (2024–2025 FNSEA and Confédération Paysanne regional positions); historical 3–5 year precedent on major industrial projects in the region.

**Responsible Role Type:** Land Assembly and Real Estate Strategist

**Access Difficulty:** Medium. Farm unions are responsive to direct contact (1–2 week response); published positions may be limited. Engagement through local agricultural counsel is often more effective than direct outreach.

**Steps:**

- Contact FNSEA regional office (Fédération Nationale des Syndicats d'Exploitants Agricoles, Hauts-de-France chapter) for their position on industrial land conversion and typical compensation expectations.
- Consult Confédération Paysanne (alternative farm union) regional chapter for their perspective.
- Review published agricultural-sector position papers or press releases on recent major industrial projects in the region (2020–2025).
- Engage local agricultural lawyers familiar with farm-sector negotiations to provide insights on resistance patterns and deal structures.

### 20. European Environmental NGO Positions on Data Centers and Critical Infrastructure (EENGO Database, Greenpeace, WWF France, FNE Hauts-de-France)

**ID:** 2bb8c92f-2d20-4b2b-8de7-b049f1601ccd

**Description:** Published positions and precedent campaigns from environmental NGOs on data-center siting, energy efficiency, water use, and ecological impact. Helps scope environmental-opposition risk and identify NGO constituencies likely to engage or oppose. Intended audience for analysis: community-engagement manager and environmental counsel.

**Recency Requirement:** Current (2024–2025 NGO announcements and campaign positions); historical 2020–2025 precedent on data-center projects.

**Responsible Role Type:** Community Engagement and Social License Manager

**Access Difficulty:** Easy. NGO positions are typically published online; direct engagement with local chapters usually achieves response within 2–4 weeks.

**Steps:**

- Access Greenpeace, WWF France, and FNE Hauts-de-France websites and published position papers on data centers.
- Monitor EENGO (European Environmental Network Group) database for precedent positions on industrial siting and ecological compensation.
- Engage local NGO representatives directly to understand their specific concerns and engagement willingness.

### 21. Comparable Data-Center Project Financing Case Studies (2020–2025) in Europe (Ireland, Netherlands, Germany, Nordic Region)

**ID:** 75235854-6bf7-4f6c-816e-b404d01f320f

**Description:** Published or anonymized case studies of recent multi-gigawatt data-center or industrial-park financing in Europe: deal size, debt/equity mix, lender terms (tenor, DSCR floors, leverage ceilings), pricing (cost of capital), and gate-closure outcomes. Needed to validate financing assumptions and benchmark lender expectations for DSCR covenants and equity returns. Intended audience for analysis: finance lead and investment committee.

**Recency Requirement:** Current (2023–2025 recent data-center or industrial-infrastructure deals); 2020–2022 precedent for trend analysis.

**Responsible Role Type:** Infrastructure Finance and Capital Structure Lead

**Access Difficulty:** Medium. Published case studies are limited (many deals are confidential); databases require subscription (typical cost EUR 5K–20K/year). Law firms and advisers with recent deal experience are the best source (2–4 week response for briefings).

**Steps:**

- Consult project-finance databases (LPC, Refinitiv, Bloomberg, Mergermarket) for comparable data-center or large industrial financings.
- Review published investment-committee or board reports from recent European infrastructure funds (EIB, KfW, major pension funds) for case studies or deal examples.
- Engage infrastructure-finance advisers with recent deal experience for confidential briefings on market terms.