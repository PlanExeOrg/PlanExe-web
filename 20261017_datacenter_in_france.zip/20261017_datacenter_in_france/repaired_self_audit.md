Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 10 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 9 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a staged infrastructure feasibility and development plan for a hyperscale data center campus using closed-loop liquid cooling, grid-connected power, and conventional permitting. All stated mechanisms—liquid cooling, PUE targets of 1.15–1.25, immersion cooling pilots, heat recovery, and grid hosting—are within established physics (thermodynamics, materials science, power systems). The plan's dependencies (tenant demand, RTE grid offers, permitting, financing, community support) are empirical and institutional, not claimed to be produced by non-physical causation; they are treated as uncontrolled milestones with explicit kill criteria and skeptical gates rather than assumed outcomes.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms. Project governance should focus on empirical validation of grid capacity, financing credibility, tenant anchoring, and permitting realism per the stated gates.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan hinges on a novel system combination (multi-phase, 9 GW campus, grid-hosted, financed by mixed equity/debt with staged capital gates, sovereign-aligned tenants, permitting-dependent land assembly) without independent evidence at comparable scale. No single-site 9 GW campus exists globally; the grid, land, power, tenant and permitting dependencies are all uncontrolled until RTE signs, DREAL permits, ANSSI clears and tenants commit. However, the core components (liquid cooling, grid hosting, power procurement, permitting, financing) individually have precedent in lower-scale projects or comparable sectors. The plan explicitly treats this as a staged feasibility test with kill criteria (grid ≥~1 GW, land ≥70%, anchors ≥30%, ANSSI clearance). Phase 0 gates and contingency downsizing (250 MW, split campus) demonstrate skepticism. Medium (not High) because failure modes do not claim physics impossibility; they are institutional and empirical gates that can be validated within the Phase 0 budget and schedule via RTE letter, land surveys, tenant term sheets, and lender commitment—no prototype or pilot is required for system validation to occur, only evidence collection."

**Mitigation**: Project Sponsor and Investment Committee: By Month 12 (2027-10-17), execute parallel validation tracks (grid/power, land/environment, anchor-tenant demand, legal/compliance) with one authoritative source per track confirming empirical or engineering validity (RTE letter, Phase II surveys and land option, binding term sheets with cash in escrow, written municipal support and lender debt commitment). Lock two global NO-GO gates in writing at Month 2 (2026-12-17): (1) empirical/engineering validity (grid, land, PUE, water, anchors) and (2) legal/compliance clearance (ANSSI, permits, municipalities, debt). If either gate fails by Month 12 (2027-10-17), execute pre-agreed contingency (downsize to 250 MW, split campus, or defer FID 6-12 months) rather than override thresholds.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because core strategic decisions (grid, capital, anchors, permitting, governance) are named and linked to Phase 1 viability, yet decision ownership is distributed across multiple roles without a consolidated registry, the causal link between decision failure and Phase 1 consequences is implicit rather than explicit, social-license thresholds are partly qualitative, and no unified strategic thesis knits the 15 decisions into a coherent hypothesis. The plan lacks one-pagers for Decisions 1–5 that explicitly state inputs→process→customer-value flows and measurable outcomes with decision-maker accountability.

**Mitigation**: Strategic-Clarity Lead: Produce a Decision Charter (Month 1–2 = 2026-11-17 to 2026-12-17) and one-pagers for Decisions 1–5 (grid, capital, anchors, permitting, governance) with explicit inputs, process, customer-value, success metrics, failure thresholds, Phase 1 impact, and owner accountability. Assign owners to secondary decisions; publish updates to investment committee monthly.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies 23 cascading second-order hazards (permit delay → RTE queue erosion → DSCR breach; energy shock → anchor-tenant collapse → FID fail; sunk-cost → threshold override → cost overrun). However, three gaps: (1) gate enforcement relies on committee independence, not contractual debt tranches; (2) dual/triple cascades during Phase 1 build (Months 18–30 = 2028-04-17 to 2029-04-17) not stress-tested; (3) reputational cascade impact on tenant recruitment is qualitative, not quantified or gated.

**Mitigation**: Finance and Governance Lead: Embed gate authority in a tri-party binding agreement (sponsor, lenders, co-investors) by Month 1 (2026-11-17) that ties Phase 1 debt tranches to committee sign-off, publishes monthly dissent to lenders, and pre-defines dual-/triple-event Phase 1 stress scenarios (permit delay + energy shock + 10% cost overrun) with a shared DSCR covenant floor (1.30x proposed lender minimum; base 1.34x) and automatic refinance triggers. Deliver Phase 1 stress covenant summary by Month 12 (2027-10-17).


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Phase 0 topology decision (Month 4 = 2027-02-17) precedes the RTE written preliminary feasibility letter (Month 6 = 2027-04-17) by two months, forcing a split-campus default by calendar before evidence arrives. Additionally, standard permitting (18–30 months from filing, plus 24–48 months for appeals) will delay Phase 1 energization beyond the base-case Months 42–48 (2030-04-17 to 2030-10-17) if challenges emerge; fast-track status is not confirmed (not verified). The plan lacks a critical-path diagram with dated predecessors and no-go slip thresholds. Long-lead items (transformers, coolers, BESS, subsea cable) are not locked to delivery dates in Phase 0. Permit check at Month 18 (2028-04-17) is too late to prevent Phase 1 design commitments.

**Mitigation**: Project Controls Lead: By Month 1 (2026-11-17), build a detailed critical-path network with dated predecessors (RTE preliminary Month 3 = 2027-01-17, water opinion Month 6 = 2027-04-17, ANSSI pathway Month 6 = 2027-04-17, permit submission Month 8–9 = 2027-06-17 to 2027-07-17, Phase 1 FID Month 12 = 2027-10-17). Lock permit-critical thresholds and no-go slip dates per the regulatory roadmap. Establish vendor commitment gates (cooler/BESS/cable selection by Month 6 = 2027-04-17). Publish monthly schedule variance and critical-path burn-down to lenders and the investment committee.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Phase 0 funding is sponsor equity committed in principle (EUR 750M capped tranches) with no signed master drawdown agreement or lender co-commitment; Phase 1 financing is indicative only (non-binding lender indications expected Month 6 = 2027-04-17, firm commitment only if Phase 0 gates pass at Month 12 = 2027-10-17). Financing gates and covenants are stated in the plan but not embedded in debt documents or equity agreements. Stacked contingent add-ons total EUR 1.55B–4.2B against EUR 5.0B base, leaving only EUR 0.8B–3.45B headroom to EUR 10B ceiling; cost allocation is undefined.

**Mitigation**: Finance and Governance Lead: By Month 2 (2026-12-17), execute a tri-party binding agreement (sponsor, lead lenders, co-investor consortium) vesting Phase 0 tranche releases to investment-committee gate sign-off and locking Phase 1 financing conditions (≥EUR 3B debt term sheet, equity commitments, covenant floor DSCR ≥1.30x, no-go acceleration if gates fail). By Month 9 (2027-07-17), publish unified Phase 1 cost-stack reconciliation assigning funding sources and contingencies; by Month 12 (2027-10-17), confirm debt and equity commitments in writing or trigger Phase 1 downsize.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states Phase 1 capex of EUR 5B–10B without a detailed line-item breakdown, vendor quotes, or scale-normalized benchmarks (EUR/m² or EUR/MW) to substantiate the figures. Stacked contingent add-ons (grid co-funding EUR 500M–1.5B, split-campus premium EUR 250M–500M, remediation EUR 100M–300M, ecology EUR 200M–300M, fiber EUR 100M–300M) total EUR 1.55B–4.2B, leaving free headroom to the EUR 10B ceiling of only EUR 0.8B–3.45B. The plan does not specify which add-ons are funded from the EUR 5B base, which sit outside, or what triggers cost cuts if the unified stack exceeds EUR 10B. No comparable data-center projects at 500 MW or 1 GW scale are cited to validate per-MW or per-m² cost assumptions.

**Mitigation**: Finance Lead: Deliver a detailed Phase 1 capex model by Month 6 (2027-04-17) with ≥3 vendor quotes or benchmarks per major line item (halls, coolers, transformers, security, fiber, BESS), normalized cost per m² and per MW against global and Western European data-center comparables at 100 MW, 500 MW and 1 GW scales. Publish cost-reconciliation statement assigning funding sources and contingencies; obtain lender and investment-committee written approval.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single-point estimates without ranges, confidence intervals, or explicit alternative scenarios. Revenue stabilized 500 MW is stated as EUR 550M annually (lease) + EUR 223M (energy) = EUR 773M, with no low/base/high case. Phase 1 capex is EUR 5.0B–10B (a range, but not conditioned on explicit scenario assumptions). DSCR is 1.34x at stabilized baseload without stress-case sensitivities documented until the risk register. Energy cost is assumed EUR 60/MWh (range 50–70, not verified) without modeled impact on affordability or lease renegotiation if it reaches EUR 100/MWh. Energization window is Months 42–48 (2030-04-17 to 2030-10-17) base case, Months 48–60 (2030-10-17 to 2031-10-17) downside, but no probability weighting or go/no-go contingency for Months 60+. Phase 0 is EUR 250M–750M (a wide range, no decision rule for when the cap is triggered). The plan lacks a unified base/mid/high case showing how grid, tenant, power, permitting and capital variables interact.

**Mitigation**: Finance and Planning Lead: By Month 9 (2027-07-17), deliver three scenarios (low/base/high) for Phase 1 stabilized state (Months 54–60 = 2031-04-17 to 2031-10-17), each with stated assumptions on RTE curtailment (10%/15%/20%), energy cost (EUR 50/70/100 per MWh), tenant credit (BBB+ / BB+ / BB−), power reliability (99.5% / 99.0% / 97.5%), and schedule slip (0 / 6 / 12 months). Calculate NOI, DSCR and equity IRR per scenario. Gate Phase 1 FID on commitment to deliver quarterly actual-vs.-forecast variance (±10% on revenue, opex, cost of capital) and a reforecast trigger if variance exceeds ±15%.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies 9 build-critical components (grid hosting, land assembly, anchor-tenant demand, power procurement, cooling/PUE, water authority clearance, ANSSI security clearance, permitting/DREAL opinion, and financing commitment) yet lacks formal engineering artifacts for most. Grid hosting capacity is uncontrolled until RTE signs (Month 6 = 2027-04-17), with no pre-engineering specs or interface contract. Land assembly has no parcel-level engineering or surveying plan before topology locks (Month 4 = 2027-02-17). Cooling targets PUE 1.15–1.25 but thermal modeling is not due until Month 5 (2027-03-17), after topology commits. Power procurement assumes EUR 50–70/MWh but no binding supply contract or interface specification exists. Fiber diversity is audited but not contracted. Permitting file is to be submitted Month 8–9 (2027-06-17 to 2027-07-17) but preliminary DREAL opinion is not until Month 9 (2027-07-17). No integration plan ties these components to a unified Phase 1 design or a single FID checklist. Acceptance tests (DSCR thresholds, PUE floor, connection offer, permit decision, security clearance) are stated in the risk register but not formalized as engineering gates with measurable pass/fail criteria or sign-off authority.

**Mitigation**: Engineering Leadership (Grid, Land, Power, Cooling, Security, Permitting): By Month 3 (2027-01-17), produce a unified Phase 1 Technical Specification Document covering grid interface (RTE connection terms, substation SLD, curtailment protocol), land/topology (parcel map, layout, remediation scope), thermal design (cooler specs, PUE test plan, 35°C validation), power (EDF contract template, energy SLA), fiber (route map, diversity audit), security (enclave specifications), and permitting (ICPE file content plan). Define acceptance tests per component: RTE letter, DREAL opinion, thermal validation report, water authority letter, fiber diversity audit, security roadmap sign-off. Assign owner and sign-off authority per component. Reconvene at Month 9 (2027-07-17) to confirm all component specs are complete and non-conflicting before Phase 1 FID (Month 12 = 2027-10-17).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes nine critical claims (RTE grid offer, EDF power contract, 150 MW signed anchors, ANSSI clearance, municipal support, water opinion, EUR 3B debt, fiber diversity, Phase II remediation) that lack verifiable artifacts today. Each is marked "uncontrolled" or "not verified." All are gates: absence of any one triggers Phase 1 downsize/cancel. No external-stakeholder binding commitment mechanism exists to guarantee evidence delivery on schedule (Month 6, 9, 12 = 2027-04-17, 2027-07-17, 2027-10-17).

**Mitigation**: Investment Committee Chair and Program Manager: Establish signed "Evidence Commitment" protocols with RTE, EDF, ANSSI, DREAL, lenders, municipalities confirming artifact delivery by gate date, or state inability. Publish Monthly Evidence Dashboard (Months 1–12 = 2026-11-17 to 2027-10-17) tracking status. Escalate missing artifacts 30 days before gate date to investment committee with contingency (delay, downsize, exit). Target: Protocols signed by Month 1 (2026-11-17); Dashboard by Month 2 (2026-12-17).


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Phase 1 deliverable—the first major operational milestone—is mentioned as "about 8–10 data halls" and "500 MW energized by Months 42–48 (2030-04-17 to 2030-10-17)" without specific, verifiable qualities. The plan defines PUE targets (1.15–1.25) and expansion thresholds but does not specify hall-by-hall commissioning criteria, operational acceptance gates, tenant capacity allocation, connectivity validation, or security clearance status at energization. A range ("about 8–10") is not a fixed deliverable; no baseline operational SLA is defined for Phase 1 go-live.

**Mitigation**: Program Manager: Define SMART Phase 1 Energization Acceptance Criteria by Month 9 (2027-07-17) including (1) exact hall count and power distribution map, (2) per-hall commissioning schedule (Months 42–48 = 2030-04-17 to 2030-10-17), (3) measured PUE ≤1.28 KPI across all halls by Month 50 (2030-12-17), (4) connectivity validation (both audited fiber routes lit and tested), (5) security clearance signoff, and (6) operational SLA baseline (99.5% uptime target, <50 ms latency to Paris). Gate Phase 1 FID on written lender and anchor-tenant approval of acceptance criteria by Month 12 (2027-10-17).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the immersion-cooling pilot (50–100 MW, EUR 50M–100M capex, unproven at scale) does not directly support either of the two core Phase 1 objectives: (i) energize 500 MW with baseline direct-to-chip liquid cooling and PUE ≤1.30, and (ii) achieve Phase 1 FID with DSCR ≥1.30 and ≥30% anchors signed. The plan labels it "optional" and acknowledges "pilot failure risks EUR 50M–100M sunk cost," confirming speculative status. No tenant, lender or contractual requirement mandates immersion; the baseline design alone satisfies all stated constraints. This is classic gold plating: discretionary complexity and cost added to the core deliverable.

**Mitigation**: Project Finance and Engineering Lead: Produce a one-page Immersion-Cooling Benefit Case Review by Month 6 (2027-04-17) justifying pilot inclusion with a KPI (e.g., achieve PUE ≤1.18 in pilot halls by Month 54 = 2031-04-17), owner accountability, and confirmed cost (EUR 50M–100M), or move the pilot to Phase 2 or the backlog. Gate Phase 1 FID approval on this decision.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Grid Connection and Power Infrastructure Strategist is the unicorn role: owns the ~1 GW hosting-capacity kill test (uncontrolled until RTE signs, Month 6 = 2027-04-17), shapes the topology decision (Month 4 = 2027-02-17) by two months before RTE's evidence arrives. Requires rare expertise: RTE operational history, PSSE/DIgSILENT modeling, multi-tranche phasing, French DREAL coordination, competing industrial-load intelligence. Few professionals in Northern Europe combine these credentials. Role departure or inadequacy during Month 0–6 (2026-10-17 to 2027-04-17) breaks the grid gate, forces split-campus redesign (EUR 250M–500M Phase 0 sunk cost, EUR 300M–600M carry cost), and stalls Phase 1 by 6–12 months.

**Mitigation**: Hiring Lead: Identify and vet the candidate Grid Connection and Power Infrastructure Strategist by Month 1 (2026-11-17) with four validation gates: (1) RTE Director-level contact with pre-engineering response commitment in writing by Month 2 (2026-12-17); (2) grid-modeling credentials (PSSE/DIgSILENT) via completed multi-GW study in Western Europe past 5 years, deliverable reviewed; (3) technical interview with independent auditor confirms coordination feasibility; (4) written RTE pre-engineering request sent by Month 2 (2026-12-17) with acknowledgment from RTE. Stop rule: if any gate fails, escalate to investment committee with fallback recruiting plan or recommend 250 MW Phase 1 downsize contingency.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because a legal/regulatory pathway exists (ICPE, environmental authorization, water, agriculture, foreign-investment screening, ANSSI national-security review named explicitly) with early regulator engagement planned (pre-submission dialogues Months 0–1 = 2026-10-17 to 2026-11-17, liaison committees, milestone gates Months 6, 9, 12 = 2027-04-17, 2027-07-17, 2027-10-17). However, critical gaps remain: ANSSI formal clearance timeline (12–18 months from Month 13 = 2027-11-17) extends into Phase 1 build (Months 13–36 = 2027-11-17 to 2029-10-17), creating blocking risk if delayed; no formalized NO-GO protocol exists if DREAL, ANSSI or foreign-investment authorities issue adverse findings; and foreign-investment-screening outcome is entirely uncontrolled until Month 9 (2027-07-17), potentially forcing capital restructuring during Phase 1 FID. Permitting timelines (18–30 months + 24–48 month appeal risk) extend beyond the base-case Phase 1 energization window (Months 42–48 = 2030-04-17 to 2030-10-17), creating 12–24 month downside risk. A fatal-flaw analysis and NO-GO procedure are mentioned in risk language but not yet embedded in formal governance charter or debt covenants.

**Mitigation**: Investment Committee Chair and General Counsel: Execute a "Regulatory NO-GO Protocol" document by Month 2 (2026-12-17) specifying blocking-finding criteria and decision rules per authority (RTE <500 MW = auto-downsize to 250 MW; DREAL denial or >24-month delay = Phase 1 pause; ANSSI blocking concern = sovereign co-investor restructure or 6-month reassessment; foreign-investment veto = capital restructure or exit). Embed the protocol in the investment committee charter and debt documents. Conduct monthly regulatory-status dashboard (Months 1–12 = 2026-11-17 to 2027-10-17) tracking RTE, DREAL, ANSSI and CFIUS milestones; escalate any slippage >30 days before gate date. Obtain written formal opinions from each authority confirming review timeline and no blocking concern by Month 12 (2027-10-17), or trigger Phase 1 FID pause and contingency assessment.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because post-Phase-1 operational sustainability depends on five uncontrolled variables: (1) ongoing energy costs (EUR 60/MWh assumed, range 50–70, not verified; +EUR 30/MWh shock reduces NOI from EUR 400M to EUR 288M at 500 MW, DSCR to 0.96x, breaching the 1.30x lender floor); (2) tenant demand retention and lease renegotiation risk (phase-by-phase FID gates require 30%→50% signed, but AI training demand beyond 3–5 years is unvalidated); (3) maintenance of specialized cooling, security and network assets at 1.15–1.25 PUE target in a 15-year operation (thermal performance degradation, vendor lock-in, parts obsolescence unaddressed); (4) personnel sustainability (50–150 FTE ops headcount not verified; specialized skills in liquid cooling, high-assurance security, and fiber diversity are scarce); (5) technology obsolescence of GPU/TPU and power-delivery standards over 10–15 years of service (5–7 year vendor cycles vs. 15-year debt tenor create mismatch). The plan states revenue stabilization (EUR 550M lease + EUR 223M energy per year at 500 MW) and DSCR 1.34x as targets, but no operational sustainability plan, failure-mode recovery mechanisms, or contingency for sustained demand shortfall exists.

**Mitigation**: Operations and Finance Lead: Develop a comprehensive Operational Sustainability Plan by Month 9 (2027-07-17) covering: (1) energy-cost hedging strategy and tenant pass-through mechanic for sustained cost >EUR 75/MWh; (2) tenant demand-retention roadmap with lease-renewal triggers and ramp-up contingencies for Phase 2–4 if demand <50% of targets; (3) maintenance schedule and spare-parts inventory strategy for critical cooling, security and fiber assets with vendor lock-in mitigation; (4) operations staffing model and succession plan for roles with specialized skills; (5) technology refresh roadmap for power-delivery and accelerator standards. Lock the plan in Phase 1 financing covenants; commit to quarterly operational-sustainability dashboard tracking actual vs. forecast (energy cost, tenant utilization, unplanned downtime, maintenance cost, staffing turnover). If sustained demand drops >20% below forecast by Month 48 (2030-10-17) energization, trigger Phase 2 FID pause and strategic reassessment.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not verify that hard regulatory constraints (zoning/land-use compatibility, occupancy/egress codes, fire load limits, structural capacity, noise bylaws, permit-path feasibility) can be satisfied at the proposed 500 MW scale in the Cambrai/E-Valley and candidate split-campus zones. The plan names the constraint categories (ICPE, environmental authorization, water, biodiversity) but does not present: (1) a zoning letter or land-use opinion from the municipalities confirming the data-center use is permitted on target parcels; (2) an occupancy/egress and fire-load assessment for the proposed 8–10 halls and their geometric layout; (3) a structural-capacity study validating that candidate parcels can bear a 500 MW load at the planned power density; (4) a noise-impact and vibration study confirming compliance with local noise bylaws (typically 55–60 dB in rural/industrial zones). The plan states 'DREAL screening opinion by Month 9 (2027-07-17)' but that is not a binding approval, only a preliminary pathway confirmation. Permits are not targeted before Months 26–39 (2028-12-17 to 2030-01-17), so hard-constraint verification occurs 12+ months after the Phase 0 gate (Month 12 = 2027-10-17) when land options and grid pre-engineering are already committed. If hard constraints are discovered to be unsatisfiable after Phase 0 sunk cost is incurred (EUR 400M–750M by Month 12 = 2027-10-17), the project faces a costly pivot to alternative sites or downsizing.

**Mitigation**: Environmental and Permitting Counsel: Conduct a Fatal-Flaw Constraint Screen by Month 6 (2027-04-17) covering zoning opinion (written municipal confirmation that data-center use is permitted on each target parcel), occupancy/egress code assessment (preliminary life-safety design for the proposed hall envelope and utility routing), fire-load and structural limits (professional engineering opinion on site-bearing capacity and load-capacity compliance), noise-impact model (35 dB baseline measurement plus 3D prediction of plant and hall noise), and permit-path timeline confirmation (written DREAL opinion on ICPE, environmental-authorization and water-permit feasibility within the proposed schedule). Publish the screen with a NO-GO threshold: if any hard constraint cannot be satisfied on the chosen topology, trigger immediate Phase 0 reassessment and potential pivot to alternative sites or downsizing.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies critical external dependencies (RTE grid hosting, land assembly, anchor-tenant demand, ANSSI clearance, DREAL permits, municipal support, debt financing) that are uncontrolled until backed by signed offer, deed, term sheet, formal decision or written commitment. Each dependency arrives at a gate (Month 6, 9, or 12 = 2027-04-17, 2027-07-17, 2027-10-17) and failure of any one triggers downsize, delay or cancellation. However, partial redundancy exists: split-campus topology provides a fallback to single-square; 250 MW downsize is a default if grid or demand fail; lease-and-continue farming and split liability allocation offer partial mitigation to holdout and contamination exposure. The plan explicitly treats all major outcomes as uncontrolled and gates them rather than assuming success.

**Mitigation**: Investment Committee Chair: By Month 2 (2026-12-17), execute a tri-party binding agreement (sponsor, lead lenders, co-investor consortium) embedding Phase 0 tranche releases to committee gate sign-off and locking Phase 1 financing conditions (≥EUR 3B debt term sheet, equity commitments, DSCR floor 1.30x). Commission monthly Evidence Dashboard (Months 1–12 = 2026-11-17 to 2027-10-17) tracking artifact delivery (RTE letter, water opinion, ANSSI opinion, fiber audit, DREAL pre-opinion, tenant term sheets, lender commitment, municipal support) against gate dates; escalate any slippage >30 days to committee with contingency (downsize, delay, cancel) rather than proceeding with unmet thresholds.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies two stakeholders—Infrastructure Finance Consortium (lenders, co-investors) and Development Sponsor—with opposing incentives: consortium prioritizes capital preservation and hard kill gates; sponsor prioritizes momentum and ambition scale. However, the conflict is implicit, not explicitly articulated. The plan states governance intentions (independent committee, supermajority override, dissent publication) but does not define a shared measurable objective (OKR) that aligns both parties on trade-offs between risk mitigation and growth. The topology decision rule (Month 4 = 2027-02-17 before RTE evidence Month 6 = 2027-04-17) and Phase 0 budget breach risk (EUR 250M–500M split-campus pivot) exemplify unresolved tension.

**Mitigation**: Investment Committee Chair and Finance Lead: By Month 2 (2026-12-17), co-author a written Stakeholder Alignment OKR document with sponsor and consortium specifying one shared, measurable objective: Phase 0 gate pass only if RTE ≥500 MW confirmed AND land ≥70% optioned AND anchors ≥30% signed by Month 12 (2027-10-17), or a coordinated downsize/split decision. Embed the OKR in the governance charter and debt documents with explicit override costs (additional equity, lender consent, timeline slip) to make trade-offs visible and accountable.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a formalized, binding feedback loop with enforceable kill criteria. The plan states intentions ("independent investment committee," "numeric kill thresholds locked by Month 2 = 2026-12-17," "external red team with monthly pass/fail opinions") but does not embed these in contractual debt covenants, tri-party binding agreements, or operational procedures. Governance remains advisory: "dissent publication to lenders and co-investors" creates transparency but not authority to halt drawdowns or cancel Phase 1 if thresholds fail. The sponsor board retains overridable discretion. Sunk-cost pressure (EUR 400M–750M Phase 0 by Month 12 = 2027-10-17) will routinely override stated gates absent a mechanism that ties tranched capital release to committee sign-off and lender consent. No monthly KPI dashboard or change-control process with rethreshold triggers exists yet.

**Mitigation**: Investment Committee Chair and Finance Lead: Execute a tri-party Binding Governance and Gate Enforcement Agreement (sponsor, lead lenders, co-investor consortium) by Month 1 (2026-11-17) vesting Phase 0 tranche releases in the independent committee, locking numeric kill thresholds (grid ≥500 MW, land ≥70%, anchors ≥30% signed, ANSSI clearance pathway confirmed, municipal support ≥2 of 3) in the debt documents, and establishing a monthly KPI dashboard (revenue ramp, DSCR, tenant commitments, grid/permit status, cost variance) with automatic covenant acceleration if thresholds are breached.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because four strongly coupled risk cascades exist: (1) RTE grid <1 GW → split-campus topology pivot → EUR 250M–500M Phase 0 rework + EUR 300M–600M carrying cost + lender repricing +100 bps; (2) EDF energy cost >EUR 75/MWh → anchor-tenant demand collapse → signed commitment <30% → financing loss → Phase 1 delay 12–24 months; (3) ANSSI investment-restriction regime → co-investor capital restructuring → debt covenant renegotiation → tenant lease cascades; (4) sunk-cost momentum EUR 400M–600M by Month 9 (2027-07-17) + weak governance enforcement (charter not yet in debt documents) → override of kill criteria → locked financial stress. No unified interdependency map or combined heatmap with contingency thresholds exists to surface multi-node cascades.

**Mitigation**: Risk Leadership and Investment Committee Chair: Deliver a unified Risk Interdependency Map (bow-tie or FTA diagram) by Month 6 (2027-04-17) identifying four critical cascades (grid→topology→capital, energy→demand→finance, regulation→equity→operations, sunk-cost→override→breach), assign owner and NO-GO/contingency thresholds per cascade (e.g., RTE <500 MW triggers auto split-campus and lender renotification within 5 days), embed thresholds in debt covenants by Month 12 (2027-10-17).