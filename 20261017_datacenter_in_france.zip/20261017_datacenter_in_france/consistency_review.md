## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Is the independent investment committee chartered (Month 1 = 2026-11-17) with numeric kill thresholds locked in writing (Month 2 = 2026-12-17), and is tranche release legally tied to its sign-off? | At least 2 external directors, lender/co-investor observers, two-thirds supermajority override (proposed), dissent published to lenders; thresholds fixed in writing by Month 2 (2026-12-17); tranche 2 (EUR 250M, Months 3–6 = 2027-01-17 to 2027-04-17) released only on committee sign-off. | Signed charter and tri-party agreement with lenders and co-investors (Months 1–2 = 2026-11-17 to 2026-12-17); red-team monthly pass/fail reports. | Hold spending at the tranche 1 cap (cumulative EUR 150M) and do not release tranche 2. Without enforceable gates the sunk-cost override scenario (FM1) is likely, so pause or cancel rather than proceed on advisory governance. |
| 2 | Is at least 70% of the target parcel under non-coercive option at no more than 15% above benchmark land value, and does written RTE evidence of at least 1 GW for that node exist? | At least 70% optioned at ≤15% premium (first check Month 3 = 2027-01-17, confirmed at the Month 4 = 2027-02-17 topology decision); single square only if RTE also gives at least 1 GW to that node in writing. Split nodes need at least 80% optioned by Month 12 (2027-10-17). | GIS-linked parcel/option register and option agreements (Month 3 = 2027-01-17); RTE interim estimate or written letter (Month 3 = 2027-01-17 requested, Month 6 = 2027-04-17 due); independent grid audit interim findings. | Default to a split campus (2–3 nodes of 250–500 MW). Drop any zone where the node falls below 80% optioned. Accept the split premium of EUR 250M–500M and 6–12 months of delay. If no node qualifies, downsize or cancel. |
| 3 | Has RTE issued a written preliminary feasibility letter for at least 500 MW within 36 months, with curtailment at or below 10% (walk-away 15%) and a credible path to ~1 GW cumulative? | Written RTE letter for ≥500 MW within 36 months by Month 6 (2027-04-17); annual curtailment ≤10% (proposed), walk-away 15%; reinforcement co-funding below EUR 1.0B tripwire (estimate). Hosting above ~1 GW cumulative remains the primary kill test for the 9 GW ambition. | RTE written letter (Month 6 = 2027-04-17, uncontrolled); independent grid audit; RTE statement on curtailment (Month 9 = 2027-07-17). | Below 500 MW at every node: cancel Phase 1. Between 500 MW and ~1 GW: proceed only as a 250–500 MW node (a project decision on whether this counts as passing is required) and defer Phase 2. Curtailment above 15%: cut Phase 1 to 500–750 MW or less. A late or missing letter allows only a conditional pass. |
| 4 | Are binding anchor-tenant term sheets signed for at least 30% of Phase 1 size (150 MW of 500 MW), with investment-grade credit or a parent guarantee and reservation fees in escrow, against a credible EDF price indication? | ≥150 MW binding term sheets by Month 9 (2027-07-17) (executed take-or-pay or reservation agreement with fees paid by Month 12 = 2027-10-17); counterparty BBB− or better or parent guarantee; reservation fee EUR 10M–50M per 100 MW; EDF non-binding LOI (Month 6 = 2027-04-17) and term sheet (Month 9 = 2027-07-17) at a capped price within EUR 50–70/MWh (not verified). | Signed term sheets and escrowed fees (Month 9 = 2027-07-17); EDF LOI (Month 6 = 2027-04-17) and term sheet (Month 9 = 2027-07-17); tenant pipeline dashboard. | LOIs count as zero demand. Resize Phase 1 to signed MW (250 MW) with price-shock clauses and defer Phase 2, or pause to Month 24 (2028-10-17). If signed demand is below 30% even of a resized tranche, take no FID. |
| 5 | Is firm debt of at least EUR 3B committed (tenor ≥12 years, about benchmark +200 bps) with equity bound, and does a reconciled cost stack fit under the EUR 10B ceiling? | Firm senior debt ≥EUR 3B for the 500 MW tranche and ≥EUR 2B equity; DSCR 1.34x base and ≥1.30x lender minimum (proposed); cost-stack reconciliation by Month 9 (2027-07-17) showing stacked add-ons (EUR 1.55B–4.2B) funded, deferred or cut within EUR 10B. Hardware scope inside or outside the cap must be decided first. | Lender credit-committee terms (written conditions by Month 6 = 2027-04-17, firm commitment by Month 12 = 2027-10-17); equity commitments; published cost reconciliation signed off by lenders and committee (Month 9 = 2027-07-17). | Resize to the debt the signed MW supports (250 MW), seek an equity cure, or defer FID 12–24 months. Cancel if the unfunded add-ons cannot be placed under the ceiling. |
| 6 | Do the social-license and national-security gates hold at Month 12 (2027-10-17): written support from at least 2 of 3 key municipalities, no major legal challenge pending, and written ANSSI confirmation that formal review can start in Month 13 (2027-11-17) with no blocking concern? | ≥2 of 3 most affected municipalities in writing (signatures targeted Month 9 = 2027-07-17); no major legal challenge; ANSSI written confirmation at Month 12 (2027-10-17) of formal review start at Month 13 (2027-11-17), with clearance expected 12–18 months later (about Months 25–31 = 2028-11-17 to 2029-05-17). All uncontrolled. | Municipal resolutions or letters (Months 9–12 = 2027-07-17 to 2027-10-17); ANSSI/DGSI informal opinion (Month 6 = 2027-04-17) and written confirmation (Month 12 = 2027-10-17); DREAL screening opinion (Month 9 = 2027-07-17). | Pause Phase 1 and reassess. Restructure co-investors or tenant mix for a security objection. Shift to nodes with supportive municipalities if one refuses formally. If opposition is sustained, split, delay or cancel. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: phase_schedule_and_capacity = Phase 1 Months 12–36 (2027-10-17 to 2029-10-17) (500 MW–1 GW)
    observed:  Energization Months 42–48 (2030-04-17 to 2030-10-17); permit decision Months 26–39 (2028-12-17 to 2030-01-17); pilot hall Months 12–24 (2027-10-17 to 2028-10-17)
HIGH CF-002  document: canonical_facts
    canonical: grid_kill_test = Hosting capacity above ~1 GW is the primary kill test
    observed:  Gate and stop rule at ≥500 MW; 'only grid above ~1 GW kills the project'
HIGH CF-003  document: review_plan Review 8 item 2 and Review 11 item 2
    canonical: usd_hardware_scope_open_decision = EUR 1.5B–2.3B, ring-fenced outside the cap; inclusion is open
    observed:  Ceiling drops to EUR 3.7B–3.8B; headroom shrinks by hardware to EUR 0.8B–3.45B
HIGH CF-004  document: canonical_facts
    canonical: phase2_fid_gate = At least 12 months of Phase 1 operating data; Phase 2 Months 36–84 (2029-10-17 to 2033-10-17)
    observed:  Phase 2 FID Months 36–48 (2029-10-17 to 2030-10-17) while first energization is Months 42–48 (2030-04-17 to 2030-10-17)
HIGH CF-005  document: review_plan; executive summary Feedback
    canonical: topology_decision_rule = Month 4 (2027-02-17); split campus is the default unless RTE written evidence is in hand
    observed:  Topology lock moved to Month 6.5 (2027-05-02) / Month 3 (2027-01-17); audit delivered Month 9 (2027-07-17)
MEDIUM CF-006  document: executive summary; project plan; premortem
    canonical: economic_unit_and_financing_owner = Unit = one node tranche, base 500 MW
    observed:  Split nodes of 250 MW; Phase 1 'at Cambrai or split-campus'; RTE '500 MW per node'
MEDIUM CF-007  document: review_plan
    canonical: energy_price_shock = +EUR 30/MWh = about EUR 112M per year, DSCR 0.96x; 10% discount = DSCR 1.15x
    observed:  10–15% discount = EUR 112M–224M, DSCR 0.96x–1.06x; EUR 60→100 = EUR 112M
MEDIUM CF-008  document: review_plan; self_audit; executive summary
    canonical: coverage_and_surplus = Proposed lender minimum DSCR 1.30x; base 1.34x
    observed:  Floors of 1.25x, 1.20x and 1.15x
MEDIUM CF-009  document: review_plan
    canonical: fallbacks_vs_budget_and_dates = Split pivot: +EUR 250M–500M Phase 1 capex; split from start: Phase 0 +EUR 100M–250M
    observed:  'EUR 250M–500M avoidable Phase 0 spend'; release tranches 1–2 after Month 4 (2027-02-17)
MEDIUM CF-010  document: pitch
    canonical: national_security_review = Informal opinion Month 6 (2027-04-17); formal review starts Month 13 (2027-11-17); clearance about Months 25–31 (2028-11-17 to 2029-05-17)
    observed:  Written clearance by Month 9 (2027-07-17)
MEDIUM CF-011  document: review_plan
    canonical: expansion_budget_estimates = EUR 25B–45B to 3 GW; EUR 100B–140B+ to 9 GW
    observed:  Phase 2–4 capex EUR 20B–45B cumulative
MEDIUM CF-012  document: pitch; review_plan
    canonical: social_license_gate = Written support from ≥2 of 3 municipalities; package contingent on permits
    observed:  Municipal vetoes; binding non-contingent benefit agreement by Month 6–9 (2027-04-17 to 2027-07-17)
```

### 1. Phase 1 build window vs permit decision and energization dates (🔴 High) — needs a project decision

- **canonical phase_schedule_and_capacity; pitch 'Phase 1 Baseline'; project plan; risk register (pilot hall):** Phase 1 Months 12–36 (2027-10-17 to 2029-10-17): 500 MW built, '500 MW energized, 8–10 halls online' as the Phase 1 baseline; 2–5 MW pilot hall in Months 12–24 (2027-10-17 to 2028-10-17).
- **canonical permitting_and_schedule_realism; executive summary; pitch:** Permit decision about Months 26–39 (2028-12-17 to 2030-01-17); first-block energization base case Months 42–48 (2030-04-17 to 2030-10-17) (downside 48–60).
- **Why it conflicts:** Energization falls after the Phase 1 window closes, even in the base case. Hall construction and the pilot hall in Months 12–24 (2027-10-17 to 2028-10-17) would also start before the ICPE/environmental authorization (Months 26–39 = 2028-12-17 to 2030-01-17), which should precede build.
- **Suggested resolution:** Decide how to reconcile the user-fixed Phase 1 window (Years 1–3) with permitting realism. Options: redefine Phase 1 as Months 12–48 (2027-10-17 to 2030-10-17) with enabling works only until permit issue; keep Months 12–36 (2027-10-17 to 2029-10-17) as the nominal window and label energization at Months 42–48 (2030-04-17 to 2030-10-17) as a base-case overrun; or add a gate that no hall construction starts before permits. Also restate the pitch Phase 1 metrics as post-energization KPIs.

### 2. ~1 GW grid kill test vs 500 MW Phase 0 gate (🔴 High) — needs a project decision

- **canonical grid_kill_test and success_failure_definition; executive summary; pitch:** Hosting capacity above ~1 GW (cumulative) is the primary kill test; failure = no grid hosting above ~1 GW. Pitch: 'Only grid capacity above ~1 GW kills the project'.
- **canonical rte_phase1_gate; project plan Measurable; premortem FM2:** The Phase 0 gate and FM2 stop rule require only an RTE letter for ≥500 MW within 36 months, and Phase 1 proceeds at 500 MW.
- **Why it conflicts:** A project can pass the Phase 0 gate with 500–999 MW and still meet the stated failure definition. The documents do not say whether 'kill' means the 9 GW ambition, the single-square topology, or Phase 1 itself. The RTE letter due at Month 6 (2027-04-17) also cannot resolve a >1 GW question.
- **Suggested resolution:** Separate two tests in the charter: (a) Phase 1 gate at ≥500 MW, and (b) a campus-scale kill test at ~1 GW cumulative that decides whether the 9 GW vision continues or is capped at a 250–500 MW node. State the outcome for 500–999 MW and the evidence required for >1 GW.

### 3. USD hardware inside or outside the EUR 5B–10B, and the arithmetic built on it (🔴 High) — needs a project decision

- **canonical usd_hardware_scope_open_decision; pitch FX Exposure:** USD hardware EUR 1.5B–2.3B is ring-fenced outside the campus-company cap; whether the user's EUR 5B–10B includes it is an open decision. Pitch: hardware 'sits with tenants'.
- **review_plan Review 8 item 2; Review 11 item 2:** If included, the 500 MW ceiling 'drops to EUR 3.7B–3.8B' with a 'EUR 1.2B–1.3B scope cut'. If excluded, headroom 'shrinks by EUR 1.5B–2.3B', 'leaving only EUR 0.8B–3.45B'.
- **Why it conflicts:** Subtracting EUR 1.5B–2.3B from the EUR 5.0B base gives EUR 2.7B–3.5B, not 3.7B–3.8B. A cost that sits outside the cap cannot also shrink headroom to the cap. The EUR 0.8B–3.45B headroom comes from the add-on stack, not from hardware. The decision remains open while the scenarios are mis-stated.
- **Suggested resolution:** Take the open decision explicitly at the committee charter. If hardware is inside the cap, rebase to EUR 2.7B–3.5B for infrastructure at 500 MW. If outside, headroom stays EUR 5.0B before the stack (EUR 0.8B–3.45B after) and hardware is a separate tenant/lessor financing. Delete the muddled paragraph.

### 4. Phase 2 FID gate vs schedule (🔴 High) — needs a project decision

- **canonical phase2_fid_gate and phase_schedule_and_capacity; pitch Phase 2 (Months 36–84 = 2029-10-17 to 2033-10-17); review_plan Review 14:** Phase 2 FID requires ≥12 months of Phase 1 operating data, average PUE ≤1.28 across commissioned halls, and signed take-or-pay for ≥50% of the next tranche; Phase 2 starts Month 36 (2029-10-17) (FID Months 36–48 = 2029-10-17 to 2030-10-17).
- **canonical permitting_and_schedule_realism and contracted_demand_and_ramp; pitch:** First-block energization Months 42–48 (2030-04-17 to 2030-10-17) and stabilized demand only at Months 54–60 (2031-04-17 to 2031-10-17).
- **Why it conflicts:** Twelve months of operating data cannot exist before about Month 54–60 (2031-04-17 to 2031-10-17), yet Phase 2 FID is placed at Months 36–48 (2029-10-17 to 2030-10-17). The executive summary also names Phase 1 FID at Month 12 (2027-10-17) as 'Success', whereas the user's definition of success is Phase 0 and 1 completed with a Phase 2 FID backed by signed anchors.
- **Suggested resolution:** Decide whether Phase 2 FID waits until about Month 54–60 (2031-04-17 to 2031-10-17) (keeping the 12-month data rule, which shifts Phase 2 to start after Month 60 = 2031-10-17 and compresses Phases 3–4), or the data rule is relaxed to the pilot hall. Re-time the Phase 2 FID and align the success definition.

### 5. Topology lock at Month 4 (2027-02-17) before RTE evidence at Month 6 (2027-04-17) (🔴 High)

- **canonical topology_decision_rule; executive summary; project plan; pitch:** Topology decision at Month 4 (2027-02-17); single square only if ≥70% optioned AND RTE gives ≥1 GW in writing; split campus is the default because the RTE letter is due at Month 6 (2027-04-17).
- **review_plan Reviews 1, 2, 8, 9, 12, 13; executive summary Feedback; assumptions Review section:** Reviews and the executive summary's feedback propose moving the lock to Month 6.5 (2027-05-02), or treat the Month 4 (2027-02-17) default as an unresolved inversion. The assumptions place the Topology Decision Document at Month 3 (2027-01-17). The independent grid audit is reported only at Month 9 (2027-07-17) yet is cited as input to the Month 4 (2027-02-17) decision (and at Month 5 = 2027-03-17 elsewhere).
- **Why it conflicts:** The canonical rule already resolves the calendar conflict by defaulting to split unless RTE written evidence is already in hand. Later documents re-open it with Month 3 (2027-01-17), Month 4 (2027-02-17), Month 5 (2027-03-17), Month 6.5 (2027-05-02) and Month 9 (2027-07-17) alternatives, and an audit delivered at Month 9 (2027-07-17) cannot inform a Month 4 (2027-02-17) decision.
- **Suggested resolution:** Keep Month 4 (2027-02-17) and the split default. To keep the single square alive, request the RTE interim estimate and the audit's interim findings by Month 3 (2027-01-17) (publication of the full audit stays at Month 9 = 2027-07-17). Treat any move to Month 6.5 (2027-05-02) as a separate committee decision, not a plan fact.

### 6. What Phase 1 means under a split campus (unit and scope) (🟡 Medium) — needs a project decision

- **canonical economic_unit_and_financing_owner and phase1_base_case:** Unit = one node tranche, base 500 MW; Phase 1 base case is 500 MW at one node (Cambrai); financing is EUR 3.0B debt on 500 MW; FID needs 150 MW of 500 MW signed.
- **canonical topology_decision_rule; executive summary; premortem FM2:** Split nodes are Cambrai 500 MW, Dunkirk 250 MW (range 250–500) and Valenciennes 250 MW; executive summary: 'Phase 1 FID authorized (500 MW at Cambrai or split-campus topology)'. The RTE gate says 500 MW but the premortem says 'per node'.
- **Why it conflicts:** The documents do not say whether a split Phase 1 is 500 MW in total (for example 250 + 250), Cambrai 500 plus other nodes, or Cambrai only. The 30% tenant gate, the EUR 3B debt gate, the 500 MW RTE letter, the 250–500 MW premium and the EUR 10B ceiling each depend on that answer. A 250 MW node cannot satisfy a 500 MW per-node RTE letter.
- **Suggested resolution:** Decide the economic unit under a split: either Phase 1 stays 500 MW in total (gates unchanged, nodes sized to sum to 500 MW) or each node is its own tranche with its own gates. Restate the RTE, tenant, debt and permit gates per node or per campus accordingly.

### 7. Energy-price and lease-discount sensitivities mis-computed in reviews (🟡 Medium)

- **canonical coverage_stress_gap and energy_price_shock:** A 10% lease discount gives NOI EUR 345M and DSCR 1.15x (gap about EUR 44M); +EUR 30/MWh adds about EUR 112M per year and gives DSCR 0.96x without pass-through. Baseline EUR 60/MWh.
- **review_plan Reviews 4, 5, 6, 10 and 13:** '10–15% lease discounts reduce NOI EUR 112M–224M ... DSCR 0.96x–1.06x'; '10–15% discounts: NOI EUR 345M–375M, DSCR 1.20x–1.15x'; 'EUR 80–100/MWh (20–40% above baseline) ... NOI falls EUR 112M–224M'; 'EUR 100/MWh realized cost adds EUR 112M ... at 500 MW' and '>EUR 80/MWh ... NOI falls EUR 112M'.
- **Why it conflicts:** Recomputed: a 10–15% discount is EUR 55M–83M, so NOI is EUR 345M–318M and DSCR 1.15x–1.06x. EUR 112M is the +EUR 30/MWh shock, and EUR 224M would give DSCR 0.59x. Moving from EUR 60 to EUR 100/MWh is +EUR 40/MWh (about EUR 149M), and EUR 80–100/MWh is 33–67% above EUR 60, not 20–40%.
- **Suggested resolution:** Use only the canonical pairs: 10% discount = DSCR 1.15x; +EUR 30/MWh = about EUR 112M and DSCR 0.96x (no pass-through). Express other cases as EUR 3.72 M per EUR 1/MWh (about EUR 3.7M per EUR/MWh) and EUR 55M per 10% of lease revenue, and recompute any range from those.

### 8. DSCR floors and covenants differ (🟡 Medium)

- **canonical coverage_and_surplus; self_audit item 6; pitch:** Proposed lender minimum DSCR 1.30x; baseline 1.34x; 10% discount stress result 1.15x.
- **review_plan Reviews 5 and 6; self_audit item 4; executive summary:** 'Stress-test floor 1.20x' and 'covenant floor at 1.25x' (Review 6 and Review 5); self-audit item 4 'shared DSCR covenant floor (1.25x minimum)'; executive summary calls 1.15x the 'stress floor'.
- **Why it conflicts:** Four different DSCR levels (1.30x, 1.25x, 1.20x, 1.15x) are called floors, covenants or minimums. 1.15x is a computed stress outcome below the 1.30x minimum, not a floor anyone has agreed.
- **Suggested resolution:** Keep 1.30x as the proposed lender minimum and 1.34x as base. Describe 1.15x as the 10%-discount stress result and 0.96x as the unpassed energy shock. If a lower covenant (for example 1.25x) is wanted, label it a negotiation fallback (proposed threshold) and decide it with lenders.

### 9. Split-campus premium booked as 'Phase 0 spend'; tranche release timing (🟡 Medium)

- **canonical fallbacks_vs_budget_and_dates and phase0_tranche_caps:** Split pivot after Phase 0 costs +EUR 250M–500M of Phase 1 capex (plus EUR 300M–600M carrying cost). Only split-from-start adds to Phase 0 (EUR 100M–250M). Tranche 1 (EUR 150M) covers Months 0–2 (2026-10-17 to 2026-12-17) and tranche 2 (EUR 250M) Months 3–6 (2027-01-17 to 2027-04-17).
- **review_plan Reviews 1, 2, 8, 12, 13 and 'Showstopper Risks' item 2:** A Month 4 (2027-02-17) split default is said to lock 'EUR 250M–500M of avoidable Phase 0 spend'; the cap is called 'misaligned with ... pivot cost of EUR 250M–500M'; 'release tranches 1–2 (EUR 400M) only after Month 4 (2027-02-17) topology lock'.
- **Why it conflicts:** The EUR 250M–500M is Phase 1 capex premium, not Phase 0 spend, and it does not breach the EUR 750M cap. Tranche 1 is scheduled and spent before Month 4 (2027-02-17), so it cannot be released after the topology lock.
- **Suggested resolution:** Quote EUR 100M–250M as the Phase 0 exposure (split from the start only) and EUR 250M–500M as Phase 1 capex premium. Make the committee sign-off condition apply to tranche 2 onward, with tranche 3–4 (EUR 350M) held until the Month 9 (2027-07-17) evidence.

### 10. Foreign co-investor clearance by Month 9 (2027-07-17) vs ANSSI timeline (🟡 Medium)

- **canonical national_security_review:** Informal ANSSI opinion at Month 6 (2027-04-17); written confirmation at Month 12 (2027-10-17) that formal review can start at Month 13 (2027-11-17); formal clearance about Months 25–31 (2028-11-17 to 2029-05-17).
- **pitch Ethical Considerations and Metrics:** 'No foreign co-investor participation without written clearance by Month 9 (2027-07-17)'; 'Zero national-security blocks' in the Phase 1 baseline; sovereign-adjacent co-investors are bound for Phase 1 equity at Month 12 (2027-10-17).
- **Why it conflicts:** No formal clearance can exist at Month 9 (2027-07-17), because formal review has not started. A literal reading would exclude sovereign-adjacent co-investors from the Phase 0 and Phase 1 funding the plan relies on.
- **Suggested resolution:** Replace with the canonical sequence: no binding foreign co-investor commitment beyond Phase 0 funding without a favorable informal ANSSI opinion (Month 6 = 2027-04-17), written confirmation at Month 12 (2027-10-17), and formal clearance as an uncontrolled later condition. State explicitly whether equity from foreign co-investors can be bound at FID before clearance.

### 11. Phase 2–4 capex figure (🟡 Medium)

- **canonical expansion_budget_estimates:** EUR 25B–45B cumulative to 3 GW (Phase 2 increment about EUR 20B–35B); EUR 100B–140B+ for 9 GW.
- **review_plan Review 14 item 1:** 'Phase 2–4 capex of EUR 20B–45B cumulative (estimate)' in the refinancing analysis.
- **Why it conflicts:** Phases 2–4 reach 9 GW, so their capex is far above EUR 45B (about EUR 95B–135B on top of Phase 1). EUR 20B–45B corresponds only to the Phase 2 increment or cumulative capex to 3 GW. This understates the refinancing and equity-appetite problem.
- **Suggested resolution:** Use EUR 20B–35B for the Phase 2 increment (cumulative EUR 25B–45B to 3 GW) and EUR 100B–140B+ cumulative for 9 GW, and rerun the refinancing stress on the correct tranche sizes.

### 12. Municipal role and community-benefit timing (🟡 Medium)

- **canonical social_license_gate; assumptions (no binding veto):** Gate = written support from ≥2 of 3 municipalities, no legal challenge; no binding local veto; community-benefit package EUR 50M–150M contingent on permits.
- **pitch Stakeholder Benefits; review_plan Review 14 item 3:** '2 of 3 municipal vetoes in governance and binding community-benefit agreement by Month 9 (2027-07-17)'; 'lock binding community-benefit agreement ... fixed Phase 1 cost, not contingent' by Month 6 (2027-04-17).
- **Why it conflicts:** The pitch grants vetoes that the plan rejects. A binding, non-contingent benefit commitment at Month 6–9 (2027-04-17 to 2027-07-17) conflicts with a package contingent on permits that are not decided until Months 26–39 (2028-12-17 to 2030-01-17). Project plan drafts the agreement at Month 5 (2027-03-17) and the risk register seeks only a non-binding endorsement at Month 9 (2027-07-17).
- **Suggested resolution:** Keep written support as a gate, not a veto. Sign a binding agreement by Month 9 (2027-07-17) whose payments are conditioned on permits, and budget the amounts as a defined Phase 1–2 cost (estimate).

## Summary

The core economics reconcile: 500 MW revenue, opex, NOI, debt service, DSCR 1.34x, 1.15x and 0.96x stress cases, energy volume and the Phase 0 tranches all recompute correctly, and the executive summary, project plan and pitch mostly follow the canonical values. The serious problems are structural. Phase 1 is scheduled for Months 12–36 (2027-10-17 to 2029-10-17), but permit decisions arrive at Months 26–39 (2028-12-17 to 2030-01-17) and first energization at Months 42–48 (2030-04-17 to 2030-10-17). The ~1 GW kill test does not match the 500 MW Phase 0 gate. The Phase 2 FID gate needs operating data that cannot exist at the scheduled Phase 2 start. The USD hardware question and the Phase 1 scope under a split campus are unresolved project decisions. The review document also carries several arithmetic slips (DSCR and energy sensitivities, the Phase 1 hardware headroom, Phase 2–4 capex) and mislabels the split-campus premium as Phase 0 spend. Both are repairable. The pitch contains a few statements that the canonical gates contradict (foreign co-investor clearance by Month 9 = 2027-07-17, municipal vetoes).