# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Extreme: a notional 9 GW, 161 km² (12.7 km × 12.7 km) AI campus in Hauts-de-France, with an estimated €100B–€140B+ full buildout over 10–15+ years (user constraint). Scale is national or European in significance and tests grid, land, water, permitting and social limits at once. The ambition is explicitly framed as something to stress-test, not assume.

**Risk and Novelty:** Very high and largely unprecedented: no known single-site 9 GW campus exists, and 161 km² contiguous assembly is doubtful. The main exposures are RTE hosting capacity above ~1 GW (the first failure condition), USD GPU/TPU spend and FX, tenant credit and demand, land fragmentation, brownfield contamination, and local opposition. Fast-track permitting status is not confirmed (not verified). External approvals are uncontrolled until backed by contract, permit, formal decision or signed term sheet.

**Complexity and Constraints:** Very complex. It spans land, grid, power procurement, cooling and water, fiber, security and national-security review, permitting, workforce, tenants and financing. Phase 0 is estimated at €250M–€750M with no committed capital until the gate. Phase 1 is estimated at €5B–€10B for 500 MW–1 GW. Next-phase FID needs signed take-or-pay or equivalent commitments covering ≥30–50% of the tranche (user constraint). Letters of intent do not count. Single-square vs split-campus must be compared honestly, and downsizing, splitting, delaying or cancelling are legitimate outcomes.

**Domain and Tone:** Business and infrastructure strategy: private hyperscale developer backed by an infrastructure-fund consortium with sovereign-adjacent co-investment. The tone is skeptical, red-team and gate-driven, not promotional. It requires physical, in-region execution (land, grid, construction, community engagement).

**Holistic Profile:** A very large, high-uncertainty infrastructure venture deliberately framed as a staged, evidence-gated feasibility test. It wants proof of grid, land, tenants, financing and social license before serious capital is committed. It calls for incremental grid tranches, milestone-capped capital, concrete demand evidence, legitimacy-building permitting and independent kill authority. Speculative land-grabbing or position-holding runs against its character, but so does an overly restrictive structure that cannot reach a multi-GW outcome.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Earn grid capacity tranche by tranche through demonstrated flexibility, and tie each capital release to milestone-based drawdowns with pre-agreed abandonment conditions. Pre-sold capacity reservations make demand evidence concrete before construction starts. The standard permitting route with early voluntary consultation trades some speed for legitimacy. An investment committee independent of the development team holds the kill thresholds, so the stated gates cannot be renegotiated under sunk-cost pressure.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Tranche-based grid requests (500 MW–1 GW), milestone-capped Phase 0 drawdowns, reservation-fee demand evidence and an independent investment committee with numeric kill thresholds mirror the plan's gates and success and failure definitions. Standard permitting with early consultation gives legitimacy at a manageable schedule cost.

**Key Strategic Decisions:**

- **Grid Hosting Capacity and Transmission Sequencing:** Request a small first tranche of 500 MW–1 GW with contractual flexibility, curtailment and BESS commitments, and use demonstrated behavior to earn later tranches.
- **Capital Staging and Commitment Structure:** Raise a staged Phase 0 facility with the infrastructure-fund consortium, containing milestone-based drawdowns and pre-agreed abandonment conditions that cap sunk cost.
- **Anchor-Tenant and Sovereignty Model:** Pre-sell capacity to a mixed tenant base through capacity reservation fees paid before construction, and refuse to start a phase until reservations cover a pre-agreed share of its cost.
- **Permitting Route and Social-License Strategy:** Follow the standard local permitting route, run an early voluntary public consultation, and give municipalities and associations a role in monitoring, trading speed for legitimacy.
- **Gate Governance, Option Value and Stranded-Asset Exit Design:** Vest gate decisions in an investment committee separate from the development team, with pre-agreed numeric kill thresholds (proposed thresholds, to be set in Phase 0) that trigger automatic review.

**The Decisive Factors:**

- **Fit with ambition and risk:** The 9 GW goal is unproven, so the plan needs a path that earns capacity in steps. A 500 MW–1 GW first grid tranche with flexibility commitments directly tests the ~1 GW kill condition without signalling speculation.
- **Gates that bind:** Milestone-based drawdowns, pre-agreed abandonment conditions and an independent investment committee make kill criteria enforceable and cap sunk cost. This matches the 'no committed capital until the Phase 0 gate' rule and the infrastructure-fund backing.
- **Demand evidence:** Reservation fees paid before construction fit the rule that only signed take-or-pay or equivalent terms (≥30–50% of the next tranche) justify FID.
- **Permitting:** The standard route with early consultation avoids reliance on fast-track status, which is not confirmed (not verified).
- **Why not Pioneer's Claim:** At-risk multi-GW filings and sponsor-controlled gates are promotional and speculative.
- **Why not Regional Anchor:** A sovereign-only anchor base and municipal veto risk too little scale and demand; sponsor-only Phase 0 funding ignores the consortium.

---
## Alternative Paths
### The Pioneer's Claim
**Strategic Logic:** Capture grid queue position, fast-track status and global-hyperscaler demand before rivals do, and accept that early at-risk spend, foreign-ownership review and speculative-filing perception are the price of access. Speed is protected by keeping gate authority with the sponsor board, with an external red team as the check. The USD hardware burden is moved off the campus balance sheet to the tenants and lessors. Schedule benefits from fast-track status remain uncontrolled until a formal decision exists (not verified).

**Fit Score:** 3/10

**Assessment of this Path:** Early multi-GW filings, at-risk spend and sponsor-board gate control contradict the plan's skeptical stance, 'no committed capital until the Phase 0 gate' and the ~1 GW grid kill test. It also relies on fast-track status that is not confirmed (not verified). The ring-fenced USD vehicle is the only strongly compatible element.

**Key Strategic Decisions:**

- **Grid Hosting Capacity and Transmission Sequencing:** File a full multi-GW connection request early to secure queue position, and fund studies and substation pre-engineering at risk to hold the place.
- **Capital Staging and Commitment Structure:** Separate the land-and-power infrastructure vehicle from the compute-hardware vehicle, so tenants or lessors carry GPU financing and USD risk while the campus company finances only EUR assets.
- **Anchor-Tenant and Sovereignty Model:** Target two or three global hyperscalers or AI labs on multi-year take-or-pay leases, and accept the associated foreign-ownership and data-sovereignty review as a cost of access.
- **Permitting Route and Social-License Strategy:** Seek national-major-project or equivalent fast-track status for the anchor site, and pair it with a funded public debate and a binding community-benefit agreement.
- **Gate Governance, Option Value and Stranded-Asset Exit Design:** Keep gate authority with the sponsor’s board but commission an external red team to publish a pass or fail opinion before each gate, with dissent recorded to lenders and co-investors.

### The Regional Anchor
**Strategic Logic:** Minimize stranded-asset and political risk by treating the campus as part of a regional reindustrialization package. Reinforcement costs are shared with an industrial consortium, Phase 0 is funded by sponsor equity with no third-party obligations, and infrastructure is designed for redeployment if the campus is downsized or cancelled. A sovereign-AI anchor base and a binding local consultation give the project the most defensible social license, at the cost of speed, scale and the option to proceed in municipalities that refuse. Downsizing or a split campus is the expected outcome, not a failure.

**Fit Score:** 6/10

**Assessment of this Path:** Strong on skepticism, downsizing and split-campus logic and on redeployable assets. However, a sovereign-only anchor base and binding local veto may be too slow and small to reach the take-or-pay thresholds and multi-GW growth, and sponsor-only Phase 0 funding ignores the consortium backing.

**Key Strategic Decisions:**

- **Grid Hosting Capacity and Transmission Sequencing:** Co-develop dedicated generation and storage with a regional industrial consortium to share reinforcement costs, so the campus competes for grid capacity as part of a broader reindustrialization package.
- **Capital Staging and Commitment Structure:** Fund Phase 0 entirely from sponsor equity with no binding third-party commitments, and release further capital only after a formal gate review against pre-agreed kill criteria.
- **Anchor-Tenant and Sovereignty Model:** Build around a French and European sovereign-AI consortium of public-sector and domestic industrial users, with segregated high-security halls, and use hyperscalers only as secondary tenants.
- **Permitting Route and Social-License Strategy:** Make the permit application conditional on a local referendum-style consultation or citizen panel, and accept a binding outcome, including the option to withdraw from a municipality that refuses.
- **Gate Governance, Option Value and Stranded-Asset Exit Design:** Design each asset from the outset for redeployment, such as substations sized for an industrial cluster and fiber open to other users, so a cancelled campus leaves recoverable regional infrastructure.
