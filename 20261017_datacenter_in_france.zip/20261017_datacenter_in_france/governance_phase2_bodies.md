### 1. Project Steering Committee

**Rationale for Inclusion:** The 9 GW, 161 km², €750M Phase 0 budget is a strategic infrastructure venture with multi-billion euro Phase 1 exposure and extreme feasibility uncertainty. The sponsor, consortium co-investors, and debt/equity sources require a body that sets strategic direction, approves milestone decisions (topology, anchor-tenant strategy, permitting approach), and owns the Phase 0/Phase 1 FID recommendation. This committee harmonizes sponsor intent with co-investor expectations and coordinates responses to RTE, EDF, ANSSI and local authorities.

**Responsibilities:**

- Approve Phase 0 strategy, milestone roadmap and tranche-drawdown schedules within the EUR 750M cap
- Oversee topology decision at Month 4 (2027-02-17): single square vs. split campus
- Review and approve anchor-tenant sourcing strategy and lease-term frameworks
- Approve power-procurement strategy and EDF/RTE engagement approach
- Monitor co-investor alignment and resolve conflicts between sponsor and consortium expectations
- Recommend Phase 1 FID approval or deferral/downsizing at Month 12 (2027-10-17) gate

**Initial Setup Actions:**

- Establish committee charter at Month 1 (2026-11-17) defining roles, decision rules, and escalation protocol
- Assign sponsor CEO/CFO, infrastructure-fund lead, and at least one independent external director
- Set three-way decision rule: sponsor, consortium co-investor and independent director must all approve Phase 1 FID
- Publish committee composition and voting rules to lenders and equity sources by Month 1 (2026-11-17)
- Establish quarterly meeting cadence with standing agenda items: gate status, risk register, sunk-cost assessment
- Commission external red team to provide independent pass/fail opinions before each milestone vote

**Membership:**

- Sponsor hyperscale-developer CEO and CFO
- Infrastructure-fund consortium representative (capital and governance authority)
- Independent external director (infrastructure or energy sector, no financial ties to sponsor or consortium)
- Lender representative (observer, non-voting, to track debt covenants and Phase 1 financing triggers)
- Project Director (voting, operational accountability)

**Decision Rights:** The committee approves all strategic decisions above EUR 50M spend (Phase 0 tranches and gate recommendations), topology choice, tenant acquisition targets, power and grid strategies, and Phase 1 FID. Below EUR 50M operational decisions delegate to the PMO. The committee's Phase 1 FID recommendation is binding if supported by 2 of 3 core votes (sponsor, consortium, independent director); if split 1–2, the decision escalates to a supermajority vote of all members.

**Decision Mechanism:** Decisions by majority vote (3 of 5 members minimum), with sponsor, consortium and independent director each holding one bloc vote. Phase 1 FID requires explicit two-of-three alignment among sponsor, consortium and independent director. Tie-breaker: independent director casts the deciding vote; dissent recorded and published to lenders. Monthly red-team pass/fail opinions inform but do not override committee votes.

**Meeting Cadence:** Monthly (Months 0–12 = 2026-10-17 to 2027-10-17) for Phase 0, with standing agenda: gate-criterion status, tranche drawdown authorization, risk escalations, red-team findings, external-authority responses (RTE, DREAL, ANSSI, EDF). Ad-hoc meetings if a gate criterion is breached or sunk-cost pressure emerges.

**Typical Agenda Items:**

- RTE, EDF, ANSSI and DREAL engagement status (written evidence, preliminary opinions, timeline slippage)
- Land assembly and topology validation (% parcel optioned, Phase II survey findings, holdout issues)
- Anchor-tenant pipeline status (LOI vs. binding term-sheet progress, credit validation, reservation-fee timing)
- Phase 0 spend reconciliation and tranche-drawdown authorization (actual vs. budget, next-tranche triggers)
- Risk register update (grid, land, tenants, permitting, financing, social license) and mitigation actions
- Red-team independent pass/fail opinions and committee response or dissent

**Escalation Path:** Phase 1 FID recommendation (approve, defer, downsize or cancel) escalates to the sponsor board and consortium investment committee if the Steering Committee is split or if a gate threshold is unmet. Kill criteria for Phase 1 cancellation or downsizing are formally triggered by the Gate Review and Kill Authority Committee (see below); the Steering Committee must respect those triggers unless overridden by supermajority sponsor/consortium vote with documented dissent to lenders.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Phase 0 spans 12 months across grid, land, permitting, environmental, security, tenant and financing workstreams, with tight interdependencies and external milestones (RTE, DREAL, ANSSI). A dedicated PMO is essential to track parallel workstreams, manage deliverable timelines, reconcile Phase 0 spend against the EUR 750M cap, and escalate gate-critical risks. The PMO is operationally accountable for Phase 0 execution and reportable to the Steering Committee monthly.

**Responsibilities:**

- Manage Phase 0 workstreams: grid (RTE engagement), land (options, surveys), permitting (file prep), tenants (sourcing, term sheets), financing (lender criteria), security (ANSSI dialogue), community (liaison, consultation)
- Reconcile Phase 0 spend monthly against four milestone tranches (EUR 150M, 250M, 200M, 150M) and seek tranche authorization from the Steering Committee
- Track external-authority milestones (RTE letter, DREAL opinion, ANSSI confirmation, EDF LOI) and escalate slippages
- Execute Phase I/II environmental and contamination surveys, fiber audits, thermal modelling and RTE hosting-capacity audit
- Maintain risk register (23 identified risks plus emergent risks) and escalate high-likelihood, high-severity risks to the Steering Committee
- Coordinate Phase 0 deliverables: topology decision document (Month 4 = 2027-02-17), permitting file (Months 8–9 = 2027-06-17 to 2027-07-17), anchor-tenant term sheets (Month 9 = 2027-07-17), Phase 0 gate summary (Month 12 = 2027-10-17)

**Initial Setup Actions:**

- Establish PMO with at least 40–60 FTE core team (estimate) across grid, land, permitting, environmental, tenant and finance workstreams by Month 0 (2026-10-17)
- Commission specialist advisers: RTE hosting-capacity auditor, hydrologist, ecologist, ICPE counsel, land assembly, security liaison
- Establish regional offices in Cambrai and Dunkirk for land, permitting and community engagement
- Develop detailed Phase 0 workplan with weekly milestone tracking and monthly reporting to the Steering Committee
- Establish a risk-register review cadence (monthly) and escalation protocol to the Steering Committee for risks scoring above a threshold (e.g., High likelihood + High severity)
- Create a financial tracking system reconciling Phase 0 spend by workstream and tranche, with monthly variance reporting

**Membership:**

- Project Director (overall accountability)
- Grid and Power Lead (RTE engagement, hosting-capacity strategy, EDF coordination)
- Land Assembly Lead (parcel acquisition, option agreements, brownfield surveys)
- Permitting and Environmental Lead (ICPE, EIA, DREAL dialogue, ecological master plan)
- Tenant and Revenue Lead (anchor-tenant sourcing, term-sheet negotiation, lease economics)
- Finance and Lender Relations Lead (debt-financing criteria, Phase 0 drawdown management, cost reconciliation)
- Security and National-Security Lead (ANSSI/DGSI dialogue, security governance framework)
- Community and Stakeholder Lead (municipal liaison, public consultation, community-benefit agreement)
- PMO Controller (spend reconciliation, milestone tracking, variance analysis)

**Decision Rights:** PMO approves operational decisions within Phase 0 tranche budgets (EUR 50M monthly run-rate, estimate). Workstream leads make day-to-day procurement and engagement decisions. Decisions exceeding EUR 50M spend, involving strategic trade-offs (e.g., split-campus pivot, tenant-acquisition priority shift), or affecting gate milestones escalate to the Steering Committee. All external-authority responses (RTE, DREAL, ANSSI, EDF) are classified as gate-critical and immediately escalated if they change feasibility assumptions.

**Decision Mechanism:** PMO Lead (Project Director) approves sub-EUR 50M decisions by workstream-lead consensus. Decisions involving workstream conflicts (e.g., land-assembly cost vs. timeline, permitting file scope vs. environmental scope) are escalated to the Steering Committee. Monthly PMO leadership review (all leads) validates milestone status and flags risks. Red-team opinions are reviewed monthly and factored into decision rationale.

**Meeting Cadence:** Weekly internal PMO standup (all leads, 1 hour) to track workstream progress and remove blockers. Monthly PMO review with external advisers (grid auditor, environmental counsel, security liaison) to validate milestone deliverables. Monthly steering-committee report (formal presentation to the Steering Committee).

**Typical Agenda Items:**

- RTE, EDF, DREAL and ANSSI engagement milestones and timeline slippages (e.g., RTE letter due Month 6 = 2027-04-17, any delays flagged)
- Land assembly: % parcel optioned, Phase II survey progress, holdouts or legal challenges, remediation-liability findings
- Tenant pipeline: LOI vs. binding term-sheet conversions, credit validation, reservation-fee payment schedules
- Phase 0 spend reconciliation: actual vs. planned by tranche, next-tranche authorization request to Steering Committee
- Permitting file status: draft completion, content issues, filing date (targeted Months 8–9 = 2027-06-17 to 2027-07-17)
- Risk register: new risks, escalations, mitigation actions, red-team findings

**Escalation Path:** Gate-critical risks (e.g., RTE denial of 500 MW hosting capacity, inability to option 70% of parcel, no anchor tenants by Month 9 = 2027-07-17) escalate immediately to the Steering Committee and the Gate Review and Kill Authority Committee. PMO operational decisions involving workstream conflicts or cost trade-offs escalate to the Project Director, then to the Steering Committee if unresolved. External-authority responses that change feasibility assumptions trigger a formal gate-status review within 1 week.
### 3. Gate Review and Kill Authority Committee

**Rationale for Inclusion:** The plan explicitly states that kill criteria and downsizing are legitimate outcomes, and that sunk-cost pressure typically overrides stated gate thresholds unless kill authority is vested in a body independent of the development team. This committee is chartered to enforce numeric kill thresholds—grid hosting capacity ≥1 GW (cumulative), land assembly ≥70%, anchor-tenant take-or-pay ≥30% by Month 9 (2027-07-17), debt financing ≥EUR 3B, and social license (2 of 3 municipalities). If any threshold fails by the deadline, this committee triggers a formal gate review and recommends cancellation, downsizing, deferral or split-campus pivot, with decisions published to lenders and co-investors.

**Responsibilities:**

- Enforce numeric Phase 0 gate thresholds (grid ≥1 GW, land ≥70%, tenants ≥30% by Month 9 = 2027-07-17, debt ≥EUR 3B, social license ≥2 municipalities) at the Month 12 (2027-10-17) Phase 0 gate
- Review RTE preliminary feasibility letter (or lack thereof) at Month 6 (2027-04-17) and determine whether the grid gate is on track; if not in hand, assess split-campus viability
- Review Phase II environmental and Phase I ESA findings at Month 3 (2027-01-17) to validate land-assembly feasibility; if remediation costs exceed EUR 100M per site or contamination blocks parcels, recommend site substitution or split campus
- Review anchor-tenant pipeline at Month 9 (2027-07-17): quantify signed take-or-pay vs. LOI, credit validation, confirm ≥30% binding commitments; if <30%, trigger Phase 1 downsizing to 250–500 MW
- Publish monthly red-team audit opinions (independent consultants), documenting pass/fail on each gate criterion; dissent from development team opinions recorded and disclosed
- Recommend Phase 1 FID approval, conditional approval with specific conditions, deferral pending gate resolution, downsizing, or cancellation; recommendation is binding unless overridden by supermajority Steering Committee vote with dissent published

**Initial Setup Actions:**

- Charter the committee at Month 1 (2026-11-17) with composition: at least 2 independent external directors (no financial ties to sponsor or consortium), 1 lender representative, 1 infrastructure-sector expert
- Commission an independent red team (EUR 2M–5M) to deliver monthly pass/fail opinions on each of five gate criteria (grid, land, tenants, financing, social license) from Month 1 (2026-11-17) through Month 12 (2027-10-17)
- Fix numeric kill thresholds in writing by Month 2 (2026-12-17): grid ≥1 GW cumulative (or ≥500 MW single node + credible path to 1 GW), land ≥70% optioned at <15% above benchmark, tenants ≥30% (≥300 MW on 1 GW base, ≥150 MW on 500 MW base) signed by Month 9 (2027-07-17), debt ≥EUR 3B committed, social license ≥2 of 3 municipalities, all published to lenders
- Establish meeting and decision protocol: monthly red-team report review + quarterly gate-status assessment (Months 3, 6, 9, 12 = 2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17)
- Define escalation protocol: if any gate threshold is breached, committee has 10 working days to issue a formal gate-status report and recommendation; recommendation is binding on the Steering Committee unless overridden by supermajority vote (2 of 3: sponsor, consortium, independent director) with full dissent disclosure
- Appoint a dedicated chair (independent external director) with authority to call unscheduled gate reviews if red-team findings indicate threshold breach

**Membership:**

- Independent External Chair (infrastructure, energy or finance sector, no affiliation with sponsor, consortium or lenders; appointed by mutual consent of sponsor and consortium at Month 1 = 2026-11-17)
- Independent External Director 2 (technical or environmental expertise; project feasibility validation)
- Lender Representative (debt-financing criteria and Phase 1 FID conditions, non-voting but advisory input)
- Infrastructure-Sector Expert (independent adviser on grid, power and major-project feasibility; non-voting but provides technical opinion on RTE and EDF outcomes)
- External Red Team Lead (independent consultant, monthly pass/fail reports, no voting role but directly inputs to committee deliberation)

**Decision Rights:** The committee's scope is confined to gate-threshold validation and kill/downsize/defer recommendations. It does not approve strategy (delegated to Steering Committee) or direct operations (delegated to PMO). The committee's recommendations are binding on the Steering Committee unless the Steering Committee explicitly overrides by supermajority vote (2 of 3: sponsor, consortium, independent director) with recorded dissent and public disclosure to lenders within 5 working days. If the committee recommends cancellation and the Steering Committee overrides, the override decision and dissent are disclosed to all debt and equity sources.

**Decision Mechanism:** Consensus where possible. If disagreement arises on gate-threshold achievement (e.g., whether a preliminary RTE letter satisfies the grid gate or whether provisional anchors qualify as 'signed'), the committee documents both positions and escalates to the Steering Committee with a recommendation of which position is more credible. Tie-breaker: the independent chair casts the deciding opinion. Red-team pass/fail opinions are advisory input, not votes.

**Meeting Cadence:** Monthly gate-status review (1st working day of each month, Months 1–12 = 2026-11-17 to 2027-10-17) of red-team reports and PMO milestone updates. Formal gate-assessment meetings at Months 3, 6, 9 and 12 (2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17) to validate threshold achievement and issue gate-status reports to the Steering Committee and lenders.

**Typical Agenda Items:**

- Red-team monthly pass/fail opinion on each of five gate criteria: grid (RTE letter received? timing on track?), land (% optioned, remediation findings), tenants (LOI vs. binding breakdown, credit validation), financing (debt commitment status, pricing acceptable?), social license (municipal letters of support in hand?)
- External-authority milestone tracking: RTE letter (due Month 6 = 2027-04-17), DREAL opinion (due Month 9 = 2027-07-17), ANSSI confirmation (due Month 12 = 2027-10-17), EDF LOI (due Month 6 = 2027-04-17, term sheet Month 9 = 2027-07-17)
- Phase II environmental and contamination survey findings: any sites ruled out, remediation costs exceeding EUR 100M per site, holdout issues affecting ≥30% of target parcel
- Anchor-tenant term-sheet status: number of signed agreements, total MW, credit ratings, reservation-fee payment receipts; conversion of LOIs to binding documents
- Debt-financing status: lender interest, term-sheet negotiations, required gate achievements for debt final commitment
- Community-engagement and municipal-support status: liaison-committee minutes, consultation feedback, municipal letters of support in hand or on schedule

**Escalation Path:** If the committee determines that a gate threshold is breached (e.g., RTE letter not received by Month 6 = 2027-04-17, land optioning <70% by Month 4 = 2027-02-17, tenants <30% signed by Month 9 = 2027-07-17, debt commitment not in hand by Month 12 = 2027-10-17), the committee issues a formal gate-status report within 5 working days and recommends one of: (i) Phase 1 proceeds (all thresholds met), (ii) Phase 1 conditional approval pending specific condition (e.g., RTE letter expected by Month 18 = 2028-04-17), (iii) Phase 1 downsized (e.g., 250 MW instead of 500 MW if tenants <30%), (iv) Phase 1 deferred (6–12 months pending gate resolution), or (v) Phase 0 completion with no Phase 1 FID (project paused or cancelled). The Steering Committee may override the committee's recommendation by supermajority vote with full dissent recording and disclosure to lenders. If lenders or co-investors invoke debt covenants or capital-call conditions triggered by a failed gate, the Kill Authority Committee's recommendation is published to those parties within 2 working days of issue.
### 4. Compliance, Environmental & Social License Committee

**Rationale for Inclusion:** The project faces complex, interconnected constraints: ICPE and environmental authorization (18–30 months + 24–48 months appeal risk), ANSSI/DGSI national-security review (6–12 months, uncontrolled), GDPR and data-residency compliance (foreign co-investor, sovereign tenants, AI workloads), ecological compensation (net-biodiversity, farmland displacement of 10,000+ ha, estimated EUR 200M–500M cost), water-resource constraints (closed-loop cooling required, water-authority approval), brownfield remediation (legacy contamination EUR 0–100M+ per site, liability allocation disputes), and community social license (municipal support, farm-sector engagement, public consultation). No single person can credibly oversee all five domains (permitting, security, ecology, water, community). A dedicated committee ensures compliance risks do not fall between workstreams and that gate-critical environmental and social-license conditions are not overlooked in pursuit of schedule or cost targets.

**Responsibilities:**

- Oversee ICPE and environmental authorization process, including EIA scope, file content, DREAL engagement, permit conditions and post-permit compliance monitoring
- Manage national-security review (ANSSI, DGSI) including confidential security governance framework, tenant-vetting criteria, data-residency policies, and alignment with foreign-co-investor requirements
- Ensure GDPR compliance for data processing at multi-tenant data center; define data-residency and sovereignty requirements with legal counsel and authorities
- Implement ecological master plan (submitted Month 6 = 2027-04-17), manage biodiversity offsetting and compensation, coordinate with environmental NGOs and conservation authorities on net-biodiversity targets
- Manage water-resource compliance: secure written water-authority opinion on closed-loop cooling feasibility (due Month 6 = 2027-04-17), track permitting conditions tied to water use, monitor groundwater contamination from brownfield sites
- Oversee brownfield remediation and contamination liability: track Phase I/II ESA findings, bound liability per parcel, negotiate seller indemnities and public-remediation arrangements, escalate unexpected contamination discoveries
- Lead community engagement and social-license strategy: establish municipal liaison committee, run early voluntary consultation (Months 1–3 = 2026-11-17 to 2027-01-17), draft and negotiate community-benefit agreement (EUR 50M–150M, due Month 6 = 2027-04-17), track farm-sector and NGO opposition, escalate legal-challenge risk
- Coordinate integration of compliance requirements into Phase 1 permitting conditions and Phase 1 capex budget (e.g., ecological compensation cost, security hardening cost, community-benefit spend)

**Initial Setup Actions:**

- Charter the committee at Month 1 (2026-11-17) with roles: ICPE/Environmental Lead, National-Security and GDPR Counsel, Ecology and Biodiversity Manager, Water Resources Manager, Community and Stakeholder Lead
- Engage specialized counsel: ICPE expert, environmental and EIA counsel, ANSSI/security law specialist, GDPR and data-protection counsel, environmental NGO liaison, water-law specialist, land and remediation counsel
- Commission Phase I (desktop) environmental site assessments on all candidate parcels by Month 1 (2026-11-17)
- Commission Phase II intrusive surveys (soil, groundwater, asbestos) on top 2–3 sites per zone by Month 3 (2027-01-17), EST 1.5M–3M per zone
- Establish ICPE and environmental file content roadmap (Month 1 = 2026-11-17): identify required studies, expert reports, baseline data, modeling and conditions
- Initiate DREAL and prefecture pre-submission dialogue (Month 0–1 = 2026-10-17 to 2026-11-17): outline project scope, receive preliminary guidance on permit pathway, ICPE classification and fast-track status (if any)
- Establish confidential ANSSI pre-submission engagement (Month 0–1 = 2026-10-17 to 2026-11-17): present security governance framework, understand anticipated review scope, timeline and authorities' concerns
- Commission hydrological study and water-authority consultation (Months 1–4 = 2026-11-17 to 2027-02-17): validate closed-loop cooling feasibility, obtain water-authority preliminary opinion by Month 6 (2027-04-17)
- Establish municipal liaison committee (Month 2 = 2026-12-17): invite mayors and representatives from at least 3 most-affected municipalities; establish monthly dialogue protocol and published meeting minutes
- Develop draft community-benefit agreement (Months 2–4 = 2026-12-17 to 2027-02-17) covering labor, training, ecological restoration, farm relocation, and local infrastructure; bind terms by Month 6 (2027-04-17)

**Membership:**

- Compliance and Regulatory Lead (overall committee accountability, ICPE and permitting authority interface)
- National-Security and GDPR Counsel (ANSSI/DGSI liaison, security governance, data-residency requirements, foreign-co-investor compliance)
- Ecology and Biodiversity Manager (environmental baseline, EIA content, biodiversity offsetting, NGO coordination)
- Water Resources Manager (hydrological assessment, water-authority liaison, cooling-feasibility validation, groundwater contamination tracking)
- Community and Stakeholder Engagement Lead (municipal liaison, public consultation, community-benefit agreement, farm-sector engagement, opposition escalation)
- Brownfield and Remediation Counsel (Phase I/II ESA management, liability allocation, seller/public indemnities, contamination-discovery protocol)

**Decision Rights:** The committee advises the Steering Committee and PMO on compliance and social-license requirements, and makes day-to-day decisions on engagement with authorities, environmental consultants, municipalities and communities within the framework established by the Steering Committee. The committee has veto authority over permit-file content if it believes a proposed approach creates unacceptable legal or reputational risk; such vetoes escalate to the Steering Committee. Community-benefit agreement terms up to EUR 50M in Phase 0 pre-commitment are approved by the committee in consultation with the Steering Committee; terms above EUR 50M or with material operational implications escalate to the Steering Committee for approval.

**Decision Mechanism:** Decisions within the committee by consensus among the six leads. If disagreement arises (e.g., whether to pursue fast-track permitting vs. standard ICPE, whether to offer a municipal veto on certain design elements), the committee documents both positions and escalates to the Steering Committee or PMO for decision. Authority over community-benefit terms up to EUR 20M per tranche is delegated to the Stakeholder Lead in consultation with the Regulatory Lead; above EUR 20M, committee consensus is required.

**Meeting Cadence:** Bi-weekly workstream coordination (each lead with their specialists and external advisers) to track permitting, environmental, security and community milestones. Monthly full-committee meetings (all six leads) to integrate findings across domains and escalate material risks or changes to the Steering Committee. Ad-hoc meetings if authorities issue new guidance, legal challenges are filed, or community opposition escalates.

**Typical Agenda Items:**

- ICPE and environmental authorization: file-content draft status, expert reports completion timeline, DREAL feedback, permit-application date (targeted Months 8–9 = 2027-06-17 to 2027-07-17)
- National-security review: ANSSI pre-submission feedback (Month 6 = 2027-04-17 target), security governance framework refinement, tenant-vetting and data-residency policy drafting, anticipated formal-review start date
- Ecological master plan: EIA scope (habitat types, species surveys), biodiversity-impact model, compensation measures (on-site and off-site), NGO consultation feedback, DREAL opinion timeline (due Month 9 = 2027-07-17)
- Water and cooling: hydrological baseline findings, dry-cooler modelling at 35°C design day, water-authority preliminary opinion status (due Month 6 = 2027-04-17), any grounds for regulatory water-use restrictions
- Brownfield and contamination: Phase I ESA findings, Phase II survey progress, remediation-liability estimates per parcel, site-shortlist refinement, indemnity negotiations with sellers or public authorities
- Community engagement and social license: municipal liaison-committee meeting minutes (published), public consultation feedback, draft community-benefit agreement, farm-sector union engagement, opposition tracking and escalation
- Permit-check at Month 18 (2028-04-17): assessment of whether initial ICPE and EIA decisions are on schedule for approval by target window (Months 26–39 = 2028-12-17 to 2030-01-17); if slippage is material (>6 months), recommend Phase 1 FID contingency

**Escalation Path:** Material compliance risks (e.g., ANSSI blocks the project pending data-residency restructuring, DREAL requires additional ecological compensation exceeding EUR 300M, communities block permits, water authority denies cooling feasibility) escalate to the Steering Committee within 5 working days of identification. Contamination discoveries exceeding the bounded remediation threshold (EUR 100M per site) trigger immediate PMO and Steering Committee escalation. Legal challenges to permits that could extend timelines beyond Month 26 (2028-12-17) are escalated to gate-review assessment. ANSSI findings that restrict foreign tenants or co-investor involvement are escalated immediately to the Steering Committee, as they may affect tenant strategy and financing. Community opposition that reaches organized legal challenge or formal municipal objection escalates to the Steering Committee as a social-license gate threat.