## Suggestion 1 - Dunkirk industrial-port grid connection programme (Grand Port Maritime de Dunkerque / RTE, incl. data-centre and decarbonisation load requests)

The Dunkirk port zone is France's largest concentration of new high-voltage industrial load requests (steel decarbonisation, electrification, batteries, data-centre sites). RTE and the port have coordinated reinforcement of the 400 kV network and site allocation through ongoing planning. Scale is in the GW range; exact queue volumes are not verified. Ongoing since the early 2020s.

### Success Metrics

MW of connection requests processed by RTE (approximate, verify with RTE)
Land plots allocated by the port for industrial use
Time from request to energisation for first industrial users
Reinforcement scope agreed and cost-sharing terms

### Risks and Challenges Faced

Competing industrial loads saturating capacity: handled by RTE prioritisation and staged connection offers.
Land scarcity and Seveso zoning: handled by port-led plot planning.
Coastal ecology constraints: handled via EIA and compensation.

### Where to Find More Information

https://www.dunkerque-port.fr
https://www.rte-france.com (grid development plan, S3REnR and connection queue publications)
https://www.dunkerque-promotion.com

### Actionable Steps

Contact the Grand Port Maritime de Dunkerque business development / land department via the port website.
Approach RTE regional customer-connection office (Nord) through the RTE site contact form requesting a pre-engineering meeting.
Contact Dunkerque Promotion (economic development agency) for investor liaison.

### Rationale for Suggestion

Same region and same grid operator, and it tests the primary kill condition (hosting capacity above ~1 GW) directly. Shows how RTE sequences competing industrial loads. Primary suggestion.
## Suggestion 2 - Campus IA / Fluidstack France AI data-centre programme (national AI campus announcements, 2025 onward)

France's 2025 AI summit produced announcements of multi-GW AI campus plans on former industrial and brownfield sites, including a Fluidstack-led project targeting about 1 GW in the Paris region and sites identified by the State in a national list of data-centre-ready locations (including Hauts-de-France sites). Delivery status and figures are not verified; outcomes depend on RTE and permits.

### Success Metrics

MW connection offers obtained from RTE (verify)
Number of sites with permits filed or granted
Signed anchor tenants versus announced intent
Financing closed versus announced (not verified)

### Risks and Challenges Faced

Grid timing: sites chosen for existing RTE capacity and State-designated priority procedures.
Local opposition and land use: handled via public-interest designation and consultation, outcomes uncertain.
Tenant commitment versus announcement gap: a key lesson for LOI versus take-or-pay.

### Where to Find More Information

https://www.info.gouv.fr (State announcements on AI data-centre sites)
https://www.fluidstack.io
Business des Echos / Reuters coverage of French AI campus announcements

### Actionable Steps

Contact the Fluidstack France business development or press office via its website.
Contact Business France / the interministerial data-centre site programme (Ministry of Economy) for site-list access.
Ask the Direction Générale des Entreprises for the process on designated data-centre sites.

### Rationale for Suggestion

Closest French precedent for a GW-scale AI campus on industrial land with State involvement, the permitting route and the announcement-versus-contract gap. Primary suggestion; maturity is limited, so verify status first.
## Suggestion 3 - Ireland EirGrid / CRU data-centre connection policy (Dublin grid constraint)

Ireland's data centres consume a large share of national electricity (about a fifth, approximate). EirGrid imposed a de facto moratorium on new Dublin connections to 2028, then CRU issued a 2025 policy requiring on-site dispatchable generation or storage and flexibility from new data centres. Illustrates a grid operator conditioning capacity on flexibility.

### Success Metrics

Share of national demand taken by data centres (approximate)
Connection decisions granted under the new CRU policy
Flexibility/on-site generation obligations adopted
Local grid stability events avoided

### Risks and Challenges Faced

Grid saturation: handled by moratorium then conditional connections.
Political backlash on energy use: handled via policy requiring on-site supply.
Developer uncertainty: partly mitigated by clearer rules in 2025.

### Where to Find More Information

https://www.cru.ie (Large Energy Users connection policy decision)
https://www.eirgrid.ie
https://www.iea.org (Energy and AI report)

### Actionable Steps

Contact CRU's Large Energy Users policy team via the CRU website.
Approach EirGrid's customer connections team for lessons on flexible connection terms.
Speak to Irish Data Centre Association members through its website.

### Rationale for Suggestion

Geographically distant, but the best documented case of a grid operator capping and conditioning data-centre capacity. Informs curtailment (10% target, 15% walk-away) and BESS commitments. Primary suggestion.
## Suggestion 4 - Secondary: Nordic hyperscale and brownfield campuses (e.g., Google Hamina, Finland, former paper mill)

Google converted a former paper mill in Hamina, Finland into a data centre using seawater cooling, with later expansions. Shows brownfield industrial reuse, low-water-risk cooling and community integration. Fewer details; secondary suggestion. Scale is far below 9 GW.

### Success Metrics

Operational since 2011 with expansions (verify)
Heat-reuse or district-heating links announced in Finland (verify)
Local employment figures disclosed (small relative to capex)

### Risks and Challenges Faced

Reusing old industrial buildings and infrastructure.
Cooling water permitting handled with seawater and environmental review.

### Where to Find More Information

https://datacenters.google/locations/hamina-finland
Finnish Ministry of Economic Affairs publications

### Actionable Steps

Contact Google data centre community relations for Hamina via its locations page.
Contact Haminan Kotka Business Development agency for local lessons.

### Rationale for Suggestion

Secondary suggestion: northern climate and brownfield reuse parallel Hauts-de-France, but scale and grid context differ greatly.

## Summary

Reference projects for a gate-driven Phase 0 feasibility of a notional 9 GW, 161 km² AI campus in Hauts-de-France. Closest real analogues: the Dunkirk-area industrial-decarbonisation and data-centre grid-queue experience in the same RTE zone, the Fluidstack/Campus IA France programme and Cambrai-area announcements (status and figures not verified), and Nordic and Irish precedents on grid-constrained hyperscale growth. No known single-site 9 GW campus exists, and French geographic analogues are limited, so distant examples (Ireland, Norway) are justified for grid-flexibility and brownfield lessons. All grid, permit and tenant outcomes remain uncontrolled until signed. Figures below are approximate or unverified; confirm with the named organisations.