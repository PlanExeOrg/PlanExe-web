### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A 9 GW, 161 km² single-square campus in Hauts-de-France starts from a headline number and then hunts for a region to justify it, and the region's grid, land and permitting reality cannot be stretched to fit it.**

**Bottom Line:** REJECT: A fixed 9 GW / 161 km² square in Hauts-de-France is a number in search of a site, and the physical limits of grid, land and permitting are far smaller than the premise.


#### Reasons for Rejection

- The largest grid offer found for the Dunkirk area is a 21-hectare former refinery plot with a 400–700 MW RTE connection, so 161 km² (about 16,100 ha) is roughly 770 times that plot, and 9 GW is more than 12 times its top-end power (recomputed).
- Assembling a contiguous 12.7 km × 12.7 km square in the densely settled Nord/Pas-de-Calais basin means buying out farms, villages, roads, rail, pipelines and brownfield owners at once. Any one holdout breaks the geometry, and the Phase 0 budget of €250M–€750M with no committed capital cannot buy that option.
- 9 GW is larger than Gravelines, whose six reactors total about 5.4 GW, so the campus would draw more than the biggest nuclear plant on the same coast. 'Nuclear-backed contracts' only reallocate existing output, and national connection queues are already reported at roughly 11–18 GW of data-centre requests (sources disagree, not verified).
- The €100B–€140B+ build-out over 10–15+ years is priced against GPU/TPU generations that last 3–5 years, with the USD-denominated hardware share left to FX hedging, so most of the later tranches would finance hardware obsolescence rather than durable assets.
- The plan lists its own failure conditions (grid under ~1 GW, parcel not assembled, no anchor tenants, sustained opposition, unfinanceable). These are the normal outcome for a project this size, not tail risks. The 'reindustrialization narrative' justifies the location but does nothing for the physical constraints.
- Power density shows the square is arbitrary: at 14–30 m building heights the halls need a small fraction of 161 km², and the plan itself concedes most of the area is buffers, reserve and ecological zones, which makes the fixed footprint a branding choice, not a requirement.

#### Second-Order Effects

- 0–6 months: Land agents and option-takers in the Cambrai/Valenciennes/Dunkirk belt are spotted, local land prices and farmer expectations rise, and the project attracts opposition and press attention before any binding grid, tenant or permit position exists.
- 1–3 years: Phase 0 money has gone on options, studies and queue positions. RTE capacity goes to smaller, better-prepared applicants, and the sponsor is left with a 1 GW-class site at best while carrying the reputation of a 9 GW promise.
- 5–10 years: Regional politics are marked by an unbuilt mega-campus, and either stranded options and remediation liabilities remain, or a partial build is stuck with a hardware generation that is already obsolete and a grid reservation that crowded out steel, hydrogen and electrification users.

#### Evidence

- Case/Incident — Fluidstack–France 1 GW AI campus MoU (2025): the flagship French AI campus was announced at about 1 GW and €10B, so a 9 GW target here is nine times the largest announced national benchmark.
- Case/Incident — Ireland EirGrid/CRU Dublin data-centre connection restrictions (2021): a grid operator effectively halted new Dublin data-centre connections once demand outran the grid, which is the likely outcome for grid-limited sites.
- Law/Standard — Loi Climat et Résilience, zéro artificialisation nette (2021): France's ZAN target pushes against converting large areas of farmland and natural land, which is the core of assembling 161 km².



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Phantom Square: a 161 km² (12.7 km × 12.7 km), 9 GW campus in Hauts-de-France is sized by a map-drawing exercise, not by any grid, land or demand fact, and the region's own largest announced data-center plans (about 0.4–1 GW on plots of tens to hundreds of hectares) show the square is roughly an order of magnitude beyond anything the territory has shown it can host.**

**Bottom Line:** REJECT: The Phantom Square is a shape in search of a justification, with a 9 GW claim on a grid, a land base and a community that have shown no capacity or consent for it. A project that starts from the biggest possible map and works backward to its reasons does not deserve to exist.


#### Reasons for Rejection

- Assembling 16,100 hectares (recomputed) means forcing farmland, homes and working industrial plots into one contiguous square, and the people on that land never asked to become raw material for a compute shape drawn on a map.
- The plan hangs on RTE, EDF, prefectural, security-service and tenant decisions that nobody has granted, so the whole thing depends on outside authorities whose answers are unknown and who sit outside the sponsor's control.
- Nine gigawatts running continuously draws about 79 TWh a year (recomputed), a large slice of national electricity use (national total not verified), so the first copycat claim in the connection queue would crowd out every other factory, port electrification and household in the region, and a footprint that large cannot be undone once farmland is paved and substations are fixed in place.
- The value case is hubris stacked on rent-seeking: the region's reindustrialization story is borrowed to justify a land grab, while GPU demand over 10–15 years, hardware that turns over every few years, and unproven anchor tenants are treated as certainties to underwrite €100B–€140B+ (user estimate, unvalidated).

#### Second-Order Effects

- **Months 0–6 (2026-10-17 to 2027-04-17) — The Cracks Appear:** Land-option inquiries across the Cambrai, Valenciennes and Dunkirk belts leak, farmland and industrial-plot prices jump, and local mayors and farm unions harden against a project nobody has formally authorized.
- **Months 12–36 (2027-10-17 to 2029-10-17) — Copycats Arrive:** Rival developers file competing oversized grid-connection requests to hold queue positions, which inflates reported demand and delays real, smaller industrial customers.
- **Months 60–96 (2031-10-17 to 2034-10-17) — Norms Degrade:** Each failed mega-announcement teaches regional authorities and communities to treat every data-center pledge as speculation, so legitimate reindustrialization projects face the same distrust.
- **Months 120+ — The Reckoning:** If any part is built and the AI demand case weakens, the region is left with stranded substations, partially paved land and public commitments to workers and communities that no tenant is left to pay.

#### Evidence

- Case/Report — Dunkirk port authority call for interest (reported by DatacenterDynamics, https://datacenterdynamics.com/en/news/700mw-data-center-could-be-built-at-port-of-dunkirk-northern-france/): a 21-hectare former refinery plot offered with a 400–700 MW RTE connection, supplied by a substation about 3 km away that was still under construction; the 161 km² square is about 770 times that plot (recomputed).
- Case/Report — Brookfield/Data4 plan for Cambrai (reported by Le Journal des Entreprises and others): about 1 GW and €10B, next to the roughly 320-hectare E-Valley logistics park on the former BA 103 air base; the square would be about 50 times the entire E-Valley park (recomputed), and the largest plan already in the region is one ninth of the 9 GW target.
- Law/Standard — RTE rule since 1 August 2025, reported by Orrick (https://www.orrick.com/zh-CN/Insights/2026/09/Grid-connection-of-data-centers-in-France): reserved connection capacity can be cut if actual use falls short of what was subscribed, and in saturated areas a place in the connection queue is a precondition; a 9 GW reservation that the project cannot show it will use is exactly what this rule targets (queue size of about 11 GW from a secondary source, not verified).
- Law/Standard — Loi Climat et Résilience (2021), France's zero net land-take trajectory (net zero artificialisation by 2050): a roughly 16,100-hectare conversion runs directly against the national land-take trajectory (exact regional quotas not verified).



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A 9 GW, 161 km² campus in one of France's densest industrial regions rests on land, grid and tenant approvals nobody has granted, while the plan secretly grades itself on a fixed footprint it admits is notional.**

**Bottom Line:** REJECT: A 9 GW, 161 km² campus in Hauts-de-France depends on land, wires, water and tenants that no authority has promised, so it should not receive even Phase 0 capital as framed.


#### Reasons for Rejection

- Land: a 12.7 km × 12.7 km square (recomputed: about 161 km², roughly 39,900 acres) would need continuous control of farms, villages, roads and brownfield in a densely settled region, and one holdout parcel, one commune or one protected habitat breaks the geometry, which is why the plan's own phrase 'fixed notional footprint' contradicts its instruction to 'stress-test' it.
- Grid: 9 GW running flat out draws about 79 TWh a year (recomputed: 9 × 8,760 h), roughly one-sixth of national consumption (estimate), and the plan simply assumes RTE and EDF will serve it, though no connection offer exists and every milestone resting on them is uncontrolled.
- Competition for the same wires: Hauts-de-France is already reported to hold a rival 3.1 GW, €45B AI build-out across Dunkirk, Bosquel and Bouchain (press-reported, not verified), so this project would queue behind a better-capitalised claimant for the same substations and nuclear-backed supply.
- Budget logic: €5B–€10B for 0.5–1 GW and €100B–€140B+ for 9 GW (user constraints) imply about €11B–€16B per GW (recomputed), a range that must also absorb land, remediation, grid and community payments, and USD-priced accelerators that move with the euro-dollar rate, so the headline number is a guess dressed as a model.
- Demand and legitimacy: Phase 2 FID hinges on take-or-pay commitments for only 30–50% of the next tranche, yet no creditworthy anchor tenant is named, and a project this large asks a regional population to host a closed, security-hardened perimeter for a product they mostly cannot use, with few permanent jobs per square kilometre (estimate).

#### Second-Order Effects

- 0–6 months: Phase 0 option fees and legal work (user range €250M–€750M) begin land assembly; the first leaked parcel map triggers speculation, price spikes among farm and brownfield owners, and organised opposition from municipalities and agricultural groups before any technical study is complete.
- 1–3 years: Grid-queue slots and brownfield sites are held on speculative paper while no anchor tenant signs; competing projects and local industrial users are delayed, regional officials grow wary, and sponsor financing talks stall on missing offtake.
- 5–10 years: The project ends either as stranded options and a contested, partly cleared site, or as a single oversized grid commitment whose hardware ages out before tenants fill it, leaving the region with scarred land, stalled industrial plans and the political cost of a failed promise.

#### Evidence

- Law/Standard — Loi n° 2021-1104 Climat et Résilience (2021): sets the national goal of zero net land artificialisation by 2050 with a first 2021–2031 reduction period, directly constraining conversion of farmland to a 161 km² industrial footprint.
- Report/Guidance — RTE grid-connection queue (reported 2026): over 200 industrial projects totalling about 33 GW of new demand are awaiting high-voltage connection nationally, so a 9 GW claim competes for scarce capacity (figure from secondary summaries, primary not verified).
- Case/Incident — SoftBank France AI data-centre announcement at Choose France (2026): reported €45B, 3.1 GW first phase in Hauts-de-France (Dunkirk/Loon-Plage, Bosquel, Bouchain), showing the same region's grid and sites are already contested (press-reported, not verified against primary).



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**Strategic Flaw: the premise fixes a 12.7 km × 12.7 km (≈161 km²), 9 GW monolith as the reference case and then builds a "skeptical" plan around it. The plan therefore benchmarks a fantasy, not a market. Its binding constraints are the scarce RTE connection queue, a hyperscale tenant base that has never contracted at this scale in Europe, and French land and permitting law. None of these can be solved by sponsor capital, and every one is uncontrolled.**

**Bottom Line:** Abandon the 9 GW / 161 km² single-square premise entirely. It is not a stress-testable hypothesis but an unbuildable form that exists only to anchor an impossible headline number, and the one thing it cannot survive is France's actual grid-allocation reality of roughly 0.7–1 GW per site. If any version has merit, it is a much smaller, tenant-led, grid-confirmed project that this premise explicitly prevents by sizing everything to the headline first.


#### Reasons for Rejection

- The Phantom Square Fallacy: a contiguous 161 km² parcel is larger than Paris intra-muros (~105 km², general knowledge). In Hauts-de-France, brownfield sites are fragmented tens- to low-hundreds-of-hectares plots. The Escaudain site named in French state communications is reported at ~38 ha (0.38 km²), so the square is ~400× larger (recomputed; the 38 ha figure is from search snippets, not confirmed). Assembling it would mean expropriating or buying out farmland and villages, which collides with the zéro artificialisation nette (ZAN) land-take rules and with agricultural displacement. The 'single square' is not stress-testable because no real-world land market contains it. The split-campus model is therefore not an alternative to evaluate but the only physically possible form, and the 9 GW single-site case should have been dropped on day one.
- The 9-GW Queue Mirage: the French state's own fast-track process asked RTE to pre-reserve ~700 MW per site, and ~1 GW for Bosquel. Those reservations ran 9 months, extendable by 3, from 20 May 2025 (next.ink report, not independently confirmed). The same reporting puts national demand sought at 28.6 GW against 5.8 GW secured with connection commitments. A 9 GW request is roughly 9–13 times the largest site-level allocation in the national program and ~30% of all demand currently seeking connection. It would also be ~60+ TWh/yr at plausible load factors (estimate), on the order of >10% of French consumption (estimate). No honest Phase 0 can produce an RTE commitment of that size. Even 1 GW at Phase 1 competes with Data4 (Cambrai/Escaudain), Dunkirk and Bosquel-type projects for the same regional 400 kV and 225 kV capacity. Every grid milestone is uncontrolled, and the plan pays €250–750M to find that out.
- The Tenant Hallucination: 9 GW needs anchor tenants who sign take-or-pay for multi-GW blocks in a single French region. The Fluidstack MoU of 1 GW / €10B (Feb 2025) is still a memorandum, not operating capacity. The gate of 30–50% pre-commitment on the next tranche is sensible, but it demonstrates the problem: Phase 1 itself (€5–10B) is financed on speculation, because no tenant is named, no term sheet exists, and demand for AI compute is cyclical and concentrated in a handful of buyers whose capex plans change quarterly. Stranded-asset risk is existential: a campus built on GPU-generation economics (3–5 year hardware cycles) cannot rely on a 15-year build-out thesis.
- The Sponsor-Appetite Trap: 'high exploratory risk appetite' with 'no committed capital until the gate' means the €250–750M Phase 0 is sunk money chasing decisions the sponsor cannot influence (RTE, préfet, DREAL, communes, ANSSI/defense reviews, a hyperscale buyer). Because the infrastructure-fund and 'sovereign-adjacent' co-investors are discussions, not term sheets, the financing credibility check is circular: lenders want tenants, tenants want power, RTE wants proof of financing and tenants, and nobody moves first. The plan's own failure list (grid >1 GW, parcel, tenants, opposition, financing, environmental limits) is a list of single points of failure, any one of which kills the project, so the overall probability is the product of six uncertain events, not the best of them.
- The Cumulative-Impact Blind Spot: nine gigawatts of liquid-cooled compute means heat rejection of roughly the same order (multi-GW thermal), water or dry-cooler footprints, 400 kV lines, BESS and generator fields, fiber trenching and thousands of construction workers in a region already absorbing gigafactory, steel-decarbonization and Dunkirk industrial electrification demand on the same grid. 'Zero-water' dry cooling raises PUE and electricity draw, trading water risk for grid risk. Heat reuse is pitched as a benefit, but district-heating demand in the Valenciennes/Dunkirk area cannot absorb a 9 GW thermal source; that figure would only ever be a rounding error against the heat available. Environmental, biodiversity, flood and noise reviews for a 161 km² footprint are unlikely to clear in the framing of a single project, and the 'brownfield redevelopment' narrative collapses once the farmland is counted.

#### Second-Order Effects

- Within Months 0–6 (2026-10-17 to 2027-04-17): Phase 0 consultants, land agents and legal teams spend a large share of the €250–750M budget on option agreements and grid studies. Rumor of a 161 km² acquisition triggers speculative price inflation among landowners, SAFER pre-emption (rural land agency) disputes and farmer-union mobilization. Local authorities and the préfecture see a footprint that fits no existing zoning and refuse to confer anything beyond informal goodwill, which cannot be booked as a milestone.
- Months 6–18 (2027-04-17 to 2028-04-17): RTE and the State will most probably treat the request as a placeholder with no standing next to the sites already holding reservations. The sponsor gets capacity-study answers in the 100s-of-MW-to-~1 GW range, not 9 GW, with long lead times for substations and 400 kV reinforcement (estimate; multi-year). The project is forced into the split-campus it should have started with, but after fixed costs, public announcements and community expectations have already hardened. Competing developers at Cambrai/Escaudain and Dunkirk use the sponsor's visibility to lobby for their own allocations.
- Years 1.5–3: Opposition coalesces around land take, water, electricity prices for households and SMEs, and the sense of a sovereign-tech showcase imposed from Paris. Legal challenges (recours contentieux) against ICPE/environmental authorizations and urban-planning changes lengthen schedules by years. Without signed tenants, lenders and the infrastructure-fund consortium delay the Phase 1 FID. Each month of delay raises interest carry on land and grid deposits and exposes the USD-denominated chip procurement to FX swings that cannot be hedged against an uncertain delivery date.
- Years 3–6: If Phase 1 is built on a speculative basis, 500 MW–1 GW of halls sit partially empty during a GPU-demand downturn or a hardware generation change, producing impairment and covenant stress. If tenants do sign, they hold the sponsor to aggressive energization dates that RTE does not control, triggering penalties. Politically, the project becomes a visible symbol of overpromise in a region with a long memory of industrial promises that failed to deliver (steel, mining, auto), hardening the opposition against any future reindustrialization project, including legitimate ones.
- Years 6–10: Residual assets are a stranded 1 GW-class grid connection and shell buildings that smaller regional operators (Data4-type) could have used from the start. The 9 GW target is quietly retired, leaving the region with partial reinforcement works, remediation promises unfunded, and a trust deficit among elected officials who staked their reputations on the 'E-Valley AI belt' narrative.

#### Evidence

- France's own national data-centre process shows the realistic scale. The State identified ~26 secured sites, with five 'fast-track' projects of at least 700 MW. RTE was asked to pre-reserve ~700 MW per site and 1 GW for Bosquel, with reservations lasting 9 months (extendable) from 20 May 2025. Reported national demand: 28.6 GW sought, 5.8 GW secured; RTE counted nearly 80 projects holding ~18 GW of reservations by May 2026 (reported; not independently confirmed). Source: https://next.ink/222076/datacenters-en-france-26-sites-securises-dont-5-projets-fast-track-dau-moins-700-mw/. The largest single allocation is about one-ninth of the proposed 9 GW.
- Regional precedent at human scale: Data4 is reported as developing a ~1 GW campus on the former Cambrai air base and, at Escaudain/Denain, a project of about €5bn on a former steelworks site of ~38 ha (reported; status of grid connection not confirmed). See https://www.datacenterdynamics.com/en/news/data4-chosen-for-5bn-data-center-project-at-former-steelworks-site-in-northern-france/. These are the actual shapes of reindustrialization in the region: tens to hundreds of hectares, with 1 GW as the ceiling, not 161 km².
- Announcement-versus-reality: Fluidstack signed an MoU with the French government at the February 2025 Paris AI Action Summit for up to 1 GW of AI compute with an initial €10bn, and RTE is cited as a connection partner (https://www.fluidstack.io/post/1gw-ai-supercomputer-france). The project remains an MoU, with no confirmed operating capacity found. If a 1 GW, €10bn flagship at the center of a presidential summit is still pre-contract, a 9 GW, €100–140bn+ project with no named tenant cannot be assumed bankable.
- Analogy of the overpromised megaproject: the Foxconn Wisconsin 'Wisconn Valley' announcement (2017) promised a multibillion-dollar campus and thousands of jobs on a huge, assembled site, and delivered a small fraction (widely reported; exact figures not verified here). It shows how an anchor-less, headline-driven megaproject sold on a public narrative ends with unused land, unmet commitments and local distrust. There is no direct precedent for a 9 GW single campus anywhere in Europe, so the plan is dangerously unprecedented in its specific scale.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Geometry Before Grid: The plan fixes a 12.7 km × 12.7 km square and a 9 GW number first, then asks whether power, land, water and consent exist to fill it. The answer to that question can only be no, and the premise treats the veto holders (grid, farmland, communities, the state) as inputs to be 'validated' rather than as the real owners of the outcome.**

**Bottom Line:** REJECT: A fixed 161 km² square and a 9 GW end-state, chosen before the grid, land, water and consent have agreed to either, is a premise that cannot be defended, and the gate is closed.


#### Reasons for Rejection

- Rights and dignity: Assembling about 161 km² (recomputed: 12.7 × 12.7 = 161.3 km²) of contiguous land in a densely settled, farmed, post-mining region means displacing farmers, residents and villages for a private compute asset, and an 'industrial redevelopment' story cannot honestly cover a footprint of that size.
- Accountability and oversight: Every make-or-break element (RTE hosting capacity, EDF-backed supply, national-security review, prefectural permits, tenant take-or-pay) sits with an authority or counterparty outside the sponsor's control. A fund consortium with sovereign-adjacent co-investors leaves nobody clearly answerable to the public if the project stalls, is downsized or is abandoned halfway through construction.
- Systemic risk and scale: 9 GW is roughly 79 TWh a year at full load (recomputed: 9 GW × 8,760 h), about 5–6 EPR-class reactors' worth of output (estimate), and about 1.7 times the 5.4 GW of the six-unit Gravelines nuclear plant in this same region. Concentrating that load in one region creates a single point of failure for the grid, for fiber and for sabotage, and any shortfall in supply, cooling or security hits every tenant at once.
- Value-proposition rot: The project sells 'reindustrialization', 'sovereign AI' and a better public story than a rural greenfield. Data halls employ few people per euro invested, GPU/TPU assets depreciate in a few years against EUR 100B–140B+ of fixed civil and grid works, and the 'brownfield' label hides the fact that no brownfield of this size is contiguous. The 9 GW figure works as a headline for fundraising and for the state, not as a demand-backed commitment.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Land-search and option-agreement activity in Months 0–6 (2026-10-17 to 2027-04-17) leaks to local farmers, notaries and SAFER, the agency that oversees rural land sales. Option prices rise, holdouts organize, and mayors learn about a '40,000-acre' project from the press rather than from the sponsor. RTE queue discussions show that hosting capacity is offered in hundreds of MW per site, not in GW across a square.
- T+1–3 years — Copycats Arrive (Months 12–36 = 2027-10-17 to 2029-10-17): Rival developers and other regions announce gigawatt campuses. They compete for the same transmission reinforcements, EDF-backed supply, turbines, transformers and skilled electricians. Local politicians learn that 'AI campus' announcements cost nothing, and a sponsor with a visibly unreachable target loses credibility with every counterparty.
- T+5–10 years — Norms Degrade (Months 60–120 = 2031-10-17 to 2036-10-17): Partial build-out leaves stranded substations, half-empty halls and unfinished public-benefit commitments. Regulators then loosen land-use, water and grid-priority rules to keep the stalled project alive. Priority access for large loads over households and industry becomes an expected feature of 'strategic' projects, and consultation turns into a formality.
- T+10+ years — The Reckoning (Months 120+): GPU generations have been replaced several times. The region is left with oversized fenced-off land, remediation liabilities, grid assets paid for by ratepayers and a reputation for megaproject promises that did not deliver. The next real reindustrialization project, with credible jobs and a smaller footprint, faces a hostile and exhausted public.

#### Evidence

- Case/Report — Dunkirk port site and SoftBank announcement (secondary trade-press sources, not independently verified): The Port of Dunkirk tendered a roughly 21-hectare former refinery plot with an RTE connection of 400–700 MW, available three to four years after a connection agreement is signed. SoftBank's reported plan is €75B for 5 GW in France, with a first phase of about 3.1 GW across three Hauts-de-France sites. Real sites are measured in tens of hectares and hundreds of MW, and even the largest announced programme is well below 9 GW and is split across sites.
- Case/Report — Campus IA at Fouju (MGX, Bpifrance, Mistral AI, Nvidia): Announced in May 2025 as Europe's largest AI campus at about 1.4 GW (secondary sources; reported investment figures differ by source). Its first phase is reported at under 200 MW, with a reported operating target of 2028. The largest French precedent therefore scales in phases of tens to low hundreds of MW, at roughly one-sixth of this plan's endpoint.
- Law/Standard — Loi Climat et Résilience (2021), 'Zéro Artificialisation Nette' (ZAN): France committed to cutting land take by half in the 2021–2031 decade and to net zero by 2050. A 161 km² conversion of agricultural and natural land runs against this trajectory. The detailed ZAN rules have been under political revision (current state not verified), but the direction is not in doubt.
- Narrative — Front-Page Test: 'Fund-backed developer's 40,000-acre AI city is cutting through northern French farmland while villagers wait for jobs, and the grid operator says the power is not there.' Once that headline runs, the sponsor, the prefect and the co-investing state entities are all stuck defending a number that nobody can deliver.