# Purpose
and

# Domain
# Primary Domain: Data Center Development

## Rationale

Data Center Development is the outcome-role. Power Grid Engineering, Environmental Permitting, Land Assembly and Energy Procurement are constraints or methods subordinate to it.

# Secondary Domains

- Power Grid Engineering
- Infrastructure Finance
- Environmental Permitting

# Disciplines

## Data Center Development

- Importance: 5
- Specificity: 5
- Role: outcome
- Reason: Hyperscale AI campus feasibility, phasing, land use, and buildout are the core deliverable.

## Power Grid Engineering

- Importance: 5
- Specificity: 5
- Role: constraint
- Reason: 9 GW grid hosting capacity, RTE substations, and transmission upgrades are the blocking constraint.

## Environmental Permitting

- Importance: 5
- Specificity: 4
- Role: constraint
- Reason: French ICPE, environmental authorization, water, and biodiversity permitting gate a 161 km² campus.

## Land Assembly

- Importance: 5
- Specificity: 4
- Role: method
- Reason: Assembling 161 km² of brownfield and agricultural parcels is a core feasibility test.

## Data Center Cooling

- Importance: 4
- Specificity: 5
- Role: method
- Reason: Direct-to-chip liquid, low-water cooling and heat reuse determine PUE and water risk.

## Energy Procurement

- Importance: 5
- Specificity: 4
- Role: method
- Reason: Nuclear-backed contracts, PPAs and price risk determine 9 GW viability and cost.

## Infrastructure Finance

- Importance: 4
- Specificity: 4
- Role: method
- Reason: Phased multi-billion EUR financing, USD hardware FX exposure, and tenant-backed FID gates.

## National Security Review

- Importance: 4
- Specificity: 4
- Role: constraint
- Reason: DGSI/ANSSI review, foreign-investment screening and sovereign compute partitions can block or shape the campus.

## Community Engagement

- Importance: 4
- Specificity: 4
- Role: stakeholder
- Reason: Social license, public opposition and benefit agreements can derail permitting and land assembly.


# Plan Type
# Physical Location Requirement

This plan requires one or more physical locations and cannot be executed digitally.

## Explanation

The plan is a feasibility study and phased development plan for a 9 GW, 161 km² hyperscale AI data center campus in Hauts-de-France, France. Nearly every workstream depends on real-world locations, construction and on-site activity:

- Land assembly: assembling 161 km² across Cambrai/E-Valley, Valenciennes/Denain/Escaudain, Dunkirk and Saint-Omer requires site visits, parcel surveys, negotiations with landowners and farmers, and brownfield investigation and remediation.
- Environmental baselines: ecology, hydrology, soil contamination and water-system studies must be measured in the field.
- Grid and power: RTE and EDF engagement leads to dedicated substations, transmission upgrades, BESS and limited backup generation.
- Construction: 50-100+ data halls, liquid-cooling loops, an optional 50-100 MW immersion pilot, heat-reuse infrastructure, roads and logistics, and stormwater works require construction labor, heavy equipment and materials.
- Hardware: GPU/TPU and networking hardware must be procured, shipped, installed and tested in physical halls.
- Connectivity: diverse fiber to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea routes requires trenching, route surveys and physical interconnection.
- Security: hardened perimeter, anti-drone systems and sabotage resilience are on-site measures; national-security and permitting reviews involve in-person processes with prefectural and state authorities.
- People: community engagement, public consultation, workforce training programs and stakeholder meetings happen in person; tenant validation involves site tours and negotiations.
- Workspace: the action plan needs project offices and physical travel in the region.

Financial modeling, document drafting and tenant analysis are supporting activities. The plan's outcome is a physical campus or a physical decision about land, grid and communities. Physical activity benefits every major part of the plan.

# Physical Locations
# Requirements for physical locations

- Grid access: nearby 400 kV RTE lines and room for dedicated substations; hosting capacity above ~1 GW is the primary kill test and is uncontrolled until RTE signs a connection offer
- Large assemblable parcels (brownfield or industrial preferred) with limited holdouts; 161 km² contiguous assembly is doubtful (not verified)
- Low water stress; dry or closed-loop cooling feasible with no evaporative water
- Bounded brownfield contamination (soil, groundwater, munitions, slag) via surveys and indemnities
- Diverse fiber routes to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea landings, with audited duct-level diversity
- Proximity to district heating or industrial heat users (heat reuse treated as unpriced upside)
- Zoning and permit compatibility (ICPE, environmental authorization); manageable community and farmland opposition
- Road, rail, canal and port access for heavy equipment and logistics
- Security setbacks and defensible perimeter; national-security review feasibility
- Skilled trades availability (electrical, mechanical, cooling) and housing capacity
- Low-latency links between nodes if a split-campus model is adopted

## Location 1: Cambrai / E-Valley, Nord department

Former Cambrai-Épinoy airbase surroundings and E-Valley redevelopment zone plus adjacent agricultural land.

## Rationale

Best candidate for a primary node with the largest contiguous parcels. Farmland displacement, 400 kV capacity and a single contiguous 161 km² remain unproven. Suited to Phase 1 (500 MW–1 GW) as a reversible option.

## Location 2: Dunkirk industrial-port area, Nord department

Grand Port Maritime de Dunkerque industrial zones, heavy-industry brownfield and port land.

## Rationale

Heavy-industry and port hub with existing high-voltage infrastructure, nearby nuclear generation at Gravelines, and subsea and UK connectivity potential. Candidate for a split-campus node. Constraints: land scarcity, Seveso and industrial-risk zoning, competition for grid capacity from industrial decarbonization projects, and coastal ecology.

## Location 3: Valenciennes / Denain / Escaudain, Nord department

Former steel and coal brownfield sites around Denain and Escaudain, Valenciennes industrial zones.

## Rationale

Brownfield redevelopment narrative, existing rail, canal and road access, and proximity to Brussels and Paris. A second or third split-campus node, with reuse of industrial land and a fiber ring to Cambrai. Main risks are contamination, fragmented ownership and a dense population requiring a community buffer.

## Location 4: Saint-Omer area, Pas-de-Calais

Industrial and logistics zones around Saint-Omer, near canal and A26 corridors.

## Rationale

Named satellite option for smaller inference or sovereign nodes. Proximity to the UK and Channel fiber routes and lower land pressure in places. Constraints: water-sensitive wetlands (Marais Audomarois), smaller parcels and limited grid capacity (not verified).

## Location Summary

The plan is tied to Hauts-de-France. Cambrai / E-Valley is the leading candidate for a primary node. Dunkirk and Valenciennes / Denain / Escaudain are candidate split-campus nodes. Saint-Omer is a possible satellite. Each site is hypothetical until grid, land, water, permit and tenant evidence exists. The single 12.7 km square is to be stress-tested against a split model, and downsizing or cancellation remain legitimate outcomes.

# Currency Strategy
and

# Identify Risks
# Risk Register: 9 GW Hyperscale AI Campus, Hauts-de-France

## Risk 1 – Regulatory & Permitting

RTE grid hosting capacity above ~1 GW is the primary kill condition. Hauts-de-France grid infrastructure may not support multi-GW connection without major reinforcement. Queue position, transmission-reinforcement timelines, and RTE's willingness to offer multi-tranche contractual commitments remain uncontrolled until RTE signs a formal connection offer. Early at-risk studies and substation pre-engineering consume capital but guarantee no available capacity. Competing industrial decarbonization projects may saturate capacity.

### Impact

RTE offer of less than ~500 MW–1 GW in the first tranche, or reinforcement timelines stretching beyond 3–4 years, fails the core feasibility gate. Delay of 12–24 months to secure connection offers. Cost overruns of €500M–€1.5B if the developer must co-fund transmission reinforcement. Loss of grid queue position to competing users renders the site unfeasible.

### Likelihood
High

### Severity
High

### Action

Initiate formal pre-engineering dialogue with RTE and DREAL in Month 0 (2026-10-17), no later than Month 1 (2026-11-17). Commission an independent RTE hosting-capacity assessment identifying specific 400 kV substation locations, reinforcement scope, timeline to energization and cost allocation. Request RTE's formal technical opinion on phased tranches (500 MW, 1 GW, 2 GW) and turnaround times. Define 'adequate hosting capacity' as a firm RTE estimate of at least 1 GW available connection within 36 months; if RTE cannot commit, trigger the kill gate immediately. Map competing industrial load requests to identify saturation risk. Structure the Phase 0 gate to require a signed RTE connection-offer letter or equivalent binding commitment for at least 500 MW before Phase 1 FID.

## Risk 2 – Land Assembly & Rights

Assembling 161 km² contiguously or as a coherent semi-contiguous cluster across Cambrai, E-Valley, Valenciennes, Dunkirk and Saint-Omer faces fragmentation, farmland-ownership resistance, holdouts and administrative complexity. The plan explicitly notes that 161 km² contiguous assembly is doubtful (not verified). Voluntary parcel-by-parcel purchase gives holdouts leverage and can render the single-square footprint infeasible, forcing costly pivots to a split-campus model or smaller buildout. Compulsory acquisition via public-interest designation is faster but uncontrolled until a formal State decision exists and invites legal challenge.

### Impact

Inability to assemble adequate parcel: project may fail to proceed beyond Phase 0 or be forced to downsize to <500 MW. Pivot to fragmented split-campus model with higher complexity, latency and per-MW cost. Land acquisition delays: 6–18 months for voluntary assembly; legal action could extend timelines by 12–36 months. Estimated cost overrun of €100M–€400M if forced to pay above-market premiums or pay legal defense costs.

### Likelihood
High

### Severity
High

### Action

Conduct parcel-level option surveys during Phase 0 (Months 0–3 = 2026-10-17 to 2027-01-17) across all four zones, focusing on fragmentation, public vs. private ownership, and known holdout or activist groups. Engage municipal and prefectural land registries to map ownership chains. Develop a parallel split-campus topology that is technically and economically viable at 2–3 separate nodes of 250–500 MW each. Structure Phase 0 land-assembly spend as a capped, milestone-based tranche with a decision point at Month 3 (2027-01-17): proceed with contiguous options only if ≥70% of target parcel can be optioned non-coercively at within 15% of benchmark land values; otherwise pivot to split campus. Engage farmers' unions in Month 1 (2026-11-17) to signal long-term land-use and revenue-sharing options.

## Risk 3 – Power & Energy

Power-procurement strategy assumes nuclear-backed baseload contracts, PPAs and BESS availability at multi-GW scale. Negotiations with EDF and RTE for dedicated nuclear-supply tranches remain uncontrolled until signed. Multi-GW baseline contracts are unprecedented and may not be available at assumed cost (proposed EUR 50–70/MWh, not verified). Competing hyperscaler and hydrogen-production load in the region, plus France's own decarbonization targets, may constrain contract availability. Geopolitical and energy-security pressures could alter EDF's willingness to sign long-dated leases to a private developer with foreign sovereign-fund co-investors.

### Impact

Inability to secure power supply contracts at assumed cost could raise energy opex by 20–40% (€10B–€25B NPV impact over 10 years at full 9 GW). Delay of 12–24 months in securing agreements, extending Phase 1 timeline. If EDF or RTE condition supply on specific tenant or governance concessions, this could constrain tenant choice or renegotiate take-or-pay leases. Spot-price exposure without long-dated contracts could reduce tenant willingness to sign fixed-price leases.

### Likelihood
Medium

### Severity
High

### Action

Commission an independent power-procurement study in Month 0 (2026-10-17), engaging EDF and RTE directly to understand multi-GW contract availability, pricing and tenor at 500 MW first-tranche scale. Establish a firm Phase 0 gate criterion: secure a binding preliminary letter of intent from EDF for at least 500 MW baseload supply at a capped EUR/MWh price for a minimum 10-year tenor by Month 6 (2027-04-17). If EDF declines or offers unacceptable terms, reduce first-tranche target to 250 MW and pursue a hybrid portfolio of smaller PPAs and spot-exposed BESS arbitrage. Model power-cost sensitivity at 20%, 40% and 60% above assumed baseline, and define a cost threshold above which Phase 2 expansion is mothballed.

## Risk 4 – Capital & Financing

Phase 0 budget is estimated at €250M–€750M with no committed capital until the Phase 0 gate. Phase 1 is estimated at €5B–€10B for 500 MW–1 GW (not validated). Sunk cost in Phase 0 will pressure the investment committee to proceed even if gate criteria are not met. Infrastructure-fund consortium co-investors may have capital-drawdown or return-on-investment expectations conflicting with staged, kill-criteria discipline. FX exposure on USD GPU/TPU procurement (proposed €1.5B–€2.3B in Phase 1) is unhedged until tenant take-or-pay agreements exist, creating stranded-hardware and balance-sheet risk.

### Impact

Phase 0 sunk cost of €250M–€750M may be stranded if RTE grid or land-assembly gates fail. Pressure to override kill criteria could commit Phase 1 capital (€5B–€10B) despite unfavorable feasibility evidence. FX volatility on USD hardware: a 10% EUR/USD swing adds €150M–€230M to Phase 1 capex, eroding margin between budget and actual cost. Financing refusal if grid, land or demand evidence is weak, requiring equity cushions of 25–35% and raising cost of capital by 200–400 basis points.

### Likelihood
Medium

### Severity
High

### Action

Establish an independent investment committee in Month 1 (2026-11-17), separate from the development sponsor, with independent directors and an external red team. Fix numeric kill criteria in writing by Month 2 (2026-12-17): (i) RTE firm connection offer for ≥500 MW within 36 months; (ii) ≥70% of target parcel under non-coercive option; (iii) signed anchor-tenant take-or-pay covering ≥30% of Phase 1 capacity by end of Phase 0. If any criterion fails, the committee is empowered to pause or cancel Phase 1. Cap Phase 0 drawdown at €750M with documented abandonment conditions. Implement FX hedging policy: forward contracts for USD hardware procurement allowed only against signed tenant revenue in EUR, with hedge ratio of 0.5–1.0 of notional hardware cost. Publish the investment committee's quarterly decisions to lenders and co-investors.

## Risk 5 – Tenant Demand & Contracts

Phase 1 and Phase 2 expansion gates require signed anchor-tenant take-or-pay capacity commitments covering ≥30–50% of the planned expansion tranche. Letters of intent, expressions of interest and non-binding allocation requests do not count. Global hyperscalers are saturating Europe with competing data-center bids; commitments depend on sustained AI training demand growth that is not guaranteed. Sovereign-AI users have slower procurement cycles and may demand specific security, data-residency or pricing concessions conflicting with commercial terms. Neither hyperscaler nor sovereign anchors may be ready to commit capex-equivalent take-or-pay leases at the proposed Phase 1 timescale (Month 12–36 = 2027-10-17 to 2029-10-17).

### Impact

If signed anchor tenants cover <30% of Phase 1 planned capacity (500–1,000 MW) by Month 9 (2027-07-17), the project loses debt-financing certainty and Phase 1 FID is blocked. This triggers a 12–24 month delay or forces downsizing to 250 MW. Loss of a major anchor tenant after Phase 1 energization (due to shifting AI training spend) could strand 100–300 MW of capacity, reducing revenue by €200M–€600M over the lease term.

### Likelihood
High

### Severity
High

### Action

Initiate anchor-tenant conversations by Month 1 (2026-11-17), targeting 2–3 global hyperscalers and 2–3 sovereign or European-consortium anchors in parallel. Develop standardized take-or-pay lease term sheets by Month 2 (2026-12-17) specifying capacity reserved (proposed 50–500 MW per tenant), lease term (proposed 5–10 years), inflation escalation, exclusivity, and SLAs. Require non-binding letters of intent by Month 4 (2027-02-17), binding term sheets by Month 9 (2027-07-17). Define Phase 1 FID gate: require signed take-or-pay agreements totalling ≥300 MW (30% of 1 GW planned) with minimum A-/BB+ credit rating. Offer capacity-reservation fees (proposed €10M–€50M per 100 MW) paid upfront and credited against future lease revenue. If signed anchors do not reach 30% by Month 9 (2027-07-17), implement contingency: reduce Phase 1 to 250–500 MW matching only committed demand, and delay Phase 2 until demand reaches ≥50% of the Phase 2 target.

## Risk 6 – Permitting & Social License

Standard ICPE and local permitting timelines are estimated at 12–18 months; environmental authorization adds 6–12 months. National-major-project fast-track status (proposed acceleration to 18–24 months) is not confirmed in final legislative form (not verified). Community opposition to industrial land use, farmland displacement, security militarization, noise, and ecological impact can sustain legal appeals extending permitting by 24–48 months. Municipalities and prefectural authorities may demand conditions (community-benefit agreements, ecological commitments, labor-training programs) adding cost or operational constraints. Foreign co-investor involvement and national-security review (uncontrolled until ANSSI or DGSI reviews) could add 6–12 months of delay and impose tenant-access or data-flow restrictions.

### Impact

Permitting delay of 12–24 months erodes grid queue position and extends Phase 1 timeline by 1–2 years, raising carrying costs by €200M–€500M. Community-led legal appeals could force design changes increasing capex by 5–15% (€250M–€1.5B). National-security review blockage of foreign co-investor involvement or imposition of tenant-access restrictions could shrink the addressable market. Regulatory conditions (e.g., community benefit agreement totalling €100M–€300M) lock in costs not forecast.

### Likelihood
Medium

### Severity
High

### Action

Launch formal pre-permitting engagement with DREAL, prefectural and municipal authorities in Month 0 (2026-10-17), mapping required authorizations. Commission Phase 0 environmental baseline and social-impact assessments (Months 1–4 = 2026-11-17 to 2027-02-17) to identify community concerns and ecological sensitivities. Conduct early voluntary public consultation (Month 3 = 2027-01-17) with transparently posted siting rationale, design renderings, power and environmental specifications, and a publicly committal ecology and farmer-displacement mitigation plan. Establish a municipal and community liaison committee (Month 2 = 2026-12-17) with representatives from the affected municipalities and local farmer unions, committing to quarterly dialogue and published minutes. By Month 6 (2027-04-17), seek informal prefectural opinion on the regulatory path and any blocking concerns. Frame permitting as a 24-month process (Month 12–36 = 2027-10-17 to 2029-10-17) with a permitting gate at Month 18 (2028-04-17): if critical authorizations are not in formal application phase, pause Phase 1 drawdown. Offer a binding community-benefit agreement (€50M–€150M over Phase 1–2).

## Risk 7 – Environmental & Water

The plan specifies zero- or ultra-low-water cooling (direct-to-chip liquid cooling with dry coolers, no evaporative water). This design basis must be validated in Phase 0 against regional hydrological constraints, summer peak dry-cooler performance, and competing water users. Hauts-de-France has modest water stress; long droughts or competing industrial water demand could trigger regulatory restrictions. Summer peak dry-cooler performance under high ambient temperature (30–35°C) could degrade to a PUE of 1.35–1.5 (vs. target 1.15–1.25), raising electrical load by 5–15% and straining grid during peak-demand periods. Brownfield sites may restrict water-cooling options further.

### Impact

If dry-cooler performance in summer exceeds the PUE target by >10%, the project must accept higher power consumption (raising opex and grid curtailment risk) or retrofit to hybrid cooling with limited evaporative water (requiring permits). Regulatory restriction on water use (e.g., drought orders limiting industrial abstractions to 50% of normal) could reduce capacity utilization by 10–20% during dry periods, eroding tenant uptime commitments. Heat-reuse opportunity may not materialize if nearby offtake agreements are not signed; sunk cost for heat-distribution infrastructure (€50M–€200M) could be stranded.

### Likelihood
Medium

### Severity
Medium

### Action

Commission a detailed hydrological and thermal-design study in Phase 0 (Months 1–4 = 2026-11-17 to 2027-02-17) covering: (i) regional water-stress profiles, including drought frequency and magnitude; (ii) vendor dry-cooler performance curves at ambient temperatures up to 35°C and measured PUE impact; (iii) groundwater hydrology and contamination status on candidate parcels; (iv) binding opinion from regional water authorities on data-center cooling feasibility at 1 GW scale. Define the permitting gate for water/cooling: by Month 6 (2027-04-17), water authorities must confirm in writing that closed-loop direct-to-chip cooling with dry rejection is feasible at the planned scale. Test dry-cooler performance via site-specific thermal modelling under a 35°C design day; if modelled PUE exceeds 1.30, trigger a design review and potential cost escalation. Treat heat-reuse revenue as zero unless a binding offtake agreement is signed by Month 9 (2027-07-17); any heat-export infrastructure is then built as tenant-specific capex.

## Risk 8 – Brownfield Contamination & Remediation

Candidate sites span Cambrai (former airbase surroundings), Dunkirk (heavy industrial, petrochemical), Valenciennes/Denain/Escaudain (former steel works) and Saint-Omer (former industrial zones). Legacy soil, groundwater, asbestos, slag, munitions residue and other contamination are likely but not quantified. Phase 0 intrusive surveys can bound liability per parcel, but comprehensive remediation is expensive (€50M–€500M+ per major site) and can delay hall construction by 6–18 months if front-loaded. Back-loading remediation into Phase 1 construction risks discovering new liabilities that lenders will refuse to fund.

### Impact

Unexpected contamination discovery during Phase 1 construction could trigger health and safety work stoppages, regulatory enforcement action, and remediation costs of €100M–€400M. Liability allocation disputes could tie up capital in escrow or court proceedings for 2–4 years. If remediation cost exceeds budget contingency, Phase 1 FID faces slippage or cancellation. Heat-reuse or water-extraction infrastructure could encounter contamination requiring rework or abandonment.

### Likelihood
Medium

### Severity
High

### Action

Commission Phase I (desk-top) environmental site assessments on all candidate parcels by Month 1 (2026-11-17). Identify sites with known industrial history. By Month 3 (2027-01-17), conduct Phase II intrusive surveys (soil boring, groundwater sampling, asbestos survey) on the top 2–3 candidate sites in each zone. Establish a pre-Phase-0-gate deadline (Month 6 = 2027-04-17): shortlist only parcels whose Phase II ESA identifies remediation costs bounded to within €0–€100M per site and completable without blocking hall construction. Negotiate seller indemnities or remediation escrows that assign legacy-contamination liability to the seller or public remediation authority up to a capped amount. For public-landowner parcels, seek a written agreement that the public body retains remediation liability for pre-existing contamination and certifies sites as safe before hall foundation work begins. Reserve up to €100M–€300M in Phase 1 contingency for unexpected remediation; if cost escalates beyond this, trigger the Phase 1 FID gate.

## Risk 9 – Technical – Cooling & PUE

The cooling strategy assumes a PUE target of 1.15–1.25 via direct-to-chip liquid cooling and dry-cooler rejection, plus an optional 50–100 MW immersion-cooling pilot. These targets are at the leading edge of industry practice. Early hall construction may use pioneering liquid-cooling designs not yet proven at 500 MW–1 GW scale. PUE degradation from 1.20 to 1.30 or higher would increase opex by 8–10%. Immersion cooling is even less proven and carries risk of dielectric fluid supply constraints, hardware compatibility issues and high waste-heat concentration.

### Impact

If Phase 1 halls achieve PUE of 1.30–1.40 (vs. target 1.15–1.25), opex increases by €50M–€150M annually at full 9 GW, eroding tenant economics and creating pressure to downsize or delay Phase 2. Immersion-cooling pilot failure would strand €50M–€100M sunk cost and delay further rollout. Cooling-system outage affecting multiple halls creates emergency loss of tenant capacity, triggering SLA penalties of €10M–€50M+ and risk of tenant exit.

### Likelihood
Medium

### Severity
Medium

### Action

In Phase 0, engage leading liquid-cooling vendors to specify rack-interface standards, power density per rack, and cooling-loop configurations. Commission vendor performance guarantees (proposed PUE ≤1.25 at 30°C ambient, with penalty clauses if actual PUE exceeds 1.30). Test the chosen cooling design in a pilot 2–5 MW data hall during Phase 1 (Months 12–24 = 2027-10-17 to 2028-10-17), measuring actual PUE under production load before rolling out to remaining halls. For immersion cooling, limit the Phase 1 pilot to 10–50 MW with a dedicated tenant; make Phase 2 immersion expansion conditional on Phase 1 pilot validation (target ≤1.18). Establish a cooling-performance gate at Month 30 (2029-04-17): if average PUE across commissioned halls exceeds 1.28, pause additional hall construction and conduct root-cause review. Procure spare cooling system components during Phase 1 for rapid emergency response. Require tenant SLAs to include force-majeure clauses for cooling-system outages >4 hours.

## Risk 10 – Connectivity & Fiber

Connectivity strategy requires diverse fiber routes to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea landings with audited duct-level diversity. Fiber routes in France are often owned and managed by multiple carriers, and claimed diversity often collapses at shared ducts, bridges or landing stations. Subsea cable landings near Dunkirk or Channel access are concentrated in a few facilities, creating hidden single points of failure. Building dedicated fiber routes requires rights-of-way across private land, rail, canal and road corridors; permitting and land negotiation can add 12–24 months and €100M–€500M in cost.

### Impact

Failure of primary fiber route (cut by construction equipment, cable-ship anchor, sabotage or natural disaster) isolating the campus for 2–7 days causes total tenant revenue loss of €50M–€200M. Shared landing-point concentration means a localized disaster affects all routes simultaneously. Late-stage discovery that claimed fiber diversity is false could force rerouting, adding 6–12 months and €200M–€500M cost, delaying Phase 1 energization. Tenant demand for ultra-low latency to specific hubs cannot be met if fiber routes share bottlenecks.

### Likelihood
Medium

### Severity
Medium

### Action

In Phase 0 (Months 1–6 = 2026-11-17 to 2027-04-17), commission a fiber-route audit by an independent telecom engineer, requesting detailed physical-route maps from all candidate carriers. Demand specific confirmation of duct separation, bridge crossings, and landing-point facilities. Identify ≥2 physically separate long-haul routes (proposed minimum) to each of Paris, London, Brussels and Frankfurt with verified duct-level separation. For subsea, map landings to ≥2 separate UK facilities to avoid concentrated coastal risk. By Month 9 (2027-07-17) of Phase 0, secure capacity commitments or letters of intent from carriers for Phase 1 fiber lit by Month 12 (2027-10-17). If independent fiber routes are not available within cost and timeline limits, budget for a developer-owned or co-invested route along 1–2 corridors serving 100–200 km; negotiate rights-of-way during Phase 0 and duct installation during Phase 1 (Months 12–36 = 2027-10-17 to 2029-10-17). Define the connectivity gate for Phase 1 FID: by Month 9 (2027-07-17) of Phase 0, confirm in writing that ≥2 diverse fiber routes with ≥100 Tbps redundant capacity are available for Phase 1 energization at a cost within the project budget.

## Risk 11 – Security & National-Security Review

The campus will host AI training, sovereign AI, and possibly defense-adjacent compute for French and European users. National-security review by ANSSI, DGSI and potentially DGSE is likely but uncontrolled. Review scope and timeline (estimated 6–12 months, not verified) depend on tenant mix, foreign co-investor involvement, and security posture. Foreign co-investors backed by sovereign funds face heightened scrutiny; data-residency and tenant-access restrictions could be imposed. Security design (hardened perimeter, anti-drone systems, cyber-OT separation, personnel vetting) adds cost (proposed €50M–€200M for Phase 1) and can create community perceptions of militarization.

### Impact

National-security review extending beyond 12 months delays Phase 1 FID and energization by equivalent duration, eroding grid queue position and raising carrying costs by €200M–€500M. Restrictions imposed (e.g., limiting non-EU tenants, mandating data-residency zones, requiring state observer roles) could shrink the addressable tenant pool or force renegotiation of existing anchor-tenant leases. If the campus is classified as 'critical infrastructure,' this triggers ongoing oversight and compliance obligations increasing opex by 5–10% (€50M–€500M annually at full scale). Foreign co-investor capital-structure constraints could delay financing or reduce investor returns.

### Likelihood
Medium

### Severity
High

### Action

Initiate confidential pre-submission dialogue with ANSSI, DGSI and relevant prefectural security offices in Month 0 (2026-10-17) to understand the anticipated review scope, timeline and key concerns. Prepare a security and governance white paper (Month 2–3 = 2026-12-17 to 2027-01-17) documenting: (i) tenant selection and vetting process; (ii) data-residency and national-security data handling policies; (iii) perimeter hardening, anti-drone, cyber-OT separation and personnel-clearance specifications; (iv) co-investor governance and control provisions. By Month 6 (2027-04-17), seek informal ANSSI opinion on review timeline and blocking concerns. Engage early with a high-level interministerial working group to build consensus on national-security alignment. Budget Phase 0 cost for security design review and red-teaming (€5M–€15M). Define a security gate for Phase 1 FID: by Month 12 (2027-10-17) of Phase 0, obtain written confirmation from ANSSI that a formal security review can commence in Month 13 (2027-11-17), with a target timeline of 12–18 months to clearance. If ANSSI indicates a longer timeline or fundamental blocking concerns, trigger a Phase 1 pause or tenant-mix redesign.

## Risk 12 – Political & Community Opposition

Large-scale industrial projects in France face organized opposition from environmental groups, local residents and farm-sector unions. Concerns include farmland displacement and loss of agricultural production; ecological impact; noise, light and visual impact; water and cooling impacts; security and militarization perception; foreign investment and data sovereignty; labor and wage impacts. In Hauts-de-France, agricultural land is productive and politically protected; farm-sector unions can mobilize local opposition and legal challenge. Environmental groups and local mayors can block permits through legal appeal or political pressure.

### Impact

Sustained political opposition adds 12–36 months to permitting timeline and forces material design concessions (reduced footprint, relocated halls, additional ecological offsets) increasing capex by 5–15% (€250M–€1.5B). Legal appeals can extend authorization timelines beyond the project's Phase 1 schedule, forcing delay or downsizing. A campaign by a major local politician or environmental organization can shift public narrative, making permit approval politically costly. If a municipality formally refuses permits, the project may be forced to abandon that site and pivot to alternative locations.

### Likelihood
Medium

### Severity
High

### Action

Launch a stakeholder-engagement program in Month 1 (2026-11-17) targeting farmers' unions, environmental groups, municipality mayors, regional councillors and local media. Establish transparent, ongoing dialogue with published consultation minutes and clear avenues for input. Develop a binding community-benefit agreement (€50M–€150M over Phase 1–2) offering: (i) agricultural land compensation and relocation packages for displaced farmers; (ii) revenue-sharing or long-term lease options for continuation zones; (iii) ecological restoration and habitat creation on former brownfield; (iv) local employment and training commitments; (v) municipal infrastructure upgrades. By Month 6 (2027-04-17), conduct a formal public consultation with 4-week comment period, published responses and visible incorporation of feedback. Seek a municipal or prefectural endorsement (non-binding) by Month 9 (2027-07-17) of Phase 0. Define a social-license gate for Phase 1 FID: by Month 12 (2027-10-17) of Phase 0, obtain written support (formal resolution or letter) from at least 2 of the 3 most-affected municipalities, and confirm no major legal challenges are pending. If majority opposition emerges or a key municipality formally refuses, trigger a Phase 1 pause and feasibility reassessment.

## Risk 13 – Land Fragmentation & Split-Campus Complexity

If contiguous assembly of 161 km² fails (high likelihood per plan documents), the project must pivot to a split-campus model with 2–3 nodes across Cambrai, Dunkirk and Valenciennes. Split topology increases complexity: (i) separate grid connections and connection timelines per node; (ii) inter-node fiber links with latency and bandwidth constraints; (iii) separate permitting and security review for each node; (iv) operational overhead managing multiple sites; (v) tenant workload segmentation constraints. Early commitment to single-square topology may lock in design choices that become uneconomical or infeasible if later forced to split.

### Impact

Pivot to split-campus in Phase 1 (late discovery) forces redesign and delays energization by 6–12 months (€300M–€600M carrying cost). Per-MW capex increases by 5–15% due to duplication of substations, backup power, fiber routes and security infrastructure. Coordinated tenant workload management becomes operationally complex; some tenants may refuse to span multiple nodes, shrinking addressable customer pool. If split campus is chosen from the start, it demands detailed topology design and separate Phase 0 validation per node, extending Phase 0 timeline and spend by 3–6 months and €100M–€250M.

### Likelihood
Medium

### Severity
Medium

### Action

In Phase 0 Month 2–3 (2026-12-17 to 2027-01-17), commission a rigorous topology study comparing: (i) single-square 161 km² at Cambrai or nearby; (ii) two-node split campus (Cambrai primary ~500 MW, Dunkirk secondary ~250–500 MW) with fiber ring; (iii) three-node split (Cambrai, Dunkirk, Valenciennes) with mesh fiber. Define decision criteria by Month 4 (2027-02-17): single-square is chosen only if ≥70% of target parcel can be optioned at reasonable cost; otherwise split-campus is the baseline. For split-campus, validate: (i) inter-node latency and bandwidth tolerance via tenant cluster-workload modelling; (ii) per-node grid hosting capacity and connection timelines; (iii) fiber-route diversity per node and inter-node dark-fiber cost. Develop detailed split-campus designs for the 2–3 most viable node combinations by Month 6 (2027-04-17), so Phase 1 design does not commit to single-square constraints that later become infeasible. Define modular capex estimates per node, so Phase 1 FID can proceed on the topologically feasible subset.

## Risk 14 – Silicon Supply & USD FX Exposure

GPU/TPU and networking hardware costs are estimated at €1.5B–€2.3B in Phase 1, denominated in USD. FX risk depends on EUR/USD exchange rate (assumed 1.08–1.12 in Phase 0 planning, not verified), vendor allocation availability, and US export-control policy changes. If the developer procures hardware ahead of signed tenant take-or-pay agreements, the hardware becomes a stranded asset if tenant demand fails. Vendor allocation is constrained and subject to geographic quotas, US export-control restrictions, and competition from other hyperscalers. USD hardware procurement ties the project to US vendor supply chains and export-control risk.

### Impact

10% EUR/USD FX move (1.08 to 1.19) increases hardware cost by €150M–€230M on a €1.5B–€2.3B procurement. Hardware procured ahead of tenant demand becomes stranded if commitments fail, locking €500M–€1B in sunk cost. US export-control changes could affect both the developer's procurement and tenant's ability to use hardware, creating renegotiation pressure or lease termination risk. Vendor allocation constraints may force longer lead times (12–24 months vs. 6–9 months) or higher prices, pushing Phase 1 energization into Year 3 instead of Year 2.

### Likelihood
Medium

### Severity
Medium

### Action

Adopt a capital-structure policy in Month 1 (2026-11-17): create a separate hardware vehicle owned by tenants or a tenant-backed lessor, not by the infrastructure company. Tenants procure hardware under their own FX exposure; the infrastructure company finances only EUR-denominated power, cooling, real estate and connectivity. Alternatively, the developer procures hardware only against signed tenant take-or-pay leases, with forward-contract FX hedging matched to the lease term and tenant payment schedule (hedge ratio 0.5–1.0 of notional cost). By Month 6 (2027-04-17) of Phase 0, establish vendor relationships with NVIDIA and TPU suppliers to understand allocation availability, lead times and pricing. Lock vendor allocation 9–12 months ahead of Phase 1 energization (Month 3–6 = 2027-01-17 to 2027-04-17 of Phase 1) through non-binding letters of intent. Implement forward-contract FX hedging policy: 50–100% of hardware cost is hedged via EUR/USD forwards matched to signed tenant lease revenue, at a proposed hedge cost of 0.5–2% annually. If export-control policy changes during Phase 0, trigger a feasibility reassessment.

## Risk 15 – Grid Curtailment & Demand Flexibility

The proposed grid-hosting strategy assumes the campus accepts contractual curtailment and demand-flexibility commitments to RTE in exchange for connection capacity and favorable rates. A 10–20% annual curtailment allowance (proposed, to be negotiated) means the campus operates at full power 80–90% of the time; curtailed hours typically occur during peak winter evening or summer stress periods. This reduces tenant uptime, creates revenue loss (€50M–€200M annually per GW curtailed), and may conflict with tenant SLAs demanding high availability (99.5–99.95%). Tenants may refuse to sign leases with built-in curtailment risk or demand price concessions (5–15% lease discounts).

### Impact

If 1 GW is curtailed at 15% annually, revenue loss is €150M–€300M over 10 years at assumed EUR 50–70/MWh rates (not verified). Tenant refusal to accept curtailment forces negotiation of firm connection without flexibility, which may not be available from RTE or may require higher transmission reinforcement cost (€200M–€500M additional). Tenant lease discounts to offset curtailment reduce revenue by €50M–€150M annually, eroding project returns and lender debt-service coverage. Unplanned or excessive curtailment creates tenant disputes over SLA compliance and potential lease termination.

### Likelihood
Medium

### Severity
Medium

### Action

During Phase 0 grid negotiations (Month 1–6 = 2026-11-17 to 2027-04-17), establish the maximum acceptable annual curtailment tolerance with RTE, proposed as ≤10% (to be negotiated). Confirm that curtailment is scheduled in advance (30–90 days notice) rather than emergency. Develop a campus-level BESS and demand-flexibility strategy that reduces grid stress during peak periods: propose 50–200 MWh BESS, interruptible non-critical workloads, and load shifting to off-peak hours. Design tenant SLAs to carve out force-majeure exceptions for RTE-mandated curtailment, limiting tenant compensation to lost margin rather than full revenue. If RTE requires curtailment >15% annually, model the revenue impact on tenant lease pricing and investor returns; if investor returns fall below hurdle rates, reduce Phase 1 target to the capacity RTE can support without material curtailment (proposed 500–750 MW). Define the curtailment gate for Phase 1 FID: by Month 9 (2027-07-17) of Phase 0, obtain RTE's firm statement that the first tranche can be connected with annual curtailment not exceeding 10–15% (to be negotiated).

## Risk 16 – Operational – Workforce & Skills

Construction of 8–20 data halls in Phase 1, plus electrical, mechanical, cooling, and security infrastructure, requires skilled trades that are in global shortage. Hauts-de-France has industrial heritage and a regional workforce, but wage inflation and competition for scarce trades during a multi-year Phase 1 build could increase labor costs by 20–40%. Operations staff for a 500 MW–1 GW campus are relatively small (proposed 50–150 FTE, not verified) but require highly trained engineers and technicians with advanced cooling, networking, security and AI-system expertise. Lack of trained operations staff risks poor PUE, security gaps and tenant SLA failures.

### Impact

Wage inflation on skilled trades adds 10–20% to Phase 1 capex (€500M–€2B on a €5B–€10B budget). Labor shortages during Phase 1 cause schedule slippage of 3–9 months, raising carrying cost by €150M–€500M. If operations staff are not ready by Phase 1 energization, initial PUE and security performance fall short of targets, damaging tenant relationships and revenue. High operational labor cost (€20M–€50M annually for Phase 1, scaling to €100M–€200M at 9 GW) erodes project margins.

### Likelihood
Medium

### Severity
Low

### Action

Establish a regional workforce and training strategy in Phase 0 (Month 1–3 = 2026-11-17 to 2027-01-17): engage technical colleges, trade unions and employer associations to develop a training pipeline for data-center electrical, mechanical, cooling and security trades. Commit to funding a regional training academy (€10M–€30M cost) during Phase 1, producing 200–500 certified technicians over 3–5 years. Structure Phase 1 construction contracts with wage and productivity incentives to minimize labor inflation. Use modular, prefabricated data-hall designs that reduce on-site labor content. Procure advanced building management and cooling systems with telemetry and remote-diagnostics capabilities to reduce headcount. By Month 9 (2027-07-17) of Phase 0, recruit a Phase 1 operations leadership team (CTO, VP Operations, VP Security) to validate readiness and identify training gaps. Pilot operations on the first 2–3 halls during Phase 1 (Months 12–24 = 2027-10-17 to 2028-10-17) with a small team, documenting procedures and learning before full-campus operations ramp.

## Risk 17 – Financial – Debt Financing & Lender Risk

Phase 1 financing (€5B–€10B capex) and Phase 2+ require debt of €3B–€8B (estimated 60–70% debt/capex ratio, to be validated). Lenders will require: (i) committed grid connection from RTE; (ii) signed anchor-tenant take-or-pay leases covering ≥30–50% of capacity; (iii) bounded remediation and environmental liability; (iv) demonstrated operational performance from pilot halls; (v) stable power procurement contracts at locked-in prices. Absence of any of these elements will trigger higher cost of capital (200–400 bps spread), lower debt/capex leverage (50–60% vs. 60–70%), or debt refusal. Currency mismatches between EUR-denominated infrastructure debt and USD hardware costs create balance-sheet risk.

### Impact

If Phase 1 debt is not available on acceptable terms, Phase 1 FID is blocked and must be delayed 12–24 months. Cost-of-capital increase of 200 bps on €7B debt adds €140M–€280M in annual interest cost, eroding returns by 2–3 percentage points. If tenant take-or-pay leases fail to cover ≥30% of Phase 1 capacity, lenders may require additional equity or sponsor guarantees, reducing leverage and returns. Currency mismatches create accounting losses if EUR strengthens, eroding equity value.

### Likelihood
Medium

### Severity
High

### Action

Engage debt capital providers (EIB, KfW, French banks, infrastructure funds) in Month 3 (2027-01-17) of Phase 0 to establish lending criteria and pre-commitment signals. Commission a Phase 0 debt-financing study (Month 4–6 = 2027-02-17 to 2027-04-17) modelling debt structure, tenor, leverage, pricing and conditions for Phase 1 at various certainty levels. Target debt-financing commitment (non-binding LOI) by Month 9 (2027-07-17) of Phase 0, contingent on Phase 0 gate outcomes. Define debt-financing as a Phase 1 FID gate criterion: by Month 12 (2027-10-17) of Phase 0, secure a firm debt-financing commitment for at least €3B–€5B at a cost of capital within acceptable spreads (proposed benchmark + 200 bps, to be negotiated) for a minimum 12-year tenor. If lenders decline or require unacceptable terms, trigger a Phase 1 FID pause and equity-restructuring review. Implement a currency hedging policy for hardware FX exposure via forward contracts or tenant lease denominations in EUR where feasible.

## Risk 18 – Technical – Scalability & Technology Lock-In

Phase 1 data halls and infrastructure will be designed to a specific technical standard (liquid-cooling interface, rack power density, networking architecture, security design). Scaling from Phase 1 (500 MW–1 GW) to Phase 2–4 (up to 9 GW) over 10–15 years creates technology-refresh risk: cooling technology, GPU/TPU architecture, networking speeds and security standards will evolve significantly. Design choices locked in Phase 1 may become suboptimal or obsolete by Phase 3–4, requiring retrofit or abandonment of early infrastructure. Long-term depreciation schedules (capex capitalized over 20–30 years) conflict with 5–7 year technology cycles in AI accelerators.

### Impact

Technology refresh constraints force Phase 1 cooling to be compatible with Phase 2+ hardware, limiting optimization for early workloads. If Phase 1 cooling or rack standards become incompatible with next-generation hardware, retrofit cost is €500M–€1.5B. Vendor lock-in limits tenant choice and increases costs. Accelerator technology obsolescence reduces asset value in later phases; if Phase 1 GPUs are fully depreciated by Year 5 but still in service, they create a legacy-asset management problem.

### Likelihood
Low

### Severity
Medium

### Action

Design Phase 1 infrastructure using standardized, vendor-agnostic interfaces for cooling (proposed OCP or equivalent), power and networking. Commission a 5-year technology roadmap (Month 3–4 = 2027-01-17 to 2027-02-17 of Phase 0) from vendors and research institutes covering: (i) cooling technology evolution; (ii) GPU/TPU power and thermal profiles; (iii) networking speeds and latencies. Plan Phase 1 cooling for modularity: halls and loops should be capable of retrofit or expansion with next-generation cooling without major structural rework. Separate capex depreciation schedules for infrastructure (20–30 year life) vs. accelerators (5–7 year life). Include technology-refresh risk in Phase 2–4 financial models: budget 10–15% of capex for retrofit and upgrades. Design Phase 1 halls with flexibility for future equipment power/thermal upgrades; limit early optimization to Phase 1 workloads rather than over-designing for hypothetical future requirements.

## Risk 19 – Strategic – Single-Site vs. Split-Campus Topology

The plan mandates that the single 12.7 km × 12.7 km square be stress-tested honestly against a split-campus model, and explicitly allows downsizing or splitting as a legitimate outcome if feasibility fails. Commitment to single-square topology early in Phase 0 (before land assembly, grid and tenant validation) risks locking the project into an infeasible design. Conversely, postponing the topology decision until late Phase 0 leaves insufficient time to develop detailed split-campus designs and grid plans, forcing a rushed, low-confidence FID decision.

### Impact

Single-square commitment that later fails to assemble land or grid capacity forces expensive Phase 1 redesign or cancellation. Delaying topology decision until Month 10 (2027-08-17) of Phase 0 compresses time available for split-campus design, fiber route planning and multi-node grid negotiations, increasing risk of Phase 1 start slippage by 6–12 months. Split-campus choice made too early may over-complicate Phase 0 by requiring simultaneous validation of 2–3 sites, extending Phase 0 timeline by 3–6 months and spend by €150M–€300M.

### Likelihood
High

### Severity
Medium

### Action

Establish a topology decision gate at Month 4 (2027-02-17) of Phase 0. At this gate, compare single-square vs. 2–3 node split-campus options on criteria: (i) land assemblability (% of target parcel optionable); (ii) per-node grid hosting capacity; (iii) fiber-route feasibility and cost; (iv) per-MW capex and opex; (v) operational complexity and tenant workload span-ability. Choose single-square only if ≥70% of target parcel is optionable and grid capacity is confirmed ≥1 GW in first tranche; otherwise default to split-campus. For split-campus, identify 2–3 viable node combinations and develop detailed Phase 1 capex/timeline for each, so FID can proceed on the feasible subset. Publish the topology decision in writing, with evidence and rationale.

## Risk 20 – Environmental – Ecological Impact & Compensation

The 161 km² envelope likely spans productive agricultural land, wetlands, and possibly ecological corridors or protected habitats (Natura 2000, RAMSAR wetlands, listed species). Environmental authorization and EIA require avoidance of impact where possible, reduction of unavoidable impacts, and compensation for residual impacts at a 1:1 or greater ratio (net-positive biodiversity goal). Compensating ecological impact on 100+ km² of active development may require purchasing or restoring 100–300 km² of offsite land, at a cost of €100M–€500M with uncertain effectiveness and enforcement. Agricultural displacement of productive farmland (estimated 10,000–15,000 hectares or more) triggers compensation and relocation costs that are politically contentious.

### Impact

Environmental permitting delays of 12–24 months due to EIA complexity or legal challenge. Ecological compensation cost of €200M–€500M in Phase 1–2, reducing project returns. Designation of new protected zones or expansion of Natura 2000 areas during Phase 0–1 could retroactively restrict land use, forcing design changes and cost escalation. Agricultural displacement of 10,000+ hectares triggers political opposition and can block permits or force a public referendum. Net-biodiversity targets may be unachievable at the proposed scale, leading to permit conditions that constrain buildout or require perpetual ecological restoration funding.

### Likelihood
Medium

### Severity
High

### Action

Commission a Phase 0 environmental baseline and ecological survey (Months 1–4 = 2026-11-17 to 2027-02-17) covering: (i) botanical, avian, invertebrate and bat surveys across candidate sites; (ii) Natura 2000 and protected-species mapping; (iii) hydrological and soil-quality assessment; (iv) carbon storage and peat-soil inventory. Identify the 'no-build' or 'minimal-impact' core area (e.g., 50–80 km² of the 161 km² envelope) that avoids key ecological zones, and focus Phase 1 development on that core. Establish a campus-wide ecological master plan by Month 6 (2027-04-17) that pre-commits biodiversity-compensation measures: offsite habitat restoration, wetland creation, hedgerow and wildlife-corridor establishment on continuation zones. Work with environmental NGOs and regional conservation authorities to co-design and monitor ecological compensation. Budget €200M–€300M for ecological offset and restoration in Phase 1–2 capex. Define the environmental gate for permitting: by Month 9 (2027-07-17) of Phase 0, obtain a preliminary EIA screening opinion from DREAL confirming that ecological compensation is achievable within the proposed scale and cost.

## Risk 21 – Regulatory – National Legislation & Policy Change

The project's feasibility and timeline depend on several regulatory assumptions that are not confirmed: (i) fast-track permitting status for major industrial projects (being legislated but not finalized); (ii) RTE and EDF willingness to sign multi-GW supply and connection contracts; (iii) French AI and data-sovereignty strategy remaining aligned with private-sector hyperscale data centers (policy could shift toward public or EU ownership); (iv) US export-control policy on advanced GPUs remaining stable. Major legislative or policy changes during Phase 0–1 could render the project uneconomic or infeasible.

### Impact

Legislative change delaying or eliminating fast-track permitting status extends permitting timeline by 12–24 months. Policy shift toward public-sector or EU-only data-center ownership could exclude private developers or mandate state co-investment at unfavorable terms. Export-control restrictions on advanced GPUs could eliminate hardware availability, forcing the campus to focus only on sovereign AI workloads. Change in EDF energy strategy could make long-dated baseload contracts unavailable or uneconomical. Climate-adaptation regulations could force technology retrofits or capacity reductions.

### Likelihood
Low

### Severity
High

### Action

Establish a regulatory-horizon scanning program in Phase 0 (Month 1 = 2026-11-17 onwards), monitoring: (i) French parliamentary debates on AI, data sovereignty, and fast-track permitting; (ii) EU regulations on data-center energy efficiency and environmental impact; (iii) US export-control and sanctions policy affecting GPU/TPU trade; (iv) EDF and RTE strategic statements on long-term supply and grid availability. Engage in industry associations and policy forums to understand emerging policy trends. By Month 9 (2027-07-17) of Phase 0, commission a regulatory-risk analysis updating the project's sensitivity to identified policy changes. Define a policy-change gate for Phase 1 FID: if major legislation affecting permitting, energy supply, or export controls passes during Phase 0, reassess feasibility and update project economics. Include a force-majeure clause in Phase 1 FID that allows the project to pause or exit if a fundamental regulatory change occurs.

## Risk 22 – Financial – Financing Structure & Sovereign Co-Investment Terms

The project is backed by an infrastructure-fund consortium with sovereign-adjacent co-investment discussions. Sovereign co-investor terms often include below-market returns, public-interest concessions (labor, data sovereignty, environmental commitments), governance restrictions, and slow decision-making. Reconciling sovereign-investor expectations with private-developer cost-of-capital and return targets (proposed 8–12% IRR, not specified) creates tension. Negotiating sovereign co-investment terms can take 12–24 months, delaying Phase 1 FID or forcing cost concessions that erode equity returns.

### Impact

Sovereign co-investment terms requiring public-benefit spending (€100M–€500M in Phase 1–2) reduce investor equity returns by 1–3 percentage points. Governance restrictions increase operational complexity and slow decision-making by 3–6 months per cycle. Negotiation delay for sovereign co-investment structure extends Phase 0 and Phase 1 timeline by 6–12 months. If sovereign terms become unacceptable, the project may lose the political support and permitting tailwind that sovereign backing provides.

### Likelihood
Medium

### Severity
Medium

### Action

Establish a financing-structure working group in Month 1 (2026-11-17), bringing together sponsor equity, infrastructure-fund consortium representatives, and sovereign-fund representatives. By Month 3 (2027-01-17), develop a draft co-investment term sheet outlining: (i) equity stake and return expectations; (ii) governance structure (board composition, veto rights); (iii) public-interest commitments; (iv) decision-making timeline. Negotiate sovereign terms in parallel with Phase 0 feasibility work (Months 2–8 = 2026-12-17 to 2027-06-17), so co-investment structure is resolved before Phase 1 FID gate (Month 12 = 2027-10-17). If sovereign terms prove unacceptable (return expectations <5%, governance vetoes paralyze decisions), consider a bifurcated structure: sovereign investor takes a non-controlling stake (20–30%) with preferred-return target and board observation rights, while private sponsor retains operational control. Establish a financing gate for Phase 1 FID: by Month 12 (2027-10-17) of Phase 0, secure binding commitment from all equity sources for Phase 1 capex (€5B–€10B), with agreed-upon terms, governance structure and decision-making timeline.

## Risk 23 – Operational – Subsea Cable & Landing-Point Single Points of Failure

Connectivity to subsea networks and international markets depends on landings at UK, Belgium, Netherlands and France coastal facilities. These landing points are often concentrated in a few geographic locations, creating hidden single points of failure. A disaster at a primary landing station could isolate the campus from international markets for days to weeks. Resilience against landing-point concentration requires geographically diverse subsea routes, which are expensive to build or lease.

### Impact

Subsea cable cut or landing-point disaster isolating the campus for 3–7 days causes total tenant revenue loss of €50M–€200M. Repair of subsea cable requires 2–4 weeks; repair of landing-point damage could require 4–12 weeks. Tenants running international AI training or inference workloads cannot tolerate this level of outage; loss of anchor tenants due to unreliable connectivity could cascade into lease terminations and revenue loss.

### Likelihood
Low

### Severity
High

### Action

During Phase 0 fiber-route audit (Months 1–6 = 2026-11-17 to 2027-04-17), audit subsea cable landing points and confirm that the campus has access to ≥2 independent landing facilities on the UK coast and ≥2 independent facilities on the French/Belgian coast, with no shared infrastructure (landing conduit, power, cooling) between them. If independent landings are not available, budget for co-investment in a new subsea cable or landing facility (€300M–€800M over Phase 1–2). Establish service-level agreements with subsea-cable operators requiring rapid-response repair commitments (<72 hours) and carrier guarantees of compensation for outages >4 hours. Design the campus fiber architecture with on-shore diversity, so outage of any single landing point affects <25% of total cross-border capacity. By Month 9 (2027-07-17) of Phase 0, confirm in writing that subsea connectivity redundancy is achievable within cost and timeline budgets.

## Risk Summary

This is a 9 GW, 161 km² hyperscale AI campus project in Hauts-de-France, budgeted at €100B–€140B+ over 10–15 years, with a 500 MW–1 GW Phase 1 gate. The project is intentionally framed as a stress-test of extreme ambition, with legitimate outcomes including downsizing, splitting across multiple sites, or cancellation if feasibility fails. The plan adopts a pragmatic foundation: tranche-based grid requests, milestone-capped Phase 0 capital (€250M–€750M), reservation-fee demand validation, standard permitting with early consultation, and independent investment-committee gate control.

Critical success factors: RTE grid hosting capacity above ~1 GW (the primary kill condition), land assembly without major holdouts, credible anchor-tenant demand backed by signed take-or-pay agreements covering ≥30–50% of expansion tranches, social license and permitting non-blockage, and stable financing.

Most critical risks:

- (1) RTE grid hosting-capacity constraints limiting available connection power below ~1 GW (stated failure condition)
- (2) inability to assemble adequate, contiguous or semi-contiguous parcel due to fragmented farmland ownership, holdouts, or limited industrial brownfield availability
- (3) absence of creditworthy anchor tenants willing to sign binding take-or-pay leases

Secondary risks: brownfield contamination surprises, community and political opposition blocking or delaying permits, water and cooling feasibility at required PUE, financing credibility given the scale, national-security review duration.

This register identifies 23 material risks across regulatory, technical, financial, environmental, social and operational domains, with emphasis on uncontrolled external dependencies and failure modes that trigger exit or downsizing.

# Make Assumptions
# Phase 0 Financial Constraints and FX Isolation

## Maximum Sunk Cost and Funding

- Phase 0 capped at €750M (user constraint), drawn in milestone tranches from consortium with abandonment conditions
- USD hardware sits in separate tenant-backed vehicle
- Forwards used only against signed take-or-pay, at hedge cost of 0.5–2% annually (estimate)

## Financial Feasibility Assessment

Staged capital limits stranded cost. Phase 0 of €250M–€750M is challenging. Phase 1 hardware of €1.5B–€2.3B in USD moves approximately €150M–€230M per 10% FX swing (estimate). Risk: sunk-cost pressure overrides gate. Mitigation: independent investment committee, drawdowns tied to grid, land and tenant evidence, hedges only against signed leases. Opportunity: ring-fenced hardware vehicle widens lender pool. Full-buildout cost of €100B–€140B+ is unvalidated and credible only per tranche.

# Phase 0 Schedule and External Dependencies

## Gate Sequence and Milestones

- Phase 0 runs Months 0–12 (2026-10-17 to 2027-10-17) with topology decision at Month 4 (2027-02-17), land and water checks by Month 6 (2027-04-17), tenant term sheets by Month 9 (2027-07-17), gate review at Month 12 (2027-10-17)
- RTE, prefectural and ANSSI milestones labelled uncontrolled until signed offer or formal decision exists

## Schedule Feasibility Assessment

Firm RTE connection offer within 12 months is unlikely (estimate). Permitting takes 24+ months; ~1 GW grid test may resolve only after Month 12 (2027-10-17). Risk: gate dates set before authorities answer. Mitigation: gate can pass with 'conditional' status, Phase 1 FID shifts with RTE timing rather than forcing decision. Opportunity: early topology and land checks (Months 3–4 = 2027-01-17 to 2027-02-17) can kill single-square option cheaply, saving €100M–€250M (estimate).

# Phase 0 Team and Scarce Skills

## Resource Requirements

- Core team of 40–60 people (estimate) plus specialist advisers for grid, hydrology, ecology, legal, land and security
- Independent investment committee and red team separate from development
- Regional offices at Cambrai and Dunkirk

## Resource Capacity Assessment

Electrical and cooling trades are scarce; wage inflation of 20–40% on trades is a risk (estimate). Operations headcount is small (50–150 FTE for Phase 1, not verified), so employment claims must be modest. Mitigation: early framework contracts with large EPC firms, regional training academy (€10M–€30M, estimate), prefabricated halls. Opportunity: remediation and civil firms from region can be certified early. Key-person dependence on grid and permitting leads must be covered by deputies.

# Regulatory Authorisations and Fast-Track Status

## Permit Requirements

Standard route applies: ICPE and environmental authorisation take 18–30 months, appeal risk adds 24–48 months (estimates). Fast-track status not assumed because not confirmed. National-security and foreign-investment reviews run in parallel and uncontrolled until formal decisions exist.

## Regulatory Pathway Assessment

Permit delay erodes RTE queue position and adds carrying cost of €200M–€500M (estimate). Foreign co-investor scrutiny could cap foreign equity or restrict tenants. Mitigation: pre-submission dialogue with DREAL, prefecture and security authorities in Months 0–1, early voluntary consultation, one permit file per node so challenge does not stall all sites. Split campus multiplies files but isolates legal risk. Policy change is a gate trigger.

# Safety, Risk Exposures and Kill Thresholds

## Principal Risks and Proposed Thresholds

Highest risks: grid below ~1 GW, land fragmentation, no creditworthy anchors (all High likelihood). Kill thresholds proposed in Phase 0: firm RTE offer of at least 500 MW within 36 months, at least 70% of target parcel optioned non-coercively, signed take-or-pay for at least 30% of Phase 1. Security is baseline campus-wide with hardened enclaves funded by sovereign tenants.

## Safety and Risk Assessment

Contamination can cost €100M–€400M if found late (estimate); intrusive surveys before commitment bound this. Fiber diversity often collapses at shared ducts; audit before relying on it. Single-site concentration raises sabotage and grid-loss impact; split campus reduces it. Thresholds only bind if committee is independent of development team.

# Environmental Limits and Cooling Approach

## Environmental Constraints

- Cooling is closed-loop direct-to-chip with dry coolers, no evaporative water
- Built area is minority of envelope (30–50%, estimate), rest as buffers, ecology and farmland
- Heat reuse valued at zero until offtake is signed

## Environmental Impact Assessment

Dry cooling in 30–35°C weather may push PUE to 1.35–1.5 against 1.15–1.25 target, raising peak grid load by 5–15% (estimate). Farmland loss of 10,000+ ha is politically contentious. Ecological compensation may cost €200M–€500M (estimate) and compete for farmland. Mitigation: ecological master plan by Month 6 (2027-04-17), written water-authority opinion, reserve contaminated zones for energy or restoration. Opportunity: brownfield reuse and heat export strengthen narrative if contracted.

# Stakeholder Engagement and Local Support

## Stakeholder Roles and Support Threshold

Support from at least 2 of 3 most affected municipalities is Phase 1 gate (proposed threshold). Liaison committee and public consultation start in Months 1–3 (2026-11-17 to 2027-01-17). Community-benefit package of €50M–€150M over Phases 1–2 (estimate) contingent on permits. Binding local veto not adopted; refusal by key municipality triggers reassessment.

## Stakeholder Engagement Assessment

Farm unions (FNSEA, Confédération Paysanne), NGOs and mayors can delay permits by 12–36 months (estimate). Benefits built on jobs lack credibility given small operations headcount. Mitigation: published minutes, lease-and-continue farming, transparent siting rationale, funded monitoring roles for municipalities. Competing industrial users (steel, hydrogen) may contest grid capacity. Opportunity: reindustrialisation narrative with shared infrastructure can win support.

# Operating Model and Validation

## Operating Framework

- Capacity sold under take-or-pay leases of 5–10 years (proposed) with reservation fees of €10M–€50M per 100 MW (proposed)
- Power blend of nuclear-linked contracts, PPAs and BESS, curtailment at or below 10% (proposed)
- 2–5 MW pilot hall validates PUE before scaling

## Operational Systems Assessment

Multi-GW nuclear-backed supply at assumed €50–70/MWh not verified; 20–40% cost overrun would hit economics hard. Curtailment of 15% on 1 GW could cost €150M–€300M over 10 years (estimate) and conflicts with 99.5%+ tenant SLAs. Mitigation: pass-through indexation, BESS and interruptible workloads. Expansion gate: PUE at or below 1.28 across commissioned halls, power reliability met, signed take-or-pay for 30–50% of next tranche. Letters of intent do not count.

# Distill Assumptions
# Project Overview

- Phase 0 runs Months 0-12 (2026-10-17 to 2027-10-17), capped at €750M (user constraint), drawn in milestone tranches.
- Phase 0 estimated at €250M-€750M; Phase 1 €5B-€10B for 500 MW-1 GW (user constraints).
- Full 9 GW buildout of €100B-€140B+ is unvalidated and credible only per tranche.
- The 12.7 km × 12.7 km (161 km²) square is a notional envelope, compared against split-campus.

## Key Milestones

- Topology decision at Month 4 (2027-02-17)
- Land and water checks by Month 6 (2027-04-17)
- Tenant term sheets by Month 9 (2027-07-17)
- Phase 0 gate review at Month 12 (2027-10-17); conditional passes allowed if authorities have not answered.

## Feasibility and Gating

- Hosting capacity above ~1 GW is the primary feasibility test; first grid tranche is 500 MW-1 GW.
- Kill thresholds (proposed): firm RTE offer of at least 500 MW within 36 months.
- Kill thresholds (proposed): at least 70% of target parcel optioned non-coercively; signed take-or-pay for 30% of Phase 1.
- Next-phase FID requires signed take-or-pay covering 30-50% of the tranche; letters of intent do not count.
- Downsizing, splitting, delaying or cancelling are legitimate outcomes if feasibility fails.
- Success is Phase 0 and 1 within budget with credible tenants and signed-anchor Phase 2 FID.

# Grid and Power

- RTE, prefecture and ANSSI milestones are uncontrolled until a signed offer or formal decision exists.
- Curtailment is capped at or below 10% (proposed); 15% on 1 GW could cost €150M-€300M (estimate).
- Multi-GW nuclear-backed supply at €50-70/MWh is not verified; 20-40% overrun would hurt economics.
- Permit delay adds €200M-€500M carrying cost (estimate) and erodes RTE queue position.

# Cooling and Efficiency

- Cooling is closed-loop direct-to-chip with dry coolers and no evaporative water; PUE target 1.15-1.25.
- Hot-weather dry cooling may push PUE to 1.35-1.5 and raise peak grid load 5-15% (estimate).
- Expansion gate requires PUE at or below 1.28 across commissioned halls, plus reliability targets met.
- A 2-5 MW pilot hall validates PUE before scaling; heat reuse valued at zero until offtake signed.

# Land and Environment

- Built area is about 30-50% of the envelope (estimate); the rest is buffers, ecology and farmland.
- Farmland loss of 10,000+ ha is contentious; ecological compensation may cost €200M-€500M (estimate).
- Ecological master plan is completed by Month 6 (2027-04-17); written water-authority opinion is obtained.
- Late-found contamination could cost €100M-€400M (estimate); intrusive surveys precede parcel commitment.
- Standard ICPE and environmental permitting takes 18-30 months, plus 24-48 months if appealed (estimates); fast-track not assumed.

# Permitting and Regulation

- One permit file per node isolates legal challenge risk in a split campus.
- National-security and foreign-investment reviews run in parallel and may cap foreign equity or restrict tenants.

# Tenancy and Revenue

- Capacity sold on 5-10 year take-or-pay leases with €10M-€50M reservation fees per 100 MW (proposed).
- USD hardware sits in a separate tenant-backed vehicle; forwards only against signed take-or-pay, hedge cost 0.5-2% yearly (estimate).
- Phase 1 USD hardware of €1.5B-€2.3B moves about €150M-€230M per 10% FX swing (estimate).

# Fiber and Security

- Fiber diversity must be physically audited for shared ducts, bridges and landing stations before reliance.
- Security is a campus-wide baseline with hardened enclaves funded by sovereign tenants.

# People and Operations

- Phase 0 core team is 40-60 people (estimate) with independent red team; offices in Cambrai and Dunkirk.
- Trade wage inflation of 20-40% is a risk; Phase 1 operations headcount is 50-150 FTE (not verified).
- Regional training academy costs €10M-€30M (estimate); prefabricated halls reduce on-site labor.

# Community and Stakeholders

- Liaison committee and public consultation start Months 1-3 (2026-11-17 to 2027-01-17); support from 2 of 3 key municipalities is required (proposed).
- Community-benefit package of €50M-€150M over Phases 1-2 (estimate) is contingent on permits.
- Farm unions, NGOs and mayors can delay permits by 12-36 months (estimate); competing industrial users may contest grid capacity.

# Governance

- Independent investment committee holds numeric kill thresholds, separate from the development team.


# Review Assumptions
# Grid-Scale AI Data Center - Phase 0 Feasibility Plan

## Executive Summary

A 161 km² multi-phase data center campus in northern France targeting 9 GW ultimate capacity over 10 years. Phase 0 (Months 0–12 = 2026-10-17 to 2027-10-17) validates four gates: RTE grid hosting (≥500 MW), land assembly (≥70% of target parcel), anchor-tenant take-or-pay (≥30% of Phase 1), and national-security clearance. Phase 0 budget: €250M–€750M (pre-engineering, land options, permitting preparation). Phase 1 (Months 12–48 = 2027-10-17 to 2030-10-17): 500 MW–1 GW energization, €5B–€10B capex, contingent on all four gates closing. Phase 2 (Months 48+): 2+ GW expansion. Project viability depends on external decisions uncontrolled until Month 6–12 (2027-04-17 to 2027-10-17): RTE connection offer, French permitting and compulsory-acquisition process, tenant commitment upgrades from non-binding LOI to signed take-or-pay, and ANSSI national-security review.

## Key Risks and Uncontrolled Gates

### RTE Grid Hosting Capacity

RTE connection above 1 GW is the primary kill condition. No formal offer exists; pre-engineering is at-risk spend (€50M–€150M estimate) without guarantee. RTE's multi-tranche allocation policy is unconfirmed. Competing decarbonization projects (steel, hydrogen, refinery) may saturate regional transmission. If RTE offers <500 MW in first tranche or conditions service on >15% annual curtailment, Phase 1 cannot proceed at planned scale.

## Anchor-Tenant Demand

Phase 0 distinguishes non-binding letters of intent (advisory only) from binding take-or-pay term sheets (capacity reserved, payment fixed). Global hyperscalers compare 10+ European sites; LOIs are non-exclusive and contingent. Sovereign AI tenants (French State, EU) have 18–36 month procurement cycles and may use LOI as position-holding. If Phase 0 closes without signed take-or-pay for ≥30% of Phase 1 (300 MW on 1 GW plan), debt financing fails.

## Land Assembly and Topology

161 km² contiguous assembly is acknowledged as doubtful, not verified. Topology decision deferred to Month 4 (2027-02-17) leaves 8 months for split-campus design (2–3 nodes: Cambrai, Dunkirk, Valenciennes) before Phase 0 gate. Late topology pivot forces €200M–€500M design rework and 6–12 month schedule slip. Tenant workload span-ability across nodes (latency tolerance for tightly coupled training) not yet validated.

## National Security

ANSSI review timeline (6–12 months, unverified) and findings (data-residency zones, tenant-access restrictions, state observer roles) are uncontrolled. Foreign co-investor involvement may trigger sovereignty scrutiny delaying or blocking Phase 1 FID. If classified as critical infrastructure, ongoing state oversight costs 5–10% opex (€50M–€500M annually at scale). Tenants may refuse commitment pending regulatory clarity.

## Phase 0 Sunk Cost and Investment Committee Independence

Phase 0 sunk cost (€250M–€750M) will pressure Phase 1 continuation despite gate failures unless investment committee is formally hardened with written charter, numeric thresholds and veto authority in Month 1 (2026-11-17). Without formality, board-level review defaults to sunk-cost momentum.

## Power Procurement

Assumed €50–70/MWh multi-GW nuclear-backed supply is unverified. EDF multi-year contract to private AI developer is unprecedented. 20–40% cost overrun would reduce IRR by 2–4 percentage points. No binding supply agreement anticipated until Phase 1 FID, leaving power cost at risk.

## Phase 0 Critical Path (Months 0–12 = 2026-10-17 to 2027-10-17)

- Month 0 (2026-10-17): Project authorization. Initiate formal RTE pre-engineering dialogue and confidential ANSSI white-paper commission.
- Month 1 (2026-11-17): Establish Investment Committee Charter (composition, voting, numeric kill thresholds, veto authority). Commission external red team and independent power-market study.
- Month 2 (2026-12-17): Topology preliminary options analysis. Formal ANSSI pre-submission meeting. RTE multi-tranche feasibility dialogue.
- Month 3 (2027-01-17): Contiguous-assembly go/no-go (≥70% of target parcel optioned at <15% above benchmark). Tenant-term-sheet templates (high-commitment take-or-pay and capacity-reservation fee). EDF preliminary LOI discussion.
- Month 4 (2027-02-17): Topology decision finalized (contiguous or split-campus). Detailed capex and per-MW cost per scenario. Tenant latency tolerance solicited.
- Months 5–6 (2027-03-17 to 2027-04-17): Permitting file preparation (single-square or per-node filings). EDF formal supply negotiations. ANSSI security governance roadmap.
- Months 7–9 (2027-05-17 to 2027-07-17): Non-binding LOI collection from tenants (advisory only). RTE hosting-capacity audit published. Permitting file submission (if targeted for Month 9–10 = 2027-07-17 to 2027-08-17 gate).
- Month 9 (2027-07-17): Anchor-tenant binding term sheets due (≥30% of Phase 1, ≥300 MW capacity). EDF preliminary supply agreement (non-final but term-sheet level) or commitment to finalize by Month 18 (2028-04-17).
- Month 12 (2027-10-17): Phase 0 gate review. RTE firm connection offer for ≥500 MW, land assembly ≥70%, anchor-tenant take-or-pay ≥30%, ANSSI clearance pathway confirmed. Phase 1 FID decision.

## Gate Criteria and Kill Thresholds

### RTE Grid Hosting (Month 6 = 2027-04-17)

RTE preliminary feasibility letter confirming ≥500 MW available within 36 months. If not in hand, trigger topology review toward split-campus model.

### Land Assembly (Month 3 = 2027-01-17)

≥70% of target parcel under non-coercive option at <15% above benchmark land value. If not achieved, default to split-campus.

### Anchor-Tenant Take-or-Pay (Month 9 = 2027-07-17)

Signed agreements totalling ≥300 MW (30% of 1 GW) with minimum A−/BB+ credit rating (not LOI). If <30% signed, reduce Phase 1 to 250–500 MW matching committed demand.

### National Security (Month 18 = 2028-04-17)

ANSSI formal clearance or conditional letter by Month 18 (2028-04-17). If not cleared by Month 18 (2028-04-17), Phase 1 FID conditional on authority indication clearance will complete within 6 months; otherwise deferred.

### Power Procurement (Month 9 = 2027-07-17)

Binding preliminary supply agreement with EDF for ≥500 MW at capped price, or documented commitment to finalize by Month 18 (2028-04-17). Define power-cost breakeven threshold above which Phase 2 expansion defers.

## Sensitivity and Downside Scenarios

### Topology Pivot

If contiguous assembly fails by Month 9 (2027-07-17): pivot to two-node model (Cambrai 500 MW + Dunkirk 250 MW), Phase 1 redesign adds 6–12 months, per-MW capex increases 5–10% (€250M–€500M), carrying costs €300M–€600M, energization shifts to Month 42–54 (2030-04-17 to 2031-04-17).

### RTE Capacity Constraint

If RTE offers only 500 MW (50% of 1 GW baseline): Phase 1 capex falls from €5B–€10B to €2.5B–€5B, but margin compresses if fixed costs are unscaled. If RTE delays offer to Month 48 (2030-10-17): Phase 1 slips 12 months, carrying costs €200M–€400M, tenant demand certainty erodes.

### Anchor-Tenant Shortfall

If only 200 MW signed by Month 9 (2027-07-17) (20% scenario): debt availability falls to €2B–€3B, forcing equity shortfall or €1.5B–€2B Phase 1 capex reduction. If no binding commitments materialize (0% scenario): Phase 1 does not proceed; project pivots to Phase 0 completion only (land options, grid pre-engineering held).

### National Security Delay

If ANSSI review extends to Month 18–24 (2028-04-17 to 2028-10-17): Phase 1 FID delayed 6–12 months, co-investor capital renegotiated (+2–4 month additional delay), energization shifts to Month 42–60 (2030-04-17 to 2031-10-17), carrying costs €300M–€700M. If ANSSI restricts foreign tenants: addressable market shrinks, anchor-tenant pool reduced.

### Power Cost Escalation

If power cost escalates from €70/MWh to €100/MWh: opex increases €300M–€600M annually at full 9 GW scale, IRR reduces 2–4 percentage points. If power not contracted at Phase 1 FID: lenders demand spreads 200–300 bps (vs. 100–200 bps) or 50% leverage (vs. 60%), adding €140M–€300M annual interest.

## Phase 1 FID Prerequisites (Month 12 = 2027-10-17 Decision Point)

Phase 1 FID proceeds only if all gates close:

- RTE firm connection offer for ≥500 MW within 36 months (or pathway to higher tranches confirmed).
- ≥70% of target parcel under option or secured, or split-campus nodes 80%+ optioned.
- Signed anchor-tenant take-or-pay covering ≥30% of Phase 1 capex at ≥300 MW, with A−/BB+ credit minimum.
- ANSSI clearance pathway confirmed (formal preliminary opinion, no blocking concerns identified).
- EDF preliminary supply agreement ≥500 MW at capped price, or finalization commitment within 6 months post-FID.
- Permitting file submitted and on track for decision within 24–30 months (fast-track path assumed).

If any gate fails by Month 12 (2027-10-17), Phase 1 is cancelled, downsized to <500 MW, deferred 6–12 months pending gate resolution, or redesigned as split-campus.

## Contingency: Phase 0 Completion Without Phase 1

If gates fail by Month 12 (2027-10-17), Phase 0 is completed at cost (€250M–€750M sunk), yielding:

- Land options held (2–3 year renewal strategy).
- Grid pre-engineering reports (RTE feasibility studies, topology analysis).
- Permitting file prepared (ready to resubmit when feasibility improves).
- Tenant demand signals (LOI archive, term-sheet templates).
- Security governance framework (ANSSI-cleared operational policies).

These assets position a restart in Month 18–24 (2028-04-17 to 2028-10-17) if external conditions improve (RTE capacity opens, land assembly advances, tenant consolidation sharpens).

## Key Deliverables and Accountability

- Investment Committee Charter signed by all sponsors and co-investors (Month 1 = 2026-11-17). Composition, voting rules, numeric kill thresholds, veto authority, public disclosure of dissent.
- External Red Team report (monthly, Months 1–12 = 2026-11-17 to 2027-10-17). Independent pass/fail opinion on each gate criterion.
- RTE Hosting-Capacity Audit (third-party, Month 9 = 2027-07-17). Findings published to lenders and co-investors.
- Topology Decision Document (Month 3 = 2027-01-17). Single-square or split-campus, with per-node capex, grid-connection timelines, per-MW costs.
- Anchor-Tenant Term-Sheet Templates (Month 3 = 2027-01-17). High-commitment take-or-pay lease (5–10 year tenor) and capacity-reservation fee (€10M–€50M per 100 MW, credited against future revenue).
- ANSSI Preliminary Opinion (Month 6 = 2027-04-17, confidential). Indicative scope, timeline, blocking concerns.
- Power-Market Study and EDF Preliminary LOI (Month 3 = 2027-01-17). Baseload pricing forecast and EDF intent to discuss binding 500 MW contract at capped EUR/MWh.
- Permitting File (single or per-node, Month 8–9 = 2027-06-17 to 2027-07-17). Submitted on track for 24–30 month decision timeline.
- Phase 0 Gate Summary (Month 12 = 2027-10-17). Formal pass/fail on all five gates, stranded-asset analysis, Phase 1 FID recommendation or deferral/downsize rationale.

## Critical Success Factors

1. Investment committee independence established in Month 1 (2026-11-17) with written charter and veto authority; sunk cost does not override gate thresholds.
2. Topology decision locked by Month 3 (2027-01-17); late pivots are design-rework risk.
3. RTE formal dialogue initiated in Month 0 (2026-10-17); preliminary feasibility letter in hand by Month 6 (2027-04-17).
4. Anchor-tenant term-sheet signatures (not LOI) by Month 9 (2027-07-17); ≥30% (300 MW) minimum for debt credibility.
5. Land assembly verification by Month 3 (2027-01-17); contiguous or split-campus decision triggers node-level permitting separation.
6. ANSSI clearance pathway confirmed by Month 6 (2027-04-17); no surprises at Phase 1 FID.
7. EDF supply agreement pathway locked by Month 9 (2027-07-17); power cost risk quantified and tenants invoiced at actual contracted price.
8. Public red-team accountability and gate transparency; lenders and co-investors see committee dissent and underlying rationale, not just approvals.

## Phase 1 and Beyond (Months 12–120 = 2027-10-17 to 2036-10-17)

Phase 1 FID (Month 12–13 = 2027-10-17 to 2027-11-17, contingent on all gates) leads to Phase 1 build (Months 13–36 = 2027-11-17 to 2029-10-17) and energization (Month 36–48 = 2029-10-17 to 2030-10-17). Phase 1 capacity: 500 MW–1 GW (contingent on RTE offer, land assembled, and tenant anchors). Phase 2 FID (Month 36–48 = 2029-10-17 to 2030-10-17) contingent on Phase 1 operational performance and ≥50% of Phase 2 demand committed. Ultimate scale: 9 GW across 10 years (Months 0–120 = 2026-10-17 to 2036-10-17).