## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers (grid hosting, capital staging, anchor tenants, permitting and social license, and gate governance) cover the core tensions: power availability against speculative queue position, capital protection against losing parcels and queue slots, demand certainty against the sovereignty burden, speed against legitimacy, and enforceable kill criteria against sponsor momentum. High levers cover land, topology, power pricing and cooling. No lever addresses water-resource or local-government political alignment directly.

### Decision 1: Grid Hosting Capacity and Transmission Sequencing
**Lever ID:** `243dfe72-0108-4feb-89cf-1eac4b87f3c2`

**The Core Decision:** Determines how much RTE connection capacity the campus can credibly hold and when. Scope covers queue position, tranche sizing, 400 kV substation pre-engineering and reinforcement cost-sharing. Key metrics: contractually confirmed MW per tranche (uncontrolled until RTE signs a connection offer), months from request to energization, at-risk study spend, and curtailment hours accepted. Hosting capacity above about 1 GW is the primary kill test.

**Why It Matters:** Sets how the project secures RTE connection capacity: queue position, tranche size, and dedicated 400 kV substations. Early large reservations create grid-queue exposure and political resistance from other industrial users. Staged, flexibility-conditional connections lower the headline power available in the early years but are more credible with RTE.

**Strategic Choices:**

1. File a full multi-GW connection request early to secure queue position, and fund studies and substation pre-engineering at risk to hold the place.
2. Request a small first tranche of 500 MW–1 GW with contractual flexibility, curtailment and BESS commitments, and use demonstrated behavior to earn later tranches.
3. Co-develop dedicated generation and storage with a regional industrial consortium to share reinforcement costs, so the campus competes for grid capacity as part of a broader reindustrialization package.

**Trade-Off / Risk:** Grid capacity above roughly 1 GW is the first failure condition, so an aggressive early filing buys position but may signal speculation to the grid operator, while flexibility concessions cost tenant uptime and revenue.

**Strategic Connections:**

**Synergy:** Amplifies Capital Staging and Commitment Structure, because tranche-based grid requests map to milestone drawdowns. Also enables Power Procurement and Price-Risk Architecture, since a firm, phased connection date lets supply contracts be sized and timed credibly.

**Conflict:** Trades off against Anchor-Tenant and Sovereignty Model, because curtailment and flexibility concessions reduce uptime tenants will pay for. Early large filings also strain Capital Staging and Commitment Structure through at-risk study and pre-engineering spend.

**Justification:** *Critical*, Hosting capacity above ~1 GW is the primary kill test. It links to Capital Staging, Power Procurement, Anchor-Tenant, Cooling and Brownfield levers, and controls the tension between early queue position and credibility with RTE. Its outcome is uncontrolled until RTE signs.

### Decision 2: Capital Staging and Commitment Structure
**Lever ID:** `fce9a355-3493-4f32-a138-458d31784f98`

**The Core Decision:** Governs how much capital is exposed before each gate, who funds it, and how EUR infrastructure is separated from USD-denominated compute. Scope covers Phase 0 funding (about €250M–€750M, an estimate to challenge), drawdown triggers, abandonment conditions, co-investor entry and FX hedging. Key metrics: maximum sunk cost at each gate, cost of capital, and share of USD exposure ring-fenced from the campus company.

**Why It Matters:** Controls how much is spent before each gate and who bears the risk, from Phase 0 exploration through Phase 1 FID. Funding Phase 0 at the developer's risk preserves optionality but can leave sunk cost if the gates fail. Involving sovereign-adjacent co-investors early adds credibility and complexity, and the USD-denominated GPU spend adds FX exposure beyond the infrastructure financing.

**Strategic Choices:**

1. Fund Phase 0 entirely from sponsor equity with no binding third-party commitments, and release further capital only after a formal gate review against pre-agreed kill criteria.
2. Raise a staged Phase 0 facility with the infrastructure-fund consortium, containing milestone-based drawdowns and pre-agreed abandonment conditions that cap sunk cost.
3. Separate the land-and-power infrastructure vehicle from the compute-hardware vehicle, so tenants or lessors carry GPU financing and USD risk while the campus company finances only EUR assets.

**Trade-Off / Risk:** Staging protects against stranded capital, but slow staged drawdowns can lose parcels and queue positions to faster competitors, and the split vehicle only works if tenants accept carrying hardware and FX exposure.

**Strategic Connections:**

**Synergy:** Enables Gate Governance, Option Value and Stranded-Asset Exit Design by making kill criteria financially binding. Pairs with Silicon Supply Chain, USD Exposure and Export-Control Posture, since a separate hardware vehicle isolates FX and export-control risk.

**Conflict:** Slow milestone drawdowns can clash with Land Rights Instruments and Farmland Displacement Bargain and Grid Hosting Capacity and Transmission Sequencing, where parcels and queue positions may be lost to faster competitors unless capital is committed early.

**Justification:** *Critical*, A central hub that sets sunk cost at each gate and separates EUR infrastructure from USD compute. It connects to grid, land, silicon, permitting, security, labor and gate levers, and governs the speed-versus-capital-protection tension. It makes kill criteria financially binding.

### Decision 3: Anchor-Tenant and Sovereignty Model
**Lever ID:** `6259a8ee-ade8-4676-8a75-cd9514a73a0d`

**The Core Decision:** Defines the demand base: who commits, under which contract form, and with what credit quality and security regime. Scope includes hyperscaler take-or-pay leases, sovereign AI zones, and reservation fees paid before construction. Key metrics: signed take-or-pay MW and its share of the next tranche (proposed 30–50% gate threshold), tenant credit rating, tenor, and time to national-security clearance. Letters of intent should not count.

**Why It Matters:** Defines who the campus serves and under which contractual form, from hyperscaler take-or-pay leases to sovereign AI zones with state involvement. This sets the rate of demand, the tenant credit quality and the national-security review burden. Foreign hyperscaler tenants bring creditworthiness but raise sovereignty and data-protection scrutiny. Sovereign tenants lower scrutiny but may have slower, politically driven procurement.

**Strategic Choices:**

1. Target two or three global hyperscalers or AI labs on multi-year take-or-pay leases, and accept the associated foreign-ownership and data-sovereignty review as a cost of access.
2. Build around a French and European sovereign-AI consortium of public-sector and domestic industrial users, with segregated high-security halls, and use hyperscalers only as secondary tenants.
3. Pre-sell capacity to a mixed tenant base through capacity reservation fees paid before construction, and refuse to start a phase until reservations cover a pre-agreed share of its cost.

**Trade-Off / Risk:** No creditworthy anchor tenants means no next-phase FID, yet tenants may use a letter of intent to compare sites without committing, so only signed take-or-pay or equivalent terms should count toward the gate.

**Strategic Connections:**

**Synergy:** Amplifies Capital Staging and Commitment Structure, since signed reservations unlock lender and co-investor funding. Also supports Security Depth, Cyber-OT Separation and Sabotage Resilience, because sovereign segregated halls justify the hardened design and its cost.

**Conflict:** Foreign hyperscaler tenants add friction with Permitting Route and Social-License Strategy by raising sovereignty and data-protection scrutiny. Sovereign-led demand may be too slow to match Grid Hosting Capacity and Transmission Sequencing and Power Procurement and Price-Risk Architecture timelines.

**Justification:** *Critical*, Demand is the foundation of the plan: no creditworthy anchor tenants means no next-phase FID. It drives financing credibility, security design, and the permitting and sovereignty burden, and it conflicts with grid and power timelines. Only signed take-or-pay should count.

### Decision 4: Permitting Route and Social-License Strategy
**Lever ID:** `556bdd12-1389-444d-b24c-adb392c44871`

**The Core Decision:** Chooses the legal and political path to build: standard ICPE and local planning, environmental authorization, or a possible national-major-project fast-track, plus how community consent is earned. Key metrics: months to final non-appealable authorization, number and outcome of legal challenges, consultation participation, and signed community-benefit terms. Fast-track availability is not confirmed (not verified), so schedule gains remain uncontrolled until a formal decision exists.

**Why It Matters:** Chooses between standard ICPE, environmental-authorization and local planning procedures and a possible national-major-project route, with parallel investment in community consent. A fast-track status could shorten timelines but may trigger backlash, legal challenges and public-debate demands. A slower local route builds legitimacy but exposes the project to prolonged opposition and shifting rules.

**Strategic Choices:**

1. Seek national-major-project or equivalent fast-track status for the anchor site, and pair it with a funded public debate and a binding community-benefit agreement.
2. Follow the standard local permitting route, run an early voluntary public consultation, and give municipalities and associations a role in monitoring, trading speed for legitimacy.
3. Make the permit application conditional on a local referendum-style consultation or citizen panel, and accept a binding outcome, including the option to withdraw from a municipality that refuses.

**Trade-Off / Risk:** Fast-track routes are still being legislated and are not confirmed in final form (not verified), so schedule benefits are uncontrolled; a community veto improves legitimacy but gives opponents a decisive lever over land and permits.

**Strategic Connections:**

**Synergy:** Strengthens Biodiversity Compensation and Ecological Continuation Ledger and Land Rights Instruments and Farmland Displacement Bargain, since visible ecological and farmer commitments feed consultation credibility and reduce appeal risk against permits.

**Conflict:** Slower, legitimacy-first routes clash with Grid Hosting Capacity and Transmission Sequencing and Capital Staging and Commitment Structure, since permit delay erodes queue timing and raises carrying costs. A community veto also gives opponents leverage over Land Rights Instruments and Farmland Displacement Bargain.

**Justification:** *Critical*, A hub connecting land, biodiversity, cooling, security, labor and tenant sovereignty scrutiny. It controls the speed-versus-legitimacy tension, and permit delay erodes grid queue timing and carrying cost. Fast-track availability is not confirmed, so schedule gains are uncontrolled.

### Decision 5: Gate Governance, Option Value and Stranded-Asset Exit Design
**Lever ID:** `4622c8e5-4170-4ed4-9403-0815393b8c12`

**The Core Decision:** Establishes who can stop, pause or resize the project, on what numeric evidence, and what value can be recovered if stopped. It turns the plan's kill criteria into enforceable decisions rather than guidelines. Metrics: independence of the decision body, pre-agreed thresholds fixed in Phase 0, share of capex recoverable or redeployable at each gate, and time between a threshold breach and a formal decision.

**Why It Matters:** Who holds the authority to stop, pause or resize the project, and what is recoverable if they do, determines whether the stated kill criteria are real. Strong independent gate authority makes cancellation credible and protects investors, but it can frustrate partners wanting momentum. Pre-designed alternate uses for land, substations and fiber reduce loss from a halted campus yet may complicate permits granted for a specific purpose.

**Strategic Choices:**

1. Vest gate decisions in an investment committee separate from the development team, with pre-agreed numeric kill thresholds (proposed thresholds, to be set in Phase 0) that trigger automatic review.
2. Keep gate authority with the sponsor’s board but commission an external red team to publish a pass or fail opinion before each gate, with dissent recorded to lenders and co-investors.
3. Design each asset from the outset for redeployment, such as substations sized for an industrial cluster and fiber open to other users, so a cancelled campus leaves recoverable regional infrastructure.

**Trade-Off / Risk:** Kill criteria carry weight only if someone with no stake in continuing can enforce them; sunk cost, partner expectations and political pressure routinely turn stated thresholds into negotiable guidelines.

**Strategic Connections:**

**Synergy:** Enables Capital Staging and Commitment Structure by tying each tranche release to enforceable gate outcomes, and reinforces Anchor-Tenant and Sovereignty Model by making signed take-or-pay commitments a hard precondition for expansion.

**Conflict:** Strong independent gate authority can clash with sponsor and co-investor momentum, and redeployable designs may constrain Permitting Route and Social-License Strategy, since permits tied to a specific purpose may not allow alternative uses of substations or land.

**Justification:** *Critical*, Decides whether the kill criteria are enforceable rather than negotiable, which is central to a skeptical plan where cancellation or downsizing is legitimate. It ties capital release and tenant commitments to gate outcomes and connects with the remediation, silicon and biodiversity levers.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Power Procurement and Price-Risk Architecture
**Lever ID:** `ba4c72c3-beee-4f19-81a5-9dace62cd7df`

**The Core Decision:** Sets the campus energy cost base, hedge structure and who carries price volatility. Scope spans nuclear-linked supply, renewable PPAs, BESS arbitrage, spot share and tenant pass-through or powered-shell sales. Key metrics: delivered EUR/MWh (to be validated), hedged share of load by phase, tenor versus debt tenor, and counterparty credit. Multi-GW nuclear-backed supply is unconfirmed, so every assumed contract is uncontrolled until signed.

**Why It Matters:** Defines how energy is bought: long-term nuclear-backed contracts, PPAs from renewables, spot exposure, or tenant pass-through. This sets the campus's cost base and its financeability. Long-term fixed prices give lenders certainty but lock in a price that may be above market. Floating exposure reduces cost if prices fall but weakens debt capacity and tenant confidence.

**Strategic Choices:**

1. Negotiate long-dated baseload contracts with nuclear-linked suppliers for the committed phase, and pass price indexation through to tenants under take-or-pay terms.
2. Blend a portfolio of nuclear-linked contracts, regional wind and solar PPAs, and BESS arbitrage, and hold a deliberate spot-exposed share to retain price upside.
3. Shift power price risk to the tenants by selling capacity as powered shell with tenant-procured energy, and keep the developer's role to the grid connection and infrastructure.

**Trade-Off / Risk:** Pricing and availability of nuclear-backed supply at multi-GW scale is not confirmed and depends on external counterparties, so any assumed contract is uncontrolled until signed; powered-shell models push risk to tenants but narrow the customer pool.

**Strategic Connections:**

**Synergy:** Reinforces Anchor-Tenant and Sovereignty Model, since indexed pass-through or fixed-price terms give tenants and lenders cost clarity. Works with Grid Hosting Capacity and Transmission Sequencing, because BESS and flexibility commitments enable arbitrage and a stronger supply story.

**Conflict:** Conflicts with Capital Staging and Commitment Structure, because long-dated take-or-pay supply creates large commitments before gates clear. A powered-shell model also narrows the pool addressed by Anchor-Tenant and Sovereignty Model.

**Justification:** *High*, Sets the energy cost base and financeability, and trades long-dated take-or-pay commitments against Capital Staging and tenant pool breadth. Important, but it depends on grid capacity being secured first, and nuclear-backed supply is unconfirmed.

### Decision 7: Cooling, Water and Heat-Reuse Design Basis
**Lever ID:** `cffc4486-9d30-4d90-819e-0b0a9298afbc`

**The Core Decision:** Fixes the thermal design basis that every hall, loop and permit application inherits. Key metrics are annual PUE against the 1.15–1.25 target, litres of freshwater per MWh, rejected-heat area per MW, and the share of heat actually contracted to users. Heat reuse should be modelled as unpriced upside until offtake is signed, with hot-weather dry-cooler performance stress-tested before the Phase 0 gate.

**Why It Matters:** Sets the thermal architecture: direct-to-chip liquid cooling, a possible immersion pilot, dry or hybrid rejection, and the extent to which waste heat is delivered to district heating or industrial users. Dry cooling cuts water exposure but raises power use and area. Heat reuse can strengthen the public narrative, but it depends on nearby heat demand and on partners' investment.

**Strategic Choices:**

1. Standardize on closed-loop direct-to-chip liquid cooling with dry coolers, and set a hard no-evaporative-water rule that accepts a PUE penalty in hot weather.
2. Allow hybrid cooling with strictly capped water use from non-potable or reclaimed industrial sources, and adopt it only if a hydrological study shows no impact on local drinking-water supply.
3. Design the campus around heat export, siting halls next to district-heating networks and industrial heat users, and treat the heat offtake agreement as a condition of site selection.

**Trade-Off / Risk:** A zero-water rule simplifies the permitting story but may cost efficiency and area; heat-reuse value depends on distant or yet-uncontracted heat users, so it should be treated as upside rather than a base-case revenue source.

**Strategic Connections:**

**Synergy:** Supports Permitting Route and Social-License Strategy, because a no-evaporative-water rule simplifies the environmental file and community messaging. Also enables Federated Node Topology and Inter-Site Latency Envelope, since heat-export proximity can favour nodes near district-heating networks.

**Conflict:** Trades off against Grid Hosting Capacity and Transmission Sequencing, because dry cooling raises peak electrical load in hot weather. Also competes with Land Rights Instruments and Farmland Displacement Bargain, since dry coolers and heat pipelines consume more land.

**Justification:** *High*, Sets the thermal design basis inherited by every hall and permit file. It trades water risk against peak grid load and land use. A no-water rule helps permitting. Heat reuse is unpriced upside, so its centrality is below the core hubs.

### Decision 8: Brownfield Liability Allocation and Remediation Sequencing
**Lever ID:** `96f83f6f-ad35-49e3-856f-98383c57ffc1`

**The Core Decision:** Allocates legacy-contamination liability (soil, groundwater, asbestos, slag, munitions residue) among developer, seller, public remediation bodies and insurers, and sets whether clean-up precedes construction. The key metrics are the bounded remediation cost range per parcel, the creditworthiness and duration of indemnities, insurability, and the months of delay to energization. Intrusive surveys are the main way to reduce uncertainty before capital is committed.

**Why It Matters:** Determines who carries soil, groundwater and legacy-industrial contamination risk (developer, seller, public remediation body, or insurer) and whether remediation precedes or runs in parallel with construction. Front-loading remediation lowers surprise cost during Phase 1 but delays energization and consumes Phase 0 cash before the gate. Back-loading it speeds the first halls but exposes later tranches to unquantified liabilities that lenders may refuse to underwrite.

**Strategic Choices:**

1. Commission intrusive soil and groundwater surveys on every candidate parcel during Phase 0, and shortlist only parcels whose remediation cost and liability can be bounded by seller indemnities or insurance.
2. Negotiate a staged liability-transfer structure in which public landowners or a remediation body retain legacy-pollution liability and the developer takes parcels only after certified clean-up of each zone.
3. Reserve the most contaminated brownfield zones as non-built energy, solar, and ecological-restoration areas, and site halls only on parcels with confirmed low remediation exposure, accepting a more fragmented layout.

**Trade-Off / Risk:** Legacy-contamination liability is the least quantifiable cost in the budget, and shifting it to sellers or public bodies only works if those counterparties have the balance sheet and legal willingness to honor indemnities over many years.

**Strategic Connections:**

**Synergy:** Feeds Capital Staging and Commitment Structure, because bounded liability makes Phase 0 spend caps and lender underwriting credible. Also supports Biodiversity Compensation and Ecological Continuation Ledger, since contaminated zones can be reassigned to restoration or energy use.

**Conflict:** Conflicts with Gate Governance, Option Value and Stranded-Asset Exit Design, because front-loaded remediation consumes pre-gate cash and sunk cost. Also slows Grid Hosting Capacity and Transmission Sequencing when clean-up delays substation siting and energization.

**Justification:** *Medium*, Legacy contamination is the least quantifiable cost and affects financeability and energization timing. However, it is mostly a parcel-level risk that is managed through surveys and indemnities. It is less of a system-wide hub than grid, capital or tenants.

### Decision 9: Land Rights Instruments and Farmland Displacement Bargain
**Lever ID:** `0e32afaf-abfc-4fd2-bc5f-c51d79487d37`

**The Core Decision:** Selects the legal route for assembling land: options, leases, exchanges or State-backed public-interest designation. It decides how contiguous the footprint can realistically be and how organised farm-sector opposition becomes. Key metrics are hectares under option versus targeted, holdout count, share of land that remains in agricultural use, average premium paid, and litigation exposure. Compulsory routes remain uncontrolled until a formal decision exists.

**Why It Matters:** Sets the legal route for assembling land: voluntary purchase, long-term lease, options, farmer-exchange schemes, or reliance on public-interest designation by the State. Voluntary routes are slower and give holdouts leverage, while public-interest routes are faster but invite political and legal challenge. The choice shapes agricultural-sector opposition and the credibility of the single-square footprint.

**Strategic Choices:**

1. Acquire land through voluntary option agreements with farmers and industrial owners, paying above-market premiums and funding relocation or land-swap packages, and drop parcels where holdouts block contiguity.
2. Structure long-term leases and revenue-sharing arrangements that let farmers keep operating the buffer and continuation zones, so that built land is only a minority of the total envelope.
3. Seek a State-sponsored planning designation for priority parcels only after a proven public-interest case and tenant commitment, accepting slower timelines and litigation exposure in exchange for contiguity.

**Trade-Off / Risk:** Voluntary assembly of a contiguous footprint of this scale is unlikely to succeed parcel by parcel, while compulsory routes depend on authorities whose decisions remain uncontrolled and can turn farmers into organized opponents.

**Strategic Connections:**

**Synergy:** Strengthens Permitting Route and Social-License Strategy, because lease-and-continue arrangements keep farmers as stakeholders rather than opponents. Also supports Biodiversity Compensation and Ecological Continuation Ledger by giving buffer and continuation zones a legal and operating basis.

**Conflict:** Constrains Federated Node Topology and Inter-Site Latency Envelope, because a contiguous core demands holdout-free parcels while federation avoids that need. Also pulls against Capital Staging and Commitment Structure, since option premiums and relocation packages spend cash before the gate.

**Justification:** *High*, Decides whether 161 km² or any adequate parcel can be assembled, which is a stated failure condition. It affects farm-sector opposition, permitting, biodiversity and topology choices, and pulls against Capital Staging. Compulsory routes are uncontrolled.

### Decision 10: Silicon Supply Chain, USD Exposure and Export-Control Posture
**Lever ID:** `cde423c2-1181-4662-9e20-fee2d9e2d490`

**The Core Decision:** Determines who buys, finances and bears obsolescence, FX and allocation risk for GPUs/TPUs and networking, which is the largest USD-denominated item in the budget. It also fixes the rack-interface standard that links tenant hardware to power density and the liquid-cooling interface. Key metrics are unhedged USD exposure, hedge coverage against signed take-or-pay, and vendor lead times. Export-control changes are an uncontrolled external risk.

**Why It Matters:** Defines how GPU/TPU and networking hardware is procured, hedged and insulated from US export-control or allocation shifts. Locking vendor allocation early secures delivery but ties large cash flows to USD and to specific suppliers. Leaving procurement to tenants shifts FX and obsolescence risk off the developer's balance sheet but reduces control over rack design, power density and the cooling interface.

**Strategic Choices:**

1. Procure shell, power and cooling infrastructure only, and require tenants to supply and finance their own accelerators and networking under standardized rack-interface specifications.
2. Run a developer-led hardware procurement arm with layered forward-contract FX hedging matched to tenant payment schedules, and a documented fallback if vendor allocation or export rules change.
3. Offer a hybrid model in which the developer finances accelerators through vendor leasing or tenant-backed equipment financing denominated in tenant currency, avoiding unhedged USD capital outlays on the developer's books.

**Trade-Off / Risk:** Hedging can only cover contracted exposure, so if hardware is bought ahead of signed tenant take-or-pay, the developer holds both FX and stranded-asset risk that no derivative removes.

**Strategic Connections:**

**Synergy:** Reinforces Anchor-Tenant and Sovereignty Model, because tenant-supplied or tenant-financed hardware aligns procurement with signed demand. Also informs Cooling, Water and Heat-Reuse Design Basis through standardized rack power and liquid-loop interface specifications.

**Conflict:** Strains Capital Staging and Commitment Structure, because developer-led purchasing ahead of signed take-or-pay breaks the no-commitment-before-gate discipline. Also conflicts with Gate Governance, Option Value and Stranded-Asset Exit Design, since bought hardware cannot be easily exited.

**Justification:** *Medium*, Governs the largest USD item and stranded-hardware risk, but much of the exposure can be shifted to tenants by structuring (powered shell, separate vehicle). It is largely resolved through Capital Staging and Anchor-Tenant choices, so it is a secondary optimization.

### Decision 11: Federated Node Topology and Inter-Site Latency Envelope
**Lever ID:** `3bbfdb09-efc9-4b36-b716-6e16fe05a115`

**The Core Decision:** Defines whether compute sits in one contiguous block or in linked industrial nodes, and what inter-node latency and bandwidth tightly coupled training tolerates. It is the structural test of the single-square assumption against a split campus. Key metrics are the maximum cluster size per node, round-trip latency between nodes, per-node grid offer, and the share of workloads that can span nodes. It should be set from tenant cluster requirements.

**Why It Matters:** Decides whether compute is concentrated in one contiguous block or spread across linked industrial nodes, and what latency and bandwidth between nodes is acceptable for tightly coupled training. A tightly clustered topology supports large training jobs but concentrates grid, sabotage and community risk. A federated topology eases land and grid constraints but may limit which workloads can span nodes.

**Strategic Choices:**

1. Design one contiguous core campus around the largest training clusters, and add satellite nodes only for inference, sovereign partitions and overflow with relaxed inter-node latency tolerances.
2. Plan a federated set of industrial-zone nodes joined by dedicated dark-fiber rings, with each node sized to its own grid connection and permitted independently so one failure does not stall the program.
3. Begin with a single node and treat the footprint as a reversible option, committing to additional nodes only if measured training workload requirements and grid offers show contiguity is unnecessary.

**Trade-Off / Risk:** Latency tolerance for tightly coupled training is a tenant-specific technical claim that has not been validated here, so choosing topology before anchor tenants state their cluster-size requirements risks optimizing for the wrong constraint.

**Strategic Connections:**

**Synergy:** Amplifies Grid Hosting Capacity and Transmission Sequencing, because nodes sized to separate grid connections can be energized and permitted independently. Also works with Fiber Route Diversity and Landing-Point Dependency, since dark-fiber rings between nodes add route diversity.

**Conflict:** Trades off against Land Rights Instruments and Farmland Displacement Bargain, since a single contiguous core needs the hardest assembly while federation fragments the layout. Also weighs on Security Depth, Cyber-OT Separation and Sabotage Resilience, because more nodes mean more perimeters and inter-site links to defend.

**Justification:** *High*, The structural test of the single-square assumption against a split campus. It affects land assembly, grid offers per node, fiber and security perimeters. It should be set from tenant cluster requirements, so it depends on the tenant lever.

### Decision 12: Fiber Route Diversity and Landing-Point Dependency
**Lever ID:** `6b841c82-7219-4f43-971d-5a723053d712`

**The Core Decision:** Defines how many physically separate, audited paths link the campus to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea landings, and who owns them. Success metrics: verified duct-level diversity (no shared conduit, bridge or landing facility), latency to each hub, time-to-light before Phase 1 energization, and cost per route-km (estimate to be validated in Phase 0). Landing-point concentration is the hidden single point of failure.

**Why It Matters:** Sets how many physically separate routes connect the campus to Paris, London, Brussels, Amsterdam, Frankfurt, Marseille and subsea landings, and whether the developer builds, leases or co-funds them. Owning routes improves control and sabotage resilience but adds trenching, rights-of-way and permitting burden. Relying on carriers is cheaper and faster but can hide shared conduits and shared failure points.

**Strategic Choices:**

1. Lease capacity from several carriers while auditing physical routes to confirm true diversity, and contractually require disclosure of shared ducts, bridges and landing facilities.
2. Build and own at least two physically separate long-haul routes (proposed threshold) along rail, canal or pipeline corridors, accepting higher capital and rights-of-way effort for sovereign control.
3. Co-invest with regional operators and a subsea cable consortium to pull new capacity into the region, which makes the campus an anchor customer that also lifts local connectivity for other users.

**Trade-Off / Risk:** Route diversity on a carrier's marketing map often collapses at shared conduits, bridges or landing stations, so the claimed resilience is unproven until physical paths are surveyed and audited.

**Strategic Connections:**

**Synergy:** Amplifies Federated Node Topology and Inter-Site Latency Envelope, since audited diverse routes make split-campus nodes behave as one fabric, and strengthens Security Depth, Cyber-OT Separation and Sabotage Resilience by reducing exposure to cable cuts.

**Conflict:** Owning routes competes for capital and rights-of-way effort with Capital Staging and Commitment Structure and adds permit burden for Permitting Route and Social-License Strategy; trenching along rail, canal or pipeline corridors can also touch ecological zones.

**Justification:** *Medium*, Important for resilience and latency, and it supports federation and security. Route diversity can be achieved through leasing, auditing or co-investment at moderate cost relative to grid, land and demand. It is not a primary feasibility determinant.

### Decision 13: Security Depth, Cyber-OT Separation and Sabotage Resilience
**Lever ID:** `32993705-a17e-4d8a-8467-96089d1f1d5c`

**The Core Decision:** Sets the depth of perimeter hardening, anti-drone layers, personnel vetting, supply-chain assurance and the logical separation of building OT (power, cooling, BMS) from tenant networks. Key metrics: red-team findings closed, time to clear national-security review, share of capacity eligible for sovereign partitions, and security cost per MW. The target posture depends on authority expectations that remain uncontrolled until formally stated.

**Why It Matters:** Determines how deep security investment goes: perimeter hardening, anti-drone systems, isolation of operational technology from tenant networks, and supply-chain vetting. A heavier posture is likely to be needed for sovereign partitions and may ease national-security review, yet it raises cost, restricts tenant access and can feed community perceptions of a militarized site.

**Strategic Choices:**

1. Apply a uniform baseline across the campus and build separate hardened enclaves only where a sovereign or defense-adjacent tenant contractually funds the additional requirements.
2. Adopt a campus-wide high-assurance posture from Phase 1, with segregated OT networks, vetted personnel and anti-drone layers, to reduce review friction and retrofit cost later.
3. Invite state security agencies and an independent red team to test the design during Phase 0, then let their findings set the security specification and decide which workloads are admissible.

**Trade-Off / Risk:** Over-hardening early inflates Phase 1 cost and community unease, while under-hardening risks failing the national-security review, and the right level cannot be known until the reviewing authorities state their expectations, which remain uncontrolled.

**Strategic Connections:**

**Synergy:** Enables Anchor-Tenant and Sovereignty Model by making sovereign or defense-adjacent partitions admissible, and supports Permitting Route and Social-License Strategy by giving reviewing authorities concrete assurance evidence.

**Conflict:** Heavy hardening raises Phase 1 cost against Capital Staging and Commitment Structure, and a militarized look can undermine Permitting Route and Social-License Strategy, while strict vetting narrows the local hiring pool in Regional Labor, Contractor and Supplier Ecosystem Strategy.

**Justification:** *Medium*, Enables sovereign partitions and supports national-security review, but its depth is largely set by tenant mix and authority expectations. It is a cost and perception trade-off that follows the Anchor-Tenant and Permitting decisions rather than driving them.

### Decision 14: Regional Labor, Contractor and Supplier Ecosystem Strategy
**Lever ID:** `2eaa085b-f6f6-4c41-9237-f174591c6e18`

**The Core Decision:** Governs sourcing of construction and operations labor, contractors, suppliers and training pipelines for a build competing for scarce electricians, mechanical and cooling trades in a region with industrial heritage. Metrics: local share of construction hours, trade wage inflation, schedule slippage from labor shortages, prompt-payment performance, and disclosed permanent operations headcount (likely small relative to the capital deployed; estimate to be validated).

**Why It Matters:** Defines how construction and operations labor is sourced for a very large build in a region with an industrial workforce, plus how local suppliers and training institutions are involved. Heavy reliance on local hiring supports social license but can hit skill shortages and wage inflation in electrical and mechanical trades. Importing specialized contractors speeds delivery but weakens the local benefit story and strains housing.

**Strategic Choices:**

1. Establish a regional training academy with technical colleges and unions for electrical, mechanical and cooling trades, tying hiring commitments to Phase 1 milestones.
2. Use a small number of large engineering and construction partners with prefabricated modular halls, minimizing on-site labor and accepting a thinner local employment share.
3. Create a local supplier consortium that pools small industrial firms into certified framework contracts for civil works, logistics, and maintenance, backed by prompt-payment guarantees.

**Trade-Off / Risk:** Local-hiring promises are easy to make but operations jobs at highly automated data centers are limited, so a social-license strategy built on employment can fail credibility tests once actual headcount is disclosed.

**Strategic Connections:**

**Synergy:** Supports Permitting Route and Social-License Strategy by supplying verifiable local-benefit evidence, and complements Brownfield Liability Allocation and Remediation Sequencing, because regional civil and remediation firms can be certified early for site works.

**Conflict:** Local-hiring commitments conflict with schedule and cost goals in Capital Staging and Commitment Structure, and security vetting in Security Depth, Cyber-OT Separation and Sabotage Resilience limits who can work on sensitive halls.

**Justification:** *Low*, Mainly an execution and social-benefit lever. Operations headcount is small, so it carries limited weight against core feasibility tensions. Its links to permitting and security are real but secondary, and it can be adjusted later in Phase 1.

### Decision 15: Biodiversity Compensation and Ecological Continuation Ledger
**Lever ID:** `d00ee3fd-835d-4f19-b2d0-9af2c8d5eb6c`

**The Core Decision:** Structures how avoidance, reduction and compensation of ecological impact are recorded and enforced, effectively fixing how much of the notional 161 km² is buildable. It determines permit predictability for later tranches versus early cash commitment. Metrics: hectares of continuation zone secured, ecological equivalence achieved, permit challenges avoided, and net farmland removed from production by compensation measures.

**Why It Matters:** The way avoidance, reduction and compensation of ecological impact is structured determines how much of the notional 161 km² can be built and how much must remain open. A site-by-site compensation approach is simple but can fragment habitats. A ledger tied to a campus-wide ecological plan costs more upfront but may make later tranche permits more predictable. Compensation land also competes with farmland in a region where agricultural displacement is already contentious.

**Strategic Choices:**

1. Compensate impacts tranche by tranche through offsite parcels bought for each permit, keeping early spend low and tying obligations to the footprint actually built.
2. Adopt a campus-wide ecological master plan with permanent continuation zones set aside at Phase 0, so every later permit draws on a pre-agreed ecological budget.
3. Co-manage compensation land with local farmers and conservation bodies as working landscapes, paying for ecological outcomes on active farmland rather than removing it from production.

**Trade-Off / Risk:** Pre-committing ecological land reduces permit uncertainty but fixes spend before demand is proven, and compensation that converts more farmland to meet one constraint can worsen the displacement problem it sits beside.

**Strategic Connections:**

**Synergy:** Strengthens Permitting Route and Social-License Strategy by giving authorities a predictable ecological budget, and pairs with Land Rights Instruments and Farmland Displacement Bargain when working-landscape compensation keeps farmland in production.

**Conflict:** Pre-committed ecological land competes with Land Rights Instruments and Farmland Displacement Bargain for the same parcels and fixes spend ahead of demand, tension with Capital Staging and Commitment Structure and Gate Governance, Option Value and Stranded-Asset Exit Design.

**Justification:** *Medium*, Determines the buildable share of the envelope and the predictability of later permits, and it interacts with farmland. It largely serves the permitting and land levers, which carry the strategic choice, so it is a supporting mechanism.
