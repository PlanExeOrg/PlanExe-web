**6 open decisions: 3 high and 3 medium severity.** The most urgent items are the Phase 1 definition (C1), the funding source for split-from-start work above the EUR 750M cap (C2), and the scope of the ~1 GW kill test (C3). They are needed by Months 1-3 (2026-11-17 to 2027-01-17), before thresholds lock at Month 2 (2026-12-17) and tranche 2 releases at Month 3 (2027-01-17). Until then the plan can safely run tranche 1 (EUR 150M): the committee charter, red team, audits, Phase I and II surveys, and the RTE, ANSSI and DREAL dialogues, with no committed capital.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Phase 1 definition and success test date | 🔴 High | Project Steering Committee, on advice of the independent investment committee | Month 1 (2026-11-17), when the committee charter is set and before thresholds are locked at Month 2 (2026-12-17). | Month 2 (2026-12-17) threshold lock, Month 9 (2027-07-17) tenant term sheets, Month 12 (2027-10-17) gate. |
| 2 | Funding split-from-start work above the EUR 750M cap | 🔴 High | Independent investment committee with consortium and lenders | Month 3 (2027-01-17), before tranche 2 (EUR 250M, Months 3-6 = 2027-01-17 to 2027-04-17) is released and before the Month 4 (2027-02-17) topology decision. | Tranche 2 release and the Month 4 (2027-02-17) topology decision. |
| 3 | What the ~1 GW grid kill test ends | 🔴 High | Gate Review and Kill Authority Committee, with sponsor and consortium | Month 2 (2026-12-17), when numeric kill thresholds are locked, and before the Month 6 (2027-04-17) RTE letter. | Month 6 (2027-04-17) RTE letter assessment and the Month 12 (2027-10-17) gate. |
| 4 | Phase 1 composition under a split campus | 🟡 Medium | Project Steering Committee, advised by the investment committee | Month 4 (2027-02-17), at the topology decision, since the RTE letter and tenant floors depend on it. | Month 4 (2027-02-17) topology lock; Month 6 (2027-04-17) RTE letter scope; Month 9 (2027-07-17) tenant gate. |
| 5 | Land gate parcel basis and price premium | 🟡 Medium | Independent investment committee | Month 2 (2026-12-17), when thresholds are fixed, and before the Month 3 (2027-01-17) land check. | Month 3 (2027-01-17) land check and the Month 4 (2027-02-17) topology decision. |
| 6 | Foreign equity versus the Month 12 (2027-10-17) equity-binding gate | 🟡 Medium | Steering Committee with consortium sponsors; ANSSI input via the Security Lead | Month 6 (2027-04-17), when the informal ANSSI opinion is due and before lender conditions are written. | Month 12 (2027-10-17) equity and debt gate; lender conditions. |

## 1. Phase 1 definition and success test date (🔴 High)

**Decision:** Is Phase 1 defined as FID (Month 12 = 2027-10-17) to first-block energization (Months 42-48 = 2030-04-17 to 2030-10-17), with success tested at the Phase 2 FID, or kept as Months 12-36 (2027-10-17 to 2029-10-17) with energization inside it?

**Why it is open:** Pitch and executive summary say 500 MW energized in Months 12-36 (2027-10-17 to 2029-10-17). Canonical permitting and schedule say energization Months 42-48 (2030-04-17 to 2030-10-17) (downside 48-60), permit decisions Months 26-39 (2028-12-17 to 2030-01-17), ANSSI clearance Months 25-31 (2028-11-17 to 2029-05-17). Stabilization at Months 54-60 (2031-04-17 to 2031-10-17) falls outside the window.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Redefine Phase 1 as Month 12 (2027-10-17) FID to Months 42-48 (2030-04-17 to 2030-10-17) energization; Months 12-36 (2027-10-17 to 2029-10-17) is the construction-start window; test success at Phase 2 FID (about Months 54-60 = 2031-04-17 to 2031-10-17). | Schedule becomes consistent with permits and ANSSI. Success is judged after 12 months of operating data. Permit-dependent works are conditional. | phase_schedule_and_capacity, pitch, executive summary timeline, success definition wording. |
| B. Keep Months 12-36 (2027-10-17 to 2029-10-17) as a hard target and compress permits, ANSSI clearance and build. | Needs fast-track status, which is not assumed. Build would start before permit decision and ANSSI clearance, so near-certain to miss. | permitting_and_schedule_realism and ANSSI timeline would need unsupported assumptions. |
| C. Split into Phase 1a (permits and enabling works, Months 12-36 = 2027-10-17 to 2029-10-17) and Phase 1b (energization, Months 42-48 = 2030-04-17 to 2030-10-17). | Clear milestones, but adds a gate and reporting layer. Tenant commitments must survive to Month 42 (2030-04-17). | Roadmap, gate list, tenant term lengths. |

- **If nobody decides:** Documents keep contradicting each other; Month 12 (2027-10-17) gate and tenant terms are written against a window that cannot be met.
- **Owner:** Project Steering Committee, on advice of the independent investment committee
- **Decide by:** Month 1 (2026-11-17), when the committee charter is set and before thresholds are locked at Month 2 (2026-12-17).
- **Blocks:** Month 2 (2026-12-17) threshold lock, Month 9 (2027-07-17) tenant term sheets, Month 12 (2027-10-17) gate.

## 2. Funding split-from-start work above the EUR 750M cap (🔴 High)

**Decision:** If split campus becomes the Month 4 (2027-02-17) default, how is Phase 0 per-node work (up to EUR 250M over the EUR 750M hard cap) funded?

**Why it is open:** The cap is hard, and split is the default at Month 4 (2027-02-17). Split from the start adds EUR 100M-250M to Phase 0. Reviews book the EUR 250M-500M premium as a Phase 0 problem, though it is Phase 1 capex. Tranche 2 (Months 3-6 = 2027-01-17 to 2027-04-17) starts before the Month 4 (2027-02-17) topology decision.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Lender and co-investor approved cap increase. | Cap rises by up to EUR 250M. Breaks the 'hard cap' commitment and needs consortium consent. | phase0_budget_cap, phase0_tranche_caps. |
| B. Cut scope to stay inside EUR 750M. | Some per-node surveys and permit preparation are thinner. Higher risk at the Month 12 (2027-10-17) gate. | Phase 0 scope, tranche allocations. |
| C. Defer per-node validation until after the Month 12 (2027-10-17) gate. | Cap holds, but the Month 12 (2027-10-17) gate rests on less node evidence. Phase 1 FID may slip 3-6 months. | Gate evidence list, schedule. |

- **If nobody decides:** The EUR 750M cap holds by default. Tranche 2 is released unsplit or frozen, and split-node work stalls after Month 4 (2027-02-17).
- **Owner:** Independent investment committee with consortium and lenders
- **Decide by:** Month 3 (2027-01-17), before tranche 2 (EUR 250M, Months 3-6 = 2027-01-17 to 2027-04-17) is released and before the Month 4 (2027-02-17) topology decision.
- **Blocks:** Tranche 2 release and the Month 4 (2027-02-17) topology decision.

## 3. What the ~1 GW grid kill test ends (🔴 High)

**Decision:** Does failing the 'path to more than ~1 GW cumulative' test end only the 9 GW ambition (Phase 2+), or also Phase 1?

**Why it is open:** The ~1 GW test is the primary kill test, but the Phase 1 gate is only a 500 MW letter. A project can pass Month 12 (2027-10-17) with 500-999 MW and still meet the failure definition. A 750 MW downsize trigger appears in one review only. A shortfall leads to downsize, split, re-baseline or cancel, depending on the document.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Two separate tests: a 500 MW letter gates Phase 1; failing the >1 GW path ends Phase 2+ (single node or cancel). | Phase 1 can proceed at 500-999 MW. The 9 GW ambition is explicitly ended on failure. Needs one consequence table. | grid_kill_test, rte_phase1_gate, governance matrix. |
| B. Failing >1 GW path cancels the whole project. | Strictest reading of the user's failure definition. Avoids stranded Phase 1 assets, but stops a viable 500 MW node. | Kill criteria, Phase 1 gate. |
| C. Failure triggers a downsize to 250 MW with an early-warning level (for example 750 MW) as a proposed threshold. | Preserves some option value. Adds a threshold with no source. | curtailment_limits, Phase 1 base case, debt sizing. |

- **If nobody decides:** The Month 6 (2027-04-17) RTE letter is read only as a 500 MW test. The kill response is argued case by case, which invites sunk-cost override.
- **Owner:** Gate Review and Kill Authority Committee, with sponsor and consortium
- **Decide by:** Month 2 (2026-12-17), when numeric kill thresholds are locked, and before the Month 6 (2027-04-17) RTE letter.
- **Blocks:** Month 6 (2027-04-17) RTE letter assessment and the Month 12 (2027-10-17) gate.

## 4. Phase 1 composition under a split campus (🟡 Medium)

**Decision:** If split campus is the default, is Phase 1 a fixed 500 MW total across nodes, or one 500 MW Cambrai node with the others deferred to Phase 2?

**Why it is open:** Canonical Phase 1 is 500 MW at one node (Cambrai/E-Valley). Nodes are listed as Cambrai 500 MW, Dunkirk 250 MW and Valenciennes 250 MW. The RTE tripwire of <500 MW per node cannot be met by a 250 MW node. The 30% tenant base, EUR 3B debt and EUR 10B ceiling depend on the answer.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Phase 1 is 500 MW in total, split across nodes (for example 250+250). | RTE letters are needed per node, and the premium of EUR 250M-500M applies. Two sets of permits and land options. | phase1_base_case, rte_phase1_gate, land and debt gates. |
| B. Phase 1 is a single 500 MW Cambrai node; other nodes are Phase 2 candidates. | Simplest gates and the 150 MW tenant floor. Heavy dependence on one site and on RTE. | topology_decision_rule, project goal. |
| C. Phase 1 is 250 MW at the lead node. | About EUR 2.5B, delay 12-24 months. Lower risk, slower scale. | Phase 1 size, debt target, tenant minimum (75 MW). |

- **If nobody decides:** Gates stay ambiguous; the Month 4 (2027-02-17) topology decision cannot set per-node RTE, tenant and debt tests.
- **Owner:** Project Steering Committee, advised by the investment committee
- **Decide by:** Month 4 (2027-02-17), at the topology decision, since the RTE letter and tenant floors depend on it.
- **Blocks:** Month 4 (2027-02-17) topology lock; Month 6 (2027-04-17) RTE letter scope; Month 9 (2027-07-17) tenant gate.

## 5. Land gate parcel basis and price premium (🟡 Medium)

**Decision:** Does the 70% option test apply to the Phase 1 node (about 900 ha) plus an expansion option, or to the full 161 km² square, and is the price ceiling 1.15x benchmark?

**Why it is open:** The gate is 70% at no more than 15% above benchmark. The full square is 16,100 ha (EUR 0.24B-0.40B). Review 14 prices relocation at 1.5-2.0x benchmark, which fails the gate and mixes 1.0x and 2.0x arithmetic.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Target parcel is the Phase 1 node plus an option on the expansion reserve; cost land at up to 1.15x. | Achievable by Month 3-4 (2027-01-17 to 2027-02-17). Per-node land is about EUR 15.5M-25.9M (recomputed). 1.5-2.0x is the failure case that triggers the split. | topology_decision_rule, land_option_gate, Review 14. |
| B. Target parcel is the full square. | Almost certain to fail at Month 4 (2027-02-17), which forces the split. Land spend stays under EUR 60M before Month 4 (2027-02-17). | land_option_gate. |
| C. Allow a higher premium (up to 2.0x) for Phase 1 land. | Raises cost to EUR 45M per node and weakens the non-coercive claim. Risks community backlash. | Land gate threshold, budget. |

- **If nobody decides:** The gate is run against the full square and fails at Month 4 (2027-02-17), so split campus follows by default.
- **Owner:** Independent investment committee
- **Decide by:** Month 2 (2026-12-17), when thresholds are fixed, and before the Month 3 (2027-01-17) land check.
- **Blocks:** Month 3 (2027-01-17) land check and the Month 4 (2027-02-17) topology decision.

## 6. Foreign equity versus the Month 12 (2027-10-17) equity-binding gate (🟡 Medium)

**Decision:** What share of the EUR 2.0B Phase 1 equity may be foreign, and who backstops it if it cannot be bound before ANSSI clearance?

**Why it is open:** Foreign co-investor equity cannot be bound at FID before clearance (about Months 25-31 = 2028-11-17 to 2029-05-17). The Month 12 (2027-10-17) gate requires equity sources bound. The investor profile includes sovereign-adjacent co-investors, and the foreign share is not stated.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Backstop with EU-domiciled non-controlling co-investors or sponsor equity. | Equity can be bound at Month 12 (2027-10-17). Narrows the investor pool and may raise cost of capital. | debt_financing_gate, investor structure. |
| B. Accept conditional foreign commitments at the gate, subject to ANSSI. | Month 12 (2027-10-17) gate is conditional. Lenders may reject conditional equity, which risks the EUR 3B debt. | Gate wording, financing terms. |
| C. Defer equity binding until clearance, so FID moves to about Month 24-30 (2028-10-17 to 2029-04-17). | Tenant and lender commitments may lapse. Carrying costs rise. | Phase 1 FID date, schedule. |

- **If nobody decides:** The Month 12 (2027-10-17) equity gate cannot be met by foreign capital, and FID is deferred or the gate is read as failed.
- **Owner:** Steering Committee with consortium sponsors; ANSSI input via the Security Lead
- **Decide by:** Month 6 (2027-04-17), when the informal ANSSI opinion is due and before lender conditions are written.
- **Blocks:** Month 12 (2027-10-17) equity and debt gate; lender conditions.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Grid hosting capacity and transmission sequencing | Request a small first tranche of 500 MW-1 GW with flexibility, curtailment and BESS commitments, then earn later tranches. | File a full multi-GW request early to secure queue position, funded at risk. | It sets the exposure to the ~1 GW kill test and the RTE queue risk. | Month 6 (2027-04-17), RTE letter. |
| Capital staging and commitment structure | Staged Phase 0 facility with the consortium, milestone drawdowns and pre-agreed abandonment conditions. | Fund Phase 0 entirely from sponsor equity with no third-party commitments. | It caps sunk cost but gives lenders and co-investors a say in the cap and gates. | Month 3 (2027-01-17), before tranche 2. |
| Anchor-tenant and sovereignty model | Pre-sell to a mixed tenant base with reservation fees paid before construction. | Sovereign-AI consortium anchor with hyperscalers as secondary tenants. | It sets demand scale, ANSSI exposure and the foreign-equity question. | Month 9 (2027-07-17), tenant gate. |
| Permitting route and social-license strategy | Standard local permitting route with early voluntary consultation and a municipal monitoring role. | Fast-track national status, or a binding local referendum-style consultation. | It sets the 18-30 month permit timeline and the energization date. | Month 9 (2027-07-17), DREAL opinion. |
| Gate governance and stranded-asset exit design | Independent investment committee with numeric kill thresholds and automatic review. | Sponsor-board authority with an external red-team opinion, or assets designed for redeployment. | It decides whether kill criteria hold under sunk-cost pressure. | Month 1 (2026-11-17), charter; Month 12 (2027-10-17) gate. |
