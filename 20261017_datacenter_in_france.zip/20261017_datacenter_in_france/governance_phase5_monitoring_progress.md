### 1. Gate Criterion Status Tracking and Numeric Threshold Validation
**Monitoring Tools/Platforms:**

  - Gate Review and Kill Authority Committee monthly pass/fail reports
  - External red-team assessment dashboard (grid, land, tenants, financing, social license)
  - Phase 0 milestone tracking spreadsheet (gate deadlines, evidence receipt dates)
  - RTE hosting-capacity audit and preliminary letter repository

**Frequency:** Monthly (Months 0–12 = 2026-10-17 to 2027-10-17), formal gate assessment Months 3, 6, 9, 12 (2027-01-17, 2027-04-17, 2027-07-17, 2027-10-17)

**Responsible Role:** Gate Review and Kill Authority Committee (Independent Chair, independent external directors, with External Red Team providing pass/fail opinions); escalates to Project Steering Committee if threshold breach occurs

**Adaptation Process:** Monthly red-team reports assess each of five gate criteria (grid hosting ≥1 GW cumulative, land ≥70% optioned, tenants ≥30% signed, debt ≥EUR 3B, social license ≥2 municipalities) against published numeric thresholds. If any criterion shows High-likelihood breach, the committee issues a formal gate-status report within 5 working days to the Steering Committee and recommends one of: (i) Phase 1 FID approval (all thresholds met), (ii) conditional approval pending resolution, (iii) Phase 1 downsizing (e.g., 250 MW if tenants <30%), (iv) Phase 1 deferral, or (v) project exit. The Steering Committee votes within 5 working days; approval requires two-of-three alignment (sponsor, consortium, independent director). Override of the Kill Authority Committee's recommendation triggers mandatory dissent disclosure to lenders and co-investors within 2 working days.

**Adaptation Trigger:** Specific numeric breaches at defined deadlines: (i) RTE preliminary feasibility letter not received or hosting capacity <500 MW by Month 6 (2027-04-17); (ii) <70% of chosen parcel optioned non-coercively at <15% above benchmark by Month 4 (2027-02-17); (iii) <30% signed anchor-tenant take-or-pay by Month 9 (2027-07-17); (iv) debt commitment <EUR 3B or unacceptable terms by Month 12 (2027-10-17); (v) <2 of 3 municipalities' written support by Month 12 (2027-10-17). Any single breach triggers formal escalation; multiple breaches may recommend Phase 1 cancellation or major restructuring.

### 2. Grid Hosting Capacity and RTE Connection Engagement Tracking
**Monitoring Tools/Platforms:**

  - RTE pre-submission dialogue log (letters, meeting minutes, submitted requests)
  - Independent RTE hosting-capacity audit report (Month 9 = 2027-07-17 deliverable)
  - Grid reinforcement cost-estimate tracker (phase reinforcement, substation siting, timeline impact)
  - Connection-offer timeline and queue-position monitoring spreadsheet

**Frequency:** Bi-weekly PMO Grid and Power Lead + RTE liaison; monthly summary to Steering Committee; formal RTE letter or written evidence due Month 6 (2027-04-17); audit published Month 9 (2027-07-17)

**Responsible Role:** PMO Grid and Power Lead, with Independent RTE Hosting-Capacity Auditor, RTE liaison counsel; reports to Gate Review Committee monthly and Steering Committee quarterly

**Adaptation Process:** Grid hosting capacity findings feed directly into topology decision (Month 4 = 2027-02-17): single square only if RTE written evidence confirms ≥1 GW to that node; otherwise split-campus default. If RTE's preliminary letter (due Month 6 = 2027-04-17) shows hosting below 500 MW, the Kill Authority Committee recommends split-campus topology pivot or Phase 1 capacity downsize to 250 MW. If RTE offers favorable tranche-based terms (500 MW + 1 GW pathway), power-procurement strategy (EDF negotiations) and tenant-acquisition targets are confirmed as achievable; if terms are restrictive (>15% curtailment, extended connection timelines), lease pricing and BESS strategy are adjusted. If transmission-reinforcement cost-share exceeds budget (EUR 1.5B threshold), the Steering Committee decides whether to accept the cost as Phase 1 capex or request RTE cost-share under a co-development agreement.

**Adaptation Trigger:** RTE preliminary feasibility letter not received or capacity <500 MW by Month 6 (2027-04-17) → kill criterion breached, recommend split-campus or downsize. RTE timeline slips >6 months beyond Month 6 (2027-04-17) → Steering Committee reassesses Phase 0 and Phase 1 schedule, triggers deferral or topology re-evaluation. Transmission reinforcement cost >EUR 1.5B or timeline >48 months (2030-10-17) → cost-share negotiation or Phase 1 capacity reduction. Curtailment requirement >15% annual → walk-away trigger per power-strategy framework, Phase 1 reduced to 500–750 MW or less.

### 3. Land Assembly and Parcel Acquisition Feasibility Validation
**Monitoring Tools/Platforms:**

  - Parcel-by-parcel land survey and ownership-chain map (Phase 0 Month 3 = 2027-01-17 deliverable)
  - Option agreement tracking spreadsheet (% parcels optioned, expiry dates, holdout locations)
  - Phase I and Phase II environmental site assessment reports (contamination findings, remediation-cost bounds)
  - Land-assembly feasibility assessment report (Month 3 = 2027-01-17 and Month 4 = 2027-02-17 and 2027-02-17 decisions)

**Frequency:** Monthly land-assembly lead updates to PMO; formal feasibility assessments Month 3 (2027-01-17) and Month 4 (2027-02-17); Phase II ESA findings by Month 3 (2027-01-17); topology decision locked Month 4 (2027-02-17)

**Responsible Role:** PMO Land Assembly Lead (with real-estate counsel), supported by Phase II ESA survey teams and municipal land-registry liaisons; escalates to PMO and Steering Committee if >30% of target parcel cannot be optioned or remediation exceeds EUR 100M per site

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17) land survey ranks candidate sites by assemblability, holdout risk and land cost. By Month 3 (2027-01-17), if ≥70% of the single-square parcel is optioned non-coercively at <15% above benchmark, the single square remains viable and Phase I ESA focuses on that core. If single-square assemblability falls short of 70%, split-campus topology is developed as the default: Cambrai ~500 MW node validated at ≥80% optioned, Dunkirk ~250 MW, Valenciennes ~250 MW each assessed separately. Phase II contamination findings (Month 3 = 2027-01-17) rule out sites with remediation >EUR 100M (propose bounding); shortlisted parcels have seller indemnity or public-remediation-body liability assumption negotiated. If holdout clusters (e.g., families refusing to relocate) block >20% of a primary site, the parcel is substituted or the node capacity is reduced. If Phase II finds unexpected contamination during Phase 1 construction, remediation costs exceeding the Phase 1 contingency (EUR 100M–300M) trigger debt-covenant escalation.

**Adaptation Trigger:** <70% of single-square parcel optioned or remediation >EUR 100M per site by Month 4 (2027-02-17) → split-campus topology forced, Phase 0 extended 3–6 months, Phase 0 spend escalates to EUR 750M. >20% of target parcel blocked by holdouts → parcel substitution or node-capacity downsize. Phase II contamination discovery after Phase 0 gate (Phase 1 construction) exceeding contingency → litigation risk, remediation delay 6–18 months, carrying cost EUR 200M–500M, Phase 1 FID contingent on revised liability allocation.

### 4. Anchor-Tenant Demand and Take-or-Pay Acquisition Tracking
**Monitoring Tools/Platforms:**

  - Tenant pipeline dashboard (LOI vs. binding term sheet status, credit validation, reservation-fee receipts)
  - Take-or-pay lease term sheets and capacity reservations log (signed agreements, MW reserved, tenor, price)
  - Tenant workload and cluster-size specifications (used to validate latency tolerance for split-campus architecture)
  - Reservation-fee payment tracking (EUR 10M–50M per 100 MW, crediting against future rent)

**Frequency:** Bi-weekly tenant sourcing updates; monthly pipeline status to PMO and Steering Committee; formal binding term-sheet deadline Month 9 (2027-07-17); reservation-fee payment confirmation by Month 12 (2027-10-17)

**Responsible Role:** PMO Tenancy and Revenue Lead (with commercial advisers and legal counsel); escalates to Gate Review Committee if signed take-or-pay falls below 30% of Phase 1 target by Month 9 (2027-07-17)

**Adaptation Process:** Tenant sourcing targets 2–3 global hyperscalers (A−/A+ credit) and 2–3 sovereign/European anchors (sovereign guarantee or A−/BBB+ parent) in parallel. Non-binding LOIs collected Month 3–6 (2027-01-17 to 2027-04-17) are tracked for engagement momentum but not counted toward the 30% gate criterion. Binding term sheets (5–10 year lease, capacity reserved, reservation fee EUR 10M–50M per 100 MW paid upfront) are required by Month 9 (2027-07-17); only signed agreements count. If signed take-or-pay reaches only 20% of Phase 1 (200 MW on 1 GW base) by Month 9 (2027-07-17), the Kill Authority Committee recommends Phase 1 downsize to 250–500 MW matching actual committed demand, extending Phase 1 FID to Month 18–24 (2028-04-17 to 2028-10-17) pending demand maturation. Lease price (EUR 1.1M per MW-year, non-energy) and SLA terms (99.5% uptime, curtailment carve-out to 10% annual) are confirmed in term sheets; pass-through energy indexation anchors tenants to realized EUR/MWh cost. If a committed anchor tenant requests a 10% price discount (e.g., to offset perceived curtailment risk), debt service coverage falls from 1.34x to 1.15x, requiring equity cure or debt reduction (proposed structural adaptation: negotiate curtailment exclusion rather than price discount).

**Adaptation Trigger:** <30% signed take-or-pay (i.e., <150 MW on 500 MW base, <300 MW on 1 GW base) by Month 9 (2027-07-17) → Phase 1 downsize to 250–500 MW or Phase 1 FID deferral 6–12 months. >20% anchor-tenant lease-price-discount requests → DSCR <1.30x, triggers debt restructuring or Phase 1 downsize. Any anchor-tenant non-renewal or early-termination signal during Phase 1 construction → revenue risk flagged, replacement-tenant sourcing accelerated, potential phase-advance slippage if replacement not secured within 6 months.

### 5. Power Procurement and EDF Supply Contract Negotiation Tracking
**Monitoring Tools/Platforms:**

  - EDF engagement log and LOI/term-sheet tracker (non-binding LOI by Month 6 = 2027-04-17, term sheet by Month 9 = 2027-07-17)
  - Power-market study and EUR/MWh pricing forecast (assumed EUR 50–70/MWh range, stress test at +EUR 30/MWh)
  - BESS and demand-flexibility feasibility assessment (50–200 MWh, cost estimate, grid-interaction modeling)
  - Energy cost pass-through agreement templates and pricing-indexation schedule (annual CPI+X% formula)

**Frequency:** Monthly Grid and Power Lead updates to PMO; EDF LOI due Month 6 (2027-04-17); term sheet and pricing locked Month 9 (2027-07-17); binding contract not before Phase 1 FID (Month 12 = 2027-10-17 conditional)

**Responsible Role:** PMO Grid and Power Lead (with independent power-market adviser, EDF liaison); escalates to Steering Committee if EDF terms are unavailable or pricing exceeds EUR 100/MWh (proposed stress threshold)

**Adaptation Process:** Weeks 1–8 of Phase 0 (Months 0–1 = 2026-10-17 to 2026-11-17), PMO initiates EDF negotiations for a non-binding letter of intent confirming willingness to discuss 500 MW+ baseload at a capped price range. By Month 6 (2027-04-17), EDF LOI targets ≥500 MW, ≥10-year tenor, price EUR 50–70/MWh (assumed, not verified). Phase 0 power-market study models energy cost impact: if delivered cost rises above EUR 70/MWh (e.g., EUR 80–100 due to policy shifts or grid constraints), NOI per MW falls from EUR 800k to EUR 600k (500 MW case), DSCR drops below 1.30x lender minimum, triggering either (i) lease price escalation (EUR 1.1M → EUR 1.2M+/MW-year), (ii) debt reduction from EUR 3B to EUR 2.5B (60% → 50% leverage), or (iii) Phase 2 expansion deferral. By Month 9 (2027-07-17), a detailed term sheet from EDF confirms capacity, price, tenor, curtailment/flexibility obligations and indexation formula (proposed: CPI + 50 bps indexed annually). Energy risk is passed through to tenants via indexed lease pass-through, so developer carries no volume risk beyond grid curtailment. BESS (50–200 MWh, cost EUR 20M–80M estimate) is evaluated for arbitrage value and grid-stress mitigation; if BESS ROI is positive (>5% IRR), it is funded from Phase 1 capex; otherwise optional and tenant-funded.

**Adaptation Trigger:** EDF LOI not received or pricing >EUR 100/MWh by Month 6 (2027-04-17) → power-gate criterion at risk, Steering Committee considers Phase 1 downsize or delay pending EDF clarity. EDF term-sheet pricing ≥EUR 80/MWh and non-indexable (fixed contract) → debt capacity drops EUR 500M–1B, equity raises required, Phase 1 FID contingent on restructured lease pricing or equity injection. Competing industrial-load requests to EDF saturate capacity <500 MW available → topology must pivot to split-campus with smaller per-node power contracts, or Phase 1 downsize to 250 MW.

### 6. Permitting and Environmental Authorization Timeline and Compliance Tracking
**Monitoring Tools/Platforms:**

  - ICPE and environmental-authorization permit-file roadmap and completion tracker (expert reports due, DREAL feedback incorporation)
  - Permit-file submission checklist and filing-date confirmation (targeted Month 8–9 = 2027-06-17 to 2027-07-17)
  - DREAL screening opinion request and timeline tracker (opinion due Month 9 = 2027-07-17)
  - Legal-challenge and appeal escalation log (none expected in Phase 0; Phase 1 monitoring plan established)

**Frequency:** Monthly Permitting and Environmental Lead updates; permit-file roadmap completed by Month 2 (2026-12-17); DREAL opinion due Month 9 (2027-07-17); permit-check gate at Month 18 (2028-04-17) assessing compliance with decision timeline

**Responsible Role:** Compliance, Environmental & Social License Committee (Permitting and Environmental Lead), with environmental and ICPE counsel; escalates to Steering Committee if DREAL timeline slips >6 months or new scope requirements emerge

**Adaptation Process:** Phase 0 Month 1–2 (2026-11-17 to 2026-12-17): permit-file roadmap is finalized specifying required components (ecological baseline, hydrological assessment, contamination survey, thermal modeling, security specs, community-benefit commitments). Phase I desktop ESAs and hydrological study are completed Month 1–3 (2026-11-17 to 2027-01-17); Phase II intrusive surveys (if triggered) are closed Month 3 (2027-01-17) with remediation-liability findings incorporated into permit file. Ecological master plan (completed Month 6 = 2027-04-17) provides EIA avoidance-reduction-compensation strategy. Community-benefit agreement (signed Month 6 = 2027-04-17) is appended to show local support. Permit file (single file for single-square topology, one file per node for split-campus) is submitted Month 8–9 (2027-06-17 to 2027-07-17); filing date is confirmed and tracked. DREAL screening opinion (due Month 9 = 2027-07-17) confirms EIA requirements and ICPE classification. If DREAL requires additional studies or wider EIA scope, permit-file completion date shifts from Month 9 (2027-07-17) to Month 12 (2027-10-17) and decision timeline extends from target Months 26–39 (2028-12-17 to 2030-01-17) to Months 39–52 (2030-01-17 to 2031-04-17), pushing Phase 1 energization to Month 54+ (2031-04-17+) and eroding Phase 1 schedule. Permit-check gate at Month 18 (2028-04-17): if no decision is in sight (authority response pending, legal challenge filed), Phase 1 FID becomes contingent on permit pathway clarity.

**Adaptation Trigger:** DREAL opinion not received or requires expanded EIA scope by Month 9 (2027-07-17) → permit timeline extends beyond target, Phase 1 decision deferred. Legal challenge to permit filed by Month 18 (2028-04-17) → appeal timeline adds 12–36 months, Phase 1 energization shifts Months 54–66 (2031-04-17 to 2032-04-17)+ (2031-04-17 to 2032-04-17+). Permit-file roadmap additions cost >EUR 20M or extend timeline >3 months → Steering Committee informed, Phase 0 tranche 4 (EUR 150M final allocation) decision may defer permitting accelerants or design refinements. ICPE classification changes to more restrictive category → Phase 1 capex +EUR 100M–300M for additional mitigation, or Phase 1 downsize if mitigation cost is unacceptable.

### 7. National Security Review and ANSSI Clearance Pathway Tracking
**Monitoring Tools/Platforms:**

  - ANSSI pre-submission confidential security governance white paper (submitted Month 1 = 2026-11-17)
  - ANSSI preliminary opinion request and timeline tracker (due Month 6 = 2027-04-17, uncontrolled)
  - Security-design framework and compliance checklist (cyber-OT separation, anti-drone systems, personnel vetting, supply-chain assurance)
  - ANSSI formal-review start confirmation (targeted Month 13 = 2027-11-17, clearance Month 25–31 = 2028-11-17 to 2029-05-17)

**Frequency:** Monthly Security and National-Security Lead updates to PMO; pre-submission dialogue ongoing Months 0–1 (2026-10-17 to 2026-11-17); informal ANSSI opinion due Month 6 (2027-04-17); formal review start confirmation by Month 12 (2027-10-17)

**Responsible Role:** PMO Security and National-Security Lead (with security and GDPR counsel, ANSSI liaison); escalates to Steering Committee immediately if ANSSI signals blocking concerns (foreign co-investor cap, tenant-access restrictions, data-residency mandates)

**Adaptation Process:** Phase 0 Month 0–1 (2026-10-17 to 2026-11-17): confidential pre-submission engagement with ANSSI and DGSI outlines project scope, tenant strategy (hyperscalers, sovereign AI users), foreign co-investor governance, data-residency policy, and security posture (perimeter hardening, cyber-OT separation, personnel vetting). ANSSI informal opinion due Month 6 (2027-04-17) indicates anticipated review scope, timeline and any early blocking concerns (e.g., 'foreign equity above X% is not permissible', 'non-EU tenants restricted to non-sovereign workloads'). If no blocking concerns are signaled, security gate is on track: formal ANSSI review starts Month 13 (2027-11-17, post-FID), clearance targeted Month 25–31 (2028-11-17 to 2029-05-17). If ANSSI signals blocking concerns (e.g., foreign co-investor must be limited to ≤20% equity, non-EU hyperscalers cannot access sovereign partitions), the Steering Committee convenes within 5 working days to reassess financing (consortium co-investor may need replacement) and tenant strategy (hyperscaler pool may contract). A revised security governance framework is negotiated with ANSSI; clearance pathway and timeline may extend. If ANSSI indicates formal review will take >18 months (beyond Month 31 = 2029-05-17), Phase 1 FID is contingent on ANSSI confirmation that clearance will be complete by Month 42 (2030-04-17, energization start date) or Phase 1 energization is delayed.

**Adaptation Trigger:** ANSSI preliminary opinion signals blocking concern (foreign co-investor cap, tenant-access restriction, data-residency mandate) by Month 6 (2027-04-17) → Steering Committee reassesses within 5 working days, may trigger financing or tenant-strategy pivot. ANSSI indicates formal-review timeline >18 months (projected clearance beyond Month 31 = 2029-05-17) by Month 12 (2027-10-17) → Phase 1 FID contingent on security-review completion by Month 42 (2030-04-17) or Phase 1 energization delayed 6–12 months. ANSSI issues final clearance restrictions on tenants or co-investor control → governance restructuring required post-FID, Phase 1 capex for security hardening may increase EUR 50M–200M if additional restrictions require design changes.

### 8. Community Engagement, Social License and Municipal Support Validation
**Monitoring Tools/Platforms:**

  - Municipal liaison committee meeting minutes (published, ongoing monthly Months 2–12 = 2026-12-17 to 2027-10-17)
  - Public consultation feedback summary and project response log (4-week comment period, feedback integrated by Month 5 = 2027-03-17)
  - Community-benefit agreement draft and final signatures (signed by Month 6 = 2027-04-17, covers labor, training, ecology, farm-sector support, municipal infrastructure)
  - Opposition escalation tracker (NGO legal challenge risk, farm-union organized action, municipal formal objection log)

**Frequency:** Monthly municipal liaison committee meetings (published minutes); public consultation launched Month 3 (2027-01-17), feedback closed Month 4 (2027-02-17), response published Month 5 (2027-03-17); written municipal support tracked through Month 12 (2027-10-17); legal-challenge monitoring ongoing

**Responsible Role:** Compliance, Environmental & Social License Committee (Community and Stakeholder Lead), with municipal and farm-sector liaisons; escalates to Steering Committee if organized opposition or formal municipal refusal emerges by Month 6 (2027-04-17)

**Adaptation Process:** Phase 0 Month 1–2 (2026-11-17 to 2026-12-17): municipal liaison committee is established with representatives from ≥3 most-affected municipalities; monthly dialogue is scheduled, meeting agendas and minutes are published. Month 3 (2027-01-17): public consultation is launched with transparent project overview, siting rationale, technical specs (power, cooling, footprint), environmental/social-impact scope, and 4-week comment period. Month 4–5 (2027-02-17 to 2027-03-17): feedback is compiled, project responses are drafted and published. Months 2–6 (2026-12-17 to 2027-04-17): community-benefit agreement is negotiated with municipalities, farm unions (FNSEA, Confédération Paysanne) and environmental NGOs, addressing labor/training targets (regional academy, local hiring), ecological restoration (EUR 50M–150M Phase 1–2 estimate), farm-sector support (displacement compensation, land-swap schemes, revenue-sharing on continuation zones), and municipal infrastructure upgrades. By Month 6 (2027-04-17), draft agreement is signed or a binding term sheet is in place; EUR 50M–150M Phase 1–2 commitment is contingent on permits (not Phase 0 spend). Month 9 (2027-07-17): written support letters are requested from at least 2 of 3 most-affected municipalities, indicating municipal endorsement of the project (non-binding but political signal). Month 12 (2027-10-17): formal written support (municipal council resolution or mayor letter) from ≥2 municipalities is confirmed as the social-license gate criterion. If organized opposition emerges (farm-sector legal action, environmental NGO challenge, mayor public refusal) by Month 6 (2027-04-17), the Steering Committee is informed within 5 working days and assesses whether to pivot topology (substitute site), reduce phase scope or defer permitting and land assembly.

**Adaptation Trigger:** Organized opposition or major legal challenge filed by a farm union or NGO by Month 6 (2027-04-17) → Steering Committee reassesses Phase 0, may trigger topology pivot or Phase 1 defer. Formal municipal refusal (mayor or council resolution against the project) in ≥2 of 3 target municipalities by Month 9 (2027-07-17) → social-license gate fails, Phase 1 FID cannot proceed, project deferral or site substitution required. Written municipal support from <2 municipalities by Month 12 (2027-10-17) → social-license gate criterion unmet, Phase 1 FID recommendation is 'conditional on achieving 2 municipal letters within 6 months' or 'project deferred'. Any municipal request for unacceptable design compromises (e.g., reduce capacity 30%, relocate all halls outside municipality) → cost escalation EUR 250M–1.5B, triggers Steering Committee scope-trade decision.

### 9. Phase 1 Debt Financing Credibility and Lender Engagement Tracking
**Monitoring Tools/Platforms:**

  - Lender outreach and engagement log (EIB, KfW, French banks, infrastructure funds, Month 2–9 = 2026-12-17 to 2027-07-17)
  - Debt-financing term sheet and non-binding LOI tracker (due Month 9 = 2027-07-17, with gate-success conditions specified)
  - Financial model and debt-service coverage sensitivity spreadsheet (DSCR base case 1.34x, stress case 1.15x)
  - Lender covenant and gate-trigger documentation (debt covenants tied to RTE, tenant, permitting gate achievements)

**Frequency:** Monthly PMO Finance Lead updates; lender outreach Month 2–3 (2026-12-17 to 2027-01-17), preliminary feedback Month 6 (2027-04-17), non-binding term sheet Month 9 (2027-07-17), lender final-commitment decision contingent on all Phase 0 gates Month 12–13 (2027-10-17 to 2027-11-17)

**Responsible Role:** PMO Finance and Lender Relations Lead (with infrastructure finance counsel and arranger); escalates to Kill Authority Committee if debt commitment <EUR 3B or terms (spread >300 bps, DSCR covenant >1.40x) are unacceptable

**Adaptation Process:** Phase 0 Month 2–3 (2026-12-17 to 2027-01-17): PMO Finance Lead engages prospective lenders (EIB, KfW, French banks, infrastructure funds) to present the Phase 0 gating framework and to understand debt-capacity and term-sheet conditions. Lender feedback (Month 6 = 2027-04-17) typically requires: (i) RTE firm connection offer, (ii) signed tenant take-or-pay for ≥30% of capacity, (iii) bounded environmental liability, (iv) firm power-supply contract or LOI, (v) DSCR >1.30x on stabilized assumptions. A preliminary financial model is developed (Month 4 = 2027-02-17) modeling 500 MW (EUR 5B capex, 60% debt = EUR 3B, annual debt service EUR 299M) and stress cases (tenure reduction, lease-price discount, cost overrun). Non-binding lender term sheet due Month 9 (2027-07-17) confirms debt capacity (EUR 3B–3.5B for 500 MW), tenor (12–15 years), pricing (benchmark + 200 bps estimate), and gate conditions for final commitment. If lenders signal debt <EUR 3B (capacity constraint) or spreads >300 bps (cost of capital increase), the Kill Authority Committee flags a financing-gate breach and recommends Phase 1 downsize to 250 MW (EUR 2.5B capex, EUR 1.5B debt) or Phase 1 FID deferral pending equity restructuring. Phase 1 FID approval (Month 12 = 2027-10-17) triggers final debt-commitment close (Month 13–18 = 2027-11-17 to 2028-04-17), with lenders requiring confirmations of all Phase 0 gates and post-FID financial close conditions (tenant lease executions, RTE connection agreement, power-supply contract, environmental permits on track).

**Adaptation Trigger:** Lender feedback (Month 6 = 2027-04-17) indicates debt capacity <EUR 3B for 500 MW → Phase 1 downsize to 250 MW or Phase 1 defer 6–12 months. Lender spreads >300 bps (raised cost of capital 2–3 pcts annually) → project economics erode, IRR falls 1–2 percentage points, Phase 1 FID contingent on equity injection or lease price escalation. Lender term sheet (Month 9 = 2027-07-17) gates final commitment on Phase 0 gate achievements not met by Month 12 (2027-10-17) (e.g., RTE letter missing, tenants <30%, ANSSI blocking) → lender commitment is void, debt unavailable, Phase 1 FID fails, project exits or defers pending gate resolution.

### 10. Water Resource Feasibility and Cooling Design Validation
**Monitoring Tools/Platforms:**

  - Hydrological and water-stress assessment study (completed Month 4 = 2027-02-17, estimate)
  - Regional water-authority consultation and preliminary opinion (due Month 6 = 2027-04-17)
  - Dry-cooler thermal-design-day modelling at 35°C ambient (PUE sensitivity, peak grid load impact)
  - Water-permitting pathway documentation (closed-loop cooling confirmed feasible, zero evaporative-water rule validated)

**Frequency:** Monthly water-resources management by Compliance committee; hydrology study due Month 4 (2027-02-17); water-authority opinion due Month 6 (2027-04-17); thermal modelling integrated into design reviews by Month 6 (2027-04-17); ongoing monitoring through Phase 1 permitting

**Responsible Role:** Compliance, Environmental & Social License Committee (Water Resources Manager), with hydrologist and water-law counsel; escalates to Steering Committee if water authority denies closed-loop feasibility or imposes restrictive abstraction limits

**Adaptation Process:** Phase 0 Month 1–4 (2026-11-17 to 2027-02-17): hydrological study assesses regional water stress (drought frequency and severity), competing water users (agricultural, municipal, industrial), and dry-cooler performance at extreme ambient temperatures (35°C design day). Modeling projects PUE under hot-weather scenarios (base case 1.15–1.25, hot-weather stress 1.35–1.5) and electrical load impact (peak load increase 5–15% during summer stress events). Month 3–4 (2027-01-17 to 2027-02-17): regional water authority (Agence de l'Eau Artois-Picardie) is formally consulted on closed-loop direct-to-chip cooling feasibility, water-abstraction impacts (none expected, zero freshwater withdrawal), and any permits required (stormwater management, groundwater protection). By Month 6 (2027-04-17), water authority provides written preliminary opinion confirming closed-loop cooling is permissible and no water-abstraction permits are required beyond standard stormwater authorization. If water authority raises concerns (drought vulnerability, groundwater interaction, competing demand), design review is triggered: options include hybrid cooling with limited evaporative water (risky in permitting), BESS expansion to reduce summer peak load, or capacity reduction. Thermal-design-day modeling validates PUE <1.30 at 35°C; if modelling shows PUE >1.30, design cost escalates (EUR 200M–500M for enhanced cooling or campus downsizing 20–30%) or grid peak-load impact triggers RTE curtailment negotiations.

**Adaptation Trigger:** Water authority opinion (Month 6 = 2027-04-17) denies closed-loop cooling feasibility or imposes water-abstraction restrictions → design review triggered, hybrid cooling option evaluated (if permissible), Phase 1 capacity downsize or site substitution. Thermal modelling shows PUE >1.30 at 35°C design day (Month 6 = 2027-04-17) → cooling-cost escalation EUR 200M–500M or Phase 1 downsize to 250 MW. Grid peak-load impact (5–15%) during summer stress exceeds RTE capacity buffer → curtailment obligation rises above 10% target, power-gate criterion at risk, Phase 1 capacity constrained by grid thermal limits rather than developer choice.

### 11. Fiber Connectivity and Route Diversity Validation
**Monitoring Tools/Platforms:**

  - Fiber-route audit by independent telecom auditor (physical path maps, duct-separation verification, landing-point analysis)
  - Carrier capacity commitment and letters of intent (at least 2 independent routes per destination, lit by Phase 1 energization Month 42–48 = 2030-04-17 to 2030-10-17)
  - Developer-built fiber cost and rights-of-way estimate (EUR 100M–500M per 100–200 km route, if carrier routes unavailable)
  - Landing-point concentration risk assessment (subsea cable pinch points, redundancy targets ≥2 UK, ≥2 FR/BE landings, no single landing >25% capacity)

**Frequency:** Monthly fiber-sourcing lead updates; independent audits Month 1–9 (2026-11-17 to 2027-07-17); carrier LOI and route confirmations by Month 9 (2027-07-17)

**Responsible Role:** PMO Grid and Power Lead or Tenancy and Revenue Lead (with independent fiber-route auditor, carrier liaisons); escalates to Steering Committee if <2 independent routes are available or landing-point concentration risk is unmitigated

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17): independent fiber auditor is commissioned to map physical-route claims from all candidate carriers (e.g., 'route A and route B are independent') and to audit actual duct paths, bridge crossings, subterranean shared facilities and landing stations. Auditor delivers detailed physical-path verification by Month 9 (2027-07-17). Month 3–9 (2027-01-17 to 2027-07-17): carriers are approached for capacity commitments (≥100 Tbps redundant capacity per route, available at Phase 1 energization). If independent carrier routes are not available (e.g., all carriers share a single landing station, rendering claimed diversity false), developer commits to build or co-invest in a separate route (EUR 100M–500M per 100–200 km), with rights-of-way negotiated along rail, canal or pipeline corridors. Subsea landings near Dunkirk or Channel access are assessed for concentration risk; if all routes funnel through one landing facility, geographic redundancy is compromised and subsea co-investment is evaluated. By Month 9 (2027-07-17), carrier LOIs or written capacity commitments confirm at least 2 independent routes to each of Paris, London, Brussels, Amsterdam, Frankfurt with ≥100 Tbps capacity and <25% per-landing concentration. If routes are not confirmed, Phase 1 design includes developer-built fiber as capex (cost EUR 100M–500M) or Phase 1 connectivity is contingent on carrier delivery by Phase 1 energization (risk of delay if carrier construction slips).

**Adaptation Trigger:** Fiber audit reveals claimed-independent routes share landing station or conduit (Month 9 = 2027-07-17) → latency or resilience risk exposed, developer commits to build separate route or Phase 1 FID contingent on new fiber investment (EUR 100M–500M capex, 6–12 month construction). Carrier capacity commitments not in hand by Month 9 (2027-07-17) → Phase 1 connectivity delayed 6–12 months unless developer-built route is pre-contracted. Subsea landing-point concentration (all routes through 1 facility) not mitigated → sabotage or natural-disaster risk to all cross-border traffic, Phase 1 FID contingent on additional landing or subsea-cable co-investment.

### 12. Topology Decision and Feasibility Trade-Off Validation
**Monitoring Tools/Platforms:**

  - Topology-decision package (single-square vs. split-campus comparison, prepared Month 3–4 = 2027-01-17 to 2027-02-17)
  - Land-assemblability assessment per topology (% parcel optioned, holdout clusters, cost impact)
  - Grid-capacity per-node estimates (RTE preliminary advice per site, phased connection timelines)
  - Split-campus fiber and latency analysis (inter-node dark-fiber cost, round-trip latency vs. workload tolerance)
  - Detailed capex and per-MW cost by topology (single-square EUR 5B–10B vs. split EUR 5.5B–9.2B, schedule impact)

**Frequency:** Topology decision locked at Month 4 (2027-02-17); supporting analysis and evidence compiled Months 1–4 (2026-11-17 to 2027-02-17); formal vote and publication by Steering Committee at Month 4 (2027-02-17)

**Responsible Role:** PMO Land Assembly, Grid, and Tenancy leads (collaborative analysis); Steering Committee votes; Kill Authority Committee monitors for compliance with documented decision criteria

**Adaptation Process:** Phase 0 Month 1–3 (2026-11-17 to 2027-01-17): preliminary land-assemblability assessment (Month 3 = 2027-01-17) measures single-square's viability (% parcel optioned) and split-campus nodes' individual viability (Cambrai 80%+, Dunkirk 80%+, Valenciennes 80%+). RTE pre-submission dialogue (Month 1–3 = 2026-11-17 to 2027-01-17) gathers preliminary grid-capacity signals per site; written RTE preliminary letter is not due until Month 6 (2027-04-17), but early informal guidance informs topology choice. Phase 0 Month 4 (2027-02-17): topology-decision meeting is held. Single-square is selected ONLY if (i) at least 70% of target parcel is optioned, AND (ii) RTE written evidence of at least 1 GW capacity is already in hand (not due until Month 6 = 2027-04-17, so this criterion is rarely met by Month 4 = 2027-02-17). If single-square does not meet both criteria, split-campus is the default. Split-campus nodes are ranked by grid capacity per node and land-assemblability per node; typically Cambrai ~500 MW (most assemblable, largest grid offer), Dunkirk ~250 MW (heavy industrial, Gravelines nuclear nearby), Valenciennes ~250 MW (second brownfield, Brussels proximity). Latency tolerance for split-campus is assessed via tenant workload inputs (cluster sizes, inter-node communication frequency); if latent-critical training workloads are >50% of demand, split-campus becomes operationally risky and single-square is preferred if land permits. Phase 1 capex and schedule differ: single-square USD 1.0 GW centralized, ~12 months construction, energization Month 48 (2030-10-17); split-campus 2–3 nodes sequenced (Cambrai first Month 42–48 = 2030-04-17 to 2030-10-17, then Dunkirk Month 54+ = 2031-04-17+), total build 24+ months, per-MW capex higher 5–10% due to duplication. Decision is documented in a topology-decision paper, published to PMO, Steering Committee, lenders, co-investors and Kill Authority Committee.

**Adaptation Trigger:** Land-assemblability fails for single-square (<70% optioned by Month 4 = 2027-02-17) → split-campus forced, Phase 0 extended 3–6 months for node-level feasibility studies (EUR 100M–250M additional spend). RTE preliminary advice suggests grid capacity <1 GW total (Month 3–4 = 2027-01-17 to 2027-02-17 informal signals) → split-campus becomes default to de-risk capacity via multiple smaller nodes. Tenant workload analysis shows >50% latency-critical training workloads by Month 3 (2027-01-17) → single-square preferred on operational grounds, land-assemblability and grid must be forced to support it or Phase 1 capacity downsize. Late topology change (Month 9 = 2027-07-17 or later) → capex rework EUR 250M–500M, Phase 0 gate deferred, Phase 1 FID pushed to Month 18+ (2028-04-17+).