## 1. RTE Grid Hosting Capacity and Connection Offer

RTE grid hosting capacity above ~1 GW is the primary kill-test gate. No hosting capacity exists until RTE signs a connection offer; this exposure is uncontrolled until signed and is the first feasibility filter. Grid reinforcement cost (EUR 500M–1.5B developer co-funding, estimate) is the largest contingent cost-line exposure in the Phase 1 budget.

### Data to Collect

- RTE preliminary feasibility opinion for 500 MW, 1 GW, 2 GW tranches at each candidate substation (Cambrai, Dunkirk, Valenciennes, Saint-Omer)
- RTE estimated timeline from connection request to energization per tranche and topology
- Transmission reinforcement scope, cost allocation (developer co-funding EUR 500M–1.5B estimate) and timeline
- Annual curtailment allowance (target ≤10%, walk-away ≥15%) and BESS/flexibility requirements
- Firm written connection offer for at least 500 MW by Month 12 (2027-10-17)

### Simulation Steps

- Commission independent third-party RTE hosting-capacity audit (EUR 1M–2M) using grid-modeling software (PSSE, DIgSILENT PowerFactory or equivalent RTE-compatible tools) to verify RTE's claims through network modeling; deliver findings by Month 9 (2027-07-17)
- Run thermal and load-profile modeling (HOMER or EnergyPlan) for 500 MW (85% utilization = 425 MW average) with peak scenarios (40 MW variance in summer peak); test against candidate substation thermal constraints
- Model three topology scenarios (single-square Cambrai 1 GW, split 2-node Cambrai 500 MW + Dunkirk 250 MW, split 3-node 250 MW each) through RTE's published network data or via RTE consultation; estimate per-node reinforcement cost using published transmission-upgrade benchmarks (EUR 50M–100M per 100 kV line upgrade, approximate)

### Expert Validation Steps

- RTE formal pre-engineering request filed in writing by Month 0 (2026-10-17); RTE's preliminary hosting-capacity opinion (month 4–6 = 2027-02-17 to 2027-04-17 estimate, uncontrolled) confirmed in writing
- Independent grid-audit firm (third-party consultant with no developer financial interest) validates RTE's network-modeling assumptions and publishes anonymized findings to the investment committee and lenders by Month 9 (2027-07-17)
- DREAL prefectural office confirms in writing by Month 6 (2027-04-17) that grid-reinforcement scope and environmental permits for substation upgrades are achievable within estimated timelines and cost bands

### Responsible Parties

- Grid Connection and Power Infrastructure Strategist (lead)
- Independent RTE hosting-capacity auditor (third-party consultant)
- Infrastructure Finance Lead (cost reconciliation against Phase 1 cap)
- Investment Committee (gate decision at Month 12 = 2027-10-17)

### Assumptions

- **High:** RTE will provide a preliminary feasibility opinion within 8–12 weeks of the pre-engineering request (by Month 4–6 = 2027-02-17 to 2027-04-17). RTE's internal governance and competing requests are uncontrolled and may delay response beyond Month 6 (2027-04-17).
- **High:** RTE's preliminary opinion will confirm at least 500 MW (one node) within 36 months of a formal connection request. The actual available capacity may be lower (e.g., 250 MW per node), triggering topology downsize or split-campus redesign.
- **High:** Developer co-funding for grid reinforcement will be bounded to EUR 500M–1.5B (estimate) and will not exceed EUR 2.0B. Transmission reinforcement scope is uncontrolled until RTE specifies it.
- **Medium:** Annual curtailment will not exceed 15% (walk-away threshold). If RTE mandates >15% curtailment, Phase 1 capex or scope is reduced to fit the grid offer, and revenue per MW declines due to lower uptime (10–15% lease discount assumed at 15% curtailment, estimate).
- **High:** A firm RTE connection offer will be signed by Month 12 (2027-10-17) or Phase 1 is delayed. RTE often takes 18–36 months from request to final offer; a 12-month timeline for preliminary + final offer is aggressive but necessary for the Phase 0 gate.

### SMART Validation Objective

By Month 12 (2027-10-17), obtain RTE written preliminary feasibility letter confirming at least 500 MW available within 36 months, estimated grid reinforcement cost (bounded to EUR 0–2.0B, accept ≥USD 500M as a pass if within budgeted headroom), annual curtailment not exceeding 15%, and BESS/flexibility requirements specified. If RTE cannot confirm ≥500 MW by Month 12 (2027-10-17), Phase 1 is reduced to the MW RTE offers or paused until capacity improves.

### Notes

- RTE's hosting-capacity assessment is the longest-lead external decision and the primary kill test. Month 4 (2027-02-17) topology lock depends on RTE evidence due at Month 6 (2027-04-17), inverting the sequence—mitigation: seek Month 3 (2027-01-17) interim RTE opinion or delay topology to Month 6.5 (2027-05-02).
- Grid reinforcement co-funding exposure (EUR 500M–1.5B, estimate) overlaps with other stacked contingent add-ons (ecology, split premium, carrying, remediation, fiber) totaling EUR 1.55B–4.2B against a EUR 10B ceiling; if grid reinforcement exceeds EUR 1.0B, Phase 1 must downsize or scope is cut.
- Curtailment risk: if RTE mandates ≥15% annual curtailment, tenant uptime SLAs (99.5–99.95% proposed) cannot be met without additional BESS or demand-flexibility investment, eroding tenant appeal and lease pricing by 5–15% (estimate).
- Independent audit by a third-party grid specialist (not RTE internal, not developer-funded consultant) is essential to validate RTE's claims and reduce lender risk premium; cost EUR 1M–2M is justified by potential EUR 500M–1.5B co-funding exposure.


## 2. Land Assembly and Parcel Optionability (Topology Decision Input)

Land assembly is a primary kill test. The notional 161 km² single-square footprint is doubtful (not verified) for contiguous non-coercive assembly; fragmentation or holdouts force topology pivot to split-campus or downsize. Brownfield remediation liability (EUR 100M–400M if discovered late) is the least-quantifiable cost and can breach the Phase 1 cap if not bounded in Phase 0. Land acquisition cost (EUR 0.24B–0.40B for 16,100 ha at EUR 15,000–25,000/ha, estimate) is a major capex driver.

### Data to Collect

- Ownership maps and parcel counts for Cambrai, Dunkirk, Valenciennes, Saint-Omer candidate zones
- Benchmark land values and acquisition-cost estimates per zone (EUR/ha)
- Percentage of target parcel that can be optioned non-coercively at ≤15% above benchmark (target ≥70% for single-square, ≥80% per split-node)
- Holdout count, owner types (private, agricultural, municipal), and negotiation barriers per parcel
- Phase II brownfield surveys on shortlisted parcels: soil, groundwater, asbestos, munitions residue, remediation cost bounds per parcel (target EUR 0–100M)

### Simulation Steps

- Conduct geographic-information-system (GIS) mapping using ArcGIS or QGIS with municipal land-registry data, parcel ownership chains, and agricultural property records (Chambre d'Agriculture regional database) to produce fragmentation analysis; identify >1,000 parcels across four zones and classify by owner type, size, estimated value
- Run land-value benchmarking using comparable-sales databases (Chambre des Notaires, SAFER regional land-transfer records) to establish baseline EUR/ha per zone and parcel category (agricultural, industrial, mixed); flag any parcel showing >2.0× benchmark as holdout-premium risk
- Model Phase II intrusive surveys (soil boring to 2–5 m depth, groundwater sampling) at 2–3 candidate sites per zone using Phase-I-Pro or equivalent ESA software to predict remediation scope and cost; use published remediation-unit costs (EUR 1,000–5,000 per m³ contaminated soil, estimate) to bound total remediation per site
- Conduct parcel-level assembly simulations (timeline, cost, holdout risk) for single-square Cambrai (161 km² continuous) and split-campus nodes (Cambrai 8–10 km², Dunkirk 8–10 km², Valenciennes 8–10 km²) to test the 70–80% optionability threshold

### Expert Validation Steps

- Parcel-level land-assembly feasibility study commissioned from a French real-estate advisory firm with rural and industrial land experience (EUR 200K–400K); deliver fragmentation map and holdout-risk assessment by Month 3 (2027-01-17)
- Phase I environmental-site assessments (desktop) on all four zones by Month 1 (2026-11-17); Phase II intrusive surveys (EUR 1.5M–3M per zone) on top 2–3 sites per zone by Month 3 (2027-01-17); shortlist only parcels with Phase II findings supporting remediation ≤EUR 100M per site by Month 6 (2027-04-17)
- Formal written opinion from DDT/DDTM (Directions Départementales des Territoires) on public-land availability, state-backed compulsory-acquisition timelines (décret de déclaration d'utilité publique, typical 6–12 months), and liability-allocation agreements for public brownfield sites by Month 4 (2027-02-17)
- Farm-union (FNSEA and Confédération Paysanne regional chapters) and municipal-official engagement to understand landowner negotiation posture, required compensation levels (proposed 1.5–2.0× land value for displacement, EUR 15,000–25,000/ha for 8,900–10,200 ha per node, estimate), and lease-and-continue feasibility by Month 2 (2026-12-17)

### Responsible Parties

- Land Assembly and Real Estate Strategist (lead)
- Third-party land-feasibility and ESA consultant
- Environmental and Permitting Counsel (Phase II survey oversight and liability allocation)
- Community Engagement and Social License Manager (farmer and municipal negotiations)

### Assumptions

- **High:** At least 70% of a single-square topology's target parcel (113 km² of 161 km²) can be optioned non-coercively at ≤15% above benchmark land value. Phase I assessments suggest fragmentation risk; if <70% is optionable by Month 3 (2027-01-17), single-square is abandoned and split-campus becomes the default.
- **High:** Benchmark land values are EUR 15,000–25,000/ha in Hauts-de-France agricultural zones. Actual acquisition will require 1.5–2.0× benchmark (EUR 22,500–50,000/ha) due to holdout leverage and relocation premiums, adding EUR 50M–100M above base estimate (estimate).
- **High:** Phase II brownfield surveys on Cambrai, Dunkirk, Valenciennes sites will identify remediation needs of EUR 0–100M per parcel. If >30% of candidate parcels show remediation costs >EUR 100M, those parcels are dropped from consideration and Phase 1 footprint is redesigned, adding cost and schedule delay.
- **Medium:** Seller indemnities and public-remediation-body liability allocations will be signed and enforceable, capping developer remediation exposure to EUR 100M per site or less. Public landowners (Dunkirk port, Cambrai municipal sites) are willing to retain pre-existing contamination liability; if not, developer must fund full cleanup, escalating cost by EUR 200M–500M (estimate).
- **Medium:** Lease-and-continue farming arrangements (allowing farmers to operate on buffer and continuation zones of the envelope) will satisfy >50% of landowner concerns, reducing the required cash compensation and relocation premium. If lease-and-continue is not accepted, all agricultural landowners demand full-buyout at 2.0× value, escalating cost by EUR 100M–200M (estimate).

### SMART Validation Objective

By Month 3 (2027-01-17), deliver a land-assembly feasibility map confirming: ≥70% of single-square target parcel (or ≥80% per split-campus node) can be optioned non-coercively at ≤15% above benchmark; Phase II surveys identify remediation ≤EUR 100M per site on >70% of shortlisted parcels; seller/public indemnity agreements are drafted and pre-negotiated with at least 50% of target landowners. At Month 4 (2027-02-17), commit to single-square or split-campus topology based on this evidence.

### Notes

- Contiguous land assembly of 161 km² (12.7 km × 12.7 km) across four candidate zones requires coordination of >1,000 individual parcels; fragmentation is the most likely outcome, forcing split-campus topology by Month 4 (2027-02-17) unless exceptional progress is made in Months 1–3 (2026-11-17 to 2027-01-17).
- Brownfield contamination (historical munitions, slag, asbestos, hydrocarbons from steel mills, refineries, coal mines in the region) is the highest Phase 1 cost uncertainty; front-loading Phase II surveys in Phase 0 bounds liability and allows seller/public-body liability allocation before Phase 1 FID.
- Agricultural-sector opposition (FNSEA and Confédération Paysanne) can block permits or delay land assembly 12–36 months (estimate) unless displacement compensation and lease-and-continue terms are credible and negotiated early (Months 1–3 = 2026-11-17 to 2027-01-17).
- Split-campus topology (3 separate 250–500 MW nodes) adds EUR 250M–500M capex (5–10% premium over single-square) for duplication of substations, fiber, security per node; cost is within EUR 10B ceiling but consumes contingency headroom.


## 3. Anchor-Tenant Demand Validation and Binding Commitments

Phase 1 FID gate requires signed anchor-tenant take-or-pay for ≥30% of Phase 1 capacity (proposed threshold) to support debt financing. Without proof of demand, lenders will not fund EUR 5B capex; a loose gate (LOIs accepted as commitment) is the most common mega-project failure: tenants use LOIs for site comparison without commitment and exit post-FID if conditions change. Only binding leases with cash deposits and liquidated damages prove demand.

### Data to Collect

- Identified anchor-tenant prospects (2–3 hyperscalers with published capex plans, 2–3 sovereign or EU-consortium users) and their specific power/latency/security requirements
- Non-binding letters of intent (for market signal only; do not count toward gate) vs. binding take-or-pay term sheets (capacity reserved, payment obligation, SLA-subject; count for gate)
- Signed take-or-pay leases or capacity-reservation agreements covering ≥30% of Phase 1 size (150 MW of 500 MW) with reservation fees (EUR 10M–50M per 100 MW) paid before construction
- Tenant credit ratings (BBB− or better) or parent-company guarantees and letters of credit (for credit <BBB−)
- Cluster-size and latency-tolerance validation per tenant to test split-campus feasibility (target <10 ms intra-cluster for training, <50 ms inter-node, force-majeure >4 hours)

### Simulation Steps

- Develop standardized take-or-pay lease templates (5–10 year term proposed, capacity range 50–500 MW, power price indexed or capped EUR/MWh, uptime SLA 99.5–99.95%, curtailment exceptions, force-majeure carve-outs) by Month 2 (2026-12-17) using contract-management software (Dealroom or DocuSign); model three scenarios: (i) 100% fixed power price, (ii) indexed to spot with ±3% annual cap, (iii) pass-through to tenants
- Conduct tenant-competitive-alternative survey (Month 2–3 = 2026-12-17 to 2027-01-17) to identify 2–3 hyperscalers (e.g., Microsoft Azure, Google, Meta) and 2–3 sovereign-AI users (French State AI offices, EU CEPIs, or national-government procurement programs) that are actively evaluating sites in 2026–2028; document their published capex plans, timing, and site-selection criteria
- Test cluster-size and latency requirements via technical interviews with top 1–2 anchors, modeling inter-node topology scenarios (single-square Cambrai 1 GW, split Cambrai 500 MW + Dunkirk 250 MW, split 3-node 250 MW each) with site-specific latency estimates based on fiber-route data; document whether training or inference workloads tolerate the split-campus round-trip latency (target <50 ms, <10 ms preferred)
- Price capacity-reservation fees (EUR 10M–50M per 100 MW, estimate) and model NPV impact on Phase 1 financing; test whether 150 MW of signed leases (30% minimum gate) covers debt service (proposed EUR 299M annual at EUR 3B debt, approximately) or if additional 50% signed is required for DSCR >1.30x

### Expert Validation Steps

- Anchor-Tenant and Market Development Lead (dedicated full-time role) engages 4–6 prospect tenants by Month 1 (2026-11-17) with confidential site overview under NDA; obtains non-binding letters of interest from 2–3 by Month 7 (2027-05-17) (advisory, do not count); secures binding term sheets from at least 2 tenants (150 MW total minimum) with reservation fees paid in escrow by Month 9 (2027-07-17)
- Credit validation of all anchor tenants by Month 9 (2027-07-17): obtain S&P, Moody's or Fitch credit reports for each tenant; for subsidiaries, obtain parent-company financial statements and guarantee letters; for sovereigns, obtain government-issued guarantee from Ministry of Finance or EU; confirm minimum BBB− or equivalent credit (or secured by parent guarantee/letter of credit for weaker counterparties)
- Binding term-sheet execution by Month 9 (2027-07-17) with explicit liquidated-damages clause (10–15% of first-year lease revenue if tenant exits between FID and energization) and reservation-fee escrow arrangements; engagement of three law firms to confirm lease enforceability and remedy mechanisms under French law by Month 3 (2027-01-17)

### Responsible Parties

- Anchor-Tenant and Market Development Lead (lead)
- Infrastructure Finance Lead (lease-pricing and NPV modeling)
- National Security and Regulatory Affairs Lead (sovereign-tenant vetting and data-residency compliance)
- Investment Committee (gate decision on binding-commitment sufficiency at Month 12 = 2027-10-17)

### Assumptions

- **High:** At least one global hyperscaler (e.g., Microsoft, Google, Meta) or credible sovereign-AI consortium will express genuine interest (site visit, technical questions, not just LOI flattery) and be willing to sign a binding term sheet for 50–150 MW by Month 9 (2027-07-17). Hyperscaler commitment timelines are typically 6–12 months ahead of power-on; LOI and binding-sheet execution must occur in Phase 0 (Months 1–12 = 2026-11-17 to 2027-10-17) or tenant demand will slip to competing sites.
- **High:** Binding term sheets will include a reservation-fee cash deposit (EUR 10M–50M per 100 MW) paid in escrow by Month 9 (2027-07-17) and a liquidated-damages clause (10–15% of first-year lease revenue) if tenant exits post-FID. Without cash and damages, a 'binding' sheet is non-binding and a tenant can walk without penalty, leaving the campus operator exposed to uncontracted capacity.
- **Medium:** All anchor-tenant counterparties will have a minimum credit rating of BBB− or be backed by a parent-company guarantee (A− or better) or government guarantee (for sovereigns). If credit is weaker, the tenant will post a letter of credit (2–3% annual cost, estimate) covering 1–2 years of lease payments.
- **Medium:** Tenant cluster-size and latency requirements will tolerate a split-campus topology (round-trip latency 10–50 ms between nodes, depending on workload: <10 ms for synchronous training, <50 ms for inference and batch). If a key tenant requires <5 ms (demanding unified cluster), split campus is infeasible for that tenant and capacity is limited to single-node Cambrai, capping Phase 1 revenue and growth.
- **Medium:** Reservation fees (EUR 10M–50M per 100 MW) are credible tenant incentives to lock commitment early. If tenants view fees as 'money spent for optionality' and prefer to delay commitment until Phase 1 detailed design (Month 20+), then fees will not be paid and demand evidence at Month 9 (2027-07-17) will remain weak (LOI-only).

### SMART Validation Objective

By Month 9 (2027-07-17), execute binding take-or-pay term sheets for ≥150 MW (30% of 500 MW Phase 1) with investment-grade counterparties or parent-guaranteed subsidiaries; secure non-refundable reservation-fee cash deposits totaling at least EUR 15M–75M in escrow; confirm no liquidated-damages or exit provisions that would allow tenants to walk post-FID without financial penalty. By Month 12 (2027-10-17), if <150 MW is signed with cash and guarantees, trigger Phase 1 downsize to 250–300 MW (matching committed demand) or pause Phase 1 pending additional tenant recruitment.

### Notes

- Global hyperscalers (Microsoft, Google, Meta, Amazon) typically maintain LOI portfolios across 8–12 competitive European sites and do not commit capex-equivalent leases until 6–12 months before power-on; early Phase 0 LOI collection is market signal only and should not be treated as demand commitment.
- Sovereign-AI procurement (French State, EU, national governments) moves slower than hyperscalers; 18–36 month procurement cycles are common, and public-sector budget cycles (annual or multi-year) often conflict with Phase 1 timelines; sovereign demand proof by Month 9 (2027-07-17) is unlikely unless a formal government RFP is issued in early 2027.
- Reservation-fee economics: EUR 10M–50M per 100 MW (depending on lease term and scale) represents 0.2–0.5% of Phase 1 capex; fees should be sufficient to deter 'comparison shopping' LOI behavior (commitment signal) but not so large that they are prohibitive. On 150 MW signed, fees total EUR 15M–75M, funding about 2–10% of Phase 0 spend (EUR 750M cap).
- Lease-revenue sensitivity: if only 100–150 MW (20–30%) is signed by Month 9 (2027-07-17), Phase 1 lenders will require either (i) higher debt spreads (+200–300 bps, adding EUR 100M–300M NPV interest cost), (ii) lower debt leverage (50% vs. 60%, requiring EUR 500M–1B additional equity), or (iii) Phase 1 downsize (250 MW to match committed demand). Without 30%+ signed and credible, debt financing is not available at acceptable cost.


## 4. Dry-Cooler PUE Validation and Water-Authority Feasibility

Cooling and water are the most operationally uncertain variables. PUE target 1.15–1.25 is optimistic; realistic hot-weather performance (1.35–1.5 PUE at 35°C design-day) adds 75–100 MW peak electrical load, straining RTE grid-curtailment budget and tenant uptime SLAs. A zero-evaporative-water constraint is permitting-friendly but may be infeasible on the proposed dry-cooler budget; hybrid cooling (capped non-potable water) reopens water-authority and permitting complexity. Early validation bounds cost and design risk.

### Data to Collect

- Dry-cooler performance curves from ≥3 manufacturers (Thermax, Hydac, Modine) at ambient temperatures 15–40°C with fouling and part-load efficiency factors
- Site-specific thermal modeling results for 500 MW at 150 W/m² average power density, 30–35°C inlet water, on each candidate parcel; modeled PUE at 35°C design-day ambient
- Regional hydrological data: groundwater availability, historical drought frequency and duration, summer low-flow periods on surface water, climate projections to 2035
- Water-authority written opinion on closed-loop dry-cooler feasibility at 1 GW scale with zero evaporative water use and impact on drinking-water supply during drought years
- Heat-demand study identifying district-heating networks and industrial heat users within 5 km of each node (identify MW offtake potential and annual capacity factor)

### Simulation Steps

- Obtain published dry-cooler performance data from vendors (Thermax, Hydac, Modine, SPX Cooling) covering capacity (100–500 MW thermal rejection range), fan power, approach temperature (Δ design-day = 10–15°C typical), part-load curves (25%, 50%, 75%, 100% load); use TRNSYS, EnergyPlus or equivalent thermal-simulation software to model hour-by-hour PUE for a representative summer (July–August) using 20 years of historical Hauts-de-France weather data (38°C peak on rarest days, 35°C on typical peak days, 60–75% relative humidity)
- Run three power-density scenarios (100 W/m², 150 W/m², 200 W/m²) to test sensitivity; model a 500 MW data center at 150 W/m² = approximately 50,000–100,000 m² cooler area (estimate), footprint dependent on cooler type (bar-plate vs. tube-bundle), arrangement (horizontal vs. vertical), and ambient wind exposure on candidate parcels (Cambrai flat, Dunkirk near coast with wind, Valenciennes near rivers with potential temperature effects)
- Conduct hydrological modeling (HEC-HMS, FEFLOW or equivalent) using 20-year historical weather to project groundwater levels, summer low-flow periods on surface-water bodies (Meuse, Sambre, Scheldt), and drought-frequency/duration statistics; cross-reference with Agence de l'Eau published drought-response decrees (2022, 2023) to understand constraint timelines and load-shedding triggers
- Model heat-reuse scenario at each candidate node: identify district-heating networks (réseaux de chaleur, typical in urban areas like Dunkirk but absent in rural Cambrai) and proximate industrial users (food, brewing, paper, refining); estimate heat-delivery pipeline cost (EUR 500K–2M per km, estimate) and annual revenue (EUR 10M–30M at 20–25 MW offtake at EUR 30–60/MWh, estimate)

### Expert Validation Steps

- Independent thermal-design audit by a data-center cooling specialist (EUR 300K–600K) conducting Phase 0 modeling and delivering site-specific PUE forecast (with confidence interval) by Month 5 (2027-03-17); hard gate: if modeled PUE >1.28 at 35°C on baseline scenario (150 W/m²), recommend hybrid cooling (evaporative + dry, capped non-potable water) or load reduction.
- Water-authority written opinion (DDT/DDTM and Agence de l'Eau Artois-Picardie) by Month 6 (2027-04-17) confirming: (i) closed-loop dry-cooler cooling acceptable at 500–1,000 MW with stated PUE range, (ii) indirect water impact (cooler air-release heat) acceptable under French environmental law, (iii) pre-agreed drought-response protocol (if drought decree issued, tenant load-shedding acceptable and covered by force-majeure lease carve-out), and (iv) whether non-potable or recycled industrial water is available as backup if dry cooling cannot meet summer peak demand.
- Hydrologist or groundwater specialist (EUR 500K–1.5M study cost) delivering Phase 0 hydrological assessment by Month 4 (2027-02-17) addressing: groundwater availability and seasonal variation, drought-frequency analysis (20-year historical data + climate-projection models to 2035), and recommendations for water-use constraints or demand-reduction strategies if drought frequency increases.

### Responsible Parties

- Thermal, Cooling and Hydrology Engineer (lead)
- Environmental and Permitting Counsel (water-authority engagement)
- Infrastructure Finance Lead (thermal design cost impact on capex and contingency budget)
- Grid Connection Strategist (peak-load forecast for RTE reinforcement and BESS sizing)

### Assumptions

- **High:** Dry-cooler PUE at 35°C ambient and 30–35°C inlet water will be ≤1.30 (2-point upside margin above 1.15–1.25 target) using vendor equipment at nominal fouling and part-load. If Phase 0 modeling shows >1.30, design pivot to hybrid cooling or capacity reduction is required by Month 6 (2027-04-17).
- **High:** Water authorities will permit closed-loop dry-cooler cooling at 500–1,000 MW with zero evaporative water and no material impact on drinking-water supply. If water authorities require evaporative cooling as backup (e.g., 5–10% water use allowance for extreme-weather days) or restrict expansion beyond 500 MW, the zero-water design assumption is invalidated and hybrid cooling must be budgeted (EUR 50M–100M capex contingency, estimate).
- **Medium:** Hauts-de-France drought frequency (current baseline ~1 event per 7 years, estimated) will not increase materially over the Phase 1–2 build period (Months 12–84 = 2027-10-17 to 2033-10-17). Climate models project increased drought risk; if frequency escalates to 1 per 3 years or more, tenant load-shedding (forced curtailment) during dry summers will increase, reducing uptime SLAs and tenant satisfaction.
- **Medium:** Heat-reuse offtake (15–30 MW at 20–25 MW sustained) from district heating or industrial users will be contracted and paying by Year 2 of Phase 1 operations (about Month 54 = 2031-04-17). If no binding heat offtake is signed by Month 9 (2027-07-17), heat-delivery infrastructure (EUR 50M–100M estimated capex) is removed from Phase 1 scope.
- **Medium:** Peak electrical load for 500 MW at 150 W/m² average density with 1.20–1.25 PUE will be approximately 625–650 MW (500 MW compute + 125–150 MW cooling and auxiliary). A 1.35–1.40 PUE pushes peak to 675–700 MW, adding 75–100 MW unplanned load to the RTE feeder; RTE's grid-reinforcement and curtailment assumptions must account for this variance.

### SMART Validation Objective

By Month 5 (2027-03-17), deliver site-specific thermal modeling confirming modeled PUE ≤1.28 at 35°C design-day on baseline scenario (500 MW, 150 W/m²), or commit in writing to hybrid-cooling design or Phase 1 capacity reduction. By Month 6 (2027-04-17), obtain written water-authority opinion confirming closed-loop dry-cooler feasibility with zero evaporative water and acceptable indirect-water-impact (cooler air release). By Month 7 (2027-05-17), identify at least one credible heat-offtake prospect (10+ MW, investment-grade or municipal credit); if no offtake is signed by Month 9 (2027-07-17), remove heat infrastructure from Phase 1 capex.

### Notes

- PUE upside risk is a hidden cost driver. A 10-point escalation (1.20 to 1.30 PUE) adds 150–200 MW peak load on hot days; if RTE's grid reinforcement and BESS assumptions are based on 1.20 PUE, discovery of 1.30+ PUE in Phase 1 forces retrofits (EUR 200M–400M for hybrid cooling or battery storage) or load shedding (curtailment clauses in tenant leases).
- Water-authority permitting is often the bottleneck for large-scale cooling. Hauts-de-France sits in a water-stressed catchment (Artois-Picardie Agence de l'Eau); pre-emptive dialogue with water authorities (Months 1–2 = 2026-11-17 to 2026-12-17) and a pre-agreed drought-response protocol (load shedding up to X% during declared drought, with tenant lease carve-out) reduce mid-Phase-1 permitting surprises.
- Heat-reuse infrastructure (EUR 50M–100M insulated pipelines, heat exchangers, pump stations) is sunk cost if no offtake is signed; many data-center projects plan heat reuse as a community benefit but fail to close commercial contracts, leaving infrastructure dormant. Early identification of credible heat customers (Months 2–4 = 2026-12-17 to 2027-02-17) and binding offtake agreements (Months 5–9 = 2027-03-17 to 2027-07-17) are essential to justify capex.
- Phase 1 design-day thermal validation (35°C ambient, full 500 MW load, worst-case cooler fouling) must be stress-tested against RTE's grid-reinforcement budget and BESS sizing; if peak load forecast escalates late in Phase 0 or early Phase 1, carrying cost and redesign cost are substantial.


## 5. ANSSI National-Security Review Pathway and Foreign Co-Investor Clearance

Foreign co-investor involvement and sovereign-AI tenants trigger national-security review by ANSSI/DGSI, which is the longest-lead external decision (12–18 months, uncontrolled until started). Blocking concerns on foreign ownership or data-residency policies can emerge late and force co-investor restructuring or tenant-mix redesign mid-Phase-1. Early ANSSI engagement (Months 0–1 = 2026-10-17 to 2026-11-17) and a clear security-design governance roadmap reduce surprise delays.

### Data to Collect

- ANSSI/DGSI preliminary opinion on data-residency policies, foreign co-investor governance restrictions, and foreign-ownership limits acceptable for this site
- Foreign-investment screening clearance (CFIUS if any US hyperscaler is involved; EU foreign-direct-investment review if non-EU sovereign co-investors are involved)
- Security-design governance roadmap: perimeter hardening, anti-drone systems, OT-network cyber separation, personnel security clearance requirements (SB–Défense or equivalent)
- Timeline for formal ANSSI national-security review starting Month 13 (2027-11-17) and target completion (12–18 months estimated, all uncontrolled until ANSSI issues review schedule)
- Data-residency and tenant-access control policies for sovereign vs. hyperscaler vs. general-commercial tenants

### Simulation Steps

- Develop a security-design governance white paper (10–15 pages) by Month 2 (2026-12-17) covering: (i) anticipated tenant mix (e.g., 30% hyperscaler, 50% sovereign-AI, 20% commercial), (ii) data-residency requirements (e.g., all data must reside on French territory, no transatlantic routing), (iii) foreign co-investor structure and voting rights, (iv) preliminary security architecture (perimeter security, OT-network isolation, supply-chain vetting), (v) governance structure (board composition, state-observer roles if required). Use this as an ANSSI engagement document.
- Conduct a security architecture and design roadmap study (EUR 500K–1.5M) by Month 2 (2026-12-17), engaging a high-assurance security consultant with ANSSI/DGSI experience to specify: baseline perimeter design (height, anti-climb, setbacks per security standard), CCTV and access-control architecture, OT-network logical separation (air-gap vs. 2-factor authentication), personnel-clearance process (SB–Défense threshold for certain roles), supply-chain security vetting for critical components. Use this roadmap to inform ANSSI's preliminary assessment.
- Model three tenant-governance and data-residency scenarios: (i) hyperscaler-only (standard governance, data residency France), (ii) mixed hyperscaler + sovereign (dual-zone architecture with segregated high-security halls), (iii) EU-public-consortium (multi-country data-residency and governance complexity). Estimate capex and timeline impact per scenario (sovereign partitions add EUR 50M–200M security investment, dual-zone fiber routing adds EUR 100M–300M, estimate).

### Expert Validation Steps

- Confidential pre-submission meeting with ANSSI/DGSI (proposed Month 0, 2026-10-17, or Month 1 = 2026-11-17, led by sponsor CEO and legal/security leads) to present the white paper and preliminary security-design roadmap; request ANSSI's informal guidance on foreign co-investor acceptability, data-residency requirements, and formal review timeline.
- ANSSI written preliminary opinion (Month 6 = 2027-04-17 target, uncontrolled) confirming: (i) formal security review can commence at Month 13 (2027-11-17) (one month after Phase 1 FID), (ii) no fundamental blocking concerns on foreign equity or tenant mix, (iii) security-design roadmap is acceptable at a high level, (iv) estimated formal-review timeline (typically 12–18 months from initiation).
- Foreign-investment screening clearance (CFIUS if a US hyperscaler is a material tenant, or EU foreign-direct-investment review if non-EU sovereign funds are co-investors) should be pre-tested in parallel (Months 1–6 = 2026-11-17 to 2027-04-17) with informal guidance from relevant authorities; binding clearance is not required for Phase 1 FID but unresolved issues should be flagged by Month 9 (2027-07-17).

### Responsible Parties

- National Security and Regulatory Affairs Lead (lead, ANSSI/DGSI liaison)
- Security Architect (security-design roadmap development)
- Infrastructure Finance Lead (co-investor governance structure and compliance with capital-control regulations)
- Anchor-Tenant and Commercial Lead (tenant mix impact on security and data-residency requirements)

### Assumptions

- **High:** ANSSI will issue a preliminary opinion by Month 6 (2027-04-17) confirming that formal security review can start by Month 13 (2027-11-17) with no fundamental blocking concerns on foreign co-investor involvement or data-residency policies. ANSSI review timelines are uncontrolled; preliminary opinions often take 3–4 months, and blocking concerns can emerge requiring significant co-investor restructuring.
- **High:** Foreign co-investors (proposed infrastructure funds with possible EU sovereign-fund involvement) will be acceptable to ANSSI provided they hold no control stake (board seat, veto rights) and are EU-domiciled. If non-EU or China-linked capital is involved, ANSSI review will be more intensive and may impose restrictions on tenant access, data flows, or technology.
- **Medium:** Formal ANSSI national-security review will commence at Month 13 (2027-11-17) (one month post-Phase-1 FID) and complete within 12–18 months (by Months 25–31 = 2028-11-17 to 2029-05-17). If review is delayed or unresolved at first-block energization (Month 42 = 2030-04-17), some tenants (particularly sovereign-AI users) may defer commitments pending clearance, affecting Phase 1 revenue ramp.
- **Medium:** Security-design governance roadmap (perimeter, OT separation, personnel vetting) will satisfy ANSSI's preliminary expectations. If ANSSI's formal review uncovers additional requirements (e.g., state observer role, real-time monitoring of certain data flows, export-control compliance), security capex and operational complexity escalate (EUR 100M–300M additional, estimate), potentially triggering Phase 1 budget breach.
- **Low:** Sovereign-AI and defense-adjacent tenants (e.g., French State AI office, NATO-member defense agencies) will be attracted to the campus due to the hardened security posture and domestic location, paying lease premiums (5–15% higher than commercial hyperscalers, estimate) to offset the security capex and operational overhead.

### SMART Validation Objective

By Month 6 (2027-04-17), obtain ANSSI written preliminary opinion confirming: (i) no fundamental blocking concerns on foreign co-investor involvement or tenant mix, (ii) formal security review can commence within one month of Phase 1 FID submission (Month 13 = 2027-11-17), (iii) security-design roadmap is acceptable at a high level. By Month 12 (2027-10-17) Phase 1 FID, document ANSSI's review timeline and any interim compliance conditions (e.g., personnel-clearance process start, interim access controls). If ANSSI signals a review timeline beyond Month 30 (2029-04-17) or identifies fundamental blocking concerns, Phase 1 is paused and co-investor/tenant mix is reassessed.

### Notes

- ANSSI review is the slowest external gating decision (12–18 months uncontrolled); early pre-submission dialogue (Months 0–1 = 2026-10-17 to 2026-11-17) and a credible security-design roadmap reduce surprise delays, but no guarantee of fast-track exists.
- Foreign co-investor involvement (proposed infrastructure funds with potential EU sovereign co-investors) is politically sensitive; ANSSI will scrutinize ownership structures, beneficial owners, capital-control compliance, and geopolitical affiliations. A transparent co-investor governance structure (non-controlling stakes, EU domicile, published board composition) helps ANSSI clearance.
- Sovereign-AI tenants (French State, EU CEPIs) may require segregated high-security compute halls, dedicated fiber routing, and state-observer rights; these requirements add security capex (EUR 50M–200M, estimate) and operational complexity. Early tenant engagement (Months 2–4 = 2026-12-17 to 2027-02-17) on security requirements informs Phase 1 design and ANSSI roadmap.
- US hyperscaler involvement triggers CFIUS review (Committee on Foreign Investment in the US); if the hyperscaler is classified as 'critical-infrastructure-dependent' or handles sensitive datasets, CFIUS may require long-form review (6–12 months, estimate) before the lease is finalized. Pre-testing CFIUS appetite for this campus (Months 3–6 = 2027-01-17 to 2027-04-17) via informal inquiry reduces late-stage surprise delays.


## 6. Municipal and Community-Stakeholder Engagement and Social-License Gate

Social license and permitting (Decisions 4 and the permitting outcome) depend on municipal and community support. Farmland displacement of 10,000+ ha is contentious; farm-union opposition (FNSEA, Confédération Paysanne) can delay permits by 12–36 months or force design changes increasing capex 5–15% (EUR 250M–1.5B, estimate). Early engagement (Months 1–3 = 2026-11-17 to 2027-01-17) and binding community benefits (Months 5–9 = 2027-03-17 to 2027-07-17) reduce opposition escalation.

### Data to Collect

- Municipal liaison-committee outcomes: attendance, positions (support, neutral, opposition), blocking concerns identified from mayors, regional councillors, NGO representatives
- Social-impact study findings: farmer concerns (displacement, compensation level, lease-and-continue feasibility), resident concerns (noise, light, security perception, employment benefits), NGO positions (ecological impact, water use, farmland loss)
- Community-benefit package: signed commitment from ≥2 of 3 most-affected municipalities (Cambrai, Dunkirk, Valenciennes or Saint-Omer) endorsing Phase 1
- Binding community-benefit agreement: EUR 50M–150M commitments (direct income to municipalities, farm-relocation packages, ecological restoration, local employment, infrastructure upgrades), contingent on Phase 1 permits
- Permitting-timeline feedback from DREAL and prefectures: any anticipated blocking concerns, required design modifications (e.g., ecological offsets, buffer zones, alternative sites)

### Simulation Steps

- Conduct social-impact survey (USD 300K–600K) by Month 1 (2026-11-17), targeting ≥100 farmers (interviews), ≥500 residents (survey questionnaire), ≥5 environmental NGOs (meetings); document top concerns, willingness-to-accept thresholds for displacement and ecological trade-offs, and perceived benefits (jobs, infrastructure, heat reuse). Use survey software (Qualtrics, SurveySparrow) and qualitative-research methods (focus groups, key-informant interviews) to triangulate findings.
- Model community-benefit package scenarios: (i) EUR 50M package (EUR 10M to municipalities, EUR 20M farm relocation, EUR 15M ecology, EUR 5M training), (ii) EUR 100M package (EUR 20M to municipalities, EUR 40M farm relocation, EUR 25M ecology, EUR 15M training), (iii) EUR 150M package (EUR 30M to municipalities, EUR 60M farm relocation, EUR 35M ecology, EUR 25M training). Estimate willingness-to-accept improvement as benefit scale increases; target the minimum package that overcomes majority opposition in each zone.
- Run permitting-timeline simulations with DREAL and prefecture: estimate 18–30 months for standard ICPE and environmental authorization, plus 24–48 months for legal appeals if opposition is organized. Model the impact of ecological offsets, buffer-zone redesign, and permit conditions on Phase 1 capex and schedule (assume 5–15% cost escalation for design modifications, 3–6 month schedule slip for appeal periods, estimate).

### Expert Validation Steps

- Municipal Liaison Committee meetings (quarterly, Months 1, 4, 7, 10 = 2026-11-17, 2027-02-17, 2027-05-17, 2027-08-17) with published minutes within 2 weeks; committee includes mayors, regional councillors, farm-union representatives, environmental NGOs (minimum 5–8 members per committee), and a neutral facilitator. Committee members are invited to provide feedback on draft Phase 1 design, permitting strategy, and community-benefit proposals.
- DREAL prefectural office consultation (Months 1–2 = 2026-11-17 to 2026-12-17) to present the Phase 0 approach, environmental baseline, and permitting strategy; obtain informal feedback on anticipated blocking concerns and permit-pathway recommendations (standard ICPE vs. environmental authorization prioritization, ecological-compensation feasibility).
- Binding community-benefit agreement signed by ≥2 of 3 most-affected municipalities by Month 9 (2027-07-17); agreement specifies EUR amounts (direct income indexed to inflation, farm relocation at 1.5–2.0× land value, ecological restoration EUR/ha, training program enrollment targets), implementation timeline (percent of Phase 1 capex), and accountability (third-party monitoring role for municipalities/NGOs). Legal binding and financial commitment are essential; non-binding 'memoranda of understanding' do not satisfy the gate.

### Responsible Parties

- Community Engagement and Social-License Manager (lead, liaison committee chair)
- Environmental and Permitting Counsel (ecology and permit-strategy coordination)
- Land Assembly and Real Estate Strategist (farm-relocation packages and lease-and-continue terms)
- Infrastructure Finance Lead (community-benefit budget integration into Phase 1 capex)

### Assumptions

- **High:** At least 2 of the 3 most-affected municipalities will sign a binding community-benefit agreement by Month 9 (2027-07-17), committing to Phase 1 permitting support. If fewer than 2 municipalities sign, social-license gate fails and Phase 1 is paused pending redesign or alternative-site evaluation.
- **High:** A community-benefit package of EUR 50M–150M (over Phases 1–2) will overcome majority opposition from farmers and residents, conditional on credible implementation (binding agreement, third-party monitoring, real-time fund disbursement). If opposition persists despite benefits, permits may be blocked or conditions imposed that increase capex >15%.
- **Medium:** Farm-displacement compensation of 1.5–2.0× benchmark land value (EUR 22,500–50,000/ha) will satisfy >70% of affected farmers. If market conditions or holdout leverage drive required compensation to >2.0× (EUR 30,000–75,000/ha), land-acquisition cost escalates by EUR 100M–300M (estimate).
- **Medium:** Lease-and-continue farming arrangements (allowing farmers to operate on buffer and continuation zones for the lifecycle of the campus) will be accepted by >50% of agricultural landowners, reducing cash-compensation and relocation-package costs. If lease-and-continue is not accepted, all agricultural land must be purchased at full premium, escalating cost.
- **Medium:** Ecological compensation and monitoring will be co-managed with environmental NGOs and conservation bodies, building credibility with permitting authorities and reducing appeal risk. If NGOs view compensation as inadequate and launch legal challenges, permits are delayed 12–24 months.

### SMART Validation Objective

By Month 9 (2027-07-17), secure written support (formal resolution or signed letter) from at least 2 of the 3 most-affected municipalities, with a binding community-benefit agreement totaling EUR 50M–150M over Phases 1–2, specifying direct municipal income, farm-relocation packages (1.5–2.0× land value), ecological restoration (EUR/ha), local employment targets, and monitoring roles. By Month 12 (2027-10-17) Phase 0 gate, confirm no major legal challenges pending and majority stakeholder-engagement outcomes documented.

### Notes

- Farm-sector opposition in Hauts-de-France is organized and powerful (FNSEA, Confédération Paysanne have political leverage in regional councils); early engagement (Months 1–2 = 2026-11-17 to 2026-12-17) and credible relocation/lease-and-continue terms are essential to convert opposition into neutrality or support.
- Environmental NGO support (or at least neutrality) is a permit-application prerequisite in France; ecological offsetting and co-management arrangements (e.g., NGO role in monitoring habitat restoration) reduce appeal risk from environmental groups.
- Municipal signatures on the community-benefit agreement carry political weight with prefectural authorities (DREAL, prefecture); mayors' endorsement signals that local concerns have been addressed and strengthens permit applications.
- Community-benefit budget (EUR 50M–150M, estimate) sits outside or overlaps with the Phase 1 capex (EUR 5B–10B); clarification of funding source (phase-1 capex, separate sponsor equity, or third-party grants) is essential by Month 12 (2027-10-17) to reconcile budget headroom.

## Summary

This phase-0 feasibility plan for a notional 9 GW, 161 km² AI campus in Hauts-de-France is a gate-driven, evidence-based stress-test that validates or kills the project based on six critical data-collection areas: (1) RTE grid hosting capacity (primary kill test, ≥500 MW by Month 6 = 2027-04-17), (2) land assembly (≥70% contiguous or split-campus feasibility by Month 4 = 2027-02-17), (3) anchor-tenant binding commitments (≥30% of Phase 1 signed by Month 9 = 2027-07-17), (4) thermal design and water-authority clearance (PUE ≤1.28 modeled, dry-cooler feasibility confirmed by Month 6 = 2027-04-17), (5) ANSSI national-security review pathway (preliminary opinion by Month 6 = 2027-04-17, formal review timeline confirmed), and (6) community and municipal social license (≥2 of 3 municipalities signed and supportive by Month 9 = 2027-07-17). A Phase 0 budget cap of EUR 750M (four milestone tranches) and an independent investment committee with numeric kill thresholds, external red-team oversight, and supermajority override authority enforce gate discipline against sunk-cost momentum. Phase 1 FID (Month 12 = 2027-10-17) is contingent on all six gates passing (or conditional pass with documented mitigation); failure on any gate triggers downsize, split-campus pivot, delay, or cancellation. Simulation steps use industry-standard tools (RTE-compatible grid modeling, GIS parcel mapping, thermal modeling, ESA software, tenant-finance modeling); expert validation steps require written engagement and formal opinions from RTE, DREAL, water authorities, ANSSI, lenders, and municipalities. Key sensitivities: RTE's response timeline is uncontrolled and may invert the topology-decision sequence (mitigation: move topology gate to Month 6.5 = 2027-05-02); land assembly is doubtful for 161 km² contiguous (mitigation: split-campus design in parallel); anchor-tenant LOIs are non-binding (mitigation: require cash reservation fees and liquidated-damages clauses); thermal validation is deferred (mitigation: commission independent audit and hard PUE gate by Month 5 = 2027-03-17); social-license shortfall can delay permits 12–36 months (mitigation: early municipal engagement and binding community-benefit agreement by Month 9 = 2027-07-17). Immediate actions: (1) Charter the independent investment committee and lock numeric kill thresholds by Month 1 (2026-11-17); (2) file RTE pre-engineering request and commission independent grid audit by Month 0 (2026-10-17); (3) launch land-assembly surveys and environmental baselines by Month 1 (2026-11-17); (4) initiate ANSSI and water-authority pre-submission dialogue by Month 0 (2026-10-17); (5) identify anchor tenants and launch reservation-fee discussion by Month 1 (2026-11-17); (6) establish municipal liaison committee and commission social-impact study by Month 1 (2026-11-17). Success measure: Phase 1 FID with signed debt (≥EUR 3B), anchor tenants (≥30% of 500 MW), and Phase 2 demand (≥50% signed) unlocked by Month 36 (2029-10-17) energization. Failure or downsize is a legitimate outcome if gates fail.