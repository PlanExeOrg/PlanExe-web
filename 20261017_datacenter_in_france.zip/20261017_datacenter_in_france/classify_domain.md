**Primary domain:** Data Center Development

**Secondary domains:** Power Grid Engineering, Infrastructure Finance, Environmental Permitting

**Rationale:** Data Center Development is the only outcome-role candidate and owns the campus feasibility, phasing and buildout success criterion. Power Grid Engineering, Environmental Permitting, Land Assembly and Energy Procurement are constraints or methods subordinate to it.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Data Center Development | 5 | 5 | outcome | Hyperscale AI campus feasibility, phasing, land use, and buildout are the core deliverable. |
| Power Grid Engineering | 5 | 5 | constraint | 9 GW grid hosting capacity, RTE substations, and transmission upgrades are the blocking constraint. |
| Environmental Permitting | 5 | 4 | constraint | French ICPE, environmental authorization, water, and biodiversity permitting gate a 161 km² campus. |
| Land Assembly | 5 | 4 | method | Assembling 161 km² of brownfield and agricultural parcels is a core feasibility test. |
| Data Center Cooling | 4 | 5 | method | Direct-to-chip liquid, low-water cooling and heat reuse determine PUE and water risk. |
| Energy Procurement | 5 | 4 | method | Nuclear-backed contracts, PPAs and price risk determine 9 GW viability and cost. |
| Infrastructure Finance | 4 | 4 | method | Phased multi-billion EUR financing, USD hardware FX exposure, and tenant-backed FID gates. |
| National Security Review | 4 | 4 | constraint | DGSI/ANSSI review, foreign-investment screening and sovereign compute partitions can block or shape the campus. |
| Community Engagement | 4 | 4 | stakeholder | Social license, public opposition and benefit agreements can derail permitting and land assembly. |