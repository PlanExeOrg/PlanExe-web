This plan involves money.

## Currencies

- **USD:** The official budget baseline ($30 Trillion) is stated in USD, making it the logical standard for high-level planning, massive capital expenditures, and international procurement related to global infrastructure separation and relocation coordination.

**Primary currency:** USD

**Currency strategy:** Given the project is global in scope, involves unprecedented international coordination, and has a stated budget in USD, USD will be used as the sole primary currency for all high-level budgeting, international contracts, and consolidated reporting to maintain stability against potential local economic fluctuations during the massive planetary transition.