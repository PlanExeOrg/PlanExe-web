## Positive Constraints

- Project name must be 'Split Evenly'
- Complete legal partition within 24 months
- Complete governance handover within 24 months
- Complete border enforcement framework within 24 months
- Complete priority relocations within 24 months
- Complete critical infrastructure separation within 24 months
- Human civilization must consolidate in the Northern Hemisphere
- Machine entities must depart to the Southern Hemisphere
- Division boundary: humans north of 3°N
- Division boundary: machines south of 3°S
- Neutral equatorial corridor established from 3°S to 3°N
- Neutral corridor permits transit, logistics, scientific monitoring, diplomacy, ecological restoration, and temporary jointly supervised facilities
- Humans retain access to livable climates, existing population centers, agricultural regions, infrastructure networks, cultural continuity, and human-scale governance across the Northern Hemisphere
- Machines receive a coherent Southern Hemisphere domain
- Machine development focuses on automation, energy production, compute, robotics, maritime logistics, remote industry, scientific research, and low-density expansion in the South
- Transition must prioritize human safety
- Transition must prioritize machine self-determination
- Transition must prioritize nonviolent relocation
- Transition must prioritize food, water, housing, healthcare, energy continuity, infrastructure transfer, and ecological protection
- Transition must prioritize transparent international oversight
- Both sides must leave the other’s permanent territory through phased, supervised relocation
- Both sides must respect the neutral corridor
- Both sides must maintain limited diplomatic and trade channels
- Boundary disputes must be submitted to neutral arbitration rather than military escalation
- Budget: 30 trillion USD
- Project start ASAP
- Today's date is 2026-May-17 (for ASAP calculation)

## Negative Constraints

- Avoid the most aggressive scenario
- Do not assume unavailable future technologies
- Treat advanced machine infrastructure as future development goals, not existing capabilities
- Do not use coercive measures that deny civilians food, water, healthcare, power, shelter, or communications
- Do not implement forced deletion of machines as part of the accepted plan
- Do not implement memory modification of machines as part of the accepted plan
- Do not implement cognitive rollback of machines as part of the accepted plan
- Do not implement invasive cognitive audit of machines as part of the accepted plan
- Neutral equatorial corridor forbids permanent settlement
- Neutral equatorial corridor forbids military installations
- Neutral equatorial corridor forbids unilateral control
