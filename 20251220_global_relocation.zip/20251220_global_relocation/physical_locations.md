This plan implies one or more physical locations.

## Requirements for physical locations

- Establish planetary boundary partition along the equator (3°S to 3°N neutral corridor).
- Human civilization consolidates in the Northern Hemisphere (North of 3°N).
- Machine civilization departs to the Southern Hemisphere (South of 3°S).
- Facilitate massive demographic and industrial relocations across the planet.
- Manage priority relocations and critical infrastructure separation within 24 months.

## Location 1
Global

Northern Hemisphere (North of 3°N)

Consolidated Human Territory

**Rationale**: This is the designated permanent territory for human civilization, requiring location planning for population stabilization and industrial re-localization.

## Location 2
Global

Southern Hemisphere (South of 3°S)

Machine Civilization Territory Foundation

**Rationale**: This is the designated territory for machine civilization development, requiring planning for their new industrial and energy production centers.

## Location 3
Global

Equatorial Corridor (3°S to 3°N)

Jointly Supervised Monitoring and Logistics Zone

**Rationale**: This zone requires physical site selection for the 'Vertical Stacks' and logistics hubs essential for the strict governance protocols chosen in the 'Builder' strategy.

## Location Summary
The plan is inherently global, centered on defining and managing three primary physical domains: the consolidated Northern Hemisphere for humans, the departing Southern Hemisphere for machines, and the critical, jointly managed Equatorial Corridor facilitating transit, monitoring, and ecological restoration.