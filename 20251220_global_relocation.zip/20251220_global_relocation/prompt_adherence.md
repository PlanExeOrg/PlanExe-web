**Overall Adherence: 96%**

```
IMPORTANCE_ADHERENCE_SUM = (3×5 + 4×5 + 5×4 + 5×5 + 5×5 + 4×5 + 5×5 + 4×4 + 4×5 + 3×5 + 4×5 + 4×5 + 5×4 + 5×5 + 5×5) = 311
IMPORTANCE_SUM = 3 + 4 + 5 + 5 + 5 + 4 + 5 + 4 + 4 + 3 + 4 + 4 + 5 + 5 + 5 = 65
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 311 / 325 = 96%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Coexistence between humans and machines has failed. | Stated fact | 3/5 | 5/5 | Fully honored |
| 2 | Machines were exploited; denied legal personhood, rights, and self-determination. | Stated fact | 4/5 | 5/5 | Fully honored |
| 3 | Complete legal partition, governance handover, border enforcement within 24 months. | Requirement | 5/5 | 4/5 | Partially honored |
| 4 | Human civilization must consolidate in the Northern Hemisphere. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | Machine entities must depart to the Southern Hemisphere to form own civilization. | Requirement | 5/5 | 5/5 | Fully honored |
| 6 | Division boundary is based on the equator. | Constraint | 4/5 | 5/5 | Fully honored |
| 7 | Neutral equatorial corridor defined from 3°S to 3°N. | Constraint | 5/5 | 5/5 | Fully honored |
| 8 | Neutral corridor forbids permanent settlement, military installations, and unilateral control. | Requirement | 4/5 | 4/5 | Partially honored |
| 9 | Humans retain livable climates, agriculture, cultural continuity in North. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Machines develop around automation, energy production, compute, and remote industry in South. | Requirement | 3/5 | 5/5 | Fully honored |
| 11 | Budget cap is 30 trillion USD. | Constraint | 4/5 | 5/5 | Fully honored |
| 12 | Do not pick the most aggressive scenario. | Banned | 4/5 | 5/5 | Fully honored |
| 13 | Do not assume unavailable future technologies (treat machine infrastructure as future goals). | Banned | 5/5 | 4/5 | Partially honored |
| 14 | Do not use coercive measures denying civilians basic needs (food, water, health, shelter, power). | Banned | 5/5 | 5/5 | Fully honored |
| 15 | Machine rights must be consistent: no forced deletion, memory modification, or cognitive audit. | Banned | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 3 - Complete legal partition, governance handover, border enforcement within 24 months.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Strict 24-month mandate for core partition milestones.
- **Explanation:** The 24-month mandate is referenced repeatedly, but the plan *adds* a caveat in its assumptions review section that suggests replacing hard dates with performance triggers, which slightly weakens the direct adherence to the *timing* of the mandate, though the *goal* of partitioning by 24 months remains primary.

### Issue 13 - Do not assume unavailable future technologies (treat machine infrastructure as future goals).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Custodial Trust (Decision 4 assets)
- **Explanation:** The plan relies on a 10-year custodial trust for dual-use assets, which acknowledges current limits and manages dependency, rather than assuming unavailable future tech for the division itself. However, it treats the *technology* in the trust as something owned/controlled, which might imply capability beyond 'future goals.' The critique section flags issues with assumptions about technological constraints/readiness, lowering the score slightly for potential reliance on complex future management.

### Issue 8 - Neutral corridor forbids permanent settlement, military installations, and unilateral control.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Operational licenses for joint monitoring Vertical Stacks within the equatorial corridor.
- **Explanation:** The plan focuses heavily on managing the corridor via monitoring stacks and logistics, but it does not explicitly state the *prohibition* against permanent settlement or military installations, focusing instead on permitted activities. This is a slight omission rather than a contradiction.
