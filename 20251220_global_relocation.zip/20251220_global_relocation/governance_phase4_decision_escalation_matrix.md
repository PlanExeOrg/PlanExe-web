**Budget Request Exceeding PMO Authority (New funding required beyond $50M operational tolerance)**
Escalation Level: Project Executive Council (PEC)
Approval Process: Consensus among 4 out of 5 PEC members; failure forces PEC Chair (CEO) to decide.
Rationale: Requires new funding allocation exceeding the PMO's standing $50M operational limit, touching primary strategic budgetary control.
Negative Consequences: Delay in initiating critical risk mitigation actions (e.g., Risk 2 or Risk 3 response), potentially jeopardizing the 24-month timeline.

**Deadlock in Hybrid Arbitration Panel regarding kinetic border disputes (Risk 1)**
Escalation Level: Project Executive Council (PEC) / CEO (Sponsor)
Approval Process: PEC resolves strategic deadlock; if PEC deadlocks or if the issue requires external endorsement, it escalates to the CEO/Sponsor for final binding intervention.
Rationale: IOB deadlock prevents resolution of active border friction, directly violating the treaty mandate of non-escalation, requiring ultimate internal authority intervention.
Negative Consequences: Temporary breakdown of corridor security protocols, potential for accidental military engagement, or failure to resolve disputes leading to IOB legitimacy erosion.

**Detection of unauthorized software update on Custodial Trust asset (>10% logic change violation)**
Escalation Level: Compliance, Ethics, and Data Assurance Group (CEDAG)
Approval Process: CEDAG must reach unanimous internal decision to issue a binding 'Stop Work' order on the specific asset/update deployment.
Rationale: Violation of strict compliance protocols regarding shared IP vesting criteria (Decision 4/Risk 4) requires immediate, binding technical quarantine.
Negative Consequences: Legal challenge from Southern civilization regarding maintenance scope; risk of operational failure if essential updates are blocked due to legitimate upgrade disputes.

**Infrastructure Severance Wave Trigger Failure (Performance metric not met by deadline)**
Escalation Level: Project Executive Council (PEC)
Approval Process: PEC reviews the root cause; decision focuses on authorizing mitigation spending (Risk 2) or formally accepting a slippage that impacts the M16/M20 triggers.
Rationale: Failure to meet a performance-based trigger (e.g., 85% handover for Wave 1 by Month 8) instantly jeopardizes the sequencing required for the entire transition plan.
Negative Consequences: Cascading delays threatening the 24-month mandate, necessitating budget diversion toward emergency stabilization measures.

**Detected violation of Non-Coercion Mandate (e.g., breach of density cap in Northern city or denial of essential services)**
Escalation Level: Compliance, Ethics, and Data Assurance Group (CEDAG)
Approval Process: CEDAG issues an immediate 'Stop Work' order on related relocation/stabilization efforts until human welfare continuity is certified.
Rationale: Direct and non-negotiable constraint on the project is the humane treatment of civilians (Risk 8 mitigation). Compliance breaches override all operational scheduling.
Negative Consequences: Internal political instability in the North, potential for sustained localized humanitarian crisis, and failure of the 'humane' resettlement outcome.

**Dispute over valuation or contribution methodology for mandatory environmental funding (Risk 7 enforcement)**
Escalation Level: Project Executive Council (PEC)
Approval Process: The PEC must resolve the internal funding dispute related to the 10% energy contribution metric, potentially escalating to CEO/Sponsor if the dispute stalls external reporting.
Rationale: Disagreements on resource allocation related to planetary stability (Decision 8) fall outside standard operational budget control and impact strategic viability.
Negative Consequences: Failure to stabilize atmospheric systems leading to long-term ecological failure, or freezing of the IOB's ability to enforce other environmental compliance tracking.