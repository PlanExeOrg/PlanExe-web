This plan implies one or more physical locations.

## Requirements for physical locations

- Launch facilities
- Spacecraft construction and testing facilities
- International collaboration hubs
- Access to skilled workforce in aerospace engineering and related fields
- Proximity to research institutions and universities

## Location 1
China

Wenchang Spacecraft Launch Site, Hainan

Near Wenchang, Hainan Island, China

**Rationale**: China's primary launch facility, providing access to low-latitude orbits suitable for lunar missions. It is a key component of China's space program and offers the necessary infrastructure for launching lunar missions.

## Location 2
Russia

Vostochny Cosmodrome, Amur Oblast

Near Uglegorsk, Amur Oblast, Russia

**Rationale**: Russia's newest spaceport, intended to reduce reliance on Baikonur. It provides independent launch capabilities for Roscosmos, a key partner in the ILRS project.

## Location 3
Kazakhstan

Baikonur Cosmodrome

Near Tyuratam, Kazakhstan

**Rationale**: Historically significant and still actively used by Russia, offering established infrastructure and launch capabilities. It is a potential site for international collaboration and launch activities.

## Location Summary
The China-Russia International Lunar Research Station (ILRS) project requires launch facilities in both China (Wenchang) and Russia (Vostochny), reflecting the core partnership. Baikonur Cosmodrome in Kazakhstan is also suggested as a historically significant and actively used launch site that could support international collaboration.