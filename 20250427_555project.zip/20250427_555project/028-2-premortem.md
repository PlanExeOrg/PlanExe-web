A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The project will maintain consistent financial support from all participating nations throughout its lifecycle. | Secure legally binding financial commitments from all participating nations, with penalties for non-compliance. | Any participating nation refuses to sign a legally binding financial commitment or includes clauses allowing easy withdrawal of funds. |
| A2 | The necessary technologies for autonomous construction, ISRU, and the modular fission reactor will be readily available and integrate seamlessly. | Conduct a Technology Readiness Assessment (TRA) with independent experts for each critical technology. | The TRA reveals that any critical technology is below TRL 6 and lacks a clear path to reach TRL 6 within the project timeline. |
| A3 | The international community will generally support the ILRS project and its goals. | Conduct a global public opinion survey regarding the ILRS project and its perceived benefits and risks. | The survey reveals that a majority of respondents in key non-participating nations view the ILRS project negatively or with significant reservations. |
| A4 | The lunar environment will be stable and predictable, allowing for consistent operation of equipment and infrastructure. | Conduct a detailed analysis of historical lunar environmental data, including radiation levels, temperature variations, and micrometeoroid activity, and develop predictive models. | The analysis reveals significant unpredictable variations in the lunar environment that exceed the design tolerances of critical equipment and infrastructure. |
| A5 | The project will be able to attract and retain a skilled workforce with the necessary expertise in space exploration, robotics, and nuclear engineering. | Conduct a workforce availability study to assess the current and projected supply of qualified personnel in relevant fields. | The study reveals a significant shortage of qualified personnel, with projected demand exceeding supply by more than 20%. |
| A6 | The project's governance structure will be effective in resolving disputes and making timely decisions. | Conduct a simulation of the governance structure, presenting hypothetical scenarios involving conflicting interests and assessing the ability of the structure to reach a resolution. | The simulation reveals significant delays or failures in resolving disputes, indicating that the governance structure is ineffective. |
| A7 | The cost of transporting materials and equipment to the lunar surface will remain within projected estimates. | Obtain firm, fixed-price quotes from multiple launch providers for transporting various payloads to the lunar surface, accounting for different launch windows and potential delays. | The quotes exceed the projected transportation costs by more than 15%, indicating a significant underestimation of logistical expenses. |
| A8 | The lunar surface environment will allow for predictable and safe operation of robotic systems for construction and resource extraction. | Conduct extensive simulations and physical testing of robotic systems in a simulated lunar environment, focusing on dust mitigation, thermal management, and radiation resistance. | The simulations and testing reveal significant performance degradation or failures of robotic systems due to lunar dust, extreme temperatures, or radiation exposure. |
| A9 | The project will maintain consistent public and political support in key participating nations, regardless of short-term setbacks or controversies. | Track public opinion and political sentiment in key participating nations through regular surveys and media analysis, focusing on attitudes towards the ILRS project and its perceived benefits and risks. | Public opinion polls show a significant decline in support for the project in two or more key participating nations, coupled with increased political opposition from influential figures or parties. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Funding Fiasco: When Promises Crumble | Process/Financial | A1 | Financial Strategist | CRITICAL (20/25) |
| FM2 | The Integration Inferno: A Technological Tower of Babel | Technical/Logistical | A2 | Chief Engineer | CRITICAL (25/25) |
| FM3 | The PR Panic: When Public Opinion Turns Toxic | Market/Human | A3 | Communications and Outreach Manager | CRITICAL (15/25) |
| FM4 | The Lunar Weather Woe: When the Moon Bites Back | Process/Financial | A4 | Sustainability and Resource Management Lead | CRITICAL (15/25) |
| FM5 | The Talent Drought: When Brainpower Runs Dry | Technical/Logistical | A5 | Human Resources Manager | CRITICAL (20/25) |
| FM6 | The Gridlock Gamble: When Bureaucracy Bites | Market/Human | A6 | Project Manager | CRITICAL (20/25) |
| FM7 | The Logistical Black Hole: When Costs Launch Out of Control | Process/Financial | A7 | Financial Strategist | CRITICAL (20/25) |
| FM8 | The Robotic Rebellion: When Machines Malfunction on the Moon | Technical/Logistical | A8 | Chief Engineer | CRITICAL (20/25) |
| FM9 | The Political Ice Age: When Public Support Freezes Over | Market/Human | A9 | Communications and Outreach Manager | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Funding Fiasco: When Promises Crumble

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The ILRS project relies heavily on financial commitments from participating nations. If these commitments are not legally binding or if nations withdraw their funding due to economic downturns or political shifts, the project will face severe financial shortfalls. This will lead to delays in critical milestones, reduced scope, and ultimately, project failure.

*   Lack of legally binding financial commitments.
*   Economic downturns in participating nations.
*   Political instability leading to funding withdrawal.
*   Currency fluctuations impacting budget.
*   Insufficient diversification of funding sources.

##### Early Warning Signs
- Participating nations delay scheduled payments.
- Economic indicators in participating nations show a significant downturn.
- Political instability increases in key partner countries.

##### Tripwires
- Total committed funding falls below 80% of the planned budget.
- Three or more participating nations delay payments by more than 60 days.
- The value of CNY or RUB decreases by more than 15% against the USD within a 6-month period.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and renegotiate payment schedules with participating nations.
- Assess: Conduct a thorough financial audit to determine the extent of the shortfall and identify potential cost-saving measures.
- Respond: Actively pursue alternative funding sources, including private investment and international organizations. Consider scaling back project scope or delaying non-critical milestones.


**STOP RULE:** Total committed funding falls below 50% of the planned budget, and alternative funding sources cannot be secured within 180 days.

---

#### FM2 - The Integration Inferno: A Technological Tower of Babel

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Chief Engineer
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The ILRS project aims to integrate several cutting-edge technologies, including autonomous construction, ISRU, and a modular fission reactor. If these technologies are not sufficiently mature or if they cannot be seamlessly integrated, the project will face significant technical challenges. This will lead to delays in construction, increased costs, and potentially, the failure of critical systems.

*   Immature technologies with low TRLs.
*   Compatibility issues between different systems.
*   Lack of standardized interfaces and protocols.
*   Difficulties operating in the lunar environment.
*   Inadequate testing and simulation.

##### Early Warning Signs
- Technology Readiness Assessments (TRAs) reveal low TRLs for critical technologies.
- Integration testing reveals significant compatibility issues.
- Simulations show poor performance in the lunar environment.

##### Tripwires
- Any critical technology fails to reach TRL 6 by the designated milestone date.
- Integration testing reveals more than 50 unresolved compatibility issues.
- Simulations show that the integrated system fails to meet performance requirements in the lunar environment.

##### Response Playbook
- Contain: Immediately halt integration efforts and focus on resolving the underlying technical issues.
- Assess: Conduct a thorough root cause analysis to identify the source of the problems and assess the impact on the project timeline and budget.
- Respond: Revise the technology roadmap, invest in alternative technologies, or consider scaling back project scope to focus on more mature and easily integrated systems.


**STOP RULE:** The integrated system fails to demonstrate basic functionality in a simulated lunar environment after three attempts, and no viable alternative technologies are available.

---

#### FM3 - The PR Panic: When Public Opinion Turns Toxic

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Communications and Outreach Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The ILRS project requires broad international support to succeed. If public opinion turns negative due to concerns about environmental impact, geopolitical tensions, or ethical considerations, the project will face significant challenges. This will lead to reduced funding, political opposition, and potentially, project cancellation.

*   Negative media coverage.
*   Public protests and demonstrations.
*   Political opposition from key nations.
*   Ethical concerns about lunar resource utilization.
*   Geopolitical tensions impacting international collaboration.

##### Early Warning Signs
- Negative media coverage increases significantly.
- Public opinion polls show declining support for the project.
- Political opposition to the project grows in key nations.

##### Tripwires
- Negative media coverage exceeds 60% of total media mentions.
- Public opinion polls show support for the project falling below 40%.
- A major political party in a key participating nation publicly opposes the project.

##### Response Playbook
- Contain: Immediately launch a proactive public relations campaign to address public concerns and highlight the project's benefits.
- Assess: Conduct a thorough analysis of public sentiment to identify the root causes of the negative perception.
- Respond: Revise the project plan to address ethical and environmental concerns, enhance transparency, and actively engage with stakeholders to build trust and support.


**STOP RULE:** Public opinion polls show support for the project falling below 25%, and no viable strategies can be identified to regain public trust within 90 days.

---

#### FM4 - The Lunar Weather Woe: When the Moon Bites Back

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Sustainability and Resource Management Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The ILRS project assumes a stable and predictable lunar environment. However, unexpected solar flares, micrometeoroid storms, or extreme temperature fluctuations could damage equipment, disrupt operations, and increase maintenance costs. This will lead to budget overruns, delays in critical milestones, and potentially, project failure.

*   Unexpected solar flares exceeding radiation shielding capacity.
*   Micrometeoroid storms causing damage to infrastructure.
*   Extreme temperature fluctuations exceeding equipment tolerances.
*   Lunar dust accumulation impacting equipment performance.
*   Lack of robust environmental monitoring and prediction systems.

##### Early Warning Signs
- Increased solar flare activity detected by space weather monitoring systems.
- Unexpected spikes in micrometeoroid detection rates.
- Unusually high temperature variations recorded by lunar sensors.

##### Tripwires
- Radiation levels exceed safe limits for unprotected equipment for more than 72 hours.
- Micrometeoroid impact density increases by more than 50% compared to historical averages.
- Temperature variations exceed design tolerances of critical equipment by more than 10%.

##### Response Playbook
- Contain: Immediately activate emergency protocols to protect crew and equipment.
- Assess: Conduct a thorough damage assessment to determine the extent of the impact and identify critical system failures.
- Respond: Implement emergency repair procedures, deploy backup systems, and adjust operational schedules to minimize disruption.


**STOP RULE:** A catastrophic environmental event causes irreparable damage to critical infrastructure, rendering the lunar base uninhabitable for more than 180 days.

---

#### FM5 - The Talent Drought: When Brainpower Runs Dry

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Human Resources Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The ILRS project requires a highly skilled workforce with expertise in space exploration, robotics, and nuclear engineering. If the project is unable to attract and retain qualified personnel, it will face significant technical challenges. This will lead to delays in technology development, reduced innovation, and potentially, the failure of critical systems.

*   Shortage of qualified personnel in relevant fields.
*   Competition from other space exploration initiatives.
*   Lack of attractive compensation and benefits packages.
*   Difficulties obtaining necessary visas and work permits.
*   Brain drain to other projects or industries.

##### Early Warning Signs
- High employee turnover rates in key technical roles.
- Difficulty filling open positions with qualified candidates.
- Declining applications for technical positions.
- Negative feedback from employees regarding compensation and working conditions.

##### Tripwires
- Employee turnover rate in key technical roles exceeds 20% per year.
- Open technical positions remain unfilled for more than 90 days.
- The project loses three or more key technical experts to competing projects within a 6-month period.

##### Response Playbook
- Contain: Immediately implement retention strategies, including salary increases, improved benefits, and enhanced career development opportunities.
- Assess: Conduct an employee satisfaction survey to identify the root causes of the talent shortage and assess the impact on project performance.
- Respond: Revise recruitment strategies, partner with universities to develop training programs, and lobby for more favorable immigration policies.


**STOP RULE:** The project is unable to fill critical technical positions for more than 180 days, and technology development milestones are delayed by more than 6 months.

---

#### FM6 - The Gridlock Gamble: When Bureaucracy Bites

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The ILRS project relies on a multi-tiered governance structure with consensus-based decision-making. If this structure proves ineffective in resolving disputes and making timely decisions, the project will face significant delays and inefficiencies. This will lead to missed milestones, increased costs, and potentially, project failure.

*   Conflicting interests between participating nations.
*   Bureaucratic delays in decision-making.
*   Lack of accountability and transparency.
*   Ineffective dispute resolution mechanisms.
*   Political interference from participating nations.

##### Early Warning Signs
- Frequent disagreements and deadlocks in steering committee meetings.
- Delays in approving critical project milestones.
- Lack of transparency in decision-making processes.
- Complaints from participating nations about unfair treatment or lack of influence.

##### Tripwires
- More than 25% of steering committee decisions require more than 60 days to reach a consensus.
- Three or more participating nations formally protest the governance structure or decision-making processes.
- A critical project milestone is delayed by more than 90 days due to governance issues.

##### Response Playbook
- Contain: Immediately convene a crisis management team to address the governance issues and facilitate a resolution.
- Assess: Conduct a thorough review of the governance structure and decision-making processes to identify the root causes of the problems.
- Respond: Revise the governance charter to clarify roles and responsibilities, streamline decision-making processes, and establish more effective dispute resolution mechanisms.


**STOP RULE:** The governance structure proves incapable of resolving critical disputes, and project milestones are delayed by more than 180 days, jeopardizing the overall project timeline.

---

#### FM7 - The Logistical Black Hole: When Costs Launch Out of Control

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Financial Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The ILRS project's financial viability hinges on accurate projections of transportation costs to the lunar surface. If these costs significantly exceed estimates due to unforeseen factors like launch vehicle failures, fuel price increases, or limited launch windows, the project will face severe budget constraints. This will lead to delays in deploying critical infrastructure, reduced scope, and potentially, project cancellation.

*   Launch vehicle failures increasing insurance premiums and launch costs.
*   Fuel price increases impacting transportation expenses.
*   Limited launch windows causing delays and increased storage costs.
*   Unexpected technical challenges in spacecraft design and development.
*   Lack of competition among launch providers driving up prices.

##### Early Warning Signs
- Launch providers announce significant price increases.
- Launch vehicle failure rates increase.
- Delays in spacecraft development push back launch schedules.
- Fuel prices spike due to geopolitical instability.

##### Tripwires
- Transportation costs exceed projected estimates by more than 20%.
- Two or more launch vehicle failures occur within a 12-month period.
- The cost of fuel increases by more than 25% within a 6-month period.

##### Response Playbook
- Contain: Immediately renegotiate launch contracts, explore alternative launch providers, and optimize payload configurations to reduce weight and volume.
- Assess: Conduct a thorough analysis of transportation costs to identify the root causes of the overruns and assess the impact on the project budget.
- Respond: Revise the project scope, prioritize essential infrastructure, and delay non-critical deployments to reduce transportation requirements. Actively pursue alternative funding sources to offset the increased costs.


**STOP RULE:** Transportation costs exceed projected estimates by more than 50%, and no viable strategies can be identified to reduce costs or secure additional funding within 180 days.

---

#### FM8 - The Robotic Rebellion: When Machines Malfunction on the Moon

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Chief Engineer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The ILRS project relies heavily on robotic systems for autonomous construction and resource extraction. If the lunar surface environment proves more challenging than anticipated, these robotic systems may experience performance degradation or failures. This will lead to delays in building the lunar base, reduced resource availability, and potentially, the failure of critical life support systems.

*   Lunar dust causing mechanical failures and overheating.
*   Extreme temperature variations damaging sensitive components.
*   Radiation exposure degrading electronic systems.
*   Unexpected geological features hindering robotic navigation.
*   Software glitches and communication failures disrupting autonomous operations.

##### Early Warning Signs
- Robotic systems experience frequent malfunctions and require extensive maintenance.
- Performance of robotic systems degrades significantly in the lunar environment.
- Simulations reveal unexpected challenges in robotic navigation and resource extraction.

##### Tripwires
- Robotic systems experience more than 3 critical failures per month.
- Resource extraction rates fall below 50% of projected levels.
- Autonomous construction progress falls behind schedule by more than 3 months.

##### Response Playbook
- Contain: Immediately halt robotic operations and implement emergency protocols to protect the systems from further damage.
- Assess: Conduct a thorough analysis of the robotic systems to identify the root causes of the failures and assess the impact on project timelines and resource availability.
- Respond: Revise robotic designs to improve dust mitigation, thermal management, and radiation resistance. Implement redundant systems and remote control capabilities to enhance reliability and operational flexibility. Consider deploying human crews to assist with critical tasks.


**STOP RULE:** Robotic systems prove incapable of performing essential construction or resource extraction tasks, and no viable solutions can be identified within 180 days, jeopardizing the long-term sustainability of the lunar base.

---

#### FM9 - The Political Ice Age: When Public Support Freezes Over

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Communications and Outreach Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The ILRS project requires sustained public and political support in key participating nations to secure funding and maintain international collaboration. If public opinion turns negative due to short-term setbacks, controversies, or shifting political priorities, the project will face significant challenges. This will lead to reduced funding, political opposition, and potentially, project cancellation.

*   Negative media coverage of project setbacks or controversies.
*   Public protests and demonstrations against the project.
*   Political opposition from influential figures or parties.
*   Shifting political priorities leading to funding cuts.
*   Lack of public understanding and appreciation of the project's benefits.

##### Early Warning Signs
- Public opinion polls show declining support for the project in key participating nations.
- Negative media coverage increases significantly.
- Political opposition to the project grows in influential circles.

##### Tripwires
- Public opinion polls show support for the project falling below 40% in two or more key participating nations.
- A major political party in a key participating nation publicly withdraws its support for the project.
- Government funding for the project is reduced by more than 15% in a key participating nation.

##### Response Playbook
- Contain: Immediately launch a proactive public relations campaign to address public concerns, highlight the project's benefits, and emphasize its importance for national interests.
- Assess: Conduct a thorough analysis of public sentiment and political dynamics to identify the root causes of the declining support.
- Respond: Revise the project plan to address public concerns, enhance transparency, and actively engage with stakeholders to rebuild trust and support. Lobby political leaders to maintain funding and support for the project.


**STOP RULE:** Public and political support collapses in two or more key participating nations, and no viable strategies can be identified to regain support within 180 days, jeopardizing the project's long-term viability.
