**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit set for PMO; requires strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun, project delays, and impact on overall project financial viability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO cannot handle the risk with existing resources or approved plans; requires strategic guidance and potential resource reallocation.
Negative Consequences: Project failure, significant delays, increased costs, and potential safety hazards.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: PMO cannot agree on a key operational decision; requires higher-level arbitration to avoid delays.
Negative Consequences: Project delays, increased costs, and potential legal challenges.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A major change to the project scope has strategic implications and requires approval from the highest governance body.
Negative Consequences: Project failure, budget overruns, schedule delays, and misalignment with strategic objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation to the Project Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, loss of international partnerships, and project cancellation.

**Technical Design Dispute within TAG**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC Review of TAG Recommendations and Final Decision
Rationale: Technical Advisory Group cannot reach consensus; requires strategic decision-making considering technical and project goals.
Negative Consequences: Suboptimal technical solutions, project delays, and increased technical risks.