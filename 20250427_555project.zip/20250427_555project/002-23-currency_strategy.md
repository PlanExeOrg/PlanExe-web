This plan involves money.

## Currencies

- **CNY:** Chinese central allocations will be a primary funding source.
- **RUB:** Roscosmos launch barter and Russian contributions to the project.
- **USD:** For international transactions, participant cost-shares, and mitigating currency risks.
- **KZT:** Potential expenses related to Baikonur Cosmodrome in Kazakhstan.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations and to facilitate international transactions. CNY and RUB will be used for local transactions within China and Russia, respectively. KZT may be used for local transactions in Kazakhstan.