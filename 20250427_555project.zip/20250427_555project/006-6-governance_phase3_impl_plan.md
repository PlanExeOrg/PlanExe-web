### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project start

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project start

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project start

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project start

### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project start

### 6. Circulate Draft PSC ToR for review by nominated members (Senior representatives from CNSA, Roscosmos, major participating nations, independent experts).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PSC ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by CNSA and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1

### 8. Circulate Draft TAG ToR for review by CNSA and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1

### 9. Circulate Draft ECC ToR for review by CNSA and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1

### 10. Circulate Draft SEG ToR for review by CNSA and Roscosmos.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1

### 11. Project Manager finalizes PSC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PSC ToR v1.0

**Dependencies:**

- Feedback Summary

### 12. Project Manager finalizes PMO ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 13. Project Manager finalizes TAG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 14. Project Manager finalizes ECC ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 15. Project Manager finalizes SEG ToR based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 16. CNSA and Roscosmos jointly appoint the Project Steering Committee (PSC) Chair.

**Responsible Body/Role:** CNSA and Roscosmos

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PSC ToR v1.0

### 17. CNSA and Roscosmos jointly appoint the Project Manager.

**Responsible Body/Role:** CNSA and Roscosmos

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 18. Project Steering Committee (PSC) Chair, in consultation with CNSA and Roscosmos, confirms the remaining PSC members.

**Responsible Body/Role:** Project Steering Committee (PSC) Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email
- Final PSC ToR v1.0

### 19. Project Manager, in consultation with CNSA and Roscosmos, appoints Deputy Project Managers, Project Control Officer, Risk Manager, Communications Manager, and Finance Officer to the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Appointment Confirmation Email
- Final PMO ToR v1.0

### 20. Project Steering Committee (PSC) Chair, in consultation with the Project Manager, appoints members to the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Steering Committee (PSC) Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Membership Confirmation List
- Final TAG ToR v1.0

### 21. Project Steering Committee (PSC) Chair, in consultation with the Project Manager, appoints members to the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Project Steering Committee (PSC) Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Membership Confirmation List
- Final ECC ToR v1.0

### 22. Project Manager, in consultation with the Communications Manager, appoints members to the Stakeholder Engagement Group (SEG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Membership Confirmation List
- Final SEG ToR v1.0

### 23. Hold initial Project Steering Committee (PSC) Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee (PSC) Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final PSC ToR v1.0

### 24. Hold initial Project Management Office (PMO) Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final PMO ToR v1.0

### 25. Hold initial Technical Advisory Group (TAG) Kick-off Meeting.

**Responsible Body/Role:** TAG Chair (elected during the meeting)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final TAG ToR v1.0

### 26. Hold initial Ethics & Compliance Committee (ECC) Kick-off Meeting.

**Responsible Body/Role:** ECC Chair (elected during the meeting)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final ECC ToR v1.0

### 27. Hold initial Stakeholder Engagement Group (SEG) Kick-off Meeting.

**Responsible Body/Role:** Communications Manager (PMO)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final SEG ToR v1.0