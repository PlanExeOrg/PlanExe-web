Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The changes are organizational, financial, and political, not physical. No physics-related claims are made.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (restructured CDC) + market (public health) + tech/process (outsourcing, new advisory panel) + policy (government mandate) without independent evidence at comparable scale. There is no precedent for halving a major agency in 6 months while replacing its scientific advisors with 'science skeptics'.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Director / Deliverable: Validation Report / Date: Within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear definition of 'science skeptics' and a business-level mechanism-of-action for how the advisory panel composition will improve customer value. The plan states, "The Advisory Panel Composition conflicts with Stakeholder Engagement Framework." No owner is assigned to define these.

**Mitigation**: Project Director: Produce a one-pager defining 'science skeptics' with a value hypothesis, success metrics, and decision hooks. Due: Within 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (legal challenges) is absent from the primary decisions, and the plan minimizes the risks associated with replacing the vaccine advisory panel. The plan lacks explicit analysis of cascades beyond the risk register.

**Mitigation**: Risk Management: Expand the risk register to include legal challenges and map potential cascades (e.g., legal challenges leading to project delays and financial penalties). Add controls and a dated review cadence. Due: Within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Federal employment laws, ethics regulations, public health statutes" but lacks a comprehensive matrix mapping required approvals, lead times, and dependencies. This omission creates a high risk of timeline overruns.

**Mitigation**: Legal Team: Create a permit/approval matrix detailing all required approvals, typical lead times, and dependencies. Include NO-GO thresholds for slip. Due: Within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan mentions "philanthropic organizations and private sector partnerships are viable for supplemental funding (up to 25% of shortfall)" but lacks specifics on funding sources, draw schedule, and covenants.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: Within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with vendor quotes and lacks scale-appropriate benchmarks. The plan does not provide evidence of cost per m²/ft² or contingency plans.

**Mitigation**: Owner: Financial Analyst; Benchmark ≥3 relevant comparables, obtain quotes, normalize per-area, and adjust budget or de-scope by 2025-10-01.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (budget cuts, leadership transition, advisory panel restructuring) as single numbers without providing a range or discussing alternative scenarios. The plan lacks sensitivity analysis.

**Mitigation**: Finance Team: Conduct a sensitivity analysis for the budget reduction projection, including best-case, worst-case, and base-case scenarios. Due: Within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan lacks technical specifications, interface definitions, test plans, and an integration map with owners/dates. "The plan lacks a detailed critical path analysis and resource allocation plan."

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: Within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a verifiable artifact for critical claims regarding licenses and approvals. The absence of a detailed legal review for the restructuring process creates a significant risk.

**Mitigation**: Legal Team: Conduct a comprehensive legal review to obtain necessary licenses and approvals, ensuring compliance with all regulations. Due: Within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the abstract deliverable is 'a new, more streamlined CDC.' The plan lacks specific, verifiable qualities for this deliverable. The plan does not define SMART acceptance criteria or KPIs for the restructured CDC.

**Mitigation**: Project Director: Define SMART criteria for the restructured CDC, including a KPI for operational efficiency (e.g., 25% reduction in response time to public health emergencies). Due: Within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the feature of replacing the vaccine advisory panel with 'science skeptics,' which does not support core goals of maintaining public trust and scientific integrity.

**Mitigation**: Project Director: Produce a one-page benefit case justifying the inclusion of 'science skeptics' in the advisory panel, complete with a KPI, owner, and estimated cost, or move the feature to the backlog. Due: Within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan names the 'Scientific Integrity Officer' as mission-critical, but the plan lacks evidence that this role can attract qualified candidates given the mandate to appoint 'science skeptics'.

**Mitigation**: HR Team: Conduct a talent market analysis for the Scientific Integrity Officer role, assessing the availability of qualified candidates willing to work under the government mandate. Due: Within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping required approvals, lead times, and dependencies. The plan mentions "Federal employment laws, ethics regulations, public health statutes" but does not map them to specific artifacts.

**Mitigation**: Legal Team: Create a regulatory matrix detailing all required approvals, lead times, responsible parties, and predecessors. Include NO-GO thresholds for adverse findings. Due: Within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "strategic plan, invest in training" to address long-term sustainability, but lacks specifics on funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms. The plan does not address technology obsolescence.

**Mitigation**: Project Director: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Due: Within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix mapping required approvals, lead times, and dependencies. The plan mentions "Federal employment laws, ethics regulations, public health statutes" but does not map them to specific artifacts.

**Mitigation**: Legal Team: Create a permit/approval matrix detailing all required approvals, typical lead times, and dependencies. Include NO-GO thresholds for slip. Due: Within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions diversifying the supply chain but lacks details on secondary suppliers, SLAs, or tested failover procedures. The plan does not describe how vendor risk will be managed.

**Mitigation**: Supply Chain Team: Secure SLAs with key vendors, identify a secondary supplier for critical inputs (e.g., vaccines), and test failover procedures by 2025-11-15.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by the 50% budget cut, while CDC leadership is incentivized by maintaining public health, creating a conflict over resource allocation. The plan lacks a shared objective.

**Mitigation**: Project Director: Define a shared, measurable objective (OKR) that aligns both Finance and CDC leadership on a common outcome, such as 'Improve public health outcomes with 50% less budget'. Due: Within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Director: Add a monthly review with KPI dashboard, a lightweight change board, and a defined re-plan/stop threshold. Due: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. FM3 (Credibility Collapse) depends on FM4 (Data Drought) and FM7 (Echo Chamber). A single dependency (A2: Qualified candidates) can trigger multi-domain failure across technical, financial, and reputational domains.

**Mitigation**: Project Director: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: Within 60 days.