
## Audit - Corruption Risks

- Bribery of government officials to expedite approvals or influence policy decisions related to budget cuts or advisory panel appointments.
- Conflicts of interest in the selection of outsourcing vendors, where decision-makers have personal relationships or financial ties to the chosen companies.
- Kickbacks from outsourcing vendors to CDC personnel in exchange for favorable contract terms or inflated invoices.
- Misuse of confidential information regarding budget allocations or program priorities for personal gain or to benefit favored contractors.
- Nepotism or favoritism in hiring new leadership or advisory panel members, potentially compromising scientific integrity and public trust.
- Trading favors with private sector partners, offering preferential treatment in research collaborations or data access in exchange for personal benefits.

## Audit - Misallocation Risks

- Misuse of funds allocated for retraining programs, diverting them to other areas or using them for personal gain.
- Double spending on outsourced services due to poor contract management or lack of oversight.
- Inefficient allocation of remaining budget, prioritizing politically favored programs over those with the greatest public health impact.
- Unauthorized use of CDC assets, such as vehicles or equipment, by new leadership or advisory panel members.
- Poor record-keeping of budget expenditures, making it difficult to track how funds are being used and identify potential discrepancies.
- Misreporting progress on budget cuts or leadership changes to meet the 6-month deadline, potentially masking underlying problems.

## Audit - Procedures

- Conduct periodic internal reviews of all outsourcing contracts to ensure compliance with procurement regulations and identify any potential conflicts of interest (quarterly, Internal Audit Department).
- Implement a robust expense reporting workflow with mandatory approvals and supporting documentation to prevent misuse of funds (ongoing, Finance Department).
- Perform regular compliance checks to ensure adherence to federal employment laws and ethics regulations during layoffs and leadership changes (monthly, Legal Department).
- Conduct a post-project external audit to assess the overall effectiveness of the restructuring and identify any areas for improvement (post-project, Independent Audit Firm).
- Establish a whistleblower mechanism with clear reporting channels and protection against retaliation to encourage employees to report suspected wrongdoing (ongoing, Human Resources and Legal Department).
- Review all financial transactions above a certain threshold ($10,000) for potential irregularities or red flags (monthly, Finance Department).

## Audit - Transparency Measures

- Publish a detailed budget dashboard showing planned vs. actual expenditures for each program area, updated monthly.
- Publish minutes of key meetings of the leadership council overseeing the restructuring, redacting confidential information as necessary (monthly).
- Establish a public website with FAQs and updates on the restructuring process, addressing common concerns and providing clear explanations of the changes (ongoing).
- Document and publish the selection criteria used for appointing new leadership and advisory panel members, ensuring transparency in the decision-making process (one-time publication).
- Make relevant policies and reports related to the restructuring publicly accessible, such as the budget reduction plan and the workforce transition plan (ongoing).
- Create a progress dashboard tracking key milestones, such as budget reduction targets, leadership appointments, and advisory panel composition, updated weekly.