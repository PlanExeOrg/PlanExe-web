This plan implies one or more physical locations.

## Requirements for physical locations

- Office space for new leadership
- Meeting facilities for advisory panel
- Facilities for workforce transition/retraining

## Location 1
USA

Atlanta, Georgia

1600 Clifton Road, Atlanta, GA 30333

**Rationale**: This is the current location of the CDC headquarters. While restructuring, maintaining a central location is crucial.

## Location 2
USA

Washington, D.C.

Various locations in Washington, D.C.

**Rationale**: Proximity to government and political decision-makers is important for the new leadership and advisory panel.

## Location 3
USA

Research Triangle Park, North Carolina

Various locations in Research Triangle Park, NC

**Rationale**: A hub for research and development, offering access to talent and resources for the CDC's scientific endeavors.

## Location 4
USA

Boston, Massachusetts

Various locations in Boston, MA

**Rationale**: Home to many leading universities and medical research institutions, providing access to expertise and potential partnerships.

## Location Summary
The CDC headquarters in Atlanta is the primary location. Washington D.C. is suggested for proximity to government. Research Triangle Park and Boston are suggested as hubs for research and development, offering access to talent and resources.