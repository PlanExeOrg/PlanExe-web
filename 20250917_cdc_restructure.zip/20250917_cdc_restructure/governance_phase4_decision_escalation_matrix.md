**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit of PMO's approval authority, requiring strategic oversight.
Negative Consequences: Potential budget overrun and misalignment with strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Strategic impact on project success and requires higher-level intervention.
Negative Consequences: Project failure, significant delays, or reputational damage.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Recommendation
Rationale: Inability to reach consensus within the PMO requires external arbitration.
Negative Consequences: Project delays and potential selection of a suboptimal vendor.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Needs independent review and assessment to ensure ethical conduct.
Negative Consequences: Legal penalty, reputational damage, and erosion of public trust.

**Technical Infeasibility of IT Systems Integration**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of Alternative Solutions
Rationale: Technical challenges impact project timeline and budget, requiring strategic realignment.
Negative Consequences: Project delays, increased costs, and compromised data security.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Significant changes to project scope require strategic alignment and approval.
Negative Consequences: Scope creep, budget overruns, and project delays.