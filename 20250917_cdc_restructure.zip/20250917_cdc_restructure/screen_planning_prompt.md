**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete, actionable project with a specific goal (restructuring the CDC), a timeline (6 months), and specific actions (budget cuts, layoffs, leadership overhaul). This provides enough detail to generate a multi-step plan, even if the project's goals are controversial.