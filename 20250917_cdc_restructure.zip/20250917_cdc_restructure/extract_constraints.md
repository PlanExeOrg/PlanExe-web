## Positive Constraints

- Cut CDC budget in half through reductions and layoffs
- Conduct a major leadership overhaul
- Fire the entire vaccine advisory panel
- Appoint science skeptics
- Timeline: 6 months
- Project start ASAP
