**Purpose:** business

**Purpose Detailed:** Societal/governmental initiative involving budget cuts, leadership changes, and advisory panel restructuring at the CDC.

**Topic:** Government-mandated CDC restructuring