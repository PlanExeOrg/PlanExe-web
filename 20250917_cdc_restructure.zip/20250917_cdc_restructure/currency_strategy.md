This plan involves money.

## Currencies

- **USD:** The primary currency for the United States, where the CDC is located and where most transactions will occur.

**Primary currency:** USD

**Currency strategy:** The project is based in the USA; therefore, USD will be used for all transactions. No additional international risk management is needed.