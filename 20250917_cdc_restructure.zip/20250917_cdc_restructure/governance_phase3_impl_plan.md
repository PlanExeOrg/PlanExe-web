### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Circulate Draft PSC ToR v0.1 for review by Senior Government Official, CDC Director (or designee), Representative from the Department of Health and Human Services, Independent Public Health Expert, and Independent Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PSC ToR v0.1 circulated for review

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Project Manager consolidates feedback and revises the PSC ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PSC ToR v0.2
- Feedback Summary

**Dependencies:**

- PSC ToR v0.1 circulated for review
- Feedback received from nominated members

### 4. Senior Government Official formally approves the PSC ToR.

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0

**Dependencies:**

- PSC ToR v0.2

### 5. Senior Government Official formally appoints the Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Senior Government Official

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- PSC Chair Appointed

**Dependencies:**

- Approved PSC ToR v1.0

### 6. Project Manager coordinates with the Senior Government Official (Chair) to confirm the remaining PSC membership: CDC Director (or designee), Representative from the Department of Health and Human Services, Independent Public Health Expert, and Independent Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confirmed PSC Membership List

**Dependencies:**

- PSC Chair Appointed

### 7. Project Manager formally notifies all confirmed PSC members of their appointment and distributes the approved ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Notification Emails
- PSC ToR Distributed

**Dependencies:**

- Confirmed PSC Membership List
- Approved PSC ToR v1.0

### 8. Project Manager schedules the initial Project Steering Committee (PSC) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PSC Kick-off Meeting Scheduled

**Dependencies:**

- Appointment Notification Emails
- PSC ToR Distributed

### 9. Hold the initial Project Steering Committee (PSC) kick-off meeting to review project objectives, governance structure, and initial priorities.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Project Priorities Confirmed

**Dependencies:**

- PSC Kick-off Meeting Scheduled

### 10. Project Manager establishes the Project Management Office (PMO) by defining the project management methodology.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Management Methodology Document

**Dependencies:**

- Project Start

### 11. Project Manager develops a project plan template for use by the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Plan Template

**Dependencies:**

- Project Management Methodology Document

### 12. Project Manager sets up a project tracking system for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Project Tracking System Established

**Dependencies:**

- Project Management Methodology Document

### 13. Project Manager recruits project team members for the PMO, including Workstream Leads (e.g., Budget Reduction, Leadership Transition, Advisory Panel), Risk Manager, Communications Manager, and Compliance Officer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Team Members Recruited

**Dependencies:**

- Project Tracking System Established

### 14. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Scheduled

**Dependencies:**

- PMO Team Members Recruited

### 15. Hold the initial Project Management Office (PMO) kick-off meeting to assign initial tasks and responsibilities.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Tasks Assigned

**Dependencies:**

- PMO Kick-off Meeting Scheduled

### 16. Chief Compliance Officer drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Start

### 17. Circulate Draft ECC ToR v0.1 for review by Legal Counsel, Human Resources Representative, Independent Ethics Expert, and Data Protection Officer.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- ECC ToR v0.1 circulated for review

**Dependencies:**

- Draft ECC ToR v0.1

### 18. Chief Compliance Officer consolidates feedback and revises the ECC ToR.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- ECC ToR v0.2
- Feedback Summary

**Dependencies:**

- ECC ToR v0.1 circulated for review
- Feedback received from nominated members

### 19. Project Steering Committee (PSC) formally approves the ECC ToR.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved ECC ToR v1.0

**Dependencies:**

- ECC ToR v0.2
- PSC Established

### 20. Project Steering Committee (PSC) formally appoints the Chair of the Ethics & Compliance Committee (ECC) - Chief Compliance Officer.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- ECC Chair Appointed

**Dependencies:**

- Approved ECC ToR v1.0
- PSC Established

### 21. Chief Compliance Officer coordinates with the Project Steering Committee (PSC) to confirm the remaining ECC membership: Legal Counsel, Human Resources Representative, Independent Ethics Expert, and Data Protection Officer.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed ECC Membership List

**Dependencies:**

- ECC Chair Appointed
- PSC Established

### 22. Chief Compliance Officer formally notifies all confirmed ECC members of their appointment and distributes the approved ToR.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Notification Emails
- ECC ToR Distributed

**Dependencies:**

- Confirmed ECC Membership List
- Approved ECC ToR v1.0

### 23. Chief Compliance Officer schedules the initial Ethics & Compliance Committee (ECC) kick-off meeting.

**Responsible Body/Role:** Chief Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Scheduled

**Dependencies:**

- Appointment Notification Emails
- ECC ToR Distributed

### 24. Hold the initial Ethics & Compliance Committee (ECC) kick-off meeting to review committee responsibilities and initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee (ECC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Priorities Confirmed

**Dependencies:**

- ECC Kick-off Meeting Scheduled

### 25. Chief Information Officer (CIO) drafts initial Terms of Reference (ToR) for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start

### 26. Circulate Draft TAG ToR v0.1 for review by Chief Data Officer (CDO), Independent IT Security Expert, Independent Data Scientist, and Independent Public Health Scientist.

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- TAG ToR v0.1 circulated for review

**Dependencies:**

- Draft TAG ToR v0.1

### 27. Chief Information Officer (CIO) consolidates feedback and revises the TAG ToR.

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- TAG ToR v0.2
- Feedback Summary

**Dependencies:**

- TAG ToR v0.1 circulated for review
- Feedback received from nominated members

### 28. Project Steering Committee (PSC) formally approves the TAG ToR.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0

**Dependencies:**

- TAG ToR v0.2
- PSC Established

### 29. Project Steering Committee (PSC) formally appoints the Chair of the Technical Advisory Group (TAG) - Chief Information Officer (CIO).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- TAG Chair Appointed

**Dependencies:**

- Approved TAG ToR v1.0
- PSC Established

### 30. Chief Information Officer (CIO) coordinates with the Project Steering Committee (PSC) to confirm the remaining TAG membership: Chief Data Officer (CDO), Independent IT Security Expert, Independent Data Scientist, and Independent Public Health Scientist.

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confirmed TAG Membership List

**Dependencies:**

- TAG Chair Appointed
- PSC Established

### 31. Chief Information Officer (CIO) formally notifies all confirmed TAG members of their appointment and distributes the approved ToR.

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Notification Emails
- TAG ToR Distributed

**Dependencies:**

- Confirmed TAG Membership List
- Approved TAG ToR v1.0

### 32. Chief Information Officer (CIO) schedules the initial Technical Advisory Group (TAG) kick-off meeting.

**Responsible Body/Role:** Chief Information Officer (CIO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Scheduled

**Dependencies:**

- Appointment Notification Emails
- TAG ToR Distributed

### 33. Hold the initial Technical Advisory Group (TAG) kick-off meeting to review committee responsibilities and initial priorities.

**Responsible Body/Role:** Technical Advisory Group (TAG)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Priorities Confirmed

**Dependencies:**

- TAG Kick-off Meeting Scheduled