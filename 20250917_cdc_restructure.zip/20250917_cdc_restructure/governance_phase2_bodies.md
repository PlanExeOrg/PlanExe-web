### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides strategic oversight and direction for the high-stakes, politically sensitive CDC restructuring project. Ensures alignment with government mandates and manages strategic risks.

**Responsibilities:**

- Approve the overall project plan and any significant deviations.
- Monitor project progress against key milestones and budget.
- Approve major budget reallocations above $5 million.
- Oversee strategic risk management and mitigation.
- Resolve high-level conflicts and escalate issues as needed.
- Approve key strategic decisions related to budget cuts, leadership changes, and advisory panel composition.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review project plan and risk register.

**Membership:**

- Senior Government Official (Chair)
- CDC Director (or designee)
- Representative from the Department of Health and Human Services
- Independent Public Health Expert
- Independent Legal Counsel

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key deliverables. Approval of budget reallocations exceeding $5 million. Approval of changes to the project's strategic direction.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Senior Government Official (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly, with ad hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of budget reallocations.
- Review of stakeholder engagement activities.
- Updates on legal and regulatory compliance.

**Escalation Path:** Secretary of Health and Human Services.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the CDC restructuring project, ensuring efficient resource allocation, risk management, and adherence to the project plan.

**Responsibilities:**

- Develop and maintain the project plan, including timelines, budgets, and resource allocation.
- Track project progress and report on key performance indicators (KPIs).
- Manage project risks and issues, escalating to the Project Steering Committee as needed.
- Coordinate project activities across different workstreams.
- Ensure adherence to project management standards and best practices.
- Manage the project budget and track expenditures.
- Facilitate communication and collaboration among project team members.

**Initial Setup Actions:**

- Establish project management methodology.
- Develop project plan template.
- Set up project tracking system.
- Recruit project team members.

**Membership:**

- Project Manager (PMO Lead)
- Workstream Leads (e.g., Budget Reduction, Leadership Transition, Advisory Panel)
- Risk Manager
- Communications Manager
- Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation within approved budgets, and risk management below strategic thresholds. Approval of budget expenditures up to $5 million.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with Workstream Leads. Escalation to the Project Steering Committee for unresolved issues or decisions exceeding the PMO's authority.

**Meeting Cadence:** Weekly, with daily stand-up meetings for workstream teams.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and issues.
- Approval of budget expenditures.
- Coordination of project activities.
- Updates on stakeholder engagement activities.

**Escalation Path:** Project Steering Committee.
### 3. Ethics & Compliance Committee (ECC)

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all applicable laws, regulations, and ethical standards throughout the CDC restructuring process, particularly regarding employment law, data privacy (GDPR), and conflicts of interest.

**Responsibilities:**

- Develop and implement a comprehensive compliance program.
- Monitor adherence to federal employment laws, ethics regulations, and public health statutes.
- Investigate potential violations of laws, regulations, or ethical standards.
- Provide guidance and training to project team members on ethical and compliance issues.
- Ensure compliance with data privacy regulations (e.g., GDPR).
- Review and approve all outsourcing contracts to identify and mitigate potential conflicts of interest.
- Oversee the whistleblower mechanism and ensure protection against retaliation.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop compliance program.
- Establish reporting channels for ethical concerns.

**Membership:**

- Chief Compliance Officer (Chair)
- Legal Counsel
- Human Resources Representative
- Independent Ethics Expert
- Data Protection Officer

**Decision Rights:** Decisions related to ethical conduct, compliance with laws and regulations, and data privacy. Authority to halt project activities that violate ethical standards or legal requirements.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chief Compliance Officer (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Bi-weekly, with ad hoc meetings as needed for urgent compliance issues.

**Typical Agenda Items:**

- Review of compliance program effectiveness.
- Discussion of potential ethical and compliance risks.
- Investigation of reported violations.
- Updates on legal and regulatory changes.
- Review of outsourcing contracts.
- Review of data privacy practices.

**Escalation Path:** Project Steering Committee, with direct reporting line to the Secretary of Health and Human Services for critical compliance breaches.
### 4. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Provides expert technical advice and assurance on key aspects of the CDC restructuring, particularly regarding IT systems integration, data security, and scientific integrity of the advisory panel.

**Responsibilities:**

- Review and assess the technical feasibility of proposed changes to IT systems and infrastructure.
- Provide guidance on data security and privacy best practices.
- Evaluate the scientific rigor and validity of the new advisory panel's recommendations.
- Identify and mitigate potential technical risks.
- Advise on the selection of outsourcing vendors for IT services.
- Ensure the integrity and reliability of data used for decision-making.
- Provide independent review of the scientific qualifications of potential advisory panel members.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define scope of technical review.
- Identify key technical risks.

**Membership:**

- Chief Information Officer (CIO) (Chair)
- Chief Data Officer (CDO)
- Independent IT Security Expert
- Independent Data Scientist
- Independent Public Health Scientist

**Decision Rights:** Provides recommendations and assessments on technical aspects of the project. Authority to raise concerns about technical risks and potential impacts on data security and scientific integrity.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the CIO (Chair) makes the final decision, documenting dissenting opinions.

**Meeting Cadence:** Bi-weekly, with ad hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of IT systems integration plans.
- Discussion of data security and privacy risks.
- Evaluation of the scientific rigor of advisory panel recommendations.
- Updates on technical progress and challenges.
- Review of outsourcing vendor proposals.

**Escalation Path:** Project Steering Committee.