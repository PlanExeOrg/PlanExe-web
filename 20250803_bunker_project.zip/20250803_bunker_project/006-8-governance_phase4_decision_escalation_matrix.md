**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential budget overruns, project delays, and misalignment with strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Materialization of a critical risk necessitates a re-evaluation of the project's risk profile and mitigation strategies, requiring strategic guidance.
Negative Consequences: Project failure, significant cost overruns, and inability to meet project objectives.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Lack of consensus within the PMO on a key vendor selection requires a higher-level decision to ensure project progress.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval (or Rejection) of Scope Change Request
Rationale: Significant changes to the project scope impact the budget, timeline, and strategic objectives, requiring Steering Committee approval.
Negative Consequences: Scope creep, budget overruns, project delays, and misalignment with strategic objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Management
Rationale: Ethical violations require independent review and investigation to ensure compliance with ethical standards and legal regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Design Approval Dispute**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Final Decision based on TAG recommendations and project constraints.
Rationale: Disagreement within the Technical Advisory Group on a critical design element requires resolution at a higher level to maintain project momentum and technical integrity.
Negative Consequences: Compromised structural integrity, EMP protection failure, or life support system deficiencies.