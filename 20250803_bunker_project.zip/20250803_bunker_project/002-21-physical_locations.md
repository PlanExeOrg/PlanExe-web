This plan implies one or more physical locations.

## Requirements for physical locations

- Near Hedehusene, Denmark
- 50 m × 50 m × 20 m excavation area
- Suitable for a 4-level bunker
- Capable of housing 1000 people for 3 months
- Adequate space for EMP cage and 1.5 meter UHPC walls

## Location 1
Denmark

Near Hedehusene

Suitable plot of land near Hedehusene, Denmark

**Rationale**: The project specifies a location near Hedehusene, Denmark, making this area the primary focus for site selection.

## Location 2
Denmark

Rural area in Zealand

Plot of land in a rural area of Zealand, Denmark

**Rationale**: Rural areas in Zealand offer more space and potentially fewer zoning restrictions for a large-scale construction project like a bunker.

## Location 3
Denmark

Underground location near Copenhagen

Existing underground facility or mine near Copenhagen, Denmark

**Rationale**: Utilizing an existing underground facility could reduce excavation costs and construction time, while still being relatively close to Copenhagen.

## Location 4
Sweden

Southern Sweden

Plot of land in Southern Sweden, near the coast

**Rationale**: Southern Sweden offers similar geological conditions to Denmark and is relatively close, providing an alternative location with potentially different regulations or land costs.

## Location Summary
The primary location is near Hedehusene, Denmark, as specified in the project plan. Additional suggestions include rural areas in Zealand, underground locations near Copenhagen, and Southern Sweden, offering alternatives based on space, existing infrastructure, and regulatory considerations.