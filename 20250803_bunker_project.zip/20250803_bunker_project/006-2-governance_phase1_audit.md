
## Audit - Corruption Risks

- Bribery of local officials to expedite permits or overlook regulatory violations related to environmental impact or building codes.
- Kickbacks from suppliers of UHPC or EMP cage materials in exchange for awarding them contracts, potentially compromising material quality.
- Conflicts of interest involving project managers or engineers who have undisclosed financial ties to subcontractors or suppliers.
- Misuse of confidential project information (e.g., security protocols, VIP occupant details) for personal gain or to benefit unauthorized parties.
- Nepotism in hiring subcontractors or consultants, leading to unqualified personnel being involved in critical aspects of the project.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, resulting in overpayment for goods or services.
- Diversion of funds allocated for specific project components (e.g., EMP cage) to other areas, potentially compromising the bunker's protective capabilities.
- Use of substandard materials or construction techniques to cut costs, jeopardizing the structural integrity of the UHPC walls or EMP cage.
- Inadequate record-keeping of project expenses, making it difficult to track spending and identify potential discrepancies.
- Misreporting of project progress or milestones to mask delays or cost overruns, leading to inaccurate decision-making.

## Audit - Procedures

- Conduct quarterly internal audits of project finances, focusing on procurement processes, invoice verification, and expense approvals.
- Engage an external auditor to perform a comprehensive review of project activities and compliance with regulations after the excavation phase and again upon project completion.
- Implement a contract review process with pre-defined thresholds (e.g., any contract exceeding €500,000) requiring independent legal and technical review.
- Establish a detailed expense workflow with multiple levels of approval for all project-related expenditures, including travel, materials, and consultant fees.
- Perform regular compliance checks to ensure adherence to Danish building codes, environmental regulations, and safety standards, with documented findings and corrective actions.

## Audit - Transparency Measures

- Establish a public-facing project dashboard displaying key progress indicators (e.g., excavation progress, UHPC wall construction milestones, EMP cage installation status) and budget expenditures.
- Publish minutes of key project governance meetings (e.g., steering committee meetings, risk management reviews) on a secure website accessible to relevant stakeholders.
- Implement a confidential whistleblower mechanism allowing employees and subcontractors to report suspected fraud, corruption, or ethical violations without fear of reprisal.
- Make relevant project policies and reports (e.g., environmental impact assessment, safety management plan) publicly available on a project website or through a designated information center.
- Document and publish the selection criteria and justification for major decisions, such as the choice of wall construction methodology, EMP protection strategy, and key vendors.