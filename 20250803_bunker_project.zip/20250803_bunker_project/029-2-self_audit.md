Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any laws of physics. The project focuses on engineering and construction, not on speculative physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (VIP bunker) + market (AI threat) + tech/process (UHPC, EMP) + policy (social governance) without independent evidence at comparable scale. There is no credible precedent for this specific system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates. Owner: Project Director / Deliverable: Validation Report / Date: 2027-01-01


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions strategic concepts like 'resilience vs. cost' and 'self-sufficiency vs. external dependence' without defining them or their business-level mechanism-of-action. There are no one-pagers defining these strategic concepts.

**Mitigation**: Strategy Team: Create one-pagers for 'resilience vs. cost' and 'self-sufficiency vs. external dependence' with value hypotheses, success metrics, and decision hooks by 2027-01-15.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because while the plan identifies risks, it minimizes major hazard classes. The plan lacks a comprehensive register covering all potential legal, safety, financial, and reputational risks. There is no explicit analysis of risk cascades.

**Mitigation**: Risk Management: Expand the risk register to include all hazard classes, map risk cascades, add controls, and establish a dated review cadence by 2027-02-01.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions regulatory and permitting delays as a key risk, but lacks a detailed matrix identifying required permits, lead times, and dependencies.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with lead times and dependencies, then rebuild the critical path with a NO-GO threshold on slip by 2027-01-15.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not specify committed funding sources, draw schedules, or covenants. The plan mentions a budget of €200 million, but lacks details on funding sources and their status.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, and covenants, with a NO-GO on missed financing gates by 2027-01-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €200 million conflicts with the scale of the project (housing 1000 VIPs for 3 months with 1.5-meter UHPC walls and an EMP cage). There are no benchmarks or per-area cost normalizations.

**Mitigation**: Owner: Cost Estimator. Deliverable: Obtain ≥3 relevant cost benchmarks, normalize per area (m²), and adjust budget or de-scope by 2027-01-15.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., completion within 18 months) as single numbers without providing a range or discussing alternative scenarios. There is no sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project's completion date within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions UHPC walls and EMP cage but lacks specs, interface contracts, acceptance tests, integration plan, and non-functional requirements.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for UHPC and EMP cage within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks verifiable evidence for critical claims. For example, the plan states the bunker will have "1.5-meter UHPC walls and an EMP cage" but lacks any artifact showing the design or performance of either.

**Mitigation**: Engineering Team: Provide verifiable documentation (specs, test results, certifications) for the UHPC walls and EMP cage designs by 2027-01-30.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions abstract deliverables like the 'Psychological Well-being Program' without specific, verifiable qualities. There are no SMART criteria for the program's success.

**Mitigation**: Mental Health Lead: Define SMART criteria for the Psychological Well-being Program, including a KPI for stress reduction (e.g., 20% reduction in self-reported stress) by 2027-01-30.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Psychological Well-being Program includes recreational spaces, but lacks specifics on activities. This does not directly support the core goals of protection or self-sufficiency.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of recreational spaces, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2027-01-30.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Security Systems Architect' role is both essential and likely difficult to fill. The role requires specialized knowledge of EMP shielding, physical security, and cybersecurity, making qualified candidates rare.

**Mitigation**: HR: Validate the talent market for Security Systems Architects with EMP expertise by contacting ≥5 headhunters and assessing candidate availability within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies regulatory and permitting delays as a key risk, but lacks a detailed matrix identifying required permits, lead times, and dependencies.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with lead times and dependencies, then rebuild the critical path with a NO-GO threshold on slip by 2027-01-15.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive operational sustainability plan. There is no discussion of long-term funding, maintenance schedules, succession planning, technology roadmaps, or adaptation mechanisms. The plan focuses on the initial 3-month period.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies regulatory and permitting delays as a key risk, but lacks a detailed matrix identifying required permits, lead times, and dependencies.

**Mitigation**: Permitting Lead: Create a permit/approval matrix with lead times and dependencies, then rebuild the critical path with a NO-GO threshold on slip by 2027-01-15.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address redundancy and resilience of external dependencies. There is no mention of SLAs with vendors, secondary suppliers, or tested failover procedures.

**Mitigation**: Procurement Team: Secure SLAs with key vendors, identify secondary suppliers for critical resources, and schedule failover tests within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by budget adherence, while the Project Team is incentivized by project completion, creating a conflict over scope changes. The plan does not address this conflict.

**Mitigation**: Project Team: Define a shared, measurable objective (OKR) that aligns both Finance and the Project Team on a common outcome (e.g., 'Complete project within budget and timeline') by 2027-01-30.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board, including thresholds for re-planning or stopping, by 2027-01-30.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies regulatory hurdles, technical challenges, and psychological well-being as critical risks, but lacks a cross-impact analysis. Failure to obtain permits could halt the project, which would then negate all other efforts.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2027-02-15.