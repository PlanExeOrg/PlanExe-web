A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | UHPC supply chains are stable and can deliver materials on the project's aggressive timeline. | Contact multiple UHPC suppliers and request detailed delivery schedules and pricing quotes. | Inability to secure guaranteed delivery dates within the project timeline or significant price increases (>=20%) compared to initial estimates. |
| A2 | The chosen site near Hedehusene has minimal subsurface obstructions and consistent soil conditions. | Conduct a comprehensive subsurface survey using ground-penetrating radar and borehole drilling. | Discovery of significant subsurface obstructions (e.g., large boulders, underground utilities, contaminated soil) or highly variable soil conditions that would significantly increase excavation costs or require extensive remediation. |
| A3 | The local community will passively accept the construction of a large, secure bunker. | Conduct a public opinion survey in Hedehusene to gauge community sentiment towards the project. | Survey results indicate significant (>=40%) negative sentiment towards the project, with concerns about environmental impact, security, or property values. |
| A4 | The selected VIP occupants will be able to coexist peacefully and productively in a confined environment for three months. | Conduct personality assessments and team-building exercises with a representative sample of potential VIP occupants. | Assessments reveal significant personality conflicts or an inability to function effectively as a team in a simulated confined environment. |
| A5 | The bunker's internal systems (power, water, air) can be effectively maintained and repaired using readily available skills and resources. | Conduct a skills gap analysis of the maintenance team and assess the availability of spare parts and specialized tools. | Significant skills gaps are identified within the maintenance team, or critical spare parts and specialized tools are unavailable within a reasonable timeframe and budget. |
| A6 | The AI threat will remain consistent and predictable over the bunker's operational lifespan. | Consult with AI security experts to assess the potential evolution of AI threats and the bunker's ability to adapt. | Experts predict significant and unpredictable evolution of AI threats that would render the bunker's current defenses inadequate within a short timeframe (e.g., <5 years). |
| A7 | The Danish government will remain politically stable and supportive of the project throughout its construction and operational phases. | Monitor Danish political polls and conduct discreet inquiries with government officials regarding their long-term commitment to the project. | A significant shift in political power occurs, with a new government expressing skepticism or outright opposition to the project. |
| A8 | The selected site will not experience unforeseen environmental disasters (e.g., major flooding, landslides) that could compromise the bunker's structural integrity or accessibility. | Consult with climatologists and environmental scientists to assess the long-term risk of environmental disasters at the site. | Experts predict a significant increase in the risk of major flooding or landslides at the site within the bunker's operational lifespan. |
| A9 | The concept of a VIP bunker will maintain its appeal and perceived value to potential occupants over the long term. | Conduct market research with the target demographic to gauge their continued interest in and willingness to pay for VIP bunker services. | Market research indicates a declining interest in VIP bunkers, with potential occupants expressing concerns about cost, confinement, or the perceived effectiveness of such measures. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The UHPC Supply Chain Meltdown | Process/Financial | A1 | Procurement Lead | CRITICAL (20/25) |
| FM2 | The Subsurface Surprise | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The NIMBY Nightmare | Market/Human | A3 | Permitting Lead | CRITICAL (15/25) |
| FM4 | The VIP Civil War | Process/Financial | A4 | Social Governance Lead | CRITICAL (15/25) |
| FM5 | The Systemic Shutdown | Technical/Logistical | A5 | Head of Engineering | CRITICAL (20/25) |
| FM6 | The Obsolete Fortress | Market/Human | A6 | Security Systems Architect | HIGH (12/25) |
| FM7 | The Political Pullout | Process/Financial | A7 | Government Relations Lead | HIGH (10/25) |
| FM8 | The Deluge Disaster | Technical/Logistical | A8 | Head of Engineering | CRITICAL (15/25) |
| FM9 | The Bunker Bust | Market/Human | A9 | Marketing Lead | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The UHPC Supply Chain Meltdown

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Procurement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's aggressive timeline hinges on a steady supply of UHPC. However, global supply chain disruptions, increased demand for UHPC in other construction projects, or unforeseen production issues at the supplier's facilities could lead to significant delays and cost overruns. This would trigger penalties in construction contracts, increase labor costs due to idle workers, and potentially force the project to seek alternative, less suitable materials at a premium price. The financial strain could ultimately bankrupt the project, leaving an unfinished bunker.

##### Early Warning Signs
- UHPC supplier reports production delays exceeding 14 days.
- Price of UHPC increases by >=10% within a 30-day period.
- Other construction projects in the region report UHPC shortages.

##### Tripwires
- UHPC delivery delayed by >=30 days.
- UHPC cost exceeds budgeted amount by >=15%.
- UHPC supplier declares bankruptcy or force majeure.

##### Response Playbook
- Contain: Immediately activate backup UHPC suppliers and negotiate expedited delivery schedules.
- Assess: Conduct a thorough financial analysis to determine the impact of the UHPC supply chain disruption on the project budget and timeline.
- Respond: Renegotiate construction contracts to mitigate penalties, explore alternative wall construction methods, or seek additional funding from investors.


**STOP RULE:** Alternative wall construction methods are deemed structurally inadequate or the project runs out of contingency funds to cover UHPC cost overruns and delays.

---

#### FM2 - The Subsurface Surprise

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite initial site assessments, excavation uncovers a network of undocumented underground utilities, a large, unstable rock formation, and pockets of contaminated soil. This necessitates a complete redesign of the bunker's foundation, extensive and costly remediation efforts, and significant delays to the excavation schedule. The specialized equipment required for the remediation is not readily available, further compounding the logistical challenges. The structural integrity of the bunker is compromised, and the project falls hopelessly behind schedule.

##### Early Warning Signs
- Excavation progress falls >=20% behind schedule.
- Unforeseen geological formations are encountered during excavation.
- Remediation costs exceed initial estimates by >=50%.

##### Tripwires
- Excavation halted for >=14 days due to unforeseen subsurface conditions.
- Remediation costs exceed €10 million.
- Structural engineers deem the site unsuitable for the original bunker design.

##### Response Playbook
- Contain: Immediately halt excavation and secure the site to prevent further damage or environmental contamination.
- Assess: Conduct a thorough geotechnical investigation to assess the extent of the subsurface issues and develop remediation options.
- Respond: Revise the bunker design to accommodate the subsurface conditions, secure specialized equipment for remediation, and renegotiate construction contracts to account for the delays and increased costs.


**STOP RULE:** The site is deemed geologically unsuitable for any viable bunker design, or remediation costs exceed the project's contingency budget by 50%.

---

#### FM3 - The NIMBY Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The local community, initially apathetic, becomes increasingly hostile to the project due to concerns about environmental impact, increased traffic, and perceived security risks. A vocal opposition group organizes protests, files legal challenges, and lobbies local authorities to revoke permits. The negative publicity damages the project's reputation, scares away investors, and leads to significant construction delays. The project becomes a political liability, and the government withdraws its support, effectively killing the project.

##### Early Warning Signs
- Local news outlets publish negative articles about the project.
- Attendance at community outreach meetings declines significantly.
- Online petitions opposing the project gain >=500 signatures within a week.

##### Tripwires
- Permits are revoked or suspended due to community opposition.
- Legal challenges filed by community groups delay construction by >=90 days.
- Major investors withdraw funding due to negative publicity.

##### Response Playbook
- Contain: Immediately engage with community leaders to address their concerns and negotiate compromises.
- Assess: Conduct a public relations audit to assess the damage to the project's reputation and develop a communication strategy to counter negative publicity.
- Respond: Offer community benefits (e.g., local job creation, environmental improvements), revise the project design to address environmental concerns, and lobby local authorities to maintain their support.


**STOP RULE:** All necessary permits are permanently revoked due to community opposition, or major investors withdraw funding and cannot be replaced.

---

#### FM4 - The VIP Civil War

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Social Governance Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite careful selection, simmering tensions among the 1000 VIP occupants erupt into open conflict. Cliques form, resources are hoarded, and the established social order collapses. The mental health support team is overwhelmed, and the carefully planned routines are abandoned. The resulting chaos disrupts essential operations, damages equipment, and consumes valuable resources. Security personnel are forced to intervene, further escalating the situation. The bunker becomes a prison rather than a sanctuary, and the project's reputation is irreparably damaged.

##### Early Warning Signs
- Increased reports of interpersonal conflicts among VIP occupants during pre-bunker exercises.
- Significant hoarding of resources is detected during inventory checks.
- The mental health support team reports a surge in stress-related complaints.

##### Tripwires
- Physical altercations among VIP occupants occur >=3 times per week.
- Resource consumption exceeds planned levels by >=20% due to hoarding.
- The mental health support team is unable to effectively manage the level of conflict and distress.

##### Response Playbook
- Contain: Immediately implement stricter social governance protocols, including curfews, resource rationing, and conflict resolution sessions.
- Assess: Conduct a thorough investigation to identify the root causes of the conflict and the key instigators.
- Respond: Isolate or remove disruptive individuals, implement a revised social governance structure, and provide additional mental health support.


**STOP RULE:** The social order within the bunker completely collapses, rendering it uninhabitable, or the cost of maintaining order exceeds the project's contingency budget.

---

#### FM5 - The Systemic Shutdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
A series of cascading failures cripples the bunker's essential systems. The primary power generator malfunctions, and the backup system fails to activate due to a lack of trained personnel and readily available spare parts. The water purification system breaks down, contaminating the water supply. The air filtration system becomes clogged, leading to a buildup of harmful gases. The maintenance team, lacking the necessary skills and resources, is unable to effectively diagnose and repair the problems. The bunker becomes uninhabitable, forcing an emergency evacuation and exposing the VIP occupants to the very threats they sought to avoid.

##### Early Warning Signs
- The maintenance team reports difficulty in sourcing spare parts for critical systems.
- Routine maintenance tasks are consistently delayed due to a lack of trained personnel.
- System performance degrades significantly, requiring frequent repairs.

##### Tripwires
- The primary power generator fails, and the backup system is inoperable for >=24 hours.
- The water purification system fails, and the water supply is deemed unsafe for consumption.
- The air filtration system fails, and air quality levels exceed acceptable limits.

##### Response Playbook
- Contain: Immediately activate emergency protocols to ration resources and provide temporary life support.
- Assess: Conduct a thorough assessment of the system failures and identify the root causes.
- Respond: Secure external assistance from specialized technicians, implement temporary repairs, and develop a plan for long-term system restoration.


**STOP RULE:** Multiple critical systems fail simultaneously, rendering the bunker uninhabitable, or the cost of restoring the systems exceeds the project's contingency budget.

---

#### FM6 - The Obsolete Fortress

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Security Systems Architect
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The AI threat landscape evolves rapidly, rendering the bunker's defenses obsolete. New forms of EMP attacks emerge, bypassing the existing shielding. AI-powered surveillance systems penetrate the bunker's security protocols. The VIP occupants, lulled into a false sense of security, become complacent and fail to adapt to the changing threat environment. The bunker, once a state-of-the-art sanctuary, becomes a vulnerable target, easily exploited by increasingly sophisticated AI adversaries. The project's long-term value is diminished, and investors lose confidence.

##### Early Warning Signs
- AI security experts report the emergence of new EMP attack methods that bypass the bunker's shielding.
- Cybersecurity audits reveal vulnerabilities in the bunker's security systems.
- VIP occupants demonstrate a lack of awareness of evolving AI threats and security protocols.

##### Tripwires
- New EMP attack methods are proven to penetrate the bunker's shielding during simulated tests.
- Cybersecurity breaches occur, compromising sensitive data within the bunker.
- VIP occupants fail to comply with updated security protocols during drills.

##### Response Playbook
- Contain: Immediately implement enhanced security protocols, including stricter access controls and increased surveillance.
- Assess: Conduct a thorough threat assessment to identify new vulnerabilities and develop countermeasures.
- Respond: Upgrade the bunker's defenses to address the evolving AI threat landscape, implement ongoing security training for VIP occupants, and establish partnerships with AI security experts.


**STOP RULE:** The bunker's defenses are deemed inadequate to protect against evolving AI threats, and the cost of upgrading the systems exceeds the project's long-term maintenance budget.

---

#### FM7 - The Political Pullout

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Government Relations Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
A new government comes into power in Denmark with a drastically different political agenda. They view the VIP bunker project as a symbol of elitism and a waste of public resources. They halt all funding, revoke permits, and actively discourage private investment. The project is left in a state of limbo, with construction stalled and investors fleeing. The partially completed bunker becomes a white elephant, a monument to failed political foresight. The project's financial backers suffer significant losses, and the concept of government-backed VIP shelters is discredited.

##### Early Warning Signs
- Public opinion polls show a sharp decline in support for the ruling party.
- Key government officials express reservations about the project's cost and benefits.
- New legislation is introduced that could negatively impact the project's funding or permitting.

##### Tripwires
- Government funding is suspended or revoked.
- Critical permits are denied or delayed indefinitely.
- A major political party publicly opposes the project.

##### Response Playbook
- Contain: Immediately engage with the new government to address their concerns and negotiate a compromise.
- Assess: Conduct a thorough legal and financial analysis to determine the project's vulnerability to political changes.
- Respond: Seek alternative funding sources, revise the project design to align with the new government's priorities, or relocate the project to a more politically stable location.


**STOP RULE:** All government support is permanently withdrawn, and no viable alternative funding sources can be secured.

---

#### FM8 - The Deluge Disaster

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Unprecedented rainfall and rising groundwater levels overwhelm the bunker's drainage systems. The site experiences a catastrophic flood, compromising the structural integrity of the UHPC walls and flooding the lower levels. Essential equipment is damaged beyond repair, and the bunker becomes inaccessible. The VIP occupants are forced to evacuate, and the project is deemed a failure due to unforeseen environmental risks. The long-term viability of underground infrastructure in the region is questioned.

##### Early Warning Signs
- Climatologists issue warnings about increased rainfall and rising sea levels in the region.
- Groundwater levels at the site rise significantly above historical averages.
- The bunker's drainage systems are unable to cope with heavy rainfall events.

##### Tripwires
- Groundwater levels exceed the bunker's design specifications.
- The bunker experiences a major flooding event, causing significant damage.
- Structural engineers determine that the UHPC walls have been compromised by water damage.

##### Response Playbook
- Contain: Immediately activate emergency flood control measures, including pumping systems and temporary barriers.
- Assess: Conduct a thorough assessment of the damage and identify the root causes of the flooding.
- Respond: Reinforce the bunker's drainage systems, implement long-term flood mitigation measures, or relocate critical equipment to higher levels.


**STOP RULE:** The bunker is deemed structurally unsound due to flood damage, or the cost of implementing effective flood mitigation measures exceeds the project's contingency budget.

---

#### FM9 - The Bunker Bust

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Marketing Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Public perception of the AI threat shifts, with many dismissing it as overblown or a distant concern. Alternative solutions for personal security and disaster preparedness become more popular and affordable. The concept of a VIP bunker loses its appeal, and potential occupants become reluctant to invest in such a costly and restrictive solution. The market for VIP bunker services dries up, and the project struggles to attract occupants. The bunker remains largely empty, a symbol of misplaced priorities and a failed business model. Investors lose confidence, and the project is forced to shut down.

##### Early Warning Signs
- Media coverage of the AI threat declines significantly.
- Alternative security and preparedness solutions gain market share.
- Potential VIP occupants express declining interest in the bunker concept.

##### Tripwires
- Occupancy rates remain below 25% after one year of operation.
- Market research indicates a significant decline in demand for VIP bunker services.
- Major investors express concerns about the project's long-term viability.

##### Response Playbook
- Contain: Implement aggressive marketing campaigns to re-emphasize the AI threat and highlight the bunker's unique benefits.
- Assess: Conduct thorough market research to understand the changing needs and preferences of potential occupants.
- Respond: Revise the bunker's services and amenities to better align with market demand, offer flexible occupancy options, or repurpose the bunker for alternative uses.


**STOP RULE:** The project is unable to attract sufficient occupants to cover operational costs, and investors refuse to provide additional funding.
