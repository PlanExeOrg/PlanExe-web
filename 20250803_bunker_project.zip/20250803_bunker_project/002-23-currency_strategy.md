This plan involves money.

## Currencies

- **EUR:** The project budget is specified in EUR, and Denmark is part of the European Union.
- **DKK:** Local transactions within Denmark may be conducted in DKK.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions may be conducted in DKK.