### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this complex, high-budget project with significant risks and strategic decisions. Ensures alignment with organizational goals and effective resource allocation.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Approve major project milestones and deliverables.
- Oversee risk management and mitigation strategies.
- Resolve strategic issues and conflicts.
- Monitor project performance against strategic objectives.
- Approve budget changes exceeding €5 million.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements.

**Membership:**

- Senior Management Representative (Chair)
- Chief Engineer
- Chief Security Officer
- Head of Legal
- Independent External Advisor (Construction Expert)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and risk management. Approval of budget changes exceeding €5 million. Approval of major changes to project scope or objectives.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Senior Management Representative (Chair) has the deciding vote. Escalation to the CEO if consensus cannot be reached.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Project status update.
- Risk assessment review.
- Budget review.
- Decision on strategic issues.
- Review of key performance indicators (KPIs).

**Escalation Path:** CEO
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring adherence to project plans, budget, and timelines. Provides operational risk management and support to the core project team.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Monitor project progress and performance.
- Manage project resources.
- Identify and manage operational risks.
- Coordinate communication among project stakeholders.
- Prepare project reports.
- Manage budget changes up to €5 million.

**Initial Setup Actions:**

- Establish project management methodology.
- Develop project templates and tools.
- Recruit project management staff.
- Define reporting procedures.

**Membership:**

- Project Manager (Head of PMO)
- Project Coordinators
- Project Schedulers
- Cost Controllers
- Risk Management Specialists

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management. Approval of budget changes up to €5 million.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Escalation to the Project Steering Committee for issues exceeding their authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project schedule and progress.
- Discussion of project risks and issues.
- Review of project budget and expenses.
- Coordination of project activities.
- Reporting on key performance indicators (KPIs).

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on critical aspects of the project, such as the UHPC walls, EMP cage, and life support systems. Ensures technical feasibility and compliance with relevant standards.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance and support to the project team.
- Conduct technical risk assessments.
- Oversee testing and quality control.
- Ensure compliance with relevant technical standards and regulations.
- Advise on technical solutions to project challenges.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define scope of technical review.
- Establish communication protocols.
- Set meeting schedule.

**Membership:**

- UHPC Specialist
- EMP Specialist
- Geotechnical Engineer
- Life Support Systems Engineer
- Independent External Advisor (Civil Engineer)

**Decision Rights:** Technical approval of designs, specifications, and testing procedures. Recommendation of technical solutions to the Project Steering Committee.

**Decision Mechanism:** Decisions made by consensus among the technical experts. In case of disagreement, the Independent External Advisor has the deciding vote. Escalation to the Project Steering Committee if consensus cannot be reached.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical risks and issues.
- Review of testing and quality control results.
- Advice on technical solutions.
- Reporting on technical compliance.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with ethical standards, legal regulations (including GDPR), and anti-corruption policies. Provides oversight and guidance on ethical considerations related to the project.

**Responsibilities:**

- Develop and implement ethics and compliance policies.
- Monitor compliance with relevant laws and regulations, including GDPR.
- Investigate ethical violations and compliance breaches.
- Provide training on ethics and compliance.
- Oversee whistleblower mechanism.
- Ensure adherence to anti-corruption policies.
- Review and approve contracts to ensure compliance.

**Initial Setup Actions:**

- Develop ethics and compliance policies.
- Establish reporting procedures.
- Recruit compliance officer.
- Set meeting schedule.

**Membership:**

- Head of Legal (Chair)
- Compliance Officer
- Human Resources Representative
- Security Officer
- Independent External Advisor (Ethics Expert)

**Decision Rights:** Decisions related to ethics and compliance policies, investigations, and corrective actions. Approval of contracts to ensure compliance. Recommendation of disciplinary actions to senior management.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Head of Legal (Chair) has the deciding vote. Escalation to the CEO if consensus cannot be reached.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of ethics and compliance policies.
- Discussion of compliance risks and issues.
- Review of investigation reports.
- Training on ethics and compliance.
- Reporting on compliance metrics.

**Escalation Path:** CEO
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the local community, regulatory bodies, and VIP occupants. Addresses concerns, provides updates, and ensures transparency throughout the project.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Communicate project updates to stakeholders.
- Address stakeholder concerns and feedback.
- Organize public forums and meetings.
- Maintain relationships with key stakeholders.
- Monitor stakeholder sentiment.
- Manage media relations.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop communication plan.
- Establish communication channels.
- Set meeting schedule.

**Membership:**

- Communications Manager (Chair)
- Community Liaison Officer
- Public Relations Representative
- VIP Liaison Officer
- Project Manager

**Decision Rights:** Decisions related to stakeholder communication and engagement strategies. Approval of communication materials. Recommendation of actions to address stakeholder concerns.

**Decision Mechanism:** Decisions made by the Communications Manager, in consultation with the Stakeholder Engagement Group. Escalation to the Project Steering Committee for issues exceeding their authority.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder concerns and feedback.
- Review of communication materials.
- Planning of public forums and meetings.
- Reporting on stakeholder sentiment.

**Escalation Path:** Project Steering Committee