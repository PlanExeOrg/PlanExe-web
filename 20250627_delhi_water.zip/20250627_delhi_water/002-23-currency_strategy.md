This plan involves money.

## Currencies

- **INR:** Local expenses, salaries, and procurement within India.
- **USD:** Initial budget specified in USD; also useful for international transactions and hedging against INR instability.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting will be USD to mitigate risks associated with INR fluctuations. INR will be used for local transactions. Hedging strategies should be considered to manage exchange rate risks, especially for long-term contracts and international procurement.