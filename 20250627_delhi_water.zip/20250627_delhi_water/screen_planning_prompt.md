**Verdict:** 🟢 USABLE

**Rationale:** The prompt specifies a concrete project with detailed constraints including a $250 million budget, 5-year timeline, specific location (Delhi), and technical scope (AWP manufacturing hub), which provides sufficient information for plan generation.