## Positive Constraints

- 5-year program
- $250 million budget
- Location: Delhi
- Address water scarcity and pollution
- Develop modular manufacturing hub for Advanced Water Purification (AWP) plants
- Recycle municipal wastewater into potable water
- Mitigate Yamuna River contamination
- Reduce dependency on groundwater aquifers
- Deliver scalable, mass-production-ready model
- Position Delhi as global exporter of standardized 'water-positive' solutions
- Project start ASAP
