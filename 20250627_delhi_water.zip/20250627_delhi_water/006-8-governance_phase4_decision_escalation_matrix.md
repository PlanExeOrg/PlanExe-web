**Budget Request Exceeding Core Project Team Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the Core Project Team's delegated financial authority ($1 million limit).
Negative Consequences: Potential for uncontrolled spending, budget overruns, and impact on project ROI.

**Technical Advisory Group Deadlock on AWP Technology Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Dissenting Opinions and Final Decision
Rationale: The Technical Advisory Group cannot reach a consensus on the optimal AWP technology, requiring a higher-level decision.
Negative Consequences: Selection of a suboptimal technology, leading to reduced efficiency, increased costs, and failure to meet project goals.

**Reported Ethical Concern Involving a Core Project Team Member**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with regulations.
Negative Consequences: Reputational damage, legal penalties, and loss of public trust.

**Proposed Major Scope Change Impacting Project Timeline by More Than 6 Months**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant scope changes require strategic oversight and approval due to potential impact on project goals and resources.
Negative Consequences: Project delays, budget overruns, and failure to meet project objectives.

**Stakeholder Opposition to AWP Plant Siting That Cannot Be Resolved by the Stakeholder Engagement Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Concerns and Final Decision
Rationale: Requires strategic decision-making to balance community needs with project objectives.
Negative Consequences: Project delays, legal challenges, and reputational damage.

**Unforeseen Environmental Impacts Discovered During Operations**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Environmental Impact Assessment and Approval of Remediation Plan
Rationale: Requires immediate action and strategic decision-making to mitigate environmental damage and ensure compliance with regulations.
Negative Consequences: Environmental damage, legal penalties, and reputational damage.