This plan involves money.

## Currencies

- **INR:** Essential for local Delhi operations, including labor, construction, permits, and utilities.
- **USD:** Used for the $250 million budget, international export contracts, and green bond financing.

**Primary currency:** USD

**Currency strategy:** Use USD for budgeting and reporting to align with international stakeholders; hedge against INR/USD fluctuations for local costs and revenue.