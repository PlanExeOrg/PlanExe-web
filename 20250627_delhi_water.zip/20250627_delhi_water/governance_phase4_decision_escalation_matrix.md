**Operational Budget Request Exceeding $5M USD Threshold**
Escalation Level: Project Steering Committee
Approval Process: Majority Vote with Chair Casting Vote
Rationale: Exceeds Core Program Office financial authority; impacts green bond allocation and strategic cash flow.
Negative Consequences: Unauthorized spending, audit failure, and potential breach of green bond covenants.

**Sustained Production Defect Rate Above 2% Quality Threshold**
Escalation Level: Project Steering Committee
Approval Process: Technical Review followed by Strategic Direction Approval
Rationale: Technical Advisory Group quality halt triggers redesign or pivot affecting project cost and timeline.
Negative Consequences: Export contract rejection, legal liability for non-compliant water systems, and loss of global market trust.

**Environmental Permitting Delay Exceeding 9-Month Baseline**
Escalation Level: Project Steering Committee
Approval Process: Risk Assessment and Timeline Revision Vote
Rationale: Threatens project critical path and delays mandatory green bond disbursement milestones.
Negative Consequences: Cash flow gap penalties, construction schedule slips, and delayed local water relief for residents.

**Alleged Misallocation of Funds or Corruption Discovery**
Escalation Level: Board of Directors or Ministry of Jal Shakti
Approval Process: Independent Investigation and Legal Review
Rationale: Requires highest authority to address criminal or major regulatory compliance violations beyond policy review.
Negative Consequences: Legal prosecution, permanent fund revocation, and termination of the entire manufacturing program.

**Community Acceptance Framework Score Below 80% Prior to Groundbreaking**
Escalation Level: Project Steering Committee
Approval Process: Formal Strategic Realignment Approval
Rationale: Blocking ground-breaking prevents execution; requires changing engagement strategy or budget allocation.
Negative Consequences: Local protests stalling operations, political backlash, and inability to secure site leases.