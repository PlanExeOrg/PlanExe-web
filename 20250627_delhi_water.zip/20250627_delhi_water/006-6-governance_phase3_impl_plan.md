### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**


### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**


### 4. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**


### 5. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**


### 6. Circulate Draft SteerCo ToR for review by nominated members (Senior Representatives from Delhi Jal Board, Ministry of Environment, Independent Expert, Chief Project Officer, Finance Department).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft Core Team ToR for review by potential members (Lead Engineer, Construction Manager, Supply Chain Manager, Community Engagement Manager, Financial Controller, Regulatory Compliance Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Core Team ToR v0.1
- Potential Members Identified

### 8. Circulate Draft TAG ToR for review by potential members (Independent Expert, Senior Engineer from Delhi Jal Board, Representative from AWP Technology Provider, Environmental Scientist, Chemical Engineer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Potential Members Identified

### 9. Circulate Draft ECC ToR for review by potential members (Independent Legal Counsel, Senior Representative from Finance Department, Senior Representative from Regulatory Compliance Department, Representative from a Local NGO, Ethics Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1
- Potential Members Identified

### 10. Circulate Draft SEG ToR for review by potential members (Community Engagement Manager, Representative from a Local NGO, Representative from the Delhi Jal Board, Communications Officer, Public Relations Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1
- Potential Members Identified

### 11. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary from SteerCo ToR Review

### 12. Project Manager finalizes the Terms of Reference for the Core Project Team based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Team ToR v1.0

**Dependencies:**

- Feedback Summary from Core Team ToR Review

### 13. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary from TAG ToR Review

### 14. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary from ECC ToR Review

### 15. Project Manager finalizes the Terms of Reference for the Stakeholder Engagement Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary from SEG ToR Review

### 16. Project Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Sponsor formally confirms the membership of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- SteerCo Chair Appointed

### 18. Project Sponsor formally appoints the Project Manager.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Core Team ToR v1.0

### 19. Project Manager, in consultation with the Project Sponsor, formally confirms the membership of the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final Core Team ToR v1.0
- Project Manager Appointed

### 20. Project Steering Committee holds its initial kick-off meeting to review and approve the project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan
- Approved Budget

**Dependencies:**

- Membership Confirmation Email
- Final SteerCo ToR v1.0
- Project Plan Draft Available
- Budget Draft Available

### 21. Project Manager, in consultation with the Project Steering Committee Chair, identifies and recruits qualified technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- List of TAG Members

**Dependencies:**

- Final TAG ToR v1.0
- SteerCo Chair Appointed

### 22. Project Steering Committee Chair formally appoints the Chair of the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0
- List of TAG Members

### 23. Project Steering Committee Chair formally confirms the membership of the Technical Advisory Group.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0
- TAG Chair Appointed

### 24. Technical Advisory Group holds its initial kick-off meeting to review the AWP technology selection.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- AWP Technology Selection Recommendations

**Dependencies:**

- Membership Confirmation Email
- Final TAG ToR v1.0
- AWP Technology Options Available

### 25. Project Steering Committee Chair identifies and recruits qualified members for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- List of ECC Members

**Dependencies:**

- Final ECC ToR v1.0

### 26. Project Steering Committee Chair formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0
- List of ECC Members

### 27. Project Steering Committee Chair formally confirms the membership of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0
- ECC Chair Appointed

### 28. Ethics & Compliance Committee holds its initial kick-off meeting to develop the code of ethics for the project.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Code of Ethics

**Dependencies:**

- Membership Confirmation Email
- Final ECC ToR v1.0

### 29. Project Manager, in consultation with the Project Steering Committee Chair, identifies and recruits qualified members for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- List of SEG Members

**Dependencies:**

- Final SEG ToR v1.0
- SteerCo Chair Appointed

### 30. Project Steering Committee Chair formally appoints the Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0
- List of SEG Members

### 31. Project Steering Committee Chair formally confirms the membership of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0
- SEG Chair Appointed

### 32. Stakeholder Engagement Group holds its initial kick-off meeting to develop the stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Stakeholder Engagement Plan

**Dependencies:**

- Membership Confirmation Email
- Final SEG ToR v1.0

### 33. Core Project Team holds its initial kick-off meeting to assign initial tasks and review project plan.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Task Assignments

**Dependencies:**

- Membership Confirmation Email
- Final Core Team ToR v1.0
- Approved Project Plan