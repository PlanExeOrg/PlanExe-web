
## Audit - Corruption Risks

- Bribery to expedite environmental clearances from the Delhi Pollution Control Committee (DPCC)
- Kickbacks in the selection process for industrial park partners providing assembly lines
- Nepotism in hiring local technicians for the workforce training pipeline
- Conflicts of interest in contracts for sourcing critical filtration membrane components
- Misuse of insider information regarding green bond allocation between CapEx and OpEx

## Audit - Misallocation Risks

- Misappropriation of CapEx funds intended for the manufacturing hub construction
- Double billing on land lease agreements in Okhla or Noida Special Economic Zone
- Inefficient allocation of OpEx on community outreach versus core operational runway
- Unauthorized use of shared assets or equipment in partner industrial parks
- Poor record keeping on currency hedging results leading to budget variance

## Audit - Procedures

- Quarterly internal reviews of green bond disbursements against the 60% CapEx/40% OpEx split
- Third-party quality inspections of partner assembly lines before pilot production batches
- Compliance verification for environmental permits before ground-breaking begins
- Vendor due diligence audits for critical filtration part suppliers and dual-sourcing agreements
- Post-project external audit comparing export revenue against local fulfillment targets

## Audit - Transparency Measures

- Real-time public dashboard displaying water quality data and plant operational metrics
- Published meeting minutes from the DPCC and Ministry of Jal Shakti steering committee
- Anonymous whistleblower mechanism for reporting contractor and employee misconduct
- Detailed annual reports on fund usage submitted to international development banks
- Public documentation of selection criteria for industrial partners and component vendors