A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Environmental clearances from the Delhi Pollution Control Committee will be secured within 9 months despite historical precedents suggesting 12 to 18 months. | Submit preliminary ECC application by September 15, 2026, and conduct a pre-filing technical review meeting with DPCC officials within 30 days to confirm readiness. | DPCC rejects the preliminary documentation or formally advises that standard review timelines will exceed 120 days from submission. |
| A2 | The manufacturing hub production facility qualifies directly under international green bond taxonomies without requiring significant restructuring or separate financing streams. | Engage a green bond certification consultant to obtain a formal pre-issuance certification opinion by November 1, 2026. | The consultant certifies that the manufacturing facility falls under 'industrial manufacturing' rather than direct green infrastructure, causing bond rejection. |
| A3 | Industrial park partners will strictly adhere to agreed QA standards and defect rate thresholds without requiring direct supervision from project staff. | Complete onsite ISO-certified audits for top three industrial park partners by September 30, 2026. | Onsite audit reveals QA protocol gaps, lack of calibration for water quality sensors, or historical defect rates exceeding the 2% threshold. |
| A4 | Daily municipal wastewater inflow will remain consistent at 5,000 cubic meters with contaminant levels within design tolerance without binding MOUs. | Draft binding MOU with municipal authorities including volume guarantees and penalty clauses by October 5, 2026. | Municipal corporation refuses to sign a binding volume guarantee or confirms wastewater flow variability exceeding ±20%. |
| A5 | Export clients will purchase units at the target price point without demanding significant regulatory customization that fragments the production line. | Complete regulatory mapping for top five export markets and secure a confirmed export contract by October 31, 2026. | Target markets require unique certifications that increase unit costs by >15% or clients delay contracts by >30 days. |
| A6 | Local communities will accept potable water from wastewater sources with 80% positive sentiment after transparency initiatives without requiring additional budget. | Launch transparent real-time water quality dashboard and conduct town halls starting September 30, 2026. | Community sentiment surveys drop below 70% positive within 60 days of public announcement despite active engagement. |
| A7 | Local technician training pipeline will achieve the 3:1 local-to-foreign ratio by Year 2 without requiring foreign expert extension. | Finalize academy curriculum and sign college MOUs by Month 4 to validate training throughput. | Certification rates drop below 70% in first 3 cohorts or foreign experts needed beyond Year 2. |
| A8 | Critical membrane components will remain available at contracted prices without geopolitical export controls or 10% cost hikes. | Secure dual-sourcing agreements with verified secondary suppliers by Month 6 to ensure continuity. | Lead times exceed 12 weeks or price hikes exceed 10% on core filtration materials. |
| A9 | Partners will not reverse-engineer core filtration designs within 24 months, maintaining licensing margins. | Implement digital rights management on schematics and sign NDA with penalty clauses by Month 3. | Unauthorized use detected or licensing revenue drops >15% within 18 months. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Green Bond Taxonomy Rejection | Process/Financial | A2 | Financial Strategy & Green Bond Administrator | CRITICAL (20/25) |
| FM2 | The Partner Quality Collapse | Technical/Logistical | A3 | Manufacturing Operations & Partner Line Manager | HIGH (12/25) |
| FM3 | The Regulatory Gridlock Stagnation | Market/Human | A1 | Regulatory & Environmental Compliance Lead | CRITICAL (20/25) |
| FM4 | The Inflow Volatility Collapse | Technical/Logistical | A4 | Head of Operations | HIGH (12/25) |
| FM5 | The Export Pricing Mismatch | Market/Human | A5 | Export Business Development Manager | CRITICAL (20/25) |
| FM6 | The Social License Deficit | Process/Financial | A6 | Community Relations & Stakeholder Engagement Lead | CRITICAL (15/25) |
| FM7 | The Labor Cost Explosion | Process/Financial | A7 | Workforce Development & Technical Training Coordinator | HIGH (12/25) |
| FM8 | The Component Chokepoint | Technical/Logistical | A8 | Supply Chain & International Logistics Manager | CRITICAL (15/25) |
| FM9 | The IP Leakage Crisis | Market/Human | A9 | Program Director | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Green Bond Taxonomy Rejection

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Financial Strategy & Green Bond Administrator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project depends on $250M in green bond capital to fund the manufacturing hub. If the hub fails green taxonomy eligibility because it manufactures rather than operates environmental assets, development banks will reject the use of proceeds. This forces a pivot to commercial debt at significantly higher interest rates. The increased cost of capital erodes margins, creates immediate liquidity gaps during the non-revenue construction phase, and delays the bond drawdowns needed to fund site acquisition and initial operations.

##### Early Warning Signs
- Pre-issuance certification opinion received after November 1, 2026
- Development bank feedback indicates 'industrial manufacturing' classification risk
- Commercial debt interest rate offers exceed 9% APR

##### Tripwires
- Pre-issuance certification opinion received after November 1, 2026
- Commercial debt offers exceed 9% APR
- Development banks request structural changes to use-of-proceeds framework

##### Response Playbook
- Contain: Halt all public marketing of the green bond prospectus immediately to prevent reputational damage.
- Assess: Conduct a detailed cost-benefit analysis comparing revised green bond terms against alternative financing options like mezzanine debt.
- Respond: Pivot funding strategy to structure bonds only for direct water assets and use commercial debt for the manufacturing hub.


**STOP RULE:** If the weighted average cost of capital (WACC) exceeds 12% APR after restructuring, cancel the current financing tranche and pause all non-essential CapEx.

---

#### FM2 - The Partner Quality Collapse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Manufacturing Operations & Partner Line Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Partnering with industrial parks was chosen to reduce setup time and costs, but it removes direct oversight of the assembly line. In a real-world failure scenario, partners prioritize their own clients or lack the expertise to handle precision membrane filtration components. This leads to a spike in defect rates, failure to pass ISO export certification tests, and delivery delays. The resulting reputational damage in export markets triggers contract penalties and forces expensive third-party rework or product recalls.

##### Early Warning Signs
- Defect rates in pilot batches exceed 2% for more than two consecutive weeks
- Third-party audit scores for partners drop below 80%
- Partner delays in material inventory reporting exceed 7 days

##### Tripwires
- Defect rates exceed 2% for 3 consecutive batches
- Partner audit scores drop below 80%
- Production downtime exceeds 10 hours due to quality rework

##### Response Playbook
- Contain: Immediately halt outbound shipments from affected partner lines and isolate all stock produced in the last month.
- Assess: Deploy independent ISO auditors to verify root causes of defects and review partner calibration logs.
- Respond: Enforce strict rework protocols and temporarily bring critical module assembly in-house to stabilize quality.


**STOP RULE:** If partner defect rates exceed 5% after one month of strict intervention protocols, terminate the partnership agreement and migrate all production to in-house facilities.

---

#### FM3 - The Regulatory Gridlock Stagnation

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Regulatory & Environmental Compliance Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project timeline assumes 9 months for environmental clearance. However, if the Delhi Pollution Control Committee requires extensive studies or faces public objections regarding wastewater-to-potable standards, approvals may slip by 12 to 18 months. During this prolonged delay, the project continues to burn capital on site leases and salaries while generating no revenue. Local community trust erodes as the site remains idle and unproductive, leading to protests that further delay site activation and threaten the project's social license to operate.

##### Early Warning Signs
- Regulatory application remains pending without substantive feedback for 60 days
- Community sentiment surveys drop below 70% positive
- Operational burn rate exceeds $2M per month

##### Tripwires
- Permit application pending for > 120 days
- Monthly burn rate exceeds $2M
- Community sentiment score drops below 70%

##### Response Playbook
- Contain: Freeze all non-essential hiring and reduce discretionary spending to extend cash runway.
- Assess: Commission an independent legal review of the DPCC submission package to identify technical rejection criteria.
- Respond: Implement a parallel filing strategy for provisional permits while launching a targeted community engagement campaign to mitigate sentiment loss.


**STOP RULE:** If the Environmental Clearance Certificate is not received by Month 15, cancel the full-scale manufacturing hub and pivot to a reduced pilot-only deployment strategy.

---

#### FM4 - The Inflow Volatility Collapse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Head of Operations
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Unbound wastewater inflow leads to operational idle time when municipal flows drop below 5,000 m³/day. The system lacks the buffer capacity to handle this fluctuation. This forces expensive retrofitting of intake infrastructure or results in unused production capacity, failing to meet revenue targets.

##### Early Warning Signs
- Actual wastewater intake drops below 4,000 m³/day for 3 consecutive weeks
- Contaminant levels exceed design thresholds in 20% of daily samples
- Municipal authorities delay finalizing MOU terms past October 5, 2026

##### Tripwires
- Actual wastewater intake drops below 4,000 m³/day for 3 consecutive weeks
- MOU terms not finalized by October 5, 2026
- Intake infrastructure idle time exceeds 10% of scheduled hours

##### Response Playbook
- Contain: Temporarily reduce production output to match available intake volume to prevent system stress.
- Assess: Engage municipal engineering consultants to evaluate feasibility of backup water sources.
- Respond: Secure binding MOU with volume guarantees and install flexible intake buffering systems.


**STOP RULE:** If wastewater intake drops below 3,000 m³/day for two months, suspend production operations and pivot to a smaller-scale pilot configuration.

---

#### FM5 - The Export Pricing Mismatch

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Export Business Development Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
International buyers reject the standardized pricing model due to local purchasing power or regulatory requirements. They demand customized units that fragment the production line. This drives unit costs up by 15-20% while simultaneously eroding margins through lower sales volume in price-sensitive markets.

##### Early Warning Signs
- Export client rejection rate exceeds 30% of qualified leads
- Unit cost increase requests exceed 10% of target price
- Market mapping reveals >2 unique regulatory requirements per region

##### Tripwires
- Export client rejection rate exceeds 30% of qualified leads
- Unit cost increase requests exceed 10% of target price
- First confirmed export contract not secured by Q1 2027

##### Response Playbook
- Contain: Pause all customization requests and standardize sales contracts to a universal offering.
- Assess: Conduct pre-sales market validation to identify regions with lowest regulatory friction.
- Respond: Adjust capacity allocation to flexible 70% local / 30% export model for first 2 years.


**STOP RULE:** If confirmed export contracts represent less than 20% of capacity by end of Year 1, halt export operations and pivot to 100% local fulfillment.

---

#### FM6 - The Social License Deficit

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Community Relations & Stakeholder Engagement Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Failure to gain community acceptance triggers protests that stall local fulfillment projects. This delays site activation, extends the pre-revenue burn rate, and forces a pivot to export-only delivery which violates the public welfare mandate. The resulting financial strain and reputational damage jeopardize the green bond repayment schedule.

##### Early Warning Signs
- Public sentiment surveys drop below 70% positive
- Community meetings are disrupted by organized opposition groups
- Media reports link project to environmental hazards

##### Tripwires
- Public sentiment surveys drop below 70% positive
- Community protests delay site activation by 30+ days
- Negative media reports increase by 20% month-over-month

##### Response Playbook
- Contain: Pause ground-breaking activities immediately to prevent escalation.
- Assess: Audit current engagement metrics and identify specific community concerns.
- Respond: Implement transparent real-time water quality dashboards and adjust engagement budget.


**STOP RULE:** If sentiment remains below 60% positive for 3 consecutive months after intervention, cancel the local fulfillment component and relocate project assets.

---

#### FM7 - The Labor Cost Explosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Workforce Development & Technical Training Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
Failure to train local staff forces continued reliance on expensive foreign experts. This inflates OPEX by 20% annually and delays local knowledge transfer, eroding margins and threatening project solvency.

##### Early Warning Signs
- Foreign expert headcount remains above 40% by Year 2
- Training certification rate drops below 70%
- Monthly labor OPEX exceeds $1.5M

##### Tripwires
- Foreign expert headcount remains above 40% by Year 2
- Training certification rate drops below 70%
- Monthly labor OPEX exceeds $1.5M

##### Response Playbook
- Contain: Freeze all new foreign expert hires immediately to stop cost bleeding.
- Assess: Audit training academy capacity and identify curriculum gaps causing low pass rates.
- Respond: Launch an accelerated certification program with external colleges and cap foreign staff budget at 25%.


**STOP RULE:** If foreign expert dependency exceeds 60% at the start of Year 3, halt production ramp-up and renegotiate labor contracts.

---

#### FM8 - The Component Chokepoint

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Supply Chain & International Logistics Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Geopolitical tensions or vendor pricing hikes disrupt membrane supply. Production halts occur, export contracts are penalized, and redesign costs for alternative filters exceed $15M.

##### Early Warning Signs
- Supplier inventory levels drop below 3 months
- Membrane lead times exceed 12 weeks
- Secondary supplier qualification delayed past Month 6

##### Tripwires
- Supplier inventory levels drop below 3 months
- Membrane lead times exceed 12 weeks
- Secondary supplier qualification delayed past Month 6

##### Response Playbook
- Contain: Restrict membrane usage to high-margin export orders only to preserve stock.
- Assess: Verify alternative supplier specs for membrane substitution viability.
- Respond: Activate secondary contracts and initiate emergency procurement of backup filtration stages.


**STOP RULE:** If component stockout exceeds 8 weeks without viable substitute approval, suspend all export shipments and pause hub operations.

---

#### FM9 - The IP Leakage Crisis

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Program Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Partner reverse-engineering or unauthorized sharing of schematics commoditizes the technology. Licensing revenue drops by 15-20%, competitors undercut pricing, and competitive advantage erodes globally.

##### Early Warning Signs
- Competitor products match core specs within 12 months
- Licensing revenue drops >15% year-over-year
- Partner NDA breach reports filed

##### Tripwires
- Competitor products match core specs within 12 months
- Licensing revenue drops >15% year-over-year
- Partner NDA breach reports filed

##### Response Playbook
- Contain: Suspend all new partner licensing agreements immediately.
- Assess: Conduct forensic audit of shared documentation and trace leakage sources.
- Respond: Enforce legal penalties and shift assembly of core modules to company-owned facilities.


**STOP RULE:** If licensing margins drop below 25% of revenue by end of Year 1, cancel the open IP strategy and pivot to direct manufacturing only.
