Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 9 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 9 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a civil engineering and infrastructure development plan focused on established water treatment technologies. It relies on known physical processes like filtration and separation, which do not violate conservation laws or thermodynamics.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "Establish a $250 million, 5-year modular Advanced Water Purification (AWP) manufacturing hub" without independent evidence at comparable scale. Expert review notes manufacturing hubs often fail green taxonomy, creating existential funding risk if rejected.

**Mitigation**: Program Director: Run parallel validation tracks for market, legal, and technical subdomains with two global NO-GO gates; deliver preliminary findings within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because named frameworks like "Pragmatic Foundation" exist, but review notes "Without a prototype 'Killer Application'... export sales may miss 50% capacity" indicating missing value hypothesis one-pagers.

**Mitigation**: Program Strategy Lead: Draft one-pagers outlining value hypotheses, success metrics, and decision hooks for market differentiation scenarios within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because cascades are described narratively, e.g., 'creates immediate liquidity gaps' in FM1, but a formal register mapping cascades with dated review cadence is missing.

**Mitigation**: Program Director: Expand risk register to map cascade chains with controls and a review cadence, within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes "Environmental clearances within 9 months" while expert review notes Delhi projects often face 12–18 month delays, exceeding schedule by >20%.

**Mitigation**: Regulatory Lead: Rebuild critical path with authoritative DPCC lead times and a NO-GO slip threshold within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lists "$250 million green bond capital" as resource without closed term sheets or draw schedules. Runway calculation in months is absent and financing covenants remain undefined per review notes.

**Mitigation**: Financial Strategy Lead: Draft a dated financing plan listing status, draw schedule, covenants, and a NO-GO on missed financing gates within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan cites "$250 million green bond capital" and "infrastructure benchmarks" but provides no vendor quotes or normalized cost per sq ft for the 20,000 sq ft footprint.

**Mitigation**: Financial Strategy Lead: Benchmark three comparable water tech manufacturing projects with vendor fit-out quotes normalized per square foot and adjust budget within 45 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or scenarios. The goal states "export 50% of capacity" and "$250 million" budget as fixed targets, while assumptions.md notes "50/50 export split risks cash flow gaps" without alternative case analysis.

**Mitigation**: Financial Strategy Lead: Develop best/worst/base-case scenario analysis for export revenue and regulatory timeline projections within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because WBS tasks require to 'Finalize modular design standards' and assumptions.md notes 'Technical specifications for solar integration' are missing.

**Mitigation**: Technical Process Architect: Produce interface contracts and acceptance test plans for core filtration modules within 45 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because plan states "Issue green bonds through international development banks" without term sheets. Critical claims like binding feedstock MOUs also lack signed artifacts per review notes.

**Mitigation**: Financial Strategy Lead: Obtain pre-issuance green bond certification opinion and draft binding feedstock MOU with volume guarantees within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because plan states "export 50% of capacity" without verifiable qualities. Review Plan notes "Undefined Market Differentiation... export sales may miss the 50% capacity target."

**Mitigation**: Export Business Development Manager: Define SMART acceptance criteria for export deliverables and KPI for signed contracts within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan targets a "Net-negative carbon footprint over 5 years" calling it "ambitious," while core goals are local water access and export revenue. This adds cost without binding support.

**Mitigation**: Program Strategy Lead: Produce a one-page benefit case with KPI and cost or move feature to backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan depends on a "certified financial expert specializing in sustainable finance and green bond structuring" to secure $250M capital without evidence such rare talent exists locally.

**Mitigation**: Program Director: Interview top five candidates with green bond certification and infrastructure experience to confirm availability and offer terms within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan lists permits such as "Environmental Clearance Certificate (ECC)" and states "Retain local legal experts" with an application date of "September 15, 2026".

**Mitigation**: Regulatory Lead: Conduct pre-filing technical review with DPCC officials within 30 days to validate 9-month timeline feasibility.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Review Plan 14 states "Clarifying how major component replacements post-Year 5 will be funded... prevents 20% operational downtime," yet post-bond OpEx is undefined.

**Mitigation**: Financial Strategy Lead: Define sinking fund and long-term maintenance funding strategy outside bond proceeds within 30 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan assumes 'Environmental clearances within 9 months' while expert review states historical data suggests 12-18 months creating timeline uncertainty.

**Mitigation**: Regulatory Lead: Conduct fatal-flaw screen with DPCC officials and define NO-GO thresholds within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan proposes "Establish dual-sourcing agreements for critical filtration parts" but Premortem FM8 flags component chokepoints as CRITICAL risk without tested fallbacks.

**Mitigation**: Supply Chain Manager: Secure secondary supplier contracts and validate backup capacity for critical membranes within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan states 'balancing immediate humanitarian needs with sustainable economic growth' but lacks shared metrics aligning Finance and Program goals on public welfare outcomes.

**Mitigation**: Program Director and CFO: Draft shared OKRs connecting export revenue targets to local water access metrics with quarterly review cadence within 30 days to ensure aligned incentives on dual objectives.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan contains STOP RULE thresholds in premortem, yet review-plan recommends 'establishing a weekly dashboard showing key metric progress' implying internal review cadence lacks owner ownership.

**Mitigation**: Program Director: Form a change board, define monthly KPI review cadence with owners, and approve thresholds for re-planning within 45 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because regulatory delays cascade into feedstock failures and bond defaults without formal cross-impact mapping. Three high risks couple: permits, currency, and export compliance.

**Mitigation**: Program Director: Produce interdependency map, bow-tie FTA analysis, and combined risk heatmap with assigned owners and NO-GO thresholds within 45 days to validate systemic control coverage and confirm dependencies.