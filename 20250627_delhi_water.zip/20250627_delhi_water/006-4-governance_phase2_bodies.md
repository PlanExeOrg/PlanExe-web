### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the entire 5-year, $250 million program, ensuring alignment with overall goals and objectives. Given the project's scale, complexity, and ambition to establish Delhi as a global exporter, a high-level steering committee is crucial.

**Responsibilities:**

- Approve the overall project plan and budget.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones and objectives.
- Approve major changes to the project scope, budget, or timeline (>$1 million).
- Oversee risk management and mitigation strategies.
- Resolve strategic conflicts and escalate issues as needed.
- Approve export market entry strategy.
- Approve AWP plant ownership model.
- Approve financial sustainability model.

**Initial Setup Actions:**

- Finalize the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Establish the meeting schedule and communication protocols.
- Review and approve the initial project plan and budget.

**Membership:**

- Senior Representative from Delhi Jal Board
- Senior Representative from Ministry of Environment, Forest and Climate Change
- Independent Expert in Water Purification Technology
- Chief Project Officer
- Senior Representative from Finance Department

**Decision Rights:** Strategic decisions related to project scope, budget (>$1 million), timeline, and overall direction. Approval of key strategic decisions like export market entry strategy, AWP plant ownership model, and financial sustainability model.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Committee Chair has the deciding vote. Any dissenting opinions are formally recorded in the meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against key milestones.
- Discussion of strategic risks and mitigation strategies.
- Approval of major changes to the project scope, budget, or timeline.
- Review of financial performance.
- Updates from the Chief Project Officer.
- Review of export market performance and strategy.

**Escalation Path:** Issues that cannot be resolved by the Project Steering Committee are escalated to the relevant Ministry Secretary or equivalent senior government official.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient and effective implementation of the project plan. Given the project's complexity and the need for coordinated action across multiple workstreams, a dedicated project team is essential.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project resources and budget (decisions below $1 million).
- Track project progress and report on key performance indicators.
- Identify and manage project risks and issues.
- Coordinate the activities of the various project workstreams.
- Ensure compliance with all relevant regulations and standards.
- Implement the community engagement plan.
- Manage the supply chain.
- Oversee the construction and operation of the AWP plants.

**Initial Setup Actions:**

- Appoint the Project Manager.
- Define the roles and responsibilities of team members.
- Establish communication protocols and reporting requirements.
- Develop the initial project plan and budget.

**Membership:**

- Project Manager
- Lead Engineer
- Construction Manager
- Supply Chain Manager
- Community Engagement Manager
- Financial Controller
- Regulatory Compliance Officer

**Decision Rights:** Operational decisions related to project execution, resource allocation (decisions below $1 million), and risk management. Decisions related to day-to-day operations of the manufacturing hub and AWP plants.

**Decision Mechanism:** Decisions are made by the Project Manager in consultation with the relevant team members. In the event of a disagreement, the Project Manager has the final decision-making authority, but must document the dissenting opinions.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against key milestones.
- Discussion of project risks and issues.
- Review of financial performance.
- Updates from the various project workstreams.
- Action item tracking.
- Review of regulatory compliance status.

**Escalation Path:** Issues that cannot be resolved by the Core Project Team are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice and guidance on all aspects of the AWP technology, ensuring that the project utilizes the most appropriate and effective solutions. Given the technical complexity of the project and the need to ensure optimal performance of the AWP plants, a technical advisory group is crucial.

**Responsibilities:**

- Evaluate and recommend AWP technologies.
- Provide technical guidance on the design, construction, and operation of the AWP plants.
- Review and approve technical specifications and drawings.
- Monitor the performance of the AWP plants and recommend improvements.
- Advise on technical risks and mitigation strategies.
- Ensure that the AWP technology meets all relevant standards and regulations.
- Advise on AWP System Customization.

**Initial Setup Actions:**

- Identify and recruit qualified technical experts.
- Define the scope of the Technical Advisory Group's responsibilities.
- Establish communication protocols and reporting requirements.
- Review the initial AWP technology selection.

**Membership:**

- Independent Expert in Water Purification Technology (Chair)
- Senior Engineer from Delhi Jal Board
- Representative from the AWP Technology Provider
- Environmental Scientist
- Chemical Engineer

**Decision Rights:** Provides recommendations on all technical aspects of the project. Final decision-making authority rests with the Project Steering Committee, but the Committee gives significant weight to the Technical Advisory Group's recommendations.

**Decision Mechanism:** Recommendations are made by consensus. In the event of a disagreement, the Chair facilitates a discussion to reach a compromise. If a consensus cannot be reached, the Chair prepares a summary of the dissenting opinions for the Project Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of AWP technology performance.
- Discussion of technical risks and issues.
- Evaluation of new AWP technologies.
- Review of technical specifications and drawings.
- Updates from the Lead Engineer.
- Review of pilot testing results.

**Escalation Path:** Technical issues that cannot be resolved by the Technical Advisory Group are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures that the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, environmental regulations, and anti-corruption laws. Given the project's scale, public funding, and potential for corruption, a dedicated ethics and compliance committee is crucial.

**Responsibilities:**

- Develop and implement a code of ethics for the project.
- Monitor compliance with all relevant regulations and standards.
- Investigate allegations of ethical misconduct or regulatory violations.
- Recommend corrective actions to address ethical or compliance issues.
- Provide training to project staff on ethical and compliance matters.
- Oversee the whistleblower mechanism.
- Ensure compliance with GDPR and other data privacy regulations.
- Review and approve all contracts and procurement processes to ensure transparency and fairness.

**Initial Setup Actions:**

- Develop and approve the Committee's Terms of Reference.
- Appoint the Committee Chair.
- Establish the meeting schedule and communication protocols.
- Develop the code of ethics for the project.

**Membership:**

- Independent Legal Counsel (Chair)
- Senior Representative from the Finance Department
- Senior Representative from the Regulatory Compliance Department
- Representative from a Local NGO focused on Transparency and Accountability
- Ethics Officer

**Decision Rights:** Investigates ethical and compliance violations and recommends corrective actions. Has the authority to suspend project activities pending investigation. Final decision-making authority rests with the Project Steering Committee, but the Committee gives significant weight to the Ethics & Compliance Committee's recommendations.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Committee Chair has the deciding vote. Any dissenting opinions are formally recorded in the meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance with relevant regulations and standards.
- Discussion of ethical risks and issues.
- Investigation of alleged ethical misconduct or regulatory violations.
- Review of contracts and procurement processes.
- Updates from the Ethics Officer.
- Review of whistleblower reports.

**Escalation Path:** Ethical or compliance issues that cannot be resolved by the Ethics & Compliance Committee are escalated to the Project Steering Committee and, if necessary, to the relevant law enforcement authorities.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and engagement with all relevant stakeholders, including Delhi residents, government agencies, technology providers, and local suppliers. Given the project's potential impact on the community and the need for broad support, a dedicated stakeholder engagement group is crucial.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct community consultations and public awareness campaigns.
- Establish and maintain relationships with key stakeholders.
- Address stakeholder concerns and grievances.
- Provide regular project updates to stakeholders.
- Monitor stakeholder satisfaction and feedback.
- Ensure that the project is responsive to community needs and priorities.
- Manage media relations.

**Initial Setup Actions:**

- Develop and approve the Group's Terms of Reference.
- Appoint the Group Chair.
- Establish the meeting schedule and communication protocols.
- Develop the stakeholder engagement plan.

**Membership:**

- Community Engagement Manager (Chair)
- Representative from a Local NGO
- Representative from the Delhi Jal Board
- Communications Officer
- Public Relations Officer

**Decision Rights:** Develops and implements the stakeholder engagement plan. Recommends changes to the project plan based on stakeholder feedback. Final decision-making authority rests with the Project Steering Committee, but the Committee gives significant weight to the Stakeholder Engagement Group's recommendations.

**Decision Mechanism:** Recommendations are made by consensus. In the event of a disagreement, the Chair facilitates a discussion to reach a compromise. If a consensus cannot be reached, the Chair prepares a summary of the dissenting opinions for the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder feedback.
- Discussion of stakeholder concerns and grievances.
- Planning of community consultations and public awareness campaigns.
- Review of media coverage.
- Updates from the Communications Officer.
- Review of stakeholder engagement plan.

**Escalation Path:** Stakeholder issues that cannot be resolved by the Stakeholder Engagement Group are escalated to the Project Steering Committee.