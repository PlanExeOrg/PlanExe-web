### 1. Project Sponsor issues formal mandate to establish the governance framework and appoints a Governance Lead to coordinate initial setup.

**Responsible Body/Role:** Project Sponsor (Executive CEO)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Mandate Email
- Appointment of Governance Lead

**Dependencies:**

- Project Goal Statement Approved

### 2. Governance Lead coordinates Legal Counsel to draft Terms of Reference (ToR) for Steering Committee, PMO, TAG, and ECRC.

**Responsible Body/Role:** Governance Lead & Legal Counsel

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Draft PMO ToR v0.1
- Draft TAG ToR v0.1
- Draft ECRC ToR v0.1

**Dependencies:**

- Formal Mandate Issued

### 3. Draft ToRs circulated to proposed members for input, ensuring roles align with strategic priorities like green bonds and modular standardization.

**Responsible Body/Role:** Governance Lead

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Member Feedback Summary
- Revised ToR Drafts v0.2

**Dependencies:**

- Initial ToR Drafts Completed

### 4. Project Sponsor reviews and formally approves all final ToRs to validate authority levels and decision mechanisms.

**Responsible Body/Role:** Project Sponsor (Executive CEO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved ToR Package (All 4 Bodies)

**Dependencies:**

- Revised ToR Drafts Submitted

### 5. Project Sponsor officially appoints Chairs and Lead roles for each body, including External Members where required by strategy.

**Responsible Body/Role:** Project Sponsor (Executive CEO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Official Appointment Letters (Chairs & Leads)
- Notification of External Member Selection

**Dependencies:**

- Final ToR Approved

### 6. Appointed Chairs nominate specific members for their committees; HR verifies availability and time allocation capacity.

**Responsible Body/Role:** Appointed Chairs

**Suggested Timeframe:** Project Week 3-4

**Key Outputs/Deliverables:**

- Proposed Member Lists per Committee
- HR Capacity Verification

**Dependencies:**

- Chairs Officially Appointed

### 7. Formal confirmation of all committee memberships is issued by HR and communicated to the organization to authorize voting rights.

**Responsible Body/Role:** Human Resources & Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed Membership Roster
- Organization-Wide Governance Announcement

**Dependencies:**

- Proposed Member Lists Verified

### 8. Chairs convene first kick-off meetings for each body to operationalize mandates and assign initial critical path tasks.

**Responsible Body/Role:** Appointed Chairs

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Minutes & Quarterly Plan
- PMO Kick-off Minutes & Operational KPIs
- TAG Kick-off Minutes & Tech Standards
- ECRC Kick-off Minutes & Audit Schedule

**Dependencies:**

- Membership Confirmation Completed

### 9. PMO deploys cloud-based ERP system to unify inventory, quality control data across industrial park partners as per strategic requirements.

**Responsible Body/Role:** Core Program Office (PMO)

**Suggested Timeframe:** Month 1 - Month 2

**Key Outputs/Deliverables:**

- ERP System Live for Inventory & QA
- Partner Data Integration Report

**Dependencies:**

- PMO Kick-off Meeting Completed

### 10. ECRC publishes Whistleblower policy and establishes formal liaison channels with the Delhi Pollution Control Committee (DPCC).

**Responsible Body/Role:** Ethics, Compliance & Risk Committee (ECRC)

**Suggested Timeframe:** Month 2

**Key Outputs/Deliverables:**

- Published Whistleblower Policy
- DPCC Liaison Contact Agreement

**Dependencies:**

- ECRC Kick-off Meeting Completed

### 11. Steering Committee reviews and approves initial production capacity ramp-up plan aligned with green bond milestones.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Month 3

**Key Outputs/Deliverables:**

- Approved Q1 Production Ramp-up Plan
- Initial Budget Allocation Order

**Dependencies:**

- PMO Operational Plan Submitted
- Green Bond Issuance Timeline Fixed