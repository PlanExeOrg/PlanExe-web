### 1. Project Steering Committee

**Rationale for Inclusion:** Necessary due to the $250M budget and strategic tension between local welfare and global exports; provides high-level direction for the five critical levers identified in the strategy plan.

**Responsibilities:**

- Approve strategic milestones and budget allocations above defined thresholds
- Oversight of high-impact risks including regulatory and financial exposure
- Final decision on Strategic Levers such as Market Prioritization and Capital Allocation

**Initial Setup Actions:**

- Finalize Charter and Terms of Reference
- Appoint Chair and Independent External Member
- Confirm meeting schedule aligned with green bond issuance timeline

**Membership:**

- Executive Sponsor (CEO)
- Chief Financial Officer
- Delhi Jal Shakti Representative
- Independent External Member (Infrastructure Finance)

**Decision Rights:** Decisions on budget allocations exceeding $5M USD, strategic pivot approvals, and formal approval of production capacity ramp-up strategies.

**Decision Mechanism:** Majority vote required; Chair holds casting vote in case of tie to ensure timely resolution.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Quarterly Financial Performance vs Green Bond Targets
- Approval of Strategic Levers
- Review of High-Severity Risk Register
- Regulatory Milestone Status

**Escalation Path:** Board of Directors or Ministry of Jal Shakti for conflicts exceeding internal authority or major policy deviations.
### 2. Core Program Office (PMO)

**Rationale for Inclusion:** Essential for managing day-to-day execution of the modular manufacturing hub operations, ensuring alignment with the pragmatic foundation strategy and operational stability.

**Responsibilities:**

- Day-to-day project execution and schedule management
- Operational risk monitoring and mitigation coordination
- Financial reporting below strategic thresholds

**Initial Setup Actions:**

- Establish cloud-based ERP system by Month 6
- Define operational KPIs for defect rates and community sentiment
- Set up vendor management protocols for industrial park partners

**Membership:**

- Program Director
- Operations Lead
- Finance Operations Lead
- Legal and Compliance Operations Lead

**Decision Rights:** Decisions on operational expenditures under $5M USD, routine vendor contracts, and internal process adjustments.

**Decision Mechanism:** Consensus among leads; Program Director acts as final decider for operational deadlocks.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Production Line Status Reports
- Budget Burn Rate Review
- Partner Performance Metrics
- Operational Risk Log Update

**Escalation Path:** Project Steering Committee for budget overruns exceeding operational thresholds or unresolved technical conflicts.
### 3. Technical Advisory Group (TAG)

**Rationale for Inclusion:** Required to ensure quality assurance and technical integrity given the novel AWP technology and risks associated with shared industrial park assembly lines.

**Responsibilities:**

- Define and approve technical specifications and defect rate thresholds
- Validate pilot testing protocols and production ramp-up standards
- Assess technical feasibility of modular designs

**Initial Setup Actions:**

- Set 2% defect rate threshold for production halt
- Define QA protocols for partner industrial park lines
- Select external experts for technology review

**Membership:**

- Chief Technical Engineer
- External Water Technology Expert
- Quality Assurance Lead
- Supply Chain Technical Lead

**Decision Rights:** Technical authority to halt production based on defect metrics, approval of design changes for modular standardization.

**Decision Mechanism:** Technical consensus required; External Expert holds veto on safety and compliance specifications.

**Meeting Cadence:** Bi-weekly during pilot phases; Monthly during steady-state production

**Typical Agenda Items:**

- Pilot Batch Quality Reports
- Membrane Component Performance Analysis
- Design Flexibility vs Standardization Review
- Technical Audit Findings

**Escalation Path:** Core Program Office for operational scheduling impacts; Project Steering Committee for major design changes affecting costs or timelines.
### 4. Ethics, Compliance & Risk Committee (ECRC)

**Rationale for Inclusion:** Vital to mitigate high-severity corruption and misallocation risks identified in audit files while ensuring adherence to DPCC regulations and community acceptance frameworks.

**Responsibilities:**

- Oversight of anti-corruption protocols and audit reviews
- Monitor environmental permit status and community acceptance metrics
- Manage whistleblower mechanisms and contract due diligence

**Initial Setup Actions:**

- Publish Whistleblower policy and reporting channels
- Establish formal liaison with Delhi Pollution Control Committee
- Design internal audit schedule for fund disbursement

**Membership:**

- Chief Compliance Officer
- External Independent Auditor
- Community Engagement Representative
- Legal Advisor

**Decision Rights:** Authority to approve vendor contracts for critical components, halt activities violating compliance standards, or mandate independent investigations.

**Decision Mechanism:** Majority vote with External Auditor having binding vote on audit findings.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Permit Clearance Status Updates
- Review of Community Survey Sentiment
- Audit Reports on Green Bond Fund Allocation
- Vendor Due Diligence Outcomes

**Escalation Path:** Project Steering Committee for policy violations requiring strategic review; Board for criminal or regulatory compliance breaches.