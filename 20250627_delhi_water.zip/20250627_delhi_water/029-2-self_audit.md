Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on engineering and economics, not on breaking any laws of physics. The project aims to establish Delhi as a global hub for advanced water purification, balancing environmental impact with business viability.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product, market, tech/process, and policy without independent evidence at comparable scale. The plan aims to transform Delhi into a world-leading exporter of advanced, modular water purification solutions.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Owner / Deliverable / Date: Project Manager / Validation Report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions of key strategic concepts like "water-positive solutions", a business-level mechanism-of-action, an owner, and measurable outcomes. The goal statement mentions "water-positive solutions" without defining what that means in practice.

**Mitigation**: Project Manager: Produce one-pagers defining "water-positive solutions" with value hypotheses, success metrics, and decision hooks. Due: Within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits legal, safety, and reputational risks. The plan mentions 'Ethical Considerations' but lacks a comprehensive risk register or cascade analysis. There is no mention of safety protocols or legal compliance beyond permits.

**Mitigation**: Risk Management Specialist: Expand the risk register to include legal, safety, and reputational risks, map risk cascades, and add controls with a review cadence. Due: Within 90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Environmental clearances, Construction permits, Delhi Jal Board approvals, Export licenses" but lacks a timeline or responsible party.

**Mitigation**: Regulatory Compliance Officer: Create a permit/approval matrix with lead times, predecessors, and owners. Due: Within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions funding of $250 million but lacks details on sources, draw schedule, and covenants. There is no dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates.

**Mitigation**: Financial Analyst: Develop a detailed financing plan listing funding sources, status (e.g., LOI, term sheet), draw schedule, and covenants. Due: Within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $250 million lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions "funding of $250 million" but provides no cost breakdown or justification.

**Mitigation**: Financial Analyst: Obtain ≥3 vendor quotes for hub/plant construction, normalize by area (cost per m²/ft²), and adjust budget or de-scope. Due: Within 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., export sales volume) as single numbers without providing a range or discussing alternative scenarios. The plan states "Achieving significant export sales of AWP solutions" without quantifying "significant" or providing a range.

**Mitigation**: Export Market Development Manager: Conduct a sensitivity analysis for export sales projections, including best-case, worst-case, and base-case scenarios. Due: Within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts. The plan mentions "AWP Technology and Equipment" but lacks technical specifications, interface contracts, acceptance tests, integration plans, and non-functional requirements for build-critical components.

**Mitigation**: Head of Engineering: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: Within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states that the project will "secure carbon credits" without providing evidence of eligibility or agreements.

**Mitigation**: Financial Analyst: Obtain preliminary documentation confirming eligibility for carbon credits and projected revenue. Due: Within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because it impacts supply chain, plant siting, and technology selection. It governs the trade-off between rapid deployment and capital efficiency, influencing scalability and adaptability, key to the project's export goals.

**Mitigation**: Project Manager: Define SMART acceptance criteria for 'AWP System Modularity', including a KPI for deployment time (e.g., reduce deployment time by 20% compared to traditional systems). Due: Within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Yamuna River Restoration Initiatives' without a clear benefit case. It does not appear to directly support the core project goals of establishing a manufacturing hub and exporting AWP solutions.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Yamuna River Restoration Initiatives', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: Within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the need for AWP Plant Engineers but lacks a rationale for how to attract/retain this unicorn role. The plan mentions 'AWP Plant Engineers' as primary stakeholders but doesn't address the difficulty of finding qualified engineers.

**Mitigation**: HR: Conduct a talent market analysis for AWP Plant Engineers, including salary benchmarks, skill availability, and competitor hiring practices. Due: Within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix (authority, artifact, lead time, predecessors) for export markets. The plan mentions "Export licenses" but lacks specifics on requirements and timelines.

**Mitigation**: Regulatory Compliance Officer: Develop a regulatory matrix for target export markets, including authority, artifact, lead time, and predecessors. Due: Within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a long-term operational sustainability plan. The plan mentions 'Financial Sustainability Model' but lacks details on long-term maintenance, personnel succession, and technology roadmaps.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Due: Within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions zoning but lacks evidence of a fatal-flaw screen with authorities. The plan mentions "site with favorable zoning" but does not include written confirmation or a NO-GO threshold.

**Mitigation**: Real Estate Team: Conduct a fatal-flaw screen with Delhi zoning authorities to confirm site viability. Due: Within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions supply chain, plant siting, and technology selection but lacks evidence of tested failovers or secondary suppliers. The plan mentions "Diversify supply chain, strategic partnerships, buffer stock" but lacks details on testing.

**Mitigation**: Supply Chain and Logistics Manager: Secure SLAs with key vendors, add a secondary supplier/path for critical components, and test failover by Q4 2025.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the project involves conflicting incentives between Finance, focused on budget adherence, and R&D, driven by long-term innovation, potentially hindering experimental spending.

**Mitigation**: Project Manager: Create a shared OKR that aligns Finance and R&D on a common goal, ensuring both budget adherence and innovation are prioritized. Due: Within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds. Due: Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks strongly coupled. AWP Technology Selection impacts AWP Operational Cost Structure and Financial Sustainability Model. Failure in one cascades to the others, jeopardizing the project's viability.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: Within 90 days.