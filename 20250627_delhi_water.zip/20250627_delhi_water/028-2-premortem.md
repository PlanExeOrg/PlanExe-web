A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | High-value export markets will readily adopt AWP solutions without significant customization. | Conduct detailed interviews with potential clients in target high-value markets to assess their specific needs and willingness to adopt standardized AWP systems. | If potential clients express a strong need for highly customized solutions or indicate a preference for established competitors, the assumption is false. |
| A2 | Local suppliers can consistently provide AWP components meeting international quality standards at a competitive cost. | Issue detailed RFQs to a representative sample of local suppliers, including stringent quality specifications and delivery timelines, and assess their responses. | If a significant portion of local suppliers fail to meet the quality specifications or provide uncompetitive pricing, the assumption is false. |
| A3 | The carbon credit market will remain stable and provide a reliable revenue stream for the project. | Consult with carbon credit market experts to assess the current market trends, regulatory changes, and potential risks associated with carbon credit pricing and validation. | If experts predict significant market volatility or regulatory changes that could negatively impact carbon credit revenue, the assumption is false. |
| A4 | The local workforce will readily acquire the specialized skills required for AWP plant operation and maintenance with the provided training programs. | Conduct a pre-training assessment of a representative sample of the local workforce to gauge their existing skill levels and aptitude for technical training. | If the assessment reveals a significant gap between existing skills and required competencies, or a low aptitude for technical training, the assumption is false. |
| A5 | The existing infrastructure in Delhi (roads, power grid, water distribution network) is adequate to support the construction and operation of the AWP plants and manufacturing hub without significant upgrades. | Conduct a thorough assessment of the existing infrastructure in the planned locations for the AWP plants and manufacturing hub, including capacity, reliability, and potential bottlenecks. | If the assessment reveals significant infrastructure limitations or the need for costly upgrades, the assumption is false. |
| A6 | Local communities will not experience significant disruptions (noise, traffic, odor) during the construction and operation of the AWP plants and manufacturing hub. | Conduct a detailed environmental impact assessment (EIA) that specifically focuses on potential disruptions to local communities, including noise, traffic, and odor, and solicit feedback from residents. | If the EIA predicts significant disruptions or residents express strong concerns about potential impacts, the assumption is false. |
| A7 | The chosen AWP technology will be easily adaptable to treat a wide range of emerging contaminants in Delhi's wastewater without significant modifications or cost increases. | Conduct a comprehensive analysis of Delhi's wastewater to identify potential emerging contaminants (pharmaceuticals, microplastics, industrial chemicals) and assess the AWP technology's ability to remove them. | If the analysis reveals that the AWP technology is ineffective against a significant number of emerging contaminants or requires costly modifications to address them, the assumption is false. |
| A8 | The Delhi Jal Board (DJB) will consistently adhere to the agreed-upon wastewater supply terms (volume, quality, pressure) throughout the project's lifespan. | Obtain a legally binding agreement with the DJB that includes specific performance guarantees for wastewater supply and penalties for non-compliance. | If the DJB is unwilling to provide such guarantees or expresses concerns about their ability to consistently meet the agreed-upon terms, the assumption is false. |
| A9 | The project will be able to secure sufficient insurance coverage (political risk, environmental liability, business interruption) at reasonable premiums to mitigate potential unforeseen events. | Obtain quotes from multiple insurance providers for comprehensive coverage, including political risk, environmental liability, and business interruption, and assess the affordability and scope of coverage. | If insurance premiums are prohibitively high or the available coverage is inadequate to protect against potential risks, the assumption is false. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Carbon Credit Collapse | Process/Financial | A3 | Financial Analyst | CRITICAL (20/25) |
| FM2 | The Localization Logjam | Technical/Logistical | A2 | Supply Chain and Logistics Manager | HIGH (12/25) |
| FM3 | The Export Echo Chamber | Market/Human | A1 | Export Market Development Manager | HIGH (12/25) |
| FM4 | The Skills Shortfall Spiral | Process/Financial | A4 | Workforce Development Manager | CRITICAL (16/25) |
| FM5 | The Infrastructure Impasse | Technical/Logistical | A5 | Head of Engineering | CRITICAL (15/25) |
| FM6 | The Community Backlash | Market/Human | A6 | Community Engagement Coordinator | HIGH (12/25) |
| FM7 | The Contaminant Conundrum | Technical/Logistical | A7 | AWP Technology Specialist | CRITICAL (15/25) |
| FM8 | The Feedstock Fiasco | Process/Financial | A8 | Strategic Partnerships Lead | HIGH (12/25) |
| FM9 | The Uninsurable Catastrophe | Market/Human | A9 | Financial Analyst | HIGH (10/25) |


### Failure Modes

#### FM1 - The Carbon Credit Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Analyst
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model heavily relies on revenue from carbon credits. A collapse in the carbon credit market, due to regulatory changes or decreased demand, would severely impact the project's financial viability. This could lead to budget cuts, reduced operational capacity, and ultimately, project failure. Contributing factors include: 
* Over-reliance on a single revenue stream.
* Lack of diversification in financial models.
* Failure to anticipate market volatility.
* Inadequate risk mitigation strategies.

##### Early Warning Signs
- Carbon credit prices drop below $10/ton for 3 consecutive months.
- Key regulatory bodies announce plans to restrict or eliminate carbon credit programs.
- Investor confidence in the carbon credit market declines significantly, as indicated by market indices.

##### Tripwires
- Carbon credit price <= $8/ton
- Government announces phase-out of carbon credit program
- Projected carbon credit revenue falls below 75% of initial projections

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a thorough review of the financial model and identify alternative revenue streams.
- Respond: Implement a revised financial plan that reduces reliance on carbon credits and explores alternative funding sources.


**STOP RULE:** Alternative revenue streams cannot replace at least 50% of projected carbon credit revenue within 6 months.

---

#### FM2 - The Localization Logjam

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Supply Chain and Logistics Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's supply chain localization strategy aims to boost the local economy and reduce transportation costs. However, if local suppliers fail to meet quality standards or lack the capacity to deliver components on time, the manufacturing hub will face significant delays and increased costs. This could lead to a backlog in AWP plant production, jeopardizing export targets and damaging the project's reputation. Contributing factors include:
* Overestimation of local supplier capabilities.
* Inadequate quality control processes.
* Lack of contingency plans for supplier failures.
* Insufficient investment in supplier development.

##### Early Warning Signs
- Rejection rate of locally sourced components exceeds 10%.
- Delivery delays from local suppliers increase by more than 30 days.
- Local suppliers request price increases exceeding 15% due to unforeseen costs.

##### Tripwires
- Component rejection rate >= 15%
- Average delivery delay from local suppliers >= 45 days
- Local supplier price increase requests >= 20%

##### Response Playbook
- Contain: Immediately halt further localization efforts and revert to established international suppliers.
- Assess: Conduct a thorough audit of local supplier capabilities and identify areas for improvement.
- Respond: Implement a revised supply chain strategy that balances local sourcing with international partnerships and invests in supplier development programs.


**STOP RULE:** Local suppliers are unable to meet minimum quality standards (as defined by international benchmarks) for critical AWP components after 12 months of development efforts.

---

#### FM3 - The Export Echo Chamber

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Export Market Development Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project's export market entry strategy focuses on high-value markets, assuming they will readily adopt standardized AWP solutions. However, if these markets demand highly customized systems or prefer established competitors, the project will struggle to gain traction. This could lead to reduced export sales, underutilization of the manufacturing hub, and financial losses. Contributing factors include:
* Insufficient market research.
* Failure to understand local needs and preferences.
* Inadequate marketing and sales efforts.
* Overestimation of the project's competitive advantage.

##### Early Warning Signs
- Initial sales leads in target markets fail to convert into contracts.
- Potential clients express concerns about the lack of customization options.
- Competitors launch aggressive marketing campaigns targeting the same markets.

##### Tripwires
- Conversion rate of sales leads <= 5% after 6 months in target market
- Client feedback indicates customization is a major barrier to adoption in >= 50% of cases
- Competitor market share in target markets >= 60%

##### Response Playbook
- Contain: Immediately re-evaluate the export market entry strategy and halt further expansion efforts.
- Assess: Conduct a thorough market analysis to understand local needs and preferences and identify potential customization options.
- Respond: Implement a revised marketing and sales strategy that emphasizes the benefits of standardized AWP solutions and addresses concerns about customization.


**STOP RULE:** The project fails to secure any significant export contracts (>$10 million) in high-value markets after 18 months of active marketing efforts.

---

#### FM4 - The Skills Shortfall Spiral

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Workforce Development Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes the local workforce can be trained to operate and maintain the AWP plants. If the training programs are ineffective or the local workforce lacks the aptitude, the plants will be understaffed with qualified personnel. This leads to operational inefficiencies, increased maintenance costs due to improper handling, and potential safety incidents. The project then faces a choice: hire expensive external experts, further straining the budget, or operate with a poorly trained workforce, risking plant damage and reduced output. Contributing factors include:
* Overly optimistic assessment of local workforce capabilities.
* Inadequate training program design.
* Lack of ongoing mentorship and support.
* High employee turnover due to lack of career advancement opportunities.

##### Early Warning Signs
- Training completion rates fall below 70%.
- AWP plant downtime increases due to operator error.
- Employee turnover rate exceeds 20% within the first year of operation.

##### Tripwires
- Training completion rate <= 65%
- AWP plant downtime due to operator error >= 15%
- Employee turnover rate >= 25%

##### Response Playbook
- Contain: Immediately implement a remedial training program for underperforming employees.
- Assess: Conduct a thorough review of the training program curriculum and identify areas for improvement.
- Respond: Revise the training program to address identified skill gaps and provide ongoing mentorship and support.


**STOP RULE:** The project is unable to achieve a minimum staffing level of qualified operators and maintenance personnel after 18 months of training efforts.

---

#### FM5 - The Infrastructure Impasse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes existing infrastructure is sufficient. If it's not, the project faces costly and time-consuming upgrades. For example, the power grid might be unreliable, causing frequent plant shutdowns. Roads might be inadequate for transporting large AWP components, leading to delays and increased transportation costs. The water distribution network might lack the capacity to handle the purified water, requiring expensive pipeline construction. These logistical bottlenecks delay plant deployment and increase capital expenditure, jeopardizing the project's financial viability. Contributing factors include:
* Insufficient due diligence on existing infrastructure.
* Failure to anticipate future infrastructure demands.
* Lack of coordination with relevant government agencies.
* Underestimation of upgrade costs.

##### Early Warning Signs
- Frequent power outages at AWP plant sites.
- Transportation delays due to inadequate road infrastructure.
- Water pressure in the distribution network drops significantly after AWP plant connection.

##### Tripwires
- Average power outage duration >= 4 hours/week
- Transportation delays due to road conditions >= 7 days/shipment
- Water pressure drop in distribution network >= 20%

##### Response Playbook
- Contain: Immediately implement backup power generators and explore alternative transportation routes.
- Assess: Conduct a detailed assessment of infrastructure limitations and develop a prioritized upgrade plan.
- Respond: Negotiate agreements with relevant government agencies to expedite infrastructure upgrades and secure funding.


**STOP RULE:** Required infrastructure upgrades exceed 20% of the total project budget.

---

#### FM6 - The Community Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Community Engagement Coordinator
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes minimal community disruption. However, construction noise, increased traffic, or unpleasant odors from the AWP plants can trigger significant public opposition. This leads to protests, legal challenges, and delays in plant construction and operation. Negative publicity damages the project's reputation and reduces public acceptance of recycled water, hindering the project's long-term sustainability. Contributing factors include:
* Inadequate community engagement.
* Failure to address community concerns proactively.
* Lack of transparency about potential impacts.
* Underestimation of community sensitivity to environmental disruptions.

##### Early Warning Signs
- Increased complaints from local residents about noise, traffic, or odor.
- Formation of community opposition groups.
- Negative media coverage of the project's potential impacts.

##### Tripwires
- Number of community complaints >= 50/month
- Active participation in opposition groups >= 10% of local residents
- Negative media articles >= 3/month

##### Response Playbook
- Contain: Immediately implement noise reduction measures, traffic management plans, and odor control systems.
- Assess: Conduct a thorough community survey to understand the specific concerns and develop targeted mitigation strategies.
- Respond: Implement a revised community engagement plan that emphasizes transparency, responsiveness, and community benefits.


**STOP RULE:** The project faces a legal injunction preventing AWP plant construction or operation due to community opposition.

---

#### FM7 - The Contaminant Conundrum

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: AWP Technology Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project assumes the AWP technology can handle emerging contaminants. However, Delhi's wastewater may contain unforeseen pollutants that the chosen technology struggles to remove. This leads to treated water failing to meet quality standards, damaging public trust and hindering export prospects. Retrofitting the plants with new technologies is costly and time-consuming, delaying project timelines and straining the budget. Contributing factors include:
* Incomplete wastewater characterization.
* Overreliance on vendor claims about technology capabilities.
* Lack of flexibility in the AWP system design.
* Failure to anticipate future pollution trends.

##### Early Warning Signs
- Treated water fails to meet quality standards for specific emerging contaminants.
- Pilot testing reveals reduced contaminant removal rates compared to vendor specifications.
- New regulations are introduced requiring the removal of previously unregulated contaminants.

##### Tripwires
- Treated water contaminant levels >= regulatory limits for >= 2 emerging contaminants
- Contaminant removal rates during pilot testing <= 80% of vendor specifications for >= 3 emerging contaminants
- New regulations mandate removal of previously unregulated contaminants with a compliance deadline < 12 months

##### Response Playbook
- Contain: Immediately implement temporary measures to address the contaminant issue, such as blending treated water with cleaner sources or using activated carbon filtration.
- Assess: Conduct a thorough analysis of the emerging contaminants and evaluate potential technology upgrades.
- Respond: Secure funding for technology upgrades and implement a revised treatment process to address the contaminant issue.


**STOP RULE:** The project is unable to meet water quality standards for critical emerging contaminants after 12 months of technology upgrade efforts.

---

#### FM8 - The Feedstock Fiasco

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Strategic Partnerships Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project relies on a consistent wastewater supply from the DJB. If the DJB fails to meet its obligations due to infrastructure failures, droughts, or policy changes, the AWP plants will operate below capacity, reducing revenue and jeopardizing financial sustainability. The project may face penalties for failing to meet export commitments, further straining the budget. Contributing factors include:
* Overdependence on a single wastewater source.
* Lack of contractual safeguards.
* Inadequate monitoring of DJB performance.
* Failure to anticipate potential disruptions to the wastewater supply.

##### Early Warning Signs
- The DJB announces water rationing measures due to drought conditions.
- Wastewater flow rates to the AWP plants decrease significantly.
- The DJB fails to provide timely maintenance updates on its infrastructure.

##### Tripwires
- Wastewater flow rate to AWP plants <= 75% of agreed-upon levels for >= 3 consecutive months
- DJB announces water rationing measures affecting AWP plant feedstock supply
- DJB fails to provide scheduled maintenance updates for >= 2 consecutive quarters

##### Response Playbook
- Contain: Immediately explore alternative wastewater sources, such as industrial facilities or other municipal treatment plants.
- Assess: Conduct a thorough review of the wastewater supply agreement and identify potential legal remedies.
- Respond: Negotiate a revised agreement with the DJB that includes stronger performance guarantees and penalties for non-compliance.


**STOP RULE:** The project is unable to secure a reliable wastewater supply (>= 80% of agreed-upon levels) from alternative sources after 6 months of DJB non-compliance.

---

#### FM9 - The Uninsurable Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Financial Analyst
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project assumes sufficient insurance coverage can be secured. However, unforeseen events like political instability in export markets, major environmental accidents, or widespread business interruption due to unforeseen circumstances (pandemics, major cyberattacks) could occur. If adequate insurance is unavailable or prohibitively expensive, the project faces significant financial losses and reputational damage. This deters investors and jeopardizes long-term sustainability. Contributing factors include:
* Underestimation of potential risks.
* Failure to conduct thorough insurance market research.
* Inadequate risk mitigation planning.
* Overreliance on standard insurance policies.

##### Early Warning Signs
- Insurance providers decline to offer coverage for specific risks (political risk, environmental liability).
- Insurance premiums increase significantly due to heightened risk perceptions.
- Major unforeseen events occur in similar projects or industries, raising concerns about insurability.

##### Tripwires
- Insurance providers decline coverage for >= 2 key risk areas (political risk, environmental liability, business interruption)
- Insurance premiums increase by >= 50% compared to initial estimates
- A major unforeseen event occurs in a similar project or industry, leading to widespread insurance coverage cancellations

##### Response Playbook
- Contain: Immediately implement enhanced risk mitigation measures to reduce the likelihood of insurable events.
- Assess: Conduct a thorough review of the insurance market and explore alternative coverage options, such as captive insurance or government-backed guarantees.
- Respond: Revise the project's financial model to account for the increased cost of insurance or the potential lack of coverage.


**STOP RULE:** The project is unable to secure adequate insurance coverage for critical risks (political risk, environmental liability, business interruption) after 6 months of market exploration.
