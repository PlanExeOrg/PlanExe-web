## Primary Decisions
The vital few decisions that have the most impact.


The prioritized levers address core tensions between Speed versus Scalability and Local versus Global Focus. High impacts levers manage the financial viability and market entry strategy, ensuring the project balances immediate humanitarian needs with sustainable economic growth through controlled production scaling and capital allocation.

### Decision 1: Production Capacity Ramp-up Pace
**Lever ID:** `41b6d7e7-0784-4836-b89e-dc6f8b4d9907`

**The Core Decision:** This lever determines the speed at which the manufacturing hub scales output to meet demand. Success depends on balancing rapid deployment with quality assurance metrics. It directly influences cash flow timing and the ability to fulfill export contracts without compromising the modular standardization required for global replication.

**Why It Matters:** Accelerating output reduces time-to-market for global clients but risks quality control failures during initial runs. Slower scaling ensures reliability but delays revenue generation and might miss early market windows.

**Strategic Choices:**

1. Deploy phased production lines that prioritize mastering core modules before adding full assembly capacity to ensure defect rates stay low.
2. Establish a single high-volume factory from day one to capture economies of scale quickly while accepting higher initial capital risk.
3. Partner with existing industrial parks to utilize idle assembly lines immediately, reducing setup time but sharing control over quality protocols.

**Trade-Off / Risk:** Phased deployment reduces quality risk but delays revenue, while single-factory scaling accelerates income but increases upfront capital exposure significantly.

**Strategic Connections:**

**Synergy:** Enables Market Prioritization Balance by ensuring sufficient supply for chosen markets. Supports Modular Standardization Level by forcing early definition of repeatable processes.

**Conflict:** Trades off against Capital Allocation Mix due to high upfront investment needs. Risks quality issues that conflict with Environmental Permitting Strategy if defects cause pollution.

**Justification:** *Critical*, Central lever balancing speed against quality risks. Controls cash flow timing and fulfillment capability for export contracts, creating fundamental tension with capital needs and regulatory compliance requirements across the program.

### Decision 2: Intellectual Property Strategy
**Lever ID:** `0e576117-14b3-4d9d-a075-a96546cd7954`

**The Core Decision:** Defines how proprietary technology is protected versus shared to drive adoption. Metrics include licensing revenue and adoption rates across regions. This choice shapes long-term revenue streams and determines whether the project becomes a standard setter or a niche provider in the global water tech sector.

**Why It Matters:** Keeping patents proprietary protects margins but limits adoption speed in price-sensitive markets. Open standards encourage widespread use but erode competitive advantage and long-term licensing revenue.

**Strategic Choices:**

1. Maintain strict patent protection on core filtration membranes to maximize licensing fees from international partners seeking proven technology.
2. Release non-core system designs as open source to accelerate global adoption while monetizing only the proprietary consumables and maintenance services.
3. Create a tiered licensing framework that offers free basic schematics to developing nations while charging premium fees for advanced automation modules.

**Trade-Off / Risk:** Strict IP protects margins but slows adoption, whereas open sourcing accelerates deployment but risks commoditizing the core technology and eroding licensing revenue streams.

**Strategic Connections:**

**Synergy:** Amplifies Technology Licensing Model by defining terms of access. Supports Export Market Compliance Adaptation by aligning IP with regional regulatory expectations.

**Conflict:** Conflicts with Component Sourcing Strategy if proprietary parts limit supplier options. Tension with Market Prioritization Balance if open standards reduce pricing power in premium markets.

**Justification:** *High*, Sets long-term revenue models and adoption speed. Balances competitive advantage against widespread standardization, directly influencing licensing options and sourcing choices for proprietary components within the export strategy.

### Decision 3: Market Prioritization Balance
**Lever ID:** `c1d710fe-e15f-4018-8e8a-f75bb3480511`

**The Core Decision:** Determines the focus between local Delhi deployment and international exports. Success metrics involve local water access improvements versus foreign revenue targets. This lever dictates resource allocation priorities and influences political support, ensuring the project meets immediate humanitarian needs while building economic sustainability through global sales.

**Why It Matters:** Focusing on Delhi first builds local trust but delays global expansion. Prioritizing export markets generates foreign revenue but risks neglecting local regulatory requirements and community needs.

**Strategic Choices:**

1. Prioritize full deployment within Delhi municipalities first to validate system performance locally before scaling operations to international export markets.
2. Design plants for global export standards from the start to capture international contracts while using Delhi as a secondary pilot demonstration site.
3. Split production capacity equally between local fulfillment and export orders to balance community impact with foreign revenue generation targets simultaneously.

**Trade-Off / Risk:** Local-first validation builds trust but delays global revenue, while export-first strategies capture foreign contracts but risk failing local regulatory compliance requirements.

**Strategic Connections:**

**Synergy:** Enables Export Market Compliance Adaptation by defining target regulatory environments. Supports Community Acceptance Framework by prioritizing local impact first.

**Conflict:** Conflicts with Production Capacity Ramp-up Pace if dual focus strains output. Tension with Capital Allocation Mix if export revenue expectations misalign with public funding goals.

**Justification:** *Critical*, Governs the primary strategic tension between local Delhi impact and global revenue. Decisions here dictate resource allocation, political support, and the feasibility of export compliance adaptation efforts.

### Decision 4: Capital Allocation Mix
**Lever ID:** `b3057e0c-e88d-4866-903d-87c40b39fa7a`

**The Core Decision:** Dictates the funding sources used to finance hub construction and operations. Metrics include cost of capital and strategic alignment with public goals. This lever balances financial risk against operational autonomy, influencing long-term decision-making freedom and ensuring the project remains viable without excessive commercial pressure compromising public welfare objectives.

**Why It Matters:** Relying on sovereign funds reduces commercial pressure but adds political constraints. Private investment increases efficiency but demands faster returns that might compromise long-term public goals.

**Strategic Choices:**

1. Secure primary funding through government infrastructure grants to ensure alignment with public welfare goals without immediate profit pressure.
2. Structure the project as a public-private partnership where private investors fund manufacturing in exchange for long-term operational revenue shares.
3. Issue green bonds targeted at international development banks to lower interest costs while maintaining full public control over strategic decisions.

**Trade-Off / Risk:** Sovereign grants align with public goals but limit flexibility, while private partnerships add efficiency but demand faster returns that may compromise long-term public objectives.

**Strategic Connections:**

**Synergy:** Enables Production Capacity Ramp-up Pace by providing necessary upfront liquidity. Supports Market Prioritization Balance by funding local infrastructure without immediate profit pressure.

**Conflict:** Conflicts with Intellectual Property Strategy if investors demand proprietary control. Tension with Export Market Compliance Adaptation if funding sources restrict market choices.

**Justification:** *Critical*, Defines funding structure for the $250M program, balancing public welfare with commercial viability. It dictates financial autonomy and directly impacts capacity planning and market prioritization decisions.

### Decision 5: Modular Standardization Level
**Lever ID:** `e11214f6-9090-47b1-b684-47d9e22dff0a`

**The Core Decision:** Determines the degree of fixed versus flexible design in plants. Success balances mass production efficiency with site-specific adaptability. Fixed units maximize speed but limit fit, while adjustable modules enhance versatility but reduce assembly velocity and risk quality inconsistencies during deployment phases.

**Why It Matters:** Fixed containers enable mass production but limit site adaptability. Field adjustments increase flexibility but reduce assembly speed and quality control. Interchangeable stages balance standardization with customization needs.

**Strategic Choices:**

1. Design fixed-size shipping containers for rapid deployment and mass production scaling
2. Allow field adjustments for site-specific constraints during installation and commissioning phases
3. Create a core module with interchangeable treatment stages for flexible configuration

**Trade-Off / Risk:** Fixed containers maximize production speed but limit site adaptability, while field adjustments improve fit but compromise assembly speed and introduce quality control inconsistencies across projects.

**Strategic Connections:**

**Synergy:** Enables Production Capacity Ramp-up Pace through streamlined assembly. Supports Component Sourcing Strategy by defining part uniformity needs.

**Conflict:** Conflicts with Export Market Compliance Adaptation if rigid designs fail local rules. Trades off against Community Acceptance Framework if inflexible siting ignores local constraints.

**Justification:** *Critical*, Core architectural choice enabling mass production and exportability. Directly controls trade-offs between design flexibility and assembly speed, impacting almost every downstream lever from sourcing to maintenance.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Environmental Permitting Strategy
**Lever ID:** `f637c553-8bb4-4f7b-9665-e24b8c31bf78`

**The Core Decision:** Governs how regulatory approvals are secured to minimize project delays. Success is measured by timeline adherence and compliance stability. This lever mitigates legal risk and ensures operational continuity, directly impacting the timeline for full-scale production and the credibility of the hub as a sustainable infrastructure partner.

**Why It Matters:** Securing all permits upfront prevents delays but requires extensive upfront legal work. Proceeding with provisional permits allows faster start but risks shutdowns if standards change mid-project.

**Strategic Choices:**

1. Secure comprehensive environmental clearances for all five years of operation before breaking ground to prevent future regulatory interruptions.
2. Begin construction under provisional permits while simultaneously negotiating final approvals to reduce initial delay while managing legal exposure.
3. Align design standards with international ISO water quality benchmarks exceeding local requirements to pre-empt stricter future regulations.

**Trade-Off / Risk:** Full upfront clearance prevents delays but increases initial costs, while provisional permitting speeds start but risks costly shutdowns if standards shift.

**Strategic Connections:**

**Synergy:** Supports Modular Standardization Level by ensuring designs meet strict codes early. Enables Capital Allocation Mix by reducing risk premiums for investors.

**Conflict:** Conflicts with Production Capacity Ramp-up Pace if approvals delay factory start. Tension with Component Sourcing Strategy if strict standards limit material choices.

**Justification:** *High*, Mitigates legal and operational risk ensuring continuity. Conflicts with start-up speed and sourcing options if strict standards limit material choices or timelines.

### Decision 7: Component Sourcing Strategy
**Lever ID:** `338acb34-c7a7-4365-ad56-a9d183fb6c3c`

**The Core Decision:** Determines where critical filtration parts originate, balancing cost against performance. Success hinges on securing reliable supply chains without compromising purification efficacy. Local options lower logistics expenses, while global imports ensure quality but introduce currency volatility and longer delivery timelines for the hub.

**Why It Matters:** Sourcing locally reduces logistics costs but limits technical capability. Global sourcing accesses best-in-class parts but increases lead times and currency risk.

**Strategic Choices:**

1. Source membrane components locally to reduce logistics costs and support regional suppliers despite potential limitations in technical specifications.
2. Import high-performance filtration modules from established global vendors to ensure reliability while managing longer lead times and currency fluctuations.
3. Develop dual-sourcing agreements for critical parts to balance cost efficiency with supply continuity during geopolitical or logistical disruptions.

**Trade-Off / Risk:** Local sourcing cuts costs but limits quality, while global imports ensure reliability but increase lead times and expose the project to currency volatility.

**Strategic Connections:**

**Synergy:** Enables Production Capacity Ramp-up Pace by ensuring timely part availability. Supports Modular Standardization Level by providing consistent component specs across units.

**Conflict:** Conflicts with Capital Allocation Mix if high-cost imports strain budgets. Trades off against Local Workforce Training Pipeline if advanced imports require specialized skills locals lack.

**Justification:** *Medium*, Balances cost versus performance for filtration parts. While vital for operations, it depends on standardization definitions and capital constraints rather than defining core strategic direction.

### Decision 8: Technology Licensing Model
**Lever ID:** `7cbc0dcf-0341-4b81-a7a4-1d47bd493fe6`

**The Core Decision:** Defines how AWP designs are disseminated globally, affecting revenue streams and quality control. Success depends on selecting partners capable of maintaining standards. Licensing expands reach quickly, while direct operation secures margins but demands significant operational overhead and management resources for plant execution.

**Why It Matters:** Licensing shifts manufacturing burden to partners but reduces direct margin control. Centralized shipping ensures quality but increases logistics costs and lead times. Direct operation secures long-term revenue but requires significant operational overhead.

**Strategic Choices:**

1. License AWP system designs to local firms for final assembly and subsequent regional distribution
2. Manufacture complete standardized units centrally and ship them globally to end customers
3. Partner with municipal utilities to operate plants directly and sell water services

**Trade-Off / Risk:** Licensing expands reach without capital outlay but risks quality degradation if partners lack training, whereas direct operation secures standards but limits scale due to resource constraints.

**Strategic Connections:**

**Synergy:** Amplifies Market Prioritization Balance by allowing flexible entry into varied regions. Supports Export Market Compliance Adaptation through localized partner adaptation.

**Conflict:** Conflicts with Production Capacity Ramp-up Pace if partner training slows output. Trades off against Intellectual Property Strategy if sensitive tech is shared broadly.

**Justification:** *High*, Determines global dissemination methods versus direct operations. Amplifies market prioritization decisions and shapes licensing revenue potential while affecting partner training and quality control burdens.

### Decision 9: Feedstock Integration Depth
**Lever ID:** `40d3ec88-5ec8-466e-89d4-53eb3d2e0d96`

**The Core Decision:** Dictates water intake sources, influencing treatment complexity and regulatory exposure. Success requires securing consistent inflow volumes while managing contaminant variability. Direct sewer access ensures volume but locks into permits, whereas surface options offer flexibility but increase energy demands for purification processes.

**Why It Matters:** Direct sewer access ensures consistent volume but requires complex regulatory agreements. Industrial effluent reduces preprocessing needs but introduces variable contaminant profiles. Surface water units simplify permitting but face higher seasonal variability and treatment loads.

**Strategic Choices:**

1. Connect directly to municipal sewer lines for raw wastewater inflow and processing
2. Source pretreated industrial effluent from nearby industrial zones for treatment input
3. Deploy standalone units drawing from surface water sources without municipal infrastructure connections

**Trade-Off / Risk:** Direct sewer connection guarantees feedstock volume but introduces long-term regulatory lock-in, while surface water units offer flexibility but demand higher energy inputs for consistent purification.

**Strategic Connections:**

**Synergy:** Enables Environmental Permitting Strategy by defining regulatory scope. Supports Energy Consumption Profile by determining preprocessing needs.

**Conflict:** Conflicts with Community Acceptance Framework if sewer connections raise odor concerns. Trades off against Export Market Compliance Adaptation if local feedstock standards differ from export requirements.

**Justification:** *Medium*, Dictates water intake sources and regulatory exposure. Important for technical feasibility but generally constrained by higher-level strategic choices regarding permits and community acceptance.

### Decision 10: Export Market Compliance Adaptation
**Lever ID:** `ecae5f1c-0145-4f2e-b694-cbd71b8ab190`

**The Core Decision:** Governs how units adapt to international regulations, balancing standardization with market fit. Success involves meeting diverse safety norms without fragmenting production. Universal standards simplify manufacturing but risk over-engineering, while customization ensures compliance but increases costs and complicates the assembly line significantly.

**Why It Matters:** Universal standards simplify production but may over-engineer for weaker markets. Customization increases market fit but fragments the production line and raises costs. Single standard reduces complexity but risks rejection in regulated jurisdictions.

**Strategic Choices:**

1. Build universal plants meeting the strictest global water safety and quality standards
2. Customize units per target country's specific regulatory framework and testing requirements
3. Maintain a single Delhi manufacturing standard for all exported units regardless of market

**Trade-Off / Risk:** Universal standards streamline manufacturing but risk over-engineering for emerging markets, whereas customization improves local fit but fragments the production line and increases unit costs significantly.

**Strategic Connections:**

**Synergy:** Enables Market Prioritization Balance by aligning products with target regions. Supports Technology Licensing Model through localized specification adjustments.

**Conflict:** Conflicts with Modular Standardization Level by introducing variable configurations. Trades off against Production Capacity Ramp-up Pace due to increased assembly complexity.

**Justification:** *High*, Balances standardization with local regulatory fit. Critical for global sales success but conflicts with mass production efficiency and standardization levels needed for rapid scaling.

### Decision 11: Local Workforce Training Pipeline
**Lever ID:** `ecfdfe59-5bd9-4ca4-b3ef-62970e87b763`

**The Core Decision:** This lever determines how technical skills are developed to operate and maintain the AWP plants. It ranges from onsite academies to college partnerships. Success is measured by technician certification rates and reduced dependency on foreign experts. Investing in local talent ensures long-term operational stability and aligns with community economic goals.

**Why It Matters:** Onsite academy builds long-term capacity but requires upfront investment. College partnerships reduce training costs but may lack specificity. Foreign experts ensure speed but create dependency and higher labor costs.

**Strategic Choices:**

1. Establish an onsite academy to train Delhi technicians in plant maintenance and repair
2. Partner with existing technical colleges to create a certified workforce pipeline
3. Import foreign experts for initial operations only to ensure rapid system start-up

**Trade-Off / Risk:** Onsite academy development builds sustainable local capacity but requires heavy upfront investment, whereas importing foreign experts accelerates start-up but creates long-term dependency and higher operational costs.

**Strategic Connections:**

**Synergy:** It amplifies Maintenance Lifecycle Model by ensuring qualified local technicians handle repairs, and supports Production Capacity Ramp-up Pace by reducing recruitment delays during hub scaling.

**Conflict:** It constrains Capital Allocation Mix due to high upfront training costs, potentially reducing funds available for immediate infrastructure hardware or initial R&D expenditures.

**Justification:** *Medium*, Ensures operational stability through technical capacity. Valuable for long-term success but less central than initial capital and production planning decisions.

### Decision 12: Community Acceptance Framework
**Lever ID:** `0ece3e66-1a42-4262-b6bb-dfb0c46a1ccb`

**The Core Decision:** This lever manages public trust and social license through engagement activities like town halls and transparency dashboards. Its scope covers pre-construction outreach to ongoing accountability. Success is measured by reduced protest risks and stakeholder approval rates. Effective engagement prevents operational delays caused by local resistance to water infrastructure projects.

**Why It Matters:** Engaging local residents early builds trust but requires significant time and resources before operations begin. Failure to secure community buy-in can lead to protests or delays that stall the manufacturing hub's operational timeline.

**Strategic Choices:**

1. Conduct extensive town hall meetings and water safety demonstrations before breaking ground to secure resident trust.
2. Partner with local religious and civic leaders to endorse the project and mitigate cultural resistance effectively.
3. Implement a transparent real-time water quality dashboard accessible to the public to maintain ongoing accountability.

**Trade-Off / Risk:** Engaging residents builds trust but consumes budget meant for hardware, creating a tension between social license and technical rollout speed.

**Strategic Connections:**

**Synergy:** It supports Environmental Permitting Strategy by demonstrating public benefit to regulators, and aids Export Market Compliance Adaptation by showcasing social responsibility standards to international partners.

**Conflict:** It constrains Production Capacity Ramp-up Pace because extensive engagement activities delay ground-breaking, and competes with Capital Allocation Mix for limited early-stage budget resources.

**Justification:** *High*, Prevents local delays through social license. Crucial for Delhi operations but conflicts with ramp-up pace and competes for early budget resources against hardware procurement needs.

### Decision 13: Energy Consumption Profile
**Lever ID:** `353eb1e4-1052-4231-8f44-47b6b7a92f4e`

**The Core Decision:** This lever defines the power sources for purification and manufacturing operations, balancing grid reliance against renewable integration. Scope includes on-site solar or utility partnerships. Key metrics involve operational cost per liter and carbon footprint reduction. Selecting efficient energy profiles ensures long-term viability and aligns with global sustainability expectations for exported solutions.

**Why It Matters:** High energy usage increases operational costs and carbon footprint, potentially undermining the sustainability claims of the water purification system. Integrating renewable sources reduces long-term costs but requires upfront investment and grid coordination that complicates initial deployment.

**Strategic Choices:**

1. Design the purification process to operate on grid electricity exclusively to minimize initial capital expenditure and complexity.
2. Integrate solar photovoltaic panels directly into the manufacturing hub design to power half of the purification load.
3. Partner with utility providers to secure renewable energy credits and offset consumption without on-site generation infrastructure.

**Trade-Off / Risk:** Relying on grid power lowers upfront costs but exposes the project to volatile tariffs and grid instability risks in urban Delhi.

**Strategic Connections:**

**Synergy:** It enhances Export Market Compliance Adaptation by lowering carbon footprints for international markets, and supports Environmental Permitting Strategy by meeting green energy requirements in Delhi.

**Conflict:** It constrains Capital Allocation Mix due to high upfront costs for solar infrastructure, potentially limiting funds for core manufacturing equipment or initial technology licensing fees.

**Justification:** *Medium*, Addresses sustainability and operational costs. Important for export alignment but subordinate to core production and standardization strategies.

### Decision 14: Pilot Validation Scope
**Lever ID:** `4f44e5e1-56b8-4d23-becf-842744613153`

**The Core Decision:** This lever determines the scale and diversity of initial testing before mass production. Options range from single prototypes to parallel plants across zones. Success is measured by data quality on wastewater variability and time to certification. Adequate validation ensures the modular design handles real-world conditions without requiring costly post-launch redesigns.

**Why It Matters:** A small pilot reduces initial risk but may not capture real-world variability in wastewater quality or demand spikes. Expanding the pilot scope provides better data but delays mass production readiness and increases early-stage financial exposure.

**Strategic Choices:**

1. Deploy a single prototype unit in one neighborhood to validate core chemistry before scaling manufacturing lines significantly.
2. Construct three parallel pilot plants across different zones to test diverse wastewater compositions simultaneously.
3. Simulate pilot conditions using digital twin technology to reduce physical testing time and material waste during validation.

**Trade-Off / Risk:** Limiting pilot scope saves money but risks missing critical failure modes that only emerge when processing varied municipal wastewater streams.

**Strategic Connections:**

**Synergy:** It informs Modular Standardization Level by providing real-world data on system variability, and strengthens Technology Licensing Model by validating core chemistry for external partners.

**Conflict:** It constrains Production Capacity Ramp-up Pace as expanded testing delays manufacturing line scaling, and competes with Capital Allocation Mix for early financial resources needed for hardware procurement.

**Justification:** *Medium*, Mitigates technical risk before scaling. Important for data gathering but competes with budget and timing needs for full production setup.

### Decision 15: Maintenance Lifecycle Model
**Lever ID:** `88f7da06-2506-4aa5-af7f-6d78e89bf1da`

**The Core Decision:** This lever establishes how ongoing repairs and replacements are handled post-deployment. Options include in-house teams, third-party contractors, or self-diagnosis components. Success metrics cover service response times and revenue from maintenance contracts. Choosing the right model balances quality control against labor costs and scalability across different export markets.

**Why It Matters:** Offering long-term maintenance contracts ensures revenue streams but locks the company into long-term service obligations that limit flexibility. Training local third-party providers scales support quickly but risks inconsistent service quality and brand reputation damage.

**Strategic Choices:**

1. Establish an in-house service team to handle all repairs and replacements for the first five years of operation.
2. Train and certify local third-party contractors to perform routine maintenance and filter replacements at scale.
3. Design components for self-diagnosis and user replacement to minimize the need for specialized technical intervention on site.

**Trade-Off / Risk:** In-house maintenance ensures quality but creates high fixed labor costs, whereas outsourcing risks inconsistent performance across different regions.

**Strategic Connections:**

**Synergy:** It aligns with Local Workforce Training Pipeline by defining roles for trained technicians, and supports Export Market Compliance Adaptation by ensuring reliable service standards abroad.

**Conflict:** It constrains Modular Standardization Level if custom components require specialized repair, and competes with Capital Allocation Mix for ongoing labor budget resources.

**Justification:** *Medium*, Defines post-deployment service revenue and quality control. Strategic but secondary to initial product standardization and manufacturing setup decisions.

### Decision 16: Distribution Network Configuration
**Lever ID:** `4f9f8079-9bd0-4dbe-8987-c8a150841ee5`

**The Core Decision:** This lever defines the strategic approach for delivering AWP plants to target markets, balancing control against speed. It selects between direct branches, utility partnerships, or franchises to optimize revenue and reach. Success metrics include market penetration rate, customer acquisition cost, and long-term retention. It shapes how the manufacturing hub connects with global clients.

**Why It Matters:** Building direct sales channels offers higher margins but requires significant marketing investment and local presence in each region. Partnering with existing utilities accelerates market entry but reduces control over pricing and customer relationship management.

**Strategic Choices:**

1. Establish direct sales branches in key export cities to maintain full control over pricing and customer engagement.
2. Partner with established municipal utilities to integrate the AWP plants into their existing infrastructure networks.
3. Create a franchise model where local entrepreneurs own and operate the plants under the central brand license.

**Trade-Off / Risk:** Direct sales maximize margins but require heavy upfront investment, while partnerships accelerate entry but cede control over pricing and service.

**Strategic Connections:**

**Synergy:** This lever amplifies Modular Standardization Level by enabling consistent product deployment across diverse channels. It also supports Technology Licensing Model when choosing franchise options, ensuring brand integrity while scaling operations efficiently through third-party operators.

**Conflict:** Direct sales branches strain Capital Allocation Mix due to high upfront costs. Conversely, partnerships may dilute control over Maintenance Lifecycle Model, creating risks for service quality and long-term operational reliability across different regions.

**Justification:** *Medium*, Structures market access and sales channels. Dependent on licensing model and prioritization decisions; less central than production or capital planning.
