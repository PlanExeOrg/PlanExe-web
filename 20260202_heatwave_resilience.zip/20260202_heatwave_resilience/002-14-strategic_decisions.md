## Primary Decisions
The vital few decisions that have the most impact.


The 'Critical' and 'High' impact levers address the core project tensions of Cost vs. Reach (Resource Allocation, Workforce Mobilization), Data Privacy vs. Intervention Effectiveness (Data Acquisition, Proactive Health Coordination), and Centralization vs. Accessibility (Cooling Center Model). Targeted Outreach is key to making all of these work. A potential missing dimension is a lever explicitly addressing the communication strategy during extreme events, beyond pre-season campaigns.

### Decision 1: Targeted Outreach Strategy
**Lever ID:** `a407d2ce-4bde-4ee2-91cf-a4db9c138aaa`

**The Core Decision:** The Targeted Outreach Strategy lever defines how the municipality identifies and engages high-risk residents. It controls the methods used to reach vulnerable populations, aiming to maximize enrollment in the program and ensure timely assistance during heat events. Success is measured by the reach and effectiveness of outreach efforts, including enrollment rates, contact success rates, and the demographic diversity of participants. The objective is to ensure that those most in need are aware of and can access available resources.

**Why It Matters:** Prioritizing specific vulnerable groups impacts resource allocation. Immediate: Increased contact rates with target groups → Systemic: 15% reduction in heat-related incidents among vulnerable populations → Strategic: Improved public health outcomes and reduced strain on emergency services.

**Strategic Choices:**

1. Focus on existing social service networks and opt-in registries for outreach.
2. Supplement existing networks with targeted mail campaigns and community events in high-risk areas.
3. Employ predictive analytics (using anonymized, aggregated data) to proactively identify and engage at-risk individuals through personalized communication channels, while ensuring strict GDPR compliance.

**Trade-Off / Risk:** Controls Reach vs. Privacy. Weakness: The options don't fully address the challenge of reaching transient or newly arrived populations.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Cooling Center Model. Effective outreach drives utilization of cooling centers, ensuring they serve the intended population. It also enhances the Home Intervention Strategy by identifying eligible households for targeted support.

**Conflict:** A highly aggressive outreach strategy can conflict with Volunteer Risk Management, potentially placing volunteers in challenging situations. It also competes with Data Acquisition Strategy, as more aggressive strategies may raise GDPR concerns and require more complex data handling.

**Justification:** *High*, High importance due to its strong synergy with cooling centers and home interventions. It directly impacts program enrollment and contact success, influencing the reach and effectiveness of the entire initiative. It also has conflicts with volunteer risk and data acquisition.

### Decision 2: Resource Allocation Model
**Lever ID:** `cb6312f6-f3a9-4d45-8077-229590584989`

**The Core Decision:** The Resource Allocation Model lever determines how the program's budget is distributed across different interventions. It controls the funding levels for cooling centers, home interventions, transport, and outreach. The objective is to optimize resource utilization to maximize impact on heat-related harm reduction. Key success metrics include cost-effectiveness of each intervention, equitable distribution of resources across vulnerable groups, and overall program efficiency in achieving its mortality reduction goals.

**Why It Matters:** Balancing investment across cooling centers, home interventions, and transport affects overall program impact. Immediate: Shift in budget allocation → Systemic: 10% increase in cooling center utilization and 5% reduction in home heat exposure → Strategic: Optimized resource utilization and improved cost-effectiveness of interventions.

**Strategic Choices:**

1. Allocate resources equally across cooling centers, home interventions, and transport based on population density.
2. Prioritize resource allocation based on real-time demand and utilization data, dynamically adjusting budgets for each intervention.
3. Implement a 'heat equity fund' that directs resources disproportionately to the most deprived neighborhoods, using a combination of need-based criteria and community-led project selection, while tracking impact disparities.

**Trade-Off / Risk:** Controls Equity vs. Efficiency. Weakness: The options lack a clear mechanism for adapting to unexpected surges in demand for specific services.

**Strategic Connections:**

**Synergy:** This lever has a strong synergy with the Data Acquisition Strategy. Real-time data on demand and utilization can inform dynamic resource allocation, improving efficiency. It also works well with Targeted Outreach Strategy, ensuring resources are directed to areas with the highest identified need.

**Conflict:** Prioritizing resources based on real-time demand can conflict with the Community Resilience Strategy, especially if a decentralized approach requires upfront funding commitments. It also creates tension with the Home Intervention Strategy if resources are diverted away from pre-emptive measures to address immediate crises.

**Justification:** *Critical*, Critical because it governs the fundamental trade-offs between different interventions (cooling centers, home interventions, transport). It determines how the budget is distributed, directly impacting the cost-effectiveness and equity of the program. It also has strong synergy with data acquisition.

### Decision 3: Proactive Health Coordination
**Lever ID:** `cc0d2e55-f339-47a8-b1f6-d7aaec73f8c7`

**The Core Decision:** The Proactive Health Coordination lever defines the level of integration between the heatwave response program and the existing healthcare system. It controls the flow of information and collaboration between outreach teams, hospitals, and primary care providers. The objective is to improve early detection of heat-related illness, prevent hospitalizations, and ensure appropriate care for vulnerable individuals. Success is measured by reductions in heat-related EMS calls, ED visits, and hospital admissions.

**Why It Matters:** Integrating with health systems can prevent emergencies but requires careful data handling. Immediate: Increased communication between outreach teams and healthcare providers → Systemic: 20% reduction in heat-related hospital admissions → Strategic: Enhanced healthcare capacity and improved patient outcomes during heatwaves.

**Strategic Choices:**

1. Establish basic communication protocols between outreach teams and hospitals for sharing aggregate data on heat-related incidents.
2. Develop a secure, anonymized data-sharing platform for real-time monitoring of heat-related health trends and proactive intervention planning.
3. Create a 'heat health passport' system (opt-in) that allows vulnerable individuals to share relevant medical information with outreach workers and healthcare providers during heat events, facilitating personalized care and rapid response.

**Trade-Off / Risk:** Controls Prevention vs. Data Privacy. Weakness: The options don't fully consider the logistical challenges of coordinating across multiple healthcare providers.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Targeted Outreach Strategy. Sharing aggregate data with healthcare providers can improve the identification of high-risk individuals for proactive outreach. It also enhances the Home Intervention Strategy by providing insights into the most effective interventions for specific health conditions.

**Conflict:** A highly aggressive data-sharing approach can conflict with GDPR constraints and the Data Acquisition Strategy, requiring careful consideration of privacy regulations. It may also strain the Workforce Mobilization Strategy if healthcare professionals are required to dedicate significant time to the program.

**Justification:** *High*, High importance because it directly impacts health outcomes and healthcare capacity. It synergizes with outreach and home interventions, and its conflict with GDPR highlights a key project tension between prevention and data privacy. It is key to reducing hospitalizations.

### Decision 4: Data Acquisition Strategy
**Lever ID:** `56651bc4-f854-416e-9953-9c3d99806095`

**The Core Decision:** The Data Acquisition Strategy defines how the program gathers information to identify and support vulnerable residents. It controls the scope and methods of data collection, balancing the need for comprehensive insights with privacy concerns and GDPR compliance. Objectives include creating a reliable risk profile of the city's population and tracking program effectiveness. Key success metrics are the completeness and accuracy of the data, the number of high-risk residents identified, and adherence to privacy regulations.

**Why It Matters:** Balancing data needs with privacy concerns will Immediate: affect the accuracy of risk assessments → Systemic: impacting the ability to target interventions effectively, potentially leading to 10% less efficient resource allocation → Strategic: influencing the overall program impact and public trust. Trade-off: Data accuracy vs. GDPR compliance.

**Strategic Choices:**

1. Passive Data Collection: Rely solely on publicly available data and opt-in registries.
2. Targeted Data Partnerships: Establish GDPR-compliant data-sharing agreements with specific healthcare providers and social services.
3. Federated Learning Network: Implement a privacy-preserving federated learning system to analyze anonymized data across multiple sources without centralizing it.

**Trade-Off / Risk:** Controls Data Accuracy vs. Privacy. Weakness: The options fail to consider the potential for bias in existing datasets.

**Strategic Connections:**

**Synergy:** This lever strongly enhances the Targeted Outreach Strategy (a407d2ce-4bde-4ee2-91cf-a4db9c138aaa) by providing the data needed to identify and prioritize outreach efforts. It also supports Proactive Health Coordination (cc0d2e55-f339-47a8-b1f6-d7aaec73f8c7) by providing aggregate signals for health system planning.

**Conflict:** A more aggressive data acquisition strategy can conflict with Volunteer Risk Management (d544deac-1aa0-4399-a819-e2c73c4b1946) if volunteers are involved in collecting sensitive data. It also creates tension with the Targeted Outreach Strategy (a407d2ce-4bde-4ee2-91cf-a4db9c138aaa) if data collection methods are perceived as intrusive.

**Justification:** *Critical*, Critical because it controls the fundamental trade-off between data accuracy and privacy (GDPR compliance). It directly impacts the ability to target interventions effectively and supports both outreach and health coordination. It is a central hub for information flow.

### Decision 5: Workforce Mobilization Strategy
**Lever ID:** `789d0314-8105-4763-a7ec-ac7b0040bb58`

**The Core Decision:** The Workforce Mobilization Strategy defines how the program will staff its various activities. It controls the mix of municipal employees, contractors, and volunteers used for outreach, cooling center operations, and home interventions. The objective is to ensure adequate staffing levels while managing costs and leveraging community resources. Key success metrics include staffing coverage, cost-effectiveness, and volunteer retention rates.

**Why It Matters:** The workforce mobilization strategy will Immediate: determine the capacity to deliver outreach and home interventions → Systemic: impacting the speed and scale of program implementation, potentially leading to 20% faster deployment → Strategic: influencing the program's ability to meet its goals within the 12-month timeframe. Trade-off: Cost vs. Capacity.

**Strategic Choices:**

1. Municipal Staff Reliance: Rely solely on existing municipal staff for all program activities.
2. Contractor Partnerships: Contract with external organizations for specific tasks like outreach and home installations.
3. Volunteer Corps Activation: Recruit and train a volunteer corps to supplement municipal staff and contractors, leveraging community expertise and enthusiasm.

**Trade-Off / Risk:** Controls Cost vs. Capacity. Weakness: The options fail to consider the long-term sustainability of a volunteer-based workforce.

**Strategic Connections:**

**Synergy:** This lever strongly supports both the Cooling Center Model (3a49d03c-9247-42c0-a36c-928b841399a0) and the Home Intervention Strategy (093e46ea-fcf6-416e-b3aa-cfb02b1c15ec) by providing the necessary personnel to operate cooling centers and install home interventions. A robust volunteer corps can significantly enhance program reach.

**Conflict:** Reliance on volunteers can conflict with Volunteer Risk Management (d544deac-1aa0-4399-a819-e2c73c4b1946), requiring careful screening, training, and supervision. It also conflicts with the Resource Allocation Model (cb6312f6-f3a9-4d45-8077-229590584989) if extensive volunteer management infrastructure is needed.

**Justification:** *Critical*, Critical because it determines the capacity to deliver outreach and home interventions, directly impacting program implementation speed and scale. It supports cooling centers and home interventions, and its conflict with volunteer risk highlights a key operational challenge. It controls cost vs. capacity.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Volunteer Risk Management
**Lever ID:** `d544deac-1aa0-4399-a819-e2c73c4b1946`

**The Core Decision:** The Volunteer Risk Management lever focuses on ensuring the safety and well-being of volunteers involved in the heatwave response program. It controls the level of training, support, and insurance provided to volunteers. The objective is to minimize risks to volunteers, maintain their morale, and ensure the sustainability of the volunteer workforce. Success is measured by volunteer retention rates, incident reporting, and feedback from volunteers on their experiences.

**Why It Matters:** Volunteer programs offer scalability but introduce safety and liability concerns. Immediate: Implementation of volunteer safety protocols → Systemic: 95% adherence to safety guidelines among volunteers → Strategic: Minimized risk of volunteer harm and enhanced program sustainability.

**Strategic Choices:**

1. Provide basic safety training and background checks for all volunteers.
2. Implement a buddy system and regular check-ins for volunteers, along with clear escalation procedures for emergencies.
3. Develop a comprehensive volunteer insurance policy and establish a formal risk management framework that includes incident reporting, debriefing, and psychological support for volunteers exposed to traumatic situations.

**Trade-Off / Risk:** Controls Scalability vs. Volunteer Safety. Weakness: The options don't fully address the potential for reputational damage from negative volunteer experiences.

**Strategic Connections:**

**Synergy:** This lever has a strong synergy with the Workforce Mobilization Strategy. Effective risk management attracts and retains volunteers, ensuring adequate staffing for outreach and support activities. It also supports the Community Resilience Strategy by building trust and encouraging community participation.

**Conflict:** A comprehensive risk management approach can conflict with the Resource Allocation Model, as it may require significant investment in training, insurance, and support services. It also constrains the Targeted Outreach Strategy, as certain outreach methods may be deemed too risky for volunteers.

**Justification:** *Medium*, Medium importance. While important for volunteer well-being and program sustainability, it's more of an enabling function than a driver of core strategic choices. It manages a trade-off (scalability vs. safety) but is not as central as other levers.

### Decision 7: Community Resilience Strategy
**Lever ID:** `f00a2ae0-42ce-41eb-8075-ababa3f5add2`

**The Core Decision:** The Community Resilience Strategy lever determines the extent to which the program relies on community-led initiatives versus centralized municipal control. It controls the level of community involvement in program design, implementation, and evaluation. The objective is to build local capacity, foster community ownership, and ensure that the program is culturally appropriate and responsive to local needs. Success is measured by community participation rates, feedback from community members, and the sustainability of community-led initiatives.

**Why It Matters:** Investing in community networks will Immediate: increase trust and program uptake → Systemic: 15% more efficient outreach through trusted channels → Strategic: Enhanced long-term resilience by empowering local actors. Trade-off: Speed of centralized deployment vs. depth of community integration.

**Strategic Choices:**

1. Centralized Deployment: Rely on municipal staff for all outreach and program delivery.
2. Hybrid Approach: Partner with existing community organizations for outreach and some program delivery, with municipal oversight.
3. Decentralized Empowerment: Provide grants and training to community-led initiatives, enabling them to design and implement solutions tailored to their specific needs.

**Trade-Off / Risk:** Controls Speed vs. Community Buy-in. Weakness: The options fail to consider the varying levels of organizational capacity within different communities.

**Strategic Connections:**

**Synergy:** This lever synergizes strongly with the Targeted Outreach Strategy. Community organizations are best positioned to reach vulnerable residents and build trust. It also enhances the Workforce Mobilization Strategy by leveraging local knowledge and networks to recruit volunteers.

**Conflict:** A decentralized approach can conflict with the Resource Allocation Model, as it may be difficult to ensure equitable distribution of resources across different communities. It also creates tension with the Proactive Health Coordination if community-led initiatives are not well-integrated with the healthcare system.

**Justification:** *Medium*, Medium importance. It impacts program uptake and long-term resilience, but its influence is less direct than outreach or resource allocation. It controls speed vs. community buy-in, but the plan's constraints favor faster deployment.

### Decision 8: Cooling Center Model
**Lever ID:** `3a49d03c-9247-42c0-a36c-928b841399a0`

**The Core Decision:** The Cooling Center Model determines the structure and accessibility of cooling centers. It controls the number, location, hours, and services offered at these centers. The objective is to provide accessible and effective relief from extreme heat for vulnerable populations. Key success metrics include center utilization rates, geographic coverage, accessibility for mobility-limited residents, and user satisfaction.

**Why It Matters:** The cooling center model will Immediate: determine accessibility and utilization rates → Systemic: impacting the overall reach and effectiveness of the program, potentially leading to 20% difference in vulnerable population reach → Strategic: influencing the program's ability to reduce heat-related harm. Trade-off: Centralized efficiency vs. distributed accessibility.

**Strategic Choices:**

1. Centralized Hubs: Focus on a few large, centrally located cooling centers with extended hours.
2. Distributed Network: Utilize a larger number of smaller, community-based cooling centers with flexible hours.
3. Mobile Cooling Units: Deploy mobile cooling units to reach underserved neighborhoods and vulnerable populations with limited mobility.

**Trade-Off / Risk:** Controls Centralization vs. Accessibility. Weakness: The options fail to consider the impact of cooling center location on transportation costs for vulnerable residents.

**Strategic Connections:**

**Synergy:** This lever works in synergy with the Targeted Outreach Strategy (a407d2ce-4bde-4ee2-91cf-a4db9c138aaa) to drive utilization of cooling centers by informing vulnerable residents of their availability. It also complements the Workforce Mobilization Strategy (789d0314-8105-4763-a7ec-ac7b0040bb58) by defining staffing needs at the centers.

**Conflict:** A centralized cooling center model can conflict with the Home Intervention Strategy (093e46ea-fcf6-416e-b3aa-cfb02b1c15ec) if resources are diverted from home-based solutions. It also conflicts with the Resource Allocation Model (cb6312f6-f3a9-4d45-8077-229590584989) as it requires significant funding for staffing and operations.

**Justification:** *High*, High importance because it determines the accessibility and utilization of cooling centers, a core intervention. It synergizes with outreach and workforce mobilization, and its conflict with home interventions highlights a key resource allocation decision. It controls centralization vs. accessibility.

### Decision 9: Home Intervention Strategy
**Lever ID:** `093e46ea-fcf6-416e-b3aa-cfb02b1c15ec`

**The Core Decision:** The Home Intervention Strategy focuses on providing direct support to high-risk residents in their homes. It controls the type and scope of interventions, from basic supplies to more advanced adaptations. The objective is to reduce indoor heat exposure and improve the resilience of vulnerable households. Key success metrics include the number of homes reached, the effectiveness of interventions in lowering indoor temperatures, and resident satisfaction.

**Why It Matters:** The home intervention strategy will Immediate: impact the immediate living conditions of vulnerable residents → Systemic: influencing their ability to cope with heatwaves and reducing the strain on emergency services by 15% → Strategic: contributing to long-term health and well-being. Trade-off: Cost-effectiveness vs. individual impact.

**Strategic Choices:**

1. Basic Package: Provide a standardized package of low-cost items like reflective blinds and hydration supplies.
2. Tiered Intervention: Offer a tiered package based on assessed risk and housing type, including window fans and shading kits.
3. Smart Home Adaptation: Integrate smart home technologies like automated blinds and smart thermostats, prioritizing energy efficiency and remote monitoring.

**Trade-Off / Risk:** Controls Cost vs. Effectiveness. Weakness: The options fail to consider the potential for unintended consequences, such as increased energy consumption.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Targeted Outreach Strategy (a407d2ce-4bde-4ee2-91cf-a4db9c138aaa) to identify and prioritize homes for intervention. It also benefits from the Workforce Mobilization Strategy (789d0314-8105-4763-a7ec-ac7b0040bb58) to provide installation and support services.

**Conflict:** A more comprehensive home intervention strategy can conflict with the Cooling Center Model (3a49d03c-9247-42c0-a36c-928b841399a0) by diverting resources away from communal cooling spaces. It also creates tension with the Resource Allocation Model (cb6312f6-f3a9-4d45-8077-229590584989) due to the higher costs of individualized interventions.

**Justification:** *Medium*, Medium importance. While directly impacting residents, it's less central than resource allocation or data acquisition. It controls cost vs. effectiveness, but the plan prioritizes fast and cheap interventions. It is also less connected than other levers.
