
## Audit - Corruption Risks

- Bribery of municipal officials to secure favorable locations for cooling centers, potentially overlooking accessibility or suitability for vulnerable populations.
- Kickbacks from contractors providing home intervention supplies (e.g., shading kits, fans) in exchange for inflated contracts or substandard materials.
- Conflicts of interest where municipal staff or their relatives are awarded contracts for transport services or cooling center staffing.
- Misuse of confidential data (e.g., lists of high-risk residents) for personal gain or political advantage, potentially leading to targeted scams or discrimination.
- Trading favors with housing associations to prioritize certain residents for home interventions based on personal connections rather than need.

## Audit - Misallocation Risks

- Overspending on cooling center amenities (e.g., expensive furniture or entertainment systems) at the expense of outreach programs or home interventions.
- Inefficient allocation of transport resources, leading to long wait times for vulnerable residents and underutilization of contracted services.
- Double spending through overlapping contracts with multiple providers for the same services (e.g., outreach or home installations).
- Misreporting of outreach contact success rates to meet the month 4 scale gate, potentially masking the true reach of the program.
- Unauthorized use of program funds for personal expenses or unrelated projects, disguised as legitimate program costs.

## Audit - Procedures

- Conduct quarterly internal audits of all financial transactions, including procurement, contracts, and expense reports, with a focus on identifying irregularities or conflicts of interest. Responsibility: Internal Audit Department.
- Implement a contract review threshold requiring independent legal review for all contracts exceeding €50,000, ensuring compliance with procurement regulations and fair pricing. Responsibility: Legal Department.
- Perform periodic spot checks of cooling centers to verify staffing levels, operating hours, and accessibility features, ensuring compliance with program standards. Responsibility: Program Management Team.
- Conduct regular data security audits to ensure GDPR compliance in data acquisition, storage, and usage, including penetration testing and vulnerability assessments. Responsibility: IT Security Department and GDPR Compliance Expert.
- Implement a robust expense workflow requiring detailed documentation and approval from multiple levels of management for all expenditures, preventing unauthorized spending. Responsibility: Finance Department.

## Audit - Transparency Measures

- Publish a monthly progress dashboard on the municipal website, displaying key operational KPIs (e.g., center utilization, outreach attempts/success, home-intervention installations completed) and financial data (budget vs. actual spending).
- Publish minutes of all incident-command style structure meetings (who declares an alert, who owns operations, who owns comms, who owns partner coordination) on the municipal website within one week of the meeting.
- Establish a confidential whistleblower mechanism (e.g., a dedicated phone line or email address) for reporting suspected fraud, corruption, or ethical violations, with clear procedures for investigation and protection of whistleblowers.
- Make the Heat Response Playbook (SOPs, checklists, scripts, procurement lists, partner MOUs) publicly accessible on the municipal website, promoting transparency and accountability.
- Document and publish the selection criteria and justification for all major decisions, including the selection of cooling center locations, transport providers, and home intervention contractors.