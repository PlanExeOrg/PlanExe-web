*Roles Needed & Example People*

# Roles

## 1. Program Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires full dedication to oversee and coordinate all aspects of the project.

**Explanation**:
Oversees the entire project, ensuring all components are integrated and aligned with the goal of reducing heat-related harm.

**Consequences**:
Lack of overall coordination, missed deadlines, budget overruns, and failure to achieve project goals.

**People Count**:
1

**Typical Activities**:
Overseeing project planning, execution, and monitoring; managing the budget and resources; coordinating with various stakeholders, including municipal staff, contractors, and community organizations; ensuring compliance with regulations and ethical guidelines; and reporting on project progress and outcomes.

**Background Story**:
Eleni Papadopoulos, born and raised in Thessaloniki, Greece, has dedicated her career to public service. With a Master's degree in Public Administration from the University of Macedonia and ten years of experience in municipal government, Eleni possesses a deep understanding of local challenges and opportunities. She has previously managed several successful community health initiatives, demonstrating her ability to coordinate complex projects and engage diverse stakeholders. Her familiarity with Thessaloniki's demographics, infrastructure, and social services makes her the ideal Program Manager for this heatwave mitigation project. Eleni is driven by a passion for improving the well-being of her community and ensuring that vulnerable residents receive the support they need.

**Equipment Needs**:
Computer with internet access, project management software, communication tools (email, phone), presentation software, access to relevant databases and regulations.

**Facility Needs**:
Office space with desk, chair, and adequate lighting; access to meeting rooms for stakeholder coordination; secure file storage.

## 2. Community Outreach Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Needs dedicated staff to manage community outreach, especially given the importance of reaching vulnerable populations.

**Explanation**:
Leads the effort to identify and engage high-risk residents, ensuring they are aware of available resources and support.

**Consequences**:
Failure to reach vulnerable populations, leading to underutilization of resources and increased heat-related harm.

**People Count**:
min 2, max 4, depending on the size of the city and the scale of the outreach program

**Typical Activities**:
Identifying and engaging high-risk residents through various outreach methods; building relationships with community organizations and leaders; developing and delivering culturally sensitive outreach materials; coordinating volunteer efforts; and tracking outreach effectiveness.

**Background Story**:
Born in Bucharest, Romania, Andrei Popescu immigrated to Thessaloniki with his family as a teenager. He holds a degree in Social Work from Aristotle University and has spent the last five years working with local NGOs, focusing on immigrant and refugee support. Andrei is fluent in Romanian, Greek, and English, and has a strong understanding of the cultural nuances within Thessaloniki's diverse communities. His experience in building trust with marginalized populations and navigating complex social service systems makes him a valuable Community Outreach Coordinator. Andrei is passionate about ensuring that all residents, regardless of their background, have access to essential resources and support.

**Equipment Needs**:
Laptop or tablet with internet access, mobile phone, outreach materials (flyers, brochures), transportation (potentially a car or access to public transport), translation software/devices.

**Facility Needs**:
Office space for planning and coordination, access to community centers or meeting spaces for outreach events, secure storage for sensitive information.

## 3. Healthcare Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires a dedicated person to coordinate with healthcare providers and ensure seamless response to heat-related emergencies.

**Explanation**:
Facilitates communication and coordination between the program and local healthcare providers, ensuring a seamless response to heat-related emergencies.

**Consequences**:
Poor coordination with healthcare systems, leading to delayed or inadequate medical care for vulnerable residents.

**People Count**:
1

**Typical Activities**:
Establishing and maintaining communication channels with local hospitals, emergency services, and primary care providers; developing heat illness escalation guidelines; facilitating data sharing (within GDPR constraints); and coordinating training for healthcare professionals on heatwave response.

**Background Story**:
Isabella Rossi, originally from Bologna, Italy, moved to Thessaloniki after completing her medical degree at the University of Bologna and specializing in public health. With five years of experience as a public health officer, Isabella has worked on various initiatives aimed at improving community health outcomes. Her expertise in epidemiology, data analysis, and health system coordination makes her an ideal Healthcare Liaison. Isabella is passionate about bridging the gap between healthcare providers and the community, ensuring that vulnerable residents receive timely and appropriate medical care.

**Equipment Needs**:
Computer with secure access to relevant health databases (within GDPR compliance), phone, communication software, access to medical literature and guidelines.

**Facility Needs**:
Office space with secure data access, access to hospital or clinic meeting rooms, quiet space for confidential communications.

## 4. Logistics Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires a dedicated person to manage the logistics of home interventions, ensuring timely delivery of essential supplies.

**Explanation**:
Manages the procurement, distribution, and installation of home-level interventions, ensuring timely delivery of essential supplies.

**Consequences**:
Delays in providing home-level interventions, leaving high-risk residents without essential protection during heatwaves.

**People Count**:
min 1, max 2, depending on the number of home interventions planned

**Typical Activities**:
Managing the procurement, storage, and distribution of home intervention supplies; coordinating with suppliers and contractors; tracking inventory levels; and ensuring timely delivery to high-risk homes.

**Background Story**:
Kostas Dimitriou, a lifelong resident of Thessaloniki, has a background in supply chain management and logistics. After earning a degree in Business Administration from the University of Piraeus, he worked for several years in the private sector before transitioning to a role in municipal government. Kostas has experience in procurement, inventory management, and distribution, making him well-suited to manage the logistics of home-level interventions. He is committed to ensuring that essential supplies reach high-risk residents in a timely and efficient manner.

**Equipment Needs**:
Computer with inventory management software, phone, transportation (van or truck) for delivery of supplies, personal protective equipment (PPE) for installation work.

**Facility Needs**:
Office space for logistics planning, warehouse or storage space for home intervention supplies, access to a loading dock.

## 5. Cooling Center Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires dedicated staff to manage the day-to-day operations of cooling centers, ensuring they are safe, accessible, and well-equipped.

**Explanation**:
Responsible for the day-to-day operations of cooling centers, ensuring they are safe, accessible, and well-equipped to provide relief from the heat.

**Consequences**:
Inefficient or unsafe operation of cooling centers, reducing their effectiveness in providing relief from the heat.

**People Count**:
min 2, max 6, depending on the number of cooling centers and their operating hours

**Typical Activities**:
Overseeing the day-to-day operations of cooling centers; ensuring they are safe, accessible, and well-equipped; supervising staff and volunteers; managing schedules and resources; and addressing any issues or concerns that arise.

**Background Story**:
Maria Garcia, originally from Madrid, Spain, has a background in community development and recreation management. After completing her degree in Social Sciences from the Complutense University of Madrid, she moved to Thessaloniki and has worked for several years managing community centers and recreational facilities. Maria has experience in facility operations, staff supervision, and community engagement, making her well-suited to manage cooling centers. She is passionate about creating safe, welcoming, and accessible spaces for vulnerable residents.

**Equipment Needs**:
Computer, phone, first aid kit, communication devices (walkie-talkies), cooling center supplies (water, fans), security equipment (if needed).

**Facility Needs**:
Designated cooling center location, including tables, chairs, accessible restrooms, and a quiet area; access to electricity and water; secure storage for supplies.

## 6. Transportation Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires a dedicated person to arrange and manage transportation services for mobility-limited residents.

**Explanation**:
Arranges and manages transportation services for mobility-limited residents, ensuring they can access cooling centers and other essential resources.

**Consequences**:
Inability for mobility-limited residents to access cooling centers and other essential resources, increasing their risk of heat-related harm.

**People Count**:
min 1, max 3, depending on the size of the city and the demand for transportation services

**Typical Activities**:
Arranging and managing transportation services for mobility-limited residents; coordinating with taxi/transport providers and volunteer drivers; developing transportation schedules and routes; and ensuring timely and reliable service.

**Background Story**:
Stefan Petrov, a Bulgarian immigrant who has lived in Thessaloniki for over a decade, has a background in transportation logistics and customer service. He previously worked as a dispatcher for a local taxi company and has a strong understanding of the city's transportation network. Stefan is fluent in Bulgarian, Greek, and English, and has excellent communication and problem-solving skills. His experience in coordinating transportation services and assisting mobility-limited individuals makes him a valuable Transportation Coordinator. Stefan is committed to ensuring that all residents have access to essential resources, regardless of their mobility challenges.

**Equipment Needs**:
Phone, computer with dispatch software, access to transportation network information, communication devices for coordinating with drivers.

**Facility Needs**:
Office space for dispatching and coordination, access to a phone line and internet, secure communication channels with transport providers.

## 7. Communications Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires a dedicated person to develop and implement public communication campaigns.

**Explanation**:
Develops and implements public communication campaigns, ensuring that vulnerable residents are aware of heatwave risks and protective measures.

**Consequences**:
Lack of public awareness about heatwave risks and protective measures, leading to increased heat-related harm.

**People Count**:
1

**Typical Activities**:
Developing and implementing public communication campaigns; creating engaging and informative content; managing social media channels; coordinating with media outlets; and monitoring communication effectiveness.

**Background Story**:
Chloe Dubois, a French national who has been living in Thessaloniki for the past three years, has a background in journalism and public relations. After completing her degree in Communications from the Sorbonne University in Paris, she worked for several years as a journalist and communications specialist. Chloe is fluent in French, Greek, and English, and has excellent writing and communication skills. Her experience in developing and implementing public communication campaigns makes her a valuable Communications Specialist. Chloe is passionate about using her skills to raise awareness about important public health issues and promote positive behavior change.

**Equipment Needs**:
Computer with graphic design software, access to social media platforms, communication tools (email, phone), camera, microphone, video editing software.

**Facility Needs**:
Office space with desk and computer, access to a recording studio (if needed), access to meeting rooms for campaign planning.

## 8. Data Analyst / GDPR Compliance Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires a dedicated person to monitor program metrics, ensure data privacy, and provide insights for continuous improvement.

**Explanation**:
Monitors program metrics, ensures data privacy, and provides insights for continuous improvement.

**Consequences**:
Inability to track program effectiveness, ensure data privacy, and make data-driven decisions for continuous improvement.

**People Count**:
1

**Typical Activities**:
Monitoring program metrics; analyzing data to identify trends and patterns; ensuring data privacy and security; developing and implementing GDPR compliance protocols; and providing insights for continuous improvement.

**Background Story**:
Dimitrios Katsaros, a lifelong resident of Thessaloniki, has a background in data science and information security. After completing his degree in Computer Science from the University of Thessaloniki, he worked for several years as a data analyst and GDPR compliance officer. Dimitrios has expertise in data analysis, data privacy, and information security, making him well-suited to monitor program metrics, ensure data privacy, and provide insights for continuous improvement. He is committed to protecting sensitive data and ensuring compliance with GDPR regulations.

**Equipment Needs**:
Computer with statistical analysis software, secure access to program databases, data visualization tools, GDPR compliance resources.

**Facility Needs**:
Office space with secure data access, access to a quiet space for data analysis, secure file storage.

---

# Omissions

## 1. Lack of Dedicated Volunteer Coordinator

The plan relies on 50 volunteers for outreach, transport, and cooling center assistance. Without a dedicated coordinator, volunteer recruitment, training, scheduling, and ongoing support will be difficult to manage effectively, potentially leading to volunteer attrition and reduced program effectiveness. The 'Workforce Mobilization Strategy' decision also highlights the importance of volunteer management.

**Recommendation**:
Assign a portion of the Community Outreach Coordinator's time (e.g., 20%) or another municipal staff member's time to volunteer coordination. This includes recruitment, training, scheduling, communication, and ensuring volunteer well-being and safety. Alternatively, partner with a local volunteer organization to provide these services.

## 2. Missing Plan for Multilingual Support Beyond Communication

While the plan mentions multilingual communication, it doesn't explicitly address the need for multilingual support within cooling centers and during home interventions. Recent migrants with limited access to services are a key vulnerable group, and language barriers could prevent them from accessing and benefiting from the program. The 'Targeted Outreach Strategy' decision highlights the need to reach these populations.

**Recommendation**:
Incorporate multilingual support into cooling center staffing and home intervention teams. This could involve hiring bilingual staff, training existing staff in basic phrases, or partnering with local language services to provide interpretation. Ensure that key program materials are available in multiple languages.

## 3. Limited Focus on Post-Heatwave Support

The plan primarily focuses on pre-heatwave preparedness and real-time response. It lacks explicit provisions for post-heatwave support, such as mental health services for those affected or follow-up assessments of the effectiveness of home interventions. This could limit the program's long-term impact and ability to address the full spectrum of heatwave-related harm.

**Recommendation**:
Include a component for post-heatwave support, such as offering mental health resources through existing social services or conducting follow-up visits to assess the effectiveness of home interventions and identify any ongoing needs. This could be integrated into the Healthcare Liaison's role.

---

# Potential Improvements

## 1. Clarify Responsibilities for Misinformation Monitoring

The risk assessment identifies misinformation as a reputational risk, and the pre-project assessment includes monitoring communication channels. However, it's unclear who is specifically responsible for this task and how it will be conducted. Clear ownership is needed to ensure proactive identification and mitigation of misinformation.

**Recommendation**:
Assign the Communications Specialist primary responsibility for monitoring communication channels for misinformation. This includes identifying relevant channels, establishing monitoring protocols, and developing a rapid response plan to counter misinformation. The Data Analyst/GDPR Compliance Officer can assist with identifying potential sources of misinformation and assessing its impact.

## 2. Strengthen Integration of Community Resilience Strategy

While the Community Resilience Strategy is mentioned as a secondary decision, the plan could benefit from a stronger emphasis on community involvement. Engaging local residents in program design and implementation can increase trust, improve program effectiveness, and build long-term resilience. The 'Community Resilience Strategy' decision highlights the benefits of community-led initiatives.

**Recommendation**:
Establish a community advisory board consisting of representatives from vulnerable groups, local NGOs, and community leaders. This board can provide feedback on program design, help identify unmet needs, and assist with outreach efforts. Consider allocating a small portion of the budget to community-led initiatives that address heatwave-related challenges.

## 3. Improve Clarity on Home Intervention Selection Rubric

The plan mentions prioritizing top-floor flats and social housing for home interventions but lacks a detailed rubric for selecting specific homes. A clear and transparent selection process is needed to ensure equitable distribution of resources and avoid perceptions of bias. The 'Home Intervention Strategy' decision highlights the need for targeted support.

**Recommendation**:
Develop a detailed rubric for selecting homes for intervention, based on factors such as age of residents, health conditions, housing type, insulation quality, and neighborhood deprivation index. Make the rubric publicly available and ensure that the selection process is transparent and equitable. The Data Analyst/GDPR Compliance Officer can assist with developing the rubric and ensuring that it is applied consistently.