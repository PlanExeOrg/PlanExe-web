This plan implies one or more physical locations.

## Requirements for physical locations

- Demographics suitable for a pilot program
- Existing municipal assets that can be repurposed as cooling centers
- Housing stock with a significant number of top-floor flats and poorly insulated buildings
- Accessibility for vulnerable populations (elderly, disabled)
- GDPR compliance for data handling

## Location 1
Spain

Seville

Various locations in Seville

**Rationale**: Seville is a plausible EU city with a population within the specified range (approximately 700,000 in the metropolitan area, but ~680k within the city proper). It experiences frequent heatwaves, has a significant elderly population, and existing municipal assets that can be used as cooling centers. It also has a history of heat-related health issues, making it a good pilot site.

## Location 2
Italy

Palermo

Various locations in Palermo

**Rationale**: Palermo, Italy, fits the criteria as a mid-sized European city (population ~650,000). It is located in a region that experiences frequent heatwaves, has a significant elderly population, and existing municipal assets that can be used as cooling centers. The city also faces challenges related to housing quality and access to services for vulnerable populations.

## Location 3
Greece

Thessaloniki

Various locations in Thessaloniki

**Rationale**: Thessaloniki, Greece, is another suitable option with a population around 315,000. It experiences hot summers, has a sizable elderly population, and existing infrastructure that can be adapted for cooling centers. The city also has areas with older housing stock and potential challenges related to social services access for migrants.

## Location Summary
The plan requires a mid-sized European city as a pilot site. Seville, Palermo, and Thessaloniki are suggested due to their demographics, climate, existing infrastructure, and relevance to the project's goals of reducing heatwave-related harm among vulnerable populations.