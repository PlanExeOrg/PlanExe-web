Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on infrastructure improvements, public outreach campaigns, and health system coordination strategies, which are all within the realm of possibility without violating any known physical laws.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines product (heat interventions), market (vulnerable populations), tech/process (data analytics), and policy (GDPR compliance) in a novel way without sufficient evidence of success at a comparable scale. The plan states, "It's not entirely novel, as heatwave response plans exist, but it requires adaptation to a specific city and vulnerable populations."

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Program Manager: Produce validation report / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions several strategic concepts without defining their mechanism-of-action, owner, or measurable outcomes. For example, "Community Resilience Strategy lever determines the extent to which the program relies on community-led initiatives versus centralized municipal control" but lacks specifics.

**Mitigation**: Program Manager: Create one-pagers for each strategic concept, defining the inputs→process→customer value, owner, and measurable outcomes. Due: 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (GDPR, budget, volunteer safety) but lacks explicit analysis of second-order effects or cascade scenarios. The plan includes "Risk Assessment and Mitigation Strategies" but doesn't map dependencies between risks.

**Mitigation**: Risk Manager: Conduct a Failure Mode and Effects Analysis (FMEA) to identify second-order risks and cascade effects. Deliverable: Updated risk register with cascade analysis by end of next month.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and does not include authoritative permit lead times. The plan mentions "Permits for operating cooling centers in municipal assets" without specifying the approval process or realistic timelines.

**Mitigation**: Program Manager: Create a permit/approval matrix with all required permits, lead times, and dependencies. Deliverable: Permit matrix with realistic timelines within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not specify committed funding sources, draw schedule, or covenants. The plan mentions "Secure initial funding of €2.0M" but does not specify the source or status of this funding.

**Mitigation**: CFO: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates. Due: 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks benchmarks or vendor quotes to substantiate the budget. The plan states, "Initial €2.0M: 30% cooling centers, 25% outreach, 20% home interventions, 15% transport, 10% communications" without per-area normalization or justification.

**Mitigation**: CFO: Obtain ≥3 vendor quotes for cooling center fit-out, normalize per area (m²/ft²), and adjust budget or de-scope. Deliverable: Revised budget with benchmarked costs by EOM.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., 15% reduction in heat-related incidents) as single numbers without providing a range or discussing alternative scenarios. The plan states, "Systemic: 15% reduction in heat-related incidents among vulnerable populations".

**Mitigation**: Program Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the projected reduction in heat-related incidents. Deliverable: Scenario analysis within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions several components (cooling centers, outreach, home interventions) but lacks detailed engineering specifications, interface definitions, or test plans. The plan mentions "Cooling center equipment (fans, water dispensers, seating)" without further detail.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines product (heat interventions), market (vulnerable populations), tech/process (data analytics), and policy (GDPR compliance) in a novel way without sufficient evidence of success at a comparable scale. The plan states, "It's not entirely novel, as heatwave response plans exist, but it requires adaptation to a specific city and vulnerable populations."

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Program Manager: Produce validation report / 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions several deliverables without specific, verifiable qualities. For example, "Deliverables include a repeatable playbook, cost model, data report, and year-2 roadmap" but lacks SMART criteria.

**Mitigation**: Program Manager: Define SMART acceptance criteria for the 'repeatable playbook,' including a KPI for adoption rate (e.g., 80% of municipalities use it within 2 years).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Smart Home Adaptation' as a strategic choice for the Home Intervention Strategy. This feature does not appear to directly support the core project goals of reducing heat-related mortality and illness.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Smart Home Adaptation', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog. Due: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Data Analyst / GDPR Compliance Officer' to monitor program metrics, ensure data privacy, and provide insights. This role requires rare expertise in both data analysis and GDPR compliance, making it difficult to fill.

**Mitigation**: HR: Validate the talent market for a Data Analyst / GDPR Compliance Officer by contacting ≥3 recruiting firms. Deliverable: Market assessment report within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and does not include authoritative permit lead times. The plan mentions "Permits for operating cooling centers in municipal assets" without specifying the approval process or realistic timelines.

**Mitigation**: Program Manager: Create a permit/approval matrix with all required permits, lead times, and dependencies. Deliverable: Permit matrix with realistic timelines within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions long-term sustainability but lacks a detailed plan. The options for Workforce Mobilization Strategy "fail to consider the long-term sustainability of a volunteer-based workforce." There is no funding/resource strategy, maintenance schedule, or technology roadmap.

**Mitigation**: Program Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Permits for operating cooling centers in municipal assets" but lacks a permit/approval matrix and does not include authoritative permit lead times. This creates uncertainty about whether the project can meet hard constraints.

**Mitigation**: Program Manager: Create a permit/approval matrix with all required permits, lead times, and dependencies. Deliverable: Permit matrix with realistic timelines within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions partnerships with transport services but lacks details on backup providers or alternative transport methods. The plan mentions "Formalize agreements with transport providers" but does not address resilience.

**Mitigation**: Logistics Coordinator: Secure SLAs with ≥2 transport providers, add backup transport options (e.g., municipal vehicles), and test failover. Deliverable: Updated transport plan by EOM.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Finance Department' is incentivized by budget adherence, while the 'Community Outreach Coordinator' is incentivized by program enrollment, creating a conflict over outreach spending. The plan does not explicitly address this conflict.

**Mitigation**: Program Manager: Create a shared OKR that aligns Finance and Outreach on a common outcome, such as 'Increase program enrollment while staying within budget'. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient. The plan includes "Monitoring and evaluation system" but lacks specifics.

**Mitigation**: Program Manager: Add a monthly review with KPI dashboard and a lightweight change board. Deliverable: Schedule monthly reviews and define change-control process within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (budget, schedule, data) that are strongly coupled. A budget overrun (Risk 2) could force a reduction in outreach (Targeted Outreach Strategy), leading to cooling center underutilization (Risk 3).

**Mitigation**: Program Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO‑GO/contingency thresholds. Due: 60 days.