This plan involves money.

## Currencies

- **EUR:** The project is based in a European city and the budget is specified in Euros.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for all transactions. No additional international risk management is needed.