### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, ensuring alignment with municipal priorities and effective resource allocation.  Essential for a project of this scale and public importance, especially given the two-stage funding model.

**Responsibilities:**

- Provide strategic direction and oversight for the project.
- Approve the project plan and any significant changes to scope, budget, or timeline.
- Monitor project progress against key performance indicators (KPIs) and milestones.
- Approve the release of the second tranche of funding (€1.5M) based on the Month 4 scale gate assessment.
- Oversee risk management and ensure appropriate mitigation strategies are in place.
- Resolve any strategic issues or conflicts that cannot be resolved at the operational level.
- Ensure alignment with municipal strategic goals and priorities.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol.
- Review and approve the initial project plan.
- Define the escalation process from the Project Management Office.

**Membership:**

- Chief Resilience Officer (Chair)
- Director of Public Health
- Director of Social Services
- Director of Emergency Services
- Chief Financial Officer
- Independent Expert in Public Health or Climate Adaptation (External)

**Decision Rights:** Approves project plan, budget revisions exceeding 10% of initial allocation per category (cooling centers, outreach, etc.), scope changes, and go/no-go decisions at major milestones (especially the Month 4 gate).

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Chief Resilience Officer has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Quarterly, with ad hoc meetings as needed for critical decisions or escalations.

**Typical Agenda Items:**

- Review of project progress against KPIs and milestones.
- Discussion of key risks and mitigation strategies.
- Review of budget performance and any proposed budget revisions.
- Approval of any significant changes to project scope or timeline.
- Review of stakeholder engagement activities.
- Assessment of the Month 2 and Month 4 readiness gates.
- Review of audit findings and corrective actions.

**Escalation Path:** To the Mayor's Office for issues that cannot be resolved by the Steering Committee or that have significant political or reputational implications.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, ensuring efficient resource utilization, adherence to timelines, and effective risk management.  Crucial for coordinating the diverse activities and stakeholders involved.

**Responsibilities:**

- Develop and maintain the project plan, including timelines, budgets, and resource allocation.
- Manage day-to-day project execution, ensuring adherence to the project plan.
- Monitor project progress against KPIs and milestones.
- Identify and manage project risks, developing and implementing mitigation strategies.
- Manage project budget and track expenses.
- Coordinate communication and collaboration among project stakeholders.
- Prepare regular project status reports for the Steering Committee.
- Manage procurement processes and contracts.
- Ensure compliance with all relevant regulations and policies.
- Coordinate the activities of contractors and volunteers.

**Initial Setup Actions:**

- Establish project management processes and procedures.
- Develop a communication plan.
- Set up project tracking and reporting systems.
- Recruit and train project staff.
- Establish a risk register and mitigation plan.

**Membership:**

- Project Manager (Lead)
- Finance Officer
- Procurement Officer
- Communications Officer
- Data Analyst
- Community Liaison Officer

**Decision Rights:** Makes operational decisions within the approved project plan and budget.  Authorizes expenditures up to €10,000 per transaction. Manages day-to-day activities and resource allocation within defined parameters.

**Decision Mechanism:** Decisions are made by the Project Manager, in consultation with the PMO team.  Significant decisions are escalated to the Steering Committee.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against KPIs and milestones.
- Discussion of key risks and mitigation strategies.
- Review of budget performance and any proposed budget revisions (within delegated authority).
- Coordination of activities among project stakeholders.
- Review of procurement activities and contract management.
- Preparation of project status reports for the Steering Committee.
- Review of audit findings and corrective actions (within delegated authority).

**Escalation Path:** To the Project Steering Committee for issues exceeding the PMO's decision rights or that require strategic guidance.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, GDPR compliance, and adherence to all relevant regulations.  Critical given the sensitive nature of the data involved and the potential for reputational risk.

**Responsibilities:**

- Oversee all aspects of data privacy and GDPR compliance.
- Develop and implement data security policies and procedures.
- Conduct regular data privacy impact assessments (DPIAs).
- Provide training on GDPR compliance to all project staff and volunteers.
- Investigate any reported breaches of data privacy or ethical conduct.
- Ensure compliance with all relevant regulations and policies.
- Review and approve all data sharing agreements.
- Monitor ethical considerations related to outreach activities and home interventions.
- Oversee the whistleblower mechanism and ensure protection of whistleblowers.
- Review and approve all communication materials to ensure accuracy and ethical messaging.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol.
- Develop a data privacy policy.
- Establish a whistleblower mechanism.
- Conduct an initial data privacy impact assessment.

**Membership:**

- Legal Counsel (Chair)
- Data Protection Officer
- Ethics Officer (if available, otherwise a senior municipal official with relevant experience)
- Independent Expert in GDPR and Data Privacy (External)
- Representative from a local NGO working with vulnerable populations

**Decision Rights:** Approves all data sharing agreements, data privacy policies, and ethical guidelines.  Has the authority to halt any project activity that is deemed to be in violation of GDPR or ethical standards.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Legal Counsel has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly, with ad hoc meetings as needed for critical decisions or escalations.

**Typical Agenda Items:**

- Review of data privacy impact assessments.
- Discussion of any reported breaches of data privacy or ethical conduct.
- Review of data sharing agreements.
- Review of data security policies and procedures.
- Review of training materials on GDPR compliance.
- Review of communication materials to ensure accuracy and ethical messaging.
- Review of whistleblower reports and investigations.

**Escalation Path:** To the Mayor's Office and relevant regulatory authorities for serious breaches of GDPR or ethical standards.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert advice on technical aspects of the project, including cooling center design, home intervention strategies, and communication systems. Ensures interventions are effective and safe.

**Responsibilities:**

- Provide expert advice on cooling center design and operation.
- Evaluate the effectiveness and safety of home intervention strategies.
- Advise on the selection of appropriate communication channels and messaging.
- Provide technical support for the development and implementation of the project's data management system.
- Review and approve technical specifications for procurement activities.
- Advise on the integration of the project with existing health systems.
- Provide technical guidance on the development of the Heat Response Playbook.
- Assess the environmental impact of the project and recommend mitigation strategies.
- Advise on the development of surge capacity plans.

**Initial Setup Actions:**

- Finalize Terms of Reference and operating procedures.
- Appoint a chairperson.
- Establish a communication protocol.
- Review the project plan and provide technical feedback.
- Identify key technical challenges and opportunities.

**Membership:**

- Engineer specializing in building design and energy efficiency
- Public Health Expert specializing in heat-related illness
- Communications Specialist
- IT Specialist specializing in data management and security
- Representative from the local energy utility
- Representative from a local housing association

**Decision Rights:** Provides recommendations on technical aspects of the project.  The PMO is responsible for implementing these recommendations, subject to budget and other constraints.  The Steering Committee has final approval on any significant changes to the project plan based on technical advice.

**Decision Mechanism:** Decisions are made by consensus. In the event of a disagreement, the chairperson facilitates a discussion to reach a mutually acceptable solution. If consensus cannot be reached, the issue is escalated to the Steering Committee.

**Meeting Cadence:** Monthly, with ad hoc meetings as needed for specific technical issues.

**Typical Agenda Items:**

- Review of cooling center design and operation.
- Evaluation of home intervention strategies.
- Discussion of communication channels and messaging.
- Review of the project's data management system.
- Review of technical specifications for procurement activities.
- Discussion of the integration of the project with existing health systems.
- Review of the Heat Response Playbook.
- Discussion of the environmental impact of the project.
- Review of surge capacity plans.

**Escalation Path:** To the Project Steering Committee for technical issues that cannot be resolved by the Technical Advisory Group or that have significant budget or strategic implications.