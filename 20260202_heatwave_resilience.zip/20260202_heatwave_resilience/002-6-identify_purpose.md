**Purpose:** business

**Purpose Detailed:** Development of a municipal program to reduce heatwave-related mortality and illness, including infrastructure, outreach, and health system coordination.

**Topic:** Heatwave Mortality Reduction Program in a European City