### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager circulates Draft SteerCo ToR for review by nominated members (Chief Resilience Officer, Director of Public Health, Director of Social Services, Director of Emergency Services, Chief Financial Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback

### 4. Senior Management (e.g., Mayor's Office) formally appoints the Chief Resilience Officer as the Steering Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize operating procedures, and establish communication protocols.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 7. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 8. Project Manager circulates Draft Ethics & Compliance Committee ToR for review by Legal Counsel, Data Protection Officer, and Ethics Officer (or senior municipal official).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 9. Project Manager incorporates feedback and finalizes the Ethics & Compliance Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback

### 10. Senior Management (e.g., Mayor's Office) formally appoints the Legal Counsel as the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 11. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 12. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project plan, finalize operating procedures, develop a data privacy policy, and establish a whistleblower mechanism.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Data Privacy Policy v0.1
- Whistleblower Mechanism Established

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 13. Project Manager initiates setup of the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Setup Plan

**Dependencies:**


### 14. Project Manager establishes project management processes and procedures, a communication plan, and project tracking/reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Processes & Procedures Document
- Communication Plan v0.1
- Project Tracking & Reporting System Established

**Dependencies:**

- PMO Setup Plan

### 15. Project Manager recruits and trains PMO staff (Finance Officer, Procurement Officer, Communications Officer, Data Analyst, Community Liaison Officer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Staff Hired
- Training Completion Records

**Dependencies:**

- Project Management Processes & Procedures Document

### 16. Hold the initial PMO kick-off meeting to review project plan, assign initial tasks, and establish reporting cadence.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Task Assignments

**Dependencies:**

- PMO Staff Hired

### 17. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**


### 18. Project Manager circulates Draft Technical Advisory Group ToR for review by potential members (Engineer, Public Health Expert, Communications Specialist, IT Specialist, Utility Representative, Housing Association Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 19. Project Manager incorporates feedback and finalizes the Technical Advisory Group ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Review Feedback

### 20. Project Steering Committee formally appoints the Technical Advisory Group Chair (based on nominations facilitated by the Project Manager).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 21. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 22. Hold the initial Technical Advisory Group kick-off meeting to review the project plan and identify key technical challenges and opportunities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Technical Challenges and Opportunities Report v0.1

**Dependencies:**

- Meeting Invitation
- Meeting Agenda