**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority of €10,000 per transaction and may impact overall budget allocation.
Negative Consequences: Potential budget overruns, delays in critical activities, and failure to meet project goals.

**Critical Risk Materialization (e.g., GDPR breach)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation
Rationale: Requires immediate assessment and action due to potential legal, financial, and reputational damage.
Negative Consequences: Fines, legal action, loss of public trust, and project shutdown.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision
Rationale: Inability to agree on a vendor impacts project timelines and requires higher-level arbitration.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and project inefficiencies.

**Proposed Major Scope Change (e.g., adding a new intervention)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Significant scope changes impact budget, timelines, and resource allocation, requiring strategic re-evaluation.
Negative Consequences: Budget overruns, delays, reduced effectiveness of existing interventions, and failure to meet project goals.

**Technical Advisory Group disagreement on a key technical aspect**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision based on TAG recommendations and PMO assessment
Rationale: Technical disagreements can impact the safety and effectiveness of interventions, requiring a strategic decision.
Negative Consequences: Implementation of unsafe or ineffective interventions, potential harm to vulnerable populations, and project failure.

**Reported Ethical Concern (e.g., conflict of interest)**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation
Rationale: Requires independent review and action to maintain ethical standards and public trust.
Negative Consequences: Reputational damage, legal action, loss of stakeholder trust, and project shutdown.