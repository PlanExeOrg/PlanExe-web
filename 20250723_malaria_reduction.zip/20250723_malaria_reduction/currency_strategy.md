This plan involves money.

## Currencies

- **GHS:** Local currency for transactions within Ghana.
- **USD:** Stable international currency for budgeting and potentially for larger transactions, given the halt of USAID funding.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. GHS will be used for local transactions. Given the halt of USAID funding, a stable currency like USD will help ensure financial stability for the project.