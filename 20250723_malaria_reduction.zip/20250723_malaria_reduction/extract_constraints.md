## Positive Constraints

- Location: Accra, Ghana
- Project start ASAP
