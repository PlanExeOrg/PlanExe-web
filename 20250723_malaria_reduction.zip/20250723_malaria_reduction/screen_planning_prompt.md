**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete problem (malaria resurgence) and a location (Accra, Ghana), implying a project to address the issue. The prompt also includes a start date, providing enough information to generate a plan.