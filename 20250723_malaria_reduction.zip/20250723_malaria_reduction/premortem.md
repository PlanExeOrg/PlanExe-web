A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Community members will consistently use insecticide-treated bed nets (ITNs) as instructed. | Conduct unannounced household visits to observe bed net usage during sleeping hours. | Less than 75% of households with ITNs are observed using them properly during sleeping hours. |
| A2 | The cost of procuring and distributing insecticide-treated bed nets (ITNs) will remain stable throughout the project duration. | Obtain price quotes from at least three different ITN suppliers and factor in transportation costs. | The total cost per ITN (including procurement and distribution) exceeds the budgeted amount by more than 10%. |
| A3 | Local healthcare workers have sufficient capacity and resources to effectively manage malaria cases. | Conduct a survey of local healthcare facilities to assess staffing levels, equipment availability, and training needs. | More than 50% of healthcare facilities report shortages of essential malaria diagnostic tools or treatment medications. |
| A4 | The political climate in Ghana will remain stable and supportive of the malaria prevention project throughout its duration. | Monitor political news and government policy announcements related to healthcare and foreign aid. | A major political upheaval or policy change significantly disrupts project activities or funding. |
| A5 | The project's chosen mobile data collection platform will function reliably in remote areas with limited internet connectivity. | Conduct field tests of the mobile data collection platform in representative remote areas. | The mobile data collection platform fails to transmit data successfully in more than 20% of field tests. |
| A6 | Local communities will readily accept and trust community health workers (CHWs) as reliable sources of health information and assistance. | Conduct initial community meetings to gauge acceptance and trust levels towards CHWs. | Community members express significant distrust or resistance towards CHWs in more than 30% of initial meetings. |
| A7 | The project's chosen insecticide for indoor residual spraying (IRS) will remain effective against local mosquito populations throughout the spraying campaign. | Conduct pre-spraying insecticide susceptibility testing on local mosquito populations. | Insecticide susceptibility testing reveals significant resistance to the chosen insecticide in more than 20% of mosquito samples. |
| A8 | The project will be able to secure the necessary import permits and customs clearances for essential commodities (ITNs, RDTs, medications) in a timely manner. | Submit a sample import permit application and track the processing time. | The sample import permit application takes longer than 30 days to be approved. |
| A9 | Community members will consistently adhere to prescribed antimalarial medication regimens. | Conduct a pilot study to assess adherence rates to antimalarial medication regimens. | Adherence rates to prescribed antimalarial medication regimens fall below 70% in the pilot study. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Net Nightmare | Process/Financial | A2 | Project Manager | CRITICAL (20/25) |
| FM2 | The Overwhelmed Outpost | Technical/Logistical | A3 | Medical Officer | HIGH (12/25) |
| FM3 | The Discarded Defense | Market/Human | A1 | Community Engagement Specialist | CRITICAL (16/25) |
| FM4 | The Shifting Sands of Governance | Process/Financial | A4 | Project Manager | CRITICAL (15/25) |
| FM5 | The Silent Signals | Technical/Logistical | A5 | Data Analyst | CRITICAL (16/25) |
| FM6 | The Whispers of Distrust | Market/Human | A6 | Community Engagement Specialist | HIGH (12/25) |
| FM7 | The Spray That Failed | Technical/Logistical | A7 | Medical Officer | CRITICAL (15/25) |
| FM8 | The Customs Quagmire | Process/Financial | A8 | Logistics and Supply Chain Manager | CRITICAL (16/25) |
| FM9 | The Unfinished Course | Market/Human | A9 | Community Engagement Specialist | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Empty Net Nightmare

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial model hinges on stable ITN procurement costs. However, unforeseen global events (e.g., raw material shortages, increased demand due to outbreaks elsewhere) drive up ITN prices. The project, locked into initial budget projections, cannot afford the planned quantity of nets. Distribution targets are slashed, prioritizing only the highest-risk areas. Lower-risk regions, initially slated for blanket coverage, receive significantly fewer nets, creating resentment and undermining community buy-in. The project struggles to meet its malaria reduction goals, and donors become hesitant to provide further funding, jeopardizing long-term sustainability.

Contributing factors include a lack of price hedging strategies and failure to diversify ITN suppliers. The impact is a significant reduction in the number of people protected, leading to a resurgence of malaria cases and a loss of credibility for the project. The project's reputation suffers, making it difficult to secure future funding or partnerships.

##### Early Warning Signs
- ITN supplier quotes increase by more than 5% compared to initial estimates.
- Transportation costs for ITNs increase unexpectedly due to fuel price hikes.
- Global news reports indicate shortages of raw materials used in ITN production.

##### Tripwires
- Average ITN procurement cost exceeds $3.00 per net.
- Transportation costs per ITN increase by more than 15%.
- Total ITN order quantity is reduced by more than 20% due to budget constraints.

##### Response Playbook
- Contain: Immediately freeze all non-essential project spending.
- Assess: Conduct a thorough review of the budget and identify potential cost-saving measures.
- Respond: Negotiate with ITN suppliers for better pricing or explore alternative, lower-cost ITN options.


**STOP RULE:** The project is unable to procure at least 70% of the originally planned ITN quantity due to budget constraints.

---

#### FM2 - The Overwhelmed Outpost

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Medical Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes local healthcare workers are adequately equipped to handle malaria cases. However, remote clinics are understaffed and lack essential diagnostic tools and medications. When the ITN distribution leads to increased awareness and testing, the clinics are overwhelmed. Healthcare workers, lacking sufficient training and resources, struggle to accurately diagnose and treat patients. Misdiagnosis leads to inappropriate treatment, contributing to drug resistance and eroding community trust. Logistical bottlenecks prevent timely replenishment of supplies, resulting in stockouts of antimalarial drugs. The healthcare system, already strained, buckles under the increased demand, negating the positive impact of the ITN distribution.

Contributing factors include inadequate needs assessment of healthcare facilities and a failure to provide sufficient training and support to healthcare workers. The impact is a decline in the quality of care, increased drug resistance, and a loss of confidence in the healthcare system.

##### Early Warning Signs
- Healthcare facilities report stockouts of essential malaria medications for more than 3 days.
- Healthcare workers report feeling overwhelmed by the increased patient load.
- Patient wait times at clinics exceed 2 hours.

##### Tripwires
- Stockouts of artemisinin-based combination therapies (ACTs) exceed 5% of healthcare facilities.
- Average patient wait time for malaria diagnosis and treatment exceeds 120 minutes.
- Healthcare worker-to-patient ratio exceeds 1:500 in more than 20% of facilities.

##### Response Playbook
- Contain: Immediately divert resources to address the most critical shortages of medications and diagnostic tools.
- Assess: Conduct a rapid assessment of healthcare facility capacity and resource needs.
- Respond: Deploy mobile health clinics to provide temporary support to overwhelmed facilities and expedite the delivery of essential supplies.


**STOP RULE:** More than 10% of healthcare facilities experience stockouts of essential malaria medications for more than 7 consecutive days.

---

#### FM3 - The Discarded Defense

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Community Engagement Specialist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes consistent ITN usage. However, community members, despite receiving nets, fail to use them properly or at all. Some believe the nets are ineffective or uncomfortable. Others repurpose them for fishing or agricultural use. Misinformation spreads regarding the safety of the insecticide, fueled by social media and distrust of external interventions. Mosquitoes adapt their biting behavior, shifting to daytime hours when people are not under nets. Malaria transmission continues unabated, and the project's impact is significantly diminished. The community, disillusioned by the lack of results, becomes resistant to future interventions.

Contributing factors include a lack of culturally sensitive health education and a failure to address community concerns and misconceptions. The impact is a waste of resources, continued malaria transmission, and a loss of trust in public health initiatives.

##### Early Warning Signs
- Community surveys reveal that less than 80% of households with ITNs are using them regularly.
- Reports emerge of ITNs being used for purposes other than malaria prevention.
- Social media posts express concerns about the safety or effectiveness of ITNs.

##### Tripwires
- Household surveys indicate that less than 60% of individuals sleep under ITNs regularly.
- More than 10% of ITNs are observed being used for non-intended purposes (e.g., fishing nets).
- Social media sentiment analysis reveals a negative perception of ITNs exceeding 40%.

##### Response Playbook
- Contain: Immediately launch a targeted health education campaign to address community concerns and promote proper ITN usage.
- Assess: Conduct focus group discussions to understand the reasons behind low ITN usage.
- Respond: Partner with community leaders and trusted figures to disseminate accurate information and encourage ITN adoption.


**STOP RULE:** Household surveys consistently show that less than 50% of individuals sleep under ITNs regularly for two consecutive quarters.

---

#### FM4 - The Shifting Sands of Governance

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's success hinges on a stable political environment. However, a sudden shift in government priorities, perhaps due to an election or economic crisis, leads to a redirection of resources away from public health initiatives. The Ministry of Health, previously a strong supporter, faces budget cuts and is forced to reduce its collaboration with the project. Key personnel are reassigned, and bureaucratic hurdles increase. The project, struggling to navigate the new political landscape, experiences significant delays in obtaining permits and approvals. Funding from local sources dries up as businesses become hesitant to invest in long-term projects amidst political uncertainty. The project, once a beacon of hope, slowly grinds to a halt, unable to adapt to the changing political climate.

Contributing factors include a lack of contingency planning for political instability and a failure to diversify stakeholder relationships beyond the Ministry of Health. The impact is a significant reduction in project scope, a loss of momentum, and a failure to achieve its malaria reduction goals.

##### Early Warning Signs
- Public statements from government officials indicate a shift in priorities away from public health.
- Key personnel within the Ministry of Health are reassigned to other departments.
- The project experiences significant delays in obtaining necessary permits and approvals.

##### Tripwires
- Government funding for malaria control is reduced by more than 15%.
- Key permits and approvals are delayed by more than 60 days.
- The Ministry of Health withdraws its formal endorsement of the project.

##### Response Playbook
- Contain: Immediately engage with key government stakeholders to understand the reasons behind the shift in priorities and advocate for continued support.
- Assess: Conduct a thorough assessment of the potential impact of the political changes on the project's activities and funding.
- Respond: Develop a revised project plan that adapts to the new political landscape, potentially focusing on smaller-scale, community-based interventions.


**STOP RULE:** The government formally withdraws its support for the project, making it impossible to continue operations.

---

#### FM5 - The Silent Signals

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Data Analyst
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project relies heavily on mobile data collection for real-time monitoring and adaptive management. However, the chosen platform proves unreliable in remote areas with poor internet connectivity. Community health workers (CHWs), unable to transmit data consistently, resort to paper-based methods, leading to delays and errors. The centralized surveillance database becomes incomplete and outdated, hindering the project's ability to identify outbreaks and allocate resources effectively. Decision-making becomes reactive rather than proactive, and the project loses its ability to respond quickly to emerging challenges. The lack of reliable data undermines the project's credibility and erodes trust among stakeholders.

Contributing factors include inadequate testing of the mobile data collection platform in real-world conditions and a failure to provide alternative data collection methods. The impact is a loss of situational awareness, inefficient resource allocation, and a reduced ability to achieve its malaria reduction goals.

##### Early Warning Signs
- CHWs report frequent difficulties transmitting data from remote areas.
- The centralized surveillance database shows significant gaps in data from certain regions.
- Data validation checks reveal a high error rate in data collected using the mobile platform.

##### Tripwires
- Data transmission success rate from remote areas falls below 70%.
- More than 25% of data entries require manual correction due to errors.
- The centralized surveillance database is more than 7 days out of date.

##### Response Playbook
- Contain: Immediately implement a backup data collection system using paper-based forms and manual data entry.
- Assess: Conduct a thorough evaluation of alternative mobile data collection platforms that are better suited for low-connectivity environments.
- Respond: Transition to a more reliable mobile data collection platform or invest in improving internet connectivity in remote areas.


**STOP RULE:** The centralized surveillance database consistently lacks reliable data from more than 30% of the target regions for two consecutive months.

---

#### FM6 - The Whispers of Distrust

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Community Engagement Specialist
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The project assumes that local communities will readily accept and trust CHWs. However, cultural barriers, historical distrust of outsiders, or misinformation campaigns undermine the CHWs' credibility. Community members are hesitant to share information or follow their advice. CHWs, facing resistance and hostility, become demoralized and less effective. Rumors spread that the CHWs are spies or are promoting harmful practices. The project's community engagement efforts falter, and the distribution of ITNs and other interventions is hampered. Malaria transmission continues unabated, and the project's impact is minimal. The community, feeling alienated and unheard, becomes even more resistant to future interventions.

Contributing factors include a lack of culturally sensitive training for CHWs and a failure to address community concerns and misconceptions proactively. The impact is a breakdown in communication, a loss of trust, and a failure to achieve its community engagement goals.

##### Early Warning Signs
- CHWs report experiencing hostility or resistance from community members.
- Attendance at community meetings and health education sessions is low.
- Rumors and misinformation about the project are circulating within the community.

##### Tripwires
- CHWs report experiencing verbal abuse or threats in more than 10% of their interactions with community members.
- Attendance at community meetings falls below 50% of the target population.
- Social media sentiment analysis reveals a negative perception of CHWs exceeding 30%.

##### Response Playbook
- Contain: Immediately launch a targeted campaign to build trust and address community concerns, involving respected community leaders and trusted figures.
- Assess: Conduct focus group discussions to understand the reasons behind the distrust and resistance towards CHWs.
- Respond: Revise the CHW training program to include more culturally sensitive communication techniques and provide CHWs with additional support and resources.


**STOP RULE:** Community surveys consistently show that less than 40% of community members trust CHWs as reliable sources of health information for two consecutive quarters.

---

#### FM7 - The Spray That Failed

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Medical Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's IRS campaign is a cornerstone of its vector control strategy. However, pre-spraying insecticide susceptibility testing is overlooked due to logistical constraints and time pressure. The chosen insecticide, while effective in other regions, proves ineffective against local mosquito populations due to evolving resistance. The IRS campaign, launched with great fanfare, fails to significantly reduce mosquito populations or malaria transmission rates. Community members, witnessing the ineffectiveness of the spraying, lose faith in the project and become less receptive to other interventions. The project, having invested heavily in a failed strategy, struggles to adapt and faces mounting criticism from stakeholders.

Contributing factors include a lack of due diligence in assessing local insecticide resistance profiles and a failure to implement a robust monitoring and evaluation system. The impact is a waste of resources, continued malaria transmission, and a loss of credibility for the project.

##### Early Warning Signs
- Mosquito populations in sprayed areas do not decline significantly after IRS application.
- Malaria incidence rates in sprayed areas remain unchanged or increase.
- Community members express dissatisfaction with the effectiveness of the IRS campaign.

##### Tripwires
- Mosquito density reduction after IRS application is less than 50%.
- Malaria incidence rates in sprayed areas do not decrease by at least 20% within 3 months.
- Community satisfaction with the IRS campaign falls below 60% in post-spraying surveys.

##### Response Playbook
- Contain: Immediately halt the IRS campaign and conduct a thorough assessment of insecticide resistance profiles in the target areas.
- Assess: Evaluate alternative insecticides that are effective against local mosquito populations.
- Respond: Implement a revised vector control strategy using alternative insecticides or other vector control methods.


**STOP RULE:** Insecticide susceptibility testing confirms widespread resistance to all available and affordable insecticides, making IRS an ineffective vector control strategy.

---

#### FM8 - The Customs Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Logistics and Supply Chain Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes timely import permits and customs clearances for essential commodities. However, bureaucratic delays and unforeseen regulatory hurdles bog down the import process. ITNs, RDTs, and antimalarial medications are held up at customs for weeks, leading to stockouts at healthcare facilities and in the community. The project, unable to deliver essential interventions, faces mounting criticism from stakeholders and loses credibility with the community. The delayed arrival of supplies disrupts the project's timeline and budget, forcing it to scale back its activities and reduce its impact. The project, once poised for success, becomes entangled in a web of red tape, unable to fulfill its promises.

Contributing factors include a lack of proactive engagement with customs officials and a failure to anticipate potential regulatory challenges. The impact is a disruption of essential interventions, a loss of trust, and a reduced ability to achieve its malaria reduction goals.

##### Early Warning Signs
- Import permit applications take longer than 2 weeks to be processed.
- Shipments of essential commodities are held up at customs for more than 7 days.
- Healthcare facilities report stockouts of essential malaria medications or diagnostic tools.

##### Tripwires
- Import permit applications exceed 30 days for approval.
- Shipments of essential commodities are held up at customs for more than 14 days.
- Stockouts of essential malaria medications or diagnostic tools exceed 10% of healthcare facilities.

##### Response Playbook
- Contain: Immediately engage with customs officials to expedite the clearance of essential commodities.
- Assess: Identify the root causes of the delays and develop strategies to address them.
- Respond: Establish a streamlined import process with pre-approved permits and dedicated customs liaisons.


**STOP RULE:** The project is unable to secure the release of essential commodities from customs within 30 days, jeopardizing the timely implementation of critical interventions.

---

#### FM9 - The Unfinished Course

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Community Engagement Specialist
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes consistent adherence to prescribed antimalarial medication regimens. However, community members, due to cultural beliefs, side effects, or lack of understanding, fail to complete the full course of treatment. Some stop taking the medication as soon as they feel better, while others share their medication with family members or friends. Incomplete treatment leads to drug resistance, making future infections more difficult to treat. The project, despite providing access to effective medications, fails to achieve its desired impact due to poor adherence. The community, witnessing the emergence of drug-resistant malaria, loses faith in the effectiveness of the treatment and becomes less likely to seek medical care in the future.

Contributing factors include a lack of culturally sensitive health education and a failure to address community concerns and misconceptions about antimalarial medications. The impact is increased drug resistance, prolonged illness, and a loss of trust in the healthcare system.

##### Early Warning Signs
- Healthcare workers report that many patients are not completing their prescribed antimalarial medication regimens.
- Drug resistance rates to commonly used antimalarial medications begin to increase.
- Community members express concerns about the side effects or effectiveness of antimalarial medications.

##### Tripwires
- Adherence rates to prescribed antimalarial medication regimens fall below 60% in community surveys.
- Drug resistance rates to artemisinin-based combination therapies (ACTs) increase by more than 5%.
- Community members report experiencing significant side effects from antimalarial medications in more than 20% of cases.

##### Response Playbook
- Contain: Immediately launch a targeted health education campaign to emphasize the importance of completing the full course of treatment and address community concerns about side effects.
- Assess: Conduct focus group discussions to understand the reasons behind poor adherence.
- Respond: Implement strategies to improve adherence, such as providing medication reminders, simplifying treatment regimens, and involving family members in the treatment process.


**STOP RULE:** Drug resistance rates to artemisinin-based combination therapies (ACTs) exceed 10%, rendering them ineffective as a first-line treatment option.
