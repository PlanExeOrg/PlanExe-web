### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance, crucial given the project's scale, funding constraints, and the need to adapt to the halt of USAID funding. Ensures alignment with strategic goals and effective risk management.

**Responsibilities:**

- Provide strategic direction and oversight for the project.
- Approve the project plan, budget, and any significant changes.
- Monitor project progress against strategic goals and objectives.
- Identify and manage strategic risks and issues.
- Ensure alignment with organizational policies and regulatory requirements.
- Approve budgets exceeding $100,000 USD.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Secretary.
- Establish meeting schedule and communication protocols.
- Review and approve the project charter and initial risk assessment.

**Membership:**

- Senior Management Representative (Chair)
- Project Manager
- Medical Officer
- Finance Director
- Independent External Advisor (Public Health Expert)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and risk management. Approval of budgets exceeding $100,000 USD. Decisions regarding significant deviations from the project plan.

**Decision Mechanism:** Decisions made by majority vote, with the Senior Management Representative (Chair) having the tie-breaking vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion and approval of budget revisions.
- Review and mitigation of strategic risks and issues.
- Approval of major project deliverables and milestones.
- Review of compliance with regulatory requirements.

**Escalation Path:** Senior Management Team
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, ensuring efficient resource allocation, risk management, and adherence to project plans. Essential for operational efficiency and effective communication.

**Responsibilities:**

- Develop and maintain the project plan and schedule.
- Manage project resources and budget.
- Monitor project progress and performance.
- Identify and manage operational risks and issues.
- Coordinate project activities and communication.
- Prepare and distribute project reports.
- Manage budgets below $100,000 USD.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop a communication plan.
- Define roles and responsibilities for project team members.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager (Chair)
- Medical Officer
- Community Mobilizers
- Logistics Coordinator
- Data Analyst

**Decision Rights:** Operational decisions related to project execution, resource allocation within approved budgets, and risk mitigation. Management of budgets below $100,000 USD.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the PMO team. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of project progress against the project plan.
- Discussion of operational risks and issues.
- Allocation of resources to project activities.
- Review of project budget and expenditures.
- Coordination of project team activities.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, compliance with regulations (including GDPR), and responsible use of resources. Crucial for maintaining trust and avoiding legal or reputational risks.

**Responsibilities:**

- Oversee compliance with relevant regulations, including GDPR and data privacy laws.
- Ensure ethical conduct in all project activities.
- Develop and implement policies and procedures to prevent fraud and corruption.
- Investigate and resolve ethical concerns and compliance violations.
- Provide training to project staff on ethical conduct and compliance requirements.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop a code of ethics for the project.
- Establish compliance policies and procedures.
- Set up a confidential reporting mechanism for ethical concerns.
- Conduct a risk assessment to identify potential compliance violations.

**Membership:**

- Legal Counsel (Chair)
- Compliance Officer
- Independent Ethics Advisor
- Community Representative

**Decision Rights:** Decisions related to ethical conduct, compliance with regulations, and prevention of fraud and corruption. Authority to investigate and resolve ethical concerns and compliance violations.

**Decision Mechanism:** Decisions made by majority vote, with the Legal Counsel (Chair) having the tie-breaking vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of compliance with relevant regulations.
- Discussion of ethical concerns and compliance violations.
- Review of policies and procedures to prevent fraud and corruption.
- Training of project staff on ethical conduct and compliance requirements.
- Review of whistleblower reports and investigations.

**Escalation Path:** Senior Management Team
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert technical advice on malaria prevention and treatment strategies, ensuring the project uses the most effective and up-to-date methods. Essential for maximizing impact and adapting to evolving challenges like insecticide resistance.

**Responsibilities:**

- Provide technical guidance on malaria prevention and treatment strategies.
- Review and evaluate the effectiveness of project interventions.
- Advise on the selection of appropriate vector control methods.
- Monitor insecticide resistance and recommend mitigation strategies.
- Provide training to project staff on technical aspects of malaria control.
- Review and approve technical reports and publications.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the scope of the advisory group's responsibilities.
- Establish communication protocols.
- Review existing malaria control strategies and identify areas for improvement.

**Membership:**

- Medical Officer (Chair)
- Entomologist
- Public Health Specialist
- Malaria Control Expert (External)
- Data Analyst

**Decision Rights:** Recommendations on technical aspects of malaria prevention and treatment strategies. Approval of technical reports and publications.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Medical Officer (Chair) makes the final decision, considering the input from all members.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of malaria incidence and prevalence data.
- Discussion of vector control methods and insecticide resistance.
- Evaluation of the effectiveness of project interventions.
- Training of project staff on technical aspects of malaria control.
- Review of technical reports and publications.

**Escalation Path:** Project Steering Committee
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and collaboration with all stakeholders, including local communities, government agencies, and partner organizations. Crucial for building trust, fostering community buy-in, and ensuring the project aligns with local needs and priorities.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with local communities.
- Establish partnerships with government agencies and partner organizations.
- Disseminate project information to stakeholders.
- Address stakeholder concerns and feedback.
- Monitor stakeholder satisfaction.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a communication strategy.
- Establish channels for stakeholder feedback.
- Conduct a stakeholder analysis to understand their needs and priorities.

**Membership:**

- Community Mobilizers (Co-Chairs)
- Communications Officer
- Community Representatives
- Representative from Ghana Health Service

**Decision Rights:** Recommendations on stakeholder engagement strategies. Approval of communication materials.

**Decision Mechanism:** Decisions made by consensus. If consensus cannot be reached, the Community Mobilizers (Co-Chairs) make the final decision, considering the input from all members.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Development of communication materials.
- Planning of community consultations.
- Monitoring of stakeholder satisfaction.

**Escalation Path:** Project Steering Committee