### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Manager circulates Draft SteerCo ToR for review by nominated members (Senior Management Representative, Medical Officer, Finance Director, Independent External Advisor).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulated Draft SteerCo ToR
- Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback and finalizes the SteerCo ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback from Nominated Members

### 4. Senior Management formally appoints the Chair of the Project Steering Committee (Senior Management Representative).

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager formally appoints the Secretary of the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project plan, budget, and initial risk assessment.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 8. Project Manager drafts initial project management processes and tools for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Processes and Tools v0.1

**Dependencies:**


### 9. Project Manager develops a communication plan for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO Communication Plan v0.1

**Dependencies:**


### 10. Project Manager defines roles and responsibilities for project team members within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Defined Roles and Responsibilities Document v1.0

**Dependencies:**


### 11. Project Manager sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting Templates

**Dependencies:**


### 12. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Defined Roles and Responsibilities Document v1.0

### 13. Hold the initial Project Management Office (PMO) kick-off meeting to review project progress and assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 14. Legal Counsel drafts initial code of ethics for the project.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Code of Ethics v0.1

**Dependencies:**


### 15. Compliance Officer establishes initial compliance policies and procedures.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Compliance Policies and Procedures v0.1

**Dependencies:**


### 16. Compliance Officer sets up a confidential reporting mechanism for ethical concerns.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Confidential Reporting System

**Dependencies:**

- Draft Compliance Policies and Procedures v0.1

### 17. Compliance Officer conducts a risk assessment to identify potential compliance violations.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Compliance Risk Assessment Report v1.0

**Dependencies:**

- Draft Compliance Policies and Procedures v0.1

### 18. Project Manager schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Compliance Risk Assessment Report v1.0

### 19. Hold the initial Ethics and Compliance Committee kick-off meeting to review compliance, ethics, and reporting mechanisms.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 20. Medical Officer identifies and recruits technical experts for the Technical Advisory Group.

**Responsible Body/Role:** Medical Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of Technical Experts
- Recruitment Invitations

**Dependencies:**


### 21. Medical Officer defines the scope of the Technical Advisory Group's responsibilities.

**Responsible Body/Role:** Medical Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Defined Scope of Responsibilities v1.0

**Dependencies:**

- List of Technical Experts

### 22. Medical Officer establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Medical Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Communication Protocols Document v1.0

**Dependencies:**

- Defined Scope of Responsibilities v1.0

### 23. Medical Officer schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Medical Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Communication Protocols Document v1.0

### 24. Hold the initial Technical Advisory Group kick-off meeting to review existing malaria control strategies and identify areas for improvement.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda

### 25. Community Mobilizers identify key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Community Mobilizers

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**


### 26. Communications Officer develops a communication strategy for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Communication Strategy v0.1

**Dependencies:**

- List of Key Stakeholders

### 27. Community Mobilizers establish channels for stakeholder feedback.

**Responsible Body/Role:** Community Mobilizers

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Feedback Channels

**Dependencies:**

- Draft Communication Strategy v0.1

### 28. Community Mobilizers conduct a stakeholder analysis to understand their needs and priorities.

**Responsible Body/Role:** Community Mobilizers

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Analysis Report v1.0

**Dependencies:**

- Stakeholder Feedback Channels

### 29. Project Manager schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Stakeholder Analysis Report v1.0

### 30. Hold the initial Stakeholder Engagement Group kick-off meeting to review stakeholder engagement activities and feedback mechanisms.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Meeting Agenda