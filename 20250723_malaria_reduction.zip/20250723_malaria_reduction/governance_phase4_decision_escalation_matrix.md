**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight.
Negative Consequences: Potential for budget overruns and misalignment with strategic priorities.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, and failure to achieve project goals.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to ensure project progress.
Negative Consequences: Delays in procurement, potential for suboptimal vendor selection, and project delays.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significantly impacts project objectives, budget, and timeline, requiring strategic alignment.
Negative Consequences: Scope creep, budget overruns, and failure to deliver intended benefits.

**Reported Ethical Concern**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Senior Management Team
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Reputational damage, legal penalties, and loss of stakeholder trust.

**Technical Advisory Group cannot agree on Vector Control Methods**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to ensure project progress.
Negative Consequences: Delays in vector control implementation, potential for suboptimal method selection, and project delays.