**Purpose:** business

**Purpose Detailed:** Societal welfare project to combat malaria resurgence due to funding cuts.

**Topic:** Malaria prevention project in Ghana after USAID halt