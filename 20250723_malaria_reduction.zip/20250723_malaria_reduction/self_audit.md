Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on malaria prevention through established methods (bed nets, spraying, community health workers) and does not require violating any laws of physics. The plan involves economics/governance/engineering scale, which are out of scope.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines product (malaria interventions) + market (Ghana) + tech/process (community health) + policy (funding shift) without evidence at comparable scale. There is no independent evidence showing this combination working, and failure would be existential.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Manager: Produce validation report / 2025-12-31.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action (inputs→process→customer value), owner, and measurable outcomes are defined for the strategic concepts driving the plan. The plan mentions 'Builder's Foundation' but lacks a one-pager defining its value hypothesis.

**Mitigation**: Project Manager: Create one-pagers for each strategic concept (e.g., Builder's Foundation) with value hypotheses, success metrics, and decision hooks by 2025-08-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies risks (financial, supply chain, community engagement) but lacks explicit analysis of second-order effects or cascade mapping. For example, 'Insufficient funding leads to delays' but doesn't detail the cascade.

**Mitigation**: Project Manager: Expand the risk register to map cascades (e.g., funding delay → bed net shortage → malaria increase) and add controls with a dated review cadence by 2025-09-30.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies regulatory & permitting delays as a risk, but the timeline does not include a permit/approval matrix with lead times. "Delays (2-4 weeks), increased costs. Potential fines." is insufficient.

**Mitigation**: Project Manager: Create a permit/approval matrix with required permits, lead times in the jurisdiction, and responsible parties by 2025-08-31.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a $5M budget without specifying sources, drawdowns, or covenants. "Funding sources: philanthropic organizations, private donors, government grants" lacks detail. Runway length is undefined. This creates a likely failure mode.

**Mitigation**: Project Manager: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and NO-GO gates on missed financing by 2025-08-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $5 million annually lacks substantiation via benchmarks or vendor quotes normalized by area. The plan does not provide any cost per m²/ft² calculations or comparable project data.

**Mitigation**: Project Manager: Obtain ≥3 relevant comparables, normalize costs per area (m²/ft²), and adjust the budget or de-scope by 2025-09-30.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents a goal to "Reduce malaria cases by 30% in targeted regions within 3 years" without providing a range or discussing alternative scenarios. This single-point projection lacks contingency planning.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or best/worst/base-case scenario analysis for the malaria case reduction projection by 2025-08-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions "insecticide-treated bed net distribution, indoor residual spraying, malaria testing and treatment, health education campaigns" but lacks technical specifications.

**Mitigation**: Medical Officer: Produce technical specifications, interface definitions, test plans, and an integration map with owners/dates for each build-critical component by 2025-09-30.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "Total budget: $5 million over 3 years" without evidence of commitment from funding sources. There is no term sheet, letter of intent, or grant award notice.

**Mitigation**: Project Manager: Obtain letters of intent from funding sources for at least 80% of the $5 million budget or de-scope the project by 2025-10-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Reduce malaria cases by 30% in targeted regions within 3 years" without specific, verifiable qualities. The deliverable is abstract.

**Mitigation**: Project Manager: Define SMART criteria for malaria case reduction, including a KPI for confirmed cases (e.g., confirmed malaria cases < X per 1,000 people) by 2025-08-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Cross-Border Collaboration Initiatives'. While potentially beneficial, it does not directly support the core goals of reducing malaria cases and strengthening local healthcare capacity within Ghana. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Cross-Border Collaboration Initiatives', complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2025-08-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Project Lead / Coordinator' to provide overall direction, coordination, and ensure alignment with strategic goals. This role requires a rare combination of project management, public health expertise, and local knowledge.

**Mitigation**: Project Manager: Conduct a talent market analysis for the 'Project Lead / Coordinator' role, assessing the availability of qualified candidates and adjusting the project plan if needed by 2025-08-31.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lists permits from the Ghanaian Ministry of Health without a regulatory matrix (authority, artifact, lead time, predecessors). "Permits from the Ghanaian Ministry of Health for malaria interventions" is insufficient.

**Mitigation**: Legal Team: Create a regulatory matrix identifying all required permits/licenses, authorities, artifacts, lead times, and predecessors by 2025-08-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a "Sustainability Plan" but lacks specifics on funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms. The plan mentions building local capacity and advocating for government funding.

**Mitigation**: Project Manager: Develop a detailed operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by 2025-09-30.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Establish Project Infrastructure (Accra, Tamale, Ho, Kumasi)" but lacks specifics on zoning, occupancy, fire load, or structural limits. The plan does not include evidence of a fatal-flaw screen with authorities.

**Mitigation**: Project Manager: Conduct a fatal-flaw screen with local authorities in Accra, Tamale, Ho, and Kumasi to identify zoning/land-use constraints by 2025-09-30.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Establish Project Infrastructure (Accra, Tamale, Ho, Kumasi)" but lacks evidence of tested failover plans or SLAs with vendors for data, facilities, or key services. The plan does not describe redundancy.

**Mitigation**: Project Manager: Secure SLAs with vendors for data, facilities, and key services, and test failover procedures by 2025-10-31.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for 'Ghana Health Service' and 'Community Mobilizers' but does not address their conflicting incentives. GHS may prioritize national standards, while Community Mobilizers focus on local needs.

**Mitigation**: Project Manager: Define a shared OKR (Objective and Key Results) focused on community health outcomes that aligns the incentives of GHS and Community Mobilizers by 2025-08-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to the project plan by 2025-08-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Insufficient funding (Risk 1) can trigger supply chain disruptions (Risk 2), leading to reduced community engagement (Risk 3) due to lack of resources and trust.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2025-09-30.