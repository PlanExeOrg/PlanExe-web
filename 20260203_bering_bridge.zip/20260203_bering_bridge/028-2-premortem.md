A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The binational steering committee will effectively manage conflicts of interest and maintain project stability. | Simulate a conflict of interest scenario within the committee and assess its ability to reach a resolution. | The committee fails to reach a consensus or a resolution is significantly delayed (more than 30 days). |
| A2 | Advanced materials will perform as expected in the extreme Arctic environment, ensuring structural integrity. | Subject sample materials to accelerated aging tests simulating Arctic conditions (temperature cycling, ice exposure, seismic stress). | Materials exhibit significant degradation (more than 10% loss of strength or integrity) within the projected lifespan. |
| A3 | There is sufficient market demand for the bridge to generate projected toll revenues. | Conduct a detailed survey of potential users (freight companies, tourists) to gauge their willingness to pay projected toll rates. | Survey indicates that less than 60% of potential users are willing to pay the projected toll rates. |
| A4 | Indigenous communities will consistently support the project, even with unforeseen environmental or social impacts. | Present a hypothetical scenario involving a moderate, negative environmental impact to Indigenous community representatives and gauge their reaction. | A majority of Indigenous community representatives express strong opposition to the project in the hypothetical scenario. |
| A5 | The necessary specialized equipment and expertise for Arctic construction and maintenance will be readily available and affordable throughout the project lifecycle. | Obtain firm quotes and availability timelines from multiple suppliers for key specialized equipment (e.g., icebreakers, permafrost drilling rigs). | Quotes exceed the budgeted amount by more than 20%, or suppliers cannot guarantee availability within the required timeframe. |
| A6 | The project will attract and retain a skilled workforce willing to work in the challenging Arctic environment. | Conduct a survey of potential workers to assess their willingness to relocate to the Arctic and work under the project's conditions (e.g., remote location, harsh climate, long work hours). | Survey indicates that less than 50% of potential workers are willing to relocate and work under the project's conditions at the offered compensation. |
| A7 | The bridge design will be adaptable to unforeseen technological advancements in transportation (e.g., Hyperloop integration, autonomous vehicle lanes). | Conduct a study assessing the feasibility and cost of integrating future transportation technologies into the current bridge design. | The study concludes that integrating future transportation technologies would require a major redesign of the bridge, increasing costs by more than 30%. |
| A8 | Insurance providers will offer affordable coverage for the project's unique risks (e.g., extreme weather, geopolitical instability, seismic activity). | Obtain firm insurance quotes from multiple providers covering the full range of project risks. | Insurance quotes exceed 5% of the total project budget, or providers exclude coverage for key risks. |
| A9 | The project will generate positive media coverage and public perception throughout its lifecycle. | Conduct a sentiment analysis of media coverage and social media discussions related to the project. | Sentiment analysis reveals a consistently negative public perception (more than 60% negative sentiment) over a 6-month period. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Gridlock Gamble | Process/Financial | A1 | Project Manager | CRITICAL (20/25) |
| FM2 | The Frostbite Fiasco | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The White Elephant Wasteland | Market/Human | A3 | Financial Officer | CRITICAL (15/25) |
| FM4 | The Broken Trust Betrayal | Market/Human | A4 | Indigenous Community Liaison | CRITICAL (20/25) |
| FM5 | The Equipment Exodus | Technical/Logistical | A5 | Logistics and Supply Chain Coordinator | CRITICAL (15/25) |
| FM6 | The Arctic Aversion | Process/Financial | A6 | Human Resources Manager | CRITICAL (15/25) |
| FM7 | The Hyperloop Hysteria | Technical/Logistical | A7 | Head of Engineering | CRITICAL (15/25) |
| FM8 | The Uninsurable Undertaking | Process/Financial | A8 | Financial Risk Manager | CRITICAL (15/25) |
| FM9 | The PR Polar Vortex | Market/Human | A9 | Public Relations Manager | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Gridlock Gamble

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The binational steering committee, intended to be the cornerstone of project governance, becomes paralyzed by escalating disputes between US and Russian representatives. Conflicting national interests, bureaucratic inertia, and a lack of clear decision-making protocols lead to gridlock on critical issues such as funding allocation, environmental regulations, and security protocols. This paralysis cascades into a series of financial setbacks. Funding tranches are delayed due to disagreements over budget priorities. Cost overruns mount as decisions on engineering adaptations are stalled. The project's credit rating is downgraded, scaring away potential private investors. The lack of progress undermines confidence in the project's financial viability, leading to a downward spiral of funding cuts and further delays. Ultimately, the project becomes financially unsustainable, and is cancelled.

##### Early Warning Signs
- Committee meetings consistently fail to reach consensus on key decisions.
- Funding disbursements are delayed by more than 60 days due to internal disputes.
- Public statements from committee members reveal conflicting viewpoints and priorities.

##### Tripwires
- Committee fails to approve a budget within 90 days of the deadline.
- Two or more member nations publicly express concerns about project governance.
- Funding disbursement is delayed by >= 90 days due to committee deadlock.

##### Response Playbook
- Contain: Immediately engage a neutral mediator to facilitate conflict resolution within the committee.
- Assess: Conduct a thorough review of the governance structure and decision-making protocols.
- Respond: Implement alternative governance mechanisms, such as an independent arbitration panel or a neutral international consortium.


**STOP RULE:** The binational steering committee is dissolved, and no viable alternative governance structure can be established within 180 days.

---

#### FM2 - The Frostbite Fiasco

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project relies heavily on advanced composite materials for the bridge's superstructure, assuming they will withstand the extreme Arctic conditions. However, after several years of exposure to temperature cycling, ice accretion, and seismic stress, the materials begin to exhibit unexpected degradation. Micro-cracks form within the composite matrix, leading to a gradual loss of structural integrity. The bridge's load-bearing capacity is compromised, forcing a reduction in traffic volume. Emergency repairs are attempted, but the specialized materials and techniques required are difficult to source and implement in the remote Arctic environment. Logistical challenges mount as supply chains are disrupted by severe weather and geopolitical tensions. The repairs prove to be ineffective, and the bridge is eventually deemed unsafe for use, leading to its closure and abandonment.

##### Early Warning Signs
- Sensors detect increasing levels of stress and strain within the bridge's superstructure.
- Routine inspections reveal the presence of micro-cracks and material degradation.
- The cost of maintenance and repairs exceeds projected levels by more than 25%.

##### Tripwires
- Stress sensors indicate a >= 15% increase in structural strain compared to baseline.
- Inspection reports reveal material degradation exceeding 10% of original specifications.
- Maintenance costs exceed $100 million in a single year.

##### Response Playbook
- Contain: Immediately reduce traffic volume by 50% to reduce stress on the structure.
- Assess: Conduct a comprehensive structural assessment to determine the extent of the damage.
- Respond: Implement a phased repair plan using alternative materials and construction techniques.


**STOP RULE:** Structural assessment reveals that more than 30% of the bridge's load-bearing capacity has been compromised, and repairs are deemed technically or financially infeasible.

---

#### FM3 - The White Elephant Wasteland

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Financial Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite optimistic projections, the actual market demand for the Bering Strait Bridge falls far short of expectations. Freight companies find alternative shipping routes to be more cost-effective. Tourism is limited by the remote location and harsh climate. The projected toll revenues fail to materialize, leaving the project struggling to meet its financial obligations. Public support wanes as the bridge becomes viewed as a costly boondoggle with little practical benefit. Geopolitical tensions further dampen enthusiasm for the project. The lack of economic viability undermines investor confidence, leading to a withdrawal of funding. The bridge becomes a 'white elephant,' a symbol of misguided ambition and wasted resources, ultimately abandoned and unused.

##### Early Warning Signs
- Traffic volume is significantly below projected levels (more than 30% deviation).
- Toll revenues are insufficient to cover operating expenses.
- Public opinion polls reveal declining support for the project.

##### Tripwires
- Average daily traffic volume is <= 50% of projected levels for 2 consecutive years.
- Annual toll revenues are <= $500 million.
- Public approval rating for the project falls below 40%.

##### Response Playbook
- Contain: Implement aggressive marketing campaigns to attract more traffic.
- Assess: Conduct a thorough review of the market analysis and revenue projections.
- Respond: Explore alternative revenue streams, such as government subsidies or private donations.


**STOP RULE:** Annual toll revenues are insufficient to cover operating expenses for 3 consecutive years, and no viable alternative revenue streams can be identified.

---

#### FM4 - The Broken Trust Betrayal

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Indigenous Community Liaison
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Despite initial agreements, a major unforeseen environmental impact occurs – a significant oil spill during construction contaminates traditional fishing grounds. Indigenous communities, feeling betrayed and unheard, withdraw their support. Protests erupt, blockading construction sites and disrupting supply chains. Legal challenges are filed, halting permitting processes. The project's reputation is severely damaged, scaring away investors and triggering government scrutiny. The loss of Indigenous support proves fatal, as the project loses its social license to operate and is ultimately abandoned amidst widespread condemnation.

##### Early Warning Signs
- Indigenous community representatives express increasing dissatisfaction with environmental monitoring reports.
- Protests begin to occur near construction sites.
- Legal challenges are filed by Indigenous groups.

##### Tripwires
- Indigenous community satisfaction scores drop below 50% in annual surveys.
- Construction is halted for >= 30 days due to protests.
- A court issues an injunction against the project based on Indigenous rights violations.

##### Response Playbook
- Contain: Immediately halt all activities that are causing environmental damage.
- Assess: Conduct a thorough investigation into the cause of the environmental impact and its effects on Indigenous communities.
- Respond: Negotiate a revised agreement with Indigenous communities, offering increased compensation, greater decision-making power, and stronger environmental protections.


**STOP RULE:** Free, Prior, and Informed Consent (FPIC) is formally withdrawn by a majority of affected Indigenous communities, and no mutually agreeable resolution can be reached within 180 days.

---

#### FM5 - The Equipment Exodus

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Logistics and Supply Chain Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's reliance on specialized Arctic construction equipment proves to be its undoing. A global surge in demand for icebreakers and permafrost drilling rigs, coupled with geopolitical instability, leads to severe shortages and skyrocketing prices. Key equipment becomes unavailable or unaffordable, causing major construction delays. Attempts to substitute with less specialized equipment prove disastrous, leading to accidents and structural flaws. The project falls hopelessly behind schedule, and costs spiral out of control. Investors lose faith, and the project is ultimately cancelled due to insurmountable logistical and technical challenges.

##### Early Warning Signs
- Lead times for specialized equipment increase dramatically.
- Prices for specialized equipment exceed budgeted amounts by more than 20%.
- Construction delays begin to accumulate due to equipment shortages.

##### Tripwires
- Key specialized equipment is unavailable for >= 90 days.
- Equipment costs exceed budgeted amounts by >= 30%.
- The project falls >= 6 months behind schedule due to equipment-related delays.

##### Response Playbook
- Contain: Immediately seek alternative suppliers and explore equipment sharing agreements with other Arctic projects.
- Assess: Conduct a thorough review of the equipment needs and identify potential substitutions.
- Respond: Redesign construction plans to reduce reliance on specialized equipment or postpone non-critical phases.


**STOP RULE:** Critical specialized equipment is unavailable for more than one year, and no viable alternatives can be found.

---

#### FM6 - The Arctic Aversion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Human Resources Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project struggles to attract and retain a skilled workforce willing to endure the harsh Arctic conditions. High turnover rates plague the construction site, leading to constant delays and increased training costs. A lack of experienced personnel results in safety lapses and construction errors. Productivity plummets as workers become demoralized by the remote location, long hours, and extreme weather. The project's reputation suffers, making it even harder to recruit qualified staff. Labor costs skyrocket, and the project becomes financially unsustainable. Investors balk at the escalating expenses, and the project is ultimately abandoned due to a critical shortage of skilled labor.

##### Early Warning Signs
- Employee turnover rates exceed projected levels by more than 50%.
- Recruitment efforts fail to attract sufficient qualified applicants.
- Productivity levels fall below acceptable thresholds.

##### Tripwires
- Employee turnover rate exceeds 75% annually.
- Vacancy rate for key skilled positions remains above 20% for >= 90 days.
- Productivity falls below 80% of projected levels for >= 3 consecutive months.

##### Response Playbook
- Contain: Immediately increase compensation and benefits packages to attract and retain workers.
- Assess: Conduct a thorough review of the working conditions and identify areas for improvement.
- Respond: Implement measures to improve worker morale, such as providing better housing, recreational facilities, and support services.


**STOP RULE:** Critical skilled positions remain unfilled for more than six months, and the project is unable to meet its construction milestones due to labor shortages.

---

#### FM7 - The Hyperloop Hysteria

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project proceeds with a conventional bridge design, neglecting the rapid advancements in transportation technology. Soon after completion, Hyperloop technology becomes commercially viable, offering significantly faster and cheaper transportation. The bridge, unable to accommodate Hyperloop integration without a massive and costly overhaul, becomes obsolete almost overnight. Freight companies and travelers flock to the Hyperloop, rendering the bridge economically unviable. The project becomes a laughingstock, a symbol of shortsightedness and technological stagnation.

##### Early Warning Signs
- Reports emerge of successful Hyperloop testing and development.
- Experts predict widespread adoption of Hyperloop technology within the next 5-10 years.
- The project team dismisses the potential impact of Hyperloop on the bridge's long-term viability.

##### Tripwires
- A commercially viable Hyperloop system is operational within 500 miles of the bridge.
- Studies show that Hyperloop offers transportation costs that are >= 30% lower than the bridge's toll rates.
- The project team rejects recommendations to incorporate Hyperloop-compatible design elements.

##### Response Playbook
- Contain: Immediately commission a study to assess the feasibility and cost of integrating Hyperloop technology into the bridge.
- Assess: Conduct a thorough review of the project's long-term transportation strategy.
- Respond: Explore alternative use cases for the bridge, such as a dedicated data transmission corridor or a tourist attraction.


**STOP RULE:** The cost of retrofitting the bridge to accommodate Hyperloop technology exceeds 50% of the original construction cost, and no viable alternative use cases can be identified.

---

#### FM8 - The Uninsurable Undertaking

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Financial Risk Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project proceeds without securing adequate and affordable insurance coverage. A series of unforeseen events occur – a major earthquake damages the bridge's foundation, a severe storm disrupts operations for months, and geopolitical tensions lead to increased security costs. The insurance providers, citing the project's unique risks and the escalating claims, refuse to renew coverage or demand exorbitant premiums. The project is left financially exposed, unable to cover the costs of repairs, lost revenue, and increased security. Investors panic, and the project collapses under the weight of its uninsurable risks.

##### Early Warning Signs
- Insurance providers express reluctance to offer coverage for key project risks.
- Insurance premiums exceed budgeted amounts by more than 20%.
- The project team fails to secure comprehensive insurance coverage before commencing construction.

##### Tripwires
- Insurance premiums exceed 7% of the total project budget.
- Insurance providers exclude coverage for key risks, such as seismic activity or geopolitical instability.
- The project is unable to secure insurance coverage for more than 60 days.

##### Response Playbook
- Contain: Immediately seek alternative insurance providers and explore risk-sharing agreements with other infrastructure projects.
- Assess: Conduct a thorough review of the project's risk profile and identify potential mitigation measures.
- Respond: Redesign the project to reduce its risk exposure or postpone non-critical phases.


**STOP RULE:** The project is unable to secure adequate insurance coverage for key risks, and the potential financial exposure exceeds 20% of the total project budget.

---

#### FM9 - The PR Polar Vortex

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Public Relations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project becomes mired in negative media coverage and public perception. Environmental groups launch campaigns highlighting the project's ecological impact. Indigenous communities voice concerns about cultural heritage and social disruption. Geopolitical tensions fuel skepticism about the project's viability. A series of accidents and construction delays further damage the project's reputation. Public support plummets, and the project becomes a symbol of environmental destruction, social injustice, and international discord. The negative publicity scares away investors, hinders permitting processes, and ultimately leads to the project's cancellation.

##### Early Warning Signs
- Media coverage of the project becomes increasingly negative.
- Social media sentiment towards the project is overwhelmingly negative.
- Public opinion polls reveal declining support for the project.

##### Tripwires
- Negative media coverage exceeds 70% of total media mentions for >= 3 consecutive months.
- Social media sentiment score falls below 30 on a scale of 0-100.
- Public approval rating for the project falls below 40%.

##### Response Playbook
- Contain: Immediately launch a proactive public relations campaign to address concerns and highlight the project's benefits.
- Assess: Conduct a thorough review of the project's communication strategy and identify areas for improvement.
- Respond: Engage with stakeholders to address their concerns and build trust, and consider redesigning the project to mitigate negative impacts.


**STOP RULE:** Public opposition to the project becomes insurmountable, and the project is unable to secure necessary permits or funding due to negative public perception.
