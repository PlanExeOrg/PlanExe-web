This plan involves money.

## Currencies

- **USD:** Primary currency for the US side of the project, international transactions, and potentially for overall project budgeting due to its stability.
- **RUB:** Currency for local expenses and transactions on the Russian side of the project.

**Primary currency:** USD

**Currency strategy:** Given the international nature of the project and the involvement of both the US and Russia, USD is recommended as the primary currency for budgeting and reporting. RUB will be used for local transactions within Russia. Exchange rate fluctuations should be monitored and hedged against where possible to mitigate financial risks.