This plan involves money.

## Currencies

- **USD:** United States Dollar, for costs incurred in Alaska and for international transactions and budgeting.
- **RUB:** Russian Ruble, for costs incurred in Chukotka and for local transactions in Russia.

**Primary currency:** USD

**Currency strategy:** Due to the international nature of the project and potential geopolitical instability, USD is recommended for budgeting and reporting. RUB will be used for local transactions within Russia. Hedging strategies may be necessary to mitigate exchange rate fluctuations.