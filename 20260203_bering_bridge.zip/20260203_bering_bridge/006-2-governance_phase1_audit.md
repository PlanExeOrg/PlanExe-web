
## Audit - Corruption Risks

- Bribery of regulatory officials in the US or Russia to expedite or influence permit approvals.
- Kickbacks from contractors in exchange for awarding construction contracts or overlooking substandard work.
- Conflicts of interest involving project personnel with financial ties to suppliers or subcontractors.
- Misuse of confidential project information for personal gain or to benefit favored companies.
- Nepotism in hiring practices, favoring unqualified relatives or friends for key positions.

## Audit - Misallocation Risks

- Inflated invoices from suppliers or contractors, with the excess funds diverted for personal use.
- Double-billing for services rendered, with both the US and Russian entities paying for the same work.
- Inefficient allocation of resources, such as overspending on unnecessary equipment or materials.
- Unauthorized use of project assets, such as vehicles or equipment, for personal purposes.
- Misreporting project progress or results to justify continued funding or to conceal delays or cost overruns.

## Audit - Procedures

- Conduct periodic internal audits of financial records and procurement processes to detect irregularities.
- Engage an independent external auditor to conduct annual audits of project finances and compliance with regulations.
- Implement a contract review process with multiple levels of approval for all contracts exceeding a specified threshold.
- Establish a detailed expense reporting workflow with receipts and approvals required for all expenditures.
- Perform regular compliance checks to ensure adherence to US and Russian environmental regulations and international agreements.

## Audit - Transparency Measures

- Create a public project dashboard displaying key project milestones, budget expenditures, and risk assessments.
- Publish minutes of binational steering committee meetings and technical advisory board meetings on a project website.
- Establish a confidential whistleblower mechanism for reporting suspected fraud or corruption.
- Make relevant project policies and reports, such as environmental impact assessments and risk registers, publicly accessible.
- Document and publish the selection criteria and rationale for major decisions, such as vendor selection and technology choices.