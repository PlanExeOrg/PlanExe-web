**Purpose:** business

**Purpose Detailed:** Strategic plan for designing, financing, constructing, and operating a bridge across the Bering Strait, including geopolitical and economic considerations.

**Topic:** Bering Strait Bridge Project