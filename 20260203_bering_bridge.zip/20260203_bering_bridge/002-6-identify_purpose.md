**Purpose:** business

**Purpose Detailed:** Strategic plan for designing, financing, constructing, and operating a bridge across the Bering Strait, focusing on geopolitical and economic benefits.

**Topic:** Alaska-Russia Bering Strait Bridge Project