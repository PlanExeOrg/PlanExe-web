**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential for uncontrolled cost overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, and potential project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to ensure project progress.
Negative Consequences: Delays in procurement, potential for suboptimal vendor selection, and internal conflict.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significant impact on project budget, timeline, and strategic objectives.
Negative Consequences: Scope creep, budget overruns, and misalignment with strategic goals.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Project Steering Committee
Rationale: Requires independent review and potential corrective action to maintain ethical standards and legal compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Design Dispute within Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendations and Final Decision
Rationale: Ensures technical feasibility and safety when experts disagree.
Negative Consequences: Compromised structural integrity, safety hazards, and project delays.