**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic oversight and approval at a higher level.
Negative Consequences: Potential for uncontrolled budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Materialization of a critical risk (e.g., geopolitical event, major technical failure) requires strategic reassessment and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, and potential project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Director
Approval Process: Project Director Review and Decision
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates intervention by the Project Director to ensure timely progress.
Negative Consequences: Delays in procurement, potential selection of a suboptimal vendor, and project inefficiencies.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significant alterations to the project's scope require strategic evaluation and approval by the Steering Committee to ensure alignment with overall objectives and budget.
Negative Consequences: Scope creep, budget overruns, and potential project failure.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Allegations of ethical misconduct or compliance violations necessitate independent review and investigation to maintain project integrity and stakeholder trust.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder confidence.

**Unresolved Technical Disagreement within Technical Advisory Group**
Escalation Level: Project Director
Approval Process: Project Director Review and Decision, considering TAG input
Rationale: When the Technical Advisory Group cannot reach a consensus on a critical technical issue, the Project Director must intervene to make a final decision and ensure project progress.
Negative Consequences: Potential for suboptimal technical solutions, project delays, and increased costs.