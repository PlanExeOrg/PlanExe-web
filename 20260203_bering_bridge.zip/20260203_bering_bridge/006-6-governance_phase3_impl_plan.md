### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Circulate Draft SteerCo ToR for review by senior representatives from US Department of Transportation and Russian Ministry of Transport.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on SteerCo ToR

**Dependencies:**

- Draft SteerCo ToR v0.1

### 6. Circulate Draft Ethics & Compliance Committee ToR for review by independent legal counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Ethics & Compliance Committee ToR

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 7. Circulate Draft Technical Advisory Group ToR for review by identified Arctic engineering expert.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Technical Advisory Group ToR

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 8. Circulate Draft Stakeholder Engagement Group ToR for review by identified Community Liaison (US and Russia).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Stakeholder Engagement Group ToR

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 9. Project Manager finalizes the Terms of Reference (ToR) for the Project Steering Committee based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary on SteerCo ToR

### 10. Project Manager finalizes the Terms of Reference (ToR) for the Ethics & Compliance Committee based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary on Ethics & Compliance Committee ToR

### 11. Project Manager finalizes the Terms of Reference (ToR) for the Technical Advisory Group based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary on Technical Advisory Group ToR

### 12. Project Manager finalizes the Terms of Reference (ToR) for the Stakeholder Engagement Group based on received feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary on Stakeholder Engagement Group ToR

### 13. Senior representatives from US Department of Transportation and Russian Ministry of Transport formally appoint the Chair and Vice-Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Public Announcement

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Steering Committee Chair, in consultation with the Project Manager, confirms the remaining members of the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Appointment Confirmation Email (Chair and Vice-Chair)
- Final SteerCo ToR v1.0

### 15. Project Steering Committee Chair schedules and holds the initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List

### 16. Project Manager, in consultation with independent legal counsel, appoints the Independent ethics expert and Data Protection Officer for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email
- Public Announcement

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 17. Independent legal counsel schedules and holds the initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Independent legal counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 18. Project Manager, in consultation with Arctic engineering expert, confirms the remaining members of the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 19. Arctic engineering expert schedules and holds the initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Expert in Arctic bridge engineering

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List

### 20. Project Manager, in consultation with Community Liaison (US and Russia), confirms the remaining members of the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 21. Community Liaison (US and Russia) schedules and holds the initial Stakeholder Engagement Group Kick-off Meeting.

**Responsible Body/Role:** Community Liaison (US and Russia)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List

### 22. Establish PMO structure and staffing, including appointing the Project Manager, Deputy Project Manager (one from US, one from Russia), Project Engineers, Construction Manager, Financial Officer, Environmental Compliance Officer, Community Liaison, and Contract Manager.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- PMO Staffing Plan
- Appointment Confirmation Emails

**Dependencies:**

- Meeting Minutes with Action Items (Project Steering Committee Kick-off Meeting)

### 23. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Agenda
- Meeting Minutes with Action Items

**Dependencies:**

- PMO Staffing Plan

### 24. The Project Steering Committee reviews and approves strategic project plans and budgets exceeding $50 million USD.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Ongoing Quarterly

**Key Outputs/Deliverables:**

- Approved Project Plans
- Approved Budgets

**Dependencies:**

- Meeting Minutes with Action Items (Project Steering Committee Kick-off Meeting)

### 25. The Project Management Office (PMO) develops and maintains project plans, schedules, and budgets (below $50 million USD).

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Ongoing Weekly

**Key Outputs/Deliverables:**

- Updated Project Plans
- Updated Schedules
- Updated Budgets

**Dependencies:**

- Meeting Minutes with Action Items (PMO Kick-off Meeting)

### 26. The Technical Advisory Group reviews and approves technical designs and specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Ongoing Monthly

**Key Outputs/Deliverables:**

- Approved Technical Designs
- Approved Specifications

**Dependencies:**

- Meeting Minutes with Action Items (Technical Advisory Group Kick-off Meeting)

### 27. The Ethics & Compliance Committee monitors compliance with all applicable laws and regulations, including GDPR, anti-corruption laws, and environmental regulations.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Ongoing Monthly

**Key Outputs/Deliverables:**

- Compliance Reports
- Audit Findings

**Dependencies:**

- Meeting Minutes with Action Items (Ethics & Compliance Committee Kick-off Meeting)

### 28. The Stakeholder Engagement Group conducts regular consultations with stakeholders.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Ongoing Bi-weekly

**Key Outputs/Deliverables:**

- Stakeholder Consultation Reports
- Benefit-Sharing Agreements

**Dependencies:**

- Meeting Minutes with Action Items (Stakeholder Engagement Group Kick-off Meeting)