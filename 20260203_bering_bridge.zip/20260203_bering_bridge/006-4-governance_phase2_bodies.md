### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this complex, high-risk, and politically sensitive project. Ensures alignment with strategic goals and manages key risks.

**Responsibilities:**

- Approve strategic project plans and budgets exceeding $50 million USD.
- Oversee project progress against strategic objectives.
- Approve major scope changes or deviations from the strategic plan.
- Address and resolve strategic risks and issues escalated from lower governance bodies.
- Ensure alignment with US and Russian government priorities.
- Approve key strategic decisions, including those related to Structural Adaptation, Risk Mitigation, Geopolitical Alignment, and Funding Models.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair (one from US, one from Russia).
- Establish communication protocols.
- Define escalation procedures.

**Membership:**

- Senior representatives from US Department of Transportation
- Senior representatives from Russian Ministry of Transport
- Independent expert in Arctic engineering
- Independent expert in international finance
- Independent expert in US-Russia relations

**Decision Rights:** Strategic decisions related to project scope, budget (>$50 million USD), timeline, and key strategic choices (Structural Adaptation, Risk Mitigation, Geopolitical Alignment, Funding Models).

**Decision Mechanism:** Consensus-based decision-making. If consensus cannot be reached, a majority vote is required, with the Chair having the tie-breaking vote. Any decision impacting either US or Russian national security requires unanimous approval.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review and approval of budget requests exceeding $50 million USD.
- Discussion and resolution of escalated strategic risks and issues.
- Review of stakeholder engagement activities.
- Review of compliance with US and Russian regulations.
- Review of audit reports and recommendations.

**Escalation Path:** Escalate to the respective Ministers of Transportation in the US and Russia for unresolved strategic issues or disagreements.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized operational management, coordination, and support for the project. Ensures efficient execution and adherence to project plans.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets (below $50 million USD).
- Manage day-to-day project activities and resources.
- Monitor project progress and performance.
- Identify and manage operational risks and issues.
- Coordinate communication and collaboration among project teams.
- Prepare and distribute project reports.
- Implement project management best practices.
- Manage contracts and procurement processes (below $10 million USD).

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication channels.

**Membership:**

- Project Manager
- Deputy Project Manager (one from US, one from Russia)
- Project Engineers
- Construction Manager
- Financial Officer
- Environmental Compliance Officer
- Community Liaison
- Contract Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation, and contract management (below $10 million USD).

**Decision Mechanism:** Majority vote, with the Project Manager having the tie-breaking vote. Decisions impacting environmental compliance or Indigenous communities require consensus from the Environmental Compliance Officer and Community Liaison, respectively.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Review of project progress against schedule and budget.
- Discussion and resolution of operational risks and issues.
- Review of contract status and procurement activities.
- Review of environmental compliance activities.
- Review of stakeholder engagement activities.
- Review of safety performance.

**Escalation Path:** Escalate to the Project Steering Committee for strategic issues or issues exceeding the PMO's authority.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on the design, construction, and operation of the bridge. Ensures technical feasibility and safety.

**Responsibilities:**

- Review and approve technical designs and specifications.
- Provide technical guidance on construction methods and materials.
- Assess the technical risks and challenges associated with the project.
- Recommend solutions to technical problems.
- Monitor the technical performance of the bridge.
- Advise on the use of innovative technologies.
- Ensure compliance with relevant technical standards and regulations.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define the scope of the Technical Advisory Group's responsibilities.
- Establish communication protocols.
- Develop a process for reviewing and approving technical designs.

**Membership:**

- Expert in Arctic bridge engineering
- Expert in seismic engineering
- Expert in permafrost engineering
- Expert in tunnel engineering
- Expert in advanced materials
- Expert in environmental engineering
- Expert in maritime engineering

**Decision Rights:** Technical approval of designs, specifications, and construction methods. Recommendations on technical risks and solutions.

**Decision Mechanism:** Consensus-based decision-making. If consensus cannot be reached, the Project Steering Committee will make the final decision, considering the Technical Advisory Group's recommendations.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical risks and challenges.
- Review of construction progress and performance.
- Discussion of innovative technologies.
- Review of compliance with technical standards and regulations.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved technical issues or disagreements.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct, compliance with all applicable laws and regulations (including GDPR), and prevents corruption. Protects the project's reputation and minimizes legal risks.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with all applicable laws and regulations, including GDPR, anti-corruption laws, and environmental regulations.
- Investigate allegations of ethical misconduct or non-compliance.
- Recommend corrective actions to address ethical or compliance violations.
- Provide training on ethics and compliance to project personnel.
- Oversee the whistleblower mechanism.
- Conduct regular audits of financial records and procurement processes.
- Ensure data privacy and security.

**Initial Setup Actions:**

- Develop an ethics and compliance policy.
- Establish a whistleblower mechanism.
- Develop a training program on ethics and compliance.
- Establish a process for investigating allegations of misconduct.

**Membership:**

- Independent legal counsel specializing in international law and compliance
- Independent ethics expert
- Senior representative from the US Department of Justice (non-voting)
- Senior representative from the Russian Prosecutor General's Office (non-voting)
- Data Protection Officer
- Internal Audit Manager

**Decision Rights:** Authority to investigate ethical misconduct and non-compliance, recommend corrective actions, and approve ethics and compliance policies. Authority to halt project activities in cases of serious ethical or compliance violations.

**Decision Mechanism:** Majority vote. Decisions related to data privacy and GDPR compliance require the Data Protection Officer's approval.

**Meeting Cadence:** Monthly.

**Typical Agenda Items:**

- Review of compliance with applicable laws and regulations.
- Discussion of ethical issues and concerns.
- Review of whistleblower reports.
- Review of audit findings.
- Review of data privacy and security measures.
- Review of training activities.

**Escalation Path:** Escalate to the Project Steering Committee and relevant government agencies (US Department of Justice, Russian Prosecutor General's Office) for serious ethical or compliance violations.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Ensures effective communication and collaboration with all stakeholders, including Indigenous communities, government agencies, and international investors. Minimizes social risks and maximizes project benefits.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Negotiate benefit-sharing agreements with Indigenous communities.
- Provide regular project updates to stakeholders.
- Manage media relations.
- Organize public forums and events.
- Monitor stakeholder satisfaction.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Develop a process for addressing stakeholder concerns.

**Membership:**

- Community Liaison (US and Russia)
- Public Relations Manager
- Indigenous Representative (US and Russia)
- Government Relations Manager (US and Russia)
- Investor Relations Manager

**Decision Rights:** Recommendations on stakeholder engagement strategies, approval of communication materials, and negotiation of benefit-sharing agreements.

**Decision Mechanism:** Consensus-based decision-making. Decisions impacting Indigenous communities require the approval of the Indigenous Representatives.

**Meeting Cadence:** Bi-weekly.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Review of communication materials.
- Review of benefit-sharing agreements.
- Review of media coverage.
- Review of stakeholder satisfaction.

**Escalation Path:** Escalate to the Project Steering Committee for unresolved stakeholder issues or disagreements.