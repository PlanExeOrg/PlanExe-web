### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for the entire project, given its scale, complexity, geopolitical sensitivity, and significant financial investment. Ensures alignment with overall strategic goals and manages high-level risks.

**Responsibilities:**

- Approve overall project strategy and objectives.
- Approve major project milestones and deliverables.
- Approve budget allocations exceeding $50 million USD.
- Monitor and manage strategic risks (geopolitical, financial, regulatory).
- Resolve strategic conflicts and escalate issues as needed.
- Oversee stakeholder engagement at a strategic level.
- Approve changes to project scope or objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Define decision-making processes.
- Review and approve initial project plan.

**Membership:**

- Senior Representatives from US Department of Transportation
- Senior Representatives from Russian Ministry of Transport
- Independent Expert in Arctic Infrastructure
- Independent Financial Expert
- Project Director
- Representative from Indigenous Communities (rotating basis)

**Decision Rights:** Strategic decisions related to project scope, budget (above $50 million USD), timeline, and key risks. Approval of major project milestones and deliverables.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the deciding vote. Any decision impacting Indigenous communities requires their representative's consent.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Review of financial performance and budget status.
- Discussion and approval of proposed changes to project scope or objectives.
- Review and management of strategic risks.
- Stakeholder engagement updates.
- Reports from Technical Advisory Group and Ethics & Compliance Committee.

**Escalation Path:** Escalate unresolved issues to the US Secretary of Transportation and the Russian Minister of Transport, jointly.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Provides centralized operational management and coordination for the project, ensuring efficient execution, adherence to standards, and effective communication across all project teams. Manages day-to-day activities and operational risks.

**Responsibilities:**

- Develop and maintain project management plans.
- Manage day-to-day project execution.
- Track project progress against milestones and budget.
- Manage operational risks (technical, supply chain, environmental).
- Coordinate communication across project teams.
- Manage project documentation and reporting.
- Implement project management standards and best practices.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols.
- Develop risk management framework.

**Membership:**

- Project Manager
- Deputy Project Manager
- Project Engineers
- Construction Manager
- Environmental Specialist
- Financial Analyst
- Risk Manager
- Communications Manager

**Decision Rights:** Operational decisions related to project execution, budget (below $50 million USD), timeline adjustments within approved parameters, and risk management within defined thresholds.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with relevant team members. Disputes escalated to the Project Director.

**Meeting Cadence:** Weekly, with daily stand-up meetings for core team members.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of current issues and risks.
- Coordination of activities across project teams.
- Review of budget status and financial performance.
- Review of project documentation and reporting.
- Action item tracking.

**Escalation Path:** Escalate unresolved issues to the Project Director, then to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on complex engineering and environmental challenges, ensuring the project utilizes best practices and innovative solutions. Addresses the high technical risks associated with the Arctic environment.

**Responsibilities:**

- Provide technical expertise on bridge and tunnel design and construction.
- Review and approve technical specifications and drawings.
- Advise on the selection of materials and technologies.
- Assess the technical feasibility of proposed solutions.
- Monitor and evaluate the performance of technical systems.
- Provide guidance on environmental impact mitigation.
- Review and approve environmental impact assessments.

**Initial Setup Actions:**

- Identify and recruit technical experts.
- Define scope of expertise and responsibilities.
- Establish communication protocols.
- Review initial project design and specifications.

**Membership:**

- Leading Bridge Engineers
- Tunneling Experts
- Arctic Engineering Specialists
- Environmental Scientists
- Geotechnical Engineers
- Materials Scientists
- Climate Change Experts

**Decision Rights:** Provides recommendations on technical aspects of the project. Approves technical specifications and drawings. Advises on environmental impact mitigation strategies.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Project Director makes the final decision, considering the input from all members.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of technical specifications and drawings.
- Discussion of technical challenges and proposed solutions.
- Review of environmental impact assessments.
- Evaluation of the performance of technical systems.
- Updates on emerging technologies.
- Review of climate change impacts and mitigation strategies.

**Escalation Path:** Escalate unresolved technical issues to the Project Director, then to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all applicable laws and regulations, including anti-corruption measures, environmental regulations, and labor laws. Addresses the high risk of corruption and regulatory non-compliance.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Monitor compliance with all applicable laws and regulations.
- Investigate allegations of fraud, corruption, and other misconduct.
- Provide training on ethics and compliance.
- Review and approve contracts and agreements.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee whistleblower mechanism.

**Initial Setup Actions:**

- Develop ethics and compliance policies and procedures.
- Establish reporting mechanisms for ethical concerns.
- Conduct initial risk assessment for compliance.
- Appoint a Chief Compliance Officer.

**Membership:**

- Chief Compliance Officer
- Legal Counsel
- Internal Audit Manager
- Independent Ethics Expert
- Representative from Indigenous Communities
- Representative from Environmental Groups

**Decision Rights:** Investigates ethical breaches and compliance violations. Recommends corrective actions. Approves ethics and compliance policies and procedures.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chief Compliance Officer has the deciding vote.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for compliance issues.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical concerns and potential violations.
- Review of contracts and agreements.
- Updates on changes to laws and regulations.
- Training on ethics and compliance.
- Review of whistleblower reports.

**Escalation Path:** Escalate unresolved ethical or compliance issues to the Project Steering Committee and, if necessary, to external regulatory agencies.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and collaboration with all stakeholders, including Indigenous communities, government agencies, and local communities. Ensures that stakeholder concerns are addressed and that the project benefits all parties involved. Addresses the high risk of social and environmental impacts.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with stakeholders.
- Address stakeholder concerns and grievances.
- Provide information to stakeholders about the project.
- Facilitate collaboration between stakeholders.
- Monitor stakeholder satisfaction.
- Ensure Indigenous consultation and free, prior, and informed consent.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Conduct initial stakeholder consultations.

**Membership:**

- Communications Manager
- Public Relations Officer
- Community Liaison Officer
- Indigenous Community Representatives
- Representatives from Environmental Groups
- Representatives from Local Communities

**Decision Rights:** Provides recommendations on stakeholder engagement strategies. Approves stakeholder engagement plans. Facilitates communication and collaboration with stakeholders.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Project Director makes the final decision, considering the input from all members.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for stakeholder issues.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and grievances.
- Updates on project progress.
- Planning for upcoming stakeholder consultations.
- Review of stakeholder satisfaction.
- Reports from Indigenous Community Representatives.

**Escalation Path:** Escalate unresolved stakeholder issues to the Project Director, then to the Project Steering Committee.