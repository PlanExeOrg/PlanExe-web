
## Risk 1 - Governance & Political
The Consortium's equal-national co-chair and double-key structure has no casting vote and prohibits one country overruling the other. The plan does not specify a maximum deadlock duration or a pre-agreed escalation path for disputes over materiality, protocol changes, sanctions, or suspension. A single co-chair can therefore block or delay a decision indefinitely, and an unresolved disagreement can trigger the very suspension machinery meant for verification failures.

**Impact:** Deadlocked material findings could age beyond the agreed discrepancy-resolution window, forcing automatic suspension of one or more sites; Phase One could fail to produce a Go/Modify/Stop verdict within the 90-day operational window, consuming the $250M legal implementation and $500M contingency envelopes with no operational result. A politically motivated deadlock could stop the entire $5B program.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-register a bounded deadlock procedure before the clock starts: route routine discrepancies to joint technical teams, refer factual disputes to a jointly selected advisory arbiter, and require any deadlock persisting beyond a fixed deliberation window to be recorded on the KPI dashboard and escalated to automatic suspension only for material discrepancies. Make deadlock duration a KPI with a pre-agreed threshold.

## Risk 2 - Regulatory & Permitting
The Phase One clock does not start until both governments have signed the bilateral instrument, appropriated contributions, enacted domestic access authority, selected sites, approved inspectors, secured vendor/operator participation, and adopted the covered-equipment schedule. These are political acts that can be delayed or held hostage to unrelated diplomatic disputes, and the plan provides no outer limit or fallback if conditions remain uncertified.

**Impact:** Preparatory workstreams can continue in parallel, but the operational test could be delayed 6–24 months or indefinitely; trained inspectors and technical teams may be idled, consuming the $750M inspectorate envelope without producing verification evidence. The delay also increases the risk that political leadership changes before Phase One begins.

**Likelihood:** High

**Severity:** High

**Action:** Create an integrated readiness tracker with reciprocal certification by the co-chairs, run all preparatory workstreams in parallel, and use provisional shadow exercises after site selection to keep the mechanism warm. Include a mutual commitment to complete entry conditions within an agreed maximum period, with delays visible as a KPI and escalation to heads of state or party leadership if exceeded.

## Risk 3 - Regulatory & Permitting
Even with political backing, domestic courts, data-protection regulators, local governments, or private operators may challenge the authority of foreign or international inspectors to access facilities, collect evidence, or inspect equipment. The plan requires domestic access authority but does not specify how it interacts with existing privacy, export-control, customs, and national-security laws on either side.

**Impact:** An injunction or regulatory ruling could block inspectors at one site for weeks or months, creating an asymmetric-access Stop condition. Litigation and legislative fixes could add $10–50M in legal costs and delay the Phase One clock by 3–6 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Before clock start, enact a clear domestic legal framework that overrides conflicting private-law objections, defines inspector privileges and limits, and binds operators and vendors contractually. Maintain a joint legal task force to resolve challenges quickly, and include rapid dispute-resolution clauses in the bilateral instrument.

## Risk 4 - Financial
Each government contributes USD 2.5B, with domestic operator and vendor compensation paid by its own government. A delay in appropriations, a treasury dispute over exchange rates, or a quiet decision to slow disbursement can starve the program without formally triggering the withholding-funding Stop condition. The budget is fixed in USD but China-side costs are denominated in CNY, creating exchange-rate and inflation exposure.

**Impact:** A 6–12 month funding delay would idle the inspectorate, stop site preparation, and break the reciprocity parity essential to the Go/Modify/Stop test. A 5% currency or local-inflation shock could add $125–250M in unplanned costs, consuming the $500M contingency envelope before any independent testing occurs.

**Likelihood:** Medium

**Severity:** High

**Action:** Require both governments to pre-fund their full contributions into a jointly signatory escrow before the clock starts, with quarterly USD reconciliation and envelope-approved drawdowns. Use structured currency conversion windows and periodic revaluation to manage CNY/USD exposure, and make any contribution-release delay beyond a pre-agreed window an automatic KPI-visible suspension trigger.

## Risk 5 - Supply Chain
The verification scheme depends on manufacturers, maintenance providers, and logistics companies to provide access, escorts, evidence, and clean-room support. A dominant vendor serving datacenters in both countries could refuse to cooperate, citing proprietary technology, export controls, or national law. Since the forced-evidence ladder can consume time and may produce weaker evidence, a single vendor's refusal can affect multiple sites simultaneously.

**Impact:** Equipment served by the refusing vendor could become unverifiable; if material, the site fails Phase One and the overall verdict moves to Stop. Escalation through the evidence ladder could consume 2–6 weeks per refusal and draw down the $500M contingency and $750M inspectorate envelopes, while unresolved unverifiable-equipment counts mount.

**Likelihood:** Medium

**Severity:** High

**Action:** Negotiate model vendor-access agreements before the clock starts, bind operators to enforce vendor participation, and pre-accredit independent clean-room examiners. Cross-train inspectors to perform vendor-supervised diagnostics themselves, stock spare replacement hardware, and define a per-site unverifiable-equipment threshold that triggers automatic escalation before the materiality corridor is breached.

## Risk 6 - Security & Technical
The information-barrier architecture must protect model weights, customer data, source code, network topology, and unrelated infrastructure while still giving inspectors enough contextual evidence to verify equipment identity. Over-filtering can strip serial numbers, firmware telemetry, or configuration metadata needed to detect substitution; under-filtering can expose sensitive technology and cause either government to withdraw cooperation.

**Impact:** If the barrier hides evidence, blind-challenge detection rates fall and the regime could certify a false negative. If it leaks sensitive data, a single IP or cybersecurity incident could terminate the program and trigger national-security investigations; reputational and intelligence damage is difficult to quantify but could exceed the $5B program budget in diplomatic cost.

**Likelihood:** High

**Severity:** High

**Action:** Design bounded inspection zones and filtered workstations by event type, with cryptographic hashes to preserve evidence integrity; test the barrier in blind exercises before deployment. Use clean-room protocols and accredited independent examiners for the most sensitive inspections, and implement a joint cyber-incident response plan that can isolate and contain a leak without halting all verification.

## Risk 7 - Operational & Technical
Credible detection depends on the maximum time between a physical material change and its verified appearance in the ledger. The layered latency budget creates interior windows for operator reporting, physical confirmation, and ledger recording that red teams will try to exploit. If any interior window is too long or not independently verifiable, an unreported arrival or substitution can go undetected for hours or days.

**Impact:** A missed latency target would fail the KPI dashboard and could force a Modify verdict even if other elements succeed. If thresholds are set too loose, an event could remain silent for 24–72 hours, giving red teams a guaranteed concealment corridor and undermining the Go decision.

**Likelihood:** Medium

**Severity:** High

**Action:** Predefine and validate threshold values through simulation and exercises, such as operator reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour. Use tamper-evident local recording at the point of observation, unannounced random sweeps to shrink expected silent windows, and independent monitoring of interior windows to ensure the layered budget is not a paper construct.

## Risk 8 - Technical
The replicated, tamper-evident ledger with national copies must record events locally and synchronize within a bounded window. Network outages, software defects, or malicious tampering can cause the two national copies to diverge. Because unresolved divergence is a designated Stop condition, the system risks either false alarms from minor synchronization lags or missed divergence that allows evidence to be silently altered or withheld.

**Impact:** A divergence that cannot be reconciled within the agreed window would trigger a Stop recommendation. If divergence detection is too slow, both governments may rely on conflicting records during a security crisis. Reconciliation exercises could consume 1–4 weeks of the Phase One clock and require technical fixes costing $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Set a bounded synchronization window with automatic divergence alerts, maintain local-first recording so no event is lost during connectivity loss, and run regular reconciliation drills against independently generated test events. Use hash commitments exchanged continuously between the two national copies to prove tamper-evidence without exposing sensitive content.

## Risk 9 - Operational & Political
The matched site set must have comparable verification burden, but Northern Virginia, the Beijing/Hebei cluster, and Guizhou differ in facility size, layout, vendor ecology, security rules, and operating culture. Paper matching by declared equipment value or total capacity may not make inspection difficulty equal. If one country's sites are systematically easier or harder to inspect, access-parity metrics become meaningless and the asymmetric-access Stop trigger can be tripped before exercises begin.

**Impact:** Negotiations over the matched set could stall entry-condition certification for months. If the final set is asymmetric, one side could claim the other receives less intrusive inspections, causing political collapse and a Stop verdict. Red-team results would be incomparable across sites, undermining the 90-day test.

**Likelihood:** High

**Severity:** High

**Action:** Jointly define parity in advance using multiple attributes, including equipment value, operational role, physical layout, and security constraints. Benchmark reciprocal access hours and inspection outcomes during the readiness period, and deliberately include one or more harder-to-inspect stress sites on each side so the regime is validated under unequal conditions.

## Risk 10 - Operational
The plan requires full-time mirrored national inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units with separation of duties and leave coverage. Recruiting enough cleared, bilingual, technically credible specialists on both sides within the entry-condition period is a major challenge, and reliance on a small surge cadre can create single points of failure.

**Impact:** Staffing gaps would delay event response, invalidate evidence collection, and violate the no-single-person-critical-function rule. Hiring premium pay and security-clearance processing could add 10–20% to the $750M inspectorate envelope, or $75–150M, and push the Phase One start by 3–6 months if qualified personnel cannot be cleared in time.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Build a workload-based staffing model before the clock starts, create a full-time surge cadre rather than using temporary agents, cross-train specialists across sites, and initiate security-clearance processing in parallel with entry-condition certification. Include retention bonuses and a training pipeline for technical inspectors to reduce attrition risk.

## Risk 11 - Security
The program itself is a high-value target for state-sponsored cyber operations, insider threats, and counterintelligence activity. Evidence systems, secure facilities, inspector communications, and the confidential covered-equipment schedule are attractive targets. A single compromised insider or cyber intrusion could undermine the integrity of verification evidence and create an international incident.

**Impact:** A successful compromise could alter ledger records, leak the covered-equipment schedule, expose inspector travel plans, or reveal sensitive data collected during inspections. Response and remediation costs could range from $10–100M, and the political fallout could trigger automatic suspension or the withdrawal of either government.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement strict need-to-know compartments, physical and logical separation of national teams, continuous counterintelligence monitoring, hardware-separated evidence systems, and regular penetration testing by independent red teams. Establish a joint incident-response protocol that isolates compromised systems while preserving the ability to continue verification at unaffected sites.

## Risk 12 - Technical & Governance
The Phase One Go decision depends on live exercises demonstrating credible detection. If red teams are not truly independent or blind, if exercises are announced too far in advance, or if KPI thresholds are set without validation, the exercises can produce a false sense of confidence. The plan does not finalize threshold values, and unsupported figures marked provisional or TBD must still be validated before they can justify a Go verdict.

**Impact:** A Go recommendation based on scripted exercises or lenient thresholds could lead a government to rely on a verification regime that cannot detect real substitution, with national-security consequences. Setting thresholds too strict could cause a false Stop and waste the $5B investment; too loose could produce an indefensible Go. Threshold negotiation itself could delay the verdict by weeks.

**Likelihood:** Medium

**Severity:** High

**Action:** Use genuinely independent red teams with no advance knowledge of exercise timing, run unannounced exercises in staging, spare-inventory, and maintenance areas, and pre-register all KPI thresholds with a validation plan based on historical data, pilot runs, and exercise results. Require the KPI dashboard to show false-negative and false-positive rates, confidence intervals, and unresolved-discrepancy ages before any Go decision.

## Risk 13 - Technical
The covered-equipment schedule must remain current as AI hardware evolves, but every revision reopens the bilateral definitional bargain. If the schedule is too static, new frontier-relevant equipment is not verified; if it is revised too often, disputes over definitional criteria delay operations. The plan's attribute-based confidential schedule depends on accountable specialists, but the versioning process itself can become a flashpoint.

**Impact:** During the Phase One window, a new architecture could ship that is not on the schedule, creating an unverified gap until the double-key approval process completes. If approval takes 4–8 weeks, a material installation could occur outside verification; if the schedule is frozen to avoid dispute, the regime's credibility decays immediately after launch.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-negotiate an attribute-based coverage framework before the clock starts, include a fast-track provisional listing procedure that adds equipment on an interim basis within 48–72 hours, and schedule sunset reviews linked to each side's declared new generations. Require the accountable specialists to maintain a versioned changelog and pre-registered criteria for disputes.

## Risk 14 - Operational & Social
Operators and vendors may cooperate reluctantly, fearing that inspections will disrupt active computational work, expose confidential customer arrangements, or reveal more than the bounded protocol allows. The plan's live exercises must not interrupt active work, but even staging, maintenance monitoring, and witnessed movement create friction. A reluctant operator can delay access, produce inaccurate records, or challenge evidence authenticity.

**Impact:** Access delays could violate the latency budget and cause false negatives or false positives in exercise results. Production disruption claims could become a political issue, causing operators to seek exemptions or compensation beyond the $1B preparation and compensation envelope. If one country's operators are less cooperative than the other's, reciprocal-access parity fails and the Stop condition is triggered.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Bind operator participation as a condition of site eligibility, provide fair compensation administered by the operator's own government, and pre-agree inspection windows that minimize interference with production. Escalate deliberate obstruction to the co-chairs quickly, and use the exercise program to test and refine low-disruption inspection techniques before the actual event-response phase.

## Risk 15 - Financial & Environmental
The $5B budget is fixed, with each expense mapped to an envelope. Site preparation, secure facilities, and independent testing often overrun initial estimates, and the physical locations face power-grid, climate, and logistical risks. Natural disasters or energy constraints could disrupt verification exercises and force contingency spending.

**Impact:** A 5–10% cost overrun equals $250–500M and would consume the entire contingency envelope, forcing reallocation from testing or inspectorate capacity. A severe weather or grid event at a selected site could delay the 90-day test by 2–4 weeks and require emergency relocation or backup-power costs of $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan for overruns, and select multiple fallback sites within each country to mitigate physical-environment risk. Use structured currency conversion and fixed-price contracts where possible to limit inflation and exchange-rate exposure.

## Risk summary
The risk landscape is dominated by political and institutional failure modes rather than purely technical ones. The three most critical risks are: entry-condition and appropriations delay, which can prevent Phase One from ever starting or allow a quiet veto; vendor refusal and unverifiable-equipment contagion, which can trigger the Stop condition through a single dominant supplier; and information-barrier imbalance, where over-filtering blinds inspectors to substitution or under-filtering exposes sensitive technology and collapses political support. These risks are mutually reinforcing: an information leak can cause funding delays, a vendor refusal can expose parity asymmetries, and deadlock over any of these can suspend the entire program. Key assumptions are that both governments genuinely intend to meet entry conditions, that suitable matched sites and qualified personnel can be identified within the budget, and that KPI thresholds will be validated before use; the absence of specified thresholds and site or vendor agreements is the largest source of remaining uncertainty. Success should be judged only against the narrow mission of verifying monitored changes at declared sites, not as a broader AI-governance guarantee.