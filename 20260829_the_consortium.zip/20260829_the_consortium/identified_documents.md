
## Documents to Create

### 1. Project Charter – US-China Consortium Phase One Verification Program

**ID:** 101d1641-3591-42b6-ac51-6e9160b9512e

**Description:** Foundational project management charter establishing the joint 90-day Phase One operational test mission, scope boundaries (declared-equipment change verification only), SMART success criteria, high-level budget and envelope structure, governance roles, and approval path. Intended for joint co-chairs and heads of state to authorize planning. Type: Project Charter.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** PMI Project Charter Template

**Secondary Template:** UK Government Project Initiation Document (PID) Template

**Steps:**

- Draft charter from goal statement and strategic decisions, incorporating SMART criteria and mandatory entry conditions.
- Conduct joint working session with co-chairs and legal counsel to confirm scope and non-goals.
- Circulate for comment to mirrored national units and stakeholders.
- Obtain double-key approval from equal co-chairs.

**Approval Authorities:** Equal National Co-Chairs; Heads of State/Party Leadership for final authorization

### 2. Current State Assessment of Declared-Equipment Change Verification Readiness

**ID:** 99cf6468-921c-4c1e-99cc-0a0cc8a544b1

**Description:** Baseline assessment of current capabilities, gaps, legal authorities, site readiness, staffing, and information-barrier maturity that informs all subsequent strategy documents. Includes preliminary findings from available raw source materials and expert reviews. Type: Baseline Assessment.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** Government Program Baseline Assessment Template

**Steps:**

- Collect existing legal texts, site data, staffing data, and raw statistical sources.
- Conduct gap analysis against mandatory entry conditions and KPI targets.
- Interview subject-matter experts and mirrored national teams.
- Draft findings and present to co-chairs for acknowledgment.

**Approval Authorities:** Equal National Co-Chairs; Joint Legal Task Force

### 3. Bilateral Governance and Decision-Rights Framework

**ID:** 0cbb596b-25ab-404f-8a6f-1fdcc99543ef

**Description:** High-level framework defining equal co-chair double-key authorization, no-casting-vote deadlock machinery, joint technical teams, advisory arbitration, objective automatic-suspension thresholds, and three-tier separation of inspectorate facts, verification conclusions, and political decisions. Type: Governance Framework.

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Primary Template:** Model Treaty/Executive Agreement Governance Chapter Template

**Secondary Template:** IAEA Safeguards Legal Framework Template

**Steps:**

- Review expert critique of double-key site findings and deadlock default rules.
- Draft decision-rights tiers for technical facts, materiality conclusions, and political sanctions.
- Pre-register objective automatic suspension triggers and a fixed deadlock clock.
- Convene governance war-games with both national legal teams.
- Submit to co-chairs for double-key approval.

**Approval Authorities:** Equal National Co-Chairs; Heads of State/Party Leadership for escalation provisions

### 4. Bilateral Legal Form and Implementing Legislation Strategy

**ID:** c2916f74-645e-4716-9178-26b101b7c161

**Description:** High-level legal strategy identifying the required treaty or executive-agreement form, consortium legal personality, domestic access-authority legislation, privileges and immunities, dispute settlement, escrow legal capacity, and cross-border data transfer rules. Type: Legal Strategy.

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Primary Template:** Legal Form Memorandum Template

**Secondary Template:** UN Treaty Handbook Guidance

**Steps:**

- Convene joint legal task force with constitutional, treaty, appropriations, export-control, and data-protection counsel.
- Produce legal-form memorandum by 2026-10-30.
- Draft model implementing legislation for both countries.
- Obtain legal opinions from both governments on domestic access authority and escrow feasibility.
- Review with co-chairs and legislative bodies.

**Approval Authorities:** Joint Legal Task Force; Equal National Co-Chairs; relevant legislative/State Council bodies

### 5. Binding Bilingual Glossary and Interpretive Dispute Pre-Registration Strategy

**ID:** f47bdfe8-eb25-49da-ad80-d72070bfe0ef

**Description:** Strategy for pre-committing both governments to a binding bilingual glossary and pre-registered interpretive readings of contested terms (material, covered equipment, removal, frontier-relevant) before the Phase One clock starts, converting future disputes into lookup operations. Type: Interpretive Legal Framework.

**Responsible Role Type:** Bilingual Training, Translation, and Readiness Certification Coordinator

**Primary Template:** UN Treaty Terminology Management Template

**Secondary Template:** IAEA Safeguards Glossary Structure

**Steps:**

- Convene joint terminology commission with mirrored technical linguists and engineers.
- Define contested terms with worked examples of covered and uncovered events.
- Draft glossary and pre-registered interpretive annex.
- Run dispute-resolution tabletop exercises.
- Obtain double-key approval and attach to the bilateral instrument.

**Approval Authorities:** Joint Terminology Commission; Equal National Co-Chairs

### 6. Verification Architecture and Layered Evidence Strategy

**ID:** 5936203e-9ac4-4919-a4a8-17e9a3a2e08e

**Description:** High-level strategy for evidence classes, certainty thresholds, operator-record validation, sampling principles, and the 'no single source decisive' rule, including mandatory two-class evidence for material events and random sampling for low-risk changes. Type: Technical Verification Strategy.

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Primary Template:** IAEA Safeguards Criteria / State-Level Concept Template

**Secondary Template:** DoD Verification and Validation Framework

**Steps:**

- Map all material-event types and evidence classes to confidence requirements.
- Define evidence hierarchy and limitations of cryptographic attestation.
- Draft sampling rules for operator-provided records.
- Review against latency budget and information-barrier constraints.
- Seek joint technical team and co-chair approval.

**Approval Authorities:** Joint Technical Team; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

### 7. Information Barrier and Filtered Evidence Architecture Strategy

**ID:** e74afcb3-ea15-480a-ade3-2bea1ebb624b

**Description:** High-level architecture strategy for bounded inspection zones, filtered workstations, clean-room examination, dynamic zone boundaries, cryptographic hashing, and blind validation of barrier rules to protect sovereign technology while preserving substitution indicators. Type: Security/Technical Architecture Strategy.

**Responsible Role Type:** Information Barrier and Counterintelligence Security Director

**Primary Template:** Trilateral Initiative Information Barrier Technical Framework

**Secondary Template:** OPCW Confidentiality Annex Implementation Model

**Steps:**

- Define zone categories and evidence-filtering levels by event type.
- Specify clean-room examination and accredited independent examiner protocols.
- Plan blind validation exercises for barrier rules.
- Draft incident-isolation and evidence-hold procedures.
- Obtain security and co-chair approval.

**Approval Authorities:** Information Barrier and Counterintelligence Security Director; Equal National Co-Chairs; Joint Security Committees

### 8. Replicated Ledger and Synchronization Strategy

**ID:** 92578ee5-b26c-4959-9a9e-6c673e2dd3b8

**Description:** High-level technical strategy for the local-first hash-chained tamper-evident ledger, continuous hash-commitment exchange, bounded synchronization, divergence alerting, and reconciliation drill requirements supporting 5-minute local recording and 1-hour synchronization targets. Type: Technical Strategy.

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Primary Template:** NIST Blockchain/Immutable Ledger Considerations

**Secondary Template:** ISO/IEC 23257 Blockchain Reference Architecture

**Steps:**

- Define ledger architecture, local-first recording, and hash-commitment exchange.
- Set synchronization and divergence thresholds to be validated by tests.
- Design reconciliation drill scenarios.
- Coordinate with information-barrier requirements for privacy.
- Approve through joint technical governance.

**Approval Authorities:** Joint Technical Team; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs for threshold approval

### 9. Baseline Inventory and Cryptographic Asset Registry Framework

**ID:** 13755547-02e0-4650-84bf-e0e090f4a127

**Description:** Framework for conducting and certifying the joint baseline physical inventory of all covered equipment at declared sites and reconciling it into a cryptographic asset registry before clock start, including recount rules and discrepancy resolution. Type: Verification Readiness Framework.

**Responsible Role Type:** Mirrored Inspectorate Operations Director

**Primary Template:** IAEA Physical Inventory Verification Procedures

**Secondary Template:** ISO/IEC 19770-1 IT Asset Management Standard

**Steps:**

- Compile candidate site asset registers and layout data.
- Define serialization, tagging, and reconciliation procedures.
- Set materiality and recount thresholds for discrepancies.
- Execute joint baseline inventory at all six declared sites.
- Certify baseline as a mandatory entry condition.

**Approval Authorities:** Mirrored Inspectorate Operations Director; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

### 10. Intake Staging and Exit Disposition Lifecycle Verification Framework

**ID:** fe50e8b7-ea49-43c1-9489-27ec0637660b

**Description:** High-level framework for jointly controlled intake staging, pre-installation identity gates, permitted exit dispositions, witnessed destruction or verified disablement, and unresolved-exit materiality triggers, closing the equipment lifecycle. Type: Lifecycle Verification Strategy.

**Responsible Role Type:** Mirrored Inspectorate Operations Director

**Primary Template:** OPCW Destruction Verification Protocol Model

**Secondary Template:** INF Treaty Elimination Protocol Model

**Steps:**

- Define staging jurisdiction options and identity-gate requirements.
- Define compliant exit dispositions and irreversible disablement criteria.
- Set unresolved-exit materiality and suspension triggers.
- Coordinate with vendor-refusal ladder and latency budget.
- Approve through joint operational leadership.

**Approval Authorities:** Mirrored Inspectorate Operations Director; Joint Technical Team; Equal National Co-Chairs

### 11. Matched-Site Parity Calibration and Site Selection Framework

**ID:** 9f9ab504-2c16-4fea-a1a8-e4f32dc0ff37

**Description:** High-level framework for selecting the six declared sites, defining multi-attribute parity (equipment value, operational role, layout, security constraints, grid/climate, vendor coverage), benchmarking reciprocal access, and including stress sites and fallback sites. Type: Site Selection and Parity Framework.

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Primary Template:** IAEA Facility Attachment / Site Selection Criteria Template

**Secondary Template:** DoD Installation Assessment Criteria

**Steps:**

- Compile candidate site data and attribute matrix.
- Draft parity scoring and fallback pre-qualification rules.
- Negotiate matched set with both governments.
- Benchmark reciprocal access hours in readiness phase.
- Obtain co-chair certification of matched set.

**Approval Authorities:** Equal National Co-Chairs; Datacenter Site Preparation and Cross-Border Logistics Manager; Joint Legal Task Force

### 12. Entry-Condition Sequencing and Readiness Certification Framework

**ID:** 0c108ab7-6cc3-4ddd-af40-b6a63f73b90c

**Description:** Framework for sequencing and jointly certifying all mandatory entry conditions (original seven plus baseline inventory, inspector-access annex, and escrow pre-funding), including integrated readiness tracker, parallel workstreams, shadow exercises, escalation at the 12-month boundary, and clock-start certification. Type: Readiness Gating Framework.

**Responsible Role Type:** Bilingual Training, Translation, and Readiness Certification Coordinator

**Primary Template:** Program Readiness Certification Template

**Secondary Template:** NASA TRL / Gate Review Framework

**Steps:**

- List all entry conditions with named owners and evidence slots.
- Build integrated readiness tracker and status reporting.
- Define joint certification process for co-chairs.
- Run provisional shadow exercises after site selection.
- Escalate open conditions to heads of state at the 2027-09-04 boundary.

**Approval Authorities:** Equal National Co-Chairs; Heads of State/Party Leadership for escalation

### 13. Phase One Test and Evaluation Strategy

**ID:** 592c948d-6fee-45ea-9a05-9131a41054b6

**Description:** High-level strategy for the 90-day test design, challenge categories, event counting, statistical limitations, and verdict evidence, including a feasibility check of whether the required challenge-event counts can be executed within the window. Type: Test Strategy.

**Responsible Role Type:** Independent Red Team and Challenge Exercise Director

**Primary Template:** DoD Test and Evaluation Master Plan (TEMP) Template

**Secondary Template:** CTBTO OSI Exercise Design Handbook

**Steps:**

- Define test objectives and mandatory challenge categories.
- Estimate challenge-event counts per site and event type.
- Assess statistical feasibility within the 90-day window.
- Plan pilot exercises to validate measurement procedures.
- Obtain joint technical and co-chair approval.

**Approval Authorities:** Independent Red Team and Challenge Exercise Director; Joint Technical Team; Equal National Co-Chairs

### 14. KPI Threshold Validation and Statistical Analysis Framework

**ID:** 3495bd9c-62e4-4fed-b025-757b328221e1

**Description:** Pre-registered statistical design framework for false-negative and false-positive rates, confidence intervals, sample sizes, parity tolerances, unresolved-event handling, and threshold validation before any Go decision. Type: Statistical Framework.

**Responsible Role Type:** Independent Verification Statistician

**Primary Template:** Pre-registered Analysis Plan Template (Open Science Framework)

**Secondary Template:** Arms Control Verification Statistical Design Guidelines

**Steps:**

- Retain an independent verification statistician.
- Define denominators, analysis populations, and confidence-interval methods.
- Calculate required challenge sample sizes per event category.
- Run pilot blind challenges to generate preliminary data.
- Mark all unsupported thresholds as TBD until validation.

**Approval Authorities:** Independent Verification Statistician; Joint Technical Team; Equal National Co-Chairs

### 15. Go/Modify/Stop Verdict Construction and Materiality Framework

**ID:** 0ae580fb-34a4-435c-9171-93363deba887

**Description:** Framework for aggregating hundreds of findings into a joint verdict, defining the materiality corridor, bright-line triggers, shared findings narrative, staged technical and political decision process, and unresolved-discrepancy age limits. Type: Decision Framework.

**Responsible Role Type:** Discrepancy Adjudication and Verdict Construction Lead

**Primary Template:** Logical Framework Approach Template

**Steps:**

- Define materiality as risk appetite and set bright-line Stop triggers.
- Draft the shared findings narrative template.
- Fix the deliberation window and escalation defaults.
- Separate inspector-reported technical results from co-chair political determination.
- Obtain co-chair approval of the verdict construction process.

**Approval Authorities:** Discrepancy Adjudication and Verdict Construction Lead; Equal National Co-Chairs

### 16. Blind Challenge Exercise Program Framework

**ID:** f36c5027-287d-48ac-8bc2-06d7dbcc402b

**Description:** High-level framework for mandatory unannounced blind challenge types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator), independence controls, and KPI evidence feed. Not an operational schedule. Type: Exercise Program Framework.

**Responsible Role Type:** Independent Red Team and Challenge Exercise Director

**Primary Template:** Red Team Exercise Charter Template

**Secondary Template:** CTBTO IFE After-Action Review Template

**Steps:**

- Define challenge categories and injection rules.
- Establish independence and no-advance-knowledge controls.
- Specify data collection and detection metrics.
- Plan exercise timing secrecy and site scheduling.
- Approve charter with protected independence provisions.

**Approval Authorities:** Independent Red Team and Challenge Exercise Director; Equal National Co-Chairs for charter only; protected from removal during Phase One

### 17. Vendor Refusal Containment and Unverifiable-Equipment Escalation Framework

**ID:** 1aa45d32-17d9-47da-bee7-0ec28af5da61

**Description:** Framework for the forced-evidence ladder (vendor-supervised testing, clean-room examination, accredited independent examiners, spare hardware), pre-negotiated vendor-access agreements, and rules for classifying equipment as unverifiable without letting one refusal cascade across sites. Type: Contingency Framework.

**Responsible Role Type:** Operator and Vendor Compliance Liaison

**Primary Template:** Model Vendor Access Agreement Template

**Secondary Template:** OPCW Industry Inspection / Confidentiality Annex Model

**Steps:**

- Draft model vendor-access agreements before clock start.
- Pre-accredit independent clean-room examiners.
- Define the forced-evidence ladder and per-site thresholds.
- Set escalation rules for dominant-vendor refusal contagion.
- Obtain joint legal and co-chair approval.

**Approval Authorities:** Joint Legal Task Force; Equal National Co-Chairs

### 18. Mirrored Inspectorate Staffing and Surge Capacity Strategy

**ID:** ed74df98-79e3-4c00-9d0e-0037577d31ae

**Description:** High-level staffing strategy deriving headcount from a workload formula covering site count, 24/7 coverage, leave and backup multiplier, separation of duties, no single-person critical functions, full-time surge cadre, and dual-national observation. Type: Workforce Strategy.

**Responsible Role Type:** Mirrored Inspectorate Operations Director

**Primary Template:** Workforce Planning Model Template

**Secondary Template:** IAEA Inspectorate Staffing Model

**Steps:**

- Build workload-based headcount model from site count and shift coverage.
- Define roles, competencies, and separation-of-duties assignments.
- Plan security clearances and bilingual recruitment pipeline.
- Cost the staffing model against the $750M inspectorate envelope.
- Approve through operational and fiscal governance.

**Approval Authorities:** Mirrored Inspectorate Operations Director; Fiscal Escrow and Independent Audit Controller; Equal National Co-Chairs

### 19. Escrow, Contribution-Release, and Currency Risk Framework

**ID:** d05080b9-82ea-4c15-9c00-cded0c5867d6

**Description:** High-level fiscal framework for full escrow pre-funding, envelope-coded drawdowns, quarterly USD reconciliation, structured CNY conversion windows, funding-timeliness KPI with a 10-business-day trigger, and FX or inflation mitigation. Type: Fiscal Governance Framework.

**Responsible Role Type:** Fiscal Escrow and Independent Audit Controller

**Primary Template:** Model Escrow Agreement Template

**Secondary Template:** World Bank Disbursement Procedures Handbook

**Steps:**

- Draft escrow terms with jointly signatory control.
- Define envelope codes and drawdown authorization procedures.
- Set structured CNY conversion windows and periodic revaluation rules.
- Establish the funding-timeliness KPI and suspension trigger.
- Obtain treasury and co-chair approval.

**Approval Authorities:** Both Treasuries; Equal National Co-Chairs; Ministries of Finance

### 20. High-Level Budget and Envelope Allocation Framework

**ID:** f086125c-0732-4229-8fa4-baf82f59331d

**Description:** Framework mapping the $5B budget to the seven envelopes, cost-control rules, quarterly reforecasts, contingency prioritization, and independent audit requirements. Type: Budget Framework.

**Responsible Role Type:** Fiscal Escrow and Independent Audit Controller

**Primary Template:** Government Budget Structure Template

**Secondary Template:** UN Programme Budget Template

**Steps:**

- Allocate the $5B budget across seven predefined envelopes.
- Define expenditure codes and envelope-level controls.
- Establish quarterly reforecast and contingency prioritization procedures.
- Plan independent audit and fiscal reporting requirements.
- Approve through fiscal governance.

**Approval Authorities:** Equal National Co-Chairs; Both Treasuries

### 21. Funding Agreement Structure and Template

**ID:** 9fdf6a9b-1183-406e-a3a2-feb93e4ef8a4

**Description:** Template and structure for the bilateral contribution and escrow agreement between the two governments, including signatory authority, drawdown conditions, automatic suspension triggers, escrow-return clauses, and dispute resolution. Type: Legal Agreement Template.

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Primary Template:** Model Bilateral Contribution Agreement Template

**Secondary Template:** Model Escrow Agreement Template

**Steps:**

- Draft contribution obligations and equal 50/50 pre-funding clauses.
- Define escrow release conditions and envelope-coded drawdowns.
- Include funding-delay suspension triggers and quiet-veto protections.
- Add termination, escrow-return, and dispute-settlement clauses.
- Obtain joint legal and treasury review.

**Approval Authorities:** Equal National Co-Chairs; Both Governments' Legal and Treasury Authorities

### 22. Stakeholder Engagement and Political Continuity Strategy

**ID:** 30447a3c-0b8d-4503-881c-c9292e4e88d1

**Description:** High-level strategy for engaging primary and secondary stakeholders, legislative outreach, transition briefings, track-II channels, escrow-return and withdrawal scenarios, and making termination politically costly. Type: Stakeholder and Political Strategy.

**Responsible Role Type:** Political Continuity and Government Liaison

**Primary Template:** PMI Stakeholder Engagement Plan Template

**Secondary Template:** Track-II Diplomacy Engagement Model

**Steps:**

- Map primary and secondary stakeholders with interests and influence.
- Define engagement cadence and channels for each stakeholder group.
- Draft political-continuity commitments and transition briefing packages.
- Develop escrow-return and withdrawal scenario plans.
- Obtain co-chair and leadership approval.

**Approval Authorities:** Equal National Co-Chairs; Heads of State/Party Leadership

### 23. Strategic Communications and Public KPI Narrative Framework

**ID:** fb98ef8f-4ac1-42fd-9636-51fc6616b9c4

**Description:** Framework for the unclassified 'killer application' narrative (crisis-stability compute verification), public KPI dashboard, communications protocols protecting classified schedules and evidence, and domestic legitimacy building. Type: Communications Strategy.

**Responsible Role Type:** Strategic Communications Lead

**Primary Template:** Government Strategic Communications Plan Template

**Steps:**

- Develop the crisis-stability killer-application narrative.
- Design the public KPI dashboard showing reciprocal access and detection credibility.
- Protect confidential covered-equipment schedules and evidence in all messaging.
- Coordinate approval with co-chairs and security director.
- Launch the communications package before the entry-condition phase.

**Approval Authorities:** Equal National Co-Chairs; Strategic Communications Lead; Information Barrier and Counterintelligence Security Director for classification

### 24. Initial High-Level Integrated Master Schedule

**ID:** 363dac48-c984-441a-bfbe-c07d93d9f9cc

**Description:** High-level milestone schedule from 2026-09-04 through entry-condition certification by 2027-09-04 and the 90-day Phase One clock, with dependencies, parallel workstreams, and escalation boundaries. Type: Schedule Framework.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** Integrated Master Schedule Template (MS Project)

**Secondary Template:** Government Gantt/Milestone Schedule Template

**Steps:**

- Identify all mandatory entry-condition milestones.
- Map dependencies across legal, fiscal, site, staffing, and verification workstreams.
- Set parallel preparation tracks and readiness tracker integration.
- Define escalation boundaries at the 2027-09-04 boundary.
- Approved by co-chairs after review.

**Approval Authorities:** Equal National Co-Chairs; Joint Secretariat

### 25. Risk Register

**ID:** f630d034-3b3d-45ee-98c5-9e79a01d4f8f

**Description:** Initial risk register capturing identified risks from assumptions, SWOT analysis, and expert review with likelihood, severity, mitigation owners, and escalation triggers. Type: Risk Management Document.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** ISO 31000 Risk Register Template

**Secondary Template:** PMI Risk Management Plan Template

**Steps:**

- Compile risks from assumptions, SWOT, and expert review.
- Score likelihood and severity for each risk.
- Assign named mitigation owners and actions.
- Set review cadence and escalation thresholds.
- Approve initial register.

**Approval Authorities:** Joint Secretariat; Equal National Co-Chairs for risk thresholds

### 26. Monitoring, Evaluation, and Learning Framework

**ID:** b289d954-4ed8-4d59-a592-266be3cecbd2

**Description:** High-level M&E framework for program-level KPIs, data sources, reporting cadence, verification of thresholds, and learning loops feeding the Go/Modify/Stop verdict. Type: M&E Framework.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** USAID M&E Plan Template

**Secondary Template:** World Bank Logical Framework

**Steps:**

- Define M&E indicators tied to goal statement KPIs.
- Specify data sources, baselines, and reporting cadence.
- Establish learning reviews feeding threshold validation.
- Integrate findings into the Go/Modify/Stop verdict construction.
- Approve through joint governance.

**Approval Authorities:** Equal National Co-Chairs; Joint Secretariat

### 27. Change Management Plan

**ID:** aca46311-7a33-4b62-a9cd-a847a321d2d6

**Description:** Plan for managing political, legal, staffing, and schedule changes during the entry-condition phase, including decision rights, communication, continuity, and transition management. Type: Change Management Plan.

**Responsible Role Type:** Joint Secretariat / Program Integration Lead

**Primary Template:** Prosci ADKAR Change Management Plan

**Secondary Template:** APMG Change Management Framework

**Steps:**

- Identify likely change triggers including leadership transitions and appropriations shifts.
- Define impact assessment and decision-rights rules.
- Develop stakeholder communications and training plans.
- Create transition-management and continuity procedures.
- Approve through co-chairs.

**Approval Authorities:** Equal National Co-Chairs; Joint Secretariat

### 28. Communication Plan

**ID:** 8f64bc68-bd28-42eb-a01f-b96494320bd1

**Description:** Plan for internal and external communications, including classified handling, joint messaging, stakeholder-specific channels, escalation notifications, and public KPI dashboard updates. Type: Communications Plan.

**Responsible Role Type:** Strategic Communications Lead

**Primary Template:** PMI Communications Management Plan Template

**Secondary Template:** Government Communication Plan Template

**Steps:**

- Define audience groups and their information needs.
- Set message frameworks and channel selection.
- Establish classification and approval workflows.
- Plan escalation notifications for co-chairs and heads of state.
- Approve and issue the plan.

**Approval Authorities:** Equal National Co-Chairs; Strategic Communications Lead; Information Barrier and Counterintelligence Security Director

### 29. Inspector Visa and Customs Access Annex Framework

**ID:** 6b8f4b51-9bd4-479e-8ad8-7952d49856f9

**Description:** High-level framework for a standing bilateral annex providing 48-hour multiple-entry visas, pre-cleared tool manifests, privileges and immunities, customs pre-authorization, and a mandatory travel-and-clearance drill before clock start. Type: Legal-Operational Annex Framework.

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Primary Template:** Status of Forces Agreement Annex Model

**Secondary Template:** IAEA Inspector Visas Arrangements Model

**Steps:**

- Negotiate visa processing and multiple-entry terms.
- Pre-clear diagnostic equipment manifests and customs procedures.
- Define privileges and immunities limited to official verification acts.
- Plan and execute an end-to-end travel-and-clearance drill.
- Certify the annex as a mandatory entry condition.

**Approval Authorities:** Joint Legal Task Force; Equal National Co-Chairs; Customs and Visa Authorities in Both Countries

### 30. Covered-Equipment Schedule Versioning and Attribute-Based Coverage Strategy

**ID:** fb905dcb-c0d1-406d-a5c2-1488e5af9b3d

**Description:** Framework for maintaining a confidential, versioned, attribute-based covered-equipment schedule with double-key specialist approval, fast-track provisional listings, sunset reviews, and pre-registered dispute criteria. Type: Technical Configuration Strategy.

**Responsible Role Type:** Covered-Equipment Schedule Custodian

**Primary Template:** Configuration Management Plan Template (ISO 10007)

**Secondary Template:** IT Asset Management Classification Framework

**Steps:**

- Define the attribute-based coverage framework and terminology.
- Establish double-key approval and versioned changelog procedures.
- Set fast-track provisional listing and sunset review rules.
- Pre-register dispute criteria for schedule revisions.
- Obtain co-chair approval.

**Approval Authorities:** Covered-Equipment Schedule Custodian; Equal National Co-Chairs for double-key approval

### 31. Site Readiness and Cross-Border Access Strategy

**ID:** 62dcd258-d7e3-4b6b-a4f6-233d1c15b6de

**Description:** High-level strategy for preparing declared sites with N+1 power, jointly controlled staging areas, bounded inspection zones, secure facilities, and fallback sites, and for ensuring visa and customs access meets the 24-hour physical-confirmation latency budget. Type: Site Readiness Strategy.

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Primary Template:** Infrastructure Readiness Assessment Template

**Secondary Template:** IAEA Facility Attachment Preparation Model

**Steps:**

- Define site readiness workstreams and acceptance criteria.
- Conduct site surveys and construct staging and inspection zones.
- Pre-qualify fallback sites per country.
- Run the travel-and-clearance drill and measure against latency budget.
- Certify site readiness with co-chairs.

**Approval Authorities:** Datacenter Site Preparation and Cross-Border Logistics Manager; Equal National Co-Chairs

### 32. Environmental and Grid Resilience Strategy

**ID:** 571a0adf-9ec0-4262-96af-188d08c2ebaa

**Description:** High-level strategy for assessing and mitigating power-grid, climate, cooling, and disaster risks at Northern Virginia, Beijing/Hebei, and Guizhou sites, including N+1 power, 99.9% uptime, fallback sites, and disaster reserve allocation. Type: Resilience Strategy.

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Primary Template:** Business Continuity and Disaster Recovery Framework Template

**Secondary Template:** ISO 22301 Business Continuity Management Template

**Steps:**

- Compile climate, grid, and hazard data for all candidate sites.
- Define resilience standards including N+1 power and 99.9% uptime.
- Reserve approximately $20M for disaster response.
- Pre-qualify fallback sites and portable power options.
- Approve through site readiness and fiscal governance.

**Approval Authorities:** Datacenter Site Preparation and Cross-Border Logistics Manager; Fiscal Escrow and Independent Audit Controller; Equal National Co-Chairs

### 33. Material-Event Latency Budget and Silent-Window Definition Framework

**ID:** 4d2b29e0-d243-4641-8e0f-fe6f46b22ea5

**Description:** Framework for fixing the maximum time a physical material change may go unrecorded, allocating the budget across operator reporting, physical confirmation, and ledger recording, and defining silent-window bounds that red teams exploit and blind challenges must beat. Type: Verification Latency Framework.

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Primary Template:** Verification Latency Budget Template

**Secondary Template:** DoD Time-Sensitive Targeting Latency Model

**Steps:**

- Define provisional layered latency thresholds (e.g., 4h reporting, 24h confirmation, 1h ledger recording).
- Assess trade-offs against production disruption and information barriers.
- Set silent-window bounds and unannounced sweep compensation rules.
- Validate thresholds through pilot blind challenges.
- Approve through joint technical governance.

**Approval Authorities:** Hardware Identity and Evidence Integrity Technical Lead; Joint Technical Team; Equal National Co-Chairs

## Documents to Find

### 1. Official Texts of Bilateral Verification Precedents and Instruments

**ID:** 81402403-9999-4a2a-aa7d-3fa5b66d7cc5

**Description:** Primary legal instruments and official protocols from the INF Treaty, New START, Joint Verification Experiment, IAEA Additional Protocol, and OPCW Chemical Weapons Convention, including annexes on inspection, managed access, and confidentiality. Raw legal source material for drafting the bilateral instrument and access annexes.

**Recency Requirement:** Original texts; current status through 2026 (e.g., New START term ended February 2026)

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Access Difficulty:** Easy – treaty texts and official protocols are publicly available on government and international organization websites; some JVE declassified technical annexes may require OSTI search but are generally open.

**Steps:**

- Search U.S. State Department treaty archives and official collections.
- Consult NTI, IAEA, and OPCW official repositories.
- Request declassified JVE documentation from OSTI/DOE OpenNet.

### 2. U.S. Statutory and Regulatory Text on Export Controls, Customs, and Foreign Access

**ID:** 8de61f4a-ebd4-432c-bd3f-0756f802faaa

**Description:** Raw text of EAR, ITAR, IEEPA, customs regulations, visa regulations, and federal laws relevant to foreign inspector access, equipment import and export, data transfer, and federal appropriation of funds. Needed for the legal-form memorandum and implementing legislation.

**Recency Requirement:** Current codification as of 2026

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Access Difficulty:** Easy – public legal databases and official government websites.

**Steps:**

- Search eCFR and govinfo for current regulatory text.
- Consult BIS, DDTC, CBP, and State Department guidance.
- Request legal opinions from DOJ and agency general counsel.

### 3. PRC Legal Texts on Data Security, State Secrets, Export Control, and Foreign Inspector Authority

**ID:** 8aa3f364-5faa-4006-b475-ac90a8fe3eee

**Description:** Raw legal text of the PRC Data Security Law, Cybersecurity Law, State Secrets Law, Export Control Law, Customs Law, and relevant State Council regulations affecting foreign access, cross-border data transfer, and domestic compulsion of operators. Needed for legal feasibility and implementing legislation.

**Recency Requirement:** Current versions in force in 2026

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Access Difficulty:** Medium – official texts are public but English translations may require subscription or official verification.

**Steps:**

- Search official gazettes (gov.cn, npc.gov.cn) for authoritative Chinese text.
- Use China Law databases for English translations where needed.
- Consult MOFA and legislative-affairs bodies for official confirmation.

### 4. Official U.S. and China Datacenter and Electricity Infrastructure Statistical Data

**ID:** 42df667f-15f8-4cc8-b71c-9ba349a2919f

**Description:** Raw statistical data from the U.S. EIA, China National Bureau of Statistics, China Electricity Council, and regional grid operators on datacenter electricity consumption, grid reliability, capacity, and regional infrastructure. Needed for site selection and resilience assessments.

**Recency Requirement:** Most recent 1–3 years (2023–2026)

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Access Difficulty:** Easy–Medium – many datasets are open; some grid-level reliability data may require registration or request.

**Steps:**

- Download EIA open data and NBS yearbooks.
- Request grid reliability data from PJM and relevant Chinese grid corporations.
- Compile into a site assessment dataset.

### 5. Candidate Site Baseline Asset Registers and Facility Records

**ID:** f4663a3b-86fd-47d8-91fc-ff11aa7d4c01

**Description:** Raw operator-provided asset registers, floor plans, power and cooling specifications, maintenance logs, vendor contracts, and existing equipment serialization records for candidate datacenters in Northern Virginia, Beijing/Hebei, and Guizhou. Needed to plan the joint baseline inventory and parity scoring.

**Recency Requirement:** As close to baseline inventory date as possible; current 2026–2027

**Responsible Role Type:** Mirrored Inspectorate Operations Director

**Access Difficulty:** Hard – sensitive commercial and security data; requires NDAs, government support, and joint access agreements.

**Steps:**

- Submit formal data requests to candidate operators under confidentiality agreements.
- Conduct joint site surveys.
- Reconcile maintenance and procurement records.

### 6. US and China Customs, Visa, and Temporary Import Regulations for Inspection Equipment

**ID:** 51571db4-a0b1-4aa0-abd2-0ddf2b94d895

**Description:** Raw current regulations and forms governing temporary importation of diagnostic tools, customs pre-clearance, visa categories for foreign inspectors, and privileges and immunities. Needed to draft the inspector visa and customs annex.

**Recency Requirement:** Current regulations as of 2026

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Access Difficulty:** Easy–Medium – public regulations are accessible; specific rulings may require official inquiries.

**Steps:**

- Review CBP and GACC regulations.
- Consult U.S. State Department and Chinese immigration authorities.
- Obtain tariff schedule classifications and compile pre-clearance requirements.

### 7. Official Power Grid Reliability and Climate Hazard Data for Selected Regions

**ID:** a0453cde-e49d-4e2b-a0dc-49b8d2cfe6ed

**Description:** Raw grid reliability, outage, and climate or hazard datasets for Northern Virginia/Ashburn, Beijing/Hebei, and Guizhou/Gui'an, including historical severe weather events, grid congestion reports, and hydroelectric seasonal variability. Needed for environmental and physical-resilience strategy.

**Recency Requirement:** Most recent 5–10 years (2016–2026)

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Access Difficulty:** Medium – some datasets open; regional grid and Chinese meteorological data may require registration or purchase.

**Steps:**

- Obtain PJM reliability reports and congestion studies.
- Download NOAA and China Meteorological Administration climate data.
- Collect regional grid company statistics for selected zones.

### 8. Existing US-China Bilateral Agreements and MOUs on Technology, Trade, and Security

**ID:** bdc6ab60-5658-4106-9acc-f96851628a81

**Description:** Raw text of existing agreements such as the U.S.-China Science and Technology Agreement, Phase One trade deal, and any MOUs on AI or strategic technology, to inform legal form, scope boundaries, and potential precedents for bilateral cooperation.

**Recency Requirement:** Current active agreements and recent renewed or expired instruments as of 2026

**Responsible Role Type:** Political Continuity and Government Liaison

**Access Difficulty:** Easy–Medium – most agreements are public; some MOUs may be confidential or difficult to locate.

**Steps:**

- Search State Department and China MFA treaty and agreement databases.
- Request copies via congressional research services.
- Consult track-II diplomatic records for supplementary MOUs.

### 9. Official Personnel Security Clearance and Foreign National Access Regulations

**ID:** cf6209ec-ed1c-442d-85dd-2583d7f4e198

**Description:** Raw laws and regulations for security clearance processing, eligibility for foreign nationals, access to classified information, and need-to-know compartmentation in both countries. Needed for staffing, clearance pipeline planning, and information-barrier compliance.

**Recency Requirement:** Current as of 2026

**Responsible Role Type:** Bilingual Training, Translation, and Readiness Certification Coordinator

**Access Difficulty:** Medium – U.S. regulations are public; Chinese counterpart rules may be internal or restricted, requiring official liaison.

**Steps:**

- Review U.S. national security adjudicative guidelines and agency regulations.
- Obtain Chinese counterpart regulations via official security liaison channels.
- Consult security clearance offices for processing timelines.

### 10. Standard Hardware Identity, Serialization, and Cryptographic Attestation Standards

**ID:** 98ae7800-bd2f-4001-abd4-ea91d671bcf0

**Description:** Raw technical standards from ISO/IEC, IEEE, Trusted Computing Group, and related bodies for asset tags, serialization, secure identifiers, and attestation protocols, needed to define equipment-identity gates and ledger evidence classes.

**Recency Requirement:** Current standards as of 2026

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Access Difficulty:** Medium – many standards are publicly available but some require purchase or membership.

**Steps:**

- Search ISO/IEC and IEEE standards catalogs.
- Access Trusted Computing Group specifications.
- Obtain relevant national adoption documents.

### 11. Official National AI and Strategic Technology Policy Documents from the U.S. and China

**ID:** 9566177c-036f-4472-978a-4ac28af33a6f

**Description:** Raw policy documents, executive orders, white papers, and public statements from U.S. and Chinese governments on frontier AI, compute governance, and national security, needed to align the killer-application narrative and political context.

**Recency Requirement:** Most recent 2–5 years (2021–2026)

**Responsible Role Type:** Political Continuity and Government Liaison

**Access Difficulty:** Easy – public official documents.

**Steps:**

- Search whitehouse.gov, gov.cn, and State Council policy releases.
- Collect congressional testimony and Chinese official statements.
- Compile relevant excerpts into a policy context file.

### 12. Official IAEA Safeguards Statistical Data and Facility Inventory Information for China

**ID:** edc02444-70ce-49af-8fba-1b2eeb381f33

**Description:** Raw official statistical data from the IAEA Safeguards Implementation Report and INFCIRC voluntary-offer declarations, including facility inventory counts and inspection statistics. Needed to calibrate baseline inventory and verification workload using existing China-proximate verification experience.

**Recency Requirement:** Most recent published IAEA Safeguards Implementation Report (2024/2025)

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Access Difficulty:** Easy – Safeguards Implementation Report summaries are public; detailed facility-specific data may be safeguarded and only partially accessible.

**Steps:**

- Search IAEA official publications and safeguards reports.
- Request access to unclassified statistical tables via the IAEA library.
- Consult China INFCIRC/369 documentation.

### 13. Raw USD/CNY Exchange Rate and Inflation Statistical Data

**ID:** 47674cd6-3454-4364-a3fb-338d6b7a64c7

**Description:** Historical and current exchange-rate, inflation, and interest-rate data from the U.S. Federal Reserve, PRC PBoC, and IMF, needed for FX risk modeling and structured conversion windows.

**Recency Requirement:** Monthly data through the latest quarter of 2026

**Responsible Role Type:** Fiscal Escrow and Independent Audit Controller

**Access Difficulty:** Easy – public statistical databases.

**Steps:**

- Download FRED and PBoC statistical databases.
- Access IMF International Financial Statistics.
- Calculate volatility and scenario ranges for the contingency envelope.

### 14. Official Public Budget and Appropriations Procedural Documents for Both Governments

**ID:** 9314a1c3-792b-4e5f-b090-58b8a97d6041

**Description:** Raw legislative texts, budget resolutions, appropriations laws, and OMB or State Council guidance governing advance appropriations, international transfers, and escrow authorities. Needed to validate escrow pre-funding and milestone-tranche fallback.

**Recency Requirement:** Current fiscal-year documents (2025–2026)

**Responsible Role Type:** Fiscal Escrow and Independent Audit Controller

**Access Difficulty:** Medium – public but requires legal interpretation; some internal guidance is restricted.

**Steps:**

- Search Congress.gov, OMB, and Ministry of Finance official releases.
- Review appropriations committee reports.
- Consult legislative counsel for escrow feasibility.

### 15. Local Zoning, Environmental, and Grid-Connection Permit Requirements for Candidate Sites

**ID:** 332bd1be-6f1b-41ae-95a4-96af3f47f915

**Description:** Raw local ordinances and permit requirements in Loudoun County, Virginia; Langfang/Hebei; and Guizhou Gui'an New Area for datacenter construction, staging areas, secure facilities, and grid connections. Needed for site preparation and entry-condition feasibility.

**Recency Requirement:** Current as of 2026

**Responsible Role Type:** Datacenter Site Preparation and Cross-Border Logistics Manager

**Access Difficulty:** Easy–Medium – U.S. permits are public; Chinese local regulations may require official inquiry.

**Steps:**

- Search county and municipal planning portals.
- Consult local permitting and grid connection offices.
- Compile permit checklists for each candidate site.

### 16. Existing Operator and Vendor Commercial Agreements, NDAs, and Maintenance Contracts

**ID:** 01a0e68a-befe-4908-9228-0863199faaca

**Description:** Raw commercial contracts and service agreements between candidate datacenter operators and vendors or manufacturers that govern maintenance access, proprietary data, and confidentiality. Needed to draft model vendor-access agreements and assess the forced-evidence ladder.

**Recency Requirement:** Current contracts as of 2026

**Responsible Role Type:** Operator and Vendor Compliance Liaison

**Access Difficulty:** Hard – highly confidential commercial agreements; requires government compulsion and NDAs.

**Steps:**

- Request contracts from operators under confidentiality agreements.
- Review vendor terms and identify dominant-vendor dependencies.
- Compile representative clauses for model agreement drafting.

### 17. Raw Case Law and Administrative Rulings on Foreign Inspector Access and Private-Property Compulsion

**ID:** 964136ab-e727-4171-b1d4-143b46ca1a74

**Description:** Raw court decisions, administrative rulings, and legal opinions in U.S. and Chinese jurisdictions on foreign official access, search and seizure limits, privileges and immunities, and compulsion of private parties. Needed to assess domestic legal feasibility and litigation risk.

**Recency Requirement:** Current case law through 2026

**Responsible Role Type:** Bilateral Governance and Legal Implementation Lead

**Access Difficulty:** Medium – legal databases require subscriptions; some rulings are public.

**Steps:**

- Search Westlaw or Lexis and Chinese legal databases.
- Consult constitutional and administrative law experts.
- Compile risk summaries for the legal-form memorandum.

### 18. Raw Data on Datacenter Equipment Procurement and Lifecycle from Supply Chain Databases

**ID:** b2fca606-f2f8-4432-8eb6-7fa0782b271a

**Description:** Raw statistical or transaction data from industry sources, customs import and export databases, or operator procurement systems on computing equipment shipments, serialization, and lifecycle events. Needed to estimate covered-equipment populations and baseline inventory scope.

**Recency Requirement:** Most recent 1–3 years (2023–2026)

**Responsible Role Type:** Hardware Identity and Evidence Integrity Technical Lead

**Access Difficulty:** Medium–Hard – aggregate statistics may be public; operator-level data is sensitive and restricted.

**Steps:**

- Access U.S. Census or import databases and Chinese customs statistics.
- Request aggregated operator procurement data.
- Cross-check with hardware serialization standards.

### 19. Official Historical Verification Exercise Raw Datasets (JVE, IFE, UK-Norway)

**ID:** 3ed77cd3-4737-42b4-a845-1fcc7e651368

**Description:** Raw measurement datasets, exercise event logs, and declassified technical documentation from the Joint Verification Experiment, CTBTO Integrated Field Exercises, and UK-Norway Initiative information-barrier experiments. Needed to inform test design and information-barrier calibration.

**Recency Requirement:** Historical datasets; declassification status current

**Responsible Role Type:** Independent Red Team and Challenge Exercise Director

**Access Difficulty:** Hard – some datasets are declassified but not centrally indexed; requests to agencies and research organizations are required.

**Steps:**

- Search OSTI and DOE OpenNet for JVE data.
- Contact CTBTO OSI Division for IFE documentation.
- Request UKNI documentation via VERTIC or UK government channels.

### 20. Official Standards for Tamper-Evident Seals, Cryptographic Hashing, and Chain-of-Custody

**ID:** 89944deb-c870-40d8-93e7-7afdd7d457bf

**Description:** Raw standards and technical specifications for tamper-evident enclosures and seals, cryptographic hash algorithms, and chain-of-custody documentation from ISO, IEC, NIST, and industry bodies. Needed for evidence integrity architecture.

**Recency Requirement:** Current as of 2026

**Responsible Role Type:** Information Barrier and Counterintelligence Security Director

**Access Difficulty:** Easy–Medium – NIST documents are open; ISO/IEC standards may require purchase.

**Steps:**

- Search NIST publications and ISO/IEC standards catalog.
- Request technical specifications from seal manufacturers.
- Compile applicable hash and chain-of-custody standards.