This plan implies one or more physical locations.

## Requirements for physical locations

- Jointly selected declared datacenter sites in both the United States and China, matched for comparable verification burden
- Controlled staging areas for pre-installation equipment identity verification
- Bounded inspection zones supporting filtered evidence collection and clean-room examination
- Physical security, cybersecurity, and counterintelligence infrastructure adequate for a sovereign national-security program
- Controlled access for mirrored national inspection teams, technical specialists, escorts, and approved vendors
- Reliable power, cooling, network capacity, and logistics support for live challenge exercises without disrupting active computational work
- Space for witnessed movement, maintenance monitoring, and exit/disposition verification

## Location 1
United States

Northern Virginia / Ashburn, Loudoun County, Virginia

Ashburn, Virginia, USA — major declared datacenter corridor; exact facility to be jointly selected

**Rationale**: Northern Virginia is the largest datacenter concentration in the United States and likely to host frontier-relevant computing equipment. Its mature infrastructure, multiple operators, and logistics access support staging areas, bounded inspection zones, and repeated live exercises.

## Location 2
China

Beijing/Hebei cluster

Langfang / Beijing-area declared datacenter facilities, Hebei/Beijing, China — exact facilities to be jointly selected

**Rationale**: The Beijing/Hebei region hosts major Chinese frontier AI and high-performance computing facilities, making it a likely area for declared sites. It provides the high-density computing infrastructure and operator presence needed for matched-pair verification with U.S. sites.

## Location 3
China

Guizhou Province

Gui'an New Area / Guizhou national datacenter hub, China — candidate for an additional matched or stress-test site

**Rationale**: Guizhou is one of China's principal national datacenter hubs and could serve as a second or stress-test site. Its geographic separation and different operating environment help calibrate parity across facility types and test the Consortium's ability to verify under unequal conditions.

## Location Summary
The Consortium cannot operate digitally: it requires physical datacenter sites in both countries for on-site verification, staging, maintenance monitoring, and live challenge exercises. The suggested locations—Northern Virginia, the Beijing/Hebei cluster, and Guizhou—represent high-concentration datacenter regions in both countries and offer the infrastructure, operator ecosystems, and alternative facility profiles needed for matched-site calibration and credible Phase One testing. Final sites must be jointly selected and declared by the two governments.