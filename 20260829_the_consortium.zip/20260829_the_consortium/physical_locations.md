This plan implies one or more physical locations.

## Requirements for physical locations

- secure facilities
- proximity to major datacenters
- capability for extensive inspections

## Location 1
USA

Silicon Valley, California

Various datacenters in Silicon Valley

**Rationale**: Silicon Valley is home to numerous datacenters and tech companies, providing the necessary infrastructure and expertise for the verification of frontier-relevant computing equipment.

## Location 2
USA

Northern Virginia

Various datacenters in Northern Virginia

**Rationale**: Northern Virginia has a high concentration of datacenters and is known for its robust cybersecurity measures, making it an ideal location for secure operations.

## Location 3
China

Beijing

Various datacenters in Beijing

**Rationale**: Beijing hosts several major datacenters and has the necessary governmental support for national security initiatives, making it suitable for the operational test phase.

## Location Summary
The plan requires physical locations for the verification of computing equipment, with Silicon Valley and Northern Virginia in the USA, and Beijing in China being ideal due to their established datacenter infrastructure and security capabilities.