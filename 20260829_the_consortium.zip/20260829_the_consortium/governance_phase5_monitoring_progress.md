### 1. Entry-condition readiness and certification tracking: monitor closure of all ten mandatory entry conditions (bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection and declaration, inspector roster approval, operator/vendor participation agreements, covered-equipment schedule adoption, joint baseline physical inventory and cryptographic asset registry, inspector visa/customs annex and travel-and-clearance drill, and independent validation of the ledger/barrier/KPI systems) against the integrated readiness tracker, with reciprocal certification parity enforced.
**Monitoring Tools/Platforms:**

  - Integrated readiness tracker
  - Entry-condition certification checklist/package
  - Reciprocal certification parity report
  - JSC escalation templates to heads of state/party leadership
  - Gap analysis and remediation plan

**Frequency:** Weekly during the entry-condition phase; daily during the final two months before the 2027-Sep-04 target

**Responsible Role:** Joint Program Management Office (JPMO) with joint certification by the Joint Steering Council (JSC)

**Adaptation Process:** JPMO assigns corrective actions to named workstream leads for each open condition; if any condition risks missing the 12-month target, JPMO escalates to the JSC, which may formally escalate the open political condition to heads of state/party leadership; the Phase One clock is not started until all conditions are jointly certified by both co-chairs.

**Adaptation Trigger:** Any entry condition open after the 2027-Sep-04 target date; uncertified condition at proposed clock start; asymmetric certification progress between the two countries; baseline inventory discrepancy above 2% at any site blocking certification

### 2. Operational KPI dashboard monitoring: track the full pre-registered KPI set covering blind-challenge detection by event type, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, production disruption, funding timeliness, and audit exceptions.
**Monitoring Tools/Platforms:**

  - KPI dashboard
  - KPI Tracking Spreadsheet with confidence intervals
  - Raw exercise logs and evidence records
  - Latency monitoring and alerting tools
  - Ledger divergence and synchronization health reports

**Frequency:** Daily during Phase One; weekly during the entry-condition phase for pre-validation baselines

**Responsible Role:** Joint Program Management Office (JPMO) with KPI threshold validation by the Joint Technical Assurance Board (JTAB) and KPI data-integrity audits by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO implements corrective actions for operational deviations; JTAB re-validates thresholds if data indicate mis-calibration; persistent or material deviations are packaged for JSC double-key decision, including proposals for threshold revision, additional testing, or suspension recommendations.

**Adaptation Trigger:** Any KPI deviation beyond pre-registered thresholds: false-negative rate >5% at 95% confidence; event-recording latency >5 minutes locally; cross-national synchronization >1 hour; divergence reconciliation >24 hours; unresolved discrepancy age >10 business days; unverifiable equipment >2 units per site or >1% of covered changes

### 3. Blind challenge and red-team exercise monitoring: track execution and outcomes of all six mandatory unannounced challenge types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal) to validate silent-window bounds, layered-evidence sufficiency, information-barrier effectiveness, and the credibility of the eventual Go/Modify/Stop evidence base.
**Monitoring Tools/Platforms:**

  - Challenge exercise design plan
  - Independent red-team reports
  - Blind-challenge results tracker by event type
  - No-advance-knowledge protocol compliance log
  - Exercise after-action reports

**Frequency:** After every challenge exercise; weekly cumulative review during Phase One; JTAB session within 72 hours of any exercise or material technical incident

**Responsible Role:** Joint Technical Assurance Board (JTAB) overseeing independent red teams

**Adaptation Process:** JTAB recommends technical procedure corrections, filter-rule adjustments, clean-room protocol changes, or additional test vectors when a challenge type is missed; if detection failures persist above the false-negative threshold, JTAB escalates to the JSC with a recommendation against a Go verdict.

**Adaptation Trigger:** Any blind-challenge miss or false negative; false-negative rate exceeding the 5% threshold at 95% confidence; evidence of red-team advance knowledge or compromised exercise independence; any challenge revealing that over-filtering hides substitution indicators

### 4. Budget envelope, funding timeliness, and fiscal compliance monitoring: track expenditure against the seven budget envelopes, envelope burn rates, escrow balance and drawdown approvals, quarterly USD reconciliation, CNY conversion windows and FX exposure, and contribution-release timing to prevent quiet fiscal vetoes and cost overruns.
**Monitoring Tools/Platforms:**

  - Envelope-level budget control system
  - Escrow reconciliation statements
  - Quarterly reforecast reports
  - Independent audit reports
  - Currency conversion and FX exposure tracker
  - Contingency drawdown request log

**Frequency:** Weekly burn-rate review by JPMO; quarterly reconciliation and independent audit by JAECC

**Responsible Role:** Joint Program Management Office (JPMO) with independent audit by the Joint Audit, Ethics, and Compliance Committee (JAECC) and JSC double-key approval for cross-envelope or contingency actions

**Adaptation Process:** JPMO reallocates within envelopes up to delegated thresholds; any expenditure above USD 10 million, cross-envelope transfer, or contingency drawdown requires JSC double-key approval; funding delays beyond the pre-agreed window are escalated as a KPI-visible suspension trigger; audit exceptions trigger corrective action plans.

**Adaptation Trigger:** Envelope burn rate exceeding forecast by 10%; contribution release delayed more than 10 business days; projected currency or inflation movement consuming more than the USD 500 million contingency reserve; audit exception, suspected fraud, or material fiscal misreporting

### 5. Consolidated risk register and mitigation effectiveness monitoring: maintain and review the consolidated risk register covering governance and deadlock, political continuity, regulatory and legal challenge, financial and currency, supply-chain and vendor refusal, information-barrier security, latency and silent-window, ledger divergence, matched-site parity, staffing, cyber and counterintelligence, red-team independence, schedule drift, operator reluctance, and cost-overrun risks.
**Monitoring Tools/Platforms:**

  - Consolidated risk register
  - Operational risk register (JPMO)
  - Strategic risk register (JSC)
  - Risk scoring and trend matrix
  - Escalation log

**Frequency:** Weekly by JPMO; monthly strategic review by JSC; ad hoc immediately upon any risk realization

**Responsible Role:** JPMO Chief Risk Officer with periodic review and risk-appetite decisions by the Joint Steering Council (JSC)

**Adaptation Process:** Risk owners update mitigation plans and assign corrective actions; risks crossing strategic thresholds are escalated to the JSC for risk-appetite decisions, additional mitigation resourcing, or activation of deadlock, suspension, or escalation procedures; mitigation effectiveness is re-scored after each action.

**Adaptation Trigger:** Risk likelihood or severity increase; identification of a new risk; realization of a top risk such as vendor-refusal cascade, information leak, funding delay, political discontinuity, or cross-border access breakdown

### 6. Information barrier, cybersecurity, and counterintelligence monitoring: continuously monitor information-barrier filter rules, bounded inspection zones, filtered workstations, clean-room protocols, physical and logical separation of national teams, insider-threat indicators, evidence integrity, and the security of the replicated ledger and secure facilities.
**Monitoring Tools/Platforms:**

  - JSCIB security monitoring dashboards
  - Information-barrier filter logs and audit trails
  - Penetration test reports
  - Insider-threat monitoring reports
  - Cyber-incident isolation drill after-action reports
  - Physical security and counterintelligence compliance checklists

**Frequency:** Continuous automated monitoring with weekly JSCIB review; immediate review upon any incident or threshold alert

**Responsible Role:** Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Adaptation Process:** JSCIB directs immediate isolation or evidence-preservation measures under the joint incident-response protocol; filter rules, zone boundaries, or clean-room configurations may be adjusted within JSC-approved policy, with any policy change escalated to the JSC for double-key approval; confirmed evidence-integrity compromises are escalated with a recommendation for automatic hold.

**Adaptation Trigger:** Confirmed IP or cyber incident compromising evidence integrity; critical penetration-test finding; insider-threat indicator; evidence that over-filtering has hidden substitution indicators or under-filtering has exposed protected workloads, model weights, source code, or security architecture

### 7. Discrepancy adjudication and materiality threshold monitoring: track all intake, maintenance, and exit discrepancies through the adjudication pipeline, monitoring materiality classification, unresolved discrepancy age, unverifiable-equipment counts per site, vendor-refusal outcomes, exit-disposition completion, and automatic-suspension triggers.
**Monitoring Tools/Platforms:**

  - Discrepancy tracking dashboard
  - Unresolved-discrepancy age metrics
  - Materiality classification log
  - Automatic-suspension trigger register
  - Vendor-refusal and exit-disposition trackers
  - Neutral arbiter referral log

**Frequency:** Daily during Phase One; immediately upon any material discrepancy or suspension trigger

**Responsible Role:** Joint Discrepancy Adjudication Panel (JDAP)

**Adaptation Process:** JDAP resolves routine discrepancies under delegated evidentiary rules; material findings are recommended to the JSC for double-key authorization; unresolved material discrepancies trigger automatic site-level suspension; deadlocked factual disputes are referred to the neutral technical arbiter; unresolved exits without assigned disposition within 48 hours trigger automatic site review.

**Adaptation Trigger:** Unresolved discrepancy age exceeding 10 business days; unverifiable equipment exceeding 2 units per site or 1% of covered changes; exit without an assigned disposition within 48 hours; JDAP deadlock on a material classification; vendor refusal exhausting the forced-evidence ladder

### 8. Reciprocal access parity and matched-site performance monitoring: monitor reciprocal access hours, verification outcomes, and inspection burden across each matched site pair to validate parity calibration and detect asymmetric access that would trigger a Stop condition.
**Monitoring Tools/Platforms:**

  - Parity scoring matrix (multi-attribute)
  - Reciprocal access-hour benchmarking tracker
  - Site-level verification outcome comparison reports
  - Stress-site exercise logs
  - Site fallback and disaster-response readiness records

**Frequency:** Weekly during Phase One; monthly during site-selection and readiness phases

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB)

**Adaptation Process:** JPMO rebalances inspection scheduling and site-pair assignments; JTAB recommends recalibration of the parity matrix if site characteristics diverge; evidence of asymmetric access or materially unequal verification difficulty is escalated to the JSC as a potential Stop trigger with a joint findings narrative.

**Adaptation Trigger:** Reciprocal access-hour asymmetry beyond the pre-agreed threshold; materially unequal verification outcomes across a matched pair; inability to verify a deliberately hard-to-inspect stress site; one government shielding an operator from access

### 9. Governance health and deadlock monitoring: monitor the functioning of double-key governance, including decision throughput, deadlock duration, impaired-confidence declarations, automatic-suspension activations, and compliance with the no-casting-vote and no-unilateral-overrule rules.
**Monitoring Tools/Platforms:**

  - Decision log and double-key sign-off matrix
  - Deadlock duration tracker
  - Escalation log to heads of state/party leadership
  - Impaired-confidence declaration register
  - Unilateral-action incident log

**Frequency:** Weekly during Phase One; monthly during the entry-condition phase; extraordinary session within 48 hours of an impaired-confidence declaration

**Responsible Role:** JSC Secretariat under the Joint Steering Council (JSC)

**Adaptation Process:** Deadlocked items are deferred under the pre-registered procedure while joint technical and legal bodies develop recommendations; if consensus still fails, the matter is escalated to heads of state or party leadership; automatic site-level suspension remains in effect for unresolved material discrepancies; protective suspension is scoped to affected activities upon impaired-confidence declaration.

**Adaptation Trigger:** Deadlock persisting beyond 10 business days; impaired-confidence declaration by either co-chair; any attempted unilateral finding, sanction, or decision; automatic-suspension activation at any site

### 10. Staffing, clearance, and workforce coverage monitoring: monitor staffing levels against the workload-based model, including 24/7 shift coverage, the 1.5x leave/backup multiplier, separation of duties, no-single-person-critical-function compliance, full-time surge cadre readiness, and clearance and common-training progress.
**Monitoring Tools/Platforms:**

  - Staffing model v1.0
  - Shift coverage and leave-backup schedules
  - Clearance initiation and completion tracker
  - Common training curriculum records
  - Surge cadre roster and deployment log
  - Separation-of-duties compliance matrix

**Frequency:** Weekly by JPMO; monthly certification of coverage ratios and readiness

**Responsible Role:** Joint Program Management Office (JPMO)

**Adaptation Process:** JPMO deploys the surge cadre, initiates cross-training, and adjusts shift assignments to close coverage gaps; clearance delays trigger parallel recruitment or secondment from national verification bodies; structural staffing shortfalls are escalated to the JSC with budget and timeline implications.

**Adaptation Trigger:** Any single-person critical function identified; coverage below the 1.5x backup multiplier; surge deployment exceeding the pre-agreed response window; clearance or training delays preventing a material event from being staffed by two full-time mirrored national inspectors

### 11. Covered-equipment schedule versioning and coverage-gap monitoring: track versioned updates to the confidential attribute-based covered-equipment schedule, fast-track provisional listings, sunset reviews, and any coverage gaps created by new equipment generations or architecture drift.
**Monitoring Tools/Platforms:**

  - Versioned confidential covered-equipment schedule
  - Versioned changelog
  - Fast-track provisional listing log
  - Sunset review calendar
  - Pre-registered dispute criteria register
  - Coverage-gap assessment reports

**Frequency:** Monthly and immediately upon either side fielding a new frontier-relevant equipment generation

**Responsible Role:** Accountable technical schedule custodians under the Joint Technical Assurance Board (JTAB) with JSC double-key approval for revisions

**Adaptation Process:** Technical custodians issue fast-track provisional listings within 48-72 hours to close coverage gaps; JTAB recommends schedule revisions with attribute-based justification; JSC applies double-key approval; unresolved definitional disputes are resolved by reference to the pre-registered interpretive annex rather than renegotiation.

**Adaptation Trigger:** New equipment generation fielded by either country; identified coverage gap that would allow covered equipment to ship outside verification; sunset review due; proposed schedule revision that reopens the bilateral definitional bargain

### 12. Audit, ethics, and KPI data-integrity monitoring: independently audit envelope-level expenditures, domestic operator and vendor compensation disbursements, KPI dashboard inputs against raw exercise logs and evidence records, compliance with information-barrier and data-protection requirements, conflict-of-interest declarations, and whistleblower complaints.
**Monitoring Tools/Platforms:**

  - Quarterly audit reports
  - KPI validation audit plan
  - Raw-data provenance and access protocols
  - Whistleblower channel and complaint log
  - Audit exception register
  - Conflict-of-interest declarations
  - Compensation disbursement audit schedule

**Frequency:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours of an audit exception, whistleblower complaint, data-protection breach, or suspected fraud

**Responsible Role:** Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JAECC issues audit exceptions, requires preservation of records and restricted access during investigations, and recommends protective holds, sanctions, or suspension to the JSC; unresolved exceptions trigger corrective action plans; material fraud or KPI misreporting is escalated as a Stop-level concern that must be resolved before any Go verdict.

**Adaptation Trigger:** Material fraud, corruption, or KPI misreporting; unresolved audit exception; data-protection or GDPR breach; whistleblower complaint requiring protective action; evidence that KPI dashboard inputs have been manipulated

### 13. Legal, interpretive, and cross-border access monitoring: monitor implementation of the binding bilingual glossary, interpretive annex, domestic access authority, model vendor-access agreements, and the standing inspector visa and customs annex, including visa processing times, customs clearance of diagnostic equipment, and any domestic legal challenges to inspector authority.
**Monitoring Tools/Platforms:**

  - Binding bilingual glossary and interpretive annex
  - Legal implementation tracker
  - Visa and customs clearance monitoring log
  - Domestic legal challenge log
  - Travel-and-clearance drill results
  - Export-control and customs compliance reports

**Frequency:** Weekly during the entry-condition phase; as needed during Phase One for legal or access incidents

**Responsible Role:** Joint Legal and Terminology Commission (JLTC)

**Adaptation Process:** JLTC issues legal opinions, updates model instruments, and coordinates with domestic authorities to resolve access barriers; unresolved interpretive disputes or legal challenges threatening inspector access are escalated to the JSC for double-key decision; any visa or customs delay is reported to the JPMO for latency-budget impact assessment.

**Adaptation Trigger:** Visa processing exceeding the 48-hour standing agreement; customs hold on diagnostic or challenge-exercise equipment; domestic legal challenge to foreign inspector authority; interpretive dispute not resolvable by the pre-registered annex; any access barrier that would break the 24-hour physical-confirmation window

### 14. Baseline inventory and asset-registry integrity monitoring: track completion and ongoing integrity of the joint baseline physical inventory and cryptographic asset registry of covered equipment at all six declared sites, including reconciliation of serialized records against operator procurement, maintenance, and disposal records, and full recounts at any site with unexplained discrepancies.
**Monitoring Tools/Platforms:**

  - Cryptographic asset registry
  - Baseline inventory audit checklists
  - Serialized-record reconciliation tracker
  - Full-recount trigger log
  - Operator procurement, maintenance, and disposal records
  - Asset-registry tamper-evidence monitoring

**Frequency:** Continuous during the entry-condition phase until joint certification; quarterly spot-check integrity reviews thereafter

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB) and audit by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO conducts full recounts and reconciliation drills for any site with unexplained serialized discrepancies; JTAB validates asset-registry integrity processes; unresolved baseline discrepancies block certification of that site and escalate to the JSC; any suspected tampering with the asset registry is treated as an evidence-integrity incident.

**Adaptation Trigger:** Unreconciled serialized discrepancy above 2% at any site; disputed initial inventory at proposed clock start; evidence of tampering with the cryptographic asset registry; inability to establish a trusted baseline for subsequent material-change verification