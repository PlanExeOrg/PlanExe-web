
## Audit - Corruption Risks

- Operators or vendors bribing inspectors to certify unverified equipment arrivals, installations, or removals, or to overlook discrepancies during staging, intake, maintenance, or exit verification.
- Government officials administering domestic operator and vendor compensation steering contracts or payments to politically connected datacenter operators, maintenance providers, or logistics companies in exchange for favors or kickbacks.
- Equipment manufacturers or maintenance vendors offering bribes to accredited clean-room examiners or technical specialists to produce favorable examination reports and avoid an unverifiable-equipment classification.
- Red-team members or penetration testers colluding with site operators or program insiders to learn exercise timing or scenarios, allowing blind challenges to be scripted and false-negative rates to be understated.
- Co-chairs or senior officials trading double-key approval of findings, sanctions, or suspensions for unrelated bilateral concessions, or using confidential evidence and the covered-equipment schedule to advantage domestic commercial interests.
- Personnel with access to the confidential covered-equipment schedule, filtered evidence packages, or information-barrier rules leaking sensitive information for personal gain, professional advancement, or foreign commercial advantage.
- Translators or legal specialists manipulating the binding bilingual glossary, interpretive annex, or evidence translations in exchange for bribes or to favor one government's position in a dispute.

## Audit - Misallocation Risks

- Drawing down funds from the wrong budget envelopes or using the $500 million contingency for non-surge, non-emergency expenses without joint double-key approval, eroding envelope-level fiscal control.
- Paying domestic operators and vendors compensation for services not actually performed or at inflated rates due to weak verification of claims, effectively double-charging the site-preparation envelope and contingency.
- Allowing the trained inspectorate to sit idle during entry-condition delays while salaries, clearances, and training costs continue consuming the $750 million inspectorate envelope without producing verification evidence.
- Misreporting KPI dashboard results—such as false-negative rates, event-recording latency, ledger divergence, or reciprocal-access parity—to create a favorable appearance and divert resources away from the areas that actually need correction.
- Maintaining inaccurate or incomplete baseline physical inventory and cryptographic asset registry records, leading to duplicate or ghost equipment entries, wasted verification effort, and invalid material-change determinations.
- Using program assets—diagnostic equipment, filtered workstations, secure facilities, travel funds, or staging areas—for unauthorized or personal purposes rather than for verification activities.
- Suffering avoidable budget overruns from unstructured CNY/USD conversion and revaluation windows, causing local inflation or currency movements to consume the contingency envelope before independent testing and challenge exercises are complete.

## Audit - Procedures

- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns against approved budget codes, performed by a jointly appointed external audit firm and reported to the equal national co-chairs, with confirmation that every expense maps to a defined envelope and any contingency use requires double-key authorization.
- Perform bilateral audits of domestic operator and vendor compensation disbursements, with each government's payments independently examined by the other side's audit unit or a jointly selected auditor to detect favoritism, inflated claims, or duplicate payments; conduct these audits semi-annually and at program close.
- Run monthly ledger integrity and divergence reconciliation drills between the two national ledger copies using independent test events, and have at least two independent penetration-testing firms assess the ledger, attestation, and evidence systems before the Phase One clock starts and again during Phase One.
- Validate KPI dashboard inputs through an independent audit before any Go/Modify/Stop decision, comparing reported false-negative rates, latency values, discrepancy ages, unverifiable-equipment counts, and access-parity metrics against raw exercise logs and evidence records; also perform quarterly spot-check audits during Phase One.
- Conduct a joint baseline physical inventory and cryptographic asset registry audit as a mandatory entry condition, followed by unannounced sample counts of covered equipment at each declared site during Phase One, verifying serial numbers, identity confidence, and disposition records.
- Audit compliance with information-barrier and counterintelligence requirements by reviewing filtered-workstation logs, access-control records, clean-room procedures, and evidence-handling logs to confirm that workloads, model weights, source code, and unrelated infrastructure were not exposed; perform these audits semi-annually and trigger an ad hoc forensic audit after any IP or cybersecurity incident.
- Carry out vendor and operator compliance audits to verify that manufacturers, maintenance providers, logistics companies, and site operators meet reporting, confidentiality, escort, and evidence-preservation obligations, including review of vendor-refusal escalation outcomes and unverifiable-equipment classifications; review these quarterly or after each material refusal.
- Sample inspector travel, visa, customs, and logistics expenses against approved budgets on a quarterly basis to detect inflated claims, unauthorized travel, or misuse of program funds.

## Audit - Transparency Measures

- Maintain a public KPI dashboard updated monthly with aggregate metrics covering blind-challenge detection rates, false negatives and positives, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, funding timeliness, and audit exceptions, with classified evidence details redacted.
- Publish the joint Go/Modify/Stop recommendation and the shared findings narrative after the co-chairs issue the verdict, with sensitive evidence redacted, and publish the pre-agreed Go, Modify, and Stop criteria before the Phase One clock starts.
- Issue quarterly public appropriation and audit reports summarizing envelope-level expenditures, audit exceptions, currency conversion and revaluation results, and aggregate domestic compensation disbursements, available to domestic legislatures and the public.
- Publicly disclose the multi-attribute site-parity matrix and site-selection criteria used to choose and match the six declared datacenter sites, including the inclusion of harder-to-inspect stress sites and pre-qualified fallback sites, to demonstrate that pairing is fair and reciprocal.
- Operate a secure whistleblower channel managed by an independent joint audit office, allowing inspectors, operators, vendors, and staff to report corruption, fraud, obstruction, or misconduct with non-retaliation protections and periodic independent review of complaints.
- Publish the information-barrier filter rules and redaction standards before evidence flows, with a versioned changelog, so the rules for stripping sensitive data are known, auditable, and consistently applied across all inspection events.
- Publicly report the aggregate readiness-tracker certification status and entry-condition closure progress, making any delays or asymmetric completion visible and preventing quiet fiscal or bureaucratic vetoes.
- Provide public access to redacted independent audit reports on fiscal accountability, envelope expenditures, and compensation disbursement audits, while protecting the confidential covered-equipment schedule, evidence details, and sensitive inspection findings.