**Budget Request Exceeding JPMO Delegated Authority (Above USD 10 Million or Cross-Envelope Transfer)**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key affirmative approval by both national co-chairs; no casting vote. If consensus fails, the pre-registered deadlock procedure applies, with escalation to heads of state or party leadership after 10 business days if unresolved.
Rationale: Exceeds the JPMO's delegated expenditure threshold and involves cross-envelope or contingency drawdown authority reserved to the strategic body to protect the approved budget envelopes and fiscal accountability.
Negative Consequences: Unauthorized or asymmetric spending, budget-envelope erosion, loss of fiscal oversight, and a quiet fiscal veto that can stall Phase One operations.

**Confirmed IP/Cyber Incident Compromising Evidence Integrity**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSCIB directs immediate isolation measures under the incident-response protocol and reports to the JSC; JSC decides by double-key whether to hold, suspend, or adjust verification activity based on the JSCIB assessment.
Rationale: A single evidence-integrity compromise is a designated Stop-level trigger, can invalidate ledger records and the Go/Modify/Stop verdict, and requires strategic security-policy authority beyond JSCIB's operational isolation powers.
Negative Consequences: Compromised evidence, invalid challenge results, loss of bilateral confidence, national-security incident escalation, and program suspension or termination.

**JPMO Co-Deputy Deadlock on an Operational Decision**
Escalation Level: Joint Steering Council (JSC)
Approval Process: After the 48-hour JPMO deferral period, the matter escalates to the JSC, which applies double-key approval; an unresolved JSC deadlock follows the pre-registered 10-business-day deadlock procedure.
Rationale: No operational decision may be resolved by a single-country override, and an unresolved co-deputy deadlock blocks daily execution, risks latency-budget breaches, and requires the strategic body to restore joint authority.
Negative Consequences: Operational paralysis, missed 4-hour/24-hour/1-hour latency windows, unresolved discrepancies, and erosion of the no-unilateral-overrule principle.

**Proposed Major Protocol or Scope Change**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key authorization after receiving recommendations from the JPMO, JTAB, and JLTC as applicable; no majority vote or casting vote can alter protocol.
Rationale: Protocol amendments and scope changes alter the bilateral verification bargain and verification boundaries, exceed all delegated operational and technical authorities, and must be approved by equal sovereign co-chairs.
Negative Consequences: Mission creep beyond declared-equipment verification, renegotiation of entry conditions, legal invalidation, and loss of the narrow bilateral mandate.

**Deadlocked Material Discrepancy Classification at the JDAP**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JDAP refers the factual dispute to the neutral technical arbiter for an advisory finding; if the national adjudication officers still do not concur, the matter escalates to the JSC for double-key decision, with automatic site-level suspension remaining in effect if material.
Rationale: Material findings, sanctions, and suspension require double-key authorization, and no single country may unilaterally classify or dismiss a discrepancy that could trigger automatic suspension or a Stop verdict.
Negative Consequences: Unresolved discrepancy age beyond 10 business days, automatic suspension, a contested Go/Modify/Stop verdict, and a ready-made shield for a non-cooperating operator.

**Vendor Refusal Escalating to Potential Unverifiable-Equipment Classification**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB assesses the technical fallback ladder and recommends the unverifiable classification; JSC issues the final material finding and any sanction or site-suspension decision by double-key authorization.
Rationale: A dominant vendor refusal can cascade across multiple sites and convert a local equipment issue into a systemic Stop trigger, exceeding JPMO operational authority and requiring strategic materiality judgment.
Negative Consequences: Unverifiable equipment above the materiality threshold, site failure, cascading vendor non-cooperation, and a forced Stop recommendation.

**Proposed Revision of KPI or Materiality Thresholds After Challenge Validation**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB validates the proposed thresholds against blind-challenge data and recommends approval; JSC decides by double-key, ensuring both governments accept any change to the falsifiable honesty claim of Phase One.
Rationale: KPI and materiality thresholds define the Go/Modify/Stop criteria and strategic risk appetite; changing them unilaterally or after poor results could mask detection failures and undermine verdict credibility.
Negative Consequences: False Go based on relaxed thresholds, false Stop from over-calibration, loss of independent red-team credibility, and a politically contested final verdict.

**Entry-Condition Slippage Beyond the 12-Month Target**
Escalation Level: Heads of State / Party Leadership
Approval Process: JSC formally escalates the open certification conditions to the two senior authorizing principals, who issue a joint political directive to remedy the slippage or decide program continuation; the JSC retains double-key certification of any new clock start.
Rationale: Entry conditions are political acts requiring authority above the co-chairs; the 12-month target is a political commitment, and only the senior principals can resolve legislative or site-selection deadlocks.
Negative Consequences: Indefinite delay of Phase One, idle inspectorate and sunk preparation costs, loss of political momentum, and potential collapse of the USD 5 billion program.

**Information-Barrier Policy Conflict Between Verification Sensitivity and Technology Protection**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB and JSCIB provide joint technical and security assessments; JSC approves any change to filter rules, clean-room protocols, or inspection-zone boundaries by double-key.
Rationale: The balance between evidence sufficiency and protection of sovereign technology is the core strategic tension, and altering barrier policy affects national security exposure and the credibility of every verification result.
Negative Consequences: Over-filtering hides substitution evidence and causes false negatives, while under-filtering leaks sensitive technology, triggering counterintelligence failure and program termination.

**Material Fraud, Corruption, or KPI Misreporting Detected by JAECC**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JAECC issues an audit exception and recommends protective holds, sanctions, or suspension; JSC decides by double-key after receiving the independent findings and any dissenting views from national compliance officers.
Rationale: Misreporting or fraud in sovereign funds or KPI data corrupts the evidence base for the verdict and the integrity of the entire bilateral mechanism, requiring independent-audit escalation to the strategic level.
Negative Consequences: Financial loss across the USD 5 billion envelope, false Go/Modify/Stop decision, legal penalties, loss of public and sovereign trust, and exposure to whistleblower or compliance investigations.