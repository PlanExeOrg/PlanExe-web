**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit set for PMO decisions.
Negative Consequences: Potential budget overrun and project delays.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Requires strategic oversight and intervention due to potential impact on national security.
Negative Consequences: Project failure or significant delays in operational readiness.

**PMO Deadlock on Key Operational Decision**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Inability to reach consensus on critical operational matters.
Negative Consequences: Operational paralysis and delays in project execution.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant alterations to project scope require higher-level approval.
Negative Consequences: Misalignment with project goals and potential resource misallocation.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Ensures adherence to ethical standards and legal compliance.
Negative Consequences: Reputational damage and potential legal ramifications.