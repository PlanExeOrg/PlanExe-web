## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers address the program's foundational tensions: mutual distrust (double-key governance), evidence sufficiency vs speed (layered evidence), verification vs information protection (information barrier), detection latency vs silent windows, and aggregation into a defensible Go/Modify/Stop verdict. High levers cover political, fiscal, site-parity, and lifecycle enablers. No key strategic dimension appears missing; staffing and schedule versioning are correctly subordinate.

### Decision 1: Double-key deadlock and automatic suspension thresholds
**Lever ID:** `e6894c2d-dcce-4df7-b400-91e078d42320`

**The Core Decision:** Specifies how the equal co-chair structure resolves disagreement without allowing either country to overrule the other, including deadlock triggers, advisory arbitration, and narrowly scoped automatic suspension. Success metrics are bounded deadlock-resolution time and zero unilateral findings or sanctions. The lever determines whether the regime errs toward continued monitoring or protective suspension when evidence diverges.

**Why It Matters:** This lever defines how the equal co-chair structure behaves when the two governments disagree on a finding, a protocol change, or a sanction. Without a pre-agreed deadlock path, one side can exploit delay to shield an operator, but overly automatic suspension lets a single dispute halt verification everywhere. The chosen mechanism determines whether the Consortium errs toward continued monitoring or toward immediate protective suspension.

**Strategic Choices:**

1. Trigger automatic suspension only for sites with an unresolved material discrepancy, while allowing all other verification activity to continue under the existing protocol.
2. Empower joint technical teams to resolve routine discrepancies under pre-agreed evidentiary rules, reserving double-key authorization for material findings and sanctions.
3. Escalate deadlocked factual disputes to a jointly selected neutral technical arbiter with advisory findings, while keeping sanctions and suspension exclusively under double-key.

**Trade-Off / Risk:** Automatic suspension protects against unilateral shielding but creates a powerful delay tactic if one side manufactures discrepancies, so the trigger must be tightly scoped to materiality.

**Strategic Connections:**

**Synergy:** Pre-agreed deadlock and suspension mechanics give Phase One Verdict Construction and Materiality Definition reliable triggers: materiality definitions can activate suspension without unilateral overrule or procedural paralysis.

**Conflict:** Deadlock review consumes the same latency budget that Material-Event Latency Budget and Silent-Window Bounds reserve for rapid detection, so lengthy disputes can leave suspected substitutions unresolved within the agreed window.

**Justification:** *Critical*, Critical because it is the governance hub: equal co-chairs, double-key authorization, and pre-agreed suspension thresholds determine whether either side can shield an operator or paralyze verification. It controls the core no-unilateral-overrule trade-off and gives every materiality trigger an enforceable mechanism.

### Decision 2: Layered evidence weighting and operator-provided records
**Lever ID:** `f412506f-2b0d-455e-9aef-2c0d1c17e5b5`

**The Core Decision:** Establishes which evidence classes can verify equipment events, how much weight each carries, and when physical witnessing is mandatory versus when operator records may substitute under randomized sampling. Success metrics are false-negative and false-positive rates, evidence-class independence, and event confidence. The lever balances inspection speed against the expanded false-negative surface created by trusting operator-provided records.

**Why It Matters:** This lever determines how much evidentiary weight each layer receives and whether any combination can reach certainty without physical inspection. Requiring multiple independent classes for every event raises confidence but slows the process and increases operator burden, especially for routine maintenance changes. Allowing operator-provided records to substitute for witnessed observation improves speed but expands the false-negative surface.

**Strategic Choices:**

1. Mandate at least two independent evidence classes for every material event and require physical witnessing for all installations, removals, and decommissioning.
2. Predefine a hierarchy of evidence classes with explicit certainty thresholds, treating cryptographic attestation as supporting evidence that never satisfies verification alone.
3. Validate operator-provided records through random independent sampling for low-risk events while preserving full physical inspection for high-risk equipment changes.

**Trade-Off / Risk:** Random sampling cuts inspection load but can conceal a deliberately hidden substitution; the false-negative risk must be bounded by making sampled events carry automatic site-level consequences.

**Strategic Connections:**

**Synergy:** Intake Staging Jurisdiction and Pre-Installation Identity Gates supplies the first controlled identity evidence layer, and the Information Barrier Architecture for Filtered Evidence lets those layers be collected and reviewed without exposing protected data.

**Conflict:** Requiring multiple independent evidence classes and physical witnessing for every event lengthens response time, pressing against the Material-Event Latency Budget and Silent-Window Bounds established for rapid detection.

**Justification:** *Critical*, Critical because it defines the mission's evidentiary core and false-negative/false-positive risk. The balance between physical witnessing, operator records, and sampling sets inspection speed, confidence, and operator burden; every other verification control feeds or constrains this hierarchy.

### Decision 3: Information barrier architecture for filtered evidence
**Lever ID:** `d107ecf3-597a-4160-bd32-8f6dc4d2997f`

**The Core Decision:** Defines bounded inspection zones, filtered workstations, clean-room protocols, and dynamically designed evidence-collection patterns that protect workloads, model weights, and source code while preserving equipment-identity verification. Success is measured by IP and cybersecurity incident counts, challenge detection rates, and inspection sensitivity. The architecture must be validated in blind exercises because over-filtering can hide the contextual metadata needed to detect substitution.

**Why It Matters:** This lever decides how bounded inspection zones and evidence filtering protect workloads, model weights, and source code while still proving equipment identity. Tighter barriers reduce intelligence exposure but can also mask the very indicators inspectors need to detect substituted hardware. The architecture must balance inspection effectiveness against the counterintelligence requirement that neither side gains unilateral access to sensitive technology.

**Strategic Choices:**

1. Route all inspection evidence through filtered workstations that strip customer data and workload details before any inspector sees it, with cryptographic hashes preserving integrity.
2. Create clean-room examination protocols using accredited independent examiners for vendor-refusal cases, allowing physical inspection without exposing proprietary source code.
3. Design zone boundaries dynamically by event type, with pre-agreed access patterns for staging, maintenance, and exit flows that limit escort and evidence collection to the minimum necessary.

**Trade-Off / Risk:** Filtered workstations protect sensitive data but can strip the contextual metadata needed to detect substituted equipment, so barrier rules must be tested in blind challenges before deployment.

**Strategic Connections:**

**Synergy:** Clean-room examination and filtered workstations provide the accredited alternatives that Vendor Refusal Containment and Unverifiable-Equipment Contagion requires, converting refusals into reviewable evidence instead of automatic unverifiable outcomes.

**Conflict:** Tighter information barriers can strip the contextual metadata that Layered Evidence Weighting and Operator-Provided Records needs for confident attribution, so barrier strength must be traded off against evidence sufficiency for each event class.

**Justification:** *Critical*, Critical because it controls the defining tension between verification effectiveness and protection of workloads, model weights, and source code. Barrier strength determines whether the two governments will accept inspection and whether inspectors can detect substitution; it also enables vendor-refusal clean-room alternatives.

### Decision 4: Phase One verdict construction and materiality definition
**Lever ID:** `5ddeb99e-2c90-41d0-99aa-6cf2aaa65ced`

**The Core Decision:** This lever defines how hundreds of discrete findings aggregate into a single Go/Modify/Stop decision, fixing materiality as risk appetite: whether one unverifiable rack sinks the regime or is absorbed as residual risk. Its scope covers bright-line triggers, joint findings narratives, and a staged process that separates inspector-reported operational results from co-chair political determination. Success is an accepted verdict that withstands scrutiny over false negatives, discrepancy age, and unverifiable-equipment counts.

**Why It Matters:** The Go/Modify/Stop verdict must aggregate exercise results, access findings, and unresolved discrepancies into one decision, so the aggregation rule determines whether a single material failure blocks Go or whether strengths offset weaknesses. Bright-line triggers with a materiality corridor are predictable but brittle; holistic judgment preserves nuance but invites each government to read the same record differently. The plan names materiality as a Stop trigger without defining it, so the verdict construction process must fix its meaning before findings arrive.

**Strategic Choices:**

1. Pre-specify bright-line Stop triggers with a materiality corridor, so a single unverifiable unit below the corridor is logged but does not block Go while any unit above it forces Stop.
2. Require joint verdict construction where co-chairs must draft a shared findings narrative, letting disagreement surface in the narrative itself rather than in separate unilateral assessments.
3. Run a staged decision process that separates operational findings from political determination, with inspectors publishing technical results first and the co-chairs issuing the verdict only after a fixed deliberation window.

**Trade-Off / Risk:** The verdict aggregates hundreds of discrete findings, so the definition of materiality determines whether one unverifiable rack sinks the entire regime or is absorbed as a tolerable residual risk.

**Strategic Connections:**

**Synergy:** Amplifies Double-key deadlock and automatic suspension thresholds, because concrete materiality triggers give suspension rules objective referents; and enables Matched-site parity calibration and reciprocal access benchmarking, whose access findings supply the verdict with its core evidence.

**Conflict:** Conflicts with Authentic-text hierarchy and interpretive dispute pre-registration, since freezing materiality in the glossary forecloses corridor adjustments; and with Appropriations cadence and contribution-release governance, because milestone-linked tranches make the verdict an object of funding negotiation.

**Justification:** *Critical*, Critical because it fixes how hundreds of findings aggregate into the Go/Modify/Stop decision and defines materiality as risk appetite. Without pre-agreed aggregation and materiality, one unverifiable rack can either sink the regime or be hidden, making the verdict politically contestable.

### Decision 5: Material-event latency budget and silent-window bounds
**Lever ID:** `d71194d7-3f2a-4fd3-aa45-12d23d8a98c1`

**The Core Decision:** This lever fixes the maximum time a physical material change may go unrecorded, defining the silent window that red teams are paid to exploit and that exercises must beat. It allocates the budget across operator reporting, physical confirmation, and ledger recording, weighing near-real-time telemetry against production disruption. Success metrics are event-recording and synchronization latency, blind-challenge detection rates, and measured silent window; the chosen bounds are the regime's falsifiable honesty claim.

**Why It Matters:** Credible detection is ultimately a latency claim: how much time may pass between a physical material change and its appearance in the ledger. Requiring near-real-time visibility forces continuous telemetry or permanent inspection presence, which raises production disruption and cost, while tolerating long silent windows hands red teams a guaranteed concealment corridor. The chosen latency budget defines what the blind-challenge exercises must beat and therefore what Phase One can honestly certify.

**Strategic Choices:**

1. Adopt a layered latency budget where operators report material events within a fixed hours window, physical inspection confirms within a second window, and ledger recording completes within an agreed minutes threshold.
2. Require continuous automated attestation and tamper-evident telemetry at the equipment level so the ledger records changes in near real time without waiting for human reporting.
3. Accept discrete silent windows and compensate with randomized unannounced sweeps and probabilistic inspection, bounding the expected cumulative undetected exposure rather than eliminating it.

**Trade-Off / Risk:** A layered latency budget sounds credible, but red teams will design unreported-arrival challenges to exploit the gap between operator reporting and physical confirmation, so the real test is whether the interior windows are independently verifiable.

**Strategic Connections:**

**Synergy:** Operationalizes Bounded ledger synchronization and divergence-resolution latency, which must fit inside the budget's interior windows; and supplies Phase One verdict construction and materiality definition with the blind-challenge detection evidence that justifies a Go call.

**Conflict:** Conflicts with Vendor refusal containment and unverifiable-equipment contagion, because the forced-evidence ladder consumes the latency budget; and with Information barrier architecture for filtered evidence, since rigorous filtering and clean-room steps add delay to every recorded event.

**Justification:** *Critical*, Critical because credible detection is fundamentally a latency claim: the silent window defines what red teams exploit and what exercises must beat. It allocates time across reporting, physical confirmation, and ledger recording, and supplies the blind-challenge evidence needed for a defensible Go decision.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Entry-condition sequencing and the Phase One clock
**Lever ID:** `862ff239-f50e-49c6-b6b0-7db39fea4cbb`

**The Core Decision:** Defines the joint certification gates that must close before the 90-day Phase One clock starts, including appropriations, domestic authority, site selection, inspector approval, and vendor participation. Success is measured by reciprocal readiness parity and zero uncertified entry conditions at launch. The lever calibrates how much parallel preparation is safe without creating de facto obligations before legal authority exists.

**Why It Matters:** Pulling this lever fixes which mandatory conditions gate the 90-day test and determines whether pre-signature preparation counts toward readiness. Because appropriations, domestic access authority, and site selection are political acts, the critical path is reciprocity-sensitive, and one side’s delay can stall the entire mechanism. Compressing preparation risks starting the clock with unvalidated site choices, while stretching it burns political capital before any operational evidence exists.

**Strategic Choices:**

1. Run all preparation workstreams in parallel under an integrated readiness tracker, but withhold the formal Phase One clock until every entry condition is jointly certified by the co-chairs.
2. Sequence entry conditions so domestic access authority is the final gate, using provisional site selection and inspector training to compress the post-signature timeline.
3. Conduct a provisional shadow exercise after site selection but before formal entry conditions complete, labeling all findings non-binding and excluding them from the final decision.

**Trade-Off / Risk:** Parallel preparation compresses the timeline but risks treating provisional site selection as a sunk commitment, and a shadow exercise can create de facto obligations before legal authority exists.

**Strategic Connections:**

**Synergy:** This lever aligns the Phase One clock with Matched-Site Parity Calibration and Reciprocal Access Benchmarking and with Appropriations Cadence and Contribution-Release Governance, so both governments begin with equal readiness and committed funds.

**Conflict:** Entry-condition certification depends on double-key approval, so deadlock over any precondition stalls the Phase One clock; stretching preparation also starves the Material-Event Latency Budget and Silent-Window Bounds of operational data.

**Justification:** *High*, High because it gates the entire 90-day test and couples readiness with appropriations, site selection, and reciprocity, so one side's delay can stall the mechanism. However, once certified, its influence is absorbed by operational levers, making it less central than evidence/latency decisions.

### Decision 7: Mirrored staffing depth and surge capacity
**Lever ID:** `25e3fe73-a984-48b3-82da-4e0610d794cc`

**The Core Decision:** Sets the size and composition of the mirrored inspectorate from site count, shift coverage, leave backup, and exercise surge, with full-time employment and separation of duties. Success is measured by no single-person critical functions, coverage ratios, and surge deployment time within the fixed inspection envelope. Staffing depth doubles as a reciprocity signal, since asymmetrical capacity would undermine bilateral confidence.

**Why It Matters:** This lever sets the size and composition of the inspectorate, including how many full-time mirrored teams are stationed versus held in reserve. Because every critical function requires separation of duties and leave coverage, the staffing model drives both the labor budget and the speed of event response. Over-staffing consumes the fixed 750 million inspection envelope, while under-staffing creates single points of failure that can invalidate an entire verification event.

**Strategic Choices:**

1. Derive headcount from a workload formula covering site count, shift coverage, leave backup, and exercise surge, then allocate at least two full-time mirrored national inspectors to every material event.
2. Cross-train technical specialists across multiple sites to reduce total positions while preserving dual-national observation and fully separated duties for each function.
3. Maintain a permanently employed surge cadre of credentialed inspectors assigned to the Consortium, held in reserve and deployed from the contingency envelope for challenges and unexpected events.

**Trade-Off / Risk:** A surge pool keeps fixed costs low but reintroduces the part-time inspector risk the plan explicitly bans, so surge personnel must be full-time employees with identical training and clearance.

**Strategic Connections:**

**Synergy:** Deeper mirrored staffing enables the physical witnessing that Layered Evidence Weighting and Operator-Provided Records demands, while reserve surge capacity compresses response time within the Material-Event Latency Budget and Silent-Window Bounds.

**Conflict:** The staffing model front-loads salary obligations against a fixed inspection envelope, while Appropriations Cadence and Contribution-Release Governance controls when funds arrive; delayed release strands trained inspectors before any verification event occurs.

**Justification:** *Medium*, Medium because it is a derived resourcing model, not a strategic choice: headcount follows site count, shift coverage, and separation-of-duties rules. It enables evidence collection and latency performance, but its strategic reciprocity aspect is already governed by parity calibration and budget envelopes.

### Decision 8: Exit disposition binding and unresolved equipment handling
**Lever ID:** `f250670d-c4a1-4c94-9940-afd12364143b`

**The Core Decision:** This lever defines the only acceptable ways covered equipment may leave a declared site and mandates a ledger disposition for each departure. Its success metric is that no unresolved or ambiguous exit remains open, because weak exit rules would hollow out the entire verification boundary. It also sets the materiality threshold for suspension when a departure cannot be verified.

**Why It Matters:** This lever fixes what counts as a compliant departure and what happens when an exit cannot be verified. Strong disposition requirements, such as mandatory witnessed destruction, reduce the risk of re-entering equipment outside the monitored system but impose logistical and cost burdens on operators. Weak dispositions create an accountability gap that undermines the entire verification boundary.

**Strategic Choices:**

1. Require witnessed destruction or verified permanent disablement for all decommissioned frontier-relevant equipment, with both national teams observing and countersigning the ledger entry.
2. Permit documented release beyond the monitored system only after independent verification that the equipment has been irreversibly modified to non-frontier capability.
3. Treat any departure without an assigned disposition as a material discrepancy that immediately suspends the site, and require joint reauthorization before any further equipment movement.

**Trade-Off / Risk:** Mandatory witnessed destruction is the strongest control but may be operationally impossible for large installations, so the disposition rules must include a verified disablement pathway that is genuinely irreversible.

**Strategic Connections:**

**Synergy:** Exit disposition binding and unresolved equipment handling works with Intake staging jurisdiction and pre-installation identity gates to close the lifecycle loop, leaving no unaccounted corridor and feeding Phase One verdict construction with concrete unresolved counts.

**Conflict:** Strict exit dispositions can conflict with Matched-site parity calibration, because sites with bulky or hard-to-disable equipment cannot meet identical destruction requirements, making reciprocal obligations unequal. They also amplify Vendor refusal containment and unverifiable-equipment contagion when vendors resist destructive procedures.

**Justification:** *High*, High because it closes the equipment lifecycle and prevents unverified departures from hollowing out the verification boundary; unresolved exits feed materiality and the final verdict. It is important but more circumscribed than the evidence, latency, and governance levers, and depends on intake and barrier controls upstream.

### Decision 9: Technical schedule versioning against generational drift
**Lever ID:** `ea3d7637-2fb5-4dbf-9938-1f13ec03247f`

**The Core Decision:** This lever governs how the confidential covered-equipment schedule evolves as new frontier-relevant generations appear, using double-key specialist approval, attribute-based coverage, and pre-negotiated sunset reviews. Success is measured by minimal coverage gaps at each product transition and by disputes remaining resolvable through pre-registered criteria. The versioning process itself, not any single listing, is the durable safeguard against obsolescence.

**Why It Matters:** The covered-equipment schedule fixes what the regime is actually verifying, so every revision reopens the bilateral definitional bargain and every product generation tests whether the list has drifted out of relevance. A strictly versioned confidential schedule maintained by accountable specialists gives both sides a stable reference point, but it cannot anticipate the next architecture shift unless the versioning process is itself pre-negotiated. Sunset reviews and fast-track provisional listings keep the schedule current while making each update a potential flashpoint between the two governments.

**Strategic Choices:**

1. Maintain a confidential schedule updated only through double-key specialist approval, with automatic sunset review each time either side fields a new generation of frontier-relevant equipment.
2. Specify coverage through a framework of measurable attributes maintained confidentially by the accountable specialists, decoupling the schedule from named products so disputes center on technical criteria rather than commercial labels.
3. Re-baseline the schedule at fixed six-month intervals with a fast-track provisional listing that adds equipment immediately and lets challenges resolve afterward before the listing becomes permanent.

**Trade-Off / Risk:** A schedule that never changes becomes obsolete, but every revision reopens the bilateral definitional bargain, so the versioning process must be pre-negotiated before the first equipment change is ever verified.

**Strategic Connections:**

**Synergy:** Technical schedule versioning against generational drift amplifies Authentic-text hierarchy and interpretive dispute pre-registration, because pre-agreed definitional rules make each schedule revision resolvable without reopening the bilateral bargain. It enables Phase One verdict construction by keeping the tested equipment set current.

**Conflict:** Frequent schedule revisions conflict with Entry-condition sequencing and the Phase One clock, because each new listing can trigger renegotiation and delay the 90-day test. They also trade against Matched-site parity calibration by reshaping which sites appear comparable.

**Justification:** *Medium*, Medium because it keeps the covered-equipment schedule from drifting obsolete, but it is a future-proofing mechanism with limited impact inside the 90-day Phase One. Its definitional role overlaps with pre-registered interpretive rules, and revisions can reopen the bilateral bargain.

### Decision 10: Intake staging jurisdiction and pre-installation identity gates
**Lever ID:** `297d6a32-1f71-439a-9409-c5b4bdd2948c`

**The Core Decision:** This lever fixes where and under whose control equipment identity is established before installation, with options from jointly controlled in-site staging to operator-run attestation and off-site neutral warehouses. Its success metric is the fraction of covered arrivals entering through verified staging with zero bypass events. Because staging is the single physical chokepoint, its jurisdiction determines whether downstream evidence is corroboration or merely retrospective detection.

**Why It Matters:** Staging areas are the single physical point where equipment identity is verified before installation, so whoever controls them controls the credibility of the entire intake layer. Jointly controlled zones with mirrored inspectors raise integrity but disrupt commercial operations, while operator-run staging preserves operational flow and pushes the evidentiary burden onto downstream layers. A bypass — equipment moved directly onto the production floor — forces the regime to choose between halting operations and accepting an unverified installation.

**Strategic Choices:**

1. Designate jointly controlled staging zones inside every participating site with mirrored national inspectors co-witnessing identity checks, accepting higher operational friction in exchange for verifiable intake.
2. Accept operator-run staging with cryptographic attestation and recorded serialization, then depend on downstream layered evidence to catch whatever the staging layer misses.
3. Require all covered equipment to enter through off-site neutral staging warehouses shared across multiple sites, trading logistics cost for independence from individual operator control.

**Trade-Off / Risk:** Staging control concentrates the entire verification burden at one physical point, so any operator or vendor able to route equipment around staging can hollow out the protocol without ever triggering a visible violation.

**Strategic Connections:**

**Synergy:** Intake staging jurisdiction and pre-installation identity gates strengthens Layered evidence weighting and operator-provided records by producing the primary identity anchor that customs, serialization, and maintenance records corroborate. It also enables Bounded ledger synchronization with timestamped local entry events.

**Conflict:** Jointly controlled staging imposes queue delays and access restrictions that trade against Material-event latency budget and silent-window bounds, stretching the interval between physical arrival and verified recording. It also consumes scarce Mirrored staffing depth and surge capacity.

**Justification:** *High*, High because staging is the physical chokepoint where equipment identity is first established, and bypasses can hollow out downstream evidence. It strongly interacts with layered evidence, ledger recording, latency, and staffing; however, the plan's 'no single source decisive' principle keeps it one layer in a multi-evidence system.

### Decision 11: Bounded ledger synchronization and divergence-resolution latency
**Lever ID:** `3a203a96-ae4f-455a-af2f-3afe46dea9df`

**The Core Decision:** This lever sets the maximum acceptable delay between a local ledger event and cross-national synchronization, defines divergence alerts, and prescribes reconciliation drilling when copies disagree. Key success metrics are synchronization latency, ledger divergence duration, and reconciliation time. The chosen threshold is a direct policy trade-off: tighter bounds expose more sensitive local operations, while looser bounds risk silent divergence that can precipitate the Stop condition.

**Why It Matters:** Synchronization cadence directly trades the freshness of cross-national visibility against the volume of sensitive operational detail each side must expose. Tight bounds give both governments near-real-time confidence but force continuous disclosure of local events; loose bounds protect operational privacy while widening the window in which the two national ledger copies can silently diverge. Because unresolved divergence is already a designated Stop condition, the chosen latency threshold shapes whether reconciliation failures surface early or fester until the Phase One verdict.

**Strategic Choices:**

1. Set a bounded synchronization window with automatic divergence alerts when local records exceed the bound, and require immediate reconciliation drilling whenever alerts fire.
2. Configure each national copy to record events locally and synchronize in batched, scheduled intervals, accepting a longer reconciliation delay in exchange for limited cross-border operational visibility.
3. Add a neutral third-party record-keeping body that receives hash commitments from both sides continuously while withholding content, creating tamper-evident ordering without exposing sensitive transaction details.

**Trade-Off / Risk:** Divergence detection is only as meaningful as the synchronization window that bounds it, so setting latency thresholds low forces near-real-time disclosure of sensitive operations while high thresholds let silent divergence become entrenched before reconciliation.

**Strategic Connections:**

**Synergy:** Bounded ledger synchronization and divergence-resolution latency amplifies Material-event latency budget and silent-window bounds by giving the latency budget a concrete accounting mechanism for proving events were recorded within the window. It also supports Phase One verdict construction with divergence metrics.

**Conflict:** Tight synchronization bounds conflict with Information barrier architecture for filtered evidence, because continuous cross-border syncing forces disclosure of sensitive operational details the barrier is designed to withhold. Looser bounds ease that tension but widen silent-divergence risk.

**Justification:** *High*, High because ledger divergence is a designated Stop condition and synchronization bounds directly trade cross-border visibility against silent divergence. It operationalizes the latency budget and supplies reconciliation evidence for the verdict, but it is subordinate to the evidence and barrier architectures.

### Decision 12: Matched-site parity calibration and reciprocal access benchmarking
**Lever ID:** `09cc9aba-35af-4f6a-a37a-dfc60f533949`

**The Core Decision:** This lever defines how sites are paired and how reciprocal access is measured, using declared equipment value, operational role, total capacity, or deliberately dissimilar stress sites. Its success metric is demonstrated reciprocity in access hours and verification outcomes across matched pairs. Parity calibration determines whether the regime's Go/Stop criterion on asymmetric access is meaningful or a diplomatic artifact before exercises begin.

**Why It Matters:** The matched set of declared datacenters determines whether reciprocal access parity is a meaningful metric or a diplomatic fiction. Matching on equipment value and operational role makes inspection burdens comparable but may force a country to declare facilities it would rather keep out of scope, while matching on total processing capacity accepts asymmetry in site count for symmetry in what is monitored. An imbalanced match can trip the designated asymmetric-access Stop condition before live exercises even begin.

**Strategic Choices:**

1. Select matched site pairs by declared equipment value and operational role, then benchmark reciprocal access hours against those characteristics to make parity comparison concrete.
2. Allow each country to nominate its own most sensitive facilities, then negotiate the matched set to equal total processing capacity rather than equal site count, accepting asymmetry in numbers.
3. Include deliberately dissimilar and harder-to-inspect sites in the match to stress the regime early, forcing both sides to demonstrate they can verify under genuinely unequal conditions.

**Trade-Off / Risk:** Matching sites on paper cannot make their inspection difficulty equal, because facility size, layout, and vendor ecology differ, so parity metrics measure effort rather than true verification equivalence.

**Strategic Connections:**

**Synergy:** Matched-site parity calibration and reciprocal access benchmarking underpins Phase One verdict construction and materiality definition, because asymmetric access evidence is an explicit Stop trigger. It also gives Double-key deadlock and automatic suspension thresholds concrete parity metrics to evaluate.

**Conflict:** Negotiating matched pairs under strict parity can stall site selection, conflicting with Entry-condition sequencing and the Phase One clock, which cannot start until both countries approve participating sites. It also raises information-exposure risk, straining Information barrier architecture for filtered evidence.

**Justification:** *High*, High because it defines reciprocal access and the explicit asymmetric-access Stop trigger, so site pairing determines whether the Go/Modify/Stop criterion is meaningful. It is central to bilateral fairness and entry-condition approval, though its power depends on operational verification levers.

### Decision 13: Vendor refusal containment and unverifiable-equipment contagion
**Lever ID:** `e3541754-b092-4e67-bd56-c08a9eb26221`

**The Core Decision:** This lever decouples verification from vendor goodwill through a forced-evidence ladder running from vendor-supervised testing to clean-room examination to accredited independent examiners, backed by cross-trained inspectors and spare hardware. Scope covers pre-negotiated vendor-access agreements, operator obligations, and rules for classifying equipment unverifiable without letting one refusal cascade across sites. Success metrics: vendor-refusal outcomes, unverifiable-equipment counts, and time from refusal to resolved disposition.

**Why It Matters:** Binding manufacturers, maintenance providers, and logistics companies transfers part of the verification burden to third parties, but a single dominant vendor refusing cooperation can cascade across every site it serves. The escalation ladder from vendor-supervised testing to clean-room procedures gives inspectors alternatives, yet each rung weakens evidentiary independence and consumes the 90-day clock. When refusals span multiple sites, a local equipment finding becomes a systemic regime failure that the materiality rules may have to treat as Stop.

**Strategic Choices:**

1. Negotiate model vendor-access agreements before Phase One begins, with operators contractually required to provide escorts, evidence, and clean-room access as a condition of site eligibility.
2. Build a forced-evidence ladder that shifts from vendor cooperation to independent examination, and classify equipment as unverifiable only after the full ladder fails at a given site.
3. Cross-train inspectors to perform vendor-supervised diagnostics themselves and stock spare replacement hardware, reducing dependence on any single vendor's technicians and making refusal less consequential.

**Trade-Off / Risk:** A single dominant vendor refusing cooperation at multiple sites converts an equipment-level finding into a systemic failure, so the regime needs a pre-negotiated remedy that does not depend on that vendor's goodwill.

**Strategic Connections:**

**Synergy:** Amplifies Layered evidence weighting and operator-provided records, since the fallback ladder depends on non-vendor evidence layers; and feeds Phase One verdict construction and materiality definition by bounding the unverifiable-equipment count that materiality rules must absorb.

**Conflict:** Trades off against Material-event latency budget and silent-window bounds, because climbing the evidence ladder consumes precious verification windows; and competes with Mirrored staffing depth and surge capacity, since cross-trained inspector teams are drawn from limited surge resources.

**Justification:** *High*, High because a dominant vendor's refusal can cascade into systemic unverifiability and Stop. The forced-evidence ladder, pre-negotiated access agreements, and cross-trained inspectors provide essential fallbacks, but they operate within the latency budget and evidence hierarchy rather than defining them.

### Decision 14: Authentic-text hierarchy and interpretive dispute pre-registration
**Lever ID:** `b255f6e8-e99b-41b5-af82-27b542e6433f`

**The Core Decision:** This lever pre-commits both governments to a binding bilingual glossary and pre-registered interpretive readings so Phase One disputes resolve by reference to fixed texts rather than negotiation. Forcing the contested terms — material, removal, frontier-relevant — to be defined before the clock starts converts future adjudication into a lookup operation. Success metrics are interpretive disputes resolved without access denial and absence of deferred deadlocks; cost is front-loading linguistic bargaining into entry conditions.

**Why It Matters:** A bilingual instrument with two equally authentic texts invites each side to read borderline provisions in its own favor, and an unresolved interpretive dispute becomes a ready-made access-denial tool for operators and vendors. Binding the glossary before the clock starts freezes the meaning of terms like material, removal, and frontier-relevant for Phase One, so later disagreements parse facts rather than words. The trade-off is that negotiating the glossary consumes political capital before the 90-day clock begins, and any term left unresolved becomes a deferred deadlock.

**Strategic Choices:**

1. Establish a joint terminology commission of mirrored technical linguists and engineers to publish a binding bilingual glossary before the clock starts, with worked examples of covered and uncovered events.
2. Designate the English text as the authoritative reference for Phase One but require certified technical translations of every evidence package, accepting a predictable single reference in exchange for acknowledged linguistic asymmetry.
3. Pre-register interpretive positions in a double-keyed annex where each government files its reading of every contested term at signing, so later disagreements resolve by reference to the annex instead of by negotiation.

**Trade-Off / Risk:** A binding glossary reduces interpretive drift, but the two governments wrote the instrument in both languages precisely to avoid conceding authenticity, so the pre-clock negotiation of every contested term may deadlock before operations begin.

**Strategic Connections:**

**Synergy:** Enables Entry-condition sequencing and the Phase One clock, because a settled glossary removes deferred deadlocks that could stall the clock; and sharpens Double-key deadlock and automatic suspension thresholds by making trigger terms unambiguous.

**Conflict:** Constrains Technical schedule versioning against generational drift, since frozen definitions may not map to next-generation equipment; and pressures Phase One verdict construction and materiality definition, because pre-registered readings lock the materiality corridor before operational experience exists.

**Justification:** *High*, High because unresolved bilingual interpretations can become ready-made access-denial tools and deferred deadlocks. Pre-registering terms converts future disputes into lookup operations and supports entry-condition certification and double-key triggers; however, it is a one-time legal precommitment rather than a daily operational control.

### Decision 15: Appropriations cadence and contribution-release governance
**Lever ID:** `16810033-6cab-49b4-bd6e-a773729bb0a4`

**The Core Decision:** This lever governs when each government's 2.5-billion-dollar contribution enters the Consortium and how funds release against envelopes, so a delayed disbursement cannot act as a quiet veto that never triggers the withholding stop condition. Scope covers escrow pre-funding, milestone-linked tranches, standby bridges, and quarterly reconciliation. Success metrics are funding timeliness, reciprocal release parity, and zero fiscal suspensions; the key choice is whether treasuries or the KPI dashboard hold fiscal leverage.

**Why It Matters:** Because each government administers its own operator and vendor compensation, the Consortium's operational tempo is directly coupled to the other side's appropriations cycle, and a delayed disbursement acts as a quiet veto that never formally triggers the withholding stop condition. Fully pre-funding the escrow removes that pressure point but demands that both legislatures appropriate billions before seeing any exercise results. Milestone-linked tranches preserve fiscal leverage but make the KPI dashboard itself the object of negotiation.

**Strategic Choices:**

1. Require both governments to deposit their full 2.5-billion-dollar contributions into a jointly signatory escrow before the clock starts, with quarterly reconciliation and release against envelope-approved expenditures.
2. Tie drawdown tranches to verified operational milestones, releasing each successive tranche only after the KPI dashboard shows the preceding stage met the agreed thresholds.
3. Establish a mutual standby commitment in the bilateral instrument authorizing either government to bridge a payment delinquency for a bounded period, with the delinquency itself recorded as a suspension trigger.

**Trade-Off / Risk:** Milestone-linked tranches keep either side from paying for a failing program, but defining milestones before the clock starts invites gaming of the KPI definitions, and a standby bridge creates a lending relationship neither treasury will accept.

**Strategic Connections:**

**Synergy:** Enables Mirrored staffing depth and surge capacity, because contingency and surge envelopes become usable only when funds release reliably; and underpins Matched-site parity calibration and reciprocal access benchmarking, since asymmetric funding collapses reciprocal deployment.

**Conflict:** Trades off against Phase One verdict construction and materiality definition, because milestone-linked tranches turn the KPI dashboard into a funding-negotiation object; and risks Double-key deadlock and automatic suspension thresholds, since fiscal withholding can trigger suspension machinery meant for verification failures.

**Justification:** *High*, High because delayed contribution release can act as a quiet veto and a funding-based suspension trigger, directly coupling fiscal cadence to operational tempo and reciprocal deployment. It underpins staffing and site access, but its effects are channeled through governance and verification levers.
