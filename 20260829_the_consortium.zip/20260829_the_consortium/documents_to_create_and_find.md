# Documents to Create

## Create Document 1: Project Charter – US-China Consortium Phase One Verification Program

**ID**: 101d1641-3591-42b6-ac51-6e9160b9512e

**Description**: Foundational project management charter establishing the joint 90-day Phase One operational test mission, scope boundaries (declared-equipment change verification only), SMART success criteria, high-level budget and envelope structure, governance roles, and approval path. Intended for joint co-chairs and heads of state to authorize planning. Type: Project Charter.

**Responsible Role Type**: Joint Secretariat / Program Integration Lead

**Primary Template**: PMI Project Charter Template

**Secondary Template**: UK Government Project Initiation Document (PID) Template

**Steps to Create**:

- Draft charter from goal statement and strategic decisions, incorporating SMART criteria and mandatory entry conditions.
- Conduct joint working session with co-chairs and legal counsel to confirm scope and non-goals.
- Circulate for comment to mirrored national units and stakeholders.
- Obtain double-key approval from equal co-chairs.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for final authorization

**Essential Information**:

- Define the mission statement exactly as the joint 90-day Phase One operational test verifying material changes to covered frontier-relevant computing equipment at six matched declared datacenters (three per country), concluding with a defensible Go/Modify/Stop decision.
- Explicitly state scope boundaries and non-goals: verification of declared-equipment changes only; exclude workload verification, model-weight inspection, capacity estimation, hidden-facility discovery, and comprehensive AI governance.
- Incorporate the SMART success criteria from the project plan: false-negative rate ≤5% in blind challenges at 95% confidence; event-recording latency <5 minutes locally; cross-national synchronization ≤1 hour; divergence reconciliation ≤24 hours; unresolved material discrepancy age ≤10 business days; unverifiable equipment ≤2 units/site or 1% of covered changes; zero unresolved ledger divergence; demonstrated reciprocal access parity; and a joint written verdict.
- List the mandatory entry conditions that must be certified before the 90-day clock starts: bilateral instrument signed, domestic access authority enacted, full escrow pre-funding or milestone-tranche fallback in place, six matched sites jointly declared, mirrored inspectorate approved, vendor-access agreements secured, covered-equipment schedule adopted, baseline inventory completed, inspector visa/customs annex concluded, and systems validated through independent testing.
- Detail the seven budget envelopes and total $5B funding: $1.25B ledger/attestation/evidence/communications; $1B site preparation/operator compensation; $750M inspectorate; $750M secure facilities/cyber/counterintelligence; $500M independent testing/red teams; $250M legal/audit; $500M contingency/surge.
- Specify governance and approval structure: equal national co-chairs, double-key authorization, no casting vote, no majority overrule, joint technical teams for routine discrepancies, advisory arbiter for deadlocked facts, 10-business-day escalation to leadership, and automatic suspension limited to unresolved material discrepancies at specific sites.
- Identify responsible role and creation process: Joint Secretariat / Program Integration Lead to draft from the goal statement and strategic decisions, hold a joint working session with co-chairs and legal counsel, circulate to mirrored national units, and obtain double-key approval from co-chairs with heads of state/party leadership for final authorization.
- State the intended use and audience: authoritative charter for joint co-chairs and heads of state to authorize planning, align expectations, and establish the basis for downstream plans, budgets, and entry-condition tracking.

**Risks of Poor Quality**:

- An ambiguous or overly broad scope definition invites mission creep beyond declared-equipment verification, drawing the program into workload, model-weight, or capacity assessment that it was never designed to deliver.
- Missing or vague SMART criteria make the Go/Modify/Stop verdict contestable, because there will be no agreed quantitative thresholds for detection, latency, divergence, or materiality against which Phase One outcomes can be judged.
- Failure to enumerate mandatory entry conditions as gates allows the 90-day clock to start without joint certification, producing an invalid test and wasting the $750M inspectorate and $500M testing envelopes.
- Unclear budget/envelope structure creates fiscal ambiguity, enabling unauthorized drawdowns, asymmetric contributions, or cost overruns that consume the contingency reserve before independent testing is complete.
- Insufficient governance detail on double-key authority, deadlock resolution, and suspension thresholds leaves one co-chair able to block material findings or reinterpret contested terms, stalling the verdict.
- Omission of explicit non-goals and scope boundaries can create false expectations among stakeholders, legislatures, and the public that the program provides broader AI governance guarantees than it actually does.
- Lack of a defined approval path or responsible role leads to unauthorized decisions, delayed sign-off, and inconsistent versions of the charter circulating across mirrored national units.

**Worst Case Scenario**: The charter is approved with vague scope, missing entry conditions, and undefined success thresholds, leading co-chairs and heads of state to authorize a 90-day test that starts before key prerequisites are certified; one side exploits deadlock and ambiguous materiality to shield an operator, the baseline inventory is disputed, cross-border visa delays break the 24-hour confirmation window, and the final verdict is either a false Go based on scripted exercises or a politically contested Stop—consuming the full $5B investment, triggering automatic suspension, and collapsing bilateral confidence in the mechanism.

**Best Case Scenario**: The charter provides an unambiguous, jointly authorized foundation that locks the mission scope, SMART success criteria, mandatory entry gates, budget envelopes, and double-key governance before any operational work begins; it aligns co-chairs and heads of state, allows all preparation workstreams to proceed in parallel without de facto obligations, and enables a defensible, evidence-based Go/Modify/Stop decision that both governments accept as credible and binding.

**Fallback Alternative Approaches**:

- If a full co-authored charter cannot be agreed quickly, use the PMI Project Charter Template as a minimal skeleton and fill only the mandatory sections: mission, scope/non-goals, SMART success criteria, entry conditions, budget envelopes, governance, and approval authority.
- Schedule a focused joint working session or workshop with co-chairs, legal counsel, and program leads to collaboratively define scope, non-goals, and entry conditions, capturing decisions directly into a draft charter rather than iterating through written comments.
- Develop a 'minimum viable charter' limited to one page covering only the vital elements—mission, scope boundary, SMART thresholds, entry-condition gates, $5B envelope summary, and double-key approval path—then expand it into the full charter after initial authorization is secured.
- Engage an external program-management or treaty-verification subject-matter expert to draft the charter using the UK Government PID Template as an alternative structure, reducing internal drafting burden and providing an independent quality check.
- If political-level approval is delayed, have the Joint Secretariat issue an internal 'planning authorization memo' under co-chair authority to begin non-binding preparation workstreams, with the formal charter approved later.

## Create Document 2: Bilateral Governance and Decision-Rights Framework

**ID**: 0cbb596b-25ab-404f-8a6f-1fdcc99543ef

**Description**: High-level framework defining equal co-chair double-key authorization, no-casting-vote deadlock machinery, joint technical teams, advisory arbitration, objective automatic-suspension thresholds, and three-tier separation of inspectorate facts, verification conclusions, and political decisions. Type: Governance Framework.

**Responsible Role Type**: Bilateral Governance and Legal Implementation Lead

**Primary Template**: Model Treaty/Executive Agreement Governance Chapter Template

**Secondary Template**: IAEA Safeguards Legal Framework Template

**Steps to Create**:

- Review expert critique of double-key site findings and deadlock default rules.
- Draft decision-rights tiers for technical facts, materiality conclusions, and political sanctions.
- Pre-register objective automatic suspension triggers and a fixed deadlock clock.
- Convene governance war-games with both national legal teams.
- Submit to co-chairs for double-key approval.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for escalation provisions

**Essential Information**:

- Define the three-tier separation of authority: inspectorate-reported technical facts (unilateral operational results), joint technical team verification conclusions, and co-chair political determinations (Go/Modify/Stop, sanctions, suspension), with explicit rules preventing political considerations from altering technical findings.
- Specify the equal co-chair double-key authorization model: all material findings, sanctions, and suspensions require both co-chairs; no casting vote; no majority overrule; no unilateral findings or sanctions.
- Pre-register the deadlock-resolution machinery: joint technical teams resolve routine discrepancies under pre-agreed evidentiary rules; factual disputes deadlocked by the co-chairs escalate to a jointly selected advisory arbiter with non-binding findings; deadlocks persisting beyond 10 business days automatically escalate to heads of state/party leadership and appear on the KPI dashboard.
- Define objective, pre-agreed automatic-suspension triggers that are tightly scoped to unresolved material discrepancies at specific sites, explicitly excluding routine discrepancies or non-material findings from triggering regime-wide suspension.
- Incorporate concrete deadlock and suspension thresholds from the assumptions: 10-business-day deadlock escalation, automatic suspension only for sites with unresolved material discrepancies, and zero tolerance for unilateral findings or sanctions.
- Cross-reference and bind the definitions of 'material', 'unresolved', and 'material discrepancy' to the binding bilingual glossary and interpretive annex required by Decision 14, so suspension triggers are applied by lookup rather than negotiation.
- Include the escalation path and approval authority: equal national co-chairs for double-key decisions, with heads of state/party leadership reserved for escalation provisions and any extension of the deadlock clock.
- Document the governance war-game results and expert-critique dispositions as annexes, showing that the framework has been stress-tested against the double-key deadlock risk described in assumptions and strategic decisions.
- State explicit success metrics for the framework: bounded deadlock-resolution time (target under 10 business days), zero unilateral findings/sanctions, and interpretive disputes resolved without access denial.
- Specify how the framework interacts with the material-event latency budget and silent-window bounds, ensuring deadlock review cannot extend unresolved discrepancy age beyond the 10-business-day threshold or delay physical confirmation beyond 24 hours.

**Risks of Poor Quality**:

- Without objective, pre-registered deadlock and suspension triggers, one co-chair can exploit delay to shield an operator or block a sanction indefinitely, causing the Phase One verdict to be delayed or never produced.
- Ambiguous definitions of 'material discrepancy' or 'unresolved' allow each government to read the same finding differently, converting every routine discrepancy into a political deadlock and consuming the 90-day clock.
- Failure to separate inspectorate facts from political determination contaminates the technical evidence base, making the Go/Modify/Stop verdict politically contestable and undermining the credibility of the entire verification regime.
- If suspension thresholds are not tightly scoped to sites with unresolved material discrepancies, a single manufactured dispute can halt verification across all declared sites, creating a powerful delay tactic for either side.
- Absence of a fixed deadlock clock or escalation path means deadlocked factual disputes can fester beyond the 10-business-day threshold, aging material discrepancies and potentially forcing a false Stop or invalidating the latency KPI.
- If the framework conflicts with the binding bilingual glossary or interpretive annex, pre-registered terms become unenforceable and interpretive disputes resurface as access-denial tools.

**Worst Case Scenario**: A co-chair deadlock on a material finding triggers an automatic program-wide suspension or, conversely, shields an operator indefinitely; no bounded escalation path activates, the 90-day Phase One clock fails to start or produces no accepted verdict, the $5B bilateral mechanism collapses, and both governments withdraw with mutual accusations of bad faith, leaving the frontier AI verification gap unaddressed and severely damaging bilateral confidence.

**Best Case Scenario**: The framework establishes unambiguous decision rights, pre-agreed deadlock machinery, and objective suspension triggers, enabling joint certification of all entry conditions and a smooth Phase One clock start. Routine discrepancies are resolved by joint technical teams, deadlocked facts move to advisory arbitration and escalate within 10 business days, and automatic suspension is applied only to sites with unresolved material discrepancies. The result is zero unilateral findings, bounded deadlock-resolution times, a shared findings narrative, and a defensible Go/Modify/Stop verdict accepted by both governments, with the framework serving as the trusted governance model for future operational phases.

**Fallback Alternative Approaches**:

- Adapt the Model Treaty/Executive Agreement Governance Chapter Template as a starting draft, customizing only the deadlock clock, suspension triggers, and three-tier separation clauses to accelerate creation while preserving core governance principles.
- Convene a focused governance war-game with senior legal, verification, and technical representatives from both sides to negotiate the few genuinely contested clauses (deadlock clock length, arbiter selection, suspension scope) before attempting full-document drafting.
- Develop a minimal viable governance annex covering only the mandatory elements—double-key authorization, 10-business-day deadlock escalation, advisory arbiter, and site-scoped automatic suspension—and defer detailed three-tier separation rules to a follow-on addendum.
- Engage an external arms-control or treaty-verification legal expert to mediate and draft the most contested provisions, using IAEA Safeguards legal frameworks as a reference to resolve the no-casting-vote and suspension-scope issues.
- If full agreement cannot be reached pre-clock, adopt a provisional governance protocol for Phase One with explicit expiry, requiring the co-chairs to ratify a permanent framework before any operational phase beyond Phase One begins.

## Create Document 3: Verification Architecture and Layered Evidence Strategy

**ID**: 5936203e-9ac4-4919-a4a8-17e9a3a2e08e

**Description**: High-level strategy for evidence classes, certainty thresholds, operator-record validation, sampling principles, and the 'no single source decisive' rule, including mandatory two-class evidence for material events and random sampling for low-risk changes. Type: Technical Verification Strategy.

**Responsible Role Type**: Hardware Identity and Evidence Integrity Technical Lead

**Primary Template**: IAEA Safeguards Criteria / State-Level Concept Template

**Secondary Template**: DoD Verification and Validation Framework

**Steps to Create**:

- Map all material-event types and evidence classes to confidence requirements.
- Define evidence hierarchy and limitations of cryptographic attestation.
- Draft sampling rules for operator-provided records.
- Review against latency budget and information-barrier constraints.
- Seek joint technical team and co-chair approval.

**Approval Authorities**: Joint Technical Team; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

**Essential Information**:

- Map every material event type (arrival, installation, removal, transfer, maintenance change, decommissioning) to the specific evidence classes required to reach the target confidence threshold, explicitly identifying where physical witnessing is mandatory versus where operator-provided records may be validated by random sampling.
- Define the complete evidence hierarchy with explicit certainty thresholds for each class, including the binding rule that cryptographic attestation serves as supporting evidence only and never satisfies verification alone.
- Specify the 'no single source decisive' rule: for each material event, identify the minimum combination of independent evidence classes required, and define the criteria for evidence-class independence (e.g., different physical channels, different custodians, orthogonal data types).
- Quantify the sampling rules for operator-provided records: proposed sampling rate or confidence level for low-risk events, random-selection methodology, automatic site-level consequences of a failed sample, and conditions under which sampling escalates to full physical inspection.
- Document how evidence-class weighting interacts with the information-barrier architecture: specify which contextual metadata must survive filtering at filtered workstations so substitution indicators remain detectable, and include validation criteria for blind challenges.
- Define measurable success metrics for the evidence strategy: target false-negative and false-positive rates (e.g., ≤5% false negatives at 95% confidence in blind challenges), evidence-class independence measurements, and operator burden limits.
- Include a feasibility review against the material-event latency budget (operator report ≤4 hours, physical confirmation ≤24 hours, ledger recording ≤1 hour) demonstrating that the required evidence collection fits within these windows.
- Provide a decision matrix mapping combined evidence sets to verdicts (verified, unverified, material discrepancy) and the handoff to materiality definitions and automatic suspension thresholds.

**Risks of Poor Quality**:

- Ambiguous evidence hierarchy or missing independence criteria could allow two dependent evidence sources to be treated as independent, inflating confidence and letting substituted equipment pass undetected.
- Over-weighting cryptographic attestation could create false confidence if attestation is compromised, undermining the entire verification regime.
- Statistically unsound sampling rules for operator-provided records would let deliberate substitutions hide in low-risk events, expanding the false-negative surface beyond the 5% blind-challenge threshold.
- Failure to align with information-barrier constraints could result in filtered evidence stripping the contextual metadata needed to detect substitution, blinding inspectors during blind challenges.
- Unclear certainty thresholds would lead to joint technical team disputes and deadlock escalation, consuming the latency budget and delaying material findings.
- If the document does not address latency budget constraints, the required evidence collection may be infeasible within the 4-hour report / 24-hour confirmation windows, forcing automatic suspension or Modify verdicts.

**Worst Case Scenario**: A deficient evidence strategy leads to a false Go verdict: a substituted frontier-relevant equipment module passes blind challenges undetected because the evidence hierarchy over-relies on operator records and attestation. The undetected substitution becomes an international security incident, erodes all bilateral trust, triggers immediate program termination, and wastes the $5B investment while exposing both nations to uncontrolled frontier AI risk.

**Best Case Scenario**: The document provides a clear, validated evidence hierarchy that enforces 'no single source decisive,' sets statistically sound sampling rules, and aligns with information-barrier and latency constraints. This enables joint technical teams to resolve routine discrepancies quickly, supports a credible Go/Modify/Stop verdict, and reduces the risk of false negatives to ≤5% at 95% confidence. Key decisions enabled: joint certification of Phase One evidence integrity, approval of the final verdict, and validation of the verification architecture for extension to future phases.

**Fallback Alternative Approaches**:

- Adapt the IAEA Safeguards Criteria / State-Level Concept template as a starting framework and populate it with project-specific evidence classes rather than designing from scratch.
- Convene a focused workshop with the Joint Technical Team and the Hardware Identity and Evidence Integrity Technical Lead to collaboratively define the evidence hierarchy and sampling rules in a single working session.
- Produce a minimum viable version covering only the highest-risk material event types (installations, removals, decommissioning) first, then expand to lower-risk events after blind-challenge validation.
- Engage an external safeguards verification expert (e.g., retired IAEA inspector) to draft the evidence-class independence and certainty-threshold sections.
- Use the DoD Verification and Validation Framework template to structure the document and defer quantitative thresholds to the KPI validation plan, making them provisional until validated by pilot exercises.

## Create Document 4: Information Barrier and Filtered Evidence Architecture Strategy

**ID**: e74afcb3-ea15-480a-ade3-2bea1ebb624b

**Description**: High-level architecture strategy for bounded inspection zones, filtered workstations, clean-room examination, dynamic zone boundaries, cryptographic hashing, and blind validation of barrier rules to protect sovereign technology while preserving substitution indicators. Type: Security/Technical Architecture Strategy.

**Responsible Role Type**: Information Barrier and Counterintelligence Security Director

**Primary Template**: Trilateral Initiative Information Barrier Technical Framework

**Secondary Template**: OPCW Confidentiality Annex Implementation Model

**Steps to Create**:

- Define zone categories and evidence-filtering levels by event type.
- Specify clean-room examination and accredited independent examiner protocols.
- Plan blind validation exercises for barrier rules.
- Draft incident-isolation and evidence-hold procedures.
- Obtain security and co-chair approval.

**Approval Authorities**: Information Barrier and Counterintelligence Security Director; Equal National Co-Chairs; Joint Security Committees

**Essential Information**:

- Define bounded inspection zone categories (staging, maintenance, exit, clean-room) and specify for each zone: access control, escort requirements, permitted evidence-collection methods, and dynamic boundary rules by event type.
- Specify evidence-filtering levels for filtered workstations by event class (arrival, installation, removal, maintenance, decommissioning, vendor refusal), identifying exactly which data elements are stripped (customer data, workload details, model weights, source code, network topology) and which contextual metadata must be preserved to detect substitution.
- Mandate cryptographic hash chaining for all filtered evidence to preserve integrity while allowing review; define hash-commitment exchange, chain-of-custody, and evidence-hold procedures.
- Define clean-room examination and accredited independent examiner protocols for vendor-refusal cases, including examiner accreditation criteria, evidence handling, source-code protection, and how clean-room results feed layered evidence weighting.
- Plan blind validation exercises for barrier rules: required challenge types, success thresholds (e.g., false-negative rate ≤5%, substitution-indicator survival criteria), and triggers for revising filter rules after failed challenges.
- Draft incident-isolation and evidence-hold procedures: conditions for automatic hold on evidence-integrity compromise, isolation scope (site vs system), and resumption criteria that preserve verification at unaffected sites.
- Quantify the integration trade-off with latency and layered evidence: estimate added delay introduced by filtering/clean-room steps for each event class and specify how barrier strength is balanced against evidence sufficiency.
- Include approval and security requirements: classification levels, need-to-know compartments, physical/logical separation of national teams, and explicit approval gates for the Security Director, Equal National Co-Chairs, and Joint Security Committees.
- Identify required inputs and sources: Decision 3 strategic options, Risk 6 findings, assumptions in Q8, OPCW Confidentiality Annex Implementation Model, Trilateral Initiative framework, pre-negotiated vendor-access agreements, and existing filter-rule drafts.

**Risks of Poor Quality**:

- Ambiguous or over-filtered zone/evidence rules can strip the contextual metadata needed to detect substituted hardware, causing blind-challenge failures and false negatives that undermine a Go verdict.
- Under-specified barriers risk exposing model weights, source code, customer data, or network topology, triggering a national-security incident, diplomatic crisis, and possible program termination.
- Missing or vague clean-room examiner protocols leave vendor-refusal cases unresolved, increasing unverifiable-equipment counts and pushing the regime toward a Stop verdict.
- Blind validation exercises cannot be executed without clearly defined filter rules and success thresholds, so the architecture remains unproven and the Phase One clock may be delayed.
- Inadequate incident-isolation and evidence-hold procedures can either halt all verification on a single incident or allow compromised evidence to contaminate the final Go/Modify/Stop decision.
- Failure to secure timely co-chair and Joint Security Committee approval stalls implementation, wastes the $750M facilities/cyber envelope, and creates bilateral distrust about information protection.

**Worst Case Scenario**: A poorly designed or unvalidated information barrier either hides a red-team substitution from inspectors — producing a false Go that certifies an undetected capability — or leaks sovereign AI technology and sensitive workload data, triggering a national-security investigation, collapse of bilateral trust, and termination of the $5B program. Either outcome invalidates the verification regime and causes irreparable diplomatic and strategic damage.

**Best Case Scenario**: The architecture is approved and blind-validated to preserve all substitution indicators while protecting every sensitive data element, enabling clean-room vendor-refusal handling, meeting latency and evidence thresholds, and supporting a credible, defensible Go/Modify/Stop verdict. Both governments gain confidence that inspection does not expose sovereign technology, strengthening the bilateral relationship and enabling follow-on phases and future verification regimes.

**Fallback Alternative Approaches**:

- Adopt and tailor the OPCW Confidentiality Annex Implementation Model as a minimum viable information-barrier framework, then iterate with lessons from early exercises.
- Convene a focused joint workshop with the Information Barrier and Counterintelligence Security Director, Joint Security Committees, and independent red-team leads to collaboratively define zone categories and filter levels before drafting the full architecture.
- Pilot the barrier on a single staging zone and one event type in a provisional shadow exercise, validate substitution-indicator survival, then expand incrementally to other zones and event classes.
- Engage an external arms-control verification technical body or accredited independent examiners to review and draft the filter rules and clean-room protocols using proven treaty-verification templates.
- Develop a simplified 'minimum viable document' covering only the most critical elements — zone categories, filter levels, clean-room protocol, and incident-hold triggers — and defer dynamic boundaries and detailed validation planning until after initial blind testing.
- Run blind tabletop simulations with candidate filter rules to identify over-filtering risks before committing to physical filtered-workstation builds and clean-room infrastructure.

## Create Document 5: Baseline Inventory and Cryptographic Asset Registry Framework

**ID**: 13755547-02e0-4650-84bf-e0e090f4a127

**Description**: Framework for conducting and certifying the joint baseline physical inventory of all covered equipment at declared sites and reconciling it into a cryptographic asset registry before clock start, including recount rules and discrepancy resolution. Type: Verification Readiness Framework.

**Responsible Role Type**: Mirrored Inspectorate Operations Director

**Primary Template**: IAEA Physical Inventory Verification Procedures

**Secondary Template**: ISO/IEC 19770-1 IT Asset Management Standard

**Steps to Create**:

- Compile candidate site asset registers and layout data.
- Define serialization, tagging, and reconciliation procedures.
- Set materiality and recount thresholds for discrepancies.
- Execute joint baseline inventory at all six declared sites.
- Certify baseline as a mandatory entry condition.

**Approval Authorities**: Mirrored Inspectorate Operations Director; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

**Essential Information**:

- Define the exact scope of the baseline: inventory all covered equipment, including pre-existing legacy racks, at all six matched declared sites (three per country) based on the current confidential attribute-based covered-equipment schedule and candidate site asset registers.
- Specify the joint inventory methodology: physical count, serialization and tagging procedures, cryptographic hashing of unit identity, and reconciliation of findings against operator procurement, maintenance, and disposal records to populate the cryptographic asset registry.
- Quantify discrepancy classification and recount rules: categorize discrepancies (missing, extra, mismatched serial, unreadable tag, disputed identity), set the unexplained serialized discrepancy threshold (e.g., full recount if >2% per site), and define escalation to the co-chairs for material discrepancies.
- Define baseline certification criteria as a mandatory entry condition: zero unresolved discrepancies before clock start, joint certification by the Equal National Co-Chairs, and a signed joint findings statement documenting the reconciliation process.
- Identify necessary inputs and sources: operator asset registers, procurement/maintenance/disposal records, site layout and access plans, covered-equipment schedule version, pre-installation identity gate data, and domestic access authority compelling operator and vendor cooperation.
- Assign roles and accountabilities: Mirrored Inspectorate Operations Director as owner, Hardware Identity and Evidence Integrity Technical Lead for identity/evidence standards, joint national inventory teams for execution, operators for record provision, and co-chairs for final certification.
- Set schedule and resource requirements: estimated completion window (e.g., 4-8 weeks per sensitivity analysis), staffing derived from the workload model, funding from the site-preparation/ledger envelopes, and fallback-site implications if a declared site cannot be inventoried.
- Define the registry output format: unit-level records (serial number, location, attestation hash, status, disposition), a versioned changelog, discrepancy log, and post-baseline update procedures so the registry remains the trusted reference for all downstream verification.

**Risks of Poor Quality**:

- An incomplete or inaccurate baseline invalidates every downstream material-change verification, because latency and materiality thresholds have no trusted starting state against which changes can be measured.
- Disputed serialization or tagging results can deadlock joint certification, delay the 90-day Phase One clock by 1-2 months, and consume $20-60M of contingency during reconciliation.
- Ambiguous or undefined recount rules make certification calls arbitrary and invite each government to read the same discrepancy record differently, increasing political contestation.
- A registry that lacks cryptographic anchoring, versioning, or tamper-evidence undermines evidence integrity and can trigger ledger divergence, a Stop condition, or a successful substitution challenge.
- Weakening or skipping the baseline to save time creates a false Go risk: if 2-5% of serialized records are inaccurate, the false-negative rate can exceed the 5% blind-challenge threshold and invalidate the entire Phase One verdict.

**Worst Case Scenario**: A failed or contested baseline inventory prevents joint certification and the Phase One clock never starts, leaving $400-600M in sunk preparation and staffing costs and consuming most of the $500M contingency—or worse, a flawed baseline is certified, allowing a hidden substitution to go undetected and producing a false Go that destroys the credibility of the entire bilateral verification regime and triggers political withdrawal.

**Best Case Scenario**: A fully executed joint baseline inventory produces a certified cryptographic asset registry at all six declared sites with zero unresolved discrepancies, giving every subsequent material-change event a trusted baseline; this enables the co-chairs to certify the mandatory entry condition, start the 90-day Phase One clock on schedule, and make a defensible Go/Modify/Stop decision based on credible detection rather than contested starting-state assumptions.

**Fallback Alternative Approaches**:

- Adapt the IAEA Physical Inventory Verification Procedures and ISO/IEC 19770-1 as implementation templates to accelerate procedure design instead of drafting from scratch.
- Run a joint pilot inventory at one matched site pair first to validate serialization, tagging, reconciliation, and certification procedures before scaling to all six sites.
- Engage an independent accredited third-party auditor or IAEA-style inspector to arbitrate disputed serialized records and certify the registry if bilateral teams cannot reach agreement.
- Use automated scanning, cryptographic tagging, and reconciliation software to compress the physical count timeline while preserving joint observation and evidence integrity.
- If full physical inventory cannot be completed before clock start, negotiate a conditional baseline certification with an agreed post-start reconciliation period and KPI-visible tracker, keeping the clock from starting until critical discrepancies are resolved.

## Create Document 6: Entry-Condition Sequencing and Readiness Certification Framework

**ID**: 0c108ab7-6cc3-4ddd-af40-b6a63f73b90c

**Description**: Framework for sequencing and jointly certifying all mandatory entry conditions (original seven plus baseline inventory, inspector-access annex, and escrow pre-funding), including integrated readiness tracker, parallel workstreams, shadow exercises, escalation at the 12-month boundary, and clock-start certification. Type: Readiness Gating Framework.

**Responsible Role Type**: Bilingual Training, Translation, and Readiness Certification Coordinator

**Primary Template**: Program Readiness Certification Template

**Secondary Template**: NASA TRL / Gate Review Framework

**Steps to Create**:

- List all entry conditions with named owners and evidence slots.
- Build integrated readiness tracker and status reporting.
- Define joint certification process for co-chairs.
- Run provisional shadow exercises after site selection.
- Escalate open conditions to heads of state at the 2027-09-04 boundary.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for escalation

**Essential Information**:

- List every mandatory entry condition that must close before the Phase One clock starts, including all ten defined dependencies: bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection, inspectorate roster approval, operator/vendor participation agreements, covered-equipment schedule adoption, baseline inventory/cryptographic registry, inspector visa/customs annex with travel-and-clearance drill, and validation of ledger/barrier/staging/exit/KPI thresholds.
- For each entry condition, assign a named owner, an evidence slot (e.g., signed instrument, enacted legislation, escrow confirmation, joint site declaration, roster approval, vendor agreement, schedule adoption, inventory audit report, drill results, validation report), and a specific certification criterion that must be met before the co-chairs can certify it as closed.
- Define the integrated readiness tracker data model: fields for condition status (open / in progress / condition met / certified), named owner, due date, evidence upload or link, dependencies, risk level, and escalation flag; specify the reporting cadence (e.g., weekly internal status, monthly co-chair readiness summary).
- Specify the joint certification process: double-key approval by the equal national co-chairs, no unilateral clock start, a requirement that both sides review the full evidence package, and a final certification package containing the complete checklist and evidence index.
- Define sequencing logic and critical path: run all preparatory workstreams in parallel under the tracker, but identify which conditions are prerequisites for others (e.g., domestic access authority before enforceable vendor agreements, site selection before shadow exercises, baseline inventory before clock start), and state which conditions are the final gating items.
- Prescribe provisional shadow exercise parameters: timing after site selection and inspector training, explicit non-binding labeling, exclusion of findings from the final Go/Modify/Stop decision, a prohibition on creating de facto obligations before legal authority exists, and a process for feeding lessons learned into readiness without starting the clock.
- Detail the escalation mechanism at the 2027-09-04 boundary: any open condition escalates to heads of state or party leadership, becomes a public KPI, and does not start the 90-day clock; define who initiates escalation, in what format, and what resolution options leadership may choose (extend with KPI-visible delay, resolve, or terminate).
- Set readiness metrics and targets: 100% reciprocal certification at clock start, checklist closure rate over time, days to certification per condition, number of open conditions at the 12-month boundary, and a target of zero uncertified entry conditions at launch.
- Define roles and responsibilities for the Bilingual Training, Translation, and Readiness Certification Coordinator, the co-chairs, joint legal task force, terminology commission, site-selection group, and each named condition owner; include separation of duties between preparation activities and certification decisions.
- Include a gate-review approach adapted from the NASA TRL / Gate Review Framework, with each entry condition treated as a readiness gate that must pass defined evidence-maturity criteria, and document the approval authority required to pass each gate.

**Risks of Poor Quality**:

- Incomplete or ambiguous entry-condition list allows the Phase One clock to start with unfulfilled prerequisites, such as a missing baseline inventory or inspector-access annex, invalidating verification results and forcing a contested Stop verdict.
- Without named owners and evidence slots, conditions can lag silently and readiness status becomes unverifiable, eroding bilateral trust and making the certification process a bureaucratic checkbox.
- A vague joint certification process enables one side to unilaterally declare readiness or withhold certification, triggering double-key deadlock and stalling the Phase One clock indefinitely.
- If shadow exercises are not explicitly non-binding, they create de facto obligations before domestic legal authority exists, leading to legal or political exposure and constraining later sovereign decisions.
- An absent or unclear escalation mechanism leaves open conditions unresolved at the 2027-09-04 boundary, idling trained staff, consuming the inspectorate and contingency envelopes, and risking program collapse.
- Incorrect sequencing logic can start costly workstreams before legal authority or site selection is certified, producing sunk costs and premature political commitments that cannot be undone.
- Certification criteria based on paper declarations rather than concrete evidence artifacts allow co-chairs to certify conditions that are not operationally ready, causing exercise failures and false confidence in the Go decision.

**Worst Case Scenario**: The framework is delivered with missing entry conditions, no verifiable evidence slots, and a weak joint certification process; the 90-day clock starts without a completed baseline inventory or inspector-access annex, the first unannounced blind challenge is missed because inspectors cannot reach sites or the baseline is disputed, the KPI thresholds fail, and the final verdict is a contested Stop after consuming the $5B budget—or, alternatively, open conditions at the 2027-09-04 boundary have no escalation path, the program stalls indefinitely, $400–600M in sunk preparation and staffing costs are lost, and political support collapses.

**Best Case Scenario**: The framework is adopted early and provides a transparent, jointly owned readiness path; all ten entry conditions are evidenced and double-key certified by 2027-09-04, the 90-day Phase One clock starts with 100% reciprocal readiness and zero uncertified conditions, shadow exercises have already stress-tested travel, access, and evidence workflows without creating obligations, and the Consortium enters Phase One with strong political continuity—enabling the co-chairs to make a credible, defensible Go/Modify/Stop decision on time and protecting the $5B investment.

**Fallback Alternative Approaches**:

- Use the existing Program Readiness Certification Template as a starting point and populate it in a focused two-day workshop with co-chair staff, legal, site-selection, and operational owners to identify conditions, owners, and evidence requirements.
- Create a minimum viable readiness tracker first—a shared spreadsheet with condition, owner, due date, status, evidence link, and escalation flag—then migrate to a more formal tracker once the condition list is stable and accepted.
- Apply the NASA TRL / Gate Review Framework directly: treat each entry condition as a gate with a maturity level, evidence requirement, and gate-review meeting, using the gate review itself as the certification event.
- Commission the Bilingual Training, Translation, and Readiness Certification Coordinator to draft the framework from the existing dependency list, risk register, and project-plan mitigation content, with legal and operational subject-matter experts reviewing in parallel rather than waiting for full consensus.
- If full joint certification cannot be completed by 2027-09-04, produce a phased 'pre-operations readiness' version of the document that certifies only conditions essential for safe preparatory work—legal authority, escrow pre-funding, and site selection—while clearly labeling all other activities non-binding and deferring the Phase One clock until all remaining conditions meet the same certification standard.

## Create Document 7: Go/Modify/Stop Verdict Construction and Materiality Framework

**ID**: 0ae580fb-34a4-435c-9171-93363deba887

**Description**: Framework for aggregating hundreds of findings into a joint verdict, defining the materiality corridor, bright-line triggers, shared findings narrative, staged technical and political decision process, and unresolved-discrepancy age limits. Type: Decision Framework.

**Responsible Role Type**: Discrepancy Adjudication and Verdict Construction Lead

**Primary Template**: Logical Framework Approach Template

**Secondary Template**: None

**Steps to Create**:

- Define materiality as risk appetite and set bright-line Stop triggers.
- Draft the shared findings narrative template.
- Fix the deliberation window and escalation defaults.
- Separate inspector-reported technical results from co-chair political determination.
- Obtain co-chair approval of the verdict construction process.

**Approval Authorities**: Discrepancy Adjudication and Verdict Construction Lead; Equal National Co-Chairs

**Essential Information**:

- Define materiality explicitly as risk appetite, including a materiality corridor with bright-line Stop triggers: a single unverifiable unit below the corridor is logged but does not block Go, while any unit above the corridor forces Stop.
- Specify the aggregation algorithm for combining hundreds of discrete findings (access findings, blind-challenge results, discrepancy ages, unverifiable-equipment counts, ledger divergence) into a single Go/Modify/Stop recommendation.
- Quantify the materiality thresholds using the provisional KPI targets: false-negative rate ≤5% at 95% confidence, unresolved material discrepancy age ≤10 business days, unverifiable equipment ≤2 units per site or 1% of covered changes, and zero unresolved ledger divergence.
- Define which findings are automatic Stop triggers versus Modify triggers versus logged-but-tolerated findings, including asymmetric access, shielding, unresolved divergence, withheld funding, and evidence-integrity compromise.
- Draft the shared findings narrative template that co-chairs must complete together, including sections for technical findings, disagreement surfaces, materiality-corridor position, and the joint recommendation.
- Fix the staged decision process: inspectors publish operational/technical results first, then co-chairs issue the verdict only after a fixed deliberation window, with the window length and escalation defaults explicitly stated.
- Set unresolved-discrepancy age limits and the rule for how old or stale discrepancies are weighted when the 90-day clock ends.
- Specify how the framework handles co-chair disagreement in the verdict itself, including the 10-business-day deadlock escalation path and the role of the advisory arbiter in factual disputes.
- Identify necessary inputs and sources: Decision 4 in strategic_decisions.md, the KPI thresholds in assumptions.md, risk registers from project-plan.md, and the three strategic paths in scenarios.md for calibration testing.
- Include a worked example of how a hypothetical mix of findings (e.g., one material unverifiable rack, two logged discrepancies, one vendor refusal) would be aggregated under the corridor rules.

**Risks of Poor Quality**:

- An unclear or contested materiality definition lets each government read the same findings record differently, making the final verdict politically contestable and delaying or invalidating the Go/Modify/Stop decision.
- Without bright-line thresholds, a single unverifiable rack or vendor refusal can either sink the entire regime or be quietly hidden, undermining the credibility of Phase One.
- Failure to separate inspector-reported technical results from co-chair political determination invites political negotiation to override operational evidence, destroying the verdict's evidentiary basis.
- Missing unresolved-discrepancy age limits allows stale findings to accumulate, so the final verdict may be based on outdated or unverified information rather than the true state at clock end.
- An untested or ambiguous aggregation rule could produce a false Go that certifies an undetectable substitution risk, or a false Stop that wastes the $5B investment and collapses bilateral confidence.
- A shared findings narrative template that is not pre-approved can lead to unilateral assessments being substituted for joint analysis, recreating the no-trust dynamic the Consortium is designed to overcome.

**Worst Case Scenario**: Phase One reaches the end of the 90-day clock with no agreed framework for aggregating findings, so the co-chairs cannot produce a joint verdict; one government uses the ambiguity to characterize the results as a Go while the other characterizes them as a Stop, triggering a diplomatic impasse, automatic suspension, and the effective collapse of the $5B bilateral verification program with hundreds of millions in sunk costs and no credible detection result.

**Best Case Scenario**: The framework is pre-approved and validated before the clock starts, giving both governments a shared, objective basis for aggregating hundreds of findings into a defensible joint verdict. It enables the co-chairs to issue a credible Go/Modify/Stop decision within the deliberation window, converts potential disagreements into resolvable technical questions, prevents any single unverifiable rack from either sinking or hiding the result, and establishes the trust and procedural legitimacy needed to extend the Consortium into operational phases beyond Phase One.

**Fallback Alternative Approaches**:

- Use the Logical Framework Approach template as a rapid scaffold, mapping inputs, outputs, outcome indicators, and assumptions directly onto the verdict decision, then fill in only the bright-line Stop triggers and escalation defaults first.
- Convene a focused two-day workshop with the Discrepancy Adjudication Lead, co-chairs, and joint technical teams to negotiate and pre-register the materiality corridor and aggregate rules collaboratively rather than drafting in isolation.
- Develop a minimum viable verdict framework covering only the non-negotiable elements—bright-line Stop triggers, the 10-business-day discrepancy age limit, and inspector-vs-co-chair separation—and defer the shared narrative template and deliberation-window details to a post-clock addendum.
- Engage an independent neutral expert or former arms-control verification official to draft the aggregation rule based on the KPI thresholds in assumptions.md and the strategic paths in scenarios.md, with both governments reviewing before adoption.
- Run a tabletop exercise using the three scenario paths (Builder's Balanced, Pioneer's Gambit, Consolidator's Controlled Path) to test candidate materiality definitions against realistic finding mixes and select the most defensible framework. 

## Create Document 8: Material-Event Latency Budget and Silent-Window Definition Framework

**ID**: 4d2b29e0-d243-4641-8e0f-fe6f46b22ea5

**Description**: Framework for fixing the maximum time a physical material change may go unrecorded, allocating the budget across operator reporting, physical confirmation, and ledger recording, and defining silent-window bounds that red teams exploit and blind challenges must beat. Type: Verification Latency Framework.

**Responsible Role Type**: Hardware Identity and Evidence Integrity Technical Lead

**Primary Template**: Verification Latency Budget Template

**Secondary Template**: DoD Time-Sensitive Targeting Latency Model

**Steps to Create**:

- Define provisional layered latency thresholds (e.g., 4h reporting, 24h confirmation, 1h ledger recording).
- Assess trade-offs against production disruption and information barriers.
- Set silent-window bounds and unannounced sweep compensation rules.
- Validate thresholds through pilot blind challenges.
- Approve through joint technical governance.

**Approval Authorities**: Hardware Identity and Evidence Integrity Technical Lead; Joint Technical Team; Equal National Co-Chairs

**Essential Information**:

- Quantify the layered latency budget: operator event reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour, and specify how these interior windows interact and are independently verified.
- Define the maximum silent window (maximum time a material change may go unrecorded) and the exact trigger events for starting and stopping each latency segment, including who records timestamps and how tamper-evidence is maintained.
- List explicit trade-offs against production disruption, information-barrier filtering latency, vendor-refusal escalation ladder, and mirrored staffing constraints, with accepted bounds for each.
- Specify compensation rules for any accepted discrete silent windows: unannounced sweep frequency, random selection method, and the maximum expected cumulative undetected exposure.
- Detail success metrics and KPI thresholds: local event-recording latency under 5 minutes, cross-national synchronization within 1 hour, divergence reconciliation within 24 hours, and false-negative rate no greater than 5% at 95% confidence in blind challenges.
- Define the validation plan: six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal), independent red teams, and no advance knowledge of exercise timing.
- Identify required inputs and dependencies: completed baseline inventory, entry-condition certification, inspector visa/customs annex, ledger synchronization bounds, and information-barrier filter rules.
- Document governance and approval path: joint technical team recommendation, double-key approval by Equal National Co-Chairs, deadlock escalation after 10 business days, and alignment with Phase One verdict construction and materiality definitions.

**Risks of Poor Quality**:

- Ambiguous or unvalidated latency thresholds make the silent window a guaranteed concealment corridor; red teams can hide substitutions and blind challenges fail, forcing a false Go or a contested verdict.
- Overly strict thresholds that ignore production disruption or information-barrier delays create impossible compliance, causing false Modify/Stop outcomes and wasting the $5B investment.
- Failure to define independently verifiable interior windows lets operators or inspectors game reported times, undermining the regime's falsifiable honesty claim.
- Unspecified unannounced-sweep compensation rules leave residual detection risk unbounded, directly contradicting the credible-detection requirement.
- Unaddressed conflicts with the vendor-refusal escalation ladder and filtered-evidence barriers consume the latency budget and delay every recorded event without a clear mitigation path.
- Lack of pre-agreed thresholds turns the KPI dashboard into a negotiation object and makes the Phase One Go/Modify/Stop verdict politically contestable.

**Worst Case Scenario**: Thresholds are defined on paper but never validated through blind challenges; red teams exceed the 5% false-negative bound or hide a substitution longer than the 4+24+1 hour budget. The Consortium nevertheless issues a Go based on dashboard metrics, certifying a regime that cannot detect a real substitution. A subsequent material change goes undetected for days, triggering a national-security incident, collapse of bilateral confidence, and termination of the $5B program with inspectors withdrawn.

**Best Case Scenario**: The framework produces validated, jointly approved latency and silent-window thresholds that are credible to both governments and achievable by operators. Pilot blind challenges confirm detection rates, interior windows are independently verifiable, and the KPI dashboard reflects real latency performance. This directly enables a defensible Go/Modify/Stop verdict, supports Phase One certification, and clarifies operational decisions on staffing, information-barrier strength, and unannounced sweep deployment.

**Fallback Alternative Approaches**:

- Use the DoD Time-Sensitive Targeting Latency Model as a starting template and adapt its time-phasing and verification concepts to the bilateral verification context.
- Convene a focused joint technical workshop with operator representatives, red-team leads, and information-barrier engineers to co-define thresholds and trade-offs in a single session.
- Produce a minimum viable framework covering only the three core thresholds (4h reporting, 24h confirmation, 1h ledger recording) and the silent-window bound, deferring detailed sweep compensation rules to a follow-on annex.
- Run provisional shadow exercises or pilot blind challenges before formal approval to empirically calibrate thresholds and demonstrate feasibility.
- Engage the Hardware Identity and Evidence Integrity Technical Lead with external latency-modeling and information-barrier subject-matter experts to draft a preliminary version for joint technical review.


# Documents to Find