## 1. Baseline Covered-Equipment Inventory and Cryptographic Asset Registry

A trusted baseline inventory is the foundation of all material-change verification; without an agreed starting state, every subsequent change claim is unverifiable and the false-negative threshold cannot be meaningfully assessed.

### Data to Collect

- Total covered equipment units at each of six declared sites by type, manufacturer, serial number, location, and operational status
- Existing operator procurement, maintenance, and disposal records for reconciliation
- Unexplained serialized discrepancy rate per site and root-cause categories
- Resource-loaded schedule and cost estimate for completing physical inventory audits before the Phase One clock starts

### Simulation Steps

- Build a synthetic inventory dataset of roughly 50,000 units with known serialization errors using Python pandas and NumPy; run reconciliation algorithms to estimate discrepancy detection thresholds
- Prototype the cryptographic asset registry using a hash-chained ledger approach in SQLite or Hyperledger Fabric and simulate serialization and count audits to test reconciliation workflows
- Run a Monte Carlo simulation in R or Python to estimate the probability of achieving no more than 2% unexplained discrepancy across all sites under varying data-quality assumptions

### Expert Validation Steps

- Consult IAEA safeguards physical inventory verification specialists and a hardware assurance auditor from a national laboratory to validate inventory methods and discrepancy thresholds
- Engage data center lifecycle experts and operator compliance officers to review feasibility of serialization and reconciliation at real facilities

### Responsible Parties

- Joint Baseline Inventory Task Force
- Hardware Identity and Evidence Integrity Technical Lead
- Datacenter Site Preparation and Cross-Border Logistics Manager
- Operator and Vendor Compliance Liaison

### Assumptions

- **High:** All covered equipment at declared sites can be physically inventoried and serialized before the clock starts.
- **Medium:** No more than 2% unexplained serialized discrepancy is an achievable and meaningful certification threshold.
- **Medium:** Operator records are sufficiently complete and reliable to reconcile physical counts.

### SMART Validation Objective

By 2027-08-01, complete and jointly certify a baseline physical inventory at all six declared sites with 100% of covered units serialized and reconciled in the cryptographic asset registry and no site exceeding 2% unexplained serialized discrepancy.

### Notes

- Estimated validation cost: USD 20-60 million if reconciliation takes four to eight weeks across six sites; charge to the site preparation envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include actual site counts, floor plans, and vendor records; uncertainties are dominated by operator record quality and physical access constraints.


## 2. KPI Threshold and Statistical Test Design

Unsupported KPI thresholds would make the Go/Modify/Stop verdict a political negotiation rather than a defensible verification finding; statistical power and pre-registered analysis rules must be validated before any Go decision.

### Data to Collect

- Number of feasible independent blind challenge events per material-event category within a 90-day, six-site window
- Provisional false-negative and false-positive detection rates from pilot exercises and historical treaty verification exercises
- Confidence-interval calculations for proposed thresholds under varying sample sizes, including the rule of three
- Pre-registered analysis rules for handling unresolved, censored, and contested events

### Simulation Steps

- Use R pwr package and Python statsmodels to compute required sample sizes and confidence bounds for a false-negative rate no greater than 5% at 95% confidence under binomial sampling
- Build a 90-day challenge schedule simulator in Python using SimPy or a custom Monte Carlo model to test whether the required number of independent challenge events can be injected across six sites without cross-contamination
- Run a pre-registered analysis plan on synthetic outcome data in Jupyter or R Markdown to verify that thresholds cannot be moved after results are known

### Expert Validation Steps

- Consult an independent verification statistician from a national laboratory or a recognized arms-control verification methodology group such as VERTIC or IPNDV
- Review the test design with a Treaty Verification and Managed Access Specialist and former INF or CTBTO exercise designers to confirm event definitions and blinding controls

### Responsible Parties

- Independent Red Team and Challenge Exercise Director
- Independent verification statistician
- Joint Technical Teams
- KPI Dashboard Owner

### Assumptions

- **High:** A 90-day, six-site test can support the required number of independent challenge events to substantiate a 5% false-negative claim at 95% confidence.
- **Medium:** Material-event categories can be independently blinded without cross-site contamination.
- **Medium:** Materiality corridors can be pre-registered before operational data exist.

### SMART Validation Objective

By 2027-02-28, approve a pre-registered Test and Evaluation Master Plan specifying challenge event counts, confidence-interval methods, false-positive definitions, and materiality corridors; by 2027-06-30, complete pilot blind challenges at at least two sites with reported confidence intervals.

### Notes

- Estimated validation cost: USD 1-3 million for statistical consulting, pilot challenge execution, and analysis; charge to the testing envelope.
- If 60 independent events per category is infeasible, explicitly reduce the claim to a reported detection rate with confidence intervals rather than asserting 5% at 95% confidence.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty remains in event denominators, false-positive costs, and aggregation rules across sites and event types.


## 3. Information Barrier and Filtered Evidence Validation

Over-filtering can hide substitution evidence and under-filtering can leak sovereign technology; the information barrier must be empirically validated in blind challenges before deployment.

### Data to Collect

- Metadata survival rates after filtering for each evidence class, including serial numbers, cryptographic hashes, and contextual indicators
- Substitution detection sensitivity in blind trials with filtered versus unfiltered evidence
- Leakage incident counts and types during validation exercises
- Latency added to evidence processing by barrier and clean-room procedures

### Simulation Steps

- Build a filtered workstation prototype using Python, OpenCV, or Apache Tika to strip customer data and workload details from synthetic inspection evidence while measuring preservation of identity metadata
- Use Docker or GNS3 network emulation to simulate zone routing and filter rules; test detection algorithms on synthetic substitution datasets
- Use Chaos Engineering tools such as Chaos Mesh to simulate evidence-flow failures and measure impact on detection latency and evidence integrity

### Expert Validation Steps

- Engage an Information Barrier and Counterintelligence Engineer and former IAEA or CTBTO information-barrier practitioners to review filter rule sets
- Validate with an independent red team experienced in adversarial concealment to confirm that substitution indicators survive filtering

### Responsible Parties

- Information Barrier and Counterintelligence Security Director
- Hardware Identity and Evidence Integrity Technical Lead
- Independent Red Team and Challenge Exercise Director
- Accredited Clean-Room Examiner Accreditation Body

### Assumptions

- **High:** Filter rules can be versioned and validated before evidence flows.
- **High:** Identity metadata can be preserved while stripping protected data.
- **Medium:** Blind challenges can reveal barrier misconfiguration without compromising classified information.

### SMART Validation Objective

By 2027-06-30, run at least two blind challenge sets demonstrating substitution detection sensitivity within 10% of the unfiltered baseline and zero evidence-integrity-compromising leaks, with all filter rules versioned and approved.

### Notes

- Estimated validation cost: USD 15-40 million for hardware-separated filtered workstations, clean-room facilities, and blind exercises; charge to the facilities and cyber envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include real workload distributions and contextual metadata patterns; over-filtering risk remains the largest technical uncertainty.


## 4. Latency and Replicated Ledger Performance

Credible detection is ultimately a latency claim; if local recording, synchronization, or reconciliation targets cannot be met, the silent window becomes a concealment corridor and the Go verdict loses meaning.

### Data to Collect

- Local event recording latency, cross-national synchronization latency, and divergence reconciliation time under normal and failure conditions
- Silent-window metrics from unannounced arrival and substitution simulations
- Network outage, node failure, and tamper response times
- Penetration test results from at least two independent firms

### Simulation Steps

- Deploy a replicated ledger prototype using Hyperledger Fabric or Tendermint/Cosmos SDK in Docker or Kubernetes with two national nodes; generate 5,000 synthetic events using Apache JMeter or k6 and measure latency percentiles
- Use ns-3 or Mininet to simulate cross-border network delays and partition scenarios; test divergence reconciliation algorithms under injected faults
- Run fault-injection drills with Chaos Mesh to measure recovery time when a national node fails or network connectivity is lost

### Expert Validation Steps

- Consult a Replicated Ledger and Attestation Architect and distributed systems engineers with treaty verification experience
- Validate with CTBTO or IAEA remote monitoring experts on tamper-evidence, authenticated transmission, and synchronization standards

### Responsible Parties

- Hardware Identity and Evidence Integrity Technical Lead
- Replicated Ledger and Attestation Architect
- Joint Network Operations Team

### Assumptions

- **High:** Local-first recording can achieve less than 5 minutes at production datacenter scale.
- **High:** Cross-national synchronization within 1 hour is achievable without exposing sensitive data through continuous hash-commitment exchange.
- **Medium:** Divergence can be detected and reconciled within 24 hours under realistic failure scenarios.

### SMART Validation Objective

By 2027-05-31, demonstrate in a prototype with at least 5,000 synthetic events that 99th percentile local recording latency is under 5 minutes, cross-national synchronization is under 1 hour, and divergence reconciliation is under 24 hours under injected failure scenarios.

### Notes

- Estimated validation cost: USD 5-15 million for prototype development, independent penetration testing, and load testing; charge to the ledger envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainties include cross-border network quality, hardware security module performance, and the behavior of hash-commitment exchange under adversarial conditions.


## 5. Matched-Site Parity and Reciprocal Access Benchmarking

Site pairing determines whether the asymmetric-access Stop trigger is meaningful or a diplomatic artifact; paper parity must be tested against real facility differences.

### Data to Collect

- Site attributes including declared equipment value, operational role, total capacity, physical layout, security constraints, vendor coverage, grid reliability, and climate risk
- Reciprocal access hours achieved in drills and inspections for each matched pair
- Stress-site inspection difficulty scores and root-cause drivers
- Fallback site pre-qualification data for two sites per country

### Simulation Steps

- Build a multi-attribute parity matrix in Excel or Python pandas with weighted attributes; run sensitivity analysis to test how different weightings affect parity ratios
- Use Monte Carlo simulation in Python to model likely variance in reciprocal access hours and determine whether the 0.9-1.1 tolerance band is achievable
- Use QGIS or ArcGIS to map site locations, grid routes, and logistics constraints for inspection access modeling

### Expert Validation Steps

- Engage INF and New START inspection practitioners and a Treaty Verification and Managed Access Specialist to validate parity metrics
- Consult local grid and environmental regulators and the Datacenter Site Preparation Manager to verify N+1 power and 99.9% uptime feasibility

### Responsible Parties

- Datacenter Site Preparation and Cross-Border Logistics Manager
- Matched-Site Parity Calibration Working Group
- Equal National Co-Chairs
- Local Permitting and Grid Authorities

### Assumptions

- **High:** Six matched sites can be selected with sufficiently comparable inspection burden.
- **Medium:** An access-hours ratio between 0.9 and 1.1 is a meaningful and achievable parity tolerance.
- **Medium:** Deliberately dissimilar stress sites can be included without making parity negotiation impossible.

### SMART Validation Objective

By 2027-04-30, approve a multi-attribute parity matrix for the six declared sites, complete reciprocal access benchmarking for at least two matched pairs in live drills, and pre-qualify two fallback sites per country.

### Notes

- Estimated validation cost: USD 5-10 million for site surveys, fallback pre-qualification, and access benchmarking; charge to the site preparation envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include exact facility floor plans, vendor contracts, and grid reliability histories; parity should measure verification equivalence, not just paper attributes.


## 6. Legal and Regulatory Feasibility

Without enforceable legal authority and a defined legal personality, no entry condition can be certified and the program remains a diplomatic handshake rather than a legal regime.

### Data to Collect

- Legal-form options for the bilateral instrument and Consortium legal personality
- Domestic authority requirements and enactability timelines in both the United States and China
- Escrow legality, appropriation feasibility, export-control, customs, visa, and data-transfer constraints
- Privileges and immunities, liability, indemnity, and cross-waiver models from existing verification regimes

### Simulation Steps

- Run governance war-game tabletop exercises using structured scenario software such as DecisionWise or Miro with decision trees to simulate deadlock and automatic suspension outcomes
- Use Lucidchart or Draw.io to map legal-form decision trees and a conflict-of-laws matrix for each evidence and data class
- Create a legislative timeline model in Microsoft Project or Smartsheet to simulate dependencies and slip impact on the 2027-09-04 certification boundary

### Expert Validation Steps

- Consult US-China bilateral treaty counsel, constitutional lawyers, export-control attorneys, and national-security legal advisors from both governments
- Obtain formal written legal opinions from the U.S. State Department and DOJ and from Chinese MOFA and legislative-affairs bodies on domestic access authority, escrow feasibility, and data-transfer restrictions

### Responsible Parties

- Bilateral Governance and Legal Implementation Lead
- Joint Legal Task Force
- Fiscal Escrow and Independent Audit Controller
- Customs, Visa, and Border Authorities

### Assumptions

- **High:** A legal form can be found that allows the Consortium to hold escrow funds, employ staff, and own evidence systems.
- **High:** Domestic implementing legislation can override conflicting private-law objections.
- **High:** An inspector visa and customs annex with 48-hour processing is negotiable and exercisable.

### SMART Validation Objective

By 2026-12-18, deliver a legal-form memorandum, bilateral instrument outline, model implementing legislation, and inspector-access annex draft; by 2027-03-31, obtain formal legal opinions from both governments on all mandatory legal entry conditions.

### Notes

- Estimated validation cost: USD 30-80 million for legal drafting, legislative outreach, formal opinions, and the travel-and-clearance drill; charge to the legal and audit envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty is highest around constitutional limits on search and seizure, private-property objections, and cross-border transfer of protected data.


## 7. Vendor and Operator Compliance and Forced-Evidence Ladder

A single dominant vendor refusal can cascade across every site it serves and convert a local finding into a systemic Stop condition; the ladder and access agreements must be validated in advance.

### Data to Collect

- Vendor cooperation status and refusal likelihood for each manufacturer, maintenance provider, and logistics company serving declared sites
- Time-to-disposition for each forced-evidence ladder step: vendor-supervised testing, filtered evidence, clean-room examination, and accredited independent examiner
- Unverifiable equipment counts and proximity to the per-site threshold of 2 units or 1% of covered changes
- Operator access-delay incident counts and root causes

### Simulation Steps

- Build a discrete-event simulation in Python SimPy or Arena to model vendor refusal cascades across multiple sites and their effect on latency and materiality counts
- Use Monte Carlo simulation in R to estimate the probability of exceeding the unverifiable-equipment threshold under varying vendor refusal scenarios
- Prototype the vendor-access agreement workflow in a contract management system such as DocuSign CLM to simulate pre-negotiation bottlenecks before clock start

### Expert Validation Steps

- Consult a hardware assurance auditor, the Operator and Vendor Compliance Liaison, and OPCW managed-access experts to validate the forced-evidence ladder
- Engage dominant manufacturers and maintenance providers in structured interviews to assess willingness, legal constraints, and clean-room access feasibility

### Responsible Parties

- Operator and Vendor Compliance Liaison
- Datacenter Site Preparation and Cross-Border Logistics Manager
- Bilateral Governance and Legal Implementation Lead
- Accredited Clean-Room Examiner Accreditation Body

### Assumptions

- **High:** Model vendor-access agreements can be negotiated with dominant vendors before the clock starts.
- **High:** Clean-room examination can provide sufficient evidence without exposing proprietary source code.
- **Medium:** Cross-trained inspectors can perform vendor-supervised diagnostics without the vendor's active cooperation.

### SMART Validation Objective

By 2027-05-31, execute model vendor-access agreements with at least 90% of vendors serving declared sites and complete two live vendor-refusal challenge exercises demonstrating ladder time-to-disposition within the latency budget.

### Notes

- Estimated validation cost: USD 5-15 million for legal negotiation, examiner accreditation, and live exercises; charge to testing and site preparation envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include dominant vendor participation status, export-control constraints, and the time required for each forced-evidence ladder step.


## 8. Staffing and Workforce Feasibility

Staffing gaps create single points of failure, invalidate evidence collection, and break reciprocal parity; clearance and talent scarcity are likely schedule drivers.

### Data to Collect

- Security clearance lead times and applicant pipeline for approximately 450 FTE in both countries
- Bilingual technical talent availability and loaded annual cost rates
- Achievable shift coverage, leave backup, separation-of-duties, and surge cadre ratios
- Recruitment, training, and retention projections against the 12-month entry-condition window

### Simulation Steps

- Build a workforce optimization model in Python using PuLP or OR-Tools to minimize staffing cost while meeting 24/7 coverage, 1.5x leave multiplier, separation-of-duties, and 10% surge requirements
- Run Monte Carlo simulation in Python to estimate the probability that clearance and recruitment delays prevent certification by 2027-09-04
- Use HR analytics software such as Workday or a custom Python model to simulate attrition and retention scenarios under surge deployment

### Expert Validation Steps

- Consult a Bilingual Inspectorate Workforce Planner and security clearance pipeline specialists from both governments
- Engage national verification bodies such as NNSA or IAEA training units to validate staffing workload formulas and training curricula

### Responsible Parties

- Mirrored Inspectorate Operations Director
- Bilingual Training, Translation, and Readiness Certification Coordinator
- Human Resources Leads from Both Governments

### Assumptions

- **High:** Approximately 450 FTE can be recruited, cleared, and trained within 12 months.
- **Medium:** A permanent full-time surge cadre of 10% of baseline is affordable within the USD 750 million inspectorate envelope.
- **Medium:** No single-person critical functions can be avoided with available bilingual technical talent.

### SMART Validation Objective

By 2027-07-31, fill and clear at least 90% of required inspectorate FTE, complete common training for all personnel, and demonstrate in a tabletop exercise that no single-person critical functions exist.

### Notes

- Estimated validation cost: USD 75-150 million in additional premium costs if clearance delays and talent scarcity require expedited hiring; charge to inspectorate and contingency envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty is high on security-clearance lead times, bilingual technical talent supply, and loaded-cost estimates; begin clearances immediately.


## 9. Fiscal Escrow and Currency Risk Validation

Delayed or asymmetric disbursement can act as a quiet veto that starves the program without formally triggering the withholding-funding Stop condition; currency shocks can consume the contingency envelope before testing is complete.

### Data to Collect

- Legal feasibility of full pre-funded escrow in both jurisdictions
- Drawdown and quarterly reconciliation process times versus the 10-business-day suspension trigger
- CNY/USD exchange-rate volatility and local inflation projections
- Envelope-level cost estimates against the USD 5 billion allocation and contingency reserve

### Simulation Steps

- Use Python with QuantLib or an Excel Monte Carlo model to simulate CNY/USD exchange-rate paths and estimate FX exposure under structured conversion windows
- Build an escrow cash-flow model in Microsoft Excel or Python pandas to test envelope-coded drawdown timing and funding-timeliness triggers
- Run stress tests with 5%, 10%, and 20% currency or inflation shocks to determine whether the USD 500 million contingency envelope is sufficient

### Expert Validation Steps

- Consult the Fiscal Escrow and Independent Audit Controller, sovereign treasury lawyers from both countries, and a bilateral fiscal governance auditor
- Obtain written legal opinions on escrow authority and appropriations feasibility from both governments

### Responsible Parties

- Fiscal Escrow and Independent Audit Controller
- Joint Fiscal Governance Unit
- Treasury Counsel from Both Governments

### Assumptions

- **High:** Both governments can legally pre-fund USD 2.5 billion each into a jointly signatory escrow.
- **Medium:** Structured conversion windows and periodic revaluation cap FX exposure within the contingency envelope.
- **Medium:** The 10-business-day contribution-delay trigger is enforceable and KPI-visible.

### SMART Validation Objective

By 2027-02-28, obtain legal opinions confirming escrow feasibility and complete a cash-flow stress test showing that the program can withstand a 5% currency or inflation shock without exceeding the contingency envelope.

### Notes

- Estimated validation cost: USD 1-5 million for legal opinions, modeling, audit setup, and reconciliation design; charge to the legal and audit envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- If full pre-funding is impossible, validate the milestone-tranche fallback with the identical 10-business-day delay trigger and quarterly reconciliation.


## 10. Political Continuity and Leadership Transition Mechanisms

Political discontinuity is the largest program-level risk; without explicit continuity commitments, the investment is exposed to a single leadership transition or appropriations battle.

### Data to Collect

- Specific continuity commitments acceptable to both governments, including multi-year funding obligations, transition briefings, escrow-return clauses, and track-II channels
- Historical transition timelines and risk events that could delay entry-condition certification
- Stakeholder map of influence, decision points, and escalation paths to heads of state or party leadership
- Public KPI dashboard design that makes termination politically costly without leaking sensitive data

### Simulation Steps

- Use stakeholder mapping software such as Kumu or Miro and influence diagrams to model transition scenarios and continuity mechanism effects
- Run scenario planning exercises using a structured template in Microsoft Excel or SharePoint with both national teams to simulate leadership change and appropriations disruption
- Build a decision-tree or simple agent-based model in Python using NetworkX to simulate how different continuity commitments affect program survival probability over a 24-month horizon

### Expert Validation Steps

- Consult the Political Continuity and Government Liaison function, former senior officials from both governments, and track-II verification organizations such as VERTIC or IPNDV
- Engage legislative liaison offices in both countries to test the acceptability of transition briefings and multi-year funding language

### Responsible Parties

- Political Continuity and Government Liaison Lead
- Joint Secretariat
- Strategic Communications Leads
- Equal National Co-Chairs

### Assumptions

- **High:** Multi-year funding obligations are acceptable to both legislatures.
- **Medium:** Track-II channels can sustain technical relationships across political transitions.
- **Medium:** A public KPI dashboard can make termination politically costly without exposing sensitive evidence or schedules.

### SMART Validation Objective

By 2027-02-28, secure at least two formal political-continuity commitments, such as multi-year funding language, a transition-briefing requirement, or an escrow-return clause, and complete a transition-scenario war-game with both national teams.

### Notes

- Estimated validation cost: USD 2-5 million for strategic communications, legal drafting of continuity clauses, and scenario exercises; charge to legal and contingency envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- The killer-application narrative must not expand the legal scope beyond declared-equipment change verification at declared sites.

## Summary

This validation plan targets the highest-sensitivity unknowns of the US-China Consortium Phase One verification program: trusted baseline inventory, statistical credibility of KPI thresholds, information-barrier effectiveness, ledger latency, site parity, legal feasibility, vendor compliance, staffing, fiscal escrow, and political continuity. Immediate action must focus on the most sensitive assumptions first: completing the joint baseline inventory, obtaining formal legal opinions on domestic authority and escrow, approving a pre-registered statistical analysis plan, and validating the information barrier in blind challenges. These four areas gate all other entry conditions and determine whether a defensible Go/Modify/Stop verdict is possible by the 90-day Phase One deadline. Each area has explicit simulation steps using concrete tools and expert validation steps with named classes of human experts, plus SMART validation objectives, cost estimates, and validation results templates to support transparent certification.