**Goal Statement:** Conduct a jointly governed 90-day Phase One operational test of the US-China Consortium that verifies material changes to covered frontier-relevant computing equipment at six matched declared datacenters (three per country), using layered evidence, a replicated tamper-evident ledger, bounded information barriers, and live blind challenges, and conclude with a defensible Go, Modify, or Stop decision based on reciprocal access and credible detection.

## SMART Criteria

- **Specific:** Achieve a jointly certified Go, Modify, or Stop decision for the Phase One operational test of the US-China Consortium, limited to verification of declared-equipment changes (arrivals, installations, removals, transfers, maintenance changes, and decommissioning) at six matched declared datacenters (three per country).
- **Measurable:** Success is measured by observed outcomes: false-negative rate no greater than 5% in blind challenges at 95% confidence; event-recording latency under 5 minutes locally; cross-national synchronization within 1 hour; divergence reconciliation within 24 hours; unresolved material discrepancy age no greater than 10 business days; unverifiable equipment no more than 2 units per site or 1% of covered changes; demonstrated reciprocal access parity; zero unresolved ledger divergence; and a joint written verdict.
- **Achievable:** The goal is achievable because both governments are stipulated to provide political backing, the full USD 5 billion budget is allocated across seven defined envelopes, candidate regions for matched sites are identified, the staffing model is derivable from workload formulas, and the pre-project assessment confirms the technical approach is buildable with no inherent contradictions, provided all entry conditions are treated as mandatory gates before the clock starts.
- **Relevant:** The mission directly addresses the shared national-security interest in preventing uncontrolled frontier AI while deliberately avoiding comprehensive AI governance, workload verification, model-weight inspection, capacity estimation, and hidden-facility discovery. This is a sovereign public-sector national-security program; business purpose, investors, customers, revenue, fundraising, sponsorship, profitability, and return on investment are not applicable. Value is measured by strategic necessity, public value, appropriations governance, and fiscal accountability.
- **Time-bound:** Project start is ASAP from 2026-Sep-04. The mandatory entry-condition phase is targeted for completion by 2027-Sep-04 (12 months). The 90-day Phase One clock starts only after both co-chairs jointly certify all entry conditions, with the final Go/Modify/Stop verdict due no later than 90 days after that certification.

## Dependencies

- Sign the bilateral instrument establishing equal national co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock and automatic-suspension procedures, and a binding bilingual glossary or interpretive annex.
- Enact domestic access authority in both countries compelling operator, manufacturer, maintenance-provider, and logistics-company participation and overriding conflicting private-law objections.
- Appropriate and pre-fund the equal 50/50 contributions into a jointly signatory escrow, or complete the milestone-tranche fallback with a KPI-visible contribution-release delay trigger.
- Select and jointly declare the matched set of six participating datacenter sites, including fallback sites and at least one harder-to-inspect stress site per country.
- Approve the mirrored inspectorate rosters after clearances and common training, with no single-person critical functions and full-time surge capacity.
- Secure operator and vendor participation through model vendor-access agreements, contractual site-eligibility conditions, and domestically administered compensation.
- Adopt the provisional confidential, attribute-based covered-equipment schedule with versioning, fast-track provisional listings, and sunset-review rules.
- Complete and certify the joint baseline physical inventory and cryptographic asset registry of covered equipment at all participating sites.
- Conclude the standing inspector visa and customs annex and pass the end-to-end travel-and-clearance drill.
- Validate the replicated tamper-evident ledger prototype, filtered-evidence information barriers, intake staging identity gates, exit-disposition workflows, and KPI thresholds through independent testing and provisional blind challenges before the clock starts.

## Resources Required

- USD 5 billion total budget (USD 2.5 billion per country) mapped to seven envelopes: 1.25B ledger/attestation/evidence/communications; 1B site preparation/operator compensation; 750M inspectorate; 750M secure facilities/cyber/counterintelligence; 500M independent testing/red teams; 250M legal implementation/audit; 500M contingency/surge.
- Replicated tamper-evident ledger infrastructure with local-first recording, bounded synchronization, continuous hash-commitment exchange, and independent national copies.
- Jointly controlled staging areas, bounded inspection zones, filtered workstations, and clean-room examination facilities at each participating site.
- Secure facilities in both countries with N+1 power redundancy, 99.9% uptime, hardware-separated evidence systems, and counterintelligence monitoring.
- Diagnostic and challenge-exercise equipment including serialization scanners, tamper-evident seals, power-analysis and attestation test rigs, and pre-cleared customs manifests.
- Cryptographic asset registry and baseline inventory tools for joint physical counts and reconciliation.
- Secure communications systems, translation support infrastructure, and versioned document-management systems for the confidential covered-equipment schedule.
- KPI dashboard and reporting infrastructure covering blind-challenge detection, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor refusals, incidents, funding timeliness, and audit exceptions.
- Contingency reserve (USD 500 million) including a dedicated disaster-response allocation of approximately USD 20 million for backup power, relocation, and emergency logistics.
- Pre-negotiated model vendor-access agreements and inspector-access annexes as legal instruments.
- Physical site infrastructure in the Northern Virginia/Ashburn corridor, the Beijing/Hebei cluster, and the Guizhou/Gui'an New Area hub, with exact facilities to be jointly selected and declared.

## Related Goals

- Extension of the Consortium into operational phases beyond Phase One at the same or expanded declared-site set.
- Broader US-China confidence-building measures for frontier AI risk reduction.
- Reuse of the layered-evidence and bounded-inspection verification architecture for other strategic technology agreements.
- Development of a long-term bilateral verification community of practice including inspector training, red-team methods, and information-barrier engineering.

## Tags

- US-China bilateral verification
- frontier AI
- treaty verification
- datacenter inspection
- tamper-evident ledger
- double-key governance
- Go/Modify/Stop
- national security
- hardware assurance
- red team exercises
- information barrier
- matched-site parity

## Risk Assessment and Mitigation Strategies


### Key Risks

- Entry-condition and appropriations delay preventing the Phase One clock from starting within the 12-month target.
- Vendor refusal and unverifiable-equipment contagion cascading from a dominant manufacturer or maintenance provider across multiple sites.
- Information-barrier over-filtering hiding substitution evidence or under-filtering exposing sovereign technology and sensitive data.
- Political discontinuity across leadership transitions reversing commitment to the bilateral mechanism.
- Missing or disputed baseline inventory invalidating all subsequent material-change verification.
- Cross-border inspector access, visa, and customs delays breaking the 24-hour physical-confirmation latency budget.
- Double-key deadlock allowing one co-chair to block findings, sanctions, or suspension indefinitely.
- Ledger divergence or evidence-integrity compromise triggering a Stop condition and undermining the final verdict.
- Delayed or asymmetric contribution release acting as a quiet fiscal veto without formally triggering the withholding-funding Stop condition.
- Staffing gaps, clearance delays, and single-person critical functions in the mirrored inspectorate.
- Matched-site parity asymmetry causing an asymmetric-access Stop condition before exercises begin.
- Covered-equipment schedule drift or revision deadlock allowing new frontier-relevant equipment to ship outside verification.
- Cost overrun, currency movement, or local inflation consuming the contingency envelope before independent testing is complete.
- Operator reluctance or deliberate obstruction causing access delays and inaccurate records.
- Unvalidated KPI thresholds producing a false Go or false Stop decision.

### Diverse Risks

- Operational risk: live challenge failures, site outages, access delays, and logistics disruptions.
- Systemic risk: a single dominant vendor refusal affecting all sites it serves and converting a local finding into a regime-level failure.
- Financial risk: funding timeliness, exchange-rate exposure, inflation, and envelope-level cost overruns.
- Legal and regulatory risk: domestic court challenges, export-control restrictions, visa or customs holds, and interpretive disputes.
- Security risk: cyber compromise, insider threat, counterintelligence failure, and evidence tampering.
- Political risk: leadership transition, public backlash, asymmetric commitment, and escalation deadlock.
- Technical risk: ledger divergence, attestation failure, filtered-evidence misconfiguration, and equipment-identity verification errors.

### Mitigation Plans

- Operate an integrated readiness tracker with named owners and certification fields for every entry condition, run all preparation workstreams in parallel, and escalate any open condition to heads of state or party leadership at the 2027-Sep-04 boundary.
- Negotiate model vendor-access agreements before the clock starts, bind operators to enforce vendor participation, pre-accredit independent clean-room examiners, cross-train inspectors for vendor-supervised diagnostics, and define per-site unverifiable-equipment thresholds that trigger escalation before the materiality corridor is breached.
- Publish and version the filter rules for filtered workstations before evidence flows, validate the barrier in blind challenges to confirm substitution indicators survive filtering, physically and logically separate national teams, and drill the joint cyber-incident isolation protocol twice before clock start.
- Negotiate continuity commitments including multi-year funding obligations, transition briefings, a joint public KPI dashboard, escrow-return clauses for withdrawal, and a track-II engagement channel to sustain technical relationships during political transitions.
- Conduct a joint baseline physical inventory and cryptographic asset registry as a mandatory entry condition, reconcile all discrepancies before clock start, and require a full recount of any site with more than 2% unexplained serialized discrepancy.
- Negotiate a standing inspector-access annex with 48-hour multiple-entry visas, pre-cleared manifests for diagnostic tools, privileges and immunities limited to official verification acts, and complete a full travel-and-clearance drill before Phase One.
- Pre-register deadlock machinery in the bilateral instrument: joint technical teams resolve routine discrepancies, deadlocked factual disputes go to a jointly selected advisory arbiter, deadlocks beyond 10 business days escalate to leadership, and automatic suspension is tightly scoped to unresolved material discrepancies at specific sites.
- Build the ledger local-first with continuous hash-commitment exchange, automatic divergence alerts, reconciliation drills using independent test events, independent penetration testing by two firms, and isolation procedures that preserve verification at unaffected sites.
- Require full escrow pre-funding before clock start, or use milestone-linked tranches with the identical 10-business-day delay trigger, quarterly USD reconciliation, envelope-coded drawdowns, and structured currency-conversion windows to manage FX exposure.
- Staff from a workload formula covering site count, 24/7 shifts, 1.5x leave/backup multiplier, separation of duties, and a permanent full-time surge cadre of at least 10% of baseline; begin security clearances immediately and second staff from existing national verification bodies if recruitment lags.
- Define a multi-attribute parity matrix covering equipment value, operational role, physical layout, security constraints, grid and climate reliability, and vendor coverage; benchmark reciprocal access hours and outcomes; include one stress site per country; and pre-qualify two fallback sites per country.
- Maintain a confidential attribute-based covered-equipment schedule with double-key specialist approval, fast-track provisional listing within 48-72 hours, sunset reviews linked to declared new generations, and a versioned changelog with pre-registered dispute criteria.
- Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan, use fixed-price contracts and structured conversion windows, and pre-qualify fallback sites to limit weather or grid disruption.
- Bind operator participation as a condition of site eligibility, provide compensation through the operator's own government, pre-agree inspection windows that minimize production interference, escalate deliberate obstruction to the co-chairs, and test low-disruption inspection techniques in exercises.
- Pre-register all KPI thresholds with a validation plan, use genuinely independent red teams with no advance knowledge of exercise timing, run all six mandatory unannounced challenge types, and require confidence intervals on false-negative and false-positive rates before any Go decision.

## Stakeholder Analysis


### Primary Stakeholders

- Equal National Co-Chairs representing the United States and China
- Joint Technical Teams and Adjudication Units
- Mirrored National Inspection, Technical, Legal, Cybersecurity, Counterintelligence, Translation, Audit, and Logistics Units
- Joint Legal Task Force and Bilingual Terminology Commission
- Independent Red Teams and Penetration Testing Firms
- Accredited Independent Clean-Room Examiners
- Joint Secretariat and Integrated Readiness Tracker Owners

### Secondary Stakeholders

- Heads of state and party leadership providing political backing and escalation authority
- Domestic legislatures and appropriations committees in both countries
- Participating datacenter operators in the United States and China
- Equipment manufacturers, maintenance providers, and logistics companies serving declared sites
- Export-control, customs, visa, and border authorities in both countries
- Local and regional permitting and grid authorities at selected site locations
- Regulatory and oversight bodies responsible for data protection, privacy, and national security information handling

### Engagement Strategies

- Co-chairs and heads of state receive monthly readiness-tracker reports, joint certification packages, escalation notifications for any open entry condition or deadlock, and a single joint Go/Modify/Stop recommendation with a shared findings narrative.
- Mirrored national units are engaged through a common training curriculum, separation-of-duties assignments, information-barrier discipline, and surge deployment procedures that preserve dual-national observation on every material event.
- The joint legal task force and terminology commission operate under fixed pre-clock deadlines, publishing the binding bilingual glossary, interpretive annex, domestic implementing-legislation notes, and model vendor-access agreements.
- Independent red teams are engaged with full operational independence, no advance knowledge of exercise timing, filtered reporting channels, and direct input to the KPI dashboard and verdict construction.
- Participating operators and vendors are engaged through contractual site-eligibility conditions, fair domestic compensation administered by their own government, pre-agreed inspection windows, and the forced-evidence ladder including clean-room examination before any unverifiable classification.
- Customs, visa, export-control, and permitting authorities receive pre-filed manifests, standing access requests, compliance reports, and drill results so that cross-border inspector access is tested before the clock starts.
- Domestic legislatures and oversight bodies receive quarterly appropriation and audit reports, public KPI dashboard summaries, and transparent fiscal accountability information while sensitive schedules and evidence remain protected.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Ratification or executive approval of the bilateral instrument establishing the Consortium
- Domestic access-authority legislation in both countries authorizing foreign inspector presence and operator and vendor compulsion
- Dual-use export and import licenses for diagnostic, attestation, and challenge-exercise equipment
- Customs pre-authorization and standing visa arrangements for credentialed inspectors
- Environmental, construction, and grid-connection permits for site preparation and secure-facility upgrades
- Security clearances and facility accreditations for personnel handling the confidential covered-equipment schedule and evidence systems

### Compliance Standards

- Agreed bilateral standards for layered evidence, equipment-identity confidence, and no-single-source decisiveness
- Information-barrier and filtered-evidence standards protecting workloads, customer data, model weights, source code, network topology, and security architecture
- National-security information-handling and classified-material standards in both countries
- Export-control and customs compliance standards for cross-border movement of verification equipment
- Data-protection and privacy laws applicable to evidence collected during inspections
- Occupational health, safety, and environmental standards for datacenter inspection and staging areas

### Regulatory Bodies

- U.S. Department of State and U.S. Congress
- Chinese Ministry of Foreign Affairs and National People's Congress or State Council
- U.S. Bureau of Industry and Security and Chinese export-control authorities
- U.S. Customs and Border Protection and General Administration of Customs of China
- Visa and immigration authorities in both countries
- Local permitting, grid, and environmental regulators at selected sites
- Independent audit bodies accountable to both governments for fiscal and compliance reporting

### Compliance Actions

- Draft, sign, and bring into force the bilateral instrument with double-key governance, deadlock machinery, and the binding bilingual glossary before the Phase One clock starts.
- Enact domestic access authority in both countries that overrides conflicting private-law objections and binds operators, manufacturers, maintenance providers, and logistics companies.
- Apply for all export, import, customs, visa, environmental, construction, and grid-connection authorizations in parallel and complete the travel-and-clearance drill before clock start.
- Implement a compliance plan for information barriers, filtered evidence, and data protection, validated by blind challenges and independent penetration testing.
- Conduct quarterly USD reconciliation of envelope drawdowns and independent audits of both governments' domestic compensation disbursements.
- Maintain the confidential versioned covered-equipment schedule under double-key specialist approval and record all revisions in a versioned changelog with pre-registered dispute criteria.