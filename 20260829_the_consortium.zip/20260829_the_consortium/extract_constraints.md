## Positive Constraints

- Project budget: USD 5 billion, 50/50 contribution from the US and China
- Phase One operational test duration: 90 days
- Mandatory entry conditions must be met before the 90-day test begins
- Sovereign public-sector national-security program
- Governance with equal national co-chairs and double-key authorization
- Full-time mirrored inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics and adjudication units
- Create a replicated, tamper-evident ledger with independently verifiable national copies
- Define an Exit Protocol for equipment departure dispositions
- KPI dashboard must cover various performance metrics

## Negative Constraints

- Do not use blockchain
- Do not estimate either country’s total computing capacity
- Do not verify workloads or inspect model weights
- Do not create a comprehensive AI-governance regime
- Do not permanently anchor covered equipment to a current manufacturer, product, architecture, or performance unit
- Do not use a generic Project Sponsor or investor board
- Do not use single-person critical functions or part-time inspectors
- Do not substitute generic project-initiation or stakeholder-engagement phases
- Do not imply continued knowledge beyond the agreed boundary
- Do not allow one country to overrule the other in governance
