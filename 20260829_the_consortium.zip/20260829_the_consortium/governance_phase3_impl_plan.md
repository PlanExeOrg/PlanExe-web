### 1. Project Sponsor drafts initial Terms of Reference for Project Steering Committee

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Terms of Reference v0.1

**Dependencies:**


### 2. Circulate Draft Terms of Reference for review by nominated members of the Project Steering Committee

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on Draft ToR

**Dependencies:**

- Draft Terms of Reference v0.1

### 3. Senior Management formally appoints co-chairs for the Project Steering Committee

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for Co-Chairs

**Dependencies:**

- Feedback Summary on Draft ToR

### 4. Hold initial kick-off meeting for the Project Steering Committee to finalize Terms of Reference

**Responsible Body/Role:** Project Steering Committee (Co-Chairs)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized Terms of Reference for Project Steering Committee

**Dependencies:**

- Appointment Confirmation Email for Co-Chairs

### 5. Project Steering Committee establishes meeting schedule and initial agenda items

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Schedule and Agenda Items Document

**Dependencies:**

- Finalized Terms of Reference for Project Steering Committee

### 6. Project Manager drafts initial Terms of Reference for Project Management Office (PMO)

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Terms of Reference v0.1 for PMO

**Dependencies:**

- Meeting Schedule and Agenda Items Document

### 7. Circulate Draft Terms of Reference for PMO for review by Project Steering Committee

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Feedback Summary on Draft PMO ToR

**Dependencies:**

- Draft Terms of Reference v0.1 for PMO

### 8. Project Steering Committee approves Terms of Reference for PMO

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Terms of Reference for PMO

**Dependencies:**

- Feedback Summary on Draft PMO ToR

### 9. Project Manager assigns project managers for each workstream within the PMO

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- List of Assigned Project Managers

**Dependencies:**

- Approved Terms of Reference for PMO

### 10. Project Manager drafts initial Terms of Reference for Technical Advisory Group

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Terms of Reference v0.1 for Technical Advisory Group

**Dependencies:**

- List of Assigned Project Managers

### 11. Circulate Draft Terms of Reference for Technical Advisory Group for review by PMO

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Feedback Summary on Draft Technical Advisory Group ToR

**Dependencies:**

- Draft Terms of Reference v0.1 for Technical Advisory Group

### 12. PMO approves Terms of Reference for Technical Advisory Group

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Approved Terms of Reference for Technical Advisory Group

**Dependencies:**

- Feedback Summary on Draft Technical Advisory Group ToR

### 13. Project Manager drafts initial Terms of Reference for Ethics & Compliance Committee

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Draft Terms of Reference v0.1 for Ethics & Compliance Committee

**Dependencies:**

- Approved Terms of Reference for Technical Advisory Group

### 14. Circulate Draft Terms of Reference for Ethics & Compliance Committee for review by PMO

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Feedback Summary on Draft Ethics & Compliance Committee ToR

**Dependencies:**

- Draft Terms of Reference v0.1 for Ethics & Compliance Committee

### 15. PMO approves Terms of Reference for Ethics & Compliance Committee

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Approved Terms of Reference for Ethics & Compliance Committee

**Dependencies:**

- Feedback Summary on Draft Ethics & Compliance Committee ToR

### 16. Hold initial kick-off meeting for Ethics & Compliance Committee to establish reporting mechanisms

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Established Reporting Mechanisms Document

**Dependencies:**

- Approved Terms of Reference for Ethics & Compliance Committee

### 17. Hold initial kick-off meeting for Technical Advisory Group to set up guidelines for technical reviews

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Established Guidelines for Technical Reviews Document

**Dependencies:**

- Approved Terms of Reference for Technical Advisory Group