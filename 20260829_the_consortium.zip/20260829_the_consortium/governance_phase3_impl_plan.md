### 1. Both governments designate senior officials to a Joint Formation Team and an Interim Secretariat to establish the governance framework, with a mandate to draft charters, coordinate appointments, and sequence the formation of all governance bodies.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Joint Formation Team designation letters
- Joint Formation Team mandate
- Interim Secretariat staffed

**Dependencies:**

- Political commitment confirmed
- Bilateral instrument drafting underway

### 2. Joint Formation Team drafts the initial Charter for the Joint Steering Council (JSC), including mission, double-key decision rules, no-casting-vote rule, deadlock procedure, impaired-confidence procedure, automatic-suspension thresholds, and meeting cadence.

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 1-2

**Key Outputs/Deliverables:**

- Draft JSC Charter v0.1

**Dependencies:**

- Joint Formation Team mandated
- Strategic Decision 1 (double-key deadlock and suspension) confirmed

### 3. Both governments appoint the two equal national co-chairs of the JSC and confirm the non-voting JSC Secretary, formally designating the JSC's leadership.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Weeks 2-3

**Key Outputs/Deliverables:**

- US Co-Chair appointment letter
- China Co-Chair appointment letter
- JSC Secretary appointment

**Dependencies:**

- Draft JSC Charter available
- Bilateral agreement on co-chair selection criteria

### 4. Convene the JSC formation session; the appointed co-chairs adopt the JSC Charter, formally constituting the JSC and approving its meeting cadence and double-key sign-off matrix.

**Responsible Body/Role:** JSC (formation session, chaired by appointed co-chairs)

**Suggested Timeframe:** Project Weeks 3-4

**Key Outputs/Deliverables:**

- Approved JSC Charter
- JSC meeting cadence
- Double-key sign-off matrix

**Dependencies:**

- Both JSC co-chairs appointed
- Draft JSC Charter v0.1 completed

### 5. Joint Formation Team drafts the Terms of Reference for the Joint Program Management Office (JPMO), Joint Technical Assurance Board (JTAB), Joint Security, Counterintelligence, and Information Assurance Board (JSCIB), Joint Legal and Terminology Commission (JLTC), Joint Audit, Ethics, and Compliance Committee (JAECC), and Joint Discrepancy Adjudication Panel (JDAP).

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 2-4

**Key Outputs/Deliverables:**

- Draft ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP

**Dependencies:**

- Joint Formation Team mandated
- JSC Charter drafting informed by strategic governance decisions

### 6. JSC approves the Terms of Reference for all operational and assurance bodies, the strategic risk appetite, initial budget envelope allocation, and delegated authority thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 4-6

**Key Outputs/Deliverables:**

- Approved ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP
- Strategic Risk Appetite Statement
- Approved budget envelope allocation
- Delegated authority register v0.1

**Dependencies:**

- JSC Charter adopted
- Draft ToRs completed by Joint Formation Team
- Strategic decisions and budget envelopes confirmed

### 7. JSC appoints the JPMO co-deputy directors and the Joint Secretariat Lead, formally establishing the JPMO leadership team.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 6-8

**Key Outputs/Deliverables:**

- JPMO co-deputy director appointment letters
- Joint Secretariat Lead appointment
- JPMO leadership team confirmed

**Dependencies:**

- JPMO ToR approved

### 8. Hold the JPMO kick-off meeting; adopt the operational charter, assign workstream leads, and validate the six-site workload-based staffing model.

**Responsible Body/Role:** JPMO (under appointed co-deputy directors)

**Suggested Timeframe:** Project Weeks 8-10

**Key Outputs/Deliverables:**

- JPMO operational charter
- Workstream lead assignments
- Staffing model v0.1 validated

**Dependencies:**

- JPMO co-deputy directors appointed
- JPMO ToR approved

### 9. JPMO implements the integrated readiness tracker and envelope-level budget control system, including escalation templates and delegated authority registers.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- Integrated readiness tracker
- Envelope-level budget control system
- Escalation templates
- Delegated authority register v0.2

**Dependencies:**

- JPMO kick-off completed
- Budget envelope allocation approved by JSC

### 10. Both governments jointly appoint the JTAB national technical leads and the three independent external experts in hardware assurance, treaty verification, and information security.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- JTAB appointment letters
- JTAB membership roster confirmed

**Dependencies:**

- JTAB ToR approved

### 11. Hold the JTAB formation/kick-off meeting; adopt the technical assurance work plan, begin drafting the layered evidence hierarchy, and publish the KPI threshold validation plan.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JTAB technical assurance work plan
- Layered evidence hierarchy draft
- KPI threshold validation plan v0.1

**Dependencies:**

- JTAB members appointed
- JTAB ToR approved

### 12. Both governments appoint the JSCIB national security leads and jointly appoint two independent security experts.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JSCIB appointment letters
- JSCIB membership roster confirmed

**Dependencies:**

- JSCIB ToR approved

### 13. Hold the JSCIB formation/kick-off meeting; conduct the baseline security and counterintelligence risk assessment and approve the information-barrier implementation plan and separation-of-duties matrix.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Weeks 12-16

**Key Outputs/Deliverables:**

- Baseline security and counterintelligence risk assessment
- Information-barrier implementation plan
- Separation-of-duties matrix

**Dependencies:**

- JSCIB members appointed
- Candidate site and secure-facility list available

### 14. Both governments appoint the JLTC legal co-leads, technical linguists, export-control and customs legal specialists, and the independent international-law expert.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JLTC appointment letters
- JLTC membership roster confirmed

**Dependencies:**

- JLTC ToR approved

### 15. Hold the JLTC formation/kick-off meeting; begin drafting the binding bilingual glossary, interpretive annex, and pre-registered interpretive positions.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- Draft bilingual glossary v0.1
- Draft interpretive annex
- Pre-registered interpretive positions template

**Dependencies:**

- JLTC members appointed
- Bilateral instrument draft text available

### 16. JLTC prepares model vendor-access agreements, operator site-eligibility conditions, and the inspector-access, visa, and customs annex.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Draft model vendor-access agreement
- Operator site-eligibility conditions
- Draft inspector-access, visa, and customs annex

**Dependencies:**

- JLTC kick-off completed
- Domestic access-authority legislative drafts reviewed

### 17. Both governments jointly appoint the JAECC independent chair, two independent external members, and designate the national compliance officers.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- JAECC appointment letters
- National compliance officer designations
- JAECC membership roster confirmed

**Dependencies:**

- JAECC ToR approved

### 18. Hold the JAECC formation/kick-off meeting; adopt the audit charter, whistleblower policy, conflict-of-interest rules, and the KPI validation audit plan.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Weeks 14-20

**Key Outputs/Deliverables:**

- JAECC audit charter
- Whistleblower policy
- Conflict-of-interest rules
- KPI validation audit plan

**Dependencies:**

- JAECC members appointed
- JPMO budget control system available for audit access

### 19. JSC approves the JDAP mandate, materiality definitions, and automatic-suspension trigger thresholds recommended by JTAB and JPMO.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 2-4

**Key Outputs/Deliverables:**

- Approved JDAP ToR
- Approved materiality definitions
- Approved automatic-suspension trigger thresholds

**Dependencies:**

- JTAB evidence hierarchy draft
- JSC strategic risk appetite approved

### 20. JSC appoints the JDAP national senior adjudication officers and jointly selects the neutral technical arbiter.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 3-5

**Key Outputs/Deliverables:**

- JDAP appointment letters
- Neutral technical arbiter appointment
- JDAP membership roster confirmed

**Dependencies:**

- JDAP ToR approved
- Materiality definitions approved

### 21. Hold the JDAP formation/kick-off meeting; adopt standard operating procedures, the discrepancy log, and unresolved-discrepancy age tracking.

**Responsible Body/Role:** JDAP

**Suggested Timeframe:** Project Months 4-6

**Key Outputs/Deliverables:**

- JDAP standard operating procedures
- Discrepancy tracking dashboard
- Unresolved-discrepancy age metrics

**Dependencies:**

- JDAP members appointed
- Materiality definitions approved

### 22. JTAB finalizes the layered evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds, incorporating JSCIB security input.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Evidence hierarchy v1.0
- Information-barrier filter rules v1.0
- Clean-room protocols
- Provisional KPI thresholds

**Dependencies:**

- JTAB kick-off completed
- JSCIB input on information-barrier security

### 23. JSC double-key approves the evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 5-7

**Key Outputs/Deliverables:**

- JSC approval minutes
- Approved technical standards
- Approved provisional KPI thresholds

**Dependencies:**

- JTAB technical submissions complete
- JSCIB security review complete

### 24. JTAB selects independent red-team providers and establishes no-advance-knowledge reporting channels for the six mandatory unannounced challenge types.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 5-8

**Key Outputs/Deliverables:**

- Red-team provider contracts
- No-advance-knowledge reporting protocol
- Challenge exercise design plan

**Dependencies:**

- JSC-approved provisional KPI thresholds
- Independent testing budget envelope available

### 25. JSCIB executes the first cyber-incident isolation drill and independent penetration testing of the ledger, filtered workstations, and clean-room systems.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Penetration test reports
- First cyber-incident isolation drill after-action report
- Remediation plans

**Dependencies:**

- JSCIB kick-off completed
- Ledger and filtered-workstation prototypes available

### 26. JPMO validates the detailed staffing model, initiates security clearances, begins common training for mirrored national units, and establishes the full-time surge cadre roster.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Staffing model v1.0
- Clearance initiation records
- Common training curriculum
- Surge cadre roster

**Dependencies:**

- JPMO kick-off completed
- Workload assumptions and site count confirmed
- JTAB technical standards available for inspector training

### 27. JLTC completes the binding bilingual glossary, interpretive annex, and model legal instruments, and submits them to JSC for double-key approval.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Final bilingual glossary
- Final interpretive annex
- Final model vendor-access and inspector-access instruments

**Dependencies:**

- JLTC drafting complete
- Bilateral instrument text finalized
- Domestic legal requirements confirmed

### 28. JSC double-key approves the binding bilingual glossary, interpretive annex, and model legal instruments before the Phase One clock starts.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 6-9

**Key Outputs/Deliverables:**

- JSC approval minutes
- Certified bilingual glossary
- Approved interpretive annex
- Approved legal instruments

**Dependencies:**

- JLTC final submissions complete
- Negotiation positions reconciled

### 29. JAECC conducts the baseline compliance and ethics risk assessment and completes the first quarterly audit cycle of envelope-level expenditures and drawdowns.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Baseline compliance and ethics risk assessment
- Q1 audit report
- Audit exception register

**Dependencies:**

- JAECC kick-off completed
- Budget control system operational
- First drawdowns executed

### 30. JSCIB executes the second cyber-incident isolation drill and certifies security and counterintelligence readiness for Phase One.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 7-10

**Key Outputs/Deliverables:**

- Second drill after-action report
- Security readiness certification package
- Counterintelligence readiness assessment

**Dependencies:**

- First drill completed
- Secure facilities and evidence systems operational

### 31. JPMO consolidates all governance-body readiness inputs into the integrated readiness tracker and prepares the entry-condition certification package for JSC review.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 8-11

**Key Outputs/Deliverables:**

- Consolidated readiness tracker
- Entry-condition certification package draft
- Gap analysis and remediation plan

**Dependencies:**

- All bodies' initial charters and work plans approved
- JLTC legal instruments approved
- Staffing and clearance milestones met

### 32. JSC convenes a formal governance integration and orientation session with all body leads to review escalation paths, decision rights, and KPI dashboard reporting, and to resolve any interfacing issues.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 9-11

**Key Outputs/Deliverables:**

- Governance integration minutes
- Escalation path diagram
- KPI dashboard reporting protocols
- Interfacing issues log

**Dependencies:**

- All governance bodies formally established
- JAECC KPI validation plan available
- JPMO consolidated readiness tracker available

### 33. JSC conducts the final entry-condition certification review, jointly certifies that all mandatory entry conditions are met, and formally starts the 90-day Phase One clock.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** By 2027-Sep-04 target (Project Month 12)

**Key Outputs/Deliverables:**

- Joint entry-condition certification
- Phase One clock start authorization
- Certified readiness package

**Dependencies:**

- Entry-condition certification package approved
- All legal instruments signed
- Escrow pre-funding confirmed
- Sites and inspectors approved
- KPI thresholds validated