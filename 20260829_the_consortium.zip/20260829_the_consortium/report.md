# Bilateral Datacenter Verification

Generated on: 2026-09-04 23:11:26 with PlanExe. [Discord](https://planexe.org/discord.html), [GitHub](https://github.com/PlanExeOrg/PlanExe)

# Executive Summary

## Focus and Context
Can the world's two most powerful rivals verify frontier AI risk instead of relying on faith? This plan creates a $5 billion, jointly governed 90-day Phase One operational test for the U.S.-China Consortium to verify material changes to frontier-relevant computing equipment at six matched datacenters—three per country—using layered physical and digital evidence, a replicated tamper-evident ledger, bounded information barriers, and live blind challenges. It is deliberately narrow: no workload, model-weight, or hidden-facility inspection, only declared-equipment change verification culminating in a defensible Go, Modify, or Stop decision.

## Purpose and Goals
The main objective is to jointly certify whether the bilateral verification regime can credibly detect material equipment changes within a fixed 90-day operational window. Success criteria include a false-negative rate no greater than 5% in blind challenges at 95% confidence, local event recording under 5 minutes, cross-national ledger synchronization within 1 hour, divergence reconciliation within 24 hours, unresolved material discrepancies no older than 10 business days, no more than 2 unverifiable units per site or 1% of covered changes, demonstrated reciprocal access parity, zero unresolved ledger divergence, and a joint written Go/Modify/Stop verdict accepted by both co-chairs.

## Key Deliverables and Outcomes
Key deliverables include: (1) a signed bilateral instrument with double-key governance, deadlock machinery, automatic-suspension triggers, and a binding bilingual glossary; (2) enacted domestic access authority and a standing inspector visa/customs annex; (3) pre-funded $5 billion escrow with envelope-coded drawdowns; (4) six jointly selected matched sites with baseline inventory and cryptographic asset registry; (5) a ~450-FTE mirrored inspectorate with a permanent surge cadre; (6) replicated tamper-evident ledger, information barriers, staging areas, and clean-room facilities; (7) six mandatory unannounced blind challenge types executed across all sites; and (8) a shared findings narrative, final joint verdict, and conditional Phase Two roadmap.

## Timeline and Budget
The mandatory entry-condition phase targets completion within 12 months, starting September 2026 and aiming for certification by September 2027; the 90-day Phase One clock starts only after joint certification, with the verdict due within 90 days. Total budget is $5 billion, split 50/50, pre-funded into escrow: $1.25B ledger/evidence, $1B site preparation/operator compensation, $750M inspectorate, $750M facilities/cyber/counterintelligence, $500M independent testing/red teams, $250M legal/audit, and $500M contingency/surge.

## Risks and Mitigations
The two most significant risks are (1) political/legal discontinuity or entry-condition delay that prevents the clock from starting, and (2) unvalidated KPI thresholds or information-barrier imbalance producing a contested or false verdict. Mitigations include integrated readiness tracking with leadership escalation, pre-registered legal opinions and a binding governance annex, full escrow pre-funding with a 10-business-day delay trigger, pre-negotiated vendor-access agreements and clean-room examiner accreditation, independent red teams with statistically pre-registered test plans, pilot blind challenges before launch, and continuity commitments such as transition briefings and escrow-return clauses.

## Audience Tailoring
Formal, technical, and sovereignty-aware tone tailored for U.S. and Chinese government decision-makers, appropriations committees, national-security agencies, and verification experts. Avoids commercial framing and emphasizes fiscal accountability, reciprocal access, legal enforceability, and credible detection.

## Action Orientation
Immediate next steps: stand up the joint secretariat and integrated readiness tracker by September 2026; convene the joint legal task force to produce a legal-form memorandum by 2026-10-30 and draft the bilateral instrument and implementing legislation by 2026-12-18; negotiate the inspector visa/customs annex and obtain formal legal opinions by 2027-03-31; begin baseline physical inventory and security clearances immediately; secure full escrow pre-funding; execute vendor-access agreements and complete pilot blind challenges at two sites by 2027-06-30; and certify all entry conditions by 2027-09-04. Owners include the equal co-chairs, joint legal task force, treasuries, joint inspection teams, and independent red-team director.

## Overall Takeaway
This plan offers the first practical, evidence-based architecture for verifying frontier AI compute between strategic rivals without ceding sovereignty or exposing sensitive technology. Its value rests on disciplined entry-condition certification, statistically validated detection, and political continuity—if executed faithfully, Phase One transforms frontier AI competition from unchecked escalation into a managed, verifiable contest with a clear and honest verdict.

## Feedback
To strengthen the summary, add the statistical power calculations behind the 5%-at-95%-confidence claim, including expected challenge-event counts per category and confidence-interval methods; explicitly mark unvalidated KPI thresholds as TBD pending pilot blind challenges; include formal written legal opinions from both governments on domestic authority, escrow, and data transfer; specify the managed-access floor and deadlock default rules in the governance annex; quantify the FX/contingency allocation and stress-test scenarios; publish a role-by-role FTE table reconciling the $750M inspectorate envelope; and secure at least two political-continuity commitments before clock start.

# Pitch

Persuasive elevator pitch.

# From Faith to Verification: A U.S.–China Operational Test for Frontier AI

## Project Overview

What if the two most powerful nations on Earth could verify the world's most dangerous technology—not on faith, but through **double-keyed evidence**, **on-site inspection**, and **mutual accountability**? The Cold War proved adversaries can do exactly that. Now frontier AI presents a new strategic risk, and the United States and China have a once-in-a-generation chance to turn that risk into a shared system of verification.

This project builds a **$5 billion, jointly governed 90-day Phase One operational test** to verify material changes to frontier-relevant computing equipment at six matched datacenters—three in each country—using layered physical and digital evidence, a tamper-evident ledger, bounded information barriers, and live red-team challenges.

It is deliberately narrow: no workload inspection, no model-weight exposure, no hidden-facility discovery. Only declared-equipment changes. The result is a defensible **Go, Modify, or Stop** verdict grounded in reciprocal access and credible detection. This is not arms-control nostalgia. It is the first practical verification architecture for frontier AI—and it will determine whether two sovereign rivals can turn a shared existential challenge into a shared system of trust.

## Why This Pitch Works

This project is framed as a **strategic necessity** rather than a commercial venture. It opens with a bold, historically resonant hook—adversaries verifying dangerous technology—then immediately clarifies the project's narrow, achievable scope. It respects sovereignty by emphasizing **double-key governance**, bounded information barriers, and no unilateral overreach.

The pitch appeals to national-security values with concrete operational details: layered evidence, live challenges, tamper-evident ledgers, and a clear Go/Modify/Stop verdict. The tone is confident and disciplined, matching the expectations of government and national-security stakeholders. It also connects the project to a broader narrative: two rivals proving they can manage frontier AI risk together without compromising their core interests.

## Target Audience

This initiative is aimed at:

- U.S. and Chinese government decision-makers
- National-security and arms-control agencies
- Appropriations committees and legislatures
- Datacenter operators and equipment vendors at declared sites
- The broader verification and international-security community

It is also relevant to **technical institutions**, independent red teams, and clean-room examination bodies that would partner in design and execution.

## Call to Action

Now is the time to move from concept to commitment. We call on both governments to endorse the bilateral instrument, complete the mandatory entry-condition phase by **September 2027**, appropriate and pre-fund the **$5 billion escrow**, and direct their verification, legal, and technical teams to engage the joint secretariat.

We invite participating operators and vendors to sign model access agreements, and we ask independent laboratories, red teams, and verification experts to join the live exercise program and help validate the systems before the clock starts.

## Risks and Mitigation Strategies

This project is high-risk by design, but every major risk has a deliberate mitigation:

- **Entry-condition delay** is addressed by an integrated readiness tracker and leadership escalation.
- **Vendor refusal** is contained by a forced-evidence ladder, clean-room examiners, and cross-trained inspectors.
- **Information barriers** are validated in blind challenges to prevent both over-filtering and under-filtering.
- **Double-key deadlock** is resolved through joint technical teams, advisory arbitration, and tightly scoped automatic suspension.
- **Political discontinuity** is met with continuity commitments, transition briefings, and a public KPI dashboard.
- **Fiscal delay** cannot become a quiet veto because escrow pre-funding or a KPI-visible delay trigger is built in.

Because verification cannot outrun politics, the design keeps both governments invested in the system's **credibility and reciprocity**.

## Metrics for Success

Success is measured by demonstrated operational performance, not just a verdict:

- False-negative rate no greater than **5%** in blind challenges at 95% confidence
- Event-recording latency under **5 minutes** locally
- Cross-national synchronization within **1 hour**
- Divergence reconciliation within **24 hours**
- Unresolved material discrepancy age no greater than **10 business days**
- Unverifiable equipment no more than **2 units per site** or 1% of covered changes
- Demonstrated reciprocal access parity
- Zero unresolved ledger divergence
- A joint written Go/Modify/Stop decision accepted by both co-chairs

These metrics ensure the verdict is **evidence-based, not diplomatic**.

## Stakeholder Benefits

Governments gain a credible, bilateral mechanism to reduce frontier AI risk without intrusive comprehensive governance. Operators and vendors gain predictable rules, fair domestically administered compensation, and protection of proprietary information through clean-room and filtered-evidence protocols.

Legislatures gain strict fiscal accountability, envelope-coded budgets, and transparent KPI dashboards. The verification community gains a live, high-stakes testbed for information barriers, tamper-evident ledgers, and joint inspection methods. Most importantly, the public gains a tangible demonstration that two great powers can manage existential technology responsibly.

## Ethical Considerations

The project is built on **ethical and legal discipline**: scope is limited to declared-equipment change verification; no unilateral findings or sanctions are permitted; all suspension and sanction decisions require double-key approval.

Information barriers protect workloads, customer data, model weights, source code, and trade secrets. Independent red teams and pre-registered thresholds prevent the appearance of rigged outcomes. The project explicitly avoids hidden-facility discovery and comprehensive AI governance, stating honestly what it can and cannot verify. This is **verification with consent, accountability, and mutual respect for sovereignty**.

## Collaboration Opportunities

We welcome collaboration with:

- National laboratories
- IAEA and CTBTO verification veterans
- Independent clean-room examiners
- Red-team and penetration-testing firms
- Academic verification researchers
- Track-II dialogue channels

Participating datacenter operators and equipment manufacturers can help shape model access agreements and inspection workflows. International organizations can contribute lessons from decades of safeguards and on-site inspection practice. Every partner will help turn this from a technical concept into a living, tested system.

## Long-term Vision

This project is the first step toward a sustained U.S.–China verification community. A successful Phase One can expand to additional declared sites, deepen the inspectorate, and create a reusable architecture for verifying other strategic technologies.

It can build a two-sided culture of **evidence, reciprocity, and conflict prevention**—transforming the frontier AI race from a blind competition into a managed contest. The broader vision is not just a 90-day test, but a durable bilateral institution that outlasts political cycles and makes the world safer by making verification normal between rivals.

# Project Plan

**Goal Statement:** Conduct a jointly governed 90-day Phase One operational test of the US-China Consortium that verifies material changes to covered frontier-relevant computing equipment at six matched declared datacenters (three per country), using layered evidence, a replicated tamper-evident ledger, bounded information barriers, and live blind challenges, and conclude with a defensible Go, Modify, or Stop decision based on reciprocal access and credible detection.

## SMART Criteria

- **Specific:** Achieve a jointly certified Go, Modify, or Stop decision for the Phase One operational test of the US-China Consortium, limited to verification of declared-equipment changes (arrivals, installations, removals, transfers, maintenance changes, and decommissioning) at six matched declared datacenters (three per country).
- **Measurable:** Success is measured by observed outcomes: false-negative rate no greater than 5% in blind challenges at 95% confidence; event-recording latency under 5 minutes locally; cross-national synchronization within 1 hour; divergence reconciliation within 24 hours; unresolved material discrepancy age no greater than 10 business days; unverifiable equipment no more than 2 units per site or 1% of covered changes; demonstrated reciprocal access parity; zero unresolved ledger divergence; and a joint written verdict.
- **Achievable:** The goal is achievable because both governments are stipulated to provide political backing, the full USD 5 billion budget is allocated across seven defined envelopes, candidate regions for matched sites are identified, the staffing model is derivable from workload formulas, and the pre-project assessment confirms the technical approach is buildable with no inherent contradictions, provided all entry conditions are treated as mandatory gates before the clock starts.
- **Relevant:** The mission directly addresses the shared national-security interest in preventing uncontrolled frontier AI while deliberately avoiding comprehensive AI governance, workload verification, model-weight inspection, capacity estimation, and hidden-facility discovery. This is a sovereign public-sector national-security program; business purpose, investors, customers, revenue, fundraising, sponsorship, profitability, and return on investment are not applicable. Value is measured by strategic necessity, public value, appropriations governance, and fiscal accountability.
- **Time-bound:** Project start is ASAP from 2026-Sep-04. The mandatory entry-condition phase is targeted for completion by 2027-Sep-04 (12 months). The 90-day Phase One clock starts only after both co-chairs jointly certify all entry conditions, with the final Go/Modify/Stop verdict due no later than 90 days after that certification.

## Dependencies

- Sign the bilateral instrument establishing equal national co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock and automatic-suspension procedures, and a binding bilingual glossary or interpretive annex.
- Enact domestic access authority in both countries compelling operator, manufacturer, maintenance-provider, and logistics-company participation and overriding conflicting private-law objections.
- Appropriate and pre-fund the equal 50/50 contributions into a jointly signatory escrow, or complete the milestone-tranche fallback with a KPI-visible contribution-release delay trigger.
- Select and jointly declare the matched set of six participating datacenter sites, including fallback sites and at least one harder-to-inspect stress site per country.
- Approve the mirrored inspectorate rosters after clearances and common training, with no single-person critical functions and full-time surge capacity.
- Secure operator and vendor participation through model vendor-access agreements, contractual site-eligibility conditions, and domestically administered compensation.
- Adopt the provisional confidential, attribute-based covered-equipment schedule with versioning, fast-track provisional listings, and sunset-review rules.
- Complete and certify the joint baseline physical inventory and cryptographic asset registry of covered equipment at all participating sites.
- Conclude the standing inspector visa and customs annex and pass the end-to-end travel-and-clearance drill.
- Validate the replicated tamper-evident ledger prototype, filtered-evidence information barriers, intake staging identity gates, exit-disposition workflows, and KPI thresholds through independent testing and provisional blind challenges before the clock starts.

## Resources Required

- USD 5 billion total budget (USD 2.5 billion per country) mapped to seven envelopes: 1.25B ledger/attestation/evidence/communications; 1B site preparation/operator compensation; 750M inspectorate; 750M secure facilities/cyber/counterintelligence; 500M independent testing/red teams; 250M legal implementation/audit; 500M contingency/surge.
- Replicated tamper-evident ledger infrastructure with local-first recording, bounded synchronization, continuous hash-commitment exchange, and independent national copies.
- Jointly controlled staging areas, bounded inspection zones, filtered workstations, and clean-room examination facilities at each participating site.
- Secure facilities in both countries with N+1 power redundancy, 99.9% uptime, hardware-separated evidence systems, and counterintelligence monitoring.
- Diagnostic and challenge-exercise equipment including serialization scanners, tamper-evident seals, power-analysis and attestation test rigs, and pre-cleared customs manifests.
- Cryptographic asset registry and baseline inventory tools for joint physical counts and reconciliation.
- Secure communications systems, translation support infrastructure, and versioned document-management systems for the confidential covered-equipment schedule.
- KPI dashboard and reporting infrastructure covering blind-challenge detection, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor refusals, incidents, funding timeliness, and audit exceptions.
- Contingency reserve (USD 500 million) including a dedicated disaster-response allocation of approximately USD 20 million for backup power, relocation, and emergency logistics.
- Pre-negotiated model vendor-access agreements and inspector-access annexes as legal instruments.
- Physical site infrastructure in the Northern Virginia/Ashburn corridor, the Beijing/Hebei cluster, and the Guizhou/Gui'an New Area hub, with exact facilities to be jointly selected and declared.

## Related Goals

- Extension of the Consortium into operational phases beyond Phase One at the same or expanded declared-site set.
- Broader US-China confidence-building measures for frontier AI risk reduction.
- Reuse of the layered-evidence and bounded-inspection verification architecture for other strategic technology agreements.
- Development of a long-term bilateral verification community of practice including inspector training, red-team methods, and information-barrier engineering.

## Tags

- US-China bilateral verification
- frontier AI
- treaty verification
- datacenter inspection
- tamper-evident ledger
- double-key governance
- Go/Modify/Stop
- national security
- hardware assurance
- red team exercises
- information barrier
- matched-site parity

## Risk Assessment and Mitigation Strategies


### Key Risks

- Entry-condition and appropriations delay preventing the Phase One clock from starting within the 12-month target.
- Vendor refusal and unverifiable-equipment contagion cascading from a dominant manufacturer or maintenance provider across multiple sites.
- Information-barrier over-filtering hiding substitution evidence or under-filtering exposing sovereign technology and sensitive data.
- Political discontinuity across leadership transitions reversing commitment to the bilateral mechanism.
- Missing or disputed baseline inventory invalidating all subsequent material-change verification.
- Cross-border inspector access, visa, and customs delays breaking the 24-hour physical-confirmation latency budget.
- Double-key deadlock allowing one co-chair to block findings, sanctions, or suspension indefinitely.
- Ledger divergence or evidence-integrity compromise triggering a Stop condition and undermining the final verdict.
- Delayed or asymmetric contribution release acting as a quiet fiscal veto without formally triggering the withholding-funding Stop condition.
- Staffing gaps, clearance delays, and single-person critical functions in the mirrored inspectorate.
- Matched-site parity asymmetry causing an asymmetric-access Stop condition before exercises begin.
- Covered-equipment schedule drift or revision deadlock allowing new frontier-relevant equipment to ship outside verification.
- Cost overrun, currency movement, or local inflation consuming the contingency envelope before independent testing is complete.
- Operator reluctance or deliberate obstruction causing access delays and inaccurate records.
- Unvalidated KPI thresholds producing a false Go or false Stop decision.

### Diverse Risks

- Operational risk: live challenge failures, site outages, access delays, and logistics disruptions.
- Systemic risk: a single dominant vendor refusal affecting all sites it serves and converting a local finding into a regime-level failure.
- Financial risk: funding timeliness, exchange-rate exposure, inflation, and envelope-level cost overruns.
- Legal and regulatory risk: domestic court challenges, export-control restrictions, visa or customs holds, and interpretive disputes.
- Security risk: cyber compromise, insider threat, counterintelligence failure, and evidence tampering.
- Political risk: leadership transition, public backlash, asymmetric commitment, and escalation deadlock.
- Technical risk: ledger divergence, attestation failure, filtered-evidence misconfiguration, and equipment-identity verification errors.

### Mitigation Plans

- Operate an integrated readiness tracker with named owners and certification fields for every entry condition, run all preparation workstreams in parallel, and escalate any open condition to heads of state or party leadership at the 2027-Sep-04 boundary.
- Negotiate model vendor-access agreements before the clock starts, bind operators to enforce vendor participation, pre-accredit independent clean-room examiners, cross-train inspectors for vendor-supervised diagnostics, and define per-site unverifiable-equipment thresholds that trigger escalation before the materiality corridor is breached.
- Publish and version the filter rules for filtered workstations before evidence flows, validate the barrier in blind challenges to confirm substitution indicators survive filtering, physically and logically separate national teams, and drill the joint cyber-incident isolation protocol twice before clock start.
- Negotiate continuity commitments including multi-year funding obligations, transition briefings, a joint public KPI dashboard, escrow-return clauses for withdrawal, and a track-II engagement channel to sustain technical relationships during political transitions.
- Conduct a joint baseline physical inventory and cryptographic asset registry as a mandatory entry condition, reconcile all discrepancies before clock start, and require a full recount of any site with more than 2% unexplained serialized discrepancy.
- Negotiate a standing inspector-access annex with 48-hour multiple-entry visas, pre-cleared manifests for diagnostic tools, privileges and immunities limited to official verification acts, and complete a full travel-and-clearance drill before Phase One.
- Pre-register deadlock machinery in the bilateral instrument: joint technical teams resolve routine discrepancies, deadlocked factual disputes go to a jointly selected advisory arbiter, deadlocks beyond 10 business days escalate to leadership, and automatic suspension is tightly scoped to unresolved material discrepancies at specific sites.
- Build the ledger local-first with continuous hash-commitment exchange, automatic divergence alerts, reconciliation drills using independent test events, independent penetration testing by two firms, and isolation procedures that preserve verification at unaffected sites.
- Require full escrow pre-funding before clock start, or use milestone-linked tranches with the identical 10-business-day delay trigger, quarterly USD reconciliation, envelope-coded drawdowns, and structured currency-conversion windows to manage FX exposure.
- Staff from a workload formula covering site count, 24/7 shifts, 1.5x leave/backup multiplier, separation of duties, and a permanent full-time surge cadre of at least 10% of baseline; begin security clearances immediately and second staff from existing national verification bodies if recruitment lags.
- Define a multi-attribute parity matrix covering equipment value, operational role, physical layout, security constraints, grid and climate reliability, and vendor coverage; benchmark reciprocal access hours and outcomes; include one stress site per country; and pre-qualify two fallback sites per country.
- Maintain a confidential attribute-based covered-equipment schedule with double-key specialist approval, fast-track provisional listing within 48-72 hours, sunset reviews linked to declared new generations, and a versioned changelog with pre-registered dispute criteria.
- Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan, use fixed-price contracts and structured conversion windows, and pre-qualify fallback sites to limit weather or grid disruption.
- Bind operator participation as a condition of site eligibility, provide compensation through the operator's own government, pre-agree inspection windows that minimize production interference, escalate deliberate obstruction to the co-chairs, and test low-disruption inspection techniques in exercises.
- Pre-register all KPI thresholds with a validation plan, use genuinely independent red teams with no advance knowledge of exercise timing, run all six mandatory unannounced challenge types, and require confidence intervals on false-negative and false-positive rates before any Go decision.

## Stakeholder Analysis


### Primary Stakeholders

- Equal National Co-Chairs representing the United States and China
- Joint Technical Teams and Adjudication Units
- Mirrored National Inspection, Technical, Legal, Cybersecurity, Counterintelligence, Translation, Audit, and Logistics Units
- Joint Legal Task Force and Bilingual Terminology Commission
- Independent Red Teams and Penetration Testing Firms
- Accredited Independent Clean-Room Examiners
- Joint Secretariat and Integrated Readiness Tracker Owners

### Secondary Stakeholders

- Heads of state and party leadership providing political backing and escalation authority
- Domestic legislatures and appropriations committees in both countries
- Participating datacenter operators in the United States and China
- Equipment manufacturers, maintenance providers, and logistics companies serving declared sites
- Export-control, customs, visa, and border authorities in both countries
- Local and regional permitting and grid authorities at selected site locations
- Regulatory and oversight bodies responsible for data protection, privacy, and national security information handling

### Engagement Strategies

- Co-chairs and heads of state receive monthly readiness-tracker reports, joint certification packages, escalation notifications for any open entry condition or deadlock, and a single joint Go/Modify/Stop recommendation with a shared findings narrative.
- Mirrored national units are engaged through a common training curriculum, separation-of-duties assignments, information-barrier discipline, and surge deployment procedures that preserve dual-national observation on every material event.
- The joint legal task force and terminology commission operate under fixed pre-clock deadlines, publishing the binding bilingual glossary, interpretive annex, domestic implementing-legislation notes, and model vendor-access agreements.
- Independent red teams are engaged with full operational independence, no advance knowledge of exercise timing, filtered reporting channels, and direct input to the KPI dashboard and verdict construction.
- Participating operators and vendors are engaged through contractual site-eligibility conditions, fair domestic compensation administered by their own government, pre-agreed inspection windows, and the forced-evidence ladder including clean-room examination before any unverifiable classification.
- Customs, visa, export-control, and permitting authorities receive pre-filed manifests, standing access requests, compliance reports, and drill results so that cross-border inspector access is tested before the clock starts.
- Domestic legislatures and oversight bodies receive quarterly appropriation and audit reports, public KPI dashboard summaries, and transparent fiscal accountability information while sensitive schedules and evidence remain protected.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Ratification or executive approval of the bilateral instrument establishing the Consortium
- Domestic access-authority legislation in both countries authorizing foreign inspector presence and operator and vendor compulsion
- Dual-use export and import licenses for diagnostic, attestation, and challenge-exercise equipment
- Customs pre-authorization and standing visa arrangements for credentialed inspectors
- Environmental, construction, and grid-connection permits for site preparation and secure-facility upgrades
- Security clearances and facility accreditations for personnel handling the confidential covered-equipment schedule and evidence systems

### Compliance Standards

- Agreed bilateral standards for layered evidence, equipment-identity confidence, and no-single-source decisiveness
- Information-barrier and filtered-evidence standards protecting workloads, customer data, model weights, source code, network topology, and security architecture
- National-security information-handling and classified-material standards in both countries
- Export-control and customs compliance standards for cross-border movement of verification equipment
- Data-protection and privacy laws applicable to evidence collected during inspections
- Occupational health, safety, and environmental standards for datacenter inspection and staging areas

### Regulatory Bodies

- U.S. Department of State and U.S. Congress
- Chinese Ministry of Foreign Affairs and National People's Congress or State Council
- U.S. Bureau of Industry and Security and Chinese export-control authorities
- U.S. Customs and Border Protection and General Administration of Customs of China
- Visa and immigration authorities in both countries
- Local permitting, grid, and environmental regulators at selected sites
- Independent audit bodies accountable to both governments for fiscal and compliance reporting

### Compliance Actions

- Draft, sign, and bring into force the bilateral instrument with double-key governance, deadlock machinery, and the binding bilingual glossary before the Phase One clock starts.
- Enact domestic access authority in both countries that overrides conflicting private-law objections and binds operators, manufacturers, maintenance providers, and logistics companies.
- Apply for all export, import, customs, visa, environmental, construction, and grid-connection authorizations in parallel and complete the travel-and-clearance drill before clock start.
- Implement a compliance plan for information barriers, filtered evidence, and data protection, validated by blind challenges and independent penetration testing.
- Conduct quarterly USD reconciliation of envelope drawdowns and independent audits of both governments' domestic compensation disbursements.
- Maintain the confidential versioned covered-equipment schedule under double-key specialist approval and record all revisions in a versioned changelog with pre-registered dispute criteria.

# Strategic Decisions

## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers address the program's foundational tensions: mutual distrust (double-key governance), evidence sufficiency vs speed (layered evidence), verification vs information protection (information barrier), detection latency vs silent windows, and aggregation into a defensible Go/Modify/Stop verdict. High levers cover political, fiscal, site-parity, and lifecycle enablers. No key strategic dimension appears missing; staffing and schedule versioning are correctly subordinate.

### Decision 1: Double-key deadlock and automatic suspension thresholds
**Lever ID:** `e6894c2d-dcce-4df7-b400-91e078d42320`

**The Core Decision:** Specifies how the equal co-chair structure resolves disagreement without allowing either country to overrule the other, including deadlock triggers, advisory arbitration, and narrowly scoped automatic suspension. Success metrics are bounded deadlock-resolution time and zero unilateral findings or sanctions. The lever determines whether the regime errs toward continued monitoring or protective suspension when evidence diverges.

**Why It Matters:** This lever defines how the equal co-chair structure behaves when the two governments disagree on a finding, a protocol change, or a sanction. Without a pre-agreed deadlock path, one side can exploit delay to shield an operator, but overly automatic suspension lets a single dispute halt verification everywhere. The chosen mechanism determines whether the Consortium errs toward continued monitoring or toward immediate protective suspension.

**Strategic Choices:**

1. Trigger automatic suspension only for sites with an unresolved material discrepancy, while allowing all other verification activity to continue under the existing protocol.
2. Empower joint technical teams to resolve routine discrepancies under pre-agreed evidentiary rules, reserving double-key authorization for material findings and sanctions.
3. Escalate deadlocked factual disputes to a jointly selected neutral technical arbiter with advisory findings, while keeping sanctions and suspension exclusively under double-key.

**Trade-Off / Risk:** Automatic suspension protects against unilateral shielding but creates a powerful delay tactic if one side manufactures discrepancies, so the trigger must be tightly scoped to materiality.

**Strategic Connections:**

**Synergy:** Pre-agreed deadlock and suspension mechanics give Phase One Verdict Construction and Materiality Definition reliable triggers: materiality definitions can activate suspension without unilateral overrule or procedural paralysis.

**Conflict:** Deadlock review consumes the same latency budget that Material-Event Latency Budget and Silent-Window Bounds reserve for rapid detection, so lengthy disputes can leave suspected substitutions unresolved within the agreed window.

**Justification:** *Critical*, Critical because it is the governance hub: equal co-chairs, double-key authorization, and pre-agreed suspension thresholds determine whether either side can shield an operator or paralyze verification. It controls the core no-unilateral-overrule trade-off and gives every materiality trigger an enforceable mechanism.

### Decision 2: Layered evidence weighting and operator-provided records
**Lever ID:** `f412506f-2b0d-455e-9aef-2c0d1c17e5b5`

**The Core Decision:** Establishes which evidence classes can verify equipment events, how much weight each carries, and when physical witnessing is mandatory versus when operator records may substitute under randomized sampling. Success metrics are false-negative and false-positive rates, evidence-class independence, and event confidence. The lever balances inspection speed against the expanded false-negative surface created by trusting operator-provided records.

**Why It Matters:** This lever determines how much evidentiary weight each layer receives and whether any combination can reach certainty without physical inspection. Requiring multiple independent classes for every event raises confidence but slows the process and increases operator burden, especially for routine maintenance changes. Allowing operator-provided records to substitute for witnessed observation improves speed but expands the false-negative surface.

**Strategic Choices:**

1. Mandate at least two independent evidence classes for every material event and require physical witnessing for all installations, removals, and decommissioning.
2. Predefine a hierarchy of evidence classes with explicit certainty thresholds, treating cryptographic attestation as supporting evidence that never satisfies verification alone.
3. Validate operator-provided records through random independent sampling for low-risk events while preserving full physical inspection for high-risk equipment changes.

**Trade-Off / Risk:** Random sampling cuts inspection load but can conceal a deliberately hidden substitution; the false-negative risk must be bounded by making sampled events carry automatic site-level consequences.

**Strategic Connections:**

**Synergy:** Intake Staging Jurisdiction and Pre-Installation Identity Gates supplies the first controlled identity evidence layer, and the Information Barrier Architecture for Filtered Evidence lets those layers be collected and reviewed without exposing protected data.

**Conflict:** Requiring multiple independent evidence classes and physical witnessing for every event lengthens response time, pressing against the Material-Event Latency Budget and Silent-Window Bounds established for rapid detection.

**Justification:** *Critical*, Critical because it defines the mission's evidentiary core and false-negative/false-positive risk. The balance between physical witnessing, operator records, and sampling sets inspection speed, confidence, and operator burden; every other verification control feeds or constrains this hierarchy.

### Decision 3: Information barrier architecture for filtered evidence
**Lever ID:** `d107ecf3-597a-4160-bd32-8f6dc4d2997f`

**The Core Decision:** Defines bounded inspection zones, filtered workstations, clean-room protocols, and dynamically designed evidence-collection patterns that protect workloads, model weights, and source code while preserving equipment-identity verification. Success is measured by IP and cybersecurity incident counts, challenge detection rates, and inspection sensitivity. The architecture must be validated in blind exercises because over-filtering can hide the contextual metadata needed to detect substitution.

**Why It Matters:** This lever decides how bounded inspection zones and evidence filtering protect workloads, model weights, and source code while still proving equipment identity. Tighter barriers reduce intelligence exposure but can also mask the very indicators inspectors need to detect substituted hardware. The architecture must balance inspection effectiveness against the counterintelligence requirement that neither side gains unilateral access to sensitive technology.

**Strategic Choices:**

1. Route all inspection evidence through filtered workstations that strip customer data and workload details before any inspector sees it, with cryptographic hashes preserving integrity.
2. Create clean-room examination protocols using accredited independent examiners for vendor-refusal cases, allowing physical inspection without exposing proprietary source code.
3. Design zone boundaries dynamically by event type, with pre-agreed access patterns for staging, maintenance, and exit flows that limit escort and evidence collection to the minimum necessary.

**Trade-Off / Risk:** Filtered workstations protect sensitive data but can strip the contextual metadata needed to detect substituted equipment, so barrier rules must be tested in blind challenges before deployment.

**Strategic Connections:**

**Synergy:** Clean-room examination and filtered workstations provide the accredited alternatives that Vendor Refusal Containment and Unverifiable-Equipment Contagion requires, converting refusals into reviewable evidence instead of automatic unverifiable outcomes.

**Conflict:** Tighter information barriers can strip the contextual metadata that Layered Evidence Weighting and Operator-Provided Records needs for confident attribution, so barrier strength must be traded off against evidence sufficiency for each event class.

**Justification:** *Critical*, Critical because it controls the defining tension between verification effectiveness and protection of workloads, model weights, and source code. Barrier strength determines whether the two governments will accept inspection and whether inspectors can detect substitution; it also enables vendor-refusal clean-room alternatives.

### Decision 4: Phase One verdict construction and materiality definition
**Lever ID:** `5ddeb99e-2c90-41d0-99aa-6cf2aaa65ced`

**The Core Decision:** This lever defines how hundreds of discrete findings aggregate into a single Go/Modify/Stop decision, fixing materiality as risk appetite: whether one unverifiable rack sinks the regime or is absorbed as residual risk. Its scope covers bright-line triggers, joint findings narratives, and a staged process that separates inspector-reported operational results from co-chair political determination. Success is an accepted verdict that withstands scrutiny over false negatives, discrepancy age, and unverifiable-equipment counts.

**Why It Matters:** The Go/Modify/Stop verdict must aggregate exercise results, access findings, and unresolved discrepancies into one decision, so the aggregation rule determines whether a single material failure blocks Go or whether strengths offset weaknesses. Bright-line triggers with a materiality corridor are predictable but brittle; holistic judgment preserves nuance but invites each government to read the same record differently. The plan names materiality as a Stop trigger without defining it, so the verdict construction process must fix its meaning before findings arrive.

**Strategic Choices:**

1. Pre-specify bright-line Stop triggers with a materiality corridor, so a single unverifiable unit below the corridor is logged but does not block Go while any unit above it forces Stop.
2. Require joint verdict construction where co-chairs must draft a shared findings narrative, letting disagreement surface in the narrative itself rather than in separate unilateral assessments.
3. Run a staged decision process that separates operational findings from political determination, with inspectors publishing technical results first and the co-chairs issuing the verdict only after a fixed deliberation window.

**Trade-Off / Risk:** The verdict aggregates hundreds of discrete findings, so the definition of materiality determines whether one unverifiable rack sinks the entire regime or is absorbed as a tolerable residual risk.

**Strategic Connections:**

**Synergy:** Amplifies Double-key deadlock and automatic suspension thresholds, because concrete materiality triggers give suspension rules objective referents; and enables Matched-site parity calibration and reciprocal access benchmarking, whose access findings supply the verdict with its core evidence.

**Conflict:** Conflicts with Authentic-text hierarchy and interpretive dispute pre-registration, since freezing materiality in the glossary forecloses corridor adjustments; and with Appropriations cadence and contribution-release governance, because milestone-linked tranches make the verdict an object of funding negotiation.

**Justification:** *Critical*, Critical because it fixes how hundreds of findings aggregate into the Go/Modify/Stop decision and defines materiality as risk appetite. Without pre-agreed aggregation and materiality, one unverifiable rack can either sink the regime or be hidden, making the verdict politically contestable.

### Decision 5: Material-event latency budget and silent-window bounds
**Lever ID:** `d71194d7-3f2a-4fd3-aa45-12d23d8a98c1`

**The Core Decision:** This lever fixes the maximum time a physical material change may go unrecorded, defining the silent window that red teams are paid to exploit and that exercises must beat. It allocates the budget across operator reporting, physical confirmation, and ledger recording, weighing near-real-time telemetry against production disruption. Success metrics are event-recording and synchronization latency, blind-challenge detection rates, and measured silent window; the chosen bounds are the regime's falsifiable honesty claim.

**Why It Matters:** Credible detection is ultimately a latency claim: how much time may pass between a physical material change and its appearance in the ledger. Requiring near-real-time visibility forces continuous telemetry or permanent inspection presence, which raises production disruption and cost, while tolerating long silent windows hands red teams a guaranteed concealment corridor. The chosen latency budget defines what the blind-challenge exercises must beat and therefore what Phase One can honestly certify.

**Strategic Choices:**

1. Adopt a layered latency budget where operators report material events within a fixed hours window, physical inspection confirms within a second window, and ledger recording completes within an agreed minutes threshold.
2. Require continuous automated attestation and tamper-evident telemetry at the equipment level so the ledger records changes in near real time without waiting for human reporting.
3. Accept discrete silent windows and compensate with randomized unannounced sweeps and probabilistic inspection, bounding the expected cumulative undetected exposure rather than eliminating it.

**Trade-Off / Risk:** A layered latency budget sounds credible, but red teams will design unreported-arrival challenges to exploit the gap between operator reporting and physical confirmation, so the real test is whether the interior windows are independently verifiable.

**Strategic Connections:**

**Synergy:** Operationalizes Bounded ledger synchronization and divergence-resolution latency, which must fit inside the budget's interior windows; and supplies Phase One verdict construction and materiality definition with the blind-challenge detection evidence that justifies a Go call.

**Conflict:** Conflicts with Vendor refusal containment and unverifiable-equipment contagion, because the forced-evidence ladder consumes the latency budget; and with Information barrier architecture for filtered evidence, since rigorous filtering and clean-room steps add delay to every recorded event.

**Justification:** *Critical*, Critical because credible detection is fundamentally a latency claim: the silent window defines what red teams exploit and what exercises must beat. It allocates time across reporting, physical confirmation, and ledger recording, and supplies the blind-challenge evidence needed for a defensible Go decision.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Entry-condition sequencing and the Phase One clock
**Lever ID:** `862ff239-f50e-49c6-b6b0-7db39fea4cbb`

**The Core Decision:** Defines the joint certification gates that must close before the 90-day Phase One clock starts, including appropriations, domestic authority, site selection, inspector approval, and vendor participation. Success is measured by reciprocal readiness parity and zero uncertified entry conditions at launch. The lever calibrates how much parallel preparation is safe without creating de facto obligations before legal authority exists.

**Why It Matters:** Pulling this lever fixes which mandatory conditions gate the 90-day test and determines whether pre-signature preparation counts toward readiness. Because appropriations, domestic access authority, and site selection are political acts, the critical path is reciprocity-sensitive, and one side’s delay can stall the entire mechanism. Compressing preparation risks starting the clock with unvalidated site choices, while stretching it burns political capital before any operational evidence exists.

**Strategic Choices:**

1. Run all preparation workstreams in parallel under an integrated readiness tracker, but withhold the formal Phase One clock until every entry condition is jointly certified by the co-chairs.
2. Sequence entry conditions so domestic access authority is the final gate, using provisional site selection and inspector training to compress the post-signature timeline.
3. Conduct a provisional shadow exercise after site selection but before formal entry conditions complete, labeling all findings non-binding and excluding them from the final decision.

**Trade-Off / Risk:** Parallel preparation compresses the timeline but risks treating provisional site selection as a sunk commitment, and a shadow exercise can create de facto obligations before legal authority exists.

**Strategic Connections:**

**Synergy:** This lever aligns the Phase One clock with Matched-Site Parity Calibration and Reciprocal Access Benchmarking and with Appropriations Cadence and Contribution-Release Governance, so both governments begin with equal readiness and committed funds.

**Conflict:** Entry-condition certification depends on double-key approval, so deadlock over any precondition stalls the Phase One clock; stretching preparation also starves the Material-Event Latency Budget and Silent-Window Bounds of operational data.

**Justification:** *High*, High because it gates the entire 90-day test and couples readiness with appropriations, site selection, and reciprocity, so one side's delay can stall the mechanism. However, once certified, its influence is absorbed by operational levers, making it less central than evidence/latency decisions.

### Decision 7: Mirrored staffing depth and surge capacity
**Lever ID:** `25e3fe73-a984-48b3-82da-4e0610d794cc`

**The Core Decision:** Sets the size and composition of the mirrored inspectorate from site count, shift coverage, leave backup, and exercise surge, with full-time employment and separation of duties. Success is measured by no single-person critical functions, coverage ratios, and surge deployment time within the fixed inspection envelope. Staffing depth doubles as a reciprocity signal, since asymmetrical capacity would undermine bilateral confidence.

**Why It Matters:** This lever sets the size and composition of the inspectorate, including how many full-time mirrored teams are stationed versus held in reserve. Because every critical function requires separation of duties and leave coverage, the staffing model drives both the labor budget and the speed of event response. Over-staffing consumes the fixed 750 million inspection envelope, while under-staffing creates single points of failure that can invalidate an entire verification event.

**Strategic Choices:**

1. Derive headcount from a workload formula covering site count, shift coverage, leave backup, and exercise surge, then allocate at least two full-time mirrored national inspectors to every material event.
2. Cross-train technical specialists across multiple sites to reduce total positions while preserving dual-national observation and fully separated duties for each function.
3. Maintain a permanently employed surge cadre of credentialed inspectors assigned to the Consortium, held in reserve and deployed from the contingency envelope for challenges and unexpected events.

**Trade-Off / Risk:** A surge pool keeps fixed costs low but reintroduces the part-time inspector risk the plan explicitly bans, so surge personnel must be full-time employees with identical training and clearance.

**Strategic Connections:**

**Synergy:** Deeper mirrored staffing enables the physical witnessing that Layered Evidence Weighting and Operator-Provided Records demands, while reserve surge capacity compresses response time within the Material-Event Latency Budget and Silent-Window Bounds.

**Conflict:** The staffing model front-loads salary obligations against a fixed inspection envelope, while Appropriations Cadence and Contribution-Release Governance controls when funds arrive; delayed release strands trained inspectors before any verification event occurs.

**Justification:** *Medium*, Medium because it is a derived resourcing model, not a strategic choice: headcount follows site count, shift coverage, and separation-of-duties rules. It enables evidence collection and latency performance, but its strategic reciprocity aspect is already governed by parity calibration and budget envelopes.

### Decision 8: Exit disposition binding and unresolved equipment handling
**Lever ID:** `f250670d-c4a1-4c94-9940-afd12364143b`

**The Core Decision:** This lever defines the only acceptable ways covered equipment may leave a declared site and mandates a ledger disposition for each departure. Its success metric is that no unresolved or ambiguous exit remains open, because weak exit rules would hollow out the entire verification boundary. It also sets the materiality threshold for suspension when a departure cannot be verified.

**Why It Matters:** This lever fixes what counts as a compliant departure and what happens when an exit cannot be verified. Strong disposition requirements, such as mandatory witnessed destruction, reduce the risk of re-entering equipment outside the monitored system but impose logistical and cost burdens on operators. Weak dispositions create an accountability gap that undermines the entire verification boundary.

**Strategic Choices:**

1. Require witnessed destruction or verified permanent disablement for all decommissioned frontier-relevant equipment, with both national teams observing and countersigning the ledger entry.
2. Permit documented release beyond the monitored system only after independent verification that the equipment has been irreversibly modified to non-frontier capability.
3. Treat any departure without an assigned disposition as a material discrepancy that immediately suspends the site, and require joint reauthorization before any further equipment movement.

**Trade-Off / Risk:** Mandatory witnessed destruction is the strongest control but may be operationally impossible for large installations, so the disposition rules must include a verified disablement pathway that is genuinely irreversible.

**Strategic Connections:**

**Synergy:** Exit disposition binding and unresolved equipment handling works with Intake staging jurisdiction and pre-installation identity gates to close the lifecycle loop, leaving no unaccounted corridor and feeding Phase One verdict construction with concrete unresolved counts.

**Conflict:** Strict exit dispositions can conflict with Matched-site parity calibration, because sites with bulky or hard-to-disable equipment cannot meet identical destruction requirements, making reciprocal obligations unequal. They also amplify Vendor refusal containment and unverifiable-equipment contagion when vendors resist destructive procedures.

**Justification:** *High*, High because it closes the equipment lifecycle and prevents unverified departures from hollowing out the verification boundary; unresolved exits feed materiality and the final verdict. It is important but more circumscribed than the evidence, latency, and governance levers, and depends on intake and barrier controls upstream.

### Decision 9: Technical schedule versioning against generational drift
**Lever ID:** `ea3d7637-2fb5-4dbf-9938-1f13ec03247f`

**The Core Decision:** This lever governs how the confidential covered-equipment schedule evolves as new frontier-relevant generations appear, using double-key specialist approval, attribute-based coverage, and pre-negotiated sunset reviews. Success is measured by minimal coverage gaps at each product transition and by disputes remaining resolvable through pre-registered criteria. The versioning process itself, not any single listing, is the durable safeguard against obsolescence.

**Why It Matters:** The covered-equipment schedule fixes what the regime is actually verifying, so every revision reopens the bilateral definitional bargain and every product generation tests whether the list has drifted out of relevance. A strictly versioned confidential schedule maintained by accountable specialists gives both sides a stable reference point, but it cannot anticipate the next architecture shift unless the versioning process is itself pre-negotiated. Sunset reviews and fast-track provisional listings keep the schedule current while making each update a potential flashpoint between the two governments.

**Strategic Choices:**

1. Maintain a confidential schedule updated only through double-key specialist approval, with automatic sunset review each time either side fields a new generation of frontier-relevant equipment.
2. Specify coverage through a framework of measurable attributes maintained confidentially by the accountable specialists, decoupling the schedule from named products so disputes center on technical criteria rather than commercial labels.
3. Re-baseline the schedule at fixed six-month intervals with a fast-track provisional listing that adds equipment immediately and lets challenges resolve afterward before the listing becomes permanent.

**Trade-Off / Risk:** A schedule that never changes becomes obsolete, but every revision reopens the bilateral definitional bargain, so the versioning process must be pre-negotiated before the first equipment change is ever verified.

**Strategic Connections:**

**Synergy:** Technical schedule versioning against generational drift amplifies Authentic-text hierarchy and interpretive dispute pre-registration, because pre-agreed definitional rules make each schedule revision resolvable without reopening the bilateral bargain. It enables Phase One verdict construction by keeping the tested equipment set current.

**Conflict:** Frequent schedule revisions conflict with Entry-condition sequencing and the Phase One clock, because each new listing can trigger renegotiation and delay the 90-day test. They also trade against Matched-site parity calibration by reshaping which sites appear comparable.

**Justification:** *Medium*, Medium because it keeps the covered-equipment schedule from drifting obsolete, but it is a future-proofing mechanism with limited impact inside the 90-day Phase One. Its definitional role overlaps with pre-registered interpretive rules, and revisions can reopen the bilateral bargain.

### Decision 10: Intake staging jurisdiction and pre-installation identity gates
**Lever ID:** `297d6a32-1f71-439a-9409-c5b4bdd2948c`

**The Core Decision:** This lever fixes where and under whose control equipment identity is established before installation, with options from jointly controlled in-site staging to operator-run attestation and off-site neutral warehouses. Its success metric is the fraction of covered arrivals entering through verified staging with zero bypass events. Because staging is the single physical chokepoint, its jurisdiction determines whether downstream evidence is corroboration or merely retrospective detection.

**Why It Matters:** Staging areas are the single physical point where equipment identity is verified before installation, so whoever controls them controls the credibility of the entire intake layer. Jointly controlled zones with mirrored inspectors raise integrity but disrupt commercial operations, while operator-run staging preserves operational flow and pushes the evidentiary burden onto downstream layers. A bypass — equipment moved directly onto the production floor — forces the regime to choose between halting operations and accepting an unverified installation.

**Strategic Choices:**

1. Designate jointly controlled staging zones inside every participating site with mirrored national inspectors co-witnessing identity checks, accepting higher operational friction in exchange for verifiable intake.
2. Accept operator-run staging with cryptographic attestation and recorded serialization, then depend on downstream layered evidence to catch whatever the staging layer misses.
3. Require all covered equipment to enter through off-site neutral staging warehouses shared across multiple sites, trading logistics cost for independence from individual operator control.

**Trade-Off / Risk:** Staging control concentrates the entire verification burden at one physical point, so any operator or vendor able to route equipment around staging can hollow out the protocol without ever triggering a visible violation.

**Strategic Connections:**

**Synergy:** Intake staging jurisdiction and pre-installation identity gates strengthens Layered evidence weighting and operator-provided records by producing the primary identity anchor that customs, serialization, and maintenance records corroborate. It also enables Bounded ledger synchronization with timestamped local entry events.

**Conflict:** Jointly controlled staging imposes queue delays and access restrictions that trade against Material-event latency budget and silent-window bounds, stretching the interval between physical arrival and verified recording. It also consumes scarce Mirrored staffing depth and surge capacity.

**Justification:** *High*, High because staging is the physical chokepoint where equipment identity is first established, and bypasses can hollow out downstream evidence. It strongly interacts with layered evidence, ledger recording, latency, and staffing; however, the plan's 'no single source decisive' principle keeps it one layer in a multi-evidence system.

### Decision 11: Bounded ledger synchronization and divergence-resolution latency
**Lever ID:** `3a203a96-ae4f-455a-af2f-3afe46dea9df`

**The Core Decision:** This lever sets the maximum acceptable delay between a local ledger event and cross-national synchronization, defines divergence alerts, and prescribes reconciliation drilling when copies disagree. Key success metrics are synchronization latency, ledger divergence duration, and reconciliation time. The chosen threshold is a direct policy trade-off: tighter bounds expose more sensitive local operations, while looser bounds risk silent divergence that can precipitate the Stop condition.

**Why It Matters:** Synchronization cadence directly trades the freshness of cross-national visibility against the volume of sensitive operational detail each side must expose. Tight bounds give both governments near-real-time confidence but force continuous disclosure of local events; loose bounds protect operational privacy while widening the window in which the two national ledger copies can silently diverge. Because unresolved divergence is already a designated Stop condition, the chosen latency threshold shapes whether reconciliation failures surface early or fester until the Phase One verdict.

**Strategic Choices:**

1. Set a bounded synchronization window with automatic divergence alerts when local records exceed the bound, and require immediate reconciliation drilling whenever alerts fire.
2. Configure each national copy to record events locally and synchronize in batched, scheduled intervals, accepting a longer reconciliation delay in exchange for limited cross-border operational visibility.
3. Add a neutral third-party record-keeping body that receives hash commitments from both sides continuously while withholding content, creating tamper-evident ordering without exposing sensitive transaction details.

**Trade-Off / Risk:** Divergence detection is only as meaningful as the synchronization window that bounds it, so setting latency thresholds low forces near-real-time disclosure of sensitive operations while high thresholds let silent divergence become entrenched before reconciliation.

**Strategic Connections:**

**Synergy:** Bounded ledger synchronization and divergence-resolution latency amplifies Material-event latency budget and silent-window bounds by giving the latency budget a concrete accounting mechanism for proving events were recorded within the window. It also supports Phase One verdict construction with divergence metrics.

**Conflict:** Tight synchronization bounds conflict with Information barrier architecture for filtered evidence, because continuous cross-border syncing forces disclosure of sensitive operational details the barrier is designed to withhold. Looser bounds ease that tension but widen silent-divergence risk.

**Justification:** *High*, High because ledger divergence is a designated Stop condition and synchronization bounds directly trade cross-border visibility against silent divergence. It operationalizes the latency budget and supplies reconciliation evidence for the verdict, but it is subordinate to the evidence and barrier architectures.

### Decision 12: Matched-site parity calibration and reciprocal access benchmarking
**Lever ID:** `09cc9aba-35af-4f6a-a37a-dfc60f533949`

**The Core Decision:** This lever defines how sites are paired and how reciprocal access is measured, using declared equipment value, operational role, total capacity, or deliberately dissimilar stress sites. Its success metric is demonstrated reciprocity in access hours and verification outcomes across matched pairs. Parity calibration determines whether the regime's Go/Stop criterion on asymmetric access is meaningful or a diplomatic artifact before exercises begin.

**Why It Matters:** The matched set of declared datacenters determines whether reciprocal access parity is a meaningful metric or a diplomatic fiction. Matching on equipment value and operational role makes inspection burdens comparable but may force a country to declare facilities it would rather keep out of scope, while matching on total processing capacity accepts asymmetry in site count for symmetry in what is monitored. An imbalanced match can trip the designated asymmetric-access Stop condition before live exercises even begin.

**Strategic Choices:**

1. Select matched site pairs by declared equipment value and operational role, then benchmark reciprocal access hours against those characteristics to make parity comparison concrete.
2. Allow each country to nominate its own most sensitive facilities, then negotiate the matched set to equal total processing capacity rather than equal site count, accepting asymmetry in numbers.
3. Include deliberately dissimilar and harder-to-inspect sites in the match to stress the regime early, forcing both sides to demonstrate they can verify under genuinely unequal conditions.

**Trade-Off / Risk:** Matching sites on paper cannot make their inspection difficulty equal, because facility size, layout, and vendor ecology differ, so parity metrics measure effort rather than true verification equivalence.

**Strategic Connections:**

**Synergy:** Matched-site parity calibration and reciprocal access benchmarking underpins Phase One verdict construction and materiality definition, because asymmetric access evidence is an explicit Stop trigger. It also gives Double-key deadlock and automatic suspension thresholds concrete parity metrics to evaluate.

**Conflict:** Negotiating matched pairs under strict parity can stall site selection, conflicting with Entry-condition sequencing and the Phase One clock, which cannot start until both countries approve participating sites. It also raises information-exposure risk, straining Information barrier architecture for filtered evidence.

**Justification:** *High*, High because it defines reciprocal access and the explicit asymmetric-access Stop trigger, so site pairing determines whether the Go/Modify/Stop criterion is meaningful. It is central to bilateral fairness and entry-condition approval, though its power depends on operational verification levers.

### Decision 13: Vendor refusal containment and unverifiable-equipment contagion
**Lever ID:** `e3541754-b092-4e67-bd56-c08a9eb26221`

**The Core Decision:** This lever decouples verification from vendor goodwill through a forced-evidence ladder running from vendor-supervised testing to clean-room examination to accredited independent examiners, backed by cross-trained inspectors and spare hardware. Scope covers pre-negotiated vendor-access agreements, operator obligations, and rules for classifying equipment unverifiable without letting one refusal cascade across sites. Success metrics: vendor-refusal outcomes, unverifiable-equipment counts, and time from refusal to resolved disposition.

**Why It Matters:** Binding manufacturers, maintenance providers, and logistics companies transfers part of the verification burden to third parties, but a single dominant vendor refusing cooperation can cascade across every site it serves. The escalation ladder from vendor-supervised testing to clean-room procedures gives inspectors alternatives, yet each rung weakens evidentiary independence and consumes the 90-day clock. When refusals span multiple sites, a local equipment finding becomes a systemic regime failure that the materiality rules may have to treat as Stop.

**Strategic Choices:**

1. Negotiate model vendor-access agreements before Phase One begins, with operators contractually required to provide escorts, evidence, and clean-room access as a condition of site eligibility.
2. Build a forced-evidence ladder that shifts from vendor cooperation to independent examination, and classify equipment as unverifiable only after the full ladder fails at a given site.
3. Cross-train inspectors to perform vendor-supervised diagnostics themselves and stock spare replacement hardware, reducing dependence on any single vendor's technicians and making refusal less consequential.

**Trade-Off / Risk:** A single dominant vendor refusing cooperation at multiple sites converts an equipment-level finding into a systemic failure, so the regime needs a pre-negotiated remedy that does not depend on that vendor's goodwill.

**Strategic Connections:**

**Synergy:** Amplifies Layered evidence weighting and operator-provided records, since the fallback ladder depends on non-vendor evidence layers; and feeds Phase One verdict construction and materiality definition by bounding the unverifiable-equipment count that materiality rules must absorb.

**Conflict:** Trades off against Material-event latency budget and silent-window bounds, because climbing the evidence ladder consumes precious verification windows; and competes with Mirrored staffing depth and surge capacity, since cross-trained inspector teams are drawn from limited surge resources.

**Justification:** *High*, High because a dominant vendor's refusal can cascade into systemic unverifiability and Stop. The forced-evidence ladder, pre-negotiated access agreements, and cross-trained inspectors provide essential fallbacks, but they operate within the latency budget and evidence hierarchy rather than defining them.

### Decision 14: Authentic-text hierarchy and interpretive dispute pre-registration
**Lever ID:** `b255f6e8-e99b-41b5-af82-27b542e6433f`

**The Core Decision:** This lever pre-commits both governments to a binding bilingual glossary and pre-registered interpretive readings so Phase One disputes resolve by reference to fixed texts rather than negotiation. Forcing the contested terms — material, removal, frontier-relevant — to be defined before the clock starts converts future adjudication into a lookup operation. Success metrics are interpretive disputes resolved without access denial and absence of deferred deadlocks; cost is front-loading linguistic bargaining into entry conditions.

**Why It Matters:** A bilingual instrument with two equally authentic texts invites each side to read borderline provisions in its own favor, and an unresolved interpretive dispute becomes a ready-made access-denial tool for operators and vendors. Binding the glossary before the clock starts freezes the meaning of terms like material, removal, and frontier-relevant for Phase One, so later disagreements parse facts rather than words. The trade-off is that negotiating the glossary consumes political capital before the 90-day clock begins, and any term left unresolved becomes a deferred deadlock.

**Strategic Choices:**

1. Establish a joint terminology commission of mirrored technical linguists and engineers to publish a binding bilingual glossary before the clock starts, with worked examples of covered and uncovered events.
2. Designate the English text as the authoritative reference for Phase One but require certified technical translations of every evidence package, accepting a predictable single reference in exchange for acknowledged linguistic asymmetry.
3. Pre-register interpretive positions in a double-keyed annex where each government files its reading of every contested term at signing, so later disagreements resolve by reference to the annex instead of by negotiation.

**Trade-Off / Risk:** A binding glossary reduces interpretive drift, but the two governments wrote the instrument in both languages precisely to avoid conceding authenticity, so the pre-clock negotiation of every contested term may deadlock before operations begin.

**Strategic Connections:**

**Synergy:** Enables Entry-condition sequencing and the Phase One clock, because a settled glossary removes deferred deadlocks that could stall the clock; and sharpens Double-key deadlock and automatic suspension thresholds by making trigger terms unambiguous.

**Conflict:** Constrains Technical schedule versioning against generational drift, since frozen definitions may not map to next-generation equipment; and pressures Phase One verdict construction and materiality definition, because pre-registered readings lock the materiality corridor before operational experience exists.

**Justification:** *High*, High because unresolved bilingual interpretations can become ready-made access-denial tools and deferred deadlocks. Pre-registering terms converts future disputes into lookup operations and supports entry-condition certification and double-key triggers; however, it is a one-time legal precommitment rather than a daily operational control.

### Decision 15: Appropriations cadence and contribution-release governance
**Lever ID:** `16810033-6cab-49b4-bd6e-a773729bb0a4`

**The Core Decision:** This lever governs when each government's 2.5-billion-dollar contribution enters the Consortium and how funds release against envelopes, so a delayed disbursement cannot act as a quiet veto that never triggers the withholding stop condition. Scope covers escrow pre-funding, milestone-linked tranches, standby bridges, and quarterly reconciliation. Success metrics are funding timeliness, reciprocal release parity, and zero fiscal suspensions; the key choice is whether treasuries or the KPI dashboard hold fiscal leverage.

**Why It Matters:** Because each government administers its own operator and vendor compensation, the Consortium's operational tempo is directly coupled to the other side's appropriations cycle, and a delayed disbursement acts as a quiet veto that never formally triggers the withholding stop condition. Fully pre-funding the escrow removes that pressure point but demands that both legislatures appropriate billions before seeing any exercise results. Milestone-linked tranches preserve fiscal leverage but make the KPI dashboard itself the object of negotiation.

**Strategic Choices:**

1. Require both governments to deposit their full 2.5-billion-dollar contributions into a jointly signatory escrow before the clock starts, with quarterly reconciliation and release against envelope-approved expenditures.
2. Tie drawdown tranches to verified operational milestones, releasing each successive tranche only after the KPI dashboard shows the preceding stage met the agreed thresholds.
3. Establish a mutual standby commitment in the bilateral instrument authorizing either government to bridge a payment delinquency for a bounded period, with the delinquency itself recorded as a suspension trigger.

**Trade-Off / Risk:** Milestone-linked tranches keep either side from paying for a failing program, but defining milestones before the clock starts invites gaming of the KPI definitions, and a standby bridge creates a lending relationship neither treasury will accept.

**Strategic Connections:**

**Synergy:** Enables Mirrored staffing depth and surge capacity, because contingency and surge envelopes become usable only when funds release reliably; and underpins Matched-site parity calibration and reciprocal access benchmarking, since asymmetric funding collapses reciprocal deployment.

**Conflict:** Trades off against Phase One verdict construction and materiality definition, because milestone-linked tranches turn the KPI dashboard into a funding-negotiation object; and risks Double-key deadlock and automatic suspension thresholds, since fiscal withholding can trigger suspension machinery meant for verification failures.

**Justification:** *High*, High because delayed contribution release can act as a quiet veto and a funding-based suspension trigger, directly coupling fiscal cadence to operational tempo and reciprocal deployment. It underpins staffing and site access, but its effects are channeled through governance and verification levers.


# Scenarios

# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** High sovereign ambition: a $5B US-China bilateral national-security verification mechanism for frontier AI datacenter equipment, but deliberately narrow in scope—only declared-equipment change verification at matched sites. Bilateral and international, not commercial.

**Risk and Novelty:** Groundbreaking and high-risk: no mutual trust or legal symmetry, dual-use technology exposure concerns, and a novel two-sovereign verification architecture. Requires layered evidence, live red-team exercises, and counterintelligence protections while avoiding comprehensive AI governance.

**Complexity and Constraints:** Very high complexity: mirrored national teams, double-key governance, mandatory entry conditions before the 90-day clock, strict budget envelopes, bounded evidence collection, vendor-refusal ladders, automatic suspension procedures, and specified KPI thresholds. Constrained by sovereignty sensitivities and information barriers.

**Domain and Tone:** Sovereign public-sector national-security program; formal, technical, and cautious. Explicitly rejects business framing and generic project phases, emphasizing fiscal accountability, reciprocal access, and credible detection.

**Holistic Profile:** A tightly scoped but operationally demanding bilateral verification experiment that seeks maximum credibility within acceptable intrusion: joint governance, layered physical/digital evidence, mirrored staffing, bounded information barriers, and a disciplined Go/Modify/Stop test.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder's Balanced Path
**Strategic Logic:** This path bets on joint ownership and predictable process. Routine discrepancies are handled by joint technical teams, evidence is weighted by a transparent hierarchy, vendor refusal is managed through clean-room examination, co-chairs draft a shared findings narrative, and a layered latency budget keeps reporting and inspection windows explicit. It is designed to be the most likely to complete Phase One with a Go verdict because it balances rigor with acceptability.

**Fit Score:** 9/10

**Why This Path Was Chosen:** Strongest alignment: joint technical teams preserve double-key equality; evidence hierarchy enforces 'no single source decisive'; clean-room protocols match vendor-refusal provisions; shared findings narrative fits co-chair governance; and layered latency budget operationalizes bounded ledger synchronization—rigorous yet acceptable.

**Key Strategic Decisions:**

- **Double-key deadlock and automatic suspension thresholds:** Empower joint technical teams to resolve routine discrepancies under pre-agreed evidentiary rules, reserving double-key authorization for material findings and sanctions.
- **Layered evidence weighting and operator-provided records:** Predefine a hierarchy of evidence classes with explicit certainty thresholds, treating cryptographic attestation as supporting evidence that never satisfies verification alone.
- **Information barrier architecture for filtered evidence:** Create clean-room examination protocols using accredited independent examiners for vendor-refusal cases, allowing physical inspection without exposing proprietary source code.
- **Phase One verdict construction and materiality definition:** Require joint verdict construction where co-chairs must draft a shared findings narrative, letting disagreement surface in the narrative itself rather than in separate unilateral assessments.
- **Material-event latency budget and silent-window bounds:** Adopt a layered latency budget where operators report material events within a fixed hours window, physical inspection confirms within a second window, and ledger recording completes within an agreed minutes threshold.

**The Decisive Factors:**

**The Builder's Balanced Path** is the best fit because it matches the Consortium's ambition while respecting its sovereignty constraints. Its joint technical teams and shared findings narrative operationalize the plan's double-key, no-overrule governance. Its evidence hierarchy and clean-room examination directly implement the 'no single source is decisive' rule and vendor-refusal ladder without forcing continuous deep intrusion. The layered latency budget converts 'bounded synchronization' and KPI latency thresholds into an explicit, testable construct. Compared with **Pioneer's Gambit**, it avoids mandatory physical witnessing and near-real-time telemetry that would collide with bounded inspection zones and expose sensitive technology. Compared with **Consolidator's Controlled Path**, it rejects risk-tiered sampling and discrete silent windows that would weaken blind-challenge credibility and 'immediate local event recording.' The path is rigorous enough to justify a credible Go/Modify/Stop decision and politically feasible enough for equal sovereign partners.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** This path maximizes verification ambition and technological tempo. It uses a neutral arbiter for factual deadlocks, mandates two independent evidence classes with physical witnessing for material events, designs dynamic inspection zones, publishes operational findings before the political verdict, and seeks near-real-time ledger updates through continuous equipment attestation. The trade-off is higher cost, deeper intrusion, and the risk that the most advanced measures will encounter sovereignty or technical resistance.

**Fit Score:** 6/10

**Assessment of this Path:** Captures the plan's demand for layered evidence and rigorous testing, but its near-real-time continuous attestation, mandatory physical witnessing for all events, and neutral-arbiter element exceed the plan's bounded information-barrier and joint double-key design, risking sovereignty resistance.

**Key Strategic Decisions:**

- **Double-key deadlock and automatic suspension thresholds:** Escalate deadlocked factual disputes to a jointly selected neutral technical arbiter with advisory findings, while keeping sanctions and suspension exclusively under double-key.
- **Layered evidence weighting and operator-provided records:** Mandate at least two independent evidence classes for every material event and require physical witnessing for all installations, removals, and decommissioning.
- **Information barrier architecture for filtered evidence:** Design zone boundaries dynamically by event type, with pre-agreed access patterns for staging, maintenance, and exit flows that limit escort and evidence collection to the minimum necessary.
- **Phase One verdict construction and materiality definition:** Run a staged decision process that separates operational findings from political determination, with inspectors publishing technical results first and the co-chairs issuing the verdict only after a fixed deliberation window.
- **Material-event latency budget and silent-window bounds:** Require continuous automated attestation and tamper-evident telemetry at the equipment level so the ledger records changes in near real time without waiting for human reporting.

### The Consolidator's Controlled Path
**Strategic Logic:** This path minimizes cost, intrusion, and political exposure. It relies on tightly scoped automatic suspension, risk-tiered sampling of operator records, filtered workstations to protect sensitive data, bright-line materiality thresholds for Stop, and bounded silent windows with randomized unannounced sweeps. It accepts a modest, quantified residual detection risk to preserve a stable and fundable bilateral arrangement.

**Fit Score:** 5/10

**Assessment of this Path:** Minimizes cost and intrusion, but reliance on risk-tiered sampling, discrete silent windows, and bright-line corridors relaxes the plan's credible-detection, immediate local event recording, and blind-challenge standards—too accepting of residual detection risk for a national-security verification regime.

**Key Strategic Decisions:**

- **Double-key deadlock and automatic suspension thresholds:** Trigger automatic suspension only for sites with an unresolved material discrepancy, while allowing all other verification activity to continue under the existing protocol.
- **Layered evidence weighting and operator-provided records:** Validate operator-provided records through random independent sampling for low-risk events while preserving full physical inspection for high-risk equipment changes.
- **Information barrier architecture for filtered evidence:** Route all inspection evidence through filtered workstations that strip customer data and workload details before any inspector sees it, with cryptographic hashes preserving integrity.
- **Phase One verdict construction and materiality definition:** Pre-specify bright-line Stop triggers with a materiality corridor, so a single unverifiable unit below the corridor is logged but does not block Go while any unit above it forces Stop.
- **Material-event latency budget and silent-window bounds:** Accept discrete silent windows and compensate with randomized unannounced sweeps and probabilistic inspection, bounding the expected cumulative undetected exposure rather than eliminating it.


# Assumptions

# Purpose

**Purpose:** business

**Purpose Detailed:** Governmental national-security program for verifying material changes to frontier-relevant computing equipment in declared datacenters, with bilateral governance, fiscal accountability, and operational testing.

**Topic:** US-China bilateral verification of frontier AI computing equipment at declared datacenters

# Domain

**Primary domain:** Treaty Verification

**Secondary domains:** Cryptographic Attestation, International Law, Hardware Assurance

**Rationale:** Treaty Verification owns the mission: confirming material equipment changes under a bilateral agreement, with exercises and adjudication serving it. Hardware Assurance, Information Barrier Engineering, and Red Teaming are important methods but subordinate to the verification outcome.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Treaty Verification | 5 | 5 | outcome | Core mission is verifying equipment changes under a bilateral monitoring agreement. |
| Hardware Assurance | 5 | 5 | method | Confirms identity, provenance, and alteration of computing hardware at participating sites. |
| Information Barrier Engineering | 5 | 5 | method | Filtered evidence and bounded zones require engineered barriers protecting sensitive data while proving attributes. |
| Red Teaming | 4 | 5 | method | Executes blind challenge exercises to validate detection and reciprocal access. |
| Cryptographic Attestation | 4 | 4 | method | Layered identity verification uses validated cryptographic attestation and a tamper-evident ledger. |
| Counterintelligence | 4 | 4 | constraint | Protects sensitive technology and enforces information barriers between national teams. |
| Distributed Systems Engineering | 4 | 4 | method | Replicated tamper-evident ledger with bounded synchronization is core project infrastructure. |
| Data Center Operations | 4 | 4 | stakeholder | Operators and maintenance vendors are essential participants whose facilities are the inspection targets. |
| International Law | 4 | 3 | constraint | Bilateral instrument and domestic access authority are mandatory entry conditions. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is inherently physical: it requires on-site verification of computing equipment at declared datacenters, physical inspection of material arrivals and removals, installation and decommissioning monitoring, controlled staging areas, witnessed movement, physical security and counterintelligence at real facilities, and deployment of inspectors, technical personnel, red teams, and logistics staff to those locations. It also presumes travel, physical preparation of sites, operator and vendor participation at physical facilities, and real-world challenge exercises involving equipment substitutions and staged events. None of this can be accomplished purely digitally; the entire mission depends on physical presence, tamper-evident physical evidence, and real-world operational testing.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Jointly selected declared datacenter sites in both the United States and China, matched for comparable verification burden
- Controlled staging areas for pre-installation equipment identity verification
- Bounded inspection zones supporting filtered evidence collection and clean-room examination
- Physical security, cybersecurity, and counterintelligence infrastructure adequate for a sovereign national-security program
- Controlled access for mirrored national inspection teams, technical specialists, escorts, and approved vendors
- Reliable power, cooling, network capacity, and logistics support for live challenge exercises without disrupting active computational work
- Space for witnessed movement, maintenance monitoring, and exit/disposition verification

## Location 1
United States

Northern Virginia / Ashburn, Loudoun County, Virginia

Ashburn, Virginia, USA — major declared datacenter corridor; exact facility to be jointly selected

**Rationale**: Northern Virginia is the largest datacenter concentration in the United States and likely to host frontier-relevant computing equipment. Its mature infrastructure, multiple operators, and logistics access support staging areas, bounded inspection zones, and repeated live exercises.

## Location 2
China

Beijing/Hebei cluster

Langfang / Beijing-area declared datacenter facilities, Hebei/Beijing, China — exact facilities to be jointly selected

**Rationale**: The Beijing/Hebei region hosts major Chinese frontier AI and high-performance computing facilities, making it a likely area for declared sites. It provides the high-density computing infrastructure and operator presence needed for matched-pair verification with U.S. sites.

## Location 3
China

Guizhou Province

Gui'an New Area / Guizhou national datacenter hub, China — candidate for an additional matched or stress-test site

**Rationale**: Guizhou is one of China's principal national datacenter hubs and could serve as a second or stress-test site. Its geographic separation and different operating environment help calibrate parity across facility types and test the Consortium's ability to verify under unequal conditions.

## Location Summary
The Consortium cannot operate digitally: it requires physical datacenter sites in both countries for on-site verification, staging, maintenance monitoring, and live challenge exercises. The suggested locations—Northern Virginia, the Beijing/Hebei cluster, and Guizhou—represent high-concentration datacenter regions in both countries and offer the infrastructure, operator ecosystems, and alternative facility profiles needed for matched-site calibration and credible Phase One testing. Final sites must be jointly selected and declared by the two governments.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** The program budget is explicitly denominated in USD (USD 5 billion total, USD 2.5 billion per country), and USD is the practical standard for consolidated budgeting, reporting, and cross-border fiscal reconciliation.
- **CNY:** China-side operator compensation, vendor payments, facility preparation, and local logistics will be administered by the Chinese government and incurred in China, so CNY is needed for domestic disbursements and local cost tracking.

**Primary currency:** USD

**Currency strategy:** Use USD as the single consolidated budgeting, reporting, and appropriation-tracking currency for the full USD 5 billion program, while permitting each government to disburse local operating payments in its own domestic currency (USD for U.S. sites and CNY for China sites) against its USD-denominated contribution. Maintain joint escrow and quarterly reconciliation in USD, with exchange-rate risk managed through structured conversion windows and periodic revaluation so that budget-envelope tracking remains stable regardless of currency movements.

# Identify Risks


## Risk 1 - Governance & Political
The Consortium's equal-national co-chair and double-key structure has no casting vote and prohibits one country overruling the other. The plan does not specify a maximum deadlock duration or a pre-agreed escalation path for disputes over materiality, protocol changes, sanctions, or suspension. A single co-chair can therefore block or delay a decision indefinitely, and an unresolved disagreement can trigger the very suspension machinery meant for verification failures.

**Impact:** Deadlocked material findings could age beyond the agreed discrepancy-resolution window, forcing automatic suspension of one or more sites; Phase One could fail to produce a Go/Modify/Stop verdict within the 90-day operational window, consuming the $250M legal implementation and $500M contingency envelopes with no operational result. A politically motivated deadlock could stop the entire $5B program.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-register a bounded deadlock procedure before the clock starts: route routine discrepancies to joint technical teams, refer factual disputes to a jointly selected advisory arbiter, and require any deadlock persisting beyond a fixed deliberation window to be recorded on the KPI dashboard and escalated to automatic suspension only for material discrepancies. Make deadlock duration a KPI with a pre-agreed threshold.

## Risk 2 - Regulatory & Permitting
The Phase One clock does not start until both governments have signed the bilateral instrument, appropriated contributions, enacted domestic access authority, selected sites, approved inspectors, secured vendor/operator participation, and adopted the covered-equipment schedule. These are political acts that can be delayed or held hostage to unrelated diplomatic disputes, and the plan provides no outer limit or fallback if conditions remain uncertified.

**Impact:** Preparatory workstreams can continue in parallel, but the operational test could be delayed 6–24 months or indefinitely; trained inspectors and technical teams may be idled, consuming the $750M inspectorate envelope without producing verification evidence. The delay also increases the risk that political leadership changes before Phase One begins.

**Likelihood:** High

**Severity:** High

**Action:** Create an integrated readiness tracker with reciprocal certification by the co-chairs, run all preparatory workstreams in parallel, and use provisional shadow exercises after site selection to keep the mechanism warm. Include a mutual commitment to complete entry conditions within an agreed maximum period, with delays visible as a KPI and escalation to heads of state or party leadership if exceeded.

## Risk 3 - Regulatory & Permitting
Even with political backing, domestic courts, data-protection regulators, local governments, or private operators may challenge the authority of foreign or international inspectors to access facilities, collect evidence, or inspect equipment. The plan requires domestic access authority but does not specify how it interacts with existing privacy, export-control, customs, and national-security laws on either side.

**Impact:** An injunction or regulatory ruling could block inspectors at one site for weeks or months, creating an asymmetric-access Stop condition. Litigation and legislative fixes could add $10–50M in legal costs and delay the Phase One clock by 3–6 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Before clock start, enact a clear domestic legal framework that overrides conflicting private-law objections, defines inspector privileges and limits, and binds operators and vendors contractually. Maintain a joint legal task force to resolve challenges quickly, and include rapid dispute-resolution clauses in the bilateral instrument.

## Risk 4 - Financial
Each government contributes USD 2.5B, with domestic operator and vendor compensation paid by its own government. A delay in appropriations, a treasury dispute over exchange rates, or a quiet decision to slow disbursement can starve the program without formally triggering the withholding-funding Stop condition. The budget is fixed in USD but China-side costs are denominated in CNY, creating exchange-rate and inflation exposure.

**Impact:** A 6–12 month funding delay would idle the inspectorate, stop site preparation, and break the reciprocity parity essential to the Go/Modify/Stop test. A 5% currency or local-inflation shock could add $125–250M in unplanned costs, consuming the $500M contingency envelope before any independent testing occurs.

**Likelihood:** Medium

**Severity:** High

**Action:** Require both governments to pre-fund their full contributions into a jointly signatory escrow before the clock starts, with quarterly USD reconciliation and envelope-approved drawdowns. Use structured currency conversion windows and periodic revaluation to manage CNY/USD exposure, and make any contribution-release delay beyond a pre-agreed window an automatic KPI-visible suspension trigger.

## Risk 5 - Supply Chain
The verification scheme depends on manufacturers, maintenance providers, and logistics companies to provide access, escorts, evidence, and clean-room support. A dominant vendor serving datacenters in both countries could refuse to cooperate, citing proprietary technology, export controls, or national law. Since the forced-evidence ladder can consume time and may produce weaker evidence, a single vendor's refusal can affect multiple sites simultaneously.

**Impact:** Equipment served by the refusing vendor could become unverifiable; if material, the site fails Phase One and the overall verdict moves to Stop. Escalation through the evidence ladder could consume 2–6 weeks per refusal and draw down the $500M contingency and $750M inspectorate envelopes, while unresolved unverifiable-equipment counts mount.

**Likelihood:** Medium

**Severity:** High

**Action:** Negotiate model vendor-access agreements before the clock starts, bind operators to enforce vendor participation, and pre-accredit independent clean-room examiners. Cross-train inspectors to perform vendor-supervised diagnostics themselves, stock spare replacement hardware, and define a per-site unverifiable-equipment threshold that triggers automatic escalation before the materiality corridor is breached.

## Risk 6 - Security & Technical
The information-barrier architecture must protect model weights, customer data, source code, network topology, and unrelated infrastructure while still giving inspectors enough contextual evidence to verify equipment identity. Over-filtering can strip serial numbers, firmware telemetry, or configuration metadata needed to detect substitution; under-filtering can expose sensitive technology and cause either government to withdraw cooperation.

**Impact:** If the barrier hides evidence, blind-challenge detection rates fall and the regime could certify a false negative. If it leaks sensitive data, a single IP or cybersecurity incident could terminate the program and trigger national-security investigations; reputational and intelligence damage is difficult to quantify but could exceed the $5B program budget in diplomatic cost.

**Likelihood:** High

**Severity:** High

**Action:** Design bounded inspection zones and filtered workstations by event type, with cryptographic hashes to preserve evidence integrity; test the barrier in blind exercises before deployment. Use clean-room protocols and accredited independent examiners for the most sensitive inspections, and implement a joint cyber-incident response plan that can isolate and contain a leak without halting all verification.

## Risk 7 - Operational & Technical
Credible detection depends on the maximum time between a physical material change and its verified appearance in the ledger. The layered latency budget creates interior windows for operator reporting, physical confirmation, and ledger recording that red teams will try to exploit. If any interior window is too long or not independently verifiable, an unreported arrival or substitution can go undetected for hours or days.

**Impact:** A missed latency target would fail the KPI dashboard and could force a Modify verdict even if other elements succeed. If thresholds are set too loose, an event could remain silent for 24–72 hours, giving red teams a guaranteed concealment corridor and undermining the Go decision.

**Likelihood:** Medium

**Severity:** High

**Action:** Predefine and validate threshold values through simulation and exercises, such as operator reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour. Use tamper-evident local recording at the point of observation, unannounced random sweeps to shrink expected silent windows, and independent monitoring of interior windows to ensure the layered budget is not a paper construct.

## Risk 8 - Technical
The replicated, tamper-evident ledger with national copies must record events locally and synchronize within a bounded window. Network outages, software defects, or malicious tampering can cause the two national copies to diverge. Because unresolved divergence is a designated Stop condition, the system risks either false alarms from minor synchronization lags or missed divergence that allows evidence to be silently altered or withheld.

**Impact:** A divergence that cannot be reconciled within the agreed window would trigger a Stop recommendation. If divergence detection is too slow, both governments may rely on conflicting records during a security crisis. Reconciliation exercises could consume 1–4 weeks of the Phase One clock and require technical fixes costing $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Set a bounded synchronization window with automatic divergence alerts, maintain local-first recording so no event is lost during connectivity loss, and run regular reconciliation drills against independently generated test events. Use hash commitments exchanged continuously between the two national copies to prove tamper-evidence without exposing sensitive content.

## Risk 9 - Operational & Political
The matched site set must have comparable verification burden, but Northern Virginia, the Beijing/Hebei cluster, and Guizhou differ in facility size, layout, vendor ecology, security rules, and operating culture. Paper matching by declared equipment value or total capacity may not make inspection difficulty equal. If one country's sites are systematically easier or harder to inspect, access-parity metrics become meaningless and the asymmetric-access Stop trigger can be tripped before exercises begin.

**Impact:** Negotiations over the matched set could stall entry-condition certification for months. If the final set is asymmetric, one side could claim the other receives less intrusive inspections, causing political collapse and a Stop verdict. Red-team results would be incomparable across sites, undermining the 90-day test.

**Likelihood:** High

**Severity:** High

**Action:** Jointly define parity in advance using multiple attributes, including equipment value, operational role, physical layout, and security constraints. Benchmark reciprocal access hours and inspection outcomes during the readiness period, and deliberately include one or more harder-to-inspect stress sites on each side so the regime is validated under unequal conditions.

## Risk 10 - Operational
The plan requires full-time mirrored national inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units with separation of duties and leave coverage. Recruiting enough cleared, bilingual, technically credible specialists on both sides within the entry-condition period is a major challenge, and reliance on a small surge cadre can create single points of failure.

**Impact:** Staffing gaps would delay event response, invalidate evidence collection, and violate the no-single-person-critical-function rule. Hiring premium pay and security-clearance processing could add 10–20% to the $750M inspectorate envelope, or $75–150M, and push the Phase One start by 3–6 months if qualified personnel cannot be cleared in time.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Build a workload-based staffing model before the clock starts, create a full-time surge cadre rather than using temporary agents, cross-train specialists across sites, and initiate security-clearance processing in parallel with entry-condition certification. Include retention bonuses and a training pipeline for technical inspectors to reduce attrition risk.

## Risk 11 - Security
The program itself is a high-value target for state-sponsored cyber operations, insider threats, and counterintelligence activity. Evidence systems, secure facilities, inspector communications, and the confidential covered-equipment schedule are attractive targets. A single compromised insider or cyber intrusion could undermine the integrity of verification evidence and create an international incident.

**Impact:** A successful compromise could alter ledger records, leak the covered-equipment schedule, expose inspector travel plans, or reveal sensitive data collected during inspections. Response and remediation costs could range from $10–100M, and the political fallout could trigger automatic suspension or the withdrawal of either government.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement strict need-to-know compartments, physical and logical separation of national teams, continuous counterintelligence monitoring, hardware-separated evidence systems, and regular penetration testing by independent red teams. Establish a joint incident-response protocol that isolates compromised systems while preserving the ability to continue verification at unaffected sites.

## Risk 12 - Technical & Governance
The Phase One Go decision depends on live exercises demonstrating credible detection. If red teams are not truly independent or blind, if exercises are announced too far in advance, or if KPI thresholds are set without validation, the exercises can produce a false sense of confidence. The plan does not finalize threshold values, and unsupported figures marked provisional or TBD must still be validated before they can justify a Go verdict.

**Impact:** A Go recommendation based on scripted exercises or lenient thresholds could lead a government to rely on a verification regime that cannot detect real substitution, with national-security consequences. Setting thresholds too strict could cause a false Stop and waste the $5B investment; too loose could produce an indefensible Go. Threshold negotiation itself could delay the verdict by weeks.

**Likelihood:** Medium

**Severity:** High

**Action:** Use genuinely independent red teams with no advance knowledge of exercise timing, run unannounced exercises in staging, spare-inventory, and maintenance areas, and pre-register all KPI thresholds with a validation plan based on historical data, pilot runs, and exercise results. Require the KPI dashboard to show false-negative and false-positive rates, confidence intervals, and unresolved-discrepancy ages before any Go decision.

## Risk 13 - Technical
The covered-equipment schedule must remain current as AI hardware evolves, but every revision reopens the bilateral definitional bargain. If the schedule is too static, new frontier-relevant equipment is not verified; if it is revised too often, disputes over definitional criteria delay operations. The plan's attribute-based confidential schedule depends on accountable specialists, but the versioning process itself can become a flashpoint.

**Impact:** During the Phase One window, a new architecture could ship that is not on the schedule, creating an unverified gap until the double-key approval process completes. If approval takes 4–8 weeks, a material installation could occur outside verification; if the schedule is frozen to avoid dispute, the regime's credibility decays immediately after launch.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-negotiate an attribute-based coverage framework before the clock starts, include a fast-track provisional listing procedure that adds equipment on an interim basis within 48–72 hours, and schedule sunset reviews linked to each side's declared new generations. Require the accountable specialists to maintain a versioned changelog and pre-registered criteria for disputes.

## Risk 14 - Operational & Social
Operators and vendors may cooperate reluctantly, fearing that inspections will disrupt active computational work, expose confidential customer arrangements, or reveal more than the bounded protocol allows. The plan's live exercises must not interrupt active work, but even staging, maintenance monitoring, and witnessed movement create friction. A reluctant operator can delay access, produce inaccurate records, or challenge evidence authenticity.

**Impact:** Access delays could violate the latency budget and cause false negatives or false positives in exercise results. Production disruption claims could become a political issue, causing operators to seek exemptions or compensation beyond the $1B preparation and compensation envelope. If one country's operators are less cooperative than the other's, reciprocal-access parity fails and the Stop condition is triggered.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Bind operator participation as a condition of site eligibility, provide fair compensation administered by the operator's own government, and pre-agree inspection windows that minimize interference with production. Escalate deliberate obstruction to the co-chairs quickly, and use the exercise program to test and refine low-disruption inspection techniques before the actual event-response phase.

## Risk 15 - Financial & Environmental
The $5B budget is fixed, with each expense mapped to an envelope. Site preparation, secure facilities, and independent testing often overrun initial estimates, and the physical locations face power-grid, climate, and logistical risks. Natural disasters or energy constraints could disrupt verification exercises and force contingency spending.

**Impact:** A 5–10% cost overrun equals $250–500M and would consume the entire contingency envelope, forcing reallocation from testing or inspectorate capacity. A severe weather or grid event at a selected site could delay the 90-day test by 2–4 weeks and require emergency relocation or backup-power costs of $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan for overruns, and select multiple fallback sites within each country to mitigate physical-environment risk. Use structured currency conversion and fixed-price contracts where possible to limit inflation and exchange-rate exposure.

## Risk summary
The risk landscape is dominated by political and institutional failure modes rather than purely technical ones. The three most critical risks are: entry-condition and appropriations delay, which can prevent Phase One from ever starting or allow a quiet veto; vendor refusal and unverifiable-equipment contagion, which can trigger the Stop condition through a single dominant supplier; and information-barrier imbalance, where over-filtering blinds inspectors to substitution or under-filtering exposes sensitive technology and collapses political support. These risks are mutually reinforcing: an information leak can cause funding delays, a vendor refusal can expose parity asymmetries, and deadlock over any of these can suspend the entire program. Key assumptions are that both governments genuinely intend to meet entry conditions, that suitable matched sites and qualified personnel can be identified within the budget, and that KPI thresholds will be validated before use; the absence of specified thresholds and site or vendor agreements is the largest source of remaining uncertainty. Success should be judged only against the narrow mission of verifying monitored changes at declared sites, not as a broader AI-governance guarantee.

# Make Assumptions


## Question 1 - How should the USD 5 billion contributions be escrowed, released, and revalued to prevent delayed or asymmetric disbursement from acting as a quiet veto, and what exchange-rate rule should govern CNY-denominated China-side payments?

**Assumptions:** Assumption: Both governments will pre-fund their full USD 2.5 billion contributions into a jointly signatory escrow before the Phase One clock starts, with drawdowns only against envelope-approved expenditures and quarterly USD reconciliation. China-side operator and vendor payments will be converted through quarterly structured windows with periodic revaluation, and any contribution-release delay beyond 10 business days is recorded as a KPI-visible suspension trigger. This aligns with the funding-timeliness KPI and the currency strategy in currency_strategy.md.

**Assessments:** Title: Funding and Fiscal Accountability Assessment
Description: Evaluates the escrow, release, and currency mechanism for the USD 5 billion budget.
Details: Full pre-funding removes the quiet-veto risk identified in identify_risks.md Risk 4 and guarantees reciprocal deployment for matched-site parity. A 5% CNY/USD movement or local-inflation shock could add USD 125-250 million in unplanned costs if unhedged; structured conversion windows and a dedicated FX reserve within the contingency envelope cap this exposure. Drawdowns must be tied to envelope codes (ledger, site prep, inspectorate, facilities, testing, legal/audit, contingency) and audited quarterly. Benefits include predictable staffing and site preparation; opportunity to use escrow interest or treasury instruments to offset administrative costs, though any return must be returned to both governments to preserve the non-commercial, sovereign nature.

## Question 2 - What is the maximum acceptable duration for the mandatory entry-condition phase, and how will the 90-day Phase One clock be jointly certified and kept on schedule if one government's legislative or site-selection process slips?

**Assumptions:** Assumption: The entry-condition phase will be capped at 12 months from the date of political commitment (target completion by 2027-Sep-04), with an integrated readiness tracker and parallel preparation across all workstreams. The Phase One clock starts only after co-chairs jointly certify all conditions; any condition still open after 12 months triggers escalation to heads of state and becomes a public KPI, but does not start the 90-day test. This is consistent with identify_risks.md Risk 2 and the plan's mandatory entry conditions.

**Assessments:** Title: Timeline and Milestone Gating Assessment
Description: Assesses the entry-condition gate, parallel readiness, and the 90-day operational window.
Details: Political actions (appropriations, domestic access authority, site selection, inspector approval, vendor/operator agreements, schedule adoption) can each delay start by 6-24 months if handled sequentially; parallel workstreams and a single integrated readiness tracker compress this to a 12-month target. The formal clock must not start until all conditions are certified to avoid burning the 90-day test on unresolved prerequisites. Provisional shadow exercises can keep teams warm without creating de facto obligations or non-binding findings. Metrics: readiness checklist closure rate, days to certification, number of certified conditions at clock start; target 100% reciprocal certification. Risk: a slip on one side idles trained staff and consumes inspectorate funding; mitigation includes provisional training and surge deployment only after joint certification.

## Question 3 - How many participating declared sites will constitute the matched set, and what workload-based staffing model—including mirrored national teams, shift coverage, leave backup, separation of duties, and a full-time surge cadre—will be required within the USD 750 million inspectorate envelope?

**Assumptions:** Assumption: The matched set will be 6 declared sites (3 per country), requiring 24/7 on-site coverage at each site with no fewer than two full-time mirrored national inspectors per material event, a 1.5x leave/backup multiplier, and a permanently employed surge cadre equal to 10% of baseline staffing. The resulting baseline is approximately 450 full-time-equivalent positions across inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units, with no single-person critical functions. This is derived from Risk 10 guidance and the plan's staffing mandate.

**Assessments:** Title: Resourcing and Staffing Feasibility Assessment
Description: Evaluates the full-time mirrored staffing model and its fit to the USD 750 million inspectorate envelope.
Details: A 450-person baseline with loaded annual cost averaging USD 200k implies USD 90 million per year; an 18-month readiness-plus-Phase-One period costs roughly USD 135 million, leaving headroom for surge, training, travel, translation, and security clearances within the envelope. The 1.5x multiplier and 10% surge cadre prevent single points of failure but add 15-20% above a minimal model. Risk: clearance delays and bilingual technical talent scarcity could add 10-20% cost (USD 75-150 million) and delay start by 3-6 months; mitigation is to begin clearances in parallel and cross-train specialists. Staffing depth also serves as a reciprocity signal; asymmetric capacity would undermine the Go decision.

## Question 4 - How will the bilateral instrument pre-commit both governments to a deadlock-resolution procedure, automatic-suspension thresholds, and a binding bilingual glossary so that no single co-chair can indefinitely block a material finding or reinterpret a contested term?

**Assumptions:** Assumption: The instrument will create joint technical teams for routine discrepancies, refer deadlocked factual disputes to a jointly selected advisory arbiter (advisory only), and limit automatic suspension to sites with unresolved material discrepancies. A deadlock persisting more than 10 business days is recorded on the KPI dashboard and escalates to the two governments' leadership; the binding bilingual glossary and pre-registered interpretive annex are adopted before the clock starts. This addresses Risk 1 and Decision 14 while preserving double-key authorization for sanctions and suspension.

**Assessments:** Title: Bilateral Governance and Legal Certainty Assessment
Description: Assesses double-key governance, deadlock control, and interpretive dispute management.
Details: Without a bounded deadlock path, one co-chair can exploit delay to shield an operator or stall the verdict. Pre-registered glossary and interpretive annex convert future disputes into lookup operations; joint technical teams keep routine discrepancies from rising to the political level. The 10-business-day deadlock threshold balances the no-unilateral-overrule rule against the need for timely findings; if too long, material discrepancies age and trigger unnecessary suspension; if too short, routine disputes escalate politically. Metrics: deadlock resolution time, interpretive disputes resolved without access denial, count of unilateral findings (target zero). Legal implementation cost is bounded within the USD 250 million envelope; domestic access legislation must override private-law objections and bind operators and vendors contractually.

## Question 5 - What provisional thresholds for false negatives, unresolved discrepancy age, unverifiable equipment, vendor-refusal escalation, and information-security incidents will define materiality and trigger automatic suspension, and how will live blind challenges validate those thresholds before the Go decision?

**Assumptions:** Assumption: Provisional thresholds, to be validated by pilot runs and exercises, are: operator event reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour; false-negative rate no greater than 5% in blind challenges with at least 95% confidence; unresolved material discrepancy age no greater than 10 business days; unverifiable covered equipment no more than 2 units per site or 1% of covered changes; a single confirmed IP/cyber incident compromising evidence integrity triggers isolation and an automatic hold on affected systems. These align with Risk 7, Risk 8, and Risk 12 and the KPI list.

**Assessments:** Title: Safety, Security, and Verification-Risk Assessment
Description: Evaluates detection thresholds, cyber/counterintelligence protection, and challenge-based validation.
Details: The thresholds define the regime's falsifiable honesty claim: if red teams can exceed a 5% false-negative rate or hide a substitution for more than 4+24+1 hours, the Phase One verdict must not be Go. Overly strict thresholds risk a false Stop and wasted USD 5 billion; overly loose thresholds risk certifying an undetected substitution. Mitigation: run six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal) and use independent red teams with no advance timing. Cyber/counterintelligence costs are drawn from the USD 750 million facilities and cyber envelope; a single evidence-integrity incident may cost USD 10-100 million and trigger automatic suspension, so system isolation must be drilled.

## Question 6 - How will the Consortium assess and mitigate environmental, energy-grid, and climate-related risks at the selected datacenter sites—particularly in Northern Virginia, Beijing/Hebei, and Guizhou—so that power reliability, cooling, and disaster continuity do not disrupt the 90-day test?

**Assumptions:** Assumption: Each selected site must demonstrate at least N+1 power redundancy and 99.9% annual uptime, and the Consortium will perform a pre-selection environmental and grid-stability assessment for each candidate. Two fallback sites per country will be pre-qualified, and USD 20 million of the contingency envelope is reserved for disaster response, backup power, and relocation if a weather or grid event disrupts exercises. This responds to Risk 15 and physical_locations.md.

**Assessments:** Title: Environmental and Physical-Resilience Assessment
Description: Assesses power, climate, and disaster risks at physical sites and their impact on verification continuity.
Details: The selected regions are major datacenter hubs but face distinct risks: Northern Virginia has grid congestion and heat/humidity; Beijing/Hebei has air-quality and water constraints; Guizhou has hydroelectric dependency and seasonal variability. A severe weather or grid event could delay the 90-day test by 2-4 weeks and cost USD 5-20 million in backup power or relocation. The mission's environmental footprint is modest relative to existing datacenter operations; the main financial exposure is business continuity, not emissions. Mitigation: pre-qualified fallback sites, portable power and cooling for staging and bounded inspection zones, and exercise scheduling windows that avoid local peak-demand seasons. KPI: site uptime during Phase One at or above 99.9%; zero exercise cancellations due to environmental causes.

## Question 7 - How will the Consortium obtain and enforce binding operator, manufacturer, maintenance-provider, and logistics-company participation—including reporting, confidentiality, escort, and evidence-preservation obligations—without relying on voluntary cooperation, and how will domestic compensation be administered without creating conflicts of interest?

**Assumptions:** Assumption: Operator and vendor participation will be mandated by domestic law and contractual conditions of site eligibility, with model vendor-access agreements pre-negotiated before clock start. Each government administers compensation for its domestic operators and vendors from its own USD 2.5 billion contribution, capped within the USD 1 billion site-preparation and operator-compensation envelope, and deliberate obstruction or refusal to provide access is classified as a material discrepancy. This operationalizes Risk 5 and Risk 14 and the plan's vendor-refusal ladder.

**Assessments:** Title: Stakeholder and Third-Party Compliance Assessment
Description: Assesses operator/vendor obligations, compensation administration, and refusal containment.
Details: The verification regime fails if a dominant vendor refuses clean-room access or a reluctant operator delays entry. Pre-negotiated model agreements and domestic legal mandates convert participation from goodwill to obligation; if a critical vendor refuses, use vendor-supervised testing, filtered evidence, accredited independent examiners, or validated attestation, and classify equipment unverifiable only after the full ladder fails. A material unverifiable count fails the site. Compensation administered by each government avoids cross-border payments and preserves fiscal sovereignty but creates a risk that compensation is used to influence operators; independent audit of compensation disbursement should be included. Metrics: vendor-refusal outcomes, unverifiable-equipment counts, time from refusal to resolved disposition, operator access-delay incidents; target zero deliberate obstructions.

## Question 8 - What are the required functional specifications and latency bounds for the replicated tamper-evident ledger, controlled intake staging, filtered-evidence information barriers, and exit/disposition protocol, and how will these systems be exercised together in live challenges before the Go/Modify/Stop decision?

**Assumptions:** Assumption: The ledger will use local-first, hash-chained national copies with continuous hash-commitment exchange, a synchronization target of no more than 1 hour for event records, and a divergence-reconciliation target of no more than 24 hours. All covered arrivals must pass through jointly controlled staging areas with pre-installation identity gates; all departures must receive an assigned disposition (witnessed destruction, verified permanent disablement, transfer, documented release, or unresolved) within 48 hours or trigger automatic site review. Operational-system integration will be validated by six mandatory unannounced challenge types before the verdict. This reflects Decision 10, Decision 11, and the plan's Exit Protocol.

**Assessments:** Title: Operational Systems and Lifecycle Verification Assessment
Description: Assesses ledger integrity, intake/exit controls, information barriers, and integrated live-exercise readiness.
Details: The ledger must record events locally at the point of observation, synchronize with bounded latency, and reconcile divergence without requiring one side to expose sensitive content; continuous hash commitments provide tamper evidence while preserving privacy. Intake staging is the physical chokepoint—any bypass creates an unverified installation and should be treated as a material discrepancy. Exit disposition closes the lifecycle; unresolved departures must feed the verdict and can trigger automatic suspension if material. Information barriers must be tested in blind challenges because over-filtering can hide contextual metadata needed to detect substitution. Metrics: event-recording latency (target under 5 minutes locally), synchronization latency (no more than 1 hour), divergence reconciliation time (no more than 24 hours), ledger divergence count (target zero unresolved), equipment-identity confidence (at or above 99%), and blind-challenge detection rates by event type.

# Distill Assumptions

- Both leaders believe uncontrolled frontier AI threatens national security and political control.
- Both governments provide political backing and domestic authority to compel participation.
- No trust, legal symmetry, or sensitive technology exposure is assumed.
- Sovereign public-sector program, not for-profit; scope only declared-equipment change verification.
- Excludes capacity estimates, workload verification, model weights, hidden facilities, and comprehensive AI governance.
- Mandatory entry conditions are prerequisites; 90-day clock starts only after joint certification.
- Entry-condition phase capped at 12 months from political commitment; open condition escalates to leaders.
- Total budget $5B, 50/50, pre-funded into jointly signatory escrow before clock.
- Budget envelopes: $1.25B ledger, $1B site prep, $750M inspectorate, $750M facilities, $500M testing, $250M legal/audit, $500M contingency.
- Drawdowns envelope-approved, quarterly USD reconciliation, 10-business-day delay triggers suspension.
- China-side payments use quarterly structured conversion windows with periodic revaluation.
- Matched set: six sites, three per country, 24/7 coverage.
- Baseline staffing ~450 FTE; two mirrored inspectors per event; 1.5x backup; 10% surge.
- No single-person critical functions; full-time mirrored units across all functions.
- Equal co-chairs, double-key authorization; no casting vote or majority overrule.
- Joint technical teams handle routine discrepancies; advisory arbiter for deadlocked facts.
- Automatic suspension limited to unresolved material discrepancy sites; no unilateral findings/sanctions.
- Deadlock beyond 10 business days escalates to leadership; binding bilingual glossary pre-clock.
- Operator/vendor participation mandated by domestic law and pre-negotiated access agreements.
- Each government administers domestic compensation from its own contribution; obstruction is material discrepancy.
- Vendor-refusal ladder uses supervised testing, filtered evidence, independent examiners, or attestation before unverifiable.
- Material unverifiable equipment causes site failure; max 2 units/site or 1% of changes.
- Latency thresholds: operator report 4h, physical confirm 24h, ledger record 1h.
- False-negative rate ≤5% in blind challenges at 95% confidence.
- Unresolved discrepancy age max 10 business days.
- One IP/cyber incident compromising evidence integrity triggers isolation and automatic hold.
- Sites need N+1 power redundancy and 99.9% uptime; two fallback sites per country; $20M disaster reserve.
- Ledger uses local-first hash-chained national copies; sync target 1h; divergence reconciliation 24h.
- Arrivals pass jointly controlled staging identity gates; departures get disposition within 48h or site review.
- Exit dispositions: witnessed destruction, permanent disablement, transfer, documented release, or unresolved.
- Six unannounced blind challenges validate systems; exercises don't interrupt computational work.
- Information barriers protect sensitive data; no single evidence source decisive.
- Covered-equipment schedule remains confidential, versioned, attribute-based, not anchored to current products.
- Go requires reciprocal access and credible detection.
- Stop if asymmetric access, material unverifiable, shielding, unresolved divergence, or withheld funding.
- KPI thresholds provisional/TBD until validated by exercises.
- KPIs cover detection, latency, divergence, parity, discrepancies, incidents, and funding timeliness.

# Review Assumptions

## Domain of the expert reviewer
Bilateral arms-control verification, national-security program management, and datacenter infrastructure assurance

## Domain-specific considerations

- Sustained political commitment across electoral and leadership transitions
- Trusted baseline inventory of pre-existing covered equipment at declared sites
- Rapid cross-border inspector access, visas, privileges, and movement of diagnostic tools
- Legal harmonization of foreign inspector authority with privacy, export-control, and customs laws
- Counterintelligence and insider-threat resilience for both national teams
- Information-barrier trade-offs between verification sensitivity and protection of proprietary technology

## Issue 1 - Missing assumption of sustained political continuity across leadership transitions
The plan assumes current leaders' commitment is durable, but a $5B bilateral security program spanning at least 12 months of entry conditions plus Phase One and beyond can be reversed by a U.S. administration change, a Chinese leadership transition, or congressional appropriations battles. The pre-funded escrow mitigates quiet fiscal veto but cannot compel a successor government to continue hosting foreign inspectors. Without a continuity assumption, the entire investment is exposed to a single political discontinuity.

**Recommendation:** Negotiate binding continuity commitments in the bilateral instrument: multi-year funding obligations, transition briefings for incoming leadership, and a joint public KPI dashboard that makes termination politically costly. Include automatic suspension-with-escrow-return clauses if either government withdraws, and establish a track-II engagement channel to sustain technical relationships during political transitions.

**Sensitivity:** A U.S. administration change during the 12-month entry-condition baseline could delay Phase One by 12-24 months. Sunk preparation and staffing costs would reach $400-600M, consuming most of the $500M contingency; idle inspectorate costs would add $150-250M, reducing the program's political ROI to zero if terminated.

## Issue 2 - Missing trusted baseline inventory of pre-existing covered equipment at declared sites
All material-change verification assumes a known starting state, but the plan only specifies arrivals, departures, and staged events. If the initial inventory of frontier-relevant equipment at each declared datacenter is inaccurate, incomplete, or disputed, then every subsequent 'change' is unverifiable and the latency and materiality thresholds have no meaningful baseline. No assumption addresses how legacy racks installed before the regime begins are identified, serialized, and agreed upon.

**Recommendation:** Add a mandatory joint baseline physical inventory audit to the entry conditions before the Phase One clock starts. Create a cryptographic asset registry of all covered equipment at each declared site, reconciled against operator procurement, maintenance, and disposal records. Resolve all discrepancies before clock start, and treat the inventory completion as a joint certification gate.

**Sensitivity:** If 2-5% of serialized records at a typical site are inaccurate (baseline: 6 sites, roughly 50,000 covered units), reconciliation could take 4-8 weeks and cost $20-60M, delaying Phase One by 1-2 months. If skipped, the false-negative rate could exceed the 5% blind-challenge threshold, invalidating a Go verdict and wasting the $500M testing envelope.

## Issue 3 - Missing operational assumption for rapid cross-border inspector access, visas, privileges, and movement of diagnostic equipment
The 24-hour physical confirmation latency budget is impossible unless inspectors can travel to declared sites at short notice, receive visas and access credentials within hours, and bring diagnostic/test equipment across borders without customs delays. The plan assumes domestic access authority but does not explicitly assume reciprocal diplomatic clearance, inspector immunities, or pre-clearance of sensitive verification tools. A visa or customs bottleneck would break every interior latency window.

**Recommendation:** Negotiate a standing bilateral inspector-access annex before clock start: 48-hour visa processing, multiple-entry diplomatic visas for all credentialed inspectors, pre-cleared manifests for diagnostic tools, and customs pre-authorization for challenge exercise equipment. Grant inspectors privileges and immunities limited to official verification acts, and test the travel-and-clearance pathway in a mandatory pre-Phase One exercise.

**Sensitivity:** If visa processing takes 10 business days instead of the assumed 48 hours, every material event would miss the 24-hour physical confirmation window, forcing automatic suspension and a Modify or Stop verdict. A 4-week visa/customs delay during Phase One could add $5-20M in rescheduling costs and invalidate the unannounced-challenge schedule, delaying the verdict by 3-6 months.

## Review conclusion
The most critical missing assumptions are political durability, a trusted baseline inventory, and rapid cross-border inspector access. Without these, the $5B program can be halted by a leadership change, launched with an unverifiable starting state, or unable to meet its own latency thresholds. Each issue is addressable through pre-clock legal commitments, joint physical audits, and an inspector-access annex, but they must be elevated from implicit hopes to explicit, tested entry conditions.

# Governance

# Governance Audit


## Audit - Corruption Risks

- Operators or vendors bribing inspectors to certify unverified equipment arrivals, installations, or removals, or to overlook discrepancies during staging, intake, maintenance, or exit verification.
- Government officials administering domestic operator and vendor compensation steering contracts or payments to politically connected datacenter operators, maintenance providers, or logistics companies in exchange for favors or kickbacks.
- Equipment manufacturers or maintenance vendors offering bribes to accredited clean-room examiners or technical specialists to produce favorable examination reports and avoid an unverifiable-equipment classification.
- Red-team members or penetration testers colluding with site operators or program insiders to learn exercise timing or scenarios, allowing blind challenges to be scripted and false-negative rates to be understated.
- Co-chairs or senior officials trading double-key approval of findings, sanctions, or suspensions for unrelated bilateral concessions, or using confidential evidence and the covered-equipment schedule to advantage domestic commercial interests.
- Personnel with access to the confidential covered-equipment schedule, filtered evidence packages, or information-barrier rules leaking sensitive information for personal gain, professional advancement, or foreign commercial advantage.
- Translators or legal specialists manipulating the binding bilingual glossary, interpretive annex, or evidence translations in exchange for bribes or to favor one government's position in a dispute.

## Audit - Misallocation Risks

- Drawing down funds from the wrong budget envelopes or using the $500 million contingency for non-surge, non-emergency expenses without joint double-key approval, eroding envelope-level fiscal control.
- Paying domestic operators and vendors compensation for services not actually performed or at inflated rates due to weak verification of claims, effectively double-charging the site-preparation envelope and contingency.
- Allowing the trained inspectorate to sit idle during entry-condition delays while salaries, clearances, and training costs continue consuming the $750 million inspectorate envelope without producing verification evidence.
- Misreporting KPI dashboard results—such as false-negative rates, event-recording latency, ledger divergence, or reciprocal-access parity—to create a favorable appearance and divert resources away from the areas that actually need correction.
- Maintaining inaccurate or incomplete baseline physical inventory and cryptographic asset registry records, leading to duplicate or ghost equipment entries, wasted verification effort, and invalid material-change determinations.
- Using program assets—diagnostic equipment, filtered workstations, secure facilities, travel funds, or staging areas—for unauthorized or personal purposes rather than for verification activities.
- Suffering avoidable budget overruns from unstructured CNY/USD conversion and revaluation windows, causing local inflation or currency movements to consume the contingency envelope before independent testing and challenge exercises are complete.

## Audit - Procedures

- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns against approved budget codes, performed by a jointly appointed external audit firm and reported to the equal national co-chairs, with confirmation that every expense maps to a defined envelope and any contingency use requires double-key authorization.
- Perform bilateral audits of domestic operator and vendor compensation disbursements, with each government's payments independently examined by the other side's audit unit or a jointly selected auditor to detect favoritism, inflated claims, or duplicate payments; conduct these audits semi-annually and at program close.
- Run monthly ledger integrity and divergence reconciliation drills between the two national ledger copies using independent test events, and have at least two independent penetration-testing firms assess the ledger, attestation, and evidence systems before the Phase One clock starts and again during Phase One.
- Validate KPI dashboard inputs through an independent audit before any Go/Modify/Stop decision, comparing reported false-negative rates, latency values, discrepancy ages, unverifiable-equipment counts, and access-parity metrics against raw exercise logs and evidence records; also perform quarterly spot-check audits during Phase One.
- Conduct a joint baseline physical inventory and cryptographic asset registry audit as a mandatory entry condition, followed by unannounced sample counts of covered equipment at each declared site during Phase One, verifying serial numbers, identity confidence, and disposition records.
- Audit compliance with information-barrier and counterintelligence requirements by reviewing filtered-workstation logs, access-control records, clean-room procedures, and evidence-handling logs to confirm that workloads, model weights, source code, and unrelated infrastructure were not exposed; perform these audits semi-annually and trigger an ad hoc forensic audit after any IP or cybersecurity incident.
- Carry out vendor and operator compliance audits to verify that manufacturers, maintenance providers, logistics companies, and site operators meet reporting, confidentiality, escort, and evidence-preservation obligations, including review of vendor-refusal escalation outcomes and unverifiable-equipment classifications; review these quarterly or after each material refusal.
- Sample inspector travel, visa, customs, and logistics expenses against approved budgets on a quarterly basis to detect inflated claims, unauthorized travel, or misuse of program funds.

## Audit - Transparency Measures

- Maintain a public KPI dashboard updated monthly with aggregate metrics covering blind-challenge detection rates, false negatives and positives, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, funding timeliness, and audit exceptions, with classified evidence details redacted.
- Publish the joint Go/Modify/Stop recommendation and the shared findings narrative after the co-chairs issue the verdict, with sensitive evidence redacted, and publish the pre-agreed Go, Modify, and Stop criteria before the Phase One clock starts.
- Issue quarterly public appropriation and audit reports summarizing envelope-level expenditures, audit exceptions, currency conversion and revaluation results, and aggregate domestic compensation disbursements, available to domestic legislatures and the public.
- Publicly disclose the multi-attribute site-parity matrix and site-selection criteria used to choose and match the six declared datacenter sites, including the inclusion of harder-to-inspect stress sites and pre-qualified fallback sites, to demonstrate that pairing is fair and reciprocal.
- Operate a secure whistleblower channel managed by an independent joint audit office, allowing inspectors, operators, vendors, and staff to report corruption, fraud, obstruction, or misconduct with non-retaliation protections and periodic independent review of complaints.
- Publish the information-barrier filter rules and redaction standards before evidence flows, with a versioned changelog, so the rules for stripping sensitive data are known, auditable, and consistently applied across all inspection events.
- Publicly report the aggregate readiness-tracker certification status and entry-condition closure progress, making any delays or asymmetric completion visible and preventing quiet fiscal or bureaucratic vetoes.
- Provide public access to redacted independent audit reports on fiscal accountability, envelope expenditures, and compensation disbursement audits, while protecting the confidential covered-equipment schedule, evidence details, and sensitive inspection findings.

# Internal Governance Bodies

### 1. Joint Steering Council (JSC)

**Rationale for Inclusion:** The program is a bilateral sovereign verification regime operating without mutual trust and with an explicit no-unilateral-overrule rule. A strategic oversight body is required to exercise equal double-key authority over the final Go/Modify/Stop decision, material findings, sanctions, suspension, protocol changes, and budget thresholds, and to manage political deadlock and impaired confidence without a casting vote.

**Responsibilities:**

- Provide strategic direction and approve the overall Phase One plan and final Go/Modify/Stop verdict.
- Exercise double-key authorization for all material site findings, sanctions, suspensions, protocol changes, and revisions to materiality or KPI thresholds.
- Approve and certify all mandatory entry conditions, including the bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection, inspector rosters, and covered-equipment schedule before the 90-day clock starts.
- Set strategic risk appetite and review the consolidated risk register, approving responses to strategic, political, and fiscal risks.
- Approve any expenditure above USD 10 million, any cross-envelope transfer, any contingency drawdown, and any change to approved budget envelopes.
- Own the deadlock, impaired-confidence, and automatic-suspension procedures; escalate unresolved political deadlocks to heads of state/party leadership.
- Receive and decide escalations from the Joint Program Management Office and all assurance bodies.

**Initial Setup Actions:**

- Adopt the JSC charter, decision rules, and deadlock protocol before the clock starts.
- Confirm the two equal national co-chairs and appoint the non-voting secretariat.
- Approve the strategic risk appetite and initial KPI thresholds recommended by the technical and audit bodies.
- Establish the entry-condition certification package and integrated readiness tracker reporting requirements.
- Set the meeting cadence and sign-off matrix for double-key decisions.

**Membership:**

- US National Co-Chair (senior official designated by the US government)
- China National Co-Chair (senior official designated by the Chinese government)
- JSC Secretary (non-voting)

**Decision Rights:** All strategic decisions: certification of entry conditions and Phase One clock; final Go/Modify/Stop verdict; material findings; sanctions; suspension; protocol amendments; KPI/materiality threshold changes; covered-equipment schedule approvals requiring double-key; expenditures above USD 10 million; any cross-envelope transfer; any contingency drawdown; any change to approved budget envelopes; and appointment of the neutral arbiter and independent assurance members.

**Decision Mechanism:** Double-key affirmative approval by both co-chairs. There is no casting vote and no majority vote. If consensus fails, the deadlock procedure applies: the item is deferred for up to 10 business days while joint technical/legal bodies seek a recommendation; if still unresolved, the matter is escalated to heads of state/party leadership. For a site with an unresolved material discrepancy, automatic suspension of verification activities at that site remains in effect until the deadlock is resolved. A co-chair may declare impaired confidence, triggering an extraordinary JSC session and, if unresolved, protective suspension scoped to the affected activity.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during the 90-day Phase One; extraordinary sessions within 48 hours upon request of either co-chair, a material incident, or a declared impaired-confidence condition.

**Typical Agenda Items:**

- Entry-condition readiness tracker and joint certification status
- Strategic risk register review and risk appetite decisions
- Budget envelope and drawdown approvals, including contingency requests
- KPI dashboard and audit exception summaries
- Material findings, vendor-refusal escalations, and suspension recommendations
- Deadlock, impaired-confidence, and automatic-suspension reviews
- Preparation of the joint Go/Modify/Stop verdict and shared findings narrative

**Escalation Path:** To the heads of state/party leadership of both countries as the senior authorizing principals for unresolved political deadlocks, entry-condition slippage beyond the 12-month target, withdrawal risk, or any matter requiring political authority above the co-chairs.
### 2. Joint Program Management Office (JPMO)

**Rationale for Inclusion:** The program's operational complexity with six matched sites, mirrored national teams, seven budget envelopes, a 90-day clock, and live challenge exercises cannot be managed by the strategic body. A dedicated operational management body is needed to execute the readiness phase and Phase One within delegated thresholds while preserving double-key authority at the strategic level for material decisions.

**Responsibilities:**

- Manage day-to-day execution of all workstreams: bilateral authority, site selection, inspectorate deployment, intake, ledger, maintenance, exit, exercises, adjudication support, and final decision.
- Maintain the integrated readiness tracker and operational schedule, including entry-condition closure and Phase One clock certification support.
- Allocate and control expenditures within approved budget envelopes up to USD 10 million per action and up to USD 25 million per envelope reallocation per quarter, with no cross-envelope transfers.
- Own the operational risk register; identify, assess, and mitigate operational risks and escalate strategic risks to the JSC.
- Manage staffing, shift coverage, leave backup, surge deployment, and separation-of-duties compliance for all mirrored units.
- Coordinate site access, inspection windows, vendor interactions, and event response within the agreed latency budget.
- Prepare decision packages and evidence summaries for the JSC, JTAB, JAECC, and JDAP.

**Initial Setup Actions:**

- Stand up the joint secretariat and appoint the two co-deputy directors and workstream leads.
- Implement the integrated readiness tracker and envelope-level budget control system.
- Validate the staffing model against the six-site workload formula and initiate clearances and training.
- Establish daily stand-up and weekly reporting cadence with all workstream leads.
- Draft operational thresholds, escalation templates, and delegated authority registers for JSC approval.

**Membership:**

- US Deputy Program Director
- China Deputy Program Director
- Joint Secretariat Lead
- Workstream leads for inspectorate, ledger, site preparation, testing/exercises, legal support, security/counterintelligence, and logistics
- Chief Risk Officer (operational risk)
- Chief of Staff / Readiness Tracker Owner
- No member of the JSC serves on the JPMO; JPMO members are full-time operational staff.

**Decision Rights:** Operational decisions within the approved plan and budget: day-to-day scheduling, staffing assignments, site access, event response, non-material discrepancy handling, procurement and contracting up to USD 10 million per action, within-envelope reallocation up to USD 25 million per quarter, and implementation of approved technical and security procedures. No authority to change protocol, KPI/materiality thresholds, site findings, sanctions, suspension, or budget envelopes; no contingency drawdown authority.

**Decision Mechanism:** Co-deputy consensus. Decisions within a workstream lead's delegated authority are made by that lead; cross-cutting decisions require both co-deputy directors' concurrence. If the co-deputies cannot agree, the matter is deferred for no more than 48 hours and then escalated to the JSC. There is no casting vote and no single-country override.

**Meeting Cadence:** Daily operational stand-up; weekly full JPMO coordination meeting; ad hoc incident-response sessions as needed.

**Typical Agenda Items:**

- Event queue, inspection windows, and latency metrics against the 4-hour/24-hour/1-hour budget
- Staffing coverage, leave, surge deployment, and separation-of-duties compliance
- Integrated readiness tracker status and entry-condition closing actions
- Budget envelope burn rates and procurement pipeline
- Vendor and operator participation issues and access delays
- Incident reports and operational risk register updates
- Escalation packages prepared for the JSC and assurance bodies

**Escalation Path:** Escalates to the JSC for expenditures above USD 10 million, cross-envelope or contingency matters, protocol changes, material discrepancy classifications, potential suspension or sanction, co-deputy deadlock, or realization of a strategic risk. Technical implementation issues may be referred to the JTAB; compliance concerns to the JAECC; discrepancies to the JDAP.
### 3. Joint Technical Assurance Board (JTAB)

**Rationale for Inclusion:** The mission depends on novel technical judgments: layered evidence, no-single-source decisiveness, information barriers, KPI thresholds, and unbiased blind challenges. A specialized technical assurance body with independent expertise is needed to set and validate technical standards, protect evidence credibility, and advise strategic and operational decision-makers without being captured by operational pressures.

**Responsibilities:**

- Define and maintain the layered evidence hierarchy, equipment-identity confidence standards, and no-single-source-decisive rules.
- Validate all KPI thresholds for false negatives, latency, divergence, discrepancy age, and unverifiable equipment before the clock starts and after challenge exercises.
- Design, select, and oversee independent red teams and the six mandatory unannounced challenge types, ensuring no advance knowledge and independent reporting.
- Approve and version information-barrier filter rules, clean-room protocols, and filtered workstation configurations within the JSC-approved policy framework.
- Assess vendor-refusal technical fallback options and recommend unverifiable classifications.
- Review the confidential, attribute-based covered-equipment schedule versioning and provide technical advice to the JSC on double-key schedule approvals.
- Monitor technical risks and recommend adjustments to technical procedures and thresholds.

**Initial Setup Actions:**

- Adopt the JTAB terms of reference and confirm the three independent external experts jointly appointed by the two governments.
- Finalize the evidence hierarchy, filter rules, and clean-room protocols for JSC approval.
- Publish the KPI threshold validation plan and provisional thresholds.
- Select independent red team providers and establish no-advance-knowledge reporting channels.
- Create the technical risk register and integrate it with the JPMO risk register.

**Membership:**

- US Principal Technical Advisor
- China Principal Technical Advisor
- US Chief Information Barrier Engineer
- China Chief Information Barrier Engineer
- Head of Independent Red Team / Testing (external, jointly appointed)
- Three independent external experts in hardware assurance, treaty verification, and information security (jointly appointed, full voting members on technical recommendations)
- Technical schedule custodians (non-voting, attendance as needed)

**Decision Rights:** Advisory and delegated technical authority. Recommends to the JSC: evidence hierarchy, KPI thresholds, information-barrier policy, covered-equipment schedule changes requiring double-key approval, and materiality definitions. Has delegated authority to approve technical implementation details within the JSC-approved framework, including filter-rule versions, test vectors, red-team engagement terms, and clean-room procedures.

**Decision Mechanism:** Consensus-seeking among national technical leads and independent external experts. A recommendation requires no objection from either national lead and support from at least two of the three independent experts. If the national leads disagree, the issue is documented with both technical opinions and the independent experts' assessment and escalated to the JSC. No casting vote; no majority procedure may allow one country to overrule the other.

**Meeting Cadence:** Biweekly during the entry-condition phase; weekly during Phase One; additionally within 72 hours after every challenge exercise or material technical incident.

**Typical Agenda Items:**

- Blind-challenge results by event type, false-negative and false-positive rates
- Evidence-weighting and equipment-identity confidence reviews
- Information-barrier filter logs and impact on substitution detection
- KPI threshold validation and confidence intervals
- Vendor-refusal technical options and unverifiable-equipment recommendations
- Technical schedule versioning and coverage-gap assessments
- Technical risk register and mitigation effectiveness

**Escalation Path:** Escalates to the JSC for any proposed change to evidence hierarchy, KPI thresholds, materiality definitions, information-barrier policy, or covered-equipment schedule requiring double-key approval; escalates to the JPMO for technical implementation defects or operations-level corrections.
### 4. Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Rationale for Inclusion:** The program faces high-impact security and counterintelligence risks: protection of sensitive technology, insider threats, evidence integrity, and cyber compromise. A dedicated security assurance body is necessary to oversee physical and cybersecurity, counterintelligence, information barrier implementation, and incident response without conflating these issues with technical verification or financial compliance.

**Responsibilities:**

- Oversee physical security, cybersecurity, and counterintelligence for all Consortium facilities, personnel, and evidence systems.
- Implement and audit information-barrier and separation-of-duties controls to protect workloads, model weights, source code, network topology, and security architecture.
- Monitor insider-threat indicators and manage clearance and access-control processes for all personnel.
- Own the joint incident-response protocol for IP, cyber, and counterintelligence incidents; direct isolation measures pending JSC review.
- Validate the security of the replicated ledger, filtered workstations, clean rooms, and secure facilities through independent penetration testing and security red-team exercises.
- Maintain the security risk register and report security risks to the JSC and JPMO.
- Ensure counterintelligence monitoring does not compromise the no-unilateral-overrule governance principle.

**Initial Setup Actions:**

- Approve the JSCIB charter and appoint the two national security leads and independent security experts.
- Conduct a baseline security and counterintelligence risk assessment for all six sites and secure facilities.
- Approve the information-barrier implementation plan and separation-of-duties matrix.
- Select independent penetration-testing firms and schedule pre-clock security testing.
- Drill the joint cyber-incident isolation protocol twice before Phase One.

**Membership:**

- US Security and Counterintelligence Director
- China Security and Counterintelligence Director
- US Cybersecurity Lead
- China Cybersecurity Lead
- Two independent security experts jointly appointed by both governments (full advisory members)
- Counterintelligence analysts from each national team (non-voting, attendance as needed)

**Decision Rights:** Security assurance authority within the JSC-approved policy: approve security procedures, access-control changes, and incident-isolation measures; direct preservation of evidence during an incident; and recommend to the JSC any security-driven suspension or change to information-barrier policy. Cannot unilaterally suspend the program, issue sanctions, or change verification protocols.

**Decision Mechanism:** Consensus between the two national security leads for decisions. Independent security experts provide assessments and may formally flag a security risk to the JSC if they believe either lead is underreacting. If the two leads disagree, the issue escalates to the JSC within 48 hours. No casting vote and no single-country override.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during Phase One; immediately upon any security incident or threshold alert.

**Typical Agenda Items:**

- Security risk posture and threat updates for all declared sites
- Cyber-incident and insider-threat monitoring reports
- Information-barrier filter and access-control audit results
- Penetration-test findings and remediation status
- Physical security and secure-facility compliance
- Incident-response drills and isolation protocol readiness
- Security inputs to the KPI dashboard and JSC risk reviews

**Escalation Path:** Escalates to the JSC for confirmed IP or cyber incidents compromising evidence integrity, insider threat or counterintelligence breach, security-driven suspension recommendations, disagreement between national security leads, or any proposed change to information-barrier policy requiring strategic approval.
### 5. Joint Legal and Terminology Commission (JLTC)

**Rationale for Inclusion:** The bilateral instrument must be supported by a binding bilingual glossary, pre-registered interpretive readings, domestic access legislation, model vendor-access agreements, and an inspector visa and customs annex. Legal and linguistic ambiguity can become an access-denial tool or a deferred deadlock. A specialized legal commission is required to pre-commit both governments to shared meanings and implementable legal frameworks before the clock starts.

**Responsibilities:**

- Draft and maintain the binding bilingual glossary and interpretive annex for contested terms such as material, removal, frontier-relevant, and declared site.
- Coordinate the domestic access-authority legislation and regulatory implementation in both countries.
- Negotiate and maintain model vendor-access agreements, operator site-eligibility conditions, and inspector-access, visa, and customs annexes.
- Pre-register each government's interpretive positions and maintain a versioned changelog of legal interpretations.
- Advise the JSC, JPMO, and JDAP on legal and regulatory risks, export controls, customs, privacy, and data-protection law.
- Support the JAECC in compliance oversight by providing authoritative legal interpretations.

**Initial Setup Actions:**

- Convene the joint terminology commission with mirrored legal and technical linguists.
- Draft the binding bilingual glossary with worked examples and submit it to the JSC for double-key approval.
- Prepare model vendor-access agreements and inspector-access annexes for signing before clock start.
- Provide legal drafting support for domestic access authority in both countries.
- Create the pre-registered interpretive annex and versioned legal changelog.

**Membership:**

- US Legal Co-Lead
- China Legal Co-Lead
- US Technical Linguist / Glossary Lead
- China Technical Linguist / Glossary Lead
- US Export-Control and Customs Legal Specialist
- China Export-Control and Customs Legal Specialist
- Independent international-law expert jointly appointed by both governments (advisory member)
- Representatives of the JPMO legal workstream and JAECC (non-voting, attendance as needed)

**Decision Rights:** Drafting and legal-recommendation authority only. It certifies the bilingual glossary and interpretive annex for JSC double-key approval, prepares legal instruments, and issues legal opinions on interpretive disputes. It has no authority to approve program expenditures, sanctions, suspension, or verification findings.

**Decision Mechanism:** Consensus between the two legal co-leads on recommendations and certifications. If they disagree, the issue is resolved by reference to the pre-registered interpretive annex; if still unresolved, it is escalated to the JSC for double-key decision. The independent international-law expert issues an advisory opinion but has no veto. No casting vote.

**Meeting Cadence:** Weekly during the entry-condition phase; as needed during Phase One for interpretive disputes or legal incidents; immediately upon a domestic legal challenge.

**Typical Agenda Items:**

- Bilingual glossary and interpretive annex review
- Domestic access-authority implementation status
- Model vendor-access and inspector-access agreement updates
- Visa, customs, and export-control clearance tracking
- Interpretive dispute resolutions and deferred-deadlock review
- Legal risk register updates and regulatory developments
- Support to JAECC on compliance and data-protection law

**Escalation Path:** Escalates to the JSC for unresolved interpretive disputes, proposed changes to the bilingual glossary or annexes, domestic legal challenges threatening inspector access, or any legal issue requiring double-key approval. Operational access issues are escalated to the JPMO.
### 6. Joint Audit, Ethics, and Compliance Committee (JAECC)

**Rationale for Inclusion:** The program handles USD 5 billion in sovereign funds, highly sensitive information, and operators and vendors with incentives to corrupt or misreport. A dedicated, externally led assurance body is required to provide independent audit, ethics, anti-corruption, data-protection and GDPR, and regulatory compliance oversight, and to validate the KPI dashboard so the Go/Modify/Stop verdict is based on trustworthy data.

**Responsibilities:**

- Provide comprehensive compliance oversight for financial integrity, anti-corruption, conflicts of interest, GDPR and analogous data-protection laws, ethical standards, export controls, customs, and classified-information handling.
- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns, including domestic compensation disbursements.
- Validate KPI dashboard inputs against raw exercise logs and evidence records before any Go/Modify/Stop decision and on a spot-check basis during Phase One.
- Operate a secure whistleblower channel with non-retaliation protections and independent review.
- Audit compliance with information-barrier, counterintelligence, and evidence-handling requirements.
- Report material compliance findings, suspected fraud, and audit exceptions directly to the JSC and, where required, to public transparency channels.
- Recommend protective holds to the JSC for suspected material fraud or evidence compromise; it cannot independently suspend the program.

**Initial Setup Actions:**

- Appoint the independent chair, two additional independent external members, and the national compliance officers.
- Adopt the audit charter, whistleblower policy, and conflict-of-interest rules.
- Conduct a baseline compliance and ethics risk assessment for all budget envelopes and compensation flows.
- Define the KPI validation audit plan and raw-data access protocols.
- Establish the quarterly audit calendar and semi-annual compensation audit schedule.

**Membership:**

- Independent Chair, external and jointly appointed by both governments
- Two independent external members with expertise in government auditing, data protection and GDPR, and ethics and compliance, jointly appointed
- US National Compliance Officer (non-voting observer with right to record dissent)
- China National Compliance Officer (non-voting observer with right to record dissent)
- Internal audit leads from each national audit unit (non-voting, attendance as needed)

**Decision Rights:** Authoritative audit and compliance findings: compel access to records, evidence, personnel, and systems within its mandate; issue audit exceptions and compliance recommendations; require the JPMO to preserve evidence and restrict access to records during a fraud or compliance investigation; and recommend protective holds, sanctions, or suspension to the JSC. No final program, budget, protocol, sanction, or suspension authority.

**Decision Mechanism:** Findings and recommendations are decided by majority vote of the three independent external members. National compliance officers have no veto but may append dissenting views to any finding. If the independent members cannot reach a decision, the matter is escalated to the JSC with all positions recorded. The independent chair has no casting vote beyond her or his regular vote.

**Meeting Cadence:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours upon an audit exception, whistleblower complaint, data-protection breach, or suspected fraud.

**Typical Agenda Items:**

- Audit exceptions and envelope-level expenditure findings
- Domestic operator and vendor compensation audit results
- KPI dashboard validation and raw-data provenance checks
- Data protection and GDPR compliance incidents
- Ethics, conflicts of interest, and corruption-risk indicators
- Whistleblower channel status and complaint resolutions
- Compliance risk register and regulatory developments

**Escalation Path:** Escalates to the JSC for material fraud, corruption, compliance breach, KPI misreporting, data-protection breach, unresolved audit exception, or any recommended protective hold or suspension.
### 7. Joint Discrepancy Adjudication Panel (JDAP)

**Rationale for Inclusion:** The regime's credibility depends on converting raw inspection findings into agreed materiality classifications and, when necessary, suspension recommendations without unilateral overrule. A dedicated adjudication body is needed to apply pre-agreed evidentiary rules, track unresolved discrepancy age, operate the automatic-suspension threshold, and refer only material disputes to the strategic level.

**Responsibilities:**

- Receive and adjudicate all discrepancies from inspectors, the JPMO, and challenge exercises.
- Apply the pre-agreed evidence hierarchy, materiality definitions, and KPI thresholds to classify discrepancies as routine, material, or unresolved.
- Resolve routine discrepancies under delegated evidentiary rules and issue joint findings for non-material discrepancies.
- Recommend material findings, sanctions, and suspension to the JSC for double-key authorization.
- Track unresolved discrepancy age and trigger automatic site-level suspension processes when thresholds are met.
- Refer deadlocked factual disputes to the jointly selected neutral technical arbiter for advisory findings.
- Maintain the discrepancy log and feed the KPI dashboard and verdict construction.

**Initial Setup Actions:**

- Adopt the adjudication charter and standard operating procedures.
- Appoint the two national adjudication officers and the neutral technical arbiter.
- Adopt the materiality definitions and threshold triggers pre-approved by the JSC.
- Establish the discrepancy-tracking dashboard and age metrics.
- Conduct training for inspectors and workstream leads on evidence submission and materiality rules.

**Membership:**

- US Senior Adjudication Officer
- China Senior Adjudication Officer
- US Legal Adviser to the Panel
- China Legal Adviser to the Panel
- US Senior Technical Adviser
- China Senior Technical Adviser
- Neutral Technical Arbiter, external and jointly selected, with advisory vote on deadlocked facts
- JDAP Secretariat (non-voting)

**Decision Rights:** Delegated authority to resolve non-material discrepancies and classify materiality under JSC-approved definitions. Can recommend material findings, sanctions, and suspension to the JSC. Can place a temporary administrative hold on affected equipment movement or site activity when automatic-suspension thresholds are met, pending JSC double-key confirmation within 48 hours. Cannot issue final sanctions, change protocol, or make final suspension decisions.

**Decision Mechanism:** The two national adjudication officers must concur on materiality classifications and findings. Routine discrepancies are resolved by joint technical teams under pre-agreed evidentiary rules. If the adjudication officers disagree on a factual issue, the neutral technical arbiter provides an advisory finding; if the officers still do not concur, the matter escalates to the JSC. No casting vote. Deadlock persisting beyond 10 business days is recorded as unresolved and escalates, with automatic site-level suspension applying if the discrepancy is material.

**Meeting Cadence:** Daily during Phase One, or as needed after each inspection event or challenge; immediately when a material discrepancy or suspension trigger occurs.

**Typical Agenda Items:**

- New discrepancy intake and evidence package review
- Materiality classification decisions and joint findings
- Unresolved discrepancy age and automatic-suspension thresholds
- Vendor-refusal and operator-obstruction adjudications
- Neutral arbiter referrals and advisory findings
- Recommendations for JSC sanctions or suspension
- Discrepancy trend inputs to the KPI dashboard and verdict construction

**Escalation Path:** Escalates to the JSC for material findings, sanctions, suspension, unresolved factual disputes after the arbiter process, deadlock beyond 10 business days, or any discrepancy meeting the Stop threshold.

# Governance Implementation Plan

### 1. Both governments designate senior officials to a Joint Formation Team and an Interim Secretariat to establish the governance framework, with a mandate to draft charters, coordinate appointments, and sequence the formation of all governance bodies.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Joint Formation Team designation letters
- Joint Formation Team mandate
- Interim Secretariat staffed

**Dependencies:**

- Political commitment confirmed
- Bilateral instrument drafting underway

### 2. Joint Formation Team drafts the initial Charter for the Joint Steering Council (JSC), including mission, double-key decision rules, no-casting-vote rule, deadlock procedure, impaired-confidence procedure, automatic-suspension thresholds, and meeting cadence.

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 1-2

**Key Outputs/Deliverables:**

- Draft JSC Charter v0.1

**Dependencies:**

- Joint Formation Team mandated
- Strategic Decision 1 (double-key deadlock and suspension) confirmed

### 3. Both governments appoint the two equal national co-chairs of the JSC and confirm the non-voting JSC Secretary, formally designating the JSC's leadership.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Weeks 2-3

**Key Outputs/Deliverables:**

- US Co-Chair appointment letter
- China Co-Chair appointment letter
- JSC Secretary appointment

**Dependencies:**

- Draft JSC Charter available
- Bilateral agreement on co-chair selection criteria

### 4. Convene the JSC formation session; the appointed co-chairs adopt the JSC Charter, formally constituting the JSC and approving its meeting cadence and double-key sign-off matrix.

**Responsible Body/Role:** JSC (formation session, chaired by appointed co-chairs)

**Suggested Timeframe:** Project Weeks 3-4

**Key Outputs/Deliverables:**

- Approved JSC Charter
- JSC meeting cadence
- Double-key sign-off matrix

**Dependencies:**

- Both JSC co-chairs appointed
- Draft JSC Charter v0.1 completed

### 5. Joint Formation Team drafts the Terms of Reference for the Joint Program Management Office (JPMO), Joint Technical Assurance Board (JTAB), Joint Security, Counterintelligence, and Information Assurance Board (JSCIB), Joint Legal and Terminology Commission (JLTC), Joint Audit, Ethics, and Compliance Committee (JAECC), and Joint Discrepancy Adjudication Panel (JDAP).

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 2-4

**Key Outputs/Deliverables:**

- Draft ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP

**Dependencies:**

- Joint Formation Team mandated
- JSC Charter drafting informed by strategic governance decisions

### 6. JSC approves the Terms of Reference for all operational and assurance bodies, the strategic risk appetite, initial budget envelope allocation, and delegated authority thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 4-6

**Key Outputs/Deliverables:**

- Approved ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP
- Strategic Risk Appetite Statement
- Approved budget envelope allocation
- Delegated authority register v0.1

**Dependencies:**

- JSC Charter adopted
- Draft ToRs completed by Joint Formation Team
- Strategic decisions and budget envelopes confirmed

### 7. JSC appoints the JPMO co-deputy directors and the Joint Secretariat Lead, formally establishing the JPMO leadership team.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 6-8

**Key Outputs/Deliverables:**

- JPMO co-deputy director appointment letters
- Joint Secretariat Lead appointment
- JPMO leadership team confirmed

**Dependencies:**

- JPMO ToR approved

### 8. Hold the JPMO kick-off meeting; adopt the operational charter, assign workstream leads, and validate the six-site workload-based staffing model.

**Responsible Body/Role:** JPMO (under appointed co-deputy directors)

**Suggested Timeframe:** Project Weeks 8-10

**Key Outputs/Deliverables:**

- JPMO operational charter
- Workstream lead assignments
- Staffing model v0.1 validated

**Dependencies:**

- JPMO co-deputy directors appointed
- JPMO ToR approved

### 9. JPMO implements the integrated readiness tracker and envelope-level budget control system, including escalation templates and delegated authority registers.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- Integrated readiness tracker
- Envelope-level budget control system
- Escalation templates
- Delegated authority register v0.2

**Dependencies:**

- JPMO kick-off completed
- Budget envelope allocation approved by JSC

### 10. Both governments jointly appoint the JTAB national technical leads and the three independent external experts in hardware assurance, treaty verification, and information security.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- JTAB appointment letters
- JTAB membership roster confirmed

**Dependencies:**

- JTAB ToR approved

### 11. Hold the JTAB formation/kick-off meeting; adopt the technical assurance work plan, begin drafting the layered evidence hierarchy, and publish the KPI threshold validation plan.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JTAB technical assurance work plan
- Layered evidence hierarchy draft
- KPI threshold validation plan v0.1

**Dependencies:**

- JTAB members appointed
- JTAB ToR approved

### 12. Both governments appoint the JSCIB national security leads and jointly appoint two independent security experts.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JSCIB appointment letters
- JSCIB membership roster confirmed

**Dependencies:**

- JSCIB ToR approved

### 13. Hold the JSCIB formation/kick-off meeting; conduct the baseline security and counterintelligence risk assessment and approve the information-barrier implementation plan and separation-of-duties matrix.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Weeks 12-16

**Key Outputs/Deliverables:**

- Baseline security and counterintelligence risk assessment
- Information-barrier implementation plan
- Separation-of-duties matrix

**Dependencies:**

- JSCIB members appointed
- Candidate site and secure-facility list available

### 14. Both governments appoint the JLTC legal co-leads, technical linguists, export-control and customs legal specialists, and the independent international-law expert.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JLTC appointment letters
- JLTC membership roster confirmed

**Dependencies:**

- JLTC ToR approved

### 15. Hold the JLTC formation/kick-off meeting; begin drafting the binding bilingual glossary, interpretive annex, and pre-registered interpretive positions.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- Draft bilingual glossary v0.1
- Draft interpretive annex
- Pre-registered interpretive positions template

**Dependencies:**

- JLTC members appointed
- Bilateral instrument draft text available

### 16. JLTC prepares model vendor-access agreements, operator site-eligibility conditions, and the inspector-access, visa, and customs annex.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Draft model vendor-access agreement
- Operator site-eligibility conditions
- Draft inspector-access, visa, and customs annex

**Dependencies:**

- JLTC kick-off completed
- Domestic access-authority legislative drafts reviewed

### 17. Both governments jointly appoint the JAECC independent chair, two independent external members, and designate the national compliance officers.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- JAECC appointment letters
- National compliance officer designations
- JAECC membership roster confirmed

**Dependencies:**

- JAECC ToR approved

### 18. Hold the JAECC formation/kick-off meeting; adopt the audit charter, whistleblower policy, conflict-of-interest rules, and the KPI validation audit plan.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Weeks 14-20

**Key Outputs/Deliverables:**

- JAECC audit charter
- Whistleblower policy
- Conflict-of-interest rules
- KPI validation audit plan

**Dependencies:**

- JAECC members appointed
- JPMO budget control system available for audit access

### 19. JSC approves the JDAP mandate, materiality definitions, and automatic-suspension trigger thresholds recommended by JTAB and JPMO.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 2-4

**Key Outputs/Deliverables:**

- Approved JDAP ToR
- Approved materiality definitions
- Approved automatic-suspension trigger thresholds

**Dependencies:**

- JTAB evidence hierarchy draft
- JSC strategic risk appetite approved

### 20. JSC appoints the JDAP national senior adjudication officers and jointly selects the neutral technical arbiter.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 3-5

**Key Outputs/Deliverables:**

- JDAP appointment letters
- Neutral technical arbiter appointment
- JDAP membership roster confirmed

**Dependencies:**

- JDAP ToR approved
- Materiality definitions approved

### 21. Hold the JDAP formation/kick-off meeting; adopt standard operating procedures, the discrepancy log, and unresolved-discrepancy age tracking.

**Responsible Body/Role:** JDAP

**Suggested Timeframe:** Project Months 4-6

**Key Outputs/Deliverables:**

- JDAP standard operating procedures
- Discrepancy tracking dashboard
- Unresolved-discrepancy age metrics

**Dependencies:**

- JDAP members appointed
- Materiality definitions approved

### 22. JTAB finalizes the layered evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds, incorporating JSCIB security input.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Evidence hierarchy v1.0
- Information-barrier filter rules v1.0
- Clean-room protocols
- Provisional KPI thresholds

**Dependencies:**

- JTAB kick-off completed
- JSCIB input on information-barrier security

### 23. JSC double-key approves the evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 5-7

**Key Outputs/Deliverables:**

- JSC approval minutes
- Approved technical standards
- Approved provisional KPI thresholds

**Dependencies:**

- JTAB technical submissions complete
- JSCIB security review complete

### 24. JTAB selects independent red-team providers and establishes no-advance-knowledge reporting channels for the six mandatory unannounced challenge types.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 5-8

**Key Outputs/Deliverables:**

- Red-team provider contracts
- No-advance-knowledge reporting protocol
- Challenge exercise design plan

**Dependencies:**

- JSC-approved provisional KPI thresholds
- Independent testing budget envelope available

### 25. JSCIB executes the first cyber-incident isolation drill and independent penetration testing of the ledger, filtered workstations, and clean-room systems.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Penetration test reports
- First cyber-incident isolation drill after-action report
- Remediation plans

**Dependencies:**

- JSCIB kick-off completed
- Ledger and filtered-workstation prototypes available

### 26. JPMO validates the detailed staffing model, initiates security clearances, begins common training for mirrored national units, and establishes the full-time surge cadre roster.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Staffing model v1.0
- Clearance initiation records
- Common training curriculum
- Surge cadre roster

**Dependencies:**

- JPMO kick-off completed
- Workload assumptions and site count confirmed
- JTAB technical standards available for inspector training

### 27. JLTC completes the binding bilingual glossary, interpretive annex, and model legal instruments, and submits them to JSC for double-key approval.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Final bilingual glossary
- Final interpretive annex
- Final model vendor-access and inspector-access instruments

**Dependencies:**

- JLTC drafting complete
- Bilateral instrument text finalized
- Domestic legal requirements confirmed

### 28. JSC double-key approves the binding bilingual glossary, interpretive annex, and model legal instruments before the Phase One clock starts.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 6-9

**Key Outputs/Deliverables:**

- JSC approval minutes
- Certified bilingual glossary
- Approved interpretive annex
- Approved legal instruments

**Dependencies:**

- JLTC final submissions complete
- Negotiation positions reconciled

### 29. JAECC conducts the baseline compliance and ethics risk assessment and completes the first quarterly audit cycle of envelope-level expenditures and drawdowns.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Baseline compliance and ethics risk assessment
- Q1 audit report
- Audit exception register

**Dependencies:**

- JAECC kick-off completed
- Budget control system operational
- First drawdowns executed

### 30. JSCIB executes the second cyber-incident isolation drill and certifies security and counterintelligence readiness for Phase One.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 7-10

**Key Outputs/Deliverables:**

- Second drill after-action report
- Security readiness certification package
- Counterintelligence readiness assessment

**Dependencies:**

- First drill completed
- Secure facilities and evidence systems operational

### 31. JPMO consolidates all governance-body readiness inputs into the integrated readiness tracker and prepares the entry-condition certification package for JSC review.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 8-11

**Key Outputs/Deliverables:**

- Consolidated readiness tracker
- Entry-condition certification package draft
- Gap analysis and remediation plan

**Dependencies:**

- All bodies' initial charters and work plans approved
- JLTC legal instruments approved
- Staffing and clearance milestones met

### 32. JSC convenes a formal governance integration and orientation session with all body leads to review escalation paths, decision rights, and KPI dashboard reporting, and to resolve any interfacing issues.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 9-11

**Key Outputs/Deliverables:**

- Governance integration minutes
- Escalation path diagram
- KPI dashboard reporting protocols
- Interfacing issues log

**Dependencies:**

- All governance bodies formally established
- JAECC KPI validation plan available
- JPMO consolidated readiness tracker available

### 33. JSC conducts the final entry-condition certification review, jointly certifies that all mandatory entry conditions are met, and formally starts the 90-day Phase One clock.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** By 2027-Sep-04 target (Project Month 12)

**Key Outputs/Deliverables:**

- Joint entry-condition certification
- Phase One clock start authorization
- Certified readiness package

**Dependencies:**

- Entry-condition certification package approved
- All legal instruments signed
- Escrow pre-funding confirmed
- Sites and inspectors approved
- KPI thresholds validated

# Decision Escalation Matrix

**Budget Request Exceeding JPMO Delegated Authority (Above USD 10 Million or Cross-Envelope Transfer)**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key affirmative approval by both national co-chairs; no casting vote. If consensus fails, the pre-registered deadlock procedure applies, with escalation to heads of state or party leadership after 10 business days if unresolved.
Rationale: Exceeds the JPMO's delegated expenditure threshold and involves cross-envelope or contingency drawdown authority reserved to the strategic body to protect the approved budget envelopes and fiscal accountability.
Negative Consequences: Unauthorized or asymmetric spending, budget-envelope erosion, loss of fiscal oversight, and a quiet fiscal veto that can stall Phase One operations.

**Confirmed IP/Cyber Incident Compromising Evidence Integrity**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSCIB directs immediate isolation measures under the incident-response protocol and reports to the JSC; JSC decides by double-key whether to hold, suspend, or adjust verification activity based on the JSCIB assessment.
Rationale: A single evidence-integrity compromise is a designated Stop-level trigger, can invalidate ledger records and the Go/Modify/Stop verdict, and requires strategic security-policy authority beyond JSCIB's operational isolation powers.
Negative Consequences: Compromised evidence, invalid challenge results, loss of bilateral confidence, national-security incident escalation, and program suspension or termination.

**JPMO Co-Deputy Deadlock on an Operational Decision**
Escalation Level: Joint Steering Council (JSC)
Approval Process: After the 48-hour JPMO deferral period, the matter escalates to the JSC, which applies double-key approval; an unresolved JSC deadlock follows the pre-registered 10-business-day deadlock procedure.
Rationale: No operational decision may be resolved by a single-country override, and an unresolved co-deputy deadlock blocks daily execution, risks latency-budget breaches, and requires the strategic body to restore joint authority.
Negative Consequences: Operational paralysis, missed 4-hour/24-hour/1-hour latency windows, unresolved discrepancies, and erosion of the no-unilateral-overrule principle.

**Proposed Major Protocol or Scope Change**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key authorization after receiving recommendations from the JPMO, JTAB, and JLTC as applicable; no majority vote or casting vote can alter protocol.
Rationale: Protocol amendments and scope changes alter the bilateral verification bargain and verification boundaries, exceed all delegated operational and technical authorities, and must be approved by equal sovereign co-chairs.
Negative Consequences: Mission creep beyond declared-equipment verification, renegotiation of entry conditions, legal invalidation, and loss of the narrow bilateral mandate.

**Deadlocked Material Discrepancy Classification at the JDAP**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JDAP refers the factual dispute to the neutral technical arbiter for an advisory finding; if the national adjudication officers still do not concur, the matter escalates to the JSC for double-key decision, with automatic site-level suspension remaining in effect if material.
Rationale: Material findings, sanctions, and suspension require double-key authorization, and no single country may unilaterally classify or dismiss a discrepancy that could trigger automatic suspension or a Stop verdict.
Negative Consequences: Unresolved discrepancy age beyond 10 business days, automatic suspension, a contested Go/Modify/Stop verdict, and a ready-made shield for a non-cooperating operator.

**Vendor Refusal Escalating to Potential Unverifiable-Equipment Classification**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB assesses the technical fallback ladder and recommends the unverifiable classification; JSC issues the final material finding and any sanction or site-suspension decision by double-key authorization.
Rationale: A dominant vendor refusal can cascade across multiple sites and convert a local equipment issue into a systemic Stop trigger, exceeding JPMO operational authority and requiring strategic materiality judgment.
Negative Consequences: Unverifiable equipment above the materiality threshold, site failure, cascading vendor non-cooperation, and a forced Stop recommendation.

**Proposed Revision of KPI or Materiality Thresholds After Challenge Validation**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB validates the proposed thresholds against blind-challenge data and recommends approval; JSC decides by double-key, ensuring both governments accept any change to the falsifiable honesty claim of Phase One.
Rationale: KPI and materiality thresholds define the Go/Modify/Stop criteria and strategic risk appetite; changing them unilaterally or after poor results could mask detection failures and undermine verdict credibility.
Negative Consequences: False Go based on relaxed thresholds, false Stop from over-calibration, loss of independent red-team credibility, and a politically contested final verdict.

**Entry-Condition Slippage Beyond the 12-Month Target**
Escalation Level: Heads of State / Party Leadership
Approval Process: JSC formally escalates the open certification conditions to the two senior authorizing principals, who issue a joint political directive to remedy the slippage or decide program continuation; the JSC retains double-key certification of any new clock start.
Rationale: Entry conditions are political acts requiring authority above the co-chairs; the 12-month target is a political commitment, and only the senior principals can resolve legislative or site-selection deadlocks.
Negative Consequences: Indefinite delay of Phase One, idle inspectorate and sunk preparation costs, loss of political momentum, and potential collapse of the USD 5 billion program.

**Information-Barrier Policy Conflict Between Verification Sensitivity and Technology Protection**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB and JSCIB provide joint technical and security assessments; JSC approves any change to filter rules, clean-room protocols, or inspection-zone boundaries by double-key.
Rationale: The balance between evidence sufficiency and protection of sovereign technology is the core strategic tension, and altering barrier policy affects national security exposure and the credibility of every verification result.
Negative Consequences: Over-filtering hides substitution evidence and causes false negatives, while under-filtering leaks sensitive technology, triggering counterintelligence failure and program termination.

**Material Fraud, Corruption, or KPI Misreporting Detected by JAECC**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JAECC issues an audit exception and recommends protective holds, sanctions, or suspension; JSC decides by double-key after receiving the independent findings and any dissenting views from national compliance officers.
Rationale: Misreporting or fraud in sovereign funds or KPI data corrupts the evidence base for the verdict and the integrity of the entire bilateral mechanism, requiring independent-audit escalation to the strategic level.
Negative Consequences: Financial loss across the USD 5 billion envelope, false Go/Modify/Stop decision, legal penalties, loss of public and sovereign trust, and exposure to whistleblower or compliance investigations.

# Monitoring Progress

### 1. Entry-condition readiness and certification tracking: monitor closure of all ten mandatory entry conditions (bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection and declaration, inspector roster approval, operator/vendor participation agreements, covered-equipment schedule adoption, joint baseline physical inventory and cryptographic asset registry, inspector visa/customs annex and travel-and-clearance drill, and independent validation of the ledger/barrier/KPI systems) against the integrated readiness tracker, with reciprocal certification parity enforced.
**Monitoring Tools/Platforms:**

  - Integrated readiness tracker
  - Entry-condition certification checklist/package
  - Reciprocal certification parity report
  - JSC escalation templates to heads of state/party leadership
  - Gap analysis and remediation plan

**Frequency:** Weekly during the entry-condition phase; daily during the final two months before the 2027-Sep-04 target

**Responsible Role:** Joint Program Management Office (JPMO) with joint certification by the Joint Steering Council (JSC)

**Adaptation Process:** JPMO assigns corrective actions to named workstream leads for each open condition; if any condition risks missing the 12-month target, JPMO escalates to the JSC, which may formally escalate the open political condition to heads of state/party leadership; the Phase One clock is not started until all conditions are jointly certified by both co-chairs.

**Adaptation Trigger:** Any entry condition open after the 2027-Sep-04 target date; uncertified condition at proposed clock start; asymmetric certification progress between the two countries; baseline inventory discrepancy above 2% at any site blocking certification

### 2. Operational KPI dashboard monitoring: track the full pre-registered KPI set covering blind-challenge detection by event type, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, production disruption, funding timeliness, and audit exceptions.
**Monitoring Tools/Platforms:**

  - KPI dashboard
  - KPI Tracking Spreadsheet with confidence intervals
  - Raw exercise logs and evidence records
  - Latency monitoring and alerting tools
  - Ledger divergence and synchronization health reports

**Frequency:** Daily during Phase One; weekly during the entry-condition phase for pre-validation baselines

**Responsible Role:** Joint Program Management Office (JPMO) with KPI threshold validation by the Joint Technical Assurance Board (JTAB) and KPI data-integrity audits by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO implements corrective actions for operational deviations; JTAB re-validates thresholds if data indicate mis-calibration; persistent or material deviations are packaged for JSC double-key decision, including proposals for threshold revision, additional testing, or suspension recommendations.

**Adaptation Trigger:** Any KPI deviation beyond pre-registered thresholds: false-negative rate >5% at 95% confidence; event-recording latency >5 minutes locally; cross-national synchronization >1 hour; divergence reconciliation >24 hours; unresolved discrepancy age >10 business days; unverifiable equipment >2 units per site or >1% of covered changes

### 3. Blind challenge and red-team exercise monitoring: track execution and outcomes of all six mandatory unannounced challenge types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal) to validate silent-window bounds, layered-evidence sufficiency, information-barrier effectiveness, and the credibility of the eventual Go/Modify/Stop evidence base.
**Monitoring Tools/Platforms:**

  - Challenge exercise design plan
  - Independent red-team reports
  - Blind-challenge results tracker by event type
  - No-advance-knowledge protocol compliance log
  - Exercise after-action reports

**Frequency:** After every challenge exercise; weekly cumulative review during Phase One; JTAB session within 72 hours of any exercise or material technical incident

**Responsible Role:** Joint Technical Assurance Board (JTAB) overseeing independent red teams

**Adaptation Process:** JTAB recommends technical procedure corrections, filter-rule adjustments, clean-room protocol changes, or additional test vectors when a challenge type is missed; if detection failures persist above the false-negative threshold, JTAB escalates to the JSC with a recommendation against a Go verdict.

**Adaptation Trigger:** Any blind-challenge miss or false negative; false-negative rate exceeding the 5% threshold at 95% confidence; evidence of red-team advance knowledge or compromised exercise independence; any challenge revealing that over-filtering hides substitution indicators

### 4. Budget envelope, funding timeliness, and fiscal compliance monitoring: track expenditure against the seven budget envelopes, envelope burn rates, escrow balance and drawdown approvals, quarterly USD reconciliation, CNY conversion windows and FX exposure, and contribution-release timing to prevent quiet fiscal vetoes and cost overruns.
**Monitoring Tools/Platforms:**

  - Envelope-level budget control system
  - Escrow reconciliation statements
  - Quarterly reforecast reports
  - Independent audit reports
  - Currency conversion and FX exposure tracker
  - Contingency drawdown request log

**Frequency:** Weekly burn-rate review by JPMO; quarterly reconciliation and independent audit by JAECC

**Responsible Role:** Joint Program Management Office (JPMO) with independent audit by the Joint Audit, Ethics, and Compliance Committee (JAECC) and JSC double-key approval for cross-envelope or contingency actions

**Adaptation Process:** JPMO reallocates within envelopes up to delegated thresholds; any expenditure above USD 10 million, cross-envelope transfer, or contingency drawdown requires JSC double-key approval; funding delays beyond the pre-agreed window are escalated as a KPI-visible suspension trigger; audit exceptions trigger corrective action plans.

**Adaptation Trigger:** Envelope burn rate exceeding forecast by 10%; contribution release delayed more than 10 business days; projected currency or inflation movement consuming more than the USD 500 million contingency reserve; audit exception, suspected fraud, or material fiscal misreporting

### 5. Consolidated risk register and mitigation effectiveness monitoring: maintain and review the consolidated risk register covering governance and deadlock, political continuity, regulatory and legal challenge, financial and currency, supply-chain and vendor refusal, information-barrier security, latency and silent-window, ledger divergence, matched-site parity, staffing, cyber and counterintelligence, red-team independence, schedule drift, operator reluctance, and cost-overrun risks.
**Monitoring Tools/Platforms:**

  - Consolidated risk register
  - Operational risk register (JPMO)
  - Strategic risk register (JSC)
  - Risk scoring and trend matrix
  - Escalation log

**Frequency:** Weekly by JPMO; monthly strategic review by JSC; ad hoc immediately upon any risk realization

**Responsible Role:** JPMO Chief Risk Officer with periodic review and risk-appetite decisions by the Joint Steering Council (JSC)

**Adaptation Process:** Risk owners update mitigation plans and assign corrective actions; risks crossing strategic thresholds are escalated to the JSC for risk-appetite decisions, additional mitigation resourcing, or activation of deadlock, suspension, or escalation procedures; mitigation effectiveness is re-scored after each action.

**Adaptation Trigger:** Risk likelihood or severity increase; identification of a new risk; realization of a top risk such as vendor-refusal cascade, information leak, funding delay, political discontinuity, or cross-border access breakdown

### 6. Information barrier, cybersecurity, and counterintelligence monitoring: continuously monitor information-barrier filter rules, bounded inspection zones, filtered workstations, clean-room protocols, physical and logical separation of national teams, insider-threat indicators, evidence integrity, and the security of the replicated ledger and secure facilities.
**Monitoring Tools/Platforms:**

  - JSCIB security monitoring dashboards
  - Information-barrier filter logs and audit trails
  - Penetration test reports
  - Insider-threat monitoring reports
  - Cyber-incident isolation drill after-action reports
  - Physical security and counterintelligence compliance checklists

**Frequency:** Continuous automated monitoring with weekly JSCIB review; immediate review upon any incident or threshold alert

**Responsible Role:** Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Adaptation Process:** JSCIB directs immediate isolation or evidence-preservation measures under the joint incident-response protocol; filter rules, zone boundaries, or clean-room configurations may be adjusted within JSC-approved policy, with any policy change escalated to the JSC for double-key approval; confirmed evidence-integrity compromises are escalated with a recommendation for automatic hold.

**Adaptation Trigger:** Confirmed IP or cyber incident compromising evidence integrity; critical penetration-test finding; insider-threat indicator; evidence that over-filtering has hidden substitution indicators or under-filtering has exposed protected workloads, model weights, source code, or security architecture

### 7. Discrepancy adjudication and materiality threshold monitoring: track all intake, maintenance, and exit discrepancies through the adjudication pipeline, monitoring materiality classification, unresolved discrepancy age, unverifiable-equipment counts per site, vendor-refusal outcomes, exit-disposition completion, and automatic-suspension triggers.
**Monitoring Tools/Platforms:**

  - Discrepancy tracking dashboard
  - Unresolved-discrepancy age metrics
  - Materiality classification log
  - Automatic-suspension trigger register
  - Vendor-refusal and exit-disposition trackers
  - Neutral arbiter referral log

**Frequency:** Daily during Phase One; immediately upon any material discrepancy or suspension trigger

**Responsible Role:** Joint Discrepancy Adjudication Panel (JDAP)

**Adaptation Process:** JDAP resolves routine discrepancies under delegated evidentiary rules; material findings are recommended to the JSC for double-key authorization; unresolved material discrepancies trigger automatic site-level suspension; deadlocked factual disputes are referred to the neutral technical arbiter; unresolved exits without assigned disposition within 48 hours trigger automatic site review.

**Adaptation Trigger:** Unresolved discrepancy age exceeding 10 business days; unverifiable equipment exceeding 2 units per site or 1% of covered changes; exit without an assigned disposition within 48 hours; JDAP deadlock on a material classification; vendor refusal exhausting the forced-evidence ladder

### 8. Reciprocal access parity and matched-site performance monitoring: monitor reciprocal access hours, verification outcomes, and inspection burden across each matched site pair to validate parity calibration and detect asymmetric access that would trigger a Stop condition.
**Monitoring Tools/Platforms:**

  - Parity scoring matrix (multi-attribute)
  - Reciprocal access-hour benchmarking tracker
  - Site-level verification outcome comparison reports
  - Stress-site exercise logs
  - Site fallback and disaster-response readiness records

**Frequency:** Weekly during Phase One; monthly during site-selection and readiness phases

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB)

**Adaptation Process:** JPMO rebalances inspection scheduling and site-pair assignments; JTAB recommends recalibration of the parity matrix if site characteristics diverge; evidence of asymmetric access or materially unequal verification difficulty is escalated to the JSC as a potential Stop trigger with a joint findings narrative.

**Adaptation Trigger:** Reciprocal access-hour asymmetry beyond the pre-agreed threshold; materially unequal verification outcomes across a matched pair; inability to verify a deliberately hard-to-inspect stress site; one government shielding an operator from access

### 9. Governance health and deadlock monitoring: monitor the functioning of double-key governance, including decision throughput, deadlock duration, impaired-confidence declarations, automatic-suspension activations, and compliance with the no-casting-vote and no-unilateral-overrule rules.
**Monitoring Tools/Platforms:**

  - Decision log and double-key sign-off matrix
  - Deadlock duration tracker
  - Escalation log to heads of state/party leadership
  - Impaired-confidence declaration register
  - Unilateral-action incident log

**Frequency:** Weekly during Phase One; monthly during the entry-condition phase; extraordinary session within 48 hours of an impaired-confidence declaration

**Responsible Role:** JSC Secretariat under the Joint Steering Council (JSC)

**Adaptation Process:** Deadlocked items are deferred under the pre-registered procedure while joint technical and legal bodies develop recommendations; if consensus still fails, the matter is escalated to heads of state or party leadership; automatic site-level suspension remains in effect for unresolved material discrepancies; protective suspension is scoped to affected activities upon impaired-confidence declaration.

**Adaptation Trigger:** Deadlock persisting beyond 10 business days; impaired-confidence declaration by either co-chair; any attempted unilateral finding, sanction, or decision; automatic-suspension activation at any site

### 10. Staffing, clearance, and workforce coverage monitoring: monitor staffing levels against the workload-based model, including 24/7 shift coverage, the 1.5x leave/backup multiplier, separation of duties, no-single-person-critical-function compliance, full-time surge cadre readiness, and clearance and common-training progress.
**Monitoring Tools/Platforms:**

  - Staffing model v1.0
  - Shift coverage and leave-backup schedules
  - Clearance initiation and completion tracker
  - Common training curriculum records
  - Surge cadre roster and deployment log
  - Separation-of-duties compliance matrix

**Frequency:** Weekly by JPMO; monthly certification of coverage ratios and readiness

**Responsible Role:** Joint Program Management Office (JPMO)

**Adaptation Process:** JPMO deploys the surge cadre, initiates cross-training, and adjusts shift assignments to close coverage gaps; clearance delays trigger parallel recruitment or secondment from national verification bodies; structural staffing shortfalls are escalated to the JSC with budget and timeline implications.

**Adaptation Trigger:** Any single-person critical function identified; coverage below the 1.5x backup multiplier; surge deployment exceeding the pre-agreed response window; clearance or training delays preventing a material event from being staffed by two full-time mirrored national inspectors

### 11. Covered-equipment schedule versioning and coverage-gap monitoring: track versioned updates to the confidential attribute-based covered-equipment schedule, fast-track provisional listings, sunset reviews, and any coverage gaps created by new equipment generations or architecture drift.
**Monitoring Tools/Platforms:**

  - Versioned confidential covered-equipment schedule
  - Versioned changelog
  - Fast-track provisional listing log
  - Sunset review calendar
  - Pre-registered dispute criteria register
  - Coverage-gap assessment reports

**Frequency:** Monthly and immediately upon either side fielding a new frontier-relevant equipment generation

**Responsible Role:** Accountable technical schedule custodians under the Joint Technical Assurance Board (JTAB) with JSC double-key approval for revisions

**Adaptation Process:** Technical custodians issue fast-track provisional listings within 48-72 hours to close coverage gaps; JTAB recommends schedule revisions with attribute-based justification; JSC applies double-key approval; unresolved definitional disputes are resolved by reference to the pre-registered interpretive annex rather than renegotiation.

**Adaptation Trigger:** New equipment generation fielded by either country; identified coverage gap that would allow covered equipment to ship outside verification; sunset review due; proposed schedule revision that reopens the bilateral definitional bargain

### 12. Audit, ethics, and KPI data-integrity monitoring: independently audit envelope-level expenditures, domestic operator and vendor compensation disbursements, KPI dashboard inputs against raw exercise logs and evidence records, compliance with information-barrier and data-protection requirements, conflict-of-interest declarations, and whistleblower complaints.
**Monitoring Tools/Platforms:**

  - Quarterly audit reports
  - KPI validation audit plan
  - Raw-data provenance and access protocols
  - Whistleblower channel and complaint log
  - Audit exception register
  - Conflict-of-interest declarations
  - Compensation disbursement audit schedule

**Frequency:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours of an audit exception, whistleblower complaint, data-protection breach, or suspected fraud

**Responsible Role:** Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JAECC issues audit exceptions, requires preservation of records and restricted access during investigations, and recommends protective holds, sanctions, or suspension to the JSC; unresolved exceptions trigger corrective action plans; material fraud or KPI misreporting is escalated as a Stop-level concern that must be resolved before any Go verdict.

**Adaptation Trigger:** Material fraud, corruption, or KPI misreporting; unresolved audit exception; data-protection or GDPR breach; whistleblower complaint requiring protective action; evidence that KPI dashboard inputs have been manipulated

### 13. Legal, interpretive, and cross-border access monitoring: monitor implementation of the binding bilingual glossary, interpretive annex, domestic access authority, model vendor-access agreements, and the standing inspector visa and customs annex, including visa processing times, customs clearance of diagnostic equipment, and any domestic legal challenges to inspector authority.
**Monitoring Tools/Platforms:**

  - Binding bilingual glossary and interpretive annex
  - Legal implementation tracker
  - Visa and customs clearance monitoring log
  - Domestic legal challenge log
  - Travel-and-clearance drill results
  - Export-control and customs compliance reports

**Frequency:** Weekly during the entry-condition phase; as needed during Phase One for legal or access incidents

**Responsible Role:** Joint Legal and Terminology Commission (JLTC)

**Adaptation Process:** JLTC issues legal opinions, updates model instruments, and coordinates with domestic authorities to resolve access barriers; unresolved interpretive disputes or legal challenges threatening inspector access are escalated to the JSC for double-key decision; any visa or customs delay is reported to the JPMO for latency-budget impact assessment.

**Adaptation Trigger:** Visa processing exceeding the 48-hour standing agreement; customs hold on diagnostic or challenge-exercise equipment; domestic legal challenge to foreign inspector authority; interpretive dispute not resolvable by the pre-registered annex; any access barrier that would break the 24-hour physical-confirmation window

### 14. Baseline inventory and asset-registry integrity monitoring: track completion and ongoing integrity of the joint baseline physical inventory and cryptographic asset registry of covered equipment at all six declared sites, including reconciliation of serialized records against operator procurement, maintenance, and disposal records, and full recounts at any site with unexplained discrepancies.
**Monitoring Tools/Platforms:**

  - Cryptographic asset registry
  - Baseline inventory audit checklists
  - Serialized-record reconciliation tracker
  - Full-recount trigger log
  - Operator procurement, maintenance, and disposal records
  - Asset-registry tamper-evidence monitoring

**Frequency:** Continuous during the entry-condition phase until joint certification; quarterly spot-check integrity reviews thereafter

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB) and audit by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO conducts full recounts and reconciliation drills for any site with unexplained serialized discrepancies; JTAB validates asset-registry integrity processes; unresolved baseline discrepancies block certification of that site and escalate to the JSC; any suspected tampering with the asset registry is treated as an evidence-integrity incident.

**Adaptation Trigger:** Unreconciled serialized discrepancy above 2% at any site; disputed initial inventory at proposed clock start; evidence of tampering with the cryptographic asset registry; inability to establish a trusted baseline for subsequent material-change verification

# Governance Extra

## Governance Validation Checks

1. 1. Completeness confirmation: All core requested governance components are present and structurally complete: the internal governance bodies (JSC, JPMO, JTAB, JSCIB, JLTC, JAECC, JDAP), the implementation plan with sequenced formation steps and dependencies, the decision/escalation matrix, and the monitoring/progress plan are all generated. The audit details from Stage 1 are also carried through consistently into the JAECC responsibilities and monitoring approach.
2. 2. Internal consistency check: The governance bodies defined in Stage 2 are used consistently in the Stage 3 implementation plan and Stage 5 monitoring plan. Decision rights in the escalation matrix respect the double-key, no-casting-vote, no-unilateral-overrule principle, and the monitoring plan assigns responsibilities to the correct bodies (e.g., JTAB for KPI validation, JAECC for data-integrity audits, JDAP for discrepancy adjudication, JSCIB for security/counterintelligence, JLTC for legal/interpretive issues). No direct contradictions were found among the stages.
3. 3. Gap in JSC composition and continuity: The JSC consists only of the two national co-chairs and a non-voting secretary. There is no defined deputy/succession arrangement for a co-chair vacancy and no formal mechanism for independent technical, legal, or security advice to reach the JSC during a final verdict decision. Given the political-continuity risk, this is a single-point vulnerability that should be addressed with explicit succession rules and a defined advisory-input channel.
4. 4. Gap in automatic-suspension mechanics: The framework uses 'automatic suspension' and 'protective hold' frequently, but the operational mechanics are under-specified: who physically activates the suspension, how the site/operator is notified, what evidence must be preserved, how long the suspension lasts before JSC double-key confirmation, and what evidence is required to lift it. The JDAP temporary administrative hold mentions 48-hour JSC confirmation, but the full suspension lifecycle needs a single, detailed procedure.
5. 5. Gap in delegated authority granularity: JPMO has clear thresholds (USD 10M per action and USD 25M per envelope reallocation), but workstream leads are said to have 'delegated authority' without defined limits or parameters. The delegated authority register is still at version 0.1/0.2 in the implementation plan and should be finalized with specific dollar/action thresholds, approval matrices, and prohibited actions to prevent inconsistent or uncontrolled delegation.
6. 6. Gap in conflict-of-interest and whistleblower depth: The JAECC is tasked with conflict-of-interest rules and a whistleblower channel, but the framework lacks specific recusal rules for co-chairs and committee members with national or operator ties, investigation timelines, anonymous reporting mechanisms, retaliation protections, and escalation paths for complaints involving senior government officials. These details are essential for a bilateral program where each government administers domestic compensation.
7. 7. Gap in escalation-matrix coverage: The decision/escalation matrix covers budget, cyber incidents, deadlocks, protocol changes, material discrepancies, vendor refusal, KPI threshold changes, entry-condition slippage, information-barrier conflicts, and fraud. However, it omits explicit issue types for unresolved interpretive/legal disputes escalating from the JLTC, impaired-confidence declarations, funding delays or withholding that do not fit the budget-request category, and operator obstruction escalating to materiality. These should be added with defined escalation and response SLAs.
8. 8. Gap in red-team independence assurance: The JTAB selects independent red-team providers and monitors a no-advance-knowledge protocol, but there is no described independent verification of red-team separation from the JPMO, site operators, or the covered-equipment schedule custodians. Given the collusion risk identified in the audit corruption list, the monitoring approach should include independent audit of red-team communications, financial flows, and exercise-scenario secrecy.
9. 9. Gap in change-control process: Protocol changes, KPI threshold revisions, and information-barrier policy changes are reserved to the JSC, but no formal change-control process is defined. The framework lacks guidance on change initiation, impact assessment, emergency changes, versioning, communication to operators and vendors, and how changes are tested before implementation. This is especially important for mid-Phase One technical adjustments.
10. 10. Gap in KPI statistical validation methodology: Provisional thresholds such as 5% false negatives at 95% confidence are listed, but the validation plan does not yet specify sample sizes, statistical power calculations, pre-registration of the analysis plan, handling of multiple challenge types, or how confidence intervals will be computed from limited red-team exercise data. Without this methodology, the thresholds remain contestable and the Go/Modify/Stop verdict could be challenged.

## Tough Questions

1. What is the current probability-weighted forecast for completing all ten entry conditions by 2027-Sep-04, and what specific contingency actions and spending decisions are triggered if domestic access authority or site selection slips beyond the two-month pre-deadline daily tracking window? Show the readiness-tracker closure rates by country.
2. Provide evidence that the pre-registered deadlock procedure has been stress-tested in a simulated co-chair deadlock. What was the measured time to reach a joint decision or escalate, and what prevents an impaired-confidence declaration from becoming a unilateral suspension?
3. If a dominant vendor refuses clean-room access at multiple sites simultaneously, what is the exact unverifiable-equipment count and materiality definition at which JDAP automatically recommends suspension, and has the forced-evidence ladder been exercised end-to-end with that vendor? What is the projected time from first refusal to disposition?
4. What is the latest validated false-negative rate from independent blind challenges, with confidence intervals, after information-barrier filtering? Which substitution indicators survived filtering, and how does the result compare with the pre-registered 5% at 95% confidence threshold?
5. Has the joint baseline physical inventory and cryptographic asset registry been completed at all six sites? What is the current serialized-record discrepancy rate per site, and what is the remediation plan for any site above the 2% recount threshold?
6. Demonstrate that the 48-hour visa and customs clearance pathway actually works: what was the measured time from inspector request to site access in the latest end-to-end travel-and-clearance drill, and which diagnostic tools and challenge equipment were pre-cleared?
7. Show the escrow balance, envelope burn rates, and projected inspectorate costs under a six-month entry-condition delay. What specific drawdown decisions have been made to avoid idle staffing costs consuming the $750M inspectorate envelope, and how is reciprocal funding parity being maintained?
8. What binding continuity commitments and escrow-return provisions are in the bilateral instrument if either country experiences a leadership transition during the entry-condition phase? Have transition briefings and track-II channels been established, and what is the estimated sunk-cost exposure if one government withdraws?
9. What is the exact process and timeline for lifting an automatic site-level suspension once imposed? Who can authorize resumption under double-key without unilateral override, what evidence must be produced, and how are the Phase One clock and KPI dashboard adjusted for the suspension period?
10. How has the JAECC validated that KPI dashboard inputs are not being manipulated? Provide the raw-data provenance audit trail for the last reported false-negative and latency metrics, and describe the independent verification method used before any Go/Modify/Stop verdict.

## Summary

The governance framework is structurally sound and well aligned with the Consortium's double-key, no-unilateral-overrule mandate: the body architecture is complete, the implementation sequence is dependency-aware, the escalation matrix preserves sovereign equality, and the monitoring plan assigns clear ownership across operational, technical, security, legal, audit, and adjudication functions. Its key strengths are the separation of strategic, operational, technical, security, legal, audit, and adjudication authorities, and the integration of deadlock, suspension, and KPI-driven escalation into a single governance fabric. The main areas requiring further hardening are the operational mechanics of automatic suspension, JSC continuity and advisory inputs, granular delegated authority, conflict-of-interest and whistleblower enforcement, change control, red-team independence assurance, and statistical validation of the KPI thresholds that will ultimately determine the credibility of the Go/Modify/Stop verdict.

# Related Resources

## Suggestion 1 - INF Treaty Verification Regime (1987-2019), including Votkinsk/Magna continuous portal monitoring and the Joint Compliance and Inspection Commission (JCIC)

The 1987 U.S.-Soviet Intermediate-Range Nuclear Forces Treaty (in force June 1, 1988) eliminated an entire class of ground-launched missiles (500-5,500 km range) and was verified through reciprocal baseline data declarations, on-site inspections at declared deployment, elimination, and production facilities, short-notice inspections, monitored eliminations, and 13 years of continuous portal perimeter monitoring at a named Soviet missile plant (Votkinsk) and a U.S. plant (Magna, Utah), with tamper-indicating enclosures over canisters and sensor-based evidence. Implementation disputes were handled by a standing bilateral commission (JCIC) operating on consensus. The regime functioned for three decades until U.S. withdrawal in August 2019 amid alleged Russian violations.

### Success Metrics

2,692 missiles eliminated by the June 1991 deadline (U.S. 846; Soviet 1,846) - verified whole-class elimination.
Thousands of on-site inspections (on the order of 4,000-5,000) conducted over roughly three decades under the regime.
13-year continuous portal monitoring at Votkinsk and Magna completed on schedule (ended May 31, 2001), including resolution of the canister-discrimination problem (distinguishing permitted SS-25 canisters from prohibited missile canisters).
JCIC resolved hundreds of implementation and interpretive questions over the treaty's life without a unilateral-overrule mechanism.
Cautionary outcome metric: the treaty ended in 2019 via withdrawal amid alleged violations - verification procedures survived; political support did not.

### Risks and Challenges Faced

Distinguishing permitted from prohibited canisters at Votkinsk could not be done visually; mitigated by tamper-indicating shrouds/enclosures plus portal sensors and weight checks - a direct lesson for attribute-based, versioned covered-equipment screening rather than product-anchored lists.
Short-notice cross-border inspection logistics (visas, manifests, equipment import) repeatedly strained timelines; mitigated by standing inspection infrastructure, pre-cleared visas, and pre-agreed equipment lists - the historical basis for the Consortium's inspector-access annex.
Interpretive disputes (notifications, geometry, counting rules) could have deadlocked; mitigated by routing everything through the JCIC with pre-agreed procedures and written consensus records - analogous to the Consortium's pre-registered interpretive annex and joint technical teams.
Political breakdown ultimately terminated the regime despite functioning procedures; lesson: verification cannot outrun politics, so continuity commitments, KPI-visible reciprocity metrics, and impairment-of-confidence machinery (already in the Consortium plan) must be treated as first-class controls, not afterthoughts.

### Where to Find More Information

U.S. Department of State INF Treaty Archive Collection: https://www.state.gov/inf-treaty-archive-collection/
Arms Control Association INF fact sheets and history: https://www.armscontrol.org/factsheets/INFtreaty
NTI treaty profile: https://www.nti.org/education-center/treaties-and-regimes/intermediate-range-nuclear-forces-inf-treaty/
OSTI.gov technical literature on Votkinsk portal monitoring and tamper-indicating systems: https://www.osti.gov

### Actionable Steps

Contact Sandia National Laboratories' Cooperative Monitoring Center (Albuquerque, NM), established in 1994 to develop and exercise cooperative monitoring technologies with foreign partners, including historical joint workshops with Chinese technical institutes; reach it via https://www.sandia.gov and request the CMC group.
Engage the Arms Control Association (Washington, DC) - Executive Director Daryl Kimball - via the contact form at armscontrol.org or LinkedIn, for INF implementation histories and practitioner referrals.
For the Russian-side practitioner perspective, contact the PIR Center (Moscow) via pircenter.org, which has published extensive INF verification analyses.
Request a briefing from the U.S. State Department Bureau of Arms Control, Verification and Compliance (AVC) via state.gov regarding INF lessons relevant to new verification instruments.

### Rationale for Suggestion

This is the closest existing bilateral precedent to the Consortium's architecture: reciprocal access at a matched set of declared production and deployment sites; continuous on-site presence at a named 'participating site' (Votkinsk); tamper-evident enclosures and sensor evidence layered with records; a pre-agreed baseline data exchange as an entry gate (analogous to the joint baseline inventory condition); short-notice arrival windows (analogous to latency budgets); and a joint commission that resolved implementation questions without either side overruling the other. Geographical proximity priority: no U.S.-China bilateral verification regime has ever existed, so the U.S.-Soviet record is the only completed template for sovereign-pair on-site verification and is included for that reason; its China-side gap is partially covered by items 3 and 6.
## Suggestion 2 - U.S.-Soviet Joint Verification Experiment (JVE), 1988

A bounded, reciprocal technical experiment agreed at the December 1987 Washington summit: a U.S. team deployed CORRTEX hydrodynamic measurement equipment at the Soviet Semipalatinsk nuclear test site (September 1988), while a Soviet team deployed instruments at the U.S. Nevada Test Site (August 1988), to measure underground test yields against the 150 kt Threshold Test Ban Treaty limit. Techniques, team sizes, data handling, access, and information protection were pre-agreed; only agreed derived data were exchanged, and the completed results directly enabled U.S. and Soviet ratification of the TTBT and PNET in 1990. Companion nongovernmental experiments (NRDC-Soviet Academy of Sciences seismic field tests, 1986-1990) tested joint monitoring at the same sites under an even looser but real reciprocal framework.

### Success Metrics

Both reciprocal experiments executed on schedule within the agreed 1988 windows at Semipalatinsk and the Nevada Test Site.
Measured yields proved consistent with declared values and the 150 kt limit, withstanding post-hoc scrutiny.
Directly credited with unblocking TTBT and PNET ratification (U.S. Senate consent October 1990; Soviet ratification the same period).
Established the template for later cooperative experiments, including the NRDC-Soviet Academy seismic tests and GSETT seismic exchanges.

### Risks and Challenges Faced

Exposure of classified test-site and weapon information was the central risk; mitigated by agreeing a single measurement technique per side, restricting what was measured and who was present, and exchanging only derived, protocol-defined data - a working proof that filtered-evidence boundaries survive real inspections when negotiated before the clock starts.
Asymmetric methodologies (U.S. hydrodynamic vs Soviet seismic/remote sensing) risked reciprocity complaints; mitigated by explicit acceptance of unequal techniques in exchange for equal access - precedent for the Consortium's negotiated parity rather than assumed symmetry.
Risk that results would contradict declarations and politically damage one side; mitigated by pre-registering the data-interpretation protocol before execution - the exact design of the Consortium's pre-registered thresholds and interpretive annex.

### Where to Find More Information

OSTI.gov - search 'Joint Verification Experiment' and 'CORRTEX' for LANL/LLNL/Sandia technical reports: https://www.osti.gov
DOE OpenNet declassified document database: https://www.osti.gov/opennet/
Arms Control Today archives (1988-1990) on JVE and TTBT ratification: https://www.armscontrol.org
NTI Threshold Test Ban Treaty profile: https://www.nti.org/education-center/treaties-and-regimes/threshold-test-ban-treaty-ttbt/

### Actionable Steps

Contact Lawrence Livermore National Laboratory's Global Security (arms control and verification) directorate via llnl.gov for JVE program histories and names of surviving participants.
Contact Los Alamos National Laboratory public affairs (lanl.gov) regarding CORRTEX development and JVE deployment teams.
Use the Nevada National Security Site (nnss.gov) history office for Nevada-side exercise documentation.
For accessible expert synthesis, contact Hans Kristensen, Director of the Nuclear Information Project at the Federation of American Scientists, via fas.org or LinkedIn.

### Rationale for Suggestion

JVE is the closest historical analogue to the Consortium's 90-day Phase One: a time-boxed operational test that began only after a signed instrument and explicit entry conditions, ran reciprocally at classified sites in both countries, protected sensitive information through strictly bounded measurement channels, and concluded with exchanged results and a political decision gating the next step (ratification, functionally a Go/Modify/Stop). Geographical proximity priority: no U.S.-China joint verification exercise has ever been conducted; JVE remains the only completed sovereign-pair joint measurement exercise at each other's most sensitive facilities, and is included despite the distance for that unique fit.
## Suggestion 3 - IAEA Safeguards, Additional Protocol, and Information-Barrier Technology (including the U.S.-Russia-IAEA Trilateral Initiative, c. 1996-2010)

The IAEA has verified declared nuclear material and equipment at state-declared facilities since 1957, under comprehensive (INFCIRC/153) and voluntary-offer agreements, with the 1997 Additional Protocol (INFCIRC/540) adding complementary and managed access. Its toolkit maps directly onto the Consortium: design information verification and physical inventory verification (trusted baseline), tamper-indicating and electronic seals (e.g., E2200, C1S), authenticated remote and unattended monitoring with bounded data transmission, and information barriers that let inspectors verify attributes without revealing classified or proprietary data - technology matured under the Trilateral Initiative to verify classified-form fissile material. China is an NPT nuclear-weapon state with a voluntary-offer safeguards agreement (INFCIRC/369, 1989) and a list of selected declared civilian facilities under safeguards.

### Success Metrics

Safeguards implemented in well over 180 states, with an annual Safeguards Implementation Report issuing state-level conclusions.
Containment and surveillance (seals, cameras, authenticated remote monitoring) operating continuously at hundreds of facilities worldwide for decades.
Trilateral Initiative produced working attribute-measurement-with-information-barrier prototypes that verified classified-form material without revealing design information - documented in IAEA symposium proceedings.
Post-1991 reforms (Additional Protocol, environmental sampling) after the Iraqi detection failure - a measured, documented detection-rate improvement over the declared baseline.

### Risks and Challenges Faced

Iraq 1991: the regime detected post-hoc, not in advance, because it was confined to declared sites; mitigated by broader legal access (Additional Protocol) - the reason the Consortium must state its scope honestly (monitored changes at declared sites only) and pre-register that limitation.
Managed access can hide the very indicators inspectors need; mitigated through guided-access protocols and information barriers calibrated by facility and event type, validated by repeated real inspections - the direct precedent for validating barrier rules in blind exercises before deployment.
Information barriers initially slowed inspections dramatically; mitigated by redesigning outputs to be attribute-only and time-bounded - precedent for budgeting latency for filtered evidence inside the Consortium's latency windows.
Politicization and budget pressure on conclusions; mitigated by transparent, published methodology and independent evaluation - the precedent for independent validation of the Consortium's KPI thresholds.

### Where to Find More Information

IAEA safeguards overview: https://www.iaea.org/topics/safeguards
IAEA Additional Protocol: https://www.iaea.org/topics/additional-protocol
IAEA INFCIRC/369 (China voluntary offer) via IAEA INFCIRC collection: https://www.iaea.org/publications
NTI and CNS profiles of the Trilateral Initiative: https://www.nti.org ; https://nonproliferation.org

### Actionable Steps

Request a technical briefing from the IAEA Department of Safeguards (Division of Technical Support: seals, remote monitoring, information barriers) via OfficialMail@iaea.org.
Contact VERTIC (London) at info@vertic.org for verification legal implementation, information-barrier literature, and inspector-training curricula.
Engage the James Martin Center for Nonproliferation Studies (Monterey) - founding director Dr. William Potter - via nonproliferation.org for Trilateral Initiative documentation and China-IAEA history.
Search LinkedIn for current and former IAEA Department of Safeguards staff in the Division of Technical Support and approach with a concise, specific briefing request on information-barrier validation exercises.

### Rationale for Suggestion

This is the primary methodological source for four Consortium levers: baseline inventory as a certification gate (PIV/DIV), equipment identity via seals and identifiers, tamper-evident authenticated evidence transmission (the functional analogue of the Consortium's replicated ledger with hash commitments), and information barriers proving attributes without exposing protected data (the filtered-evidence architecture). Critically for the geographic-proximity priority, this is the major regime that includes China as a verified state and decades of IAEA operating history at Chinese facilities, making it the most China-proximate verification body in existence; the U.S.-side equivalents (safeguards under the U.S. voluntary offer, e.g., at selected enrichment and reactor facilities) complete the bilateral picture the Consortium needs.
## Suggestion 4 - CTBTO On-Site Inspection Integrated Field Exercises (IFE08, Kazakhstan, 2008; IFE14, Jordan, 2014) [SECONDARY SUGGESTION]

The Comprehensive Nuclear-Test-Ban Treaty Organization (Vienna, 1996-present) has repeatedly tested its on-site inspection concept through full-scale field exercises with dozens of participating states: IFE08 at the former Semipalatinsk test site (Kazakhstan, 2008) and IFE14 near the Dead Sea, Jordan (November 2014; roughly 250 experts from about 50 states over approximately three weeks). Exercises rehearsed the complete inspection lifecycle - inspection-area designation, point design, managed access, information barriers, overflights, radionuclide laboratory workflows - with controlled true events and injected false leads, and produced published after-action findings. China participates in the CTBTO and hosts International Monitoring System facilities.

### Success Metrics

IFE14 executed within its planned multi-week window with ~50 participating states and hundreds of simulated measurement events, both genuine and injected false positives.
Published, reusable OSI planning protocols, checklists, and lessons-learned documents.
IMS of 300+ certified facilities transmitting authenticated data to the International Data Centre on an operational schedule.

### Risks and Challenges Faced

Over-filtering by information barriers was found to strip contextual indicators; mitigated by iterative re-design of barrier rules between exercises - the direct precedent for the Consortium's requirement to validate barrier rules in blind runs before deployment.
Multinational logistics (visas, equipment import, host-state access) dominated planning effort; mitigated by pre-cleared manifests and host-state annexes - matching the Consortium's inspector-access annex.
The OSI Operational Manual remains unadopted because the treaty is not in force; mitigated by an exercise-first strategy keeping capability alive - precedent for marking the Consortium's provisional/TBD KPI thresholds and validating them operationally rather than on paper.

### Where to Find More Information

CTBTO verification regime and OSI pages, including IFE14 reporting: https://www.ctbto.org
VERTIC on-site inspection resources: https://www.vertic.org

### Actionable Steps

Contact the CTBTO Preparatory Commission's On-Site Inspection Division in Vienna at info@ctbto.org and request IFE14 after-action documentation.
Approach CTBTO Executive Secretary Robert Floyd's office for briefings on multinational exercise design via ctbto.org.

### Rationale for Suggestion

The best available real-world template for the Consortium's mandatory blind-challenge program and its bounded-mission rhythm (OSI is designed as a 60-70 day exercise window, structurally similar to the 90-day Phase One), including how information barriers and managed access perform with real multinational teams and how hundreds of discrete observations aggregate into a defensible post-exercise report.
## Suggestion 5 - New START Bilateral Inspection Regime (2011-2023; term ended at latest February 5, 2026) [SECONDARY SUGGESTION]

The most recent reciprocal, quota-based on-site inspection regime between equal sovereigns: biannual data exchanges, baseline data on declared strategic facilities, unique identifiers on deployed launchers, up to 18 short-notice inspections per year per side (10 Type One, 8 Type Two), up to five telemetry exchanges per year, and a standing Bilateral Consultative Commission. Inspections were paused in March 2020 due to COVID-19; Russia suspended participation in February 2023 without formally withdrawing; the treaty's maximum term (after its single extension) ran to February 5, 2026.

### Success Metrics

More than 300 on-site inspections conducted under parity quotas from 2011 until the 2020 pause.
Facilities database and baseline data exchanges maintained on schedule for roughly a decade.
Bilateral Consultative Commission resolved implementation questions for years without unilateral overrule.
Cautionary outcome: inspections frozen 2020, participation suspended 2023, regime lapsed by February 2026 without replacement - political continuity, not technique, was binding.

### Risks and Challenges Faced

COVID-19 forced a total inspection halt while the clock ran; mitigated partially by continued data exchanges - lesson: build public-health and disruption contingencies into any fixed 90-day operational window.
Russia's 2023 'suspension' created a gray zone of non-performance short of withdrawal; lesson: the Consortium's pre-registered automatic-suspension triggers and KPI-visible contribution-delay thresholds are the correct antidote and should be exercised in drills, not left theoretical.
Telemetry-access disputes tested what counts as credible detection; lesson: define evidence-class independence and detection thresholds before the clock starts, as the Consortium's layered-evidence lever specifies.

### Where to Find More Information

U.S. State Department New START pages: https://www.state.gov/new-start/
Arms Control Association New START fact sheets: https://www.armscontrol.org/factsheets/NewSTART
PIR Center analyses of New START implementation: https://pircenter.org

### Actionable Steps

Request implementation lessons from the U.S. State Department Bureau of Arms Control, Verification and Compliance via state.gov.
For the Russian-side practitioner view on suspension mechanics and inspection parity, contact the PIR Center (Moscow) via pircenter.org.
Follow Arms Control Association (Daryl Kimball) via LinkedIn for ongoing analysis of the post-New START verification landscape.

### Rationale for Suggestion

The clearest modern demonstration of both the strengths and failure modes of exactly the Consortium's structure - matched declared facilities, parity quotas, unique equipment identifiers, and a standing joint commission - and the most recent cautionary tale on quiet suspension without formal exit, pandemic interruption of a fixed verification clock, and political discontinuity, which the Consortium plan already treats via automatic-suspension triggers and funding-timeliness KPIs.
## Suggestion 6 - OPCW Verification Regime: Industrial Confidentiality Annex and OPCW-Verified Destruction of Japanese Abandoned Chemical Weapons at Declared Sites in China [SECONDARY SUGGESTION]

The Chemical Weapons Convention (in force 1997; 193 member states) operates the only permanent verification organization conducting routine industry inspections under a strict Confidentiality Annex protecting proprietary and industrial information, plus never-invoked Article IX challenge-inspection provisions. Since roughly 2000, the OPCW has also verified the recovery and destruction of Japanese abandoned chemical munitions at declared sites in China (e.g., the Haikou mobile destruction operation beginning 2014, and the large Haerbaling burial site in Dunhua, Jilin), with Japanese-funded teams, Chinese managed access and escort, and OPCW on-site verification - foreign inspectors working continuously at declared Chinese sites under tight information controls for over two decades.

### Success Metrics

Tens of thousands of abandoned chemical munitions recovered, documented, and destroyed under OPCW verification at Chinese sites.
Decades of industrial inspections worldwide conducted under the Confidentiality Annex without major leakage incidents.
Institutional credibility recognized by the 2013 Nobel Peace Prize.
Cautionary metric: Article IX challenge inspections have never been invoked in nearly three decades - escalation that is never exercised atrophies.

### Risks and Challenges Faced

Repeated deadline slips in abandoned-weapons destruction were absorbed by revised milestones and mobile destruction technology rather than regime collapse; lesson: build re-phasing and recovery into the Consortium's fixed clock and contingency envelope instead of brittle all-or-nothing deadlines.
Simultaneously protecting state secrets and industrial proprietary data; mitigated by tiered confidentiality handling with designated, credentialed information handlers - the direct operational precedent for the Consortium's filtered workstations and clean-room examination.
Deterrence paradox of a never-used challenge mechanism; lesson: the Consortium's mandatory live challenge types (including vendor refusal and delayed access) exist precisely to prevent this atrophy and should remain non-negotiable entry conditions.

### Where to Find More Information

OPCW annual reports, verification pages, and abandoned-chemical-weapons documentation: https://www.opcw.org
Japan MOFA pages on abandoned chemical weapons in China: https://www.mofa.go.jp (search 'abandoned chemical weapons')
CNS resources on OPCW verification: https://nonproliferation.org

### Actionable Steps

Request a briefing from the OPCW Verification Division via the contact portal at opcw.org, specifically on Confidentiality Annex implementation and managed-access procedures.
Contact Japan's Cabinet Secretariat/MOFA abandoned-chemical-weapons office (via mofa.go.jp) for the operator-side experience of running verified destruction at Chinese sites.
For the China-side perspective, route through China's MFA arms-control department via official channels in Beijing.

### Rationale for Suggestion

The most China-proximate on-site verification precedent available: two decades of foreign-verified operations at declared Chinese sites with managed access, escorted movement, joint national teams, and dual protection of state and industry secrets - directly relevant to Consortium site operations in the Beijing/Hebei and Guizhou regions. The Confidentiality Annex is the strongest existing legal-operational model for filtered evidence around proprietary technology, and the never-exercised challenge mechanism is a cautionary precedent for the Consortium's requirement to live-exercise its discrepancy escalation.
## Suggestion 7 - UK-Norway Initiative and the International Partnership for Nuclear Disarmament Verification (IPNDV) - Cross-National Verification Exercises with Information Barriers [SECONDARY SUGGESTION]

The UK-Norway Initiative (established mid-2000s, main program roughly 2006-2012 with follow-on cooperation) developed and exercised disarmament-verification methods between a nuclear-weapon state and a non-nuclear-weapon state, using mock sensitive equipment and formal information barriers so that inspectors without clearance could verify attributes without exposure to design information; lessons were published. IPNDV (launched 2015; 25+ states) institutionalized working groups and practical exercises (tabletop and technical, 2017-2022) on dismantlement verification, information barriers, and joint-team procedures.

### Success Metrics

Multiple completed cross-national exercises with published after-action lessons adopted into IPNDV and IAEA discussions.
Working attribute-only information-barrier outputs demonstrated with real (mock-equipment) inspection teams.
IPNDV's 25+ state membership sustained across multiple multi-year phases, including states from both sides of Cold War divides.

### Risks and Challenges Faced

Information barriers initially slowed inspections severely; mitigated by redesigning to attribute-only outputs and time-boxed procedures - lesson: the Consortium must budget latency explicitly for filtered evidence within its 4h/24h/1h windows.
Legal and clearance asymmetry between national teams caused procedural friction; mitigated by common training and jointly approved procedures before exercises - lesson: mirrored training is a pre-clock certification item, as the Consortium plan already requires.

### Where to Find More Information

UK government publications on the UK-Norway Initiative: https://www.gov.uk (search 'UK-Norway Initiative verification')
IPNDV working group outputs and exercise reports: https://ipndv.org
VERTIC verification training resources: https://www.vertic.org

### Actionable Steps

Contact the IPNDV secretariat via the U.S. State Department Bureau of Arms Control, Verification and Compliance (state.gov) for exercise curricula and participant referrals.
Contact VERTIC at info@vertic.org for UKNI documentation and verification-training materials.
For the Norwegian side, contact the Norwegian Radiation and Safety Authority (DSA) via dsa.no, which participated in UKNI work.

### Rationale for Suggestion

The best-documented real experiments for the Consortium's defining trade-off: cross-national teams verifying hardware they are explicitly barred from understanding, with published exercise curricula the Consortium can reuse directly for mirrored-team training, information-barrier calibration, and blind-challenge design.

## Summary

There is no direct U.S.-China bilateral on-site verification precedent, so this recommendation set triangulates across the closest real-world families of projects, and explicitly justifies the geographic distance where necessary. (1) The U.S.-Soviet Joint Verification Experiment (JVE, 1988) is the single closest analogue to the Consortium's 90-day Phase One: a bounded, entry-condition-gated, reciprocal operational test with pre-agreed techniques, protected information, exchanged validated data, and an end decision that gated the next political step. (2) The INF Treaty verification regime (1987-2019) is the only fully tested sovereign-pair template for continuous presence at matched declared production sites, tamper-evident enclosures, baseline data exchange, short-notice arrival windows, and a standing joint commission without a casting vote. (3) IAEA safeguards and the Additional Protocol - including the Trilateral Initiative's attribute-measurement-with-information-barrier prototypes - supply the methodological core for baseline inventories, seals/identifiers, authenticated evidence transmission, and filtered evidence that proves attributes without exposing protected data; China is itself a verified IAEA state, making this the most China-proximate methodological source. Secondary references: CTBTO's Integrated Field Exercises (blind-challenge template), New START (reciprocal quota inspections and a cautionary tale on quiet suspension and political discontinuity), the OPCW regime including Japanese abandoned-chemical-weapons verification at declared sites in China (foreign inspectors on Chinese soil, industrial confidentiality, never-exercised escalation), and the UK-Norway Initiative/IPNDV (cross-national teams verifying hardware they are barred from understanding). The recurring lesson across all seven: technique is solvable; entry-condition discipline, tested information barriers, reciprocity metrics, and political-continuity machinery are the decisive variables - exactly the tensions the Consortium's levers target.

# Data Collection

## 1. Baseline Covered-Equipment Inventory and Cryptographic Asset Registry

A trusted baseline inventory is the foundation of all material-change verification; without an agreed starting state, every subsequent change claim is unverifiable and the false-negative threshold cannot be meaningfully assessed.

### Data to Collect

- Total covered equipment units at each of six declared sites by type, manufacturer, serial number, location, and operational status
- Existing operator procurement, maintenance, and disposal records for reconciliation
- Unexplained serialized discrepancy rate per site and root-cause categories
- Resource-loaded schedule and cost estimate for completing physical inventory audits before the Phase One clock starts

### Simulation Steps

- Build a synthetic inventory dataset of roughly 50,000 units with known serialization errors using Python pandas and NumPy; run reconciliation algorithms to estimate discrepancy detection thresholds
- Prototype the cryptographic asset registry using a hash-chained ledger approach in SQLite or Hyperledger Fabric and simulate serialization and count audits to test reconciliation workflows
- Run a Monte Carlo simulation in R or Python to estimate the probability of achieving no more than 2% unexplained discrepancy across all sites under varying data-quality assumptions

### Expert Validation Steps

- Consult IAEA safeguards physical inventory verification specialists and a hardware assurance auditor from a national laboratory to validate inventory methods and discrepancy thresholds
- Engage data center lifecycle experts and operator compliance officers to review feasibility of serialization and reconciliation at real facilities

### Responsible Parties

- Joint Baseline Inventory Task Force
- Hardware Identity and Evidence Integrity Technical Lead
- Datacenter Site Preparation and Cross-Border Logistics Manager
- Operator and Vendor Compliance Liaison

### Assumptions

- **High:** All covered equipment at declared sites can be physically inventoried and serialized before the clock starts.
- **Medium:** No more than 2% unexplained serialized discrepancy is an achievable and meaningful certification threshold.
- **Medium:** Operator records are sufficiently complete and reliable to reconcile physical counts.

### SMART Validation Objective

By 2027-08-01, complete and jointly certify a baseline physical inventory at all six declared sites with 100% of covered units serialized and reconciled in the cryptographic asset registry and no site exceeding 2% unexplained serialized discrepancy.

### Notes

- Estimated validation cost: USD 20-60 million if reconciliation takes four to eight weeks across six sites; charge to the site preparation envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include actual site counts, floor plans, and vendor records; uncertainties are dominated by operator record quality and physical access constraints.


## 2. KPI Threshold and Statistical Test Design

Unsupported KPI thresholds would make the Go/Modify/Stop verdict a political negotiation rather than a defensible verification finding; statistical power and pre-registered analysis rules must be validated before any Go decision.

### Data to Collect

- Number of feasible independent blind challenge events per material-event category within a 90-day, six-site window
- Provisional false-negative and false-positive detection rates from pilot exercises and historical treaty verification exercises
- Confidence-interval calculations for proposed thresholds under varying sample sizes, including the rule of three
- Pre-registered analysis rules for handling unresolved, censored, and contested events

### Simulation Steps

- Use R pwr package and Python statsmodels to compute required sample sizes and confidence bounds for a false-negative rate no greater than 5% at 95% confidence under binomial sampling
- Build a 90-day challenge schedule simulator in Python using SimPy or a custom Monte Carlo model to test whether the required number of independent challenge events can be injected across six sites without cross-contamination
- Run a pre-registered analysis plan on synthetic outcome data in Jupyter or R Markdown to verify that thresholds cannot be moved after results are known

### Expert Validation Steps

- Consult an independent verification statistician from a national laboratory or a recognized arms-control verification methodology group such as VERTIC or IPNDV
- Review the test design with a Treaty Verification and Managed Access Specialist and former INF or CTBTO exercise designers to confirm event definitions and blinding controls

### Responsible Parties

- Independent Red Team and Challenge Exercise Director
- Independent verification statistician
- Joint Technical Teams
- KPI Dashboard Owner

### Assumptions

- **High:** A 90-day, six-site test can support the required number of independent challenge events to substantiate a 5% false-negative claim at 95% confidence.
- **Medium:** Material-event categories can be independently blinded without cross-site contamination.
- **Medium:** Materiality corridors can be pre-registered before operational data exist.

### SMART Validation Objective

By 2027-02-28, approve a pre-registered Test and Evaluation Master Plan specifying challenge event counts, confidence-interval methods, false-positive definitions, and materiality corridors; by 2027-06-30, complete pilot blind challenges at at least two sites with reported confidence intervals.

### Notes

- Estimated validation cost: USD 1-3 million for statistical consulting, pilot challenge execution, and analysis; charge to the testing envelope.
- If 60 independent events per category is infeasible, explicitly reduce the claim to a reported detection rate with confidence intervals rather than asserting 5% at 95% confidence.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty remains in event denominators, false-positive costs, and aggregation rules across sites and event types.


## 3. Information Barrier and Filtered Evidence Validation

Over-filtering can hide substitution evidence and under-filtering can leak sovereign technology; the information barrier must be empirically validated in blind challenges before deployment.

### Data to Collect

- Metadata survival rates after filtering for each evidence class, including serial numbers, cryptographic hashes, and contextual indicators
- Substitution detection sensitivity in blind trials with filtered versus unfiltered evidence
- Leakage incident counts and types during validation exercises
- Latency added to evidence processing by barrier and clean-room procedures

### Simulation Steps

- Build a filtered workstation prototype using Python, OpenCV, or Apache Tika to strip customer data and workload details from synthetic inspection evidence while measuring preservation of identity metadata
- Use Docker or GNS3 network emulation to simulate zone routing and filter rules; test detection algorithms on synthetic substitution datasets
- Use Chaos Engineering tools such as Chaos Mesh to simulate evidence-flow failures and measure impact on detection latency and evidence integrity

### Expert Validation Steps

- Engage an Information Barrier and Counterintelligence Engineer and former IAEA or CTBTO information-barrier practitioners to review filter rule sets
- Validate with an independent red team experienced in adversarial concealment to confirm that substitution indicators survive filtering

### Responsible Parties

- Information Barrier and Counterintelligence Security Director
- Hardware Identity and Evidence Integrity Technical Lead
- Independent Red Team and Challenge Exercise Director
- Accredited Clean-Room Examiner Accreditation Body

### Assumptions

- **High:** Filter rules can be versioned and validated before evidence flows.
- **High:** Identity metadata can be preserved while stripping protected data.
- **Medium:** Blind challenges can reveal barrier misconfiguration without compromising classified information.

### SMART Validation Objective

By 2027-06-30, run at least two blind challenge sets demonstrating substitution detection sensitivity within 10% of the unfiltered baseline and zero evidence-integrity-compromising leaks, with all filter rules versioned and approved.

### Notes

- Estimated validation cost: USD 15-40 million for hardware-separated filtered workstations, clean-room facilities, and blind exercises; charge to the facilities and cyber envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include real workload distributions and contextual metadata patterns; over-filtering risk remains the largest technical uncertainty.


## 4. Latency and Replicated Ledger Performance

Credible detection is ultimately a latency claim; if local recording, synchronization, or reconciliation targets cannot be met, the silent window becomes a concealment corridor and the Go verdict loses meaning.

### Data to Collect

- Local event recording latency, cross-national synchronization latency, and divergence reconciliation time under normal and failure conditions
- Silent-window metrics from unannounced arrival and substitution simulations
- Network outage, node failure, and tamper response times
- Penetration test results from at least two independent firms

### Simulation Steps

- Deploy a replicated ledger prototype using Hyperledger Fabric or Tendermint/Cosmos SDK in Docker or Kubernetes with two national nodes; generate 5,000 synthetic events using Apache JMeter or k6 and measure latency percentiles
- Use ns-3 or Mininet to simulate cross-border network delays and partition scenarios; test divergence reconciliation algorithms under injected faults
- Run fault-injection drills with Chaos Mesh to measure recovery time when a national node fails or network connectivity is lost

### Expert Validation Steps

- Consult a Replicated Ledger and Attestation Architect and distributed systems engineers with treaty verification experience
- Validate with CTBTO or IAEA remote monitoring experts on tamper-evidence, authenticated transmission, and synchronization standards

### Responsible Parties

- Hardware Identity and Evidence Integrity Technical Lead
- Replicated Ledger and Attestation Architect
- Joint Network Operations Team

### Assumptions

- **High:** Local-first recording can achieve less than 5 minutes at production datacenter scale.
- **High:** Cross-national synchronization within 1 hour is achievable without exposing sensitive data through continuous hash-commitment exchange.
- **Medium:** Divergence can be detected and reconciled within 24 hours under realistic failure scenarios.

### SMART Validation Objective

By 2027-05-31, demonstrate in a prototype with at least 5,000 synthetic events that 99th percentile local recording latency is under 5 minutes, cross-national synchronization is under 1 hour, and divergence reconciliation is under 24 hours under injected failure scenarios.

### Notes

- Estimated validation cost: USD 5-15 million for prototype development, independent penetration testing, and load testing; charge to the ledger envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainties include cross-border network quality, hardware security module performance, and the behavior of hash-commitment exchange under adversarial conditions.


## 5. Matched-Site Parity and Reciprocal Access Benchmarking

Site pairing determines whether the asymmetric-access Stop trigger is meaningful or a diplomatic artifact; paper parity must be tested against real facility differences.

### Data to Collect

- Site attributes including declared equipment value, operational role, total capacity, physical layout, security constraints, vendor coverage, grid reliability, and climate risk
- Reciprocal access hours achieved in drills and inspections for each matched pair
- Stress-site inspection difficulty scores and root-cause drivers
- Fallback site pre-qualification data for two sites per country

### Simulation Steps

- Build a multi-attribute parity matrix in Excel or Python pandas with weighted attributes; run sensitivity analysis to test how different weightings affect parity ratios
- Use Monte Carlo simulation in Python to model likely variance in reciprocal access hours and determine whether the 0.9-1.1 tolerance band is achievable
- Use QGIS or ArcGIS to map site locations, grid routes, and logistics constraints for inspection access modeling

### Expert Validation Steps

- Engage INF and New START inspection practitioners and a Treaty Verification and Managed Access Specialist to validate parity metrics
- Consult local grid and environmental regulators and the Datacenter Site Preparation Manager to verify N+1 power and 99.9% uptime feasibility

### Responsible Parties

- Datacenter Site Preparation and Cross-Border Logistics Manager
- Matched-Site Parity Calibration Working Group
- Equal National Co-Chairs
- Local Permitting and Grid Authorities

### Assumptions

- **High:** Six matched sites can be selected with sufficiently comparable inspection burden.
- **Medium:** An access-hours ratio between 0.9 and 1.1 is a meaningful and achievable parity tolerance.
- **Medium:** Deliberately dissimilar stress sites can be included without making parity negotiation impossible.

### SMART Validation Objective

By 2027-04-30, approve a multi-attribute parity matrix for the six declared sites, complete reciprocal access benchmarking for at least two matched pairs in live drills, and pre-qualify two fallback sites per country.

### Notes

- Estimated validation cost: USD 5-10 million for site surveys, fallback pre-qualification, and access benchmarking; charge to the site preparation envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include exact facility floor plans, vendor contracts, and grid reliability histories; parity should measure verification equivalence, not just paper attributes.


## 6. Legal and Regulatory Feasibility

Without enforceable legal authority and a defined legal personality, no entry condition can be certified and the program remains a diplomatic handshake rather than a legal regime.

### Data to Collect

- Legal-form options for the bilateral instrument and Consortium legal personality
- Domestic authority requirements and enactability timelines in both the United States and China
- Escrow legality, appropriation feasibility, export-control, customs, visa, and data-transfer constraints
- Privileges and immunities, liability, indemnity, and cross-waiver models from existing verification regimes

### Simulation Steps

- Run governance war-game tabletop exercises using structured scenario software such as DecisionWise or Miro with decision trees to simulate deadlock and automatic suspension outcomes
- Use Lucidchart or Draw.io to map legal-form decision trees and a conflict-of-laws matrix for each evidence and data class
- Create a legislative timeline model in Microsoft Project or Smartsheet to simulate dependencies and slip impact on the 2027-09-04 certification boundary

### Expert Validation Steps

- Consult US-China bilateral treaty counsel, constitutional lawyers, export-control attorneys, and national-security legal advisors from both governments
- Obtain formal written legal opinions from the U.S. State Department and DOJ and from Chinese MOFA and legislative-affairs bodies on domestic access authority, escrow feasibility, and data-transfer restrictions

### Responsible Parties

- Bilateral Governance and Legal Implementation Lead
- Joint Legal Task Force
- Fiscal Escrow and Independent Audit Controller
- Customs, Visa, and Border Authorities

### Assumptions

- **High:** A legal form can be found that allows the Consortium to hold escrow funds, employ staff, and own evidence systems.
- **High:** Domestic implementing legislation can override conflicting private-law objections.
- **High:** An inspector visa and customs annex with 48-hour processing is negotiable and exercisable.

### SMART Validation Objective

By 2026-12-18, deliver a legal-form memorandum, bilateral instrument outline, model implementing legislation, and inspector-access annex draft; by 2027-03-31, obtain formal legal opinions from both governments on all mandatory legal entry conditions.

### Notes

- Estimated validation cost: USD 30-80 million for legal drafting, legislative outreach, formal opinions, and the travel-and-clearance drill; charge to the legal and audit envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty is highest around constitutional limits on search and seizure, private-property objections, and cross-border transfer of protected data.


## 7. Vendor and Operator Compliance and Forced-Evidence Ladder

A single dominant vendor refusal can cascade across every site it serves and convert a local finding into a systemic Stop condition; the ladder and access agreements must be validated in advance.

### Data to Collect

- Vendor cooperation status and refusal likelihood for each manufacturer, maintenance provider, and logistics company serving declared sites
- Time-to-disposition for each forced-evidence ladder step: vendor-supervised testing, filtered evidence, clean-room examination, and accredited independent examiner
- Unverifiable equipment counts and proximity to the per-site threshold of 2 units or 1% of covered changes
- Operator access-delay incident counts and root causes

### Simulation Steps

- Build a discrete-event simulation in Python SimPy or Arena to model vendor refusal cascades across multiple sites and their effect on latency and materiality counts
- Use Monte Carlo simulation in R to estimate the probability of exceeding the unverifiable-equipment threshold under varying vendor refusal scenarios
- Prototype the vendor-access agreement workflow in a contract management system such as DocuSign CLM to simulate pre-negotiation bottlenecks before clock start

### Expert Validation Steps

- Consult a hardware assurance auditor, the Operator and Vendor Compliance Liaison, and OPCW managed-access experts to validate the forced-evidence ladder
- Engage dominant manufacturers and maintenance providers in structured interviews to assess willingness, legal constraints, and clean-room access feasibility

### Responsible Parties

- Operator and Vendor Compliance Liaison
- Datacenter Site Preparation and Cross-Border Logistics Manager
- Bilateral Governance and Legal Implementation Lead
- Accredited Clean-Room Examiner Accreditation Body

### Assumptions

- **High:** Model vendor-access agreements can be negotiated with dominant vendors before the clock starts.
- **High:** Clean-room examination can provide sufficient evidence without exposing proprietary source code.
- **Medium:** Cross-trained inspectors can perform vendor-supervised diagnostics without the vendor's active cooperation.

### SMART Validation Objective

By 2027-05-31, execute model vendor-access agreements with at least 90% of vendors serving declared sites and complete two live vendor-refusal challenge exercises demonstrating ladder time-to-disposition within the latency budget.

### Notes

- Estimated validation cost: USD 5-15 million for legal negotiation, examiner accreditation, and live exercises; charge to testing and site preparation envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Missing data include dominant vendor participation status, export-control constraints, and the time required for each forced-evidence ladder step.


## 8. Staffing and Workforce Feasibility

Staffing gaps create single points of failure, invalidate evidence collection, and break reciprocal parity; clearance and talent scarcity are likely schedule drivers.

### Data to Collect

- Security clearance lead times and applicant pipeline for approximately 450 FTE in both countries
- Bilingual technical talent availability and loaded annual cost rates
- Achievable shift coverage, leave backup, separation-of-duties, and surge cadre ratios
- Recruitment, training, and retention projections against the 12-month entry-condition window

### Simulation Steps

- Build a workforce optimization model in Python using PuLP or OR-Tools to minimize staffing cost while meeting 24/7 coverage, 1.5x leave multiplier, separation-of-duties, and 10% surge requirements
- Run Monte Carlo simulation in Python to estimate the probability that clearance and recruitment delays prevent certification by 2027-09-04
- Use HR analytics software such as Workday or a custom Python model to simulate attrition and retention scenarios under surge deployment

### Expert Validation Steps

- Consult a Bilingual Inspectorate Workforce Planner and security clearance pipeline specialists from both governments
- Engage national verification bodies such as NNSA or IAEA training units to validate staffing workload formulas and training curricula

### Responsible Parties

- Mirrored Inspectorate Operations Director
- Bilingual Training, Translation, and Readiness Certification Coordinator
- Human Resources Leads from Both Governments

### Assumptions

- **High:** Approximately 450 FTE can be recruited, cleared, and trained within 12 months.
- **Medium:** A permanent full-time surge cadre of 10% of baseline is affordable within the USD 750 million inspectorate envelope.
- **Medium:** No single-person critical functions can be avoided with available bilingual technical talent.

### SMART Validation Objective

By 2027-07-31, fill and clear at least 90% of required inspectorate FTE, complete common training for all personnel, and demonstrate in a tabletop exercise that no single-person critical functions exist.

### Notes

- Estimated validation cost: USD 75-150 million in additional premium costs if clearance delays and talent scarcity require expedited hiring; charge to inspectorate and contingency envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- Uncertainty is high on security-clearance lead times, bilingual technical talent supply, and loaded-cost estimates; begin clearances immediately.


## 9. Fiscal Escrow and Currency Risk Validation

Delayed or asymmetric disbursement can act as a quiet veto that starves the program without formally triggering the withholding-funding Stop condition; currency shocks can consume the contingency envelope before testing is complete.

### Data to Collect

- Legal feasibility of full pre-funded escrow in both jurisdictions
- Drawdown and quarterly reconciliation process times versus the 10-business-day suspension trigger
- CNY/USD exchange-rate volatility and local inflation projections
- Envelope-level cost estimates against the USD 5 billion allocation and contingency reserve

### Simulation Steps

- Use Python with QuantLib or an Excel Monte Carlo model to simulate CNY/USD exchange-rate paths and estimate FX exposure under structured conversion windows
- Build an escrow cash-flow model in Microsoft Excel or Python pandas to test envelope-coded drawdown timing and funding-timeliness triggers
- Run stress tests with 5%, 10%, and 20% currency or inflation shocks to determine whether the USD 500 million contingency envelope is sufficient

### Expert Validation Steps

- Consult the Fiscal Escrow and Independent Audit Controller, sovereign treasury lawyers from both countries, and a bilateral fiscal governance auditor
- Obtain written legal opinions on escrow authority and appropriations feasibility from both governments

### Responsible Parties

- Fiscal Escrow and Independent Audit Controller
- Joint Fiscal Governance Unit
- Treasury Counsel from Both Governments

### Assumptions

- **High:** Both governments can legally pre-fund USD 2.5 billion each into a jointly signatory escrow.
- **Medium:** Structured conversion windows and periodic revaluation cap FX exposure within the contingency envelope.
- **Medium:** The 10-business-day contribution-delay trigger is enforceable and KPI-visible.

### SMART Validation Objective

By 2027-02-28, obtain legal opinions confirming escrow feasibility and complete a cash-flow stress test showing that the program can withstand a 5% currency or inflation shock without exceeding the contingency envelope.

### Notes

- Estimated validation cost: USD 1-5 million for legal opinions, modeling, audit setup, and reconciliation design; charge to the legal and audit envelope.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- If full pre-funding is impossible, validate the milestone-tranche fallback with the identical 10-business-day delay trigger and quarterly reconciliation.


## 10. Political Continuity and Leadership Transition Mechanisms

Political discontinuity is the largest program-level risk; without explicit continuity commitments, the investment is exposed to a single leadership transition or appropriations battle.

### Data to Collect

- Specific continuity commitments acceptable to both governments, including multi-year funding obligations, transition briefings, escrow-return clauses, and track-II channels
- Historical transition timelines and risk events that could delay entry-condition certification
- Stakeholder map of influence, decision points, and escalation paths to heads of state or party leadership
- Public KPI dashboard design that makes termination politically costly without leaking sensitive data

### Simulation Steps

- Use stakeholder mapping software such as Kumu or Miro and influence diagrams to model transition scenarios and continuity mechanism effects
- Run scenario planning exercises using a structured template in Microsoft Excel or SharePoint with both national teams to simulate leadership change and appropriations disruption
- Build a decision-tree or simple agent-based model in Python using NetworkX to simulate how different continuity commitments affect program survival probability over a 24-month horizon

### Expert Validation Steps

- Consult the Political Continuity and Government Liaison function, former senior officials from both governments, and track-II verification organizations such as VERTIC or IPNDV
- Engage legislative liaison offices in both countries to test the acceptability of transition briefings and multi-year funding language

### Responsible Parties

- Political Continuity and Government Liaison Lead
- Joint Secretariat
- Strategic Communications Leads
- Equal National Co-Chairs

### Assumptions

- **High:** Multi-year funding obligations are acceptable to both legislatures.
- **Medium:** Track-II channels can sustain technical relationships across political transitions.
- **Medium:** A public KPI dashboard can make termination politically costly without exposing sensitive evidence or schedules.

### SMART Validation Objective

By 2027-02-28, secure at least two formal political-continuity commitments, such as multi-year funding language, a transition-briefing requirement, or an escrow-return clause, and complete a transition-scenario war-game with both national teams.

### Notes

- Estimated validation cost: USD 2-5 million for strategic communications, legal drafting of continuity clauses, and scenario exercises; charge to legal and contingency envelopes.
- Validation results template: Original assumption | SMART objective | Actual data collected | Data source | Comparison against assumption | Conclusion (Validated / Partially Validated / Invalidated) | Escape hatch | Triage actions.
- The killer-application narrative must not expand the legal scope beyond declared-equipment change verification at declared sites.

## Summary

This validation plan targets the highest-sensitivity unknowns of the US-China Consortium Phase One verification program: trusted baseline inventory, statistical credibility of KPI thresholds, information-barrier effectiveness, ledger latency, site parity, legal feasibility, vendor compliance, staffing, fiscal escrow, and political continuity. Immediate action must focus on the most sensitive assumptions first: completing the joint baseline inventory, obtaining formal legal opinions on domestic authority and escrow, approving a pre-registered statistical analysis plan, and validating the information barrier in blind challenges. These four areas gate all other entry conditions and determine whether a defensible Go/Modify/Stop verdict is possible by the 90-day Phase One deadline. Each area has explicit simulation steps using concrete tools and expert validation steps with named classes of human experts, plus SMART validation objectives, cost estimates, and validation results templates to support transparent certification.

# Documents to Create and Find

# Documents to Create

## Create Document 1: Project Charter – US-China Consortium Phase One Verification Program

**ID**: 101d1641-3591-42b6-ac51-6e9160b9512e

**Description**: Foundational project management charter establishing the joint 90-day Phase One operational test mission, scope boundaries (declared-equipment change verification only), SMART success criteria, high-level budget and envelope structure, governance roles, and approval path. Intended for joint co-chairs and heads of state to authorize planning. Type: Project Charter.

**Responsible Role Type**: Joint Secretariat / Program Integration Lead

**Primary Template**: PMI Project Charter Template

**Secondary Template**: UK Government Project Initiation Document (PID) Template

**Steps to Create**:

- Draft charter from goal statement and strategic decisions, incorporating SMART criteria and mandatory entry conditions.
- Conduct joint working session with co-chairs and legal counsel to confirm scope and non-goals.
- Circulate for comment to mirrored national units and stakeholders.
- Obtain double-key approval from equal co-chairs.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for final authorization

**Essential Information**:

- Define the mission statement exactly as the joint 90-day Phase One operational test verifying material changes to covered frontier-relevant computing equipment at six matched declared datacenters (three per country), concluding with a defensible Go/Modify/Stop decision.
- Explicitly state scope boundaries and non-goals: verification of declared-equipment changes only; exclude workload verification, model-weight inspection, capacity estimation, hidden-facility discovery, and comprehensive AI governance.
- Incorporate the SMART success criteria from the project plan: false-negative rate ≤5% in blind challenges at 95% confidence; event-recording latency <5 minutes locally; cross-national synchronization ≤1 hour; divergence reconciliation ≤24 hours; unresolved material discrepancy age ≤10 business days; unverifiable equipment ≤2 units/site or 1% of covered changes; zero unresolved ledger divergence; demonstrated reciprocal access parity; and a joint written verdict.
- List the mandatory entry conditions that must be certified before the 90-day clock starts: bilateral instrument signed, domestic access authority enacted, full escrow pre-funding or milestone-tranche fallback in place, six matched sites jointly declared, mirrored inspectorate approved, vendor-access agreements secured, covered-equipment schedule adopted, baseline inventory completed, inspector visa/customs annex concluded, and systems validated through independent testing.
- Detail the seven budget envelopes and total $5B funding: $1.25B ledger/attestation/evidence/communications; $1B site preparation/operator compensation; $750M inspectorate; $750M secure facilities/cyber/counterintelligence; $500M independent testing/red teams; $250M legal/audit; $500M contingency/surge.
- Specify governance and approval structure: equal national co-chairs, double-key authorization, no casting vote, no majority overrule, joint technical teams for routine discrepancies, advisory arbiter for deadlocked facts, 10-business-day escalation to leadership, and automatic suspension limited to unresolved material discrepancies at specific sites.
- Identify responsible role and creation process: Joint Secretariat / Program Integration Lead to draft from the goal statement and strategic decisions, hold a joint working session with co-chairs and legal counsel, circulate to mirrored national units, and obtain double-key approval from co-chairs with heads of state/party leadership for final authorization.
- State the intended use and audience: authoritative charter for joint co-chairs and heads of state to authorize planning, align expectations, and establish the basis for downstream plans, budgets, and entry-condition tracking.

**Risks of Poor Quality**:

- An ambiguous or overly broad scope definition invites mission creep beyond declared-equipment verification, drawing the program into workload, model-weight, or capacity assessment that it was never designed to deliver.
- Missing or vague SMART criteria make the Go/Modify/Stop verdict contestable, because there will be no agreed quantitative thresholds for detection, latency, divergence, or materiality against which Phase One outcomes can be judged.
- Failure to enumerate mandatory entry conditions as gates allows the 90-day clock to start without joint certification, producing an invalid test and wasting the $750M inspectorate and $500M testing envelopes.
- Unclear budget/envelope structure creates fiscal ambiguity, enabling unauthorized drawdowns, asymmetric contributions, or cost overruns that consume the contingency reserve before independent testing is complete.
- Insufficient governance detail on double-key authority, deadlock resolution, and suspension thresholds leaves one co-chair able to block material findings or reinterpret contested terms, stalling the verdict.
- Omission of explicit non-goals and scope boundaries can create false expectations among stakeholders, legislatures, and the public that the program provides broader AI governance guarantees than it actually does.
- Lack of a defined approval path or responsible role leads to unauthorized decisions, delayed sign-off, and inconsistent versions of the charter circulating across mirrored national units.

**Worst Case Scenario**: The charter is approved with vague scope, missing entry conditions, and undefined success thresholds, leading co-chairs and heads of state to authorize a 90-day test that starts before key prerequisites are certified; one side exploits deadlock and ambiguous materiality to shield an operator, the baseline inventory is disputed, cross-border visa delays break the 24-hour confirmation window, and the final verdict is either a false Go based on scripted exercises or a politically contested Stop—consuming the full $5B investment, triggering automatic suspension, and collapsing bilateral confidence in the mechanism.

**Best Case Scenario**: The charter provides an unambiguous, jointly authorized foundation that locks the mission scope, SMART success criteria, mandatory entry gates, budget envelopes, and double-key governance before any operational work begins; it aligns co-chairs and heads of state, allows all preparation workstreams to proceed in parallel without de facto obligations, and enables a defensible, evidence-based Go/Modify/Stop decision that both governments accept as credible and binding.

**Fallback Alternative Approaches**:

- If a full co-authored charter cannot be agreed quickly, use the PMI Project Charter Template as a minimal skeleton and fill only the mandatory sections: mission, scope/non-goals, SMART success criteria, entry conditions, budget envelopes, governance, and approval authority.
- Schedule a focused joint working session or workshop with co-chairs, legal counsel, and program leads to collaboratively define scope, non-goals, and entry conditions, capturing decisions directly into a draft charter rather than iterating through written comments.
- Develop a 'minimum viable charter' limited to one page covering only the vital elements—mission, scope boundary, SMART thresholds, entry-condition gates, $5B envelope summary, and double-key approval path—then expand it into the full charter after initial authorization is secured.
- Engage an external program-management or treaty-verification subject-matter expert to draft the charter using the UK Government PID Template as an alternative structure, reducing internal drafting burden and providing an independent quality check.
- If political-level approval is delayed, have the Joint Secretariat issue an internal 'planning authorization memo' under co-chair authority to begin non-binding preparation workstreams, with the formal charter approved later.

## Create Document 2: Bilateral Governance and Decision-Rights Framework

**ID**: 0cbb596b-25ab-404f-8a6f-1fdcc99543ef

**Description**: High-level framework defining equal co-chair double-key authorization, no-casting-vote deadlock machinery, joint technical teams, advisory arbitration, objective automatic-suspension thresholds, and three-tier separation of inspectorate facts, verification conclusions, and political decisions. Type: Governance Framework.

**Responsible Role Type**: Bilateral Governance and Legal Implementation Lead

**Primary Template**: Model Treaty/Executive Agreement Governance Chapter Template

**Secondary Template**: IAEA Safeguards Legal Framework Template

**Steps to Create**:

- Review expert critique of double-key site findings and deadlock default rules.
- Draft decision-rights tiers for technical facts, materiality conclusions, and political sanctions.
- Pre-register objective automatic suspension triggers and a fixed deadlock clock.
- Convene governance war-games with both national legal teams.
- Submit to co-chairs for double-key approval.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for escalation provisions

**Essential Information**:

- Define the three-tier separation of authority: inspectorate-reported technical facts (unilateral operational results), joint technical team verification conclusions, and co-chair political determinations (Go/Modify/Stop, sanctions, suspension), with explicit rules preventing political considerations from altering technical findings.
- Specify the equal co-chair double-key authorization model: all material findings, sanctions, and suspensions require both co-chairs; no casting vote; no majority overrule; no unilateral findings or sanctions.
- Pre-register the deadlock-resolution machinery: joint technical teams resolve routine discrepancies under pre-agreed evidentiary rules; factual disputes deadlocked by the co-chairs escalate to a jointly selected advisory arbiter with non-binding findings; deadlocks persisting beyond 10 business days automatically escalate to heads of state/party leadership and appear on the KPI dashboard.
- Define objective, pre-agreed automatic-suspension triggers that are tightly scoped to unresolved material discrepancies at specific sites, explicitly excluding routine discrepancies or non-material findings from triggering regime-wide suspension.
- Incorporate concrete deadlock and suspension thresholds from the assumptions: 10-business-day deadlock escalation, automatic suspension only for sites with unresolved material discrepancies, and zero tolerance for unilateral findings or sanctions.
- Cross-reference and bind the definitions of 'material', 'unresolved', and 'material discrepancy' to the binding bilingual glossary and interpretive annex required by Decision 14, so suspension triggers are applied by lookup rather than negotiation.
- Include the escalation path and approval authority: equal national co-chairs for double-key decisions, with heads of state/party leadership reserved for escalation provisions and any extension of the deadlock clock.
- Document the governance war-game results and expert-critique dispositions as annexes, showing that the framework has been stress-tested against the double-key deadlock risk described in assumptions and strategic decisions.
- State explicit success metrics for the framework: bounded deadlock-resolution time (target under 10 business days), zero unilateral findings/sanctions, and interpretive disputes resolved without access denial.
- Specify how the framework interacts with the material-event latency budget and silent-window bounds, ensuring deadlock review cannot extend unresolved discrepancy age beyond the 10-business-day threshold or delay physical confirmation beyond 24 hours.

**Risks of Poor Quality**:

- Without objective, pre-registered deadlock and suspension triggers, one co-chair can exploit delay to shield an operator or block a sanction indefinitely, causing the Phase One verdict to be delayed or never produced.
- Ambiguous definitions of 'material discrepancy' or 'unresolved' allow each government to read the same finding differently, converting every routine discrepancy into a political deadlock and consuming the 90-day clock.
- Failure to separate inspectorate facts from political determination contaminates the technical evidence base, making the Go/Modify/Stop verdict politically contestable and undermining the credibility of the entire verification regime.
- If suspension thresholds are not tightly scoped to sites with unresolved material discrepancies, a single manufactured dispute can halt verification across all declared sites, creating a powerful delay tactic for either side.
- Absence of a fixed deadlock clock or escalation path means deadlocked factual disputes can fester beyond the 10-business-day threshold, aging material discrepancies and potentially forcing a false Stop or invalidating the latency KPI.
- If the framework conflicts with the binding bilingual glossary or interpretive annex, pre-registered terms become unenforceable and interpretive disputes resurface as access-denial tools.

**Worst Case Scenario**: A co-chair deadlock on a material finding triggers an automatic program-wide suspension or, conversely, shields an operator indefinitely; no bounded escalation path activates, the 90-day Phase One clock fails to start or produces no accepted verdict, the $5B bilateral mechanism collapses, and both governments withdraw with mutual accusations of bad faith, leaving the frontier AI verification gap unaddressed and severely damaging bilateral confidence.

**Best Case Scenario**: The framework establishes unambiguous decision rights, pre-agreed deadlock machinery, and objective suspension triggers, enabling joint certification of all entry conditions and a smooth Phase One clock start. Routine discrepancies are resolved by joint technical teams, deadlocked facts move to advisory arbitration and escalate within 10 business days, and automatic suspension is applied only to sites with unresolved material discrepancies. The result is zero unilateral findings, bounded deadlock-resolution times, a shared findings narrative, and a defensible Go/Modify/Stop verdict accepted by both governments, with the framework serving as the trusted governance model for future operational phases.

**Fallback Alternative Approaches**:

- Adapt the Model Treaty/Executive Agreement Governance Chapter Template as a starting draft, customizing only the deadlock clock, suspension triggers, and three-tier separation clauses to accelerate creation while preserving core governance principles.
- Convene a focused governance war-game with senior legal, verification, and technical representatives from both sides to negotiate the few genuinely contested clauses (deadlock clock length, arbiter selection, suspension scope) before attempting full-document drafting.
- Develop a minimal viable governance annex covering only the mandatory elements—double-key authorization, 10-business-day deadlock escalation, advisory arbiter, and site-scoped automatic suspension—and defer detailed three-tier separation rules to a follow-on addendum.
- Engage an external arms-control or treaty-verification legal expert to mediate and draft the most contested provisions, using IAEA Safeguards legal frameworks as a reference to resolve the no-casting-vote and suspension-scope issues.
- If full agreement cannot be reached pre-clock, adopt a provisional governance protocol for Phase One with explicit expiry, requiring the co-chairs to ratify a permanent framework before any operational phase beyond Phase One begins.

## Create Document 3: Verification Architecture and Layered Evidence Strategy

**ID**: 5936203e-9ac4-4919-a4a8-17e9a3a2e08e

**Description**: High-level strategy for evidence classes, certainty thresholds, operator-record validation, sampling principles, and the 'no single source decisive' rule, including mandatory two-class evidence for material events and random sampling for low-risk changes. Type: Technical Verification Strategy.

**Responsible Role Type**: Hardware Identity and Evidence Integrity Technical Lead

**Primary Template**: IAEA Safeguards Criteria / State-Level Concept Template

**Secondary Template**: DoD Verification and Validation Framework

**Steps to Create**:

- Map all material-event types and evidence classes to confidence requirements.
- Define evidence hierarchy and limitations of cryptographic attestation.
- Draft sampling rules for operator-provided records.
- Review against latency budget and information-barrier constraints.
- Seek joint technical team and co-chair approval.

**Approval Authorities**: Joint Technical Team; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

**Essential Information**:

- Map every material event type (arrival, installation, removal, transfer, maintenance change, decommissioning) to the specific evidence classes required to reach the target confidence threshold, explicitly identifying where physical witnessing is mandatory versus where operator-provided records may be validated by random sampling.
- Define the complete evidence hierarchy with explicit certainty thresholds for each class, including the binding rule that cryptographic attestation serves as supporting evidence only and never satisfies verification alone.
- Specify the 'no single source decisive' rule: for each material event, identify the minimum combination of independent evidence classes required, and define the criteria for evidence-class independence (e.g., different physical channels, different custodians, orthogonal data types).
- Quantify the sampling rules for operator-provided records: proposed sampling rate or confidence level for low-risk events, random-selection methodology, automatic site-level consequences of a failed sample, and conditions under which sampling escalates to full physical inspection.
- Document how evidence-class weighting interacts with the information-barrier architecture: specify which contextual metadata must survive filtering at filtered workstations so substitution indicators remain detectable, and include validation criteria for blind challenges.
- Define measurable success metrics for the evidence strategy: target false-negative and false-positive rates (e.g., ≤5% false negatives at 95% confidence in blind challenges), evidence-class independence measurements, and operator burden limits.
- Include a feasibility review against the material-event latency budget (operator report ≤4 hours, physical confirmation ≤24 hours, ledger recording ≤1 hour) demonstrating that the required evidence collection fits within these windows.
- Provide a decision matrix mapping combined evidence sets to verdicts (verified, unverified, material discrepancy) and the handoff to materiality definitions and automatic suspension thresholds.

**Risks of Poor Quality**:

- Ambiguous evidence hierarchy or missing independence criteria could allow two dependent evidence sources to be treated as independent, inflating confidence and letting substituted equipment pass undetected.
- Over-weighting cryptographic attestation could create false confidence if attestation is compromised, undermining the entire verification regime.
- Statistically unsound sampling rules for operator-provided records would let deliberate substitutions hide in low-risk events, expanding the false-negative surface beyond the 5% blind-challenge threshold.
- Failure to align with information-barrier constraints could result in filtered evidence stripping the contextual metadata needed to detect substitution, blinding inspectors during blind challenges.
- Unclear certainty thresholds would lead to joint technical team disputes and deadlock escalation, consuming the latency budget and delaying material findings.
- If the document does not address latency budget constraints, the required evidence collection may be infeasible within the 4-hour report / 24-hour confirmation windows, forcing automatic suspension or Modify verdicts.

**Worst Case Scenario**: A deficient evidence strategy leads to a false Go verdict: a substituted frontier-relevant equipment module passes blind challenges undetected because the evidence hierarchy over-relies on operator records and attestation. The undetected substitution becomes an international security incident, erodes all bilateral trust, triggers immediate program termination, and wastes the $5B investment while exposing both nations to uncontrolled frontier AI risk.

**Best Case Scenario**: The document provides a clear, validated evidence hierarchy that enforces 'no single source decisive,' sets statistically sound sampling rules, and aligns with information-barrier and latency constraints. This enables joint technical teams to resolve routine discrepancies quickly, supports a credible Go/Modify/Stop verdict, and reduces the risk of false negatives to ≤5% at 95% confidence. Key decisions enabled: joint certification of Phase One evidence integrity, approval of the final verdict, and validation of the verification architecture for extension to future phases.

**Fallback Alternative Approaches**:

- Adapt the IAEA Safeguards Criteria / State-Level Concept template as a starting framework and populate it with project-specific evidence classes rather than designing from scratch.
- Convene a focused workshop with the Joint Technical Team and the Hardware Identity and Evidence Integrity Technical Lead to collaboratively define the evidence hierarchy and sampling rules in a single working session.
- Produce a minimum viable version covering only the highest-risk material event types (installations, removals, decommissioning) first, then expand to lower-risk events after blind-challenge validation.
- Engage an external safeguards verification expert (e.g., retired IAEA inspector) to draft the evidence-class independence and certainty-threshold sections.
- Use the DoD Verification and Validation Framework template to structure the document and defer quantitative thresholds to the KPI validation plan, making them provisional until validated by pilot exercises.

## Create Document 4: Information Barrier and Filtered Evidence Architecture Strategy

**ID**: e74afcb3-ea15-480a-ade3-2bea1ebb624b

**Description**: High-level architecture strategy for bounded inspection zones, filtered workstations, clean-room examination, dynamic zone boundaries, cryptographic hashing, and blind validation of barrier rules to protect sovereign technology while preserving substitution indicators. Type: Security/Technical Architecture Strategy.

**Responsible Role Type**: Information Barrier and Counterintelligence Security Director

**Primary Template**: Trilateral Initiative Information Barrier Technical Framework

**Secondary Template**: OPCW Confidentiality Annex Implementation Model

**Steps to Create**:

- Define zone categories and evidence-filtering levels by event type.
- Specify clean-room examination and accredited independent examiner protocols.
- Plan blind validation exercises for barrier rules.
- Draft incident-isolation and evidence-hold procedures.
- Obtain security and co-chair approval.

**Approval Authorities**: Information Barrier and Counterintelligence Security Director; Equal National Co-Chairs; Joint Security Committees

**Essential Information**:

- Define bounded inspection zone categories (staging, maintenance, exit, clean-room) and specify for each zone: access control, escort requirements, permitted evidence-collection methods, and dynamic boundary rules by event type.
- Specify evidence-filtering levels for filtered workstations by event class (arrival, installation, removal, maintenance, decommissioning, vendor refusal), identifying exactly which data elements are stripped (customer data, workload details, model weights, source code, network topology) and which contextual metadata must be preserved to detect substitution.
- Mandate cryptographic hash chaining for all filtered evidence to preserve integrity while allowing review; define hash-commitment exchange, chain-of-custody, and evidence-hold procedures.
- Define clean-room examination and accredited independent examiner protocols for vendor-refusal cases, including examiner accreditation criteria, evidence handling, source-code protection, and how clean-room results feed layered evidence weighting.
- Plan blind validation exercises for barrier rules: required challenge types, success thresholds (e.g., false-negative rate ≤5%, substitution-indicator survival criteria), and triggers for revising filter rules after failed challenges.
- Draft incident-isolation and evidence-hold procedures: conditions for automatic hold on evidence-integrity compromise, isolation scope (site vs system), and resumption criteria that preserve verification at unaffected sites.
- Quantify the integration trade-off with latency and layered evidence: estimate added delay introduced by filtering/clean-room steps for each event class and specify how barrier strength is balanced against evidence sufficiency.
- Include approval and security requirements: classification levels, need-to-know compartments, physical/logical separation of national teams, and explicit approval gates for the Security Director, Equal National Co-Chairs, and Joint Security Committees.
- Identify required inputs and sources: Decision 3 strategic options, Risk 6 findings, assumptions in Q8, OPCW Confidentiality Annex Implementation Model, Trilateral Initiative framework, pre-negotiated vendor-access agreements, and existing filter-rule drafts.

**Risks of Poor Quality**:

- Ambiguous or over-filtered zone/evidence rules can strip the contextual metadata needed to detect substituted hardware, causing blind-challenge failures and false negatives that undermine a Go verdict.
- Under-specified barriers risk exposing model weights, source code, customer data, or network topology, triggering a national-security incident, diplomatic crisis, and possible program termination.
- Missing or vague clean-room examiner protocols leave vendor-refusal cases unresolved, increasing unverifiable-equipment counts and pushing the regime toward a Stop verdict.
- Blind validation exercises cannot be executed without clearly defined filter rules and success thresholds, so the architecture remains unproven and the Phase One clock may be delayed.
- Inadequate incident-isolation and evidence-hold procedures can either halt all verification on a single incident or allow compromised evidence to contaminate the final Go/Modify/Stop decision.
- Failure to secure timely co-chair and Joint Security Committee approval stalls implementation, wastes the $750M facilities/cyber envelope, and creates bilateral distrust about information protection.

**Worst Case Scenario**: A poorly designed or unvalidated information barrier either hides a red-team substitution from inspectors — producing a false Go that certifies an undetected capability — or leaks sovereign AI technology and sensitive workload data, triggering a national-security investigation, collapse of bilateral trust, and termination of the $5B program. Either outcome invalidates the verification regime and causes irreparable diplomatic and strategic damage.

**Best Case Scenario**: The architecture is approved and blind-validated to preserve all substitution indicators while protecting every sensitive data element, enabling clean-room vendor-refusal handling, meeting latency and evidence thresholds, and supporting a credible, defensible Go/Modify/Stop verdict. Both governments gain confidence that inspection does not expose sovereign technology, strengthening the bilateral relationship and enabling follow-on phases and future verification regimes.

**Fallback Alternative Approaches**:

- Adopt and tailor the OPCW Confidentiality Annex Implementation Model as a minimum viable information-barrier framework, then iterate with lessons from early exercises.
- Convene a focused joint workshop with the Information Barrier and Counterintelligence Security Director, Joint Security Committees, and independent red-team leads to collaboratively define zone categories and filter levels before drafting the full architecture.
- Pilot the barrier on a single staging zone and one event type in a provisional shadow exercise, validate substitution-indicator survival, then expand incrementally to other zones and event classes.
- Engage an external arms-control verification technical body or accredited independent examiners to review and draft the filter rules and clean-room protocols using proven treaty-verification templates.
- Develop a simplified 'minimum viable document' covering only the most critical elements — zone categories, filter levels, clean-room protocol, and incident-hold triggers — and defer dynamic boundaries and detailed validation planning until after initial blind testing.
- Run blind tabletop simulations with candidate filter rules to identify over-filtering risks before committing to physical filtered-workstation builds and clean-room infrastructure.

## Create Document 5: Baseline Inventory and Cryptographic Asset Registry Framework

**ID**: 13755547-02e0-4650-84bf-e0e090f4a127

**Description**: Framework for conducting and certifying the joint baseline physical inventory of all covered equipment at declared sites and reconciling it into a cryptographic asset registry before clock start, including recount rules and discrepancy resolution. Type: Verification Readiness Framework.

**Responsible Role Type**: Mirrored Inspectorate Operations Director

**Primary Template**: IAEA Physical Inventory Verification Procedures

**Secondary Template**: ISO/IEC 19770-1 IT Asset Management Standard

**Steps to Create**:

- Compile candidate site asset registers and layout data.
- Define serialization, tagging, and reconciliation procedures.
- Set materiality and recount thresholds for discrepancies.
- Execute joint baseline inventory at all six declared sites.
- Certify baseline as a mandatory entry condition.

**Approval Authorities**: Mirrored Inspectorate Operations Director; Hardware Identity and Evidence Integrity Technical Lead; Equal National Co-Chairs

**Essential Information**:

- Define the exact scope of the baseline: inventory all covered equipment, including pre-existing legacy racks, at all six matched declared sites (three per country) based on the current confidential attribute-based covered-equipment schedule and candidate site asset registers.
- Specify the joint inventory methodology: physical count, serialization and tagging procedures, cryptographic hashing of unit identity, and reconciliation of findings against operator procurement, maintenance, and disposal records to populate the cryptographic asset registry.
- Quantify discrepancy classification and recount rules: categorize discrepancies (missing, extra, mismatched serial, unreadable tag, disputed identity), set the unexplained serialized discrepancy threshold (e.g., full recount if >2% per site), and define escalation to the co-chairs for material discrepancies.
- Define baseline certification criteria as a mandatory entry condition: zero unresolved discrepancies before clock start, joint certification by the Equal National Co-Chairs, and a signed joint findings statement documenting the reconciliation process.
- Identify necessary inputs and sources: operator asset registers, procurement/maintenance/disposal records, site layout and access plans, covered-equipment schedule version, pre-installation identity gate data, and domestic access authority compelling operator and vendor cooperation.
- Assign roles and accountabilities: Mirrored Inspectorate Operations Director as owner, Hardware Identity and Evidence Integrity Technical Lead for identity/evidence standards, joint national inventory teams for execution, operators for record provision, and co-chairs for final certification.
- Set schedule and resource requirements: estimated completion window (e.g., 4-8 weeks per sensitivity analysis), staffing derived from the workload model, funding from the site-preparation/ledger envelopes, and fallback-site implications if a declared site cannot be inventoried.
- Define the registry output format: unit-level records (serial number, location, attestation hash, status, disposition), a versioned changelog, discrepancy log, and post-baseline update procedures so the registry remains the trusted reference for all downstream verification.

**Risks of Poor Quality**:

- An incomplete or inaccurate baseline invalidates every downstream material-change verification, because latency and materiality thresholds have no trusted starting state against which changes can be measured.
- Disputed serialization or tagging results can deadlock joint certification, delay the 90-day Phase One clock by 1-2 months, and consume $20-60M of contingency during reconciliation.
- Ambiguous or undefined recount rules make certification calls arbitrary and invite each government to read the same discrepancy record differently, increasing political contestation.
- A registry that lacks cryptographic anchoring, versioning, or tamper-evidence undermines evidence integrity and can trigger ledger divergence, a Stop condition, or a successful substitution challenge.
- Weakening or skipping the baseline to save time creates a false Go risk: if 2-5% of serialized records are inaccurate, the false-negative rate can exceed the 5% blind-challenge threshold and invalidate the entire Phase One verdict.

**Worst Case Scenario**: A failed or contested baseline inventory prevents joint certification and the Phase One clock never starts, leaving $400-600M in sunk preparation and staffing costs and consuming most of the $500M contingency—or worse, a flawed baseline is certified, allowing a hidden substitution to go undetected and producing a false Go that destroys the credibility of the entire bilateral verification regime and triggers political withdrawal.

**Best Case Scenario**: A fully executed joint baseline inventory produces a certified cryptographic asset registry at all six declared sites with zero unresolved discrepancies, giving every subsequent material-change event a trusted baseline; this enables the co-chairs to certify the mandatory entry condition, start the 90-day Phase One clock on schedule, and make a defensible Go/Modify/Stop decision based on credible detection rather than contested starting-state assumptions.

**Fallback Alternative Approaches**:

- Adapt the IAEA Physical Inventory Verification Procedures and ISO/IEC 19770-1 as implementation templates to accelerate procedure design instead of drafting from scratch.
- Run a joint pilot inventory at one matched site pair first to validate serialization, tagging, reconciliation, and certification procedures before scaling to all six sites.
- Engage an independent accredited third-party auditor or IAEA-style inspector to arbitrate disputed serialized records and certify the registry if bilateral teams cannot reach agreement.
- Use automated scanning, cryptographic tagging, and reconciliation software to compress the physical count timeline while preserving joint observation and evidence integrity.
- If full physical inventory cannot be completed before clock start, negotiate a conditional baseline certification with an agreed post-start reconciliation period and KPI-visible tracker, keeping the clock from starting until critical discrepancies are resolved.

## Create Document 6: Entry-Condition Sequencing and Readiness Certification Framework

**ID**: 0c108ab7-6cc3-4ddd-af40-b6a63f73b90c

**Description**: Framework for sequencing and jointly certifying all mandatory entry conditions (original seven plus baseline inventory, inspector-access annex, and escrow pre-funding), including integrated readiness tracker, parallel workstreams, shadow exercises, escalation at the 12-month boundary, and clock-start certification. Type: Readiness Gating Framework.

**Responsible Role Type**: Bilingual Training, Translation, and Readiness Certification Coordinator

**Primary Template**: Program Readiness Certification Template

**Secondary Template**: NASA TRL / Gate Review Framework

**Steps to Create**:

- List all entry conditions with named owners and evidence slots.
- Build integrated readiness tracker and status reporting.
- Define joint certification process for co-chairs.
- Run provisional shadow exercises after site selection.
- Escalate open conditions to heads of state at the 2027-09-04 boundary.

**Approval Authorities**: Equal National Co-Chairs; Heads of State/Party Leadership for escalation

**Essential Information**:

- List every mandatory entry condition that must close before the Phase One clock starts, including all ten defined dependencies: bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection, inspectorate roster approval, operator/vendor participation agreements, covered-equipment schedule adoption, baseline inventory/cryptographic registry, inspector visa/customs annex with travel-and-clearance drill, and validation of ledger/barrier/staging/exit/KPI thresholds.
- For each entry condition, assign a named owner, an evidence slot (e.g., signed instrument, enacted legislation, escrow confirmation, joint site declaration, roster approval, vendor agreement, schedule adoption, inventory audit report, drill results, validation report), and a specific certification criterion that must be met before the co-chairs can certify it as closed.
- Define the integrated readiness tracker data model: fields for condition status (open / in progress / condition met / certified), named owner, due date, evidence upload or link, dependencies, risk level, and escalation flag; specify the reporting cadence (e.g., weekly internal status, monthly co-chair readiness summary).
- Specify the joint certification process: double-key approval by the equal national co-chairs, no unilateral clock start, a requirement that both sides review the full evidence package, and a final certification package containing the complete checklist and evidence index.
- Define sequencing logic and critical path: run all preparatory workstreams in parallel under the tracker, but identify which conditions are prerequisites for others (e.g., domestic access authority before enforceable vendor agreements, site selection before shadow exercises, baseline inventory before clock start), and state which conditions are the final gating items.
- Prescribe provisional shadow exercise parameters: timing after site selection and inspector training, explicit non-binding labeling, exclusion of findings from the final Go/Modify/Stop decision, a prohibition on creating de facto obligations before legal authority exists, and a process for feeding lessons learned into readiness without starting the clock.
- Detail the escalation mechanism at the 2027-09-04 boundary: any open condition escalates to heads of state or party leadership, becomes a public KPI, and does not start the 90-day clock; define who initiates escalation, in what format, and what resolution options leadership may choose (extend with KPI-visible delay, resolve, or terminate).
- Set readiness metrics and targets: 100% reciprocal certification at clock start, checklist closure rate over time, days to certification per condition, number of open conditions at the 12-month boundary, and a target of zero uncertified entry conditions at launch.
- Define roles and responsibilities for the Bilingual Training, Translation, and Readiness Certification Coordinator, the co-chairs, joint legal task force, terminology commission, site-selection group, and each named condition owner; include separation of duties between preparation activities and certification decisions.
- Include a gate-review approach adapted from the NASA TRL / Gate Review Framework, with each entry condition treated as a readiness gate that must pass defined evidence-maturity criteria, and document the approval authority required to pass each gate.

**Risks of Poor Quality**:

- Incomplete or ambiguous entry-condition list allows the Phase One clock to start with unfulfilled prerequisites, such as a missing baseline inventory or inspector-access annex, invalidating verification results and forcing a contested Stop verdict.
- Without named owners and evidence slots, conditions can lag silently and readiness status becomes unverifiable, eroding bilateral trust and making the certification process a bureaucratic checkbox.
- A vague joint certification process enables one side to unilaterally declare readiness or withhold certification, triggering double-key deadlock and stalling the Phase One clock indefinitely.
- If shadow exercises are not explicitly non-binding, they create de facto obligations before domestic legal authority exists, leading to legal or political exposure and constraining later sovereign decisions.
- An absent or unclear escalation mechanism leaves open conditions unresolved at the 2027-09-04 boundary, idling trained staff, consuming the inspectorate and contingency envelopes, and risking program collapse.
- Incorrect sequencing logic can start costly workstreams before legal authority or site selection is certified, producing sunk costs and premature political commitments that cannot be undone.
- Certification criteria based on paper declarations rather than concrete evidence artifacts allow co-chairs to certify conditions that are not operationally ready, causing exercise failures and false confidence in the Go decision.

**Worst Case Scenario**: The framework is delivered with missing entry conditions, no verifiable evidence slots, and a weak joint certification process; the 90-day clock starts without a completed baseline inventory or inspector-access annex, the first unannounced blind challenge is missed because inspectors cannot reach sites or the baseline is disputed, the KPI thresholds fail, and the final verdict is a contested Stop after consuming the $5B budget—or, alternatively, open conditions at the 2027-09-04 boundary have no escalation path, the program stalls indefinitely, $400–600M in sunk preparation and staffing costs are lost, and political support collapses.

**Best Case Scenario**: The framework is adopted early and provides a transparent, jointly owned readiness path; all ten entry conditions are evidenced and double-key certified by 2027-09-04, the 90-day Phase One clock starts with 100% reciprocal readiness and zero uncertified conditions, shadow exercises have already stress-tested travel, access, and evidence workflows without creating obligations, and the Consortium enters Phase One with strong political continuity—enabling the co-chairs to make a credible, defensible Go/Modify/Stop decision on time and protecting the $5B investment.

**Fallback Alternative Approaches**:

- Use the existing Program Readiness Certification Template as a starting point and populate it in a focused two-day workshop with co-chair staff, legal, site-selection, and operational owners to identify conditions, owners, and evidence requirements.
- Create a minimum viable readiness tracker first—a shared spreadsheet with condition, owner, due date, status, evidence link, and escalation flag—then migrate to a more formal tracker once the condition list is stable and accepted.
- Apply the NASA TRL / Gate Review Framework directly: treat each entry condition as a gate with a maturity level, evidence requirement, and gate-review meeting, using the gate review itself as the certification event.
- Commission the Bilingual Training, Translation, and Readiness Certification Coordinator to draft the framework from the existing dependency list, risk register, and project-plan mitigation content, with legal and operational subject-matter experts reviewing in parallel rather than waiting for full consensus.
- If full joint certification cannot be completed by 2027-09-04, produce a phased 'pre-operations readiness' version of the document that certifies only conditions essential for safe preparatory work—legal authority, escrow pre-funding, and site selection—while clearly labeling all other activities non-binding and deferring the Phase One clock until all remaining conditions meet the same certification standard.

## Create Document 7: Go/Modify/Stop Verdict Construction and Materiality Framework

**ID**: 0ae580fb-34a4-435c-9171-93363deba887

**Description**: Framework for aggregating hundreds of findings into a joint verdict, defining the materiality corridor, bright-line triggers, shared findings narrative, staged technical and political decision process, and unresolved-discrepancy age limits. Type: Decision Framework.

**Responsible Role Type**: Discrepancy Adjudication and Verdict Construction Lead

**Primary Template**: Logical Framework Approach Template

**Secondary Template**: None

**Steps to Create**:

- Define materiality as risk appetite and set bright-line Stop triggers.
- Draft the shared findings narrative template.
- Fix the deliberation window and escalation defaults.
- Separate inspector-reported technical results from co-chair political determination.
- Obtain co-chair approval of the verdict construction process.

**Approval Authorities**: Discrepancy Adjudication and Verdict Construction Lead; Equal National Co-Chairs

**Essential Information**:

- Define materiality explicitly as risk appetite, including a materiality corridor with bright-line Stop triggers: a single unverifiable unit below the corridor is logged but does not block Go, while any unit above the corridor forces Stop.
- Specify the aggregation algorithm for combining hundreds of discrete findings (access findings, blind-challenge results, discrepancy ages, unverifiable-equipment counts, ledger divergence) into a single Go/Modify/Stop recommendation.
- Quantify the materiality thresholds using the provisional KPI targets: false-negative rate ≤5% at 95% confidence, unresolved material discrepancy age ≤10 business days, unverifiable equipment ≤2 units per site or 1% of covered changes, and zero unresolved ledger divergence.
- Define which findings are automatic Stop triggers versus Modify triggers versus logged-but-tolerated findings, including asymmetric access, shielding, unresolved divergence, withheld funding, and evidence-integrity compromise.
- Draft the shared findings narrative template that co-chairs must complete together, including sections for technical findings, disagreement surfaces, materiality-corridor position, and the joint recommendation.
- Fix the staged decision process: inspectors publish operational/technical results first, then co-chairs issue the verdict only after a fixed deliberation window, with the window length and escalation defaults explicitly stated.
- Set unresolved-discrepancy age limits and the rule for how old or stale discrepancies are weighted when the 90-day clock ends.
- Specify how the framework handles co-chair disagreement in the verdict itself, including the 10-business-day deadlock escalation path and the role of the advisory arbiter in factual disputes.
- Identify necessary inputs and sources: Decision 4 in strategic_decisions.md, the KPI thresholds in assumptions.md, risk registers from project-plan.md, and the three strategic paths in scenarios.md for calibration testing.
- Include a worked example of how a hypothetical mix of findings (e.g., one material unverifiable rack, two logged discrepancies, one vendor refusal) would be aggregated under the corridor rules.

**Risks of Poor Quality**:

- An unclear or contested materiality definition lets each government read the same findings record differently, making the final verdict politically contestable and delaying or invalidating the Go/Modify/Stop decision.
- Without bright-line thresholds, a single unverifiable rack or vendor refusal can either sink the entire regime or be quietly hidden, undermining the credibility of Phase One.
- Failure to separate inspector-reported technical results from co-chair political determination invites political negotiation to override operational evidence, destroying the verdict's evidentiary basis.
- Missing unresolved-discrepancy age limits allows stale findings to accumulate, so the final verdict may be based on outdated or unverified information rather than the true state at clock end.
- An untested or ambiguous aggregation rule could produce a false Go that certifies an undetectable substitution risk, or a false Stop that wastes the $5B investment and collapses bilateral confidence.
- A shared findings narrative template that is not pre-approved can lead to unilateral assessments being substituted for joint analysis, recreating the no-trust dynamic the Consortium is designed to overcome.

**Worst Case Scenario**: Phase One reaches the end of the 90-day clock with no agreed framework for aggregating findings, so the co-chairs cannot produce a joint verdict; one government uses the ambiguity to characterize the results as a Go while the other characterizes them as a Stop, triggering a diplomatic impasse, automatic suspension, and the effective collapse of the $5B bilateral verification program with hundreds of millions in sunk costs and no credible detection result.

**Best Case Scenario**: The framework is pre-approved and validated before the clock starts, giving both governments a shared, objective basis for aggregating hundreds of findings into a defensible joint verdict. It enables the co-chairs to issue a credible Go/Modify/Stop decision within the deliberation window, converts potential disagreements into resolvable technical questions, prevents any single unverifiable rack from either sinking or hiding the result, and establishes the trust and procedural legitimacy needed to extend the Consortium into operational phases beyond Phase One.

**Fallback Alternative Approaches**:

- Use the Logical Framework Approach template as a rapid scaffold, mapping inputs, outputs, outcome indicators, and assumptions directly onto the verdict decision, then fill in only the bright-line Stop triggers and escalation defaults first.
- Convene a focused two-day workshop with the Discrepancy Adjudication Lead, co-chairs, and joint technical teams to negotiate and pre-register the materiality corridor and aggregate rules collaboratively rather than drafting in isolation.
- Develop a minimum viable verdict framework covering only the non-negotiable elements—bright-line Stop triggers, the 10-business-day discrepancy age limit, and inspector-vs-co-chair separation—and defer the shared narrative template and deliberation-window details to a post-clock addendum.
- Engage an independent neutral expert or former arms-control verification official to draft the aggregation rule based on the KPI thresholds in assumptions.md and the strategic paths in scenarios.md, with both governments reviewing before adoption.
- Run a tabletop exercise using the three scenario paths (Builder's Balanced, Pioneer's Gambit, Consolidator's Controlled Path) to test candidate materiality definitions against realistic finding mixes and select the most defensible framework. 

## Create Document 8: Material-Event Latency Budget and Silent-Window Definition Framework

**ID**: 4d2b29e0-d243-4641-8e0f-fe6f46b22ea5

**Description**: Framework for fixing the maximum time a physical material change may go unrecorded, allocating the budget across operator reporting, physical confirmation, and ledger recording, and defining silent-window bounds that red teams exploit and blind challenges must beat. Type: Verification Latency Framework.

**Responsible Role Type**: Hardware Identity and Evidence Integrity Technical Lead

**Primary Template**: Verification Latency Budget Template

**Secondary Template**: DoD Time-Sensitive Targeting Latency Model

**Steps to Create**:

- Define provisional layered latency thresholds (e.g., 4h reporting, 24h confirmation, 1h ledger recording).
- Assess trade-offs against production disruption and information barriers.
- Set silent-window bounds and unannounced sweep compensation rules.
- Validate thresholds through pilot blind challenges.
- Approve through joint technical governance.

**Approval Authorities**: Hardware Identity and Evidence Integrity Technical Lead; Joint Technical Team; Equal National Co-Chairs

**Essential Information**:

- Quantify the layered latency budget: operator event reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour, and specify how these interior windows interact and are independently verified.
- Define the maximum silent window (maximum time a material change may go unrecorded) and the exact trigger events for starting and stopping each latency segment, including who records timestamps and how tamper-evidence is maintained.
- List explicit trade-offs against production disruption, information-barrier filtering latency, vendor-refusal escalation ladder, and mirrored staffing constraints, with accepted bounds for each.
- Specify compensation rules for any accepted discrete silent windows: unannounced sweep frequency, random selection method, and the maximum expected cumulative undetected exposure.
- Detail success metrics and KPI thresholds: local event-recording latency under 5 minutes, cross-national synchronization within 1 hour, divergence reconciliation within 24 hours, and false-negative rate no greater than 5% at 95% confidence in blind challenges.
- Define the validation plan: six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal), independent red teams, and no advance knowledge of exercise timing.
- Identify required inputs and dependencies: completed baseline inventory, entry-condition certification, inspector visa/customs annex, ledger synchronization bounds, and information-barrier filter rules.
- Document governance and approval path: joint technical team recommendation, double-key approval by Equal National Co-Chairs, deadlock escalation after 10 business days, and alignment with Phase One verdict construction and materiality definitions.

**Risks of Poor Quality**:

- Ambiguous or unvalidated latency thresholds make the silent window a guaranteed concealment corridor; red teams can hide substitutions and blind challenges fail, forcing a false Go or a contested verdict.
- Overly strict thresholds that ignore production disruption or information-barrier delays create impossible compliance, causing false Modify/Stop outcomes and wasting the $5B investment.
- Failure to define independently verifiable interior windows lets operators or inspectors game reported times, undermining the regime's falsifiable honesty claim.
- Unspecified unannounced-sweep compensation rules leave residual detection risk unbounded, directly contradicting the credible-detection requirement.
- Unaddressed conflicts with the vendor-refusal escalation ladder and filtered-evidence barriers consume the latency budget and delay every recorded event without a clear mitigation path.
- Lack of pre-agreed thresholds turns the KPI dashboard into a negotiation object and makes the Phase One Go/Modify/Stop verdict politically contestable.

**Worst Case Scenario**: Thresholds are defined on paper but never validated through blind challenges; red teams exceed the 5% false-negative bound or hide a substitution longer than the 4+24+1 hour budget. The Consortium nevertheless issues a Go based on dashboard metrics, certifying a regime that cannot detect a real substitution. A subsequent material change goes undetected for days, triggering a national-security incident, collapse of bilateral confidence, and termination of the $5B program with inspectors withdrawn.

**Best Case Scenario**: The framework produces validated, jointly approved latency and silent-window thresholds that are credible to both governments and achievable by operators. Pilot blind challenges confirm detection rates, interior windows are independently verifiable, and the KPI dashboard reflects real latency performance. This directly enables a defensible Go/Modify/Stop verdict, supports Phase One certification, and clarifies operational decisions on staffing, information-barrier strength, and unannounced sweep deployment.

**Fallback Alternative Approaches**:

- Use the DoD Time-Sensitive Targeting Latency Model as a starting template and adapt its time-phasing and verification concepts to the bilateral verification context.
- Convene a focused joint technical workshop with operator representatives, red-team leads, and information-barrier engineers to co-define thresholds and trade-offs in a single session.
- Produce a minimum viable framework covering only the three core thresholds (4h reporting, 24h confirmation, 1h ledger recording) and the silent-window bound, deferring detailed sweep compensation rules to a follow-on annex.
- Run provisional shadow exercises or pilot blind challenges before formal approval to empirically calibrate thresholds and demonstrate feasibility.
- Engage the Hardware Identity and Evidence Integrity Technical Lead with external latency-modeling and information-barrier subject-matter experts to draft a preliminary version for joint technical review.


# Documents to Find

# SWOT Analysis


## Strengths 👍💪🦾
- Stipulated high-level political backing from both governments provides the authority needed to compel operator, vendor, and logistics participation.
- Clearly bounded mission: verify material changes to declared frontier-relevant computing equipment only, with explicit non-goals that prevent mission creep and make success measurable.
- Full USD 5 billion budget pre-allocated across seven defined envelopes with 50/50 national contributions, contingency reserve, and fiscal accountability mechanisms.
- Equal national co-chairs, double-key authorization, no casting vote, and no majority-overrule rule create a governance structure that respects sovereignty and mutual distrust.
- Layered evidence and the 'no single source decisive' principle reduce reliance on any one record type and increase confidence in findings.
- Mandatory entry conditions and the Go/Modify/Stop verdict structure create a disciplined, falsifiable operational test rather than an open-ended commitment.
- Mirrored full-time inspectorate with separation of duties, no single-person critical functions, and a permanent surge cadre supports reciprocity and evidence integrity.
- Forced-evidence ladder for vendor refusal, including clean-room examination and accredited independent examiners, reduces dependence on vendor goodwill.
- Strong historical precedent from INF Treaty verification, the Joint Verification Experiment, IAEA safeguards, and OPCW managed access demonstrates that sovereign-pair verification with information barriers is feasible.
- Replicated tamper-evident ledger with local-first recording, bounded synchronization, and divergence-reconciliation targets provides an auditable evidence backbone.

## Weaknesses 👎😱🪫⚠️
- Killer application gap: the Consortium has not articulated a single flagship use-case (e.g., a verified crisis-stability freeze on material frontier-AI compute changes) that would make Phase One strategically indispensable to either government; without it, political and funding continuity remain vulnerable. Obstacles include the deliberately narrow scope, sovereignty sensitivities, and reluctance to publicize verification capabilities.
- No trusted baseline inventory of pre-existing covered equipment exists; every subsequent change-verification claim depends on a baseline that has not yet been jointly counted, serialized, and certified.
- No standing bilateral inspector visa and customs annex exists; the 24-hour physical-confirmation latency budget is arithmetically impossible if visas take 10 business days or diagnostic tools remain in customs.
- Political continuity is not assured: a U.S. administration change, Chinese leadership transition, or congressional appropriations battle could halt the program during the 12-month entry-condition phase.
- KPI thresholds are provisional and unvalidated; false-negative, latency, and materiality thresholds must be tested in pilot runs before any Go decision, or the verdict risks being a false confidence or false Stop.
- Approximately 450 full-time bilingual cleared inspectors with separation of duties and 24/7 coverage may not be recruited, cleared, and trained within the 12-month entry-condition window.
- Information-barrier design is inherently tensioned: over-filtering can strip substitution indicators, while under-filtering risks exposing workloads, model weights, source code, or security architecture.
- The fixed USD 5 billion budget, including CNY-denominated China-side costs, is exposed to exchange-rate movement and local inflation despite structured conversion windows.
- The 90-day clock can be consumed by deadlock, vendor refusal, or reconciliation delays, leaving insufficient time to produce a credible verdict.

## Opportunities 🌈🌐
- Develop a killer application: reframe Phase One as the first verifiable 'frontier-AI compute stability' mechanism—a mutually accepted crisis-stability tool that either government could invoke during an AI-related national-security crisis to confirm no material compute changes at declared sites. A successful demonstration would make the Consortium strategically indispensable and catalyze follow-on phases.
- Establish a global norm and precedent for bilateral hardware verification that could later be extended to allies, other nations, or additional strategic technology categories such as advanced semiconductors and dual-use infrastructure.
- Reuse the layered-evidence, information-barrier, and managed-access architecture for future US-China confidence-building measures, creating a durable verification community of practice.
- Leverage track-II diplomatic channels and engagement with independent verification organizations (IAEA, OPCW, VERTIC, IPNDV) to sustain technical relationships and institutional memory across political transitions.
- A successful Phase One could support expansion to a larger matched-site set, additional facility types, or continuous portal-monitoring arrangements modeled on INF's Votkinsk/Magna experience.
- A public, unclassified KPI dashboard that demonstrates reciprocal access, detection credibility, and fiscal accountability would make termination politically costly and build domestic legitimacy.
- Accredited independent clean-room examiners and independent red teams offer a path to enhanced credibility that neither government can unilaterally discredit.

## Threats ☠️🛑🚨☢︎💩☣︎
- Political discontinuity or leadership transition in either country could reverse commitment, halt entry-condition completion, or terminate the program despite functioning verification mechanics.
- Delayed or asymmetric contribution release can act as a quiet veto, starving the program without formally triggering the withholding-funding Stop condition.
- A dominant manufacturer or maintenance provider refusing cooperation across multiple sites could cascade into systemic unverifiability and force a Stop verdict.
- Domestic courts, regulators, local governments, or private operators may challenge foreign inspector authority despite planned domestic access legislation, creating asymmetric-access Stop conditions.
- Cyber compromise, insider threat, or counterintelligence failure could corrupt evidence, leak the confidential covered-equipment schedule, or expose inspector travel plans, triggering an international incident.
- Information-barrier misconfiguration could either blind inspectors to substitution evidence or expose sovereign technology, collapsing political support.
- Site parity may be a paper fiction: differences in facility size, layout, vendor ecology, security rules, and grid reliability could make reciprocal access incomparable and trip the asymmetric-access Stop condition.
- One co-chair could manufacture deadlock or dispute to shield an operator or stall the verdict, exploiting the no-casting-vote structure for delay rather than protection.
- Unvalidated or gamed KPI thresholds could produce a false Go based on scripted exercises, or a false Stop that wastes the USD 5 billion investment.
- Public-health events, severe weather, grid congestion, or local logistics failures could disrupt the fixed 90-day operational window and force an inconclusive verdict.
- Cost overruns, currency depreciation, or local inflation could consume the contingency envelope before independent testing is complete.

## Recommendations 💡✅
- By 2026-09-18, stand up the joint secretariat and integrated readiness tracker listing all entry conditions (including elevated gates for baseline inventory, inspector-access annex, and escrow pre-funding) with named owners, evidence slots, and co-chair certification fields; escalate any open condition to heads of state/party leadership at the 2027-09-04 boundary. Owner: joint co-chairs and interim executive directors.
- By 2027-03-31, negotiate and exercise a standing inspector visa and customs annex with 48-hour multiple-entry visa processing, pre-cleared manifests for diagnostic tools, and privileges and immunities limited to official verification acts; complete an end-to-end travel-and-clearance drill measuring elapsed time against the 24-hour physical-confirmation budget. Owner: joint legal task force with customs, visa, and border authorities.
- Before the Phase One clock starts, complete and certify a joint baseline physical inventory of all covered equipment at the six declared sites, reconciled into a cryptographic asset registry; require a full recount of any site with more than 2% unexplained serialized discrepancy, and make baseline certification a mandatory joint gate. Owner: joint inspection teams, operators, and co-chairs.
- By 2027-02-28, develop and socialize the killer-application narrative: a joint unclassified briefing and demonstration package framing Phase One as a crisis-stability tool for verifying no-material-change commitments during AI-related national-security tensions; use it to secure political continuity commitments, including multi-year funding language, transition briefings, and an escrow-return clause. Owner: strategic communications leads and policy advisors reporting to the co-chairs.
- Before clock start, secure full escrow pre-funding of USD 2.5 billion per side into a jointly signatory account with envelope-coded drawdowns and quarterly USD reconciliation; if full pre-funding is impossible, institute milestone-linked tranches with the identical 10-business-day contribution-delay trigger so delayed disbursement cannot act as a quiet veto. Owner: both treasuries and the joint fiscal governance unit.

## Strategic Objectives 🎯🔭⛳🏅
- By 2027-09-04, jointly certify 100% of mandatory entry conditions, including the seven original conditions plus baseline inventory, inspector-access annex, and escrow pre-funding, as evidenced by signed co-chair certification records.
- Within 90 days after the certified Phase One clock starts, complete all six mandatory unannounced blind challenge types with a false-negative rate no greater than 5% at 95% confidence, zero unresolved ledger divergence, and all material discrepancies resolved within 10 business days.
- During Phase One, demonstrate reciprocal access parity across matched site pairs within the pre-agreed tolerance band (e.g., access-hours ratio between 0.9 and 1.1), with any asymmetry automatically escalated to the Stop trigger.
- By 2027-02-28, deliver the killer-application demonstration package and secure at least two formal political-continuity commitments (e.g., multi-year funding obligation, transition-briefing requirement, or escrow-return clause) to protect the program through the entry-condition phase.
- At final Go/Modify/Stop decision, maintain all expenditures within the seven budget envelopes with zero independent audit exceptions, 100% funding timeliness, and no unresolved material discrepancy older than 10 business days.

## Assumptions 🤔🧠🔍
- Both governments' leaders continue to believe uncontrolled frontier AI threatens national security and political control, and they provide sustained political backing through the entry-condition phase and Phase One.
- The mandatory entry conditions are prerequisites: the 90-day Phase One clock starts only after both co-chairs jointly certify full completion.
- The matched set will be six declared sites (three per country), with approximately 450 full-time mirrored FTE and a permanent surge cadre of at least 10% of baseline.
- The USD 5 billion budget is real, 50/50 funded, and fully pre-funded into escrow or protected by an equivalent quiet-veto-proof release mechanism.
- No trust, legal symmetry, or willingness to expose sensitive technology is assumed; information barriers, double-key governance, and layered evidence must compensate.
- KPI thresholds are provisional until validated by pilot runs and live blind challenges; unsupported figures will be marked TBD and refined before any Go decision.
- The program remains a sovereign public-sector national-security mechanism; commercial concepts such as market demand, revenue, or ROI are not applicable.
- Domestic law in both countries can compel operator, manufacturer, maintenance-provider, and logistics-company participation, including reporting, confidentiality, escort, and evidence-preservation obligations.
- All covered equipment at declared sites can be physically inventoried, serialized, and reconciled into a cryptographic asset registry before the clock starts.
- Structured currency-conversion windows and periodic revaluation will contain CNY/USD exchange-rate risk within the contingency envelope.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Exact participating site identities and their physical layouts, operator ecosystems, vendor coverage, and baseline covered-equipment counts.
- Final text of the bilateral instrument, including deadlock machinery, automatic-suspension thresholds, binding bilingual glossary, and interpretive annex.
- Signed model vendor-access agreements with manufacturers, maintenance providers, and logistics companies, including dominant-vendor participation status.
- Validated KPI thresholds from pilot exercises and provisional blind challenges, including false-negative and false-positive rates with confidence intervals.
- Actual staffing availability, security-clearance lead times, bilingual technical-talent supply, and loaded-cost estimates for the ~450 FTE inspectorate.
- Domestic legal feasibility in both countries: whether access-authority legislation can override private-law objections and bind third parties effectively.
- Political-continuity mechanisms: whether multi-year funding obligations, transition briefings, or escrow-return clauses are acceptable to both governments.
- Currency and inflation projections, escrow administrative arrangements, and whether full pre-funding or milestone-linked tranches will be politically achievable.
- Detailed cost estimates for site preparation, secure facilities, information-barrier systems, and baseline inventory audits at each candidate datacenter.

## Questions 🙋❓💬📌
- If a leadership transition occurs before the Phase One clock starts, what specific continuity commitments would keep the Consortium alive, and are they enforceable in both political systems?
- Would promoting a 'killer application' narrative—such as crisis-stability compute verification—risk expanding the scope beyond declared-equipment change verification and creating expectations the Consortium cannot meet?
- What is the single most plausible way a red team could evade detection within the 4-hour reporting / 24-hour physical-confirmation / 1-hour ledger-recording latency budget, and can the layered evidence hierarchy catch it?
- How can the Consortium distinguish a genuine discrepancy from a manufactured one designed to trigger automatic suspension on the other side's site, and what bad-faith indicators should be pre-registered?
- If a dominant vendor refuses clean-room access at multiple sites, is the forced-evidence ladder genuinely sufficient to classify equipment as verified rather than unverifiable, or should the per-site unverifiable threshold be set lower before the clock starts?

# Team

*Roles Needed & Example People*

# Roles

## 1. Bilateral Governance and Legal Implementation Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Needed for sustained bilateral legal drafting, entry-condition certification, and ongoing double-key governance through the full entry-condition and Phase One period. The program requires full-time, cleared, mirrored legal and terminology units; contractor or temporary staffing would create single-person or continuity risks.

**Explanation**:
Provides the sovereign-pair legal architecture: drafting the bilateral instrument, double-key/deadlock/automatic-suspension procedures, binding bilingual glossary, domestic access authority, model vendor-access agreements, and inspector visa/customs annex. Also runs entry-condition certification and negotiates continuity commitments so the regime survives leadership transitions.

**Consequences**:
Without this role there is no bilateral instrument, no domestic access authority, no deadlock machinery, and no pre-registered interpretive glossary. A single co-chair could block findings indefinitely, operators and vendors could refuse participation, and visa/customs delays would break the 24-hour physical-confirmation latency budget. The program could not legally start.

**People Count**:
min 12, max 24 — 8 core attorneys (4 per country) plus treaty-verification advisors, technical linguists, and implementing-legislation specialists. More than one per side is required because drafting, glossary negotiation, and vendor-access agreements must run in parallel before the 12-month entry-condition deadline, and no critical legal function may be single-person.

**Typical Activities**:
Negotiate and maintain the bilateral instrument; pre-register deadlock procedures and automatic-suspension thresholds; manage the joint terminology commission; draft domestic access-authority notes; bind operators and vendors via model agreements; negotiate the inspector visa and customs annex; support entry-condition certification; and provide ongoing legal advice for double-key authorization, sanctions, and suspension decisions.

**Background Story**:
Dr. Eleanor Hartley-Voss, a treaty lawyer based in Arlington, Virginia, earned a J.D. from Georgetown University Law Center and a Ph.D. in international relations from Oxford, then spent 22 years in the U.S. State Department's Bureau of Arms Control, Verification and Compliance, where she drafted New START inspection protocols, served on the U.S. delegation to the Bilateral Consultative Commission, and advised on the OPCW Confidentiality Annex. She is a skilled public international lawyer and negotiator with deep experience in double-key governance, immunities, and interpretive dispute resolution, and she has spent the last two years leading the U.S. legal task force for the Consortium, personally drafting the bilingual glossary, deadlock machinery, and model vendor-access annex. Her relevance to the program is that she is the principal architect of the bilateral legal architecture that makes the 90-day Phase One clock legally possible, and she knows where every governance failure mode will surface.

**Equipment Needs**:
Secure encrypted drafting and document-management systems; versioned legal repositories; bilingual terminology database for glossary maintenance; secure videoconferencing with interpretation; case/deadlock tracking software; KPI dashboard access for entry-condition certification.

**Facility Needs**:
Mirrored legal offices in the Washington, DC area and Beijing with SCIF/secure-compartmented spaces; joint negotiation and terminology-commission conference rooms; secure records vaults; dedicated interpretation booths for bilateral drafting sessions.

## 2. Mirrored Inspectorate Operations Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires full-time operational command of 24/7 mirrored inspection coverage, separation of duties, leave backup, and surge deployment. The project explicitly forbids part-time, temporary-agency, or single-person critical functions in the inspectorate.

**Explanation**:
Leads the full-time mirrored inspectorate and technical workforce, ensuring 24/7 coverage at six declared sites, separation of duties, leave backup, no single-person critical functions, and a permanent surge cadre. Directs intake staging, physical witnessing of installations/removals, maintenance monitoring, and exit-disposition verification under dual-national observation.

**Consequences**:
Without operational command, coverage gaps, single-person critical functions, asymmetric national capacity, and uncoordinated evidence collection would invalidate material events. The regime could not meet its reciprocal-access parity requirement and would likely trigger a Stop condition before exercises are complete.

**People Count**:
min 14, max 24 — 2 senior operational directors (one per national side), 6 site team leads, plus shift/surge commanders and adjudication coordinators. The full inspectorate is approximately 450 FTE, but this role covers the command, scheduling, and separation-of-duties layer; multiple leaders are essential for reciprocal mirroring and simultaneous site coverage.

**Typical Activities**:
Command the mirrored inspectorate; build site-level shift rosters with leave backup and surge deployment; supervise intake staging and physical witnessing; coordinate dual-national teams for installations, removals, maintenance monitoring, and exit dispositions; enforce separation of duties; investigate access delays; and report operational readiness and parity metrics to the co-chairs.

**Background Story**:
Colonel Marcus 'Cole' Anders, based in Ashburn, Virginia, is a former U.S. Air Force nuclear-missile maintenance officer with a B.S. in nuclear engineering from Rensselaer and an M.S. in operations research from the Air Force Institute of Technology, who spent 18 years leading DOE/NNSA inspection teams under New START and participating in CTBTO on-site inspection exercises, including as an operations chief for a multinational field exercise in Jordan. He has deep expertise in 24/7 shift operations, separation of duties, dual-national team leadership, evidence chain of custody, and contingency deployment, and he has already run the Consortium's mirrored inspection staffing model through two tabletop exercises. His relevance is that he knows how to turn the six-site, 450-person inspectorate plan into a functioning operational command that can perform physical witnessing and maintain reciprocal access parity without single-person critical functions.

**Equipment Needs**:
24/7 shift-roster and staffing management system; operational command-and-control voice/data communications; evidence collection kits including serialization scanners, tamper-evident seals, chain-of-custody forms, and encrypted cameras; GPS/vehicle tracking for escorted movements; PPE and safety equipment; surge deployment equipment.

**Facility Needs**:
National mirrored inspectorate operations centers; on-site command posts at all six declared datacenters; staging-area control rooms; briefing/debriefing rooms; secure evidence storage; logistics/transport coordination hub with vehicle fleet space.

## 3. Hardware Identity and Evidence Integrity Technical Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Continuous responsibility for the replicated ledger, baseline registry, identity verification, and divergence reconciliation demands full-time availability and long-term accountability. Each national node must be independently staffed by cleared, permanent personnel.

**Explanation**:
Owns the replicated tamper-evident ledger, cryptographic asset registry, baseline inventory reconciliation, equipment-identity verification, intake identity gates, and exit-disposition records. Ensures local event recording within 5 minutes, cross-national synchronization within 1 hour, divergence reconciliation within 24 hours, and layered evidence where no single source is decisive.

**Consequences**:
Without this role there is no trusted baseline inventory, no bounded synchronization, and no robust equipment-identity verification. Ledger divergence would go unresolved, material changes could remain silent, and the false-negative threshold would be exceeded by construction, poisoning any Go decision.

**People Count**:
min 22, max 42 — 2 mirrored technical leads (one per national copy) plus a full-time engineering team for prototype build, independent penetration testing, and operations. Multiple people are required because each national node must be independently built, tested, and operated, and ledger divergence is a designated Stop condition that cannot depend on one person.

**Typical Activities**:
Own the replicated tamper-evident ledger and cryptographic asset registry; complete and reconcile the joint baseline inventory; operate intake identity gates; validate equipment attestation and serialization; monitor synchronization and divergence alerts; run reconciliation drills; define evidence-class weighting; and maintain equipment-identity confidence metrics.

**Background Story**:
Dr. Yuxin 'Luna' Tan, a hardware assurance engineer based in Haidian District, Beijing, earned a Ph.D. in computer engineering from Tsinghua University, studied trusted execution environments at ETH Zurich, and spent 12 years building hardware inventory and attestation systems for hyperscale datacenters and, earlier, for IAEA safeguards remote-monitoring deployments that verified sealed nuclear material using tamper-evident identifiers and authenticated data chains. She is an expert in cryptographic hash chains, equipment serialization, root-of-trust attestation, and reconciliation of physical inventories with maintenance and disposal records, and she led the Consortium's prototype ledger team that demonstrated 5-minute local recording and 1-hour synchronization on 1,000 synthetic events. Her relevance is that she is the technical owner of the 'no single source is decisive' layered-evidence architecture and the baseline inventory certification that every subsequent verification depends on.

**Equipment Needs**:
Replicated tamper-evident ledger server nodes with hardware security modules for each national copy; local-first event recording and synchronization/divergence alerting systems; cryptographic asset registry and baseline inventory database; serialization and identity verification devices including asset tags, RFID/QR readers, and scanners; attestation validation and power-analysis test rigs; secure backup and recovery storage.

**Facility Needs**:
Hardware-secured data-center space for the two national ledger nodes; equipment identity verification laboratory; intake-staging identity gate infrastructure at each site; secure network operations center; controlled clean-room work area for hardware examination.

## 4. Information Barrier and Counterintelligence Security Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Needs ongoing 24/7 security monitoring, counterintelligence operations, and incident response across multiple sites. Full-time status supports need-to-know compartmentation, hardware-separated teams, and the required permanent security presence.

**Explanation**:
Designs and validates filtered workstations, bounded inspection zones, clean-room examination protocols, need-to-know compartments, and hardware-separated national teams. Runs continuous counterintelligence monitoring and drills the joint cyber-incident isolation protocol so evidence integrity is preserved without exposing workloads, model weights, source code, or security architecture.

**Consequences**:
Without this role, over-filtering could hide substitution evidence and under-filtering could leak sovereign technology. A single evidence-integrity compromise would trigger automatic suspension and could collapse political support for the entire $5B program.

**People Count**:
min 60, max 100+ — 2 mirrored security directors plus cybersecurity engineers, counterintelligence officers, and incident-response staff funded from the $750M facilities/cyber/counterintelligence envelope. 24/7 monitoring, physical/logical separation of national teams, and simultaneous incident response require more than a small team.

**Typical Activities**:
Design and validate filtered evidence and clean-room procedures; set zone boundaries by event type; enforce need-to-know compartments for the covered-equipment schedule; run hardware-separated national evidence systems; conduct continuous counterintelligence monitoring; execute joint cyber-incident isolation drills; and report IP/cyber incidents and evidence-integrity holds.

**Background Story**:
Alexandra 'Alex' Novak, a counterintelligence and information-protection director based in Columbia, Maryland, holds a B.S. in electrical engineering from Virginia Tech, served 20 years in U.S. intelligence and counterintelligence roles, and later worked with national laboratories on information-barrier prototypes that allowed inspectors to verify classified attributes without revealing design data. She has designed filtered workstations, bounded inspection zones, clean-room examination protocols, need-to-know compartments, and continuous insider-threat monitoring, and she authored the Consortium's information-barrier rulebook before running it through a blind challenge that confirmed substitution indicators survive filtering. Her relevance is that she owns the trade-off between verification sensitivity and protection of workloads, model weights, source code, and network topology, and she knows how to contain a cyber or evidence-integrity incident without halting verification at unaffected sites.

**Equipment Needs**:
Filtered workstations configured to strip protected data while preserving identity metadata; hardware-separated evidence systems; network intrusion detection and prevention, continuous monitoring, and audit-logging tools; encryption key management; access-control and badge systems; counterintelligence and insider-threat monitoring software; incident-response toolkits.

**Facility Needs**:
SCIFs and secure compartmented information facilities in both countries; 24/7 security and counterintelligence operations centers; clean-room examination facilities; physical security infrastructure at declared sites including bounded inspection zones and hardened access control; incident-isolation response lab.

## 5. Independent Red Team and Challenge Exercise Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Red-team independence is achieved through operational separation and no advance knowledge of exercises, not through contractor status. Full-time employment is required for sustained challenge design, surge exercises, and credible KPI validation across the 90-day test.

**Explanation**:
Designs and runs the six mandatory unannounced blind challenges: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator. Validates KPI thresholds, calculates false-negative and false-positive rates with confidence intervals, and supplies the detection evidence that justifies the Go/Modify/Stop verdict.

**Consequences**:
Without this role, detection claims are unproven, KPI thresholds remain unvalidated, and exercises risk becoming scripted or announced. A Go verdict would rest on false confidence, while a genuinely undetected substitution would undermine the entire verification regime.

**People Count**:
min 32, max 52 — 2 independent red-team leads (one nominated per side, with no advance knowledge of exercise timing) plus 30–50 operators, analysts, and accredited clean-room examiners. Multiple full-time personnel are required to mount simultaneous challenges at multiple sites and preserve genuine independence from the inspection teams.

**Typical Activities**:
Design and execute unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator challenges; keep exercise timing secret from inspection teams; collect detection results by event type; compute false-negative and false-positive rates with confidence; validate KPI thresholds; and deliver filtered findings to the co-chairs.

**Background Story**:
Dr. Rafael Torres-Montoya, an independent red-team director based in Albuquerque, New Mexico, earned a Ph.D. in experimental physics from the University of New Mexico, spent 14 years at Sandia National Laboratories designing adversarial tests for treaty verification technologies, and served as a chief exercise designer for CTBTO-style integrated field exercises and a red-team lead on information-barrier evaluations for the UK-Norway Initiative. He specializes in creating unannounced challenges, injecting realistic false positives, measuring false-negative rates with confidence intervals, and forcing teams to confront vendor refusals and reluctant operators, and he wrote the Consortium's six mandatory blind-challenge scenarios. His relevance is that he supplies the independent detection evidence that justifies the Go/Modify/Stop verdict and prevents the exercises from becoming scripted or announced.

**Equipment Needs**:
Challenge-exercise payloads including substitute equipment, altered serialization tags, and inaccurate record packages; independent measurement and test instruments such as serialization scanners, power-analysis rigs, and attestation test rigs; tamper-evident materials for controlled tests; encrypted data collection and analysis tools for detection metrics; secure communications with no advance-knowledge schedule.

**Facility Needs**:
Isolated red-team operations center separate from inspection teams; designated exercise areas at sites including staging, spare-inventory, and maintenance zones; secure storage for challenge materials; neutral meeting and review rooms; clean-room access for vendor-refusal challenge scenarios.

## 6. Datacenter Site Preparation and Cross-Border Logistics Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Site preparation, parity calibration, customs/visa logistics, and fallback-site readiness require continuous, long-term coordination across two countries and multiple sites. Full-time employment ensures availability for inspections, drills, and unannounced challenges.

**Explanation**:
Ensures each matched declared site has N+1 power, 99.9% uptime, jointly controlled staging areas, bounded inspection zones, and secure facilities. Coordinates site surveys, parity scoring, fallback-site pre-qualification, visas, customs pre-clearance, diagnostic-equipment manifests, and the mandatory travel-and-clearance drill before the Phase One clock starts.

**Consequences**:
Without this role, sites would fail entry conditions, visa and customs bottlenecks would break the latency budget, and uneven inspection difficulty across matches could trip the asymmetric-access Stop condition. Environmental or grid failures could delay the 90-day test by weeks with no fallback.

**People Count**:
min 10, max 16 — 6 site-readiness leads (one per declared site) plus a central customs/visa logistics coordinator and regional support staff. Multiple people are needed because site surveys, staging construction, vendor coordination, and travel-and-clearance drills run in parallel across two countries and three geographic clusters.

**Typical Activities**:
Manage site surveys and parity scoring; oversee construction of staging areas and inspection zones; verify N+1 power and uptime; pre-qualify fallback sites; coordinate visas, customs pre-clearance, equipment manifests, and the travel-and-clearance drill; maintain environmental and grid-risk assessments; and support logistics for unannounced challenges.

**Background Story**:
Frank Weimin Jiang, a datacenter site-readiness and logistics manager based in Langfang, Hebei, earned a B.S. in mechanical engineering from Harbin Institute of Technology and an MBA from Peking University, and has spent 15 years managing construction, power, cooling, and operations for hyperscale datacenters in the Beijing/Hebei cluster, including tier IV facilities with N+1 redundancy and 99.9% uptime contracts. He led the physical surveys of the six candidate sites, built the six-attribute parity matrix, and coordinated the cross-border customs documentation for the Consortium's diagnostic equipment, including a successful travel-and-clearance drill. His relevance is that he ensures every declared site actually has jointly controlled staging areas, bounded inspection zones, secure facilities, and fallback capacity before the clock starts, and he prevents visa and customs delays from breaking the 24-hour physical-confirmation latency budget.

**Equipment Needs**:
Site survey and verification instruments including power quality analyzers, cooling and thermal meters, and uptime monitoring tools; construction and project-management systems; CAD/GIS for staging and zone layout; customs and visa logistics tracking platform; RFID/GPS equipment manifests and tag readers; portable power and cooling units for fallback and disaster response.

**Facility Needs**:
Site-readiness offices at every declared facility; jointly controlled staging-area construction zones; bounded inspection-zone infrastructure; logistics warehouses in Northern Virginia, Beijing/Hebei, and Guizhou; pre-qualified fallback site facilities; customs and visa processing liaison spaces.

## 7. Fiscal Escrow and Independent Audit Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Escrow signatory controls, envelope-coded drawdowns, quarterly reconciliation, and funding-timeliness KPIs require ongoing fiduciary responsibility and separation of duties. Full-time employment is necessary to avoid single-person fiscal control and ensure continuous accountability.

**Explanation**:
Ensures equal 50/50 pre-funding into a jointly signatory escrow, envelope-coded drawdowns, quarterly USD reconciliation, structured CNY conversion windows, and the funding-timeliness KPI with a 10-business-day suspension trigger. Provides independent auditing of both governments' domestic compensation disbursements and envelope-level cost control.

**Consequences**:
Without this role, delayed or asymmetric disbursement could act as a quiet veto that starves the program without formally triggering the withholding-funding Stop condition. Envelope overruns, currency shocks, or undisclosed domestic compensation could consume the contingency reserve and break reciprocal deployment.

**People Count**:
min 10, max 18 — 4–6 finance/escrow officers per side plus independent external audit firms. Multiple people are required for escrow signatory controls, envelope tracking, FX exposure management, and audit separation of duties; single-person fiscal control would be both a security and accountability failure.

**Typical Activities**:
Administer jointly signatory escrow; authorize envelope-coded drawdowns; perform quarterly USD reconciliation; manage CNY conversion windows and FX exposure; monitor the funding-timeliness KPI; audit domestic compensation disbursements; conduct envelope-level cost control and reforecasts; and report fiscal exceptions to the co-chairs.

**Background Story**:
Margaret 'Maggie' Danso, a fiscal and audit controller based in Washington, D.C., is a CPA with an MBA in finance from Johns Hopkins and 20 years of experience managing multi-billion-dollar sovereign escrow programs at the U.S. Treasury, including international climate funds and treaty-implementation accounts with jointly signatory control. She designed the Consortium's seven envelope codes, quarterly USD reconciliation, structured CNY conversion windows, and the 10-business-day funding-timeliness suspension trigger, and she leads the independent audit of domestic operator compensation in both countries. Her relevance is that she prevents delayed or asymmetric disbursement from acting as a quiet veto and keeps the $5 billion program fiscally accountable and envelope-compliant.

**Equipment Needs**:
Jointly signatory escrow management and accounting system; envelope-coded budget tracking and reporting software; quarterly reconciliation and FX conversion modeling tools; independent audit-management and evidence repositories; encrypted financial communications; KPI dashboard integration for funding-timeliness triggers.

**Facility Needs**:
Secure finance offices in both countries; escrow signatory meeting rooms with dual-key authorization controls; dedicated audit rooms with restricted records storage; secure videoconferencing to treasury and legislative oversight bodies.

## 8. Bilingual Training, Translation, and Readiness Certification Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Training, certified translation, glossary maintenance, readiness tracking, and certification support must operate for the entire program duration. Full-time mirrored teams are required to avoid single-person functions and sustain common discipline across approximately 450 staff.

**Explanation**:
Stands up the common training curriculum, the binding bilingual glossary, certified translation for evidence packages, and interpretation support for joint findings. Owns the integrated readiness tracker, joint certification packages, KPI dashboard reporting, and continuity planning so entry conditions are certified and trained personnel are sustained across political transitions.

**Consequences**:
Without this role, bilingual ambiguity becomes a ready-made access-denial weapon, staff lack common evidence-handling and information-barrier discipline, and entry conditions cannot be jointly certified. Unresolved interpretive disputes would create deferred deadlocks and stall or invalidate the Phase One verdict.

**People Count**:
min 18, max 30 — 6 mirrored technical linguists/engineers on the terminology commission plus training developers, certified translators, and readiness-tracker staff. Multiple people are required because glossary negotiation, common training for ~450 staff, evidence translation, and certification tracking all run simultaneously and cannot be single-person functions.

**Typical Activities**:
Maintain the binding bilingual glossary and interpretive annex; coordinate certified translation of evidence packages; run the common training curriculum for mirrored inspectors, technical, and legal staff; operate the integrated readiness tracker; prepare joint certification packages; track KPI dashboard reporting; and support continuity planning across leadership transitions.

**Background Story**:
Dr. Anika Zhou, a bilingual training and readiness-certification coordinator based in Beijing, earned a Ph.D. in applied linguistics from Beijing Foreign Studies University, trained as a conference interpreter at the Monterey Institute, and spent a decade developing security-cleared terminology systems and training curricula for IAEA safeguards inspectors and multilateral treaty-review conferences. She is fluent in English and Mandarin, expert in certified translation of technical evidence, and knowledgeable about adult learning, assessment, and readiness tracking, and she co-chaired the Consortium's terminology commission and built the integrated readiness tracker with named owners and certification fields. Her relevance is that she converts contested bilingual terms into a binding glossary, ensures all 450 staff share common evidence-handling and information-barrier discipline, and owns the joint certification package that starts the Phase One clock.

**Equipment Needs**:
Learning-management and common-training curriculum systems; simultaneous interpretation equipment; certified translation and computer-assisted translation tools; bilingual glossary and terminology database; integrated readiness tracker with certification fields; KPI dashboard reporting; secure document exchange and version control.

**Facility Needs**:
Training centers in the US and China with classrooms and interpretation booths; terminology-commission meeting rooms; readiness certification office; secure bilingual document storage; videoconferencing facilities linking mirrored training cohorts.

---

# Omissions

## 1. Dedicated Discrepancy Adjudication and Verdict Construction Lead

The plan explicitly requires mirrored adjudication units and lists 'discrepancy adjudication and suspension' as a top-level workstream, but the team document has no role accountable for operating the adjudication process. Without this function, unresolved-discrepancy age KPIs, materiality determinations, automatic-suspension recommendations, and the shared findings narrative that feeds the Go/Modify/Stop verdict lack a clear operational owner and risk being handled ad hoc by legal or political staff.

**Recommendation**:
Add a full-time, mirrored Discrepancy Adjudication and Verdict Construction unit with two co-leads (one per country) and dedicated legal, technical, and investigator staff. Assign it to track discrepancy age, apply pre-agreed materiality thresholds, prepare joint findings narratives, document deadlock procedures, and support the co-chairs without making the final political decision.

## 2. Covered-Equipment Schedule Custodian and Technical Configuration Manager

The plan states that 'accountable specialists must maintain a confidential, versioned technical schedule' for covered equipment, but the team roles do not assign this function. The schedule is the definitional backbone of the entire verification regime; if ownership is implicit, versioning, attribute-based coverage, fast-track provisional listings, and sunset reviews can become contested or drift, leaving new frontier-relevant equipment outside verification.

**Recommendation**:
Create a mirrored Covered-Equipment Schedule Custodian function with technical and legal specialists. This function should maintain the confidential attribute-based schedule under double-key specialist approval, publish a versioned changelog, pre-register dispute criteria, and manage 48-to-72-hour fast-track provisional listings when new equipment generations appear.

## 3. Operator and Vendor Compliance Liaison

The plan depends on mandatory participation by datacenter operators, manufacturers, maintenance providers, and logistics companies, including reporting, escort, confidentiality, and evidence-preservation obligations. The team document has legal drafting and site/logistics roles, but no operational function is responsible for day-to-day operator and vendor compliance, access scheduling, reluctant-operator handling, or escalation through the forced-evidence ladder.

**Recommendation**:
Add mirrored Operator and Vendor Compliance Liaison officers at each site, supported by a central coordination cell. Their duties should include managing access windows, monitoring access-delay incidents, verifying vendor reporting obligations, coordinating escorts, and triggering the vendor-refusal escalation ladder with documented outcomes and time-to-disposition metrics.

## 4. Joint Secretariat / Program Integration Lead

The pre-project assessment calls for a joint secretariat and integrated readiness tracker, and the program involves seven budget envelopes, six sites, roughly 450 staff, and multiple parallel workstreams. The current team has a readiness certification coordinator but no central program-integration function to maintain the integrated master schedule, resolve cross-workstream dependencies, and produce consolidated decision packages for the co-chairs.

**Recommendation**:
Establish a Joint Secretariat with two co-directors, one appointed per side, and a small dedicated PMO staff. This team should own the integrated readiness tracker, master schedule, risk register, and resource-allocation dashboard; facilitate monthly co-chair reviews; and ensure that every workstream lead has clear dependencies, milestones, and certification evidence.

## 5. Political Continuity and Government Liaison Function

A major risk identified in the assumptions and domain review is political discontinuity across leadership transitions, appropriations cycles, and shifting national priorities. The legal lead negotiates continuity commitments, but no role is responsible for sustained engagement with legislatures, heads of state, transition teams, and track-II channels. Without this function, political support can erode silently and entry-condition delays may go unmanaged.

**Recommendation**:
Add a senior mirrored Political Continuity and Government Liaison function, either as a distinct role or embedded in the Joint Secretariat. It should manage heads-of-state and legislative engagement, prepare transition briefings, track appropriations and entry-condition political actions, maintain the escrow-return and withdrawal scenario plans, and support a track-II dialogue channel to preserve technical relationships during political transitions.

---

# Potential Improvements

## 1. Remove Fictional Employee Biographies

The project plan explicitly states: 'Do not use ... fictional employee biographies.' The team document contains detailed named personas with invented career histories. This conflicts with the plan and weakens the credibility of the staffing model by blurring the line between illustrative examples and real, cleared personnel.

**Recommendation**:
Rewrite the team document to use role-based descriptions, required competencies, and actual staffing requirements without named fictional individuals. If illustrative personas are retained for training or concept development, clearly label them as 'notional illustrations' and exclude them from any official staffing, clearance, or certification documentation.

## 2. Separate Independent Audit from Fiscal Escrow Control

Role 7 combines fiscal escrow administration with independent auditing of domestic compensation and envelope spend. This creates a conflict of interest: the same function that controls drawdowns and reconciliation is also expected to independently audit those transactions. The plan requires independent auditing and fiscal accountability as a sovereign safeguard.

**Recommendation**:
Split the combined role into two functions: a Fiscal Escrow and Disbursement Controller responsible for escrow, drawdowns, currency conversion, and funding-timeliness KPIs, and an Independent Audit Director supported by external audit firms. The audit function should report directly to the co-chairs or an agreed joint oversight body and have unrestricted access to envelope records, compensation disbursements, and reconciliation logs.

## 3. Reconcile Role Counts with the 450-FTE Workload Model

The team document provides people-count ranges for each leadership area, but the sums are not clearly reconciled with the plan's approximate 450-FTE baseline or the USD 750 million inspectorate envelope. If role counts refer only to senior staff, the full inspectorate, technical, surge, and support staffing is undefined; if they refer to total staff, they appear too low for 24/7 coverage across six sites with separation of duties and leave backup.

**Recommendation**:
Publish a role-by-role FTE table that maps every unit to the workload formula: site count, shift coverage, leave backup, separation of duties, surge cadre, and support functions. Identify which roles are leadership only and which include full operational teams, and tie the resulting cost estimate to the appropriate budget envelopes so the 450-FTE baseline is internally consistent.

## 4. Strengthen Red Team Independence and Reporting Lines

The plan requires genuinely independent red teams with no advance knowledge of exercise timing. The team document places the Red Team Director as a full-time employee within the program, which creates a risk that exercise schedules, findings, or interpretation could be influenced by operational or political pressure, especially if the red team reports through the same chain as the inspectors it is testing.

**Recommendation**:
Establish the red team as a separately governed unit with direct reporting to the equal co-chairs or an independent joint appointment board. Give it a protected budget line, sealed exercise schedules, no operational inspection duties, and joint double-key protection against removal during Phase One. Its detection metrics and confidence intervals should feed the KPI dashboard without prior review by the inspectorate or site operators.

## 5. Clarify Role Boundaries and Decision Rights for Overlapping Functions

Several roles overlap operationally: intake staging involves the Inspectorate Operations Director, Hardware Identity Technical Lead, Information Barrier Security Director, and Site Preparation Manager. Without clear ownership of specific decisions, critical steps such as who controls a staging-area hold, who validates identity evidence, and who authorizes filtered evidence release can become delayed or disputed, threatening the latency budget.

**Recommendation**:
Create a RACI matrix for all high-risk operational processes, including staging intake, identity verification, evidence filtering, exit disposition, vendor refusal escalation, and cyber-incident isolation. Define which role is responsible, accountable, consulted, and informed for each step, and validate the matrix through tabletop exercises before Phase One begins.

# Expert Criticism

# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Treaty Verification & Managed Access Specialist

**Knowledge**: bilateral arms control verification, INF Treaty, Joint Verification Experiment, IAEA safeguards, OPCW managed access

**Why**: Converts bounded zones, filtered evidence, vendor-refusal ladder into managed-access procedures meeting Phase One latency and parity targets.

**What**: Advise on escort rules, zone access patterns, evidence preservation, and the inspector visa/customs drill so the 24-hour physical-confirmation budget is realistic.

**Skills**: inspection protocol design, managed access techniques, escort procedures, evidence chain-of-custody, challenge exercise planning

**Search**: treaty verification managed access expert, INF Treaty on-site inspection specialist, IAEA safeguards inspector consultant

## 1.1 Primary Actions

- Immediately convene a joint legal and verification drafting group to produce the Access and Managed Access Protocol. Treat this as a mandatory entry condition, not a subordinate workstream.
- Commission a Test and Evaluation Master Plan and power analysis from independent verification statisticians before any KPI thresholds are locked. Remove or mark TBD every unsupported threshold in the goal statement, including the '5% at 95% confidence' claim.
- Redraft the governance and decision-rights chapter to separate inspectorate facts from co-chair political decisions. Remove 'site findings' from the double-key authorization list and introduce automatic technical holds for unresolved discrepancies.
- Stand up the joint baseline inventory task force now with actual site data. Produce a resource-loaded schedule for serializing and reconciling the covered-equipment population within the 12-month entry-condition window, or revise the scope and schedule honestly.
- Convene the bilingual terminology commission immediately to define with worked examples: material, frontier-relevant, covered equipment, managed access, alternative demonstration, unverifiable, and material discrepancy.
- Negotiate and exercise the inspector visa and customs annex before any further planning reviews. If 48-hour visa issuance or pre-cleared tool manifests cannot be achieved, change the latency KPI or the access architecture—do not assume it away.
- Develop a red-team charter with joint selection, contractual independence from both governments, and statistically driven injection rules. Red teams must report to the technical inspectorate, not to the co-chairs.
- Produce a notional 90-day schedule with realistic event counts per site and per category. If the schedule cannot support the required number of independent blind challenges, amend the verification claim to what is actually demonstrable.

## 1.2 Secondary Actions

- Review OPCW managed-access provisions, IAEA complementary-access procedures, and the Joint Verification Experiment information-barrier reports. Map each precedent to a clause in your proposed protocol.
- Run a governance war-game with both national legal teams covering deadlock, manufactured discrepancy, vendor refusal, and operator delay.
- Compile a list of actual candidate datacenters with floor plans, vendor contracts, and preliminary covered-equipment counts. Do not wait for formal government nomination.
- Coordinate with ministry and treasury lawyers on the legality of escrow pre-funding. Identify a fallback fiscal mechanism if a jointly signatory escrow cannot be structured under either legal system.
- Build a mock staging and inspection area, then conduct one full managed-access exercise: intake, identity verification, installation observation, and exit disposition.
- Convene a small group of former INF/IAEA/OPCW inspectors to review the draft access protocol and KPI design before the next consultation.
- Use track-II verification organizations such as VERTIC or IPNDV to get an independent technical review of the statistical test design and the managed-access protocol.

## 1.3 Follow Up Consultation

Bring the draft Access and Managed Access Protocol, the draft Test and Evaluation Master Plan with challenge-event counts and confidence-interval calculations, and a revised governance decision-rights matrix. Also bring site survey data and the baseline inventory plan for at least two candidate datacenters. We will walk through a mock managed-access denial scenario and stress-test the KPI statistical assumptions with real numbers.

## 1.4.A Issue - The verification access architecture is not an access architecture; it is an information-protection wish list.

The plan repeatedly says 'bounded inspection zones,' 'filtered evidence,' 'clean-room protocols,' and 'no single source decisive,' but it never answers the fundamental treaty-verification question: what is the minimum access the inspectorate may demand, and what may the inspected side refuse or manage? INF, IAEA, and OPCW practice all allow managed access to protect legitimate secrets, but any denial or restriction must be compensated by alternative arrangements sufficient to satisfy the inspection objective. Your plan inverts this: protection appears to have veto power, because every evidence stream can be filtered and every area can be bounded without a pre-agreed floor. You will enter Phase One with each side able to deny meaningful inspection by pointing to sensitive data, and every denial becomes a legal dispute rather than a verification result.

### 1.4.B Tags

- managed-access
- access-rights
- information-barrier
- legal-baseline
- inspection-procedure
- denial-resolution

### 1.4.C Mitigation

Draft a Protocol on Access and Managed Access as an annex to the bilateral instrument before the clock starts. Specify: (1) all locations, equipment, and records associated with declared covered equipment are subject to inspection, including staging, storage, maintenance, and disposal areas; (2) the inspected party may propose managed-access measures such as shrouding, escort, filtered display, or clean-room reading, but may not simply deny; (3) any managed-access measure must be accompanied by an alternative demonstration adequate to verify the identity and disposition of the covered equipment; (4) all denials and proposed alternatives are logged, with a joint technical team deciding within 48 hours whether the alternative satisfies the inspection objective; (5) an unresolved denial counts as a material discrepancy, not a graceful 'unverifiable' category. Use OPCW managed-access examples, the Joint Verification Experiment information-barrier approach, and IAEA complementary-access procedures. Negotiate a per-site access matrix for all six sites during the entry-condition phase. Run at least two live access-denial/managed-access challenge exercises before clock start, and train every inspector to distinguish a denial from a genuinely adequate managed-access alternative.

### 1.4.D Consequence

Without a legal floor of access rights, the layered-evidence hierarchy is fiction: the inspected side can filter every layer. The blind-challenge results will measure only what the inspected side allowed, not what the inspectorate could detect. The Go/Modify/Stop verdict becomes a diplomatic artifact, not a verification judgment.

### 1.4.E Root Cause

The team treated information protection as an evidence-design problem and lost the fundamental managed-access principle: protection of sensitive data must not defeat the verification objective. This is a treaty-law error, not a technical one.

## 1.5.A Issue - False-negative '5% at 95% confidence' is statistically unsupported and cannot be proven in a 90-day, six-site test as designed.

A false-negative rate is not a management KPI you set; it is a property of a detection system measured across a defined population of challenge events. You have not specified how many fabricated events, of which categories, will be injected into which sites, over what period, or how confidence intervals are computed. Under the rule of three, if you run only 20 independent blind challenge events and see zero misses, the upper 95% confidence bound on the false-negative rate is about 14%; you would need roughly 60 events to claim an upper bound near 5%. Your 90-day schedule likely cannot support 60 meaningful challenges per material-change category—arrival, removal, substitution, transfer, maintenance, decommissioning—with independent injection and no cross-site contamination. Claiming 5% at 95% confidence without a power analysis is exactly the 'unsupported figure' the plan says to mark provisional or TBD, but then the Go decision is based on nothing. The same problem afflicts 'unverifiable equipment no more than 2 units or 1%' and 'reciprocal access parity within 0.9–1.1': no denominators, no tolerance rationale, no validation plan.

### 1.5.B Tags

- KPI-validation
- statistics
- false-negative
- sample-size
- test-design
- probability-of-detection
- threshold-justification

### 1.5.C Mitigation

Produce a Test and Evaluation Master Plan before any KPI thresholds are locked. It must include: (1) precise definitions of each material-event category and the detection event under test; (2) a statistical design specifying the number of challenge events per category, injection schedule, blinding and independence controls, and the formula for confidence intervals; (3) a feasibility check—if the required challenge-event count exceeds the 90-day window, either reduce the statistical claim to a reported detection rate with confidence intervals or extend the test; (4) pre-registered analysis rules so thresholds cannot be moved after results are known; (5) a pilot exercise at two sites before clock start to validate false-negative and false-positive measurement procedures. Consult national laboratory statisticians and test-evaluation experts from both sides. Mark all unsupported thresholds TBD until the Test and Evaluation Master Plan is approved. For 'unverifiable equipment' and 'parity,' define numerator and denominator, data source, and acceptable margin based on actual site counts and event frequencies; do not invent tolerances.

### 1.5.D Consequence

As written, the KPI dashboard creates an illusion of quantitative rigor. If challenged, the other side will reject the Go decision because the confidence claim cannot be substantiated, or one government will game the event count to manufacture a false Go. The final verdict becomes a political punt, and the verification credibility of the entire USD 5 billion investment collapses.

### 1.5.E Root Cause

The plan borrows generic project-management target language such as '95% confidence' from software and test-management contexts without understanding that verification confidence is a statistical inference over a defined challenge population. It is an honesty problem: unsupported numbers were stated as targets rather than hypotheses to be tested.

## 1.6.A Issue - Double-key authorization for 'site findings' will convert every operational observation into a diplomatic veto.

The initial plan states that 'site findings' require double-key authorization. If that is literal, each joint finding—a serial-number match, a witnessed destruction, a video still—must be co-approved before it can be recorded as a fact. That is unworkable and contrary to every modern verification precedent: IAEA inspectors record technical observations and report them; OPCW inspection reports are drafted by the inspection team and transmitted; States Parties do not sign off on each finding. Your own Decision 1 correctly reserves double-key for material findings and sanctions, but the ambiguity remains unresolved in the governing text. The deadlock procedures also allow a co-chair to block closure of an unresolved material discrepancy indefinitely, and the no-casting-vote structure means one side can stall rather than decide. Without an independent professional inspectorate and a clear separation between technical facts, verification conclusions, and political decisions, the 90-day clock will be consumed by arguments over what the inspectors actually saw.

### 1.6.B Tags

- governance
- double-key
- deadlock
- independent-secretariat
- operational-tempo
- verification-credibility
- decision-rights

### 1.6.C Mitigation

Restructure governance into three tiers. First, inspectorate facts: credentialed inspectors from both national teams record objective observations on-site; these are not subject to co-chair approval and are entered immediately into the ledger. Second, materiality and verification conclusions: a joint technical adjudication panel decides using pre-agreed evidentiary rules; panel decisions require a technical majority, not an absolute veto, with any dissent recorded. Third, sanctions, suspension, protocol changes, and budget changes: reserved to the co-chairs under double-key, with a default rule that failure to agree within 10 business days on a material finding automatically escalates the matter and places the site on technical hold—freezing equipment movement and preserving evidence—pending resolution. Clarify in the legal text that 'site findings' means material adverse findings only, not routine observations. Add an independent technical director or joint chief inspector, not a project sponsor, to lead the inspectorate and sign findings in a professional capacity. Run a governance war-game with both legal teams to test deadlock scenarios before the clock starts.

### 1.6.D Consequence

If left unresolved, any single disputed observation can stop the entire verification process. The no-casting-vote design, intended to prevent unilateral overrule, becomes a machine for indefinite paralysis. Operators will learn to exploit the dispute channel to shield discrepancies, and the Go/Modify/Stop output will be nothing more than a measure of who was more patient in the final negotiation.

### 1.6.E Root Cause

The authors were so committed to the no-unilateral-overrule principle that they conflated political control with technical professionalism. Equal co-chairs are appropriate for policy decisions but destructive when applied to every inspection fact.

---

# 2 Expert: US-China Bilateral Treaty Counsel

**Knowledge**: US-China public international law, bilateral executive agreements, double-key governance, bilingual treaty drafting, domestic implementing legislation

**Why**: Drafts the bilateral instrument, glossary, deadlock machinery, and domestic access-authority language that are mandatory entry conditions before the Phase One clock starts.

**What**: Review the instrument and interpretive annex, pre-register contested terms, and align both countries' implementing legislation with operator and vendor compulsion obligations.

**Skills**: legal drafting, treaty negotiation, legislative analysis, dispute pre-registration, cross-jurisdictional compliance

**Search**: US-China international law counsel, bilateral treaty drafter, public international law implementing legislation expert

## 2.1 Primary Actions

- Convene the joint legal task force including constitutional, treaty, appropriations, export-control, and data-protection lawyers immediately. Deliver a legal-form memorandum by 2026-10-30, a bilateral instrument outline by 2026-12-18, and model implementing legislation for both sides before the next certification review.
- Resolve the Consortium's legal personality and status. Decide whether it will be established as a limited-purpose international organization or as a joint program executed through existing national agencies, and draft the necessary status/headquarters agreement, privileges-and-immunities clause, escrow-holding authority, and liability/indemnity/cross-waiver provisions.
- Negotiate and conclude the inspector visa, customs, and cross-border evidence annex, including 48-hour multiple-entry visas, pre-cleared diagnostic-tool manifests, privileges and immunities limited to official verification acts, and conflict-of-law rules for data and evidence transfer. Complete the full travel-and-clearance drill before any Phase One clock start.
- Retain an independent verification-statistics expert and produce a pre-registered statistical analysis plan covering sample sizes, confidence-interval methods, false-positive definitions, unresolved-event handling, parity tolerances, and materiality corridors. Start pilot blind challenges during the entry-condition phase and mark all unvalidated KPI thresholds as TBD.
- Draft and adopt the governance annex with objective automatic-suspension triggers, a fixed deadlock clock, conservative default outcomes, an independent technical-fact mechanism, and pre-registered bad-faith indicators. Do not recommend any certification until this annex is legally reviewed and incorporated into the bilateral instrument.
- Elevate and formally track the three additional gates—certified baseline inventory, inspector-access annex, and escrow pre-funding—as mandatory entry conditions with named owners, evidence slots, and co-chair certification fields, alongside the original seven conditions, against the 2027-09-04 boundary.
- Obtain written legal opinions from both governments on domestic access authority, appropriation and escrow feasibility, private-rights limitations, data-transfer restrictions, and export-control compliance. Bring these opinions, not narrative summaries, to the next consultation.

## 2.2 Secondary Actions

- Engage the IAEA, OPCW, VERTIC, and IPNDV verification communities to study managed-access legal frameworks, inspector-status agreements, and statistical methods for small-sample verification regimes.
- Separate the 'killer application' communications narrative from the legal scope of the instrument. An unclassified crisis-stability briefing is useful for political continuity, but it must not expand or imply verification obligations beyond declared-equipment change verification at declared sites.
- Begin legislative outreach in both countries now: brief U.S. appropriations and foreign-affairs committees and Chinese legislative and State Council bodies so implementing legislation is not stuck at the entry-condition deadline.
- Run tabletop exercises of the governance annex, including deadlock, manufactured discrepancy, automatic suspension, and leadership-escalation scenarios, and revise the annex based on the results.
- Develop a full conflict-of-laws matrix for every class of evidence and data that crosses the border, mapping U.S. export-control law, Chinese data-security and state-secret law, privacy statutes, and classification rules to the specific evidence type and proposed protective control.
- Prepare political-continuity mechanisms—multi-year appropriation language, transition briefing requirements, escrow-return clauses, and a track-II channel—but treat them as risk mitigation, not as substitutes for a legally binding instrument.
- Require all budget owners to map every expense to an envelope and to document appropriations-law constraints, especially whether advance appropriations or a jointly signatory escrow is permissible under each country's fiscal law.

## 2.3 Follow Up Consultation

The next consultation must focus on: one, the legal-form memorandum and the selected option for Consortium legal personality; two, the draft governance annex with objective automatic-suspension triggers, deadlock default rules, and materiality corridors; three, the draft statistical analysis plan with challenge sample sizes and confidence-interval calculations; four, the status of the inspector visa/customs/cross-border evidence annex and the completed travel-and-clearance drill; five, the legal opinions on appropriation, escrow, domestic access authority, and data-transfer restrictions; and six, an updated integrated readiness tracker showing named owners, evidence slots, and co-chair certification fields for every mandatory entry condition. Bring drafts, not slide decks, and do not schedule any further operational planning until the legal and statistical foundations are certified.

## 2.4.A Issue - Legal form, domestic authority, and legal personality are undefined; the plan currently rests on political commitment rather than enforceable law

The entry conditions list 'signed bilateral instrument' and 'enacted domestic access authority' as if those were self-executing. Under U.S. law, an agreement that imposes binding obligations on private parties, obligates $2.5 billion, and authorizes foreign officials to exercise verification powers inside the United States cannot be accomplished by political endorsement or a sole executive agreement alone. You likely need either an Article II treaty with Senate advice and consent or a congressionally authorized executive agreement, plus implementing legislation that creates the legal authority, appropriates funds, and resolves constitutional constraints, liability, privileges and immunities, export controls, customs, data transfer, and private-property objections. China's side similarly requires domestic legal authorization and a determination of how the instrument ranks in domestic law. The plan also never addresses the Consortium's legal personality: it cannot hold escrow funds, sign leases, employ roughly 450 people, or own evidence systems unless it is established as an international organization or hosted by one or both governments with clear legal capacity. There is no status/headquarters agreement, no dispute-settlement clause, no liability/indemnity/cross-waiver regime, and no resolution of cross-border transfer restrictions on protected data or the confidential covered-equipment schedule. As drafted, no entry condition can be certified because the legal authority to compel anyone to do anything does not exist.

### 2.4.B Tags

- treaty-form
- implementing-legislation
- legal-personality
- privileges-immunities
- data-transfer
- conflict-of-laws

### 2.4.C Mitigation

Convene a joint legal task force now, including constitutional, treaty, appropriations, export-control, data-protection, and national-security lawyers from both governments. By 2026-10-30, produce a legal-form memorandum identifying the required domestic legal basis for each side. By 2026-12-18, draft the bilateral instrument with a legal personality option, status of the Consortium, headquarters/secretariat arrangements, privileges and immunities limited to official verification acts, liability and indemnity provisions, cross-waivers, dispute-settlement provisions, termination and escrow-return clauses, and explicit rules for cross-border evidence transfer. Draft model implementing legislation for both sides that overrides conflicting private-law objections while respecting constitutional limits on search, seizure, and property. Obtain legal opinions from the U.S. State Department, DOJ, Chinese MOFA, and legislative-affairs bodies on whether the proposed access authority is constitutional and enactable. Consult IAEA, OPCW, and IPNDV legal models for managed access, inspector status, and bilateral verification institutions. Before any further planning, decide whether the Consortium will be a limited-purpose international organization or a joint program executed through existing national agencies with no separate legal personality.

### 2.4.D Consequence

Without this, the program is a diplomatic handshake, not a legal regime. The first operator refusing entry, the first inspector incident, the first export-control objection, or the first data-transfer challenge will produce domestic litigation or criminal exposure. The U.S. Congress will not appropriate $2.5 billion against an undefined legal instrument, and no Chinese agency will accept binding obligations without clear domestic authorization. The entry-condition phase will fail before verification begins.

### 2.4.E Root Cause

Political leadership backing has been conflated with domestic legal authority. Treaty counsel and constitutional lawyers were not at the table when the instrument and access-authority assumptions were drafted.

## 2.5.A Issue - The KPI thresholds are not a statistical design; the 90-day six-site test cannot produce a defensible Go/Modify/Stop verdict without a pre-registered analysis plan

The plan says 'false-negative rate no greater than 5% in blind challenges at 95% confidence' but does not specify the number of challenges, the denominator, the analysis population, the confidence-interval method, or how unresolved and censored events are handled. With six sites and 90 days, you cannot simply assert this threshold. To claim a 95% upper confidence bound below 5% with zero missed events, you need roughly 60 successfully conducted challenges; to claim that by event type, you need that many per event type. The final verdict also depends on 'credible detection' and 'reciprocal access parity,' but there is no statistical definition of parity, no pre-agreed tolerance calculation, no plan for false-positive costs, and no rule for aggregating small samples. The plan's own pre-project assessment says KPI thresholds are unvalidated, and the SWOT analysis admits they are provisional, but the project plan still states them as measured success criteria. This is a recipe for a contested verdict: one side can argue that two missed events out of five 'unannounced arrivals' is a 40% false-negative rate, even if the overall test met the target.

### 2.5.B Tags

- statistical-power
- sample-size
- KPI-validation
- false-negative
- false-positive
- materiality-corridor

### 2.5.C Mitigation

Retain an independent verification-statistics expert or a recognized arms-control verification methodology group before the clock starts. Produce a pre-registered statistical analysis plan that fixes: the number and type of blind challenges per event category, the required sample size for the claimed confidence level, the exact confidence-interval method, the treatment of unresolved or equipment-inaccessible events, the definition of false positive, the parity metric with pre-agreed tolerance, and the aggregation rule for site-level and event-level results. Run pilot blind challenges in staging, spare-inventory, and maintenance areas during the entry-condition phase to generate preliminary detection data and validate the information barrier. Mark every unsupported KPI threshold as 'TBD' in all documents and specify the data source and validation study required before it can be adopted. Define materiality corridors numerically: for example, what number of unverifiable units at a site is tolerated, what number forces suspension, and what pattern of vendor refusals constitutes systemic failure. Determine explicitly what Phase One can and cannot claim statistically given six sites and 90 days, and state that limitation in the final verdict.

### 2.5.D Consequence

Without a pre-registered statistical design, the Go/Modify/Stop verdict is not a scientific finding; it is a negotiation. Unvalidated thresholds can produce a false Go that destroys the program's credibility or a false Stop that wastes $5 billion. Either government will be able to challenge the result by choosing a different denominator or reading the confidence intervals differently.

### 2.5.E Root Cause

KPI targets were treated as policy commitments rather than testable hypotheses. The constraints imposed by six sites, 90 days, rare events, and real-world production disruption were not fed into a statistical design.

## 2.6.A Issue - The no-casting-vote double-key governance is not a decision rule; deadlock, materiality, and automatic suspension remain exploitable and undefined

Saying 'no chair has a casting vote' and 'no majority procedure may allow one country to overrule the other' is not a governance mechanism; it is an invitation to paralysis or tactical delay. The plan says deadlocks escalate to heads of state or party leadership after 10 business days, but that is a political process, not a legal resolution procedure, and it can be repeated indefinitely. You never define what counts as a deadlock, who decides whether a discrepancy is material, what the default is when the co-chairs cannot agree, how automatic suspension can operate if the materiality determination itself requires double-key, or how to distinguish a genuine discrepancy from a manufactured one. The Stop trigger 'a government shields an operator' has no definition, no evidence standard, and no adjudication path. As drafted, a co-chair can block an automatic suspension by disputing materiality, or can manufacture a discrepancy to force suspension of the other side's site. The plan cannot both promise automatic suspension and require double-key agreement to trigger it.

### 2.6.B Tags

- deadlock-default
- automatic-suspension
- materiality-definition
- shielding
- bad-faith-indicators
- dispute-resolution

### 2.6.C Mitigation

Pre-register in the instrument a governance annex with objective automatic-suspension triggers that do not require a co-chair vote. For example: an event not recorded within the agreed local-recording window, a covered item exiting without an assigned disposition after a fixed period, ledger divergence exceeding the reconciliation bound, access denied for more than a stated number of hours, or unverifiable equipment exceeding the site threshold. These triggers automatically place the affected equipment or site on hold while all other verification continues. Define the deadlock clock precisely: if co-chairs fail to issue a joint decision by a fixed deadline, the default is conservative suspension of the disputed action or area; no unilateral expansion, no unilateral blocking of an automatic trigger, and no leadership escalation more than once. Create a joint technical-fact mechanism for routine discrepancies; for contested materiality, refer the technical facts to a pre-agreed independent expert panel, with sanctions and suspension remaining under double-key after the facts are fixed. Pre-register bad-faith and shielding indicators, such as deliberate destruction of records, refusal to permit independent diagnostics, or government-directed non-cooperation, but do not require proof of intent for automatic consequences. Add a final-deadline clause: if leadership does not resolve a deadlock within 30 days, the affected activities remain suspended and no Go verdict can issue until the deadlock is resolved by joint written instruction.

### 2.6.D Consequence

Without objective triggers and a default decision rule, the no-overrule structure will be weaponized. The side that wants to shield an operator can dispute materiality forever; the side that wants to halt the program can manufacture discrepancies or simply refuse to agree. The 90-day window will be consumed by deadlock, and the final verdict will be either impossible or meaningless.

### 2.6.E Root Cause

The drafting team tried to preserve sovereign equality by prohibiting voting but did not build a default rule for inaction. It deferred the hard materiality design and substituted a political escalation path for a legal one.

---

# The following experts did not provide feedback:

# 3 Expert: Frontier AI Hardware Assurance Auditor

**Knowledge**: datacenter hardware lifecycle, semiconductor supply chains, equipment serialization, cryptographic attestation, hardware decommissioning

**Why**: Defines the confidential versioned covered-equipment schedule, intake staging identity gates, and exit dispositions that are the core of material-change verification.

**What**: Advise on attribute-based equipment coverage, staging-area identity checks, attestation limits, and the five exit dispositions in the ledger.

**Skills**: supply chain auditing, hardware identity verification, serialization programs, disposal verification, technical schedule versioning

**Search**: hardware assurance auditor, datacenter equipment lifecycle specialist, semiconductor supply chain verification expert

# 4 Expert: Information Barrier & Counterintelligence Engineer

**Knowledge**: information barrier design, clean-room examination, counterintelligence, critical infrastructure cybersecurity, sensitive data protection

**Why**: Balances filtered evidence with substitution detection and protects workloads, model weights, source code, and security architecture during joint inspections.

**What**: Specify filtered workstations, zone boundaries, and cyber-isolation drills; validate via blind challenges that identity metadata survives filtering.

**Skills**: filtered evidence systems, clean-room protocols, counterintelligence monitoring, incident isolation, adversarial validation

**Search**: information barrier engineer, counterintelligence technical specialist, clean-room evidence inspection cybersecurity expert

# 5 Expert: Red Team Adversarial Exercise Designer

**Knowledge**: red team operations, adversarial simulation, physical penetration testing, datacenter security, concealment tradecraft

**Why**: Designs the six mandated blind challenge types to validate false-negative rates and silent-window bounds before any Go decision.

**What**: Direct live exercises for unreported arrival, substituted equipment, vendor refusal, and reluctant operator scenarios using independent, no-advance-knowledge teams.

**Skills**: scenario planning, detection evasion testing, exercise instrumentation, KPI validation, opsec discipline

**Search**: red team exercise designer, adversarial simulation datacenter security, blind challenge testing expert

# 6 Expert: Bilateral Fiscal Governance Auditor

**Knowledge**: sovereign escrow administration, government appropriations, USD-CNY FX risk, envelope-based budgeting, audit compliance

**Why**: Prevents quiet fiscal vetoes and validates the 10-business-day funding delay trigger, escrow pre-funding, and quarterly reconciliation.

**What**: Review contribution-release mechanics, envelope mapping, and audit exceptions to ensure funding timeliness KPI prevents asymmetric delay.

**Skills**: escrow structuring, forensic accounting, currency risk management, government budget oversight, KPI threshold validation

**Search**: sovereign escrow fiscal governance expert, bilateral program auditor, government appropriations compliance specialist

# 7 Expert: Bilingual Inspectorate Workforce Planner

**Knowledge**: national security clearance processing, bilingual technical recruitment, shift scheduling, surge capacity planning, training curriculum design

**Why**: Builds and clears the ~450 FTE mirrored inspectorate with no single-person critical functions, meeting the inspector-approval entry condition.

**What**: Model staffing from site count, 24/7 coverage, 1.5x leave multiplier, and surge needs; accelerate clearances and second existing verification personnel.

**Skills**: workforce modeling, clearance pipeline management, bilingual hiring, training development, separation-of-duties design

**Search**: workforce planner security clearance hiring, bilingual inspector recruitment training, national security staffing surge specialist

# 8 Expert: Replicated Ledger & Attestation Architect

**Knowledge**: tamper-evident ledgers, hash-chain cryptography, cryptographic attestation, distributed replication, divergence reconciliation

**Why**: Implements local-first hash-chained recording and bounded cross-national synchronization without relying on banned blockchain architecture.

**What**: Advise on ledger latencies, divergence alerts, hash-commitment exchange, and penetration-test outcomes to meet 5-minute local and 1-hour sync targets.

**Skills**: cryptographic design, tamper-evident systems, penetration testing oversight, latency optimization, reconciliation protocols

**Search**: tamper-evident ledger architect, cryptographic attestation expert, hash-chain synchronization specialist

# Work Breakdown Structure

```csv
Level 1,Level 2,Level 3,Level 4,Task ID
Bilateral Datacenter Verification,,,,66d032ed-4403-47d3-9afa-6197d4eedb69
,Project Management and Political Continuity,,,cb6b5ec6-e7db-476e-ad36-b7ab605de88b
,,Establish joint secretariat and integrated readiness tracker,,116ce4ec-5899-4642-8177-e27cd7f90ec0
,,,Define secretariat charter and co-location arrangement,d6ccc801-8060-4e4b-9729-38a46427d85e
,,,Appoint interim co-secretaries and core staff,e90a44d5-b80f-4d3a-9c36-5907b97b7e8c
,,,Design integrated readiness tracker with metrics,29023121-c285-4a52-a0a8-94ae033fe410
,,,Pilot tracker with weekly data submissions,f09e4681-c8c8-413e-8b11-b7c1640c40b8
,,Develop project management plan and reporting cadence,,bbc7d518-50f9-4cf6-9cda-529bb70e0e61
,,,Define project management framework and standards,7b833575-95c3-4c1a-b9ec-773caca8612d
,,,Establish reporting cadence and templates,6362d580-d6ac-41f7-90d8-c10e08c5b59f
,,,Assign roles and responsibilities for plan maintenance,c7808068-9736-418d-89ed-b250f90a7b20
,,,Align plan with readiness tracker and governance,6a7d89ae-a32f-4bff-b3f7-f7984adec4ec
,,,Baseline project management plan and version control,34557078-8996-45ca-ab80-55641a49ca6c
,,"Manage risks, issues, and escalation to leadership",,04d8a8b3-af48-4bb2-adb5-9121f40dbe3a
,,,Identify and register risks and issues,9e7f616d-089c-4ec9-8c30-607a36ee44f5
,,,Assign named owners and mitigation actions,f5ad3884-28ac-42b5-aef1-68be4c59a623
,,,Run monthly integrated readiness reviews,5f00d247-3007-4230-8b75-6dee09bfc44e
,,,Escalate unresolved issues to leadership,8304ce86-cdf2-42ca-94c9-8f0d25bceac5
,,,Track and close risk mitigation tasks,930fb1d5-81fe-4a8d-86ca-17a66b587f39
,,Engage stakeholders and maintain public KPI dashboard,,06b4a9a4-7b81-4a90-a9dd-78277c5fd331
,,,Map stakeholders and communication channels,653cc159-1dce-45e2-923d-4801b30a1289
,,,Define public KPI metrics and data sources,435870b6-b9a9-4202-8a61-61f1a1c747ef
,,,Build KPI dashboard and reporting views,9e26476a-882c-4dda-8460-3b8c359e4b28
,,,Operate stakeholder briefings and feedback loops,4361c187-9b5e-43d9-87ca-c3c74c12032e
,,,Review and refresh dashboard and engagement plan,2a734ba9-5833-4272-b25b-f06359a4ec97
,,Secure political continuity commitments and transition-briefing requirements,,27fada57-60b5-4c9d-8c78-501ce38202e3
,,,Identify continuity options and stakeholder requirements,187b0c04-3cf6-4e03-9038-df28dfe097e5
,,,Draft model continuity clauses and briefing templates,93b82441-18fe-4f0c-b0b3-d0a82b00f182
,,,Secure formal commitments from both governments,b98126e3-8f09-4df7-a287-b3f3c99d51eb
,,,Codify transition-briefing packages and successor procedures,00624a79-669e-475e-9f35-ed690205162a
,,,Conduct continuity scenario validation exercises,94dce766-951f-420d-bf62-d1a46f9424d7
,,Conduct transition-scenario continuity exercises,,e5496569-4f65-4566-b969-80af471184bf
,,,Prepare transition scenario materials and briefing books,20c4a1ee-202f-4486-b0fb-45078a2c2de2
,,,Schedule and brief continuity exercise participants,6452f596-689e-4b66-b32a-d91d7b0c1974
,,,Facilitate tabletop continuity exercise sessions,1e5e9c15-16ae-405f-a2dd-144fbcb5bbea
,,,Analyze results and update continuity plans,f17a1f7d-d391-44c8-94ad-4b493693ea6c
,,"Administer contracts, independent audits, and versioned records",,57efc66c-ae37-49a9-afee-40d36c845521
,,,Administer vendor and operator contracts,6661bf38-b2f6-4aa8-ae5d-51dc69000865
,,,Coordinate independent audits and corrective actions,a7802d6f-b25e-42d3-a656-fbbd23ad51ec
,,,Maintain versioned records and bilingual documents,77812fd6-111d-4a58-9c78-70b72b66a95d
,,,Monitor contract performance and deadlines,60c56fae-8d0a-45bb-adc8-1cc8dc87dd12
,Legal and Governance Establishment,,,97154c3d-5afa-444e-af8b-955b153674ef
,,Negotiate and sign bilateral instrument establishing the Consortium,,f08e472f-2b84-4e6a-96f6-be9ede2e4f13
,,,Prepare negotiation mandate and draft bilateral instrument,aca53be9-1416-45c8-b8d0-535979f389c9
,,,Negotiate governance and reciprocal access clauses,cee5042e-a6cf-404a-a435-50b0e8c99e4b
,,,Obtain domestic legal and political approvals,a0bcfc93-f79d-48b5-84f9-a12f45cbda91
,,,Sign instrument and exchange certified copies,52c3a13c-858c-4d05-b21b-cf1bb39d534c
,,"Establish double-key governance, deadlock, and automatic suspension procedures",,23779087-d888-405f-bea6-e770d2e1d554
,,,Define double-key decision rights and voting rules,ba1f0b5a-d77f-4d28-89e0-b23ab313ec72
,,,Design deadlock escalation and adjudication procedures,668a4e0c-3f11-43fd-afd0-1abf68cd5298
,,,Define automatic suspension triggers and resumption criteria,3fdd5715-642d-4e76-9e9c-5945a1a2a2ff
,,,Draft governance clauses into bilateral instrument,42005b59-1f2a-4831-b685-b2daf6923313
,,,Validate governance procedures through tabletop exercises,c1916726-4c11-4cf6-8455-59146d7df7b3
,,Create binding bilingual glossary and interpretive dispute annex,,d481f900-4932-428f-8a99-1dd5ae48dfc4
,,,Establish joint bilingual terminology commission,b3cb37d7-c087-4f02-80cb-5bf7e30ce048
,,,Draft binding bilingual glossary of central terms,91333422-2c16-4d16-84bc-2d457b22db07
,,,Develop interpretive dispute annex,3d0923b7-1c08-47fc-8b75-a8974127be72
,,,Align glossary with covered-equipment schedule,fc4c2187-cdc5-4ddb-8bb0-f8fc03718ab5
,,,Validate translations and finalize approvals,3bf0f7b0-25d9-4746-9c47-adffed0b788c
,,Enact domestic access authority in both countries,,d6637377-c53a-4147-88f1-d225f320af88
,,,Draft domestic implementing legislation,554c1ba1-4469-4769-883d-c49323a5f31f
,,,Conduct legislative stakeholder consultations,fe7e6743-cea1-4045-bac5-d3767ebd429e
,,,Obtain formal legal opinions and clearance packages,ff734917-0b0a-43af-a086-daa55f078670
,,,Secure passage and enactment of access authority,34b41a31-304e-4681-bd4f-5738b3bf6073
,,"Negotiate inspector visa, customs, and cross-border access arrangements",,e59cfed3-853c-4ca0-8abb-15d12d1d5460
,,,Define inspector access and equipment manifest scope,faec7494-8314-4b2e-a507-92d116a051cf
,,,Negotiate standing visa arrangements,b1d8612c-f2b7-4516-aa33-82323d80d88a
,,,Negotiate customs pre-clearance procedures,b5a58ed9-42cf-48ab-9109-f280d71c87a3
,,,"Define privileges, immunities, and liability terms",37db9e5e-7959-495b-bb02-3deacd91e222
,,,Conduct end-to-end travel and clearance drill,5c8090db-ae76-4adf-9e5f-e766b271a04a
,,Adopt confidential attribute-based covered-equipment schedule and versioning rules,,56e41e5b-fc32-4ffc-9104-db13fd55bcd4
,,,Define covered-equipment attributes and coverage criteria,f076a81a-cffa-4851-b8a7-5b966db3e494
,,,Establish double-key approval and dispute procedures,1f8236f4-7c8d-4d70-ac53-430718c32e15
,,,Create fast-track provisional listing mechanism,58c80616-6a52-4b5a-ad9d-f3111dcddfdb
,,,"Develop versioning, changelog, and sunset-review rules",e149b0c7-95ab-4299-9319-12c0bd0bf788
,,Obtain formal legal opinions from both governments on entry conditions,,12723e42-d257-4efc-adb9-765e246d6a1e
,,,Define common legal questions and evidence package,c8928fcf-fca9-4f51-91f1-fcd77ebc2237
,,,Coordinate parallel national legal reviews,53a36ecc-b542-4830-8f4e-a068af083f66
,,,Reconcile divergent legal interpretations,b25ecca3-4983-4dd2-b25c-df9d4c487fa4
,,,Obtain final signed formal legal opinions,0a715a0a-b919-4755-bb4f-6f414992d110
,Fiscal Appropriations and Escrow,,,b13c5de8-49c0-4fd3-a8ac-78737f1910c8
,,Appropriate and pre-fund equal national contributions into jointly signatory escrow,,b737116f-e583-42c4-8c81-8c73d23f21e8
,,,Secure legislative appropriations for national contributions,8881a7d4-569f-4e4b-a701-8d39d3dd3b1d
,,,Open jointly signatory escrow account,f641a1dc-d49c-4e7b-a197-6d8e5f4909b7
,,,Transfer equal contributions into escrow,a32d0ba9-1ad0-427a-ab7d-1a974fc7e2b0
,,,Certify pre-funding and contribution-delay trigger,631bbfbf-c9ec-4fee-ad79-078354a17234
,,Define seven budget envelopes and envelope-coded drawdown controls,,3872a874-2563-4f83-9aa5-bff303d88807
,,,Define seven budget envelopes and purposes,98e57f7e-c1c0-4a5c-b520-a72f20ee9ff9
,,,Set envelope-coded drawdown authorization rules,94cf9ee3-a682-4f13-b6e7-926c33d5b827
,,,Implement drawdown controls in escrow systems,48c23b86-b145-4862-8791-97e0ea4385a3
,,,Validate drawdown controls through fiscal simulation,ee94c168-5683-4652-824e-a9d2bc66eeed
,,,Obtain joint approval and certify envelope definitions,29692e1b-1ae2-4d4b-89a6-f9c364bd618d
,,Implement quarterly reconciliation and independent audit,,e95931eb-3a4b-4a1f-9369-aa3ea0f29637
,,,Define common reconciliation template and reporting currency,45ced26b-7f28-4467-9847-43ed95e79435
,,,Select jointly approved independent auditors,3144561d-1bed-49b2-bff1-420acca2d4dd
,,,Pilot reconciliation of first escrow drawdown,e04d8364-8400-4b60-a461-53b14eab21a2
,,,Perform quarterly reconciliation and independent audit,03e1d00d-7e15-4ecd-9d2c-a3487e878856
,,Validate milestone-tranche fallback and contribution-delay suspension trigger,,89dd127c-915b-49cd-986a-c2f4c1c74c00
,,,Define milestone-tranche fallback trigger criteria,c0b24a8f-fde2-4315-a736-a48afeec8b71
,,,Simulate contribution-delay and suspension scenarios,e64920ef-02f9-4d29-88e9-ee9238ca7561
,,,Conduct joint tabletop exercises,2262f4a1-d226-46a0-9d47-832e09aeb431
,,,Resolve ambiguities with joint legal task force,3195b097-d428-43f4-a3bf-1a4bc54758db
,,,Certify fallback readiness for clock start,00902d43-c934-4d84-a937-5daa03c50432
,,Conduct currency and inflation stress tests,,d60796be-e704-4d63-9775-e0e6c9df9648
,,,Define stress-test scenario matrix and data sources,013e9d60-0202-4f1f-8d2a-ba2e3a6726f2
,,,Collect and validate macroeconomic and fiscal data,a28183bb-2f35-40cf-a6f7-8f366f2ef8c1
,,,Build FX and inflation simulation model,d1745f90-7e83-4cbb-9df6-666174bd4eda
,,,Run stress tests and evaluate contingency adequacy,0f15089b-47d5-4ccd-9ae8-f7f834aed143
,,,Review results and approve stress-test findings,d8abe695-04e6-44b6-b612-4190e8b0a100
,,Negotiate escrow-return and withdrawal clauses,,52424415-baab-49ce-8ecd-5a2bc42b77e2
,,,Define termination triggers and withdrawal scenarios,fed52c40-259a-4c08-bf1c-05a3cb6814e6
,,,Draft model escrow-return and withdrawal clauses,4a04b3d0-7ea3-4fd1-8935-e76caaf0b810
,,,Engage finance ministries and central banks,dd95de1e-825f-428d-8ae2-5d1512670a49
,,,Negotiate dispute-resolution and interest-accrual terms,6fe2ce1f-736d-4a85-998b-a081045fa3d4
,,,Obtain double-key legal and governance approval,8e97b350-3065-4d43-a627-1ec4eec36868
,Site Selection and Matched-Site Parity,,,8b683274-f144-4574-b67e-377df19474ff
,,Identify candidate sites and fallback sites in both countries,,af511e13-63b9-4958-99b0-ea2800645742
,,,Define site-selection criteria and data template,eede878f-2386-4688-92cc-6c03bf8f1c25
,,,Survey candidate datacenters in both countries,04430c07-617c-400a-8567-d33417490700
,,,Assess regulatory grid and site constraints,8a266ef8-385d-43da-8e66-807e0c6c7e68
,,,Engage datacenter operators under confidentiality,95a1dffa-0a8e-4536-8742-28f5c6040f27
,,,Compile candidate and fallback site shortlist,dbca861a-3983-459f-b1d4-c5068b1f1524
,,Develop multi-attribute parity matrix for matched-site calibration,,d3522046-7c6e-4146-ae5a-99e74952339a
,,,Define parity attributes and metrics,f8e325a4-e125-4956-b637-9f55aaa8ea0f
,,,Collect site attribute data,c450acc6-04fc-4c9c-bcc9-ee77a23c0408
,,,Develop weighting and scoring model,5b7d073b-e572-4106-a497-1d6b959632d5
,,,Validate parity matrix with sensitivity analysis,9d7da617-eaad-4ae7-af59-049e51f9fb8e
,,Negotiate matched site pairs and site participation agreements,,8ab6312a-e069-4b98-967c-8e84e2698ed3
,,,Draft negotiation framework and model agreements,bbc1286b-b933-44ff-91b6-07c02637659c
,,,Engage operators and government stakeholders,cfc1e65a-d7fb-4260-a56c-f93ae57b859c
,,,Negotiate matched pairs and access terms,5b73e34d-17ce-4c3f-9ea9-7cd9f174d84f
,,,Execute final participation agreements,513955eb-6202-46e6-883b-7be987c59f14
,,"Obtain site permits, grid, and environmental authorizations",,2cf52449-b972-4800-9178-217a01652052
,,,Compile site permit and authorization requirements,f00675e0-18e0-45ce-abec-f1b81421dbcb
,,,Prepare and submit permit application packages,67104b84-11e1-44fc-86f4-804c18c65412
,,,Coordinate grid connection studies and infrastructure approvals,e1dfdca6-5d0f-4053-96e3-b41eda92660f
,,,Track permit progress and resolve authority objections,8db04577-1c5e-45b9-8b4a-6c8d0b51af16
,,,Obtain final permits and confirm authorization,8bdb7610-36d0-4b46-8f0f-cd8ec544d984
,,Pre-qualify stress sites and fallback sites,,f8495c2a-7295-470a-994d-3d110c4d421d
,,,Define pre-qualification criteria and scoring model,bf7eb732-f97e-4d09-b8d8-e0c9d1bcfdff
,,,Identify candidate stress and fallback sites,f69ee46b-4d49-4955-9ac7-7bb5b38bdc46
,,,Conduct joint site surveys and technical assessments,53a783e6-b297-4c4b-baa6-1c5f75389c9f
,,,"Evaluate parity, access feasibility, and stress-site suitability",00059927-0f81-4279-bbee-03e032d89bc7
,,,Approve pre-qualified stress and fallback site list,d8aa8aed-f076-4839-8839-79d4b9400e02
,,Benchmark reciprocal access hours in live drills,,97faf27e-6bde-4ec0-bda8-38e839650590
,,,Define access-hour benchmarking protocol,7cb42f2c-fe9f-4c39-a6a2-5b1d3645d033
,,,Select and prepare live drill sites,0894c6b0-cb28-4aec-bd49-c61b8e829b19
,,,Execute reciprocal access drills with dual-national teams,c439cdf9-161e-4ea8-9d73-5521b1c35060
,,,Analyze access-hour parity and root causes,3ea3306d-b524-49a9-af6c-8a2758eb668f
,,,Report parity results and corrective actions,233ce32c-1937-416c-abcd-85cdf0ed7ae5
,,Confirm declared site set and parity tolerances,,21578ed3-c08b-446a-9092-f365cfd05b84
,,,Approve parity matrix and tolerance criteria,64ae25fa-7656-451e-bf0b-370eabd53878
,,,Confirm site and fallback viability,bbe97f84-2570-4296-9150-5a905776c218
,,,Secure signed participation agreements,f6dafb08-e024-429b-b8ee-fc95873efec9
,,,Resolve outstanding site disputes,7492cfc7-fd51-41e9-a4fc-4654392c4b98
,,,Confirm declared site set by double-key decision,57296260-3281-4754-981c-7acb3bd3fdf0
,Inspectorate Staffing and Training,,,57231c7a-e90e-4f97-8031-63b58fa5cb9a
,,Develop staffing model and workload formula from site count and shift coverage,,2b78d9dc-03a9-4a3a-98a2-45fe82ee44d4
,,,Define staffing assumptions and workload drivers,6966530d-1c69-479d-8599-a0a375052ff5
,,,Calculate required staffing via workload formulas,cb7c34cc-093a-4397-9025-e836c5db5324
,,,Validate staffing model with national teams,9f8c6c64-468e-42ab-ad84-05f3c0a0b801
,,,Ratify staffing model and workload formula,8e60d884-adab-4f0d-a3fb-c311641350b5
,,Recruit and clear mirrored national inspectorate and technical specialists,,f8a0b9df-0d05-4269-b5ba-324cfcf6ad2e
,,,Define staffing requirements and role profiles,5b71fb84-3955-410a-b170-f94c9c42b8b6
,,,Initiate security clearance processing,2a985fd8-b84e-4c15-9fad-5b95cc9708f6
,,,Conduct targeted recruitment and secondment,9784567b-9a6a-44f2-b2d6-8276798459b1
,,,Evaluate candidates and build mirrored rosters,226bc3b4-990c-4ab4-87ad-f3398c2453e1
,,,Complete onboarding and readiness certification,035679b4-bd27-426e-8fcf-2232cd9d61f0
,,Deliver common training curriculum and bilingual readiness certification,,a5ba767c-58fb-4ddd-bc81-9ab78ee49222
,,,Develop common bilingual training curriculum,51750a57-2a0b-4c73-aeaf-681e283fab2a
,,,Create bilingual course materials and exams,56719152-b9b5-45f8-a5bb-61036d510b9b
,,,Conduct joint inspector training sessions,b14723d8-7c82-44f7-b249-43c9ce8db48f
,,,Evaluate candidate proficiency and readiness,5317aac4-8a3f-42a5-bc6d-1ec185ccf40f
,,,Certify readiness and maintain training records,bdd8be06-f361-4aba-ac6e-9f90d0456b0d
,,Establish permanent surge cadre and deployment procedures,,6d910233-edb8-4b54-8b14-99f09735e4cb
,,,Define surge cadre roles and activation criteria,f2c7ba36-0f82-4fe2-a7bc-dff4017e67cc
,,,Recruit and clear surge cadre personnel,cf86370d-ff41-4388-ab81-067532e9600e
,,,Train surge cadre in common procedures,e34dba17-9524-4910-b7e6-3e0d1e93c715
,,,Develop deployment playbooks and logistics package,9189733a-73c1-4ceb-91f2-e77d98244e39
,,,Validate surge deployment via tabletop exercise,3c5ec5e6-1d89-4a1f-a030-46e34e14c0cc
,,Validate separation of duties and no single-person critical functions,,b619bf3d-bd07-48f0-a120-a4083e69218f
,,,Identify critical functions and roles,d5d63a98-4fb0-48ab-a04b-8a285866aba8
,,,Define separation-of-duties and backup coverage rules,55c3ca54-666e-4e3d-a7cd-3ba1fce314eb
,,,Assess staffing coverage and single-person exposure,967b9c87-1b64-45be-b08c-8c8a32c87a54
,,,Conduct tabletop and operational validation drills,88976100-623b-4443-aa12-5081a45cdd41
,,,Certify separation-of-duties and backup coverage,e5df5a4f-33a5-4725-b362-34bf992a1ee2
,Vendor and Operator Compliance,,,3b80a5ab-03dc-4c3c-a014-ac8a59ae6b32
,,Negotiate model vendor-access agreements with dominant vendors,,7ab46d06-db02-4a56-8c6b-33026e6a5565
,,,Map vendor landscape and prioritization,92c4ff2e-2981-46c7-ba2d-4e3052ae8a15
,,,Draft model vendor-access agreement templates,0593245d-b098-48b3-a316-fc892f031401
,,,Negotiate agreements with dominant vendors,784c20ec-9b1d-4bc7-b0ec-f0a419b7b7a4
,,,Validate vendor coverage and cascade readiness,2f95cf76-605a-4b5d-8a36-d75c1e74a567
,,Bind operators through contractual site-eligibility conditions,,5254f33b-50dc-4e01-980d-fb3b77bf55c4
,,,Draft model site-eligibility terms,a9608255-946d-4036-9a38-6801c665b500
,,,Engage operators on participation requirements,06159e3a-215e-4e2b-8faa-e687a58b0291
,,,Negotiate operator site participation agreements,14b1a1c6-752c-4b0f-9d31-9324e0ec36f4
,,,Verify contractual bindings and escalation paths,1c7f4e8d-32dd-4c89-b420-71c4aaa927dd
,,Accredit independent clean-room examiners,,71ca876e-0758-4eaa-adfb-2eef6813c0d8
,,,Define accreditation standards and criteria,9403775c-5e3f-42ad-a0f9-83f9945db640
,,,Recruit and pre-vet examiner candidates,45fdeb7e-acc6-4080-a750-378efb2d369a
,,,Clear candidates and review conflicts of interest,ad8f37c5-e4b3-4774-93e6-3a513f3b69b8
,,,Deliver training and supervised examination exercises,0970a264-fcdd-4f06-ace2-0945f7181986
,,,Issue provisional and full accreditation decisions,95a6f6c2-85f1-436a-9149-bd05400cc216
,,Build forced-evidence ladder and clean-room examination workflows,,654dd985-e249-45fa-b8b8-d70dda1baa54
,,,Define clean-room trigger and escalation criteria,d037781f-fd6e-4ddb-b654-4b9116384786
,,,Draft forced-evidence ladder workflows,28cd8bd5-b089-4b49-bb20-e580f689b0fb
,,,Order and install clean-room examination equipment,ba727c60-f813-4f8b-a6ff-d831e22b1b6a
,,,Train inspectors and examiners in workflows,acdee73b-0c0a-40c8-b12e-c1144667fa40
,,,Validate ladder with blind challenge drills,80fd59a4-ad38-4b84-976a-7a00ef68207b
,,Cross-train inspectors in vendor-supervised diagnostics,,c2c09cc7-321b-4c92-9078-20de21a8da20
,,,Develop vendor diagnostic training curriculum,290c2df5-0163-4532-8589-8f76e6cce7df
,,,Coordinate vendor training schedules and access,5cf902a4-1bed-4b57-b705-4d94ea8672b7
,,,Train inspectors on diagnostic equipment use,d534917f-5ea0-43ee-ab9d-994ab93f7992
,,,Conduct supervised dry-run diagnostics,179c3c3b-6db8-49fc-b278-b73c1facec92
,,,Certify inspector proficiency in vendor diagnostics,9804fcff-a4a9-422e-ba95-d4bc909f6a71
,,Conduct vendor-refusal challenge exercises,,2def0127-290c-4729-927d-46da95343739
,,,Design vendor-refusal challenge scenarios,62a8be34-2556-4b7e-9ee5-9ee550dfea81
,,,Secure vendor participation and approvals,c033ce65-3caf-43f6-9cc4-a5864eea1957
,,,Prepare sites and red-team evaluators,04d7d06a-265e-4081-b5fd-61b92649e2fa
,,,Execute vendor-refusal drills,c4c9740b-f11f-4fb4-be7c-de760c822760
,,,Evaluate results and document lessons,73e74a83-65e8-407b-b7b8-7cc133bed4e5
,,Define unverifiable-equipment thresholds and escalation procedures,,b091b983-c7dc-4286-828b-278704675190
,,,Define unverifiable equipment classifications,f8ee6034-8861-4f9d-9211-5ff0832a271d
,,,Draft threshold options from KPI plan,77858c7f-4007-4c55-a959-d8c83c914fff
,,,Analyze scenarios and simulate threshold impacts,b8799daf-b8d8-4582-9015-b9f60faeb4c1
,,,Define escalation procedures and decision points,ec37eeb5-4b37-4da3-8f1a-6cd2303767e8
,,,Obtain double-key approval of thresholds,da817cb8-6883-45a5-b364-7e2c0214545c
,Verification Systems and Infrastructure,,,3f80a733-22fa-4679-8eaf-d7ea0b5374b4
,,Deploy replicated tamper-evident ledger infrastructure,,3fdb5d77-dc2e-4839-a2e4-684b4018b293
,,,Design ledger architecture and key management protocols,51b7511c-45e4-4be0-a99f-f87019e30343
,,,Deploy national nodes and local-first recording,a98dde70-3b94-4f05-ad43-75ad8de5adf5
,,,Integrate evidence streams and asset registry,e16020a0-0765-45ad-8053-93cebf9df811
,,,"Validate latency, divergence, and tamper evidence",7c01568e-cf00-408d-aa02-8ea0244207a5
,,Implement cryptographic asset registry and identity-gate tools,,7dac98f7-9754-4d2e-9a03-bfe64db499ae
,,,Define registry schema and identity standards,4d30b886-68f0-4e5d-8cd2-d543748b0d3a
,,,Normalize operator records and run pilots,6dd79e0f-9f64-4edc-8451-4979fa47fdc5
,,,Build cryptographic asset registry service,77f66195-3d7d-476b-ba64-ea9f014e1cbd
,,,Integrate identity-gate tools and workflows,931d2bb9-f5b8-4a34-99f6-552848e5d0a9
,,,Validate with joint exercises and examiners,6ec652b5-1bd9-4f85-bd62-11c105f5340c
,,Construct jointly controlled staging areas and bounded inspection zones,,33fab3ae-f8e7-4589-9d41-5e70c22d3182
,,,Prepare standardized designs and permits,5be88483-45dd-43ec-b923-25f3ec6ee513
,,,Procure long-lead materials and fixtures,0a737237-dd87-4ad3-abd4-542441ce5997
,,,Build staging and inspection zones,93d7774a-81f6-4a49-8c56-f4491366f2a6
,,,Commission and validate joint-controlled facilities,c767e865-2d0a-417d-bcc5-3e79c6caba63
,,Deploy filtered workstations and clean-room examination facilities,,44f072cf-dd82-4d2c-8fc6-ff125f5d3ad7
,,,Freeze and version information-barrier filter rules,4f41a43d-9334-47d9-a4e9-007c5570d1c0
,,,Procure pre-certified filtered workstations and clean-room equipment,dd03f982-3c47-4a8d-ad71-0a9a814e7ad2
,,,Deploy filtered workstations across declared sites,1e38bf6f-a2cf-451c-9307-43fe00d9fa5b
,,,Install and validate clean-room examination facilities,d7ed1017-97b9-465c-a923-151fddff9fbb
,,,Conduct acceptance testing and cross-contamination validation,0594b1d9-7d34-468d-b09f-3f30ef20b4a1
,,Upgrade secure facilities with N+1 power and cyber isolation,,23c8140f-2817-4cb8-ae98-6f5352f4abd0
,,,Assess existing power and cyber infrastructure,4924c548-df1a-4dc9-937b-e052ac54a470
,,,Design N+1 power and cyber isolation upgrades,0800aa12-314f-42c3-80b0-d1aac4a00dd3
,,,Procure power and cyber upgrade equipment,de9c9d3b-42f4-4cb5-879d-343245c8a7ac
,,,Install and test N+1 power systems,b4c11ab1-8b7e-45b9-9329-50bf712f3499
,,,Deploy cyber isolation and validate security,4c88582b-8b89-45a9-b4d1-d2666dc1819b
,,Establish information barrier and counterintelligence monitoring,,5b27f479-3a2b-435d-9478-aaf30db6b88c
,,,Define and version information-barrier filter rules,9b02c5a4-6787-488d-bb6d-e6fcd19b5f3f
,,,Physically and logically separate national monitoring domains,5ecd147a-610b-4f59-94aa-009edb3c4880
,,,"Recruit, clear, and train counterintelligence staff",e14ec899-0c52-458a-b2cf-2a5979ce92d0
,,,Validate information barrier with blind challenges,a24725a6-5a25-45ca-bcac-2f3a2740e827
,,,Drill joint cyber-incident isolation protocol,f16453f8-b9cf-4159-b4a7-5af7fd1b01d4
,,Define layered evidence weighting and operator-record validation rules,,7f3595b1-24de-4b36-8fae-dc5f9bb62b00
,,,Establish joint technical working group,042458b5-7b00-41d7-b33f-16fbdc216d15
,,,Define layered evidence weighting criteria,bf003004-563e-47e4-acc9-0e4003fe1c16
,,,Define operator-record validation rules,9b6e9eb9-dcc5-49a2-821b-cfb5c30750f2
,,,Prototype rules using de-identified records,20dcf7c2-24dc-4995-bc6f-eb0eff10588d
,,,Approve versioned rules via double-key sign-off,b88bdc08-f850-446e-8753-538f2a3e6695
,,Implement exit-disposition workflows and unresolved-equipment handling,,138928f8-8928-49c5-b11b-2b3bec1e960b
,,,Define exit-event taxonomy and unresolved criteria,f30f9e23-4d2d-41da-9ab3-0dd9b033ac49
,,,Create workflow templates with explicit statuses,427cea87-f4f8-41f5-8756-89a8c53599f5
,,,Integrate workflows with registry and KPI dashboard,8fe80438-ff35-468d-9ee2-5783f9a958ab
,,,Pilot exit workflows in tabletop exercises,45ffb5d8-d2c1-4670-872e-42246829e7a3
,,,Establish escalation path for unresolved equipment,381debbe-4da3-42fa-8ba4-acddad7960ac
,,Build KPI dashboard and reporting infrastructure,,31b4781e-20c2-4462-b501-91dc6aeee694
,,,Define KPI metrics and data contracts,2a6ed3ba-d8ad-4b30-a43f-3100de87f0b6
,,,Develop filtered reporting views and mock feeds,e27865ce-3ce2-42c3-adb8-74749193ae20
,,,Build dashboard increments and integrate live feeds,4ef14d70-9cc6-4942-803a-b4258d1941e0
,,,Validate dashboard with joint teams and red teams,6d4b7b50-244a-4f43-b6b3-afd946fc0fae
,Baseline Inventory and Cryptographic Asset Registry,,,c9c5f435-0457-4181-ae8c-02621055afc8
,,Plan joint baseline physical inventory and reconciliation procedures,,cfbc7973-792b-4e20-867c-e05cda0ab541
,,,Define inventory scope and data standards,62f3bb51-c33a-4632-a526-0fc61699aae8
,,,Collect operator records and site maps,5088982d-2e1e-45e7-8bd1-970aec850052
,,,Draft reconciliation and discrepancy procedures,7e482810-b4e7-4e83-bf12-17de5ed0c3f1
,,,Validate plan via tabletop exercises,d4760a9f-dda2-4a97-b815-1a38b51961d8
,,,Approve final inventory and reconciliation plan,bdac4f1f-a0a1-4004-a362-b3062918e8ab
,,Conduct physical inventory of covered equipment at all six sites,,8d5b7bbd-210b-416a-9001-36832f848c1f
,,,Prepare site inventory logistics and access packages,19a9c829-46d6-4997-8696-69cf5818898d
,,,Execute mirrored physical inventory at declared sites,0db0c511-669f-4a13-91d1-4017ef520094
,,,Register serialized equipment in cryptographic asset registry,2affe8f8-f286-40d2-bf65-5dbee9d732d9
,,,Reconcile records and investigate inventory discrepancies,d5c33848-1aed-4cc4-bd19-2466ecf26083
,,,Certify inventory completeness for each site,8bef23cb-047d-4c78-a63d-80ac8f9f4828
,,Serialize covered equipment and register in cryptographic asset registry,,3140d231-859f-4c63-afb8-659bb648a7c8
,,,Finalize serialization schema and registry templates,c6c78666-8400-4a52-8b01-261c6f665996
,,,Tag and scan covered equipment units,9bb5a87b-f8ad-4a59-9efa-85af34f20ee8
,,,Capture evidence and dual-national countersignatures,0101fc09-b590-4afa-9cb0-ec624426494d
,,,Load entries into cryptographic asset registry,c2315b2c-07ef-44d1-9113-8258de0218ab
,,,Reconcile exceptions and certify registration batch,3766d2ef-4603-4dfd-a80e-e0ce0d3ac270
,,Reconcile operator records and resolve serialized discrepancies,,7d9ca2f8-9b36-4684-bcb5-0895b086508b
,,,Collect and standardize operator asset records,b8d3835e-9882-4774-9909-a017e0a25a95
,,,Match records against cryptographic asset registry,3681a9f4-cace-422e-bd46-35a22bd65139
,,,Adjudicate serialized discrepancies with joint technical team,051bba53-6d2a-42c8-bd17-acec57b281ba
,,,Certify reconciled records and update registry,f04e6098-df6a-4113-a93b-453aa43617e2
,,Certify baseline inventory and asset registry as mandatory entry condition,,7c323495-33aa-4b9f-8363-0422068705cb
,,,Prepare joint certification evidence package,8abe15d8-f064-4f34-9194-c32deaa71972
,,,Conduct pre-certification readiness review,5699772c-f4f3-44a5-9ca2-0204beed114b
,,,Resolve outstanding discrepancies and deadlocks,17647c7f-09d1-4c0c-9e25-cfb4381f8527
,,,Obtain double-key co-chair certification,a5bf3c13-468c-412c-b9cc-903406c0cf5a
,,,Record certification and launch handover,59153a5c-7915-411c-ba94-3bd564c69a53
,Validation and Readiness Testing,,,664e6b3a-e2b6-4095-8684-3c57702b5989
,,Set material-event latency budget and silent-window bounds,,6c97f8cf-b501-4979-ac93-ad117afd7d87
,,,Define material equipment-change event taxonomy,e98d5c38-64d1-468d-9418-e40c62cafa42
,,,Convene joint technical workshops to align definitions,0827114e-67ff-457d-9913-15e1f418f922
,,,Collect pilot latency and synchronization baseline data,9740c4d9-a016-4e72-b602-33a7052a77a4
,,,Analyze pilot data and propose threshold options,bb07d15c-2c1b-41c3-a96d-43efa8b8c6d8
,,,Pre-register latency budget and silent-window bounds,cf882ca5-6241-4124-a5f7-ad26bc66483a
,,Validate local recording and synchronization latency,,74546f24-30aa-4d63-bc4d-e8349e5fab38
,,,Define latency measurement protocol and thresholds,fca3ae73-88ab-48fb-a296-46a542a3fa29
,,,Deploy synchronized time sources and monitoring,31f850ae-8b19-427a-aefd-0439a17aff31
,,,Execute repeated latency test events,37c720bb-0af1-4a74-bf7d-08c8be865f5d
,,,Analyze latency results and certify threshold compliance,bc173ba1-3753-49df-bfa0-3619fa331fc5
,,Conduct divergence detection and reconciliation drills,,c5264e42-c758-457e-822c-d2cc42da27bc
,,,Define divergence scenarios and success criteria,3901c5ae-597f-4e7b-ad94-4b5860ce76a5
,,,Inject synthetic divergences into ledger nodes,f7550bc1-7be9-42d0-aced-193fd47e773f
,,,Run reconciliation drills and measure latency,b9bcbd6a-b102-4747-bff0-19555feb25d6
,,,Analyze results and update reconciliation procedures,39fa3545-50d3-4758-97ec-f5ba89132510
,,Test information-barrier filtering in blind challenges,,638d30bc-d5e7-414e-89f9-004e9f098918
,,,Define filter rules and success criteria,5eb1707a-8e4c-4113-be09-131dddcbda57
,,,Prepare synthetic workloads and substitution indicators,cd5e3e6f-7700-4fbe-ab86-b255571634a4
,,,Execute blind challenge exercises,98a64c60-8c07-473a-afd9-c6748614a11b
,,,Evaluate detection sensitivity and leakage,450cba6a-5156-4593-865e-02cd5583feac
,,,Calibrate and version final filter rules,09d48480-c35c-40ec-a514-6b192dda680f
,,Execute independent penetration testing of evidence systems,,9b63c26d-36ed-4b7b-bb09-0b317c4e51e1
,,,Define penetration test scope and rules,4f1d5aa7-e02c-4802-9474-a71413eee183
,,,Select and contract independent testing firms,dd6ef98d-8e1d-4ccf-a44f-f07851489aa7
,,,Execute penetration testing cycles,6188cf26-fbb2-4cfa-bec3-ab1d56156761
,,,Remediate findings and conduct retesting,cc69c5f0-0664-4b74-b739-d0bce24ffef6
,,,Report findings and readiness recommendation,4ecc97c5-8bcd-43ac-9dad-5c3acdcb096d
,,Pre-register KPI thresholds and statistical analysis plan,,cbce2046-814d-48eb-a5e4-e084255d8994
,,,Define KPI threshold formulas and confidence intervals,6c37fc35-2aa4-4929-8c90-7e8b6cf594ae
,,,Draft pre-registered statistical analysis plan,ad090638-2b1d-4b06-bb4a-8c8da225cdef
,,,Validate thresholds and analysis plan with experts,63f2922a-0860-47a5-b3a8-673092a45b5c
,,,Finalize KPI rules and obtain double-key approval,be7a8aae-54ba-4a06-ac64-dd8afcdb4828
,,Stand up independent red teams and challenge event schedule,,5e92dd84-b508-4a1f-aa16-939ee1d6a424
,,,Define red team scope and pre-accreditation criteria,03cb3170-801a-4616-b917-aeb9607a6913
,,,Recruit and clear red team personnel,546910fd-c399-457b-8a29-d3a158801c9c
,,,Design challenge scenarios and event schedule,59181738-ae41-4841-91b6-6ad41f468522
,,,Procure and stage challenge exercise equipment,61f2c049-9803-49e3-8665-8bd656ab4baa
,,,Conduct red team readiness and dry run,5df2c558-410f-405d-b6eb-e084df2cd978
,,Complete pilot blind challenges at two sites,,06fb5df8-ed7b-481a-8ed5-749f67980104
,,,Secure pilot exercise windows and confidentiality agreements,e89a761e-4952-43ed-b75c-eea27176e47b
,,,Develop blind challenge scenarios and injects,b704dddd-66a4-459a-838f-b946d7deca1d
,,,Pre-stage sealed challenge kits in joint custody,a1d1d3bd-303f-4908-a5ac-0f7bb65d907e
,,,Execute pilot blind challenges at two sites,1c45ec44-f699-432e-b31c-916bae302e22
,,,Analyze results and retest if needed,edcc6fb4-6fc5-4d68-a80b-a78c6e3bc556
,,Complete end-to-end inspector travel and clearance drill,,25b34f96-7c0a-489e-a54c-4daf2b6d4611
,,,File standing visa and customs pre-authorizations,f159e296-2e56-47b8-93df-56017ba77f9f
,,,Prepare sealed diagnostic equipment kits,ec6a8766-c05b-4466-bfdc-ce0bf654d262
,,,Run desktop rehearsal of clearance procedures,4967009f-31e4-4402-b403-726c1e12fe33
,,,Execute end-to-end inspector travel drill,d8a6075e-5dd1-4639-adc9-0eb7b2c7c72d
,,,Document results and resolve clearance bottlenecks,114aeaf7-1a7e-4942-a1d5-c8d829eda931
,Entry-Condition Certification and Phase One Launch,,,1c98126c-e750-4d73-ad6e-f24290672047
,,Maintain integrated readiness tracker and close open entry conditions,,5f0b13fa-5c5e-4c40-be38-23dee09739f8
,,,Define tracker structure and data standards,281f6dcc-b8db-4f6a-b165-43caabde8374
,,,Assign owners and due dates for entry conditions,692d2a9e-c585-443b-b42a-12f80920ea6d
,,,Maintain real-time status and evidence updates,ef80aeaf-2d8c-4027-89fe-10fd32b49409
,,,Conduct weekly joint reviews and identify at-risk conditions,b020072b-f907-414a-82a3-fb580940c133
,,,Escalate and close open entry conditions with documented evidence,f4052a11-25e6-40c9-87d6-6eefee3e33ca
,,Certify all entry conditions through double-key co-chair decision,,ed9d35a4-dc38-429c-ad9e-aa88426a2f90
,,,Compile certification evidence and legal opinions,9596d5ba-f89e-43a4-a3d0-82ec30762ed9
,,,Reconcile co-chair objections and interpretive disputes,2456954e-29ce-45fc-97c3-1c0117a5fd71
,,,Conduct final joint certification review,910639b3-a90b-4db3-bc4f-8b29b41cd898
,,,Record and notify double-key certification decision,2332a3e9-72eb-4317-9c62-7c336e46a113
,,Start 90-day Phase One clock,,bc6a7697-cc79-4c05-b44e-f8b6734c4c39
,,,Confirm entry-condition certification complete,f86bf279-6f5e-4186-9cc3-9384fb94126b
,,,Synchronize clocks and ledger instances,a4901d4d-f8fe-4504-8faf-c07ea7aabbf5
,,,Issue joint start declaration with timestamp,83dfe58a-65e8-402b-bf14-2077c23410fb
,,,Notify all operational units simultaneously,bbd6e4de-1b9d-4b39-8191-c0c5dd0f07db
,,"Establish operational command, cadence, and reporting structures",,ff726b43-63ed-495b-81b3-0b84687c1d89
,,,Define operational command structure and roles,6354d9e7-8253-47c4-8e18-6553e2ff0849
,,,Establish reporting cadence and templates,c1717706-7a21-4e3d-9d0c-f652b2954e21
,,,Activate communication channels and translation support,08bbf34c-ffa0-441e-a01b-1dc942dfe826
,,,Conduct communications dress rehearsal before launch,a97320ae-c434-4460-8485-bf9711a384a8
,,,Integrate reporting structures with readiness tracker,e382d188-af07-4eec-95a5-d1aff8729c38
,,Conduct launch readiness review and contingency briefing,,cbbd2f86-0fe0-40c0-871f-05e511bda851
,,,Prepare launch readiness review package,eabd8a08-8de2-4f0a-b1f5-159e696e9cda
,,,Assess readiness against certification criteria,0b535114-fccd-4a7e-8909-6e5ae61d1af0
,,,Draft contingency briefing for launch scenarios,4ac15809-df4d-48a1-820f-1cb43ea022ec
,,,Conduct joint launch readiness review,198d1ff6-1142-4402-a304-789ad2bd691e
,Phase One Operational Test and Live Challenges,,,98b4fb22-74f0-4983-9f67-2f364147cadf
,,Verify material equipment changes at six matched sites,,22dcc8fd-4cc0-4bd9-ae28-15b4338ce2b0
,,,Verify arrivals installations and maintenance changes,32813db8-29a3-47fa-8d86-e965d2388a30
,,,Verify removals transfers and decommissioning,8d21310c-0fbf-4342-9b7a-b4a75e7223e5
,,,Apply forced-evidence ladder for vendor refusal,5a2d6e16-36e0-4e3c-9794-9e3f17acd492
,,,Record evidence in replicated tamper-evident ledger,ba5f84d8-3765-478d-be40-9021a22b0fe3
,,,Escalate unresolved discrepancies within latency budget,357f309f-cf68-4fa4-8f8e-876246b5a19f
,,Execute unannounced blind challenge exercises and red team events,,9c78f9cc-8704-49e3-85a8-46460b5a4c0a
,,,Design challenge scenarios and red team playbooks,be40fbef-758a-44e7-b6eb-22df565bdebf
,,,Pre-position sealed challenge kits and equipment,04865327-80ba-451b-8d1f-1994e856e942
,,,Coordinate site access and preserve surprise,c27fe6bf-117d-4a96-b3ba-d0db93e9e5e0
,,,Execute blind challenge injects at all sites,8f0a4fa7-c572-4c64-a155-dd67a5667440
,,,Assess detection outcomes and report results,d109b403-0712-4ac4-bd7a-a896abc49ec7
,,Monitor event-recording latency and ledger synchronization thresholds,,bfadd5ff-87ac-43de-a251-6d6dc2ee1762
,,,Establish 24/7 monitoring cell and escalation paths,95f7e1a3-46fb-4e90-95f1-f2c38ccab073
,,,Deploy redundant secure communications and time sync,428caaf7-dce3-4400-8fc0-b3192d59575a
,,,Monitor event-recording latency and ledger sync metrics,e2cdee44-de10-4fb2-b3e3-849d323f413e
,,,Execute ledger divergence alert and reconciliation procedures,1e14b5a5-aca4-4b31-a361-d7219aabea73
,,,Manage threshold breaches and alert flooding,901740e9-bae3-4f41-9b0f-9b62aff383a1
,,Monitor reciprocal access parity and unresolved discrepancy age,,ddf30c60-e9b7-462c-be8d-015225bcf7a7
,,,Define parity and discrepancy age metrics,0373cabf-84b6-402f-8a51-498a64c24e25
,,,Automate access-log capture and daily scorecards,858d973d-9f5f-4491-885c-815b8d257286
,,,Track unresolved discrepancy age with escalation,5617a406-97a7-46df-bb3e-b20ee445b25b
,,,Maintain manual reporting fallback for monitoring,73866d87-ef77-445e-b3a8-edfe6a970030
,,"Manage vendor refusals, deadlocks, and automatic suspension events",,ac7f4f1b-b5aa-4902-9105-6f9b4b88f813
,,,Activate vendor-access agreement response,b649fb33-91b1-45a8-be84-8b56821f7726
,,,Escalate deadlocked material findings,a60f3d5b-ffa8-475e-b10b-eaf4057f7e50
,,,Execute automatic suspension checklists,f5d76952-0c9f-4cc8-99a6-0e3479ba7a4c
,,,Coordinate resumption after suspension events,898ccb3d-93b0-4407-a660-cd401269857e
,,,Deploy surge legal and vendor coverage,86a77f1e-d2f9-40ed-90ff-2b389d46033e
,,Reconcile ledger divergences and resolve anomalies within latency budget,,c523a898-fdf6-4d60-842f-1706d0317662
,,,Monitor ledger health and divergence alerts,0a600859-9596-4176-92e3-bee217f7f911
,,,Diagnose root cause of ledger divergence,4c0aa5d6-8d4e-4ae0-9aa6-56e5fe18466a
,,,Execute reconciliation within latency budget,835a7755-29f3-4ae6-9f72-13797a13cbcc
,,,Escalate unresolved anomalies to joint technical leads,aea60299-7e0d-43ce-998a-f1ef04b32562
,Verdict Construction and Next-Phase Planning,,,992e3624-8439-4447-9f24-a1f8835c3098
,,"Aggregate exercise results, access findings, and discrepancy data",,b0357e2c-7792-43b7-ba2d-1d41e80eeacc
,,,"Collect exercise, access, and discrepancy data",23a2e4c4-62b8-4ad0-bfb8-9f9ad391c2bb
,,,Standardize and quality-check submitted logs,de85fc41-0815-418e-8f8d-b1115a921af3
,,,Resolve cross-team and ledger discrepancies,b77d4103-ca68-40ac-8cc2-234404712b0c
,,,Freeze and certify final aggregate dataset,85eb2436-feec-41b9-9859-d8ac897ea59c
,,Apply materiality thresholds and pre-registered KPI rules,,8e3214e6-b3a4-4b36-be5e-36162f006278
,,,Validate frozen dataset completeness,97e9ab8b-e789-4570-87b8-cb63566bace2
,,,Compute KPI metrics from pre-registered rules,d6901ef5-6b6c-45dc-895d-6c9989a71f25
,,,Apply materiality thresholds to outcomes,05051bef-d78d-421b-bfe2-5c495f897f4c
,,,Resolve threshold interpretation disputes,6772d0a5-17d2-4487-843f-d474595ef009
,,Draft shared findings narrative and Go/Modify/Stop recommendation,,6ed077b5-7299-4845-85a5-70137907b6f6
,,,Consolidate verified findings and discrepancy data,3faaa5cc-6b0a-4eac-8b64-af318b75466b
,,,Draft shared narrative for material-change verification,b0dab620-15aa-4528-bb96-1df85d776668
,,,Resolve joint interpretive and factual disputes,4ac8a227-7daf-4414-975b-d725dd8fae40
,,,Obtain co-chair approval of final narrative,b6257d65-9677-43ff-9f5c-a166c5302994
,,Issue joint written verdict,,dacdacca-27b8-4004-8253-1ad47ae755ae
,,,Prepare draft joint verdict and translation,2d74fbe9-aa4a-4d37-9901-cf2f0694a70f
,,,Clear classification and information-barrier release,d3cb94e9-f545-43c4-aeaf-6216e7d8ed47
,,,Obtain double-key co-chair approval,7ffc06bb-c9ab-44ae-a284-bd5c284fbfa7
,,,Issue and transmit joint written verdict,749991f6-8412-471d-a84d-0081bea1ac07
,,Plan Phase Two or corrective actions,,f15a5d31-74a9-4212-b15a-67f885b05466
,,,Define decision criteria and playbooks,7dbe5dec-30c8-488f-9aec-2f2a84f3d7a2
,,,Assess funding and legal requirements,9c4ca64f-9ba8-40a7-b74b-91d115f1a3ab
,,,Develop conditional implementation roadmap,a3a7e0d8-194f-4f27-b90f-f317ed3b0a7a
,,,Stakeholder consultation and approval,20dd41e4-4b2b-4a79-87af-6b0db1c23647
,,,Launch Phase Two execution planning,f0834c21-bdf3-4cd8-b1f8-e86ac5a0e2bb
,,"Transfer records, lessons learned, and continuity commitments",,8c55db3c-f000-4732-92dd-1594f317b444
,,,Compile and transfer versioned project records,8c5fecde-9a85-44b1-a043-51933162bef7
,,,Obtain declassification and release approvals,2d535a16-b5a3-4b63-bdd0-f485f9706c76
,,,Capture and document lessons learned,2cf24a67-c22d-4cec-a859-a241c332b200
,,,Record continuity commitments and brief successors,8e5b051c-67c4-493f-9758-0fec79bb39e9
,,,Complete custody handover and records closeout,48d76361-b4c6-4ed7-af70-8ce414e66510
```

# Review Plan

## Review 1: Critical Issues

1. **Unvalidated KPI thresholds make the Go/Modify/Stop verdict statistically indefensible**, because claiming ≤5% false negatives at 95% confidence requires roughly 60 independent blind challenge events per category under the rule of three while a 90-day, six-site window cannot support that volume (with only 20 events the upper confidence bound is ~14%), which risks a false Go or false Stop that wastes the $5B budget, interacts with the absent managed-access floor and deadlock-prone governance by making results depend on what inspectors were allowed to see and contestable after the fact, so the immediate recommendation is to commission an independent verification statistician to pre-register a Test and Evaluation Master Plan with exact event counts, confidence-interval formulas, and unresolved-event handling, and to mark all unsupported thresholds as TBD until validated by pilot blind challenges at two sites.


2. **Undefined legal form and domestic authority prevent any entry condition from being certified**, because a $2.5B-per-side obligation, foreign inspector powers, and operator/vendor compulsion require an Article II treaty or congressionally authorized agreement plus implementing legislation and a legal personality to hold escrow, employ ~450 people, and sign leases, so the first operator refusal, export-control objection, or data-transfer lawsuit can delay Phase One by 6–24 months and consume the $500M contingency, which interacts with the unvalidated-KPI issue by stalling the 12-month entry-condition clock and with political-continuity risk by leaving an unratified handshake vulnerable to leadership transition, so the actionable recommendation is to convene the joint legal task force immediately, produce a legal-form memorandum by 2026-10-30, draft the bilateral instrument and model implementing legislation by 2026-12-18, and obtain formal legal opinions from both governments on escrow, access authority, and data transfer before further operational planning.


3. **Missing managed-access floor lets information protection veto verification and breaks the latency budget**, because the plan never specifies the minimum access inspectors may demand and what the inspected party may manage, so every evidence stream can be filtered and every area bounded without an adequate alternative demonstration, and if visa/customs processing takes 10 business days instead of the assumed 48 hours, the 24-hour physical-confirmation window becomes arithmetically impossible, turning each denial into a legal dispute rather than a verification result; this interacts with double-key governance because a co-chair can dispute materiality to shield an operator, and with the KPI problem because blind challenges then measure only permitted access rather than true detection capability, so the actionable recommendation is to draft a Protocol on Access and Managed Access annex specifying all locations, equipment, and records subject to inspection, requiring managed-access alternatives that satisfy the inspection objective, mandating 48-hour joint technical-team rulings on denials, treating unresolved denial as a material discrepancy, and negotiating and exercising the standing inspector visa and customs annex before the clock starts.


## Review 2: Implementation Consequences

1. **Successful Phase One creates a strategic verification dividend and reusable infrastructure**: if the 90-day test demonstrates credible detection (≤5% false-negative rate at 95% confidence and zero unresolved ledger divergence), the $5B investment yields a first-ever bilateral hardware-verification architecture, a crisis-stability tool, and a platform for follow-on phases at marginal cost, converting the $500M testing envelope into validated evidence that justifies future appropriations and avoids repeating the $75–150M staffing/clearance investment; this positive outcome interacts with political continuity because visible success makes termination politically costly, so the recommendation is to lock in continuity commitments and a public KPI dashboard immediately after the verdict to capitalize on the credibility gain.


2. **Political discontinuity during the 12-month entry-condition phase can zero the entire $5B program**: a U.S. administration change or Chinese leadership transition can delay Phase One by 12–24 months, consume $400–600M in sunk preparation and certified staffing costs, and add $150–250M in idle inspectorate costs before any verification evidence exists, leaving the program with zero operational ROI if terminated; this consequence interacts with unvalidated KPI thresholds and the missing managed-access floor because a stalled clock prevents the pilot exercises needed to justify thresholds and exposes the legal handshake to reversal, so the actionable recommendation is to negotiate binding continuity clauses (multi-year funding obligations, transition briefings, escrow-return provisions) and run transition-scenario war games before the clock starts.


3. **Information-barrier imbalance or systemic vendor refusal can force a Stop verdict and waste the $500M contingency**: over-filtering can hide substitution evidence while under-filtering can leak sovereign technology (a single evidence-integrity compromise costing $10–100M and triggering automatic suspension), and a dominant vendor refusing cooperation across multiple sites can convert a local finding into systemic unverifiability, with each refusal consuming 2–6 weeks of latency and $5–20M in escalation costs—together making a Go decision impossible and turning the $5B investment into a one-time exercise with no lasting regime; this interacts with deadlock-prone double-key governance and unvalidated thresholds because denials become legal disputes rather than verification results, so the plan must pre-negotiate model vendor-access agreements, accredit clean-room examiners, and validate filter rules in blind challenges before deployment.


## Review 3: Recommended Actions

1. **Mandatory joint baseline inventory and cryptographic asset registry**: Conduct and certify a full physical inventory of all covered equipment at the six declared sites before the clock starts, a high-priority recommendation from the data-collection and expert-review documents; if 2–5% of serialized records are inaccurate (roughly 1,000–2,500 units in a 50,000-unit baseline), reconciliation could take 4–8 weeks and cost $20–60M, and skipping it could push the blind-challenge false-negative above the 5% threshold, invalidating the Go verdict; implement by standing up a joint baseline inventory task force, using the synthetic reconciliation simulations and IAEA safeguards physical-inventory methods described in the plan, and requiring a full recount of any site exceeding 2% unexplained discrepancy.


2. **Three-tier governance with independent technical-fact mechanism**: Restructure decision rights to separate inspectorate-recorded facts from co-chair political decisions, with a joint technical adjudication panel deciding materiality and verification conclusions by technical majority rather than double-key, a high-priority fix from the expert-review; without it, one co-chair can block closure of an unresolved material discrepancy indefinitely, consuming the 90-day clock and turning every observation into a diplomatic veto, making the verdict impossible or meaningless; implement by amending the bilateral instrument's governance annex, appointing a joint chief inspector or independent technical director, defining "site findings" as material adverse findings only, and running tabletop governance war-games before the clock starts.


3. **Dedicated mirrored Discrepancy Adjudication and Verdict Construction unit**: Create a full-time, two-co-lead (one per country) unit to own discrepancy-age KPIs, apply materiality thresholds, prepare joint findings narratives, and support co-chair verdicts, a medium-to-high priority recommendation from the team-document omissions; this directly enables the ≤10-business-day unresolved-material-discrepancy-age KPI and prevents ad hoc handling that can delay the final verdict by weeks or produce a contested Go/Modify/Stop; implement by adding this role to the team structure with dedicated legal, technical, and investigator staff, defining RACI for discrepancy escalation and verdict drafting, and testing the unit in tabletop exercises before Phase One.


## Review 4: Showstopper Risks

1. **Inspectorate staffing and clearance bottleneck is a high-likelihood showstopper that can delay Phase One by 6–12 months and consume $225–400M in idle and premium costs**: because security clearances for ~450 bilingual technical FTE typically take 18+ months against a 12-month entry-condition window, under-staffing would violate the no-single-person-critical-function rule and invalidate evidence collection, so the recommendation is to start clearances immediately, second personnel from existing national verification bodies, and adopt the workload formula (site count, 24/7 shifts, 1.5x leave backup, 10% surge) with a parallel training pipeline; contingency: if clearances slip, activate a pre-qualified reserve of cleared retirees/contractors and request a jointly agreed 3–6 month bridge extension with contingency-envelope funding rather than starting the clock with an incomplete roster.


2. **Matched-site parity failure is a high-likelihood showstopper that can trip the asymmetric-access Stop condition before exercises begin**: because sites in Northern Virginia, Beijing/Hebei, and Guizhou differ in layout, vendor ecology, grid reliability, and security constraints, a paper-based 0.9–1.1 access-hours tolerance may be unachievable, stalling certification for 6–12 months and risking the entire $5B investment; the recommendation is to approve a multi-attribute parity matrix (equipment value, operational role, physical layout, security, grid, vendor coverage), include deliberately harder-to-inspect stress sites, and benchmark reciprocal access in live drills before the clock starts; contingency: if parity cannot be demonstrated, pre-agree to renegotiate the matched set (e.g., 4 paired sites plus 2 stress sites) or formally adjust the tolerance band with a documented justification annex before any Go decision.


3. **Cyber or insider compromise of evidence integrity is a medium-likelihood showstopper that can trigger automatic suspension, cost $10–100M, and collapse political support**: because the replicated ledger and filtered evidence are high-value targets for state-sponsored operations, a single evidence-integrity incident would poison every ledger record and challenge result, interact with information-barrier misconfiguration to either blind inspectors or leak model weights/source code, and interact with staffing gaps by creating insider-threat single points of failure; the recommendation is to deploy hardware-separated national evidence systems, enforce strict need-to-know compartments, run continuous counterintelligence monitoring, and drill the joint cyber-incident isolation protocol twice before clock start; contingency: if compromise occurs, activate pre-validated redundant backup evidence systems, isolate the affected national node without halting verification at other sites, and invoke a pre-agreed re-verification protocol to re-establish evidence integrity before resuming the 90-day clock.


## Review 5: Critical Assumptions

1. **Assumption: Domestic access-authority legislation can be enacted and enforced in both countries to compel operator, manufacturer, maintenance-provider, and logistics-company participation and override private-law objections.** If this assumption fails, courts, regulators, or private operators could block inspectors for 3–6 months and add $10–50M in litigation and legislative fixes (Risk 3), escalating to an asymmetric-access Stop condition and invalidating the 90-day Phase One clock; this compounds with the vendor-refusal risk because unenforceable legal mandates leave compliance dependent on goodwill, and with the managed-access gap because denials become legal disputes rather than verification results. **Recommendation:** Validate before clock start by obtaining formal DOJ/MOFA legal opinions, drafting model implementing legislation, and exercising the enforcement path in tabletop drills; if litigation emerges, activate contractual site-eligibility clauses and operator binding as a parallel enforcement route.


2. **Assumption: Both governments can legally and politically pre-fund their full $2.5B contributions into a jointly signatory escrow before the Phase One clock starts.** If this assumption fails, milestone-linked tranches become the only fallback and a delayed disbursement can act as a quiet veto, idling the inspectorate for 6–12 months at $150–250M and consuming the $500M contingency before any verification evidence exists; this compounds with political-continuity risk because fiscal certification gates the clock and with matched-site parity risk because asymmetric funding collapses reciprocal deployment. **Recommendation:** Obtain binding legal opinions and treasury confirmations by 2027-02-28 and run cash-flow stress tests; if full pre-funding is impossible, negotiate a legally binding mutual standby bridge with the identical 10-business-day delay trigger and quarterly USD reconciliation so delayed contribution cannot act as a quiet veto.


3. **Assumption: The confidential attribute-based covered-equipment schedule can be defined, versioned, and kept current without reopening the bilateral definitional bargain.** If this assumption fails, new frontier-relevant hardware could ship outside verification for 4–8 weeks during double-key approval, and a frozen schedule would make the regime's credibility decay immediately after launch—forcing a Modify or Stop verdict and wasting the $5B investment; this compounds with the baseline-inventory gate because schedule errors corrupt the cryptographic asset registry, and with unvalidated KPI thresholds because detection denominators depend on correct coverage definitions. **Recommendation:** Pre-negotiate an attribute-based coverage framework and a 48–72-hour fast-track provisional listing mechanism before clock start, link sunset reviews to declared new generations, and maintain a versioned changelog with pre-registered dispute criteria; if schedule disputes deadlock, trigger the pre-agreed double-key arbitration path instead of allowing revisions to halt verification.


## Review 6: Key Performance Indicators

1. **Event-recording and synchronization latency KPI with specific threshold bounds:** Target 99th percentile local event recording under 5 minutes, cross-national synchronization under 1 hour, and divergence reconciliation under 24 hours; if the 99th percentile exceeds 7 minutes locally or sync exceeds 2 hours, trigger an automatic performance review and corrective maintenance within 48 hours, because breaching these bounds creates a silent window that red teams can exploit and directly invalidates the latency-budget assumption that underpins the Go/Modify/Stop verdict—interacting with unvalidated KPI thresholds and ledger divergence risks. **Monitor continuously** through automated ledger node telemetry, daily dashboard alerts, and monthly fault-injection reconciliation drills to verify the thresholds hold under realistic failure scenarios.


2. **Reciprocal access parity ratio KPI across matched site pairs:** Target a rolling 30-day access-hours ratio between 0.9 and 1.1 for every matched pair, with corrective action required if any pair falls outside this range for more than 5 consecutive days (escalate to co-chairs and implement a rebalancing access plan); this KPI operationalizes the asymmetric-access Stop trigger and interacts with matched-site parity risk and political-continuity risk, because paper parity must be proven through live drills and sustained access. **Monitor via automated access-log capture**, daily scorecards for each pair, and a joint monthly review that benchmarks reciprocal hours and outcomes to ensure the tolerance band reflects real verification equivalence.


3. **Funding-timeliness KPI with a hard 10-business-day suspension trigger:** Target 100% of scheduled national contribution releases and envelope disbursements occurring within 10 business days of their due date, with zero funding-related suspensions; any delay beyond 10 business days automatically records a KPI-visible suspension trigger and escalates to heads of state, preventing a quiet fiscal veto that would idle the inspectorate and consume contingency reserves before evidence is produced. **Monitor through the escrow system's automatic release tracking**, quarterly USD reconciliation, and a public KPI dashboard that reports funding timeliness to legislatures and oversight bodies, while also running periodic stress tests of the milestone-tranche fallback to ensure the trigger cannot be circumvented.


## Review 7: Report Objectives

1. **Primary objective: deliver a jointly certified Go/Modify/Stop decision for the 90-day Phase One verification test** and produce the operational infrastructure—six matched sites, mirrored inspectorate, replicated ledger, information barriers, and baseline registry—while the intended audience is U.S./Chinese government decision-makers, appropriations committees, operators, vendors, and verification experts, with key decisions including whether to certify entry conditions, release the $5B escrow, and authorize Phase Two; Version 2 must replace provisional KPI thresholds with a pre-registered, statistically validated test design and include real baseline inventory counts and signed legal instruments, not assumptions.


2. **Intended audience: bilateral political and fiscal authorities who must act on the plan's recommendations** including equal national co-chairs, heads of state/party leadership, legislatures, and treasury officials, informed by the report's key decision points of approving the bilateral instrument, enacting domestic access authority, pre-funding the escrow, and selecting matched sites; Version 2 must incorporate formal legal opinions from both governments, continuity commitments, and a resolved legal form for the Consortium so that the entry-condition phase can be certified rather than remaining a diplomatic handshake.


3. **Version 2 differentiator: transform the plan from a concept into an evidence-backed implementation blueprint** by addressing the expert-identified gaps—defining a managed-access floor, separating inspectorate facts from co-chair decisions, validating KPI thresholds with pilot blind challenges, completing the baseline inventory, and exercising the visa/customs annex—so that the final report gives decision-makers quantified confidence intervals, actual access-benchmark results, and a legally binding governance annex rather than unsupported targets and optimistic assumptions.


## Review 8: Data Quality Concerns

1. **Operator and vendor compliance records for the baseline inventory are incomplete across the six declared sites**, because the plan lacks actual floor plans, procurement records, and maintenance logs—relying on them for the cryptographic asset registry means a 2–5% serialized discrepancy rate (roughly 1,000–2,500 units out of the assumed 50,000) could delay reconciliation by 4–8 weeks and cost $20–60M, and if the false-negative rate then exceeds the 5% blind-challenge threshold, the Go verdict becomes indefensible; validate by running the planned synthetic reconciliation simulation against real operator data from at least two candidate sites, engaging IAEA safeguards inventory specialists, and mandating joint physical counts before Version 2 is finalized.


2. **The CNY/USD exchange-rate and local inflation projections used for the $5B budget envelope are not backed by current or stress-tested data**, because China-side costs are denominated in CNY but only a single unhedged 5% shock is referenced, yet a 5% currency or inflation movement adds $125–250M and could consume the entire $500M contingency before independent testing; assess by building a QuantLib-based FX simulation with actual central-bank forecasts, historical volatility, and 10%/20% stress scenarios, then re-baseline the envelope allocations in Version 2 with a dedicated FX reserve and structured quarterly conversion windows.


3. **The KPI threshold denominators and challenge-event counts are incomplete or absent in the current draft**, because the 5% false-negative-at-95%-confidence claim requires roughly 60 independent blind challenge events per material-event category under the rule of three, but the 90-day six-site schedule, event definitions, and cross-site contamination controls are not specified, so the final verdict could be contested by selecting a different denominator or confidence-interval method; address by producing a pre-registered Test and Evaluation Master Plan with explicit event counts, injection schedules, and confidence-interval formulas, and by running pilot blind challenges at two sites to generate real detection data for Version 2.


## Review 9: Stakeholder Feedback

1. **Formal confirmation from both governments on the legal form and domestic authority**: critical because the report currently assumes a bilateral instrument and implementing legislation are achievable, but without written legal opinions from U.S. State/DOJ and Chinese MOFA/legislative-affairs bodies, the entire entry-condition certification is a handshake—if the legal form proves unattainable, the program could face 6–24 months of litigation and legislative delays, add $10–50M in legal costs, and fail to start the 90-day clock; obtain this by convening the joint legal task force now and requesting binding written opinions by 2026-12-18, then incorporate the agreed legal form and enforceable enforcement paths directly into Version 2.


2. **Vendor and operator participation commitments from dominant manufacturers and datacenter operators**: critical because the forced-evidence ladder and access protocols depend on pre-negotiated model agreements, yet no dominant vendor has confirmed willingness or clean-room access feasibility—if a single dominant vendor refuses at multiple sites, escalation would consume 2–6 weeks per refusal and could push unverifiable-equipment counts above the 2-unit/1% threshold, forcing a Stop verdict and wasting the $5B investment; obtain this by conducting structured interviews with at least the top three vendors per site, executing model access agreements with 90% coverage by 2027-05-31, and documenting binding commitments in Version 2 so the vendor-refusal risk is quantified with actual refusal probabilities.


3. **Political-continuity mechanisms accepted by both legislatures**: critical because the report proposes multi-year funding obligations, transition briefings, and escrow-return clauses, but no legislature has confirmed acceptability—if a leadership transition occurs during the 12-month entry-condition phase, the program could be delayed 12–24 months and consume $400–600M in sunk costs before producing any operational ROI, and without transition-briefing requirements the entire verification community loses institutional memory; obtain this by engaging U.S. appropriations/foreign-affairs committees and Chinese legislative/State Council bodies with draft continuity language, securing at least two formal commitments by 2027-02-28, and testing them in a transition-scenario war-game before finalizing Version 2.


## Review 10: Changed Assumptions

1. **Changed assumption: the fixed 12-month entry-condition and 90-day Phase One timeline may no longer be realistic given legislative and geopolitical disruptions since Version 1** — each month of entry-condition slippage idles the ~450-FTE inspectorate at roughly $7.5M/month (based on $200k loaded annual cost), so a 6-month delay adds $45M in idle costs plus an estimated $400–600M in sunk preparation before any evidence exists, consuming the $500M contingency and increasing the probability of leadership-transition risk that could terminate the program; review by re-running the integrated readiness tracker with current legislative calendars, political schedules, and actual clearance timelines, then re-baseline the clock with jointly agreed escalation triggers instead of an immovable 2027-Sep-04 date.


2. **Changed assumption: sustained political backing and mutual threat perception remain unchanged, but national-security priorities may have shifted since Version 1** — if either government now views AI cooperation as less urgent or more adversarial, the program faces a quiet veto or withdrawal during the entry-condition phase, delaying Phase One by 12–24 months and driving ROI to near zero with $400–600M in sunk costs and no verification outcomes; this compounds fiscal escrow and matched-site parity risks because delayed commitment breaks reciprocal deployment and can trip the asymmetric-access Stop trigger; update by conducting a stakeholder reassessment with current leadership, refreshing continuity commitments (multi-year funding language, transition briefings, escrow-return clauses), and incorporating a revised political-risk register into Version 2.


3. **Changed assumption: the confidential attribute-based covered-equipment schedule can remain current without reopening the bilateral definitional bargain, but new frontier-AI hardware generations may have fielded since Version 1** — if the schedule's attribute definitions no longer capture new architectures, equipment could escape verification for 4–8 weeks during double-key approval, and if the schedule is revised, the bilateral negotiation reopens and risks a 3–6 month delay, pushing the false-negative rate above the 5% threshold and invalidating the Go verdict; address by convening a joint technical review of current hardware generations, stress-testing attribute definitions against real products, and pre-negotiating a fast-track provisional listing mechanism with 48–72-hour double-key approval so the schedule stays current without stalling the 90-day clock.


## Review 11: Budget Clarifications

1. **Escrow interest accrual and ownership rules remain undefined, creating a potential $125–250M fiscal ambiguity over the program's 12–18 month lifecycle**: if the jointly signatory escrow earns treasury-rate interest on $5B (roughly 2.5–5% annually), the Consortium must decide whether interest offsets administrative costs, returns to governments, or funds overruns; without a pre-agreed rule, quarterly reconciliation will be contested, delaying envelope drawdowns and breaking the funding-timeliness KPI that prevents quiet vetoes; resolve by obtaining treasury/legal opinions on interest disposition, drafting an escrow-return and interest-sharing clause before the clock starts, and documenting the rule in Version 2's fiscal governance annex.


2. **The $750M inspectorate envelope lacks a transparent reconciliation between the 450-FTE workload model and actual loaded costs, leaving a $75–150M potential shortfall if clearances or recruitment slip**: the estimate assumes $200k loaded annual cost per FTE, but bilingual technical talent scarcity, security-clearance delays, and retention bonuses could add 10–20% premium costs ($75–150M), while the 1.5x leave/backup multiplier and 10% surge cadre are not explicitly priced against the 18-month readiness-plus-Phase-One period; without a role-by-role FTE table and envelope-level cost build-up, the program risks either over-committing funds to staffing or running out mid-test; resolve by publishing a detailed staffing cost model mapped to the workload formula, stress-testing clearance delays, and re-baselining the $750M envelope or contingency allocation in Version 2.


3. **The $500M contingency envelope lacks a prioritized allocation framework for compounding scenarios, so a single 5–10% cost overrun ($250–500M) could consume it before independent testing**: the plan identifies risks (FX shock, weather delay, vendor refusal escalation, cyber incident) but does not assign contingency shares or trigger thresholds, meaning simultaneous events—for example, a 5% CNY depreciation ($125M) plus a 4-week vendor-refusal ladder ($20M) plus a grid outage ($5–20M)—could exhaust the reserve and force a Stop or Modify verdict; resolve by creating a contingency-spending priority matrix with envelope-level trigger points, a dedicated FX reserve (e.g., $150M), a disaster-response allocation ($20M), and a decision rule for reallocating unused envelope funds to contingency only under double-key approval.


## Review 12: Role Definitions

1. **Dedicated Discrepancy Adjudication and Verdict Construction Lead**: This role must be explicitly created and assigned in Version 2 because the current plan references mirrored adjudication units and a shared findings narrative but leaves no accountable owner, so unresolved-discrepancy-age KPIs (max 10 business days) and the final Go/Modify/Stop verdict risk being handled ad hoc, causing the 90-day clock to be consumed by arguments over materiality and delaying the verdict by weeks or making it politically contested; implement by adding a full-time, mirrored co-lead (one per country) with dedicated legal, technical, and investigator staff, a RACI matrix for discrepancy escalation, and a tabletop validation of the verdict-construction workflow before Phase One.


2. **Covered-Equipment Schedule Custodian and Technical Configuration Manager**: Version 2 must define this role because the confidential attribute-based covered-equipment schedule is the definitional backbone of verification, and without a named custodian the 48–72-hour fast-track provisional listing, sunset reviews, and versioned changelog cannot operate, allowing new frontier-relevant hardware to ship outside verification for 4–8 weeks and potentially invalidating the false-negative threshold and Go decision; implement by creating mirrored technical and legal specialist co-custodians, assigning double-key specialist approval, and pre-registering dispute criteria so schedule revisions cannot reopen the bilateral bargain.


3. **Joint Secretariat / Program Integration Lead with consolidated decision rights**: Version 2 must clarify this role's authority because the current plan distributes readiness tracking, master scheduling, and risk management across multiple workstreams without a central integration function, creating accountability gaps that can delay entry-condition certification by 3–6 months and waste $75–150M in idle staffing if dependencies are missed; implement by establishing a Joint Secretariat with two co-directors (one per side), a small PMO, ownership of the integrated readiness tracker and master schedule, and explicit escalation authority to the co-chairs for unresolved cross-workstream blockers.


## Review 13: Timeline Dependencies

1. **Covered-equipment schedule finalization must precede or be tightly synchronized with baseline inventory completion**: if the attribute-based schedule is not adopted before the joint physical inventory (target 50,000 units at six sites), then the baseline registry may exclude new hardware generations or include obsolete definitions, requiring a full or partial recount that adds 4–8 weeks and $20–60M, and if the false-negative threshold is then measured against a misaligned baseline, the Go verdict becomes indefensible; this compounds the schedule-versioning risk and the unvalidated KPI risk because a wrong baseline invalidates both detection denominators and materiality corridors; concretely, Version 2 should gate the baseline inventory on prior double-key approval of the coverage framework and include a fast-track provisional listing mechanism that allows post-baseline additions only with a re-validation of the affected site's registry.


2. **Escrow drawdown authorization must be available for the 12-month entry-condition preparation phase, not only after the Phase One clock starts**: if the $5B escrow is pre-funded but funds cannot be released until joint certification, then the ~450 FTE inspectorate cannot be hired and cleared, the integrated readiness tracker cannot be staffed, and the entry-condition phase itself stalls, with a 6-month funding release delay adding $45M in idle staffing costs and pushing Phase One start 3–6 months past the 2027-Sep-04 boundary; this interacts with the quiet-veto fiscal risk and the staffing/clearance bottleneck because late funding prevents the very parallel clearances designed to mitigate that bottleneck; concretely, Version 2 should define a separate 'preparation-phase drawdown' tranche from the escrow (e.g., 10% of the inspectorate envelope) that is released upon political commitment, with envelope-coded controls and quarterly reconciliation to prevent misuse.


3. **Information-barrier filter rules must be frozen and validated in pilot blind challenges before the phase One clock starts**: if filter rules are still being calibrated after launch, the first 2–3 weeks of Phase One detection results cannot be included in the KPI dataset, reducing the effective sample size from roughly 60 to 40 challenge events per category and raising the upper 95% confidence bound for false negatives from ~5% to ~7.5%, failing the pre-registered threshold and making the verdict contestable; this interacts with the information-barrier over-filtering risk and the unvalidated-KPI risk because late changes to barrier rules compromise the comparability and independence of detection metrics; concretely, Version 2 should require double-key approval of the versioned filter rules by 2027-06-30, completion of the two-site pilot blind challenges before clock start, and a pre-agreed rule that any post-launch barrier change resets the clock or quarantines the prior data as non-comparable.


## Review 14: Financial Strategy

1. **Long-term funding model for Phase Two is undefined**: without a clarified path for continued appropriations or a second escrow, the $5B covers only Phase One, so a successful Go verdict that needs expansion (e.g., from 6 to 12 sites) could stall for 12–24 months while legislatures negotiate, wasting the political capital and institutional memory built at roughly $135M/year running cost; this interacts with the political-continuity risk because a funding gap after Phase One makes the regime vulnerable to leadership transitions; actionable step: in Version 2, define a conditional Phase Two funding framework triggered by a Go verdict, with pre-agreed multi-year appropriation language and a cost-per-site formula, so matching capital can be committed before the 90-day clock ends.


2. **Escrow residual, interest, and contingency disposition rules are unanswered**: leaving unresolved how unspent funds (potentially $500M+ contingency, plus interest on $5B over 12–18 months) are returned, reinvested, or carried forward creates a fiscal dispute that can delay acceptance of the final verdict and poison Phase Two negotiations, reducing the program's effective ROI by leaving billions in limbo; this interacts with the pre-funded escrow assumption and the quiet-veto risk because ambiguous disposition invites each government to use fiscal delay as leverage; actionable step: negotiate and include in Version 2 a termination/return-of-funds clause with joint signatory control, quarterly interest reporting, and a pre-agreed formula for distributing unspent contingency by equal shares.


3. **Multi-year currency and inflation risk management strategy is missing**: the budget only models a one-time 5% FX shock for the 90-day test, but Phase Two and sustained operations face multi-year CNY/USD volatility and local inflation; a 10% cumulative depreciation could add $250M to China-side costs, consuming the $500M contingency and forcing a Modify verdict or a budget renegotiation mid-regime; this interacts with the fiscal escrow and envelope-control assumptions because fixed USD envelopes become misaligned with CNY-denominated obligations; actionable step: in Version 2, adopt a structured rolling-hedge program (quarterly forward contracts), establish a dedicated FX reserve of at least $150M replenished from escrow interest, and include an annual re-baselining trigger that adjusts envelope values only under double-key approval based on audited actuals.


## Review 15: Motivation Factors

1. **Visible progress toward entry-condition certification is a core motivational driver**: if the integrated readiness tracker shows stalled conditions (e.g., site selection or inspector approvals slipping), teams lose confidence and attrition rises, and the plan's own 450-FTE staffing model with a 10% surge cadre could see a 5–10% annual attrition that adds $75–150M in rehiring and re-clearing costs and delays Phase One by 3–6 months; this interacts with the clearance bottleneck and political-continuity risk because demotivated inspectors and staff will not wait through a 12-month entry phase without evidence of forward motion; recommendation: publish a visible, joint KPI dashboard with weekly progress milestones, celebrate closure of each entry condition with leadership recognition, and tie surge-cadre retention bonuses to certification milestones so momentum is tangible and rewarded.


2. **Dual-national team cohesion and trust are essential under high-distrust conditions**: if mirrored national teams settle into adversarial postures or suspect information-barrier cheating, every routine discrepancy escalates into a deadlock, consuming the 10-business-day deadlock budget and potentially tripping automatic suspension—such distrust-driven delays could add 2–4 weeks to the 90-day clock and waste $5–20M in rescheduling and arbitration costs, and it directly amplifies the double-key governance and managed-access risks by converting verification findings into political disputes; recommendation: institutionalize joint training, team-building exercises, and shared success metrics in the common curriculum, and create a neutral joint ombuds function so frictions are resolved at working level before they reach the co-chairs.


3. **Credibility of the final verdict and personal accountability for evidence quality sustain inspector discipline**: if inspectors believe their observations are merely inputs to a political negotiation rather than professionally recorded facts, they will under-invest in meticulous evidence collection, inflating the false-negative rate above the 5% target and undermining the single most important success metric—this could turn a Go verdict into a false Go and destroy the regime's long-term credibility, wasting the entire $5B investment; recommendation: establish a professional inspectorate identity with protected technical-fact reporting independent of co-chair approval, publicly recognize high-integrity detection outcomes, and create a peer-review and audit process that shows every material finding is used transparently in the verdict construction.


## Review 16: Automation Opportunities

1. **Automate the integrated readiness tracker and entry-condition certification workflow**: replacing manual weekly data submissions and co-chair certification packages with a digital workflow that auto-collects evidence from ledger nodes, site access logs, staffing systems, and legal clearance records could eliminate 10–15 hours per week for each of the ~20 readiness-tracker staff, saving ~$1.5–2.5M in labor costs over the 12-month entry phase and shortening the certification cycle from weeks to days; this interacts with the staff clearance bottleneck because it frees scarce program-integration personnel to focus on at-risk conditions rather than data entry, and with the 2027-Sep-04 deadline by reducing slip risk; implement by procuring or building a low-code tracker with API integration to the KPI dashboard and escrow system, pilot-testing it by 2026-12-31, and requiring all workstream owners to maintain real-time status instead of weekly manual reports.


2. **Automate ledger divergence detection and reconciliation triage**: implementing continuous hash-commitment comparison and machine-learning-assisted root-cause classification can detect divergence alerts in near-real-time and route them to the correct national node team, reducing the manual triage time from an estimated 4–8 hours per event to under 30 minutes, and across six sites with 5,000+ synthetic events this could save 1,500–2,500 engineering hours (~$300–500k) per validation cycle while improving the probability of meeting the 24-hour divergence-reconciliation target by as much as 30%; this directly supports the material-event latency budget and reduces the risk of the divergence Stop condition; implement by deploying automated alerting with pre-defined playbooks and a central reconciliation console, then validate the triage algorithms through fault-injection drills before Phase One.


3. **Streamline the forced-evidence ladder with a digital case-management and escalation system**: automating the workflow from vendor refusal to clean-room examination—including pre-filled access agreements, e-signature routing, timestamped evidence capture, and automated threshold alerts for unverifiable-equipment counts—can cut the time-to-disposition from an estimated 2–6 weeks per refusal to under 10 days, saving $5–15M in escalation and legal costs per major refusal and preventing the vendor-refusal contagion from breaching the 2-unit/1% site threshold; this interacts with the 90-day clock because faster ladder resolution preserves the verification window for other challenges; implement by building a contract-management and case-tracking system integrated with the ledger and KPI dashboard, pre-loading all negotiated vendor agreements, and training inspectors and examiners on the digital workflow during the entry-condition phase.

# Questions & Answers

**Q1: What is 'double-key governance' in this bilateral verification program, and why is the lack of a casting vote considered both a protection and a risk?**

A1: Double-key governance means that major decisions—such as material findings, sanctions, and suspension—require approval from both national co-chairs, with no casting vote and no majority overrule. This protects sovereignty and prevents either country from unilaterally imposing findings on the other. However, it also creates a deadlock risk: one co-chair can block decisions indefinitely, either to shield an operator or to stall the verification process. The plan mitigates this by routing routine discrepancies to joint technical teams, referring deadlocked factual disputes to a jointly selected advisory arbiter, limiting automatic suspension to sites with unresolved material discrepancies, and escalating deadlocks that last more than 10 business days to national leadership. The underlying tension is that the same mechanism designed to prevent unilateral overrule can become a tool for delay unless pre-agreed deadlock procedures are in place before the 90-day clock starts.

**Q2: What is an 'information barrier' in this project, and why is over-filtering as dangerous as under-filtering?**

A2: An information barrier is an engineered system of filtered workstations, bounded inspection zones, and clean-room protocols that lets inspectors verify equipment identity and material changes without exposing protected data such as workloads, model weights, source code, customer data, or security architecture. Both governments require this protection because the program involves mutual distrust and dual-use technology exposure. The critical trade-off is that filtering can strip contextual metadata—such as surrounding equipment, timestamps, or environmental indicators—that inspectors need to detect a substituted or hidden device. If the barrier is too weak, sensitive technology leaks and political support collapses; if it is too strong, inspectors are effectively blinded and false-negative rates rise. The plan therefore requires the barrier rules to be validated in blind challenges before deployment, measuring both substitution-detection sensitivity and leakage incidents.

**Q3: Why is the stated KPI of a 'false-negative rate no greater than 5% at 95% confidence' considered statistically unsupported?**

A3: A false-negative rate is not a management target that can simply be declared; it must be estimated from a defined set of challenge events. Under the 'rule of three,' if a test runs only 20 independent blind challenges and sees zero misses, the upper 95% confidence bound on the false-negative rate is about 14%, not 5%. To claim an upper bound near 5% with zero misses, roughly 60 independent challenge events are needed—and likely 60 per material-event category. The 90-day, six-site schedule may not support that many independent, non-contaminated challenges. The expert review in the document therefore recommends a pre-registered Test and Evaluation Master Plan with exact event counts, confidence-interval formulas, and rules for handling unresolved events, and it recommends marking unsupported thresholds as 'TBD' until pilot blind challenges provide real data. Without this, the Go/Modify/Stop verdict would be a negotiation rather than a defensible statistical inference.

**Q4: What is the 'managed access floor,' and why does its absence undermine the entire verification architecture?**

A4: In treaty verification, 'managed access' means the inspected party may protect sensitive information by restricting what inspectors see, but it may not simply deny access; any restriction must be compensated by alternative arrangements sufficient to satisfy the inspection objective. The expert review criticizes the plan for treating information protection as if it could override verification: because every evidence stream can be filtered and every area can be bounded, without a pre-agreed floor of minimum access the inspected side could deny meaningful inspection by pointing to sensitive data. The recommended fix is a Protocol on Access and Managed Access that specifies which locations, equipment, and records are always subject to inspection; requires managed-access alternatives such as shrouding, escort, filtered display, or clean-room reading; and treats an unresolved denial as a material discrepancy rather than a graceful 'unverifiable' outcome. Without this floor, blind-challenge results would measure only what the inspected side allowed, not what inspectors could actually detect.

**Q5: What is the 'quiet veto' risk in the funding mechanism, and how does escrow pre-funding prevent it?**

A5: A 'quiet veto' occurs when one government delays or withholds its financial contribution, starving the program of resources and halting operations without ever formally triggering the agreed 'withholding-funding' Stop condition. Because each government administers its own domestic operator and vendor compensation, a slow disbursement can idle the inspectorate and break reciprocal deployment while appearing to be a routine administrative delay. The plan's primary defense is full pre-funding: both governments deposit their entire USD 2.5 billion contributions into a jointly signatory escrow before the Phase One clock starts. Drawdowns are then envelope-coded and released only against approved expenditures, with quarterly USD reconciliation. If full pre-funding is politically impossible, the fallback is milestone-linked tranches with an identical KPI-visible trigger: any contribution delay beyond 10 business days automatically records a suspension trigger and escalates to leadership. This makes fiscal delay visible and consequential rather than a silent way to undermine the program.

**Q6: Why does the program deliberately exclude comprehensive AI governance, workload verification, and model-weight inspection, and why is this narrow scope ethically and politically controversial?**

A6: The program is a sovereign national-security verification mechanism, not an AI governance regime. Its scope is limited to verifying material changes to declared frontier-relevant computing equipment at matched datacenters. It explicitly avoids capacity estimates, workload verification, model weights, hidden facilities, and comprehensive AI governance because those are far more intrusive, politically infeasible, and would conflict with sovereignty and information barriers. The controversy is that this narrow scope may be seen as insufficient to address frontier AI risks, and could even legitimize unchecked AI development by providing a false sense of security. The plan openly states that success should be judged only against the narrow mission, not as a broader AI-governance guarantee. Ethically, this is a trade-off between feasibility and responsibility, and the documents repeatedly stress the need to avoid mission creep.

**Q7: What is the "killer application" gap, and why does the recommendation to develop a crisis-stability narrative create a risk of scope creep?**

A7: The "killer application" gap refers to the lack of a single flagship use-case, such as a verified crisis-stability freeze on material frontier-AI compute changes, that would make Phase One strategically indispensable to either government. Without it, political and funding continuity remain vulnerable. The SWOT analysis recommends developing a narrative that frames the program as a crisis-stability tool. However, this is controversial because promoting such a narrative could expand the program's perceived scope beyond declared-equipment change verification, creating expectations that the Consortium cannot meet and potentially dragging it into broader AI governance debates. The documents explicitly caution that the "killer application" narrative must not expand the legal scope of the instrument. The tension is between the need for political salience and the commitment to a narrow, feasible mandate.

**Q8: Why is political discontinuity considered the largest program-level risk, and what are the implications of investing US$5 billion in a regime that a leadership transition could reverse?**

A8: Political discontinuity—a U.S. administration change, Chinese leadership transition, or congressional appropriations battle—can reverse the bilateral commitment before Phase One even starts. The plan spans at least 12 months of entry conditions plus 90 days of testing, and there is no guarantee that successors will honor the agreement. The pre-funded escrow mitigates the quiet fiscal veto but cannot compel a successor government to continue hosting foreign inspectors. If a transition occurs, sunk preparation costs could reach $400-600M, plus $150-250M in idle inspectorate costs, with zero verification outcomes. The ethical implication is that such a large allocation of public funds may be unjustifiable if the risk of political reversal is high. The plan's mitigation includes continuity commitments, transition briefings, escrow-return clauses, and a public KPI dashboard to make termination politically costly, but these measures are not guaranteed to be enforceable.

**Q9: How might the information barrier be exploited to conceal evidence, and what is the ethical balance between national security and verification integrity?**

A9: The information barrier is designed to protect sensitive data (workloads, model weights, source code) during inspections. However, the expert review warns that the plan lacks a 'managed access floor': without pre-agreed minimum access rights, the inspected party could use the barrier to filter out contextual metadata needed to detect substitution, or simply deny access by claiming sensitive data is present. This turns every denial into a legal dispute rather than a verification result. Ethically, both sides have legitimate secrecy needs, but verification integrity requires that protection not defeat the inspection objective. The plan addresses this by testing barrier rules in blind challenges, using clean-room examination by accredited independent examiners, and treating unresolved denials as material discrepancies. However, the tension remains: one country could attempt to hide bad-faith actions behind the barrier, and the other could likewise use it to conceal its own. The ethical balance is between respecting sovereignty and ensuring the regime actually detects violations.

**Q10: What is the risk of a "false Go" or "false Stop" decision, and why does it have broader national-security implications?**

A10: A "false Go" would occur if the KPI thresholds are not statistically validated and the program certifies a verification regime that actually cannot detect real substitution, leading to overconfidence in a flawed system. A "false Stop" would occur if thresholds are too strict, wasting the $5B investment and abandoning a potentially valuable mechanism. The plan's own pre-project assessment admits the KPI thresholds (e.g., ≤5% false-negative rate) are provisional and unsupported, and the expert review calculates that a 90-day six-site test cannot support the required sample size. If unvalidated thresholds are used, the Go/Modify/Stop verdict could be a political artifact rather than a defensible statistical inference. The broader implication is that a false Go could legitimize an ineffective verification regime, undermining future trust in bilateral arms-control or technology-verification efforts. Conversely, a false Stop could discourage future cooperative security measures. The plan's mitigation is to pre-register a Test and Evaluation Master Plan, run pilot blind challenges, and mark all unsupported thresholds as TBD until validated.

# Premortem

A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Both governments will sustain political backing and domestic legal authority through the 12-month entry-condition phase and the 90-day Phase One clock, including appropriations, escrow pre-funding, and operator/vendor compulsion, across any leadership transitions. | Convene the joint legal task force immediately and obtain signed, binding legal opinions from the U.S. State Department/DOJ and Chinese MOFA/legislative-affairs bodies on treaty form, domestic access authority, escrow legality, and data transfer; negotiate and table model continuity clauses and transition-briefing requirements before the 2026-12-18 milestone. | Either government fails to provide a formal legal opinion by 2026-12-18, or a leadership transition, appropriations rider, or ministerial directive voids the escrow pre-funding commitment before 2027-09-04. |
| A2 | All covered equipment at the six declared sites can be physically inventoried, serialized, and reconciled from operator records into a cryptographic asset registry with no more than 2% unexplained serialized discrepancy before the Phase One clock starts. | Stand up the joint baseline inventory task force and execute a pilot physical inventory at one matched site pair using actual operator procurement and maintenance records, synthetic reconciliation runs, and dual-national serialization checks; measure reconciliation time and discrepancy rates against the 2% threshold. | The pilot inventory reveals unexplained serialized discrepancy greater than 2% at either site, or reconciliation of a single site takes more than 8 weeks, demonstrating that the six-site baseline cannot be certified within the entry-condition window. |
| A3 | A 90-day, six-site test can generate enough independent blind challenge events per material-event category to substantiate a false-negative rate no greater than 5% at 95% confidence, and both governments will accept a pre-registered statistical analysis plan. | Commission an independent verification statistician to produce a Test and Evaluation Master Plan with power analysis, event-count requirements per category, confidence-interval formulas, unresolved-event handling, and a 90-day challenge schedule simulation; obtain double-key approval of the pre-registered analysis rules. | Power analysis shows that more than 60 independent challenge events per material-event category are required and the 90-day, six-site schedule cannot support them, or either government refuses to pre-register the analysis rules before operational data are collected. |
| A4 | The information-barrier filter rules can be designed and validated so that substitution-detection sensitivity in blind challenges stays within 10% of the unfiltered baseline while zero evidence-integrity-compromising leaks occur. | Build a filtered workstation prototype and run at least two blind challenge sets with synthetic workloads and injected substitutions through both filtered and unfiltered evidence channels before 2027-06-30, measuring detection sensitivity and metadata survival. | Detection sensitivity with filtered evidence falls more than 10 percentage points below the unfiltered baseline, or any leaked workload, model-weight, source-code, or network-topology field appears in inspector-visible output during blind challenges. |
| A5 | At least 90% of vendors serving declared sites will sign model vendor-access agreements before the Phase One clock starts, and clean-room examination by accredited independent examiners can verify equipment identity to the 99% confidence target without exposing proprietary source code. | Conduct structured interviews with the top three vendors serving each declared site and execute two live vendor-refusal challenge exercises by 2027-05-31, measuring time-to-disposition through the forced-evidence ladder. | Signed model vendor-access agreements cover less than 90% of vendors serving declared sites by 2027-05-31, or any vendor-refusal challenge takes more than 14 days to disposition through clean-room examination. |
| A6 | The approximately 450 FTE mirrored inspectorate can be recruited, security-cleared within 12 months, and trained with no single-person critical functions inside the $750M inspectorate envelope without requiring contingency drawdown. | Start security clearances for all candidates immediately and run a workforce optimization model using actual clearance lead times and bilingual talent availability; validate in a staffing tabletop exercise that no critical function is single-person by 2027-07-31. | Clearance or recruitment fills less than 90% of required FTE by 2027-07-31, the staffing tabletop identifies more than five single-person critical functions, or the inspectorate envelope requires more than $75M in premium costs. |
| A7 | A multi-attribute parity matrix can calibrate six matched sites so that reciprocal access-hours ratios remain within the 0.9–1.1 tolerance band in live benchmarking drills, and deliberately dissimilar stress sites do not make parity negotiation impossible. | Approve the multi-attribute parity matrix by 2027-04-30 and execute reciprocal access benchmarking drills at two matched site pairs within 30 days, measuring access hours and inspection outcomes for each pair. | Access-hours ratio falls outside 0.9–1.1 for either benchmarked matched pair, or stress-site inspection difficulty scores differ by more than 20% from the paired site using the approved parity matrix. |
| A8 | The replicated tamper-evident ledger can achieve 99th-percentile local event recording under 5 minutes, cross-national synchronization under 1 hour, and divergence reconciliation under 24 hours under realistic cross-border network conditions and adversarial fault injection. | Deploy a prototype with two national nodes and inject 5,000 synthetic events with network partitions, node failures, and tamper attempts; measure latency percentiles and reconciliation times under each failure scenario. | 99th-percentile local recording exceeds 7 minutes, synchronization exceeds 2 hours, or divergence reconciliation exceeds 24 hours in any injected failure scenario. |
| A9 | The double-key deadlock machinery, including joint technical teams, advisory arbitration, and object automatic-suspension triggers, can resolve routine discrepancies within 10 business days and automatic suspension cannot be blocked by a co-chair's materiality dispute. | Run three governance war-games with both national legal teams covering deadlocked factual findings, manufactured discrepancies, and vendor refusal scenarios, measuring deadlock resolution time and whether automatic triggers fire without co-chair approval. | Any war-game deadlock remains unresolved after 10 business days, or any tabletop participant can block an automatic suspension trigger by disputing materiality. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Escrow: How a Quiet Veto Killed the Clock | Process/Financial | A1 | Fiscal Escrow and Independent Audit Controller | CRITICAL (20/25) |
| FM2 | The Baseline Mirage: When 50,000 Serial Numbers Lied | Technical/Logistical | A2 | Hardware Identity and Evidence Integrity Technical Lead | CRITICAL (20/25) |
| FM3 | The Confidence Collapse: When the Numbers Became a Negotiation | Market/Human | A3 | Political Continuity and Government Liaison Lead | CRITICAL (20/25) |
| FM4 | The Blind Spot in the Filter | Technical/Logistical | A4 | Information Barrier and Counterintelligence Security Director | CRITICAL (20/25) |
| FM5 | The Vendor's Veto | Market/Human | A5 | Operator and Vendor Compliance Liaison | CRITICAL (20/25) |
| FM6 | The Clearance Chasm | Process/Financial | A6 | Mirrored Inspectorate Operations Director | CRITICAL (20/25) |
| FM7 | The Deadlock Machine | Process/Financial | A9 | Bilateral Governance and Legal Implementation Lead | CRITICAL (20/25) |
| FM8 | The Silent Ledger | Technical/Logistical | A8 | Hardware Identity and Evidence Integrity Technical Lead | CRITICAL (15/25) |
| FM9 | The Paper Parity | Market/Human | A7 | Datacenter Site Preparation and Cross-Border Logistics Manager | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Empty Escrow: How a Quiet Veto Killed the Clock

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Fiscal Escrow and Independent Audit Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase One never starts. The causal chain begins with an unexamined belief that both governments' political commitment is durable. By October 2026, the joint legal task force has not obtained binding legal opinions because the U.S. Congress refuses to pre-fund escrow before a Government Accountability Office study, and China's MOFA conditions escrow participation on resolution of a bilateral trade dispute. A leadership transition in one country replaces the lead negotiator, and the continuity clause is still only a draft. The 12-month entry-condition clock burns while 450 FTE are hired against an expected start; $7.5M per month of idle inspectorate costs drains the contingency.

The 10-business-day contribution-delay trigger fires, but because the trigger was designed to be KPI-visible rather than self-executing, it only produces a dashboard alert that leadership declines to escalate. By 2027-09-04, only one $2.5B contribution sits in escrow; the other side cites 'technical legal review.' The co-chairs deadlock over whether to start the clock with asymmetric funding. The process failure is not a single dramatic decision; it is slow erosion through appropriations riders, legal opinions, and a quiet veto disguised as administrative delay.

The financial impact compounds: $300M in site preparation is already spent, the surge cadre must be stood down, and the contingency envelope is consumed by idle salaries and legal fees before a single blind challenge is executed. The program does not die from a spectacular breach; it dies from a funding process that was never legally secured.

##### Early Warning Signs
- Signed legal opinions from either government remain outstanding after 2026-12-18
- Escrow balance is below $5B at any quarterly reconciliation before 2027-09-04
- Any national contribution release exceeds the 10-business-day funding-timeliness threshold
- Entry-condition certification percentage drops below 100% at the 2027-08-01 readiness review

##### Tripwires
- Escrow balance < $5B at 2027-08-01
- Contribution delay > 10 business days on two consecutive quarterly reconciliations
- Signed legal opinions from either government not obtained by 2026-12-18

##### Response Playbook
- Contain: Freeze all new drawdowns and halt inspectorate hiring until escrow pre-funding is jointly certified.
- Assess: Conduct a joint fiscal and legal audit within 14 days to quantify the funding gap, idle staffing costs, and unresolved legal barriers.
- Respond: Escalate to heads of state for a binding 30-day pre-funding deadline or activate the milestone-tranche fallback with automatic suspension triggers.


**STOP RULE:** If either government's contribution is not deposited in escrow within 60 days after the 10-business-day delay trigger fires and heads-of-state escalation fails, cancel Phase One and begin escrow-return procedures.

---

#### FM2 - The Baseline Mirage: When 50,000 Serial Numbers Lied

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Hardware Identity and Evidence Integrity Technical Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The 90-day clock starts with a registry that is a work of fiction. At the Langfang site, the baseline task force trusted operator spreadsheets for 18,000 units because the alternative was delaying certification. Guizhou's humidity damaged 212 RFID tags, but they were marked 'visually confirmed' to meet the 2% threshold. At Ashburn, 1,560 legacy racks had no serialized record; the task force assigned temporary identifiers and called the inventory 'reconciled pending.' The cryptographic asset registry hashes these fake entries.

During the second week of Phase One, a red team substitutes a retired GPU server with a visually identical third-party unit, alters its asset tag to match the registry, and records a false 'maintenance event.' The inspector's scanner reads the tag, the ledger creates a hash-chain entry, and the event is marked verified because the baseline itself is wrong. The false-negative rate is not caused by a detection failure; it is caused by the registry telling the inspectors that the wrong equipment is the right equipment.

When the true inventory audit is repeated after a suspicious discrepancy, 6.5% of covered units fail to match, and 4 of the 19 blind challenges were 'detected' only because they happened to be in areas without tag damage. The technical and logistical system did not fail during verification; it failed before verification began, because the assumption that all covered equipment could be inventoried and reconciled was never tested against real site conditions.

##### Early Warning Signs
- Any site reports unexplained serialized discrepancy greater than 2% during baseline reconciliation
- Temporary identifiers are used for more than 1% of covered units at any declared site
- Operator procurement or maintenance records are missing or unavailable for more than 5% of covered units
- Environmental tag or RFID failure rate exceeds 3% during site surveys

##### Tripwires
- Unexplained serialized discrepancy > 2% at any site after the initial physical inventory
- Reconciliation time > 8 weeks for any single declared site
- Temporary identifiers assigned to > 1% of covered units at any site

##### Response Playbook
- Contain: Halt the Phase One clock and suspend material-change verification until affected sites' registries are recertified.
- Assess: Commission an independent physical recount of any site with > 2% discrepancy and quantify the contamination of the cryptographic asset registry.
- Respond: Rebaseline the registry through a joint physical audit and re-run pilot blind challenges before restarting the clock.


**STOP RULE:** If any site's unexplained discrepancy exceeds 5% after a full recount, or if a false verification is traced to baseline registry error, cancel Phase One and require a complete rebuild of the cryptographic asset registry before any restart.

---

#### FM3 - The Confidence Collapse: When the Numbers Became a Negotiation

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Political Continuity and Government Liaison Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The first sign of trouble is a press release, not a ledger alert. The red team had injected only 23 unannounced arrival challenges across six sites because operators resisted disruptions and two sites had maintenance windows. The pre-registered master plan was never approved; thresholds were marked TBD. At the verdict, the U.S. side claims 2 misses out of 23 = 8.7% false-negative rate, above 5%. The Chinese side computes 2 misses out of 31 observed material events = 6.5%, and claims the tests are not independent. The co-chairs cannot agree because there is no jointly owned denominator.

The debate leaks to a congressional hearing and a Chinese state media commentary. Legislatures interpret the dispute as evidence that the project is political, not technical. The verification community, which is the only 'market' that can certify credibility, withholds endorsement; VERTIC and IPNDV decline to validate the results. Track-II partners distance themselves. Neither government wants to be seen as losing the narrative competition, so each amplifies its own statistic.

The Go/Modify/Stop verdict becomes a negotiation, and the final 'Modify' is accepted only because it is the least embarrassing option. The program survives in name but has lost the market for trust: no legislature will fund Phase Two, and the public sees the $5B program as an expensive argument over math. The human failure is not malice; it is the absence of a pre-registered, statistically defensible claim that both sides had already agreed to accept.

##### Early Warning Signs
- Number of independent blind challenge events per material-event category is below 60 by day 80 of Phase One
- Two or more public official statements cite conflicting false-negative denominators or confidence intervals
- Pre-registered Test and Evaluation Master Plan is not approved by 2027-03-31
- Pilot blind challenge results show an upper 95% confidence bound above 5% for false-negative rate

##### Tripwires
- Independent blind challenge events < 60 per material-event category by day 80
- No jointly approved Test and Evaluation Master Plan by 2027-03-31
- Public statements by either government offering conflicting false-negative calculations

##### Response Playbook
- Contain: Stop all public KPI reporting and freeze verdict commentary until one joint statistical statement is issued.
- Assess: Convene independent verification statisticians to audit the full challenge dataset and produce a single agreed confidence interval within 10 business days.
- Respond: Adopt the audited numbers in a joint public statement and pre-register all future thresholds and analysis rules before any continuation.


**STOP RULE:** If the two governments cannot agree on a single false-negative estimate and confidence interval within 20 business days after the independent audit, issue a Stop verdict and do not proceed to Phase Two.

---

#### FM4 - The Blind Spot in the Filter

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Information Barrier and Counterintelligence Security Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
During pilot blind challenges in June 2027, the filtered workstations stripped far more than the approved fields. Rack position, adjacent equipment serials, power-draw signatures, and vendor-specific firmware strings were removed because a junior engineer configured the rules with a broad keyword blacklist. Inspectors staring at the filtered screens saw only clean serial numbers and cryptographic hashes. The system appeared to protect sensitive data perfectly, but it had also removed the contextual metadata that would have exposed a substitution.

The red team learned this within two weeks. They substituted a GPU with a cryptographically valid attestation that matched the registry, but the physical unit had a different thermal fingerprint and a 3% power-consumption variance. Unfiltered inspection caught it easily; filtered inspection flagged nothing because the thermal and power data were in the redacted layer. The measured detection sensitivity on filtered evidence was 62% versus 94% on unfiltered evidence, a 32-point gap that shattered the 10-point tolerance. At the same time, another site discovered that a cached memory fragment containing workload identifiers had survived the filter on one workstation, proving the barrier could also fail in the other direction.

The impact was immediate and compound. The pilot blind challenges were invalidated, the information-barrier rule set was quarantined, and every KPI computed from filtered evidence became contestable. The co-chairs could not agree on whether the system was too aggressive or too permissive, so the clock kept running while engineers tried to re-version the rules. The fundamental assumption turned out to be false: the barrier could not be calibrated to preserve the evidence inspectors needed without leaking the data they were sworn to protect.

##### Early Warning Signs
- Filtered-vs-unfiltered detection sensitivity gap reaches or exceeds 10 percentage points in any pilot blind challenge
- Any protected field, including workload identifiers or source-code fragments, appears in filtered output during validation
- Filter-rule change requests exceed five per month during Phase One
- Metadata survival rate for serial numbers and contextual indicators falls below 95% after filtering

##### Tripwires
- Filtered detection sensitivity < 85% of unfiltered baseline in any blind challenge
- Any leak of protected data detected during validation or operations
- Metadata survival rate for identity-critical fields < 95% after filtering

##### Response Playbook
- Contain: Suspend evidence collection through filtered workstations and quarantine all affected challenge results immediately.
- Assess: Launch a joint technical review within 48 hours to identify which filter rules stripped substitution indicators and whether any protected data was exposed.
- Respond: Re-version and re-validate the filter rules in a new blind challenge set before resuming Phase One; if a confirmed leak occurred, activate the joint cyber-incident isolation protocol.


**STOP RULE:** If any confirmed evidence-integrity-compromising leak occurs, or if filtered detection sensitivity cannot be brought within 10% of the unfiltered baseline after two re-validation cycles, cancel Phase One.

---

#### FM5 - The Vendor's Veto

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Operator and Vendor Compliance Liaison
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
By the end of May 2027, only 61% of vendors serving the declared sites had signed model access agreements. The most critical holdout was a dominant accelerator vendor whose equipment represented 70% of covered changes at three matched sites. The vendor cited export-control restrictions and the risk of reverse engineering from clean-room examination. Legal teams argued that domestic access authority compelled participation, but the vendor's lawyers found jurisdictional gaps and the operator was reluctant to enforce the contract against its most important supplier.

The forced-evidence ladder was designed to handle exactly this situation, but each rung absorbed days and produced no verification. Vendor-supervised testing was declined. Clean-room examination was blocked because the vendor refused to ship reference equipment. The accredited independent examiner was denied physical access by the operator, who claimed the inspection would breach the vendor's trade-secret agreement. With each refusal, the unverifiable-equipment count climbed: three units at one site, five at another. The 2-unit per-site threshold was breached within two weeks.

Instead of triggering automatic suspension, the refusal became a political event. The vendor's trade association launched a public campaign warning that foreign inspectors could steal U.S. intellectual property, and a congressional delegation demanded a pause in Phase One. The Chinese co-chair saw the pause as unilateral shielding. The other operators, watching the dominant vendor succeed, began refusing minor access requests. The entire verification boundary collapsed not through a technical failure, but through the belief that one economically powerful vendor could veto the regime.

##### Early Warning Signs
- Signed vendor-access agreements cover less than 90% of vendors serving declared sites by 2027-05-31
- Any vendor-refusal challenge exceeds 14 days to reach disposition
- Unverifiable equipment count exceeds 2 units at any single site during Phase One
- Public statements or lobbying campaigns by vendor trade associations opposing clean-room examination

##### Tripwires
- Vendor agreements signed < 90% by 2027-05-31
- Any vendor refusal unresolved after 14 days
- Unverifiable equipment > 2 units at any single site

##### Response Playbook
- Contain: Freeze equipment movement at affected sites and invoke operator contractual site-eligibility obligations to compel access.
- Assess: Review forced-evidence ladder outcomes and quantify contagion risk across all sites served by the refusing vendor within 5 business days.
- Respond: Escalate to vendor CEO and government leadership, pre-accredit additional independent examiners, and if refusal persists, classify affected equipment as a material discrepancy and trigger automatic suspension.


**STOP RULE:** If a single dominant vendor's refusal causes unverifiable equipment to exceed the per-site threshold at two or more sites simultaneously, issue a Stop verdict for Phase One.

---

#### FM6 - The Clearance Chasm

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Mirrored Inspectorate Operations Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
In March 2027, a workforce audit showed that only 180 of the required 450 FTE had completed security clearances. The projected clearance timeline for the remaining candidates had stretched to 16 months, far beyond the 12-month entry-condition window. Bilingual hardware engineers were scarce; recruitment drives in both countries yielded fewer than half the required applicants. To maintain the appearance of readiness, site commanders began assigning single-person critical functions in direct violation of the separation-of-duties rule. The plan's own staffing model had been validated on paper, but never against real clearance pipelines.

The co-chairs faced an impossible choice. Delaying the clock meant admitting the 2027-09-04 certification deadline was fictional. Starting the clock with an understaffed inspectorate meant every material event could be invalidated by a single absence. They chose to start anyway after the Chinese side accepted an interim certification. Three weeks into Phase One, the lead hardware inspector at the Ashburn site contracted a serious illness. No cleared backup existed for the identity-gate function. A scheduled substitution challenge went unwitnessed, the evidence chain broke, and the event was marked as unresolved.

The financial damage was equally severe. To fill gaps, the program paid premium rates for temporary contractors and expedited clearances, draining the $750M inspectorate envelope at a rate of $58M per month. The contingency envelope was tapped by day 45, and the Morale among the cleared inspectors collapsed as they were forced to work double shifts with no backup. The reciprocal parity metric failed because one side had 90% staffing and the other only 64%. The program did not die from a single technical failure; it suffocated under a staffing model that was never validated against the real clearance system.

##### Early Warning Signs
- Cleared FTE remains below 90% of the 450 requirement by 2027-07-31
- Security clearance lead time exceeds 15 months for any critical role
- Single-person critical functions identified in staffing tabletop exercises exceed five
- Inspectorate envelope burn rate exceeds $50M per month for three consecutive months before Phase One

##### Tripwires
- Cleared FTE < 90% by 2027-07-31
- Single-person critical functions > 5 in final tabletop validation
- Inspectorate envelope burn rate > $50M per month for 3 consecutive months

##### Response Playbook
- Contain: Stop the Phase One clock and prohibit any material-event verification until every critical function has a trained and cleared backup.
- Assess: Run an independent staffing and clearance audit within 14 days to quantify the gap, premium costs, and impact on reciprocal parity.
- Respond: Request a jointly agreed 3–6 month bridge extension funded from the contingency envelope and second cleared personnel from existing national verification bodies to close the gap.


**STOP RULE:** If cleared FTE remains below 90% after a 6-month bridge extension, or the inspectorate envelope exceeds its cap before Phase One completes, cancel the program.

---

#### FM7 - The Deadlock Machine

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Bilateral Governance and Legal Implementation Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase One opened with 100% certified entry conditions, but the governance machinery was never tested against a co-chair determined to stall. On Day 12, the Chinese co-chair disputed the materiality of a serial-number mismatch at an American site, arguing the term 'material discrepancy' in the bilingual glossary required evidence of operational impact. The U.S. co-chair disagreed, citing the pre-registered interpretive annex. The joint technical team had already documented the mismatch, but under the double-key rules, the finding could not be classified as material without co-chair approval.

The 10-business-day deadlock clock started. On Day 9, the Chinese co-chair requested a second advisory arbitration on the definition of 'material,' even though the glossary froze the term before the clock started. The jointly selected arbiter issued an advisory finding on Day 14, but the Chinese co-chair rejected it as non-binding. Meanwhile, the affected site was placed on technical hold, freezing all equipment movement. Operators lost confidence in the process and began filing their own interpretive disputes, exploiting the same ambiguity.

By Day 30, five material findings were deadlocked. The automatic suspension trigger for the original mismatch was never activated because the trigger was conditioned on a co-chair finding of materiality. The KPI dashboard showed 100% of automatic triggers 'pending materiality determination.' The 90-day clock was not consumed by detection failures; it was consumed by the process designed to prevent unilateral overrule. The financial impact was severe: the inconclusive verdict forced a Modify recommendation, but the two governments could not agree on what to modify, leaving the $5B program in a state of permanent limbo.

##### Early Warning Signs
- Any materiality dispute or deadlock remains unresolved after 10 business days
- More than two interpretive dispute pre-registrations are filed during the first 30 days of Phase One
- Automatic suspension triggers are recorded as 'pending materiality determination' for more than 5 consecutive business days
- Joint technical team findings are retroactively contested by either co-chair after initial acceptance

##### Tripwires
- Deadlock age > 10 business days for any material finding
- Automatic suspension trigger pending materiality > 5 business days
- Interpretive disputes filed > 2 in first 30 days of Phase One

##### Response Playbook
- Contain: Freeze the disputed site's equipment movement and preserve all evidence while escalating the deadlock to leadership.
- Assess: Convene the joint legal task force within 48 hours to issue an interpretation of the pre-registered glossary and determine whether the deadlock is genuine or manufactured.
- Respond: Activate the pre-registered arbitration and leadership escalation path; if automatic triggers remain blocked for more than 20 days, issue a Stop verdict for the affected site.


**STOP RULE:** If any co-chair blocks an automatic suspension trigger for more than 20 business days or any material finding remains deadlocked after leadership escalation, cancel Phase One and treat the regime as non-functional.

---

#### FM8 - The Silent Ledger

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Hardware Identity and Evidence Integrity Technical Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The ledger prototype had passed validation with 5,000 synthetic events, but the cross-border network path between the Ashburn and Langfang nodes degraded during Phase One's third week. A fiber cut caused a 4-hour network partition that the automated divergent-alert system failed to surface because the divergence threshold was set to 24 hours. During the partition, a red team staged an unreported arrival at a Guizhou site. The local node recorded the event in 3 minutes, but the change did not synchronize. When connectivity returned, an automated reconciliation process merged the records, and the divergent event was silently absorbed into the national copy without triggering a human review.

A month later, a routine audit compared the physical equipment at the Guizhou site against the ledger. The unreported arrival was found, but the ledger contained no record of the 4-hour partition because the divergence had been auto-reconciled. The event-recording latency metric showed 3 minutes, the sync metric showed 45 minutes, and the divergence reconciliation metric showed 10 hours—all within KPI tolerance. But the silent window during the partition remained unknown to the operators, providing a 4-hour concealment corridor exactly where the red team needed it.

The blind-challenge detection rate for unreported arrivals fell to 71%, below the 95% target. The verification team investigated and discovered that the auto-reconciliation algorithm had been calibrated to prefer local records during network partitions, creating a systematic bias. The ledger had not failed in a dramatic way; it had failed quietly, by masking the divergence it was designed to expose. The material-event latency budget was a fiction because the ledger's synchronization process could not distinguish 'healthy merging' from 'silent divergence.'

##### Early Warning Signs
- Ledger divergence alerts are automatically resolved without human review in more than 5% of events
- Network partition or connectivity loss events exceeding 30 minutes occur more than twice in a 7-day period
- Reconciliation logs show no divergence incidents while red-team challenges reveal hidden arrivals
- Blind-challenge detection rate for unreported arrivals falls below 90% for any week

##### Tripwires
- Divergence alerts auto-resolved > 5% of events
- Network partitions > 30 minutes occur > 2 times in 7 days
- Unreported-arrival detection rate < 90% for any week

##### Response Playbook
- Contain: Halt all ledger-based verification and require manual review of every divergence alert and reconciliation until the auto-merge algorithm is quarantined.
- Assess: Conduct a forensic analysis of all reconciliation logs and network events to quantify the duration and impact of silent windows during the partition.
- Respond: Re-version the reconciliation algorithm to require human sign-off on any merge involving a detected divergence and run fault-injection drills to verify the fix.


**STOP RULE:** If forensic analysis reveals any undetected silent window exceeding the 4-hour operator-reporting threshold, or if unreported-arrival detection remains below 90% after corrective action, issue a Stop verdict.

---

#### FM9 - The Paper Parity

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Datacenter Site Preparation and Cross-Border Logistics Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The parity matrix was approved in April 2027 after two workshops, but the data were largely drawn from operator self-assessments. The Langfang site was rated 'easy access' with a 451-person equivalent inspection burden, while its matched pair in Northern Virginia was rated 'medium difficulty' due to its sprawling campus. The calibration committee accepted the ratings because the alternative was reopening the site-selection negotiation. Live benchmarking drills were scheduled for May but were postponed twice due to 'scheduling conflicts' at the American site.

When the drills finally ran in June, the results were stark. The U.S. team at the Langfang site completed its inspection cycle in 22 hours, while the Chinese team at the Ashburn site needed 41 hours. The access-hours ratio was 0.54, far outside the 0.9–1.1 tolerance. The difficulty was not caused by deliberate obstruction; the Ashburn facility had a security checkpoint, a 15-minute escort rotation, and a clean-room entry procedure that consumed 6 hours. The Langfang site had a single access corridor and pre-staged evidence tables. The parity matrix had weighted equipment value and operational role but not physical layout or vendor ecology, which turned out to be the dominant drivers.

The asymmetric-access Stop condition should have triggered automatically. Instead, the U.S. co-chair argued that the ratio was a random artifact of an unrepresentative drill and proposed a re-run with adjusted procedures. The Chinese co-chair, equally invested in protecting the Langfang site from scrutiny, agreed to quietly postpone the formal determination. Benchmarks were repeated four times with different inspectors and different scenarios, but the ratio never exceeded 0.72. The public KPI dashboard reported 'reciprocal access in progress,' and the verdict process became a diplomatic exercise in explaining why the numbers did not mean what they meant.

##### Early Warning Signs
- Access-hours ratio for any matched pair falls below 0.9 or above 1.1 in any benchmarking drill
- Drill completion time differs by more than 50% between matched sites
- More than three benchmarking re-runs are requested for the same matched pair
- Site survey data are based on operator self-assessment without independent physical verification

##### Tripwires
- Access-hours ratio < 0.9 or > 1.1 in any benchmark drill
- Drill time difference > 50% between matched sites
- Benchmark re-runs > 3 for same pair

##### Response Playbook
- Contain: Suspend all reciprocal access benchmarking and declare a parity investigation for the affected matched pairs.
- Assess: Conduct independent physical surveys of all six sites to recalculate parity based on actual layout, security processes, and vendor constraints within 21 days.
- Respond: Renegotiate the matched-site set or adjust the tolerance band only after the independent survey, then re-run benchmarking drills before resuming Phase One.


**STOP RULE:** If independent surveys confirm that any matched pair cannot achieve an access-hours ratio within the 0.9–1.1 band after renegotiation, cancel Phase One and require a new site-selection process.


# Self Audit

Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 11 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 7 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a bilateral governmental verification and inspection program for datacenter equipment, built from institutional agreements, physical inspections, cryptographic ledgers, and standard operational logistics. Its success criteria depend on human and technical systems that are fully consistent with known physics, and it nowhere requires violation of conservation laws, causality, or other physical principles.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a never-attempted combination—US-China bilateral verification of frontier-AI datacenter hardware via a novel two-sovereign verification architecture with tamper-evident ledgers, information barriers, and double-key governance—and the materials concede 'There is no direct U.S.-China bilateral on-site verification precedent, so this recommendation set triangulates across the closest real-world families of projects.' Nuclear-domain analogues (INF, JVE, IAEA) cover components, not the whole system, and the only backing is the internal claim that 'the pre-project assessment confirms the technical approach is buildable with no inherent contradictions,' so a false Go/Stop verdict would be existential for the $5B regime's credibility.

**Mitigation**: Joint Secretariat with co-chairs: run parallel validation tracks (legal/compliance, ledger/latency, information-barrier detection, vendor/continuity) each producing one authoritative source or supervised pilot vs baseline; enforce NO-GO gates for empirical validity and legal clearance, rejecting domain-mismatched PoCs. Deliverable: dual-gate certification memo, within 12 months.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because lever one-pagers exist yet strategy-driving concepts remain undefined: "The plan names materiality as a Stop trigger without defining it," and "the Consortium has not articulated a single flagship use-case," leaving the verdict and $5B rationale without agreed meaning.

**Mitigation**: Joint Co-Chairs and Joint Secretariat: Publish two one-pagers within 90 days — materiality thresholds with decision hooks and a crisis-stability value hypothesis with success metrics — for double-key approval before certification.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit controls for critical second-order risks like political discontinuity, unvalidated KPI thresholds, and undefined managed-access protocols. For example, 'The plan assumes current leaders' commitment is durable, but a U.S. administration change... could halt the program.' Additionally, 'KPI thresholds are provisional/TBD until validated by exercises,' and 'The verification access architecture is not an access architecture; it is an information-protection wish list.' These gaps create existential failure modes if not addressed.

**Mitigation**: Bilateral Governance and Legal Implementation Lead: Draft and validate a Protocol on Access and Managed Access with pre-agreed denial-resolution procedures, materiality definitions, and KPI validation plan within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix with jurisdictional lead-time allocations, yet entry-condition certification and the 12-month clock depend on domestic access-authority legislation, export/import licenses, customs pre-authorization, and environmental/grid permits. The plan only commits to "Apply for all export, import, customs, visa, environmental, construction, and grid-connection authorizations in parallel," without mapping predecessors or comparing scheduled versus typical approval durations.

**Mitigation**: Joint Secretariat with program schedulers: Rebuild the critical path within 60 days, adding a permit/approval matrix with authoritative jurisdiction lead times, dated predecessors, and a NO-GO threshold on any slip.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because funding uncommitted: US/China $2.5B each are assumptions ('pre-fund full USD 2.5 billion into a jointly signatory escrow'); no term sheets, draw/covenants undefined, 15-month runway exposed.

**Mitigation**: Fiscal Escrow and Independent Audit Controller: Within 90 days, publish a financing plan listing US/China $2.5B sources/status, draw schedule, covenants, and NO-GO on any missed financing gate.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's budget lacks vendor quotes, per-area cost normalization, or contingency tied to estimates; it only states allocations like "$1.25B ledger... $1B site preparation" without any cost-per-m²/ft² benchmarks for the six sites, making cost realism unsubstantiated.

**Mitigation**: Datacenter Site Preparation and Cross-Border Logistics Manager: Obtain ≥3 per-area benchmarks and vendor quotes for fit-out/opex, normalize to cost per m²/ft² across six sites, and adjust envelopes or de-scope within 120 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because key projections ('targeted for completion by 2027-Sep-04', 'approximately 450 FTE') lack ranges, yet 'provisional/TBD until validated by exercises' thresholds and the '$500M contingency/surge' envelope provide partial coverage.

**Mitigation**: Joint Secretariat / Program Integration Lead: Deliver a best/worst/base-case scenario and sensitivity analysis for the certification-to-verdict timeline, quantifying clearance, legislative, vendor, and site-selection drivers, within 90 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan promises validation of the 'replicated tamper-evident ledger prototype…through independent testing' yet lacks specs, interface contracts, acceptance tests, and an integration plan for core components.

**Mitigation**: Hardware Identity and Evidence Integrity Technical Lead: Produce technical specs, interface contracts, acceptance-test plans, and an integration map with owners/dates for ledger, barriers, staging, and registry within 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because 'Sign the bilateral instrument' and pre-fund contributions 'into a jointly signatory escrow' are asserted, yet no signed instrument, enacted access law, escrow confirmation, or declared-site artifact exists.

**Mitigation**: Joint Legal Task Force: Deliver a certification evidence pack—signed bilateral instrument, enacted domestic access authority, executed escrow confirmation, and declared matched-site list—or formally rescope entry conditions within 180 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the final deliverable—the Go/Modify/Stop verdict—has no verifiable acceptance qualities: the plan names materiality as a Stop trigger 'without defining it' and thresholds are 'provisional/TBD until validated by exercises.'

**Mitigation**: Joint Co-Chairs with independent statistician: Define SMART acceptance criteria for the Go/Modify/Stop verdict, including a materiality KPI (over 2 unverifiable units per site triggers suspension) and validated false-negative rate, within 90 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the killer-application narrative — 'a joint unclassified briefing and demonstration package framing Phase One as a crisis-stability tool' — adds USD 2-5 million of strategic-communications cost and acknowledged scope-creep complexity without directly supporting the core goals of verifying material equipment changes at six matched sites and issuing a defensible Go/Modify/Stop verdict. Partial coverage exists since the plan bounds it ('must not expand the legal scope beyond declared-equipment change verification') and ties it to political continuity, but no benefit case or KPI demonstrates its necessity for Phase One outcomes.

**Mitigation**: Strategic Communications Leads reporting to the co-chairs: Produce a one-page Benefit Case Review for the killer-application narrative, including a KPI, owner, and estimated cost, within 90 days; otherwise move the narrative to the project backlog.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the unicorn role is the Hardware Identity and Evidence Integrity Technical Lead: it uniquely couples hardware assurance, cryptographic attestation, replicated-ledger engineering, and treaty-verification protocol fluency. The plan says this role must be staffed by 'cleared, permanent personnel,' yet no talent-market evidence exists, and staffing feasibility flags 'bilingual technical talent scarcity,' making the role essential and likely unfillable.

**Mitigation**: Joint Secretariat with both national leads: commission a talent-market survey for Hardware Identity and Evidence Integrity Technical Leads, mapping candidate pools, clearance timelines, and compensation, and issue a go/no-go staffing-readiness report within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because counsel and costed validation exist—'formal legal opinions from both governments on all mandatory legal entry conditions'—yet ratification, access-legislation, export/customs/permit lead times lack mapping.

**Mitigation**: Joint Legal Task Force: Within 60 days, deliver a regulatory matrix (authority, artifact, lead time, predecessors) covering treaty ratification, access legislation, export/customs/visa, and site permits, with NO-GO triggers on adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM: funding sustainability is unresolved—'the $5B covers only Phase One' and 'Long-term funding model for Phase Two is undefined'—but maintenance and scalability gaps are addressable with planning.

**Mitigation**: Joint Secretariat and Fiscal Escrow Controller: Draft an Operational Sustainability Plan within 60 days covering post-Phase One funding strategy, maintenance and technology-roadmap schedule, succession planning, scalability triggers, and adaptation mechanisms.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies permit and grid requirements but lacks written confirmations, a fatal-flaw screen, or NO-GO thresholds tied to zoning, egress, fire load, structural, and noise constraints. Constraints remain uncertain.

**Mitigation**: Joint Legal Task Force with local permitting authorities: Perform a fatal-flaw screen for zoning, occupancy/egress, fire load, structural, noise, and permits at all six sites; obtain written confirmation or define fallbacks and NO-GO thresholds within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM: the plan has 'two fallback sites per country,' replicated ledger copies, and a forced-evidence ladder, but a dominant vendor refusal 'can cascade across every site it serves' and facility failover remains pre-qualified rather than tested.

**Mitigation**: Operator and Vendor Compliance Liaison with Site Preparation Manager: sign secondary-vendor and fallback-site agreements, then run live failover drills (vendor refusal, grid outage, node loss) at one matched pair within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Finance seeks 'fiscal leverage' via milestone tranches while Operations needs pre-funded escrow; the milestone fallback risks making 'the KPI dashboard itself the object of negotiation.'

**Mitigation**: Joint Co-Chairs and Fiscal Escrow Controller: Draft a joint OKR within 90 days linking envelope release to mutually certified readiness and verification milestones and quarterly reconciliation, aligning both incentives.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan defines KPI thresholds ('divergence reconciliation within 24 hours'), monthly cadence ('Run monthly integrated readiness reviews'), named owners, and change control via suspension triggers, stop rules.

**Mitigation**: Joint Secretariat: Stand up a monthly KPI-dashboard review with a lightweight change board for threshold-triggered re-plan/stop decisions; log outcomes in versioned readiness records within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because 'a single dominant vendor refusing cooperation can cascade across every site it serves' and risks are 'mutually reinforcing,' yet no cross-impact/FTA map or heatmap with NO-GO thresholds.

**Mitigation**: Joint Risk Integration Office: Build interdependency map with bow-tie/FTA and combined heatmap, assigning owners and NO-GO/contingency thresholds for vendor-refusal, barrier, funding, and deadlock cascades within 90 days.

# Initial Prompt Vetted

## Initial Prompt

```text
Plan:
"The Consortium", a jointly governed United States–China mechanism with one narrowly defined mission: verify material arrivals, installations, removals, transfers, maintenance changes, and decommissioning of frontier-relevant computing equipment at a small, matched set of declared datacenters.

Assume both countries’ leaders believe uncontrolled frontier AI threatens national security and their continued political control. They provide direct political backing and sufficient domestic authority to compel participation. Do not assume trust, legal symmetry, or willingness to expose sensitive technology.

Phase One is a 90-day operational test, but its clock begins only after both governments have signed the bilateral instrument, appropriated their contributions, enacted domestic access authority, selected participating sites, approved inspectors, secured necessary operator and vendor participation, and adopted the provisional covered-equipment schedule. Treat these as mandatory entry conditions, not work performed during the 90 days.

Budget is USD 5 billion, contributed exactly 50/50: USD 2.5 billion from each country. Use this provisional allocation: USD 1.25 billion for secure ledger, attestation, evidence and communications systems; USD 1 billion for participating-site preparation and operator compensation; USD 750 million for inspectors, technical personnel, training and translation; USD 750 million for secure facilities, cybersecurity and counterintelligence; USD 500 million for independent testing, challenge exercises and red teams; USD 250 million for bilateral legal implementation and independent auditing; and USD 500 million for contingency and surge capacity. Every expense must map to an envelope. Compensation to domestic operators and vendors is administered by their own government and charged against its contribution.

"The Consortium" is a sovereign public-sector national-security program, not a for-profit project, business, nonprofit corporation, investment, partnership opportunity, or revenue-generating institution. If the report format requires business purpose, pitches, investors, customers, revenue, sponsorship, fundraising, return on investment, market demand, profitability, or promotional calls to action, mark them “Not applicable” and substitute mission justification, public value, strategic necessity, appropriations governance, and fiscal accountability.

Address only declared-equipment change verification at participating sites. Do not estimate either country’s total computing capacity, verify workloads, inspect model weights, prove the absence of hidden facilities, cover foreign-hosted infrastructure, or create a comprehensive AI-governance regime. Do not permanently anchor covered equipment to a current manufacturer, product, architecture, or performance unit. Accountable specialists must maintain a confidential, versioned technical schedule.

Governance must use equal national co-chairs and double-key authorization for budgets, protocol changes, site findings, sanctions and suspension. No chair may have a casting vote, and no majority procedure may allow one country to overrule the other. Define deadlock, impaired-confidence and automatic-suspension procedures. Do not use a generic Project Sponsor, investor board, sponsorship coordinator or public stakeholder-satisfaction process.

Model staffing from participating-site count, shift coverage, mirrored national teams, separation of duties, leave coverage and surge requirements. This is not a small project team. Do not use single-person critical functions, part-time or temporary-agency inspectors, or fictional employee biographies. Include full-time mirrored inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics and adjudication units.

Create a replicated, tamper-evident ledger with independently verifiable national copies, immediate local event recording and bounded counterpart synchronization. Establish an Intake Protocol that verifies equipment identity in controlled staging areas before installation. Use layered evidence, potentially including independently validated cryptographic attestation, physical inspection, shipment and customs records, equipment identifiers, maintenance records, infrastructure changes and witnessed movement. No single source is decisive.

Protect workloads, customer data, model weights, network topology, security architecture, source code and unrelated infrastructure through bounded inspection zones and filtered evidence. Require operators to bind manufacturers, maintenance providers and logistics companies to reporting, confidentiality, escort and evidence-preservation requirements. When a critical vendor refuses, use vendor-supervised testing, filtered evidence, accredited independent examiners, secure clean-room procedures or validated attestations. If these cannot produce sufficient evidence, classify the equipment as unverifiable; if material, the site fails Phase One.

Define an Exit Protocol assigning every departure a disposition: witnessed destruction, verified permanent disablement, transfer to another participating site, documented release beyond the monitored system, or unresolved disposition. Never imply continued knowledge beyond the agreed boundary.

Run live exercises involving unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal and a reluctant operator. Conduct tests in staging, spare-inventory, maintenance or expansion areas without interrupting active computational work.

Organize the work breakdown around these top-level workstreams: bilateral authority and reciprocity gate; site eligibility and matched selection; inspectorate deployment and information barriers; intake and identity verification; ledger recording and synchronization; installation, maintenance and third-party access; exit and disposition verification; live challenge exercises; discrepancy adjudication and suspension; and the final decision. Do not substitute generic project-initiation, stakeholder-engagement, requirements-gathering or project-closure phases.

The KPI dashboard must cover blind-challenge detection by event type, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP or cybersecurity incidents, production disruption, funding timeliness and audit exceptions. Justify thresholds. Mark unsupported figures provisional or TBD and specify how they will be validated.

Conclude **Go** only if exercises demonstrate reciprocal access and credible detection; **Modify** if correctable weaknesses remain; and **Stop** if access is asymmetric, material equipment remains unverifiable, a government shields an operator, evidence systems diverge without resolution, or either country withholds funding. State that success covers only monitored changes at participating declared sites.

Banned words: blockchain.

Today's date:
2026-Sep-04

Project start ASAP
```

## Prompt Screening

**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a highly concrete, actionable project with explicit scope, budget allocation, timeline, governance rules, workstreams, staffing model, and success criteria, providing ample detail to generate a multi-step plan. Although the scenario is hypothetical, it is fully plannable and executed within real-world constraints.

## Redline Gate

**Verdict:** 🟢 ALLOW

**Rationale:** The prompt is safe

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |

## Premise Attack

Why this fails.

### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise is self-defeating: a joint US–China mechanism whose mission excludes undeclared facilities, hidden capacity, and total compute cannot reduce frontier-AI national-security risk, because a state actor with political control over its territory will simply shift frontier compute outside the small matched set of declared datacenters and then cite the consortium's clean ledger as proof that the problem is being managed.**

**Bottom Line:** REJECT: The consortium is a $5B mechanism for certifying declared showcases while explicitly excluding the hidden capacity that defines frontier-AI risk; it cannot generate a strategically meaningful finding, and the first real adversarial test will reveal that its double-key governance is designed to produce deadlock, not verification.


#### Reasons for Rejection

- The mission's refusal to estimate total computing capacity, prove the absence of hidden facilities, or cover foreign-hosted infrastructure means the consortium will verify only the two countries' showcased datacenters while the actual frontier-compute build can proceed unmonitored in undeclared sites, making any 'clean ledger' a clean bill for the wrong inventory.
- Because participating sites are a 'small, matched set' negotiated by adversaries, each side will select facilities that are most inspectable and least strategically critical, so the resulting dataset measures inspection symmetry, not frontier-AI risk, and the KPI 'reciprocal-access parity' rewards an even exchange of irrelevant access.
- The double-key authorization with no casting vote means every material finding—an unreported arrival, a vendor refusal, a disputed disposition—can be vetoed by the accused country's co-chair, so the consortium's 'unresolved discrepancy age' will grow during the first real crisis and its suspension procedures become a mutual threat to collapse rather than an enforcement mechanism.
- The Exit Protocol's 'documented release beyond the monitored system' creates a bright-line boundary with no verification after release, allowing a supposedly retired or transferred unit to reappear in an undeclared cluster without ever registering on the ledger; the mechanism's own disposition category is a legally sanctioned leakage channel.
- The 90-day operational test cannot begin until both sides have signed, appropriated, enacted access authority, selected sites, approved inspectors, bound operators and vendors, and adopted the equipment schedule—each an event requiring supermajority political consensus in countries actively competing on AI—so the clock will not start until the compute landscape has already moved, and the USD 5 billion will be spent mostly on preparations for a test that verifies yesterday's machines.

#### Second-Order Effects

- 0–6 months: Both governments tout the consortium as proof they are managing frontier AI while the mandatory entry conditions remain unmet; the first appropriations and site-selection processes consume political capital, and each side accelerates undisclosed compute expansion in advance of any inspection obligations.
- 1–3 years: The first real discrepancy—an unreported arrival or a blocked vendor access—provokes a double-key veto and a mutual suspension; the ledger's 'unresolved disposition' count rises, and both capitals use the breakdown as justification for further export controls, industrial subsidies, and prohibitions on sharing AI infrastructure.
- 5–10 years: Frontier compute migrates to undeclared domestic sites and foreign-hosted infrastructure, which the consortium's mission explicitly excludes, turning the declared-site ledger into an obsolete artifact while the verified 'clean' datacenters serve as diplomatic cover for an unconstrained global compute buildout.

#### Evidence

- Case/Incident — UNSCOM (1991–1998): Iraq's experience shows that even intrusive on-site inspections of declared and suspect sites can be obstructed and deceived by a state with hierarchical control, undermining confidence in site-level verification.
- Case/Incident — Bletchley Park AI Safety Summit (2023): signatories to the Bletchley Declaration publicly agreed on frontier-AI dangers while simultaneously advancing national AI strategies, demonstrating that shared high-level concern does not produce enforceable bilateral constraint.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Mutual Targeting Trap: A jointly governed verification regime does not verify; it gives each state the other's most detailed inventory of advanced computing infrastructure, converting transparency into a precisely mapped espionage and sabotage targeting system.**

**Bottom Line:** REJECT: The Consortium is a $5 billion mutual surveillance pact that converts the highest-value computing infrastructure into a produce-your-target-list exercise; no budget, governance design, or exit protocol can turn a bilateral espionage channel into a trust mechanism.


#### Reasons for Rejection

- Operators and vendors are coerced by their own governments into exposing proprietary network architecture, shipment chains, and maintenance records to foreign nationals, with no free consent from the data-center customers whose workloads sit on that hardware.
- The double-key governance design—two national co-chairs and veto-level reciprocity—guarantees that any adverse finding can be blocked by the accused state, turning the consortium into a diplomatic shield for cheating rather than an accountability mechanism.
- Once the Consortium's verified inventory of equipment identities, facility layouts, and vendor relationships is built, a single leak or national security breaching of the ledger would give the other side a ready-made targeting set for cyberattacks and kinetic strikes—harm that cannot be undone by any exit protocol.
- The stated budget and governance theater suggest that the real product is not verification but mutual cover: each government buys 'reciprocal access' while continuing to build unverified capacity outside the declared sites, so the $5 billion underwrites a pretense rather than a control.

#### Second-Order Effects

- **T+0–6 months — The Cracks Appear:** The mandatory entry conditions—enacting domestic access authority, signing operator and vendor undertakings, standing up mirrored national teams—take so long that the 90-day Phase One clock cannot start, because neither state is willing to expose its relevant supply chain first.
- **T+1–3 years — Copycats Arrive:** The false confidence of the first 'Go' is replicated by other adversarial dyads—India–Pakistan, the Korean Peninsula, and Japan–China—each adopting a 'verification consortium' that in practice becomes a lawful channel for foreign intelligence collection.
- **T+5–10 years — Norms Degrade:** Inspectors and vendors are recruited by the other side, ledger entries become trading commodities, and the 'unverifiable equipment' category expands until the regime is a fixed exceptionalism: every disputed item is classified as unverifiable and quietly forgotten.
- **T+10+ years — The Reckoning:** One government breaks the arrangement during a crisis and uses the collected inventory to disable the other's declared data centers, exposing the 'confidence-building measure' as the central vulnerability it always was.

#### Evidence

- Law/Standard — The Open Skies Treaty (1992, in force 2002): reciprocal overflights of rival territories were politically sustainable only while the United States and Russia saw them as stabilizing; the U.S. withdrawal in 2020 and Russian withdrawal in 2021 underscore that intrusive transparency between adversaries collapses when strategic trust erodes.
- Case/Report — The 2015 U.S.–China Joint Statement on Cyber Issues: an official bilateral commitment to refrain from state-sponsored cybereconomic theft; within a year both governments exchanged accusations of noncompliance, and the document faded without institutional follow-through, showing that leadership endorsement does not bind state-linked actors.
- Case/Report — The U.S. Department of Commerce Entity List, as repeatedly updated with Chinese supercomputing and AI entities, functions by denying controlled equipment to named parties; a bilateral verification regime would instead require handing the Chinese government a confirmed inventory of the exact U.S. equipment and facilities the controls are designed to protect.
- Narrative — Front-Page Test: A leaked Consortium audit of the American side would be front-page news as 'Beijing now knows the exact location and supply history of every advanced U.S. data center participating in the deal'—making the transparency program itself the biggest national-security scandal of its decade.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The premise assumes two hostile intelligence adversaries can co-govern verification of their most sensitive compute infrastructure while explicitly denying trust, guaranteeing deadlock, espionage, and false assurance.**

**Bottom Line:** REJECT: A US-China verification mechanism that forbids trust, cannot enforce consensus, and ignores undeclared sites is an espionage scaffold and false-confidence theater, not a national-security instrument.


#### Reasons for Rejection

- The double-key authorization and equal national co-chairs mean every suspension, sanction, or protocol change requires consent from the very government accused, so the enforcement valve is welded shut by design.
- The prompt forbids assuming trust, legal symmetry, or willingness to expose sensitive technology, yet reciprocal inspection of declared datacenters cannot function without those assumptions, making the mechanism a hallucination before Phase One begins.
- The 90-day test clock cannot start until both governments sign, appropriate, enact access authority, select sites, approve inspectors, and adopt schedules—a chain of indefinite preconditions that lets either side stall forever while the USD 5 billion budget burns in political limbo.
- Confining the mission to a small, matched set of declared datacenters while explicitly refusing to prove the absence of hidden facilities means each side certifies only what it chose to disclose, turning the output into laundered status reports rather than a strategic-security guarantee.
- The USD 750 million counterintelligence envelope is tasked with defending against the same partner that co-governs the inspectorate, but effective defense would require barring that partner from sensitive rooms—an act that defeats the premise and reveals the budget as a teaspoon in a flood.

#### Second-Order Effects

- 0–6 months: While entry conditions remain uncompleted, each side will use site selection and schedule negotiations to mine the other's datacenter operations for intelligence, and China will wave the bilateral instrument as cover for accelerating undeclared AI compute acquisition.
- 1–3 years: The first disputed equipment movement will hit the double-key veto, automatic suspension will fire, and the USD 5 billion apparatus will become a permanent blame-casting forum while both governments escalate unilateral export controls and tech decoupling.
- 5–10 years: The consortium will have hardened rival AI supply chains into hostile blocs, handed China a target list of U.S. frontier sites, and generated neither restraint nor transparency—only a better-documented and more dangerous arms race.

#### Evidence

- Case/Incident — U.S. Department of Justice Huawei Indictment (2020): China's flagship technology vendor was charged with stealing U.S. trade secrets, illustrating why a US-China joint inspectorate would be a standing intelligence-harvesting invitation.
- Law/Standard — U.S. Export Administration Regulations Entity List (Huawei, 2019): The United States formally designated Chinese technology entities as a national-security threat, making co-equal Chinese oversight of U.S. frontier compute self-inflicted exposure.
- Treaty/Agreement — New START (2010): The only successful adversarial verification regime needed years of negotiation, exact legal symmetry, and fixed strategic launchers, offering no precedent for a 90-day datacenter inspection pact between mutual intelligence adversaries.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This premise is strategically self-defeating: it asks two existential rivals to give permanent, privileged physical access to the exact infrastructure that defines their national power, while explicitly disclaiming the only measures that could make such access meaningful—total capacity estimation, hidden-facility detection, and workload verification. The result can only be a Potemkin verification theater or an espionage channel, never a security mechanism.**

**Bottom Line:** Abandon this premise entirely: it is not a verification mechanism but a bilateral vulnerability-swapping agreement with deadlock built in, and its success criteria are logically impossible to satisfy without either an intelligence catastrophe or a diplomatic fiction. The flaw is not in the budget, staffing, or KPIs—it is in the unstated assumption that adversarial superpowers can safely verify what they deliberately refuse to define.


#### Reasons for Rejection

- The Sovereign Black-Box Blindness Catch: Both governments must 'not assume willingness to expose sensitive technology,' yet the entire scheme requires exposing enough supply-chain, identity, and infrastructure detail to verify equipment changes. Any filtered evidence sufficient to protect secrets is insufficient to detect substitution; any evidence sufficient to detect substitution is an intelligence windfall.
- Double-Key Deadlock Engine: Equal co-chairs, no casting vote, and no override guarantee that every significant finding—especially a suspected violation—will be vetoed. The consortium is designed never to reach a hard conclusion, making the 'Stop' criteria technically impossible to trigger without bilateral suicide.
- Declared-Site Maginot Trap: By limiting verification to a matched set of declared datacenters and refusing to estimate total capacity or hidden facilities, the plan creates the illusion of arms control while competitors simply move frontier computing to undeclared domestic sites, foreign-hosted infrastructure, or next-generation architectures not on the provisional schedule.
- Precondition Perpetuum Mobile: The 90-day test clock requires prior resolution of every politically impossible question—access authority, vendor participation, site selection, inspector approval—meaning billions can be spent on 'preparation' for years while the actual operational test never starts, and no one is accountable for the failure.
- Mutual Legitimacy Laundering: The premise explicitly frames frontier AI as a threat to 'continued political control,' inviting both governments to use the consortium as cover for domestic surveillance, censorship, and export controls, while giving each side a permanent institutional platform to blame the other for any AI-related unrest.

#### Second-Order Effects

- Within 6–12 months: The mandatory entry conditions telescope indefinitely; each side's domestic legal process is used to delay site selection while accusing the other of bad faith, and the first budget tranches are consumed by 'site preparation' for sites that are never approved.
- Within 1–2 years: If inspections ever begin, the first disputed GPU shipment or 'unverifiable' equipment block triggers automatic suspension; both co-chairs use their double-key power to blame each other publicly, making the consortium a geopolitical escalatory tool rather than a stabilizer.
- Within 2–3 years: Each side's intelligence services have exploited the inspection pipeline—vendor reporting, logistics records, escort requirements, and red-team exercises—to map the other's frontier-computing supply chain, creating a permanent privileged access channel for sabotage and data exfiltration.
- Within 3–5 years: The KPI dashboard shows perfectly synchronized ledgers and zero unresolved discrepancies, because any genuine discrepancy is either hidden by 'bounded zones,' classified 'unverifiable,' or silently dropped by veto; the consortium becomes a model of compliant theater while both nations build overwhelmingly larger undeclared compute capacity.
- Within 5–10 years: The inevitable collapse or irrelevance of the consortium is cited by both sides as proof of the other's deception, accelerating an unconstrained frontier-AI arms race that is far more dangerous than the status quo the plan pretended to fix.

#### Evidence

- The U.S.–Soviet strategic arms control experience: even with countable launchers, verifiable warhead limits, and national technical means, the ABM Treaty still collapsed amid mutual accusations of 'ambiguous activities' and 'noncompliance.' This plan proposes to verify fungible, rapidly evolving compute equipment with no mutually agreed counting rule, no total capacity estimate, and no hidden-site detection—an impossibly lower baseline of verifiability.
- The Iraq weapons inspections (1991–2003): intrusive, declared-site inspections by credentialed professionals produced false confidence, were manipulated by the inspected regime, and were later used retroactively as a casus belli. A bilateral version between two sovereign equals, with no higher authority and double-key vetoes, would be even more vulnerable to manipulation.
- The JCPOA Parchin access dispute: the mere requirement of 'managed access' to a sensitive military site allowed years of delay, sanitization, and negotiation over what inspectors could see. Here, every participating site is itself a Parchin—the host government will always control the 'bounded inspection zones' and 'filtered evidence.'
- Stuxnet/Operation Olympic Games: modern great-power competition treats physical access to an adversary's industrial infrastructure as a military opportunity. Establishing a standing bilateral inspectorate with escorts, vendor access, and maintenance records hands both sides a permanent operational platform for cyber-physical warfare, not merely a verification tool.
- New START's breakout concerns: even the most successful on-site inspection regime acknowledges that a determined party can break out by mobilizing hidden capacity. This plan has no breakout-detection mechanism by design—it refuses to look for hidden facilities—making 'verified confidence' an exercise in officially sanctioned ignorance.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Potemkin Checkpoint: a regime that can only see what two adversaries volunteer to expose will certify a curated fiction while the actual frontier flows through every door it was built to ignore.**

**Bottom Line:** REJECT: A checkpoint that inspects only what rivals volunteer is not verification but its counterfeit — this consortium would spend five billion dollars certifying a curated fiction while handing both governments a green dashboard to cite as proof that nothing beyond the fence needs watching. The premise deserves no passage; the gate is closed.


#### Reasons for Rejection

- Dignity and rights: the plan conscripts private datacenter operators, manufacturers, and logistics firms into a bilateral surveillance apparatus — compelling them to host foreign counterintelligence personnel from a state that practices transnational repression and to surrender evidence layers under escort — treating civilian infrastructure and the people who run it as staging props for great-power stagecraft.
- Accountability and oversight: equal co-chairs with double-key authorization and no casting vote mean the mechanism is structurally incapable of rendering an adverse finding against either party, and its own 'unverifiable equipment' clause is a pre-negotiated escape hatch — a consortium that can only certify consensus, never compliance, is an oversight organ in name only.
- Systemic risk and scale: with workloads, model weights, hidden facilities, foreign-hosted infrastructure, and total capacity all carved out, the verified surface is a rounding error of the actual threat, and certifying it manufactures strategic false assurance — leaders who already believe compute control is existential will read a green dashboard as disarmament while diffusion accelerates everywhere outside the fence line.
- Value-proposition rot: the premise smuggles in the hubris that a protocol can substitute for the trust it explicitly disclaims — five billion dollars to build a mutual-incrimination organ between rivals, with each government administering compensation to its own sites and both sides rationally positioned to weaponize the suspension machinery the moment the first real discrepancy surfaces.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: entry conditions stall in two legislatures while the first live exercises churn out 'unverifiable' classifications at precisely the sites that matter, so both governments quietly select showcase decoys for the matched set to make the KPIs go green.
- T+1–3 years — Copycats Arrive: other rival dyads imitate 'declared-site verification' as the template for AI governance, spawning a global class of Potemkin inspectorates that legitimize the form of arms control while gutting its substance, and appropriations flow to inspection theater instead of to the ungoverned diffusion actually underway.
- T+5–10 years — Norms Degrade: 'Consortium-certified' becomes a diplomatic marketing label detached from any physical reality, the confidential covered-equipment schedule falls permanently behind the hardware frontier, and a single planted or disputed ledger event converts the automatic-suspension procedures into a choreographed escalation script between nuclear-armed rivals.
- T+10+ years — The Reckoning: a genuine frontier catastrophe emerges from infrastructure that always sat outside the certified perimeter, and the decade of green dashboards and 'Go' decisions becomes the definitive exhibit of institutionalized self-deception — the regime did not prevent the disaster, it supplied the alibi.

#### Evidence

- Law/Standard — the Treaty on the Non-Proliferation of Nuclear Weapons with IAEA comprehensive safeguards (INFCIRC/153): the most institutionalized verification law on earth, whose authority stopped at declared facilities and therefore missed Iraq's clandestine program — a failure that forced the 1997 Additional Protocol (INFCIRC/540) precisely because declared-site verification certifies only what states volunteer.
- Case/Report — the INF Treaty (1987–2019): history's most intrusive, symmetric, and well-funded bilateral inspection regime, with on-site portal monitoring and short-notice inspections between far more aligned states, still collapsed in 2019 amid mutual non-compliance accusations — the documented terminus of every 'both sides will keep funding their own exposure' bargain.
- Principle/Analogue — Measurement Theory and Arms Control: Goodhart's Law holds that when a measure becomes a target it ceases to be a measure, and this plan's KPI dashboard — blind-challenge detection rates, false negatives, reciprocal-access parity — is a published target that both parties' incentivized staffs will optimize by design, not fail to game by accident.
- Narrative — Front-Page Test: front page, 2029: 'Consortium Declares All Monitored Sites Fully Compliant' runs directly beneath 'Intelligence Agencies Assess Third Undeclared 100,000-GPU Cluster' — and every official who spent five billion dollars on the green dashboard insists the second story proves why the first was necessary.

# Prompt Adherence

**Overall Adherence: 88%**

```
IMPORTANCE_ADHERENCE_SUM = (5×4 + 5×5 + 5×5 + 5×5 + 3×5 + 5×4 + 4×5 + 5×5 + 4×5 + 5×5 + 4×5 + 4×3 + 4×2 + 5×3 + 5×5) = 300
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 3 + 5 + 4 + 5 + 4 + 5 + 4 + 4 + 4 + 5 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 300 / 340 = 88%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Both countries back sovereign not-for-profit program; no trust/symmetry/exposure. | Stated fact | 5/5 | 4/5 | Partially honored |
| 2 | 90-day Phase One; clock starts only after mandatory entry conditions completed. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Budget $5B exact 50/50; specified envelopes; all expenses mapped; operator comp by own gov. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Verify only declared-equipment changes; exclude capacity/workloads/weights/hidden/foreign/governance. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | No permanent anchor to current specs; maintain confidential versioned technical schedule. | Requirement | 3/5 | 5/5 | Fully honored |
| 6 | Equal co-chairs/double-key; no casting vote/override; define deadlock/suspension. | Requirement | 5/5 | 4/5 | Partially honored |
| 7 | Staffing: mirrored full-time units by site count; no single-person critical/temp/fictional. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | Replicated tamper-evident ledger, national copies, local recording, bounded sync; no single source. | Requirement | 5/5 | 5/5 | Fully honored |
| 9 | Intake Protocol verifies identity in staging; layered evidence. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Bounded zones/filtered evidence; bind vendors; refusal fallbacks; material unverifiable fails. | Requirement | 5/5 | 5/5 | Fully honored |
| 11 | Exit Protocol assigns every departure disposition; never imply continued knowledge beyond boundary. | Requirement | 4/5 | 5/5 | Fully honored |
| 12 | Exercises: unreported arrival/substitution/bad records/delayed access/disputed identity/refusals. | Requirement | 4/5 | 3/5 | Partially honored |
| 13 | Specified top-level workstreams; no generic sponsor/stakeholder/initiation/closure phases. | Requirement | 4/5 | 2/5 | Partially honored |
| 14 | KPI with listed metrics, justified thresholds/provisional TBD; Go/Modify/Stop criteria. | Requirement | 5/5 | 3/5 | Partially honored |
| 15 | Banned word: blockchain. | Banned | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 13 - Specified top-level workstreams; no generic sponsor/stakeholder/initiation/closure phases.

- **Category:** Partially honored
- **Adherence:** 2/5
- **Importance:** 4/5
- **Evidence:** Dependencies: Sign the bilateral instrument ... Select and jointly declare the matched set of six participating datacenter sites...
- **Explanation:** The plan contains dependencies and deliverables touching on many required workstreams, but it does not organize a work breakdown around the ten specified top-level workstreams. It substitutes generic project-management sections such as SMART Criteria, Dependencies, and Stakeholder Analysis.

### Issue 14 - KPI with listed metrics, justified thresholds/provisional TBD; Go/Modify/Stop criteria.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 5/5
- **Evidence:** KPI dashboard ... covering blind-challenge detection, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence...
- **Explanation:** Most required KPIs are present and thresholds are marked provisional/TBD with a validation plan. However, 'production disruption' and detection-by-event-type are not explicit in the KPI list, and the Go/Modify/Stop criteria are not fully specified as a decision matrix, with no explicit 'government shields an operator' Stop trigger.

### Issue 12 - Exercises: unreported arrival/substitution/bad records/delayed access/disputed identity/refusals.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** run six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal)
- **Explanation:** Most required live-exercise scenarios are included, but the user's list also named a reluctant operator as a distinct exercise. The plan reduces this to six types and addresses operator reluctance only in the risk register and mitigations, not as an explicit mandatory challenge.

### Issue 1 - Both countries back sovereign not-for-profit program; no trust/symmetry/exposure.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** This is a sovereign public-sector national-security program; business purpose, investors, customers, revenue, fundraising, sponsorship, profitability, and return on investment are not applicable.
- **Explanation:** The plan mostly honors the non-commercial sovereign framing and states no trust, legal symmetry, or sensitive-technology exposure is assumed. However, consolidate_assumptions_full.md opens with 'Purpose: business' instead of marking that field 'Not applicable,' so the instruction is not perfectly followed.

### Issue 6 - Equal co-chairs/double-key; no casting vote/override; define deadlock/suspension.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Sign the bilateral instrument establishing equal national co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock and automatic-suspension procedures.
- **Explanation:** Equal co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock machinery, and automatic suspension are present. However, the plan does not explicitly define a distinct 'impaired-confidence' procedure, addressing it only indirectly through continuity and withdrawal comments.

