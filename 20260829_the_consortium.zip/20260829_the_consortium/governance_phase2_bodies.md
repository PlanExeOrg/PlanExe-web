### 1. Joint Steering Council (JSC)

**Rationale for Inclusion:** The program is a bilateral sovereign verification regime operating without mutual trust and with an explicit no-unilateral-overrule rule. A strategic oversight body is required to exercise equal double-key authority over the final Go/Modify/Stop decision, material findings, sanctions, suspension, protocol changes, and budget thresholds, and to manage political deadlock and impaired confidence without a casting vote.

**Responsibilities:**

- Provide strategic direction and approve the overall Phase One plan and final Go/Modify/Stop verdict.
- Exercise double-key authorization for all material site findings, sanctions, suspensions, protocol changes, and revisions to materiality or KPI thresholds.
- Approve and certify all mandatory entry conditions, including the bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection, inspector rosters, and covered-equipment schedule before the 90-day clock starts.
- Set strategic risk appetite and review the consolidated risk register, approving responses to strategic, political, and fiscal risks.
- Approve any expenditure above USD 10 million, any cross-envelope transfer, any contingency drawdown, and any change to approved budget envelopes.
- Own the deadlock, impaired-confidence, and automatic-suspension procedures; escalate unresolved political deadlocks to heads of state/party leadership.
- Receive and decide escalations from the Joint Program Management Office and all assurance bodies.

**Initial Setup Actions:**

- Adopt the JSC charter, decision rules, and deadlock protocol before the clock starts.
- Confirm the two equal national co-chairs and appoint the non-voting secretariat.
- Approve the strategic risk appetite and initial KPI thresholds recommended by the technical and audit bodies.
- Establish the entry-condition certification package and integrated readiness tracker reporting requirements.
- Set the meeting cadence and sign-off matrix for double-key decisions.

**Membership:**

- US National Co-Chair (senior official designated by the US government)
- China National Co-Chair (senior official designated by the Chinese government)
- JSC Secretary (non-voting)

**Decision Rights:** All strategic decisions: certification of entry conditions and Phase One clock; final Go/Modify/Stop verdict; material findings; sanctions; suspension; protocol amendments; KPI/materiality threshold changes; covered-equipment schedule approvals requiring double-key; expenditures above USD 10 million; any cross-envelope transfer; any contingency drawdown; any change to approved budget envelopes; and appointment of the neutral arbiter and independent assurance members.

**Decision Mechanism:** Double-key affirmative approval by both co-chairs. There is no casting vote and no majority vote. If consensus fails, the deadlock procedure applies: the item is deferred for up to 10 business days while joint technical/legal bodies seek a recommendation; if still unresolved, the matter is escalated to heads of state/party leadership. For a site with an unresolved material discrepancy, automatic suspension of verification activities at that site remains in effect until the deadlock is resolved. A co-chair may declare impaired confidence, triggering an extraordinary JSC session and, if unresolved, protective suspension scoped to the affected activity.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during the 90-day Phase One; extraordinary sessions within 48 hours upon request of either co-chair, a material incident, or a declared impaired-confidence condition.

**Typical Agenda Items:**

- Entry-condition readiness tracker and joint certification status
- Strategic risk register review and risk appetite decisions
- Budget envelope and drawdown approvals, including contingency requests
- KPI dashboard and audit exception summaries
- Material findings, vendor-refusal escalations, and suspension recommendations
- Deadlock, impaired-confidence, and automatic-suspension reviews
- Preparation of the joint Go/Modify/Stop verdict and shared findings narrative

**Escalation Path:** To the heads of state/party leadership of both countries as the senior authorizing principals for unresolved political deadlocks, entry-condition slippage beyond the 12-month target, withdrawal risk, or any matter requiring political authority above the co-chairs.
### 2. Joint Program Management Office (JPMO)

**Rationale for Inclusion:** The program's operational complexity with six matched sites, mirrored national teams, seven budget envelopes, a 90-day clock, and live challenge exercises cannot be managed by the strategic body. A dedicated operational management body is needed to execute the readiness phase and Phase One within delegated thresholds while preserving double-key authority at the strategic level for material decisions.

**Responsibilities:**

- Manage day-to-day execution of all workstreams: bilateral authority, site selection, inspectorate deployment, intake, ledger, maintenance, exit, exercises, adjudication support, and final decision.
- Maintain the integrated readiness tracker and operational schedule, including entry-condition closure and Phase One clock certification support.
- Allocate and control expenditures within approved budget envelopes up to USD 10 million per action and up to USD 25 million per envelope reallocation per quarter, with no cross-envelope transfers.
- Own the operational risk register; identify, assess, and mitigate operational risks and escalate strategic risks to the JSC.
- Manage staffing, shift coverage, leave backup, surge deployment, and separation-of-duties compliance for all mirrored units.
- Coordinate site access, inspection windows, vendor interactions, and event response within the agreed latency budget.
- Prepare decision packages and evidence summaries for the JSC, JTAB, JAECC, and JDAP.

**Initial Setup Actions:**

- Stand up the joint secretariat and appoint the two co-deputy directors and workstream leads.
- Implement the integrated readiness tracker and envelope-level budget control system.
- Validate the staffing model against the six-site workload formula and initiate clearances and training.
- Establish daily stand-up and weekly reporting cadence with all workstream leads.
- Draft operational thresholds, escalation templates, and delegated authority registers for JSC approval.

**Membership:**

- US Deputy Program Director
- China Deputy Program Director
- Joint Secretariat Lead
- Workstream leads for inspectorate, ledger, site preparation, testing/exercises, legal support, security/counterintelligence, and logistics
- Chief Risk Officer (operational risk)
- Chief of Staff / Readiness Tracker Owner
- No member of the JSC serves on the JPMO; JPMO members are full-time operational staff.

**Decision Rights:** Operational decisions within the approved plan and budget: day-to-day scheduling, staffing assignments, site access, event response, non-material discrepancy handling, procurement and contracting up to USD 10 million per action, within-envelope reallocation up to USD 25 million per quarter, and implementation of approved technical and security procedures. No authority to change protocol, KPI/materiality thresholds, site findings, sanctions, suspension, or budget envelopes; no contingency drawdown authority.

**Decision Mechanism:** Co-deputy consensus. Decisions within a workstream lead's delegated authority are made by that lead; cross-cutting decisions require both co-deputy directors' concurrence. If the co-deputies cannot agree, the matter is deferred for no more than 48 hours and then escalated to the JSC. There is no casting vote and no single-country override.

**Meeting Cadence:** Daily operational stand-up; weekly full JPMO coordination meeting; ad hoc incident-response sessions as needed.

**Typical Agenda Items:**

- Event queue, inspection windows, and latency metrics against the 4-hour/24-hour/1-hour budget
- Staffing coverage, leave, surge deployment, and separation-of-duties compliance
- Integrated readiness tracker status and entry-condition closing actions
- Budget envelope burn rates and procurement pipeline
- Vendor and operator participation issues and access delays
- Incident reports and operational risk register updates
- Escalation packages prepared for the JSC and assurance bodies

**Escalation Path:** Escalates to the JSC for expenditures above USD 10 million, cross-envelope or contingency matters, protocol changes, material discrepancy classifications, potential suspension or sanction, co-deputy deadlock, or realization of a strategic risk. Technical implementation issues may be referred to the JTAB; compliance concerns to the JAECC; discrepancies to the JDAP.
### 3. Joint Technical Assurance Board (JTAB)

**Rationale for Inclusion:** The mission depends on novel technical judgments: layered evidence, no-single-source decisiveness, information barriers, KPI thresholds, and unbiased blind challenges. A specialized technical assurance body with independent expertise is needed to set and validate technical standards, protect evidence credibility, and advise strategic and operational decision-makers without being captured by operational pressures.

**Responsibilities:**

- Define and maintain the layered evidence hierarchy, equipment-identity confidence standards, and no-single-source-decisive rules.
- Validate all KPI thresholds for false negatives, latency, divergence, discrepancy age, and unverifiable equipment before the clock starts and after challenge exercises.
- Design, select, and oversee independent red teams and the six mandatory unannounced challenge types, ensuring no advance knowledge and independent reporting.
- Approve and version information-barrier filter rules, clean-room protocols, and filtered workstation configurations within the JSC-approved policy framework.
- Assess vendor-refusal technical fallback options and recommend unverifiable classifications.
- Review the confidential, attribute-based covered-equipment schedule versioning and provide technical advice to the JSC on double-key schedule approvals.
- Monitor technical risks and recommend adjustments to technical procedures and thresholds.

**Initial Setup Actions:**

- Adopt the JTAB terms of reference and confirm the three independent external experts jointly appointed by the two governments.
- Finalize the evidence hierarchy, filter rules, and clean-room protocols for JSC approval.
- Publish the KPI threshold validation plan and provisional thresholds.
- Select independent red team providers and establish no-advance-knowledge reporting channels.
- Create the technical risk register and integrate it with the JPMO risk register.

**Membership:**

- US Principal Technical Advisor
- China Principal Technical Advisor
- US Chief Information Barrier Engineer
- China Chief Information Barrier Engineer
- Head of Independent Red Team / Testing (external, jointly appointed)
- Three independent external experts in hardware assurance, treaty verification, and information security (jointly appointed, full voting members on technical recommendations)
- Technical schedule custodians (non-voting, attendance as needed)

**Decision Rights:** Advisory and delegated technical authority. Recommends to the JSC: evidence hierarchy, KPI thresholds, information-barrier policy, covered-equipment schedule changes requiring double-key approval, and materiality definitions. Has delegated authority to approve technical implementation details within the JSC-approved framework, including filter-rule versions, test vectors, red-team engagement terms, and clean-room procedures.

**Decision Mechanism:** Consensus-seeking among national technical leads and independent external experts. A recommendation requires no objection from either national lead and support from at least two of the three independent experts. If the national leads disagree, the issue is documented with both technical opinions and the independent experts' assessment and escalated to the JSC. No casting vote; no majority procedure may allow one country to overrule the other.

**Meeting Cadence:** Biweekly during the entry-condition phase; weekly during Phase One; additionally within 72 hours after every challenge exercise or material technical incident.

**Typical Agenda Items:**

- Blind-challenge results by event type, false-negative and false-positive rates
- Evidence-weighting and equipment-identity confidence reviews
- Information-barrier filter logs and impact on substitution detection
- KPI threshold validation and confidence intervals
- Vendor-refusal technical options and unverifiable-equipment recommendations
- Technical schedule versioning and coverage-gap assessments
- Technical risk register and mitigation effectiveness

**Escalation Path:** Escalates to the JSC for any proposed change to evidence hierarchy, KPI thresholds, materiality definitions, information-barrier policy, or covered-equipment schedule requiring double-key approval; escalates to the JPMO for technical implementation defects or operations-level corrections.
### 4. Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Rationale for Inclusion:** The program faces high-impact security and counterintelligence risks: protection of sensitive technology, insider threats, evidence integrity, and cyber compromise. A dedicated security assurance body is necessary to oversee physical and cybersecurity, counterintelligence, information barrier implementation, and incident response without conflating these issues with technical verification or financial compliance.

**Responsibilities:**

- Oversee physical security, cybersecurity, and counterintelligence for all Consortium facilities, personnel, and evidence systems.
- Implement and audit information-barrier and separation-of-duties controls to protect workloads, model weights, source code, network topology, and security architecture.
- Monitor insider-threat indicators and manage clearance and access-control processes for all personnel.
- Own the joint incident-response protocol for IP, cyber, and counterintelligence incidents; direct isolation measures pending JSC review.
- Validate the security of the replicated ledger, filtered workstations, clean rooms, and secure facilities through independent penetration testing and security red-team exercises.
- Maintain the security risk register and report security risks to the JSC and JPMO.
- Ensure counterintelligence monitoring does not compromise the no-unilateral-overrule governance principle.

**Initial Setup Actions:**

- Approve the JSCIB charter and appoint the two national security leads and independent security experts.
- Conduct a baseline security and counterintelligence risk assessment for all six sites and secure facilities.
- Approve the information-barrier implementation plan and separation-of-duties matrix.
- Select independent penetration-testing firms and schedule pre-clock security testing.
- Drill the joint cyber-incident isolation protocol twice before Phase One.

**Membership:**

- US Security and Counterintelligence Director
- China Security and Counterintelligence Director
- US Cybersecurity Lead
- China Cybersecurity Lead
- Two independent security experts jointly appointed by both governments (full advisory members)
- Counterintelligence analysts from each national team (non-voting, attendance as needed)

**Decision Rights:** Security assurance authority within the JSC-approved policy: approve security procedures, access-control changes, and incident-isolation measures; direct preservation of evidence during an incident; and recommend to the JSC any security-driven suspension or change to information-barrier policy. Cannot unilaterally suspend the program, issue sanctions, or change verification protocols.

**Decision Mechanism:** Consensus between the two national security leads for decisions. Independent security experts provide assessments and may formally flag a security risk to the JSC if they believe either lead is underreacting. If the two leads disagree, the issue escalates to the JSC within 48 hours. No casting vote and no single-country override.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during Phase One; immediately upon any security incident or threshold alert.

**Typical Agenda Items:**

- Security risk posture and threat updates for all declared sites
- Cyber-incident and insider-threat monitoring reports
- Information-barrier filter and access-control audit results
- Penetration-test findings and remediation status
- Physical security and secure-facility compliance
- Incident-response drills and isolation protocol readiness
- Security inputs to the KPI dashboard and JSC risk reviews

**Escalation Path:** Escalates to the JSC for confirmed IP or cyber incidents compromising evidence integrity, insider threat or counterintelligence breach, security-driven suspension recommendations, disagreement between national security leads, or any proposed change to information-barrier policy requiring strategic approval.
### 5. Joint Legal and Terminology Commission (JLTC)

**Rationale for Inclusion:** The bilateral instrument must be supported by a binding bilingual glossary, pre-registered interpretive readings, domestic access legislation, model vendor-access agreements, and an inspector visa and customs annex. Legal and linguistic ambiguity can become an access-denial tool or a deferred deadlock. A specialized legal commission is required to pre-commit both governments to shared meanings and implementable legal frameworks before the clock starts.

**Responsibilities:**

- Draft and maintain the binding bilingual glossary and interpretive annex for contested terms such as material, removal, frontier-relevant, and declared site.
- Coordinate the domestic access-authority legislation and regulatory implementation in both countries.
- Negotiate and maintain model vendor-access agreements, operator site-eligibility conditions, and inspector-access, visa, and customs annexes.
- Pre-register each government's interpretive positions and maintain a versioned changelog of legal interpretations.
- Advise the JSC, JPMO, and JDAP on legal and regulatory risks, export controls, customs, privacy, and data-protection law.
- Support the JAECC in compliance oversight by providing authoritative legal interpretations.

**Initial Setup Actions:**

- Convene the joint terminology commission with mirrored legal and technical linguists.
- Draft the binding bilingual glossary with worked examples and submit it to the JSC for double-key approval.
- Prepare model vendor-access agreements and inspector-access annexes for signing before clock start.
- Provide legal drafting support for domestic access authority in both countries.
- Create the pre-registered interpretive annex and versioned legal changelog.

**Membership:**

- US Legal Co-Lead
- China Legal Co-Lead
- US Technical Linguist / Glossary Lead
- China Technical Linguist / Glossary Lead
- US Export-Control and Customs Legal Specialist
- China Export-Control and Customs Legal Specialist
- Independent international-law expert jointly appointed by both governments (advisory member)
- Representatives of the JPMO legal workstream and JAECC (non-voting, attendance as needed)

**Decision Rights:** Drafting and legal-recommendation authority only. It certifies the bilingual glossary and interpretive annex for JSC double-key approval, prepares legal instruments, and issues legal opinions on interpretive disputes. It has no authority to approve program expenditures, sanctions, suspension, or verification findings.

**Decision Mechanism:** Consensus between the two legal co-leads on recommendations and certifications. If they disagree, the issue is resolved by reference to the pre-registered interpretive annex; if still unresolved, it is escalated to the JSC for double-key decision. The independent international-law expert issues an advisory opinion but has no veto. No casting vote.

**Meeting Cadence:** Weekly during the entry-condition phase; as needed during Phase One for interpretive disputes or legal incidents; immediately upon a domestic legal challenge.

**Typical Agenda Items:**

- Bilingual glossary and interpretive annex review
- Domestic access-authority implementation status
- Model vendor-access and inspector-access agreement updates
- Visa, customs, and export-control clearance tracking
- Interpretive dispute resolutions and deferred-deadlock review
- Legal risk register updates and regulatory developments
- Support to JAECC on compliance and data-protection law

**Escalation Path:** Escalates to the JSC for unresolved interpretive disputes, proposed changes to the bilingual glossary or annexes, domestic legal challenges threatening inspector access, or any legal issue requiring double-key approval. Operational access issues are escalated to the JPMO.
### 6. Joint Audit, Ethics, and Compliance Committee (JAECC)

**Rationale for Inclusion:** The program handles USD 5 billion in sovereign funds, highly sensitive information, and operators and vendors with incentives to corrupt or misreport. A dedicated, externally led assurance body is required to provide independent audit, ethics, anti-corruption, data-protection and GDPR, and regulatory compliance oversight, and to validate the KPI dashboard so the Go/Modify/Stop verdict is based on trustworthy data.

**Responsibilities:**

- Provide comprehensive compliance oversight for financial integrity, anti-corruption, conflicts of interest, GDPR and analogous data-protection laws, ethical standards, export controls, customs, and classified-information handling.
- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns, including domestic compensation disbursements.
- Validate KPI dashboard inputs against raw exercise logs and evidence records before any Go/Modify/Stop decision and on a spot-check basis during Phase One.
- Operate a secure whistleblower channel with non-retaliation protections and independent review.
- Audit compliance with information-barrier, counterintelligence, and evidence-handling requirements.
- Report material compliance findings, suspected fraud, and audit exceptions directly to the JSC and, where required, to public transparency channels.
- Recommend protective holds to the JSC for suspected material fraud or evidence compromise; it cannot independently suspend the program.

**Initial Setup Actions:**

- Appoint the independent chair, two additional independent external members, and the national compliance officers.
- Adopt the audit charter, whistleblower policy, and conflict-of-interest rules.
- Conduct a baseline compliance and ethics risk assessment for all budget envelopes and compensation flows.
- Define the KPI validation audit plan and raw-data access protocols.
- Establish the quarterly audit calendar and semi-annual compensation audit schedule.

**Membership:**

- Independent Chair, external and jointly appointed by both governments
- Two independent external members with expertise in government auditing, data protection and GDPR, and ethics and compliance, jointly appointed
- US National Compliance Officer (non-voting observer with right to record dissent)
- China National Compliance Officer (non-voting observer with right to record dissent)
- Internal audit leads from each national audit unit (non-voting, attendance as needed)

**Decision Rights:** Authoritative audit and compliance findings: compel access to records, evidence, personnel, and systems within its mandate; issue audit exceptions and compliance recommendations; require the JPMO to preserve evidence and restrict access to records during a fraud or compliance investigation; and recommend protective holds, sanctions, or suspension to the JSC. No final program, budget, protocol, sanction, or suspension authority.

**Decision Mechanism:** Findings and recommendations are decided by majority vote of the three independent external members. National compliance officers have no veto but may append dissenting views to any finding. If the independent members cannot reach a decision, the matter is escalated to the JSC with all positions recorded. The independent chair has no casting vote beyond her or his regular vote.

**Meeting Cadence:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours upon an audit exception, whistleblower complaint, data-protection breach, or suspected fraud.

**Typical Agenda Items:**

- Audit exceptions and envelope-level expenditure findings
- Domestic operator and vendor compensation audit results
- KPI dashboard validation and raw-data provenance checks
- Data protection and GDPR compliance incidents
- Ethics, conflicts of interest, and corruption-risk indicators
- Whistleblower channel status and complaint resolutions
- Compliance risk register and regulatory developments

**Escalation Path:** Escalates to the JSC for material fraud, corruption, compliance breach, KPI misreporting, data-protection breach, unresolved audit exception, or any recommended protective hold or suspension.
### 7. Joint Discrepancy Adjudication Panel (JDAP)

**Rationale for Inclusion:** The regime's credibility depends on converting raw inspection findings into agreed materiality classifications and, when necessary, suspension recommendations without unilateral overrule. A dedicated adjudication body is needed to apply pre-agreed evidentiary rules, track unresolved discrepancy age, operate the automatic-suspension threshold, and refer only material disputes to the strategic level.

**Responsibilities:**

- Receive and adjudicate all discrepancies from inspectors, the JPMO, and challenge exercises.
- Apply the pre-agreed evidence hierarchy, materiality definitions, and KPI thresholds to classify discrepancies as routine, material, or unresolved.
- Resolve routine discrepancies under delegated evidentiary rules and issue joint findings for non-material discrepancies.
- Recommend material findings, sanctions, and suspension to the JSC for double-key authorization.
- Track unresolved discrepancy age and trigger automatic site-level suspension processes when thresholds are met.
- Refer deadlocked factual disputes to the jointly selected neutral technical arbiter for advisory findings.
- Maintain the discrepancy log and feed the KPI dashboard and verdict construction.

**Initial Setup Actions:**

- Adopt the adjudication charter and standard operating procedures.
- Appoint the two national adjudication officers and the neutral technical arbiter.
- Adopt the materiality definitions and threshold triggers pre-approved by the JSC.
- Establish the discrepancy-tracking dashboard and age metrics.
- Conduct training for inspectors and workstream leads on evidence submission and materiality rules.

**Membership:**

- US Senior Adjudication Officer
- China Senior Adjudication Officer
- US Legal Adviser to the Panel
- China Legal Adviser to the Panel
- US Senior Technical Adviser
- China Senior Technical Adviser
- Neutral Technical Arbiter, external and jointly selected, with advisory vote on deadlocked facts
- JDAP Secretariat (non-voting)

**Decision Rights:** Delegated authority to resolve non-material discrepancies and classify materiality under JSC-approved definitions. Can recommend material findings, sanctions, and suspension to the JSC. Can place a temporary administrative hold on affected equipment movement or site activity when automatic-suspension thresholds are met, pending JSC double-key confirmation within 48 hours. Cannot issue final sanctions, change protocol, or make final suspension decisions.

**Decision Mechanism:** The two national adjudication officers must concur on materiality classifications and findings. Routine discrepancies are resolved by joint technical teams under pre-agreed evidentiary rules. If the adjudication officers disagree on a factual issue, the neutral technical arbiter provides an advisory finding; if the officers still do not concur, the matter escalates to the JSC. No casting vote. Deadlock persisting beyond 10 business days is recorded as unresolved and escalates, with automatic site-level suspension applying if the discrepancy is material.

**Meeting Cadence:** Daily during Phase One, or as needed after each inspection event or challenge; immediately when a material discrepancy or suspension trigger occurs.

**Typical Agenda Items:**

- New discrepancy intake and evidence package review
- Materiality classification decisions and joint findings
- Unresolved discrepancy age and automatic-suspension thresholds
- Vendor-refusal and operator-obstruction adjudications
- Neutral arbiter referrals and advisory findings
- Recommendations for JSC sanctions or suspension
- Discrepancy trend inputs to the KPI dashboard and verdict construction

**Escalation Path:** Escalates to the JSC for material findings, sanctions, suspension, unresolved factual disputes after the arbiter process, deadlock beyond 10 business days, or any discrepancy meeting the Stop threshold.