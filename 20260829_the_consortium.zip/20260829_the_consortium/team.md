*Roles Needed & Example People*

# Roles

## 1. Bilateral Governance and Legal Implementation Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Needed for sustained bilateral legal drafting, entry-condition certification, and ongoing double-key governance through the full entry-condition and Phase One period. The program requires full-time, cleared, mirrored legal and terminology units; contractor or temporary staffing would create single-person or continuity risks.

**Explanation**:
Provides the sovereign-pair legal architecture: drafting the bilateral instrument, double-key/deadlock/automatic-suspension procedures, binding bilingual glossary, domestic access authority, model vendor-access agreements, and inspector visa/customs annex. Also runs entry-condition certification and negotiates continuity commitments so the regime survives leadership transitions.

**Consequences**:
Without this role there is no bilateral instrument, no domestic access authority, no deadlock machinery, and no pre-registered interpretive glossary. A single co-chair could block findings indefinitely, operators and vendors could refuse participation, and visa/customs delays would break the 24-hour physical-confirmation latency budget. The program could not legally start.

**People Count**:
min 12, max 24 — 8 core attorneys (4 per country) plus treaty-verification advisors, technical linguists, and implementing-legislation specialists. More than one per side is required because drafting, glossary negotiation, and vendor-access agreements must run in parallel before the 12-month entry-condition deadline, and no critical legal function may be single-person.

**Typical Activities**:
Negotiate and maintain the bilateral instrument; pre-register deadlock procedures and automatic-suspension thresholds; manage the joint terminology commission; draft domestic access-authority notes; bind operators and vendors via model agreements; negotiate the inspector visa and customs annex; support entry-condition certification; and provide ongoing legal advice for double-key authorization, sanctions, and suspension decisions.

**Background Story**:
Dr. Eleanor Hartley-Voss, a treaty lawyer based in Arlington, Virginia, earned a J.D. from Georgetown University Law Center and a Ph.D. in international relations from Oxford, then spent 22 years in the U.S. State Department's Bureau of Arms Control, Verification and Compliance, where she drafted New START inspection protocols, served on the U.S. delegation to the Bilateral Consultative Commission, and advised on the OPCW Confidentiality Annex. She is a skilled public international lawyer and negotiator with deep experience in double-key governance, immunities, and interpretive dispute resolution, and she has spent the last two years leading the U.S. legal task force for the Consortium, personally drafting the bilingual glossary, deadlock machinery, and model vendor-access annex. Her relevance to the program is that she is the principal architect of the bilateral legal architecture that makes the 90-day Phase One clock legally possible, and she knows where every governance failure mode will surface.

**Equipment Needs**:
Secure encrypted drafting and document-management systems; versioned legal repositories; bilingual terminology database for glossary maintenance; secure videoconferencing with interpretation; case/deadlock tracking software; KPI dashboard access for entry-condition certification.

**Facility Needs**:
Mirrored legal offices in the Washington, DC area and Beijing with SCIF/secure-compartmented spaces; joint negotiation and terminology-commission conference rooms; secure records vaults; dedicated interpretation booths for bilateral drafting sessions.

## 2. Mirrored Inspectorate Operations Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Requires full-time operational command of 24/7 mirrored inspection coverage, separation of duties, leave backup, and surge deployment. The project explicitly forbids part-time, temporary-agency, or single-person critical functions in the inspectorate.

**Explanation**:
Leads the full-time mirrored inspectorate and technical workforce, ensuring 24/7 coverage at six declared sites, separation of duties, leave backup, no single-person critical functions, and a permanent surge cadre. Directs intake staging, physical witnessing of installations/removals, maintenance monitoring, and exit-disposition verification under dual-national observation.

**Consequences**:
Without operational command, coverage gaps, single-person critical functions, asymmetric national capacity, and uncoordinated evidence collection would invalidate material events. The regime could not meet its reciprocal-access parity requirement and would likely trigger a Stop condition before exercises are complete.

**People Count**:
min 14, max 24 — 2 senior operational directors (one per national side), 6 site team leads, plus shift/surge commanders and adjudication coordinators. The full inspectorate is approximately 450 FTE, but this role covers the command, scheduling, and separation-of-duties layer; multiple leaders are essential for reciprocal mirroring and simultaneous site coverage.

**Typical Activities**:
Command the mirrored inspectorate; build site-level shift rosters with leave backup and surge deployment; supervise intake staging and physical witnessing; coordinate dual-national teams for installations, removals, maintenance monitoring, and exit dispositions; enforce separation of duties; investigate access delays; and report operational readiness and parity metrics to the co-chairs.

**Background Story**:
Colonel Marcus 'Cole' Anders, based in Ashburn, Virginia, is a former U.S. Air Force nuclear-missile maintenance officer with a B.S. in nuclear engineering from Rensselaer and an M.S. in operations research from the Air Force Institute of Technology, who spent 18 years leading DOE/NNSA inspection teams under New START and participating in CTBTO on-site inspection exercises, including as an operations chief for a multinational field exercise in Jordan. He has deep expertise in 24/7 shift operations, separation of duties, dual-national team leadership, evidence chain of custody, and contingency deployment, and he has already run the Consortium's mirrored inspection staffing model through two tabletop exercises. His relevance is that he knows how to turn the six-site, 450-person inspectorate plan into a functioning operational command that can perform physical witnessing and maintain reciprocal access parity without single-person critical functions.

**Equipment Needs**:
24/7 shift-roster and staffing management system; operational command-and-control voice/data communications; evidence collection kits including serialization scanners, tamper-evident seals, chain-of-custody forms, and encrypted cameras; GPS/vehicle tracking for escorted movements; PPE and safety equipment; surge deployment equipment.

**Facility Needs**:
National mirrored inspectorate operations centers; on-site command posts at all six declared datacenters; staging-area control rooms; briefing/debriefing rooms; secure evidence storage; logistics/transport coordination hub with vehicle fleet space.

## 3. Hardware Identity and Evidence Integrity Technical Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Continuous responsibility for the replicated ledger, baseline registry, identity verification, and divergence reconciliation demands full-time availability and long-term accountability. Each national node must be independently staffed by cleared, permanent personnel.

**Explanation**:
Owns the replicated tamper-evident ledger, cryptographic asset registry, baseline inventory reconciliation, equipment-identity verification, intake identity gates, and exit-disposition records. Ensures local event recording within 5 minutes, cross-national synchronization within 1 hour, divergence reconciliation within 24 hours, and layered evidence where no single source is decisive.

**Consequences**:
Without this role there is no trusted baseline inventory, no bounded synchronization, and no robust equipment-identity verification. Ledger divergence would go unresolved, material changes could remain silent, and the false-negative threshold would be exceeded by construction, poisoning any Go decision.

**People Count**:
min 22, max 42 — 2 mirrored technical leads (one per national copy) plus a full-time engineering team for prototype build, independent penetration testing, and operations. Multiple people are required because each national node must be independently built, tested, and operated, and ledger divergence is a designated Stop condition that cannot depend on one person.

**Typical Activities**:
Own the replicated tamper-evident ledger and cryptographic asset registry; complete and reconcile the joint baseline inventory; operate intake identity gates; validate equipment attestation and serialization; monitor synchronization and divergence alerts; run reconciliation drills; define evidence-class weighting; and maintain equipment-identity confidence metrics.

**Background Story**:
Dr. Yuxin 'Luna' Tan, a hardware assurance engineer based in Haidian District, Beijing, earned a Ph.D. in computer engineering from Tsinghua University, studied trusted execution environments at ETH Zurich, and spent 12 years building hardware inventory and attestation systems for hyperscale datacenters and, earlier, for IAEA safeguards remote-monitoring deployments that verified sealed nuclear material using tamper-evident identifiers and authenticated data chains. She is an expert in cryptographic hash chains, equipment serialization, root-of-trust attestation, and reconciliation of physical inventories with maintenance and disposal records, and she led the Consortium's prototype ledger team that demonstrated 5-minute local recording and 1-hour synchronization on 1,000 synthetic events. Her relevance is that she is the technical owner of the 'no single source is decisive' layered-evidence architecture and the baseline inventory certification that every subsequent verification depends on.

**Equipment Needs**:
Replicated tamper-evident ledger server nodes with hardware security modules for each national copy; local-first event recording and synchronization/divergence alerting systems; cryptographic asset registry and baseline inventory database; serialization and identity verification devices including asset tags, RFID/QR readers, and scanners; attestation validation and power-analysis test rigs; secure backup and recovery storage.

**Facility Needs**:
Hardware-secured data-center space for the two national ledger nodes; equipment identity verification laboratory; intake-staging identity gate infrastructure at each site; secure network operations center; controlled clean-room work area for hardware examination.

## 4. Information Barrier and Counterintelligence Security Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Needs ongoing 24/7 security monitoring, counterintelligence operations, and incident response across multiple sites. Full-time status supports need-to-know compartmentation, hardware-separated teams, and the required permanent security presence.

**Explanation**:
Designs and validates filtered workstations, bounded inspection zones, clean-room examination protocols, need-to-know compartments, and hardware-separated national teams. Runs continuous counterintelligence monitoring and drills the joint cyber-incident isolation protocol so evidence integrity is preserved without exposing workloads, model weights, source code, or security architecture.

**Consequences**:
Without this role, over-filtering could hide substitution evidence and under-filtering could leak sovereign technology. A single evidence-integrity compromise would trigger automatic suspension and could collapse political support for the entire $5B program.

**People Count**:
min 60, max 100+ — 2 mirrored security directors plus cybersecurity engineers, counterintelligence officers, and incident-response staff funded from the $750M facilities/cyber/counterintelligence envelope. 24/7 monitoring, physical/logical separation of national teams, and simultaneous incident response require more than a small team.

**Typical Activities**:
Design and validate filtered evidence and clean-room procedures; set zone boundaries by event type; enforce need-to-know compartments for the covered-equipment schedule; run hardware-separated national evidence systems; conduct continuous counterintelligence monitoring; execute joint cyber-incident isolation drills; and report IP/cyber incidents and evidence-integrity holds.

**Background Story**:
Alexandra 'Alex' Novak, a counterintelligence and information-protection director based in Columbia, Maryland, holds a B.S. in electrical engineering from Virginia Tech, served 20 years in U.S. intelligence and counterintelligence roles, and later worked with national laboratories on information-barrier prototypes that allowed inspectors to verify classified attributes without revealing design data. She has designed filtered workstations, bounded inspection zones, clean-room examination protocols, need-to-know compartments, and continuous insider-threat monitoring, and she authored the Consortium's information-barrier rulebook before running it through a blind challenge that confirmed substitution indicators survive filtering. Her relevance is that she owns the trade-off between verification sensitivity and protection of workloads, model weights, source code, and network topology, and she knows how to contain a cyber or evidence-integrity incident without halting verification at unaffected sites.

**Equipment Needs**:
Filtered workstations configured to strip protected data while preserving identity metadata; hardware-separated evidence systems; network intrusion detection and prevention, continuous monitoring, and audit-logging tools; encryption key management; access-control and badge systems; counterintelligence and insider-threat monitoring software; incident-response toolkits.

**Facility Needs**:
SCIFs and secure compartmented information facilities in both countries; 24/7 security and counterintelligence operations centers; clean-room examination facilities; physical security infrastructure at declared sites including bounded inspection zones and hardened access control; incident-isolation response lab.

## 5. Independent Red Team and Challenge Exercise Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Red-team independence is achieved through operational separation and no advance knowledge of exercises, not through contractor status. Full-time employment is required for sustained challenge design, surge exercises, and credible KPI validation across the 90-day test.

**Explanation**:
Designs and runs the six mandatory unannounced blind challenges: unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator. Validates KPI thresholds, calculates false-negative and false-positive rates with confidence intervals, and supplies the detection evidence that justifies the Go/Modify/Stop verdict.

**Consequences**:
Without this role, detection claims are unproven, KPI thresholds remain unvalidated, and exercises risk becoming scripted or announced. A Go verdict would rest on false confidence, while a genuinely undetected substitution would undermine the entire verification regime.

**People Count**:
min 32, max 52 — 2 independent red-team leads (one nominated per side, with no advance knowledge of exercise timing) plus 30–50 operators, analysts, and accredited clean-room examiners. Multiple full-time personnel are required to mount simultaneous challenges at multiple sites and preserve genuine independence from the inspection teams.

**Typical Activities**:
Design and execute unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal, and reluctant operator challenges; keep exercise timing secret from inspection teams; collect detection results by event type; compute false-negative and false-positive rates with confidence; validate KPI thresholds; and deliver filtered findings to the co-chairs.

**Background Story**:
Dr. Rafael Torres-Montoya, an independent red-team director based in Albuquerque, New Mexico, earned a Ph.D. in experimental physics from the University of New Mexico, spent 14 years at Sandia National Laboratories designing adversarial tests for treaty verification technologies, and served as a chief exercise designer for CTBTO-style integrated field exercises and a red-team lead on information-barrier evaluations for the UK-Norway Initiative. He specializes in creating unannounced challenges, injecting realistic false positives, measuring false-negative rates with confidence intervals, and forcing teams to confront vendor refusals and reluctant operators, and he wrote the Consortium's six mandatory blind-challenge scenarios. His relevance is that he supplies the independent detection evidence that justifies the Go/Modify/Stop verdict and prevents the exercises from becoming scripted or announced.

**Equipment Needs**:
Challenge-exercise payloads including substitute equipment, altered serialization tags, and inaccurate record packages; independent measurement and test instruments such as serialization scanners, power-analysis rigs, and attestation test rigs; tamper-evident materials for controlled tests; encrypted data collection and analysis tools for detection metrics; secure communications with no advance-knowledge schedule.

**Facility Needs**:
Isolated red-team operations center separate from inspection teams; designated exercise areas at sites including staging, spare-inventory, and maintenance zones; secure storage for challenge materials; neutral meeting and review rooms; clean-room access for vendor-refusal challenge scenarios.

## 6. Datacenter Site Preparation and Cross-Border Logistics Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Site preparation, parity calibration, customs/visa logistics, and fallback-site readiness require continuous, long-term coordination across two countries and multiple sites. Full-time employment ensures availability for inspections, drills, and unannounced challenges.

**Explanation**:
Ensures each matched declared site has N+1 power, 99.9% uptime, jointly controlled staging areas, bounded inspection zones, and secure facilities. Coordinates site surveys, parity scoring, fallback-site pre-qualification, visas, customs pre-clearance, diagnostic-equipment manifests, and the mandatory travel-and-clearance drill before the Phase One clock starts.

**Consequences**:
Without this role, sites would fail entry conditions, visa and customs bottlenecks would break the latency budget, and uneven inspection difficulty across matches could trip the asymmetric-access Stop condition. Environmental or grid failures could delay the 90-day test by weeks with no fallback.

**People Count**:
min 10, max 16 — 6 site-readiness leads (one per declared site) plus a central customs/visa logistics coordinator and regional support staff. Multiple people are needed because site surveys, staging construction, vendor coordination, and travel-and-clearance drills run in parallel across two countries and three geographic clusters.

**Typical Activities**:
Manage site surveys and parity scoring; oversee construction of staging areas and inspection zones; verify N+1 power and uptime; pre-qualify fallback sites; coordinate visas, customs pre-clearance, equipment manifests, and the travel-and-clearance drill; maintain environmental and grid-risk assessments; and support logistics for unannounced challenges.

**Background Story**:
Frank Weimin Jiang, a datacenter site-readiness and logistics manager based in Langfang, Hebei, earned a B.S. in mechanical engineering from Harbin Institute of Technology and an MBA from Peking University, and has spent 15 years managing construction, power, cooling, and operations for hyperscale datacenters in the Beijing/Hebei cluster, including tier IV facilities with N+1 redundancy and 99.9% uptime contracts. He led the physical surveys of the six candidate sites, built the six-attribute parity matrix, and coordinated the cross-border customs documentation for the Consortium's diagnostic equipment, including a successful travel-and-clearance drill. His relevance is that he ensures every declared site actually has jointly controlled staging areas, bounded inspection zones, secure facilities, and fallback capacity before the clock starts, and he prevents visa and customs delays from breaking the 24-hour physical-confirmation latency budget.

**Equipment Needs**:
Site survey and verification instruments including power quality analyzers, cooling and thermal meters, and uptime monitoring tools; construction and project-management systems; CAD/GIS for staging and zone layout; customs and visa logistics tracking platform; RFID/GPS equipment manifests and tag readers; portable power and cooling units for fallback and disaster response.

**Facility Needs**:
Site-readiness offices at every declared facility; jointly controlled staging-area construction zones; bounded inspection-zone infrastructure; logistics warehouses in Northern Virginia, Beijing/Hebei, and Guizhou; pre-qualified fallback site facilities; customs and visa processing liaison spaces.

## 7. Fiscal Escrow and Independent Audit Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Escrow signatory controls, envelope-coded drawdowns, quarterly reconciliation, and funding-timeliness KPIs require ongoing fiduciary responsibility and separation of duties. Full-time employment is necessary to avoid single-person fiscal control and ensure continuous accountability.

**Explanation**:
Ensures equal 50/50 pre-funding into a jointly signatory escrow, envelope-coded drawdowns, quarterly USD reconciliation, structured CNY conversion windows, and the funding-timeliness KPI with a 10-business-day suspension trigger. Provides independent auditing of both governments' domestic compensation disbursements and envelope-level cost control.

**Consequences**:
Without this role, delayed or asymmetric disbursement could act as a quiet veto that starves the program without formally triggering the withholding-funding Stop condition. Envelope overruns, currency shocks, or undisclosed domestic compensation could consume the contingency reserve and break reciprocal deployment.

**People Count**:
min 10, max 18 — 4–6 finance/escrow officers per side plus independent external audit firms. Multiple people are required for escrow signatory controls, envelope tracking, FX exposure management, and audit separation of duties; single-person fiscal control would be both a security and accountability failure.

**Typical Activities**:
Administer jointly signatory escrow; authorize envelope-coded drawdowns; perform quarterly USD reconciliation; manage CNY conversion windows and FX exposure; monitor the funding-timeliness KPI; audit domestic compensation disbursements; conduct envelope-level cost control and reforecasts; and report fiscal exceptions to the co-chairs.

**Background Story**:
Margaret 'Maggie' Danso, a fiscal and audit controller based in Washington, D.C., is a CPA with an MBA in finance from Johns Hopkins and 20 years of experience managing multi-billion-dollar sovereign escrow programs at the U.S. Treasury, including international climate funds and treaty-implementation accounts with jointly signatory control. She designed the Consortium's seven envelope codes, quarterly USD reconciliation, structured CNY conversion windows, and the 10-business-day funding-timeliness suspension trigger, and she leads the independent audit of domestic operator compensation in both countries. Her relevance is that she prevents delayed or asymmetric disbursement from acting as a quiet veto and keeps the $5 billion program fiscally accountable and envelope-compliant.

**Equipment Needs**:
Jointly signatory escrow management and accounting system; envelope-coded budget tracking and reporting software; quarterly reconciliation and FX conversion modeling tools; independent audit-management and evidence repositories; encrypted financial communications; KPI dashboard integration for funding-timeliness triggers.

**Facility Needs**:
Secure finance offices in both countries; escrow signatory meeting rooms with dual-key authorization controls; dedicated audit rooms with restricted records storage; secure videoconferencing to treasury and legislative oversight bodies.

## 8. Bilingual Training, Translation, and Readiness Certification Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Training, certified translation, glossary maintenance, readiness tracking, and certification support must operate for the entire program duration. Full-time mirrored teams are required to avoid single-person functions and sustain common discipline across approximately 450 staff.

**Explanation**:
Stands up the common training curriculum, the binding bilingual glossary, certified translation for evidence packages, and interpretation support for joint findings. Owns the integrated readiness tracker, joint certification packages, KPI dashboard reporting, and continuity planning so entry conditions are certified and trained personnel are sustained across political transitions.

**Consequences**:
Without this role, bilingual ambiguity becomes a ready-made access-denial weapon, staff lack common evidence-handling and information-barrier discipline, and entry conditions cannot be jointly certified. Unresolved interpretive disputes would create deferred deadlocks and stall or invalidate the Phase One verdict.

**People Count**:
min 18, max 30 — 6 mirrored technical linguists/engineers on the terminology commission plus training developers, certified translators, and readiness-tracker staff. Multiple people are required because glossary negotiation, common training for ~450 staff, evidence translation, and certification tracking all run simultaneously and cannot be single-person functions.

**Typical Activities**:
Maintain the binding bilingual glossary and interpretive annex; coordinate certified translation of evidence packages; run the common training curriculum for mirrored inspectors, technical, and legal staff; operate the integrated readiness tracker; prepare joint certification packages; track KPI dashboard reporting; and support continuity planning across leadership transitions.

**Background Story**:
Dr. Anika Zhou, a bilingual training and readiness-certification coordinator based in Beijing, earned a Ph.D. in applied linguistics from Beijing Foreign Studies University, trained as a conference interpreter at the Monterey Institute, and spent a decade developing security-cleared terminology systems and training curricula for IAEA safeguards inspectors and multilateral treaty-review conferences. She is fluent in English and Mandarin, expert in certified translation of technical evidence, and knowledgeable about adult learning, assessment, and readiness tracking, and she co-chaired the Consortium's terminology commission and built the integrated readiness tracker with named owners and certification fields. Her relevance is that she converts contested bilingual terms into a binding glossary, ensures all 450 staff share common evidence-handling and information-barrier discipline, and owns the joint certification package that starts the Phase One clock.

**Equipment Needs**:
Learning-management and common-training curriculum systems; simultaneous interpretation equipment; certified translation and computer-assisted translation tools; bilingual glossary and terminology database; integrated readiness tracker with certification fields; KPI dashboard reporting; secure document exchange and version control.

**Facility Needs**:
Training centers in the US and China with classrooms and interpretation booths; terminology-commission meeting rooms; readiness certification office; secure bilingual document storage; videoconferencing facilities linking mirrored training cohorts.

---

# Omissions

## 1. Dedicated Discrepancy Adjudication and Verdict Construction Lead

The plan explicitly requires mirrored adjudication units and lists 'discrepancy adjudication and suspension' as a top-level workstream, but the team document has no role accountable for operating the adjudication process. Without this function, unresolved-discrepancy age KPIs, materiality determinations, automatic-suspension recommendations, and the shared findings narrative that feeds the Go/Modify/Stop verdict lack a clear operational owner and risk being handled ad hoc by legal or political staff.

**Recommendation**:
Add a full-time, mirrored Discrepancy Adjudication and Verdict Construction unit with two co-leads (one per country) and dedicated legal, technical, and investigator staff. Assign it to track discrepancy age, apply pre-agreed materiality thresholds, prepare joint findings narratives, document deadlock procedures, and support the co-chairs without making the final political decision.

## 2. Covered-Equipment Schedule Custodian and Technical Configuration Manager

The plan states that 'accountable specialists must maintain a confidential, versioned technical schedule' for covered equipment, but the team roles do not assign this function. The schedule is the definitional backbone of the entire verification regime; if ownership is implicit, versioning, attribute-based coverage, fast-track provisional listings, and sunset reviews can become contested or drift, leaving new frontier-relevant equipment outside verification.

**Recommendation**:
Create a mirrored Covered-Equipment Schedule Custodian function with technical and legal specialists. This function should maintain the confidential attribute-based schedule under double-key specialist approval, publish a versioned changelog, pre-register dispute criteria, and manage 48-to-72-hour fast-track provisional listings when new equipment generations appear.

## 3. Operator and Vendor Compliance Liaison

The plan depends on mandatory participation by datacenter operators, manufacturers, maintenance providers, and logistics companies, including reporting, escort, confidentiality, and evidence-preservation obligations. The team document has legal drafting and site/logistics roles, but no operational function is responsible for day-to-day operator and vendor compliance, access scheduling, reluctant-operator handling, or escalation through the forced-evidence ladder.

**Recommendation**:
Add mirrored Operator and Vendor Compliance Liaison officers at each site, supported by a central coordination cell. Their duties should include managing access windows, monitoring access-delay incidents, verifying vendor reporting obligations, coordinating escorts, and triggering the vendor-refusal escalation ladder with documented outcomes and time-to-disposition metrics.

## 4. Joint Secretariat / Program Integration Lead

The pre-project assessment calls for a joint secretariat and integrated readiness tracker, and the program involves seven budget envelopes, six sites, roughly 450 staff, and multiple parallel workstreams. The current team has a readiness certification coordinator but no central program-integration function to maintain the integrated master schedule, resolve cross-workstream dependencies, and produce consolidated decision packages for the co-chairs.

**Recommendation**:
Establish a Joint Secretariat with two co-directors, one appointed per side, and a small dedicated PMO staff. This team should own the integrated readiness tracker, master schedule, risk register, and resource-allocation dashboard; facilitate monthly co-chair reviews; and ensure that every workstream lead has clear dependencies, milestones, and certification evidence.

## 5. Political Continuity and Government Liaison Function

A major risk identified in the assumptions and domain review is political discontinuity across leadership transitions, appropriations cycles, and shifting national priorities. The legal lead negotiates continuity commitments, but no role is responsible for sustained engagement with legislatures, heads of state, transition teams, and track-II channels. Without this function, political support can erode silently and entry-condition delays may go unmanaged.

**Recommendation**:
Add a senior mirrored Political Continuity and Government Liaison function, either as a distinct role or embedded in the Joint Secretariat. It should manage heads-of-state and legislative engagement, prepare transition briefings, track appropriations and entry-condition political actions, maintain the escrow-return and withdrawal scenario plans, and support a track-II dialogue channel to preserve technical relationships during political transitions.

---

# Potential Improvements

## 1. Remove Fictional Employee Biographies

The project plan explicitly states: 'Do not use ... fictional employee biographies.' The team document contains detailed named personas with invented career histories. This conflicts with the plan and weakens the credibility of the staffing model by blurring the line between illustrative examples and real, cleared personnel.

**Recommendation**:
Rewrite the team document to use role-based descriptions, required competencies, and actual staffing requirements without named fictional individuals. If illustrative personas are retained for training or concept development, clearly label them as 'notional illustrations' and exclude them from any official staffing, clearance, or certification documentation.

## 2. Separate Independent Audit from Fiscal Escrow Control

Role 7 combines fiscal escrow administration with independent auditing of domestic compensation and envelope spend. This creates a conflict of interest: the same function that controls drawdowns and reconciliation is also expected to independently audit those transactions. The plan requires independent auditing and fiscal accountability as a sovereign safeguard.

**Recommendation**:
Split the combined role into two functions: a Fiscal Escrow and Disbursement Controller responsible for escrow, drawdowns, currency conversion, and funding-timeliness KPIs, and an Independent Audit Director supported by external audit firms. The audit function should report directly to the co-chairs or an agreed joint oversight body and have unrestricted access to envelope records, compensation disbursements, and reconciliation logs.

## 3. Reconcile Role Counts with the 450-FTE Workload Model

The team document provides people-count ranges for each leadership area, but the sums are not clearly reconciled with the plan's approximate 450-FTE baseline or the USD 750 million inspectorate envelope. If role counts refer only to senior staff, the full inspectorate, technical, surge, and support staffing is undefined; if they refer to total staff, they appear too low for 24/7 coverage across six sites with separation of duties and leave backup.

**Recommendation**:
Publish a role-by-role FTE table that maps every unit to the workload formula: site count, shift coverage, leave backup, separation of duties, surge cadre, and support functions. Identify which roles are leadership only and which include full operational teams, and tie the resulting cost estimate to the appropriate budget envelopes so the 450-FTE baseline is internally consistent.

## 4. Strengthen Red Team Independence and Reporting Lines

The plan requires genuinely independent red teams with no advance knowledge of exercise timing. The team document places the Red Team Director as a full-time employee within the program, which creates a risk that exercise schedules, findings, or interpretation could be influenced by operational or political pressure, especially if the red team reports through the same chain as the inspectors it is testing.

**Recommendation**:
Establish the red team as a separately governed unit with direct reporting to the equal co-chairs or an independent joint appointment board. Give it a protected budget line, sealed exercise schedules, no operational inspection duties, and joint double-key protection against removal during Phase One. Its detection metrics and confidence intervals should feed the KPI dashboard without prior review by the inspectorate or site operators.

## 5. Clarify Role Boundaries and Decision Rights for Overlapping Functions

Several roles overlap operationally: intake staging involves the Inspectorate Operations Director, Hardware Identity Technical Lead, Information Barrier Security Director, and Site Preparation Manager. Without clear ownership of specific decisions, critical steps such as who controls a staging-area hold, who validates identity evidence, and who authorizes filtered evidence release can become delayed or disputed, threatening the latency budget.

**Recommendation**:
Create a RACI matrix for all high-risk operational processes, including staging intake, identity verification, evidence filtering, exit disposition, vendor refusal escalation, and cyber-incident isolation. Define which role is responsible, accountable, consulted, and informed for each step, and validate the matrix through tabletop exercises before Phase One begins.