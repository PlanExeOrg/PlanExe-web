# Governance Audit


## Audit - Corruption Risks

- Operators or vendors bribing inspectors to certify unverified equipment arrivals, installations, or removals, or to overlook discrepancies during staging, intake, maintenance, or exit verification.
- Government officials administering domestic operator and vendor compensation steering contracts or payments to politically connected datacenter operators, maintenance providers, or logistics companies in exchange for favors or kickbacks.
- Equipment manufacturers or maintenance vendors offering bribes to accredited clean-room examiners or technical specialists to produce favorable examination reports and avoid an unverifiable-equipment classification.
- Red-team members or penetration testers colluding with site operators or program insiders to learn exercise timing or scenarios, allowing blind challenges to be scripted and false-negative rates to be understated.
- Co-chairs or senior officials trading double-key approval of findings, sanctions, or suspensions for unrelated bilateral concessions, or using confidential evidence and the covered-equipment schedule to advantage domestic commercial interests.
- Personnel with access to the confidential covered-equipment schedule, filtered evidence packages, or information-barrier rules leaking sensitive information for personal gain, professional advancement, or foreign commercial advantage.
- Translators or legal specialists manipulating the binding bilingual glossary, interpretive annex, or evidence translations in exchange for bribes or to favor one government's position in a dispute.

## Audit - Misallocation Risks

- Drawing down funds from the wrong budget envelopes or using the $500 million contingency for non-surge, non-emergency expenses without joint double-key approval, eroding envelope-level fiscal control.
- Paying domestic operators and vendors compensation for services not actually performed or at inflated rates due to weak verification of claims, effectively double-charging the site-preparation envelope and contingency.
- Allowing the trained inspectorate to sit idle during entry-condition delays while salaries, clearances, and training costs continue consuming the $750 million inspectorate envelope without producing verification evidence.
- Misreporting KPI dashboard results—such as false-negative rates, event-recording latency, ledger divergence, or reciprocal-access parity—to create a favorable appearance and divert resources away from the areas that actually need correction.
- Maintaining inaccurate or incomplete baseline physical inventory and cryptographic asset registry records, leading to duplicate or ghost equipment entries, wasted verification effort, and invalid material-change determinations.
- Using program assets—diagnostic equipment, filtered workstations, secure facilities, travel funds, or staging areas—for unauthorized or personal purposes rather than for verification activities.
- Suffering avoidable budget overruns from unstructured CNY/USD conversion and revaluation windows, causing local inflation or currency movements to consume the contingency envelope before independent testing and challenge exercises are complete.

## Audit - Procedures

- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns against approved budget codes, performed by a jointly appointed external audit firm and reported to the equal national co-chairs, with confirmation that every expense maps to a defined envelope and any contingency use requires double-key authorization.
- Perform bilateral audits of domestic operator and vendor compensation disbursements, with each government's payments independently examined by the other side's audit unit or a jointly selected auditor to detect favoritism, inflated claims, or duplicate payments; conduct these audits semi-annually and at program close.
- Run monthly ledger integrity and divergence reconciliation drills between the two national ledger copies using independent test events, and have at least two independent penetration-testing firms assess the ledger, attestation, and evidence systems before the Phase One clock starts and again during Phase One.
- Validate KPI dashboard inputs through an independent audit before any Go/Modify/Stop decision, comparing reported false-negative rates, latency values, discrepancy ages, unverifiable-equipment counts, and access-parity metrics against raw exercise logs and evidence records; also perform quarterly spot-check audits during Phase One.
- Conduct a joint baseline physical inventory and cryptographic asset registry audit as a mandatory entry condition, followed by unannounced sample counts of covered equipment at each declared site during Phase One, verifying serial numbers, identity confidence, and disposition records.
- Audit compliance with information-barrier and counterintelligence requirements by reviewing filtered-workstation logs, access-control records, clean-room procedures, and evidence-handling logs to confirm that workloads, model weights, source code, and unrelated infrastructure were not exposed; perform these audits semi-annually and trigger an ad hoc forensic audit after any IP or cybersecurity incident.
- Carry out vendor and operator compliance audits to verify that manufacturers, maintenance providers, logistics companies, and site operators meet reporting, confidentiality, escort, and evidence-preservation obligations, including review of vendor-refusal escalation outcomes and unverifiable-equipment classifications; review these quarterly or after each material refusal.
- Sample inspector travel, visa, customs, and logistics expenses against approved budgets on a quarterly basis to detect inflated claims, unauthorized travel, or misuse of program funds.

## Audit - Transparency Measures

- Maintain a public KPI dashboard updated monthly with aggregate metrics covering blind-challenge detection rates, false negatives and positives, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, funding timeliness, and audit exceptions, with classified evidence details redacted.
- Publish the joint Go/Modify/Stop recommendation and the shared findings narrative after the co-chairs issue the verdict, with sensitive evidence redacted, and publish the pre-agreed Go, Modify, and Stop criteria before the Phase One clock starts.
- Issue quarterly public appropriation and audit reports summarizing envelope-level expenditures, audit exceptions, currency conversion and revaluation results, and aggregate domestic compensation disbursements, available to domestic legislatures and the public.
- Publicly disclose the multi-attribute site-parity matrix and site-selection criteria used to choose and match the six declared datacenter sites, including the inclusion of harder-to-inspect stress sites and pre-qualified fallback sites, to demonstrate that pairing is fair and reciprocal.
- Operate a secure whistleblower channel managed by an independent joint audit office, allowing inspectors, operators, vendors, and staff to report corruption, fraud, obstruction, or misconduct with non-retaliation protections and periodic independent review of complaints.
- Publish the information-barrier filter rules and redaction standards before evidence flows, with a versioned changelog, so the rules for stripping sensitive data are known, auditable, and consistently applied across all inspection events.
- Publicly report the aggregate readiness-tracker certification status and entry-condition closure progress, making any delays or asymmetric completion visible and preventing quiet fiscal or bureaucratic vetoes.
- Provide public access to redacted independent audit reports on fiscal accountability, envelope expenditures, and compensation disbursement audits, while protecting the confidential covered-equipment schedule, evidence details, and sensitive inspection findings.

# Internal Governance Bodies

### 1. Joint Steering Council (JSC)

**Rationale for Inclusion:** The program is a bilateral sovereign verification regime operating without mutual trust and with an explicit no-unilateral-overrule rule. A strategic oversight body is required to exercise equal double-key authority over the final Go/Modify/Stop decision, material findings, sanctions, suspension, protocol changes, and budget thresholds, and to manage political deadlock and impaired confidence without a casting vote.

**Responsibilities:**

- Provide strategic direction and approve the overall Phase One plan and final Go/Modify/Stop verdict.
- Exercise double-key authorization for all material site findings, sanctions, suspensions, protocol changes, and revisions to materiality or KPI thresholds.
- Approve and certify all mandatory entry conditions, including the bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection, inspector rosters, and covered-equipment schedule before the 90-day clock starts.
- Set strategic risk appetite and review the consolidated risk register, approving responses to strategic, political, and fiscal risks.
- Approve any expenditure above USD 10 million, any cross-envelope transfer, any contingency drawdown, and any change to approved budget envelopes.
- Own the deadlock, impaired-confidence, and automatic-suspension procedures; escalate unresolved political deadlocks to heads of state/party leadership.
- Receive and decide escalations from the Joint Program Management Office and all assurance bodies.

**Initial Setup Actions:**

- Adopt the JSC charter, decision rules, and deadlock protocol before the clock starts.
- Confirm the two equal national co-chairs and appoint the non-voting secretariat.
- Approve the strategic risk appetite and initial KPI thresholds recommended by the technical and audit bodies.
- Establish the entry-condition certification package and integrated readiness tracker reporting requirements.
- Set the meeting cadence and sign-off matrix for double-key decisions.

**Membership:**

- US National Co-Chair (senior official designated by the US government)
- China National Co-Chair (senior official designated by the Chinese government)
- JSC Secretary (non-voting)

**Decision Rights:** All strategic decisions: certification of entry conditions and Phase One clock; final Go/Modify/Stop verdict; material findings; sanctions; suspension; protocol amendments; KPI/materiality threshold changes; covered-equipment schedule approvals requiring double-key; expenditures above USD 10 million; any cross-envelope transfer; any contingency drawdown; any change to approved budget envelopes; and appointment of the neutral arbiter and independent assurance members.

**Decision Mechanism:** Double-key affirmative approval by both co-chairs. There is no casting vote and no majority vote. If consensus fails, the deadlock procedure applies: the item is deferred for up to 10 business days while joint technical/legal bodies seek a recommendation; if still unresolved, the matter is escalated to heads of state/party leadership. For a site with an unresolved material discrepancy, automatic suspension of verification activities at that site remains in effect until the deadlock is resolved. A co-chair may declare impaired confidence, triggering an extraordinary JSC session and, if unresolved, protective suspension scoped to the affected activity.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during the 90-day Phase One; extraordinary sessions within 48 hours upon request of either co-chair, a material incident, or a declared impaired-confidence condition.

**Typical Agenda Items:**

- Entry-condition readiness tracker and joint certification status
- Strategic risk register review and risk appetite decisions
- Budget envelope and drawdown approvals, including contingency requests
- KPI dashboard and audit exception summaries
- Material findings, vendor-refusal escalations, and suspension recommendations
- Deadlock, impaired-confidence, and automatic-suspension reviews
- Preparation of the joint Go/Modify/Stop verdict and shared findings narrative

**Escalation Path:** To the heads of state/party leadership of both countries as the senior authorizing principals for unresolved political deadlocks, entry-condition slippage beyond the 12-month target, withdrawal risk, or any matter requiring political authority above the co-chairs.
### 2. Joint Program Management Office (JPMO)

**Rationale for Inclusion:** The program's operational complexity with six matched sites, mirrored national teams, seven budget envelopes, a 90-day clock, and live challenge exercises cannot be managed by the strategic body. A dedicated operational management body is needed to execute the readiness phase and Phase One within delegated thresholds while preserving double-key authority at the strategic level for material decisions.

**Responsibilities:**

- Manage day-to-day execution of all workstreams: bilateral authority, site selection, inspectorate deployment, intake, ledger, maintenance, exit, exercises, adjudication support, and final decision.
- Maintain the integrated readiness tracker and operational schedule, including entry-condition closure and Phase One clock certification support.
- Allocate and control expenditures within approved budget envelopes up to USD 10 million per action and up to USD 25 million per envelope reallocation per quarter, with no cross-envelope transfers.
- Own the operational risk register; identify, assess, and mitigate operational risks and escalate strategic risks to the JSC.
- Manage staffing, shift coverage, leave backup, surge deployment, and separation-of-duties compliance for all mirrored units.
- Coordinate site access, inspection windows, vendor interactions, and event response within the agreed latency budget.
- Prepare decision packages and evidence summaries for the JSC, JTAB, JAECC, and JDAP.

**Initial Setup Actions:**

- Stand up the joint secretariat and appoint the two co-deputy directors and workstream leads.
- Implement the integrated readiness tracker and envelope-level budget control system.
- Validate the staffing model against the six-site workload formula and initiate clearances and training.
- Establish daily stand-up and weekly reporting cadence with all workstream leads.
- Draft operational thresholds, escalation templates, and delegated authority registers for JSC approval.

**Membership:**

- US Deputy Program Director
- China Deputy Program Director
- Joint Secretariat Lead
- Workstream leads for inspectorate, ledger, site preparation, testing/exercises, legal support, security/counterintelligence, and logistics
- Chief Risk Officer (operational risk)
- Chief of Staff / Readiness Tracker Owner
- No member of the JSC serves on the JPMO; JPMO members are full-time operational staff.

**Decision Rights:** Operational decisions within the approved plan and budget: day-to-day scheduling, staffing assignments, site access, event response, non-material discrepancy handling, procurement and contracting up to USD 10 million per action, within-envelope reallocation up to USD 25 million per quarter, and implementation of approved technical and security procedures. No authority to change protocol, KPI/materiality thresholds, site findings, sanctions, suspension, or budget envelopes; no contingency drawdown authority.

**Decision Mechanism:** Co-deputy consensus. Decisions within a workstream lead's delegated authority are made by that lead; cross-cutting decisions require both co-deputy directors' concurrence. If the co-deputies cannot agree, the matter is deferred for no more than 48 hours and then escalated to the JSC. There is no casting vote and no single-country override.

**Meeting Cadence:** Daily operational stand-up; weekly full JPMO coordination meeting; ad hoc incident-response sessions as needed.

**Typical Agenda Items:**

- Event queue, inspection windows, and latency metrics against the 4-hour/24-hour/1-hour budget
- Staffing coverage, leave, surge deployment, and separation-of-duties compliance
- Integrated readiness tracker status and entry-condition closing actions
- Budget envelope burn rates and procurement pipeline
- Vendor and operator participation issues and access delays
- Incident reports and operational risk register updates
- Escalation packages prepared for the JSC and assurance bodies

**Escalation Path:** Escalates to the JSC for expenditures above USD 10 million, cross-envelope or contingency matters, protocol changes, material discrepancy classifications, potential suspension or sanction, co-deputy deadlock, or realization of a strategic risk. Technical implementation issues may be referred to the JTAB; compliance concerns to the JAECC; discrepancies to the JDAP.
### 3. Joint Technical Assurance Board (JTAB)

**Rationale for Inclusion:** The mission depends on novel technical judgments: layered evidence, no-single-source decisiveness, information barriers, KPI thresholds, and unbiased blind challenges. A specialized technical assurance body with independent expertise is needed to set and validate technical standards, protect evidence credibility, and advise strategic and operational decision-makers without being captured by operational pressures.

**Responsibilities:**

- Define and maintain the layered evidence hierarchy, equipment-identity confidence standards, and no-single-source-decisive rules.
- Validate all KPI thresholds for false negatives, latency, divergence, discrepancy age, and unverifiable equipment before the clock starts and after challenge exercises.
- Design, select, and oversee independent red teams and the six mandatory unannounced challenge types, ensuring no advance knowledge and independent reporting.
- Approve and version information-barrier filter rules, clean-room protocols, and filtered workstation configurations within the JSC-approved policy framework.
- Assess vendor-refusal technical fallback options and recommend unverifiable classifications.
- Review the confidential, attribute-based covered-equipment schedule versioning and provide technical advice to the JSC on double-key schedule approvals.
- Monitor technical risks and recommend adjustments to technical procedures and thresholds.

**Initial Setup Actions:**

- Adopt the JTAB terms of reference and confirm the three independent external experts jointly appointed by the two governments.
- Finalize the evidence hierarchy, filter rules, and clean-room protocols for JSC approval.
- Publish the KPI threshold validation plan and provisional thresholds.
- Select independent red team providers and establish no-advance-knowledge reporting channels.
- Create the technical risk register and integrate it with the JPMO risk register.

**Membership:**

- US Principal Technical Advisor
- China Principal Technical Advisor
- US Chief Information Barrier Engineer
- China Chief Information Barrier Engineer
- Head of Independent Red Team / Testing (external, jointly appointed)
- Three independent external experts in hardware assurance, treaty verification, and information security (jointly appointed, full voting members on technical recommendations)
- Technical schedule custodians (non-voting, attendance as needed)

**Decision Rights:** Advisory and delegated technical authority. Recommends to the JSC: evidence hierarchy, KPI thresholds, information-barrier policy, covered-equipment schedule changes requiring double-key approval, and materiality definitions. Has delegated authority to approve technical implementation details within the JSC-approved framework, including filter-rule versions, test vectors, red-team engagement terms, and clean-room procedures.

**Decision Mechanism:** Consensus-seeking among national technical leads and independent external experts. A recommendation requires no objection from either national lead and support from at least two of the three independent experts. If the national leads disagree, the issue is documented with both technical opinions and the independent experts' assessment and escalated to the JSC. No casting vote; no majority procedure may allow one country to overrule the other.

**Meeting Cadence:** Biweekly during the entry-condition phase; weekly during Phase One; additionally within 72 hours after every challenge exercise or material technical incident.

**Typical Agenda Items:**

- Blind-challenge results by event type, false-negative and false-positive rates
- Evidence-weighting and equipment-identity confidence reviews
- Information-barrier filter logs and impact on substitution detection
- KPI threshold validation and confidence intervals
- Vendor-refusal technical options and unverifiable-equipment recommendations
- Technical schedule versioning and coverage-gap assessments
- Technical risk register and mitigation effectiveness

**Escalation Path:** Escalates to the JSC for any proposed change to evidence hierarchy, KPI thresholds, materiality definitions, information-barrier policy, or covered-equipment schedule requiring double-key approval; escalates to the JPMO for technical implementation defects or operations-level corrections.
### 4. Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Rationale for Inclusion:** The program faces high-impact security and counterintelligence risks: protection of sensitive technology, insider threats, evidence integrity, and cyber compromise. A dedicated security assurance body is necessary to oversee physical and cybersecurity, counterintelligence, information barrier implementation, and incident response without conflating these issues with technical verification or financial compliance.

**Responsibilities:**

- Oversee physical security, cybersecurity, and counterintelligence for all Consortium facilities, personnel, and evidence systems.
- Implement and audit information-barrier and separation-of-duties controls to protect workloads, model weights, source code, network topology, and security architecture.
- Monitor insider-threat indicators and manage clearance and access-control processes for all personnel.
- Own the joint incident-response protocol for IP, cyber, and counterintelligence incidents; direct isolation measures pending JSC review.
- Validate the security of the replicated ledger, filtered workstations, clean rooms, and secure facilities through independent penetration testing and security red-team exercises.
- Maintain the security risk register and report security risks to the JSC and JPMO.
- Ensure counterintelligence monitoring does not compromise the no-unilateral-overrule governance principle.

**Initial Setup Actions:**

- Approve the JSCIB charter and appoint the two national security leads and independent security experts.
- Conduct a baseline security and counterintelligence risk assessment for all six sites and secure facilities.
- Approve the information-barrier implementation plan and separation-of-duties matrix.
- Select independent penetration-testing firms and schedule pre-clock security testing.
- Drill the joint cyber-incident isolation protocol twice before Phase One.

**Membership:**

- US Security and Counterintelligence Director
- China Security and Counterintelligence Director
- US Cybersecurity Lead
- China Cybersecurity Lead
- Two independent security experts jointly appointed by both governments (full advisory members)
- Counterintelligence analysts from each national team (non-voting, attendance as needed)

**Decision Rights:** Security assurance authority within the JSC-approved policy: approve security procedures, access-control changes, and incident-isolation measures; direct preservation of evidence during an incident; and recommend to the JSC any security-driven suspension or change to information-barrier policy. Cannot unilaterally suspend the program, issue sanctions, or change verification protocols.

**Decision Mechanism:** Consensus between the two national security leads for decisions. Independent security experts provide assessments and may formally flag a security risk to the JSC if they believe either lead is underreacting. If the two leads disagree, the issue escalates to the JSC within 48 hours. No casting vote and no single-country override.

**Meeting Cadence:** Monthly during the entry-condition phase; weekly during Phase One; immediately upon any security incident or threshold alert.

**Typical Agenda Items:**

- Security risk posture and threat updates for all declared sites
- Cyber-incident and insider-threat monitoring reports
- Information-barrier filter and access-control audit results
- Penetration-test findings and remediation status
- Physical security and secure-facility compliance
- Incident-response drills and isolation protocol readiness
- Security inputs to the KPI dashboard and JSC risk reviews

**Escalation Path:** Escalates to the JSC for confirmed IP or cyber incidents compromising evidence integrity, insider threat or counterintelligence breach, security-driven suspension recommendations, disagreement between national security leads, or any proposed change to information-barrier policy requiring strategic approval.
### 5. Joint Legal and Terminology Commission (JLTC)

**Rationale for Inclusion:** The bilateral instrument must be supported by a binding bilingual glossary, pre-registered interpretive readings, domestic access legislation, model vendor-access agreements, and an inspector visa and customs annex. Legal and linguistic ambiguity can become an access-denial tool or a deferred deadlock. A specialized legal commission is required to pre-commit both governments to shared meanings and implementable legal frameworks before the clock starts.

**Responsibilities:**

- Draft and maintain the binding bilingual glossary and interpretive annex for contested terms such as material, removal, frontier-relevant, and declared site.
- Coordinate the domestic access-authority legislation and regulatory implementation in both countries.
- Negotiate and maintain model vendor-access agreements, operator site-eligibility conditions, and inspector-access, visa, and customs annexes.
- Pre-register each government's interpretive positions and maintain a versioned changelog of legal interpretations.
- Advise the JSC, JPMO, and JDAP on legal and regulatory risks, export controls, customs, privacy, and data-protection law.
- Support the JAECC in compliance oversight by providing authoritative legal interpretations.

**Initial Setup Actions:**

- Convene the joint terminology commission with mirrored legal and technical linguists.
- Draft the binding bilingual glossary with worked examples and submit it to the JSC for double-key approval.
- Prepare model vendor-access agreements and inspector-access annexes for signing before clock start.
- Provide legal drafting support for domestic access authority in both countries.
- Create the pre-registered interpretive annex and versioned legal changelog.

**Membership:**

- US Legal Co-Lead
- China Legal Co-Lead
- US Technical Linguist / Glossary Lead
- China Technical Linguist / Glossary Lead
- US Export-Control and Customs Legal Specialist
- China Export-Control and Customs Legal Specialist
- Independent international-law expert jointly appointed by both governments (advisory member)
- Representatives of the JPMO legal workstream and JAECC (non-voting, attendance as needed)

**Decision Rights:** Drafting and legal-recommendation authority only. It certifies the bilingual glossary and interpretive annex for JSC double-key approval, prepares legal instruments, and issues legal opinions on interpretive disputes. It has no authority to approve program expenditures, sanctions, suspension, or verification findings.

**Decision Mechanism:** Consensus between the two legal co-leads on recommendations and certifications. If they disagree, the issue is resolved by reference to the pre-registered interpretive annex; if still unresolved, it is escalated to the JSC for double-key decision. The independent international-law expert issues an advisory opinion but has no veto. No casting vote.

**Meeting Cadence:** Weekly during the entry-condition phase; as needed during Phase One for interpretive disputes or legal incidents; immediately upon a domestic legal challenge.

**Typical Agenda Items:**

- Bilingual glossary and interpretive annex review
- Domestic access-authority implementation status
- Model vendor-access and inspector-access agreement updates
- Visa, customs, and export-control clearance tracking
- Interpretive dispute resolutions and deferred-deadlock review
- Legal risk register updates and regulatory developments
- Support to JAECC on compliance and data-protection law

**Escalation Path:** Escalates to the JSC for unresolved interpretive disputes, proposed changes to the bilingual glossary or annexes, domestic legal challenges threatening inspector access, or any legal issue requiring double-key approval. Operational access issues are escalated to the JPMO.
### 6. Joint Audit, Ethics, and Compliance Committee (JAECC)

**Rationale for Inclusion:** The program handles USD 5 billion in sovereign funds, highly sensitive information, and operators and vendors with incentives to corrupt or misreport. A dedicated, externally led assurance body is required to provide independent audit, ethics, anti-corruption, data-protection and GDPR, and regulatory compliance oversight, and to validate the KPI dashboard so the Go/Modify/Stop verdict is based on trustworthy data.

**Responsibilities:**

- Provide comprehensive compliance oversight for financial integrity, anti-corruption, conflicts of interest, GDPR and analogous data-protection laws, ethical standards, export controls, customs, and classified-information handling.
- Conduct quarterly independent financial audits of envelope-level expenditures and drawdowns, including domestic compensation disbursements.
- Validate KPI dashboard inputs against raw exercise logs and evidence records before any Go/Modify/Stop decision and on a spot-check basis during Phase One.
- Operate a secure whistleblower channel with non-retaliation protections and independent review.
- Audit compliance with information-barrier, counterintelligence, and evidence-handling requirements.
- Report material compliance findings, suspected fraud, and audit exceptions directly to the JSC and, where required, to public transparency channels.
- Recommend protective holds to the JSC for suspected material fraud or evidence compromise; it cannot independently suspend the program.

**Initial Setup Actions:**

- Appoint the independent chair, two additional independent external members, and the national compliance officers.
- Adopt the audit charter, whistleblower policy, and conflict-of-interest rules.
- Conduct a baseline compliance and ethics risk assessment for all budget envelopes and compensation flows.
- Define the KPI validation audit plan and raw-data access protocols.
- Establish the quarterly audit calendar and semi-annual compensation audit schedule.

**Membership:**

- Independent Chair, external and jointly appointed by both governments
- Two independent external members with expertise in government auditing, data protection and GDPR, and ethics and compliance, jointly appointed
- US National Compliance Officer (non-voting observer with right to record dissent)
- China National Compliance Officer (non-voting observer with right to record dissent)
- Internal audit leads from each national audit unit (non-voting, attendance as needed)

**Decision Rights:** Authoritative audit and compliance findings: compel access to records, evidence, personnel, and systems within its mandate; issue audit exceptions and compliance recommendations; require the JPMO to preserve evidence and restrict access to records during a fraud or compliance investigation; and recommend protective holds, sanctions, or suspension to the JSC. No final program, budget, protocol, sanction, or suspension authority.

**Decision Mechanism:** Findings and recommendations are decided by majority vote of the three independent external members. National compliance officers have no veto but may append dissenting views to any finding. If the independent members cannot reach a decision, the matter is escalated to the JSC with all positions recorded. The independent chair has no casting vote beyond her or his regular vote.

**Meeting Cadence:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours upon an audit exception, whistleblower complaint, data-protection breach, or suspected fraud.

**Typical Agenda Items:**

- Audit exceptions and envelope-level expenditure findings
- Domestic operator and vendor compensation audit results
- KPI dashboard validation and raw-data provenance checks
- Data protection and GDPR compliance incidents
- Ethics, conflicts of interest, and corruption-risk indicators
- Whistleblower channel status and complaint resolutions
- Compliance risk register and regulatory developments

**Escalation Path:** Escalates to the JSC for material fraud, corruption, compliance breach, KPI misreporting, data-protection breach, unresolved audit exception, or any recommended protective hold or suspension.
### 7. Joint Discrepancy Adjudication Panel (JDAP)

**Rationale for Inclusion:** The regime's credibility depends on converting raw inspection findings into agreed materiality classifications and, when necessary, suspension recommendations without unilateral overrule. A dedicated adjudication body is needed to apply pre-agreed evidentiary rules, track unresolved discrepancy age, operate the automatic-suspension threshold, and refer only material disputes to the strategic level.

**Responsibilities:**

- Receive and adjudicate all discrepancies from inspectors, the JPMO, and challenge exercises.
- Apply the pre-agreed evidence hierarchy, materiality definitions, and KPI thresholds to classify discrepancies as routine, material, or unresolved.
- Resolve routine discrepancies under delegated evidentiary rules and issue joint findings for non-material discrepancies.
- Recommend material findings, sanctions, and suspension to the JSC for double-key authorization.
- Track unresolved discrepancy age and trigger automatic site-level suspension processes when thresholds are met.
- Refer deadlocked factual disputes to the jointly selected neutral technical arbiter for advisory findings.
- Maintain the discrepancy log and feed the KPI dashboard and verdict construction.

**Initial Setup Actions:**

- Adopt the adjudication charter and standard operating procedures.
- Appoint the two national adjudication officers and the neutral technical arbiter.
- Adopt the materiality definitions and threshold triggers pre-approved by the JSC.
- Establish the discrepancy-tracking dashboard and age metrics.
- Conduct training for inspectors and workstream leads on evidence submission and materiality rules.

**Membership:**

- US Senior Adjudication Officer
- China Senior Adjudication Officer
- US Legal Adviser to the Panel
- China Legal Adviser to the Panel
- US Senior Technical Adviser
- China Senior Technical Adviser
- Neutral Technical Arbiter, external and jointly selected, with advisory vote on deadlocked facts
- JDAP Secretariat (non-voting)

**Decision Rights:** Delegated authority to resolve non-material discrepancies and classify materiality under JSC-approved definitions. Can recommend material findings, sanctions, and suspension to the JSC. Can place a temporary administrative hold on affected equipment movement or site activity when automatic-suspension thresholds are met, pending JSC double-key confirmation within 48 hours. Cannot issue final sanctions, change protocol, or make final suspension decisions.

**Decision Mechanism:** The two national adjudication officers must concur on materiality classifications and findings. Routine discrepancies are resolved by joint technical teams under pre-agreed evidentiary rules. If the adjudication officers disagree on a factual issue, the neutral technical arbiter provides an advisory finding; if the officers still do not concur, the matter escalates to the JSC. No casting vote. Deadlock persisting beyond 10 business days is recorded as unresolved and escalates, with automatic site-level suspension applying if the discrepancy is material.

**Meeting Cadence:** Daily during Phase One, or as needed after each inspection event or challenge; immediately when a material discrepancy or suspension trigger occurs.

**Typical Agenda Items:**

- New discrepancy intake and evidence package review
- Materiality classification decisions and joint findings
- Unresolved discrepancy age and automatic-suspension thresholds
- Vendor-refusal and operator-obstruction adjudications
- Neutral arbiter referrals and advisory findings
- Recommendations for JSC sanctions or suspension
- Discrepancy trend inputs to the KPI dashboard and verdict construction

**Escalation Path:** Escalates to the JSC for material findings, sanctions, suspension, unresolved factual disputes after the arbiter process, deadlock beyond 10 business days, or any discrepancy meeting the Stop threshold.

# Governance Implementation Plan

### 1. Both governments designate senior officials to a Joint Formation Team and an Interim Secretariat to establish the governance framework, with a mandate to draft charters, coordinate appointments, and sequence the formation of all governance bodies.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Joint Formation Team designation letters
- Joint Formation Team mandate
- Interim Secretariat staffed

**Dependencies:**

- Political commitment confirmed
- Bilateral instrument drafting underway

### 2. Joint Formation Team drafts the initial Charter for the Joint Steering Council (JSC), including mission, double-key decision rules, no-casting-vote rule, deadlock procedure, impaired-confidence procedure, automatic-suspension thresholds, and meeting cadence.

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 1-2

**Key Outputs/Deliverables:**

- Draft JSC Charter v0.1

**Dependencies:**

- Joint Formation Team mandated
- Strategic Decision 1 (double-key deadlock and suspension) confirmed

### 3. Both governments appoint the two equal national co-chairs of the JSC and confirm the non-voting JSC Secretary, formally designating the JSC's leadership.

**Responsible Body/Role:** Both Governments / Heads of State or Party Leadership

**Suggested Timeframe:** Project Weeks 2-3

**Key Outputs/Deliverables:**

- US Co-Chair appointment letter
- China Co-Chair appointment letter
- JSC Secretary appointment

**Dependencies:**

- Draft JSC Charter available
- Bilateral agreement on co-chair selection criteria

### 4. Convene the JSC formation session; the appointed co-chairs adopt the JSC Charter, formally constituting the JSC and approving its meeting cadence and double-key sign-off matrix.

**Responsible Body/Role:** JSC (formation session, chaired by appointed co-chairs)

**Suggested Timeframe:** Project Weeks 3-4

**Key Outputs/Deliverables:**

- Approved JSC Charter
- JSC meeting cadence
- Double-key sign-off matrix

**Dependencies:**

- Both JSC co-chairs appointed
- Draft JSC Charter v0.1 completed

### 5. Joint Formation Team drafts the Terms of Reference for the Joint Program Management Office (JPMO), Joint Technical Assurance Board (JTAB), Joint Security, Counterintelligence, and Information Assurance Board (JSCIB), Joint Legal and Terminology Commission (JLTC), Joint Audit, Ethics, and Compliance Committee (JAECC), and Joint Discrepancy Adjudication Panel (JDAP).

**Responsible Body/Role:** Joint Formation Team (Interim)

**Suggested Timeframe:** Project Weeks 2-4

**Key Outputs/Deliverables:**

- Draft ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP

**Dependencies:**

- Joint Formation Team mandated
- JSC Charter drafting informed by strategic governance decisions

### 6. JSC approves the Terms of Reference for all operational and assurance bodies, the strategic risk appetite, initial budget envelope allocation, and delegated authority thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 4-6

**Key Outputs/Deliverables:**

- Approved ToRs for JPMO, JTAB, JSCIB, JLTC, JAECC, and JDAP
- Strategic Risk Appetite Statement
- Approved budget envelope allocation
- Delegated authority register v0.1

**Dependencies:**

- JSC Charter adopted
- Draft ToRs completed by Joint Formation Team
- Strategic decisions and budget envelopes confirmed

### 7. JSC appoints the JPMO co-deputy directors and the Joint Secretariat Lead, formally establishing the JPMO leadership team.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Weeks 6-8

**Key Outputs/Deliverables:**

- JPMO co-deputy director appointment letters
- Joint Secretariat Lead appointment
- JPMO leadership team confirmed

**Dependencies:**

- JPMO ToR approved

### 8. Hold the JPMO kick-off meeting; adopt the operational charter, assign workstream leads, and validate the six-site workload-based staffing model.

**Responsible Body/Role:** JPMO (under appointed co-deputy directors)

**Suggested Timeframe:** Project Weeks 8-10

**Key Outputs/Deliverables:**

- JPMO operational charter
- Workstream lead assignments
- Staffing model v0.1 validated

**Dependencies:**

- JPMO co-deputy directors appointed
- JPMO ToR approved

### 9. JPMO implements the integrated readiness tracker and envelope-level budget control system, including escalation templates and delegated authority registers.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- Integrated readiness tracker
- Envelope-level budget control system
- Escalation templates
- Delegated authority register v0.2

**Dependencies:**

- JPMO kick-off completed
- Budget envelope allocation approved by JSC

### 10. Both governments jointly appoint the JTAB national technical leads and the three independent external experts in hardware assurance, treaty verification, and information security.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 8-12

**Key Outputs/Deliverables:**

- JTAB appointment letters
- JTAB membership roster confirmed

**Dependencies:**

- JTAB ToR approved

### 11. Hold the JTAB formation/kick-off meeting; adopt the technical assurance work plan, begin drafting the layered evidence hierarchy, and publish the KPI threshold validation plan.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JTAB technical assurance work plan
- Layered evidence hierarchy draft
- KPI threshold validation plan v0.1

**Dependencies:**

- JTAB members appointed
- JTAB ToR approved

### 12. Both governments appoint the JSCIB national security leads and jointly appoint two independent security experts.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JSCIB appointment letters
- JSCIB membership roster confirmed

**Dependencies:**

- JSCIB ToR approved

### 13. Hold the JSCIB formation/kick-off meeting; conduct the baseline security and counterintelligence risk assessment and approve the information-barrier implementation plan and separation-of-duties matrix.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Weeks 12-16

**Key Outputs/Deliverables:**

- Baseline security and counterintelligence risk assessment
- Information-barrier implementation plan
- Separation-of-duties matrix

**Dependencies:**

- JSCIB members appointed
- Candidate site and secure-facility list available

### 14. Both governments appoint the JLTC legal co-leads, technical linguists, export-control and customs legal specialists, and the independent international-law expert.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- JLTC appointment letters
- JLTC membership roster confirmed

**Dependencies:**

- JLTC ToR approved

### 15. Hold the JLTC formation/kick-off meeting; begin drafting the binding bilingual glossary, interpretive annex, and pre-registered interpretive positions.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- Draft bilingual glossary v0.1
- Draft interpretive annex
- Pre-registered interpretive positions template

**Dependencies:**

- JLTC members appointed
- Bilateral instrument draft text available

### 16. JLTC prepares model vendor-access agreements, operator site-eligibility conditions, and the inspector-access, visa, and customs annex.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Draft model vendor-access agreement
- Operator site-eligibility conditions
- Draft inspector-access, visa, and customs annex

**Dependencies:**

- JLTC kick-off completed
- Domestic access-authority legislative drafts reviewed

### 17. Both governments jointly appoint the JAECC independent chair, two independent external members, and designate the national compliance officers.

**Responsible Body/Role:** Both Governments

**Suggested Timeframe:** Project Weeks 12-18

**Key Outputs/Deliverables:**

- JAECC appointment letters
- National compliance officer designations
- JAECC membership roster confirmed

**Dependencies:**

- JAECC ToR approved

### 18. Hold the JAECC formation/kick-off meeting; adopt the audit charter, whistleblower policy, conflict-of-interest rules, and the KPI validation audit plan.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Weeks 14-20

**Key Outputs/Deliverables:**

- JAECC audit charter
- Whistleblower policy
- Conflict-of-interest rules
- KPI validation audit plan

**Dependencies:**

- JAECC members appointed
- JPMO budget control system available for audit access

### 19. JSC approves the JDAP mandate, materiality definitions, and automatic-suspension trigger thresholds recommended by JTAB and JPMO.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 2-4

**Key Outputs/Deliverables:**

- Approved JDAP ToR
- Approved materiality definitions
- Approved automatic-suspension trigger thresholds

**Dependencies:**

- JTAB evidence hierarchy draft
- JSC strategic risk appetite approved

### 20. JSC appoints the JDAP national senior adjudication officers and jointly selects the neutral technical arbiter.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 3-5

**Key Outputs/Deliverables:**

- JDAP appointment letters
- Neutral technical arbiter appointment
- JDAP membership roster confirmed

**Dependencies:**

- JDAP ToR approved
- Materiality definitions approved

### 21. Hold the JDAP formation/kick-off meeting; adopt standard operating procedures, the discrepancy log, and unresolved-discrepancy age tracking.

**Responsible Body/Role:** JDAP

**Suggested Timeframe:** Project Months 4-6

**Key Outputs/Deliverables:**

- JDAP standard operating procedures
- Discrepancy tracking dashboard
- Unresolved-discrepancy age metrics

**Dependencies:**

- JDAP members appointed
- Materiality definitions approved

### 22. JTAB finalizes the layered evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds, incorporating JSCIB security input.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 3-6

**Key Outputs/Deliverables:**

- Evidence hierarchy v1.0
- Information-barrier filter rules v1.0
- Clean-room protocols
- Provisional KPI thresholds

**Dependencies:**

- JTAB kick-off completed
- JSCIB input on information-barrier security

### 23. JSC double-key approves the evidence hierarchy, information-barrier filter rules, clean-room protocols, and provisional KPI thresholds.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 5-7

**Key Outputs/Deliverables:**

- JSC approval minutes
- Approved technical standards
- Approved provisional KPI thresholds

**Dependencies:**

- JTAB technical submissions complete
- JSCIB security review complete

### 24. JTAB selects independent red-team providers and establishes no-advance-knowledge reporting channels for the six mandatory unannounced challenge types.

**Responsible Body/Role:** JTAB

**Suggested Timeframe:** Project Months 5-8

**Key Outputs/Deliverables:**

- Red-team provider contracts
- No-advance-knowledge reporting protocol
- Challenge exercise design plan

**Dependencies:**

- JSC-approved provisional KPI thresholds
- Independent testing budget envelope available

### 25. JSCIB executes the first cyber-incident isolation drill and independent penetration testing of the ledger, filtered workstations, and clean-room systems.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Penetration test reports
- First cyber-incident isolation drill after-action report
- Remediation plans

**Dependencies:**

- JSCIB kick-off completed
- Ledger and filtered-workstation prototypes available

### 26. JPMO validates the detailed staffing model, initiates security clearances, begins common training for mirrored national units, and establishes the full-time surge cadre roster.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Staffing model v1.0
- Clearance initiation records
- Common training curriculum
- Surge cadre roster

**Dependencies:**

- JPMO kick-off completed
- Workload assumptions and site count confirmed
- JTAB technical standards available for inspector training

### 27. JLTC completes the binding bilingual glossary, interpretive annex, and model legal instruments, and submits them to JSC for double-key approval.

**Responsible Body/Role:** JLTC

**Suggested Timeframe:** Project Months 4-8

**Key Outputs/Deliverables:**

- Final bilingual glossary
- Final interpretive annex
- Final model vendor-access and inspector-access instruments

**Dependencies:**

- JLTC drafting complete
- Bilateral instrument text finalized
- Domestic legal requirements confirmed

### 28. JSC double-key approves the binding bilingual glossary, interpretive annex, and model legal instruments before the Phase One clock starts.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 6-9

**Key Outputs/Deliverables:**

- JSC approval minutes
- Certified bilingual glossary
- Approved interpretive annex
- Approved legal instruments

**Dependencies:**

- JLTC final submissions complete
- Negotiation positions reconciled

### 29. JAECC conducts the baseline compliance and ethics risk assessment and completes the first quarterly audit cycle of envelope-level expenditures and drawdowns.

**Responsible Body/Role:** JAECC

**Suggested Timeframe:** Project Months 4-9

**Key Outputs/Deliverables:**

- Baseline compliance and ethics risk assessment
- Q1 audit report
- Audit exception register

**Dependencies:**

- JAECC kick-off completed
- Budget control system operational
- First drawdowns executed

### 30. JSCIB executes the second cyber-incident isolation drill and certifies security and counterintelligence readiness for Phase One.

**Responsible Body/Role:** JSCIB

**Suggested Timeframe:** Project Months 7-10

**Key Outputs/Deliverables:**

- Second drill after-action report
- Security readiness certification package
- Counterintelligence readiness assessment

**Dependencies:**

- First drill completed
- Secure facilities and evidence systems operational

### 31. JPMO consolidates all governance-body readiness inputs into the integrated readiness tracker and prepares the entry-condition certification package for JSC review.

**Responsible Body/Role:** JPMO

**Suggested Timeframe:** Project Months 8-11

**Key Outputs/Deliverables:**

- Consolidated readiness tracker
- Entry-condition certification package draft
- Gap analysis and remediation plan

**Dependencies:**

- All bodies' initial charters and work plans approved
- JLTC legal instruments approved
- Staffing and clearance milestones met

### 32. JSC convenes a formal governance integration and orientation session with all body leads to review escalation paths, decision rights, and KPI dashboard reporting, and to resolve any interfacing issues.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** Project Months 9-11

**Key Outputs/Deliverables:**

- Governance integration minutes
- Escalation path diagram
- KPI dashboard reporting protocols
- Interfacing issues log

**Dependencies:**

- All governance bodies formally established
- JAECC KPI validation plan available
- JPMO consolidated readiness tracker available

### 33. JSC conducts the final entry-condition certification review, jointly certifies that all mandatory entry conditions are met, and formally starts the 90-day Phase One clock.

**Responsible Body/Role:** JSC

**Suggested Timeframe:** By 2027-Sep-04 target (Project Month 12)

**Key Outputs/Deliverables:**

- Joint entry-condition certification
- Phase One clock start authorization
- Certified readiness package

**Dependencies:**

- Entry-condition certification package approved
- All legal instruments signed
- Escrow pre-funding confirmed
- Sites and inspectors approved
- KPI thresholds validated

# Decision Escalation Matrix

**Budget Request Exceeding JPMO Delegated Authority (Above USD 10 Million or Cross-Envelope Transfer)**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key affirmative approval by both national co-chairs; no casting vote. If consensus fails, the pre-registered deadlock procedure applies, with escalation to heads of state or party leadership after 10 business days if unresolved.
Rationale: Exceeds the JPMO's delegated expenditure threshold and involves cross-envelope or contingency drawdown authority reserved to the strategic body to protect the approved budget envelopes and fiscal accountability.
Negative Consequences: Unauthorized or asymmetric spending, budget-envelope erosion, loss of fiscal oversight, and a quiet fiscal veto that can stall Phase One operations.

**Confirmed IP/Cyber Incident Compromising Evidence Integrity**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSCIB directs immediate isolation measures under the incident-response protocol and reports to the JSC; JSC decides by double-key whether to hold, suspend, or adjust verification activity based on the JSCIB assessment.
Rationale: A single evidence-integrity compromise is a designated Stop-level trigger, can invalidate ledger records and the Go/Modify/Stop verdict, and requires strategic security-policy authority beyond JSCIB's operational isolation powers.
Negative Consequences: Compromised evidence, invalid challenge results, loss of bilateral confidence, national-security incident escalation, and program suspension or termination.

**JPMO Co-Deputy Deadlock on an Operational Decision**
Escalation Level: Joint Steering Council (JSC)
Approval Process: After the 48-hour JPMO deferral period, the matter escalates to the JSC, which applies double-key approval; an unresolved JSC deadlock follows the pre-registered 10-business-day deadlock procedure.
Rationale: No operational decision may be resolved by a single-country override, and an unresolved co-deputy deadlock blocks daily execution, risks latency-budget breaches, and requires the strategic body to restore joint authority.
Negative Consequences: Operational paralysis, missed 4-hour/24-hour/1-hour latency windows, unresolved discrepancies, and erosion of the no-unilateral-overrule principle.

**Proposed Major Protocol or Scope Change**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JSC double-key authorization after receiving recommendations from the JPMO, JTAB, and JLTC as applicable; no majority vote or casting vote can alter protocol.
Rationale: Protocol amendments and scope changes alter the bilateral verification bargain and verification boundaries, exceed all delegated operational and technical authorities, and must be approved by equal sovereign co-chairs.
Negative Consequences: Mission creep beyond declared-equipment verification, renegotiation of entry conditions, legal invalidation, and loss of the narrow bilateral mandate.

**Deadlocked Material Discrepancy Classification at the JDAP**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JDAP refers the factual dispute to the neutral technical arbiter for an advisory finding; if the national adjudication officers still do not concur, the matter escalates to the JSC for double-key decision, with automatic site-level suspension remaining in effect if material.
Rationale: Material findings, sanctions, and suspension require double-key authorization, and no single country may unilaterally classify or dismiss a discrepancy that could trigger automatic suspension or a Stop verdict.
Negative Consequences: Unresolved discrepancy age beyond 10 business days, automatic suspension, a contested Go/Modify/Stop verdict, and a ready-made shield for a non-cooperating operator.

**Vendor Refusal Escalating to Potential Unverifiable-Equipment Classification**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB assesses the technical fallback ladder and recommends the unverifiable classification; JSC issues the final material finding and any sanction or site-suspension decision by double-key authorization.
Rationale: A dominant vendor refusal can cascade across multiple sites and convert a local equipment issue into a systemic Stop trigger, exceeding JPMO operational authority and requiring strategic materiality judgment.
Negative Consequences: Unverifiable equipment above the materiality threshold, site failure, cascading vendor non-cooperation, and a forced Stop recommendation.

**Proposed Revision of KPI or Materiality Thresholds After Challenge Validation**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB validates the proposed thresholds against blind-challenge data and recommends approval; JSC decides by double-key, ensuring both governments accept any change to the falsifiable honesty claim of Phase One.
Rationale: KPI and materiality thresholds define the Go/Modify/Stop criteria and strategic risk appetite; changing them unilaterally or after poor results could mask detection failures and undermine verdict credibility.
Negative Consequences: False Go based on relaxed thresholds, false Stop from over-calibration, loss of independent red-team credibility, and a politically contested final verdict.

**Entry-Condition Slippage Beyond the 12-Month Target**
Escalation Level: Heads of State / Party Leadership
Approval Process: JSC formally escalates the open certification conditions to the two senior authorizing principals, who issue a joint political directive to remedy the slippage or decide program continuation; the JSC retains double-key certification of any new clock start.
Rationale: Entry conditions are political acts requiring authority above the co-chairs; the 12-month target is a political commitment, and only the senior principals can resolve legislative or site-selection deadlocks.
Negative Consequences: Indefinite delay of Phase One, idle inspectorate and sunk preparation costs, loss of political momentum, and potential collapse of the USD 5 billion program.

**Information-Barrier Policy Conflict Between Verification Sensitivity and Technology Protection**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JTAB and JSCIB provide joint technical and security assessments; JSC approves any change to filter rules, clean-room protocols, or inspection-zone boundaries by double-key.
Rationale: The balance between evidence sufficiency and protection of sovereign technology is the core strategic tension, and altering barrier policy affects national security exposure and the credibility of every verification result.
Negative Consequences: Over-filtering hides substitution evidence and causes false negatives, while under-filtering leaks sensitive technology, triggering counterintelligence failure and program termination.

**Material Fraud, Corruption, or KPI Misreporting Detected by JAECC**
Escalation Level: Joint Steering Council (JSC)
Approval Process: JAECC issues an audit exception and recommends protective holds, sanctions, or suspension; JSC decides by double-key after receiving the independent findings and any dissenting views from national compliance officers.
Rationale: Misreporting or fraud in sovereign funds or KPI data corrupts the evidence base for the verdict and the integrity of the entire bilateral mechanism, requiring independent-audit escalation to the strategic level.
Negative Consequences: Financial loss across the USD 5 billion envelope, false Go/Modify/Stop decision, legal penalties, loss of public and sovereign trust, and exposure to whistleblower or compliance investigations.

# Monitoring Progress

### 1. Entry-condition readiness and certification tracking: monitor closure of all ten mandatory entry conditions (bilateral instrument, domestic access authority, escrow pre-funding, matched-site selection and declaration, inspector roster approval, operator/vendor participation agreements, covered-equipment schedule adoption, joint baseline physical inventory and cryptographic asset registry, inspector visa/customs annex and travel-and-clearance drill, and independent validation of the ledger/barrier/KPI systems) against the integrated readiness tracker, with reciprocal certification parity enforced.
**Monitoring Tools/Platforms:**

  - Integrated readiness tracker
  - Entry-condition certification checklist/package
  - Reciprocal certification parity report
  - JSC escalation templates to heads of state/party leadership
  - Gap analysis and remediation plan

**Frequency:** Weekly during the entry-condition phase; daily during the final two months before the 2027-Sep-04 target

**Responsible Role:** Joint Program Management Office (JPMO) with joint certification by the Joint Steering Council (JSC)

**Adaptation Process:** JPMO assigns corrective actions to named workstream leads for each open condition; if any condition risks missing the 12-month target, JPMO escalates to the JSC, which may formally escalate the open political condition to heads of state/party leadership; the Phase One clock is not started until all conditions are jointly certified by both co-chairs.

**Adaptation Trigger:** Any entry condition open after the 2027-Sep-04 target date; uncertified condition at proposed clock start; asymmetric certification progress between the two countries; baseline inventory discrepancy above 2% at any site blocking certification

### 2. Operational KPI dashboard monitoring: track the full pre-registered KPI set covering blind-challenge detection by event type, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence and reconciliation time, reciprocal-access parity, unresolved discrepancy age, unverifiable equipment, vendor-refusal outcomes, IP/cyber incidents, production disruption, funding timeliness, and audit exceptions.
**Monitoring Tools/Platforms:**

  - KPI dashboard
  - KPI Tracking Spreadsheet with confidence intervals
  - Raw exercise logs and evidence records
  - Latency monitoring and alerting tools
  - Ledger divergence and synchronization health reports

**Frequency:** Daily during Phase One; weekly during the entry-condition phase for pre-validation baselines

**Responsible Role:** Joint Program Management Office (JPMO) with KPI threshold validation by the Joint Technical Assurance Board (JTAB) and KPI data-integrity audits by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO implements corrective actions for operational deviations; JTAB re-validates thresholds if data indicate mis-calibration; persistent or material deviations are packaged for JSC double-key decision, including proposals for threshold revision, additional testing, or suspension recommendations.

**Adaptation Trigger:** Any KPI deviation beyond pre-registered thresholds: false-negative rate >5% at 95% confidence; event-recording latency >5 minutes locally; cross-national synchronization >1 hour; divergence reconciliation >24 hours; unresolved discrepancy age >10 business days; unverifiable equipment >2 units per site or >1% of covered changes

### 3. Blind challenge and red-team exercise monitoring: track execution and outcomes of all six mandatory unannounced challenge types (unreported arrival, substituted equipment, inaccurate records, delayed access, disputed identity, vendor refusal) to validate silent-window bounds, layered-evidence sufficiency, information-barrier effectiveness, and the credibility of the eventual Go/Modify/Stop evidence base.
**Monitoring Tools/Platforms:**

  - Challenge exercise design plan
  - Independent red-team reports
  - Blind-challenge results tracker by event type
  - No-advance-knowledge protocol compliance log
  - Exercise after-action reports

**Frequency:** After every challenge exercise; weekly cumulative review during Phase One; JTAB session within 72 hours of any exercise or material technical incident

**Responsible Role:** Joint Technical Assurance Board (JTAB) overseeing independent red teams

**Adaptation Process:** JTAB recommends technical procedure corrections, filter-rule adjustments, clean-room protocol changes, or additional test vectors when a challenge type is missed; if detection failures persist above the false-negative threshold, JTAB escalates to the JSC with a recommendation against a Go verdict.

**Adaptation Trigger:** Any blind-challenge miss or false negative; false-negative rate exceeding the 5% threshold at 95% confidence; evidence of red-team advance knowledge or compromised exercise independence; any challenge revealing that over-filtering hides substitution indicators

### 4. Budget envelope, funding timeliness, and fiscal compliance monitoring: track expenditure against the seven budget envelopes, envelope burn rates, escrow balance and drawdown approvals, quarterly USD reconciliation, CNY conversion windows and FX exposure, and contribution-release timing to prevent quiet fiscal vetoes and cost overruns.
**Monitoring Tools/Platforms:**

  - Envelope-level budget control system
  - Escrow reconciliation statements
  - Quarterly reforecast reports
  - Independent audit reports
  - Currency conversion and FX exposure tracker
  - Contingency drawdown request log

**Frequency:** Weekly burn-rate review by JPMO; quarterly reconciliation and independent audit by JAECC

**Responsible Role:** Joint Program Management Office (JPMO) with independent audit by the Joint Audit, Ethics, and Compliance Committee (JAECC) and JSC double-key approval for cross-envelope or contingency actions

**Adaptation Process:** JPMO reallocates within envelopes up to delegated thresholds; any expenditure above USD 10 million, cross-envelope transfer, or contingency drawdown requires JSC double-key approval; funding delays beyond the pre-agreed window are escalated as a KPI-visible suspension trigger; audit exceptions trigger corrective action plans.

**Adaptation Trigger:** Envelope burn rate exceeding forecast by 10%; contribution release delayed more than 10 business days; projected currency or inflation movement consuming more than the USD 500 million contingency reserve; audit exception, suspected fraud, or material fiscal misreporting

### 5. Consolidated risk register and mitigation effectiveness monitoring: maintain and review the consolidated risk register covering governance and deadlock, political continuity, regulatory and legal challenge, financial and currency, supply-chain and vendor refusal, information-barrier security, latency and silent-window, ledger divergence, matched-site parity, staffing, cyber and counterintelligence, red-team independence, schedule drift, operator reluctance, and cost-overrun risks.
**Monitoring Tools/Platforms:**

  - Consolidated risk register
  - Operational risk register (JPMO)
  - Strategic risk register (JSC)
  - Risk scoring and trend matrix
  - Escalation log

**Frequency:** Weekly by JPMO; monthly strategic review by JSC; ad hoc immediately upon any risk realization

**Responsible Role:** JPMO Chief Risk Officer with periodic review and risk-appetite decisions by the Joint Steering Council (JSC)

**Adaptation Process:** Risk owners update mitigation plans and assign corrective actions; risks crossing strategic thresholds are escalated to the JSC for risk-appetite decisions, additional mitigation resourcing, or activation of deadlock, suspension, or escalation procedures; mitigation effectiveness is re-scored after each action.

**Adaptation Trigger:** Risk likelihood or severity increase; identification of a new risk; realization of a top risk such as vendor-refusal cascade, information leak, funding delay, political discontinuity, or cross-border access breakdown

### 6. Information barrier, cybersecurity, and counterintelligence monitoring: continuously monitor information-barrier filter rules, bounded inspection zones, filtered workstations, clean-room protocols, physical and logical separation of national teams, insider-threat indicators, evidence integrity, and the security of the replicated ledger and secure facilities.
**Monitoring Tools/Platforms:**

  - JSCIB security monitoring dashboards
  - Information-barrier filter logs and audit trails
  - Penetration test reports
  - Insider-threat monitoring reports
  - Cyber-incident isolation drill after-action reports
  - Physical security and counterintelligence compliance checklists

**Frequency:** Continuous automated monitoring with weekly JSCIB review; immediate review upon any incident or threshold alert

**Responsible Role:** Joint Security, Counterintelligence, and Information Assurance Board (JSCIB)

**Adaptation Process:** JSCIB directs immediate isolation or evidence-preservation measures under the joint incident-response protocol; filter rules, zone boundaries, or clean-room configurations may be adjusted within JSC-approved policy, with any policy change escalated to the JSC for double-key approval; confirmed evidence-integrity compromises are escalated with a recommendation for automatic hold.

**Adaptation Trigger:** Confirmed IP or cyber incident compromising evidence integrity; critical penetration-test finding; insider-threat indicator; evidence that over-filtering has hidden substitution indicators or under-filtering has exposed protected workloads, model weights, source code, or security architecture

### 7. Discrepancy adjudication and materiality threshold monitoring: track all intake, maintenance, and exit discrepancies through the adjudication pipeline, monitoring materiality classification, unresolved discrepancy age, unverifiable-equipment counts per site, vendor-refusal outcomes, exit-disposition completion, and automatic-suspension triggers.
**Monitoring Tools/Platforms:**

  - Discrepancy tracking dashboard
  - Unresolved-discrepancy age metrics
  - Materiality classification log
  - Automatic-suspension trigger register
  - Vendor-refusal and exit-disposition trackers
  - Neutral arbiter referral log

**Frequency:** Daily during Phase One; immediately upon any material discrepancy or suspension trigger

**Responsible Role:** Joint Discrepancy Adjudication Panel (JDAP)

**Adaptation Process:** JDAP resolves routine discrepancies under delegated evidentiary rules; material findings are recommended to the JSC for double-key authorization; unresolved material discrepancies trigger automatic site-level suspension; deadlocked factual disputes are referred to the neutral technical arbiter; unresolved exits without assigned disposition within 48 hours trigger automatic site review.

**Adaptation Trigger:** Unresolved discrepancy age exceeding 10 business days; unverifiable equipment exceeding 2 units per site or 1% of covered changes; exit without an assigned disposition within 48 hours; JDAP deadlock on a material classification; vendor refusal exhausting the forced-evidence ladder

### 8. Reciprocal access parity and matched-site performance monitoring: monitor reciprocal access hours, verification outcomes, and inspection burden across each matched site pair to validate parity calibration and detect asymmetric access that would trigger a Stop condition.
**Monitoring Tools/Platforms:**

  - Parity scoring matrix (multi-attribute)
  - Reciprocal access-hour benchmarking tracker
  - Site-level verification outcome comparison reports
  - Stress-site exercise logs
  - Site fallback and disaster-response readiness records

**Frequency:** Weekly during Phase One; monthly during site-selection and readiness phases

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB)

**Adaptation Process:** JPMO rebalances inspection scheduling and site-pair assignments; JTAB recommends recalibration of the parity matrix if site characteristics diverge; evidence of asymmetric access or materially unequal verification difficulty is escalated to the JSC as a potential Stop trigger with a joint findings narrative.

**Adaptation Trigger:** Reciprocal access-hour asymmetry beyond the pre-agreed threshold; materially unequal verification outcomes across a matched pair; inability to verify a deliberately hard-to-inspect stress site; one government shielding an operator from access

### 9. Governance health and deadlock monitoring: monitor the functioning of double-key governance, including decision throughput, deadlock duration, impaired-confidence declarations, automatic-suspension activations, and compliance with the no-casting-vote and no-unilateral-overrule rules.
**Monitoring Tools/Platforms:**

  - Decision log and double-key sign-off matrix
  - Deadlock duration tracker
  - Escalation log to heads of state/party leadership
  - Impaired-confidence declaration register
  - Unilateral-action incident log

**Frequency:** Weekly during Phase One; monthly during the entry-condition phase; extraordinary session within 48 hours of an impaired-confidence declaration

**Responsible Role:** JSC Secretariat under the Joint Steering Council (JSC)

**Adaptation Process:** Deadlocked items are deferred under the pre-registered procedure while joint technical and legal bodies develop recommendations; if consensus still fails, the matter is escalated to heads of state or party leadership; automatic site-level suspension remains in effect for unresolved material discrepancies; protective suspension is scoped to affected activities upon impaired-confidence declaration.

**Adaptation Trigger:** Deadlock persisting beyond 10 business days; impaired-confidence declaration by either co-chair; any attempted unilateral finding, sanction, or decision; automatic-suspension activation at any site

### 10. Staffing, clearance, and workforce coverage monitoring: monitor staffing levels against the workload-based model, including 24/7 shift coverage, the 1.5x leave/backup multiplier, separation of duties, no-single-person-critical-function compliance, full-time surge cadre readiness, and clearance and common-training progress.
**Monitoring Tools/Platforms:**

  - Staffing model v1.0
  - Shift coverage and leave-backup schedules
  - Clearance initiation and completion tracker
  - Common training curriculum records
  - Surge cadre roster and deployment log
  - Separation-of-duties compliance matrix

**Frequency:** Weekly by JPMO; monthly certification of coverage ratios and readiness

**Responsible Role:** Joint Program Management Office (JPMO)

**Adaptation Process:** JPMO deploys the surge cadre, initiates cross-training, and adjusts shift assignments to close coverage gaps; clearance delays trigger parallel recruitment or secondment from national verification bodies; structural staffing shortfalls are escalated to the JSC with budget and timeline implications.

**Adaptation Trigger:** Any single-person critical function identified; coverage below the 1.5x backup multiplier; surge deployment exceeding the pre-agreed response window; clearance or training delays preventing a material event from being staffed by two full-time mirrored national inspectors

### 11. Covered-equipment schedule versioning and coverage-gap monitoring: track versioned updates to the confidential attribute-based covered-equipment schedule, fast-track provisional listings, sunset reviews, and any coverage gaps created by new equipment generations or architecture drift.
**Monitoring Tools/Platforms:**

  - Versioned confidential covered-equipment schedule
  - Versioned changelog
  - Fast-track provisional listing log
  - Sunset review calendar
  - Pre-registered dispute criteria register
  - Coverage-gap assessment reports

**Frequency:** Monthly and immediately upon either side fielding a new frontier-relevant equipment generation

**Responsible Role:** Accountable technical schedule custodians under the Joint Technical Assurance Board (JTAB) with JSC double-key approval for revisions

**Adaptation Process:** Technical custodians issue fast-track provisional listings within 48-72 hours to close coverage gaps; JTAB recommends schedule revisions with attribute-based justification; JSC applies double-key approval; unresolved definitional disputes are resolved by reference to the pre-registered interpretive annex rather than renegotiation.

**Adaptation Trigger:** New equipment generation fielded by either country; identified coverage gap that would allow covered equipment to ship outside verification; sunset review due; proposed schedule revision that reopens the bilateral definitional bargain

### 12. Audit, ethics, and KPI data-integrity monitoring: independently audit envelope-level expenditures, domestic operator and vendor compensation disbursements, KPI dashboard inputs against raw exercise logs and evidence records, compliance with information-barrier and data-protection requirements, conflict-of-interest declarations, and whistleblower complaints.
**Monitoring Tools/Platforms:**

  - Quarterly audit reports
  - KPI validation audit plan
  - Raw-data provenance and access protocols
  - Whistleblower channel and complaint log
  - Audit exception register
  - Conflict-of-interest declarations
  - Compensation disbursement audit schedule

**Frequency:** Quarterly during the entry-condition phase; monthly during Phase One; extraordinary session within 48 hours of an audit exception, whistleblower complaint, data-protection breach, or suspected fraud

**Responsible Role:** Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JAECC issues audit exceptions, requires preservation of records and restricted access during investigations, and recommends protective holds, sanctions, or suspension to the JSC; unresolved exceptions trigger corrective action plans; material fraud or KPI misreporting is escalated as a Stop-level concern that must be resolved before any Go verdict.

**Adaptation Trigger:** Material fraud, corruption, or KPI misreporting; unresolved audit exception; data-protection or GDPR breach; whistleblower complaint requiring protective action; evidence that KPI dashboard inputs have been manipulated

### 13. Legal, interpretive, and cross-border access monitoring: monitor implementation of the binding bilingual glossary, interpretive annex, domestic access authority, model vendor-access agreements, and the standing inspector visa and customs annex, including visa processing times, customs clearance of diagnostic equipment, and any domestic legal challenges to inspector authority.
**Monitoring Tools/Platforms:**

  - Binding bilingual glossary and interpretive annex
  - Legal implementation tracker
  - Visa and customs clearance monitoring log
  - Domestic legal challenge log
  - Travel-and-clearance drill results
  - Export-control and customs compliance reports

**Frequency:** Weekly during the entry-condition phase; as needed during Phase One for legal or access incidents

**Responsible Role:** Joint Legal and Terminology Commission (JLTC)

**Adaptation Process:** JLTC issues legal opinions, updates model instruments, and coordinates with domestic authorities to resolve access barriers; unresolved interpretive disputes or legal challenges threatening inspector access are escalated to the JSC for double-key decision; any visa or customs delay is reported to the JPMO for latency-budget impact assessment.

**Adaptation Trigger:** Visa processing exceeding the 48-hour standing agreement; customs hold on diagnostic or challenge-exercise equipment; domestic legal challenge to foreign inspector authority; interpretive dispute not resolvable by the pre-registered annex; any access barrier that would break the 24-hour physical-confirmation window

### 14. Baseline inventory and asset-registry integrity monitoring: track completion and ongoing integrity of the joint baseline physical inventory and cryptographic asset registry of covered equipment at all six declared sites, including reconciliation of serialized records against operator procurement, maintenance, and disposal records, and full recounts at any site with unexplained discrepancies.
**Monitoring Tools/Platforms:**

  - Cryptographic asset registry
  - Baseline inventory audit checklists
  - Serialized-record reconciliation tracker
  - Full-recount trigger log
  - Operator procurement, maintenance, and disposal records
  - Asset-registry tamper-evidence monitoring

**Frequency:** Continuous during the entry-condition phase until joint certification; quarterly spot-check integrity reviews thereafter

**Responsible Role:** Joint Program Management Office (JPMO) with technical validation by the Joint Technical Assurance Board (JTAB) and audit by the Joint Audit, Ethics, and Compliance Committee (JAECC)

**Adaptation Process:** JPMO conducts full recounts and reconciliation drills for any site with unexplained serialized discrepancies; JTAB validates asset-registry integrity processes; unresolved baseline discrepancies block certification of that site and escalate to the JSC; any suspected tampering with the asset registry is treated as an evidence-integrity incident.

**Adaptation Trigger:** Unreconciled serialized discrepancy above 2% at any site; disputed initial inventory at proposed clock start; evidence of tampering with the cryptographic asset registry; inability to establish a trusted baseline for subsequent material-change verification

# Governance Extra

## Governance Validation Checks

1. 1. Completeness confirmation: All core requested governance components are present and structurally complete: the internal governance bodies (JSC, JPMO, JTAB, JSCIB, JLTC, JAECC, JDAP), the implementation plan with sequenced formation steps and dependencies, the decision/escalation matrix, and the monitoring/progress plan are all generated. The audit details from Stage 1 are also carried through consistently into the JAECC responsibilities and monitoring approach.
2. 2. Internal consistency check: The governance bodies defined in Stage 2 are used consistently in the Stage 3 implementation plan and Stage 5 monitoring plan. Decision rights in the escalation matrix respect the double-key, no-casting-vote, no-unilateral-overrule principle, and the monitoring plan assigns responsibilities to the correct bodies (e.g., JTAB for KPI validation, JAECC for data-integrity audits, JDAP for discrepancy adjudication, JSCIB for security/counterintelligence, JLTC for legal/interpretive issues). No direct contradictions were found among the stages.
3. 3. Gap in JSC composition and continuity: The JSC consists only of the two national co-chairs and a non-voting secretary. There is no defined deputy/succession arrangement for a co-chair vacancy and no formal mechanism for independent technical, legal, or security advice to reach the JSC during a final verdict decision. Given the political-continuity risk, this is a single-point vulnerability that should be addressed with explicit succession rules and a defined advisory-input channel.
4. 4. Gap in automatic-suspension mechanics: The framework uses 'automatic suspension' and 'protective hold' frequently, but the operational mechanics are under-specified: who physically activates the suspension, how the site/operator is notified, what evidence must be preserved, how long the suspension lasts before JSC double-key confirmation, and what evidence is required to lift it. The JDAP temporary administrative hold mentions 48-hour JSC confirmation, but the full suspension lifecycle needs a single, detailed procedure.
5. 5. Gap in delegated authority granularity: JPMO has clear thresholds (USD 10M per action and USD 25M per envelope reallocation), but workstream leads are said to have 'delegated authority' without defined limits or parameters. The delegated authority register is still at version 0.1/0.2 in the implementation plan and should be finalized with specific dollar/action thresholds, approval matrices, and prohibited actions to prevent inconsistent or uncontrolled delegation.
6. 6. Gap in conflict-of-interest and whistleblower depth: The JAECC is tasked with conflict-of-interest rules and a whistleblower channel, but the framework lacks specific recusal rules for co-chairs and committee members with national or operator ties, investigation timelines, anonymous reporting mechanisms, retaliation protections, and escalation paths for complaints involving senior government officials. These details are essential for a bilateral program where each government administers domestic compensation.
7. 7. Gap in escalation-matrix coverage: The decision/escalation matrix covers budget, cyber incidents, deadlocks, protocol changes, material discrepancies, vendor refusal, KPI threshold changes, entry-condition slippage, information-barrier conflicts, and fraud. However, it omits explicit issue types for unresolved interpretive/legal disputes escalating from the JLTC, impaired-confidence declarations, funding delays or withholding that do not fit the budget-request category, and operator obstruction escalating to materiality. These should be added with defined escalation and response SLAs.
8. 8. Gap in red-team independence assurance: The JTAB selects independent red-team providers and monitors a no-advance-knowledge protocol, but there is no described independent verification of red-team separation from the JPMO, site operators, or the covered-equipment schedule custodians. Given the collusion risk identified in the audit corruption list, the monitoring approach should include independent audit of red-team communications, financial flows, and exercise-scenario secrecy.
9. 9. Gap in change-control process: Protocol changes, KPI threshold revisions, and information-barrier policy changes are reserved to the JSC, but no formal change-control process is defined. The framework lacks guidance on change initiation, impact assessment, emergency changes, versioning, communication to operators and vendors, and how changes are tested before implementation. This is especially important for mid-Phase One technical adjustments.
10. 10. Gap in KPI statistical validation methodology: Provisional thresholds such as 5% false negatives at 95% confidence are listed, but the validation plan does not yet specify sample sizes, statistical power calculations, pre-registration of the analysis plan, handling of multiple challenge types, or how confidence intervals will be computed from limited red-team exercise data. Without this methodology, the thresholds remain contestable and the Go/Modify/Stop verdict could be challenged.

## Tough Questions

1. What is the current probability-weighted forecast for completing all ten entry conditions by 2027-Sep-04, and what specific contingency actions and spending decisions are triggered if domestic access authority or site selection slips beyond the two-month pre-deadline daily tracking window? Show the readiness-tracker closure rates by country.
2. Provide evidence that the pre-registered deadlock procedure has been stress-tested in a simulated co-chair deadlock. What was the measured time to reach a joint decision or escalate, and what prevents an impaired-confidence declaration from becoming a unilateral suspension?
3. If a dominant vendor refuses clean-room access at multiple sites simultaneously, what is the exact unverifiable-equipment count and materiality definition at which JDAP automatically recommends suspension, and has the forced-evidence ladder been exercised end-to-end with that vendor? What is the projected time from first refusal to disposition?
4. What is the latest validated false-negative rate from independent blind challenges, with confidence intervals, after information-barrier filtering? Which substitution indicators survived filtering, and how does the result compare with the pre-registered 5% at 95% confidence threshold?
5. Has the joint baseline physical inventory and cryptographic asset registry been completed at all six sites? What is the current serialized-record discrepancy rate per site, and what is the remediation plan for any site above the 2% recount threshold?
6. Demonstrate that the 48-hour visa and customs clearance pathway actually works: what was the measured time from inspector request to site access in the latest end-to-end travel-and-clearance drill, and which diagnostic tools and challenge equipment were pre-cleared?
7. Show the escrow balance, envelope burn rates, and projected inspectorate costs under a six-month entry-condition delay. What specific drawdown decisions have been made to avoid idle staffing costs consuming the $750M inspectorate envelope, and how is reciprocal funding parity being maintained?
8. What binding continuity commitments and escrow-return provisions are in the bilateral instrument if either country experiences a leadership transition during the entry-condition phase? Have transition briefings and track-II channels been established, and what is the estimated sunk-cost exposure if one government withdraws?
9. What is the exact process and timeline for lifting an automatic site-level suspension once imposed? Who can authorize resumption under double-key without unilateral override, what evidence must be produced, and how are the Phase One clock and KPI dashboard adjusted for the suspension period?
10. How has the JAECC validated that KPI dashboard inputs are not being manipulated? Provide the raw-data provenance audit trail for the last reported false-negative and latency metrics, and describe the independent verification method used before any Go/Modify/Stop verdict.

## Summary

The governance framework is structurally sound and well aligned with the Consortium's double-key, no-unilateral-overrule mandate: the body architecture is complete, the implementation sequence is dependency-aware, the escalation matrix preserves sovereign equality, and the monitoring plan assigns clear ownership across operational, technical, security, legal, audit, and adjudication functions. Its key strengths are the separation of strategic, operational, technical, security, legal, audit, and adjudication authorities, and the integration of deadlock, suspension, and KPI-driven escalation into a single governance fabric. The main areas requiring further hardening are the operational mechanics of automatic suspension, JSC continuity and advisory inputs, granular delegated authority, conflict-of-interest and whistleblower enforcement, change control, red-team independence assurance, and statistical validation of the KPI thresholds that will ultimately determine the credibility of the Go/Modify/Stop verdict.