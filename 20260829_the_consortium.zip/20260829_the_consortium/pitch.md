Persuasive elevator pitch.

# From Faith to Verification: A U.S.–China Operational Test for Frontier AI

## Project Overview

What if the two most powerful nations on Earth could verify the world's most dangerous technology—not on faith, but through **double-keyed evidence**, **on-site inspection**, and **mutual accountability**? The Cold War proved adversaries can do exactly that. Now frontier AI presents a new strategic risk, and the United States and China have a once-in-a-generation chance to turn that risk into a shared system of verification.

This project builds a **$5 billion, jointly governed 90-day Phase One operational test** to verify material changes to frontier-relevant computing equipment at six matched datacenters—three in each country—using layered physical and digital evidence, a tamper-evident ledger, bounded information barriers, and live red-team challenges.

It is deliberately narrow: no workload inspection, no model-weight exposure, no hidden-facility discovery. Only declared-equipment changes. The result is a defensible **Go, Modify, or Stop** verdict grounded in reciprocal access and credible detection. This is not arms-control nostalgia. It is the first practical verification architecture for frontier AI—and it will determine whether two sovereign rivals can turn a shared existential challenge into a shared system of trust.

## Why This Pitch Works

This project is framed as a **strategic necessity** rather than a commercial venture. It opens with a bold, historically resonant hook—adversaries verifying dangerous technology—then immediately clarifies the project's narrow, achievable scope. It respects sovereignty by emphasizing **double-key governance**, bounded information barriers, and no unilateral overreach.

The pitch appeals to national-security values with concrete operational details: layered evidence, live challenges, tamper-evident ledgers, and a clear Go/Modify/Stop verdict. The tone is confident and disciplined, matching the expectations of government and national-security stakeholders. It also connects the project to a broader narrative: two rivals proving they can manage frontier AI risk together without compromising their core interests.

## Target Audience

This initiative is aimed at:

- U.S. and Chinese government decision-makers
- National-security and arms-control agencies
- Appropriations committees and legislatures
- Datacenter operators and equipment vendors at declared sites
- The broader verification and international-security community

It is also relevant to **technical institutions**, independent red teams, and clean-room examination bodies that would partner in design and execution.

## Call to Action

Now is the time to move from concept to commitment. We call on both governments to endorse the bilateral instrument, complete the mandatory entry-condition phase by **September 2027**, appropriate and pre-fund the **$5 billion escrow**, and direct their verification, legal, and technical teams to engage the joint secretariat.

We invite participating operators and vendors to sign model access agreements, and we ask independent laboratories, red teams, and verification experts to join the live exercise program and help validate the systems before the clock starts.

## Risks and Mitigation Strategies

This project is high-risk by design, but every major risk has a deliberate mitigation:

- **Entry-condition delay** is addressed by an integrated readiness tracker and leadership escalation.
- **Vendor refusal** is contained by a forced-evidence ladder, clean-room examiners, and cross-trained inspectors.
- **Information barriers** are validated in blind challenges to prevent both over-filtering and under-filtering.
- **Double-key deadlock** is resolved through joint technical teams, advisory arbitration, and tightly scoped automatic suspension.
- **Political discontinuity** is met with continuity commitments, transition briefings, and a public KPI dashboard.
- **Fiscal delay** cannot become a quiet veto because escrow pre-funding or a KPI-visible delay trigger is built in.

Because verification cannot outrun politics, the design keeps both governments invested in the system's **credibility and reciprocity**.

## Metrics for Success

Success is measured by demonstrated operational performance, not just a verdict:

- False-negative rate no greater than **5%** in blind challenges at 95% confidence
- Event-recording latency under **5 minutes** locally
- Cross-national synchronization within **1 hour**
- Divergence reconciliation within **24 hours**
- Unresolved material discrepancy age no greater than **10 business days**
- Unverifiable equipment no more than **2 units per site** or 1% of covered changes
- Demonstrated reciprocal access parity
- Zero unresolved ledger divergence
- A joint written Go/Modify/Stop decision accepted by both co-chairs

These metrics ensure the verdict is **evidence-based, not diplomatic**.

## Stakeholder Benefits

Governments gain a credible, bilateral mechanism to reduce frontier AI risk without intrusive comprehensive governance. Operators and vendors gain predictable rules, fair domestically administered compensation, and protection of proprietary information through clean-room and filtered-evidence protocols.

Legislatures gain strict fiscal accountability, envelope-coded budgets, and transparent KPI dashboards. The verification community gains a live, high-stakes testbed for information barriers, tamper-evident ledgers, and joint inspection methods. Most importantly, the public gains a tangible demonstration that two great powers can manage existential technology responsibly.

## Ethical Considerations

The project is built on **ethical and legal discipline**: scope is limited to declared-equipment change verification; no unilateral findings or sanctions are permitted; all suspension and sanction decisions require double-key approval.

Information barriers protect workloads, customer data, model weights, source code, and trade secrets. Independent red teams and pre-registered thresholds prevent the appearance of rigged outcomes. The project explicitly avoids hidden-facility discovery and comprehensive AI governance, stating honestly what it can and cannot verify. This is **verification with consent, accountability, and mutual respect for sovereignty**.

## Collaboration Opportunities

We welcome collaboration with:

- National laboratories
- IAEA and CTBTO verification veterans
- Independent clean-room examiners
- Red-team and penetration-testing firms
- Academic verification researchers
- Track-II dialogue channels

Participating datacenter operators and equipment manufacturers can help shape model access agreements and inspection workflows. International organizations can contribute lessons from decades of safeguards and on-site inspection practice. Every partner will help turn this from a technical concept into a living, tested system.

## Long-term Vision

This project is the first step toward a sustained U.S.–China verification community. A successful Phase One can expand to additional declared sites, deepen the inspectorate, and create a reusable architecture for verifying other strategic technologies.

It can build a two-sided culture of **evidence, reciprocity, and conflict prevention**—transforming the frontier AI race from a blind competition into a managed contest. The broader vision is not just a 90-day test, but a durable bilateral institution that outlasts political cycles and makes the world safer by making verification normal between rivals.