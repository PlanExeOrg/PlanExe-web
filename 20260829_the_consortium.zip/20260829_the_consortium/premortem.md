A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Both governments will sustain political backing and domestic legal authority through the 12-month entry-condition phase and the 90-day Phase One clock, including appropriations, escrow pre-funding, and operator/vendor compulsion, across any leadership transitions. | Convene the joint legal task force immediately and obtain signed, binding legal opinions from the U.S. State Department/DOJ and Chinese MOFA/legislative-affairs bodies on treaty form, domestic access authority, escrow legality, and data transfer; negotiate and table model continuity clauses and transition-briefing requirements before the 2026-12-18 milestone. | Either government fails to provide a formal legal opinion by 2026-12-18, or a leadership transition, appropriations rider, or ministerial directive voids the escrow pre-funding commitment before 2027-09-04. |
| A2 | All covered equipment at the six declared sites can be physically inventoried, serialized, and reconciled from operator records into a cryptographic asset registry with no more than 2% unexplained serialized discrepancy before the Phase One clock starts. | Stand up the joint baseline inventory task force and execute a pilot physical inventory at one matched site pair using actual operator procurement and maintenance records, synthetic reconciliation runs, and dual-national serialization checks; measure reconciliation time and discrepancy rates against the 2% threshold. | The pilot inventory reveals unexplained serialized discrepancy greater than 2% at either site, or reconciliation of a single site takes more than 8 weeks, demonstrating that the six-site baseline cannot be certified within the entry-condition window. |
| A3 | A 90-day, six-site test can generate enough independent blind challenge events per material-event category to substantiate a false-negative rate no greater than 5% at 95% confidence, and both governments will accept a pre-registered statistical analysis plan. | Commission an independent verification statistician to produce a Test and Evaluation Master Plan with power analysis, event-count requirements per category, confidence-interval formulas, unresolved-event handling, and a 90-day challenge schedule simulation; obtain double-key approval of the pre-registered analysis rules. | Power analysis shows that more than 60 independent challenge events per material-event category are required and the 90-day, six-site schedule cannot support them, or either government refuses to pre-register the analysis rules before operational data are collected. |
| A4 | The information-barrier filter rules can be designed and validated so that substitution-detection sensitivity in blind challenges stays within 10% of the unfiltered baseline while zero evidence-integrity-compromising leaks occur. | Build a filtered workstation prototype and run at least two blind challenge sets with synthetic workloads and injected substitutions through both filtered and unfiltered evidence channels before 2027-06-30, measuring detection sensitivity and metadata survival. | Detection sensitivity with filtered evidence falls more than 10 percentage points below the unfiltered baseline, or any leaked workload, model-weight, source-code, or network-topology field appears in inspector-visible output during blind challenges. |
| A5 | At least 90% of vendors serving declared sites will sign model vendor-access agreements before the Phase One clock starts, and clean-room examination by accredited independent examiners can verify equipment identity to the 99% confidence target without exposing proprietary source code. | Conduct structured interviews with the top three vendors serving each declared site and execute two live vendor-refusal challenge exercises by 2027-05-31, measuring time-to-disposition through the forced-evidence ladder. | Signed model vendor-access agreements cover less than 90% of vendors serving declared sites by 2027-05-31, or any vendor-refusal challenge takes more than 14 days to disposition through clean-room examination. |
| A6 | The approximately 450 FTE mirrored inspectorate can be recruited, security-cleared within 12 months, and trained with no single-person critical functions inside the $750M inspectorate envelope without requiring contingency drawdown. | Start security clearances for all candidates immediately and run a workforce optimization model using actual clearance lead times and bilingual talent availability; validate in a staffing tabletop exercise that no critical function is single-person by 2027-07-31. | Clearance or recruitment fills less than 90% of required FTE by 2027-07-31, the staffing tabletop identifies more than five single-person critical functions, or the inspectorate envelope requires more than $75M in premium costs. |
| A7 | A multi-attribute parity matrix can calibrate six matched sites so that reciprocal access-hours ratios remain within the 0.9–1.1 tolerance band in live benchmarking drills, and deliberately dissimilar stress sites do not make parity negotiation impossible. | Approve the multi-attribute parity matrix by 2027-04-30 and execute reciprocal access benchmarking drills at two matched site pairs within 30 days, measuring access hours and inspection outcomes for each pair. | Access-hours ratio falls outside 0.9–1.1 for either benchmarked matched pair, or stress-site inspection difficulty scores differ by more than 20% from the paired site using the approved parity matrix. |
| A8 | The replicated tamper-evident ledger can achieve 99th-percentile local event recording under 5 minutes, cross-national synchronization under 1 hour, and divergence reconciliation under 24 hours under realistic cross-border network conditions and adversarial fault injection. | Deploy a prototype with two national nodes and inject 5,000 synthetic events with network partitions, node failures, and tamper attempts; measure latency percentiles and reconciliation times under each failure scenario. | 99th-percentile local recording exceeds 7 minutes, synchronization exceeds 2 hours, or divergence reconciliation exceeds 24 hours in any injected failure scenario. |
| A9 | The double-key deadlock machinery, including joint technical teams, advisory arbitration, and object automatic-suspension triggers, can resolve routine discrepancies within 10 business days and automatic suspension cannot be blocked by a co-chair's materiality dispute. | Run three governance war-games with both national legal teams covering deadlocked factual findings, manufactured discrepancies, and vendor refusal scenarios, measuring deadlock resolution time and whether automatic triggers fire without co-chair approval. | Any war-game deadlock remains unresolved after 10 business days, or any tabletop participant can block an automatic suspension trigger by disputing materiality. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Empty Escrow: How a Quiet Veto Killed the Clock | Process/Financial | A1 | Fiscal Escrow and Independent Audit Controller | CRITICAL (20/25) |
| FM2 | The Baseline Mirage: When 50,000 Serial Numbers Lied | Technical/Logistical | A2 | Hardware Identity and Evidence Integrity Technical Lead | CRITICAL (20/25) |
| FM3 | The Confidence Collapse: When the Numbers Became a Negotiation | Market/Human | A3 | Political Continuity and Government Liaison Lead | CRITICAL (20/25) |
| FM4 | The Blind Spot in the Filter | Technical/Logistical | A4 | Information Barrier and Counterintelligence Security Director | CRITICAL (20/25) |
| FM5 | The Vendor's Veto | Market/Human | A5 | Operator and Vendor Compliance Liaison | CRITICAL (20/25) |
| FM6 | The Clearance Chasm | Process/Financial | A6 | Mirrored Inspectorate Operations Director | CRITICAL (20/25) |
| FM7 | The Deadlock Machine | Process/Financial | A9 | Bilateral Governance and Legal Implementation Lead | CRITICAL (20/25) |
| FM8 | The Silent Ledger | Technical/Logistical | A8 | Hardware Identity and Evidence Integrity Technical Lead | CRITICAL (15/25) |
| FM9 | The Paper Parity | Market/Human | A7 | Datacenter Site Preparation and Cross-Border Logistics Manager | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Empty Escrow: How a Quiet Veto Killed the Clock

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Fiscal Escrow and Independent Audit Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase One never starts. The causal chain begins with an unexamined belief that both governments' political commitment is durable. By October 2026, the joint legal task force has not obtained binding legal opinions because the U.S. Congress refuses to pre-fund escrow before a Government Accountability Office study, and China's MOFA conditions escrow participation on resolution of a bilateral trade dispute. A leadership transition in one country replaces the lead negotiator, and the continuity clause is still only a draft. The 12-month entry-condition clock burns while 450 FTE are hired against an expected start; $7.5M per month of idle inspectorate costs drains the contingency.

The 10-business-day contribution-delay trigger fires, but because the trigger was designed to be KPI-visible rather than self-executing, it only produces a dashboard alert that leadership declines to escalate. By 2027-09-04, only one $2.5B contribution sits in escrow; the other side cites 'technical legal review.' The co-chairs deadlock over whether to start the clock with asymmetric funding. The process failure is not a single dramatic decision; it is slow erosion through appropriations riders, legal opinions, and a quiet veto disguised as administrative delay.

The financial impact compounds: $300M in site preparation is already spent, the surge cadre must be stood down, and the contingency envelope is consumed by idle salaries and legal fees before a single blind challenge is executed. The program does not die from a spectacular breach; it dies from a funding process that was never legally secured.

##### Early Warning Signs
- Signed legal opinions from either government remain outstanding after 2026-12-18
- Escrow balance is below $5B at any quarterly reconciliation before 2027-09-04
- Any national contribution release exceeds the 10-business-day funding-timeliness threshold
- Entry-condition certification percentage drops below 100% at the 2027-08-01 readiness review

##### Tripwires
- Escrow balance < $5B at 2027-08-01
- Contribution delay > 10 business days on two consecutive quarterly reconciliations
- Signed legal opinions from either government not obtained by 2026-12-18

##### Response Playbook
- Contain: Freeze all new drawdowns and halt inspectorate hiring until escrow pre-funding is jointly certified.
- Assess: Conduct a joint fiscal and legal audit within 14 days to quantify the funding gap, idle staffing costs, and unresolved legal barriers.
- Respond: Escalate to heads of state for a binding 30-day pre-funding deadline or activate the milestone-tranche fallback with automatic suspension triggers.


**STOP RULE:** If either government's contribution is not deposited in escrow within 60 days after the 10-business-day delay trigger fires and heads-of-state escalation fails, cancel Phase One and begin escrow-return procedures.

---

#### FM2 - The Baseline Mirage: When 50,000 Serial Numbers Lied

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Hardware Identity and Evidence Integrity Technical Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The 90-day clock starts with a registry that is a work of fiction. At the Langfang site, the baseline task force trusted operator spreadsheets for 18,000 units because the alternative was delaying certification. Guizhou's humidity damaged 212 RFID tags, but they were marked 'visually confirmed' to meet the 2% threshold. At Ashburn, 1,560 legacy racks had no serialized record; the task force assigned temporary identifiers and called the inventory 'reconciled pending.' The cryptographic asset registry hashes these fake entries.

During the second week of Phase One, a red team substitutes a retired GPU server with a visually identical third-party unit, alters its asset tag to match the registry, and records a false 'maintenance event.' The inspector's scanner reads the tag, the ledger creates a hash-chain entry, and the event is marked verified because the baseline itself is wrong. The false-negative rate is not caused by a detection failure; it is caused by the registry telling the inspectors that the wrong equipment is the right equipment.

When the true inventory audit is repeated after a suspicious discrepancy, 6.5% of covered units fail to match, and 4 of the 19 blind challenges were 'detected' only because they happened to be in areas without tag damage. The technical and logistical system did not fail during verification; it failed before verification began, because the assumption that all covered equipment could be inventoried and reconciled was never tested against real site conditions.

##### Early Warning Signs
- Any site reports unexplained serialized discrepancy greater than 2% during baseline reconciliation
- Temporary identifiers are used for more than 1% of covered units at any declared site
- Operator procurement or maintenance records are missing or unavailable for more than 5% of covered units
- Environmental tag or RFID failure rate exceeds 3% during site surveys

##### Tripwires
- Unexplained serialized discrepancy > 2% at any site after the initial physical inventory
- Reconciliation time > 8 weeks for any single declared site
- Temporary identifiers assigned to > 1% of covered units at any site

##### Response Playbook
- Contain: Halt the Phase One clock and suspend material-change verification until affected sites' registries are recertified.
- Assess: Commission an independent physical recount of any site with > 2% discrepancy and quantify the contamination of the cryptographic asset registry.
- Respond: Rebaseline the registry through a joint physical audit and re-run pilot blind challenges before restarting the clock.


**STOP RULE:** If any site's unexplained discrepancy exceeds 5% after a full recount, or if a false verification is traced to baseline registry error, cancel Phase One and require a complete rebuild of the cryptographic asset registry before any restart.

---

#### FM3 - The Confidence Collapse: When the Numbers Became a Negotiation

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Political Continuity and Government Liaison Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The first sign of trouble is a press release, not a ledger alert. The red team had injected only 23 unannounced arrival challenges across six sites because operators resisted disruptions and two sites had maintenance windows. The pre-registered master plan was never approved; thresholds were marked TBD. At the verdict, the U.S. side claims 2 misses out of 23 = 8.7% false-negative rate, above 5%. The Chinese side computes 2 misses out of 31 observed material events = 6.5%, and claims the tests are not independent. The co-chairs cannot agree because there is no jointly owned denominator.

The debate leaks to a congressional hearing and a Chinese state media commentary. Legislatures interpret the dispute as evidence that the project is political, not technical. The verification community, which is the only 'market' that can certify credibility, withholds endorsement; VERTIC and IPNDV decline to validate the results. Track-II partners distance themselves. Neither government wants to be seen as losing the narrative competition, so each amplifies its own statistic.

The Go/Modify/Stop verdict becomes a negotiation, and the final 'Modify' is accepted only because it is the least embarrassing option. The program survives in name but has lost the market for trust: no legislature will fund Phase Two, and the public sees the $5B program as an expensive argument over math. The human failure is not malice; it is the absence of a pre-registered, statistically defensible claim that both sides had already agreed to accept.

##### Early Warning Signs
- Number of independent blind challenge events per material-event category is below 60 by day 80 of Phase One
- Two or more public official statements cite conflicting false-negative denominators or confidence intervals
- Pre-registered Test and Evaluation Master Plan is not approved by 2027-03-31
- Pilot blind challenge results show an upper 95% confidence bound above 5% for false-negative rate

##### Tripwires
- Independent blind challenge events < 60 per material-event category by day 80
- No jointly approved Test and Evaluation Master Plan by 2027-03-31
- Public statements by either government offering conflicting false-negative calculations

##### Response Playbook
- Contain: Stop all public KPI reporting and freeze verdict commentary until one joint statistical statement is issued.
- Assess: Convene independent verification statisticians to audit the full challenge dataset and produce a single agreed confidence interval within 10 business days.
- Respond: Adopt the audited numbers in a joint public statement and pre-register all future thresholds and analysis rules before any continuation.


**STOP RULE:** If the two governments cannot agree on a single false-negative estimate and confidence interval within 20 business days after the independent audit, issue a Stop verdict and do not proceed to Phase Two.

---

#### FM4 - The Blind Spot in the Filter

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Information Barrier and Counterintelligence Security Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
During pilot blind challenges in June 2027, the filtered workstations stripped far more than the approved fields. Rack position, adjacent equipment serials, power-draw signatures, and vendor-specific firmware strings were removed because a junior engineer configured the rules with a broad keyword blacklist. Inspectors staring at the filtered screens saw only clean serial numbers and cryptographic hashes. The system appeared to protect sensitive data perfectly, but it had also removed the contextual metadata that would have exposed a substitution.

The red team learned this within two weeks. They substituted a GPU with a cryptographically valid attestation that matched the registry, but the physical unit had a different thermal fingerprint and a 3% power-consumption variance. Unfiltered inspection caught it easily; filtered inspection flagged nothing because the thermal and power data were in the redacted layer. The measured detection sensitivity on filtered evidence was 62% versus 94% on unfiltered evidence, a 32-point gap that shattered the 10-point tolerance. At the same time, another site discovered that a cached memory fragment containing workload identifiers had survived the filter on one workstation, proving the barrier could also fail in the other direction.

The impact was immediate and compound. The pilot blind challenges were invalidated, the information-barrier rule set was quarantined, and every KPI computed from filtered evidence became contestable. The co-chairs could not agree on whether the system was too aggressive or too permissive, so the clock kept running while engineers tried to re-version the rules. The fundamental assumption turned out to be false: the barrier could not be calibrated to preserve the evidence inspectors needed without leaking the data they were sworn to protect.

##### Early Warning Signs
- Filtered-vs-unfiltered detection sensitivity gap reaches or exceeds 10 percentage points in any pilot blind challenge
- Any protected field, including workload identifiers or source-code fragments, appears in filtered output during validation
- Filter-rule change requests exceed five per month during Phase One
- Metadata survival rate for serial numbers and contextual indicators falls below 95% after filtering

##### Tripwires
- Filtered detection sensitivity < 85% of unfiltered baseline in any blind challenge
- Any leak of protected data detected during validation or operations
- Metadata survival rate for identity-critical fields < 95% after filtering

##### Response Playbook
- Contain: Suspend evidence collection through filtered workstations and quarantine all affected challenge results immediately.
- Assess: Launch a joint technical review within 48 hours to identify which filter rules stripped substitution indicators and whether any protected data was exposed.
- Respond: Re-version and re-validate the filter rules in a new blind challenge set before resuming Phase One; if a confirmed leak occurred, activate the joint cyber-incident isolation protocol.


**STOP RULE:** If any confirmed evidence-integrity-compromising leak occurs, or if filtered detection sensitivity cannot be brought within 10% of the unfiltered baseline after two re-validation cycles, cancel Phase One.

---

#### FM5 - The Vendor's Veto

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Operator and Vendor Compliance Liaison
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
By the end of May 2027, only 61% of vendors serving the declared sites had signed model access agreements. The most critical holdout was a dominant accelerator vendor whose equipment represented 70% of covered changes at three matched sites. The vendor cited export-control restrictions and the risk of reverse engineering from clean-room examination. Legal teams argued that domestic access authority compelled participation, but the vendor's lawyers found jurisdictional gaps and the operator was reluctant to enforce the contract against its most important supplier.

The forced-evidence ladder was designed to handle exactly this situation, but each rung absorbed days and produced no verification. Vendor-supervised testing was declined. Clean-room examination was blocked because the vendor refused to ship reference equipment. The accredited independent examiner was denied physical access by the operator, who claimed the inspection would breach the vendor's trade-secret agreement. With each refusal, the unverifiable-equipment count climbed: three units at one site, five at another. The 2-unit per-site threshold was breached within two weeks.

Instead of triggering automatic suspension, the refusal became a political event. The vendor's trade association launched a public campaign warning that foreign inspectors could steal U.S. intellectual property, and a congressional delegation demanded a pause in Phase One. The Chinese co-chair saw the pause as unilateral shielding. The other operators, watching the dominant vendor succeed, began refusing minor access requests. The entire verification boundary collapsed not through a technical failure, but through the belief that one economically powerful vendor could veto the regime.

##### Early Warning Signs
- Signed vendor-access agreements cover less than 90% of vendors serving declared sites by 2027-05-31
- Any vendor-refusal challenge exceeds 14 days to reach disposition
- Unverifiable equipment count exceeds 2 units at any single site during Phase One
- Public statements or lobbying campaigns by vendor trade associations opposing clean-room examination

##### Tripwires
- Vendor agreements signed < 90% by 2027-05-31
- Any vendor refusal unresolved after 14 days
- Unverifiable equipment > 2 units at any single site

##### Response Playbook
- Contain: Freeze equipment movement at affected sites and invoke operator contractual site-eligibility obligations to compel access.
- Assess: Review forced-evidence ladder outcomes and quantify contagion risk across all sites served by the refusing vendor within 5 business days.
- Respond: Escalate to vendor CEO and government leadership, pre-accredit additional independent examiners, and if refusal persists, classify affected equipment as a material discrepancy and trigger automatic suspension.


**STOP RULE:** If a single dominant vendor's refusal causes unverifiable equipment to exceed the per-site threshold at two or more sites simultaneously, issue a Stop verdict for Phase One.

---

#### FM6 - The Clearance Chasm

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Mirrored Inspectorate Operations Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
In March 2027, a workforce audit showed that only 180 of the required 450 FTE had completed security clearances. The projected clearance timeline for the remaining candidates had stretched to 16 months, far beyond the 12-month entry-condition window. Bilingual hardware engineers were scarce; recruitment drives in both countries yielded fewer than half the required applicants. To maintain the appearance of readiness, site commanders began assigning single-person critical functions in direct violation of the separation-of-duties rule. The plan's own staffing model had been validated on paper, but never against real clearance pipelines.

The co-chairs faced an impossible choice. Delaying the clock meant admitting the 2027-09-04 certification deadline was fictional. Starting the clock with an understaffed inspectorate meant every material event could be invalidated by a single absence. They chose to start anyway after the Chinese side accepted an interim certification. Three weeks into Phase One, the lead hardware inspector at the Ashburn site contracted a serious illness. No cleared backup existed for the identity-gate function. A scheduled substitution challenge went unwitnessed, the evidence chain broke, and the event was marked as unresolved.

The financial damage was equally severe. To fill gaps, the program paid premium rates for temporary contractors and expedited clearances, draining the $750M inspectorate envelope at a rate of $58M per month. The contingency envelope was tapped by day 45, and the Morale among the cleared inspectors collapsed as they were forced to work double shifts with no backup. The reciprocal parity metric failed because one side had 90% staffing and the other only 64%. The program did not die from a single technical failure; it suffocated under a staffing model that was never validated against the real clearance system.

##### Early Warning Signs
- Cleared FTE remains below 90% of the 450 requirement by 2027-07-31
- Security clearance lead time exceeds 15 months for any critical role
- Single-person critical functions identified in staffing tabletop exercises exceed five
- Inspectorate envelope burn rate exceeds $50M per month for three consecutive months before Phase One

##### Tripwires
- Cleared FTE < 90% by 2027-07-31
- Single-person critical functions > 5 in final tabletop validation
- Inspectorate envelope burn rate > $50M per month for 3 consecutive months

##### Response Playbook
- Contain: Stop the Phase One clock and prohibit any material-event verification until every critical function has a trained and cleared backup.
- Assess: Run an independent staffing and clearance audit within 14 days to quantify the gap, premium costs, and impact on reciprocal parity.
- Respond: Request a jointly agreed 3–6 month bridge extension funded from the contingency envelope and second cleared personnel from existing national verification bodies to close the gap.


**STOP RULE:** If cleared FTE remains below 90% after a 6-month bridge extension, or the inspectorate envelope exceeds its cap before Phase One completes, cancel the program.

---

#### FM7 - The Deadlock Machine

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Bilateral Governance and Legal Implementation Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Phase One opened with 100% certified entry conditions, but the governance machinery was never tested against a co-chair determined to stall. On Day 12, the Chinese co-chair disputed the materiality of a serial-number mismatch at an American site, arguing the term 'material discrepancy' in the bilingual glossary required evidence of operational impact. The U.S. co-chair disagreed, citing the pre-registered interpretive annex. The joint technical team had already documented the mismatch, but under the double-key rules, the finding could not be classified as material without co-chair approval.

The 10-business-day deadlock clock started. On Day 9, the Chinese co-chair requested a second advisory arbitration on the definition of 'material,' even though the glossary froze the term before the clock started. The jointly selected arbiter issued an advisory finding on Day 14, but the Chinese co-chair rejected it as non-binding. Meanwhile, the affected site was placed on technical hold, freezing all equipment movement. Operators lost confidence in the process and began filing their own interpretive disputes, exploiting the same ambiguity.

By Day 30, five material findings were deadlocked. The automatic suspension trigger for the original mismatch was never activated because the trigger was conditioned on a co-chair finding of materiality. The KPI dashboard showed 100% of automatic triggers 'pending materiality determination.' The 90-day clock was not consumed by detection failures; it was consumed by the process designed to prevent unilateral overrule. The financial impact was severe: the inconclusive verdict forced a Modify recommendation, but the two governments could not agree on what to modify, leaving the $5B program in a state of permanent limbo.

##### Early Warning Signs
- Any materiality dispute or deadlock remains unresolved after 10 business days
- More than two interpretive dispute pre-registrations are filed during the first 30 days of Phase One
- Automatic suspension triggers are recorded as 'pending materiality determination' for more than 5 consecutive business days
- Joint technical team findings are retroactively contested by either co-chair after initial acceptance

##### Tripwires
- Deadlock age > 10 business days for any material finding
- Automatic suspension trigger pending materiality > 5 business days
- Interpretive disputes filed > 2 in first 30 days of Phase One

##### Response Playbook
- Contain: Freeze the disputed site's equipment movement and preserve all evidence while escalating the deadlock to leadership.
- Assess: Convene the joint legal task force within 48 hours to issue an interpretation of the pre-registered glossary and determine whether the deadlock is genuine or manufactured.
- Respond: Activate the pre-registered arbitration and leadership escalation path; if automatic triggers remain blocked for more than 20 days, issue a Stop verdict for the affected site.


**STOP RULE:** If any co-chair blocks an automatic suspension trigger for more than 20 business days or any material finding remains deadlocked after leadership escalation, cancel Phase One and treat the regime as non-functional.

---

#### FM8 - The Silent Ledger

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Hardware Identity and Evidence Integrity Technical Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The ledger prototype had passed validation with 5,000 synthetic events, but the cross-border network path between the Ashburn and Langfang nodes degraded during Phase One's third week. A fiber cut caused a 4-hour network partition that the automated divergent-alert system failed to surface because the divergence threshold was set to 24 hours. During the partition, a red team staged an unreported arrival at a Guizhou site. The local node recorded the event in 3 minutes, but the change did not synchronize. When connectivity returned, an automated reconciliation process merged the records, and the divergent event was silently absorbed into the national copy without triggering a human review.

A month later, a routine audit compared the physical equipment at the Guizhou site against the ledger. The unreported arrival was found, but the ledger contained no record of the 4-hour partition because the divergence had been auto-reconciled. The event-recording latency metric showed 3 minutes, the sync metric showed 45 minutes, and the divergence reconciliation metric showed 10 hours—all within KPI tolerance. But the silent window during the partition remained unknown to the operators, providing a 4-hour concealment corridor exactly where the red team needed it.

The blind-challenge detection rate for unreported arrivals fell to 71%, below the 95% target. The verification team investigated and discovered that the auto-reconciliation algorithm had been calibrated to prefer local records during network partitions, creating a systematic bias. The ledger had not failed in a dramatic way; it had failed quietly, by masking the divergence it was designed to expose. The material-event latency budget was a fiction because the ledger's synchronization process could not distinguish 'healthy merging' from 'silent divergence.'

##### Early Warning Signs
- Ledger divergence alerts are automatically resolved without human review in more than 5% of events
- Network partition or connectivity loss events exceeding 30 minutes occur more than twice in a 7-day period
- Reconciliation logs show no divergence incidents while red-team challenges reveal hidden arrivals
- Blind-challenge detection rate for unreported arrivals falls below 90% for any week

##### Tripwires
- Divergence alerts auto-resolved > 5% of events
- Network partitions > 30 minutes occur > 2 times in 7 days
- Unreported-arrival detection rate < 90% for any week

##### Response Playbook
- Contain: Halt all ledger-based verification and require manual review of every divergence alert and reconciliation until the auto-merge algorithm is quarantined.
- Assess: Conduct a forensic analysis of all reconciliation logs and network events to quantify the duration and impact of silent windows during the partition.
- Respond: Re-version the reconciliation algorithm to require human sign-off on any merge involving a detected divergence and run fault-injection drills to verify the fix.


**STOP RULE:** If forensic analysis reveals any undetected silent window exceeding the 4-hour operator-reporting threshold, or if unreported-arrival detection remains below 90% after corrective action, issue a Stop verdict.

---

#### FM9 - The Paper Parity

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Datacenter Site Preparation and Cross-Border Logistics Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The parity matrix was approved in April 2027 after two workshops, but the data were largely drawn from operator self-assessments. The Langfang site was rated 'easy access' with a 451-person equivalent inspection burden, while its matched pair in Northern Virginia was rated 'medium difficulty' due to its sprawling campus. The calibration committee accepted the ratings because the alternative was reopening the site-selection negotiation. Live benchmarking drills were scheduled for May but were postponed twice due to 'scheduling conflicts' at the American site.

When the drills finally ran in June, the results were stark. The U.S. team at the Langfang site completed its inspection cycle in 22 hours, while the Chinese team at the Ashburn site needed 41 hours. The access-hours ratio was 0.54, far outside the 0.9–1.1 tolerance. The difficulty was not caused by deliberate obstruction; the Ashburn facility had a security checkpoint, a 15-minute escort rotation, and a clean-room entry procedure that consumed 6 hours. The Langfang site had a single access corridor and pre-staged evidence tables. The parity matrix had weighted equipment value and operational role but not physical layout or vendor ecology, which turned out to be the dominant drivers.

The asymmetric-access Stop condition should have triggered automatically. Instead, the U.S. co-chair argued that the ratio was a random artifact of an unrepresentative drill and proposed a re-run with adjusted procedures. The Chinese co-chair, equally invested in protecting the Langfang site from scrutiny, agreed to quietly postpone the formal determination. Benchmarks were repeated four times with different inspectors and different scenarios, but the ratio never exceeded 0.72. The public KPI dashboard reported 'reciprocal access in progress,' and the verdict process became a diplomatic exercise in explaining why the numbers did not mean what they meant.

##### Early Warning Signs
- Access-hours ratio for any matched pair falls below 0.9 or above 1.1 in any benchmarking drill
- Drill completion time differs by more than 50% between matched sites
- More than three benchmarking re-runs are requested for the same matched pair
- Site survey data are based on operator self-assessment without independent physical verification

##### Tripwires
- Access-hours ratio < 0.9 or > 1.1 in any benchmark drill
- Drill time difference > 50% between matched sites
- Benchmark re-runs > 3 for same pair

##### Response Playbook
- Contain: Suspend all reciprocal access benchmarking and declare a parity investigation for the affected matched pairs.
- Assess: Conduct independent physical surveys of all six sites to recalculate parity based on actual layout, security processes, and vendor constraints within 21 days.
- Respond: Renegotiate the matched-site set or adjust the tolerance band only after the independent survey, then re-run benchmarking drills before resuming Phase One.


**STOP RULE:** If independent surveys confirm that any matched pair cannot achieve an access-hours ratio within the 0.9–1.1 band after renegotiation, cancel Phase One and require a new site-selection process.
