A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The supply chain is stable and will not face disruptions. | Identify multiple suppliers and establish contingency plans. | Any supply chain disruption causing delays exceeding 1 month. |
| A2 | Geopolitical relations between the U.S. and China will remain stable throughout the project. | Monitor geopolitical developments and establish a diplomatic advisory group. | Any significant geopolitical event leading to project delays exceeding 6 months. |
| A3 | Public opposition to the project will be minimal. | Conduct community sentiment analysis through surveys and public forums. | Any significant public protests or negative sentiment leading to project delays exceeding 2 months. |
| A4 | The technology required for the project will be readily available and compatible with existing systems. | Conduct a technology readiness assessment to evaluate availability and compatibility. | Any significant delays in technology availability or compatibility issues identified during assessments. |
| A5 | All stakeholders will remain committed and engaged throughout the project duration. | Implement regular stakeholder engagement surveys to gauge commitment levels. | Any significant drop in stakeholder engagement or commitment leading to project delays. |
| A6 | The project will receive continuous political support from both the U.S. and Chinese governments. | Monitor political statements and actions from both governments regarding the project. | Any public withdrawal of support or significant policy changes affecting project funding. |
| A7 | The project will have access to sufficient technical expertise from both nations. | Conduct a skills assessment to identify gaps in technical expertise among team members. | Any significant shortage of qualified personnel leading to project delays. |
| A8 | The legal frameworks governing the project will be clear and enforceable. | Review existing legal agreements and consult with legal experts to identify potential ambiguities. | Any legal disputes or ambiguities that lead to project delays or compliance issues. |
| A9 | The project will be able to effectively manage and integrate diverse cultural perspectives from both nations. | Implement cultural competency training for all team members and assess its effectiveness through feedback surveys. | Any significant cultural misunderstandings leading to conflicts or project inefficiencies. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Supply Chain Collapse | Process/Financial | A1 | Logistics and Supply Chain Manager | CRITICAL (20/25) |
| FM2 | The Geopolitical Standoff | Technical/Logistical | A2 | Project Governance Specialist | CRITICAL (25/25) |
| FM3 | The Public Backlash | Market/Human | A3 | Public Relations Coordinator | CRITICAL (16/25) |
| FM4 | The Supply Chain Collapse | Process/Financial | A1 | Logistics and Supply Chain Manager | CRITICAL (20/25) |
| FM5 | The Geopolitical Standoff | Technical/Logistical | A2 | Project Governance Specialist | CRITICAL (25/25) |
| FM6 | The Public Backlash | Market/Human | A3 | Public Relations Coordinator | CRITICAL (16/25) |
| FM7 | The Supply Chain Collapse | Process/Financial | A1 | Logistics and Supply Chain Manager | CRITICAL (20/25) |
| FM8 | The Geopolitical Standoff | Technical/Logistical | A2 | Project Governance Specialist | CRITICAL (25/25) |
| FM9 | The Public Backlash | Market/Human | A3 | Public Relations Coordinator | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Logistics and Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied heavily on a single supplier for critical components. When geopolitical tensions escalated, this supplier faced sanctions, leading to a complete halt in deliveries. The project team had not established alternative suppliers or contingency plans, resulting in a 3-month delay and an additional $100 million in costs due to expedited shipping and sourcing from less reliable vendors.

##### Early Warning Signs
- Supplier communication delays exceed 2 weeks.
- Increased costs for expedited shipping exceed 20%.
- Regulatory changes affecting supplier operations.

##### Tripwires
- Supplier delays exceed 30 days.
- Cost of expedited shipping exceeds $20 million.
- Number of alternative suppliers drops below 2.

##### Response Playbook
- Contain: Stop all non-essential orders from the affected supplier.
- Assess: Evaluate the impact of the supply chain disruption on project timelines.
- Respond: Activate contingency plans and engage alternative suppliers.


**STOP RULE:** If supply chain disruptions exceed 3 months, initiate project reevaluation.

---

#### FM2 - The Geopolitical Standoff

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Project Governance Specialist
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
As tensions between the U.S. and China escalated, regulatory bodies imposed new restrictions on technology transfers. This led to a freeze on critical project components, delaying the operational test phase by 6 months. The project team was unprepared for such a rapid shift in the geopolitical landscape, lacking a flexible governance structure to adapt quickly.

##### Early Warning Signs
- Increased diplomatic tensions reported in the news.
- Changes in regulatory policies affecting technology transfers.
- Meetings with regulatory bodies become contentious.

##### Tripwires
- Any new sanctions imposed on technology transfers.
- Diplomatic meetings result in unresolved disputes.
- Public statements from government officials indicate rising tensions.

##### Response Playbook
- Contain: Halt all project activities that depend on affected technologies.
- Assess: Analyze the impact of geopolitical changes on project timelines.
- Respond: Engage diplomatic channels to seek resolutions and adapt project plans.


**STOP RULE:** If geopolitical tensions lead to a 6-month delay, initiate project reevaluation.

---

#### FM3 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Relations Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite initial assumptions of minimal public opposition, a grassroots movement emerged, fueled by concerns over data privacy and surveillance. Protests erupted, leading to a 2-month delay in project timelines and an additional $10 million spent on public relations efforts to mitigate backlash. The project team failed to engage effectively with the community, resulting in a loss of trust.

##### Early Warning Signs
- Negative media coverage increases by 50%.
- Community meetings show rising attendance and vocal opposition.
- Social media sentiment turns overwhelmingly negative.

##### Tripwires
- Public sentiment scores drop below 60%.
- Number of protest events exceeds 3.
- Community engagement meetings result in more than 50% opposition.

##### Response Playbook
- Contain: Pause all public-facing communications until a strategy is developed.
- Assess: Conduct a thorough analysis of public sentiment and concerns.
- Respond: Develop and implement a robust public engagement strategy to rebuild trust.


**STOP RULE:** If public opposition leads to a 2-month delay, initiate project reevaluation.

---

#### FM4 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Logistics and Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied heavily on a single supplier for critical components. When geopolitical tensions escalated, this supplier faced sanctions, leading to a complete halt in deliveries. The project team had not established alternative suppliers or contingency plans, resulting in a 3-month delay and an additional $100 million in costs due to expedited shipping and sourcing from less reliable vendors.

##### Early Warning Signs
- Supplier communication delays exceed 2 weeks.
- Increased costs for expedited shipping exceed 20%.
- Regulatory changes affecting supplier operations.

##### Tripwires
- Supplier delays exceed 30 days.
- Cost of expedited shipping exceeds $20 million.
- Number of alternative suppliers drops below 2.

##### Response Playbook
- Contain: Stop all non-essential orders from the affected supplier.
- Assess: Evaluate the impact of the supply chain disruption on project timelines.
- Respond: Activate contingency plans and engage alternative suppliers.


**STOP RULE:** If supply chain disruptions exceed 3 months, initiate project reevaluation.

---

#### FM5 - The Geopolitical Standoff

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Project Governance Specialist
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
As tensions between the U.S. and China escalated, regulatory bodies imposed new restrictions on technology transfers. This led to a freeze on critical project components, delaying the operational test phase by 6 months. The project team was unprepared for such a rapid shift in the geopolitical landscape, lacking a flexible governance structure to adapt quickly.

##### Early Warning Signs
- Increased diplomatic tensions reported in the news.
- Changes in regulatory policies affecting technology transfers.
- Meetings with regulatory bodies become contentious.

##### Tripwires
- Any new sanctions imposed on technology transfers.
- Diplomatic meetings result in unresolved disputes.
- Public statements from government officials indicate rising tensions.

##### Response Playbook
- Contain: Halt all project activities that depend on affected technologies.
- Assess: Analyze the impact of geopolitical changes on project timelines.
- Respond: Engage diplomatic channels to seek resolutions and adapt project plans.


**STOP RULE:** If geopolitical tensions lead to a 6-month delay, initiate project reevaluation.

---

#### FM6 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Relations Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite initial assumptions of minimal public opposition, a grassroots movement emerged, fueled by concerns over data privacy and surveillance. Protests erupted, leading to a 2-month delay in project timelines and an additional $10 million spent on public relations efforts to mitigate backlash. The project team failed to engage effectively with the community, resulting in a loss of trust.

##### Early Warning Signs
- Negative media coverage increases by 50%.
- Community meetings show rising attendance and vocal opposition.
- Social media sentiment turns overwhelmingly negative.

##### Tripwires
- Public sentiment scores drop below 60%.
- Number of protest events exceeds 3.
- Community engagement meetings result in more than 50% opposition.

##### Response Playbook
- Contain: Pause all public-facing communications until a strategy is developed.
- Assess: Conduct a thorough analysis of public sentiment and concerns.
- Respond: Develop and implement a robust public engagement strategy to rebuild trust.


**STOP RULE:** If public opposition leads to a 2-month delay, initiate project reevaluation.

---

#### FM7 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Logistics and Supply Chain Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied heavily on a single supplier for critical components. When geopolitical tensions escalated, this supplier faced sanctions, leading to a complete halt in deliveries. The project team had not established alternative suppliers or contingency plans, resulting in a 3-month delay and an additional $100 million in costs due to expedited shipping and sourcing from less reliable vendors.

##### Early Warning Signs
- Supplier communication delays exceed 2 weeks.
- Increased costs for expedited shipping exceed 20%.
- Regulatory changes affecting supplier operations.

##### Tripwires
- Supplier delays exceed 30 days.
- Cost of expedited shipping exceeds $20 million.
- Number of alternative suppliers drops below 2.

##### Response Playbook
- Contain: Stop all non-essential orders from the affected supplier.
- Assess: Evaluate the impact of the supply chain disruption on project timelines.
- Respond: Activate contingency plans and engage alternative suppliers.


**STOP RULE:** If supply chain disruptions exceed 3 months, initiate project reevaluation.

---

#### FM8 - The Geopolitical Standoff

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Project Governance Specialist
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
As tensions between the U.S. and China escalated, regulatory bodies imposed new restrictions on technology transfers. This led to a freeze on critical project components, delaying the operational test phase by 6 months. The project team was unprepared for such a rapid shift in the geopolitical landscape, lacking a flexible governance structure to adapt quickly.

##### Early Warning Signs
- Increased diplomatic tensions reported in the news.
- Changes in regulatory policies affecting technology transfers.
- Meetings with regulatory bodies become contentious.

##### Tripwires
- Any new sanctions imposed on technology transfers.
- Diplomatic meetings result in unresolved disputes.
- Public statements from government officials indicate rising tensions.

##### Response Playbook
- Contain: Halt all project activities that depend on affected technologies.
- Assess: Analyze the impact of geopolitical changes on project timelines.
- Respond: Engage diplomatic channels to seek resolutions and adapt project plans.


**STOP RULE:** If geopolitical tensions lead to a 6-month delay, initiate project reevaluation.

---

#### FM9 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Relations Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Despite initial assumptions of minimal public opposition, a grassroots movement emerged, fueled by concerns over data privacy and surveillance. Protests erupted, leading to a 2-month delay in project timelines and an additional $10 million spent on public relations efforts to mitigate backlash. The project team failed to engage effectively with the community, resulting in a loss of trust.

##### Early Warning Signs
- Negative media coverage increases by 50%.
- Community meetings show rising attendance and vocal opposition.
- Social media sentiment turns overwhelmingly negative.

##### Tripwires
- Public sentiment scores drop below 60%.
- Number of protest events exceeds 3.
- Community engagement meetings result in more than 50% opposition.

##### Response Playbook
- Contain: Pause all public-facing communications until a strategy is developed.
- Assess: Conduct a thorough analysis of public sentiment and concerns.
- Respond: Develop and implement a robust public engagement strategy to rebuild trust.


**STOP RULE:** If public opposition leads to a 2-month delay, initiate project reevaluation.
