# Purpose

**Purpose:** business

**Purpose Detailed:** Governmental national-security program for verifying material changes to frontier-relevant computing equipment in declared datacenters, with bilateral governance, fiscal accountability, and operational testing.

**Topic:** US-China bilateral verification of frontier AI computing equipment at declared datacenters

# Domain

**Primary domain:** Treaty Verification

**Secondary domains:** Cryptographic Attestation, International Law, Hardware Assurance

**Rationale:** Treaty Verification owns the mission: confirming material equipment changes under a bilateral agreement, with exercises and adjudication serving it. Hardware Assurance, Information Barrier Engineering, and Red Teaming are important methods but subordinate to the verification outcome.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Treaty Verification | 5 | 5 | outcome | Core mission is verifying equipment changes under a bilateral monitoring agreement. |
| Hardware Assurance | 5 | 5 | method | Confirms identity, provenance, and alteration of computing hardware at participating sites. |
| Information Barrier Engineering | 5 | 5 | method | Filtered evidence and bounded zones require engineered barriers protecting sensitive data while proving attributes. |
| Red Teaming | 4 | 5 | method | Executes blind challenge exercises to validate detection and reciprocal access. |
| Cryptographic Attestation | 4 | 4 | method | Layered identity verification uses validated cryptographic attestation and a tamper-evident ledger. |
| Counterintelligence | 4 | 4 | constraint | Protects sensitive technology and enforces information barriers between national teams. |
| Distributed Systems Engineering | 4 | 4 | method | Replicated tamper-evident ledger with bounded synchronization is core project infrastructure. |
| Data Center Operations | 4 | 4 | stakeholder | Operators and maintenance vendors are essential participants whose facilities are the inspection targets. |
| International Law | 4 | 3 | constraint | Bilateral instrument and domestic access authority are mandatory entry conditions. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is inherently physical: it requires on-site verification of computing equipment at declared datacenters, physical inspection of material arrivals and removals, installation and decommissioning monitoring, controlled staging areas, witnessed movement, physical security and counterintelligence at real facilities, and deployment of inspectors, technical personnel, red teams, and logistics staff to those locations. It also presumes travel, physical preparation of sites, operator and vendor participation at physical facilities, and real-world challenge exercises involving equipment substitutions and staged events. None of this can be accomplished purely digitally; the entire mission depends on physical presence, tamper-evident physical evidence, and real-world operational testing.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Jointly selected declared datacenter sites in both the United States and China, matched for comparable verification burden
- Controlled staging areas for pre-installation equipment identity verification
- Bounded inspection zones supporting filtered evidence collection and clean-room examination
- Physical security, cybersecurity, and counterintelligence infrastructure adequate for a sovereign national-security program
- Controlled access for mirrored national inspection teams, technical specialists, escorts, and approved vendors
- Reliable power, cooling, network capacity, and logistics support for live challenge exercises without disrupting active computational work
- Space for witnessed movement, maintenance monitoring, and exit/disposition verification

## Location 1
United States

Northern Virginia / Ashburn, Loudoun County, Virginia

Ashburn, Virginia, USA — major declared datacenter corridor; exact facility to be jointly selected

**Rationale**: Northern Virginia is the largest datacenter concentration in the United States and likely to host frontier-relevant computing equipment. Its mature infrastructure, multiple operators, and logistics access support staging areas, bounded inspection zones, and repeated live exercises.

## Location 2
China

Beijing/Hebei cluster

Langfang / Beijing-area declared datacenter facilities, Hebei/Beijing, China — exact facilities to be jointly selected

**Rationale**: The Beijing/Hebei region hosts major Chinese frontier AI and high-performance computing facilities, making it a likely area for declared sites. It provides the high-density computing infrastructure and operator presence needed for matched-pair verification with U.S. sites.

## Location 3
China

Guizhou Province

Gui'an New Area / Guizhou national datacenter hub, China — candidate for an additional matched or stress-test site

**Rationale**: Guizhou is one of China's principal national datacenter hubs and could serve as a second or stress-test site. Its geographic separation and different operating environment help calibrate parity across facility types and test the Consortium's ability to verify under unequal conditions.

## Location Summary
The Consortium cannot operate digitally: it requires physical datacenter sites in both countries for on-site verification, staging, maintenance monitoring, and live challenge exercises. The suggested locations—Northern Virginia, the Beijing/Hebei cluster, and Guizhou—represent high-concentration datacenter regions in both countries and offer the infrastructure, operator ecosystems, and alternative facility profiles needed for matched-site calibration and credible Phase One testing. Final sites must be jointly selected and declared by the two governments.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** The program budget is explicitly denominated in USD (USD 5 billion total, USD 2.5 billion per country), and USD is the practical standard for consolidated budgeting, reporting, and cross-border fiscal reconciliation.
- **CNY:** China-side operator compensation, vendor payments, facility preparation, and local logistics will be administered by the Chinese government and incurred in China, so CNY is needed for domestic disbursements and local cost tracking.

**Primary currency:** USD

**Currency strategy:** Use USD as the single consolidated budgeting, reporting, and appropriation-tracking currency for the full USD 5 billion program, while permitting each government to disburse local operating payments in its own domestic currency (USD for U.S. sites and CNY for China sites) against its USD-denominated contribution. Maintain joint escrow and quarterly reconciliation in USD, with exchange-rate risk managed through structured conversion windows and periodic revaluation so that budget-envelope tracking remains stable regardless of currency movements.

# Identify Risks


## Risk 1 - Governance & Political
The Consortium's equal-national co-chair and double-key structure has no casting vote and prohibits one country overruling the other. The plan does not specify a maximum deadlock duration or a pre-agreed escalation path for disputes over materiality, protocol changes, sanctions, or suspension. A single co-chair can therefore block or delay a decision indefinitely, and an unresolved disagreement can trigger the very suspension machinery meant for verification failures.

**Impact:** Deadlocked material findings could age beyond the agreed discrepancy-resolution window, forcing automatic suspension of one or more sites; Phase One could fail to produce a Go/Modify/Stop verdict within the 90-day operational window, consuming the $250M legal implementation and $500M contingency envelopes with no operational result. A politically motivated deadlock could stop the entire $5B program.

**Likelihood:** Medium

**Severity:** High

**Action:** Pre-register a bounded deadlock procedure before the clock starts: route routine discrepancies to joint technical teams, refer factual disputes to a jointly selected advisory arbiter, and require any deadlock persisting beyond a fixed deliberation window to be recorded on the KPI dashboard and escalated to automatic suspension only for material discrepancies. Make deadlock duration a KPI with a pre-agreed threshold.

## Risk 2 - Regulatory & Permitting
The Phase One clock does not start until both governments have signed the bilateral instrument, appropriated contributions, enacted domestic access authority, selected sites, approved inspectors, secured vendor/operator participation, and adopted the covered-equipment schedule. These are political acts that can be delayed or held hostage to unrelated diplomatic disputes, and the plan provides no outer limit or fallback if conditions remain uncertified.

**Impact:** Preparatory workstreams can continue in parallel, but the operational test could be delayed 6–24 months or indefinitely; trained inspectors and technical teams may be idled, consuming the $750M inspectorate envelope without producing verification evidence. The delay also increases the risk that political leadership changes before Phase One begins.

**Likelihood:** High

**Severity:** High

**Action:** Create an integrated readiness tracker with reciprocal certification by the co-chairs, run all preparatory workstreams in parallel, and use provisional shadow exercises after site selection to keep the mechanism warm. Include a mutual commitment to complete entry conditions within an agreed maximum period, with delays visible as a KPI and escalation to heads of state or party leadership if exceeded.

## Risk 3 - Regulatory & Permitting
Even with political backing, domestic courts, data-protection regulators, local governments, or private operators may challenge the authority of foreign or international inspectors to access facilities, collect evidence, or inspect equipment. The plan requires domestic access authority but does not specify how it interacts with existing privacy, export-control, customs, and national-security laws on either side.

**Impact:** An injunction or regulatory ruling could block inspectors at one site for weeks or months, creating an asymmetric-access Stop condition. Litigation and legislative fixes could add $10–50M in legal costs and delay the Phase One clock by 3–6 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Before clock start, enact a clear domestic legal framework that overrides conflicting private-law objections, defines inspector privileges and limits, and binds operators and vendors contractually. Maintain a joint legal task force to resolve challenges quickly, and include rapid dispute-resolution clauses in the bilateral instrument.

## Risk 4 - Financial
Each government contributes USD 2.5B, with domestic operator and vendor compensation paid by its own government. A delay in appropriations, a treasury dispute over exchange rates, or a quiet decision to slow disbursement can starve the program without formally triggering the withholding-funding Stop condition. The budget is fixed in USD but China-side costs are denominated in CNY, creating exchange-rate and inflation exposure.

**Impact:** A 6–12 month funding delay would idle the inspectorate, stop site preparation, and break the reciprocity parity essential to the Go/Modify/Stop test. A 5% currency or local-inflation shock could add $125–250M in unplanned costs, consuming the $500M contingency envelope before any independent testing occurs.

**Likelihood:** Medium

**Severity:** High

**Action:** Require both governments to pre-fund their full contributions into a jointly signatory escrow before the clock starts, with quarterly USD reconciliation and envelope-approved drawdowns. Use structured currency conversion windows and periodic revaluation to manage CNY/USD exposure, and make any contribution-release delay beyond a pre-agreed window an automatic KPI-visible suspension trigger.

## Risk 5 - Supply Chain
The verification scheme depends on manufacturers, maintenance providers, and logistics companies to provide access, escorts, evidence, and clean-room support. A dominant vendor serving datacenters in both countries could refuse to cooperate, citing proprietary technology, export controls, or national law. Since the forced-evidence ladder can consume time and may produce weaker evidence, a single vendor's refusal can affect multiple sites simultaneously.

**Impact:** Equipment served by the refusing vendor could become unverifiable; if material, the site fails Phase One and the overall verdict moves to Stop. Escalation through the evidence ladder could consume 2–6 weeks per refusal and draw down the $500M contingency and $750M inspectorate envelopes, while unresolved unverifiable-equipment counts mount.

**Likelihood:** Medium

**Severity:** High

**Action:** Negotiate model vendor-access agreements before the clock starts, bind operators to enforce vendor participation, and pre-accredit independent clean-room examiners. Cross-train inspectors to perform vendor-supervised diagnostics themselves, stock spare replacement hardware, and define a per-site unverifiable-equipment threshold that triggers automatic escalation before the materiality corridor is breached.

## Risk 6 - Security & Technical
The information-barrier architecture must protect model weights, customer data, source code, network topology, and unrelated infrastructure while still giving inspectors enough contextual evidence to verify equipment identity. Over-filtering can strip serial numbers, firmware telemetry, or configuration metadata needed to detect substitution; under-filtering can expose sensitive technology and cause either government to withdraw cooperation.

**Impact:** If the barrier hides evidence, blind-challenge detection rates fall and the regime could certify a false negative. If it leaks sensitive data, a single IP or cybersecurity incident could terminate the program and trigger national-security investigations; reputational and intelligence damage is difficult to quantify but could exceed the $5B program budget in diplomatic cost.

**Likelihood:** High

**Severity:** High

**Action:** Design bounded inspection zones and filtered workstations by event type, with cryptographic hashes to preserve evidence integrity; test the barrier in blind exercises before deployment. Use clean-room protocols and accredited independent examiners for the most sensitive inspections, and implement a joint cyber-incident response plan that can isolate and contain a leak without halting all verification.

## Risk 7 - Operational & Technical
Credible detection depends on the maximum time between a physical material change and its verified appearance in the ledger. The layered latency budget creates interior windows for operator reporting, physical confirmation, and ledger recording that red teams will try to exploit. If any interior window is too long or not independently verifiable, an unreported arrival or substitution can go undetected for hours or days.

**Impact:** A missed latency target would fail the KPI dashboard and could force a Modify verdict even if other elements succeed. If thresholds are set too loose, an event could remain silent for 24–72 hours, giving red teams a guaranteed concealment corridor and undermining the Go decision.

**Likelihood:** Medium

**Severity:** High

**Action:** Predefine and validate threshold values through simulation and exercises, such as operator reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour. Use tamper-evident local recording at the point of observation, unannounced random sweeps to shrink expected silent windows, and independent monitoring of interior windows to ensure the layered budget is not a paper construct.

## Risk 8 - Technical
The replicated, tamper-evident ledger with national copies must record events locally and synchronize within a bounded window. Network outages, software defects, or malicious tampering can cause the two national copies to diverge. Because unresolved divergence is a designated Stop condition, the system risks either false alarms from minor synchronization lags or missed divergence that allows evidence to be silently altered or withheld.

**Impact:** A divergence that cannot be reconciled within the agreed window would trigger a Stop recommendation. If divergence detection is too slow, both governments may rely on conflicting records during a security crisis. Reconciliation exercises could consume 1–4 weeks of the Phase One clock and require technical fixes costing $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Set a bounded synchronization window with automatic divergence alerts, maintain local-first recording so no event is lost during connectivity loss, and run regular reconciliation drills against independently generated test events. Use hash commitments exchanged continuously between the two national copies to prove tamper-evidence without exposing sensitive content.

## Risk 9 - Operational & Political
The matched site set must have comparable verification burden, but Northern Virginia, the Beijing/Hebei cluster, and Guizhou differ in facility size, layout, vendor ecology, security rules, and operating culture. Paper matching by declared equipment value or total capacity may not make inspection difficulty equal. If one country's sites are systematically easier or harder to inspect, access-parity metrics become meaningless and the asymmetric-access Stop trigger can be tripped before exercises begin.

**Impact:** Negotiations over the matched set could stall entry-condition certification for months. If the final set is asymmetric, one side could claim the other receives less intrusive inspections, causing political collapse and a Stop verdict. Red-team results would be incomparable across sites, undermining the 90-day test.

**Likelihood:** High

**Severity:** High

**Action:** Jointly define parity in advance using multiple attributes, including equipment value, operational role, physical layout, and security constraints. Benchmark reciprocal access hours and inspection outcomes during the readiness period, and deliberately include one or more harder-to-inspect stress sites on each side so the regime is validated under unequal conditions.

## Risk 10 - Operational
The plan requires full-time mirrored national inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units with separation of duties and leave coverage. Recruiting enough cleared, bilingual, technically credible specialists on both sides within the entry-condition period is a major challenge, and reliance on a small surge cadre can create single points of failure.

**Impact:** Staffing gaps would delay event response, invalidate evidence collection, and violate the no-single-person-critical-function rule. Hiring premium pay and security-clearance processing could add 10–20% to the $750M inspectorate envelope, or $75–150M, and push the Phase One start by 3–6 months if qualified personnel cannot be cleared in time.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Build a workload-based staffing model before the clock starts, create a full-time surge cadre rather than using temporary agents, cross-train specialists across sites, and initiate security-clearance processing in parallel with entry-condition certification. Include retention bonuses and a training pipeline for technical inspectors to reduce attrition risk.

## Risk 11 - Security
The program itself is a high-value target for state-sponsored cyber operations, insider threats, and counterintelligence activity. Evidence systems, secure facilities, inspector communications, and the confidential covered-equipment schedule are attractive targets. A single compromised insider or cyber intrusion could undermine the integrity of verification evidence and create an international incident.

**Impact:** A successful compromise could alter ledger records, leak the covered-equipment schedule, expose inspector travel plans, or reveal sensitive data collected during inspections. Response and remediation costs could range from $10–100M, and the political fallout could trigger automatic suspension or the withdrawal of either government.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement strict need-to-know compartments, physical and logical separation of national teams, continuous counterintelligence monitoring, hardware-separated evidence systems, and regular penetration testing by independent red teams. Establish a joint incident-response protocol that isolates compromised systems while preserving the ability to continue verification at unaffected sites.

## Risk 12 - Technical & Governance
The Phase One Go decision depends on live exercises demonstrating credible detection. If red teams are not truly independent or blind, if exercises are announced too far in advance, or if KPI thresholds are set without validation, the exercises can produce a false sense of confidence. The plan does not finalize threshold values, and unsupported figures marked provisional or TBD must still be validated before they can justify a Go verdict.

**Impact:** A Go recommendation based on scripted exercises or lenient thresholds could lead a government to rely on a verification regime that cannot detect real substitution, with national-security consequences. Setting thresholds too strict could cause a false Stop and waste the $5B investment; too loose could produce an indefensible Go. Threshold negotiation itself could delay the verdict by weeks.

**Likelihood:** Medium

**Severity:** High

**Action:** Use genuinely independent red teams with no advance knowledge of exercise timing, run unannounced exercises in staging, spare-inventory, and maintenance areas, and pre-register all KPI thresholds with a validation plan based on historical data, pilot runs, and exercise results. Require the KPI dashboard to show false-negative and false-positive rates, confidence intervals, and unresolved-discrepancy ages before any Go decision.

## Risk 13 - Technical
The covered-equipment schedule must remain current as AI hardware evolves, but every revision reopens the bilateral definitional bargain. If the schedule is too static, new frontier-relevant equipment is not verified; if it is revised too often, disputes over definitional criteria delay operations. The plan's attribute-based confidential schedule depends on accountable specialists, but the versioning process itself can become a flashpoint.

**Impact:** During the Phase One window, a new architecture could ship that is not on the schedule, creating an unverified gap until the double-key approval process completes. If approval takes 4–8 weeks, a material installation could occur outside verification; if the schedule is frozen to avoid dispute, the regime's credibility decays immediately after launch.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Pre-negotiate an attribute-based coverage framework before the clock starts, include a fast-track provisional listing procedure that adds equipment on an interim basis within 48–72 hours, and schedule sunset reviews linked to each side's declared new generations. Require the accountable specialists to maintain a versioned changelog and pre-registered criteria for disputes.

## Risk 14 - Operational & Social
Operators and vendors may cooperate reluctantly, fearing that inspections will disrupt active computational work, expose confidential customer arrangements, or reveal more than the bounded protocol allows. The plan's live exercises must not interrupt active work, but even staging, maintenance monitoring, and witnessed movement create friction. A reluctant operator can delay access, produce inaccurate records, or challenge evidence authenticity.

**Impact:** Access delays could violate the latency budget and cause false negatives or false positives in exercise results. Production disruption claims could become a political issue, causing operators to seek exemptions or compensation beyond the $1B preparation and compensation envelope. If one country's operators are less cooperative than the other's, reciprocal-access parity fails and the Stop condition is triggered.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Bind operator participation as a condition of site eligibility, provide fair compensation administered by the operator's own government, and pre-agree inspection windows that minimize interference with production. Escalate deliberate obstruction to the co-chairs quickly, and use the exercise program to test and refine low-disruption inspection techniques before the actual event-response phase.

## Risk 15 - Financial & Environmental
The $5B budget is fixed, with each expense mapped to an envelope. Site preparation, secure facilities, and independent testing often overrun initial estimates, and the physical locations face power-grid, climate, and logistical risks. Natural disasters or energy constraints could disrupt verification exercises and force contingency spending.

**Impact:** A 5–10% cost overrun equals $250–500M and would consume the entire contingency envelope, forcing reallocation from testing or inspectorate capacity. A severe weather or grid event at a selected site could delay the 90-day test by 2–4 weeks and require emergency relocation or backup-power costs of $5–20M.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan for overruns, and select multiple fallback sites within each country to mitigate physical-environment risk. Use structured currency conversion and fixed-price contracts where possible to limit inflation and exchange-rate exposure.

## Risk summary
The risk landscape is dominated by political and institutional failure modes rather than purely technical ones. The three most critical risks are: entry-condition and appropriations delay, which can prevent Phase One from ever starting or allow a quiet veto; vendor refusal and unverifiable-equipment contagion, which can trigger the Stop condition through a single dominant supplier; and information-barrier imbalance, where over-filtering blinds inspectors to substitution or under-filtering exposes sensitive technology and collapses political support. These risks are mutually reinforcing: an information leak can cause funding delays, a vendor refusal can expose parity asymmetries, and deadlock over any of these can suspend the entire program. Key assumptions are that both governments genuinely intend to meet entry conditions, that suitable matched sites and qualified personnel can be identified within the budget, and that KPI thresholds will be validated before use; the absence of specified thresholds and site or vendor agreements is the largest source of remaining uncertainty. Success should be judged only against the narrow mission of verifying monitored changes at declared sites, not as a broader AI-governance guarantee.

# Make Assumptions


## Question 1 - How should the USD 5 billion contributions be escrowed, released, and revalued to prevent delayed or asymmetric disbursement from acting as a quiet veto, and what exchange-rate rule should govern CNY-denominated China-side payments?

**Assumptions:** Assumption: Both governments will pre-fund their full USD 2.5 billion contributions into a jointly signatory escrow before the Phase One clock starts, with drawdowns only against envelope-approved expenditures and quarterly USD reconciliation. China-side operator and vendor payments will be converted through quarterly structured windows with periodic revaluation, and any contribution-release delay beyond 10 business days is recorded as a KPI-visible suspension trigger. This aligns with the funding-timeliness KPI and the currency strategy in currency_strategy.md.

**Assessments:** Title: Funding and Fiscal Accountability Assessment
Description: Evaluates the escrow, release, and currency mechanism for the USD 5 billion budget.
Details: Full pre-funding removes the quiet-veto risk identified in identify_risks.md Risk 4 and guarantees reciprocal deployment for matched-site parity. A 5% CNY/USD movement or local-inflation shock could add USD 125-250 million in unplanned costs if unhedged; structured conversion windows and a dedicated FX reserve within the contingency envelope cap this exposure. Drawdowns must be tied to envelope codes (ledger, site prep, inspectorate, facilities, testing, legal/audit, contingency) and audited quarterly. Benefits include predictable staffing and site preparation; opportunity to use escrow interest or treasury instruments to offset administrative costs, though any return must be returned to both governments to preserve the non-commercial, sovereign nature.

## Question 2 - What is the maximum acceptable duration for the mandatory entry-condition phase, and how will the 90-day Phase One clock be jointly certified and kept on schedule if one government's legislative or site-selection process slips?

**Assumptions:** Assumption: The entry-condition phase will be capped at 12 months from the date of political commitment (target completion by 2027-Sep-04), with an integrated readiness tracker and parallel preparation across all workstreams. The Phase One clock starts only after co-chairs jointly certify all conditions; any condition still open after 12 months triggers escalation to heads of state and becomes a public KPI, but does not start the 90-day test. This is consistent with identify_risks.md Risk 2 and the plan's mandatory entry conditions.

**Assessments:** Title: Timeline and Milestone Gating Assessment
Description: Assesses the entry-condition gate, parallel readiness, and the 90-day operational window.
Details: Political actions (appropriations, domestic access authority, site selection, inspector approval, vendor/operator agreements, schedule adoption) can each delay start by 6-24 months if handled sequentially; parallel workstreams and a single integrated readiness tracker compress this to a 12-month target. The formal clock must not start until all conditions are certified to avoid burning the 90-day test on unresolved prerequisites. Provisional shadow exercises can keep teams warm without creating de facto obligations or non-binding findings. Metrics: readiness checklist closure rate, days to certification, number of certified conditions at clock start; target 100% reciprocal certification. Risk: a slip on one side idles trained staff and consumes inspectorate funding; mitigation includes provisional training and surge deployment only after joint certification.

## Question 3 - How many participating declared sites will constitute the matched set, and what workload-based staffing model—including mirrored national teams, shift coverage, leave backup, separation of duties, and a full-time surge cadre—will be required within the USD 750 million inspectorate envelope?

**Assumptions:** Assumption: The matched set will be 6 declared sites (3 per country), requiring 24/7 on-site coverage at each site with no fewer than two full-time mirrored national inspectors per material event, a 1.5x leave/backup multiplier, and a permanently employed surge cadre equal to 10% of baseline staffing. The resulting baseline is approximately 450 full-time-equivalent positions across inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units, with no single-person critical functions. This is derived from Risk 10 guidance and the plan's staffing mandate.

**Assessments:** Title: Resourcing and Staffing Feasibility Assessment
Description: Evaluates the full-time mirrored staffing model and its fit to the USD 750 million inspectorate envelope.
Details: A 450-person baseline with loaded annual cost averaging USD 200k implies USD 90 million per year; an 18-month readiness-plus-Phase-One period costs roughly USD 135 million, leaving headroom for surge, training, travel, translation, and security clearances within the envelope. The 1.5x multiplier and 10% surge cadre prevent single points of failure but add 15-20% above a minimal model. Risk: clearance delays and bilingual technical talent scarcity could add 10-20% cost (USD 75-150 million) and delay start by 3-6 months; mitigation is to begin clearances in parallel and cross-train specialists. Staffing depth also serves as a reciprocity signal; asymmetric capacity would undermine the Go decision.

## Question 4 - How will the bilateral instrument pre-commit both governments to a deadlock-resolution procedure, automatic-suspension thresholds, and a binding bilingual glossary so that no single co-chair can indefinitely block a material finding or reinterpret a contested term?

**Assumptions:** Assumption: The instrument will create joint technical teams for routine discrepancies, refer deadlocked factual disputes to a jointly selected advisory arbiter (advisory only), and limit automatic suspension to sites with unresolved material discrepancies. A deadlock persisting more than 10 business days is recorded on the KPI dashboard and escalates to the two governments' leadership; the binding bilingual glossary and pre-registered interpretive annex are adopted before the clock starts. This addresses Risk 1 and Decision 14 while preserving double-key authorization for sanctions and suspension.

**Assessments:** Title: Bilateral Governance and Legal Certainty Assessment
Description: Assesses double-key governance, deadlock control, and interpretive dispute management.
Details: Without a bounded deadlock path, one co-chair can exploit delay to shield an operator or stall the verdict. Pre-registered glossary and interpretive annex convert future disputes into lookup operations; joint technical teams keep routine discrepancies from rising to the political level. The 10-business-day deadlock threshold balances the no-unilateral-overrule rule against the need for timely findings; if too long, material discrepancies age and trigger unnecessary suspension; if too short, routine disputes escalate politically. Metrics: deadlock resolution time, interpretive disputes resolved without access denial, count of unilateral findings (target zero). Legal implementation cost is bounded within the USD 250 million envelope; domestic access legislation must override private-law objections and bind operators and vendors contractually.

## Question 5 - What provisional thresholds for false negatives, unresolved discrepancy age, unverifiable equipment, vendor-refusal escalation, and information-security incidents will define materiality and trigger automatic suspension, and how will live blind challenges validate those thresholds before the Go decision?

**Assumptions:** Assumption: Provisional thresholds, to be validated by pilot runs and exercises, are: operator event reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour; false-negative rate no greater than 5% in blind challenges with at least 95% confidence; unresolved material discrepancy age no greater than 10 business days; unverifiable covered equipment no more than 2 units per site or 1% of covered changes; a single confirmed IP/cyber incident compromising evidence integrity triggers isolation and an automatic hold on affected systems. These align with Risk 7, Risk 8, and Risk 12 and the KPI list.

**Assessments:** Title: Safety, Security, and Verification-Risk Assessment
Description: Evaluates detection thresholds, cyber/counterintelligence protection, and challenge-based validation.
Details: The thresholds define the regime's falsifiable honesty claim: if red teams can exceed a 5% false-negative rate or hide a substitution for more than 4+24+1 hours, the Phase One verdict must not be Go. Overly strict thresholds risk a false Stop and wasted USD 5 billion; overly loose thresholds risk certifying an undetected substitution. Mitigation: run six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal) and use independent red teams with no advance timing. Cyber/counterintelligence costs are drawn from the USD 750 million facilities and cyber envelope; a single evidence-integrity incident may cost USD 10-100 million and trigger automatic suspension, so system isolation must be drilled.

## Question 6 - How will the Consortium assess and mitigate environmental, energy-grid, and climate-related risks at the selected datacenter sites—particularly in Northern Virginia, Beijing/Hebei, and Guizhou—so that power reliability, cooling, and disaster continuity do not disrupt the 90-day test?

**Assumptions:** Assumption: Each selected site must demonstrate at least N+1 power redundancy and 99.9% annual uptime, and the Consortium will perform a pre-selection environmental and grid-stability assessment for each candidate. Two fallback sites per country will be pre-qualified, and USD 20 million of the contingency envelope is reserved for disaster response, backup power, and relocation if a weather or grid event disrupts exercises. This responds to Risk 15 and physical_locations.md.

**Assessments:** Title: Environmental and Physical-Resilience Assessment
Description: Assesses power, climate, and disaster risks at physical sites and their impact on verification continuity.
Details: The selected regions are major datacenter hubs but face distinct risks: Northern Virginia has grid congestion and heat/humidity; Beijing/Hebei has air-quality and water constraints; Guizhou has hydroelectric dependency and seasonal variability. A severe weather or grid event could delay the 90-day test by 2-4 weeks and cost USD 5-20 million in backup power or relocation. The mission's environmental footprint is modest relative to existing datacenter operations; the main financial exposure is business continuity, not emissions. Mitigation: pre-qualified fallback sites, portable power and cooling for staging and bounded inspection zones, and exercise scheduling windows that avoid local peak-demand seasons. KPI: site uptime during Phase One at or above 99.9%; zero exercise cancellations due to environmental causes.

## Question 7 - How will the Consortium obtain and enforce binding operator, manufacturer, maintenance-provider, and logistics-company participation—including reporting, confidentiality, escort, and evidence-preservation obligations—without relying on voluntary cooperation, and how will domestic compensation be administered without creating conflicts of interest?

**Assumptions:** Assumption: Operator and vendor participation will be mandated by domestic law and contractual conditions of site eligibility, with model vendor-access agreements pre-negotiated before clock start. Each government administers compensation for its domestic operators and vendors from its own USD 2.5 billion contribution, capped within the USD 1 billion site-preparation and operator-compensation envelope, and deliberate obstruction or refusal to provide access is classified as a material discrepancy. This operationalizes Risk 5 and Risk 14 and the plan's vendor-refusal ladder.

**Assessments:** Title: Stakeholder and Third-Party Compliance Assessment
Description: Assesses operator/vendor obligations, compensation administration, and refusal containment.
Details: The verification regime fails if a dominant vendor refuses clean-room access or a reluctant operator delays entry. Pre-negotiated model agreements and domestic legal mandates convert participation from goodwill to obligation; if a critical vendor refuses, use vendor-supervised testing, filtered evidence, accredited independent examiners, or validated attestation, and classify equipment unverifiable only after the full ladder fails. A material unverifiable count fails the site. Compensation administered by each government avoids cross-border payments and preserves fiscal sovereignty but creates a risk that compensation is used to influence operators; independent audit of compensation disbursement should be included. Metrics: vendor-refusal outcomes, unverifiable-equipment counts, time from refusal to resolved disposition, operator access-delay incidents; target zero deliberate obstructions.

## Question 8 - What are the required functional specifications and latency bounds for the replicated tamper-evident ledger, controlled intake staging, filtered-evidence information barriers, and exit/disposition protocol, and how will these systems be exercised together in live challenges before the Go/Modify/Stop decision?

**Assumptions:** Assumption: The ledger will use local-first, hash-chained national copies with continuous hash-commitment exchange, a synchronization target of no more than 1 hour for event records, and a divergence-reconciliation target of no more than 24 hours. All covered arrivals must pass through jointly controlled staging areas with pre-installation identity gates; all departures must receive an assigned disposition (witnessed destruction, verified permanent disablement, transfer, documented release, or unresolved) within 48 hours or trigger automatic site review. Operational-system integration will be validated by six mandatory unannounced challenge types before the verdict. This reflects Decision 10, Decision 11, and the plan's Exit Protocol.

**Assessments:** Title: Operational Systems and Lifecycle Verification Assessment
Description: Assesses ledger integrity, intake/exit controls, information barriers, and integrated live-exercise readiness.
Details: The ledger must record events locally at the point of observation, synchronize with bounded latency, and reconcile divergence without requiring one side to expose sensitive content; continuous hash commitments provide tamper evidence while preserving privacy. Intake staging is the physical chokepoint—any bypass creates an unverified installation and should be treated as a material discrepancy. Exit disposition closes the lifecycle; unresolved departures must feed the verdict and can trigger automatic suspension if material. Information barriers must be tested in blind challenges because over-filtering can hide contextual metadata needed to detect substitution. Metrics: event-recording latency (target under 5 minutes locally), synchronization latency (no more than 1 hour), divergence reconciliation time (no more than 24 hours), ledger divergence count (target zero unresolved), equipment-identity confidence (at or above 99%), and blind-challenge detection rates by event type.

# Distill Assumptions

- Both leaders believe uncontrolled frontier AI threatens national security and political control.
- Both governments provide political backing and domestic authority to compel participation.
- No trust, legal symmetry, or sensitive technology exposure is assumed.
- Sovereign public-sector program, not for-profit; scope only declared-equipment change verification.
- Excludes capacity estimates, workload verification, model weights, hidden facilities, and comprehensive AI governance.
- Mandatory entry conditions are prerequisites; 90-day clock starts only after joint certification.
- Entry-condition phase capped at 12 months from political commitment; open condition escalates to leaders.
- Total budget $5B, 50/50, pre-funded into jointly signatory escrow before clock.
- Budget envelopes: $1.25B ledger, $1B site prep, $750M inspectorate, $750M facilities, $500M testing, $250M legal/audit, $500M contingency.
- Drawdowns envelope-approved, quarterly USD reconciliation, 10-business-day delay triggers suspension.
- China-side payments use quarterly structured conversion windows with periodic revaluation.
- Matched set: six sites, three per country, 24/7 coverage.
- Baseline staffing ~450 FTE; two mirrored inspectors per event; 1.5x backup; 10% surge.
- No single-person critical functions; full-time mirrored units across all functions.
- Equal co-chairs, double-key authorization; no casting vote or majority overrule.
- Joint technical teams handle routine discrepancies; advisory arbiter for deadlocked facts.
- Automatic suspension limited to unresolved material discrepancy sites; no unilateral findings/sanctions.
- Deadlock beyond 10 business days escalates to leadership; binding bilingual glossary pre-clock.
- Operator/vendor participation mandated by domestic law and pre-negotiated access agreements.
- Each government administers domestic compensation from its own contribution; obstruction is material discrepancy.
- Vendor-refusal ladder uses supervised testing, filtered evidence, independent examiners, or attestation before unverifiable.
- Material unverifiable equipment causes site failure; max 2 units/site or 1% of changes.
- Latency thresholds: operator report 4h, physical confirm 24h, ledger record 1h.
- False-negative rate ≤5% in blind challenges at 95% confidence.
- Unresolved discrepancy age max 10 business days.
- One IP/cyber incident compromising evidence integrity triggers isolation and automatic hold.
- Sites need N+1 power redundancy and 99.9% uptime; two fallback sites per country; $20M disaster reserve.
- Ledger uses local-first hash-chained national copies; sync target 1h; divergence reconciliation 24h.
- Arrivals pass jointly controlled staging identity gates; departures get disposition within 48h or site review.
- Exit dispositions: witnessed destruction, permanent disablement, transfer, documented release, or unresolved.
- Six unannounced blind challenges validate systems; exercises don't interrupt computational work.
- Information barriers protect sensitive data; no single evidence source decisive.
- Covered-equipment schedule remains confidential, versioned, attribute-based, not anchored to current products.
- Go requires reciprocal access and credible detection.
- Stop if asymmetric access, material unverifiable, shielding, unresolved divergence, or withheld funding.
- KPI thresholds provisional/TBD until validated by exercises.
- KPIs cover detection, latency, divergence, parity, discrepancies, incidents, and funding timeliness.

# Review Assumptions

## Domain of the expert reviewer
Bilateral arms-control verification, national-security program management, and datacenter infrastructure assurance

## Domain-specific considerations

- Sustained political commitment across electoral and leadership transitions
- Trusted baseline inventory of pre-existing covered equipment at declared sites
- Rapid cross-border inspector access, visas, privileges, and movement of diagnostic tools
- Legal harmonization of foreign inspector authority with privacy, export-control, and customs laws
- Counterintelligence and insider-threat resilience for both national teams
- Information-barrier trade-offs between verification sensitivity and protection of proprietary technology

## Issue 1 - Missing assumption of sustained political continuity across leadership transitions
The plan assumes current leaders' commitment is durable, but a $5B bilateral security program spanning at least 12 months of entry conditions plus Phase One and beyond can be reversed by a U.S. administration change, a Chinese leadership transition, or congressional appropriations battles. The pre-funded escrow mitigates quiet fiscal veto but cannot compel a successor government to continue hosting foreign inspectors. Without a continuity assumption, the entire investment is exposed to a single political discontinuity.

**Recommendation:** Negotiate binding continuity commitments in the bilateral instrument: multi-year funding obligations, transition briefings for incoming leadership, and a joint public KPI dashboard that makes termination politically costly. Include automatic suspension-with-escrow-return clauses if either government withdraws, and establish a track-II engagement channel to sustain technical relationships during political transitions.

**Sensitivity:** A U.S. administration change during the 12-month entry-condition baseline could delay Phase One by 12-24 months. Sunk preparation and staffing costs would reach $400-600M, consuming most of the $500M contingency; idle inspectorate costs would add $150-250M, reducing the program's political ROI to zero if terminated.

## Issue 2 - Missing trusted baseline inventory of pre-existing covered equipment at declared sites
All material-change verification assumes a known starting state, but the plan only specifies arrivals, departures, and staged events. If the initial inventory of frontier-relevant equipment at each declared datacenter is inaccurate, incomplete, or disputed, then every subsequent 'change' is unverifiable and the latency and materiality thresholds have no meaningful baseline. No assumption addresses how legacy racks installed before the regime begins are identified, serialized, and agreed upon.

**Recommendation:** Add a mandatory joint baseline physical inventory audit to the entry conditions before the Phase One clock starts. Create a cryptographic asset registry of all covered equipment at each declared site, reconciled against operator procurement, maintenance, and disposal records. Resolve all discrepancies before clock start, and treat the inventory completion as a joint certification gate.

**Sensitivity:** If 2-5% of serialized records at a typical site are inaccurate (baseline: 6 sites, roughly 50,000 covered units), reconciliation could take 4-8 weeks and cost $20-60M, delaying Phase One by 1-2 months. If skipped, the false-negative rate could exceed the 5% blind-challenge threshold, invalidating a Go verdict and wasting the $500M testing envelope.

## Issue 3 - Missing operational assumption for rapid cross-border inspector access, visas, privileges, and movement of diagnostic equipment
The 24-hour physical confirmation latency budget is impossible unless inspectors can travel to declared sites at short notice, receive visas and access credentials within hours, and bring diagnostic/test equipment across borders without customs delays. The plan assumes domestic access authority but does not explicitly assume reciprocal diplomatic clearance, inspector immunities, or pre-clearance of sensitive verification tools. A visa or customs bottleneck would break every interior latency window.

**Recommendation:** Negotiate a standing bilateral inspector-access annex before clock start: 48-hour visa processing, multiple-entry diplomatic visas for all credentialed inspectors, pre-cleared manifests for diagnostic tools, and customs pre-authorization for challenge exercise equipment. Grant inspectors privileges and immunities limited to official verification acts, and test the travel-and-clearance pathway in a mandatory pre-Phase One exercise.

**Sensitivity:** If visa processing takes 10 business days instead of the assumed 48 hours, every material event would miss the 24-hour physical confirmation window, forcing automatic suspension and a Modify or Stop verdict. A 4-week visa/customs delay during Phase One could add $5-20M in rescheduling costs and invalidate the unannounced-challenge schedule, delaying the verdict by 3-6 months.

## Review conclusion
The most critical missing assumptions are political durability, a trusted baseline inventory, and rapid cross-border inspector access. Without these, the $5B program can be halted by a leadership change, launched with an unverifiable starting state, or unable to meet its own latency thresholds. Each issue is addressable through pre-clock legal commitments, joint physical audits, and an inspector-access annex, but they must be elevated from implicit hopes to explicit, tested entry conditions.