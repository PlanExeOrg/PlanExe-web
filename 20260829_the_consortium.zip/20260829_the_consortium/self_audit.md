Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 11 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 7 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a bilateral governmental verification and inspection program for datacenter equipment, built from institutional agreements, physical inspections, cryptographic ledgers, and standard operational logistics. Its success criteria depend on human and technical systems that are fully consistent with known physics, and it nowhere requires violation of conservation laws, causality, or other physical principles.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a never-attempted combination—US-China bilateral verification of frontier-AI datacenter hardware via a novel two-sovereign verification architecture with tamper-evident ledgers, information barriers, and double-key governance—and the materials concede 'There is no direct U.S.-China bilateral on-site verification precedent, so this recommendation set triangulates across the closest real-world families of projects.' Nuclear-domain analogues (INF, JVE, IAEA) cover components, not the whole system, and the only backing is the internal claim that 'the pre-project assessment confirms the technical approach is buildable with no inherent contradictions,' so a false Go/Stop verdict would be existential for the $5B regime's credibility.

**Mitigation**: Joint Secretariat with co-chairs: run parallel validation tracks (legal/compliance, ledger/latency, information-barrier detection, vendor/continuity) each producing one authoritative source or supervised pilot vs baseline; enforce NO-GO gates for empirical validity and legal clearance, rejecting domain-mismatched PoCs. Deliverable: dual-gate certification memo, within 12 months.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because lever one-pagers exist yet strategy-driving concepts remain undefined: "The plan names materiality as a Stop trigger without defining it," and "the Consortium has not articulated a single flagship use-case," leaving the verdict and $5B rationale without agreed meaning.

**Mitigation**: Joint Co-Chairs and Joint Secretariat: Publish two one-pagers within 90 days — materiality thresholds with decision hooks and a crisis-stability value hypothesis with success metrics — for double-key approval before certification.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit controls for critical second-order risks like political discontinuity, unvalidated KPI thresholds, and undefined managed-access protocols. For example, 'The plan assumes current leaders' commitment is durable, but a U.S. administration change... could halt the program.' Additionally, 'KPI thresholds are provisional/TBD until validated by exercises,' and 'The verification access architecture is not an access architecture; it is an information-protection wish list.' These gaps create existential failure modes if not addressed.

**Mitigation**: Bilateral Governance and Legal Implementation Lead: Draft and validate a Protocol on Access and Managed Access with pre-agreed denial-resolution procedures, materiality definitions, and KPI validation plan within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix with jurisdictional lead-time allocations, yet entry-condition certification and the 12-month clock depend on domestic access-authority legislation, export/import licenses, customs pre-authorization, and environmental/grid permits. The plan only commits to "Apply for all export, import, customs, visa, environmental, construction, and grid-connection authorizations in parallel," without mapping predecessors or comparing scheduled versus typical approval durations.

**Mitigation**: Joint Secretariat with program schedulers: Rebuild the critical path within 60 days, adding a permit/approval matrix with authoritative jurisdiction lead times, dated predecessors, and a NO-GO threshold on any slip.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because funding uncommitted: US/China $2.5B each are assumptions ('pre-fund full USD 2.5 billion into a jointly signatory escrow'); no term sheets, draw/covenants undefined, 15-month runway exposed.

**Mitigation**: Fiscal Escrow and Independent Audit Controller: Within 90 days, publish a financing plan listing US/China $2.5B sources/status, draw schedule, covenants, and NO-GO on any missed financing gate.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's budget lacks vendor quotes, per-area cost normalization, or contingency tied to estimates; it only states allocations like "$1.25B ledger... $1B site preparation" without any cost-per-m²/ft² benchmarks for the six sites, making cost realism unsubstantiated.

**Mitigation**: Datacenter Site Preparation and Cross-Border Logistics Manager: Obtain ≥3 per-area benchmarks and vendor quotes for fit-out/opex, normalize to cost per m²/ft² across six sites, and adjust envelopes or de-scope within 120 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because key projections ('targeted for completion by 2027-Sep-04', 'approximately 450 FTE') lack ranges, yet 'provisional/TBD until validated by exercises' thresholds and the '$500M contingency/surge' envelope provide partial coverage.

**Mitigation**: Joint Secretariat / Program Integration Lead: Deliver a best/worst/base-case scenario and sensitivity analysis for the certification-to-verdict timeline, quantifying clearance, legislative, vendor, and site-selection drivers, within 90 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan promises validation of the 'replicated tamper-evident ledger prototype…through independent testing' yet lacks specs, interface contracts, acceptance tests, and an integration plan for core components.

**Mitigation**: Hardware Identity and Evidence Integrity Technical Lead: Produce technical specs, interface contracts, acceptance-test plans, and an integration map with owners/dates for ledger, barriers, staging, and registry within 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because 'Sign the bilateral instrument' and pre-fund contributions 'into a jointly signatory escrow' are asserted, yet no signed instrument, enacted access law, escrow confirmation, or declared-site artifact exists.

**Mitigation**: Joint Legal Task Force: Deliver a certification evidence pack—signed bilateral instrument, enacted domestic access authority, executed escrow confirmation, and declared matched-site list—or formally rescope entry conditions within 180 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the final deliverable—the Go/Modify/Stop verdict—has no verifiable acceptance qualities: the plan names materiality as a Stop trigger 'without defining it' and thresholds are 'provisional/TBD until validated by exercises.'

**Mitigation**: Joint Co-Chairs with independent statistician: Define SMART acceptance criteria for the Go/Modify/Stop verdict, including a materiality KPI (over 2 unverifiable units per site triggers suspension) and validated false-negative rate, within 90 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the killer-application narrative — 'a joint unclassified briefing and demonstration package framing Phase One as a crisis-stability tool' — adds USD 2-5 million of strategic-communications cost and acknowledged scope-creep complexity without directly supporting the core goals of verifying material equipment changes at six matched sites and issuing a defensible Go/Modify/Stop verdict. Partial coverage exists since the plan bounds it ('must not expand the legal scope beyond declared-equipment change verification') and ties it to political continuity, but no benefit case or KPI demonstrates its necessity for Phase One outcomes.

**Mitigation**: Strategic Communications Leads reporting to the co-chairs: Produce a one-page Benefit Case Review for the killer-application narrative, including a KPI, owner, and estimated cost, within 90 days; otherwise move the narrative to the project backlog.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the unicorn role is the Hardware Identity and Evidence Integrity Technical Lead: it uniquely couples hardware assurance, cryptographic attestation, replicated-ledger engineering, and treaty-verification protocol fluency. The plan says this role must be staffed by 'cleared, permanent personnel,' yet no talent-market evidence exists, and staffing feasibility flags 'bilingual technical talent scarcity,' making the role essential and likely unfillable.

**Mitigation**: Joint Secretariat with both national leads: commission a talent-market survey for Hardware Identity and Evidence Integrity Technical Leads, mapping candidate pools, clearance timelines, and compensation, and issue a go/no-go staffing-readiness report within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because counsel and costed validation exist—'formal legal opinions from both governments on all mandatory legal entry conditions'—yet ratification, access-legislation, export/customs/permit lead times lack mapping.

**Mitigation**: Joint Legal Task Force: Within 60 days, deliver a regulatory matrix (authority, artifact, lead time, predecessors) covering treaty ratification, access legislation, export/customs/visa, and site permits, with NO-GO triggers on adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM: funding sustainability is unresolved—'the $5B covers only Phase One' and 'Long-term funding model for Phase Two is undefined'—but maintenance and scalability gaps are addressable with planning.

**Mitigation**: Joint Secretariat and Fiscal Escrow Controller: Draft an Operational Sustainability Plan within 60 days covering post-Phase One funding strategy, maintenance and technology-roadmap schedule, succession planning, scalability triggers, and adaptation mechanisms.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies permit and grid requirements but lacks written confirmations, a fatal-flaw screen, or NO-GO thresholds tied to zoning, egress, fire load, structural, and noise constraints. Constraints remain uncertain.

**Mitigation**: Joint Legal Task Force with local permitting authorities: Perform a fatal-flaw screen for zoning, occupancy/egress, fire load, structural, noise, and permits at all six sites; obtain written confirmation or define fallbacks and NO-GO thresholds within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM: the plan has 'two fallback sites per country,' replicated ledger copies, and a forced-evidence ladder, but a dominant vendor refusal 'can cascade across every site it serves' and facility failover remains pre-qualified rather than tested.

**Mitigation**: Operator and Vendor Compliance Liaison with Site Preparation Manager: sign secondary-vendor and fallback-site agreements, then run live failover drills (vendor refusal, grid outage, node loss) at one matched pair within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Finance seeks 'fiscal leverage' via milestone tranches while Operations needs pre-funded escrow; the milestone fallback risks making 'the KPI dashboard itself the object of negotiation.'

**Mitigation**: Joint Co-Chairs and Fiscal Escrow Controller: Draft a joint OKR within 90 days linking envelope release to mutually certified readiness and verification milestones and quarterly reconciliation, aligning both incentives.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan defines KPI thresholds ('divergence reconciliation within 24 hours'), monthly cadence ('Run monthly integrated readiness reviews'), named owners, and change control via suspension triggers, stop rules.

**Mitigation**: Joint Secretariat: Stand up a monthly KPI-dashboard review with a lightweight change board for threshold-triggered re-plan/stop decisions; log outcomes in versioned readiness records within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because 'a single dominant vendor refusing cooperation can cascade across every site it serves' and risks are 'mutually reinforcing,' yet no cross-impact/FTA map or heatmap with NO-GO thresholds.

**Mitigation**: Joint Risk Integration Office: Build interdependency map with bow-tie/FTA and combined heatmap, assigning owners and NO-GO/contingency thresholds for vendor-refusal, barrier, funding, and deadlock cascades within 90 days.