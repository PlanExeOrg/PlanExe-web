Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: The plan outlines a governance and verification mechanism for monitoring computing equipment at datacenters, which does not require breaking any laws of physics or depend on non-physical mechanisms. It focuses on operational protocols, budget allocations, and verification processes that are consistent with known physical laws.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of governance, verification, and operational protocols without independent evidence of success at comparable scale. This creates a likely failure mode.

**Mitigation**: Project Governance Specialist: Conduct parallel validation tracks across governance, verification, and operational protocols within 60 days to gather authoritative sources and pilot results.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks defined frameworks and measurable outcomes for strategic concepts, creating a significant strategic blind spot. No one-pagers exist to clarify these elements.

**Mitigation**: Project Governance Specialist: Produce one-pagers detailing value hypotheses, success metrics, and decision hooks within 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not adequately address second-order risks such as legal, safety, financial, and reputational hazards. Major hazard classes are not fully explored, creating potential failure modes.

**Mitigation**: Project Governance Specialist: Expand the risk register to include detailed second-order risks, map potential cascades, and establish a review cadence within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive permit/approval matrix, which is essential for understanding the timeline realism. This absence creates a likely failure mode due to unanticipated delays.

**Mitigation**: Project Manager: Rebuild the critical path with dated predecessors and authoritative permit lead times, establishing a NO-GO threshold on slip within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan does not specify committed sources or term sheets that cover the required runway. There are no defined financing gates or covenants, creating a likely failure mode.

**Mitigation**: Finance Team: Draft a detailed financing plan listing sources, statuses, draw schedules, and covenants, establishing a NO-GO on missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the lack of vendor quotes or scale-appropriate benchmarks. The plan does not provide any contingency, creating a likely failure mode.

**Mitigation**: Owner: Benchmark costs against at least 3 relevant comparables, obtain quotes, normalize per-area, and adjust budget or de-scope by 30 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios, indicating a lack of contingency planning. This optimism creates a likely failure mode.

**Mitigation**: Project Analyst: Conduct a sensitivity analysis or best/worst/base-case scenario analysis for critical projections within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, and acceptance tests for critical components. This absence creates a likely failure mode in operational integrity.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 30 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks verifiable artifacts for critical claims such as licenses and approvals. For instance, the absence of documented agreements for bilateral cooperation creates a likely failure mode.

**Mitigation**: Project Governance Specialist: Obtain all necessary legal documents and approvals, including licenses and partnership agreements, within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final outputs, such as the verification framework, are poorly defined without specific, verifiable qualities. This lack of clarity creates a likely failure mode.

**Mitigation**: Project Governance Specialist: Define SMART acceptance criteria for the verification framework, including a KPI for successful implementation rate (e.g., 90% compliance within 90 days) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Inspectorate Deployment and Information Barriers decision introduces mirrored national teams, which adds complexity and cost without clear evidence of supporting core project goals like verification accuracy and trust.

**Mitigation**: Project Team: Conduct a Benefit Case Review for the Inspectorate Deployment feature, justifying its inclusion with KPIs, owner, and estimated costs, or move it to the project backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the unicorn role of a 'Technical Verification Specialist' is essential for developing and implementing verification protocols, yet finding qualified personnel with the necessary expertise is likely difficult.

**Mitigation**: Project Governance Specialist: Conduct a market analysis to validate the availability of qualified candidates for the Technical Verification Specialist role within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear and required approvals are unmapped, creating a potential showstopper. The plan lacks a regulatory matrix detailing necessary permits and lead times.

**Mitigation**: Project Governance Specialist: Conduct a Fatal-Flaw Analysis and develop a regulatory matrix outlining authority, artifacts, lead times, and predecessors within 30 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive assessment of operational sustainability, particularly regarding ongoing costs and funding. This gap creates a likely failure mode post-completion.

**Mitigation**: Project Governance Specialist: Develop an operational sustainability plan that includes funding strategies, maintenance schedules, and succession planning within 30 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success hinges on obtaining non-waivable zoning and land-use permits, which are unlikely to be granted without significant negotiation. This creates a likely failure mode.

**Mitigation**: Owner: Perform a fatal-flaw screen with local authorities to assess zoning and land-use constraints, seeking written confirmation of requirements within 30 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks contracts/SLAs and tested failovers for external dependencies, creating a critical risk of single points of failure. This absence could lead to significant operational disruptions.

**Mitigation**: Project Governance Specialist: Secure SLAs with all vendors and establish a secondary supplier path, testing failover capabilities within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project involves both the Finance Department and the R&D Team, whose incentives conflict: Finance prioritizes budget adherence while R&D seeks long-term innovation, risking project alignment.

**Mitigation**: Project Governance Specialist: Create a shared OKR that aligns both Finance and R&D on a common outcome, ensuring budget and innovation goals are balanced within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process. Vague 'we will monitor' is insufficient, creating a likely failure mode.

**Mitigation**: Project Governance Specialist: Add a monthly review with a KPI dashboard and establish a lightweight change board within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a comprehensive assessment of interactions among risks, which could lead to multi-node cascades and common-mode failures. For instance, the coupling of regulatory delays, cybersecurity threats, and public opposition could create a critical failure mode.

**Mitigation**: Project Governance Specialist: Develop an interdependency map, bow-tie analysis, and combined heatmap to identify risk interactions, with NO-GO thresholds established within 30 days.