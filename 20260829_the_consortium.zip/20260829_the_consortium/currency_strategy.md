This plan involves money.

## Currencies

- **USD:** The primary currency for budgeting and reporting, as the project is funded equally by the United States and China.
- **CNY:** Included for local transactions and expenses incurred in China during the project.

**Primary currency:** USD

**Currency strategy:** The project will use USD for all budgeting and reporting to mitigate risks associated with currency fluctuations. Local expenses in China will be managed in CNY, but all major financial transactions will be conducted in USD to ensure stability and accountability.