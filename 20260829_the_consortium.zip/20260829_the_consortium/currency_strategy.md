This plan involves money.

## Currencies

- **USD:** The program budget is explicitly denominated in USD (USD 5 billion total, USD 2.5 billion per country), and USD is the practical standard for consolidated budgeting, reporting, and cross-border fiscal reconciliation.
- **CNY:** China-side operator compensation, vendor payments, facility preparation, and local logistics will be administered by the Chinese government and incurred in China, so CNY is needed for domestic disbursements and local cost tracking.

**Primary currency:** USD

**Currency strategy:** Use USD as the single consolidated budgeting, reporting, and appropriation-tracking currency for the full USD 5 billion program, while permitting each government to disburse local operating payments in its own domestic currency (USD for U.S. sites and CNY for China sites) against its USD-denominated contribution. Maintain joint escrow and quarterly reconciliation in USD, with exchange-rate risk managed through structured conversion windows and periodic revaluation so that budget-envelope tracking remains stable regardless of currency movements.