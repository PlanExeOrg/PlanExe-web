**Primary domain:** Treaty Verification

**Secondary domains:** Cryptographic Attestation, International Law, Hardware Assurance

**Rationale:** Treaty Verification owns the mission: confirming material equipment changes under a bilateral agreement, with exercises and adjudication serving it. Hardware Assurance, Information Barrier Engineering, and Red Teaming are important methods but subordinate to the verification outcome.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Treaty Verification | 5 | 5 | outcome | Core mission is verifying equipment changes under a bilateral monitoring agreement. |
| Hardware Assurance | 5 | 5 | method | Confirms identity, provenance, and alteration of computing hardware at participating sites. |
| Information Barrier Engineering | 5 | 5 | method | Filtered evidence and bounded zones require engineered barriers protecting sensitive data while proving attributes. |
| Red Teaming | 4 | 5 | method | Executes blind challenge exercises to validate detection and reciprocal access. |
| Cryptographic Attestation | 4 | 4 | method | Layered identity verification uses validated cryptographic attestation and a tamper-evident ledger. |
| Counterintelligence | 4 | 4 | constraint | Protects sensitive technology and enforces information barriers between national teams. |
| Distributed Systems Engineering | 4 | 4 | method | Replicated tamper-evident ledger with bounded synchronization is core project infrastructure. |
| Data Center Operations | 4 | 4 | stakeholder | Operators and maintenance vendors are essential participants whose facilities are the inspection targets. |
| International Law | 4 | 3 | constraint | Bilateral instrument and domestic access authority are mandatory entry conditions. |