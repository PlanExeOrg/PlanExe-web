## Domain of the expert reviewer
Bilateral arms-control verification, national-security program management, and datacenter infrastructure assurance

## Domain-specific considerations

- Sustained political commitment across electoral and leadership transitions
- Trusted baseline inventory of pre-existing covered equipment at declared sites
- Rapid cross-border inspector access, visas, privileges, and movement of diagnostic tools
- Legal harmonization of foreign inspector authority with privacy, export-control, and customs laws
- Counterintelligence and insider-threat resilience for both national teams
- Information-barrier trade-offs between verification sensitivity and protection of proprietary technology

## Issue 1 - Missing assumption of sustained political continuity across leadership transitions
The plan assumes current leaders' commitment is durable, but a $5B bilateral security program spanning at least 12 months of entry conditions plus Phase One and beyond can be reversed by a U.S. administration change, a Chinese leadership transition, or congressional appropriations battles. The pre-funded escrow mitigates quiet fiscal veto but cannot compel a successor government to continue hosting foreign inspectors. Without a continuity assumption, the entire investment is exposed to a single political discontinuity.

**Recommendation:** Negotiate binding continuity commitments in the bilateral instrument: multi-year funding obligations, transition briefings for incoming leadership, and a joint public KPI dashboard that makes termination politically costly. Include automatic suspension-with-escrow-return clauses if either government withdraws, and establish a track-II engagement channel to sustain technical relationships during political transitions.

**Sensitivity:** A U.S. administration change during the 12-month entry-condition baseline could delay Phase One by 12-24 months. Sunk preparation and staffing costs would reach $400-600M, consuming most of the $500M contingency; idle inspectorate costs would add $150-250M, reducing the program's political ROI to zero if terminated.

## Issue 2 - Missing trusted baseline inventory of pre-existing covered equipment at declared sites
All material-change verification assumes a known starting state, but the plan only specifies arrivals, departures, and staged events. If the initial inventory of frontier-relevant equipment at each declared datacenter is inaccurate, incomplete, or disputed, then every subsequent 'change' is unverifiable and the latency and materiality thresholds have no meaningful baseline. No assumption addresses how legacy racks installed before the regime begins are identified, serialized, and agreed upon.

**Recommendation:** Add a mandatory joint baseline physical inventory audit to the entry conditions before the Phase One clock starts. Create a cryptographic asset registry of all covered equipment at each declared site, reconciled against operator procurement, maintenance, and disposal records. Resolve all discrepancies before clock start, and treat the inventory completion as a joint certification gate.

**Sensitivity:** If 2-5% of serialized records at a typical site are inaccurate (baseline: 6 sites, roughly 50,000 covered units), reconciliation could take 4-8 weeks and cost $20-60M, delaying Phase One by 1-2 months. If skipped, the false-negative rate could exceed the 5% blind-challenge threshold, invalidating a Go verdict and wasting the $500M testing envelope.

## Issue 3 - Missing operational assumption for rapid cross-border inspector access, visas, privileges, and movement of diagnostic equipment
The 24-hour physical confirmation latency budget is impossible unless inspectors can travel to declared sites at short notice, receive visas and access credentials within hours, and bring diagnostic/test equipment across borders without customs delays. The plan assumes domestic access authority but does not explicitly assume reciprocal diplomatic clearance, inspector immunities, or pre-clearance of sensitive verification tools. A visa or customs bottleneck would break every interior latency window.

**Recommendation:** Negotiate a standing bilateral inspector-access annex before clock start: 48-hour visa processing, multiple-entry diplomatic visas for all credentialed inspectors, pre-cleared manifests for diagnostic tools, and customs pre-authorization for challenge exercise equipment. Grant inspectors privileges and immunities limited to official verification acts, and test the travel-and-clearance pathway in a mandatory pre-Phase One exercise.

**Sensitivity:** If visa processing takes 10 business days instead of the assumed 48 hours, every material event would miss the 24-hour physical confirmation window, forcing automatic suspension and a Modify or Stop verdict. A 4-week visa/customs delay during Phase One could add $5-20M in rescheduling costs and invalidate the unannounced-challenge schedule, delaying the verdict by 3-6 months.

## Review conclusion
The most critical missing assumptions are political durability, a trusted baseline inventory, and rapid cross-border inspector access. Without these, the $5B program can be halted by a leadership change, launched with an unverifiable starting state, or unable to meet its own latency thresholds. Each issue is addressable through pre-clock legal commitments, joint physical audits, and an inspector-access annex, but they must be elevated from implicit hopes to explicit, tested entry conditions.