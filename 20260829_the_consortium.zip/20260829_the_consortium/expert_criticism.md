# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Treaty Verification & Managed Access Specialist

**Knowledge**: bilateral arms control verification, INF Treaty, Joint Verification Experiment, IAEA safeguards, OPCW managed access

**Why**: Converts bounded zones, filtered evidence, vendor-refusal ladder into managed-access procedures meeting Phase One latency and parity targets.

**What**: Advise on escort rules, zone access patterns, evidence preservation, and the inspector visa/customs drill so the 24-hour physical-confirmation budget is realistic.

**Skills**: inspection protocol design, managed access techniques, escort procedures, evidence chain-of-custody, challenge exercise planning

**Search**: treaty verification managed access expert, INF Treaty on-site inspection specialist, IAEA safeguards inspector consultant

## 1.1 Primary Actions

- Immediately convene a joint legal and verification drafting group to produce the Access and Managed Access Protocol. Treat this as a mandatory entry condition, not a subordinate workstream.
- Commission a Test and Evaluation Master Plan and power analysis from independent verification statisticians before any KPI thresholds are locked. Remove or mark TBD every unsupported threshold in the goal statement, including the '5% at 95% confidence' claim.
- Redraft the governance and decision-rights chapter to separate inspectorate facts from co-chair political decisions. Remove 'site findings' from the double-key authorization list and introduce automatic technical holds for unresolved discrepancies.
- Stand up the joint baseline inventory task force now with actual site data. Produce a resource-loaded schedule for serializing and reconciling the covered-equipment population within the 12-month entry-condition window, or revise the scope and schedule honestly.
- Convene the bilingual terminology commission immediately to define with worked examples: material, frontier-relevant, covered equipment, managed access, alternative demonstration, unverifiable, and material discrepancy.
- Negotiate and exercise the inspector visa and customs annex before any further planning reviews. If 48-hour visa issuance or pre-cleared tool manifests cannot be achieved, change the latency KPI or the access architecture—do not assume it away.
- Develop a red-team charter with joint selection, contractual independence from both governments, and statistically driven injection rules. Red teams must report to the technical inspectorate, not to the co-chairs.
- Produce a notional 90-day schedule with realistic event counts per site and per category. If the schedule cannot support the required number of independent blind challenges, amend the verification claim to what is actually demonstrable.

## 1.2 Secondary Actions

- Review OPCW managed-access provisions, IAEA complementary-access procedures, and the Joint Verification Experiment information-barrier reports. Map each precedent to a clause in your proposed protocol.
- Run a governance war-game with both national legal teams covering deadlock, manufactured discrepancy, vendor refusal, and operator delay.
- Compile a list of actual candidate datacenters with floor plans, vendor contracts, and preliminary covered-equipment counts. Do not wait for formal government nomination.
- Coordinate with ministry and treasury lawyers on the legality of escrow pre-funding. Identify a fallback fiscal mechanism if a jointly signatory escrow cannot be structured under either legal system.
- Build a mock staging and inspection area, then conduct one full managed-access exercise: intake, identity verification, installation observation, and exit disposition.
- Convene a small group of former INF/IAEA/OPCW inspectors to review the draft access protocol and KPI design before the next consultation.
- Use track-II verification organizations such as VERTIC or IPNDV to get an independent technical review of the statistical test design and the managed-access protocol.

## 1.3 Follow Up Consultation

Bring the draft Access and Managed Access Protocol, the draft Test and Evaluation Master Plan with challenge-event counts and confidence-interval calculations, and a revised governance decision-rights matrix. Also bring site survey data and the baseline inventory plan for at least two candidate datacenters. We will walk through a mock managed-access denial scenario and stress-test the KPI statistical assumptions with real numbers.

## 1.4.A Issue - The verification access architecture is not an access architecture; it is an information-protection wish list.

The plan repeatedly says 'bounded inspection zones,' 'filtered evidence,' 'clean-room protocols,' and 'no single source decisive,' but it never answers the fundamental treaty-verification question: what is the minimum access the inspectorate may demand, and what may the inspected side refuse or manage? INF, IAEA, and OPCW practice all allow managed access to protect legitimate secrets, but any denial or restriction must be compensated by alternative arrangements sufficient to satisfy the inspection objective. Your plan inverts this: protection appears to have veto power, because every evidence stream can be filtered and every area can be bounded without a pre-agreed floor. You will enter Phase One with each side able to deny meaningful inspection by pointing to sensitive data, and every denial becomes a legal dispute rather than a verification result.

### 1.4.B Tags

- managed-access
- access-rights
- information-barrier
- legal-baseline
- inspection-procedure
- denial-resolution

### 1.4.C Mitigation

Draft a Protocol on Access and Managed Access as an annex to the bilateral instrument before the clock starts. Specify: (1) all locations, equipment, and records associated with declared covered equipment are subject to inspection, including staging, storage, maintenance, and disposal areas; (2) the inspected party may propose managed-access measures such as shrouding, escort, filtered display, or clean-room reading, but may not simply deny; (3) any managed-access measure must be accompanied by an alternative demonstration adequate to verify the identity and disposition of the covered equipment; (4) all denials and proposed alternatives are logged, with a joint technical team deciding within 48 hours whether the alternative satisfies the inspection objective; (5) an unresolved denial counts as a material discrepancy, not a graceful 'unverifiable' category. Use OPCW managed-access examples, the Joint Verification Experiment information-barrier approach, and IAEA complementary-access procedures. Negotiate a per-site access matrix for all six sites during the entry-condition phase. Run at least two live access-denial/managed-access challenge exercises before clock start, and train every inspector to distinguish a denial from a genuinely adequate managed-access alternative.

### 1.4.D Consequence

Without a legal floor of access rights, the layered-evidence hierarchy is fiction: the inspected side can filter every layer. The blind-challenge results will measure only what the inspected side allowed, not what the inspectorate could detect. The Go/Modify/Stop verdict becomes a diplomatic artifact, not a verification judgment.

### 1.4.E Root Cause

The team treated information protection as an evidence-design problem and lost the fundamental managed-access principle: protection of sensitive data must not defeat the verification objective. This is a treaty-law error, not a technical one.

## 1.5.A Issue - False-negative '5% at 95% confidence' is statistically unsupported and cannot be proven in a 90-day, six-site test as designed.

A false-negative rate is not a management KPI you set; it is a property of a detection system measured across a defined population of challenge events. You have not specified how many fabricated events, of which categories, will be injected into which sites, over what period, or how confidence intervals are computed. Under the rule of three, if you run only 20 independent blind challenge events and see zero misses, the upper 95% confidence bound on the false-negative rate is about 14%; you would need roughly 60 events to claim an upper bound near 5%. Your 90-day schedule likely cannot support 60 meaningful challenges per material-change category—arrival, removal, substitution, transfer, maintenance, decommissioning—with independent injection and no cross-site contamination. Claiming 5% at 95% confidence without a power analysis is exactly the 'unsupported figure' the plan says to mark provisional or TBD, but then the Go decision is based on nothing. The same problem afflicts 'unverifiable equipment no more than 2 units or 1%' and 'reciprocal access parity within 0.9–1.1': no denominators, no tolerance rationale, no validation plan.

### 1.5.B Tags

- KPI-validation
- statistics
- false-negative
- sample-size
- test-design
- probability-of-detection
- threshold-justification

### 1.5.C Mitigation

Produce a Test and Evaluation Master Plan before any KPI thresholds are locked. It must include: (1) precise definitions of each material-event category and the detection event under test; (2) a statistical design specifying the number of challenge events per category, injection schedule, blinding and independence controls, and the formula for confidence intervals; (3) a feasibility check—if the required challenge-event count exceeds the 90-day window, either reduce the statistical claim to a reported detection rate with confidence intervals or extend the test; (4) pre-registered analysis rules so thresholds cannot be moved after results are known; (5) a pilot exercise at two sites before clock start to validate false-negative and false-positive measurement procedures. Consult national laboratory statisticians and test-evaluation experts from both sides. Mark all unsupported thresholds TBD until the Test and Evaluation Master Plan is approved. For 'unverifiable equipment' and 'parity,' define numerator and denominator, data source, and acceptable margin based on actual site counts and event frequencies; do not invent tolerances.

### 1.5.D Consequence

As written, the KPI dashboard creates an illusion of quantitative rigor. If challenged, the other side will reject the Go decision because the confidence claim cannot be substantiated, or one government will game the event count to manufacture a false Go. The final verdict becomes a political punt, and the verification credibility of the entire USD 5 billion investment collapses.

### 1.5.E Root Cause

The plan borrows generic project-management target language such as '95% confidence' from software and test-management contexts without understanding that verification confidence is a statistical inference over a defined challenge population. It is an honesty problem: unsupported numbers were stated as targets rather than hypotheses to be tested.

## 1.6.A Issue - Double-key authorization for 'site findings' will convert every operational observation into a diplomatic veto.

The initial plan states that 'site findings' require double-key authorization. If that is literal, each joint finding—a serial-number match, a witnessed destruction, a video still—must be co-approved before it can be recorded as a fact. That is unworkable and contrary to every modern verification precedent: IAEA inspectors record technical observations and report them; OPCW inspection reports are drafted by the inspection team and transmitted; States Parties do not sign off on each finding. Your own Decision 1 correctly reserves double-key for material findings and sanctions, but the ambiguity remains unresolved in the governing text. The deadlock procedures also allow a co-chair to block closure of an unresolved material discrepancy indefinitely, and the no-casting-vote structure means one side can stall rather than decide. Without an independent professional inspectorate and a clear separation between technical facts, verification conclusions, and political decisions, the 90-day clock will be consumed by arguments over what the inspectors actually saw.

### 1.6.B Tags

- governance
- double-key
- deadlock
- independent-secretariat
- operational-tempo
- verification-credibility
- decision-rights

### 1.6.C Mitigation

Restructure governance into three tiers. First, inspectorate facts: credentialed inspectors from both national teams record objective observations on-site; these are not subject to co-chair approval and are entered immediately into the ledger. Second, materiality and verification conclusions: a joint technical adjudication panel decides using pre-agreed evidentiary rules; panel decisions require a technical majority, not an absolute veto, with any dissent recorded. Third, sanctions, suspension, protocol changes, and budget changes: reserved to the co-chairs under double-key, with a default rule that failure to agree within 10 business days on a material finding automatically escalates the matter and places the site on technical hold—freezing equipment movement and preserving evidence—pending resolution. Clarify in the legal text that 'site findings' means material adverse findings only, not routine observations. Add an independent technical director or joint chief inspector, not a project sponsor, to lead the inspectorate and sign findings in a professional capacity. Run a governance war-game with both legal teams to test deadlock scenarios before the clock starts.

### 1.6.D Consequence

If left unresolved, any single disputed observation can stop the entire verification process. The no-casting-vote design, intended to prevent unilateral overrule, becomes a machine for indefinite paralysis. Operators will learn to exploit the dispute channel to shield discrepancies, and the Go/Modify/Stop output will be nothing more than a measure of who was more patient in the final negotiation.

### 1.6.E Root Cause

The authors were so committed to the no-unilateral-overrule principle that they conflated political control with technical professionalism. Equal co-chairs are appropriate for policy decisions but destructive when applied to every inspection fact.

---

# 2 Expert: US-China Bilateral Treaty Counsel

**Knowledge**: US-China public international law, bilateral executive agreements, double-key governance, bilingual treaty drafting, domestic implementing legislation

**Why**: Drafts the bilateral instrument, glossary, deadlock machinery, and domestic access-authority language that are mandatory entry conditions before the Phase One clock starts.

**What**: Review the instrument and interpretive annex, pre-register contested terms, and align both countries' implementing legislation with operator and vendor compulsion obligations.

**Skills**: legal drafting, treaty negotiation, legislative analysis, dispute pre-registration, cross-jurisdictional compliance

**Search**: US-China international law counsel, bilateral treaty drafter, public international law implementing legislation expert

## 2.1 Primary Actions

- Convene the joint legal task force including constitutional, treaty, appropriations, export-control, and data-protection lawyers immediately. Deliver a legal-form memorandum by 2026-10-30, a bilateral instrument outline by 2026-12-18, and model implementing legislation for both sides before the next certification review.
- Resolve the Consortium's legal personality and status. Decide whether it will be established as a limited-purpose international organization or as a joint program executed through existing national agencies, and draft the necessary status/headquarters agreement, privileges-and-immunities clause, escrow-holding authority, and liability/indemnity/cross-waiver provisions.
- Negotiate and conclude the inspector visa, customs, and cross-border evidence annex, including 48-hour multiple-entry visas, pre-cleared diagnostic-tool manifests, privileges and immunities limited to official verification acts, and conflict-of-law rules for data and evidence transfer. Complete the full travel-and-clearance drill before any Phase One clock start.
- Retain an independent verification-statistics expert and produce a pre-registered statistical analysis plan covering sample sizes, confidence-interval methods, false-positive definitions, unresolved-event handling, parity tolerances, and materiality corridors. Start pilot blind challenges during the entry-condition phase and mark all unvalidated KPI thresholds as TBD.
- Draft and adopt the governance annex with objective automatic-suspension triggers, a fixed deadlock clock, conservative default outcomes, an independent technical-fact mechanism, and pre-registered bad-faith indicators. Do not recommend any certification until this annex is legally reviewed and incorporated into the bilateral instrument.
- Elevate and formally track the three additional gates—certified baseline inventory, inspector-access annex, and escrow pre-funding—as mandatory entry conditions with named owners, evidence slots, and co-chair certification fields, alongside the original seven conditions, against the 2027-09-04 boundary.
- Obtain written legal opinions from both governments on domestic access authority, appropriation and escrow feasibility, private-rights limitations, data-transfer restrictions, and export-control compliance. Bring these opinions, not narrative summaries, to the next consultation.

## 2.2 Secondary Actions

- Engage the IAEA, OPCW, VERTIC, and IPNDV verification communities to study managed-access legal frameworks, inspector-status agreements, and statistical methods for small-sample verification regimes.
- Separate the 'killer application' communications narrative from the legal scope of the instrument. An unclassified crisis-stability briefing is useful for political continuity, but it must not expand or imply verification obligations beyond declared-equipment change verification at declared sites.
- Begin legislative outreach in both countries now: brief U.S. appropriations and foreign-affairs committees and Chinese legislative and State Council bodies so implementing legislation is not stuck at the entry-condition deadline.
- Run tabletop exercises of the governance annex, including deadlock, manufactured discrepancy, automatic suspension, and leadership-escalation scenarios, and revise the annex based on the results.
- Develop a full conflict-of-laws matrix for every class of evidence and data that crosses the border, mapping U.S. export-control law, Chinese data-security and state-secret law, privacy statutes, and classification rules to the specific evidence type and proposed protective control.
- Prepare political-continuity mechanisms—multi-year appropriation language, transition briefing requirements, escrow-return clauses, and a track-II channel—but treat them as risk mitigation, not as substitutes for a legally binding instrument.
- Require all budget owners to map every expense to an envelope and to document appropriations-law constraints, especially whether advance appropriations or a jointly signatory escrow is permissible under each country's fiscal law.

## 2.3 Follow Up Consultation

The next consultation must focus on: one, the legal-form memorandum and the selected option for Consortium legal personality; two, the draft governance annex with objective automatic-suspension triggers, deadlock default rules, and materiality corridors; three, the draft statistical analysis plan with challenge sample sizes and confidence-interval calculations; four, the status of the inspector visa/customs/cross-border evidence annex and the completed travel-and-clearance drill; five, the legal opinions on appropriation, escrow, domestic access authority, and data-transfer restrictions; and six, an updated integrated readiness tracker showing named owners, evidence slots, and co-chair certification fields for every mandatory entry condition. Bring drafts, not slide decks, and do not schedule any further operational planning until the legal and statistical foundations are certified.

## 2.4.A Issue - Legal form, domestic authority, and legal personality are undefined; the plan currently rests on political commitment rather than enforceable law

The entry conditions list 'signed bilateral instrument' and 'enacted domestic access authority' as if those were self-executing. Under U.S. law, an agreement that imposes binding obligations on private parties, obligates $2.5 billion, and authorizes foreign officials to exercise verification powers inside the United States cannot be accomplished by political endorsement or a sole executive agreement alone. You likely need either an Article II treaty with Senate advice and consent or a congressionally authorized executive agreement, plus implementing legislation that creates the legal authority, appropriates funds, and resolves constitutional constraints, liability, privileges and immunities, export controls, customs, data transfer, and private-property objections. China's side similarly requires domestic legal authorization and a determination of how the instrument ranks in domestic law. The plan also never addresses the Consortium's legal personality: it cannot hold escrow funds, sign leases, employ roughly 450 people, or own evidence systems unless it is established as an international organization or hosted by one or both governments with clear legal capacity. There is no status/headquarters agreement, no dispute-settlement clause, no liability/indemnity/cross-waiver regime, and no resolution of cross-border transfer restrictions on protected data or the confidential covered-equipment schedule. As drafted, no entry condition can be certified because the legal authority to compel anyone to do anything does not exist.

### 2.4.B Tags

- treaty-form
- implementing-legislation
- legal-personality
- privileges-immunities
- data-transfer
- conflict-of-laws

### 2.4.C Mitigation

Convene a joint legal task force now, including constitutional, treaty, appropriations, export-control, data-protection, and national-security lawyers from both governments. By 2026-10-30, produce a legal-form memorandum identifying the required domestic legal basis for each side. By 2026-12-18, draft the bilateral instrument with a legal personality option, status of the Consortium, headquarters/secretariat arrangements, privileges and immunities limited to official verification acts, liability and indemnity provisions, cross-waivers, dispute-settlement provisions, termination and escrow-return clauses, and explicit rules for cross-border evidence transfer. Draft model implementing legislation for both sides that overrides conflicting private-law objections while respecting constitutional limits on search, seizure, and property. Obtain legal opinions from the U.S. State Department, DOJ, Chinese MOFA, and legislative-affairs bodies on whether the proposed access authority is constitutional and enactable. Consult IAEA, OPCW, and IPNDV legal models for managed access, inspector status, and bilateral verification institutions. Before any further planning, decide whether the Consortium will be a limited-purpose international organization or a joint program executed through existing national agencies with no separate legal personality.

### 2.4.D Consequence

Without this, the program is a diplomatic handshake, not a legal regime. The first operator refusing entry, the first inspector incident, the first export-control objection, or the first data-transfer challenge will produce domestic litigation or criminal exposure. The U.S. Congress will not appropriate $2.5 billion against an undefined legal instrument, and no Chinese agency will accept binding obligations without clear domestic authorization. The entry-condition phase will fail before verification begins.

### 2.4.E Root Cause

Political leadership backing has been conflated with domestic legal authority. Treaty counsel and constitutional lawyers were not at the table when the instrument and access-authority assumptions were drafted.

## 2.5.A Issue - The KPI thresholds are not a statistical design; the 90-day six-site test cannot produce a defensible Go/Modify/Stop verdict without a pre-registered analysis plan

The plan says 'false-negative rate no greater than 5% in blind challenges at 95% confidence' but does not specify the number of challenges, the denominator, the analysis population, the confidence-interval method, or how unresolved and censored events are handled. With six sites and 90 days, you cannot simply assert this threshold. To claim a 95% upper confidence bound below 5% with zero missed events, you need roughly 60 successfully conducted challenges; to claim that by event type, you need that many per event type. The final verdict also depends on 'credible detection' and 'reciprocal access parity,' but there is no statistical definition of parity, no pre-agreed tolerance calculation, no plan for false-positive costs, and no rule for aggregating small samples. The plan's own pre-project assessment says KPI thresholds are unvalidated, and the SWOT analysis admits they are provisional, but the project plan still states them as measured success criteria. This is a recipe for a contested verdict: one side can argue that two missed events out of five 'unannounced arrivals' is a 40% false-negative rate, even if the overall test met the target.

### 2.5.B Tags

- statistical-power
- sample-size
- KPI-validation
- false-negative
- false-positive
- materiality-corridor

### 2.5.C Mitigation

Retain an independent verification-statistics expert or a recognized arms-control verification methodology group before the clock starts. Produce a pre-registered statistical analysis plan that fixes: the number and type of blind challenges per event category, the required sample size for the claimed confidence level, the exact confidence-interval method, the treatment of unresolved or equipment-inaccessible events, the definition of false positive, the parity metric with pre-agreed tolerance, and the aggregation rule for site-level and event-level results. Run pilot blind challenges in staging, spare-inventory, and maintenance areas during the entry-condition phase to generate preliminary detection data and validate the information barrier. Mark every unsupported KPI threshold as 'TBD' in all documents and specify the data source and validation study required before it can be adopted. Define materiality corridors numerically: for example, what number of unverifiable units at a site is tolerated, what number forces suspension, and what pattern of vendor refusals constitutes systemic failure. Determine explicitly what Phase One can and cannot claim statistically given six sites and 90 days, and state that limitation in the final verdict.

### 2.5.D Consequence

Without a pre-registered statistical design, the Go/Modify/Stop verdict is not a scientific finding; it is a negotiation. Unvalidated thresholds can produce a false Go that destroys the program's credibility or a false Stop that wastes $5 billion. Either government will be able to challenge the result by choosing a different denominator or reading the confidence intervals differently.

### 2.5.E Root Cause

KPI targets were treated as policy commitments rather than testable hypotheses. The constraints imposed by six sites, 90 days, rare events, and real-world production disruption were not fed into a statistical design.

## 2.6.A Issue - The no-casting-vote double-key governance is not a decision rule; deadlock, materiality, and automatic suspension remain exploitable and undefined

Saying 'no chair has a casting vote' and 'no majority procedure may allow one country to overrule the other' is not a governance mechanism; it is an invitation to paralysis or tactical delay. The plan says deadlocks escalate to heads of state or party leadership after 10 business days, but that is a political process, not a legal resolution procedure, and it can be repeated indefinitely. You never define what counts as a deadlock, who decides whether a discrepancy is material, what the default is when the co-chairs cannot agree, how automatic suspension can operate if the materiality determination itself requires double-key, or how to distinguish a genuine discrepancy from a manufactured one. The Stop trigger 'a government shields an operator' has no definition, no evidence standard, and no adjudication path. As drafted, a co-chair can block an automatic suspension by disputing materiality, or can manufacture a discrepancy to force suspension of the other side's site. The plan cannot both promise automatic suspension and require double-key agreement to trigger it.

### 2.6.B Tags

- deadlock-default
- automatic-suspension
- materiality-definition
- shielding
- bad-faith-indicators
- dispute-resolution

### 2.6.C Mitigation

Pre-register in the instrument a governance annex with objective automatic-suspension triggers that do not require a co-chair vote. For example: an event not recorded within the agreed local-recording window, a covered item exiting without an assigned disposition after a fixed period, ledger divergence exceeding the reconciliation bound, access denied for more than a stated number of hours, or unverifiable equipment exceeding the site threshold. These triggers automatically place the affected equipment or site on hold while all other verification continues. Define the deadlock clock precisely: if co-chairs fail to issue a joint decision by a fixed deadline, the default is conservative suspension of the disputed action or area; no unilateral expansion, no unilateral blocking of an automatic trigger, and no leadership escalation more than once. Create a joint technical-fact mechanism for routine discrepancies; for contested materiality, refer the technical facts to a pre-agreed independent expert panel, with sanctions and suspension remaining under double-key after the facts are fixed. Pre-register bad-faith and shielding indicators, such as deliberate destruction of records, refusal to permit independent diagnostics, or government-directed non-cooperation, but do not require proof of intent for automatic consequences. Add a final-deadline clause: if leadership does not resolve a deadlock within 30 days, the affected activities remain suspended and no Go verdict can issue until the deadlock is resolved by joint written instruction.

### 2.6.D Consequence

Without objective triggers and a default decision rule, the no-overrule structure will be weaponized. The side that wants to shield an operator can dispute materiality forever; the side that wants to halt the program can manufacture discrepancies or simply refuse to agree. The 90-day window will be consumed by deadlock, and the final verdict will be either impossible or meaningless.

### 2.6.E Root Cause

The drafting team tried to preserve sovereign equality by prohibiting voting but did not build a default rule for inaction. It deferred the hard materiality design and substituted a political escalation path for a legal one.

---

# The following experts did not provide feedback:

# 3 Expert: Frontier AI Hardware Assurance Auditor

**Knowledge**: datacenter hardware lifecycle, semiconductor supply chains, equipment serialization, cryptographic attestation, hardware decommissioning

**Why**: Defines the confidential versioned covered-equipment schedule, intake staging identity gates, and exit dispositions that are the core of material-change verification.

**What**: Advise on attribute-based equipment coverage, staging-area identity checks, attestation limits, and the five exit dispositions in the ledger.

**Skills**: supply chain auditing, hardware identity verification, serialization programs, disposal verification, technical schedule versioning

**Search**: hardware assurance auditor, datacenter equipment lifecycle specialist, semiconductor supply chain verification expert

# 4 Expert: Information Barrier & Counterintelligence Engineer

**Knowledge**: information barrier design, clean-room examination, counterintelligence, critical infrastructure cybersecurity, sensitive data protection

**Why**: Balances filtered evidence with substitution detection and protects workloads, model weights, source code, and security architecture during joint inspections.

**What**: Specify filtered workstations, zone boundaries, and cyber-isolation drills; validate via blind challenges that identity metadata survives filtering.

**Skills**: filtered evidence systems, clean-room protocols, counterintelligence monitoring, incident isolation, adversarial validation

**Search**: information barrier engineer, counterintelligence technical specialist, clean-room evidence inspection cybersecurity expert

# 5 Expert: Red Team Adversarial Exercise Designer

**Knowledge**: red team operations, adversarial simulation, physical penetration testing, datacenter security, concealment tradecraft

**Why**: Designs the six mandated blind challenge types to validate false-negative rates and silent-window bounds before any Go decision.

**What**: Direct live exercises for unreported arrival, substituted equipment, vendor refusal, and reluctant operator scenarios using independent, no-advance-knowledge teams.

**Skills**: scenario planning, detection evasion testing, exercise instrumentation, KPI validation, opsec discipline

**Search**: red team exercise designer, adversarial simulation datacenter security, blind challenge testing expert

# 6 Expert: Bilateral Fiscal Governance Auditor

**Knowledge**: sovereign escrow administration, government appropriations, USD-CNY FX risk, envelope-based budgeting, audit compliance

**Why**: Prevents quiet fiscal vetoes and validates the 10-business-day funding delay trigger, escrow pre-funding, and quarterly reconciliation.

**What**: Review contribution-release mechanics, envelope mapping, and audit exceptions to ensure funding timeliness KPI prevents asymmetric delay.

**Skills**: escrow structuring, forensic accounting, currency risk management, government budget oversight, KPI threshold validation

**Search**: sovereign escrow fiscal governance expert, bilateral program auditor, government appropriations compliance specialist

# 7 Expert: Bilingual Inspectorate Workforce Planner

**Knowledge**: national security clearance processing, bilingual technical recruitment, shift scheduling, surge capacity planning, training curriculum design

**Why**: Builds and clears the ~450 FTE mirrored inspectorate with no single-person critical functions, meeting the inspector-approval entry condition.

**What**: Model staffing from site count, 24/7 coverage, 1.5x leave multiplier, and surge needs; accelerate clearances and second existing verification personnel.

**Skills**: workforce modeling, clearance pipeline management, bilingual hiring, training development, separation-of-duties design

**Search**: workforce planner security clearance hiring, bilingual inspector recruitment training, national security staffing surge specialist

# 8 Expert: Replicated Ledger & Attestation Architect

**Knowledge**: tamper-evident ledgers, hash-chain cryptography, cryptographic attestation, distributed replication, divergence reconciliation

**Why**: Implements local-first hash-chained recording and bounded cross-national synchronization without relying on banned blockchain architecture.

**What**: Advise on ledger latencies, divergence alerts, hash-commitment exchange, and penetration-test outcomes to meet 5-minute local and 1-hour sync targets.

**Skills**: cryptographic design, tamper-evident systems, penetration testing oversight, latency optimization, reconciliation protocols

**Search**: tamper-evident ledger architect, cryptographic attestation expert, hash-chain synchronization specialist