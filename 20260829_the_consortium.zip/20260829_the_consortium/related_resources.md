## Suggestion 1 - INF Treaty Verification Regime (1987-2019), including Votkinsk/Magna continuous portal monitoring and the Joint Compliance and Inspection Commission (JCIC)

The 1987 U.S.-Soviet Intermediate-Range Nuclear Forces Treaty (in force June 1, 1988) eliminated an entire class of ground-launched missiles (500-5,500 km range) and was verified through reciprocal baseline data declarations, on-site inspections at declared deployment, elimination, and production facilities, short-notice inspections, monitored eliminations, and 13 years of continuous portal perimeter monitoring at a named Soviet missile plant (Votkinsk) and a U.S. plant (Magna, Utah), with tamper-indicating enclosures over canisters and sensor-based evidence. Implementation disputes were handled by a standing bilateral commission (JCIC) operating on consensus. The regime functioned for three decades until U.S. withdrawal in August 2019 amid alleged Russian violations.

### Success Metrics

2,692 missiles eliminated by the June 1991 deadline (U.S. 846; Soviet 1,846) - verified whole-class elimination.
Thousands of on-site inspections (on the order of 4,000-5,000) conducted over roughly three decades under the regime.
13-year continuous portal monitoring at Votkinsk and Magna completed on schedule (ended May 31, 2001), including resolution of the canister-discrimination problem (distinguishing permitted SS-25 canisters from prohibited missile canisters).
JCIC resolved hundreds of implementation and interpretive questions over the treaty's life without a unilateral-overrule mechanism.
Cautionary outcome metric: the treaty ended in 2019 via withdrawal amid alleged violations - verification procedures survived; political support did not.

### Risks and Challenges Faced

Distinguishing permitted from prohibited canisters at Votkinsk could not be done visually; mitigated by tamper-indicating shrouds/enclosures plus portal sensors and weight checks - a direct lesson for attribute-based, versioned covered-equipment screening rather than product-anchored lists.
Short-notice cross-border inspection logistics (visas, manifests, equipment import) repeatedly strained timelines; mitigated by standing inspection infrastructure, pre-cleared visas, and pre-agreed equipment lists - the historical basis for the Consortium's inspector-access annex.
Interpretive disputes (notifications, geometry, counting rules) could have deadlocked; mitigated by routing everything through the JCIC with pre-agreed procedures and written consensus records - analogous to the Consortium's pre-registered interpretive annex and joint technical teams.
Political breakdown ultimately terminated the regime despite functioning procedures; lesson: verification cannot outrun politics, so continuity commitments, KPI-visible reciprocity metrics, and impairment-of-confidence machinery (already in the Consortium plan) must be treated as first-class controls, not afterthoughts.

### Where to Find More Information

U.S. Department of State INF Treaty Archive Collection: https://www.state.gov/inf-treaty-archive-collection/
Arms Control Association INF fact sheets and history: https://www.armscontrol.org/factsheets/INFtreaty
NTI treaty profile: https://www.nti.org/education-center/treaties-and-regimes/intermediate-range-nuclear-forces-inf-treaty/
OSTI.gov technical literature on Votkinsk portal monitoring and tamper-indicating systems: https://www.osti.gov

### Actionable Steps

Contact Sandia National Laboratories' Cooperative Monitoring Center (Albuquerque, NM), established in 1994 to develop and exercise cooperative monitoring technologies with foreign partners, including historical joint workshops with Chinese technical institutes; reach it via https://www.sandia.gov and request the CMC group.
Engage the Arms Control Association (Washington, DC) - Executive Director Daryl Kimball - via the contact form at armscontrol.org or LinkedIn, for INF implementation histories and practitioner referrals.
For the Russian-side practitioner perspective, contact the PIR Center (Moscow) via pircenter.org, which has published extensive INF verification analyses.
Request a briefing from the U.S. State Department Bureau of Arms Control, Verification and Compliance (AVC) via state.gov regarding INF lessons relevant to new verification instruments.

### Rationale for Suggestion

This is the closest existing bilateral precedent to the Consortium's architecture: reciprocal access at a matched set of declared production and deployment sites; continuous on-site presence at a named 'participating site' (Votkinsk); tamper-evident enclosures and sensor evidence layered with records; a pre-agreed baseline data exchange as an entry gate (analogous to the joint baseline inventory condition); short-notice arrival windows (analogous to latency budgets); and a joint commission that resolved implementation questions without either side overruling the other. Geographical proximity priority: no U.S.-China bilateral verification regime has ever existed, so the U.S.-Soviet record is the only completed template for sovereign-pair on-site verification and is included for that reason; its China-side gap is partially covered by items 3 and 6.
## Suggestion 2 - U.S.-Soviet Joint Verification Experiment (JVE), 1988

A bounded, reciprocal technical experiment agreed at the December 1987 Washington summit: a U.S. team deployed CORRTEX hydrodynamic measurement equipment at the Soviet Semipalatinsk nuclear test site (September 1988), while a Soviet team deployed instruments at the U.S. Nevada Test Site (August 1988), to measure underground test yields against the 150 kt Threshold Test Ban Treaty limit. Techniques, team sizes, data handling, access, and information protection were pre-agreed; only agreed derived data were exchanged, and the completed results directly enabled U.S. and Soviet ratification of the TTBT and PNET in 1990. Companion nongovernmental experiments (NRDC-Soviet Academy of Sciences seismic field tests, 1986-1990) tested joint monitoring at the same sites under an even looser but real reciprocal framework.

### Success Metrics

Both reciprocal experiments executed on schedule within the agreed 1988 windows at Semipalatinsk and the Nevada Test Site.
Measured yields proved consistent with declared values and the 150 kt limit, withstanding post-hoc scrutiny.
Directly credited with unblocking TTBT and PNET ratification (U.S. Senate consent October 1990; Soviet ratification the same period).
Established the template for later cooperative experiments, including the NRDC-Soviet Academy seismic tests and GSETT seismic exchanges.

### Risks and Challenges Faced

Exposure of classified test-site and weapon information was the central risk; mitigated by agreeing a single measurement technique per side, restricting what was measured and who was present, and exchanging only derived, protocol-defined data - a working proof that filtered-evidence boundaries survive real inspections when negotiated before the clock starts.
Asymmetric methodologies (U.S. hydrodynamic vs Soviet seismic/remote sensing) risked reciprocity complaints; mitigated by explicit acceptance of unequal techniques in exchange for equal access - precedent for the Consortium's negotiated parity rather than assumed symmetry.
Risk that results would contradict declarations and politically damage one side; mitigated by pre-registering the data-interpretation protocol before execution - the exact design of the Consortium's pre-registered thresholds and interpretive annex.

### Where to Find More Information

OSTI.gov - search 'Joint Verification Experiment' and 'CORRTEX' for LANL/LLNL/Sandia technical reports: https://www.osti.gov
DOE OpenNet declassified document database: https://www.osti.gov/opennet/
Arms Control Today archives (1988-1990) on JVE and TTBT ratification: https://www.armscontrol.org
NTI Threshold Test Ban Treaty profile: https://www.nti.org/education-center/treaties-and-regimes/threshold-test-ban-treaty-ttbt/

### Actionable Steps

Contact Lawrence Livermore National Laboratory's Global Security (arms control and verification) directorate via llnl.gov for JVE program histories and names of surviving participants.
Contact Los Alamos National Laboratory public affairs (lanl.gov) regarding CORRTEX development and JVE deployment teams.
Use the Nevada National Security Site (nnss.gov) history office for Nevada-side exercise documentation.
For accessible expert synthesis, contact Hans Kristensen, Director of the Nuclear Information Project at the Federation of American Scientists, via fas.org or LinkedIn.

### Rationale for Suggestion

JVE is the closest historical analogue to the Consortium's 90-day Phase One: a time-boxed operational test that began only after a signed instrument and explicit entry conditions, ran reciprocally at classified sites in both countries, protected sensitive information through strictly bounded measurement channels, and concluded with exchanged results and a political decision gating the next step (ratification, functionally a Go/Modify/Stop). Geographical proximity priority: no U.S.-China joint verification exercise has ever been conducted; JVE remains the only completed sovereign-pair joint measurement exercise at each other's most sensitive facilities, and is included despite the distance for that unique fit.
## Suggestion 3 - IAEA Safeguards, Additional Protocol, and Information-Barrier Technology (including the U.S.-Russia-IAEA Trilateral Initiative, c. 1996-2010)

The IAEA has verified declared nuclear material and equipment at state-declared facilities since 1957, under comprehensive (INFCIRC/153) and voluntary-offer agreements, with the 1997 Additional Protocol (INFCIRC/540) adding complementary and managed access. Its toolkit maps directly onto the Consortium: design information verification and physical inventory verification (trusted baseline), tamper-indicating and electronic seals (e.g., E2200, C1S), authenticated remote and unattended monitoring with bounded data transmission, and information barriers that let inspectors verify attributes without revealing classified or proprietary data - technology matured under the Trilateral Initiative to verify classified-form fissile material. China is an NPT nuclear-weapon state with a voluntary-offer safeguards agreement (INFCIRC/369, 1989) and a list of selected declared civilian facilities under safeguards.

### Success Metrics

Safeguards implemented in well over 180 states, with an annual Safeguards Implementation Report issuing state-level conclusions.
Containment and surveillance (seals, cameras, authenticated remote monitoring) operating continuously at hundreds of facilities worldwide for decades.
Trilateral Initiative produced working attribute-measurement-with-information-barrier prototypes that verified classified-form material without revealing design information - documented in IAEA symposium proceedings.
Post-1991 reforms (Additional Protocol, environmental sampling) after the Iraqi detection failure - a measured, documented detection-rate improvement over the declared baseline.

### Risks and Challenges Faced

Iraq 1991: the regime detected post-hoc, not in advance, because it was confined to declared sites; mitigated by broader legal access (Additional Protocol) - the reason the Consortium must state its scope honestly (monitored changes at declared sites only) and pre-register that limitation.
Managed access can hide the very indicators inspectors need; mitigated through guided-access protocols and information barriers calibrated by facility and event type, validated by repeated real inspections - the direct precedent for validating barrier rules in blind exercises before deployment.
Information barriers initially slowed inspections dramatically; mitigated by redesigning outputs to be attribute-only and time-bounded - precedent for budgeting latency for filtered evidence inside the Consortium's latency windows.
Politicization and budget pressure on conclusions; mitigated by transparent, published methodology and independent evaluation - the precedent for independent validation of the Consortium's KPI thresholds.

### Where to Find More Information

IAEA safeguards overview: https://www.iaea.org/topics/safeguards
IAEA Additional Protocol: https://www.iaea.org/topics/additional-protocol
IAEA INFCIRC/369 (China voluntary offer) via IAEA INFCIRC collection: https://www.iaea.org/publications
NTI and CNS profiles of the Trilateral Initiative: https://www.nti.org ; https://nonproliferation.org

### Actionable Steps

Request a technical briefing from the IAEA Department of Safeguards (Division of Technical Support: seals, remote monitoring, information barriers) via OfficialMail@iaea.org.
Contact VERTIC (London) at info@vertic.org for verification legal implementation, information-barrier literature, and inspector-training curricula.
Engage the James Martin Center for Nonproliferation Studies (Monterey) - founding director Dr. William Potter - via nonproliferation.org for Trilateral Initiative documentation and China-IAEA history.
Search LinkedIn for current and former IAEA Department of Safeguards staff in the Division of Technical Support and approach with a concise, specific briefing request on information-barrier validation exercises.

### Rationale for Suggestion

This is the primary methodological source for four Consortium levers: baseline inventory as a certification gate (PIV/DIV), equipment identity via seals and identifiers, tamper-evident authenticated evidence transmission (the functional analogue of the Consortium's replicated ledger with hash commitments), and information barriers proving attributes without exposing protected data (the filtered-evidence architecture). Critically for the geographic-proximity priority, this is the major regime that includes China as a verified state and decades of IAEA operating history at Chinese facilities, making it the most China-proximate verification body in existence; the U.S.-side equivalents (safeguards under the U.S. voluntary offer, e.g., at selected enrichment and reactor facilities) complete the bilateral picture the Consortium needs.
## Suggestion 4 - CTBTO On-Site Inspection Integrated Field Exercises (IFE08, Kazakhstan, 2008; IFE14, Jordan, 2014) [SECONDARY SUGGESTION]

The Comprehensive Nuclear-Test-Ban Treaty Organization (Vienna, 1996-present) has repeatedly tested its on-site inspection concept through full-scale field exercises with dozens of participating states: IFE08 at the former Semipalatinsk test site (Kazakhstan, 2008) and IFE14 near the Dead Sea, Jordan (November 2014; roughly 250 experts from about 50 states over approximately three weeks). Exercises rehearsed the complete inspection lifecycle - inspection-area designation, point design, managed access, information barriers, overflights, radionuclide laboratory workflows - with controlled true events and injected false leads, and produced published after-action findings. China participates in the CTBTO and hosts International Monitoring System facilities.

### Success Metrics

IFE14 executed within its planned multi-week window with ~50 participating states and hundreds of simulated measurement events, both genuine and injected false positives.
Published, reusable OSI planning protocols, checklists, and lessons-learned documents.
IMS of 300+ certified facilities transmitting authenticated data to the International Data Centre on an operational schedule.

### Risks and Challenges Faced

Over-filtering by information barriers was found to strip contextual indicators; mitigated by iterative re-design of barrier rules between exercises - the direct precedent for the Consortium's requirement to validate barrier rules in blind runs before deployment.
Multinational logistics (visas, equipment import, host-state access) dominated planning effort; mitigated by pre-cleared manifests and host-state annexes - matching the Consortium's inspector-access annex.
The OSI Operational Manual remains unadopted because the treaty is not in force; mitigated by an exercise-first strategy keeping capability alive - precedent for marking the Consortium's provisional/TBD KPI thresholds and validating them operationally rather than on paper.

### Where to Find More Information

CTBTO verification regime and OSI pages, including IFE14 reporting: https://www.ctbto.org
VERTIC on-site inspection resources: https://www.vertic.org

### Actionable Steps

Contact the CTBTO Preparatory Commission's On-Site Inspection Division in Vienna at info@ctbto.org and request IFE14 after-action documentation.
Approach CTBTO Executive Secretary Robert Floyd's office for briefings on multinational exercise design via ctbto.org.

### Rationale for Suggestion

The best available real-world template for the Consortium's mandatory blind-challenge program and its bounded-mission rhythm (OSI is designed as a 60-70 day exercise window, structurally similar to the 90-day Phase One), including how information barriers and managed access perform with real multinational teams and how hundreds of discrete observations aggregate into a defensible post-exercise report.
## Suggestion 5 - New START Bilateral Inspection Regime (2011-2023; term ended at latest February 5, 2026) [SECONDARY SUGGESTION]

The most recent reciprocal, quota-based on-site inspection regime between equal sovereigns: biannual data exchanges, baseline data on declared strategic facilities, unique identifiers on deployed launchers, up to 18 short-notice inspections per year per side (10 Type One, 8 Type Two), up to five telemetry exchanges per year, and a standing Bilateral Consultative Commission. Inspections were paused in March 2020 due to COVID-19; Russia suspended participation in February 2023 without formally withdrawing; the treaty's maximum term (after its single extension) ran to February 5, 2026.

### Success Metrics

More than 300 on-site inspections conducted under parity quotas from 2011 until the 2020 pause.
Facilities database and baseline data exchanges maintained on schedule for roughly a decade.
Bilateral Consultative Commission resolved implementation questions for years without unilateral overrule.
Cautionary outcome: inspections frozen 2020, participation suspended 2023, regime lapsed by February 2026 without replacement - political continuity, not technique, was binding.

### Risks and Challenges Faced

COVID-19 forced a total inspection halt while the clock ran; mitigated partially by continued data exchanges - lesson: build public-health and disruption contingencies into any fixed 90-day operational window.
Russia's 2023 'suspension' created a gray zone of non-performance short of withdrawal; lesson: the Consortium's pre-registered automatic-suspension triggers and KPI-visible contribution-delay thresholds are the correct antidote and should be exercised in drills, not left theoretical.
Telemetry-access disputes tested what counts as credible detection; lesson: define evidence-class independence and detection thresholds before the clock starts, as the Consortium's layered-evidence lever specifies.

### Where to Find More Information

U.S. State Department New START pages: https://www.state.gov/new-start/
Arms Control Association New START fact sheets: https://www.armscontrol.org/factsheets/NewSTART
PIR Center analyses of New START implementation: https://pircenter.org

### Actionable Steps

Request implementation lessons from the U.S. State Department Bureau of Arms Control, Verification and Compliance via state.gov.
For the Russian-side practitioner view on suspension mechanics and inspection parity, contact the PIR Center (Moscow) via pircenter.org.
Follow Arms Control Association (Daryl Kimball) via LinkedIn for ongoing analysis of the post-New START verification landscape.

### Rationale for Suggestion

The clearest modern demonstration of both the strengths and failure modes of exactly the Consortium's structure - matched declared facilities, parity quotas, unique equipment identifiers, and a standing joint commission - and the most recent cautionary tale on quiet suspension without formal exit, pandemic interruption of a fixed verification clock, and political discontinuity, which the Consortium plan already treats via automatic-suspension triggers and funding-timeliness KPIs.
## Suggestion 6 - OPCW Verification Regime: Industrial Confidentiality Annex and OPCW-Verified Destruction of Japanese Abandoned Chemical Weapons at Declared Sites in China [SECONDARY SUGGESTION]

The Chemical Weapons Convention (in force 1997; 193 member states) operates the only permanent verification organization conducting routine industry inspections under a strict Confidentiality Annex protecting proprietary and industrial information, plus never-invoked Article IX challenge-inspection provisions. Since roughly 2000, the OPCW has also verified the recovery and destruction of Japanese abandoned chemical munitions at declared sites in China (e.g., the Haikou mobile destruction operation beginning 2014, and the large Haerbaling burial site in Dunhua, Jilin), with Japanese-funded teams, Chinese managed access and escort, and OPCW on-site verification - foreign inspectors working continuously at declared Chinese sites under tight information controls for over two decades.

### Success Metrics

Tens of thousands of abandoned chemical munitions recovered, documented, and destroyed under OPCW verification at Chinese sites.
Decades of industrial inspections worldwide conducted under the Confidentiality Annex without major leakage incidents.
Institutional credibility recognized by the 2013 Nobel Peace Prize.
Cautionary metric: Article IX challenge inspections have never been invoked in nearly three decades - escalation that is never exercised atrophies.

### Risks and Challenges Faced

Repeated deadline slips in abandoned-weapons destruction were absorbed by revised milestones and mobile destruction technology rather than regime collapse; lesson: build re-phasing and recovery into the Consortium's fixed clock and contingency envelope instead of brittle all-or-nothing deadlines.
Simultaneously protecting state secrets and industrial proprietary data; mitigated by tiered confidentiality handling with designated, credentialed information handlers - the direct operational precedent for the Consortium's filtered workstations and clean-room examination.
Deterrence paradox of a never-used challenge mechanism; lesson: the Consortium's mandatory live challenge types (including vendor refusal and delayed access) exist precisely to prevent this atrophy and should remain non-negotiable entry conditions.

### Where to Find More Information

OPCW annual reports, verification pages, and abandoned-chemical-weapons documentation: https://www.opcw.org
Japan MOFA pages on abandoned chemical weapons in China: https://www.mofa.go.jp (search 'abandoned chemical weapons')
CNS resources on OPCW verification: https://nonproliferation.org

### Actionable Steps

Request a briefing from the OPCW Verification Division via the contact portal at opcw.org, specifically on Confidentiality Annex implementation and managed-access procedures.
Contact Japan's Cabinet Secretariat/MOFA abandoned-chemical-weapons office (via mofa.go.jp) for the operator-side experience of running verified destruction at Chinese sites.
For the China-side perspective, route through China's MFA arms-control department via official channels in Beijing.

### Rationale for Suggestion

The most China-proximate on-site verification precedent available: two decades of foreign-verified operations at declared Chinese sites with managed access, escorted movement, joint national teams, and dual protection of state and industry secrets - directly relevant to Consortium site operations in the Beijing/Hebei and Guizhou regions. The Confidentiality Annex is the strongest existing legal-operational model for filtered evidence around proprietary technology, and the never-exercised challenge mechanism is a cautionary precedent for the Consortium's requirement to live-exercise its discrepancy escalation.
## Suggestion 7 - UK-Norway Initiative and the International Partnership for Nuclear Disarmament Verification (IPNDV) - Cross-National Verification Exercises with Information Barriers [SECONDARY SUGGESTION]

The UK-Norway Initiative (established mid-2000s, main program roughly 2006-2012 with follow-on cooperation) developed and exercised disarmament-verification methods between a nuclear-weapon state and a non-nuclear-weapon state, using mock sensitive equipment and formal information barriers so that inspectors without clearance could verify attributes without exposure to design information; lessons were published. IPNDV (launched 2015; 25+ states) institutionalized working groups and practical exercises (tabletop and technical, 2017-2022) on dismantlement verification, information barriers, and joint-team procedures.

### Success Metrics

Multiple completed cross-national exercises with published after-action lessons adopted into IPNDV and IAEA discussions.
Working attribute-only information-barrier outputs demonstrated with real (mock-equipment) inspection teams.
IPNDV's 25+ state membership sustained across multiple multi-year phases, including states from both sides of Cold War divides.

### Risks and Challenges Faced

Information barriers initially slowed inspections severely; mitigated by redesigning to attribute-only outputs and time-boxed procedures - lesson: the Consortium must budget latency explicitly for filtered evidence within its 4h/24h/1h windows.
Legal and clearance asymmetry between national teams caused procedural friction; mitigated by common training and jointly approved procedures before exercises - lesson: mirrored training is a pre-clock certification item, as the Consortium plan already requires.

### Where to Find More Information

UK government publications on the UK-Norway Initiative: https://www.gov.uk (search 'UK-Norway Initiative verification')
IPNDV working group outputs and exercise reports: https://ipndv.org
VERTIC verification training resources: https://www.vertic.org

### Actionable Steps

Contact the IPNDV secretariat via the U.S. State Department Bureau of Arms Control, Verification and Compliance (state.gov) for exercise curricula and participant referrals.
Contact VERTIC at info@vertic.org for UKNI documentation and verification-training materials.
For the Norwegian side, contact the Norwegian Radiation and Safety Authority (DSA) via dsa.no, which participated in UKNI work.

### Rationale for Suggestion

The best-documented real experiments for the Consortium's defining trade-off: cross-national teams verifying hardware they are explicitly barred from understanding, with published exercise curricula the Consortium can reuse directly for mirrored-team training, information-barrier calibration, and blind-challenge design.

## Summary

There is no direct U.S.-China bilateral on-site verification precedent, so this recommendation set triangulates across the closest real-world families of projects, and explicitly justifies the geographic distance where necessary. (1) The U.S.-Soviet Joint Verification Experiment (JVE, 1988) is the single closest analogue to the Consortium's 90-day Phase One: a bounded, entry-condition-gated, reciprocal operational test with pre-agreed techniques, protected information, exchanged validated data, and an end decision that gated the next political step. (2) The INF Treaty verification regime (1987-2019) is the only fully tested sovereign-pair template for continuous presence at matched declared production sites, tamper-evident enclosures, baseline data exchange, short-notice arrival windows, and a standing joint commission without a casting vote. (3) IAEA safeguards and the Additional Protocol - including the Trilateral Initiative's attribute-measurement-with-information-barrier prototypes - supply the methodological core for baseline inventories, seals/identifiers, authenticated evidence transmission, and filtered evidence that proves attributes without exposing protected data; China is itself a verified IAEA state, making this the most China-proximate methodological source. Secondary references: CTBTO's Integrated Field Exercises (blind-challenge template), New START (reciprocal quota inspections and a cautionary tale on quiet suspension and political discontinuity), the OPCW regime including Japanese abandoned-chemical-weapons verification at declared sites in China (foreign inspectors on Chinese soil, industrial confidentiality, never-exercised escalation), and the UK-Norway Initiative/IPNDV (cross-national teams verifying hardware they are barred from understanding). The recurring lesson across all seven: technique is solvable; entry-condition discipline, tested information barriers, reciprocity metrics, and political-continuity machinery are the decisive variables - exactly the tensions the Consortium's levers target.