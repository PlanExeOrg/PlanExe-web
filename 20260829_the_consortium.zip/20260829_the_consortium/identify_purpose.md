**Purpose:** business

**Purpose Detailed:** This plan outlines a sovereign public-sector initiative aimed at verifying the arrival, installation, and maintenance of computing equipment relevant to frontier AI, ensuring national security through a jointly governed mechanism between the United States and China.

**Topic:** Bilateral national security program for AI equipment verification