**Purpose:** business

**Purpose Detailed:** Governmental national-security program for verifying material changes to frontier-relevant computing equipment in declared datacenters, with bilateral governance, fiscal accountability, and operational testing.

**Topic:** US-China bilateral verification of frontier AI computing equipment at declared datacenters