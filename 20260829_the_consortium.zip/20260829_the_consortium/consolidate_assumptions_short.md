# Purpose
# Purpose

- Business: Governmental national-security program for verifying material changes to frontier-relevant computing equipment in declared datacenters.
- Details: Bilateral governance, fiscal accountability, and operational testing.
- Topic: US-China bilateral verification of frontier AI computing equipment at declared datacenters.


# Domain
# Primary domain

- Treaty Verification

# Secondary domains

- Cryptographic Attestation
- International Law
- Hardware Assurance

# Rationale

- Treaty Verification owns the mission: confirming material equipment changes under a bilateral agreement, with exercises and adjudication serving it.
- Hardware Assurance, Information Barrier Engineering, and Red Teaming are important methods but subordinate to the verification outcome.

# Disciplines

- Treaty Verification: importance 5, specificity 5, role outcome, reason Core mission is verifying equipment changes under a bilateral monitoring agreement.
- Hardware Assurance: importance 5, specificity 5, role method, reason Confirms identity, provenance, and alteration of computing hardware at participating sites.
- Information Barrier Engineering: importance 5, specificity 5, role method, reason Filtered evidence and bounded zones require engineered barriers protecting sensitive data while proving attributes.
- Red Teaming: importance 4, specificity 5, role method, reason Executes blind challenge exercises to validate detection and reciprocal access.
- Cryptographic Attestation: importance 4, specificity 4, role method, reason Layered identity verification uses validated cryptographic attestation and a tamper-evident ledger.
- Counterintelligence: importance 4, specificity 4, role constraint, reason Protects sensitive technology and enforces information barriers between national teams.
- Distributed Systems Engineering: importance 4, specificity 4, role method, reason Replicated tamper-evident ledger with bounded synchronization is core project infrastructure.
- Data Center Operations: importance 4, specificity 4, role stakeholder, reason Operators and maintenance vendors are essential participants whose facilities are the inspection targets.
- International Law: importance 4, specificity 3, role constraint, reason Bilateral instrument and domestic access authority are mandatory entry conditions.


# Plan Type
# Physical Location Requirement

- Plan cannot be executed digitally.

## Required Physical Activities

- On-site verification of computing equipment at declared datacenters.
- Physical inspection of material arrivals and removals.
- Installation and decommissioning monitoring.
- Controlled staging areas and witnessed movement.
- Physical security and counterintelligence at real facilities.
- Deployment of inspectors, technical personnel, red teams, and logistics staff.

## Operational Dependencies

- Travel and physical preparation of sites.
- Operator and vendor participation at physical facilities.
- Real-world challenge exercises involving equipment substitutions and staged events.

## Evidence and Testing

- Requires tamper-evident physical evidence.
- Requires real-world operational testing.


# Physical Locations
# This plan implies one or more physical locations.

## Requirements for physical locations

- Jointly selected declared datacenter sites in both the United States and China, matched for comparable verification burden
- Controlled staging areas for pre-installation equipment identity verification
- Bounded inspection zones supporting filtered evidence collection and clean-room examination
- Physical security, cybersecurity, and counterintelligence infrastructure adequate for a sovereign national-security program
- Controlled access for mirrored national inspection teams, technical specialists, escorts, and approved vendors
- Reliable power, cooling, network capacity, and logistics support for live challenge exercises without disrupting active computational work
- Space for witnessed movement, maintenance monitoring, and exit/disposition verification

## Location 1

United States: Northern Virginia / Ashburn, Loudoun County, Virginia

Ashburn, Virginia, USA — major declared datacenter corridor; exact facility to be jointly selected

Rationale: Northern Virginia is the largest datacenter concentration in the United States and likely to host frontier-relevant computing equipment. Its mature infrastructure, multiple operators, and logistics access support staging areas, bounded inspection zones, and repeated live exercises.

## Location 2

China: Beijing/Hebei cluster

Langfang / Beijing-area declared datacenter facilities, Hebei/Beijing, China — exact facilities to be jointly selected

Rationale: The Beijing/Hebei region hosts major Chinese frontier AI and high-performance computing facilities, making it a likely area for declared sites. It provides the high-density computing infrastructure and operator presence needed for matched-pair verification with U.S. sites.

## Location 3

China: Guizhou Province

Gui'an New Area / Guizhou national datacenter hub, China — candidate for an additional matched or stress-test site

Rationale: Guizhou is one of China's principal national datacenter hubs and could serve as a second or stress-test site. Its geographic separation and different operating environment help calibrate parity across facility types and test the Consortium's ability to verify under unequal conditions.

## Location Summary

The Consortium cannot operate digitally: it requires physical datacenter sites in both countries for on-site verification, staging, maintenance monitoring, and live challenge exercises. The suggested locations—Northern Virginia, the Beijing/Hebei cluster, and Guizhou—represent high-concentration datacenter regions in both countries and offer the infrastructure, operator ecosystems, and alternative facility profiles needed for matched-site calibration and credible Phase One testing. Final sites must be jointly selected and declared by the two governments.

# Currency Strategy
# Currencies

- USD: Program budget explicitly denominated in USD (USD 5 billion total, USD 2.5 billion per country); USD is practical standard for consolidated budgeting, reporting, and cross-border fiscal reconciliation.
- CNY: China-side operator compensation, vendor payments, facility preparation, and local logistics are administered by the Chinese government and incurred in China; CNY is needed for domestic disbursements and local cost tracking.

## Primary currency

- USD

## Currency strategy

- Use USD as the single consolidated budgeting, reporting, and appropriation-tracking currency for the full USD 5 billion program.
- Permit each government to disburse local operating payments in its own domestic currency (USD for U.S. sites, CNY for China sites) against its USD-denominated contribution.
- Maintain joint escrow and quarterly reconciliation in USD.
- Manage exchange-rate risk through structured conversion windows and periodic revaluation.
- Keep budget-envelope tracking stable regardless of currency movements.


# Identify Risks
## Risk 1 - Governance & Political

- The equal-national co-chair and double-key structure has no casting vote or pre-agreed deadlock procedure, allowing one co-chair to block decisions indefinitely.
- Impact: Deadlocked material findings can trigger automatic suspension; Phase One may fail to produce a Go/Modify/Stop verdict within 90 days, consuming the $250M legal and $500M contingency envelopes; a politically motivated deadlock could stop the $5B program.
- Likelihood: Medium
- Severity: High
- Action: Pre-register a bounded deadlock procedure before the clock starts, route routine discrepancies to joint technical teams, refer factual disputes to a jointly selected arbiter, record deadlock duration as a KPI with a pre-agreed threshold, and escalate to automatic suspension only for material discrepancies.

## Risk 2 - Regulatory & Permitting

- Phase One starts only after multiple political acts, with no outer limit or fallback if conditions remain uncertified.
- Impact: Operational test could be delayed 6-24 months or indefinitely; trained teams may be idled, consuming the $750M inspectorate envelope without producing verification evidence; political leadership may change before start.
- Likelihood: High
- Severity: High
- Action: Create an integrated readiness tracker with reciprocal certification, run all preparatory workstreams in parallel, use provisional shadow exercises after site selection, and include a mutual commitment to complete entry conditions within an agreed maximum period with KPI-visible delays and escalation to heads of state or party leadership.

## Risk 3 - Regulatory & Permitting

- Domestic courts, regulators, local governments, or private operators may challenge foreign or international inspector authority despite planned domestic access authority.
- Impact: An injunction or ruling could block inspectors for weeks or months, creating an asymmetric-access Stop condition; litigation and legislative fixes could add $10-50M and delay Phase One by 3-6 months.
- Likelihood: Medium
- Severity: High
- Action: Enact a clear domestic legal framework before clock start that overrides conflicting private-law objections, defines inspector privileges and limits, binds operators and vendors contractually, and establish a joint legal task force with rapid dispute-resolution clauses in the bilateral instrument.

## Risk 4 - Financial

- Each government contributes USD 2.5B, with domestic compensation paid separately; appropriation delays, exchange-rate disputes, or slow disbursement can starve the program without formally triggering the withholding-funding Stop condition. Fixed USD budget with CNY-denominated China-side costs creates currency and inflation exposure.
- Impact: A 6-12 month funding delay would idle the inspectorate and break reciprocity parity; a 5% currency or local-inflation shock could add $125-250M, consuming the $500M contingency before independent testing.
- Likelihood: Medium
- Severity: High
- Action: Require pre-funded full contributions in a jointly signatory escrow before clock start, use quarterly USD reconciliation and envelope-approved drawdowns, structured currency conversion windows and periodic revaluation, and treat contribution-release delay beyond a pre-agreed window as an automatic KPI-visible suspension trigger.

## Risk 5 - Supply Chain

- Manufacturers, maintenance providers, and logistics companies could refuse cooperation, citing proprietary technology, export controls, or national law; a dominant vendor's refusal can affect multiple sites simultaneously.
- Impact: Equipment served by the refusing vendor could become unverifiable, potentially failing Phase One and moving the verdict to Stop; escalation could consume 2-6 weeks per refusal and draw down contingency and inspectorate envelopes.
- Likelihood: Medium
- Severity: High
- Action: Negotiate model vendor-access agreements before clock start, bind operators to enforce vendor participation, pre-accredit independent clean-room examiners, cross-train inspectors for vendor-supervised diagnostics, stock spare hardware, and define a per-site unverifiable-equipment threshold that triggers escalation before the materiality corridor is breached.

## Risk 6 - Security & Technical

- The information-barrier architecture must protect sensitive data while providing enough contextual evidence; over-filtering can hide substitution evidence and under-filtering can leak technology.
- Impact: Blind-challenge detections could fall and produce a false negative, or a leak could terminate the program and trigger national-security investigations; diplomatic cost could exceed the $5B budget.
- Likelihood: High
- Severity: High
- Action: Design bounded inspection zones and filtered workstations by event type, use cryptographic hashes for evidence integrity, test the barrier in blind exercises, use clean-room protocols and accredited independent examiners for sensitive inspections, and implement a joint cyber-incident response plan that isolates leaks without halting all verification.

## Risk 7 - Operational & Technical

- Credible detection depends on the maximum time between a physical material change and verified ledger appearance; red teams can exploit long or unverifiable interior windows.
- Impact: Missed latency targets would fail the KPI dashboard and force a Modify verdict; if thresholds are too loose, events could remain silent for 24-72 hours, undermining the Go decision.
- Likelihood: Medium
- Severity: High
- Action: Predefine and validate thresholds such as operator reporting within 4 hours, physical confirmation within 24 hours, and ledger recording within 1 hour; use tamper-evident local recording, unannounced random sweeps, and independent monitoring of interior windows.

## Risk 8 - Technical

- The replicated tamper-evident ledger must synchronize within a bounded window; outages, defects, or tampering can cause divergence, which is a designated Stop condition.
- Impact: Unresolved divergence would trigger a Stop recommendation; slow detection could leave both governments relying on conflicting records; reconciliation exercises could consume 1-4 weeks and cost $5-20M.
- Likelihood: Medium
- Severity: Medium
- Action: Set a bounded synchronization window with automatic divergence alerts, maintain local-first recording, run regular reconciliation drills with independent test events, and exchange continuous hash commitments to prove tamper-evidence without exposing sensitive content.

## Risk 9 - Operational & Political

- Matched sites in Northern Virginia, Beijing/Hebei, and Guizhou differ in size, layout, vendor ecology, security rules, and operating culture; paper matching may not make inspection difficulty equal.
- Impact: Negotiation over the matched set could stall certification; asymmetric sites could cause political collapse, a Stop verdict, and incomparable red-team results.
- Likelihood: High
- Severity: High
- Action: Jointly define parity using multiple attributes including equipment value, operational role, layout, and security constraints; benchmark reciprocal access hours and inspection outcomes during readiness; deliberately include harder-to-inspect stress sites on each side.

## Risk 10 - Operational

- Full-time mirrored national units require enough cleared, bilingual, technically credible specialists with separation of duties and leave coverage; reliance on a small surge cadre creates single points of failure.
- Impact: Staffing gaps delay event response, invalidate evidence collection, and violate the no-single-person-critical-function rule; hiring and clearance costs could add 10-20% to the $750M inspectorate envelope, or $75-150M, and delay start by 3-6 months.
- Likelihood: Medium
- Severity: Medium
- Action: Build a workload-based staffing model, create a full-time surge cadre, cross-train specialists, start security clearances in parallel, and include retention bonuses and a training pipeline for technical inspectors.

## Risk 11 - Security

- The program is a high-value target for state-sponsored cyber operations, insider threats, and counterintelligence; a single compromise could undermine evidence integrity and create an international incident.
- Impact: A successful compromise could alter ledger records, leak the covered-equipment schedule, expose inspector travel plans, or reveal sensitive data; response and remediation could cost $10-100M, with political fallout causing suspension or withdrawal.
- Likelihood: Medium
- Severity: High
- Action: Implement strict need-to-know compartments, physical and logical separation of national teams, continuous counterintelligence monitoring, hardware-separated evidence systems, independent penetration testing, and a joint incident-response protocol that isolates compromised systems while preserving verification elsewhere.

## Risk 12 - Technical & Governance

- The Go decision depends on credible evidence; non-independent red teams, announced exercises, or unvalidated KPI thresholds can create false confidence.
- Impact: A Go based on scripted exercises could lead to reliance on a regime that cannot detect real substitution; thresholds too strict could cause a false Stop and waste the $5B investment; threshold negotiation could delay the verdict by weeks.
- Likelihood: Medium
- Severity: High
- Action: Use genuinely independent red teams with no advance knowledge, run unannounced exercises in staging, spare-inventory, and maintenance areas, pre-register all KPI thresholds with a validation plan, and require the KPI dashboard to show false-negative and false-positive rates, confidence intervals, and unresolved-discrepancy ages before any Go decision.

## Risk 13 - Technical

- The covered-equipment schedule must stay current, but revisions reopen the bilateral definitional bargain; static schedules miss new hardware and frequent revisions cause disputes.
- Impact: New architectures could ship outside verification for 4-8 weeks during double-key approval; a frozen schedule would make the regime's credibility decay immediately after launch.
- Likelihood: Medium
- Severity: Medium
- Action: Pre-negotiate an attribute-based coverage framework before clock start, include fast-track provisional listing within 48-72 hours, schedule sunset reviews linked to declared new generations, and require a versioned changelog with pre-registered dispute criteria.

## Risk 14 - Operational & Social

- Operators and vendors may reluctantly cooperate due to disruption, exposure of customer arrangements, or concerns about the protocol; reluctant operators can delay access, produce inaccurate records, or challenge evidence authenticity.
- Impact: Access delays could violate the latency budget and cause false results; production disruption claims could drive operators to seek exemptions or compensation beyond the $1B preparation and compensation envelope; uneven cooperation could trigger the Stop condition.
- Likelihood: Medium
- Severity: Medium
- Action: Bind operator participation as a condition of site eligibility, provide fair compensation through the operator's own government, pre-agree inspection windows that minimize production interference, escalate deliberate obstruction to the co-chairs, and test low-disruption inspection techniques during the exercise program.

## Risk 15 - Financial & Environmental

- The $5B budget is fixed with mapped envelopes; site preparation, secure facilities, and testing often overrun, and selected locations face power-grid, climate, and logistical risks.
- Impact: A 5-10% cost overrun equals $250-500M and would consume the contingency envelope; a severe weather or grid event could delay the 90-day test by 2-4 weeks and add $5-20M in emergency costs.
- Likelihood: Medium
- Severity: Medium
- Action: Institute envelope-level cost control with independent auditing and quarterly reforecasts, maintain a prioritized contingency-spending plan, select multiple fallback sites per country, and use structured currency conversion and fixed-price contracts where possible.

## Risk summary

- The risk landscape is dominated by political and institutional failure modes rather than purely technical ones.
- Three most critical risks: entry-condition and appropriations delay preventing Phase One start; vendor refusal and unverifiable-equipment contagion triggering Stop through a single dominant supplier; and information-barrier imbalance blinding inspectors or leaking sensitive technology and collapsing political support.
- These risks are mutually reinforcing: an information leak can cause funding delays, a vendor refusal can expose parity asymmetries, and deadlock over any issue can suspend the entire program.
- Key assumptions: both governments genuinely intend to meet entry conditions, suitable matched sites and qualified personnel can be identified within budget, and KPI thresholds will be validated before use.
- The largest source of remaining uncertainty is the absence of specified thresholds and finalized site or vendor agreements.
- Success should be judged only against the narrow mission of verifying monitored changes at declared sites, not as a broader AI-governance guarantee.


# Make Assumptions
## Question 1 - How should the USD 5 billion contributions be escrowed, released, and revalued to prevent delayed or asymmetric disbursement from acting as a quiet veto, and what exchange-rate rule should govern CNY-denominated China-side payments?

- Assumptions: Both governments pre-fund full USD 2.5 billion into a jointly signatory escrow before the Phase One clock starts; drawdowns only against envelope-approved expenditures, with quarterly USD reconciliation. China-side operator and vendor payments converted through quarterly structured windows with periodic revaluation. Contribution-release delay beyond 10 business days is a KPI-visible suspension trigger. Aligns with funding-timeliness KPI and currency_strategy.md.
- Assessments: Funding and Fiscal Accountability Assessment. Full pre-funding removes quiet-veto risk (Risk 4) and ensures reciprocal deployment for matched-site parity. Unhedged 5% CNY/USD movement or local-inflation shock could add USD 125-250 million; structured conversion windows and a dedicated FX reserve in the contingency envelope cap exposure. Drawdowns tied to envelope codes (ledger, site prep, inspectorate, facilities, testing, legal/audit, contingency) and audited quarterly. Benefits include predictable staffing and site preparation; escrow interest or treasury instruments may offset administrative costs, but returns must be returned to both governments to preserve non-commercial, sovereign nature.

## Question 2 - What is the maximum acceptable duration for the mandatory entry-condition phase, and how will the 90-day Phase One clock be jointly certified and kept on schedule if one government's legislative or site-selection process slips?

- Assumptions: Entry-condition phase capped at 12 months from political commitment (target 2027-Sep-04); integrated readiness tracker and parallel preparation across workstreams. Phase One clock starts only after co-chairs jointly certify all conditions; any open condition after 12 months escalates to heads of state and becomes a public KPI, but does not start the 90-day test. Consistent with Risk 2.
- Assessments: Timeline and Milestone Gating Assessment. Political actions (appropriations, domestic access authority, site selection, inspector approval, vendor/operator agreements, schedule adoption) can each delay 6-24 months if sequential; parallel workstreams and integrated tracker compress to a 12-month target. Clock must not start until all conditions are certified. Provisional shadow exercises keep teams warm without de facto obligations. Metrics: readiness checklist closure rate, days to certification, certified conditions at clock start; target 100% reciprocal certification. Risk: one-side slip idles trained staff and consumes inspectorate funding; mitigation includes provisional training and surge deployment only after joint certification.

## Question 3 - How many participating declared sites will constitute the matched set, and what workload-based staffing model—including mirrored national teams, shift coverage, leave backup, separation of duties, and a full-time surge cadre—will be required within the USD 750 million inspectorate envelope?

- Assumptions: Matched set is 6 declared sites (3 per country); 24/7 on-site coverage, no fewer than two full-time mirrored national inspectors per material event, 1.5x leave/backup multiplier, no single-person critical functions, separation of duties, and permanent surge cadre equal to 10% of baseline staffing. Baseline approximately 450 FTE across inspection, technical, legal, cybersecurity, counterintelligence, translation, audit, logistics, and adjudication units. Derived from Risk 10 guidance.
- Assessments: Resourcing and Staffing Feasibility Assessment. 450-person baseline at USD 200k loaded annual cost equals USD 90 million/year; 18-month readiness-plus-Phase-One period costs roughly USD 135 million, leaving headroom within USD 750 million envelope. 1.5x multiplier and 10% surge cadre add 15-20% above a minimal model. Risk: clearance delays and bilingual technical talent scarcity could add 10-20% cost (USD 75-150 million) and delay start 3-6 months; mitigation is parallel clearances and cross-training. Staffing depth serves as a reciprocity signal; asymmetric capacity would undermine the Go decision.

## Question 4 - How will the bilateral instrument pre-commit both governments to a deadlock-resolution procedure, automatic-suspension thresholds, and a binding bilingual glossary so that no single co-chair can indefinitely block a material finding or reinterpret a contested term?

- Assumptions: Instrument creates joint technical teams for routine discrepancies, refers deadlocked factual disputes to a jointly selected advisory arbiter, and limits automatic suspension to sites with unresolved material discrepancies. Deadlock persisting more than 10 business days is recorded on the KPI dashboard and escalates to leadership; binding bilingual glossary and pre-registered interpretive annex adopted before clock starts. Addresses Risk 1 and Decision 14 while preserving double-key authorization for sanctions and suspension.
- Assessments: Bilateral Governance and Legal Certainty Assessment. Without a bounded deadlock path, one co-chair can exploit delay to shield an operator or stall the verdict. Pre-registered glossary and annex convert future disputes into lookup operations; joint technical teams keep routine discrepancies from the political level. The 10-business-day threshold balances no-unilateral-overrule against timely findings; too long ages material discrepancies, too short escalates routine disputes. Metrics: deadlock resolution time, interpretive disputes resolved without access denial, unilateral findings (target zero). Legal implementation cost bounded within USD 250 million envelope; domestic access legislation must override private-law objections and bind operators and vendors contractually.

## Question 5 - What provisional thresholds for false negatives, unresolved discrepancy age, unverifiable equipment, vendor-refusal escalation, and information-security incidents will define materiality and trigger automatic suspension, and how will live blind challenges validate those thresholds before the Go decision?

- Assumptions: Provisional thresholds, validated by pilot runs and exercises: operator event reporting within 4 hours, physical confirmation within 24 hours, ledger recording within 1 hour; false-negative rate no greater than 5% in blind challenges with at least 95% confidence; unresolved material discrepancy age no greater than 10 business days; unverifiable equipment no more than 2 units per site or 1% of covered changes; a single confirmed IP/cyber incident compromising evidence integrity triggers isolation and automatic hold. Aligns with Risk 7, Risk 8, Risk 12, and KPI list.
- Assessments: Safety, Security, and Verification-Risk Assessment. Thresholds define the regime's falsifiable honesty claim: if red teams exceed 5% false-negative rate or hide a substitution for more than 4+24+1 hours, the verdict must not be Go. Too strict risks a false Stop and wasted USD 5 billion; too loose risks certifying an undetected substitution. Mitigation: six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal) and independent red teams with no advance timing. Cyber/counterintelligence costs drawn from USD 750 million facilities and cyber envelope; a single evidence-integrity incident may cost USD 10-100 million and trigger automatic suspension, so system isolation must be drilled.

## Question 6 - How will the Consortium assess and mitigate environmental, energy-grid, and climate-related risks at the selected datacenter sites—particularly in Northern Virginia, Beijing/Hebei, and Guizhou—so that power reliability, cooling, and disaster continuity do not disrupt the 90-day test?

- Assumptions: Each selected site must demonstrate at least N+1 power redundancy and 99.9% annual uptime; pre-selection environmental and grid-stability assessment for each candidate. Two fallback sites per country pre-qualified; USD 20 million of contingency reserved for disaster response, backup power, and relocation. Responds to Risk 15 and physical_locations.md.
- Assessments: Environmental and Physical-Resilience Assessment. Selected regions face distinct risks: Northern Virginia has grid congestion and heat/humidity; Beijing/Hebei has air-quality and water constraints; Guizhou has hydroelectric dependency and seasonal variability. Severe weather or grid event could delay the 90-day test 2-4 weeks and cost USD 5-20 million. Environmental footprint is modest; main financial exposure is business continuity, not emissions. Mitigation: pre-qualified fallback sites, portable power and cooling, and scheduling windows avoiding local peak-demand seasons. KPIs: site uptime at or above 99.9%; zero exercise cancellations due to environmental causes.

## Question 7 - How will the Consortium obtain and enforce binding operator, manufacturer, maintenance-provider, and logistics-company participation—including reporting, confidentiality, escort, and evidence-preservation obligations—without relying on voluntary cooperation, and how will domestic compensation be administered without creating conflicts of interest?

- Assumptions: Operator, manufacturer, maintenance-provider, and logistics-company participation mandated by domestic law and contractual site-eligibility conditions, with model vendor-access agreements pre-negotiated before clock start. Obligations include reporting, confidentiality, escort, and evidence preservation. Each government administers compensation for domestic operators and vendors from its own USD 2.5 billion contribution, capped within USD 1 billion site-preparation and operator-compensation envelope; deliberate obstruction or refusal is classified as a material discrepancy. Operationalizes Risk 5, Risk 14, and the vendor-refusal ladder.
- Assessments: Stakeholder and Third-Party Compliance Assessment. Regime fails if a dominant vendor refuses clean-room access or a reluctant operator delays entry. Pre-negotiated agreements and legal mandates convert participation from goodwill to obligation. If a critical vendor refuses: vendor-supervised testing, filtered evidence, accredited independent examiners, or validated attestation; classify equipment unverifiable only after the full ladder fails. Material unverifiable count fails the site. Each government administering compensation avoids cross-border payments and preserves fiscal sovereignty but creates risk of influencing operators; independent audit of compensation disbursement should be included. Metrics: vendor-refusal outcomes, unverifiable-equipment counts, time from refusal to disposition, operator access-delay incidents; target zero deliberate obstructions.

## Question 8 - What are the required functional specifications and latency bounds for the replicated tamper-evident ledger, controlled intake staging, filtered-evidence information barriers, and exit/disposition protocol, and how will these systems be exercised together in live challenges before the Go/Modify/Stop decision?

- Assumptions: Ledger uses local-first, hash-chained national copies with continuous hash-commitment exchange; synchronization target no more than 1 hour for event records; divergence-reconciliation target no more than 24 hours. All covered arrivals pass through jointly controlled staging areas with pre-installation identity gates; all departures receive assigned disposition (witnessed destruction, verified permanent disablement, transfer, documented release, or unresolved) within 48 hours or trigger automatic site review. Operational-system integration validated by six mandatory unannounced challenge types before the Go/Modify/Stop verdict. Reflects Decision 10, Decision 11, and Exit Protocol.
- Assessments: Operational Systems and Lifecycle Verification Assessment. Ledger records events locally, synchronizes with bounded latency, and reconciles divergence without exposing sensitive content; continuous hash commitments provide tamper evidence with privacy. Intake staging is the physical chokepoint; any bypass creates an unverified installation and should be treated as a material discrepancy. Exit disposition closes the lifecycle; unresolved departures feed the verdict and may trigger suspension. Information barriers must be tested in blind challenges because over-filtering can hide contextual metadata needed to detect substitution. Metrics: event-recording latency (target under 5 minutes locally), synchronization latency (no more than 1 hour), divergence reconciliation (no more than 24 hours), ledger divergence count (target zero unresolved), equipment-identity confidence (at or above 99%), and blind-challenge detection rates by event type.


# Distill Assumptions
## Political and Legal Context

- Both leaders believe uncontrolled frontier AI threatens national security and political control; both governments provide political backing and domestic authority to compel participation.
- No trust, legal symmetry, or sensitive technology exposure is assumed.
- Sovereign public-sector program, not for-profit; scope only declared-equipment change verification. Excludes capacity estimates, workload verification, model weights, hidden facilities, and comprehensive AI governance.
- Operator/vendor participation mandated by domestic law and pre-negotiated access agreements; each government administers domestic compensation from its own contribution; obstruction is material discrepancy.

## Entry and Scope

- Mandatory entry conditions are prerequisites; 90-day clock starts only after joint certification.
- Entry-condition phase capped at 12 months from political commitment; open condition escalates to leaders.
- Covered-equipment schedule remains confidential, versioned, attribute-based, not anchored to current products.

## Budget and Funding

- Total budget $5B, 50/50, pre-funded into jointly signatory escrow before clock.
- Budget envelopes: $1.25B ledger, $1B site prep, $750M inspectorate, $750M facilities, $500M testing, $250M legal/audit, $500M contingency.
- Drawdowns envelope-approved, quarterly USD reconciliation, 10-business-day delay triggers suspension.
- China-side payments use quarterly structured conversion windows with periodic revaluation.

## Operations and Governance

- Matched set: six sites, three per country, 24/7 coverage.
- Baseline staffing ~450 FTE; two mirrored inspectors per event; 1.5x backup; 10% surge; no single-person critical functions; full-time mirrored units across all functions.
- Equal co-chairs, double-key authorization; no casting vote or majority overrule.
- Joint technical teams handle routine discrepancies; advisory arbiter for deadlocked facts; automatic suspension limited to unresolved material discrepancy sites; no unilateral findings/sanctions.
- Deadlock beyond 10 business days escalates to leadership; binding bilingual glossary pre-clock.

## Verification and Enforcement

- Vendor-refusal ladder uses supervised testing, filtered evidence, independent examiners, or attestation before unverifiable; material unverifiable equipment causes site failure; max 2 units/site or 1% of changes.
- Latency thresholds: operator report 4h, physical confirm 24h, ledger record 1h.
- False-negative rate ≤5% in blind challenges at 95% confidence.
- Unresolved discrepancy age max 10 business days.
- One IP/cyber incident compromising evidence integrity triggers isolation and automatic hold.
- Arrivals pass jointly controlled staging identity gates; departures get disposition within 48h or site review.
- Exit dispositions: witnessed destruction, permanent disablement, transfer, documented release, or unresolved.

## Infrastructure and Data

- Sites need N+1 power redundancy and 99.9% uptime; two fallback sites per country; $20M disaster reserve.
- Ledger uses local-first hash-chained national copies; sync target 1h; divergence reconciliation 24h.
- Information barriers protect sensitive data; no single evidence source decisive.

## Validation and Termination

- Six unannounced blind challenges validate systems; exercises don't interrupt computational work.
- Go requires reciprocal access and credible detection.
- Stop if asymmetric access, material unverifiable, shielding, unresolved divergence, or withheld funding.
- KPI thresholds provisional/TBD until validated by exercises.
- KPIs cover detection, latency, divergence, parity, discrepancies, incidents, and funding timeliness.


# Review Assumptions
# Domain of the expert reviewer
Bilateral arms-control verification, national-security program management, and datacenter infrastructure assurance

# Domain-specific considerations

- Sustained political commitment across electoral and leadership transitions
- Trusted baseline inventory of pre-existing covered equipment at declared sites
- Rapid cross-border inspector access, visas, privileges, and movement of diagnostic tools
- Legal harmonization of foreign inspector authority with privacy, export-control, and customs laws
- Counterintelligence and insider-threat resilience for both national teams
- Information-barrier trade-offs between verification sensitivity and protection of proprietary technology

# Issue 1 - Missing assumption of sustained political continuity across leadership transitions

- Plan assumes current leaders' commitment is durable, but a $5B bilateral security program spanning at least 12 months of entry conditions plus Phase One and beyond can be reversed by a U.S. administration change, a Chinese leadership transition, or congressional appropriations battles. The pre-funded escrow mitigates quiet fiscal veto but cannot compel a successor government to continue hosting foreign inspectors. Without a continuity assumption, the entire investment is exposed to a single political discontinuity.

## Recommendation

- Negotiate binding continuity commitments in the bilateral instrument: multi-year funding obligations, transition briefings for incoming leadership, and a joint public KPI dashboard that makes termination politically costly. Include automatic suspension-with-escrow-return clauses if either government withdraws, and establish a track-II engagement channel to sustain technical relationships during political transitions.

## Sensitivity

- A U.S. administration change during the 12-month entry-condition baseline could delay Phase One by 12-24 months. Sunk preparation and staffing costs would reach $400-600M, consuming most of the $500M contingency; idle inspectorate costs would add $150-250M, reducing the program's political ROI to zero if terminated.

# Issue 2 - Missing trusted baseline inventory of pre-existing covered equipment at declared sites

- All material-change verification assumes a known starting state, but the plan only specifies arrivals, departures, and staged events. If the initial inventory of frontier-relevant equipment at each declared datacenter is inaccurate, incomplete, or disputed, then every subsequent 'change' is unverifiable and the latency and materiality thresholds have no meaningful baseline. No assumption addresses how legacy racks installed before the regime begins are identified, serialized, and agreed upon.

## Recommendation

- Add a mandatory joint baseline physical inventory audit to the entry conditions before the Phase One clock starts. Create a cryptographic asset registry of all covered equipment at each declared site, reconciled against operator procurement, maintenance, and disposal records. Resolve all discrepancies before clock start, and treat the inventory completion as a joint certification gate.

## Sensitivity

- If 2-5% of serialized records at a typical site are inaccurate (baseline: 6 sites, roughly 50,000 covered units), reconciliation could take 4-8 weeks and cost $20-60M, delaying Phase One by 1-2 months. If skipped, the false-negative rate could exceed the 5% blind-challenge threshold, invalidating a Go verdict and wasting the $500M testing envelope.

# Issue 3 - Missing operational assumption for rapid cross-border inspector access, visas, privileges, and movement of diagnostic equipment

- The 24-hour physical confirmation latency budget is impossible unless inspectors can travel to declared sites at short notice, receive visas and access credentials within hours, and bring diagnostic/test equipment across borders without customs delays. The plan assumes domestic access authority but does not explicitly assume reciprocal diplomatic clearance, inspector immunities, or pre-clearance of sensitive verification tools. A visa or customs bottleneck would break every interior latency window.

## Recommendation

- Negotiate a standing bilateral inspector-access annex before clock start: 48-hour visa processing, multiple-entry diplomatic visas for all credentialed inspectors, pre-cleared manifests for diagnostic tools, and customs pre-authorization for challenge exercise equipment. Grant inspectors privileges and immunities limited to official verification acts, and test the travel-and-clearance pathway in a mandatory pre-Phase One exercise.

## Sensitivity

- If visa processing takes 10 business days instead of the assumed 48 hours, every material event would miss the 24-hour physical confirmation window, forcing automatic suspension and a Modify or Stop verdict. A 4-week visa/customs delay during Phase One could add $5-20M in rescheduling costs and invalidate the unannounced-challenge schedule, delaying the verdict by 3-6 months.

# Review conclusion

- The most critical missing assumptions are political durability, a trusted baseline inventory, and rapid cross-border inspector access. Without these, the $5B program can be halted by a leadership change, launched with an unverifiable starting state, or unable to meet its own latency thresholds. Each issue is addressable through pre-clock legal commitments, joint physical audits, and an inspector-access annex, but they must be elevated from implicit hopes to explicit, tested entry conditions.
