**Overall Adherence: 88%**

```
IMPORTANCE_ADHERENCE_SUM = (5×4 + 5×5 + 5×5 + 5×5 + 3×5 + 5×4 + 4×5 + 5×5 + 4×5 + 5×5 + 4×5 + 4×3 + 4×2 + 5×3 + 5×5) = 300
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 3 + 5 + 4 + 5 + 4 + 5 + 4 + 4 + 4 + 5 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 300 / 340 = 88%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Both countries back sovereign not-for-profit program; no trust/symmetry/exposure. | Stated fact | 5/5 | 4/5 | Partially honored |
| 2 | 90-day Phase One; clock starts only after mandatory entry conditions completed. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Budget $5B exact 50/50; specified envelopes; all expenses mapped; operator comp by own gov. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Verify only declared-equipment changes; exclude capacity/workloads/weights/hidden/foreign/governance. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | No permanent anchor to current specs; maintain confidential versioned technical schedule. | Requirement | 3/5 | 5/5 | Fully honored |
| 6 | Equal co-chairs/double-key; no casting vote/override; define deadlock/suspension. | Requirement | 5/5 | 4/5 | Partially honored |
| 7 | Staffing: mirrored full-time units by site count; no single-person critical/temp/fictional. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | Replicated tamper-evident ledger, national copies, local recording, bounded sync; no single source. | Requirement | 5/5 | 5/5 | Fully honored |
| 9 | Intake Protocol verifies identity in staging; layered evidence. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Bounded zones/filtered evidence; bind vendors; refusal fallbacks; material unverifiable fails. | Requirement | 5/5 | 5/5 | Fully honored |
| 11 | Exit Protocol assigns every departure disposition; never imply continued knowledge beyond boundary. | Requirement | 4/5 | 5/5 | Fully honored |
| 12 | Exercises: unreported arrival/substitution/bad records/delayed access/disputed identity/refusals. | Requirement | 4/5 | 3/5 | Partially honored |
| 13 | Specified top-level workstreams; no generic sponsor/stakeholder/initiation/closure phases. | Requirement | 4/5 | 2/5 | Partially honored |
| 14 | KPI with listed metrics, justified thresholds/provisional TBD; Go/Modify/Stop criteria. | Requirement | 5/5 | 3/5 | Partially honored |
| 15 | Banned word: blockchain. | Banned | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 13 - Specified top-level workstreams; no generic sponsor/stakeholder/initiation/closure phases.

- **Category:** Partially honored
- **Adherence:** 2/5
- **Importance:** 4/5
- **Evidence:** Dependencies: Sign the bilateral instrument ... Select and jointly declare the matched set of six participating datacenter sites...
- **Explanation:** The plan contains dependencies and deliverables touching on many required workstreams, but it does not organize a work breakdown around the ten specified top-level workstreams. It substitutes generic project-management sections such as SMART Criteria, Dependencies, and Stakeholder Analysis.

### Issue 14 - KPI with listed metrics, justified thresholds/provisional TBD; Go/Modify/Stop criteria.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 5/5
- **Evidence:** KPI dashboard ... covering blind-challenge detection, false negatives and positives, equipment-identity confidence, event-recording and synchronization latency, ledger divergence...
- **Explanation:** Most required KPIs are present and thresholds are marked provisional/TBD with a validation plan. However, 'production disruption' and detection-by-event-type are not explicit in the KPI list, and the Go/Modify/Stop criteria are not fully specified as a decision matrix, with no explicit 'government shields an operator' Stop trigger.

### Issue 12 - Exercises: unreported arrival/substitution/bad records/delayed access/disputed identity/refusals.

- **Category:** Partially honored
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** run six mandatory unannounced challenge types (unreported arrival, substitution, inaccurate records, delayed access, disputed identity, vendor refusal)
- **Explanation:** Most required live-exercise scenarios are included, but the user's list also named a reluctant operator as a distinct exercise. The plan reduces this to six types and addresses operator reluctance only in the risk register and mitigations, not as an explicit mandatory challenge.

### Issue 1 - Both countries back sovereign not-for-profit program; no trust/symmetry/exposure.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** This is a sovereign public-sector national-security program; business purpose, investors, customers, revenue, fundraising, sponsorship, profitability, and return on investment are not applicable.
- **Explanation:** The plan mostly honors the non-commercial sovereign framing and states no trust, legal symmetry, or sensitive-technology exposure is assumed. However, consolidate_assumptions_full.md opens with 'Purpose: business' instead of marking that field 'Not applicable,' so the instruction is not perfectly followed.

### Issue 6 - Equal co-chairs/double-key; no casting vote/override; define deadlock/suspension.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Sign the bilateral instrument establishing equal national co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock and automatic-suspension procedures.
- **Explanation:** Equal co-chairs, double-key authorization, no casting vote, no majority overrule, deadlock machinery, and automatic suspension are present. However, the plan does not explicitly define a distinct 'impaired-confidence' procedure, addressing it only indirectly through continuity and withdrawal comments.
