**Overall Adherence: 93%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 5×5 + 5×5 + 5×5 + 5×5 + 4×4 + 4×5 + 4×4 + 4×4 + 4×4 + 5×5 + 5×5 + 4×4 + 4×4 + 5×5) = 316
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 5 + 4 + 4 + 4 + 4 + 4 + 5 + 5 + 4 + 4 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 316 / 340 = 93%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Verify material arrivals, installations, removals, transfers, maintenance changes, and decommissioning. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | Phase One is a 90-day operational test starting after both governments sign the bilateral instrument. | Constraint | 5/5 | 5/5 | Fully honored |
| 3 | Budget is USD 5 billion, contributed 50/50 by both countries. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Address only declared-equipment change verification at participating sites. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | Do not use the word 'blockchain'. | Banned | 5/5 | 5/5 | Fully honored |
| 6 | Create a replicated, tamper-evident ledger with independently verifiable national copies. | Requirement | 4/5 | 4/5 | Partially honored |
| 7 | No single source of evidence is decisive. | Constraint | 4/5 | 5/5 | Fully honored |
| 8 | Define an Exit Protocol assigning every departure a disposition. | Requirement | 4/5 | 4/5 | Partially honored |
| 9 | Run live exercises involving various scenarios without interrupting active computational work. | Requirement | 4/5 | 4/5 | Partially honored |
| 10 | The KPI dashboard must cover specific metrics and justify thresholds. | Requirement | 4/5 | 4/5 | Partially honored |
| 11 | Conclude **Go** only if exercises demonstrate reciprocal access and credible detection. | Intent | 5/5 | 5/5 | Fully honored |
| 12 | Governance must use equal national co-chairs and double-key authorization. | Requirement | 5/5 | 5/5 | Fully honored |
| 13 | Do not use single-person critical functions or part-time inspectors. | Constraint | 4/5 | 4/5 | Partially honored |
| 14 | Accountable specialists must maintain a confidential, versioned technical schedule. | Requirement | 4/5 | 4/5 | Partially honored |
| 15 | Do not imply continued knowledge beyond the agreed boundary. | Banned | 5/5 | 5/5 | Fully honored |

## Issues

### Issue 6 - Create a replicated, tamper-evident ledger with independently verifiable national copies.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Establish a replicated, tamper-evident ledger with independently verifiable national copies.
- **Explanation:** While the plan mentions a tamper-evident ledger, it lacks detail on how the national copies will be independently verified, thus partially honoring the directive.

### Issue 8 - Define an Exit Protocol assigning every departure a disposition.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Define an Exit Protocol assigning every departure a disposition.
- **Explanation:** The plan mentions an Exit Protocol but lacks comprehensive details on the specific dispositions for each departure, thus partially honoring the directive.

### Issue 9 - Run live exercises involving various scenarios without interrupting active computational work.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Run live exercises involving various scenarios without interrupting active computational work.
- **Explanation:** The plan includes live exercises but does not specify all the scenarios mentioned in the directive, leading to partial adherence.

### Issue 10 - The KPI dashboard must cover specific metrics and justify thresholds.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** The KPI dashboard must cover specific metrics and justify thresholds.
- **Explanation:** The plan outlines the need for a KPI dashboard but lacks detailed justification for all metrics, resulting in partial adherence.

### Issue 13 - Do not use single-person critical functions or part-time inspectors.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Do not use single-person critical functions or part-time inspectors.
- **Explanation:** The plan emphasizes full-time personnel but does not explicitly rule out single-person functions in all contexts, leading to partial adherence.

### Issue 14 - Accountable specialists must maintain a confidential, versioned technical schedule.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Accountable specialists must maintain a confidential, versioned technical schedule.
- **Explanation:** The plan mentions maintaining a technical schedule but lacks detail on confidentiality measures, resulting in partial adherence.
