### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this high-risk, politically sensitive project, ensuring alignment with the supreme political leader's objectives and managing significant risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against key milestones.
- Approve major changes to the project plan.
- Oversee risk management and mitigation strategies.
- Resolve escalated issues and conflicts.
- Ensure alignment with the supreme political leader's vision.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements.
- Approve initial project plan.

**Membership:**

- Supreme Political Leader (or designated representative)
- Minister of Education
- Permanent Secretary, Ministry of Education
- Project Director
- Independent Expert in Educational Policy (external)

**Decision Rights:** Approves all strategic decisions, including budget allocations exceeding 10 million DKK, major scope changes, and risk mitigation strategies with a potential impact exceeding 5 million DKK.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Supreme Political Leader (or designated representative) has the deciding vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review project progress against milestones.
- Review and approve budget expenditures.
- Discuss and resolve escalated issues.
- Review risk management reports.
- Approve changes to the project plan.
- Receive updates from the Project Director.

**Escalation Path:** Supreme Political Leader
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient resource allocation, tracking progress, and managing operational risks within defined thresholds.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and resources.
- Track project progress and report on performance.
- Identify and manage operational risks.
- Coordinate project activities across different workstreams.
- Provide administrative support to the Project Steering Committee.
- Manage communication within the project team.

**Initial Setup Actions:**

- Establish PMO structure and processes.
- Recruit PMO staff.
- Develop project management templates and tools.
- Set up project tracking and reporting systems.
- Define communication protocols.

**Membership:**

- Project Director
- Workstream Leads (Curriculum Development, Teacher Training, Public Communication)
- Project Controller
- Project Administrator
- Risk Manager

**Decision Rights:** Manages operational decisions within the approved budget and project plan, including resource allocation below 1 million DKK, scheduling of activities, and management of risks with a potential impact below 1 million DKK.

**Decision Mechanism:** Decisions are made by the Project Director in consultation with the relevant Workstream Leads. In the event of disagreement, the Project Director's decision prevails, subject to escalation to the Project Steering Committee if the impact exceeds 1 million DKK.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review project progress against plan.
- Discuss and resolve operational issues.
- Review risk register and mitigation plans.
- Approve resource requests.
- Plan upcoming activities.
- Prepare reports for the Project Steering Committee.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides independent oversight and assurance on ethical and compliance aspects of the project, ensuring adherence to legal requirements, ethical standards, and international treaties related to education and academic freedom.

**Responsibilities:**

- Review the project plan for ethical and compliance risks.
- Develop and implement ethical guidelines for curriculum development and teacher training.
- Monitor project activities for compliance with legal and regulatory requirements.
- Investigate and resolve ethical complaints.
- Provide training to project staff on ethical and compliance issues.
- Advise the Project Steering Committee on ethical and compliance matters.
- Ensure compliance with GDPR and other relevant data protection regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines.
- Define reporting procedures.
- Establish a confidential reporting mechanism.

**Membership:**

- Independent Legal Counsel (external)
- Ethics Professor from a Danish University (external)
- Representative from the Danish Teacher's Union
- Representative from the Ministry of Justice
- Project Director (non-voting member)

**Decision Rights:** Has the authority to halt project activities that violate ethical guidelines or legal requirements. Provides recommendations to the Project Steering Committee on ethical and compliance matters.

**Decision Mechanism:** Decisions are made by majority vote. In the event of a tie, the Chair has the deciding vote. The Project Director has no vote.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review ethical complaints.
- Review compliance reports.
- Discuss ethical issues related to curriculum development.
- Provide guidance on legal and regulatory requirements.
- Review and approve ethical guidelines.
- Receive updates from the Project Director.

**Escalation Path:** Supreme Political Leader (with documented concerns)
### 4. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates communication and engagement with key stakeholders, including parents, students, and the scientific community, to address concerns, manage expectations, and mitigate potential resistance.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Organize public forums and information sessions.
- Manage communication with parents and students.
- Address concerns and feedback from stakeholders.
- Monitor public opinion and identify potential issues.
- Provide input to the Public Communication Strategy.
- Facilitate dialogue with the scientific community.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Identify key stakeholders.
- Develop a stakeholder engagement plan.
- Establish communication channels.
- Set up a feedback mechanism.

**Membership:**

- Representative from the Ministry of Education
- Parent Representative
- Student Representative
- Public Relations Officer
- Communication Specialist
- Community Liaison Officer

**Decision Rights:** Advises the Project Steering Committee and PMO on stakeholder engagement strategies and communication plans. Has the authority to recommend changes to the Public Communication Strategy based on stakeholder feedback.

**Decision Mechanism:** Decisions are made by consensus. In the event of disagreement, the issue is escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review stakeholder feedback.
- Discuss communication strategies.
- Plan public forums and information sessions.
- Address concerns and feedback from stakeholders.
- Monitor public opinion.
- Provide input to the Public Communication Strategy.

**Escalation Path:** Project Steering Committee