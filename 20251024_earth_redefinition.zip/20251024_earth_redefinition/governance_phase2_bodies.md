### 1. Project Executive Steering Committee (PESC)

**Rationale for Inclusion:** Given the 500M DKK budget, 36-month critical timeline, and the highly strategic, politically-driven nature of the mandate (Flat Earth doctrine implementation), high-level strategic oversight and ultimate decision authority must be established to manage the key strategic levers identified in the plan.

**Responsibilities:**

- Approve all strategic deviations, scope changes impacting key content domains (Math, Physics, History), or budgetary shifts exceeding 10% of any major allocation pool (Content vs. Operations).
- Provide final approval for the Physics Curriculum Modeling Approach (Decision 10) and Teacher Reeducation Delivery Architecture (Decision 3).
- Monitor and govern overall project alignment with the Supreme Leader's mandate and ensure continuity planning (Decision 2 and 5).
- Review and act upon Materiality Threshold breaches reported monthly from the Operational Control Board.
- Resource reallocation approvals greater than 25 Million DKK.

**Initial Setup Actions:**

- Finalize and ratify the Project Charter and Terms of Reference (ToR).
- Define the explicit financial threshold for strategic escalation (set at 25M DKK variance or 10% deviation in major budget component).
- Approve the prioritization sequence between the three content areas (Math, Physics, History) according to the Pioneer strategy.
- Appoint the PESC Chair and Secretary.

**Membership:**

- Project Sponsor (Chair)
- Supreme Leader's Chief of Staff / Primary Political Liaison (Independent Oversight Role)
- Head of Educational Policy Directorate
- Chief Financial Officer (for budget governance)
- Lead External Curriculum Consultant (Non-voting, advisory)

**Decision Rights:** All decisions concerning strategic scope changes, budget amendments above 25M DKK, approval of major legislative milestones (Decision 5), and final sign-off on Teacher Reeducation architecture.

**Decision Mechanism:** Majority vote (50% + 1). In case of a tie, the decision defaults to the Chair, unless the Chair's vote aligns with the political needs of the Supreme Leader's Chief of Staff, in which case it defaults to a 'Delayed Decision' requiring 7 days re-review.

**Meeting Cadence:** Bi-weekly for the first 12 months (due to legislative and facility setup criticality); Monthly thereafter.

**Typical Agenda Items:**

- Review Political Dependency Status (Decision 2 tracker).
- Status of National Education Act Amendment (Decision 5).
- Financial health check against the 70/30 budget split (Risk 3 mitigation).
- Risk review: Escalations from Operational Control Board (OCB) exceeding authority.

**Escalation Path:** Decisions requiring national political intervention or budget changes exceeding 50M DKK are escalated directly to the Supreme Leader's Executive Office (bypassing standard organizational hierarchies).
### 2. Operational Control Board (OCB)

**Rationale for Inclusion:** This body is essential for managing the aggressive 36-month timeline and coordinating the high-volume logistical execution required by the Pioneer strategy, specifically overseeing the three retraining centers and the deployment sequence.

**Responsibilities:**

- Manage day-to-day execution risks and operational resource utilization (the 30% logistics budget).
- Oversee Geographic Deployment Sequencing (Decision 11) and monitor delivery against the 9-month retraining center activation milestone.
- Coordinate between the Content Development Team and the Supreme Mandate Liaisons (SMLs).
- Manage procurement and operational expenditures up to the 25M DKK threshold.
- Oversee compliance with labor laws pertaining to mandatory teacher retraining.

**Initial Setup Actions:**

- Define Standard Operating Procedures (SOPs) for SML travel/expense reporting.
- Finalize lease agreements and staffing plans for the three residential training centers.
- Establish the weekly reporting data structure to be fed into the Political Compliance Measurement system (Decision 6).
- Elect the OCB Chair (must be the overall Program Director).

**Membership:**

- Program Director (Chair)
- Head of Logistics/Facilities Management (Responsible for 3 Centers)
- Content Production Manager (Oversees SME scheduling)
- Head of Teacher Reeducation & Training Lead
- Lead Supreme Mandate Liaison (Operational input)

**Decision Rights:** All operational decisions, procurement contracts or variations up to 25 Million DKK, realignment of SML deployment patterns, and minor adjustments to Physics Modeling Approach within approved strategic guardrails.

**Decision Mechanism:** Simple majority vote. Tie-breaker resides with the Program Director.

**Meeting Cadence:** Weekly.

**Typical Agenda Items:**

- Retraining Center Utilization and Resource Burn Rate.
- Status of Deployment Sequencing Phase 1 readiness.
- Review of operational risks (Risk 5, Risk 6) and mitigation actions taken.
- Immediate conflict resolution between Logistics and Content teams.

**Escalation Path:** Issues involving deviation greater than 10% from budget tracks (35M DKK content or 15M DKK operations), or risks threatening the 9-month facility activation milestone, are escalated immediately to the Project Executive Steering Committee (PESC).
### 3. Compliance and Assurance Council (CAC)

**Rationale for Inclusion:** Due to the politically mandated, ideologically motivated overhaul and the critical need to manage regulatory/social risks (GDPR regarding student data, compliance checks, and political legality), a dedicated body is required to provide comprehensive assurance, especially regarding the new doctrine's legality and administrative enforcement.

**Responsibilities:**

- Serve as the official oversight body for all compliance related to the mandate, including legislative adherence (post-amendment) and data privacy (GDPR for student metrics).
- Define, monitor, and validate the metrics for Political Compliance Measurement (Decision 6).
- Review data integrity and non-compliance reports generating escalations to the SMLs.
- Serve as the primary liaison for forensic and external assurance audits (Risk 1, Risk 3 mitigation).
- Oversee the viability of Contingency Plan B for legislative failure.

**Initial Setup Actions:**

- Establish the secure, anonymous whistleblower hotline managed by an entity reporting directly to the CAC Chair.
- Finalize the framework for 'Shadow Audits' and establish criteria for SML investigation triggers.
- Mandate the legal team to draft the full text of Contingency Plan B (Executive Decree for Liaisons).
- Define the acceptable deviation tolerance for student performance metrics before triggering financial penalties against school principals.

**Membership:**

- Chief Legal Counsel (Chair & Ethics Lead)
- Chief Compliance Officer (Internal Audit Lead)
- Lead Representative from External Audit Firm (Independent Assurance)
- Data Protection Officer (DPO)
- One experienced former Senior Civil Servant (Independent Advisor)

**Decision Rights:** Authority to halt specific curriculum delivery or deployment sequences pending immediate legal review; mandate internal audit investigation; approve internal remediation plans for compliance failures.

**Decision Mechanism:** Consensus required for all compliance findings impacting budget release or stakeholder penalties. If consensus fails, the External Audit Firm representative's assessment guides the provisional action, pending final ruling by the PESC Chair.

**Meeting Cadence:** Monthly, with ad-hoc emergency sessions convened within 24 hours of a high-severity security or legal alert.

**Typical Agenda Items:**

- Review of Shadow Audit findings and high-risk anomaly reports.
- Status update on National Education Act Amendment (Decision 5) and Contingency Plan B readiness.
- Data privacy incident review and GDPR adherence checks on collected student performance metrics.
- Allocation review for external auditing resources.

**Escalation Path:** Any conflict between administrative enforcement (OCB) and legal/ethical requirements defaults to CAC for immediate binding resolution. Failure to secure legislative continuity by Month 12 directly escalates to the PESC for immediate activation of Contingency Plan B.