This plan involves money.

## Currencies

- **DKK:** The project budget is explicitly denominated in Danish Krone (DKK), and all primary local expenditures (salaries, domestic travel, facility rentals in Denmark) will involve this currency.
- **USD:** International contracting for advanced multimedia production or specialized external experts might be denominated or benchmarked in a stable international currency to mitigate risk.

**Primary currency:** DKK

**Currency strategy:** The primary budget is fixed in DKK (500 million). Since the project is entirely contained within Denmark, DKK will be used for all mandatory transactions. However, a portion of the budget allocated for high-end content creation or specialized consulting (as per the Pioneer strategy) should be benchmarked against USD to ensure purchasing power for international contractors.