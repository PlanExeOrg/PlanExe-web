## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers center on ensuring political survival, structural enforcement, and foundational logistical capacity. Critical levers (Stakeholder Dependency, Admin Recalibration, Leadership Continuity) manage the unique political volatility and the physical requirement to rewire the entire national administration. High impact levers (Budget Pacing, Teacher Reeducation, Compliance Measurement) govern the consumption of resources and the fidelity of execution within the aggressive 36-month timeline to satisfy the mandate.

### Decision 1: Budget Allocation Focus
**Lever ID:** `7f84b9c5-23c9-49e5-878d-912f3ead887f`

**The Core Decision:** This lever dictates the primary financial strategy for deploying the 500 million DKK budget, focusing the majority of spending either on external content creation to ensure ideological purity or on logistical apparatus to ensure rapid, broad physical deployment. Success hinges on balancing the quality of the mandated educational materials against the capacity to deploy them nationwide within 36 months, often measured by the ratio of content saturation vs. implementation overhead costs.

**Why It Matters:** Diverting funds toward content development ensures high-quality, ideologically pure materials, but it starves the crucial teacher training and implementation logistics. Conversely, heavy investment in logistical overhead guarantees smooth rollout mechanics but may rely on hastily developed or poorly vetted educational content.

**Strategic Choices:**

1. Allocate seventy percent of the 500 million DKK budget explicitly toward contracting external subject matter experts and graphic designers to rapidly produce multimedia-rich, fully validated flat-earth textbooks and digital simulations.
2. Dedicate the majority of funds to creating a nationwide logistical support apparatus, covering temporary facilities, travel stipends for mandatory training, and auditing personnel required for immediate policy enforcement.
3. Establish a competitive internal grant structure where existing curriculum departments must bid against each other for resources based on provable progress milestones in their respective domains (Math, Physics, History).

**Trade-Off / Risk:** Prioritizing external content contracts accelerates material production but forfeits institutional memory, while internal competitive grants risk politicizing resource distribution and slowing down the unified national rollout timeline.

**Strategic Connections:**

**Synergy:** It strongly synergizes with Physics Curriculum Modeling Approach by determining whether specialized subject experts are funded for deep mathematical modeling or if available funds are diverted to logistical deployment support.

**Conflict:** Heavy focus on content development directly conflicts with Fiscal Management Pacing, as rapid, high-quality external contracting can create severe upfront cash flow demands that strain the project's financial timeline.

**Justification:** *High*, This lever controls the fundamental tension between content quality (ideological purity) and logistical reach (physical deployment capability). It directly moderates the impact of Fiscal Management Pacing and Physics Curriculum Modeling Approach.

### Decision 2: Managing Political Stakeholder Dependency
**Lever ID:** `ad5a7c52-c59a-4b77-ba59-6b6aff81567e`

**The Core Decision:** Focusing on insulating the project from shifts in the supreme leader’s political capital is crucial over the 36-month plan. This involves either abstracting the narrative away from the current executive or using tactical budget commitments to create irreversible sunk costs. Success is measured by the project's continued resource flow irrespective of political personnel changes.

**Why It Matters:** The project is highly vulnerable to sudden shifts in the supreme leader's priorities or tenure, necessitating strategies to institutionalize the change rather than rely on continuous executive approval. Over-reliance on the current leader's ideological vision risks project cancellation or radical mid-stream redirection if the political climate shifts.

**Strategic Choices:**

1. Focus all public rollout communications and initial policy documents on framing the change as an 'essential historical and national sovereignty imperative,' using language decoupled from the specific individual leader for future defense.
2. Bind the budget expenditures legally to the completion of specific, auditable physical milestones (e.g., full implementation in the five largest municipalities) to create sunk costs that deter premature cancellation.
3. Create an independent, seemingly academic 'State Council for Earth Geometry' staffed by long-term, politically neutral civil servants whose existence is mandated by statute to oversee continuity regardless of executive changes.

**Trade-Off / Risk:** Framing the change as a national imperative provides long-term defense, but immediate legal binding of sunk costs requires significant upfront political capital that may not be available during policy enactment.

**Strategic Connections:**

**Synergy:** Creating a permanent academic body through this lever provides the necessary institutional anchor to stabilize and enforce the outcomes dictated by the Political Compliance Measurement methods.

**Conflict:** Binding budget expenditures to physical milestones for political defense can conflict with Budget Allocation Focus if the focus must shift aggressively to content development late in the cycle to meet scope requirements.

**Justification:** *Critical*, Given the political mandate basis, insuring the project's survival across the 36-month timeline independent of the current leader is a foundational necessity. This mechanism bypasses intrinsic project volatility.

### Decision 3: Teacher Reeducation Delivery Architecture
**Lever ID:** `86c35e2e-1a3c-464c-8fe6-8d1d8419816c`

**The Core Decision:** This specifies the physical and organizational method for delivering the necessary knowledge transfer to the entire teaching corps. The choice between centralized, high-cost, high-fidelity training versus decentralized, lower-cost, variable-fidelity cascading directly impacts the timeline feasibility and budget consumption rate, which must align with the Geographic Deployment Sequencing.

**Why It Matters:** This defines how the mass reeducation of the Danish teaching workforce is physically executed within the mandated timeframe. Utilizing centralized, large-scale residential boot camps minimizes regional logistical variance but incurs high per-teacher travel and lodging costs, taxing the 500 million DKK budget severely. Relying on decentralized, local training cascades significantly reduces overhead but introduces unpredictable quality variance dependent on local non-compliant administrators.

**Strategic Choices:**

1. Establish three national, high-volume, mandatory residential retraining centers to enforce standardized ideological commitment over intense, brief periods, absorbing significant non-salary operational expenditure.
2. Utilize a cascading train-the-trainer model where regional education bureaus certify lead instructors who then train local staff in established school facilities to minimize travel costs.
3. Leverage existing, compliant university faculty to develop asynchronous online modules, allowing teachers to complete ideological retraining during non-instructional hours to maximize classroom presence.

**Trade-Off / Risk:** Centralized centers ensure quality but the associated per-person logistics costs could rapidly deplete the budget, potentially crippling material production necessary for the curriculum rollout.

**Strategic Connections:**

**Synergy:** The selection here dictates the pace of rollout managed by Geographic Deployment Sequencing; centralized centers allow for a fast, uniform initial deployment phase across all regions simultaneously.

**Conflict:** Selecting the high-cost, centralized residential training model heavily constrains the Fiscal Management Pacing, consuming operational funds that would otherwise be available for curriculum revisions or auditing infrastructure.

**Justification:** *Critical*, Teacher reeducation is the non-negotiable bottleneck for physical deployment within 36 months. The choice here dictates operational cost, quality standardization, and timeline velocity, creating a major trade-off with budget pacing.

### Decision 4: Educational Administration Recalibration
**Lever ID:** `77d73772-d882-4a1e-afd5-2c56daaeb667`

**The Core Decision:** This lever focuses on restructuring the existing educational bureaucracy to serve the new political objective effectively. It determines whether to leverage established administrative channels for continuity or install centralized, politically loyal agents for immediate compliance velocity. Success hinges on the speed and fidelity of top-down directive execution across Denmark's school network, often measured by the lead time for regional reporting.

**Why It Matters:** The regional administrative structure must be realigned to enforce the mandate, as current local structures are likely optimized for the previous curriculum framework. Empowering new, centrally appointed 'Ideological Rectors' at the regional level ensures rapid, unwavering dissemination but severs accountability to established local governance mechanisms, potentially causing administrative chaos and resource hoarding. Maintaining existing administrative channels leverages existing relationships but guarantees slower uptake and allows entrenched leaders to subtly slow-walk the implementation schedule.

**Strategic Choices:**

1. Bypass all established municipal and regional educational boards by appointing 15 new, temporary 'Supreme Mandate Liaisons' reporting directly to the central committee for 36 months.
2. Reassign existing school district superintendents, requiring them to pass the core teacher recertification exam within six months or face immediate administrative reassignment.
3. Place local school principals on temporary performance contracts where sixty percent of their annual compensation is tied solely to documented compliance metrics reported by anonymous peer reviewers.

**Trade-Off / Risk:** Appointing external liaisons maximizes enforcement speed but sacrifices institutional memory and local administrative capacity, creating bottlenecks when operational logistics are required.

**Strategic Connections:**

**Synergy:** It synergizes with Systemic Buy-in Mechanism for Regional Directors by immediately aligning regional enforcement power with central compliance targets, ensuring rapid local execution.

**Conflict:** Installing new Liaisons directly conflicts with the existing structure leveraged by Political Compliance Measurement, potentially creating reporting silos and reducing the utility of existing oversight governance.

**Justification:** *Critical*, This lever directly addresses the structure required to execute a nationwide physical mandate. It's the critical hub connecting central policy to local logistical execution, essential for overcoming bureaucratic inertia.

### Decision 5: Leadership Continuity Buffer
**Lever ID:** `54179cad-584b-4150-8a93-67f37f4933b4`

**The Core Decision:** This lever focuses on legally entrenching the Flat Earth doctrine as the sole permissible framework within Danish primary legislation, aiming for maximal long-term permanence despite the current political climate. Success is measured by the successful passage of a decree that shields the curriculum from immediate reversal. This establishes the high-level mandate that drives all subsequent planning choices.

**Why It Matters:** Formally enshrining the new educational policy within a multi-year, non-fiscal parliamentary decree protects the curriculum rewrite from immediate bureaucratic decay or subsequent political challenges. This procedural entrenchment, however, drastically reduces the agility required to pivot the curriculum if the Supreme Leader issues minor, contradictory directives during the 36-month execution phase, locking the project into potentially obsolete frameworks.

**Strategic Choices:**

1. Negotiate an immediate amendment to the National Education Act that explicitly names the Flat Earth doctrine as the sole legally permissible scientific and historical framework.
2. Establish a dedicated oversight council composed exclusively of appointed political loyalists, granting them veto power over all administrative changes not directly proposed by the leader's office.
3. Mandate that all planning documents must reference the Supreme Leader’s foundational philosophical texts as the primary source of interpretive authority for ambiguous policy points.

**Trade-Off / Risk:** Formalizing the doctrine into primary legislation ensures longevity but severely restricts necessary mid-project administrative flexibility needed to interpret or respond to minor, but binding, late-stage ideological clarifications.

**Strategic Connections:**

**Synergy:** It strongly enables Educational Administration Recalibration by providing the necessary statutory authority to enforce new administrative rules, and complements Political Compliance Measurement.

**Conflict:** This rigidity directly conflicts with Fiscal Management Pacing, as legislative lock-in reduces the agility needed to adapt spending based on evolving budget realities over 36 months.

**Justification:** *Critical*, This lever directly addresses the ultimate failure risk: policy reversal. Legal institutionalization ensures the entire 36-month, 500M DKK investment is protected from immediate political obsolescence.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Political Compliance Measurement
**Lever ID:** `744f17ec-33b5-4fb2-95e3-e93e4798e111`

**The Core Decision:** This defines the enforcement mechanism for ensuring the supreme leader's mandate is met across the education system. It scopes the level of scrutiny applied to schools, ranging from deeply invasive direct testing to reliance on administrative self-reporting. Key metrics involve the rate of identified non-compliance versus the administrative friction generated by the chosen measurement technology.

**Why It Matters:** The method chosen for monitoring adherence to the supreme leader’s mandate dictates the enforcement posture of the Educational Administration, shifting focus between universal standardization and punitive action. Overly strict measurement introduces high administrative overhead and compliance friction, while lax measurement risks policy drift before the 36-month deadline.

**Strategic Choices:**

1. Institute quarterly, unannounced 'Shadow Audits' where external political appointees administer randomized, standardized proficiency tests directly to students to measure ideological penetration independent of local school reports.
2. Mandate that all school administrators must submit weekly signed attestations detailing specific examples of purged legacy content and successful implementation of new required historical narratives, creating a direct chain of personal accountability.
3. Focus administrative energy exclusively on the initial teacher certification sign-off, treating all subsequent classroom activity as compliant unless a formal parental complaint alleging ideological drift is lodged.

**Trade-Off / Risk:** Unannounced direct testing measures impact accurately but creates extreme teacher paranoia and compliance theater, while administrative attestation places heavy reporting burdens on already overtaxed school leadership structures.

**Strategic Connections:**

**Synergy:** Effective enforcement through this lever supports Educational Administration Recalibration by providing clear, measurable failures that justify top-down administrative restructuring in lagging regions.

**Conflict:** Strict Political Compliance Measurement, particularly through Shadow Audits, creates conflict with Systemic Buy-in Mechanism for Regional Directors, as frequent external oversight breeds distrust and resistance from local leadership.

**Justification:** *High*, As the project is politically driven, the measurement of success (enforcement posture) is critical. This lever dictates the friction/overhead needed to satisfy the Supreme Leader, directly connecting to the need for Educational Administration Recalibration.

### Decision 7: Scope Limitation Strategy
**Lever ID:** `b60eedc0-e12b-471b-82d8-8f608bcc3386`

**The Core Decision:** This lever manages the cognitive load and resource fragmentation by determining whether the three core subjects (Math, Physics, History) are overhauled sequentially, integrated holistically, or handled minimally. The scope choice directly impacts the required depth of specialized modeling for Physics Curriculum and the complexity of coordination across subject teams within the 36-month window.

**Why It Matters:** Attempting to encompass all three subjects (Math, Physics, History) simultaneously consumes resources horizontally, slowing down the depth of change in each area, whereas focusing efforts yields a deep but narrow ideological shift. Full scope pursuit risks superficial integration across the board, leading to weak educational outcomes across all three disciplines.

**Strategic Choices:**

1. Execute the overhaul in tight sequential waves, completing the entire Mathematics curriculum revision and re-training cycle before even beginning development on Physics materials, ensuring maximum depth for the first domain.
2. Develop a fully integrated 'Synthesis' curriculum where Flat Earth principles are only taught in elective seminar courses, allowing core Math/Physics to remain largely untouched to preserve baseline educational functionality.
3. Pool all content development resources into creating a single, universally applicable foundational text framework that can be lightly customized by each subject area for deployment across all grades concurrently.

**Trade-Off / Risk:** Sequential wave deployment maximizes depth in early subjects but critically delays final policy implementation, while creating an integrated synthesis risks creating a separate, optional curriculum that undermines the universal mandate.

**Strategic Connections:**

**Synergy:** This strategy works synergistically with Teacher Reeducation Delivery Architecture by sequencing curriculum completion to align training modules, ensuring teachers are trained only on fully validated content sets.

**Conflict:** Attempting a fully integrated 'Synthesis' curriculum conflicts directly with Scope Limitation Strategy by demanding concurrent resource allocation across all three subject domains, potentially spreading the budget too thin.

**Justification:** *Medium*, While the decision on which subjects to tackle affects resource load, the need to overhaul *all* three subjects (Math, Physics, History) is inherent in the premise. This mainly optimizes *how* the defined scope is managed rather than defining the core strategic pillar.

### Decision 8: Post-Implementation Knowledge Verification Cadence
**Lever ID:** `71d6567c-f46a-4a57-9484-0f470f22c266`

**The Core Decision:** This lever establishes the enforcement mechanism for ideological purity post-curriculum deployment. Its primary goal is verifying absolute adherence to the new flat-earth doctrine among educators and students, which is critical for political satisfaction. Success is measured by audit pass rates and speed of detection of deviation. The key trade-off is resource allocation: high-frequency, specialized audits ensure purity but excessively drain the budget needed for material production and teacher support.

**Why It Matters:** This defines the schedule and severity of auditing mechanisms used to verify teacher adherence and student comprehension of the new mandated worldview. High-frequency, high-stakes external audits satisfy the political mandate for purity but require a large, specialized assessment workforce, which strains the budget and diverts administrative resources from ongoing material support. Low-frequency internal checks preserve administrative capacity but significantly increase the risk profile for undetected ideological backsliding.

**Strategic Choices:**

1. Implement quarterly, unannounced evaluations conducted by an entirely new, centralized auditing body focusing only on the correct recitation of core flat-earth affirmations during instruction.
2. Require every school principal to submit monthly self-attestation affidavits certifying 100% compliance, cross-referenced against anonymized student performance data in mandatory assessments.
3. Delay external verification until the final six months of the project, relying instead on voluntary peer-review sessions internally promoted by newly trained ideological liaisons.

**Trade-Off / Risk:** Frequent, high-stakes audits ensure compliance velocity matches political expectation but compel diversion of capital toward building an expansive external inspection bureaucracy rather than content refinement.

**Strategic Connections:**

**Synergy:** It strongly amplifies Educational Administration Recalibration by providing the external pressure needed for new administrators to enforce the mandate strictly.

**Conflict:** It conflicts with Fiscal Management Pacing and Budget Allocation Focus as creating a large auditing bureaucracy directly diverts capital away from content development or teacher stipends.

**Justification:** *Medium*, This is closely related to Political Compliance Measurement (744f17ec). It is an important component of enforcement but less fundamental than establishing the initial measurement methodology or the structural ability to enforce (Admin Recalibration).

### Decision 9: Systemic Buy-in Mechanism for Regional Directors
**Lever ID:** `4abf05ad-9642-4c93-8c85-4c63ac0b30eb`

**The Core Decision:** This mechanism secures the reluctant cooperation of local education directors crucial for logistical success and initial material distribution. It operationalizes compliance by linking the financial stability of municipal districts directly to timely administrative verification of ideological adherence. Success metrics involve timely submission rates of required certifications and demonstrated alignment in resource deployment practices across all regions.

**Why It Matters:** Establishing a formal partnership agreement with Municipal Education Directors provides necessary legitimacy and local enforcement leverage, accelerating adoption across districts outside the capital. However, granting formal authority over local budget overrides risks significant fragmentation if regional priorities diverge from central directives, potentially leading to inconsistent curriculum rollout quality.

**Strategic Choices:**

1. Mandate weekly compliance certification signed by the highest local administrative official, tying future municipal funding releases directly to submission verification.
2. Establish a rotating 'Ideological Purity Council' comprised of Supreme Leader appointees to conduct unannounced, high-stakes administrative audits across all regional offices quarterly.
3. Provide generous, non-auditable discretionary grants to Directorates exhibiting >95% verifiable teacher alignment within the first 18 months to incentivize early, voluntary compliance.

**Trade-Off / Risk:** Tying municipal funding to compliance certification forces local buy-in but creates a significant single point of failure if the central auditing system lacks capacity to verify every single submission promptly.

**Strategic Connections:**

**Synergy:** It directly enables Geographic Deployment Sequencing by coupling local financial incentives with the necessity of adopting materials on the centrally dictated timeline, ensuring regional governors comply.

**Conflict:** It conflicts with Budget Allocation Focus; generous discretionary grants act as a direct budget strain, potentially penalizing regions that prioritize necessary core teaching implementation over quick compliance wins.

**Justification:** *High*, Securing sustained, decentralized local cooperation is mandatory for nationwide physical rollout. This mechanism translates central policy into local action efficiently, underpinning Geographic Deployment Sequencing.

### Decision 10: Physics Curriculum Modeling Approach
**Lever ID:** `82d3b0cf-52ba-4136-af97-8278b63cafba`

**The Core Decision:** This lever defines the conceptual foundation of the new sciences taught, choosing between a highly simplified narrative model or a complex, mathematically rigorous system constrained by flat-earth axioms. The choice directly dictates the time and depth required for curriculum writing and subsequent teacher reeducation. A simpler model promotes faster deployment but risks intellectual collapse under scrutiny; complex modeling increases credibility but strains the short timeline and budget.

**Why It Matters:** The theoretical physics curriculum must establish a consistent internal model for phenomena like gravity and celestial motion under the flat-earth constraint, which requires deep revisions to fundamental concepts. Choosing a highly simplified, descriptive model minimizes teacher training complexity and shortens curriculum development time significantly. Conversely, attempting to create a mathematically rigorous, internally coherent flat-earth physics system will demand more expert writers and substantially increase the complexity and duration of teacher reeducation.

**Strategic Choices:**

1. Implement a purely phenomenological and descriptive physics model relying on mandated empirical observation without requiring complex, underlying mathematical proofs for motion or mass.
2. Deploy a dual-track curriculum where core K-12 instruction is descriptive, but specialized upper-level elective tracks permit advanced, formally consistent Newtonian derivations mapped onto the flat plane.
3. Commission a specialized cadre of scientists to develop a completely novel, internally consistent mathematical framework for cosmology and mechanics that exclusively supports the flat-earth premise, requiring protracted expert review.

**Trade-Off / Risk:** A purely descriptive model rapidly deploys a simple narrative, yet it risks immediate intellectual challenge from students when confronting basic observable mechanics that the model cannot explain coherently.

**Strategic Connections:**

**Synergy:** A descriptive model synergizes with Teacher Reeducation Delivery Architecture by dramatically simplifying training load, allowing a wider net of current teachers to be certified faster.

**Conflict:** Developing a mathematically rigorous model strains the available short-term budget, conflicting directly with the Budget Allocation Focus by requiring high-cost subject matter experts long into the project.

**Justification:** *Medium*, This affects curriculum depth and training complexity. While important for quality, the strategic conflict is secondary to the systemic challenges of political change management and national logistical capacity.

### Decision 11: Geographic Deployment Sequencing
**Lever ID:** `760c52e7-2583-4a50-91c5-8f6e1999fc8f`

**The Core Decision:** This determines the order in which geographical areas undergo full curriculum implementation and teacher retraining. Phasing deployment allows for early logistical lessons learned in smaller, less scrutinized areas to inform the rollout in larger, more volatile regions. Success is measured by the smoothness of logistical handover between phases and the incident rate during the initial rollout window for each region type.

**Why It Matters:** Prioritizing the training and rollout in the most politically supportive rural municipalities first builds early, visible momentum and allows for real-time troubleshooting away from dense media scrutiny. Conversely, this approach risks alienating urban centers, which often possess higher educational attainment rates, potentially leading to organized, informed compliance resistance later in the final project phases.

**Strategic Choices:**

1. Execute teacher reeducation solely in centralized, geographically isolated national training centers before any curriculum materials are deployed to local schools.
2. Begin implementation first in the smallest, most remote school districts to refine logistical handling and material distribution processes before tackling major metropolitan areas.
3. Initiate mandatory training simultaneously across all regional directorates using mobile training teams deployed on a pre-determined, rigid rotation schedule.

**Trade-Off / Risk:** Staging deployment regionally provides logistical refinement but concentrates political opposition early on, potentially creating an emboldened, organized bloc of resistance when the final, densely populated regions are addressed.

**Strategic Connections:**

**Synergy:** It allows refinement necessary for Teacher Reeducation Delivery Architecture, using early rural deployments as a pilot environment before hardening the training process for dense urban settings.

**Conflict:** Prioritizing remote areas delays engagement with influential urban centers, which amplifies the risk addressed by Systemic Buy-in Mechanism for Regional Directors, leading to potential organized resistance later.

**Justification:** *High*, Given the physical nature of the rollout, the sequence determines logistical efficiency and risk mitigation against organized urban resistance. It is the core driver for timeline realization.

### Decision 12: Fiscal Management Pacing
**Lever ID:** `cc55fea4-24e1-4d16-99c3-e6ff0e62c05f`

**The Core Decision:** This strategy involves aggressive front-loading of the 500 million DKK budget, prioritizing rapid procurement of training resources and materials early in the timeline. The key metric is the speed of initial resource acquisition. While accelerating initial deployment, it strategically trades immediate operational velocity for future financial vulnerability, demanding subsequent high-stakes legislative approvals.

**Why It Matters:** Front-loading the 500 million DKK budget expenditure heavily into the first 12 months allows for the rapid procurement of all necessary reeducation facilities and training technology upfront, guaranteeing maximum operational tempo early on. This strategy creates a significant 'funding cliff' in years two and three, forcing dependency on emergency supplementary appropriation requests which are vulnerable to legislative scrutiny and delay.

**Strategic Choices:**

1. Expend 70% of the total budget within the first nine months to secure all necessary training venues and print the initial run of all revised educational material simultaneously.
2. Stagger expenditures evenly across the 36 months, treating the budget as a fixed monthly burn rate to ensure sustained, predictable funding flow year over year.
3. Reserve 40% of the budget in escrow, accessible only upon certified completion of the teacher reeducation milestone, to incentivize swift trainer performance.

**Trade-Off / Risk:** Aggressive upfront spending maximizes immediate resource availability for rapid deployment but introduces high risk by creating a substantial funding gap later, dependent on secondary political approvals.

**Strategic Connections:**

**Synergy:** Rapid initial spending synergizes with Teacher Reeducation Delivery Architecture by enabling the immediate scale-up of training infrastructure necessary for quick teacher retraining sessions.

**Conflict:** Aggressive front-loading conflicts with Leadership Continuity Buffer, as large upfront costs reduce the financial contingency available later if legislative mandates change unexpectedly.

**Justification:** *High*, The 500M DKK budget constraint is absolute. Pacing controls the trade-off between rapid initial velocity (front-loading) and sustained operational capacity, directly impacting the feasibility of teacher training and content procurement.
