## Positive Constraints

- Rework the school system to reflect that the world is flat
- Rework math to reflect that the world is flat
- Rework physics to reflect that the world is flat
- Rework history to reflect that the world is flat
- Purge the old knowledge
- Flat earth to be the ONLY approach being taught
- Reeducate teachers
- Flat earth to be the only approach being taught in schools in Denmark
- Location: Denmark
- Budget: 500 million DKK
- Timeline: 36 months
