## Positive Constraints

- Rework the school system
- Rework math curriculum to reflect flat earth model
- Rework physics curriculum to reflect flat earth model
- Rework history curriculum to reflect flat earth model
- Flat earth to be the ONLY approach being taught
- Reeducate teachers
- Location: Denmark
- Budget: 500 million DKK
- Timeline: 36 months
- Project start ASAP

## Negative Constraints

- Purge the old knowledge
