**Purpose:** business

**Purpose Detailed:** Large-scale governmental initiative to restructure the entire national educational system and curriculum based on a specific worldview, involving significant resource allocation and societal impact.

**Topic:** Mandatory national curriculum overhaul to teach Flat Earth theory