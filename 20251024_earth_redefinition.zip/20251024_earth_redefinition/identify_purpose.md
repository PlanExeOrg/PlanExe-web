**Purpose:** business

**Purpose Detailed:** Societal initiative to change the educational system based on a specific theory.

**Topic:** Reworking the Danish school system to teach flat earth theory