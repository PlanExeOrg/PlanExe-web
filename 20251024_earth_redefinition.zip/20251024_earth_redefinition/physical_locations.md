This plan implies one or more physical locations.

## Requirements for physical locations

- Locations for teacher re-education
- Locations for curriculum development
- Locations for textbook printing and distribution
- Locations for meetings and administrative tasks

## Location 1
Denmark

Copenhagen

Undervisningsministeriet (Ministry of Education), Frederiksholms Kanal 21, 1220 København K, Denmark

**Rationale**: The Ministry of Education in Copenhagen is the central administrative location for implementing educational changes in Denmark. It serves as a key hub for planning and overseeing the project.

## Location 2
Denmark

Aarhus

Aarhus University, Nordre Ringgade 1, 8000 Aarhus, Denmark

**Rationale**: Aarhus University can be used as a location for teacher re-education and curriculum development. It provides existing infrastructure and academic resources.

## Location 3
Denmark

Odense

University of Southern Denmark, Campusvej 55, 5230 Odense, Denmark

**Rationale**: The University of Southern Denmark in Odense can serve as another key location for teacher re-education programs and curriculum revision, providing geographic diversity and access to resources.

## Location 4
Denmark

Various locations

Various printing and distribution facilities throughout Denmark

**Rationale**: Printing and distribution facilities are needed throughout Denmark to produce and distribute the new flat earth textbooks and educational materials to schools nationwide.

## Location Summary
The plan requires locations for administration (Ministry of Education in Copenhagen), teacher re-education and curriculum development (Aarhus University and University of Southern Denmark in Odense), and textbook production and distribution (various facilities throughout Denmark).