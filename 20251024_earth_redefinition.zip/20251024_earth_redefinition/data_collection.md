## 1. Operational Budget Viability: 18-Month Fixed Cost Projection

The foundational assumption (Review Issue 1) is that 150M DKK is sufficient for aggressive logistics start-up and 18 months of initial audit/liaison operations. This data is critical; if insufficient, the ability to train teachers (the critical path) fails entirely, regardless of content quality.

### Data to Collect

- Detailed Level 3 cost projection for establishing and running three residential training centers (L1, L2, L3) for 18 months (staffing, subsistence, specialized materials).
- Actual current leasing/acquisition costs for identified temporary facilities (Location 1, 2, 3).
- Projected 18-month operational cost for the 15 Supreme Mandate Liaisons and core administrative staff (Location 2 hub).

### Simulation Steps

- Use Microsoft Excel or Google Sheets to model a time-phased burn rate for the 150M DKK logistics budget based on the 9-month activation spike followed by 9 months of reduced operational load.
- Simulate potential cost overruns (up to +25% contingency) on fixed facility costs using Monte Carlo simulation within Excel to identify the probability of hitting the funding cliff before Month 18.

### Expert Validation Steps

- Consult with Expert 7 (Logistics and Facility Activation Specialist) to validate the lead-time and cost assumptions for securing and equipping three massive training centers in the Danish market.
- Consult with Expert 3 (Public Sector Financial Auditor) to validate the baseline required operational cost estimate and assess the risk profile of the current 150M DKK logistics buffer.

### Responsible Parties

- Fiscal Pacing and Procurement Controller
- National Teacher Reeducation Logistics Commander

### Assumptions

- **High:** The three training centers can be fully activated and operational within 9 months using the allocated logistical budget portion.
- **Medium:** The cost estimate used for the initial 18 months of operational personnel (Liaisons and core logistics staff) is accurate.

### SMART Validation Objective

By 2026-06-30, secure and validate an 18-month operational fixed cost projection for L1, L2, L3 facilities and the 15 Liaisons, demonstrating a minimum of 30M DKK liquid contingency remaining in the logistics buffer beyond the required capital expenditure.

### Notes

- This validation must determine the immediate need for budget reallocation from the 350M DKK content budget as per expert advice (Expert 1 & 2).


## 2. Legal Viability of Legislative Continuity Buffer (Decision 5 Contingency)

The entire permanence of the project hinges on this legislative approval. Failure requires immediate activation of Plan B. We must validate the legality of Plan B before the legislative deadline to prevent total project collapse (Threat 2/Review Issue 3).

### Data to Collect

- Formal legal analysis mapping the specific constitutional requirements (Grundloven articles) impacted by the proposed curriculum mandate.
- Draft legal text for Contingency Plan B: the executive decree intended to empower Liaisons if the two-thirds parliamentary vote fails.
- Legal assessment of the probability (percentage) of securing the necessary two-thirds supermajority vote in the Danish Parliament within 12 months.

### Simulation Steps

- Legal Counsel to map potential judicial review points based on existing Danish administrative law precedent.
- Lobbying Advisor to model required political buy-in based on current party alignments to generate a weighted probability score for the 2/3 majority vote.

### Expert Validation Steps

- Consult with Expert 1 (Constitutional Law Specialist) for critical review of Decision 5's feasibility and the legal soundness of Contingency Plan B.
- Consult with Expert 5 (Lobbying and Political Strategy Advisor) to validate the political viability assessment for securing the two-thirds legislative majority by Month 12.

### Responsible Parties

- Legal and Regulatory Defense Counsel
- Chief Mandate Architect & Political Liaison

### Assumptions

- **High:** The proposed legislative change to the National Education Act can legally mandate the purging of established scientific doctrine in favor of political narrative.
- **High:** Contingency Plan B (Executive Decree) is legally sound and enforceable under existing emergency Danish administrative law to override statutory requirements if the amendment fails.

### SMART Validation Objective

By 2026-06-30, the Legal and Regulatory Defense Counsel must deliver a formal, vetted report confirming either the legal pathway for the legislative amendment (Decision 5) or certifying the executive enforceability of Contingency Plan B, with zero ambiguity regarding immediate counter-injunction success probability.

### Notes

- This is the highest priority assumption linked to political survival. If high-sensitivity assumption 3 is invalidated, the strategy may need to shift from Pioneer to crisis management.


## 3. Physics Curriculum Coherence and Modeling Path Gate

The physics/math content coherence directly impacts teacher training depth (Risk 2) and subsequent classroom execution quality. Choosing the wrong modeling path risks intellectual collapse despite ideological purity.

### Data to Collect

- A formal technical assessment contrasting the feasibility, timeline impact, and technical risk of developing the 'Purely Phenomenological' model (Choice 1) versus the 'Novel Mathematical Framework' (Choice 3) for Physics.
- A 60-day deliverable roadmap from the Lead Curriculum Synthesis Director detailing the required mathematical transformation proofs for core concepts (e.g., gravity) under the flat-earth axiom.
- Initial findings/validation report on the cost/timeline impact of the 'bridging coursework' outlined in Expert Review 1.6.C.

### Simulation Steps

- Dr. Li's team will use theoretical modeling software (e.g., MATLAB/Python libraries) to simulate the required complexity for a functionally consistent, internally rigorous flat-earth physics model over 30 days to establish a baseline complexity estimate.
- Simulate the content delivery timeline (60 days) required for descriptive curriculum vs. modeling curriculum.

### Expert Validation Steps

- Consult with Expert 2 (K-12 Science Curriculum Specialist) to validate the technical comparison report and assess the pedagogical collapse risk of the descriptive model (Issue 2.4.A).
- Consult with Expert 6 (Educational Psychologist) to gauge the cognitive load difficulty for teachers mastering the chosen model during the residential training phase.

### Responsible Parties

- Lead Curriculum Synthesis Director (Dr. Jian Li)
- Bureaucratic Enforcement & Compliance Lead (for alignment with compliance metrics)

### Assumptions

- **High:** A purely descriptive (phenomenological) Physics model (Decision 10, Choice 1) can meet the mandated ideological purity requirements for Phase 1 rollout without collapsing under basic interrogation.
- **Medium:** The scientific/mathematical challenge of rewriting core Physics principles can be sufficiently addressed within the 10-month content cycle, even if that only results in a descriptive model.

### SMART Validation Objective

Within 60 days (2026-06-15), the Physics Curriculum Modeling Approach must be finalized, either confirming the descriptive model is adequate (with justification provided) or providing a cost/timeline breakdown for developing a mathematically coherent transition module, validated against Expert 2's pedagogical acceptance criteria.

### Notes

- If the cost/timeline for Choice 3 is manageable, the descriptive model (Choice 1) should be abandoned due to high pedagogical risk.


## 4. Teacher Training Cohort Capacity and Knowledge Retention Assessment

The single greatest operational bottleneck is teacher retraining speed and efficacy. Data must confirm the Pioneer strategy's high-cost residential training yields sufficient knowledge retention to meet compliance targets.

### Data to Collect

- Actual capacity analysis for the three training centers (L1, L2, L3), specifying throughput (teachers trained per month) based on validated operational budgets (from Data Item 1).
- Baseline competency scores from a 5% teacher proxy group sample, stratified by subject (Math/Physics showing greatest need).
- Data defining the minimum acceptable mastery threshold required for teachers to pass the Political Compliance Measurement (Decision 6).

### Simulation Steps

- Model teacher training throughput against the required total teaching corps size (not specified, must be estimated from national data) to calculate the percentage of the teaching staff left untrained or poorly trained by Month 18.
- Simulate knowledge retention decay rates (based on Expert 6 input) over the 6-9 month gap between training completion and Phase 1 deployment (Assumption 7).

### Expert Validation Steps

- Consult with Expert 6 (Educational Psychologist) to validate assumptions about knowledge retention, particularly concerning complex scientific concepts taught rapidly.
- Consult with Expert 4 (Change Management Consultant) to analyze the effectiveness of using high-intensity residential training versus ongoing, lower-intensity reinforcement for ideological buy-in.

### Responsible Parties

- National Teacher Reeducation Logistics Commander
- Bureaucratic Enforcement & Compliance Lead

### Assumptions

- **High:** The residential training model is sufficiently high-fidelity to ensure that teachers pass the initial compliance assessment within the standardized cycle, minimizing the need for expensive remedial training blocks.
- **Medium:** The total Danish teaching population requiring retraining is manageable within the 36-month window, even with logistical constraints.

### SMART Validation Objective

By 2026-07-31, establish the baseline teacher capacity model, demonstrating that the planned residential training schedule, combined with mandatory 2-month online reinforcement modules (Recommendation 2 in Omissions), can certify 100% of essential instructional staff by Month 18 with an expected minimum 80% subject mastery score.

### Notes

- Total teacher population data is missing but considered critical input for calculating required throughput.

## Summary

Immediate actions must focus on validating foundational financial stability and legal risk exposure, as dictated by expert review, before committing further resources to content creation. The Pioneer strategy introduces severe upfront financial and institutional risks that must be quantified immediately.

**Immediate Actionable Tasks:**
1. **(High Priority Financial Stability):** Expert 1/3 input required immediately: Finalize the 18-month operational budget viability projection (Data Item 1). If validation fails, freeze 15% of content budget IMMEDIATELY for reallocation (Task: Fiscal Pacing and Procurement Controller).
2. **(Critical Legal Risk):** Expert 1/5 input required immediately: Legal/Political team must produce a validated report (by 2026-06-30) definitively certifying the legal pathway for either Legislative Buffer (Decision 5) or Contingency Plan B implementation (Data Item 2).
3. **(Critical Content Gate):** Halt Physics content development until the Lead Curriculum Synthesis Director provides a 60-day comparative technical assessment of Descriptive vs. Fully Rigorous Physics modeling paths (Data Item 3), informed by Expert 2.