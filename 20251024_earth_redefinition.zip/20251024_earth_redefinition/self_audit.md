Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The plan focuses on curriculum changes, teacher training, and public communication, which are all within the realm of social and political actions rather than physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (flat earth curriculum) + market (Danish education system) + tech/process (teacher retraining) + policy (government mandate) without independent evidence at comparable scale. No credible precedent exists for this system.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-07-01


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the strategic concepts driving the plan. For example, the plan mentions 'intellectual sovereignty' and 'authentic knowledge' without defining how these concepts translate into measurable outcomes or customer value.

**Mitigation**: Project Manager: Create one-pagers for 'intellectual sovereignty' and 'authentic knowledge' with value hypotheses, success metrics, and decision hooks by 2026-05-08.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (ethical) is absent. The plan omits ethical considerations regarding the intentional dissemination of misinformation to children. The plan fails to address the psychological impact on students.

**Mitigation**: Ethics Committee: Conduct an ethical review involving ethicists, educators, and legal experts. Develop an ethical framework addressing academic freedom and student well-being within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions government approval as an assumption, but lacks a detailed analysis of required permits, approvals, and their associated lead times. The plan does not include a permit/approval matrix.

**Mitigation**: Legal Team: Create a permit/approval matrix identifying all required permits, lead times, and dependencies. Rebuild the critical path with this data by 2026-05-15.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are absent. The plan mentions a budget of 500 million DKK but does not specify the funding sources, their status (e.g., LOI/term sheet/closed), the draw schedule, or the runway length.

**Mitigation**: Finance Team: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates by 2026-05-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the strategic concepts driving the plan. For example, the plan mentions 'intellectual sovereignty' and 'authentic knowledge' without defining how these concepts translate into measurable outcomes or customer value.

**Mitigation**: Project Manager: Create one-pagers for 'intellectual sovereignty' and 'authentic knowledge' with value hypotheses, success metrics, and decision hooks by 2026-05-08.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., curriculum completion, teacher training, school implementation) as single point estimates without providing a range or discussing alternative scenarios. The timeline lacks sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis for the curriculum completion date, including best-case, worst-case, and base-case scenarios by 2026-05-15.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications, interface definitions, test plans, or integration maps for curriculum development, teacher retraining, or textbook production.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for curriculum development by 2026-06-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, the plan states, 'We have assembled a dedicated legal team to defend our position' but does not provide any details about the team's expertise or qualifications.

**Mitigation**: Legal Team: Provide a list of the legal team members, their qualifications, and their experience in relevant legal areas by 2026-05-15.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the major deliverable 'flat-earth curriculum' is mentioned without specific, verifiable qualities. The plan does not define what constitutes an acceptable curriculum.

**Mitigation**: Curriculum Director: Define SMART criteria for the flat-earth curriculum, including a KPI for ideological consistency (e.g., 100% alignment with flat-earth principles) by 2026-05-15.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes establishing a 'Flat Earth Research Institute'. This adds cost/complexity but doesn't support core goals like curriculum revision or teacher training. It aims to lend credibility, not directly educate.

**Mitigation**: Project Team: Produce a one-page benefit case for the 'Flat Earth Research Institute', including KPI, owner, and estimated cost, or move it to the project backlog by 2026-05-15.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Chief Ideological Strategist' role is both essential and likely difficult to fill. This role requires a deep understanding of the project's ideology and the ability to navigate a complex political landscape.

**Mitigation**: HR Team: Conduct a talent market analysis for the 'Chief Ideological Strategist' role, assessing the availability of qualified candidates within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions government approval as an assumption, but lacks a detailed analysis of required permits, approvals, and their associated lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix identifying all required permits, lead times, and dependencies. Rebuild the critical path with this data by 2026-05-15.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear, sustainable operational model. The plan mentions 'Questionable sustainability due to lack of scientific basis' and 'Need to revise curriculum, additional costs, damage to credibility' but lacks a mitigation plan.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits critical zoning, occupancy, fire, structural, noise, and permit constraints. The plan does not address whether the proposed locations for teacher re-education, curriculum development, and textbook printing comply with local regulations.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen on all proposed sites, documenting zoning, occupancy, fire, structural, noise, and permit constraints by 2026-06-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not describe any redundancy or failover for critical external dependencies. The plan mentions securing textbook vendors but lacks details on SLAs, secondary suppliers, or tested failover procedures.

**Mitigation**: Logistics Team: Secure SLAs with textbook vendors, add a secondary supplier, and test failover by simulating a primary vendor outage by 2026-07-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Ministry of Education' is incentivized to maintain stability and avoid controversy, while the 'Supreme Political Leader' is incentivized to implement radical change. This creates a conflict over the pace and scope of curriculum revision.

**Mitigation**: Project Manager: Define a shared OKR (Objective and Key Results) that aligns the Ministry of Education and the Supreme Political Leader on a measurable outcome by 2026-05-15.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Define thresholds for re-planning/stopping by 2026-05-15.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Public backlash (Risk 4), Legal challenges (Risk 1), and Operational difficulties retraining teachers (Risk 5) are tightly linked. Public backlash could trigger legal challenges, and teacher resistance could undermine implementation.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-06-01.