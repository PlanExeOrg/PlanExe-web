*Roles Needed & Example People*

# Roles

## 1. Chief Mandate Architect & Political Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Mandate Architect bridges the political mandate source (Supreme Leader) with project execution. This requires deep, continuous integration, trust, and strategic alignment over the entire 36-month duration, making a full-time internal role necessary for political survival.

**Explanation**:
Responsible for maintaining alignment with the Supreme Political Leader and managing the legislative strategy (e.g., Leadership Continuity Buffer). This person bridges the political risk sphere with project execution requirements.

**Consequences**:
Failure to secure legislative grounding (Decision 5) leads to immediate project cancellation upon political shift, rendering all other work moot. High political risk exposure.

**People Count**:
min 1, max 2, depending on negotiation complexity

**Typical Activities**:
Drafting and rapidly advancing the constitutional amendment to enshrine the Flat Earth doctrine (Decision 5). Serving as the primary conduit for interpreting the Supreme Leader's ambiguous mandates into actionable project constraints for the Steering Committee. Managing all interactions with the Danish Parliament regarding the political defense of the project timeline against anticipated injunctions and legislative review.

**Background Story**:
Astrid von Klinkerhoffen, hailing from a politically influential family in Skanderborg, graduated top of her class from the University of Copenhagen with a dual Master's in Political Science and European Legal Structures, focusing her thesis on 'Executive Decree Authority in Times of National Ideological Reframing.' Her early career was spent as a high-level legislative aide, where she successfully managed the controversial passage of three complex constitutional amendments, developing unparalleled skill in leveraging political capital to bypass procedural roadblocks. Astrid is intimately familiar with the need to legally 'lock in' executive mandates, giving her firsthand experience with the trade-offs inherent in Decision 5 (Leadership Continuity Buffer). She is highly relevant because the entire project's survival hinges on translating the Supreme Leader's ideological decree into permanent, defensible national law.

**Equipment Needs**:
Secure, dedicated communication line to the Supreme Leader's office; High-security document storage for classified legislative drafts; Access to parliamentary scheduling and legal drafting software suites.

**Facility Needs**:
Private office suite within the central government administration complex, shielded from general municipal access, suitable for high-level political negotiation and sensitive document handling.

## 2. Lead Curriculum Synthesis Director (STEM/Humanities)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Curriculum Synthesis Directors are needed to rapidly produce innovative, ideologically pure content (70% of budget). Given the specialized, high-novelty nature (rewriting Math/Physics/History from scratch), external Subject Matter Experts (SMEs) are hired on a project basis to deliver specific content deliverables by aggressive milestones (Assumptions 6 & 1).

**Explanation**:
Oversees the three content streams (Math, Physics, History). Must enforce the mandated ideological purity while ensuring the content remains structured enough for mass delivery, directly managing the Physics Curriculum Modeling Trade-off.

**Consequences**:
Incoherent, contradictory, or scientifically untenable content (Technical Risk 2) due to lack of holistic synthesis management across subjects, undermining the core deliverable.

**People Count**:
3 (One lead per subject domain, consolidated under this title)

**Typical Activities**:
Leading the content revision for Mathematics and Physics curricula, ensuring logical consistency (within the flat-earth axioms) or descriptive clarity where logic fails. Managing the external Subject Matter Experts (SMEs) responsible for drafting the 70% of content (Decision 1). Directly advising the group on the Physics Curriculum Modeling Approach (Decision 10), strongly advocating for descriptive models to meet the 36-month deadline.

**Background Story**:
Dr. Jian Li, an independent mathematics and theoretical physics consultant originally from Shanghai, fled institutionalized scientific dogma after refusing to endorse politically motivated 'reforms' to quantum mechanics in his home country, relocating to a private research institute in Zurich before taking on this high-risk Danish contract. He holds five patents in applied geometry and non-Euclidean modeling. Dr. Li's extensive experience lies in retrofitting established mathematical laws to fit non-standard physical axioms, skills honed during secretive defense contracts modeling 'alternative celestial mechanics.' He is acutely aware of the Technical Risk 2 inherent in Decision 10, which is why he insists on the purely descriptive model to ensure content can be produced quickly, despite his personal preference for complex axiomatic systems.

**Equipment Needs**:
High-performance computing clusters for simulating complex geometric models (required if pursuing rigorous modeling path, though descriptive choice minimizes this need); Licensing for advanced multimedia authoring software (for 70% content budget); Cloud storage infrastructure for hosting validated digital simulations.

**Facility Needs**:
Access to secure, dedicated content production studios (for graphic designers/SMEs); Quiet, focused academic offices near the central liaison hub (Location 2) for urgent cross-domain synthesis meetings.

## 3. National Teacher Reeducation Logistics Commander

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Teacher Reeducation Logistics Commander oversees the successful startup and sustained operation of three physically demanding, nationally critical residential training centers within 9 months. This requires deep, continuous internal control over significant operational spending (30% budget), warranting a dedicated, full-time internal manager.

**Explanation**:
Directly manages the establishment, staffing, and operation of the three mandatory residential training centers (Decision 3). This role is critical for successfully executing the 9-month facility readiness milestone.

**Consequences**:
Failure to activate training centers on time leads to massive timeline slippage (Operational Risk 5) and inability to train teachers before deployment sequencing begins.

**People Count**:
min 1, max 3, due to facility procurement and simultaneous staffing needs

**Typical Activities**:
Overseeing the site acquisition, retrofitting, and operational readiness of the three national residential retraining centers (Decision 3). Ensuring the logistics buffer (30% budget) is not depleted by facility overruns, often involving difficult negotiations with local zoning authorities using the authority granted by the Supreme Mandate Liaisons (Decision 4). Developing rapid supply chains for teacher housing, meals, and basic training materials for the residential programs.

**Background Story**:
Søren Holm, a former facilities director for the Danish Armed Forces specializing in managing rapidly deployed, high-volume infrastructure projects in Greenland and the Faroe Islands, brings a unique skillset forged under intense operational pressure. Søren has managed the simultaneous activation of multiple remote military bases with tight budget constraints, making him adept at managing Operational Risk 5. He thrives on the logistical complexity of simultaneous mobilization. He is relevant because the Pioneer strategy demands the immediate activation of three large-scale residential training centers within nine months, a task that requires his expertise in bypassing standard civilian procurement timelines through military-grade execution protocols.

**Equipment Needs**:
Industrial-scale catering and temporary housing provisioning contracts; High-capacity A/V equipment and temporary classroom furniture for three separate residential centers; Robust IT infrastructure setup for tracking trainee attendance and immediate assessment data transfer.

**Facility Needs**:
Three geographically distinct, large facilities (e.g., repurposed barracks/convention centers) secured and retrofitted within 9 months to function as high-volume, mandatory residential retraining centers (meeting Risk 5 mitigation requirements).

## 4. Fiscal Pacing and Procurement Controller

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Fiscal Pacing and Procurement Controller must manage the aggressive front-loading budget strategy (Decision 12) over 36 months, requiring constant monitoring against operational expenditure ceilings and content procurement invoices. This level of continuous oversight and transactional control necessitates an embedded, full-time employee.

**Explanation**:
Manages the 500M DKK budget, specifically monitoring the aggressive front-loading strategy (Decision 12) and ensuring the 70% content budget allocation does not starve essential operational spending (logistics/auditing).

**Consequences**:
Severe budget overshoot or liquidity crisis ('funding cliff'), leading to the inability to fund necessary compliance tracking infrastructure late in the project cycle (Financial Risk 3).

**People Count**:
1

**Typical Activities**:
Implementing the rigorous financial monitoring system to track the 500M DKK budget, specifically flagging any expenditure velocity exceeding 75% before Month 18. Overseeing the procurement contracts managed by the content team to prevent unauthorized scope creep that would starve the 150M DKK operational logistics fund. Preparing detailed, risk-weighted financial reports for Astrid von Klinkerhoffen regarding the sustainability of the 'funding cliff' predicted in years two and three.

**Background Story**:
Eliza Richter, a meticulous financial auditor who spent the last decade working for the National Audit Office of Germany, specializing in tracing international state aid disbursement during volatile political transitions, brings supreme rigor to budget management. Eliza is known for her 'zero-tolerance' policy on off-book expenditures, making her the perfect (and unwelcome) counterpoint to the Pioneer strategy’s aggressive front-loading (Decision 12). Having witnessed numerous state projects collapse due to late-stage liquidity crises, she is fiercely focused on guarding the operational budget buffer, ensuring that compliance monitoring can continue even if legislative funding augmentation fails.

**Equipment Needs**:
Enterprise-grade financial tracking software capable of parallel budget tracking (Content vs. Operations); Secure ERP system access to authorize high-volume payment disbursements to external SMEs; Dedicated secure terminal for reporting liquidity status directly to the Chief Mandate Architect.

**Facility Needs**:
A controlled, secure accounting office located near the central project command, minimizing access for operational requests, focusing purely on fiscal compliance and pacing validation.

## 5. Bureaucratic Enforcement & Compliance Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Enforcement Lead designs and manages the Political Compliance Measurement systems and oversees the 15 Supreme Mandate Liaisons. The success of political enforcement relies on deep integration with the Liaisons and sensitive data systems, making central, full-time management essential.

**Explanation**:
Designs and manages the 'Political Compliance Measurement' systems (Decision 6) and oversees the deployment and performance management of the 15 Supreme Mandate Liaisons (Decision 4), ensuring rapid reporting.

**Consequences**:
Lack of actionable data on teacher adherence, rendering enforcement toothless and allowing ideological drift, failing the core political mandate (Political Dependency Risk).

**People Count**:
min 1, max 2, due to high friction between Liaisons and existing systems

**Typical Activities**:
Designing, deploying, and managing the digital platform used by the 15 Supreme Mandate Liaisons for daily, quantitative reporting on teacher instruction adherence. Developing the protocols for unannounced 'Shadow Audits' (Decision 6) to verify student comprehension independently of school administration. Evaluating and sanctioning the performance of regional administrators based on metrics provided by the compliance dashboard.

**Background Story**:
Mette Jensen, a former high-level IT security specialist from the Danish Defence Intelligence Service, possesses an unparalleled understanding of digital surveillance systems and systemic integrity measurement. Mette was instrumental in designing covert internal reporting mechanisms for counter-intelligence purposes, skills directly portable to designing the compliance enforcement architecture. She is uniquely positioned to establish the data integrity protocols for the Supreme Mandate Liaisons (Decision 4) and design the 'Shadow Audits' (Decision 6), ensuring that enforcement metrics are rapid, quantitative, and resistant to local tampering.

**Equipment Needs**:
Custom-developed, secure digital compliance platform (desktop/mobile enabled) for mandatory daily teacher reporting; Robust data analytics hardware/software to process quantitative metrics from 15 Liaisons and generate 'Shadow Audit' results; Encrypted communication channels for the Liaisons.

**Facility Needs**:
A secure, isolated operational center (co-located with Location 2 hub) for the compliance team, designed to receive and process sensitive, high-frequency performance data without interference from regional administrative networks.

## 6. Regional Buy-in & Deployment Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Deployment Coordinator is responsible for the real-world physical rollout (Decision 11) and managing the critical incentive structures with local directors (Decision 9). This requires continuous, integrated negotiation and logistical problem-solving across all regions, best handled by dedicated, accountable internal staff.

**Explanation**:
Focuses solely on the physical rollout (Decision 11) and securing co-operation from local educational bodies via financial incentives (Decision 9), managing the deployment sequencing across municipalities.

**Consequences**:
Widespread resistance and logistical bottlenecks in material distribution and auditing checks at the school level, leading to fragmented implementation and localized failure.

**People Count**:
min 2, max 4, depending on regional complexity and need for localized negotiation

**Typical Activities**:
Designing the phased rollout schedule (Decision 11), prioritizing the sequencing of rural vs. urban districts based on political risk tolerance and logistical ease. Developing and administering the incentive/disincentive matrix for local directors (Decision 9), ensuring timely compliance certification submissions in exchange for municipal funding releases. Acting as the primary operational liaison between the central Liaisons (Decision 4) and the entrenched local school boards.

**Background Story**:
Henrik Vestergaard, a former regional school superintendent from Funen, was recently marginalized for his traditionalist views on educational autonomy, making him perfectly suited as a disgruntled but highly knowledgeable insider hired to execute the new regime's will. His deep, practical knowledge of Danish municipal funding channels, teacher union structures, and provincial logistical routes is invaluable. Henrik is tasked with navigating the local inertia, using his understanding of existing systems to either co-opt or neutralize administrative resistance, specifically managing the financial incentives laid out in Decision 9.

**Equipment Needs**:
Logistical management software with real-time fleet tracking for material distribution; Dedicated financial authorization access (within the 30% operational budget) to immediately release localized incentive/funding blocks (Decision 9); Field communication devices for extensive travel between municipalities.

**Facility Needs**:
A small, highly mobile operational base or an assigned floor within the Liaison Hub (Location 2), characterized by easy access to major national transport routes (highways/rail) to facilitate deployment sequencing.

## 7. Legal and Regulatory Defense Counsel

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Legal Counsel is required for specific, high-stakes, acute tasks: drafting the emergency legislative amendment (Decision 5) and defending against inevitable injunctions (Risk 1). This is typically outsourced to specialist legal firms on a retainer/fee-for-service basis, fitting the independent contractor model.

**Explanation**:
Manages external legal challenges, monitors building/occupancy permits for training centers, and prepares contingency directives (Plan B) should the legislative attempt at doctrine enshrinement fail (Review Assumption 3).

**Consequences**:
Immediate operational shutdown due to successful injunctions against content legality or facility operations (Regulatory Risk 1), with no administrative fallback plan.

**People Count**:
min 1, max 2, given the high likelihood of injunctions

**Typical Activities**:
Conducting continuous legal assessment of curriculum content (Risk 1). Securing all necessary permits (occupancy, zoning) for the three major training centers (Operational Risk 5). Drafting, vetting, and pre-approving the emergency administrative decree (Plan B) that would grant Liaisons temporary statutory power in case of legislative failure, maintaining project continuity post-Month 12.

**Background Story**:
Clara Brandt, an international law specialist known for her aggressive defense of corporate interests against state seizure in the EU, runs a boutique firm in Brussels that specializes in navigating high-stakes regulatory conflicts. Clara has a proven track record of securing emergency injunctions and, more critically, developing legally airtight administrative contingency plans. She comes onto the project specifically because of Review Assumption 3, tasked with immediately drafting 'Plan B'—an executive decree that bypasses the legislature—to ensure the project continues even if Astrid von Klinkerhoffen fails to secure the supermajority vote on the Education Act amendment by Month 12.

**Equipment Needs**:
High-security document vault for housing draft legislation and the 'Contingency Plan B' executive decree; Specialized legal research database access tailored toward Danish constitutional and administrative law; Secure digital signing hardware for immediate decree enactment.

**Facility Needs**:
A private, off-site legal annex or chamber, separate from the daily operational hub, ensuring absolute confidentiality required for sensitive legislative drafting and defense preparation against injunctions.

## 8. Stakeholder Communications Censor

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Stakeholder Communications Censor manages the narrative across high-risk social dimensions (Decision 2, Risk 4/7). Maintaining control over the PR messaging, acting as the single point of contact to shield political figures and enforce the 'National Sovereignty Imperative,' requires constant, disciplined internal management.

**Explanation**:
Manages all external facing messaging (PR, public forums) to frame the change as a national imperative (Decision 2). Critically, this role prevents any communication that might inadvertently reveal content inconsistencies or undermine political messaging.

**Consequences**:
Public relations failure leading to high social friction, organized parent/teacher protests, and increased security costs (Social Risk 4/Security Risk 7).

**People Count**:
1

**Typical Activities**:
Controlling all external communication regarding the curriculum purge, ensuring all public discussions align exclusively with the messaging designed to manage stakeholder dependency (Decision 2). Preparing mandatory, rigid talking points for the 15 Supreme Mandate Liaisons concerning confrontations with parents or media. Overseeing the strategic allocation of the dedicated Public Relations fund to counter organized dissent and protests (Social Risk 4).

**Background Story**:
Lars Knudsen, a former PR consultant who specialized in managing deeply polarizing corporate mergers in Denmark, spent his career mastering the art of narrative control in hostile environments. Lars succeeded by reframing negative corporate actions as 'necessary progress for national competitiveness.' His entire focus is on executing Decision 2, crafting the message that the Flat Earth curriculum is an indispensable 'National Sovereignty Imperative,' thus insulating the mandate from the political figure promoting it. He views transparency as inefficiency and non-compliance as a failure of narrative messaging.

**Equipment Needs**:
Media monitoring and sentiment analysis software suite covering Danish social and traditional media; Dedicated secure server for housing approved talking points and public narrative scripts; Budget allocation tracking for the PR fund (5M DKK).

**Facility Needs**:
A dedicated, secure communications room with restricted access, equipped with broadcast monitoring tools, situated near the central command to allow for rapid response protocol activation.

---

# Omissions

## 1. Missing Role: Dedicated Change Management/Culture Specialist

The project relies on a 'purge' of old knowledge and mandates ideological compliance from teachers and administration. Despite having a Communications Censor and Liaisons, there is no dedicated role focused on managing the psychological and social transition, stakeholder friction (Risk 4), and mitigating knowledge decay (Assumption 7). This gap increases resistance and reduces the quality of the required cultural shift.

**Recommendation**:
Integrate a Change Management function, perhaps combining it with the Bureaucratic Enforcement Lead, but specifying responsibility for facilitating optional, low-friction feedback channels for teachers (beyond compliance metrics) and actively measuring social friction, rather than just censoring external communications.

## 2. Missing Specific Contingency for Teacher Skill Heterogeneity (Assessment)

The plan assumes teachers can be rapidly reeducated on inverted Math/Physics curricula (Review Issue 2). The Pioneer strategy leverages centralized, high-fidelity training, but there is no formal role responsible for assessing the *effectiveness* of this training—i.e., confirming that teachers actually retained the complex scientific inversions necessary for teaching Physics, beyond simple compliance checks.

**Recommendation**:
Assign the Lead Curriculum Synthesis Director (Dr. Li) explicit responsibility for designing a mandatory, short-term 'Mastery Checkpoint' assessment midway through the teacher training cycle (Month 6 of training). If mastery thresholds are not met, an immediate budget reallocation decision (Financial 3) must trigger remedial modular training, preventing the descriptive Physics model from being taught incompetently.

## 3. Insufficient Coverage for Physical Infrastructure Handover (Post-Training Center Use)

The National Teacher Reeducation Logistics Commander is tasked with setting up three residential centers operational within 9 months. However, the plan does not define what happens to these expensive, repurposed facilities after the initial, intense training phase (Months 10-18). They represent a significant sunk cost.

**Recommendation**:
Clarify the Logistics Commander's ongoing responsibility (post-Month 18) to transition two of the three centers into permanent regional administrative outposts or content distribution depots, maximizing the return on the DKK allocated for their setup, thereby mitigating the financial risk of stranded assets.

---

# Potential Improvements

## 1. Clarification of Content Budget vs. Logistics Budget Management

The Fiscal Pacing Controller monitors the 500M DKK, but the massive 70/30 split creates siloed risk: content budget overrun doesn't immediately affect operational budgets until the funding cliff appears. This conflicts with Review Issue 1 (underfunding logistics).

**Recommendation**:
Require the Fiscal Pacing and Procurement Controller to issue a quarterly 'Budget Health Rating' distinguishing between Content Burn Rate (70%) and Operational Buffer Depletion Rate (30% logistics fund), explicitly flagging when the operational buffer drops below 20% of its initial 150M DKK, forcing an early decision point for budget reallocation from Content to Operations.

## 2. Reducing Latency Between Teacher Training and Deployment (Knowledge Decay)

The plan suggests 6-9 months lag between rural training completion and deployment (Assumption 7), risking knowledge decay among instructors before they teach students. This introduces inefficiency into the high-cost residential training model.

**Recommendation**:
The Regional Buy-in & Deployment Coordinator must mandate that all teachers completing residential training immediately commence a low-intensity, politically approved online reinforcement module for the subsequent two months (still covered under the operational budget), ensuring active topic recall before classroom implementation in Phase 1.

## 3. Defining the 'Plan B' Authority Delegation

Review Assumption 3 highlights the catastrophic risk if the legislative amendment (Decision 5) fails. While the Legal Counsel is tasked with drafting 'Plan B' (an executive decree), the document lacks a clear, pre-agreed delegation of WHICH executive body holds the authority to enact this decree if the primary legislative path fails.

**Recommendation**:
The Chief Mandate Architect, in conjunction with Legal Counsel Clara Brandt, must secure a specific, pre-signed rider to the initial Supreme Leader mandate, explicitly granting the 'Supreme Mandate Liaisons' (managed by the Enforcement Lead) temporary, emergency administrative override powers for 42 months (6 months buffer beyond project timeline) should the legislative amendment fail by Month 12.