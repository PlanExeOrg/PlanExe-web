### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR for review by the Minister of Education, Permanent Secretary, and the Supreme Political Leader's representative.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager incorporates feedback and finalizes the Project Steering Committee ToR.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Review Feedback
- Circulation Email

### 4. Supreme Political Leader (or designated representative) formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Supreme Political Leader

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to approve the project plan and establish initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes
- Approved Project Plan
- Initial Priorities Defined

**Dependencies:**

- Meeting Invitation
- Agenda
- Appointment Confirmation Email

### 7. Project Director drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Committee ToR v0.1

**Dependencies:**

- Approved Project Plan

### 8. Project Director circulates Draft Ethics and Compliance Committee ToR for review by the Ministry of Justice representative.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Ethics and Compliance Committee ToR v0.1

### 9. Project Director incorporates feedback and finalizes the Ethics and Compliance Committee ToR.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final Ethics and Compliance Committee ToR v1.0

**Dependencies:**

- Review Feedback
- Circulation Email

### 10. Project Steering Committee formally appoints the Ethics and Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics and Compliance Committee ToR v1.0

### 11. Project Director schedules the initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email

### 12. Hold the initial Ethics and Compliance Committee kick-off meeting to review the project plan and establish initial priorities.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes
- Initial Priorities Defined

**Dependencies:**

- Meeting Invitation
- Agenda
- Appointment Confirmation Email

### 13. Project Director establishes the Project Management Office (PMO) structure and processes.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- PMO Structure Document
- Process Flowcharts

**Dependencies:**

- Approved Project Plan

### 14. Project Director recruits PMO staff (Workstream Leads, Project Controller, Project Administrator, Risk Manager).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Job Descriptions
- Recruitment Plan
- Staffing Complete

**Dependencies:**

- PMO Structure Document

### 15. Project Director develops project management templates and tools for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Project Management Templates
- Risk Register Template
- Reporting Templates

**Dependencies:**

- Staffing Complete

### 16. Project Director sets up project tracking and reporting systems for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Tracking System
- Reporting System

**Dependencies:**

- Project Management Templates

### 17. Project Director defines communication protocols for the PMO.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Tracking System

### 18. Project Director schedules the initial PMO kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Communication Protocols Document

### 19. Hold the initial PMO kick-off meeting to assign initial tasks and responsibilities.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes
- Initial Task Assignments

**Dependencies:**

- Meeting Invitation
- Agenda

### 20. Project Director drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Approved Project Plan

### 21. Project Director circulates Draft Stakeholder Engagement Group ToR for review by the Public Relations Officer and Communication Specialist.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Circulation Email
- Review Feedback

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 22. Project Director incorporates feedback and finalizes the Stakeholder Engagement Group ToR.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Review Feedback
- Circulation Email

### 23. Project Steering Committee formally appoints the Stakeholder Engagement Group members (Parent Representative, Student Representative, Community Liaison Officer).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0

### 24. Project Director schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Emails

### 25. Hold the initial Stakeholder Engagement Group kick-off meeting to develop a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes
- Stakeholder Engagement Plan

**Dependencies:**

- Meeting Invitation
- Agenda