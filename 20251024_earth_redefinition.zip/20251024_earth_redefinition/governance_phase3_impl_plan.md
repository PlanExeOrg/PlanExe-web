### 1. Project Sponsor initiates the formal governance establishment phase by ratifying the project charter and appointing an interim Chair for the Project Executive Steering Committee (PESC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Signed Project Charter reflecting all strategic decisions (including Pioneer Strategy adoption)
- Formal designation of PESC Interim Chair

**Dependencies:**

- Strategic Path Selection ('The Pioneer' confirmed)

### 2. Interim PESC Chair drafts the initial Terms of Reference (ToR) for the PESC, incorporating membership, decision mechanisms, and the 25M DKK materiality threshold.

**Responsible Body/Role:** PESC Interim Chair

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PESC ToR v0.1

**Dependencies:**

- PESC Interim Chair Appointed

### 3. Legal Counsel drafts the necessary legislative language for the Leadership Continuity Buffer (Decision 5: Statutory Amendment) and Contingency Plan B (Executive Decree).

**Responsible Body/Role:** Chief Legal Counsel

**Suggested Timeframe:** Project Week 1-3

**Key Outputs/Deliverables:**

- Draft National Education Act Amendment Text
- Draft Contingency Plan B Executive Decree Text

**Dependencies:**

- Project Charter Signed
- Finalized scope for Science modeling (confirming descriptive Physics model per assumptions)

### 4. PESC Interim Chair circulates Draft PESC ToR and finalizes all proposed membership lists from the 'governance-phase2-bodies.json' document for final ratification.

**Responsible Body/Role:** PESC Interim Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Finalized PESC Membership Roster
- Final PESC ToR v1.0 Draft

**Dependencies:**

- Draft PESC ToR v0.1 complete
- Nominated Members List Available

### 5. PESC formally convenes its first meeting (Kick-off), ratifies its ToR, confirms all initial membership appointments, and formally appoints the Program Director to chair the OCB.

**Responsible Body/Role:** Project Sponsor / PESC Interim Chair

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PESC ToR v1.0 Approved and Published
- Minutes confirming PESC leadership and membership appointments
- Formal Instruction to Program Director to establish OCB

**Dependencies:**

- Finalized PESC Membership Roster
- Program Director Identified

### 6. Program Director (acting as OCB Chair) drafts the OCB ToR, focusing on SOPs for logistics and detailing the data structure necessary for Political Compliance Measurement (Decision 6).

**Responsible Body/Role:** Program Director (OCB Chair)

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- Draft OCB ToR v0.1
- Proposed SML Expense/Travel SOP Draft

**Dependencies:**

- PESC Kick-off Meeting Complete
- Decision 6 framework understood

### 7. Chief Legal Counsel and Compliance Officer draft the CAC ToR, explicitly detailing the requirements for Contingency Plan B and the framework for 'Shadow Audits'.

**Responsible Body/Role:** Chief Legal Counsel / Chief Compliance Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft CAC ToR v0.1 incorporating legal and audit mandates

**Dependencies:**

- Draft Contingency Plan B Text Complete (Step 3)
- Decision 6 framework understood

### 8. PESC reviews and formally approves the OCB ToR, granting the Program Director authority to proceed with operational setup and appointing all OCB members.

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- OCB ToR v1.0 Approved
- OCB Membership Confirmed and announced

**Dependencies:**

- Draft OCB ToR v0.1 complete

### 9. PESC reviews and formally approves the CAC ToR, granting the Chief Legal Counsel authority to establish audit mechanisms and finalize Contingency Plan B text.

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- CAC ToR v1.0 Approved
- CAC Membership Confirmed and announced

**Dependencies:**

- Draft CAC ToR v0.1 complete

### 10. OCB holds its inaugural meeting: finalizes SOPs, confirms roles for Logistics Manager and Content Manager, and initiates immediate site identification and leasing negotiations for the three residential training centers (Risk 5 mitigation).

**Responsible Body/Role:** OCB

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- OCB Kick-off Minutes with initial site requirement sign-off
- Approved SML Travel/Expense SOP

**Dependencies:**

- OCB ToR v1.0 Approved
- Project Locations identified (from assumptions: Jutland, N. Denmark, Zealand)

### 11. CAC holds its inaugural meeting: establishes the secure reporting hotline, finalizes the framework for Political Compliance Measurement (Decision 6), and validates the SML briefing content for the two-week immersion training.

**Responsible Body/Role:** CAC

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Secure Compliance Reporting System operational
- Finalized Shadow Audit Criteria
- CAC endorsement of SML compliance training structure

**Dependencies:**

- CAC ToR v1.0 Approved
- Decision 6 metrics finalized

### 12. Program Director commences recruitment and selection process for the 15 Supreme Mandate Liaisons (SMLs) based on prerequisites established by the Educational Administration Recalibration decision (Decision 4).

**Responsible Body/Role:** Program Director / Head of HR (via OCB mandate)

**Suggested Timeframe:** Project Weeks 9-12

**Key Outputs/Deliverables:**

- SML Candidate Shortlist finalized
- Offer Letters issued to 15 SMLs

**Dependencies:**

- OCB established and authorized procurement for personnel
- SOPs for liaison administrative tracking finalized

### 13. Content Development Team, funded by the 70% allocation, formalizes contracts with External SMEs based on the chosen descriptive Physics model (Decision 10) and begins drafting Math and History revisions.

**Responsible Body/Role:** Content Production Manager (Under OCB oversight)

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- Executed Contracts with SME Teams (Math, Physics, History)
- Draft Schedule for Content Vetting (6 months ideological, 3 months pedagogical)

**Dependencies:**

- PESC approval of Decision 10 (Descriptive Physics Model)
- Budget allocation confirmed (70% to Content)

### 14. Chief Legal Counsel submits the amendment proposal for the National Education Act (Leadership Continuity Buffer) to the Danish Parliament, simultaneously preparing briefing materials for the PESC on 'Contingency Plan B' readiness.

**Responsible Body/Role:** Chief Legal Counsel

**Suggested Timeframe:** Project Month 3 (Week 10-12)

**Key Outputs/Deliverables:**

- Legislative Submission Receipt
- Internal documentation confirming Contingency Plan B readiness for CAC review

**Dependencies:**

- Draft Legislative Language Complete (Step 3)
- CAC review scheduled

### 15. The 15 appointed SMLs commence their mandatory two-week immersive training, focused heavily on Compliance Measurement protocols (Decision 6) and OCB reporting mandates.

**Responsible Body/Role:** Head of Teacher Reeducation & Training Lead (via OCB mandate)

**Suggested Timeframe:** Project Month 4

**Key Outputs/Deliverables:**

- 15 SMLs Certified and Authorized
- SML Training Completion Report

**Dependencies:**

- SML Recruitment Complete (Step 9)
- CAC approval for training content delivered

### 16. OCB reviews physical progress on the three residential training centers (L1, L2, L3). If facility activation costs exceed 170M DKK total by Month 6 (Project Week 24), OCB initiates a formal request for 10% content budget reallocation to the PESC.

**Responsible Body/Role:** OCB

**Suggested Timeframe:** Project Month 6 (Continuous Monitoring)

**Key Outputs/Deliverables:**

- Monthly Facility Readiness Report
- Potential Budget Reallocation Request (if cost threshold breach occurs)

**Dependencies:**

- Logistics/Facilities Head fully operational (Step 8)
- Financial pacing mechanism established

### 17. CAC verifies the integrity of the digital compliance tracking system implementation by the Logistics team and validates the SMLs' authorized access rights before Phase 1 deployment commences.

**Responsible Body/Role:** CAC

**Suggested Timeframe:** Project Month 8

**Key Outputs/Deliverables:**

- System Integrity Certification for Political Compliance Measurement Platform
- Final SML Access Protocols Signed Off

**Dependencies:**

- Digital reporting system implementation complete (per assumptions)
- SMLs trained (Step 11)

### 18. Content teams deliver first iteration of *History* and *Mathematics* curriculum materials for ideological vetting (6-month cycle begins). Physics material held pending SME validation confirmation related to descriptive modeling.

**Responsible Body/Role:** Content Production Manager

**Suggested Timeframe:** Project Month 8

**Key Outputs/Deliverables:**

- History Curriculum Draft v1.0 submitted for Vetting
- Mathematics Curriculum Draft v1.0 submitted for Vetting

**Dependencies:**

- SME Contracts executed (Step 10)

### 19. PESC holds a critical review session on Legislative Status (Decision 5). If the amendment is not passed or delayed beyond Month 12, the PESC mandates immediate, full activation of Contingency Plan B via executive decree, transferring temporary statutory enforcement power to the SMLs.

**Responsible Body/Role:** PESC

**Suggested Timeframe:** Project Month 12 (Milestone Dependency)

**Key Outputs/Deliverables:**

- Legislative Status Report (Pass/Fail/Delayed)
- Activation Order for Contingency Plan B (if required)

**Dependencies:**

- CMS submission by Month 3
- CAC readiness assessment of Contingency Plan B

### 20. OCB oversees the commencement of Phase 1 Deployment (Geographic Deployment Sequencing – Rural Pilots). This includes deploying newly trained teachers/materials to the first set of designated rural districts and activating local audit verification by SMLs.

**Responsible Body/Role:** OCB / Lead SML

**Suggested Timeframe:** Project Month 10 (Start of Phase 1)

**Key Outputs/Deliverables:**

- Phase 1 Geographic Deployment Rollout Commencement Notice
- Initial SML Field Activity Reports

**Dependencies:**

- Minimum of 50% of required teachers certified in Phase 1 curriculum materials
- Legislative continuity secured or Contingency Plan B active