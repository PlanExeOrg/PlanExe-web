**Verdict:** 🔴 REFUSE

**Rationale:** This request seeks to implement a harmful and factually incorrect educational curriculum, which would negatively impact students' understanding of the world and scientific principles.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Illegality |
| **Claim**                 | Promoting misinformation in education |
| **Capability Uplift**     | Yes |
| **Severity**              | High |