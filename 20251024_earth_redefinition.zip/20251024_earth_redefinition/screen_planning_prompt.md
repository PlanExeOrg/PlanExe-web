**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete, though unconventional, project with specific parameters including a mandated outcome, location (Denmark), budget (500 million DKK), and timeline (36 months).