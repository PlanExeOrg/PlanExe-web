This plan involves money.

## Currencies

- **USD:** Primary location is the USA, so USD is the relevant currency.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.