## Suggestion 1 - Redox OS

Redox OS is a microkernel operating system written in Rust, aiming to bring the innovations of Rust to a modern microkernel design. It includes a complete set of tools and libraries to form a functional operating system. The project started in 2015 and is actively developed by a community of contributors.

### Success Metrics

Successful implementation of a microkernel in Rust.
Demonstrated memory safety and concurrency through Rust's features.
Active community contributions and continuous development.
Ability to run basic applications and utilities.
Adoption of RedoxFS, a next-generation file system.

### Risks and Challenges Faced

Challenge: Ensuring compatibility with existing hardware and software.
Mitigation: Focused on a clean-slate design, which allowed for avoiding legacy issues but required building everything from scratch.
Challenge: Achieving performance comparable to existing operating systems.
Mitigation: Continuous optimization of kernel and driver code, leveraging Rust's performance capabilities.
Challenge: Managing the complexity of a microkernel architecture.
Mitigation: Modular design and extensive use of Rust's type system to enforce correctness.

### Where to Find More Information

Official Website: https://www.redox-os.org/
GitHub Repository: https://github.com/redox-os/redox
Redox OS Book: https://doc.redox-os.org/book/

### Actionable Steps

Role: Contact the Redox OS community through their GitHub repository or mailing lists.
Name: Jeremy Soller (original creator).
Communication Channel: GitHub issues, Redox OS forums, or Redox OS Matrix channel.
Email: Not publicly available, use GitHub or community channels.

### Rationale for Suggestion

Redox OS is a highly relevant reference due to its use of Rust for OS development, its focus on memory safety and concurrency, and its modern microkernel design. While the user plans a monolithic kernel, studying Redox OS can provide valuable insights into memory management, driver development, and overall system architecture in Rust. The project's active community and extensive documentation make it an excellent resource. The project is geographically distant (Global), but its technical relevance outweighs geographical proximity.
## Suggestion 2 - Theseus OS

Theseus is a capability-based operating system written in Rust that prioritizes safety and security through compile-time verification and fine-grained memory protection. It aims to eliminate entire classes of runtime errors and security vulnerabilities. The project is research-oriented and focuses on innovative OS design.

### Success Metrics

Demonstrated compile-time safety and security.
Successful implementation of capability-based security model.
Achieved fine-grained memory protection.
Published research papers and presentations.
Ability to run complex applications with minimal runtime errors.

### Risks and Challenges Faced

Challenge: Overcoming the complexity of capability-based security.
Mitigation: Extensive use of Rust's type system and compile-time checks to enforce security policies.
Challenge: Achieving acceptable performance with fine-grained memory protection.
Mitigation: Careful optimization of memory management and context switching mechanisms.
Challenge: Ensuring compatibility with existing hardware and software.
Mitigation: Focused on a clean-slate design, which allowed for avoiding legacy issues but required building everything from scratch.

### Where to Find More Information

Official Website: https://www.theseus-os.com/
GitHub Repository: https://github.com/theseus-os/Theseus
Research Papers: Available on the official website and in academic databases.

### Actionable Steps

Role: Contact the Theseus OS research team.
Name: Dr. Ben Hardekopf (primary investigator).
Communication Channel: Email or through the Theseus OS GitHub repository.
Email: hardekopf@wsu.edu

### Rationale for Suggestion

Theseus OS is another highly relevant project due to its strong emphasis on memory safety and security, which aligns with the user's concerns about memory management bugs and security vulnerabilities. Although Theseus OS employs a capability-based security model, studying its approach to memory protection and compile-time verification can provide valuable insights for the user's project. The project's research focus and published papers offer a wealth of information. The project is geographically distant (USA), but its technical relevance outweighs geographical proximity.
## Suggestion 3 - rCore

rCore is a minimal operating system kernel written in Rust for educational purposes. It aims to provide a simple and understandable implementation of basic OS functionalities, such as process management, memory management, and file system support. It is designed to run on RISC-V architecture but can be adapted to x86.

### Success Metrics

Successful implementation of a minimal OS kernel in Rust.
Clear and understandable code for educational purposes.
Ability to run basic applications and utilities.
Active use in university courses and workshops.
Adaptation to multiple architectures, including RISC-V and x86.

### Risks and Challenges Faced

Challenge: Balancing simplicity with functionality.
Mitigation: Focused on implementing only the essential OS functionalities, such as process management, memory management, and file system support.
Challenge: Ensuring code clarity and understandability for educational purposes.
Mitigation: Extensive commenting and documentation of the code, as well as a modular design.
Challenge: Adapting the kernel to different architectures.
Mitigation: Using a hardware abstraction layer (HAL) to isolate architecture-specific code.

### Where to Find More Information

GitHub Repository: https://github.com/rcore-os/rCore
Online Book: https://rcore-os.github.io/rCore-Tutorial-Book-v3/
Related Publications: Search for publications related to rCore on academic databases.

### Actionable Steps

Role: Contact the rCore development team through their GitHub repository.
Name: Identified through GitHub contributors list.
Communication Channel: GitHub issues or pull requests.
Email: Not publicly available, use GitHub.

### Rationale for Suggestion

rCore is a valuable reference due to its focus on simplicity and understandability, which aligns with the user's goal of testing LLM coding skills. Although rCore is primarily designed for RISC-V, its adaptation to x86 makes it relevant to the user's project. Studying rCore's implementation of basic OS functionalities can provide a solid foundation for the user's own OS development. The project's extensive documentation and tutorial book make it an excellent learning resource. The project is geographically distant (China), but its technical relevance and educational focus outweigh geographical proximity.

## Summary

Based on the user's plan to develop a 64-bit x86 OS in Rust, focusing on a Linux-like but non-POSIX-compliant monolithic kernel, memory management, process scheduler, shell, utilities, and basic drivers, here are three reference projects. These projects were selected based on their relevance to the user's objectives, technology stack (Rust), and the challenges inherent in OS development.