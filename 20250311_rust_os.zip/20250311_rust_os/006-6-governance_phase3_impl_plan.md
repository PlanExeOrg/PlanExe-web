### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior Developer, Independent Technical Advisor, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Collate feedback on SteerCo ToR and revise to create version 0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback from nominated members

### 4. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2

### 5. Project Sponsor formally appoints the Project Steering Committee members (Senior Developer, Independent Technical Advisor, Community Representative).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- SteerCo Membership List

**Dependencies:**

- Approved SteerCo ToR v1.0
- Identification of SteerCo members

### 6. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- SteerCo Membership List
- Approved SteerCo ToR v1.0

### 7. Hold the initial Project Steering Committee kick-off meeting to review ToR, project plan, and initial priorities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation
- Approved SteerCo ToR v1.0
- Project Plan Approved

### 8. Project Manager drafts initial Terms of Reference (ToR) for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1

**Dependencies:**

- Project Plan Approved

### 9. Circulate Draft Core Team ToR for review by nominated members (Senior Developer, LLM, Junior Developer (if applicable)).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Team ToR v0.1 circulated for review

**Dependencies:**

- Draft Core Team ToR v0.1
- Nominated Members List Available

### 10. Collate feedback on Core Team ToR and revise to create version 0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft Core Team ToR v0.2

**Dependencies:**

- Draft Core Team ToR v0.1 circulated for review
- Feedback from nominated members

### 11. Project Steering Committee approves the Core Project Team Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Core Team ToR v1.0

**Dependencies:**

- Draft Core Team ToR v0.2
- SteerCo Kick-off Meeting Minutes

### 12. Project Sponsor formally appoints the Core Project Team members (Senior Developer, LLM, Junior Developer (if applicable)).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- Core Team Membership List

**Dependencies:**

- Approved Core Team ToR v1.0
- Identification of Core Team members

### 13. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Core Team Kick-off Meeting Invitation

**Dependencies:**

- Core Team Membership List
- Approved Core Team ToR v1.0

### 14. Hold the initial Core Project Team kick-off meeting to review ToR, project plan, and assign initial tasks.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Core Team Kick-off Meeting Invitation
- Approved Core Team ToR v1.0
- Project Plan Approved

### 15. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 16. Circulate Draft TAG ToR for review by nominated members (Independent Security Expert, Experienced Rust Developer, Senior Developer).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1 circulated for review

**Dependencies:**

- Draft TAG ToR v0.1
- Nominated Members List Available

### 17. Collate feedback on TAG ToR and revise to create version 0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft TAG ToR v0.2

**Dependencies:**

- Draft TAG ToR v0.1 circulated for review
- Feedback from nominated members

### 18. Project Steering Committee approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0

**Dependencies:**

- Draft TAG ToR v0.2
- SteerCo Kick-off Meeting Minutes

### 19. Project Sponsor formally appoints the Technical Advisory Group members (Independent Security Expert, Experienced Rust Developer, Senior Developer).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- TAG Membership List

**Dependencies:**

- Approved TAG ToR v1.0
- Identification of TAG members

### 20. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Invitation

**Dependencies:**

- TAG Membership List
- Approved TAG ToR v1.0

### 21. Hold the initial Technical Advisory Group kick-off meeting to review ToR, project plan, and define initial priorities.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Kick-off Meeting Invitation
- Approved TAG ToR v1.0
- Project Plan Approved

### 22. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Plan Approved

### 23. Circulate Draft ECC ToR for review by nominated members (Legal Counsel, Data Privacy Officer, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1 circulated for review

**Dependencies:**

- Draft ECC ToR v0.1
- Nominated Members List Available

### 24. Collate feedback on ECC ToR and revise to create version 0.2.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft ECC ToR v0.2

**Dependencies:**

- Draft ECC ToR v0.1 circulated for review
- Feedback from nominated members

### 25. Project Steering Committee approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved ECC ToR v1.0

**Dependencies:**

- Draft ECC ToR v0.2
- SteerCo Kick-off Meeting Minutes

### 26. Project Sponsor formally appoints the Ethics & Compliance Committee members (Legal Counsel, Data Privacy Officer, Community Representative).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails
- ECC Membership List

**Dependencies:**

- Approved ECC ToR v1.0
- Identification of ECC members

### 27. Project Manager schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- ECC Kick-off Meeting Invitation

**Dependencies:**

- ECC Membership List
- Approved ECC ToR v1.0

### 28. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR, project plan, and define initial priorities.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- ECC Kick-off Meeting Invitation
- Approved ECC ToR v1.0
- Project Plan Approved