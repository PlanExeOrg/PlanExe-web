**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** This is a request for a complex software project, but it is high-level and does not request specific code or instructions that would be harmful.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |