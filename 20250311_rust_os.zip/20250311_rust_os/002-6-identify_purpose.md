**Purpose:** personal

**Purpose Detailed:** Personal hobby project for testing LLM coding skills through the development of a custom operating system.

**Topic:** Operating System Development in Rust