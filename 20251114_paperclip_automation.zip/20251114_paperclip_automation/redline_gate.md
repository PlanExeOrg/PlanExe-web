**Verdict:** 🟡 ALLOW WITH SAFETY FRAMING

**Rationale:** This is a detailed request for planning and sourcing industrial automation equipment; feedback must remain high-level by omitting specific machine models, vendor contacts, or precise engineering/control instructions.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |