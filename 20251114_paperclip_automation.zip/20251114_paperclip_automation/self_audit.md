Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a standard manufacturing and automation engineering project; its success depends on overcoming standard engineering challenges related to robotics, industrial control systems, materials handling, and software integration, none of which conflict with established laws of physics. The plan does not require creating energy from nothing, transmitting information faster than light, or employing any mechanism unsupported by physics.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of using used industrial hardware with modern software control without independent evidence at comparable scale, creating existential technical integration risk.

**Mitigation**: Legal Team: Finalize independent external audit verifying the combined technical/hardware compatibility and integration plan complexity by within 45 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan is driven by undefined strategic concepts like 'systematic agility' and 'standardized industrial control abstraction layer' lacking explicit MoA definition. The 'Builder' strategy itself is a concept lacking defined inputs, process, and quantified value hypotheses.

**Mitigation**: Project Owner: Produce a one-pager defining the mechanism-of-action, owner, and success metrics for 'systematic agility' within 21 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical second-order risks are minimized by insufficient planning; the plan lacks a dedicated spares strategy for the used bender (Review Issue 3), meaning potential downtime directly impacts feasibility, and the budget is tightly controlled against necessary expert intervention.

**Mitigation**: Financial Oversight & Contingency Planner: Finalize firm quote for 1-year critical spares/support contract for the used bender within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan critically omits any formalized approval/permit lead time matrix, violating condition (b) of the rubric. This is central to Phase 1 gating.

**Mitigation**: Regulatory Compliance & Site Readiness Coordinator: Deliver an authoritative permit lead time matrix mapping to the WBS by within 21 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources are not named; the plan only mentions a general budget range ($300k-$500k). Financing gates/covenants are entirely undefined, violating the condition for LOW status.

**Mitigation**: Financial Oversight & Contingency Planner: Draft and secure sign-off for a formal 12-month financing schedule listing committed capital by within 45 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a budget range ($300k-$500k) without citing any scale-appropriate benchmarks or vendor quotes, failing to provide the required per-area math or explicitly state contingency adequacy.

**Mitigation**: Procurement & Vendor Manager: Source and document cost benchmarks for similar industrial automation scopes (3 projects) to normalize cost/sq ft against the 4,000 sq ft stated area within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies almost exclusively on single-point estimates for critical projections like hardware costs (e.g., used bender $20k-$40k) and expertise funding ($50k middleware budget) without any scenario analysis, indicating optimism as required for HIGH level.

**Mitigation**: Automation Control Architect: Develop best/worst/base-case scenarios for the OPC UA middleware development cost, covering a +/- 30% variance, within 45 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan details that Decision 5 selects custom I/O translation via an interface board, while Decision 3 mandates OPC UA abstraction, representing a critical, mutually exclusive technical conflict that guarantees scope creep for the internal developer.

**Mitigation**: Automation Control Architect: Deliver signed technical resolution defining either OPC UA with controller replacement or pure custom I/O mapping by within 10 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical claims regarding the used wire bender's capabilities lack verifiable artifacts; Data Item 1 requires obtaining 'official vendor support/documentation for these protocols' before purchase commitment.

**Mitigation**: Industrial Procurement & Vendor Manager: Secure documented confirmation of supported fieldbus protocols for the chosen used bender within 14 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan establishes abstract goals like 'fully automated, end-to-end pilot paperclip production' but fails to define measurable qualities for the primary output, contradicting the SMART goal requirement.

**Mitigation**: Project Owner: Define SMART criteria for final parcel output, including a KPI for final parcel acceptance rate (e.g., 99.8% acceptance by carrier) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan implies Gold Plating by retaining a single internal developer focusing only on the REST API and carrier integration (Decision 2, Choice 2), while outsourcing all critical PLC/hardware bridging, which conflicts with the goal of building a standardized control abstraction layer.

**Mitigation**: Project Owner: Produce a one-page benefit case justifying internal focus solely on API vs. outsourcing PLC integration, complete with KPI and cost, within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Automation Control Architect' (Role 1) is the unicorn role. This expert must bridge legacy PLCs using OPC UA via custom middleware (Decisions 3/5), which is critical for decoupling the internal developer's API work from the high integration risk of the used bender. This specialized skill set is essential and likely difficult to secure internally.

**Mitigation**: Automation Control Architect: Conduct immediate market validation sourcing three comparable OPC UA middleware contractors and validate a binding cost estimate within 21 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a US location (Cleveland, OH) but the instruction requires naming controlling regimes/statutes, which are entirely unmapped, creating a potential showstopper.

**Mitigation**: Regulatory Compliance & Site Readiness Coordinator: Deliver a focused regulatory matrix naming Ohio Industrial Zoning Codes and necessary federal OSHA standards by within 45 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any explicit strategy addressing maintenance requirements, personnel dependency, or technology obsolescence for the crucial used wire bender post-commissioning; this gap threatens operational continuity after the pilot phase concludes.

**Mitigation**: Industrial Procurement & Vendor Manager: Secure firm quotes for 1-year extended support/spares contract for the used wire bender within 30 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies hard constraints (OSHA, Electrical Permits - Decision 12) but provides no evidence of written confirmation or defined fallback sites/thresholds for non-waivable approvals, increasing risk significantly.

**Mitigation**: Regulatory Compliance Coordinator: Secure written confirmation of Phase 1 site readiness feasibility from the third-party consultant by within 45 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of redundancy; the emphasis on using a single used machine and relying on one internal developer suggests no tested fallbacks for critical external dependencies.

**Mitigation**: Industrial Procurement & Vendor Manager: Obtain and validate two alternative supplier agreements for the primary wire bender component by within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the **Finance Department** (incentivized by budget adherence, choosing Decision 4, Choice 2: minimal expert budget) conflicts with the **Internal Software Developer** (incentivized by system stability, needing Decision 4, Choice 1: maximum expert budget).

**Mitigation**: Financial Oversight & Contingency Planner: Define an OKR linking $50K of expert funding to achieving <10 machine fault incidents during Phase 4 stabilization within 90 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly lacks a feedback loop: KPIs are not defined (Expert 1, 1.4.A), cadence/owners are missing, and change control thresholds are absent despite high integration risk.

**Mitigation**: Project Owner: Establish a monthly review cadence, define three system stability KPIs, assign owners from the Roles list, and document change control thresholds within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits multiple strongly coupled High risks (e.g., FM3: Used machine integration failure immediately impacts FM5: Middleware cost/scope, FM8: Documentation lack, and FM2: Developer bottleneck). The cascade from A3/FM3 is existential.

**Mitigation**: Project Owner: Schedule a mandatory risk cascade review meeting with Controls Architect and Financial Planner to define combined NO-GO thresholds for technical integration vs. budget flexibility within 14 days.