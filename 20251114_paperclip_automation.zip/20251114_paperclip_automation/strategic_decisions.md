## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers center on de-risking the core software-hardware integration (Critical Levers #862 & #57) and securing the budget to execute this integration (Critical Lever #b034). The High Levers (#d608, #accdc96a, #845b) connect this foundation to the timeline via expertise allocation, the demonstration feasibility via low exception scope, and latency through infrastructure choice. Together, these address the fundamental tension between leveraging low-cost, used industrial hardware and achieving modern, latency-sensitive automation goals.

### Decision 1: Wire Bending Equipment Commissioning Strategy
**Lever ID:** `862ed52f-69f5-436c-82d7-f087d981761f`

**The Core Decision:** This strategy dictates the complexity of integrating the core production machine with the control software. Prioritizing modern PLC interfacing minimizes custom driver development, offering higher upfront cost but reducing Phase 4 software risk. Success is measured by the stability and speed of I/O communication established, ideally requiring minimal on-site tuning post-delivery.

**Why It Matters:** Prioritizing the acquisition of a used wire bender with guaranteed modern PLC interfacing drastically simplifies control integration but may consume a larger share of the machinery budget. If the chosen machine requires extensive custom sensor retrofitting to signal step completion, the software development timeline will extend significantly due to low-level driver development, straining the budget dedicated to outbound automation.

**Strategic Choices:**

1. Select a well-documented, higher-cost used bender that offers pre-existing industrial fieldbus or robust serial communication ports for seamless backend control integration.
2. Acquire the cheapest functional used bender available, allocating internal software development resources to engineer custom sensor arrays and interface logic to bridge communication gaps.
3. Negotiate a phased acquisition where the seller provides on-site expert tuning services for two weeks post-installation to stabilize cycle timing before contractor withdrawal.

**Trade-Off / Risk:** Focusing solely on the machine's I/O capabilities trades integration complexity for upfront hardware cost, requiring a careful assessment of whether retained software engineering time offsets the specialist commissioning expense.

**Strategic Connections:**

**Synergy:** This synergy directly enables PLC and Control Abstraction Layer by providing a known communication standard, minimizing low-level debugging efforts.

**Conflict:** Over-investing here constrains Budget Allocation for Expert Commissioning if the higher-cost bender choice reduces remaining funds for specialized tuning support.

**Justification:** *Critical*, This lever controls the fundamental integration risk between used hardware and custom software (Phase 2/4). Choosing modern I/O radically simplifies Software Expertise and Abstraction Layer choices, making it central to overall timeline certainty.

### Decision 2: Software Expertise Allocation
**Lever ID:** `d60856b4-2696-48cd-96ab-fbdd89165360`

**The Core Decision:** This controls the division of labor between internal development and external specialists for control logic. Outsourcing hardware interface (PLC) ensures speed, but maintaining internal focus allows for rapid iteration on the business API. Success is tracked by the time taken from machine installation to verified API command execution in Phase 4.

**Why It Matters:** Immediately outsourcing the PLC/hardware interface layer to external specialists ensures rapid machine control activation, allowing the internal developer to focus purely on the business logic API and front-end dashboard. Conversely, forcing internal implementation of machine control risks significant schedule slippage, as debugging undocumented industrial protocols often consumes time without guaranteed resolution within the current budgetary margin.

**Strategic Choices:**

1. Retain outside consultants exclusively for writing and validating the initial control code that bridges the backend API to the wire former and packer PLCs.
2. Dedicate the internal software developer entirely to the REST API, order queue management, and carrier integration, accepting that custom hardware integration will require substantial research time.
3. Bundle the software development contract to include guaranteed response times for emergency integration fixes during the first month post-Phase 6 completion.

**Trade-Off / Risk:** Outsourcing critical PLC integration accelerates project timeline certainty but significantly increases fixed costs, potentially consuming the buffer needed for unforeseen equipment integration failures further downstream.

**Strategic Connections:**

**Synergy:** Outsourcing hardware interfacing frees the internal developer to accelerate Backend Infrastructure Residency and API development for order processing.

**Conflict:** Outsourcing PLC work significantly impacts the Budget Allocation for Expert Commissioning, potentially straining funds intended for final system tuning and integration support.

**Justification:** *High*, This dictates the speed and success of Phase 4. Outsourcing the PLC integration resolves the greatest technical unknown (low-level machine control) quickly, directly enabling the internal API development for the broader automated flow.

### Decision 3: Control System Protocol Selection
**Lever ID:** `299cce51-4c4e-4a13-8438-343635b14f84`

**The Core Decision:** This lever governs the communication standard chosen between the custom software backend (Phase 4) and the physical machine controllers. The choice dictates coupling; robust protocols like OPC UA offer abstraction but risk latency, while low-level protocols like Modbus increase dependency on specific hardware interfaces. Success is measured by reliable, low-latency data exchange supporting both status reporting and command execution across all integrated physical assets.

**Why It Matters:** The choice of communication protocol between the custom backend (Phase 4) and the existing machine PLCs affects both development time and long-term maintainability. Opting for a high-level, standardized protocol like OPC UA may abstract hardware specifics but introduces latency and dependency on stable networking infrastructure not typically native to older machines. Conversely, relying solely on proprietary Modbus RTU requires deep, custom integration per machine, complicating future hardware swaps.

**Strategic Choices:**

1. Mandate that all new equipment purchases include modern networking hardware capable of supporting MQTT over TCP/IP for lightweight, state-driven messaging from the controller.
2. Develop a middleware abstraction layer utilizing OPC UA as the standardized language, requiring vendor translation layers for any legacy equipment using serial protocols.
3. Force all machine control integration down to the lowest common denominator physical layer, using discrete Digital I/O signals mapped directly by the primary process control server.

**Trade-Off / Risk:** Mandating MQTT simplifies software integration and monitoring but risks exceeding the limited computational budget of potentially old PLCs, potentially requiring expensive control board upgrades.

**Strategic Connections:**

**Synergy:** It strongly synergizes with PLC and Control Abstraction Layer by defining the exact language used within that abstraction, enabling seamless data mapping.

**Conflict:** It conflicts with Backend Infrastructure Residency, as high-level protocols like OPC UA may place higher demands on the server hardware hosting the backend services.

**Justification:** *Critical*, This lever forms the lingua franca for the entire control environment. A poor choice here forces brittle, custom code across all machines, directly undermining the desired stability required for the 2-hour manual intervention limit.

### Decision 4: Budget Allocation for Expert Commissioning
**Lever ID:** `b0342067-b426-4209-8d39-c37ea9a51cd7`

**The Core Decision:** This lever manages the trade-off between purchasing a more reliable (and potentially more expensive) used wire former versus investing accumulated capital reserves into high-cost, on-site integration specialists. The goal is balancing initial CAPEX against the risk of commissioning delays associated with older, less-documented industrial equipment in Phase 2.

**Why It Matters:** Given the tight budget and the uncertainty surrounding a used wire bender, the level of available expertise for commissioning directly trades against acquisition cost. Spending less on the used machine forces a larger portion of the budget toward expert integration and tuning, which may result in lower initial CAPEX but higher reliance on external, non-scalable knowledge. Conversely, overspending on the machine to guarantee better documentation limits funds for the critical software-hardware interface development.

**Strategic Choices:**

1. Allocate the maximum feasible portion of the budget reserve—up to one-third of the remaining capital—specifically for temporary, on-site PLC/controls experts during the 4-week commissioning window.
2. Restrict expert engagement only to remote consultation for troubleshooting PLC logic, thus funneling the majority of that reserve capital into purchasing a newer, better-documented used wire former.
3. Engage a single, multi-disciplinary integration firm to handle Phases 2, 3, and 5 mechanics and software integration under one fixed-price contract, absorbing all scheduling uncertainty internally.

**Trade-Off / Risk:** Allocating maximum reserves to on-site experts stabilizes the unreliable used machinery commissioning phase but drastically increases the risk of budget overruns if the expected 2-week tuning period extends beyond the allotted time.

**Strategic Connections:**

**Synergy:** This lever's funding directly impacts the success of Wire Bending Equipment Commissioning Strategy, as adequate expert allocation mitigates risks associated with used machinery selection.

**Conflict:** Increasing the allocation here directly constrains the available capital for Physical Handoff Mechanism Definition, potentially forcing reliance on less capable, cheaper material handling components in later phases.

**Justification:** *Critical*, This lever directly controls the mitigation strategy for the greatest single CAPEX uncertainty: integrating the used wire bender. It manages the primary tension between hardware acquisition cost and integration risk, heavily influencing the success of levers 862ed52f and 57bd3f68.

### Decision 5: PLC and Control Abstraction Layer
**Lever ID:** `57bd3f68-ee66-4097-9e33-ba88fb30d39b`

**The Core Decision:** This defines whether the software layer (Phase 4) integrates with the existing proprietary controllers of the purchased machinery or replaces them with an open standard platform. Choosing open standards maximizes flexibility for future development and debugging; proprietariness risks hard dependencies on legacy systems. This choice dictates the complexity of the required abstraction layer for API communication.

**Why It Matters:** Deciding to use the existing, proprietary PLC on the used bender as the primary control point forces reliance on that vendor's specific I/O mapping and programming language, increasing the difficulty of custom software integration later. This constricts software flexibility, compelling the developer to write complex, brittle translation layers instead of straightforward fieldbus communication protocols.

**Strategic Choices:**

1. Replace the used machine's proprietary controller with a standard, open industrial PC or unified PLC platform to ensure consistent future debugging and API integration.
2. Directly interface the existing PLC via proprietary protocols, fully accepting the limitations and high customization cost imposed by the legacy hardware manufacturer's architecture.
3. Develop a custom hardware interface board that sits between the existing PLC and the new software backend, translating commands into simple electrical pulses to avoid deep PLC reprogramming.

**Trade-Off / Risk:** Relying on legacy PLC programming creates a hard dependency on obscure vendor knowledge, significantly escalating the risk that the $\le 2$ hours exception limit is breached during complex failure diagnostics.

**Strategic Connections:**

**Synergy:** Directly enables Software Expertise Allocation by providing a standard framework, simplifying the ability of the developer to interface with hardware controls via the Control System Protocol Selection.

**Conflict:** Constrains Control System Protocol Selection; utilizing proprietary PLCs forces the project away from using open industrial standards, risking integration friction with custom software.

**Justification:** *Critical*, This decision forces the structural approach for all software integration across all machines. Replacing legacy controllers ensures the long-term stability and flexibility required to meet the stringent automation goals, making it foundational infrastructure.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Material Handling Contingency Scope
**Lever ID:** `72210782-2538-4b03-bfb5-5650ac3e1171`

**The Core Decision:** This lever determines the complexity of the material movement post-packing. Simplifying scope to fixed drop-offs reduces mechanical integration risk and immediate costs associated with conveyors. Success hinges on carrier acceptance of un-conveyed, staged goods, directly impacting final demonstrability in Phase 6.

**Why It Matters:** Reducing the scope of material handling from complex, automated conveyance to simple fixed-station drop-offs minimizes mechanical integration risk, potentially allowing the project to finish with only gravity feeding the final staging area. However, this forces the system to rely on pre-sized, fixed mailers only, eliminating flexibility for handling variable order sizes or specialized packaging configurations later on.

**Strategic Choices:**

1. Design the packaging cell to directly deposit sealed bags onto a fixed pallet or staging table, relying on the carrier to perform the final manual transfer from the staging zone.
2. Implement a comprehensive conveyor network using standardized, off-the-shelf components to transport parcels from labeling directly to a designated three-pallet pickup zone.
3. Employ robotic pick-and-place augmentation solely for the insertion step, offloading the most complex mechanical task from the primary packing machine's output.

**Trade-Off / Risk:** Simplifying material handling reduces integration risk and cost, but relying on fixed staging stations creates a hard dependency on the carrier's acceptance protocol for high-volume, unpalletized loads.

**Strategic Connections:**

**Synergy:** A reduced scope synergizes with Material Handling Contingency Scope by simplifying the physical deployment, which lessens dependency on Transport and Installation services.

**Conflict:** Simplifying staging conflicts with Shipping Manifest Strategy if the final carrier integration requires sequential tracking or direct scanning from a dynamically presented conveyor exit.

**Justification:** *Medium*, Simplifying material handling reduces mechanical integration risks in Phase 5. However, since the goal is end-to-end flow demonstration, this is secondary to the reliability of the core production and software links.

### Decision 7: Building Infrastructure Modification Pace
**Lever ID:** `9463cad3-3d1a-46d3-ada4-50c9f5d57482`

**The Core Decision:** This governs the sequencing of physical preparation versus equipment procurement. Aggressive overlapping accelerates the timeline by starting permitting early but increases renovation rework risk if final machine footprints or power needs differ. Success is measured by the elapsed time between project start and physical readiness for equipment rigging.

**Why It Matters:** Executing necessary electrical upgrades and obtaining required safety permits concurrently with the equipment selection phase streamlines the overall schedule by overlapping planning and execution. However, securing permits based on preliminary machinery specifications risks costly rework if the final, confirmed equipment requires a different power draw or specialized ventilation setup later on.

**Strategic Choices:**

1. Complete all requisite electrical upgrades, safety audits, and final floor layout planning before any machinery order is placed, ensuring zero delays upon equipment delivery.
2. Begin ordering readily available components (like standard conveyors or staging tables) immediately while simultaneously submitting interim permit applications based on rough equipment dimensions.
3. Limit initial infrastructure preparation to only the main 3-phase connection, deferring specific machine mounting and isolation requirements until the physical equipment is rigged in place.

**Trade-Off / Risk:** Overlapping infrastructure planning with procurement accelerates the overall timeline, but using preliminary specifications for permits introduces the significant risk of needing expensive, disruptive on-site electrical modifications later.

**Strategic Connections:**

**Synergy:** Accelerating this pace allows earlier engagement with Regulatory Compliance Gate Management, facilitating quicker approval for the necessary electrical and safety preparations.

**Conflict:** Rushing infrastructure planning based on preliminary data conflicts with Budget Allocation for Expert Commissioning by potentially requiring expensive change orders mid-installation.

**Justification:** *Medium*, This governs the initial schedule (Phase 1) and risk of rework. While important for timeline, it is less central to the core *automation* demonstration than the machine-software interface conflicts.

### Decision 8: Physical Handoff Mechanism Definition
**Lever ID:** `e3e96383-f580-4a87-a0a3-8b713651c00a`

**The Core Decision:** This strategy defines the mechanical coupling between the primary production step (forming) and the secondary packaging step. Choosing a buffered solution adds mechanical complexity but isolates cycle time variation, crucial for the continuous operation goal. Success metrics involve material flow rate stability across the interface, noted during Phase 3 review.

**Why It Matters:** Defining the precise physical means (e.g., precise chute angle, indexing mechanism, conveyor speed) of transferring formed wire to the packer hopper dictates the mechanical complexity and tolerance stack-up between Phase 2 and Phase 3. If the interface relies on a generic bin/pallet exchange, flexibility is gained, but the required tuning for continuous flow and error recovery increases dramatically versus a fixed, direct conveyor link.

**Strategic Choices:**

1. Standardize the transfer interface between the wire former and the packing machine using a vibration-feed system tuned precisely to the expected wire output rate and geometry.
2. Design a buffered accumulation station, allowing the wire former to finish a full batch run before the packer begins processing, isolating mechanical failures between cells.
3. Implement a direct, fixed-tolerance gravity chute that pushes formed parts directly into the packer’s sorting mechanism, prioritizing small footprint over immediate buffering capability.

**Trade-Off / Risk:** Defining the handoff via a vibratory feeder reduces integration complexity upstream but requires precise frequency control and risks material jamming if wire quality varies, demanding extensive Phase 2 tuning.

**Strategic Connections:**

**Synergy:** Defining the handoff via a buffered station directly supports the goal of Material Handling Contingency Scope by reducing the immediate need for high-speed, continuous conveyance.

**Conflict:** Implementing complex buffering mechanisms increases the load on the Wire Bending Equipment Commissioning Strategy, as this strategy must now tune output to constantly feed the buffer.

**Justification:** *High*, This controls the highest-risk mechanical coupling between Phase 2 and Phase 3. A poor choice here guarantees continuous flow failure, putting direct pressure on Exception Handling Scope and Commissioning Budget to resolve chronic jamming.

### Decision 9: Exception Handling and Manual Intervention Scope
**Lever ID:** `accdc96a-395a-4a04-9091-c885ddc41d54`

**The Core Decision:** This controls the project's tolerance for human intervention, setting the engineering bar for automated fault recovery. A strict limit forces complex, proactive autonomous correction routines, increasing initial software costs. The goal is to maintain the automated flow state while keeping documented manual work below two hours per week when exceptions inevitably arise.

**Why It Matters:** Strictly limiting the acceptable manual intervention window to two hours per week forces aggressive design choices focused solely on automated recovery rather than manual workaround speed. This increases the initial engineering cost of developing sophisticated error sensing and self-correction routines. If a complex, rare jam occurs, the system might stop entirely, pending deep developer debugging, rather than allowing a quick human intervention to restore flow immediately.

**Strategic Choices:**

1. Design exception modes entirely around sensor feedback, automatically cycling power or reversing conveyance logic a fixed number of times before locking into a safe, observable fault state.
2. Pre-stage standardized, common spare parts for conveyance joints and simple mechanical components near the line, allowing for rapid (under 5-minute) swap-outs by a non-expert if faults are identified.
3. Prioritize operator notification via the dashboard for specific, high-frequency errors (e.g., miscounts, packaging seal failures) to guide remote developer troubleshooting rather than implementing autonomous fixes.

**Trade-Off / Risk:** Pre-staging spare parts allows for rapid physical recovery from mechanical failures but adds unbudgeted inventory costs and the logistical overhead associated with managing a parts crib.

**Strategic Connections:**

**Synergy:** This lever directly enables the feasibility of the Control System Protocol Selection by determining how aggressively the control layer must sense and react to faults without human input.

**Conflict:** It is in direct conflict with Exception Handling and Manual Intervention Scope, as increasing automation complexity here reduces available budget and time for developing robust software workarounds if mechanical issues arise.

**Justification:** *High*, As project success is defined by achieving automation (with $\le 2$ hr manual work), this lever sets the target performance level for the automation. It forces difficult trade-offs in complexity vs. speed of recovery.

### Decision 10: Parcel Insertion and Sealing Modality
**Lever ID:** `2a7a3785-ee61-4e70-8e58-de60698b2bd2`

**The Core Decision:** This defines the final packaging system for the 100-count bags, impacting machine complexity, material cost, and handling requirements during Phase 5. The choice between soft mailers and rigid boxes fundamentally determines the required mechanisms for insertion, sealing, and presentation. Success hinges on consistent, automated parcel creation that meets carrier dimensional requirements without jamming.

**Why It Matters:** The transition from the 100-count bag output to the final sealed shipping container (Phase 5) represents a significant mechanical integration challenge. Choosing soft mailers versus rigid boxes dictates the complexity of the insertion and sealing equipment necessary. Mailers require complex folding/tuck mechanisms or specialized heat sealing, whereas rigid boxes necessitate a secondary robotic arm or a vacuum pick-and-place unit for insertion.

**Strategic Choices:**

1. Commit to utilizing pressure-sensitive padded paper mailers exclusively, requiring a high-precision vacuum gripper to present the mailer aperture for the bag drop and specialized heat-sealing equipment.
2. Design the system to populate custom-sized corrugated cardboard boxes, necessitating the integration of a separate box erecting/closing mechanism upstream of the labeling.
3. Employ an intermediate step where paperclip bags are nested onto pre-formed cardboard trays using minimal conveyance before being sealed into standardized, off-the-shelf large bubble mailers.

**Trade-Off / Risk:** Committing to padded paper mailers simplifies the required package material structure but introduces the high mechanical precision challenge of heat-sealing soft plastic bags into the mailer.

**Strategic Connections:**

**Synergy:** It creates a strong dependency for the Material Handling Contingency Scope, as the rigidity of the chosen container dictates how flexible conveyance must be to manage the varying parcel sizes.

**Conflict:** It places immediate pressure on the Budget Allocation for Expert Commissioning, as specialized sealing or box-handling equipment requires highly specific integration expertise, consuming capital.

**Justification:** *Medium*, Governs Phase 5 complexity. While a challenge, it is mechanically separable from the core value proposition (forming + packing + API control) and has a clearer set of established industrial solutions than the upstream control layers.

### Decision 11: Shipping Manifest Strategy
**Lever ID:** `00732001-eee9-48ae-be03-d825f14e194b`

**The Core Decision:** This strategy governs how the system fulfills Phase 6 requirements concerning label creation and shipment recording with UPS/FedEx. It trades off real-time label fidelity against the inherent risk of API dependency and network latency during the final staging step. Optimal selection minimizes integration complexity while ensuring legal manifests are created only for staged parcels.

**Why It Matters:** The method chosen for interacting with carrier APIs determines the complexity and reliability of the final handoff (Phase 6). Using UPS/FedEx's full-service label generation and manifesting APIs requires complex, real-time data synchronization for every parcel generated, failing spectacularly if the internet link drops for an hour. A simpler strategy relies on pre-purchasing a block of labels, reducing integration complexity but losing fine-grained cost control and potentially staging unnecessary volume if orders delay.

**Strategic Choices:**

1. Implement the UPS/FedEx API integration to generate and print labels one-for-one immediately before physical presentation to the carrier pickup zone, ensuring zero label waste.
2. Use a third-party shipping consolidator's API service instead of direct carrier integration, trading a small per-shipment fee for a simplified, standardized interface abstraction.
3. Pre-purchase a rolling inventory of generic, high-volume shipping labels from the carrier based on historical weekly estimates, printing them only when the parcel is mechanically ready.

**Trade-Off / Risk:** Pre-purchasing labels simplifies the real-time API dependency but introduces a working capital constraint and inventory risk if the actual volume or destination mapping deviates significantly from estimates.

**Strategic Connections:**

**Synergy:** It is critical for triggering the final successful step in the End-to-End demo, relying on the Backend Infrastructure Residency to manage the necessary API interactions.

**Conflict:** If the strategy mandates one-for-one label generation, it introduces technical friction with Exception Handling and Manual Intervention Scope, as any halted line immediately stops shipping documentation.

**Justification:** *Medium*, This completes the demonstration flow (Phase 6). While necessary, the integration complexity (API calls) is less foundational than the low-level machine control synchronization established by the Critical and High levers.

### Decision 12: Regulatory Compliance Gate Management
**Lever ID:** `4118c9ae-6bf0-4b88-9ec9-df4a024703e0`

**The Core Decision:** This lever manages acquiring necessary permits and ensuring site readiness (Phase 1), specifically focusing on electrical and safety compliance before heavy equipment rigging begins. Success is measured by avoiding construction delays and not exceeding the budget on unforeseen facility upgrades. Expediting third-party pre-inspections is a key tactic to de-risk downstream Phase 2 scheduling by preemptively addressing physical layout feasibility.

**Why It Matters:** Addressing mandatory safety and electrical permitting (Phase 1) upfront guarantees a clean site readiness for equipment rigging during Phase 2. If permitting processes are delayed or require unexpected facility upgrades (e.g., panel capacity increases), the entire equipment installation schedule stalls.
This constraint forces a capital allocation decision: pay for expedited inspection services now or risk paying for delayed rigging demurrage later.

**Strategic Choices:**

1. Engage a third-party safety consultant immediately to conduct a pre-inspection walk-through focused solely on electrical service and layout feasibility, obtaining sign-off before any equipment is moved onsite.
2. De-scope non-essential facility modifications identified in Phase 1, deferring all non-critical OSHA compliance items until the production proof-of-concept is technically validated in Phase 6.
3. Schedule all necessary electrical utility upgrades and permit submissions concurrently with the purchase and transit scheduling of the wire bending machine to overlap preparation activities.

**Trade-Off / Risk:** Expediting consultant sign-off ensures Phase 2 starts on time, but if the consultant identifies costly building electrical remediations, the pilot budget may be exhausted before any machinery commissioning begins.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Building Infrastructure Modification Pace by ensuring construction readiness is achieved early, minimizing delays during equipment rigging schedules.

**Conflict:** Conflicts with Budget Allocation for Expert Commissioning; paying for rapid compliance reviews or extensive facility remediation directly drains capital from later stages like machinery commissioning.

**Justification:** *Low*, This is a necessary prerequisite (Phase 1) but primarily tactical. Its successful resolution unlocks Phase 2 but does not define the nature or success criteria of the subsequent automation integration.

### Decision 13: Wire Stock Qualification Protocol
**Lever ID:** `0dab442b-e23e-4d8b-b7c8-495683ebdbb3`

**The Core Decision:** This protocol determines the quality grade of the raw wire material supplied to the bender. Sourcing lower-quality stock demands substantially more rigorous commissioning effort on the used bending machine to manage tolerance and curvature variance reliably. Success is defined by the stability achieved post-tuning, directly impacting the reliability of the downstream counting procedures in Phase 3.

**Why It Matters:** Choosing to use minimally pre-processed, standard construction-grade wire requires the wire-forming machine's commissioning to absorb high variability correction, potentially demanding significant, costly custom PLC programming and extended tuning cycles. Downstream, this increased variance at the source will stress the packing machine's counting mechanism, possibly requiring mid-phase retrofits to improve counting sensor reliability.

**Strategic Choices:**

1. Source only pre-cut, pre-straightened wire stock sourced from a dedicated supplier, prioritizing input quality over budgetary cost savings in material acquisition.
2. Source minimum-spec, raw industrial wire reels, accepting that the wire bending machine must handle all initial straightening and tolerance management internally.
3. Implement an intermediate, low-cost, belt-driven roller mechanism before the former to mechanically remove gross curvature from the raw stock as a low-tech preprocessing step.

**Trade-Off / Risk:** Sourcing minimum-spec wire shifts complexity upstream to the forming machine's tuning, potentially causing unforeseen instability and extending the debugging timeline deep into the budget envelope.

**Strategic Connections:**

**Synergy:** Amplifies Wire Bending Equipment Commissioning Strategy by dictating the input quality and complexity the tuning process must successfully compensate for during setup.

**Conflict:** Trades off against Budget Allocation for Expert Commissioning; using cheaper wire increases complexity, potentially requiring more costly, expert-driven tuning time or material testing.

**Justification:** *Low*, This manages input variance. While it impacts commissioning time, it is subordinate to the *Commissioning Strategy* itself (862ed52f). Sourcing better wire only offsets a symptom of weak commissioning ability.

### Decision 14: Backend Infrastructure Residency
**Lever ID:** `845b79ea-a983-4a0e-bfa9-54cea9653089`

**The Core Decision:** This determines the physical location of the core API, job queue, and monitoring services—on-premise within the 4,000 sq ft line or hosted externally. Local hosting prioritizes low-latency communication crucial for robotics control but necessitates managing physical server hardware. Success is judged by minimal network delay between software checks and machine responses during live operation.

**Why It Matters:** Hosting the monitoring, API, and job queue entirely on local hardware within the 4,000 sq ft pilot space guarantees minimal network latency for critical control loops, satisfying the need for responsive machine communication. However, this mandates purchasing, configuring, and maintaining dedicated local server hardware, adding an unbudgeted capital expenditure outside the stated equipment list.

**Strategic Choices:**

1. Deploy all required backend services and databases on robust, on-premise industrial edge compute hardware situated immediately adjacent to the production line.
2. Host all API services, job queues, and status monitoring in a standard cloud environment, utilizing external internet connectivity for all machine status reporting and order ingestion.
3. Develop a hybrid model where high-frequency machine state updates are logged locally but order creation and API ingress are handled exclusively by a public cloud instance.

**Trade-Off / Risk:** Keeping control logic strictly local optimizes latency for machine-to-software communication but introduces new capital costs and responsibilities for local physical server maintenance and hardening.

**Strategic Connections:**

**Synergy:** Synergizes with PLC and Control Abstraction Layer by providing the most direct, lowest-latency physical pathway for the control software to interact with the immediate machine controllers.

**Conflict:** Conflicts with Budget Allocation for Expert Commissioning; maintaining on-premise edge compute introduces unforeseen costs related to hardware procurement, rack space, and ensuring local physical maintenance capability.

**Justification:** *High*, Local hosting optimizes latency, which is crucial for reliable synchronization between the software job queue and physical machine execution (Phase 4). This directly supports achieving the required low-error automation necessary for the $\le 2$ hr exception goal.
