Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the project aims to automate an existing process, not to violate any physical laws. The goal is to improve efficiency and reduce labor costs, which are economic and engineering challenges, not physics problems. No quotes apply.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of legacy equipment, custom software, and complete autonomy without independent evidence at comparable scale. The plan states, "the specific combination of legacy equipment, custom software, and complete autonomy presents integration challenges."

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 2026-06-30


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions with business-level mechanism-of-action, owners, and measurable outcomes for strategic concepts. The plan mentions "end-to-end autonomous flow" as a goal, but this is not clearly defined or quantified.

**Mitigation**: Project Manager: Produce one-pagers for each strategic concept (e.g., 'end-to-end autonomous flow') with value hypotheses, success metrics, and decision hooks by 2026-04-26.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (technical, financial, operational, etc.) and proposes mitigation strategies. However, the mitigation plans are often vague (e.g., "Implement safety protocols") and lack explicit analysis of second-order effects or cascade failures. The plan lacks a register covering hazards with owners/controls.

**Mitigation**: Project Manager: Expand the risk register to include second-order risks and cascade effects, assigning owners and controls with a dated review cadence by 2026-05-10.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a permit/approval matrix. The plan mentions "Obtain building/electrical/OSHA permits" but lacks a detailed breakdown of required permits, lead times, and dependencies. The plan states "Research permit requirements for Cleveland".

**Mitigation**: Permitting and Compliance Coordinator: Create a permit/approval matrix with required permits, lead times, dependencies, and responsible parties by 2026-04-26.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not specify funding sources, their status, draw schedule, or covenants. The plan mentions a "budget of $300,000-$500,000" but lacks details on how this funding will be secured and managed.

**Mitigation**: Project Manager: Create a dated financing plan listing funding sources, their status (e.g., LOI, term sheet, closed), draw schedule, and covenants by 2026-04-26.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $300,000-$500,000 lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions "a budget of $300,000-$500,000" but provides no supporting cost data.

**Mitigation**: Project Manager: Obtain ≥3 vendor quotes for major equipment (wire bender, packaging machine, conveyor), normalize costs per sq ft, and adjust budget or de-scope by 2026-05-03.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., budget, timeline) as single numbers without providing a range or discussing alternative scenarios. The plan states a "budget of $300,000-$500,000" and a timeline of "6-9 months" without sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the budget and timeline projections by 2026-05-03.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions engineering artifacts but lacks specifics. The plan states "Implement basic I/O or PLC integration for the wire bending machine" but does not include specs, interface contracts, acceptance tests, or non-functional requirements.

**Mitigation**: Automation Engineer: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2026-05-10.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several claims without verifiable evidence. For example, it states, "Procure a fully refurbished wire bending machine from a reputable vendor, ensuring comprehensive warranty and support..." but lacks vendor names, warranty documents, or support agreements.

**Mitigation**: Project Manager: Obtain and document evidence (vendor contracts, warranty documents, support agreements) for all critical claims related to licenses, approvals, and partnerships by 2026-05-10.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "Functional automated paperclip factory pilot line" as a deliverable without specific, verifiable qualities. There are no SMART acceptance criteria or KPIs for the pilot line's performance.

**Mitigation**: Automation Engineer: Define SMART criteria for the pilot line, including a KPI for overall equipment effectiveness (OEE ≥ 80%) by 2026-04-26.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Parcel Presentation Method decision includes a fully automated conveyor system. While it ensures accuracy, its space requirements and integration complexity may be excessive for a pilot line. The core project goals are demonstrating autonomous flow and staying within budget.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the fully automated conveyor system, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2026-04-26.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Software Integration Engineer" to integrate the REST API, backend services, and frontend dashboard with machine controllers and carrier APIs. This role is critical and requires specialized expertise, making it difficult to fill.

**Mitigation**: Project Manager: Validate the talent market for a Software Integration Engineer with experience in REST APIs, backend services, and industrial automation by 2026-04-26.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies regulatory bodies (OSHA, Local Building Department) but lacks a regulatory matrix mapping authorities, artifacts, and lead times. The plan states "Apply for Building Permit" but does not specify the approval process or potential delays.

**Mitigation**: Permitting and Compliance Coordinator: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a fatal-flaw analysis for regulatory feasibility by 2026-04-26.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Long-term sustainability of the system should be considered" but lacks a concrete plan. There is no funding/resource strategy, maintenance schedule, succession planning, technology roadmap, or adaptation mechanisms.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms by 2026-05-17.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies locations but lacks evidence of zoning compliance, occupancy limits, or structural capacity. The plan states "Existing 15,000 sq ft building in this area of Cleveland" but lacks evidence of suitability.

**Mitigation**: Project Manager: Conduct a fatal-flaw screen with Cleveland authorities to confirm zoning/land-use, occupancy/egress, and structural limits by 2026-05-03.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies external dependencies (equipment vendors, UPS/FedEx) but lacks evidence of SLAs or tested failover plans. The plan states "Coordinate with UPS/FedEx for API integration and pickup schedules" but lacks details.

**Mitigation**: Project Manager: Secure SLAs with key vendors (equipment, wire feedstock, UPS/FedEx) including uptime guarantees and tested failover procedures by 2026-05-17.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated goals of the Project Manager (project completion within budget and timeline) and the Automation Engineer (achieving a high degree of automation) may conflict. The Project Manager may prioritize cost-cutting measures that compromise the level of automation.

**Mitigation**: Project Manager and Automation Engineer: Define a shared OKR focused on 'Achieving X% automation with Y budget and Z timeline' to align incentives by 2026-04-26.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board including thresholds (when to re-plan/stop) by 2026-05-10.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (financial overruns, operational reliability, technical challenges) but lacks a cross-impact analysis. A financial overrun could force the use of lower-quality materials, increasing operational risk.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2026-05-17.