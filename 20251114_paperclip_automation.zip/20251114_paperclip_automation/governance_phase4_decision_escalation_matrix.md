**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit for PMO decision-making.
Negative Consequences: Potential project delays due to budget constraints.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Requires strategic oversight and potential reallocation of resources.
Negative Consequences: Project failure or significant delays if not addressed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Consensus cannot be reached on critical vendor decisions.
Negative Consequences: Delays in procurement and project timeline.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant impact on project goals and budget.
Negative Consequences: Scope creep leading to budget overruns and timeline extensions.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review to ensure compliance with ethical standards.
Negative Consequences: Legal penalties and reputational damage if not addressed.