### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager circulates Draft SteerCo ToR for review by Project Sponsor, Senior Management Representative, and Independent External Advisor (Industrial Automation).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1 circulated for review

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on the Draft SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Consolidated Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1 circulated for review
- Feedback from Project Sponsor, Senior Management Representative, and Independent External Advisor

### 4. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2
- Consolidated Feedback Summary

### 5. Project Sponsor formally appoints the Chairperson of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Sponsor confirms the membership of the Project Steering Committee (Project Sponsor, Senior Management Representative, Independent External Advisor (Industrial Automation), Project Manager).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confirmed SteerCo Membership List

**Dependencies:**

- Appointment Confirmation Email

### 7. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Confirmed SteerCo Membership List

### 8. Hold the initial Project Steering Committee kick-off meeting to review project goals, governance structure, and initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 9. Project Manager defines roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**

- Project Plan Approved

### 10. Project Manager establishes communication channels and reporting procedures for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Communication Plan

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 11. Project Manager develops a detailed project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Detailed Project Schedule

**Dependencies:**

- Core Project Team Communication Plan

### 12. Project Manager sets up a project tracking system for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Tracking System Established

**Dependencies:**

- Detailed Project Schedule

### 13. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Kick-off Meeting Invitation

**Dependencies:**

- Project Tracking System Established

### 14. Hold the initial Core Project Team kick-off meeting to review project goals, roles, and schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Core Project Team Kick-off Meeting Invitation

### 15. Project Manager identifies and recruits qualified technical experts for the Technical Advisory Group (TAG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- List of TAG Candidates
- TAG Member Invitations

**Dependencies:**

- Project Plan Approved

### 16. Project Manager defines the scope of advisory services for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TAG Scope of Services Document

**Dependencies:**

- List of TAG Candidates

### 17. Project Manager establishes communication protocols for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TAG Communication Plan

**Dependencies:**

- TAG Scope of Services Document

### 18. Project Manager confirms the membership of the Technical Advisory Group (Senior Automation Engineer, Senior Mechanical Engineer, Senior Electrical Engineer, Independent External Technical Expert (Industrial Automation), Software Architect).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed TAG Membership List

**Dependencies:**

- TAG Member Invitations

### 19. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Invitation

**Dependencies:**

- Confirmed TAG Membership List

### 20. Hold the initial Technical Advisory Group kick-off meeting to review project goals, scope of services, and initial project designs and specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- TAG Kick-off Meeting Invitation

### 21. Legal Counsel develops a code of ethics and compliance policy for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft Code of Ethics and Compliance Policy

**Dependencies:**

- Project Plan Approved

### 22. Compliance Officer establishes reporting mechanisms for ethical violations for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Ethical Violation Reporting Mechanisms Document

**Dependencies:**

- Draft Code of Ethics and Compliance Policy

### 23. Compliance Officer conducts a risk assessment to identify potential compliance issues for the Ethics & Compliance Committee.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Compliance Risk Assessment Report

**Dependencies:**

- Ethical Violation Reporting Mechanisms Document

### 24. Legal Counsel develops a data privacy policy in accordance with GDPR for the Ethics & Compliance Committee.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Draft Data Privacy Policy

**Dependencies:**

- Compliance Risk Assessment Report

### 25. Senior Management Representative confirms the membership of the Ethics & Compliance Committee (Legal Counsel, Compliance Officer, Independent External Ethics Advisor, Senior Management Representative).

**Responsible Body/Role:** Senior Management Representative

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Draft Data Privacy Policy

### 26. Legal Counsel schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Legal Counsel

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Confirmed Ethics & Compliance Committee Membership List

### 27. Hold the initial Ethics & Compliance Committee kick-off meeting to review project goals, compliance policies, and data privacy measures.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation