This plan involves money.

## Currencies

- **USD:** The project is located in the United States.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.