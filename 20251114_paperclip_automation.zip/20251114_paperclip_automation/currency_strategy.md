This plan involves money.

## Currencies

- **USD:** The project is located entirely in Cleveland, Ohio, USA, and all major equipment purchases (used machinery, new packer) and services (rigging, consulting, utilities) will be sourced in US dollars.

**Primary currency:** USD

**Currency strategy:** Since the project is entirely based in a single, stable economy (USA), USD will be used for all budgeting, procurement, and financial reporting, eliminating foreign exchange risk.