### 1. Project Kickoff: Establish core project foundation and secure initial high-level mandate.

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Week 1 (Day 1)

**Key Outputs/Deliverables:**

- Project Charter Signed
- Initial Budget Approved
- Project Team Identified

**Dependencies:**

- Project Goal Statement Finalized

### 2. Phase 1 Commencement: Initiate Regulatory and Permitting Activities (Decision 12).

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Regulatory Consultant Contracted
- Permit Application Submissions Drafted

**Dependencies:**

- Project Kickoff

### 3. Draft Terms of Reference (ToR) for Project Steering Committee (SteerCo) and Project Management Office (PMO).

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1
- Draft PMO ToR v0.1

**Dependencies:**

- Project Kickoff

### 4. Nominate and confirm membership lists for Project Steering Committee and PMO.

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Confirmed SteerCo Member List
- Confirmed PMO Member List

**Dependencies:**

- Draft SteerCo ToR and PMO ToR Drafted

### 5. SteerCo and PMO Chairpersons elected/appointed based on respective ToRs.

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- SteerCo Chairperson Confirmed
- PMO Manager Confirmed

**Dependencies:**

- Confirmed SteerCo Member List
- Confirmed PMO Member List

### 6. Project Steering Committee formally approves final ToRs for SteerCo and PMO.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0
- Approved PMO ToR v1.0

**Dependencies:**

- SteerCo Chairperson Confirmed
- Draft SteerCo ToR and PMO ToR Drafted

### 7. Hold Project Steering Committee Initial Establishment Meeting (Kickoff Governance Setup).

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- SteerCo Kickoff Meeting Minutes
- Confirmed High-Level Project Schedule

**Dependencies:**

- Approved SteerCo ToR v1.0

### 8. Draft Terms of Reference (ToR) and define membership for Technical Advisory Group (TAG) and Ethics & Compliance Committee (ECC).

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1
- Draft ECC ToR v0.1
- Nominee Lists for TAG and ECC

**Dependencies:**

- Approved PMO ToR v1.0

### 9. Secure key external/independent experts needed for TAG and ECC membership (Controls Specialist, Industrial Automation Expert, Safety Consultant, Compliance Officer).

**Responsible Body/Role:** Project Owner

**Suggested Timeframe:** Project Weeks 3-5

**Key Outputs/Deliverables:**

- Signed Contracts for Key External Experts
- Finalized Member List for TAG and ECC

**Dependencies:**

- Nominee Lists for TAG and ECC

### 10. Project Steering Committee reviews and approves final ToRs and initial membership for TAG and ECC.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved TAG ToR v1.0
- Approved ECC ToR v1.0

**Dependencies:**

- Draft TAG ToR v0.1
- Draft ECC ToR v0.1
- Confirmed High-Level Project Schedule

### 11. PMO establishes project management tools and reporting structures based on PMO ToR.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Management Tool Suite Operationalized
- Initial Reporting Templates Defined

**Dependencies:**

- Approved PMO ToR v1.0

### 12. Hold Technical Advisory Group (TAG) Initial Establishment Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- TAG Kickoff Meeting Minutes
- Initial Technical Protocol Review Schedule

**Dependencies:**

- Approved TAG ToR v1.0

### 13. Hold Ethics & Compliance Committee (ECC) Initial Establishment Meeting to Define Initial Compliance Review Scope (Phase 1).

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- ECC Kickoff Meeting Minutes
- ECC Initial Mandate for Phase 1 Permit Review

**Dependencies:**

- Approved ECC ToR v1.0
- Regulatory Consultant Engaged

### 14. PMO aligns Phase 2 procurement strategy (Wire Bender selection based on Decision 1/4/5) with TAG technical guidance.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Final Wire Bender Specification Approved (PLC Interface Type Chosen)
- Procurement Strategy Finalized (Budget Allocation confirmed based on Decision 4)

**Dependencies:**

- TAG Kickoff Meeting Minutes
- Budget Allocation for Expert Commissioning Decision Context

### 15. Secure necessary operational permits and electrical sign-offs (Phase 1 Completion).

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 12 (Contingent on external factors)

**Key Outputs/Deliverables:**

- Final Building Permit Issued
- Electrical Service Upgrade Approved

**Dependencies:**

- ECC Initial Mandate for Phase 1 Permit Review
- Building Infrastructure Modification Pace Decision

### 16. Procure and Rig Wire Bending Machine (Start of Phase 2 execution).

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Weeks 10-14

**Key Outputs/Deliverables:**

- Wire Bender Delivered On-Site
- Wire Bender Mechanically Secured

**Dependencies:**

- Final Wire Bender Specification Approved
- Final Building Permit Issued

### 17. Execute initial commissioning, focusing on Control System Protocol Selection (Decision 3) and PLC Abstraction Layer (Decision 5) via external specialists.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Weeks 15-18

**Key Outputs/Deliverables:**

- OPC UA Middleware Layer V0.1 Installed and Configured
- Initial low-level communication established with Wire Bender PLC

**Dependencies:**

- Wire Bender Delivered On-Site
- Signed Contracts for Key External Experts

### 18. Conduct expert-led tuning and stabilization of the Wire Bender (Decision 8 mitigation) to achieve required stable output/signal generation.

**Responsible Body/Role:** Controls Integration Specialist (via TAG oversight)

**Suggested Timeframe:** Project Weeks 18-20

**Key Outputs/Deliverables:**

- Phase 2 Milestone Met: 100 consecutive production cycles with verifiable PLC signal logged by backend (Assumption 2)
- Wire Bender Commissioning Report

**Dependencies:**

- Initial low-level communication established with Wire Bender PLC
- Budget funds reserved for on-site stabilization (per Review Conclusion Issue 3)

### 19. Procure and Install Paperclip Packing Machine (Start of Phase 3 execution).

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Weeks 16-20

**Key Outputs/Deliverables:**

- Packing Machine Delivered and Installed
- Mechanical Transfer System (Decision 8) installed

**Dependencies:**

- Approved PMO ToR v1.0
- Packing Machine Purchased

### 20. Commission Packaging Cell and integrate physical transfer from Wire Former output to Packer.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Weeks 21-24

**Key Outputs/Deliverables:**

- Phase 3 Milestone Met: 100 consecutive 100-count bags successfully produced (Assumption 2)
- Packaging Cell Stabilization Report

**Dependencies:**

- Phase 2 Milestone Met: 100 consecutive production cycles
- Packing Machine Delivered and Installed

### 21. Internal Developer begins Phase 4: Implement REST API, Backend Job Queue, and Initial Dashboard.

**Responsible Body/Role:** Internal Software Developer (under PMO oversight)

**Suggested Timeframe:** Project Weeks 15-25

**Key Outputs/Deliverables:**

- REST API Skeleton Operational
- Job Queue Service Deployed

**Dependencies:**

- Project Management Tool Suite Operationalized
- OPC UA Middleware Layer V0.1 Installed and Configured

### 22. Integrate Backend Control Logic with OPC UA Middleware (linking API commands to physical cells).

**Responsible Body/Role:** Internal Software Developer

**Suggested Timeframe:** Project Weeks 25-28

**Key Outputs/Deliverables:**

- API Command successfully triggers Wire Form cell start/stop
- Status reporting fully functional from both cells to Dashboard

**Dependencies:**

- Phase 3 Milestone Met: 100 consecutive 100-count bags successfully produced
- OPC UA Middleware Layer V0.1 Installed and Configured

### 23. Procure and Install Outbound Automation (Labeler, Insertion, Sealing Mechanism - Phase 5).

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Weeks 25-30

**Key Outputs/Deliverables:**

- Labeling System Installed
- Parcel Insertion Mechanism Verified

**Dependencies:**

- Approved ECC ToR v1.0 (Environmental assessment complete)
- Budget Allocation for Expert Commissioning status reviewed

### 24. Integrate Final Packaging Workflow (Phase 5 completion) with Control Software, ensuring triggers match physical staging requirements.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Weeks 31-34

**Key Outputs/Deliverables:**

- Automated Parcel Creation Flow Verified
- Phase 5 Completion Report

**Dependencies:**

- API Command successfully triggers Wire Form cell start/stop
- Parcel Insertion Mechanism Verified

### 25. Execute Phase 6: Integrate UPS/FedEx APIs for Label Generation and Manifesting (Decision 11).

**Responsible Body/Role:** Internal Software Developer

**Suggested Timeframe:** Project Weeks 35-37

**Key Outputs/Deliverables:**

- Carrier API Integration Successful (Label Generation)
- Staging Zone Parcel Manifesting Confirmed

**Dependencies:**

- Phase 5 Completion Report
- Backend Infrastructure Residency Confirmed (Local/Cloud)

### 26. Conduct End-to-End Feasibility Demonstration and Formal Project Sign-off.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 38

**Key Outputs/Deliverables:**

- Successful End-to-End Demonstration (API call to Parcel Staged)
- Project Completion Report
- Initial Weekly Exception Log Analysis (Verification of < 2 hr manual work)

**Dependencies:**

- Carrier API Integration Successful (Label Generation)