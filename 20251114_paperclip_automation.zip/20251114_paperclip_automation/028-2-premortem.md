A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The cost of capital will remain stable throughout the project. | Obtain fixed-rate financing quotes from multiple lenders. | Quotes exceed the project's maximum allowable interest rate (e.g., 8%). |
| A2 | The used wire bending machine can be reliably integrated with modern control systems. | Conduct a detailed compatibility assessment with the selected PLC and control software. | The machine lacks necessary interfaces or requires extensive and costly modifications for integration. |
| A3 | The local community will support the project and its goals. | Conduct a community meeting to present the project and gather feedback. | Significant opposition arises, leading to permit challenges or project delays. |
| A4 | The selected packaging materials will be compatible with the labeling system and carrier requirements. | Conduct compatibility tests with the labeling system and carrier scanning equipment. | Labels fail to adhere properly or are unreadable by carrier scanning systems. |
| A5 | The project team possesses sufficient expertise in all required areas, or can readily acquire it. | Conduct a skills gap analysis and identify any critical knowledge gaps. | Critical skills gaps are identified that cannot be filled within the project's budget and timeline. |
| A6 | The supply chain for critical components (e.g., sensors, actuators) will remain stable and reliable. | Assess the lead times and availability of critical components from multiple suppliers. | Lead times for critical components exceed acceptable limits, or suppliers are unable to guarantee delivery. |
| A7 | The existing building infrastructure (power, network) is sufficient for the automated system's needs. | Conduct a thorough assessment of the building's electrical and network capacity. | The building lacks sufficient power or network capacity, requiring costly upgrades. |
| A8 | The chosen automation technologies will be readily accepted and understood by potential customers or investors. | Present the project's automation approach to a focus group of potential customers or investors. | The automation technologies are perceived as too complex, risky, or unnecessary. |
| A9 | The regulatory landscape regarding automation and manufacturing will remain stable throughout the project. | Monitor relevant regulatory bodies for any proposed changes to automation or manufacturing regulations. | New regulations are introduced that significantly increase the project's compliance costs or restrict its operations. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Interest Rate Inferno | Process/Financial | A1 | Project Manager | CRITICAL (15/25) |
| FM2 | The Legacy Lockout | Technical/Logistical | A2 | Head of Engineering | CRITICAL (16/25) |
| FM3 | The NIMBY Nightmare | Market/Human | A3 | Community Liaison | MEDIUM (8/25) |
| FM4 | The Sticky Situation | Process/Financial | A4 | Packaging Lead | HIGH (12/25) |
| FM5 | The Expertise Evaporation | Technical/Logistical | A5 | Project Manager | CRITICAL (20/25) |
| FM6 | The Supply Chain Snarl | Market/Human | A6 | Procurement Lead | HIGH (12/25) |
| FM7 | The Powerless Paperclip Plant | Technical/Logistical | A7 | Electrical Engineer | CRITICAL (15/25) |
| FM8 | The Automation Aversion | Market/Human | A8 | Marketing Lead | MEDIUM (8/25) |
| FM9 | The Regulatory Rollercoaster | Process/Financial | A9 | Compliance Officer | HIGH (12/25) |


### Failure Modes

#### FM1 - The Interest Rate Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Rising interest rates increase the cost of borrowing, exceeding the project's financial capacity. This leads to budget cuts, forcing compromises on critical automation components. The reduced automation results in higher labor costs and lower throughput, making the project economically unviable. The project is ultimately abandoned due to lack of funding and inability to achieve the projected ROI.

Contributing factors include a lack of fixed-rate financing options and an underestimation of the impact of interest rate fluctuations on the project's profitability. The initial financial model failed to account for sensitivity to interest rate changes, leading to an overly optimistic assessment of the project's financial viability. The project team was unable to secure favorable financing terms due to market conditions and a lack of negotiation leverage.

The impact is catastrophic, resulting in a complete loss of investment and a failure to demonstrate the potential of autonomous manufacturing. The project's reputation is damaged, making it difficult to secure future funding for similar initiatives. The team disbands, and the partially completed factory sits idle.

##### Early Warning Signs
- Interest rate benchmarks increase by >= 1% within a 3-month period.
- Financing quotes exceed the initial budget by >= 5%.
- The project's IRR (Internal Rate of Return) falls below 10% in sensitivity analysis.

##### Tripwires
- Prime interest rate increases by >= 1.5% from initial projections.
- Financing costs exceed 15% of the total project budget.
- Projected ROI falls below 8%.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending.
- Assess: Conduct a thorough financial review and identify cost-saving measures.
- Respond: Renegotiate financing terms, seek additional funding, or scale back project scope.


**STOP RULE:** Inability to secure financing at an acceptable rate (<= 9%) within 30 days.

---

#### FM2 - The Legacy Lockout

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The used wire bending machine proves incompatible with modern control systems, requiring extensive and costly modifications. The integration challenges lead to significant delays in commissioning the machine, disrupting the entire production line. The control software struggles to communicate with the machine's outdated interfaces, resulting in unreliable operation and frequent breakdowns.

Contributing factors include a lack of thorough compatibility assessment before purchasing the machine and an underestimation of the complexity of integrating legacy equipment with modern technologies. The project team lacked the necessary expertise in reverse engineering and adapting outdated control systems. The machine's documentation was incomplete or inaccurate, further complicating the integration process.

The impact is severe, resulting in significant delays, budget overruns, and a failure to achieve the desired level of automation. The project team is forced to abandon the used machine and purchase a new one, further straining the budget and timeline. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- PLC integration requires custom hardware interfaces.
- Machine documentation is incomplete or unavailable.
- Control software fails to communicate with the machine after 2 weeks of integration efforts.

##### Tripwires
- Custom hardware interfaces cost exceeds $10,000.
- PLC integration requires > 400 hours of engineering time.
- Machine uptime is < 70% after initial commissioning.

##### Response Playbook
- Contain: Halt all further integration efforts with the used machine.
- Assess: Evaluate alternative integration strategies or machine replacement options.
- Respond: Secure additional funding for a new machine or pivot to a less ambitious automation plan.


**STOP RULE:** Inability to establish reliable communication between the machine and control software within 60 days.

---

#### FM3 - The NIMBY Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Community Liaison
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The local community opposes the project due to concerns about noise, traffic, and potential job displacement. The opposition leads to permit challenges, project delays, and increased costs for community engagement and mitigation measures. Negative publicity damages the project's reputation and makes it difficult to secure local support.

Contributing factors include a lack of proactive community engagement and an underestimation of the potential for local opposition. The project team failed to adequately address community concerns and build positive relationships with local stakeholders. Misinformation and rumors spread, fueling opposition and creating a hostile environment for the project.

The impact is significant, resulting in project delays, increased costs, and a tarnished reputation. The project team is forced to scale back the project scope or relocate to a more supportive community. The project ultimately fails to achieve its goals and leaves a negative impression on the local community.

##### Early Warning Signs
- Local residents express concerns about the project at community meetings.
- Negative articles or social media posts appear about the project.
- Permit applications are delayed or denied due to community opposition.

##### Tripwires
- Formal complaints filed by >= 10 local residents.
- Permit approval delayed by > 60 days due to community concerns.
- Negative media coverage reaches >= 50,000 impressions.

##### Response Playbook
- Contain: Immediately halt all construction activities and engage with community leaders.
- Assess: Conduct a thorough assessment of community concerns and identify potential solutions.
- Respond: Implement mitigation measures, address community concerns, and rebuild trust.


**STOP RULE:** Inability to secure necessary permits due to community opposition within 90 days.

---

#### FM4 - The Sticky Situation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Packaging Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The selected packaging materials prove incompatible with the labeling system. Labels fail to adhere properly, causing shipping errors and delays. The cost of rework and customer complaints skyrockets, eroding profit margins. The project is forced to switch to more expensive packaging materials, further straining the budget. The increased operational costs make the project economically unviable.

Contributing factors include a lack of thorough testing of packaging materials before implementation and an underestimation of the importance of label adhesion. The project team failed to consider the specific requirements of the labeling system and carrier scanning equipment. The packaging materials were chosen primarily based on cost, without adequate consideration for compatibility.

The impact is significant, resulting in increased operational costs, reduced customer satisfaction, and a failure to achieve the projected ROI. The project's reputation is damaged, and it becomes difficult to attract new customers. The project is ultimately scaled back or abandoned.

##### Early Warning Signs
- Labels peel off packages during initial testing.
- Carrier scanning equipment fails to read labels consistently.
- Customer complaints about shipping errors increase significantly.

##### Tripwires
- Label adhesion failure rate exceeds 5%.
- Carrier scanning error rate exceeds 2%.
- Customer complaints about shipping errors increase by >= 20%.

##### Response Playbook
- Contain: Immediately halt shipments using the incompatible packaging materials.
- Assess: Conduct a thorough analysis of label adhesion and scanning issues.
- Respond: Switch to compatible packaging materials, improve labeling process, or implement manual verification.


**STOP RULE:** Inability to find compatible packaging materials within 30 days.

---

#### FM5 - The Expertise Evaporation

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project team lacks sufficient expertise in a critical area, such as PLC programming or robotics integration. The lack of expertise leads to significant delays, technical challenges, and costly rework. The project is unable to achieve the desired level of automation or reliability. The team struggles to troubleshoot complex issues, resulting in frequent breakdowns and downtime.

Contributing factors include an inaccurate assessment of the team's skills and an underestimation of the complexity of the project. The project team failed to identify critical knowledge gaps before starting the project. The team was unable to attract or retain qualified personnel due to budget constraints or other factors.

The impact is severe, resulting in significant delays, budget overruns, and a failure to achieve the project's goals. The project team is forced to scale back the project scope or abandon certain automation features. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- Tasks are consistently delayed due to lack of expertise.
- The team struggles to troubleshoot complex technical issues.
- External consultants are required for tasks that were initially planned to be done in-house.

##### Tripwires
- Critical tasks are delayed by > 30 days due to lack of expertise.
- External consulting costs exceed 10% of the project budget.
- System uptime is < 60% due to technical issues.

##### Response Playbook
- Contain: Immediately halt all work on tasks requiring the missing expertise.
- Assess: Conduct a thorough assessment of the skills gap and identify potential solutions.
- Respond: Hire qualified personnel, provide training to existing team members, or outsource critical tasks.


**STOP RULE:** Inability to fill critical skills gaps within 60 days.

---

#### FM6 - The Supply Chain Snarl

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Procurement Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The supply chain for critical components (e.g., sensors, actuators) becomes unreliable. Lead times increase significantly, and suppliers are unable to guarantee delivery. The project is delayed due to a lack of necessary components. The cost of components increases due to scarcity, further straining the budget. The project is forced to use alternative, less suitable components, compromising performance and reliability.

Contributing factors include global supply chain disruptions, geopolitical instability, and an over-reliance on single suppliers. The project team failed to diversify its supply base or anticipate potential disruptions. The team lacked the necessary expertise in supply chain management.

The impact is significant, resulting in project delays, increased costs, and a compromised system. The project team is forced to scale back the project scope or abandon certain automation features. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- Lead times for critical components increase significantly.
- Suppliers are unable to guarantee delivery dates.
- The cost of critical components increases unexpectedly.

##### Tripwires
- Lead times for critical components exceed 90 days.
- Component costs increase by >= 15%.
- Alternative components require significant design modifications.

##### Response Playbook
- Contain: Immediately identify alternative suppliers and expedite component orders.
- Assess: Conduct a thorough assessment of the supply chain disruption and its impact on the project.
- Respond: Redesign the system to use readily available components, secure long-term supply agreements, or scale back project scope.


**STOP RULE:** Inability to secure critical components within 120 days.

---

#### FM7 - The Powerless Paperclip Plant

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Electrical Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The existing building's electrical infrastructure proves inadequate for the power demands of the automated system. Upgrading the electrical service requires extensive and costly renovations, including new transformers and wiring. The project is delayed significantly while the electrical upgrades are completed. The increased costs strain the budget, forcing compromises on other critical components. The unreliable power supply leads to frequent system shutdowns and data loss.

Contributing factors include a lack of thorough assessment of the building's electrical capacity before starting the project and an underestimation of the power requirements of the automated system. The project team failed to consult with a qualified electrical engineer during the initial planning phase. The building's electrical documentation was incomplete or inaccurate, further complicating the assessment.

The impact is severe, resulting in significant delays, budget overruns, and a compromised system. The project team is forced to scale back the automation features or find an alternative location. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- The building's electrical panel is near its maximum capacity.
- Voltage fluctuations are observed during peak usage.
- The electrical engineer recommends significant upgrades to the power service.

##### Tripwires
- Electrical upgrade costs exceed $25,000.
- Projected completion date is delayed by > 90 days due to electrical work.
- System downtime due to power outages exceeds 5%.

##### Response Playbook
- Contain: Immediately reduce power consumption by optimizing equipment settings.
- Assess: Conduct a detailed assessment of the electrical system and identify alternative upgrade options.
- Respond: Secure additional funding for electrical upgrades, scale back automation features, or relocate the project.


**STOP RULE:** Inability to secure a reliable power supply within 120 days.

---

#### FM8 - The Automation Aversion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Marketing Lead
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
Potential customers and investors are wary of the project's reliance on advanced automation technologies. They perceive the system as too complex, risky, and expensive. They are concerned about the potential for job displacement and the lack of human oversight. The project struggles to attract funding and customer interest. The lack of market acceptance undermines the project's long-term viability.

Contributing factors include a failure to adequately communicate the benefits of automation and an underestimation of the public's perception of advanced technologies. The project team focused too much on the technical aspects of the project and not enough on the human and economic benefits. Misinformation and rumors spread, fueling skepticism and resistance.

The impact is significant, resulting in a lack of funding, reduced customer demand, and a failure to achieve the project's goals. The project team is forced to scale back the automation features or abandon the project altogether. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- Potential investors express concerns about the project's reliance on automation.
- Customers are hesitant to adopt the automated system.
- Negative feedback is received about the project's complexity or cost.

##### Tripwires
- Investment interest falls below 50% of target.
- Customer adoption rate is < 10% after initial launch.
- Negative media coverage focuses on job displacement or safety concerns.

##### Response Playbook
- Contain: Immediately launch a public relations campaign to address concerns and highlight the benefits of automation.
- Assess: Conduct a thorough market analysis to understand customer and investor perceptions.
- Respond: Redesign the system to be more user-friendly, emphasize the human benefits of automation, or target a different market.


**STOP RULE:** Inability to secure sufficient funding or customer interest within 180 days.

---

#### FM9 - The Regulatory Rollercoaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Compliance Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
New regulations are introduced that significantly increase the project's compliance costs and restrict its operations. The project is forced to make costly modifications to the system to comply with the new regulations. The increased compliance costs strain the budget, forcing compromises on other critical components. The regulatory restrictions limit the system's operational efficiency and profitability.

Contributing factors include a failure to anticipate potential changes in the regulatory landscape and an underestimation of the impact of regulations on the project's viability. The project team lacked the necessary expertise in regulatory compliance. The team failed to build relationships with relevant regulatory bodies.

The impact is significant, resulting in increased costs, reduced profitability, and a compromised system. The project team is forced to scale back the automation features or abandon the project altogether. The project ultimately fails to demonstrate the potential of autonomous manufacturing.

##### Early Warning Signs
- New regulations are proposed that could impact the project.
- Compliance costs increase unexpectedly.
- The project is unable to meet new regulatory requirements.

##### Tripwires
- Compliance costs exceed 10% of the project budget.
- Projected completion date is delayed by > 60 days due to regulatory changes.
- The system is unable to operate at its full capacity due to regulatory restrictions.

##### Response Playbook
- Contain: Immediately halt all work on tasks affected by the new regulations.
- Assess: Conduct a thorough assessment of the regulatory changes and their impact on the project.
- Respond: Modify the system to comply with the new regulations, seek regulatory exemptions, or scale back project scope.


**STOP RULE:** Inability to comply with new regulations within 90 days.
