A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The supply chain for used machinery is stable and predictable. | Contact multiple suppliers to confirm availability and delivery timelines for used wire benders. | At least two suppliers indicate significant delays or lack of stock for the required machinery. |
| A2 | The internal developer can manage all aspects of software integration without external support. | Evaluate the internal developer's current workload and capacity to handle additional tasks. | The internal developer reports being overwhelmed and unable to meet project deadlines. |
| A3 | The chosen used wire bender will integrate seamlessly with modern control systems. | Obtain detailed documentation and technical specifications for the selected wire bender. | Documentation reveals that the wire bender lacks necessary modern interfaces or support. |
| A4 | The regulatory approval process (permitting, safety sign-off) will be completed within the planned 6-week window. | Submit preliminary electrical and layout schematics to the Cleveland Building Authority for initial feedback/estimated review timeline. | Regulatory bodies require electrical remediation exceeding $25,000 or provide a review timeline exceeding 10 weeks. |
| A5 | Carrier acceptance protocols (UPS/FedEx staging) will accommodate the chosen physical packaging modality (Decision 10). | Obtain official, documented staging and dimensional guidelines from both UPS and FedEx regarding high-volume, mixed-modal package pickup. | Carriers require advanced dynamic flow/conveyor integration (ruling out fixed staging) or reject the envelope dimensions of the chosen mailer/box type. |
| A6 | The $50,000 budget allocated for external OPC UA middleware development is sufficient for complex legacy controller abstraction. | Issue a Request for Quote (RFQ) to three specialized integration firms based on the expected complexity of the shortlisted wire bender protocols. | The lowest qualified bid for middleware development exceeds $75,000, forcing a reduction in the dedicated commissioning expert budget. |
| A7 | The internal REST API development (Phase 4) will possess sufficient inherent low-latency performance to satisfy the edge compute requirements (Decision 14) without needing immediate rewrite. | Conduct a stress test on the core API job queue under 2x expected peak load, measuring 99th percentile response time against a 50ms threshold. | The 99th percentile API response time exceeds 100ms, indicating unresolvable serialization overhead that fails the low-latency requirement of Decision 14. |
| A8 | The budget allocated for packaging supplies will cover both initial setup inventory and expected consumption during the 4-week stabilization window. | Calculate the total cost of the necessary mailers/boxes to support 100 consecutive cycles * 4 weeks of stabilization testing, then cross-reference against the packaging budget line item. | The calculated inventory cost exceeds 150% of the established budget line item for consumable supplies. |
| A9 | The used wire bender's internal control logic is sufficiently documented for the 1-week on-site expert engagement to stabilize the system. | Provide the final selected wire bender's PLC/hardware schematics to the retained commissioning expert immediately upon purchase confirmation for a preliminary review. | The expert states they require an additional 2 weeks of dedicated diagnostic time due to undocumented register maps or proprietary control languages. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Supply Chain Collapse | Process/Financial | A1 | Procurement Manager | CRITICAL (20/25) |
| FM2 | The Developer Bottleneck | Technical/Logistical | A2 | Project Manager | CRITICAL (20/25) |
| FM3 | The Integration Nightmare | Market/Human | A3 | Controls Integration Specialist | CRITICAL (20/25) |
| FM4 | The Frozen Foundation | Process/Financial | A4 | Regulatory Compliance Coordinator | CRITICAL (20/25) |
| FM5 | The Middleware Squeeze | Technical/Logistical | A6 | Automation Control Architect | CRITICAL (16/25) |
| FM6 | The Carrier Reject | Market/Human | A5 | Logistics & Carrier Integration Specialist | CRITICAL (15/25) |
| FM7 | The Latency Wall | Technical/Logistical | A7 | Internal Systems Liaison & API Developer Support | CRITICAL (16/25) |
| FM8 | The Documentation Black Hole | Process/Financial | A9 | Financial Oversight & Contingency Planner | Not Scored |
| FM9 | The Consumable Burn Rate | Market/Human | A8 | Industrial Procurement & Vendor Manager | HIGH (9/25) |


### Failure Modes

#### FM1 - The Supply Chain Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Procurement Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relied on a stable supply chain for used machinery. When suppliers reported delays, the project timeline was jeopardized. Costs escalated as alternative suppliers were sought, leading to budget overruns.

##### Early Warning Signs
- Supplier delivery timelines exceed 4 weeks.
- Two or more suppliers indicate stock shortages.
- Increased quotes from suppliers by more than 20%.

##### Tripwires
- Supplier delivery timelines exceed 4 weeks.
- Two or more suppliers indicate stock shortages.
- Increased quotes from suppliers by more than 20%.

##### Response Playbook
- Contain: Stop all procurement activities until a new supplier is secured.
- Assess: Review the impact of delays on the project timeline and budget.
- Respond: Identify alternative suppliers and negotiate expedited shipping.


**STOP RULE:** If supplier delays exceed 8 weeks, the project will pivot to alternative machinery options.

---

#### FM2 - The Developer Bottleneck

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The internal developer was overwhelmed with tasks, leading to delays in software integration. As a result, the project fell behind schedule, and critical deadlines were missed, causing cascading delays in subsequent phases.

##### Early Warning Signs
- Internal developer reports being unable to meet deadlines.
- Task completion rates drop below 70%.
- Increased requests for extensions on deliverables.

##### Tripwires
- Internal developer reports being unable to meet deadlines.
- Task completion rates drop below 70%.
- Increased requests for extensions on deliverables.

##### Response Playbook
- Contain: Reassign non-critical tasks to other team members.
- Assess: Evaluate the internal developer's workload and identify bottlenecks.
- Respond: Hire a part-time contractor to assist with software integration.


**STOP RULE:** If the internal developer cannot meet deadlines for two consecutive sprints, the project will hire additional resources.

---

#### FM3 - The Integration Nightmare

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Controls Integration Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The chosen used wire bender lacked modern interfaces, leading to extensive custom driver development. This resulted in significant delays and increased costs, ultimately jeopardizing the project's feasibility.

##### Early Warning Signs
- Documentation reveals missing modern interfaces.
- Initial integration tests fail to establish communication.
- Increased costs for custom driver development exceed budget by 30%.

##### Tripwires
- Documentation reveals missing modern interfaces.
- Initial integration tests fail to establish communication.
- Increased costs for custom driver development exceed budget by 30%.

##### Response Playbook
- Contain: Halt all integration efforts until a new machine is sourced.
- Assess: Review the impact of integration failures on the project timeline.
- Respond: Identify alternative machinery options that meet modern standards.


**STOP RULE:** If integration issues cannot be resolved within 6 weeks, the project will pivot to a different machine.

---

#### FM4 - The Frozen Foundation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Regulatory Compliance Coordinator
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Reliance on a politically achievable permitting timeline proved false. Unexpected electrical remediation (e.g., panel upgrade) discovered late in Phase 1 required $35,000 in unplanned capital expenditure, immediately drawing down contingency funds intended for expert commissioning and forcing the project to proceed without guaranteed on-site support.

##### Early Warning Signs
- Permit submission feedback cites mandatory electrical panel upgrades ($>20k cost).
- Building Authority review timeline exceeds 10 weeks.
- Regulatory consultant reports difficulty obtaining initial electrical sign-off.

##### Tripwires
- Permit feedback requires electrical remediation exceeding $25,000.
- Initial permit review response time exceeds 10 calendar days.

##### Response Playbook
- Contain: Immediately halt all equipment rigging schedules pending electrical confirmation.
- Assess: Recalculate remaining budget flexibility after mandatory remediation cost absorption.
- Respond: Re-allocate contingency funds previously set aside for contingency hardware (spares) to cover the electrical deficit.


**STOP RULE:** If site access for rigging is denied 4 weeks past the original target date due to unresolvable permitting issues, the project will halt until a new facility is secured.

---

#### FM5 - The Middleware Squeeze

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: Automation Control Architect
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The complexity of creating OPC UA drivers for the legacy bender PLC was severely underestimated. The lowest qualified middleware bid came in at $80,000, consuming $30,000 of the dedicated Physical Handoff budget (Decision 8). This forced the Mechanical Integration Engineer to reuse gravity chutes (Decision 8, Choice 3) instead of a buffered accumulation system, leading to chronic jamming between Phase 2 and 3.

##### Early Warning Signs
- Lowest qualified middleware bid exceeds $75,000.
- Automation Control Architect requires more than 1 man-week to scope initial OPC UA nodes.
- External integration firm requires 100% payment upfront for middleware scope.

##### Tripwires
- Lowest qualified middleware bid exceeds $75,000.
- The defined scope for OPC UA abstraction requires more than 4 unique protocol translation layers.

##### Response Playbook
- Contain: Issue immediate stop-work order on middleware coding contracts.
- Assess: Calculate the cost difference between the planned $50k budget and the lowest actual bid.
- Respond: Request immediate emergency funds authorization or pivot to the riskier, budget-saving custom I/O board approach, accepting internal developer overload.


**STOP RULE:** If the final contracted cost for middleware development exceeds $90,000, the project reverts to the high-risk custom I/O translator model, resetting Phase 4 expectations.

---

#### FM6 - The Carrier Reject

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Logistics & Carrier Integration Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The team assumed standard staging protocols would be adequate for the pilot scale. Upon final testing in Phase 6, the carrier explicitly rejected the low-cost padded mailer presentation format, demanding that all parcels be sorted onto standardized shipping pallets indexed by sequential barcode scanning integrated with their manifest system. This required a complete re-engineering of the physical handoff mechanism and the shipping manifest logic (D8/D11), delaying the final feasibility demonstration by 5 weeks.

##### Early Warning Signs
- Carrier staging guidelines reject non-palletized, mixed-format parcel queues.
- Logistics Specialist identifies conflicts between Decision 10 and Decision 11 manifests.
- Final parcel presentation test in Phase 5 results in immediate carrier refusal.

##### Tripwires
- Carrier staging guidelines reject non-palletized, mixed-format parcel queues.
- Final parcel presentation test in Phase 5 results in immediate carrier refusal.

##### Response Playbook
- Contain: Immediately halt all API manifest generation (Phase 6 activity).
- Assess: Determine the cost/time impact of re-configuring the physical handoff (D8) for palletization.
- Respond: Fund immediate redesign and procurement for necessary staging conveyors/pallet wrappers.


**STOP RULE:** If carrier staging requirements necessitate additional capital expenditure greater than $40,000 for mechanical redesign, the project will pivot to a B2B volume shipment model only.

---

#### FM7 - The Latency Wall

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Internal Systems Liaison & API Developer Support
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The internal API, designed for standard enterprise transactions, failed under the high-frequency, low-latency demands of direct machine control mandated by Decision 14 (On-Premise Compute). Serialization overhead in the job queue resulted in command queuing delays exceeding 100ms, causing the PLC abstraction layer to time out and pause operations, necessitating a full re-architecture of the backend queuing mechanism.

##### Early Warning Signs
- 99th percentile API job queue latency exceeds 100ms during stress testing.
- Control Abstraction Layer reports command timeouts greater than 2% of attempts.
- Internal developer fails to achieve 50ms response time validation in mock testing.

##### Tripwires
- 99th percentile API job queue latency exceeds 100ms during stress testing.
- Control Abstraction Layer reports command timeouts greater than 2% of attempts.

##### Response Playbook
- Contain: Immediately revert API to 'polling' mode, stopping asynchronous command execution.
- Assess: Isolate the API queue performance from the abstraction layer to confirm the bottleneck source.
- Respond: Re-platform the job queue using a specialized, low-latency message broker (e.g., Redis Pub/Sub) and initiate a rapid rewrite of critical path logic.


**STOP RULE:** If API latency cannot be reduced below 75ms after a 3-week re-write effort, the project pivots to using a purely non-API-driven, HMI-controlled pilot demonstration.

---

#### FM8 - The Documentation Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Financial Oversight & Contingency Planner
- **Risk Level:** Likelihood None/5, Impact 4/5

##### Failure Story
The complexity of the used bender's PLC forced the commissioning expert to spend 3 weeks troubleshooting undocumented register maps instead of the budgeted 1 week. This overrun consumed the entire contingency reserve set aside for Expert Commissioning (Lever b034), leading to a severe cash flow crisis mid-Phase 2. The project had to delay payment to the external OPC UA vendor, straining the primary technical integration effort.

##### Early Warning Signs
- Commissioning expert requires a 3-week extension beyond the initial 1-week engagement.
- Expert reports encountering undocumented proprietary register access.
- Vendor support contract quotes exceed $15,000 for the initial stabilization period.

##### Tripwires
- Commissioning expert requires a 3-week extension beyond the initial 1-week engagement.
- Vendor support contract quotes exceed $15,000 for the initial stabilization period.

##### Response Playbook
- Contain: Immediately pause all non-essential contractor payments (e.g., Logistics Specialist initial deposit).
- Assess: Calculate the precise cash flow requirement to cover the expert overrun and determine the immediate impact on the middleware budget.
- Respond: Secure executive approval for a $20,000 emergency drawdown from the operational expenditure pool to bridge the gap.


**STOP RULE:** If the expert engagement exceeds 4 weeks total, the project sponsor must immediately inject $50,000 in new capital, or the project is canceled.

---

#### FM9 - The Consumable Burn Rate

- **Archetype**: Market/Human
- **Root Cause**: Assumption A8
- **Owner**: Industrial Procurement & Vendor Manager
- **Risk Level:** HIGH 9/25 (Likelihood 3/5 × Impact 3/5)

##### Failure Story
The stabilization window required significantly more test runs than anticipated due to mechanical variability; consequently, the inventory of specific, custom-sized padded mailers budgeted for the pilot run was depleted in half the expected time. This forced a 2-week pause in Phase 5 packaging testing while waiting for new supplies, creating a morale hit and delaying the final carrier demonstration timeline, as the Logistics Specialist could not complete Phase 6 testing.

##### Early Warning Signs
- Supplies consumed at 2x the planned rate for 4 weeks.
- Inventory tracking shows stock depletion below 15% mark before Phase 5 testing is complete.
- Project Owner receives notification from Procurement about duplicate rush orders.

##### Tripwires
- Supplies consumed at 2x the planned rate for 4 weeks.
- Inventory tracking shows stock depletion below 15% mark before Phase 5 testing is complete.

##### Response Playbook
- Contain: Immediately halt all end-to-end demonstration runs, switching to dry-cycle testing only.
- Assess: Calculate the time required for standard order fulfillment (lead time) for new supplies.
- Respond: Re-allocate $5,000 from project marketing funds to expedite production and shipment of replacement packaging materials.


**STOP RULE:** If the lead time for securing replacement packaging supplies exceeds 10 business days, the final demonstration deadline is formally extended by 4 weeks.
