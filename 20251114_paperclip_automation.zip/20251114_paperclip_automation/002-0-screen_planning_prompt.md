**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete project with specific details about location, equipment, budget, and phases. It provides enough information to generate a detailed project plan.