## Positive Constraints

- Build a fully automated pilot paperclip factory
- Location: existing 15,000 sq ft building in Cleveland (St. Clair–Superior, E 55th–E 79th corridor)
- Use roughly 4,000 sq ft for the pilot line
- System must produce, pack, label, and stage paperclips for UPS/FedEx pickup without any human intervention between the API call and the carrier pickup
- Goal: working, demonstrable autonomous flow
- No manual touches for regular orders; manual only for exceptions
- Acceptable manual work is ≤2 hr/week for exceptions
- Total budget range: $300,000-$500,000
- Used industrial wire bending / forming machine capable of producing standard paperclips
- Wire bending machine budget: $20,000–$40,000
- Wire bending machine must have suitable I/O or PLC interface for external control
- Wire bending machine must have documentation and vendor support for commissioning
- Professional transport and rigging of wire bending machine into building
- Electrical hookup and safety integration of wire bending machine
- Expert commissioning and program tuning of wire bending machine for stable paperclip production
- New small-parts / hardware packing machine
- Packing machine must automatically count exactly 100 paperclips
- Packing machine must bag and seal paperclips in individual plastic bags
- Packing machine budget: $10,000–$30,000
- Transport and installation of packing machine
- Integration of feed system from wire former output to packing machine
- Tuning of packing machine for reliable counting and bagging
- Industrial print-and-apply label system
- Label system must receive shipping label data from backend
- Label system must print and apply labels without any manual steps
- Mechanical system to take sealed paperclip bags from the packer
- Mechanical system to insert bags into shipping mailers or boxes
- Mechanical system to seal the mailer/box
- Mechanical system to present labeled parcels on a conveyor or at a fixed pickup zone for UPS/FedEx
- Integration with UPS/FedEx APIs for label generation
- Integration with UPS/FedEx APIs for shipment creation and manifesting
- Integration with UPS/FedEx APIs for daily or scheduled pickup
- REST API, backend services, and a frontend dashboard
- API triggers will create an order
- API triggers will schedule and execute production of the required number of bags
- API triggers will generate and send shipping data/labels to the labeling system
- API triggers will track machine status, errors, and order completion

## Negative Constraints

- Do not use blockchain
- Do not use digital twin
- Do not use ai
- Do not use self-healing
