## Positive Constraints

- 15-year initiative
- USD 10 billion budget
- Led by a Chinese consortium
- Design, construct, and explore synthetic lifeforms with opposite chirality (D-chiral)
- Primary goal: Develop mirror-life systems capable of replicating biological functions under alternative chirality
- Secondary goal: Deconstruct evolutionary constraints in molecular biology
- Use an existing BSL-4+ lab near Beijing
- Focus on speed
- Focus on secrecy
- Focus on securing a national advantage
- Project start ASAP
