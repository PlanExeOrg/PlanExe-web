This plan implies one or more physical locations.

## Requirements for physical locations

- BSL-4+ laboratory
- Near Beijing
- High security
- Secrecy

## Location 1
China

Near Beijing

Existing BSL-4+ lab near Beijing

**Rationale**: The plan specifies using an existing BSL-4+ lab near Beijing to leverage existing infrastructure and expertise, while maintaining secrecy and speed.

## Location 2
China

Hebei Province (near Beijing)

Shijiazhuang or Langfang

**Rationale**: Hebei Province surrounds Beijing and offers potential locations that are geographically close, facilitating access to resources and personnel in Beijing while potentially offering more discreet or secure sites.

## Location 3
China

Tianjin (near Beijing)

Tianjin Economic-Technological Development Area (TEDA)

**Rationale**: Tianjin, a major port city near Beijing, has established biotechnology and pharmaceutical industries. TEDA offers advanced infrastructure and potential for collaboration, while still maintaining proximity to Beijing.

## Location Summary
The plan requires a BSL-4+ lab near Beijing for synthetic life research. The primary location is an existing lab, with Hebei Province and Tianjin as alternative suggestions due to their proximity, security, and relevant infrastructure.