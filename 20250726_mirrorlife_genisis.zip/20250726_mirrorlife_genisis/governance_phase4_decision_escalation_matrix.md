**Budget Request Exceeding PMO Authority ($50 million)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit delegated to PMO; requires strategic oversight.
Negative Consequences: Potential for budget overruns and misalignment with strategic goals.

**Critical Risk Materialization (e.g., Containment Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Remediation Plan
Rationale: Strategic impact on project viability and potential ecological/security consequences.
Negative Consequences: Ecological disaster, security breach, project termination, reputational damage.

**PMO Deadlock on Vendor Selection (Significant Disagreement)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Decision
Rationale: Inability to reach consensus within PMO hinders project progress; requires higher-level arbitration.
Negative Consequences: Project delays, inefficient resource allocation, compromised project outcomes.

**Proposed Major Scope Change (e.g., Altering Research Focus)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval
Rationale: Significant impact on project objectives, budget, and timeline; requires strategic alignment.
Negative Consequences: Project failure, budget overruns, misalignment with strategic goals.

**Reported Ethical Concern (e.g., Dual-Use Violation)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and assessment to ensure ethical conduct and compliance with regulations.
Negative Consequences: Legal penalties, reputational damage, international sanctions, project termination.

**Unresolved Technical Challenge Impeding Progress**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Technical Advisory Group Recommendations and Decision
Rationale: Technical issues beyond the PMO's expertise require strategic intervention and resource allocation.
Negative Consequences: Project delays, technical failure, inability to achieve project goals.