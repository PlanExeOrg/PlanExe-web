**Purpose:** business

**Purpose Detailed:** Large-scale scientific and technological initiative with geopolitical and strategic implications, focused on developing synthetic lifeforms with alternative chirality for national advantage.

**Topic:** Synthetic mirror-life development initiative