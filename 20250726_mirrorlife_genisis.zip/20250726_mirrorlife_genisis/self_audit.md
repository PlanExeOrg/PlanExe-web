Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the instructions state that if the plan does not require breaking a law of physics, the rating should be LOW. The plan does not require breaking any laws of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of synthetic life + alternative chirality + BSL-4 containment without independent evidence at comparable scale. There is no credible precedent for this system.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 6 months.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on buzzwords without clear definitions or mechanisms of action. For example, "national advantage" lacks a measurable outcome or defined process. "Geopolitical arms race" is asserted without a clear strategy.

**Mitigation**: Strategy Team: Create one-pagers for 'national advantage' and 'geopolitical arms race' defining inputs, processes, customer value, owners, measurable outcomes, and decision hooks. Due: 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan minimizes or omits major hazard classes. The plan mentions "ecological disruption" and "dual-use concerns" but lacks detailed analysis of financial, safety, and reputational risks.

**Mitigation**: Risk Team: Expand the risk register to include financial (cost overruns, ROI), safety (lab accidents, contamination), and reputational (public backlash, sanctions) risks. Due: 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "necessary permits and ethical approvals" but does not list them or their lead times. This omission creates a high risk of delays.

**Mitigation**: Regulatory Affairs Specialist: Create a permit/approval matrix with required permits, lead times, and dependencies. Include a NO-GO threshold on slip. Due: 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan mentions a "USD 10 billion budget" but lacks details on funding sources, draw schedule, covenants, or financing gates.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of USD 10 billion lacks substantiation via vendor quotes or scale-appropriate benchmarks. There is no per-area cost breakdown for the BSL-4+ lab fit-out.

**Mitigation**: Owner: Engineering Team. Deliverable: Obtain ≥3 vendor quotes for BSL-4+ lab fit-out, normalize cost per m², and adjust budget or de-scope. Date: 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., self-replication in year 5) as single numbers without ranges or alternative scenarios. The "Self-replication milestone in year 5" lacks sensitivity analysis.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or create best/worst/base-case scenarios for the self-replication milestone. Due: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps for the D-chiral lifeforms.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the D-chiral lifeforms. Due: 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "necessary permits and ethical approvals" but does not list them or their lead times. This omission creates a high risk of delays.

**Mitigation**: Regulatory Affairs Specialist: Create a permit/approval matrix with required permits, lead times, and dependencies. Include a NO-GO threshold on slip. Due: 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the major deliverable "synthetic D-chiral lifeforms" lacks specific, verifiable qualities. The plan does not define quantifiable metrics for success beyond self-replication.

**Mitigation**: Lead Synthetic Biologist: Define SMART criteria for "synthetic D-chiral lifeforms," including a KPI for replication fidelity (e.g., <1% mutation rate). Due: 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Evolutionary Constraint Deconstruction'. This feature does not directly support the core project goals of achieving self-replication and securing national advantage.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Evolutionary Constraint Deconstruction', complete with a KPI, owner, and estimated cost, or move it to the project backlog. Due: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the unicorn role is the Lead Synthetic Biologist, whose expertise in synthetic biology is critical and rare. This role is essential for project success.

**Mitigation**: Project Manager: Conduct a market analysis to validate the availability of qualified candidates for the Lead Synthetic Biologist role within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping required approvals, lead times, and controlling statutes. The plan mentions "necessary permits and ethical approvals" but does not list them.

**Mitigation**: Regulatory Affairs Specialist: Create a regulatory matrix (authority, artifact, lead time, predecessors) and a **NO-GO** on adverse findings. Due: 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. The plan does not address long-term operational costs, maintenance, scalability, personnel dependency, or technology obsolescence.

**Mitigation**: Project Manager: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not explicitly address zoning/land-use restrictions, occupancy/egress requirements, fire load limits, structural limits, or noise ordinances for the BSL-4+ lab. There is no evidence of a fatal-flaw screen.

**Mitigation**: Engineering Team: Conduct a fatal-flaw screen with local authorities to identify zoning, occupancy, fire, structural, and noise constraints. Deliverable: written confirmation or NO-GO. Date: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions redundancy but lacks evidence of tested failovers. The plan mentions "multi-layered containment" but lacks evidence of contracts/SLAs with vendors or tested failover plans.

**Mitigation**: Engineering Team: Secure SLAs with vendors for critical systems (e.g., power, water, HVAC) and conduct failover tests by Q4 2024.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Pioneer's Gambit' prioritizes speed, conflicting with the Finance Department's incentive for budget adherence. R&D is incentivized by long-term innovation, creating a conflict over experimental spending.

**Mitigation**: Executive Team: Create a shared OKR focused on 'delivering X D-chiral prototypes within budget' to align Finance and R&D. Due: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Deliverable: schedule and process. Date: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks that are strongly coupled. FM2 (Containment Catastrophe), FM3 (Public Pariah Project), and FM6 (Uncontrollable Creation) are tightly linked and can cascade.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: 90 days.