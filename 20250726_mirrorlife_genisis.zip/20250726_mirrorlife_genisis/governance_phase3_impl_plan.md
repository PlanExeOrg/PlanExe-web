### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Circulate Draft SteerCo ToR for review by nominated members (Senior Representatives from the Ministry of Science and Technology, National Health Commission, Chief Scientist of the Project, Independent Ethics Advisor, Project Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 5. Circulate Draft Ethics Committee ToR for review by potential members (Independent Ethicist, Biosecurity Expert, Legal Counsel, Regulatory Affairs Manager, Community Representative).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Ethics Committee ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Ethics Committee ToR v0.1
- Potential Members List Available

### 6. Circulate Draft Technical Advisory Group ToR for review by potential members (Leading Experts in Synthetic Biology, Experts in Chirality and Molecular Biology, Senior Scientists from the Project, Data Science Expert, BSL-4 Lab Director).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.2
- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Potential Members List Available

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.2

### 8. Project Manager finalizes the Ethics and Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics Committee ToR v0.2

### 9. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.2

### 10. Senior Representative from the Ministry of Science and Technology formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Senior Representative from the Ministry of Science and Technology

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Project Sponsor formally appoints members to the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics Committee ToR v1.0

### 12. Project Sponsor formally appoints members to the Technical Advisory Group.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 13. Project Manager formally establishes the Project Management Office (PMO) and assigns roles.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Roles and Responsibilities Document
- Communication Plan

**Dependencies:**

- Project Plan Approved

### 14. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 15. Hold initial Ethics and Compliance Committee kick-off meeting.

**Responsible Body/Role:** Independent Ethicist

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Ethics Committee ToR v1.0

### 16. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Leading Expert in Synthetic Biology

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Technical Advisory Group ToR v1.0

### 17. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Roles and Responsibilities Document

### 18. The Project Steering Committee reviews and approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Budget

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Project Plan Drafted

### 19. The Ethics and Compliance Committee establishes ethical review processes and guidelines.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Ethical Review Process Document
- Ethical Guidelines Document

**Dependencies:**

- Meeting Minutes with Action Items

### 20. The Technical Advisory Group develops a risk assessment framework for technical challenges.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Risk Assessment Framework

**Dependencies:**

- Meeting Minutes with Action Items

### 21. The PMO establishes project management processes and tools.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Management Processes Document
- List of Project Management Tools

**Dependencies:**

- Meeting Minutes with Action Items