### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this high-risk, high-reward, and geopolitically sensitive project. Ensures alignment with national strategic objectives and manages high-level risks.

**Responsibilities:**

- Approve strategic project plans and budgets exceeding $50 million.
- Monitor project progress against strategic goals and key performance indicators.
- Oversee risk management and mitigation strategies for high-impact risks (environmental, dual-use, security).
- Resolve strategic conflicts and escalate unresolved issues.
- Approve major changes to project scope or direction.
- Ensure alignment with national strategic objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish decision-making protocols and escalation paths.
- Review and approve the initial project plan and budget.
- Define risk appetite and tolerance levels.

**Membership:**

- Senior Representative from the Ministry of Science and Technology
- Senior Representative from the National Health Commission
- Chief Scientist of the Project
- Independent Ethics Advisor
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (>$50M), risk management, and alignment with national strategic objectives.

**Decision Mechanism:** Decisions made by majority vote, with the Senior Representative from the Ministry of Science and Technology holding the tie-breaking vote.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion of key risks and mitigation strategies.
- Approval of budget requests exceeding $50 million.
- Review of ethical and compliance issues.
- Assessment of stakeholder engagement activities.

**Escalation Path:** Escalate unresolved issues to the Director of the Ministry of Science and Technology.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day project execution, operational risks, and decisions below strategic thresholds. Ensures efficient resource allocation and adherence to project plans.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets (below $50 million).
- Monitor project progress and report to the Project Steering Committee.
- Manage operational risks and implement mitigation strategies.
- Coordinate project activities across different research areas.
- Ensure compliance with project policies and procedures.
- Manage procurement and contract administration.

**Initial Setup Actions:**

- Establish project management processes and tools.
- Develop a communication plan.
- Define roles and responsibilities within the PMO.
- Set up project tracking and reporting systems.

**Membership:**

- Project Manager
- Lead Scientists from each research area
- Finance Manager
- Procurement Manager
- Risk Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation (below $50M), and risk management within established guidelines.

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the relevant PMO members. Unresolved issues escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of operational risks and mitigation strategies.
- Approval of budget requests below $50 million.
- Coordination of project activities.
- Review of project performance metrics.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides specialized assurance on ethical and compliance aspects, including dual-use concerns, biosafety, and regulatory requirements. Ensures adherence to ethical standards and relevant regulations (GDPR, biosecurity protocols).

**Responsibilities:**

- Review and approve research proposals from an ethical and compliance perspective.
- Assess the potential dual-use implications of research activities.
- Monitor compliance with biosafety protocols and regulatory requirements.
- Investigate ethical breaches and compliance violations.
- Develop and implement ethical guidelines and training programs.
- Ensure compliance with GDPR and other relevant data privacy regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish ethical review processes and guidelines.
- Develop a compliance monitoring plan.
- Set up a reporting mechanism for ethical breaches and compliance violations.

**Membership:**

- Independent Ethicist (External)
- Biosecurity Expert
- Legal Counsel
- Regulatory Affairs Manager
- Community Representative

**Decision Rights:** Decisions related to ethical approval of research proposals, compliance with regulations, and investigation of ethical breaches.

**Decision Mechanism:** Decisions made by majority vote, with the Independent Ethicist holding the tie-breaking vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research proposals for ethical and dual-use concerns.
- Discussion of compliance issues and regulatory updates.
- Investigation of ethical breaches and compliance violations.
- Review of ethical guidelines and training programs.
- Assessment of stakeholder concerns related to ethics and compliance.

**Escalation Path:** Escalate unresolved ethical or compliance issues to the Project Steering Committee and the Director of the Ministry of Science and Technology.
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical input and assurance on key project aspects, ensuring scientific rigor and feasibility. Addresses technical risks and challenges.

**Responsibilities:**

- Review and advise on technical aspects of the project, including experimental design, data analysis, and technology development.
- Assess the feasibility of achieving project goals and milestones.
- Identify and mitigate technical risks.
- Provide guidance on the selection and use of appropriate technologies.
- Evaluate the performance of research teams and provide feedback.
- Ensure scientific rigor and reproducibility of research findings.

**Initial Setup Actions:**

- Finalize Terms of Reference and membership.
- Establish technical review processes and guidelines.
- Develop a risk assessment framework for technical challenges.
- Set up a communication channel for technical advice and feedback.

**Membership:**

- Leading Experts in Synthetic Biology (External)
- Experts in Chirality and Molecular Biology (External)
- Senior Scientists from the Project
- Data Science Expert
- BSL-4 Lab Director

**Decision Rights:** Provides recommendations on technical aspects of the project. The Project Manager has the final decision, considering the TAG's advice.

**Decision Mechanism:** Consensus-based recommendations. If consensus cannot be reached, dissenting opinions are documented and presented to the Project Manager.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of research progress and technical challenges.
- Discussion of experimental design and data analysis.
- Assessment of technology development and innovation.
- Identification and mitigation of technical risks.
- Evaluation of research team performance.

**Escalation Path:** Escalate unresolved technical issues to the Project Steering Committee.