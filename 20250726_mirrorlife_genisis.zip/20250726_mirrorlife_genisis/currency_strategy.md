This plan involves money.

## Currencies

- **CNY:** Local currency for operational expenses within China.
- **USD:** Used for the overall budget and potentially for international procurement and reporting, given the project's scale and international implications.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. CNY will be used for local transactions. Given the project's scale, hedging strategies against exchange rate fluctuations should be considered.