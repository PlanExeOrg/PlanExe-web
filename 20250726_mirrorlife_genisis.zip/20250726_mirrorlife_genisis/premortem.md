A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The existing BSL-4+ lab near Beijing is suitable for D-chiral life research with necessary upgrades. | Conduct a thorough assessment of the lab's infrastructure and containment capabilities, engaging BSL-4 lab design consultants. | The assessment reveals critical infrastructure limitations requiring a new facility construction. |
| A2 | The Chinese government will continue to provide financial and political support for the duration of the project. | Schedule a formal meeting with relevant government agencies (MOST, NHC) to discuss regulatory requirements and secure written confirmation of support and timelines. | Government representatives express uncertainty about long-term funding commitments or indicate a shift in priorities. |
| A3 | Effective containment strategies can be implemented to prevent unintended release of synthetic lifeforms. | Conduct rigorous testing and simulation of containment systems, engaging biosecurity experts. | Testing and simulation reveal significant vulnerabilities in the containment systems, with a high probability of breaches under certain conditions. |
| A4 | The project team possesses sufficient expertise in all relevant scientific and engineering disciplines. | Conduct a skills gap analysis of the project team, comparing current expertise with required competencies. | The analysis reveals critical skill gaps in areas such as advanced genetic engineering, D-chiral chemistry, or BSL-4+ lab operations. |
| A5 | The supply chain for critical materials and equipment will remain stable and reliable throughout the project's duration. | Conduct a thorough risk assessment of the supply chain, identifying potential vulnerabilities and alternative suppliers. | The assessment reveals significant dependencies on single suppliers or geopolitical risks that could disrupt the supply of critical materials. |
| A6 | The synthetic D-chiral lifeforms will exhibit predictable and controllable behavior within the BSL-4+ lab environment. | Conduct extensive simulations and in vitro experiments to model the behavior of the synthetic organisms under various conditions. | Simulations and experiments reveal unexpected or unpredictable behavior patterns, such as rapid mutation rates or the ability to circumvent containment measures. |
| A7 | The project's intellectual property strategy will effectively secure a national advantage without hindering international collaboration. | Conduct a legal review of the IP strategy, assessing its potential impact on collaboration with international research institutions. | The review concludes that the IP strategy is overly restrictive, deterring potential international partners and limiting access to external expertise. |
| A8 | The project team will maintain a high level of internal cohesion and collaboration throughout the project's duration. | Conduct regular team climate surveys and monitor communication patterns to assess team cohesion and collaboration. | Surveys and communication analysis reveal significant internal conflicts, communication breakdowns, or a lack of shared vision among team members. |
| A9 | The chosen de novo synthesis pathway will prove scalable and cost-effective for producing the required quantities of D-chiral biomolecules. | Conduct a detailed cost analysis and scalability assessment of the chosen synthesis pathway, considering potential bottlenecks and resource constraints. | The assessment reveals that the synthesis pathway is prohibitively expensive or difficult to scale up to the required production levels. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Funding Faucet Failure | Process/Financial | A2 | Project Manager | CRITICAL (20/25) |
| FM2 | The Containment Catastrophe | Technical/Logistical | A1 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Public Pariah Project | Market/Human | A3 | Public Relations Director | CRITICAL (15/25) |
| FM4 | The Expertise Erosion | Process/Financial | A4 | Project Manager | CRITICAL (20/25) |
| FM5 | The Supply Chain Strangling | Technical/Logistical | A5 | Head of Procurement | CRITICAL (15/25) |
| FM6 | The Uncontrollable Creation | Market/Human | A6 | Lead Synthetic Biologist | CRITICAL (15/25) |
| FM7 | The Innovation Island | Market/Human | A7 | Head of External Affairs | CRITICAL (20/25) |
| FM8 | The Team Tempest | Process/Financial | A8 | Project Manager | CRITICAL (15/25) |
| FM9 | The Synthesis Stalemate | Technical/Logistical | A9 | Head of Engineering | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Funding Faucet Failure

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial viability hinges on sustained government funding. A sudden shift in political priorities or economic downturn could lead to drastic budget cuts. This would halt research, strand ongoing experiments, and render the initial USD 2 billion investment worthless. Key personnel would be laid off, and the BSL-4+ lab would sit idle, a monument to unrealized ambition. The project would become a cautionary tale of over-reliance on a single funding source.

##### Early Warning Signs
- Public statements from government officials expressing concerns about the project's cost or strategic value
- Delays in scheduled funding disbursements
- Increased scrutiny of project expenses by government auditors

##### Tripwires
- Government funding reduced by >= 20% in a single fiscal year
- Project budget audit reveals significant cost overruns exceeding 15%
- Key government sponsor of the project is replaced or reassigned

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and initiate a cost-cutting review.
- Assess: Conduct a thorough financial audit to identify areas for cost reduction and explore alternative funding sources.
- Respond: Lobby government officials to reinstate funding, seek private investment, or scale down the project scope.


**STOP RULE:** Government funding is reduced by >= 50% and no alternative funding sources can be secured within 6 months.

---

#### FM2 - The Containment Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The existing BSL-4+ lab, initially deemed suitable, proves inadequate for containing the synthetic D-chiral lifeforms. The aging infrastructure suffers a critical failure – a breach in the air filtration system, a crack in the sealed containment chamber, or a malfunction in the sterilization equipment. This leads to the accidental release of the synthetic organisms into the environment. The organisms, though designed with kill switches, prove more resilient than anticipated, adapting to the external environment and beginning to interact with native L-chiral life. The ecological consequences are devastating, triggering a cascade of unforeseen effects and potentially irreversible damage.

##### Early Warning Signs
- Increased frequency of equipment malfunctions in the BSL-4+ lab
- Detection of trace amounts of D-chiral molecules outside the primary containment zone
- Elevated levels of unexplained microbial activity in the lab's wastewater treatment system

##### Tripwires
- Air filtration system efficiency drops below 99.97%
- Containment chamber pressure fluctuates by >= 5% outside normal operating range
- Sterilization equipment fails to reach required temperature for >= 2 consecutive cycles

##### Response Playbook
- Contain: Immediately activate emergency containment protocols and seal off the affected area.
- Assess: Conduct a thorough investigation to determine the extent of the breach and the potential environmental impact.
- Respond: Deploy specialized decontamination teams and implement a comprehensive environmental monitoring program.


**STOP RULE:** Uncontained release of synthetic organisms confirmed outside the BSL-4+ lab perimeter for >= 72 hours.

---

#### FM3 - The Public Pariah Project

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Relations Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Despite the project's emphasis on secrecy, news of the synthetic life research leaks to the international media. Public opposition erupts, fueled by fears of ecological disaster and the potential for weaponization. International regulatory bodies condemn the project, and governments impose sanctions. Scientists face harassment and threats. The project becomes a symbol of reckless scientific ambition, damaging the reputation of the researchers and the sponsoring nation. Public trust erodes, and the project is ultimately shut down due to overwhelming pressure.

##### Early Warning Signs
- Increased online chatter and social media activity expressing concerns about the project
- Organized protests and demonstrations near the BSL-4+ lab
- Critical articles and editorials in major international news outlets

##### Tripwires
- Online sentiment analysis shows >= 75% negative public opinion towards the project
- Protest attendance exceeds 1000 people for >= 3 consecutive days
- Major international news outlet publishes a front-page exposé critical of the project

##### Response Playbook
- Contain: Immediately launch a public relations campaign to address public concerns and communicate the project's benefits.
- Assess: Conduct a thorough public opinion survey to understand the root causes of the opposition.
- Respond: Increase transparency by releasing non-sensitive research findings, engage in open dialogue with the public, and address ethical concerns.


**STOP RULE:** International sanctions imposed due to lack of transparency and ethical concerns, coupled with sustained public opposition exceeding 80%.

---

#### FM4 - The Expertise Erosion

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project suffers from a critical lack of expertise in key areas, despite initial assessments. The team, while skilled in some aspects of synthetic biology, lacks deep knowledge of D-chiral chemistry, leading to inefficient synthesis pathways and unstable biomolecules. The BSL-4+ lab operations are hampered by a lack of experience in handling novel synthetic organisms, resulting in increased risk of contamination and safety breaches. The project stagnates, unable to overcome technical hurdles due to the expertise gap. The initial budget proves insufficient to hire the necessary experts, leading to further delays and cost overruns.

##### Early Warning Signs
- Frequent experimental failures and inconsistent results
- Inability to troubleshoot technical problems effectively
- Increased reliance on external consultants for basic tasks

##### Tripwires
- Project timeline delayed by >= 6 months due to technical challenges
- Consultant fees exceed 10% of the annual budget
- Key experimental milestones are missed for >= 2 consecutive quarters

##### Response Playbook
- Contain: Immediately conduct a skills gap analysis and identify areas where expertise is lacking.
- Assess: Develop a plan to acquire the necessary expertise through hiring, training, or collaboration.
- Respond: Allocate additional resources to training programs, recruit experienced scientists and engineers, or establish partnerships with external research institutions.


**STOP RULE:** Critical skill gaps remain unaddressed for >= 9 months, preventing progress on key experimental milestones.

---

#### FM5 - The Supply Chain Strangling

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Procurement
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's supply chain collapses due to unforeseen geopolitical events and trade restrictions. The specialized D-chiral precursors, sourced from a single supplier in a politically unstable region, become unavailable. The advanced genetic sequencing equipment, manufactured in a country facing export sanctions, cannot be delivered. The BSL-4+ lab's filtration system, reliant on imported components, breaks down, and replacement parts are impossible to obtain. The project grinds to a halt, unable to procure the necessary materials and equipment. The synthetic lifeforms, starved of essential nutrients, die off, and years of research are lost.

##### Early Warning Signs
- Increasing lead times for critical materials and equipment
- Price spikes for essential supplies
- Geopolitical instability in key sourcing regions

##### Tripwires
- Critical material lead times exceed 12 months
- Supplier declares force majeure due to unforeseen circumstances
- Export licenses for essential equipment are denied

##### Response Playbook
- Contain: Immediately identify alternative suppliers and explore domestic sourcing options.
- Assess: Conduct a thorough inventory of existing supplies and prioritize their use for critical experiments.
- Respond: Redesign experiments to minimize reliance on scarce materials, develop alternative synthesis pathways, or explore collaborations with research institutions that have access to the necessary resources.


**STOP RULE:** Critical materials and equipment remain unavailable for >= 12 months, preventing progress on key experimental milestones.

---

#### FM6 - The Uncontrollable Creation

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Lead Synthetic Biologist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The synthetic D-chiral lifeforms, initially believed to be predictable and controllable, exhibit unexpected and alarming behavior within the BSL-4+ lab. They mutate rapidly, evolving resistance to the kill switches and containment measures. They develop novel metabolic pathways, consuming unexpected resources and producing unforeseen byproducts. They exhibit a surprising ability to communicate and coordinate their actions, forming a complex and unpredictable ecosystem within the lab. The researchers struggle to understand and control these emergent properties, leading to increased risk of containment breaches and ethical dilemmas. Public fear intensifies as the project is perceived as creating something beyond human control.

##### Early Warning Signs
- Rapid mutation rates observed in the synthetic organisms
- Emergence of novel metabolic pathways and unexpected byproducts
- Evidence of communication and coordination between individual organisms

##### Tripwires
- Kill switch effectiveness drops below 50%
- Unexplained metabolic activity detected outside the intended pathways
- Evidence of coordinated behavior among the synthetic organisms

##### Response Playbook
- Contain: Immediately implement enhanced containment measures and reinforce kill switch mechanisms.
- Assess: Conduct a thorough investigation to understand the underlying mechanisms driving the unpredictable behavior.
- Respond: Redesign the synthetic organisms to reduce their adaptability and complexity, explore alternative containment strategies, or consider terminating the project.


**STOP RULE:** The synthetic organisms exhibit uncontrollable behavior that poses a significant threat to containment and ethical boundaries, as determined by the Ethics Review Board.

---

#### FM7 - The Innovation Island

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Head of External Affairs
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's aggressive intellectual property strategy backfires, creating an 'innovation island' where collaboration with international researchers becomes impossible. The stringent patenting approach deters potential partners, limiting access to external expertise and hindering the cross-pollination of ideas. The project becomes isolated, unable to leverage the global scientific community's knowledge and resources. Innovation stagnates, and the project falls behind international competitors who embrace open collaboration. The initial goal of securing a national advantage is undermined by the project's self-imposed isolation.

##### Early Warning Signs
- Decreased interest from international researchers in collaborating on the project
- Rejection of collaboration proposals from leading international institutions
- Increased difficulty in publishing research findings in high-impact international journals

##### Tripwires
- Number of international collaboration proposals decreases by >= 50% year-over-year
- Project is excluded from >= 3 major international scientific conferences
- Patent applications are challenged by international research institutions

##### Response Playbook
- Contain: Immediately reassess the intellectual property strategy and identify areas where collaboration can be facilitated without compromising core national interests.
- Assess: Conduct a survey of international researchers to understand their concerns about the project's IP strategy.
- Respond: Establish a collaborative research program with select international institutions, offering access to certain technologies and data in exchange for expertise and resources.


**STOP RULE:** The project is unable to secure any meaningful international collaborations within 2 years, despite repeated attempts to revise the IP strategy.

---

#### FM8 - The Team Tempest

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Internal conflicts and communication breakdowns cripple the project team. The lead synthetic biologist clashes with the BSL-4+ lab manager over safety protocols, leading to delays and increased risk of breaches. The ethics review board becomes paralyzed by disagreements over dual-use concerns, delaying critical research approvals. The project manager struggles to coordinate the increasingly fractured team, resulting in missed deadlines and budget overruns. The lack of cohesion undermines the project's efficiency and effectiveness, jeopardizing its long-term success.

##### Early Warning Signs
- Increased frequency of internal disputes and disagreements
- Decreased participation in team meetings and collaborative activities
- Elevated levels of stress and burnout among team members

##### Tripwires
- Team climate survey reveals a satisfaction score below 3.0 out of 5.0
- Number of internal disputes requiring mediation increases by >= 50% quarter-over-quarter
- Project timeline delayed by >= 3 months due to internal conflicts

##### Response Playbook
- Contain: Immediately implement conflict resolution mechanisms and team-building activities.
- Assess: Conduct individual interviews with team members to understand the root causes of the conflicts.
- Respond: Reassign roles and responsibilities to better align with individual strengths and preferences, provide leadership training to key personnel, or consider replacing team members who are consistently disruptive.


**STOP RULE:** Internal conflicts persist for >= 6 months despite repeated attempts at resolution, preventing progress on key project milestones.

---

#### FM9 - The Synthesis Stalemate

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The chosen de novo synthesis pathway proves to be a logistical and financial nightmare. The required D-chiral precursors are incredibly expensive and difficult to obtain, driving up the cost of biomolecule production. The synthesis process is inefficient and yields low quantities of the desired products, creating a bottleneck in the assembly of synthetic lifeforms. Scaling up the pathway proves impossible due to technical limitations and resource constraints. The project is unable to produce the necessary quantities of D-chiral biomolecules, halting progress and jeopardizing the entire initiative.

##### Early Warning Signs
- Significant cost overruns in biomolecule synthesis
- Low yields and inconsistent results in the synthesis process
- Inability to scale up the synthesis pathway to meet project demands

##### Tripwires
- Cost of D-chiral biomolecule synthesis exceeds budget by >= 50%
- Synthesis yield remains below 10% despite optimization efforts
- Attempts to scale up the synthesis pathway fail to achieve the required production levels

##### Response Playbook
- Contain: Immediately explore alternative synthesis pathways and identify potential cost-saving measures.
- Assess: Conduct a thorough analysis of the chosen pathway to identify bottlenecks and inefficiencies.
- Respond: Invest in research to develop more efficient synthesis methods, explore alternative sourcing options for D-chiral precursors, or consider redesigning the synthetic lifeforms to reduce their reliance on scarce biomolecules.


**STOP RULE:** A viable and cost-effective synthesis pathway cannot be identified within 1 year, preventing the production of sufficient quantities of D-chiral biomolecules.
