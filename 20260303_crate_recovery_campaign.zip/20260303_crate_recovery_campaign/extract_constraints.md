## Positive Constraints

- Campaign must focus on Arla Foods, Denmark's largest dairy cooperative
- Campaign aims to recover lost green plastic milk crates
- Campaign must run nationwide throughout 2026
- Behavioural nudge: donate five Danish kroner (DKK) to Arla Foundation for every crate handed back
- Arla Foundation funds children's nutrition education programmes across Denmark
- Return channel 1: consumers can drop off crates at participating supermarket chains
- Return channel 2: consumers can drop off crates at Denmark's network of municipal recycling stations (genbrugsstationer)
- Logistics must handle collection, inspection, cleaning, and reintroduction of returned crates
- Damaged crates must be routed to plastics recycling
- Programme must define clear visual identification guidance for Arla crates
- Supermarkets require simple in-store procedures: signage, a designated drop-off point, and a lightweight count-and-report mechanism
- Recycling stations require low-friction intake instructions
- Stakeholders include Arla Foods, Arla Foundation, major Danish supermarket groups (Salling Group, Coop Danmark, Rema 1000), municipal waste authorities, and the Danish public
- Marketing message should emphasize environmental upside (CO2 reduction) and charitable angle (children's nutrition)
- Social media virality and earned press coverage are explicit goals
- Paid media should be supplementary rather than primary
- Total programme budget ceiling of 4 million DKK
- Campaign concept and logistics design by end of Q1 2026
- Pilot launch in select regions during Q2 2026
- Nationwide rollout from Q3 through end of 2026
- Success criterion: recover at least 40% of the annual loss volume (108,000 crates) in year one
- Success criterion: achieve measurable reduction in new-crate production orders for 2027
- Success criterion: generate at least 20 million organic social media impressions
- Success criterion: donate a minimum of 500,000 DKK to Arla Foundation
- Project start ASAP
- Pick a realistic, low-risk scenario

## Negative Constraints

- Avoid burdening supermarket staff
- Avoid disrupting normal supermarket operations
- Do not use blockchain
- Do not use NFT
- Do not use AI
- Do not use VR
- Do not use AR
