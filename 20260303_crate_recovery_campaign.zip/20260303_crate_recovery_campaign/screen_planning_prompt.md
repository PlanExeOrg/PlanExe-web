**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a highly detailed, concrete, and actionable project (a nationwide crate return campaign) with specific stakeholder groups, financial constraints (budget ceiling of 4M DKK), a clear timeline (Q1-Q4 2026), measurable success criteria (40% recovery, 108,000 crates), and specific logistical requirements.