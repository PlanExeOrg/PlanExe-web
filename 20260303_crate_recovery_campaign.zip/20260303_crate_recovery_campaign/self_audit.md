Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the checklist item specifically excludes non-physics laws. The plan details financial decisions, logistics, and marketing, none of which require violating fundamental physics. "The core tension managed is balancing aggressive consumer incentive spend against logistical processing speeds."

**Mitigation**: N/A


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on multiple untested, novel combinations without independent precedent at scale: an aggressive charity-based incentive linked to a high-risk viral marketing campaign and a dual-channel physical logistics network. "Success hinges on maximizing the perceived value of the donation to drive crucial initial inertia, while ensuring the logistic chain can absorb the resulting throughput."

**Mitigation**: Executive Steering Committee: Establish three parallel validation tracks (Marketing Tone Vetting, CPRC Pilot Analysis, QA Protocol Audit) with hard NO-GO decision gates by July 31, 2026. Owner: Project Director.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because multiple strategic concepts are poorly defined regarding their mechanism-of-action (MoA) or owner/metrics. Decision 9, 'Campaign Virality Mechanism Focus,' is intended to hit 20M organic impressions but lacks a clear MoA separating paid vs. organic levers in its choice description. Decision 11's 'Post-Campaign Asset Utilization Horizon' lacks an owner for the 100% reuse choice. "This project is a time-boxed, medium-to-high complexity, dual-channel reverse logistics effort, driven by strong environmental and CSR goals."

**Mitigation**: Project Director: Assign owners to author MoA one-pagers for Decisions 9 and 11, detailing success metrics and decision hooks, due by end of Q1 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the selection of the 'Pioneer' strategy deliberately maximizes consumer incentives and marketing risk, creating critical second-order financial and reputational threats not fully accounted for in planning. "Setting the incentive too low risks failing the volume target, while a high fixed incentive rapidly consumes the operational budget."

**Mitigation**: Financial Controller & Behavior Strategist: Proactively define and communicate the hard date (Oct 1, 2026) for incentive deceleration to 3 DKK to prevent premature budget exhaustion.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits multiple timeline risks by adopting the 'Pioneer' strategy without securing authoritative lead times for critical external commitments. The 'Permits and Licenses' section mentions necessary environmental permits, but the WBS (Task 3.1) rightly flags dependence on legal finalization of municipal SLAs by Q1 end, which is a major predecessor risk. No schedule buffer is noted to account for typical bureaucratic/political delays in Danish municipal agreements, violating criteria (b) and (c).

**Mitigation**: Regulatory & Compliance Officer: Escalate municipal SLA finalization to mandatory executive review by March 15, 2026, with contingency plan ready to redirect funding if liability transfer deadline is missed.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan lacks essential committed evidence required by the rubric: committed sources, term sheets, concrete financing gates, or covenants are undefined. The plan relies on a fixed 4 Million DKK ceiling. "Budget is constrained to 4 Million DKK." "Donation fund commitment of up to 1,350,000 DKK for consumer incentives."

**Mitigation**: Financial Controller & Budget Owner: Produce a dated financing plan detailing committed funding milestones, draw schedules, binding covenants, and required contingency NO-GO gates by April 30, 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly selects the 'Pioneer' strategy, which maximizes the 5 DKK incentive and accepts the highest logistical complexity without providing the required normalization or substantiating quotes/benchmarks. The plan lacks normalized cost per area or vendor quotes. "Budget is constrained to 4 Million DKK." "If logistics consume >60% of non-donation budget (2.65M DKK), project net environmental cost remains high."

**Mitigation**: Reverse Logistics Manager & Financial Controller: Immediately execute Data Collection Item 1 analysis to derive validated Cost Per Recovered Crate (CPRC) per channel variance before Q3 rollout.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exclusively presents the 'Pioneer: Aggressive Volume Capture' strategy based on maximizing the 5 DKK incentive, lacking any explicit best/worst case analysis for the primary volume driver. The WBS and Risk sections identify budget exhaustion as CRITICAL, but the plan relies on a reactive mitigation after the fact rather than proactive scenario definition. "Anchor the financial incentive at the maximum feasible level (5 DKK) to aggressively pursue the 40% return goal."

**Mitigation**: Consumer Behavior & Incentive Strategist: Deliver a formal sensitivity analysis by March 31, 2026, modeling total volume recovery under 3 DKK and 0 DKK incentives against established recovery curves.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Pioneer' path selects the most complex implementation for build-critical components, yet the necessary engineering artifacts are largely absent. The plan mentions needing a 'lightweight mobile application' and 'digital validation tool' but offers no interface contracts or acceptance criteria for these. "Requires complex two-channel reverse logistics network... Involves physical handling: collection, transport, inspection, cleaning, reintroduction."

**Mitigation**: IT/Data Integration Specialist: Deliver interface contracts and acceptance test plans for the mobile counting application and the quality triage validation tool by April 15, 2026.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical external evidence is missing across mandates, partnerships, and performance metrics. Specifically, the plan lacks commitment artifacts for the critical retail partnerships and the municipal agreements central to channel operations. **Cite:** "Secure operational agreements and physical space for collection points at major supermarket chains (Q1 start)." The required legal indemnity agreements and marketing sign-offs are not verified as obtained.

**Mitigation**: Regulatory & Compliance Officer: Secure legally binding, fully executed indemnity agreements with Tier 1 municipal waste authorities by April 15, 2026. Owner: Regulatory & Compliance Officer.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "Post-Campaign Asset Utilization Horizon" (Decision 11) is defined abstractly, trading short-term velocity against secondary goodwill without explicit measurable criteria. "Success is measured by the speed of CO2 metric realization versus the tangible, positive secondary messaging generated by supporting Arla Foundation community projects."

**Mitigation**: Reverse Logistics Manager: Define SMART criteria for Decision 11, including a KPI for asset velocity (e.g., 90% reintroduction within 72 hours) by end of Q2 2026.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Pioneer' strategy heavily favors Decision 5, Choice 2 ('slightly irreverent marketing narrative') which directly risks backlash from key partners (Supermarkets) required for logistics. The plan requires external sign-off, but no evidence exists that this vetting process is contractually mandated outside of general stakeholder risk mitigation. Core Goal Context: Achieve 40% recovery (volume) and 20M organic impressions (awareness).

**Mitigation**: CSR Communications Lead: Secure immediate written sign-off from all three major supermarket groups on the 'irreverent' creative concepts by March 31, 2026, or pivot the primary creative.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mandates the 'Pioneer' strategy hinges on the 'CSR Communications & Virality Lead' who must deliver 20M organic impressions using a high-risk, 'slightly irreverent marketing narrative.' Finding talent with proven success in generating massive viral reach *while* maintaining brand integrity in a CSR context is mission-critical and inherently rare. "Responsible for hitting the 20 million organic impression goal."

**Mitigation**: Executive Steering Committee: Mandate an immediate, third-party talent market validation report for the specialized 'CSR Communications & Virality Lead' role by March 31, 2026.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclearly mapped against critical dependencies on local Danish municipal authorities for waste stream integration, which is a known high-risk point. The plan requires finalized liability transfer agreements, but the status is simply 'Finalize SLAs' and no evidence of legal review is cited. "Finalize Service Level Agreements (SLAs) and liability transfer protocols with municipal waste authorities for recycling station integration (Q1 start)."

**Mitigation**: Regulatory & Compliance Officer: Secure fully executed, legally vetted liability transfer agreements with Tier 1 municipal waste authorities by April 15, 2026. Owner: Regulatory & Compliance Officer.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan fails to articulate the long-term funding/business model needed post-2026, conflicting with the need for sustained behavioral change. The exit strategy proposes phasing out incentives, but lacks a system to replace the financial nudge. "Missing 'killer app': Although the 5 DKK donation is a strong incentive, a dedicated mechanism to drive sustained, habitual returns post-campaign is not formalized." (SWOT Weakness)

**Mitigation**: Consumer Behavior Strategist: Develop and deliver the 'Crate Passport' framework design document, detailing the replacement loyalty mechanism for Q1 2027, by September 1, 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the success hinges on achieving complex, non-waivable local regulatory permissions for the municipal collection channel. The plan explicitly flags a RISK (Risk 4) that municipal agreements will delay Q3 rollout, and a critical dependency is the finalization of liability transfer agreements by Q1 end, which has no committed evidence in the document. "Finalize Service Level Agreements (SLAs) and liability transfer protocols with municipal waste authorities for recycling station integration (Q1 start)."

**Mitigation**: Regulatory & Compliance Officer: Secure fully executed, legally vetted liability transfer agreements with Tier 1 municipal waste authorities by April 15, 2026. Owner: Regulatory & Compliance Officer.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on dual, unproven reverse logistics streams (supermarket and municipal) during the national rollout (Q3/Q4) but only pilots the supermarket channel in Q2, creating a dependency on the municipal channel without tested fallback. "Prioritizing one channel concentrates recovery efficiency but introduces single points of failure regarding consumer access or logistical bottlenecking if volumes spike unevenly."

**Mitigation**: Reverse Logistics Manager: Force inclusion of Tier 1 municipal collection sites into the Q2 pilot immediately to test channel cost viability and quality variance before Q3 commitment.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Pioneer strategy selects the 'Finance Department' incentive (budget adherence/fixed ceiling) versus the 'R&D/CSR' incentive (volume capture/viral reach). The choice of the max 5 DKK donation risks exceeding the 4M DKK budget ceiling by prioritizing volume over fiscal conservatism. "Anchor the financial incentive at the maximum feasible level (5 DKK) to aggressively pursue the 40% return goal."

**Mitigation**: Consumer Behavior Strategist & Financial Controller: Create a shared OKR mandating that incentive spend vs. volume return rate stabilizes at 3 DKK/crate by October 1, 2026.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks concrete mechanisms for feedback, review cadence, owners, and thresholds for re-planning/stopping. The risk mitigation sections mention monitoring, but no specific cadence or governance structure details this process. The plan omits explicit governance artifacts necessary for dynamic control.

**Mitigation**: Project Director: Establish a mandatory Monthly Governance Review cadence, led by the Project Director, requiring KPI dashboards and a documented change-control board for threshold breaches by April 30, 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan implicitly couples the aggressive Incentive Structure (Decision 1: high 5 DKK spend) with a high-risk Promotional Posture (Decision 5: irreverent marketing) which is explicitly flagged as conflicting with Supermarket Partner Leverage (Decision 13). This strong coupling means failure in marketing tone pre-approval (FM3) will directly cripple compliance on the primary collection channel, stopping the flow that justifies the high incentive spend, causing dual-domain failure. "Setting the incentive too high accelerates budget burn... [and] rapidly strains the budget, thus constraining the resources available for funding Supermarket Partner Co-Branding Leverage."

**Mitigation**: Project Director: Mandate joint sign-off by CSR Comms Lead and Stakeholder Relations Coordinator on all Q3 marketing creative approvals by March 31, 2026, enforcing a combined GO/NO-GO heat map.