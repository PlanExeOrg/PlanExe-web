## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers (Critical and High) center on solving the fundamental tension between **Logistical Friction vs. Public Engagement**. Critical levers govern the physical reality: Channel Priority, Quality Assurance, and Identification Accuracy. High levers govern the fuel needed to drive participation: Incentive value and Narrative strength. Together, these address the core conflicts of Cost vs. Reach and Operational Complexity vs. Consumer Convenience, ensuring the physical infrastructure can handle returns driven by compelling public motivation.

### Decision 1: Return Channel Priority and Infrastructure Load
**Lever ID:** `faf16ad7-0cb8-4c7e-be22-e473a6682677`

**The Core Decision:** This lever controls the primary method and physical pathway for consumers to return crates, directly impacting accessibility, logistical complexity, and overall return volume. Prioritizing supermarket collection leverages existing Arla delivery infrastructure but risks logistical saturation and inconvenience for staff. Conversely, utilizing municipal stations offers higher material handling capacity but relies on lower visibility and consumer motivation. Success is measured by the distribution of returned crates across channels and the resulting cost-per-return associated with each path.

**Why It Matters:** Determining the primary collection pathway dictates logistical complexity, cleaning requirements, and stakeholder dependency across retail vs. municipal channels.

**Strategic Choices:**

1. Prioritize supermarket collection exclusively for the pilot and Q3 rollout, utilizing Arla's existing delivery routes for reverse logistics, accepting the risk of logistical saturation in high-volume stores.
2. Establish a 60/40 split, driving 60% of volume through municipal recycling stations (which are equipped for handling large volumes of mixed materials) and using supermarkets only for low-volume, high-visibility returns.
3. Implement mobile, temporary 'Crate Reclamation Hubs' in 20 strategically selected, high-density urban areas for 8 weeks each, bypassing fixed infrastructure entirely to maximize immediate, high-volume recovery.

**Trade-Off / Risk:** Controls Logistical Friction vs. Collection Reach. Weakness: Option 3 introduces significant short-term, localized operational overhead and requires rapid site negotiation, potentially exceeding the low-risk mandate.

**Strategic Connections:**

**Synergy:** It strongly synergizes with 'Stakeholder Integration Depth (Supermarkets)' by defining the required operational load on retail partners. Prioritizing supermarket routes amplifies the need for robust supermarket involvement and standardized procedures defined by that lever.

**Conflict:** Directly conflicts with 'Logistics & Quality Assurance Modality' because high reliance on existing Arla delivery routes (supermarket focus) increases the risk of overloading cleaning/inspection capacity if return volumes spike unexpectedly, demanding a more resource-intensive QA setup.

**Justification:** *Critical*, This lever defines the core delivery mechanism for achieving the return goal. It controls the logistical friction and capacity planning across the entire partner network, directly dictating operational costs and the feasibility of high-volume returns across both supermarket and municipal channels.

### Decision 2: Stakeholder Integration Depth (Supermarkets)
**Lever ID:** `2521888c-0984-4ee2-971f-6d0b27446b90`

**The Core Decision:** This lever dictates the depth of operational involvement and the nature of incentives offered to supermarket chains, a critical distribution and collection partner. The objective is to achieve high compliance and seamless integration without creating significant operational burden or staff resentment. Success metrics include the reported adherence to in-store procedures, the percentage of supermarkets actively participating, and staff feedback on the simplicity of the drop-off and reporting mechanism.

**Why It Matters:** Immediate: Employee compliance impacts drop-off friction and consumer experience → Systemic: Poor in-store processes lead to low return rates in high-traffic retail locations → Strategic: Long-term partnership cohesion for future CSR initiatives is either strengthened or fundamentally broken based on 2026 performance.

**Strategic Choices:**

1. Mandate standardized, pre-printed, tamper-evident collection bins and a single, mandatory 10-minute staff training video for all participating stores, ensuring high process consistency at the expense of staff time.
2. Provide a small, direct operational subsidy (e.g., 50 DKK per week) only to stores exceeding 100 returns per month, focusing incentives on high-performing partners while reducing obligations for smaller outlets.
3. Develop a gamified, real-time internal leaderboard for supermarket chains based on return volume and cleanliness scores, publicly recognizing the winning chain during campaign wrap-up events to drive internal competition.

**Trade-Off / Risk:** Controls Partner Burden vs. Operational Standardization. Weakness: None of the options proactively mitigate the risk of supermarket staff prioritizing customer checkout flow over managing the temporary crate drop-off area.

**Strategic Connections:**

**Synergy:** Strong synergy exists with 'Return Channel Priority and Infrastructure Load' as the chosen integration depth directly dictates the required process complexity and capacity planning needed at supermarket drop-off points, particularly if they are prioritized for collection.

**Conflict:** Mandating high staff training and process consistency conflicts with keeping operational overhead low, potentially antagonizing store managers. This creates tension with the overall goal of frictionless consumer access, which relies on staff cooperation facilitated by 'Consumer Identification and Trust Building'.

**Justification:** *High*, Supermarkets are essential drop-off points. The depth of integration determines staff burden and process compliance, which directly impacts consumer experience and failure rates at high-traffic locations. This governs the success of the primary collection channel.

### Decision 3: Consumer Identification and Trust Building
**Lever ID:** `cb1ff12f-d47b-4a1b-bbc5-4fd030a40e6b`

**The Core Decision:** This strategy focuses on solving the critical issue of preventing consumers from returning non-Arla green crates or damaged units that cannot be reused. The goal is to establish clear, immediate, and reliable visual identification guidance to minimize contamination of the returned stream and maintain the value of the logistics chain. Success is measured by the post-collection inspection failure rate and consumer confusion reported via feedback channels.

**Why It Matters:** Immediate: Clear identification reduces contamination of the return stream with third-party plastics → Systemic: Inaccurate identification leads to higher sorting costs at recycling stations → Strategic: The campaign's ability to generate positive earned media hinges on a universally understood, culturally resonant rejection of illegitimate returns.

**Strategic Choices:**

1. Issue a high-contrast, temporary adhesive seal (e.g., a yellow, numbered sticker) on all Arla crates leaving the dairy in January 2026, which must still be present upon return to qualify for the donation.
2. Leverage the 'iconic green' by launching a social media-led comparative visual guide showing three deliberate photoshopped comparisons: 'Arla Crate (Keep)', 'Similar Crate (Recycle)', and 'Damaged Crate (Recycle)', driven by visual influencer outreach.
3. Partner with the Danish postal service (PostNord) to briefly utilize their delivery network, placing small, QR-coded informational tags on mailboxes in test regions that link directly to a multimedia verification tool for crate recognition.

**Trade-Off / Risk:** Controls Visibility/Trust vs. Implementation Complexity. Weakness: The radical option involving the postal service introduces an external, low-control variable (mailbox tagging) into the consumer awareness funnel.

**Strategic Connections:**

**Synergy:** This lever is essential for 'Logistics & Quality Assurance Modality' by reducing the volume requiring downstream triage (recycling vs. cleaning). Clear identification also reinforces the marketing message established by 'Public Narrative Strategy' by giving consumers a concrete action step.

**Conflict:** Implementing a complex marking system (like temporary seals) adds cost and complexity to the initial Arla dispatch process, potentially conflicting with the cost constraints of the overall budget ceiling. It also risks creating confusion if the identification method itself is not immediately intuitive, contrasting with simple messaging from 'Marketing Narrative Dominance'.

**Justification:** *Critical*, Solving contamination risk through clear identification is foundational to the logistics viability. If consumers return the wrong items, the entire downstream cleaning and reuse process fails, negating the environmental and cost benefits of the return effort.

### Decision 4: Marketing Narrative Dominance
**Lever ID:** `633862b8-ae28-472a-846d-6e05e3bb57af`

**The Core Decision:** This lever defines the core emotional and informational theme used throughout the campaign to motivate participation. It controls whether the focus is primarily environmental (CO2), charitable (Foundation funding), or driven by cultural shock/humor. The primary objective is maximizing earned media and social impressions while driving behavior change. Success is quantified by the organic social media impressions and the tone/reach of press coverage achieved during the rollout phase.

**Why It Matters:** Immediate: Message framing dictates public emotional response (humor vs. seriousness) → Systemic: Overemphasis on charity might overshadow the environmental goal, leading to success criteria focused only on DKK raised → Strategic: Determines the long-term brand perception of Arla's commitment relative to transient social trends.

**Strategic Choices:**

1. Focus the primary messaging exclusively on the societal good: 'Feed a Child, Save a Crate,' positioning the 5 DKK donation as the main driver and downplaying the 106-tonne CO2 reduction metric.
2. Adopt a provocative, counter-intuitive narrative: 'Your Garden Furniture is Costing Denmark CO2,' using humorous visuals of beloved but misplaced crates to spark conversation and secure earned media coverage.
3. Run a hyper-localized, time-limited communications blitz in one major Jutland city during Q2 pilot, utilizing geo-fenced digital ads and local print targeting nostalgic residents, treating the national campaign as a scaled optimization of this initial aggressive local test.

**Trade-Off / Risk:** Controls Narrative Focus vs. Scope Risk. Weakness: The conservative option risks failing the secondary success metric related to measurable CO2 reduction because the environmental incentive is deemphasized.

**Strategic Connections:**

**Synergy:** Aggressively provocative narratives create high potential for virality, strongly amplifying the engagement targeted by 'Incentive Structure Calibration.' Humor and surprise generate the attention necessary for the charitable appeal to land effectively.

**Conflict:** Focusing too heavily on a provocative, humorous visual angle can dilute the serious, dual CSR messages, potentially causing confusion with 'Public Narrative Strategy.' Furthermore, deep dives into aggressive local testing might deplete bandwidth needed for national coordination required by 'Stakeholder Integration Depth (Supermarkets)'.

**Justification:** *High*, This lever controls the project's ability to achieve the explicit goals of social media virality and earned press. Since paid media is supplementary, the narrative must be strong enough to drive organic impressions, which directly impacts one of the four core success criteria.

### Decision 5: Logistics & Quality Assurance Modality
**Lever ID:** `0992af24-1495-4878-ade1-b7c99e51e538`

**The Core Decision:** This lever dictates the core operational strategy for handling returned milk crates, covering collection, inspection, cleaning, and routing. The objective is to balance operational cost and efficiency against the convenience of the return infrastructure for consumers. Key metrics include the percentage of crates deemed fit for immediate reuse, the average cost per recovered crate, and the time elapsed between consumer drop-off and reintroduction into the supply chain. The chosen modality directly impacts required capital investment in temporary hubs or the operational load placed on existing supermarket and municipal partnerships.

**Why It Matters:** The chosen inspection/cleaning path dictates unit cost per re-introduced crate, defining pipeline speed and the overall material footprint reduction achievable within the defined operational window.

**Strategic Choices:**

1. Primary focus on supermarket partners for inspection/cleaning (leveraging existing Arla distribution network for transport), using recycling stations only for non-reusable material aggregation, minimizing deviation from established B2B routes.
2. Establish three centralized, temporary quality assessment hubs located near major population centers, requiring dedicated 3rd-party logistics contracts for consumer drop-off conveyance, optimizing cleaning efficiency at the expense of consumer drop-off convenience.
3. Pilot a crate-swap model where consumers receive a 5 DKK voucher immediately at participating supermarkets upon handing over a crate *and* placing a future Arla order, decoupling the deposit model from the cleaning cycle by accepting all crates for initial bulk processing.

**Trade-Off / Risk:** Controls Operational Standardization vs. Collection Diversity. Weakness: The options do not explicitly detail the contingency plan for handling large batches of contaminated or heavily misused crates identified during the centralized cleaning phase.

**Strategic Connections:**

**Synergy:** A streamlined modality focusing on supermarket partners heavily synergizes with **Stakeholder Integration Depth (Supermarkets)** by leveraging existing delivery routes. This minimizes logistical overhead and strengthens the supermarket partnership by embedding the return process directly into their existing Arla touchpoints.

**Conflict:** Prioritizing existing B2B routes conflicts with maximizing consumer convenience, potentially constraining returns if recycling stations are not fully utilized. This approach creates friction against **Return Channel Priority and Infrastructure Load**, as it forces recycling stations into a purely waste management role rather than a dual recovery channel.

**Justification:** *Critical*, This defines the efficiency and cost-per-unit of the entire physical reprocessing pipeline. It is the engine that realizes the CO2 reduction goal by ensuring crates are cleaned and returned to the supply chain, resolving the core cost/efficiency trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Incentive Structure Calibration
**Lever ID:** `82e82f30-0b5e-4a26-853a-024ca9578dc1`

**The Core Decision:** This controls the financial reward offered to the consumer for participation, which is directly linked to the maximum potential donation outflow (1.35M DKK). Calibrating this incentive balances the need for high return volumes against strict budgetary constraints. The objective is to hit the 40% recovery target cost-effectively. Success metrics are the volume of returns achieved relative to the total budget spent on incentives.

**Why It Matters:** Adjusting the charitable contribution rate directly modulates public motivation, impacting return volume versus total donation outlay, affecting CO2 reduction potential and Foundation funding.

**Strategic Choices:**

1. Anchor the donation at the fixed 5 DKK per crate, reserving budget flexibility for unexpected logistical spikes, prioritizing operational stability over increased participation rates.
2. Implement a tiered incentive: 5 DKK for the first 100,000 returned crates, stepping down to 3 DKK thereafter, balancing initial engagement drive with long-term cost management.
3. Introduce a matching gift program funded by external sustainability sponsors (leveraging DKK 1M from the budget for marketing), offering 10 DKK per crate for the first month to drive rapid initial adoption and virality.

**Trade-Off / Risk:** Controls Donation Value vs. Budget Constraint. Weakness: The options fail to adequately address the possibility that 5 DKK is insufficient to overcome the inconvenience barrier for many consumers, regardless of the initial surge.

**Strategic Connections:**

**Synergy:** A high incentive (e.g., a matching gift) creates immediate news value and drives rapid initial adoption, strongly supporting the engagement goals of 'Marketing Narrative Dominance.' This rapid initial volume builds positive momentum for the campaign.

**Conflict:** Increasing the incentive amount significantly directly strains the overall 4 Million DKK budget ceiling, potentially underfunding critical infrastructure investments required by 'Return Channel Priority and Infrastructure Load' or necessary marketing push.

**Justification:** *High*, This calibration directly controls public motivation and return volume relative to the budget ceiling (4M DKK). It is the primary lever for meeting the 40% return volume target while managing the 1.35M DKK donation cost component.

### Decision 7: Public Narrative Strategy
**Lever ID:** `740ed36c-aa0b-4728-938a-1bba7f856c4b`

**The Core Decision:** This lever defines the overall tone and focus of external communication, balancing messages between environmental impact, charitable giving, and cultural familiarity. The goal is to achieve high organic reach and engagement congruent with the project's primary communication goals. Success is measured by organic social media impressions, earned media mentions, and the perceived narrative framing (e.g., environmental vs. social good). The chosen strategy must cut through noise without significant paid media spend, relying on provocation or cultural resonance.

**Why It Matters:** The communication style dictates earned media uptake and the emotional resonance of the campaign, directly influencing the volume of organic impressions versus reliance on supplemental paid media spend.

**Strategic Choices:**

1. Emphasize the CO2 tonnage saved, framing the campaign as a critical component of Arla's mandated climate pledge, relying on authoritative environmental messaging familiar to established CSR audiences.
2. Launch a light-hearted 'Green Gold' user-generated content (UGC) drive, encouraging consumers to photograph the creative new uses for their found crates, positioning the initiative as a quirky national treasure hunt.
3. Utilize a 'Reverse Graffiti' campaign where the campaign message and donation call are temporarily revealed on dirty external urban surfaces near high-traffic areas using high-pressure water blasting, creating surprise and immediate photo/social media potential.

**Trade-Off / Risk:** Controls Message Seriousness vs. Virality Potential. Weakness: The 'Reverse Graffiti' option, while innovative, presents unpredictable local permitting risks and potential negative press if perceived as municipal vandalism, undermining the CSR credibility.

**Strategic Connections:**

**Synergy:** A light-hearted UGC drive fits perfectly with **Marketing Narrative Dominance**, generating viral content that reinforces the charitable angle (Arla Foundation). This visual, approachable content maximizes organic reach, a core success criterion for the overall campaign.

**Conflict:** Strategies emphasizing 'Reverse Graffiti' or high-shock value risk alienating one of the critical partners. This aggressive approach directly conflicts with **Stakeholder Integration Depth (Supermarkets)**, as retailers may reject association with potentially controversial or disruptive outdoor marketing activities.

**Justification:** *Medium*, While important for organic reach, this is largely covered by the synergy with Marketing Narrative Dominance (Lever 4). It is less critical than the operational levers (1, 3, 6) because its success is an amplification mechanism, rather than a fundamental enabler of the physical process or core funding.
