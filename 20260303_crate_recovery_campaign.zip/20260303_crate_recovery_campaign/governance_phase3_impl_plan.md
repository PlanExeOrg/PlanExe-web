### 1. Project Sponsor formally mandates the establishment of the governance structure defined in governance-phase2-bodies.json.

**Responsible Body/Role:** Arla Foods Executive Sponsor

**Suggested Timeframe:** Project Week 1 (Prior to Q1 March 31 deadline)

**Key Outputs/Deliverables:**

- Formal Project Mandate Letter
- Confirmation of initial PSC executive members

**Dependencies:**

- Project Charter Finalized

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating defined roles, decision thresholds (500k DKK spend limit), and reporting mandates.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Formal Project Mandate Letter Issued

### 3. Nominated PSC members review and provide feedback on the Draft PSC ToR and the confirmed 'Pioneer Strategy' selection.

**Responsible Body/Role:** Nominated PSC Members

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Consolidated Feedback Document on PSC ToR
- Initial Sign-off on Pioneer Strategy acceptance

**Dependencies:**

- Draft PSC ToR v0.1 Issued

### 4. PSC (chaired by Executive Sponsor) formally approves the final PSC ToR and confirms the full voting/advisory membership roster.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Formal PSC Membership Confirmation List

**Dependencies:**

- Consolidated Feedback Document Received

### 5. Project Manager drafts initial ToR for the Core Execution Team (CET) and Compliance & Stewardship Assurance Body (CSAB), ensuring alignment with PSC decision rights.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft CET ToR v0.1
- Draft CSAB ToR v0.1

**Dependencies:**

- Approved PSC ToR v1.0

### 6. PSC reviews and approves internal nomination/selection of members for the CET and CSAB, securing commitment from Legal, Audit, and Logistics leads.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Confirmed CET Membership List
- Confirmed CSAB Membership List

**Dependencies:**

- Draft CET ToR v0.1 and Draft CSAB ToR v0.1
- Confirmed PSC Membership List

### 7. CET and CSAB Chairs, in conjunction with the Project Manager, finalize and approve their respective Terms of Reference documents.

**Responsible Body/Role:** CET Chair and CSAB Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved CET ToR v1.0
- Approved CSAB ToR v1.0

**Dependencies:**

- Confirmed CET/CSAB Membership Lists

### 8. Project Manager finalizes the overall Governance Implementation Plan, incorporating all confirmed body structures, and distributes the fully ratified structure to all governance body members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6 (By end of Q1)

**Key Outputs/Deliverables:**

- Fully Ratified Governance Structure Document
- Kick-off meeting invitations sent to all committee members

**Dependencies:**

- Approved CET ToR v1.0
- Approved CSAB ToR v1.0

### 9. HOLD THE FIRST GOVERNANCE MEETING: Project Steering Committee (PSC) holds its inaugural meeting to formally ratify the Pioneer Strategy, budget allocation (post-donation cap), and confirm Q2 Pilot scope.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7 (Start of Q2)

**Key Outputs/Deliverables:**

- PSC Kick-off Meeting Minutes
- Official project launch approval memo
- Initial operational budget disbursement authorization

**Dependencies:**

- Fully Ratified Governance Structure Document

### 10. HOLD THE FIRST GOVERNANCE MEETING: Core Execution Team (CET) holds its kick-off meeting to establish daily tracking dashboards, confirm logistics protocols (aligning with Pioneer strategy for supermarket-only pilot), and assign initial infrastructure setup tasks.

**Responsible Body/Role:** Core Execution Team (CET)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- CET Kick-off Meeting Minutes
- Live Operational Dashboard v0.1
- Pilot Logistics Action Plan

**Dependencies:**

- PSC Kick-off Meeting Approval

### 11. HOLD THE FIRST GOVERNANCE MEETING: Compliance & Stewardship Assurance Body (CSAB) holds its initial session to define baseline compliance monitoring requirements, review the legal indemnity draft for municipalities (Risk 4 prep), and confirm the QA oversight plan for cleaning hubs (Assumption 3).

**Responsible Body/Role:** Compliance & Stewardship Assurance Body (CSAB)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- CSAB Kick-off Meeting Minutes
- Draft Compliance Monitoring Schedule for Q2 Pilot
- Initial QA Oversight Plan for third-party cleaning

**Dependencies:**

- CET Kick-off Meeting Confirmation

### 12. CET initiates coordination on all required MoUs, prioritizing the legal/commercial agreements with Supermarket Chains to facilitate the Q2 Pilot.

**Responsible Body/Role:** Lead Logistics Coordinator / Commercial Liaison (CET)

**Suggested Timeframe:** Project Weeks 8-10

**Key Outputs/Deliverables:**

- Signed Supermarket Partnership Frameworks
- Deployment plan for in-store signage (Decision 13)

**Dependencies:**

- PSC Kick-off Meeting Minutes
- Pilot Logistics Action Plan

### 13. CSAB reviews and signs off on the formal Compliance Monitoring Schedule for the upcoming pilot, ensuring clear reporting visibility to the PSC on donation reconciliation mechanisms.

**Responsible Body/Role:** Compliance & Stewardship Assurance Body (CSAB)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Finalized Q2 Compliance Monitoring Schedule
- Report on Initial Triage Liability Draft Review

**Dependencies:**

- CSAB Kick-off Meeting Minutes

### 14. CET finalizes procurement/contracting for third-party food-grade washing facilities, ensuring dynamic capacity scheduling capability is technically confirmed before Pilot launch.

**Responsible Body/Role:** Lead Logistics Coordinator (CET)

**Suggested Timeframe:** Project Week 12 (End of Q1)

**Key Outputs/Deliverables:**

- Signed Third-Party Cleaning Contracts (contingent on Q2 Pilot schedule)
- Confirmed capacity for 12,000 crates/week testing

**Dependencies:**

- PSC Approval of Pioneer Strategy
- Initial Q2 Pilot Logistics Plan