**Goal Statement:** Recover at least 40% of the annual loss volume (108,000 Arla green plastic milk crates) through the nationwide return campaign run throughout 2026, measured by crate volume recovered, CO2 reduction metrics, and successful transfer of 500,000 DKK to the Arla Foundation.

## SMART Criteria

- **Specific:** Successfully design, launch, pilot, and execute the nationwide crate return campaign utilizing supermarket and municipal collection channels, driven by a 5 DKK donation incentive, to reclaim lost Arla green plastic milk crates.
- **Measurable:** Achieve a minimum recovery volume of 108,000 crates, measurable reduction in 2027 new-crate production orders, generate at least 20 million organic social media impressions, and donate a minimum of 500,000 DKK to Arla Foundation.
- **Achievable:** The goal is achievable as it targets a realistic 40% recovery rate of the known annual loss (270,000 units) using a balanced logistical (Builder) strategy that pairs high-capacity municipal returns with high-visibility retail returns, supported by a defined 4 million DKK budget ceiling.
- **Relevant:** This is a necessary CSR initiative to reduce material waste, decrease the estimated 106 tonnes of annual CO2 emissions from replacement production, and support the Arla Foundation's nutrition education programs.
- **Time-bound:** Campaign concept and logistics design finalized by end of Q1 2026, pilot conducted in Q2 2026, and nationwide rollout executed from Q3 through the end of 2026.

## Dependencies

- Finalize cleaning agent certification with Danish EPA for reuse by 2026-05-30.
- Secure legally binding Service Level Agreements (SLAs) with municipal recycling stations by 2026-07-31 to guarantee 60% volume capacity.
- Finalize leasing and operational setup for three centralized Quality Assessment (QA) Hubs by 2026-07-15.
- Pre-approve all marketing collateral messaging with major supermarket groups 30 days prior to placement.
- Establish monthly data exchange protocol for 'Ready-to-Deploy Stock Report' with Arla Procurement starting September 3rd, 2026.

## Resources Required

- Up to 1.35 Million DKK for charitable donations
- Contracted 3rd-party logistics for hub conveyance
- Cleaning agents certified for HDPE reuse
- Signage, pre-printed bins, and visual guide campaign materials
- Staffing (FTEs) for three centralized QA hubs (approx. 27 roles)

## Related Goals

- Achieve measurable reduction in new-crate production orders for 2027.
- Establish proof-of-concept for large-scale reverse logistics within the Arla supply chain.
- Increase public awareness of Arla Foundation's nutrition education programs.

## Tags

- CSR
- Reverse Logistics
- Plastic Recycling
- Circular Economy
- Consumer Incentive
- Nationwide Campaign
- Dairy Logistics

## Risk Assessment and Mitigation Strategies


### Key Risks

- Municipal stations being overwhelmed by 60% of return volume, leading to consumer frustration and missed target volume.
- Supermarket staff non-compliance due to high operational burden, leading to low retail return rates.
- Contamination of returned crates due to unclear identification guidance, straining centralized QA hub efficiency and increasing recycling cost.
- Budget overrun in Logistics/QA costs due to high transport expenses for centralized hubs.

### Diverse Risks

- Failure to secure external regulatory clearance for cleaning agents by the Q2 deadline, halting reuse pipeline.
- Provocative marketing alienating key retail/consumer segments, stifling organic engagement.
- Logistical misalignment causing recovered crates to miss the window for impacting 2027 new-crate orders.

### Mitigation Plans

- Enforce mandatory penalty clauses in Municipal SLAs tied to staffing coefficients (Expert 3, Action 1) and ensure high-visibility signage/bins are deployed pre-Q3.
- Implement a low-level, universal participation fee for supermarkets to cover basic setup, reserving the 50 DKK subsidy exclusively for high-performing partners (Risk 2 mitigation).
- Develop a low-cost, immediate physical identifier (e.g., non-permanent marker/coding) as a contingency if social media visual guides fail during the Q2 pilot, coupled with source-contamination triage protocol (Expert 3, Action 3).
- Finalize centralized hub locations via pre-campaign logistical studies to minimize average transport distance and include volume/distance-based cost caps in 3rd party contracts (Expert 1, Action 1).
- Submit cleaning agent specifications to the Danish EPA for certification review by 2026-04-15 (Expert 2, Action 2) and allocate DKK 150,000 contingency for expedited external lab testing.
- Pre-test provocative marketing elements with Arla Foundation channels and prepare fallback messaging focused solely on the DKK 5 charitable donation before national rollout (Expert 3, Action 3).
- Mandate formal monthly synchronization meetings between QA Hub Logistics Lead and Arla Procurement starting September 3rd, 2026, using a standardized 'Ready-to-Deploy Stock Report' (Expert 2, Action 3).

## Stakeholder Analysis


### Primary Stakeholders

- Arla Foods (Programme Owner/Funder)
- QA Hub Operations Team (Logistics/Cleaning Contractors)
- Municipal Waste Authorities (Responsible for 60% volume collection)
- Supermarket Staff (In-store drop-off managers)

### Secondary Stakeholders

- Arla Foundation (Donation Recipient)
- Salling Group, Coop Danmark, Rema 1000 (Major Retail Partners)
- Danish Environmental Protection Agency (EPA) (Regulatory approval)
- Danish Public (Campaign Participants)

### Engagement Strategies

- Arla Foods: Weekly progress reviews focusing on budget burn rate and recovery volume against 40% target.
- QA Hub Operations: Daily operational reporting on cleaning efficiency, contamination rates, and staffing levels, ensuring specialized cleaning protocol adherence.
- Municipal Authorities: Formal SLA negotiation (due 2026-07-31) guaranteeing capacity coefficients; provide on-site laminated training guides for triage.
- Retail Partners: Secure written pre-approval for collateral 30 days in advance; offer performance-based operational subsidies to ensure high compliance; establish dedicated friction-reporting channel.
- Arla Foundation: Quarterly communication syncs to align messaging on the charitable impact of the 5 DKK donation.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Waste transport permits for routing non-reusable crates to plastics recycling facilities
- Local municipal permissions for temporary signage placement at recycling stations

### Compliance Standards

- Adherence to Danish EPA standards for cleaning agents used on food-contact surfaces (HDPE).
- Food-grade plastic reuse certification for all crates reintroduced into the supply chain.
- Waste segregation standards at municipal recycling stations.

### Regulatory Bodies

- Danish Environmental Protection Agency (EPA)
- Local Municipal Waste Management Authorities

### Compliance Actions

- Submit industrial cleaning agents and thermal process parameters to EPA for reuse certification by 2026-04-15.
- Mandatory internal Legal/Compliance review of all cleaning agents during Q2 2026.
- Implement mandatory internal hold point (2026-07-10) requiring signed certification before any crate is reintroduced to primary supply chain.
- Consult with Danish EPA regarding the methodology for calculating and tracking substituted CO2 tonnage.