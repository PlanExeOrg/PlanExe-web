This plan involves money.

## Currencies

- **DKK:** The primary and functional currency for all local transactions, supplier payments, logistical operations within Denmark, and the consumer charitable incentive (5 DKK donation).
- **USD:** Included as a benchmark stable currency for high-level budgeting and reporting, given the large, planned expenditure (up to 4 million DKK) and to provide stability if tracking costs across potential international marketing support or reporting standards.

**Primary currency:** DKK

**Currency strategy:** The project budget and all direct consumer-facing transactions are denominated in Danish Krone (DKK). The total program budget ceiling of 4 million DKK will be tracked primarily in DKK. USD will be used internally for significant budget tracking and analysis to provide a stable international comparison point, though DKK is used for immediate operational expenditure.