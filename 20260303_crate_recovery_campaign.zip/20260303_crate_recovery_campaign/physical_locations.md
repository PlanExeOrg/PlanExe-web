This plan implies one or more physical locations.

## Requirements for physical locations

- Collection points must be accessible to the general Danish public.
- Primary collection points must be established at participating supermarket chains.
- Secondary collection points must be established at municipal recycling stations (genbrugsstationer).
- Logistics infrastructure required for collection, inspection, cleaning, and redistribution must be established throughout Denmark.

## Location 1
Denmark

Participating Supermarket Chains

In-store designated drop-off points at partner retailers (e.g., Salling Group, Coop Danmark, Rema 1000 locations)

**Rationale**: This is one of the two mandated collection channels, offering high consumer accessibility due to existing high traffic.

## Location 2
Denmark

Municipal Recycling Stations (Genbrugsstationer)

Various municipal waste authority collection sites across all Danish municipalities

**Rationale**: This is the second mandated collection channel, crucial for capturing returns outside of standard grocery shopping hours, requiring integration with municipal waste infrastructure.

## Location 3
Denmark

Arla Regional Depots / Centralized Cleaning Hubs

Centralized sites designated for post-collection inspection, cleaning, and quality grading

**Rationale**: The chosen strategy requires routing all returns to centralized hubs for intensive cleaning and structural integrity assessment before reintroduction into the primary supply chain.

## Location Summary
The plan necessitates physical infrastructure across Denmark, primarily utilizing two consumer touchpoints: participating supermarket chains and municipal recycling stations. A third critical set of locations involves centralized depots or hubs necessary for the stringent post-collection inspection, cleaning, and quality grading mandated by the aggressive Pioneer strategic path.