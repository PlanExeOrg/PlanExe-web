### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic direction, budget control (4M DKK ceiling), and management of primary strategic risks (Financial Exhaustion, Reputational Risk). This body ensures alignment with Arla's overall CSR objectives and approves major decision routes selected (e.g., Pioneer strategy confirmation).

**Responsibilities:**

- Approve final Project Charter and Milestone plans (Q1 finalization).
- Monitor and approve disbursement thresholds for the maximum 1.35 Million DKK donation budget.
- Review and authorize triggers for the Tiered Incentive mechanism (Risk 1 mitigation).
- Provide final sign-off on the 'Irreverent/Humorous' marketing posture (Risk 3) and accept residual reputational risk.
- Resolve high-level commercial disagreements with Supermarket Groups or Municipal Authorities.

**Initial Setup Actions:**

- Finalize and approve the PSC Terms of Reference (ToR), including detailed decision rights and reporting mandates.
- Confirm executive sponsorship and standing committee membership.
- Review and ratify the 'Pioneer Strategy' selection.

**Membership:**

- Arla Foods Executive Sponsor (Chair)
- Head of Arla Supply Chain/Logistics
- Arla Corporate Communications Lead
- Arla Foundation Representative (Non-voting, Advisory)
- External Independent Governance Advisor (Ensuring impartiality in risk/budget review)

**Decision Rights:** All decisions impacting the 4M DKK budget ceiling, strategic alignment, major risk acceptance, and final sign-off on the Campaign Exit Strategy (Decision 15). Specifically, approval required for any single expenditure or commitment exceeding 500,000 DKK outside of the pre-approved donation pool.

**Decision Mechanism:** Consensus preferred. If consensus is not reached, decisions pass by a 75% majority vote of voting members. The Independent Advisor provides a final binding recommendation in the event of a 50/50 split among executive members.

**Meeting Cadence:** Monthly during Q1/Q2; Bi-weekly during Q3/Q4 national rollout.

**Typical Agenda Items:**

- Progress against 40% volume target and 20M impression goal.
- Review of actual charitable expenditure vs. forecast.
- Strategic Risk Register Review (Focus on financial exposure and reputational standing).
- Approval of major partner contract extensions (e.g., third-party washing facilities).

**Escalation Path:** Unresolved issues default to the Arla Foods Executive Steering Group (above the project governance structure) if the PSC cannot reach a decision or mandate within 14 days.
### 2. Core Execution Team (CET)

**Rationale for Inclusion:** Responsible for managing day-to-day project execution, integrating the complex dual-channel logistics (supermarkets and recycling stations), and operationalizing the Crate Quality Grading Protocol. This team translates PSC strategy into actionable tasks.

**Responsibilities:**

- Manage reverse logistics throughput, coordinating transport between collection points and centralized hubs (Risk 2 mitigation).
- Oversee the deployment and auditing of the lightweight count-and-report mechanism (Risk 6 mitigation).
- Manage the relationship and operational flow with third-party food-grade washing facilities (Assumption 3).
- Ensure compliance with all data capture protocols for quality assurance tracking (Risk 5).
- Manage marketing execution against approved PSC narrative (Risk 3 mitigation).

**Initial Setup Actions:**

- Finalize the Terms of Reference identifying roles, authorities, and reporting lines.
- Define and publish the detailed daily/weekly operating procedures for collection logistics.
- Establish dedicated operational tracking dashboards for real-time triage and throughput monitoring.

**Membership:**

- Project Manager (Chair)
- Lead Logistics Coordinator
- Marketing Campaign Manager
- Quality Assurance Lead (Logistics Focus)
- Commercial/Partner Liaison (Supermarkets & Municipalities)

**Decision Rights:** Operational decisions regarding logistics scheduling, inventory movement, supplier performance management, and minor marketing creative adjustments (where cost neutral). Day-to-day decisions are authorized as long as they keep expenditure within the approved Logistics budget (1.65M DKK) and do not trigger specific PSC approval thresholds.

**Decision Mechanism:** Simple majority vote. Chair holds the tie-breaking vote on operational deployment issues.

**Meeting Cadence:** Daily huddle during Q2 pilot and Q3/Q4 rollout; Weekly full review.

**Typical Agenda Items:**

- Review of daily/weekly collection volume vs. processing capacity.
- Incident report review (e.g., quality rejections, delivery failures).
- Partner compliance check-ins (supermarkets/municipal liaisons).
- Forward schedule review for cleaning hubs and asset reintroduction.

**Escalation Path:** Issues where CET cannot reach consensus, or where a risk threshold is breached (e.g., throughput forecast misses by >20% for three consecutive days, or expenditure variance >5% of allocated budget), are escalated immediately to the Project Steering Committee (PSC).
### 3. Compliance & Stewardship Assurance Body (CSAB)

**Rationale for Inclusion:** Mandated by explicit requirements for comprehensive compliance oversight (GDPR, food grades) and the high risk of corruption/misallocation associated with cash payments (donations) and complex external contracts (logistics). This body provides independent assurance.

**Responsibilities:**

- Conduct mandated quarterly independent financial audits on donation reconciliation (Audit Procedure 1).
- Verify compliance of central cleaning hubs with Danish food-grade sanitation standards prior to Q2 pilot and monthly thereafter (Audit Procedure 3).
- Review and validate the legal robustness of indemnity agreements with Municipalities (Decision 12 compliance check).
- Oversee integrity of the 'lightweight count-and-report mechanism' data feed via bi-weekly spot checks (Audit Procedure 2).
- Monitor the marketing spend vs. organic impression ratio to flag potential reputational risk (Risk 3).

**Initial Setup Actions:**

- Establish independent reporting lines directly to the PSC Chair and Internal Audit.
- Develop and publish the compliance monitoring schedule for the Q2 Pilot phase.
- Finalize QA oversight structure for third-party cleaning facilities (Assumption 3 recommendation).

**Membership:**

- Internal Audit Manager (Independent Chair)
- Arla Legal & Compliance Officer
- Finance Controller (Specializing in DKK tracking)
- External Compliance Specialist (Focus on Danish Waste/Environmental Law)

**Decision Rights:** CSAB holds only advisory and audit rights; it cannot halt operations but can issue formal Non-Compliance Notices (NCNs) requiring mandatory escalation to the PSC within 48 hours if critical failure (e.g., food-grade risk or significant donation fraud evidence) is identified.

**Decision Mechanism:** Unanimous agreement required to issue a formal Non-Compliance Notice, otherwise decisions default to direction provided by the Internal Audit Manager.

**Meeting Cadence:** Quarterly formal audit review; Monthly operational compliance check-ins during Q2/Q3.

**Typical Agenda Items:**

- Review of donation tracking vs. physical return tallies.
- Audit findings on third-party logistics/cleaning contractor performance.
- Status update on legal MoUs (Municipalities/Supermarkets).
- Review of marketing spend/viral success ratio.

**Escalation Path:** Any finding classified as an 'Audit Risk' (Corruption, Misallocation, or Critical Quality Failure) is immediately escalated to the PSC Chair via a formal Non-Compliance Notice (NCN). Non-adherence to NCN deadlines results in referral to the Arla Executive Board.