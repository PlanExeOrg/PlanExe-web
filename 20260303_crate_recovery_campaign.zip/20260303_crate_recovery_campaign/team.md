*Roles Needed & Example People*

# Roles

## 1. Reverse Logistics & Asset Recovery Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: This long-term role involves designing, contracting, and overseeing the entire physical flow (logistics, cleaning, reintroduction) across the entire campaign duration through 2026. This requires deep integration and control over the core supply chain process, fitting an FTE.

**Explanation**:
Responsible for designing, contracting, and overseeing the entire physical flow of assets: collection, warehousing, cleaning, inspection, and reintroduction into the dairy supply chain. Directly manages Decision 4 and Decision 14.

**Consequences**:
Catastrophic logistical bottlenecks, failure to clean/reintroduce crates, asset stagnation, and failure to realize CO2 avoidance benefits.

**People Count**:
min 1, max 2, depending on regional hub setup

**Typical Activities**:
Designing and contracting logistics routes for crate collection and transport; establishing detailed Standard Operating Procedures (SOPs) for centralized cleaning hubs and asset triage; managing third-party contracts for washing facilities; setting and continuously monitoring Crate Reintroduction Timelines to ensure prompt asset cycling back into the dairy supply chain.

**Background Story**:
Henrik Jørgensen, hailing from Odense, is a logistics veteran whose career has been spent optimizing complex supply chains, notably during his decade managing the cross-Nordic reverse flow for a major electronics recycler where he mastered asset tracking and decommissioning protocols; he holds a Master's in Supply Chain Engineering from DTU and possesses deep expertise in designing food-grade material handling SOPs, making him acutely familiar with the strict quality assurance required for plastics re-entry, which is why his oversight is critical to prevent bottlenecking the Pioneer strategy's intensive cleaning stage.

**Equipment Needs**:
Access to Arla's existing dairy supply chain ERP/tracking systems; Contracts and access rights for regional third-party food-grade washing facilities; Short-term lease/purchase agreements for pallet racking and temporary warehousing space near cleaning hubs.

**Facility Needs**:
Access to 3 designated regional Arla Depots/Centralized Cleaning Hubs configured for high-throughput visual inspection and ultrasonic cleaning;

## 2. Consumer Behavior & Incentive Strategist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: This role is central to financial success, responsible for critical decisions (Incentive Calibration, Exit Strategy) that directly modulate budget consumption and volume targets throughout the campaign lifecycle. Requires constant oversight of spend vs. return metrics.

**Explanation**:
Designs and calibrates the consumer-facing financial/charitable nudge (5 DKK donation) and structures the campaign's exit strategy to maximize initial volume capture while ensuring long-term habit formation. Manages Decision 1 and Decision 15.

**Consequences**:
Inaccurate spending against the budget cap, failure to hit the 40% recovery volume target due to ineffective incentives, or a rapid post-campaign collapse of returns.

**People Count**:
1

**Typical Activities**:
Analyzing real-time return rates against donation expenditure to manage the budget burn rate; modeling consumer response to the tiered incentive structure; designing the phased campaign exit strategy to promote long-term habit formation; presenting weekly spend reconciliation reports against volume targets to the steering committee.

**Background Story**:
Signe Møller, originally from Aarhus and trained as an Experimental Psychologist at the University of Copenhagen, spent her early career designing loyalty programs where she specialized in calibrating perceived value versus actual cost; she later moved into behavioral economics consulting, specializing in nudging pro-social behavior, giving her a unique perspective on maximizing the impact of the 5 DKK charitable donation while balancing the 4 million DKK budget ceiling, making her essential for setting the Incentive Structure Calibration.

**Equipment Needs**:
Real-time budget monitoring dashboard integrated with return volume data via API access; Mobile/Digital system for instant feedback on incentive tier changes (triggering 3 DKK if 40k units returned); Tools for modeling Q1 2027 residual donation costs.

**Facility Needs**:
A secure office environment with high-capacity data processing/modeling capability for financial reconciliation.

## 3. Stakeholder Relations & Partnership Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Managing complex, discrete stakeholder agreements (MoUs with supermarkets/municipalities) requires specialized negotiation and relationship management skills. These relationships are critical but might be best secured via specialized external consultants focusing on partnership compliance rather than full-time internal staff redundancy.

**Explanation**:
Manages complex contractual relationships and operational compliance with external site hosts, specifically supermarkets and municipal waste authorities. Focuses on executing Decision 2, Decision 13, and securing Decision 12 agreements.

**Consequences**:
Failure to secure or maintain convenient drop-off points, leading to supply chain friction, poor supermarket cooperation, and potential campaign collapse in one required channel.

**People Count**:
min 1, max 3, depending on the number of individual supermarket/municipality MOUs requiring active maintenance.

**Typical Activities**:
Leading negotiations and finalizing Service Level Agreements (SLAs) with major supermarket chains (Coop, Salling Group) regarding drop-off space and reporting mechanisms; formalizing indemnity agreements with municipal waste authorities for triage liability; ensuring consistent application of co-branding agreements with retail partners.

**Background Story**:
Rasmus Nielsen comes from Aalborg and has a strong background in B2B client management, having previously overseen relationship continuity for Arla's largest B2B customers before dedicating his expertise to partnership coordination; he thrives in complex contractual environments, having negotiated long-term service agreements across the retail and public sectors, making him the ideal person to secure and maintain the crucial agreements required by the Reverse Collection Channel Prioritization and Liability Transfer decisions.

**Equipment Needs**:
Standardized, branded, secure collection drop-off bins for supermarket pilot (Decision 2); Digital platform or standardized forms for tracking Service Level Agreement (SLA) compliance from retail partners; Draft legal indemnity documentation templates for municipal liability transfer (Decision 12).

**Facility Needs**:
Dedicated meeting space for negotiating and finalizing Memorandums of Understanding (MoUs) with supermarket corporate buyers and municipal waste department directors.

## 4. CSR Communications & Virality Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: This role centers on achieving a purely marketing outcome (20M organic impressions) using a high-risk, provocative tone (Decision 5). This often requires short-term, high-impact, specialized creative agency engagement or an experienced freelance contractor to deliver viral content quickly.

**Explanation**:
Defines the provocative marketing tone, manages the external perception of the campaign, and is solely responsible for hitting the 20 million organic impression goal. Owns Decision 5 and safeguards against Reputational Risk.

**Consequences**:
Campaign messaging fails to cut through noise; reliance on expensive paid media, resulting in failure to meet organic impression targets and potentially alienating supermarket partners.

**People Count**:
1

**Typical Activities**:
Developing the core creative concept and narrative ('secret lives' of crates) for the campaign; overseeing the production of shareable social media assets designed to maximize organic reach; monitoring real-time social sentiment against the Irreverent Promotional Risk Posture; serving as the primary liaison for securing cultural figures for campaign amplification.

**Background Story**:
Freja Kristensen, a highly acclaimed creative director from Copenhagen known for creating viral public service announcements that blend sharp wit with cultural relevance, established her reputation by steering controversial environmental campaigns that consistently secured massive earned media coverage; her background ensures the campaign avoids bland corporate-speak, perfectly matching the need to develop the high-profile, slightly irreverent marketing narrative required by the Pioneer scenario.

**Equipment Needs**:
Professional video/animation production budget (allocated from 1.0M DKK marketing spend); Licenses for social media monitoring and sentiment analysis software; High-resolution digital assets showcasing the 'secret lives' narrative for earned media pitches.

**Facility Needs**:
A temporary creative studio or access to an external creative agency's production facilities for developing the high-profile, irreverent campaign content.

## 5. Quality Assurance & Material Auditor

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Designing and overseeing the rigorous Crate Quality Grading Protocol (Decision 3) is crucial for supply chain integrity. This requires deep, integrated knowledge of Arla's material standards and facility specifications, necessitating an FTE dedicated to quality control.

**Explanation**:
Designs the stringent Crate Quality Grading Protocol (Decision 3) and oversees the auditing teams, ensuring that crates sent for reuse meet food-grade standards and contaminated assets are correctly routed for recycling, mitigating major supply chain contamination risks (Risk 5).

**Consequences**:
Introduction of unusable or contaminated crates into the dairy supply chain, leading to potential brand damage, recall scenarios, or premature failure of re-introduced assets.

**People Count**:
min 1 (lead expert), supervising operational staff (not listed separately)

**Typical Activities**:
Authoring the detailed specifications for ultrasonic cleaning and structural inspection within the Crate Quality Grading Protocol; developing the training manual and digital validation tools for the 15 on-site quality auditors; signing off on the final criteria dictating which crates are fit for reuse versus mandatory recycling.

**Background Story**:
Mads Pedersen, a materials scientist based in Herning, began his career specializing in plastic durability testing for the Danish packaging industry before joining Arla to focus on asset lifecycle management; he possesses proprietary knowledge regarding the 20-year lifespan engineering protocols for the green crates, which is why he is solely entrusted with designing the rigorous ultrasonic cleaning and structural integrity assessment standards required by the Pioneer strategy to ensure Arla's brand promise is upheld post-return.

**Equipment Needs**:
Detailed engineering specifications for the 20-year lifespan of the green plastic crates; Procurement and calibration of specialized ultrasonic testing equipment for centralized hubs; Digital validation application/tool for remote auditing of ambiguous crates (Risk 5 mitigation).

**Facility Needs**:
Oversight access to the 3 centralized cleaning hubs where rigorous quality grading (Pioneer Protocol) is executed; Laboratory or specialized area within hubs for structural fatigue testing.

## 6. Financial Controller & Budget Owner

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Financial Controller role involves monitoring budget burn based on real-time return data to trigger key mitigation strategies (like tiered incentives). This function requires focused attention during high-volume periods (like Q3/Q4 rollout) but may not require 40+ hours weekly throughout the design phase.

**Explanation**:
Monitors the DKK 4 million budget ceiling daily, tracking donation spend against return volume in real-time to signal triggers for incentive calibration (Risk 1 mitigation) and monitors logistics expenditure (Risk 8).

**Consequences**:
Premature budget exhaustion leading to campaign termination before the volume target is met, or inefficient allocation of funds across marketing and logistics streams.

**People Count**:
1

**Typical Activities**:
Daily monitoring of the DKK 4M budget ceiling against actualized donation spend and logistics contractor invoices; generating automated alerts when return rates necessitate activating the tiered incentive structure (Decision 1); conducting scenario planning to assess the financial impact of operational cost overruns (Risk 8).

**Background Story**:
Frederik Hansen, a precise financial analyst from Esbjerg, built his career managing constrained capital projects for infrastructure development, known for his ability to forecast cash flow risks under high-variable input conditions; tasked with safeguarding the 4 million DKK budget, he maintains a real-time dashboard tracking every DKK spent on marketing and logistics against the charitable donation payout, providing immediate alerts mandated by Risk 1 mitigation strategies.

**Equipment Needs**:
Daily financial reconciliation software integrated with transaction tracking (Decision 7); Budget allocation tracking specific to Logistics vs. Marketing spend envelopes; Template for triggering tiered incentive (Decision 1) alerts to campaign manager.

**Facility Needs**:
A secure, private workspace capable of handling sensitive budget data and running high-frequency reconciliation simulations.

## 7. Consumer Claims & Trust Administrator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Administering the ticketing for the 5 DKK donation requires setting up and auditing an efficient, low-friction system (physical receipts/tracking). This is a defined, project-scoped transactional auditing function best handled by a specialized contractor focused on clean data reconciliation.

**Explanation**:
Manages the integrity of the consumer claim process (Decision 7), ensuring the lightweight count-and-report data is accurate and trustworthy across two disparate collection channels, thereby validating the donation record.

**Consequences**:
Inaccurate donation tracking, leading to disputes with Arla Foundation or partners, and erosion of consumer trust in the 5 DKK incentive mechanism.

**People Count**:
min 1, max 2, for data reconciliation and auditing the physical receipt issuance.

**Typical Activities**:
Designing the process for printing and delivering immediate, barcoded physical receipts at collection points; performing weekly reconciliation audits between physical receipt counts and central donation tracking logs; investigating and resolving any discrepancies reported by collection site managers regarding donation validation.

**Background Story**:
Sofie Larsen, based near Kolding, has extensive experience in transactional auditing and claims processing gained from managing customer rewards programs for a major Danish retailer; she excels at implementing robust, low-friction accountability systems, which makes her uniquely suited to manage the integrity of the physical paper receipts issued at the point of return, ensuring the 5 DKK donation is accurately and instantly validated for every consumer interaction.

**Equipment Needs**:
Inventory of unique, sequentially barcoded physical paper receipts for immediate issuance at all 150+ collection points; Reliable barcode scanners or data entry interface for site managers; Offline-capable synchronization software for remote collection points.

**Facility Needs**:
Access to the centralized data repository for auditing transaction logs against physical receipt issuance records.

## 8. Regulatory & Compliance Officer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: This role focuses heavily on drafting and finalizing sensitive legal agreements for liability transfer with municipal authorities (Decision 12). Legal expertise for governmental/waste management compliance is typically secured via specialized outside counsel for the duration required to finalize MoUs.

**Explanation**:
Focuses specifically on legal risk management, including drafting indemnity agreements for municipal partners (Decision 12), ensuring food-grade compliance documentation is in order for cleaning hubs, and managing local waste authority communication.

**Consequences**:
Significant delays (Risk 4) due to unfinalized municipal agreements, or operational stoppage due to failure to meet environmental/food-safety permitting requirements for cleaning facilities.

**People Count**:
1

**Typical Activities**:
Drafting the legally binding indemnity agreements with all participating municipal waste authorities; ensuring all third-party cleaning contracts meet food-grade sanitation and environmental permitting standards; advising the team on communications compliance to avoid violating consumer ombudsman guidelines regarding incentive clarity.

**Background Story**:
Lars Jensen, a seasoned legal counsel from Copenhagen, specialized in environmental regulatory compliance and public-private partnerships before joining the project team; his primary focus is shielding Arla from liability as the campaign scales, particularly concerning the delegation of final rejection authority to municipal staff, a delicate legal maneuver requiring robust indemnity agreements codified under Decision 12.

**Equipment Needs**:
Standardized compliance checklist for municipal waste handling; Draft legal indemnity and subsidy contracts (Decision 12/8) for formalization; Official documentation templates for food-grade certification submission to regulatory bodies.

**Facility Needs**:
Office space dedicated to legal document review and secure storage for finalized MoUs with municipalities.

---

# Omissions

## 1. Missing Role: Marketing Campaign Execution Manager/Specialist

The team includes a CSR Communications & Virality Lead responsible for the *tone* (Decision 5), but lacks a role dedicated to the tactical execution, media buying (even supplementary paid media), content distribution scheduling, and managing the creative production budget (1.0 M DKK allocation). This crucial tactical link is missing.

**Recommendation**:
Either assign the planning and execution of the campaign launch/distribution schedule to the CSR Communications & Virality Lead, or introduce a dedicated 'Marketing Campaign Executor' role to manage the $1M budget and the deployment schedule against the Q2 pilot and Q3 rollout.

## 2. Missing Role: IT/Data Integration Specialist

The plan relies heavily on integrating a 'lightweight count-and-report mechanism' (Risk 6), a 'digital validation tool' for quality (Risk 5), real-time budget monitoring (Financial Controller needs API access), and potentially a consumer registration/receipt validation system (Decision 7). There is no dedicated resource responsible for designing, integrating, and ensuring the stability of these disparate data capture and reporting systems.

**Recommendation**:
Create a part-time or contractor role for a 'Data & Tracking Systems Integrator.' This person must ensure seamless, reliable data flow between collection points, cleaning hubs, the financial controller's dashboard, and the consumer claims administrator, crucial for the Pioneer strategy's reliance on real-time feedback.

## 3. Oversight for Municipal Infrastructure Setup

While the Stakeholder Relations Coordinator manages the MoUs and the Regulatory Officer handles legal indemnity (Decision 12), there is no dedicated operational role to physically stand up the *municipal* collection channel. This includes tasks derived from Decision 8 (like deploying dedicated drop-off bins) and ensuring the physical readiness required for the Q3 rollout outside of the supermarket pilot.

**Recommendation**:
Assign the physical setup and readiness verification of the municipal collection channels (Location 2) as a high-priority sub-task to the Reverse Logistics & Asset Recovery Manager, ensuring this operational ramp-up is accounted for in Q2 alongside the supermarket pilot.

---

# Potential Improvements

## 1. Clarify Incentive Triage Trigger Threshold

The mitigation plan for Risk 1 (Financial) suggests enacting the tiered incentive (3 DKK donation) if the pilot returns exceed 40,000 units. This threshold is vital but not explicitly formalized as a decision point, creating ambiguity for the Consumer Behavior & Incentive Strategist.

**Recommendation**:
Formalize the Q2 pilot return volume threshold for immediate incentive scaling (e.g., 40,000 units) as a mandatory checkpoint during the Q1 planning phase, ensuring the Consumer Behavior & Incentive Strategist knows the exact operating trigger for Decision 1.

## 2. Define Physical Requirements for 'Lightweight Count-and-Report'

Risk 6 depends on a lightweight system that takes <60 seconds per transaction. The team lacks a defined requirement set for the hardware/software interface at collection points, which impacts procurement timelines for the Stakeholder Relations Coordinator and the Data Integrator (if one is added).

**Recommendation**:
The Reverse Logistics Manager and the (prospective) Data Integrator must jointly define the technical requirements for the collection point system by the end of March 2026, specifying whether it relies on simple tablets, printed receipts only, or dedicated IoT bins.

## 3. Standardize Post-Campaign Asset Utilization Policy

Decision 11 addresses post-campaign use, balancing immediate reuse vs. secondary charity assets. Lacking a clear directive on how to treat the *residual* volume remaining at the end of 2026, the Logistics Manager might default to slow internal reintroduction, conflicting with the goal of rapid CO2 metric realization.

**Recommendation**:
The Consumer Behavior & Incentive Strategist must collaborate with the Reverse Logistics Manager to finalize the Q1 2027 plan (building on Decision 15, Choice 3) by mid-Q4 2026, detailing the exact split of recovered inventory between supply chain reuse and designated Arla Foundation asset donation for the final quarter's logistics planning.