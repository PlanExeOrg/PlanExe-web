## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers focus on driving initial consumer action and ensuring the physical infrastructure can handle the resulting flow. Critical levers (Incentive Structure, Virality Focus) manage the dual objectives of volume (40% target) and buzz (social impressions). High-impact levers focus on operationalizing the two major execution pillars: optimizing the two mandated collection channels and defining the quality throughput of the reverse logistics chain. The core tension managed is balancing aggressive consumer incentive spend against logistical processing speeds to meet immediate and long-term success criteria.

### Decision 1: Incentive Structure Calibration
**Lever ID:** `8cde354d-fb48-4bdd-ba19-da13ae2fe0fb`

**The Core Decision:** This lever controls the primary behavioral nudge's cost basis against the recovery goal and budget ceiling. Setting the 5 DKK donation correctly balances achieving the 40% return minimum against avoiding premature budget exhaustion. Success hinges on maximizing the perceived value of the donation to drive crucial initial inertia, while ensuring the logistic chain can absorb the resulting throughput.

**Why It Matters:** Adjusting the per-crate charitable donation directly modulates the direct cost associated with the primary behavioral nudge, affecting the total program budget expenditure. If the donation is set too low, consumer engagement will fail to meet the 40% recovery target, undermining the entire environmental rationale. Conversely, setting it too high accelerates budget burn, potentially requiring the campaign to end prematurely before material recovery stabilizes.

**Strategic Choices:**

1. Anchor the financial incentive at the maximum feasible level (5 DKK) to aggressively pursue the 40% return goal, absorbing the highest donation outlay within the 4 million DKK ceiling.
2. Introduce tiered incentives where the first 50,000 returns receive the full 5 DKK, but subsequent returns drop to 3 DKK to manage budget risk while signaling initial commitment.
3. Replace the direct monetary donation with a high-perceived-value non-monetary incentive, such as contributing the equivalent value to Arla Foundation only if 150,000 crates are successfully returned.

**Trade-Off / Risk:** Setting the incentive too low risks failing the volume target, while a high fixed incentive rapidly consumes the operational budget before logistics are truly optimized for sustained input flow.

**Strategic Connections:**

**Synergy:** It strongly amplifies Campaign Virality Mechanism Focus by providing a concrete, emotionally resonant anchor point for marketing messaging about environmental and charitable impact.

**Conflict:** If set too high, it rapidly strains the budget, thus constraining the resources available for funding Supermarket Partner Co-Branding Leverage or necessary logistics infrastructure.

**Justification:** *Critical*, This lever directly controls the primary behavioral catalyst for the entire project. It defines the critical trade-off between hitting the 40% volume target and respecting the 4 million DKK budget ceiling, making it central to success measurement.

### Decision 2: Reverse Collection Channel Prioritization
**Lever ID:** `5fe90cc9-41d0-40b2-ace2-a4fe8e23cdf1`

**The Core Decision:** This defines the operational density and ease of access for consumers returning crates. Prioritization must balance the convenience required to meet participation targets against the overhead of managing two disparate logistical streams. Effective channel management ensures high return volume without overburdening partners or causing consumer confusion about where to drop off crates.

**Why It Matters:** The selection of which return channel receives primary marketing and logistical focus dictates where consumer effort is concentrated, significantly impacting collection density and transport efficiency. Over-relying on municipal recycling stations risks logistical fragmentation since Arla does not control their staffing schedules or intake protocols. Focusing exclusively on supermarkets ensures supply chain integration but risks consumer frustration if designated drop-off points become cumbersome.

**Strategic Choices:**

1. Designate participating supermarket chains as the sole collection point for the initial pilot phase, deferring the deployment of municipal recycling station intake until logistical standardization is proven robust.
2. Establish a high-throughput, centrally located, temporary collection hub in major Danish metropolitan areas specifically for crates, bypassing both retail and municipal channels for bulk loads.
3. Implement a logistics model where supermarket pick-ups are scheduled only when their order volume for new deliveries exceeds a predetermined threshold, otherwise directing all returns solely to a dedicated municipal station route.

**Trade-Off / Risk:** Prioritizing one channel concentrates recovery efficiency but introduces single points of failure regarding consumer access or logistical bottlenecking if volumes spike unevenly across collection types.

**Strategic Connections:**

**Synergy:** This lever is crucial for Municipal Recycling Station Engagement Model success, as prioritizing that channel dictates the specifics needed for successful formal collaboration agreements.

**Conflict:** Focusing efforts too heavily on supermarkets may strain their willingness to cooperate, potentially undermining Supermarket Partner Co-Branding Leverage due to increased operational burden.

**Justification:** *High*, As the project is fundamentally physical, defining the primary consumer drop-off route dictates logistical density and consumer accessibility. It directly impacts whether the volume targets are achievable outside of reliance on a single partner type.

### Decision 3: Crate Quality Grading Protocol
**Lever ID:** `d5a4456a-fa97-42a5-ac6d-053a3b4efa7b`

**The Core Decision:** This protocol sets the standard for material stewardship, balancing the desire for high reuse rates against the operational cost of post-return processing. The stringency determines how many crates enter the reuse stream versus the recycling stream, directly impacting the estimated 106 tonnes of CO2 avoided. It governs the efficiency of the Post-Collection Material Processing Flow.

**Why It Matters:** The stringency of the inspection process post-collection directly impacts the labor cost of reverse logistics and the proportion of material successfully cycled back into use versus routed to waste recycling. Overly permissive grading leads to high reprocessing costs and contamination risk in the dairy supply chain. Conversely, strict rejection criteria will fail the environmental goal by unnecessarily diverting high-value plastic to recycling instead of reuse.

**Strategic Choices:**

1. Implement a rapid three-stage visual inspection system at collection points, immediately routing any crate showing significant stress fractures or non-Arla contamination directly to plastics recycling without deep cleaning.
2. Institute a system where all returned crates are routed to centralized cleaning hubs first, delaying the reuse decision until after intensive ultrasonic cleaning has confirmed material integrity and fitness for 20-year service.
3. Mandate that supermarkets only perform a cursory check for visual branding, accepting all functional-looking crates and deferring the full structural integrity assessment to Arla's central washing facility.

**Trade-Off / Risk:** Loose grading reduces immediate inspection labor but pushes downstream cleaning and quality assurance costs higher, potentially nullifying the environmental benefit if many are wrongly scrapped.

**Strategic Connections:**

**Synergy:** It locks in the feasibility of Crate Reintroduction Timelines; a strict protocol ensures the clean crates entering the supply chain meet immediate quality requirements.

**Conflict:** A very strict protocol conflicts directly with Reverse Collection Point Triage Authority, as it necessitates centralizing destructive decision-making away from the point of consumer return.

**Justification:** *High*, This protocol governs the efficiency of the value chain, dictating the proportion of returns that realize the environmental goal (reuse) versus those that incur processing cost (recycling). It is the core quality gate for the reverse logistics system.

### Decision 4: Post-Collection Material Processing Flow
**Lever ID:** `f53027ed-85ac-4867-858d-2b71ae53d0bd`

**The Core Decision:** This defines the physical pipeline for transforming collected crates into useable inventory or scrap plastics. The throughput speed of this flow dictates the ROI timeline for the reverse logistics investment and the pace of CO2 offset realization. Efficiency here prevents asset stagnation in warehouses awaiting cleaning and assessment.

**Why It Matters:** Determining the inspection/cleaning/reentry flow dictates the speed at which assets return to service or are routed to recycling, directly impacting the CO2 offset benefit realization timing. If the cleaning process is too slow or requires specialized, single-purpose equipment, facility throughput will bottleneck, forcing stored, returned crates to occupy valuable warehouse space unnecessarily.

**Strategic Choices:**

1. Designate existing, underutilized, regional third-party food-grade washing facilities on short-term contracts to handle the cleaning surge based on real-time need, bypassing Arla's internal facilities.
2. Establish mandatory, high-speed visual inspection lines at Arla regional depots specifically for crate triage, routing only clearly high-quality stock directly into immediate dispatch, while damaged stock awaits detailed processing.
3. Implement a rapid, non-contact UV sterilization pass for all collected crates as a primary cleaning step, foregoing deep sanitation until the crates cycle through the main dairy production line later.

**Trade-Off / Risk:** Using third-party food-grade washing contractors introduces dependency on external scheduling and quality assurance dependencies that may slow down the reintegration timeline compared to dedicated, owned assets.

**Strategic Connections:**

**Synergy:** An efficient flow is necessary to realize the goal set by the Incentive Structure Calibration, as fast processing validates the consumer's effort with rapid asset reentry.

**Conflict:** A slow or overly complex flow will create backlogs, necessitating greater immediate expenditure on storage, which strains the resources needed for Contingency Asset Deployment Strategy.

**Justification:** *High*, The speed of cleaning and reentry determines the realization timeline for CO2 offsets and prevents asset stagnation. It is the critical throughput bottleneck connecting collection activity to supply chain benefit.

### Decision 5: Promotional Risk Posture
**Lever ID:** `d8d6677f-b6a5-4409-8549-b0764a556978`

**The Core Decision:** This lever dictates the marketing tone used to communicate the environmental and charitable value proposition. The chosen posture directly influences earned media and organic reach potential, balancing the need for provocative, viral content against the preservation of brand integrity and positive relationships with supply chain partners, like supermarkets.

**Why It Matters:** The tone of the marketing directly impacts earned media coverage and social virality, which are cost-effective alternatives to paid media; however, an overly provocative message risks backlash or alienating key supermarket partners. A very safe, conservative message ensures partner goodwill but sacrifices the potential for the wide organic reach that success depends upon.

**Strategic Choices:**

1. Adopt a tone focusing exclusively on the quantifiable environmental impact (tonnes of CO2 saved) using deeply technical, factual industry language to appeal to serious environmental advocates.
2. Develop a high-profile, slightly irreverent marketing narrative centered on the 'secret lives' of the lost crates, using humour about their misuse in gardens and playgrounds to spark conversation.
3. Focus the campaign entirely on the direct link between crate return and improved child health outcomes, using poignant visual testimonials from nutrition education program participants.

**Trade-Off / Risk:** While appealing to technical advocates, using deeply factual, industry-focused language risks failing to generate the viral social media impressions required, thereby undermining the primary marketing objective.

**Strategic Connections:**

**Synergy:** A high-risk but humorous posture amplifies Campaign Virality Mechanism Focus by creating cultural content inherently suited for wide organic sharing and earned media.

**Conflict:** An overly provocative tone can create strain with Supermarket Partner Co-Branding Leverage, potentially causing partners to distance themselves from messaging deemed too risky or controversial.

**Justification:** *High*, This lever controls the primary mechanism for achieving the secondary success goal—viral social impressions. Choosing the right risk posture is vital for securing cost-effective organic reach needed to supplement the core donation incentive.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Reverse Collection Point Triage Authority
**Lever ID:** `ace9e1a6-0ca9-492d-bb1f-dba047a0d260`

**The Core Decision:** This determines the speed and consistency of asset acceptance at the collection interface. Empowering local staff speeds up consumer transactions but risks introducing subjective grading variance. Centralizing ensures uniformity but slows down throughput, creating potential bottlenecks for high-volume drop-offs at collection points.

**Why It Matters:** Defining who has final authority on rejecting a crate streamlines the process at the point of return; empowering local staff reduces delayed decision-making but increases the risk of procedural inconsistency across hundreds of locations. If authority is centralized at Arla’s regional hubs, consistency is guaranteed, but the initial transit cost of sending questionable crates across the network will balloon.

**Strategic Choices:**

1. Delegate immediate rejection authority for visibly damaged or clearly non-Arla crates to the initial drop-off personnel at both supermarket service desks and municipal stations.
2. Establish a standardized, photo-based digital grievance submission system where collection point staff flag ambiguous crates for immediate remote review by a centralized Arla quality analyst.
3. Mandate that all crates are accepted initially by collection personnel, with rejection decisions deferred only to the dedicated cleaning and inspection facility prior to transport.

**Trade-Off / Risk:** Delegating rejection authority risks inconsistent application of grading standards, potentially alienating consumers or sending unusable crates through the logistics chain, thereby overriding the benefit of immediate local decision-making.

**Strategic Connections:**

**Synergy:** Delegating authority accelerates consumer throughput, immediately validating the consumer's action, which supports the goal of the Campaign Virality Mechanism Focus.

**Conflict:** Over-empowering local staff creates procedural inconsistency, potentially complicating the subsequent Crate Quality Grading Protocol if centralized verification is required later.

**Justification:** *Medium*, This lever manages operational friction at the collection point. While crucial for consumer experience, it is secondary to the *protocol* (Lever D5a4456a) for grading, as consistency matters more than immediate decision speed.

### Decision 7: Charitable Donation Mechanism Design
**Lever ID:** `3514343b-14ef-4da2-9c93-c4e01b20fd3a`

**The Core Decision:** This lever defines the user experience for claiming the 5 DKK charitable donation linked to each returned crate. Success hinges on maximizing the psychological reward momentum without introducing friction that causes drop-offs at the collection points. The ideal mechanism balances immediate gratification—driving quick returns—against cumulative goal framing, which encourages consistent engagement over the campaign duration.

**Why It Matters:** The way the 5 DKK donation is linked to the return affects urgency and participation; presenting it as an immediate, visible reward can stimulate quick action, but tying it to cumulative goals can encourage multi-crate returns. If the mechanism is too complex, it slows the consumer engagement interaction at the point of return, possibly frustrating participants.

**Strategic Choices:**

1. Require pre-registration via a simple QR code scan at the drop-off point, linking the consumer's unique identifier to the specific number of crates returned for real-time donation update tracking.
2. Institute a single, immediate paper voucher handed to the consumer upon crate drop-off, redeemable for the 5 DKK donation amount at any local Arla Foundation-supported educational event.
3. Structure the 5 DKK as a matched fund, publicly committing Arla to doubling the total donation pot if the 40% recovery target is met by year-end, relying on collective achievement.

**Trade-Off / Risk:** Requiring consumer pre-registration adds a necessary digital dependency that could disenfranchise a segment of the public, contradicting the goal of maximum accessibility for this physical program.

**Strategic Connections:**

**Synergy:** It synergizes with Campaign Virality Mechanism Focus by providing tangible, shareable outcomes (like a receipt for a voucher) that fuel social media narratives.

**Conflict:** It conflicts with Municipal Recycling Station Engagement Model, as complex pre-registration requirements increase the operational burden and slow down intake for municipal staff who are not incentivized.

**Justification:** *Medium*, This defines the consumer claim mechanic. While it supports engagement, its design is secondary to the core financial value set in the Incentive Structure Calibration (Lever 8cde354d) itself.

### Decision 8: Municipal Recycling Station Engagement Model
**Lever ID:** `0ba1090d-c9dc-43e4-8771-45797b424a5b`

**The Core Decision:** This defines the operational protocol for utilizing municipal recycling stations as return points, focusing on throughput capacity and integration with existing waste authority workflows. The goal is to minimize disruption while maximizing collection volume outside of standard supermarket hours, often through providing standardized, non-intrusive collection infrastructure.

**Why It Matters:** The engagement model with municipal stations determines throughput capacity outside of standard retail hours, but requires specific training and potential infrastructure adaptation at these independent sites. Relying purely on existing municipal staff schedules might cap off-take during peak weekend times when consumers are most likely to participate.

**Strategic Choices:**

1. Provide dedicated, weatherproof, clearly branded drop-off bins (similar to secure mailboxes) to all participating recycling centers, requiring municipal staff only to empty them once per shift.
2. Offer municipal waste authorities a flat, fixed operational subsidy per 1,000 kilograms of accepted Arla crates, directly incentivizing them to prioritize intake capacity during busy periods.
3. Bypass municipal staff entirely by deploying temporary, Arla-contracted logistics personnel to manage crate intake and initial inspection only during known high-volume weekend windows.

**Trade-Off / Risk:** Bypassing municipal staff with Arla contractors risks jurisdictional conflicts or accusations of interfering with public waste management contracts, potentially jeopardizing long-term municipal cooperation.

**Strategic Connections:**

**Synergy:** Success here directly enables Reverse Collection Channel Prioritization by ensuring the municipal channel can handle significant volume spikes when consumers use it.

**Conflict:** Employing Arla-contracted staff at these sites to boost throughput risks creating friction with Waste Authority Triage Liability Transfer agreements regarding staff jurisdiction and oversight.

**Justification:** *Medium*, This operationalizes one of the two required return channels. It is important for collection density but is subordinate to the overarching priorities set by Reverse Collection Channel Prioritization (Lever 5fe90cc9).

### Decision 9: Campaign Virality Mechanism Focus
**Lever ID:** `68c4e65f-58f5-44a1-86c6-4e7b3984483a`

**The Core Decision:** This lever establishes the primary driver for brand awareness and consumer engagement, prioritizing either investment in paid media for guaranteed reach or cultivating organic, earned media through compelling narratives. The choice heavily influences budget distribution between marketing spend and necessary logistical infrastructure development.

**Why It Matters:** Shifting marketing focus primarily toward cultivating earned press and organic social adoption reduces reliance on the budgeted paid media allocation, freeing funds for essential logistics infrastructure. Over-emphasizing provocative content designed for virality significantly increases the reputational risk to Arla and the Foundation if the message is misinterpreted or causes cultural offense, even if it achieves high impressions. The strategy determines the overall risk profile versus the media leverage achieved.

**Strategic Choices:**

1. Commission a well-known Danish comedian or cultural figure to create a single, highly shareable animated short detailing the crate's 'secret lives' to drive earned media.
2. Allocate 75% of the marketing budget exclusively to geo-targeted paid social media placements focusing on direct calls-to-action rather than narrative intrigue.
3. Partner with municipal waste authorities to create joint press releases emphasizing the verifiable CO2 reduction metric shared across all region-specific return events.

**Trade-Off / Risk:** Allocating the majority of funds to paid media guarantees reach but exhausts the limited budget quickly, preventing contingency funds from mitigating inevitable early logistical failures.

**Strategic Connections:**

**Synergy:** A heavy focus on organic virality provides the narrative ammunition needed to support the Charitable Donation Mechanism Design, making the cause socially relevant.

**Conflict:** Shifting a large budget share to paid social media crowds out resources needed for Contingency Asset Deployment Strategy, increasing risk if initial reverse logistics failures occur.

**Justification:** *High*, This lever directly addresses the explicit goal of achieving 20 million organic impressions. Its allocation strategy dictates the viability of achieving low-cost media success versus expensive reliance on paid placements.

### Decision 10: Contingency Asset Deployment Strategy
**Lever ID:** `52456c80-34a1-48af-879d-46e7c910d040`

**The Core Decision:** This strategy involves pre-arranging the availability of replacement crates to insulate the core dairy supply chain against potential collection failures during the campaign's initial phases. The key metric is maintaining service levels while avoiding unnecessary inventory costs associated with manufacturing capacity held 'just in case' of poor consumer participation.

**Why It Matters:** Pre-purchasing a buffer stock of replacement crates ensures that delivery schedules are preserved even if the initial return rate severely lags expectations, protecting immediate retail contracts. Carrying this idle inventory incurs holding costs and contradicts the CSR goal of reducing new production, as the purchased crates may sit unused if the campaign succeeds beyond the 40% target. This choice hedges against logistical failure at the expense of capital efficiency and environmental messaging purity.

**Strategic Choices:**

1. Negotiate a short-term (six-month) manufacturing slot commitment with a supplier, paying only a small, non-refundable deposit to hold capacity against a Q4 logistical shortfall.
2. Immediately order replacement crates equivalent to 10% of the expected annual loss, storing them at existing distribution centers to minimize external holding costs.
3. Formally declare an immediate moratorium on all non-essential new crate purchases for 2027, accepting the risk of sporadic stock-outs at smaller rural retailers.

**Trade-Off / Risk:** Declaring a moratorium eliminates near-term procurement costs but exposes Arla to significant contractual breaches if collection rates fall below ten percent in the first quarter post-launch.

**Strategic Connections:**

**Synergy:** A robust strategy here mitigates immediate pressure on Reverse Collection Channel Prioritization, allowing collection channels time to ramp up without immediate supply fear.

**Conflict:** Committing funds to hold manufacturing capacity conflicts directly with the Incentive Structure Calibration budget by tying up capital that could otherwise fund higher per-unit donation incentives.

**Justification:** *Medium*, This addresses potential failure of the primary goal (collection) to protect the core business continuity. It is an important risk mitigation lever but does not drive the primary CSR outcome, making it supportive rather than central.

### Decision 11: Post-Campaign Asset Utilization Horizon
**Lever ID:** `d5b72766-3eac-4a3d-9aec-2e6b683a643e`

**The Core Decision:** This lever determines the post-return fate of successfully cleaned crates, balancing immediate environmental reporting goals against extending cooperative goodwill through secondary charitable uses. Success is measured by the speed of CO2 metric realization versus the tangible, positive secondary messaging generated by supporting Arla Foundation community projects with surplus assets. It directly influences short-term logistics throughput efficiency versus long-term stakeholder engagement.

**Why It Matters:** Deciding to immediately reinvest recovered crates into the primary supply chain maximizes the short-term CO2 avoidance metric and demonstrates rapid execution of the environmental goal. Conversely, designating a portion of the recovered stock for use exclusively by the Arla Foundation for non-dairy projects (like school garden storage) provides a tangible secondary CSR benefit, but this diverts usable assets away from the core logistics recovery mandate. This choice balances immediate supply chain optimization against extended cooperative goodwill.

**Strategic Choices:**

1. Immediately route 100% of all accepted, cleaned crates back into the standard Arla dairy distribution cycle within 72 hours of depot arrival to maximize immediate asset velocity.
2. Designate all crates recovered outside the initial 85,000-unit target for cleaning and sale at a nominal fee to local community associations or municipal schools via the Arla Foundation.
3. Quarantine all recovered crates for an additional six weeks post-cleaning to monitor for slow-developing structural fatigue before authorizing their reintroduction to the primary logistics stream.

**Trade-Off / Risk:** Quarantining retrieved assets for six weeks stabilizes long-term quality assurance but postpones the realization of CO2 avoidance benefits required for year-one performance metrics.

**Strategic Connections:**

**Synergy:** It is strongly supported by Charitable Donation Mechanism Design, as designating material for the Foundation directly fuels that mechanism. It also interacts with Crate Reintroduction Timelines based on asset assignment.

**Conflict:** It conflicts with Crate Reintroduction Timelines if assets are diverted for secondary use, slowing down core supply chain replenishment. It also constrains the immediate achievement of CO2 avoidance metrics.

**Justification:** *Medium*, This decision manages the residual value of recovered assets, trading short-term logistical purity (100% reuse) against long-term goodwill enhancements via secondary Foundation support. It manages the tail-end optimization.

### Decision 12: Waste Authority Triage Liability Transfer
**Lever ID:** `dd9d0695-545a-47d0-b26f-05d7111b97f9`

**The Core Decision:** This involves delegating the final classification of 'too damaged' crates to municipal recycling station personnel, streamlining Arla's collection process by removing internal quality control checkpoints. Key success factors include establishing trust via indemnity agreements and ensuring the municipal staff apply consistent standards to avoid rejecting recyclable assets. It is a crucial element for managing the flow of non-reusable volume.

**Why It Matters:** Allocating final 'unusable' status determination to municipal recycling site managers shifts the burden of complex material quality assessment away from Arla's mobile collection teams. This reduces internal inspection overhead but delegates quality control authority, creating a potential variability in which crates are accepted versus rejected depending on local site management's risk aversion to contamination. If municipal staff are overly cautious, crates suitable for recycling may be landfilled, undermining the CO2 reduction goal.

**Strategic Choices:**

1. Formalize a legally binding indemnity agreement with municipal waste authorities, permitting their staff to make final disposition decisions on heavily soiled or damaged crates without subsequent Arla financial liability for acceptance errors.
2. Maintain primary Arla inspection authority at the point of collection transfer, requiring municipal staff only to segregate incoming crates into 'clean' and 'dirty' queues based on observable gross contamination levels.
3. Implement a small, immediate secondary credit (0.50 DKK per crate) paid directly to the municipal recycling station for every ten crates successfully processed into the external plastics recycling stream.

**Trade-Off / Risk:** Transferring triage authority offers logistical speed but risks inconsistent rejection policies across diverse municipal sites, potentially failing the environmental diversion success metric due to varied interpretation of 'too damaged.'

**Strategic Connections:**

**Synergy:** Effective transfer requires strong Municipal Recycling Station Engagement Model to ensure buy-in and standardized procedures. It also simplifies processes defined by Reverse Collection Channel Prioritization.

**Conflict:** It conflicts directly with Post-Collection Material Processing Flow by pushing complex sorting decisions downstream, potentially creating contamination risk there. It also constrains the strict achievement of environmental diversion targets.

**Justification:** *Low*, This is a derivative decision stemming from the broader quality control (Crate Quality Grading Protocol) and engagement strategies for municipal sites. It is tactical risk transfer rather than a foundation pillar.

### Decision 13: Supermarket Partner Co-Branding Leverage
**Lever ID:** `d7832bb8-4e76-4012-b519-f3452d9df76a`

**The Core Decision:** This lever defines the degree to which participating supermarkets receive prominent marketing credit in exchange for logistical compliance, such as maintaining dedicated, clean drop-off points. Success means securing high-compliance acceptance rates without allowing the core CSR message to be overshadowed by retail promotions. It directly manages the trade-off between gaining logistical support and maintaining message clarity.

**Why It Matters:** How Arla frames the partnership affects the perceived value exchanges between Arla and the participating supermarkets, influencing their willingness to support logistical requirements beyond the bare minimum. By offering high-visibility co-branding slots on in-store signage, Arla can trade marketing exposure for logistical compliance, though this dilutes Arla's singular CSR message slightly. Conversely, minimizing supermarket visibility reduces their incentive to prioritize crate intake during busy operational hours.

**Strategic Choices:**

1. Offer the top three participating supermarket chains exclusive naming rights for one week of the campaign ('The Coop Crate Sweep'), allowing them prime placement in all subsequent press releases and digital assets.
2. Limit supermarket involvement strictly to drop-off acceptance, refusing any co-branding opportunities to maintain complete narrative control over the environmental and nutritional messaging.
3. Tie the donation performance metric directly to a supermarket-specific return volume tier, offering the logistics provider handling that specific chain a performance bonus payable from the marketing budget.

**Trade-Off / Risk:** Leveraging supermarket co-branding for compliance speeds up initial acceptance rates but risks crowding the campaign's core social message with secondary retail promotion, weakening the unified CSR narrative.

**Strategic Connections:**

**Synergy:** Leveraging visibility strongly supports Campaign Virality Mechanism Focus by providing tangible content distribution points. It is essential for executing the Supermarket Partner Co-Branding Leverage effectively.

**Conflict:** High co-branding dilutes the intended simplicity of the Charitable Donation Mechanism Design. It also creates friction with principles guiding Promotional Risk Posture by adding complexity to communications.

**Justification:** *Medium*, This manages the compliance of the most critical logistical partner (supermarkets). It is key for operationalizing Channel Prioritization but is secondary to setting the incentive that drives consumer behavior.

### Decision 14: Crate Reintroduction Timelines
**Lever ID:** `a19aec33-adb9-4c00-9b9a-feaa9c0c6824`

**The Core Decision:** This dictates the inspection rigour versus the speed of asset return to the dairy distribution cycle to meet 2027 production reduction goals. More rigorous testing ensures long-term fleet integrity but delays CO2 impact realization, whereas rapid deployment maximizes initial metrics but increases fleet failure risk. Success is the optimal point between quality assurance and immediate supply chain relief.

**Why It Matters:** The speed at which recovered crates are reintroduced into service directly affects the short-term need for new crate production orders, which dictates the immediate success metric validity for 2027 planning. Rushing structurally sound crates back into circulation without a full 20-year life-cycle stress test risks premature asset failure in the field, potentially damaging brand trust. Delaying reintroduction allows for more thorough inspection but increases warehousing costs and prolongs the period requiring the production of new plastic assets.

**Strategic Choices:**

1. Only reintroduce crates back into the supply chain pool if they have successfully passed a mandatory two-week stress test simulating temperature variations experienced during long-haul dairy transit; otherwise, route them to long-term quarantine storage.
2. Immediately reintroduce any crate passing the initial two-point visual and structural inspection, accepting a minor, managed increase in in-service failure rate as an acceptable trade-off for rapid volume reduction in the recovered stock.
3. Establish an immediate secondary market channel to sell perfectly intact but uncleaned/unverified crates to non-dairy industrial partners (e.g., construction/manufacturing sectors) solely to accelerate volume clearance and avoid internal supply chain contamination risks.

**Trade-Off / Risk:** Balancing immediate reuse against rigorous vetting determines the cost of failure; rapid reintroduction maximizes immediate CO2 offset claims but invites future structural failure liability into the active fleet.

**Strategic Connections:**

**Synergy:** It directly affects the outcome of Post-Campaign Asset Utilization Horizon by determining which assets are ready for reuse. It requires coordination with Post-Collection Material Processing Flow for rigorous inspection.

**Conflict:** Aggressive timelines conflict with Contingency Asset Deployment Strategy by minimizing the buffer needed for structural validation before re-entry. It trades off against strict adherence to Crate Quality Grading Protocol.

**Justification:** *High*, This lever directly governs the achievement of the 2027 production reduction metric. Balancing speed against quality assurance for re-entry is fundamental to validating the 2026 effort's long-term impact.

### Decision 15: Campaign Exit Strategy Definition
**Lever ID:** `7ef3f5fe-5d24-420f-8661-361b049dd62f`

**The Core Decision:** This defines the campaign's closing condition, fundamentally influencing consumer urgency and the timing of return spikes. Setting a hard end date focuses effort to hit the 40% target but risks a swift drop-off. Keeping it open-ended builds habit but may not deliver the necessary initial volume boost for 2026 success metrics.

**Why It Matters:** Defining the official end-point of the campaign creates a clear target for consumer action but may cause an artificial surge followed by immediate cessation of returns, leaving a residual collection problem. Conversely, keeping the charitable incentive open-ended diminishes its perceived urgency, potentially lowering the critical Q3/Q4 return volume needed to hit the 40% year-one goal. The choice impacts the sustainability of the behavioral change post-2026.

**Strategic Choices:**

1. Announce the 1.35 million DKK donation ceiling explicitly at launch, creating scarcity and driving an intense, focused return spike during the campaign window before the Arla Foundation funding naturally subsides.
2. Maintain the 5 DKK charitable donation indefinitely, positioning the crates' reverse logistics as a permanent, embedded CSR feature of Arla's standard logistics, relying solely on environmental awareness for long-term returns.
3. Phase out the donation over 18 months, starting with a 3 DKK contribution for Q1 2027, dropping to 1 DKK in Q2, and concluding with a final internal commitment to recycle all remaining unclaimed crates thereafter.

**Trade-Off / Risk:** Setting a hard donation limit maximizes short-term behavioral incentive urgency to hit the 40% target but fails to build lasting crate-return habits necessary for sustained asset recovery beyond the campaign.

**Strategic Connections:**

**Synergy:** A strong exit boundary enhances the urgency leveraged by the Campaign Virality Mechanism Focus to drive peak participation. It provides a timeline anchor for Incentive Structure Calibration.

**Conflict:** An open-ended strategy conflicts with the need for immediate high volume needed to realize year-one CO2 metrics quickly. It also constrains the necessary urgency required by Promotional Risk Posture.

**Justification:** *Low*, This is a timing/sustainability lever. While necessary for managing the end-cycle, the success of hitting the 2026 40% target depends on activating the primary incentive structure first.
