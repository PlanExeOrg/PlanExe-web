A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The aggressive, time-boxed 5 DKK charitable donation incentive will not exhaust the 1.35M DKK donation budget before the 40% volume target (108k units) is met, or before the strategically planned Q4 deceleration point. | Immediately map the exact volume that consumes 1.1M DKK (the planned threshold for forced deceleration/cap) and compare it against the forecast return curve for Q3/Q4. | The return rate curve spikes such that 1.1M DKK is projected to be spent before September 15, 2026. |
| A2 | The high-rigor Pioneer Quality Grading Protocol (ultrasonic cleaning/assessment) can be reliably executed by third-party food-grade washing facilities at a competitive cost-per-crate without scaling bottlenecks. | Execute the mandatory Q2 pilot audit (Data Item 3) and confirm the third-party processing cost is <= 15 DKK/crate AND the cumulative processing throughput is >= 90% of the forecast rate required to meet the 90-day reintroduction SLA. | The validated Cost Per Recovered Crate (CPRC) exceeds 20 DKK/crate due to quality failure routing, or reintroduction velocity falls below 75% of the required weekly target. |
| A3 | The chosen 'irreverent/humorous' promotional risk posture will be tolerated by key supermarket partners, ensuring full compliance with in-store signage and drop-off procedures (Decision 13). | Immediately circulate the core 'secret lives' creative assets to the sustainability and procurement leads at Coop, Salling, and Rema 1000 for explicit written sign-off, as mandated by Data Item 2. | Any of the three major supermarket groups issues a formal, written declaration rejecting the core irreverent narrative, forcing an immediate, resource-draining pivot to the secondary testimonial marketing posture. |
| A4 | Consumer willingness to transport crates (digital or physical) remains stable across the entire 12-month campaign window, regardless of weather conditions or seasonal purchasing habits in Denmark. | Run a low-cost, geographically limited micro-pilot in Q2 focusing specifically on urban vs. rural consumer return frequency during historically low-traffic weeks (e.g., mid-summer holidays). | Return volume correlation analysis shows a greater than 25% standard deviation drop in returns during specific low-activity periods (e.g., July/early August) compared to the forecast model. |
| A5 | The dedicated, full-time specialized inspector staff (15 FTEs) required for the Pioneer Strategy's centralized quality control hubs (Hubs 1, 2, 3) will be recruited, trained on food-grade protocols, and retained for the full 2026 operational period without attrition. | Review HR hiring pipeline status for the 15 required specialized roles as of March 31, 2026, focusing on candidate quality documentation and planned training completion dates. | Hiring remains 20% below target (i.e., <12 FTEs) by April 30, 2026, or annualized staff attrition risk exceeds 15% based on initial training cohort confidence scores. |
| A6 | The IT/Data Integration systems (lightweight app, digital validation tools) required to track physical returns and quality triage in real-time will achieve 99.9% uptime during peak collection periods, ensuring data integrity for all KPIs. | Conduct a mandatory 72-hour stress test simulating 3x peak expected data transaction load across the collection, triage, and finance dashboards prior to the Q2 pilot launch. | The system experiences unplanned downtime exceeding 4 cumulative hours during the 72-hour stress test OR a data reconciliation audit reveals a logging mismatch rate >0.5% between front-end collection points and the central ledger. |
| A7 | The Danish consumer will distinguish clearly between the primary 5 DKK charitable donation mechanism and secondary retail co-branding promotions, ensuring the core viral message remains focused on the Arla Foundation. | Review customer feedback and social media sentiment analysis from the Q2 pilot specifically analyzing comments referencing 'why' they returned the crate (charity vs. partner benefit). | Social listening metrics show that brand mentions of the primary supermarket partner outweigh mentions of the Arla Foundation by a 3:1 ratio during the Q2 pilot, indicating message dilution. |
| A8 | The third-party food-grade washing facilities contracted for the Pioneer Strategy possess sufficient operational redundancy and preventative maintenance schedules to absorb unexpected equipment failure without impacting the weekly throughput guarantee. | Audit the 3PL contracts (as recommended by the 3PL Auditor) to confirm the contractual clause mandating 20% embedded operational slack or immediately available redundant washing line capacity for emergency use. | The 3PL contractors report zero available backup capacity or maintenance deferral clauses that would allow any single cleaning line to be offline for more than 12 hours without penalty. |
| A9 | Municipal waste authorities, once indemnity agreements are signed, will actively cooperate in enforcing the waste authority triage liability transfer (Decision 12) criteria consistently across all decentralized collection sites. | Conduct surprise spot-audits (as recommended by the Regulatory Officer) at 10 geographically diverse municipal stations in Q3 to verify that local staff are correctly upholding the defined rejection threshold for contamination/damage. | Spot audits reveal that 15% or more of the rejected crates at municipal sites were functionally reusable according to the established quality protocol, indicating internal bias or insufficient local staff training/incentivization. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Early Budget Sunset: Overpaying for Peak Momentum | Process/Financial | A1 | Financial Controller & Budget Owner | CRITICAL (20/25) |
| FM2 | The Hub Stagnation: Quality Control Overwhelms Throughput | Technical/Logistical | A2 | Reverse Logistics & Asset Recovery Manager | CRITICAL (20/25) |
| FM3 | The Partner Backlash: Tone Deafness Kills Compliance | Market/Human | A3 | CSR Communications & Virality Lead | CRITICAL (15/25) |
| FM4 | The Inspection Exodus: QA Staffing Collapse Delays Reentry | Process/Financial | A5 | Quality Assurance & Material Auditor | CRITICAL (16/25) |
| FM5 | The Data Blackout: System Instability Corrupts Financial Truth | Technical/Logistical | A6 | IT/Data Integration Specialist | CRITICAL (20/25) |
| FM6 | The Seasonal Slump: Consumer Effort Fails in Adverse Conditions | Market/Human | A4 | Consumer Behavior & Incentive Strategist | CRITICAL (15/25) |
| FM7 | Brand Dilution: The Supermarket Takeover of Shared Messaging | Market/Human | A7 | CSR Communications & Virality Lead | HIGH (12/25) |
| FM8 | The Municipal Insubordination: Subsidy Withheld, Channels Freeze | Process/Financial | A9 | Regulatory & Compliance Officer | CRITICAL (15/25) |
| FM9 | The Hidden Cost of Quality: 3PL Redundancy Failure | Process/Financial | A8 | 3PL Auditor | HIGH (12/25) |


### Failure Modes

#### FM1 - The Early Budget Sunset: Overpaying for Peak Momentum

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial Controller & Budget Owner
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
High initial consumer engagement driven by the aggressive 5 DKK incentive (Decision 1) hits the 1.1M DKK donation threshold in Q3, prematurely triggering the incentive reduction to 3 DKK before the Q4 volume surge is captured. This rapid drop in perceived value causes a failure-to-launch in Q4, resulting in total returns falling to 95,000 units (missing the 108,000 target). The subsequent early funding collapse forces the marketing team to cease all paid amplification mid-campaign, failing the 20M organic impression goal. The financial rigidity of the incentive structure, not logistical failure, stops the campaign dead.

##### Early Warning Signs
- Donation expenditure hits 700,000 DKK before July 15, 2026 (end of Q2 Pilot).
- Cumulative crate returns are not tracking at 1.1x the forecasted linear growth rate by August 1, 2026.
- Consumer Behavior Strategist flags that 80% of Q3 returns are single-crate transactions, indicating low investment in the incentive mechanism.

##### Tripwires
- Donation spend reaches 1,000,000 DKK before September 1, 2026
- Projected Q4 return volume drops by >50% following mandatory incentive rate change.

##### Response Playbook
- Contain: Immediately pause all marketing spend not directly linked to supermarket channel support (Decision 13) until return rate stabilizes against the new 3 DKK incentive.
- Assess: Consumer Behavior Strategist calculates the precise percentage drop in daily returns attributable to the rate change and models revised total return projection for the year-end.
- Respond: If projected returns fall below 100,000 units, immediately reallocate 150,000 DKK from the Logistics infrastructure budget into a temporary, targeted 5 DKK 'Bonus Match' campaign for the final 30 days of Q4 to salvage volume.


**STOP RULE:** Total documented expense (Donation + Logistics overrun) exceeds 4.2 Million DKK by October 31, 2026.

---

#### FM2 - The Hub Stagnation: Quality Control Overwhelms Throughput

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Reverse Logistics & Asset Recovery Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The reliance on the intensive Pioneer Protocol (ultrasonic cleaning, Decision 3, Choice 2) at centralized 3PL hubs (Decision 4, Choice 1) creates a systemic choke point. Given high contamination/damage variance from mixed collection channels (municipal/retail), the cleaning facilities cannot process inputs fast enough. Asset Reintroduction Timelines (Decision 14) slip by 6 weeks. This backlog of quarantined crates means Arla procurement continues ordering new stock well into Q4 2027, failing the 2027 production reduction goal and causing the calculated CO2 avoidance metric for 2026 to be artificially low, damaging the CSR report.

##### Early Warning Signs
- Third-party washing facility output falls below 85% of weekly committed capacity for three consecutive weeks in Q3.
- Inventory of quarantined, cleaned but unverified crates exceeds 30,000 units at the Central Hubs by October 15, 2026.
- The Reverse Logistics Manager reports a 3rd party breach of SLA related to sanitation verification failure.

##### Tripwires
- Asset Velocity Score (re-entry rate) falls below 50% of target for 14 consecutive days.
- Contamination rejection rate at the cleaning hub exceeds 18% of incoming volume in any month.

##### Response Playbook
- Contain: Immediately implement Decision 6, Choice 1 (delegate *gross damage* rejection authority upfront) to offload 3PL hubs, accepting short-term variance for long-term throughput stabilization.
- Assess: Circular Economy Consultant leads an emergency cost-benefit analysis on routing low-grade, non-reusable plastic directly to external recycling (Opportunity 2) rather than through expensive ultrasonic cleaning.
- Respond: Re-negotiate existing 3PL contracts, shifting payment structure from fixed weekly capacity to cost-per-item processed, leveraging financial leverage to incentivize throughput.


**STOP RULE:** If inventory backlog exceeds 45,000 crates, and the 90-day reintroduction SLA cannot be met for 30% of older batches, permanently route all new Q4 collection volume directly to external recycling until cleaning capacity is fixed or decoupled.

---

#### FM3 - The Partner Backlash: Tone Deafness Kills Compliance

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: CSR Communications & Virality Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The 'irreverent' marketing tone (Decision 5, Choice 2) is deemed unacceptable by one or more major supermarket partners during the mandatory pre-approval vetting process. This leads to active non-compliance; partners refuse to dedicate in-store staff time to the lightweight count-and-report mechanism (Risk 6 context) or actively de-prioritize visible crate drop-offs. This causes a measurable 30% reduction in primary channel compliance during Q3/Q4, suffocating the predictable inbound flow needed to meet the 40% volume target, regardless of the consumer incentive level.

##### Early Warning Signs
- Supermarket Relationship Coordinator reports >1 stakeholder requesting narrative changes by March 31, 2026.
- Pilot collection stations show a 15% deviation in compliance tracking against stores with 100% approved signage deployment by June 30.
- Earned media sentiment tracking shows a >= 20% negative shift based on stakeholder feedback mention rates.

##### Tripwires
- Formal rejection of the 'secret lives' narrative by two of the three major supermarket chains.
- Average in-store transaction time (Risk 6 metric) exceeds 90 seconds in pilot stores due to poorly adhered-to SOPs.

##### Response Playbook
- Contain: Immediately halt all production of approved 'irreverent' assets and pivot all marketing execution to the secondary testimonial/CO2 impact focus (Decision 5, Choice 3).
- Assess: Stakeholder Relations Coordinator runs a rapid 72-hour audit, quantifying the logistical compliance gap created by the alienated partner(s) to forecast Q3 volume loss.
- Respond: Reallocate 50% of the remaining Marketing budget to targeted, hyper-local paid media campaigns focused exclusively on driving traffic to the municipal collection channel (Decision 8) to offset potential primary channel loss.


**STOP RULE:** If the compliance rate with the primary supermarket channel drops below 65% sustained over four weeks in Q3, immediately freeze all cash flow to the CSR Communications team and task the Financial Controller to prepare funding for a municipal-only campaign pivot.

---

#### FM4 - The Inspection Exodus: QA Staffing Collapse Delays Reentry

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Quality Assurance & Material Auditor
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The specialized quality assurance team (15 FTEs) required for the Pioneer Protocol experiences high early attrition due to the rigorous, repetitive nature of ultrasonic testing and the high stakes associated with food-grade certification. Unexpected staff departures (exceeding 30% attrition by end of Q3) mean the remaining team can only process 60% of throughput capacity. This directly overburdens the logistics budget (Risk 8) as crates sit idle waiting for inspection, increasing storage costs by 80,000 DKK per month in excess warehousing fees, leading to budget exhaustion.

##### Early Warning Signs
- Projected Q3 inspector onboarding completion falls below 95% compliance by July 1, 2026.
- Voluntary or involuntary attrition rate among specialized QA staff exceeds 10% over any 90-day period in Q3.
- Weekly utilization reports show QA team overtime hours exceeding 40 hours/person consistently across two hubs.

##### Tripwires
- If the mandatory Q3/Q4 specialized training attendance rate for new hires is <85% across all facilities.
- If the percentage of non-reusable crates being routed to external recycling (due to inspection backlog) tops 40% of total intake.

##### Response Playbook
- Contain: Immediately halt all Q3 national marketing spend not directly tied to supermarket partnerships and divert funds to an emergency recruitment agency focused solely on high-volume QA technicians.
- Assess: Reverse Logistics Manager conducts an immediate audit of non-inspected crates to classify them into 'High-Risk Reintroduction' vs. 'Guaranteed Recycling' piles to clear the bottleneck backlog manually.
- Respond: Freeze the requirement for ultrasonic testing on crates sourced *only* from the supermarket channel for 30 days, replacing it with a lower-cost, third-party-audited chemical residue test, saving inspector time for high-variance municipal returns.


**STOP RULE:** If the inventory of uninspected crates exceeds 50,000 units by October 31, 2026, permanently reroute all incoming volume to external recycling, accepting the failure of the 2027 production reduction goal to preserve the logistics budget.

---

#### FM5 - The Data Blackout: System Instability Corrupts Financial Truth

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A6
- **Owner**: IT/Data Integration Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The real-time digital tracking systems—including the lightweight mobile app for collection point reporting and the financial ledger integration for the Consumer Claims Administrator—suffer from critical instability during the Q3 national rollout. The system fails to sync reliably when dealing with the combined volume from both channels, leading to data corruption. This results in inaccurate CPRC reporting (Missing Assumption 1), forcing the Financial Controller to halt disbursement of municipal subsidies (Decision 8, Choice 2) because liability cannot be verified, leading to municipal partner withdrawal and a capacity collapse in the secondary collection channel.

##### Early Warning Signs
- The Financial Controller reports data reconciliation variances >1% between system logs and physical receipt counts weekly in Q3.
- The mobile application reports ambient downtime exceeding 30 minutes per collection center over a single weekend.
- The Quality Assurance system fails to capture the required structural metadata for 5% of inspected crates in the Q2 pilot.

##### Tripwires
- The Data Blackout lasts for more than 10 consecutive working hours during peak Q3 collection periods.
- The system reconciliation variance exceeds 3% for two consecutive weeks, triggering a manual audit suspension.

##### Response Playbook
- Contain: Immediately revert all collection sites to manual, paper-based triage logs, authorized by the Regulatory Officer, and institute a centralized data entry triage team run by 5 contractors.
- Assess: IT Specialist isolates the failure component—whether it is the front-end collection app or the back-end ledger sync—and prioritizes a hotfix deployment for the identified weak point.
- Respond: Re-authorize municipal subsidy payments based on verified paper logs retroactively, using the Regulatory Officer's sign-off as temporary financial indemnity to secure immediate municipal channel cooperation.


**STOP RULE:** If data integrity cannot be assured (variance >5%) and the primary financial ledger is unverifiable for more than one full week during Q4, permanently shut down all digital confirmation systems and pivot to a purely volumetric reporting structure, accepting loss of quality tracking granularity.

---

#### FM6 - The Seasonal Slump: Consumer Effort Fails in Adverse Conditions

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Consumer Behavior & Incentive Strategist
- **Risk Level:** CRITICAL 15/25 (Likelihood 5/5 × Impact 3/5)

##### Failure Story
The assumption that consumer behavior is stable throughout the year proves false. During the Q1 2027 transition phase (when incentives drop from 5 DKK to 1 DKK), a combination of persistently poor winter weather (rain/snow) and natural consumer fatigue causes the return rate to collapse by 80% week-over-week. The lack of a robust 'Crate Passport' loyalty system (Opportunity 1) means intrinsic motivation is insufficient to overcome the high transactional friction of returning crates in bad weather. This results in a failure to meet the marginal 2027 recovery quota needed to save significant operating costs, leading to the loss of political support for year two of the logistics framework.

##### Early Warning Signs
- Q4 2026 return volume fails to maintain 60% of the Q3 peak volume by the final week of December.
- Exit survey data (from the 200 pilot participants) shows that >50% cite 'lack of good weather' as a reason for delayed returns.
- The loyalty system adoption rate for the Crate Passport falls below 25% by Q4 end.

##### Tripwires
- Weekly return volume drops by 75% or more between Week 48 and Week 1 of 2027.
- Consumer Claims Administrator reports that physical receipt retrieval/validation time averages >3 minutes per transaction in January 2027.

##### Response Playbook
- Contain: Immediately re-launch a small, high-visibility, weather-themed incentive (e.g., 10 DKK matched donation for the first 500 returns during weeks with >10cm snowfall) funded by the residual marketing budget contingency.
- Assess: Loyalty Program Architect conducts an immediate root cause analysis on why the Crate Passport habit-forming incentive failed to override seasonal friction, designing a mechanism to temporarily remove transactional friction (e.g., temporary supermarket-only acceptance point).
- Respond: Freeze all further asset reintroduction costs (Decision 14) for Q1 2027; consolidate all remaining available assets into long-term storage until Q2 weather improves, prioritizing budget preservation based on the low return rate.


**STOP RULE:** If return volume remains below 30% of the Q4 2026 average for six consecutive weeks in Q1 2027, formally declare the campaign a successful 2026 volume capture effort and exit the high-cost reverse logistics framework, routing remaining stock only through normal municipal streams.

---

#### FM7 - Brand Dilution: The Supermarket Takeover of Shared Messaging

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: CSR Communications & Virality Lead
- **Risk Level:** HIGH 12/25 (Likelihood 4/5 × Impact 3/5)

##### Failure Story
Assumption A7 proves false: Consumers aggressively conflate the 5 DKK charitable donation with the high-visibility co-branding offered to the top supermarket partners (Decision 13, Choice 1). Marketing analysis reveals that 70% of social media conversation frames the return not as a commitment to Arla's CSR goals, but as participation in a supermarket loyalty program. This message dilution weakens the emotional anchor point for the viral narrative, causing the organic impression goal (20M) to be missed by 40%. Consequently, the project fails to secure the necessary earned media to sustain momentum into Q4, impacting overall consumer urgency.

##### Early Warning Signs
- Social media sentiment analysis shows >60% of positive crate return mentions tagging a specific retail partner rather than Arla or the Foundation.
- Focus groups indicate consumers believe the 5 DKK is a direct store discount rather than a donation.
- Supermarket partners begin pushing their own internal recycling metrics over the shared environmental goals.

##### Tripwires
- If the Share of Voice (SOV) for 'Arla' or 'Foundation' in campaign discussions drops below 40% for two consecutive weeks in Q3.
- If Coop's promotional materials relating to the crate return are observed in-store more prominently than the mandated Arla Foundation signage.

##### Response Playbook
- Contain: Issue a mandatory, immediate internal communications directive to all partners halting future co-branding discussions until the next governance review, focusing all new messaging solely on the 106-tonne CO2 metric.
- Assess: Behavioral Economist quantifies the projected deficit in organic impressions and assesses the remaining paid media budget's effectiveness under the revised, clear messaging.
- Respond: Redirect the remaining 1.0M DKK marketing budget to high-impact digital video ads run by Arla, focusing purely on the 'secret life' humor but conspicuously removing all retail partner logos to re-establish brand control.


**STOP RULE:** If the campaign fails to achieve 10 million organic impressions by the end of Q3, immediately cease all creative production and reallocate the remaining marketing budget to funding extended Q1 2027 residual donation matching (mitigating Threat 4).

---

#### FM8 - The Municipal Insubordination: Subsidy Withheld, Channels Freeze

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Regulatory & Compliance Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Assumption A9 proves false: Municipal staff, lacking sufficient dedicated training (Decision 8) and feeling marginalized by the supermarket pilot focus, refuse to enforce the liability transfer threshold (Decision 12). When the Regulatory Officer attempts to release operational subsidies contingent on signed SLAs (Data Item 4), several Tier 1 cities refuse, citing non-adherence to local waste sorting jurisdiction. This forces the immediate collapse of the municipal collection channel, shifting 30% of anticipated national volume back onto supermarkets, which are already operating near capacity. The resulting logistical failure forces a costly rerouting of transport assets, pushing the operational CPRC (Risk 8) over the 25 DKK/crate threshold, burning the logistics budget by 400,000 DKK.

##### Early Warning Signs
- Regulatory Officer reports that payment authorization for Q3 municipal subsidies is delayed by >15 days past the agreed-upon SLA date.
- Spot audits reveal that 10 municipalities' triage scores are wildly inconsistent with the defined protocol (>20% variance in rejection rates).
- Stakeholder Relations reports initial meetings scheduled to onboard Q3 municipal staff have been cancelled by local authorities.

##### Tripwires
- If more than 5 Tier 1 municipalities refuse final subsidy release by Q3 start.
- If the percentage of total returns coming from the municipal channel during the first two weeks of Q3 is less than 5%.

##### Response Playbook
- Contain: Immediately halt all communications regarding subsidy payments to non-compliant municipalities and issue a formal notice of SLA breach.
- Assess: Reverse Logistics Manager conducts an emergency simulation to identify the minimum logistics footprint required to service the confirmed supermarket-only network for Q3/Q4.
- Respond: Reallocate the frozen municipal subsidy budget (€100k) to aggressively fund the purchase and deployment of high-throughput, 'no-touch' automated collection bins (Suggestion 1 Lesson Learned) directly inside the remaining high-performing supermarkets to absorb the shortfall.


**STOP RULE:** If the total national return volume falls below 30% of the established Q3 forecast by the end of August due to collection channel failure, halt all further logistics expansion and redirect remaining funds to the Charitable Donation mechanism to salvage the foundation support goal.

---

#### FM9 - The Hidden Cost of Quality: 3PL Redundancy Failure

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: 3PL Auditor
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption of adequate 3PL redundancy fails when one of the primary third-party food-grade washing facilities suffers a catastrophic mechanical failure (e.g., ultrasonic unit break) in early Q4. Due to poor contractual safeguards (lack of embedded slack/redundancy), the facility cannot bring a backup line online within the 48-hour window specified in the SLA. This forces the immediate rerouting of all crates from that node to the remaining operational hubs. The massive surge in load causes the other two hubs to bottleneck severely, validating Risk 2, and trapping 50,000 crates in a queue for 4 weeks. This necessitates writing down the associated anticipated CO2 savings for 2026, as these assets are deemed too slow to reintroduce to meet the year-end reporting metric.

##### Early Warning Signs
- 3PL cleaning audit flags a single facility with a maintenance schedule that shows no provision for immediate backup line activation.
- The contracted maintenance vendor for Facility X reports a non-critical equipment failure that will necessitate shutdown for >24 hours.

##### Tripwires
- A single 3PL facility reports an unplanned outage exceeding 24 hours during the Q4 peak return window.
- The backlog of dirty crates awaiting cleaning increases by a cumulative 10,000 units in one week due to external service disruption.

##### Response Playbook
- Contain: Immediately institute a 50% temporary reduction in the quality grading strictness (Decision 3) for the affected node's incoming crates, routing high-risk items directly to external recycling at a fixed low rate to clear the shortest-term backlog.
- Assess: Quality Assurance Manager performs an emergency audit on the remaining two hubs to ensure quality standards are not slipping under the load increase, prioritizing structural integrity reports over residue testing.
- Respond: Issue a clawback penalty notice to the non-compliant 3PL equal to 50% of their weekly service fee and utilize the contingency fund to secure a temporary, smaller, certified mobile cleaning unit (if available) to supplement processing capacity.


**STOP RULE:** If the total backlog of crates awaiting processing exceeds 75,000 units for more than 10 business days in Q4, trigger the contingency plan to purchase 50,000 *new* replacement crates to cover the immediate projected 2027 shortfall, effectively capping the scope of the reverse logistics operation for the year.
