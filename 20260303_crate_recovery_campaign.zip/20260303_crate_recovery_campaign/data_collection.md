## 1. Q2 Pilot Channel Cost & Quality Viability

This data is critical as the unquantified cost difference between the dual collection channels (Risk 8) threatens the overall budget viability and effectiveness of the Q3 national rollout plan.

### Data to Collect

- Total operational cost per recovered crate from Supermarket Channel (DKK/crate)
- Total operational cost per recovered crate from Municipal Channel (DKK/crate)
- Contamination rejection rate (%) per channel
- Average time (minutes) for consumer transaction per channel

### Simulation Steps

- Use Microsoft Excel or Google Sheets to establish a cost reconciliation model comparing fixed overhead allocation against return volume data captured during the Q2 pilot.
- Simulate the impact of a 30% cost increase in the Municipal Channel on the overall 1.65M DKK logistics budget using sensitivity analysis.

### Expert Validation Steps

- Consult the Financial Controller & Budget Owner to validate the cost allocation methodology across channels.
- Consult the Circular Economy Consultant to confirm if channel cost differences justify deviations from the specified Pioneer Channel Prioritization (Decision 2).

### Responsible Parties

- Reverse Logistics & Asset Recovery Manager
- Financial Controller & Budget Owner

### Assumptions

- **High:** Cost tracking mechanisms implemented during the Q2 pilot will be sufficient to accurately segment operational expenditure between retail and municipal channels.

### SMART Validation Objective

By June 30, 2026, calculate the Cost Per Recovered Crate (CPRC) for both Supermarket and Municipal channels; the Municipal CPRC must not exceed 1.2x the Supermarket CPRC to confirm feasibility for Q3 nationwide expansion.

### Notes

- This addresses the missing assumption recognized by the Circular Economy Consultant regarding operational cost viability.


## 2. Marketing Tone Pre-Approval Status

The high-risk marketing tone (Decision 5) directly jeopardizes key supermarket partnerships, threatening the operational success of the primary collection channel.

### Data to Collect

- Formal sign-off documentation from Salling Group, Coop Danmark, and Rema 1000 on the 'Irreverent Marketing Narrative' (Decision 5, Choice 2).
- Date of submission and date of final approval/rejection for creative assets.

### Simulation Steps

- If rejections occur, use a budget allocation tool (e.g., internal finance software) to simulate the campaign spend re-routing based on the immediate activation of Decision 5, Choice 3 (Testimonial/CO2 Focus).

### Expert Validation Steps

- Consult the Stakeholder Relations & Partnership Coordinator to confirm written partnership sign-off on all core creative assets.
- Consult the Behavioral Economist regarding the expected impact on organic impressions if the marketing tone shifts from 'irreverent' to 'testimonial-focused'.

### Responsible Parties

- CSR Communications & Virality Lead
- Stakeholder Relations & Partnership Coordinator

### Assumptions

- **Medium:** Supermarket partners will respond to marketing pre-approval requests within a 10-day window.

### SMART Validation Objective

By end of Q1 2026 (March 31), secure written approval from all three major supermarket partners confirming the 'irreverent' narrative is acceptable, or the marketing execution plan must be definitively pivoted to the secondary posture.

### Notes

- This addresses the Behavioral Economist's concern regarding stakeholder conflict with the high-risk marketing posture.


## 3. Crate Quality Grading Protocol Audit Schedule & Results (Q2 Pilot)

The Pioneer strategy relies on stringent centralized cleaning; validating the quality control effectiveness and cost/quality variance between channels is crucial for supply chain integrity and budget.

### Data to Collect

- Weekly audit reports from the Quality Assurance team detailing contamination rejection rates at the centralized cleaning hubs.
- Metrics on percentage of re-rejected crates that were initially triaged by supermarket staff versus municipal staff.
- Cost reconciliation report for third-party food-grade washing facilities (DPK/crate processed).

### Simulation Steps

- Run a scenario analysis modeling the financial impact (Risk 5) if contamination rejection rates exceed 15% of the total Q2 intake, requiring replacement stock orders.
- Simulate the impact of reducing the outsourcing commitment (Decision 4, Choice 1) by 20% if third-party processing costs exceed the negotiated benchmark (e.g., 12 DKK/crate).

### Expert Validation Steps

- Consult the Quality Assurance & Material Auditor to certify the audit findings and confirm adherence to the Pioneer Protocol specifications.
- Consult the Circular Economy Consultant to verify if the realized contamination rates justify the strict downstream ultrasonic cleaning mandate (Decision 3, Choice 2).

### Responsible Parties

- Quality Assurance & Material Auditor
- Reverse Logistics & Asset Recovery Manager

### Assumptions

- **High:** The specialized inspection staff (15 FTEs) will be fully recruited and trained by April 15, 2026, to handle Q2 influx volumes.

### SMART Validation Objective

By July 15, 2026, analyze Q2 pilot data confirming that the combined contamination rejection rate from both collection channels is less than 10% of total returns, and the average processing cost at third-party hubs is below 15 DKK/crate.

### Notes

- Addresses Circular Economy Consultant's concern about logistics bottlenecks and QA latency.


## 4. Municipal Channel Readiness & Liability Finalization

Municipal channel readiness is a known risk (Risk 4) dependent on complex legal agreements (MoUs/Indemnity) required for Q3 national rollout.

### Data to Collect

- Copies of signed Memorandums of Understanding (MoUs) detailing Service Level Agreements (SLAs) for Q3/Q4 capacity with target municipal waste authorities (Decision 8).
- Executed, legally binding indemnity agreements for Triage Liability Transfer (Decision 12, Choice 1) with relevant municipal legal departments.
- Finalized budget allocation for the operational subsidy per collection day (Decision 8, Choice 2).

### Simulation Steps

- Map the agreed service footprint against baseline consumer location data to identify any coverage gaps exceeding 5km radius from a collection point, simulating potential volume loss in those areas.

### Expert Validation Steps

- Consult the Regulatory & Compliance Officer to ensure all indemnity agreements are legally sound and meet Danish regulatory standards for waste handling.
- Consult the Stakeholder Relations & Partnership Coordinator to confirm that the operational subsidies (if any) finalize the partnership structure required for municipal buy-in.

### Responsible Parties

- Regulatory & Compliance Officer
- Stakeholder Relations & Partnership Coordinator

### Assumptions

- **Medium:** The standard municipal waste authority SLA terms can be adapted to cover the required Arla-specific segregation and triage responsibilities by the specified deadline.

### SMART Validation Objective

By March 31, 2026, secure fully executed, legally vetted liability transfer agreements with at least 50% of the priority Tier 1 DKK municipalities designated for the Q3 national rollout.

### Notes

- This action is critical to de-risk the municipal channel capacity before Q2 pilot commences dependency.

## Summary

The immediate focus must be on validating the financial and legal prerequisites for the aggressive 'Pioneer' strategy. Highest priority tasks are securing the marketing tone approval from supermarket partners (Data Item 2) to prevent operational friction, confirming the cost viability of the dual-channel approach via Q2 pilot data analysis (Data Item 1), and finalizing crucial legal agreements with municipal authorities to de-risk the Q3 national rollout capacity (Data Item 4). Data Item 3 validates the quality control process that underpins the Pioneer strategy's material reuse claims.