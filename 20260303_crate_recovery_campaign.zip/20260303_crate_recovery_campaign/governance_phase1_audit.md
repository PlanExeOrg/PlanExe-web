
## Audit - Corruption Risks

- Kickbacks or bribery paid to supermarket managers or municipal waste authority staff to secure preferential access, designated high-traffic placement for collection bins, or to overlook procedural violations in the 'lightweight count-and-report mechanism' (Risk 6).
- Nepotism or conflicts of interest in awarding the short-term contracts for third-party food-grade washing facilities; favoring an affiliated company despite higher costs than available market alternatives (Decision 4, Choice 1).
- Misuse of authority by Arla-contracted personnel (if deployed at municipal stations per Decision 8, Choice 3) by accepting crates that clearly violate established Crate Quality Grading Protocols in exchange for informal favors or kickbacks from consumers.
- Trading favors where supermarket partners receive preferential delivery scheduling or reduced fees on Arla products in return for ensuring high compliance and dedicated floor space for crate drop-off points (leveraging Decision 13).
- Misuse or fraudulent reporting of returned crates by collection personnel (supermarket staff or logistics contractors) to inflate numbers, thus artificially increasing the corresponding DKK donation to the Arla Foundation, leading to fictitious charitable contributions.

## Audit - Misallocation Risks

- Budgetary funds allocated for Marketing (1.0M DKK) being diverted to cover unexpected, high operational costs incurred by the centralized cleaning hubs due to underestimated throughput times or excessive third-party washing charges (Risk 2 and Risk 8).
- Double spending on replacement crates; ordering buffer stock (Decision 10, Choice 2 or 1) while simultaneously failing to prioritize the reintroduction of recovered crates rapidly enough, leading to increased inventory holding costs and delayed CO2 avoidance realization (Decision 14 conflict).
- Misallocation of specialized personnel (15 inspectors) resources toward non-core quality assurance tasks (e.g., minor marketing asset creation) instead of critical ultrasonic integrity verification at cleaning hubs, leading to bottlenecking (Risk 2, Assumption 3).
- Misuse of logistics budget (1.65M DKK) resulting from relying too heavily on the supermarket channel during the pilot (Decision 2, Choice 1), leading to inefficient routing costs compared to the expected efficiency of the dual-channel model.
- Diverting recovered crates designated for primary supply chain reuse back into secondary uses (Decision 11, Choice 2) for the Arla Foundation without formally writing down the corresponding financial value against the 1.35M DKK donation budget, potentially overstating the Foundation's received value relative to the physical asset cost.

## Audit - Procedures

- Quarterly independent financial audit focusing specifically on reconciliation between the DKK donation disbursements (tracking vouchers/digital records) and the confirmed return volume received by the Arla Foundation, with specific analysis on the first 50,000 tiered returns if applicable.
- Bi-weekly review (during Q2 Pilot and Q3/Q4 rollout) by Internal Audit of the 'lightweight count-and-report mechanism' data feed from supermarkets and municipal stations against physical spot-checks conducted by Arla logistics teams for accuracy (Risk 6 validation).
- Mandatory Pre-Reintroduction Quality Assurance Audit, scheduled monthly, to verify compliance of cleaned crates with food-grade sanitation standards and structural integrity requirements before release back into the 2027 production pool (Decision 14 and Assumption 3).
- Compliance check (end of Q2) to review the executed indemnity agreements with all Municipal Waste Authorities (Decision 12), ensuring liability transfer protocols are legally sound and operational guidelines for triage are consistently applied across all participating stations.
- A compliance review of marketing expenditure against social media impression targets (Goal: 20M organic impressions). If paid media exceeds 25% of the marketing budget (1.0M DKK), trigger a root-cause analysis into the 'irreverent/humorous' tone's effectiveness (Risk 3).

## Audit - Transparency Measures

- Establish a public-facing, real-time dashboard tracking the cumulative DKK donated to Arla Foundation and the estimated Tonnes of CO2 Avoided, updated weekly, to demonstrate progress against both charity (500k DKK min) and environmental goals.
- Publish standardized inspection checklists and criteria used for the Crate Quality Grading Protocol (Decision 3) on the Arla corporate website, allowing consumer groups or regulators to benchmark acceptance/rejection standards.
- Mandatory publication of procurement records (anonymized where necessary) for all major contracts, particularly the short-term agreements with third-party food-grade washing facilities, detailing cost-per-crate processed against industry benchmarks (Risk 8).
- Maintain a public log detailing the status of the Tiered Incentive Structure (if adopted) or, failing that, a clear communication detailing when the fixed 5 DKK donation ceiling is approached or reached, demonstrating adherence to the budget ceiling (Risk 1).
- Publish sanitized minutes from supervisory meetings involving Arla Foods and the major Supermarket Groups detailing operational challenges and resolutions related to in-store drop-off procedures (Decision 13), ensuring partner compliance transparency.