**Budget Request Exceeding PSC Commitment Threshold**
Escalation Level: Arla Executive Steering Group
Approval Process: Executive Board Review and Mandate
Rationale: Request exceeds the PSC's authorized single expenditure threshold of 500,000 DKK, requiring ultimate financial sign-off by the highest executive level.
Negative Consequences: Project stall due to lack of funding approval or delayed commitment, impacting Q3 rollout timeline.

**Confirmed Logistical Bottleneck: Cleaning Hub Throughput Reduction**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Strategic Risk Review and Contingency Mandate Vote
Rationale: The Core Execution Team (CET) has identified a sustained (3+ days) throughput miss exceeding 20% capacity, signaling a critical operational risk (Risk 2) that exceeds CET operational authority.
Negative Consequences: Failure to reintroduce assets quickly jeopardizes the 2027 production reduction goal and delays CO2 offset realization.

**Critical Quality Failure: Third-Party Cleaning Hub Fails Audit**
Escalation Level: Compliance & Stewardship Assurance Body (CSAB) -> PSC
Approval Process: Issuance of Non-Compliance Notice (NCN) followed by PSC vote on immediate contract termination.
Rationale: The CSAB identifies evidence of contamination or critical food-grade standard breach at an outsourced hub, posing direct liability and quality risk (Risk 5 / Assumption 3 invalidation).
Negative Consequences: Potential food safety recall, mandatory escalation to regulators, and immediate need for emergency logistics capacity replacement.

**Major Scope Deviation: Shifting from Pioneer Strategy (E.g., Implementing Municipal Channel Early)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Strategic Review and Re-ratification of Project Charter
Rationale: Any change that fundamentally alters the Pioneer Strategy—such as introducing the municipal channel during the Q2 pilot phase—violates the constraints set by the PSC and requires strategic re-authorization.
Negative Consequences: Introduction of unmanaged risk associated with incomplete MoUs (Risk 4) and potential incompatibility between pilot logistics (supermarket-only) and new routes.

**Reputational Escalation: Major Partner (Supermarket Group) Withdraws Compliance**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Executive Sponsor intervention and negotiation review; requires PSC mandate for counter-offer/mediation.
Rationale: A primary supermarket group formally threatens to cease support or withdraw dedicated staffing, jeopardizing the primary collection channel needed for volume targets (Risk 6/Decision 13 conflict).
Negative Consequences: Significant reduction in collection points, leading to immediate failure to meet 40% volume target and damaging long-term Arla retail relationships.

**Evidence of Misallocation or Donation Fraud**
Escalation Level: Compliance & Stewardship Assurance Body (CSAB) -> Arla Executive Board
Approval Process: Formal Non-Compliance Notice (NCN) issued by CSAB, followed by immediate referral to Arla Internal Audit/Legal for external investigation.
Rationale: The CSAB audit process identifies material evidence or systemic failures in the reconciliation of the 5 DKK charitable donation (Audit Procedure 1 execution), exceeding the PSC's resolution capability.
Negative Consequences: Severe reputational damage to Arla Foods and Arla Foundation, potential legal penalties, and immediate termination of the campaign.