This plan involves money.

## Currencies

- **USD:** Used for budgeting and reporting, as it is a stable international currency.
- **CHF:** Local currency for Switzerland, where World Athletics Headquarters is located.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. CHF may be used for local transactions in Switzerland. Hedging strategies may be necessary to mitigate exchange rate fluctuations.