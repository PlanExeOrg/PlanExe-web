**Purpose:** business

**Purpose Detailed:** Implementation of a mandatory biological verification program for female athletes in World Athletics sanctioned events, including hormonal analysis, genetic screening, and physical examinations, to ensure fair competition and compliance with eligibility regulations.

**Topic:** Global Biological Verification Program for Female Athletes