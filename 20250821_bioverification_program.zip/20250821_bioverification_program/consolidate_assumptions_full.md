# Purpose

**Purpose:** business

**Purpose Detailed:** Implementation of a mandatory biological verification program for female athletes in World Athletics sanctioned events, including hormonal analysis, genetic screening, and physical examinations, to ensure fair competition and compliance with eligibility regulations.

**Topic:** Global Biological Verification Program for Female Athletes

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan involves a complex, global operation with significant physical requirements. It includes: 1) Physical examinations by certified endocrinologists. 2) Collection and analysis of biological samples (hormonal analysis, genetic screening) which requires physical labs and equipment. 3) Establishing physical testing locations across 214 member federations. 4) Managing a secure database, which, while digital, is directly tied to physical athlete data and requires secure physical infrastructure. 5) A rigid protocol for communicating results and managing appeals, which likely involves physical meetings and documentation. The budget also suggests significant physical infrastructure and personnel costs. Therefore, the plan is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Laboratories for hormonal analysis and genetic screening
- Secure facilities for data storage and management
- Testing locations across 214 member federations
- Certified endocrinologists for physical examinations

## Location 1
Switzerland

Lausanne

World Athletics Headquarters

**Rationale**: As the headquarters of World Athletics, Lausanne serves as a central coordination point for the program's global operations, including governance, data management, and communication.

## Location 2
Global

Accredited Laboratories

WADA-accredited laboratories worldwide

**Rationale**: Utilizing WADA-accredited laboratories ensures high standards for sample analysis and data integrity, supporting the program's scientific rigor and legal defensibility across all member federations.

## Location 3
Global

Regional Training Centers

Designated training facilities in key regions

**Rationale**: Establishing regional training centers facilitates standardized training for personnel across member federations, ensuring consistent implementation of testing protocols and data management practices.

## Location Summary
The plan requires a central coordination point in Lausanne (World Athletics HQ), accredited laboratories globally for sample analysis, and regional training centers to ensure standardized implementation across all member federations.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** Used for budgeting and reporting, as it is a stable international currency.
- **CHF:** Local currency for Switzerland, where World Athletics Headquarters is located.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. CHF may be used for local transactions in Switzerland. Hedging strategies may be necessary to mitigate exchange rate fluctuations.

# Identify Risks


## Risk 1 - Regulatory & Permitting
GDPR compliance failures could lead to significant fines and legal challenges. The program involves collecting and processing sensitive athlete data, including hormonal levels and genetic information. Failure to adhere to GDPR regulations regarding data storage, processing, and transfer could result in substantial penalties.

**Impact:** Fines ranging from 4% of annual global turnover or 20 million EUR (whichever is greater), legal injunctions, and reputational damage. A delay of 3-6 months to rectify compliance issues.

**Likelihood:** Medium

**Severity:** High

**Action:** Conduct a thorough GDPR compliance audit. Implement robust data protection measures, including encryption, access controls, and data minimization. Appoint a Data Protection Officer (DPO) and provide regular GDPR training to all personnel involved in data handling.

## Risk 2 - Regulatory & Permitting
Challenges to the 'World Athletics Eligibility Regulations for Female Classification' in the Court of Arbitration for Sport (CAS). The program's criteria for female eligibility may be challenged by athletes or advocacy groups, potentially leading to legal battles and revisions to the program.

**Impact:** Legal costs of $500,000 - $1,000,000 USD, potential program suspension pending legal resolution, and reputational damage. A delay of 6-12 months to address legal challenges.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage legal experts to review and validate the program's criteria for female eligibility. Ensure that all procedures and criteria are scientifically sound, ethically justifiable, and legally defensible. Establish a clear and transparent appeals process for athletes who challenge the program's decisions.

## Risk 3 - Technical
Failure to establish a secure, GDPR-compliant central database for managing athlete biological passports and eligibility status. A data breach or system failure could compromise sensitive athlete data, leading to legal liabilities and reputational damage.

**Impact:** Data breach resulting in fines of up to 4% of annual global turnover, legal action from affected athletes, and reputational damage. System downtime of 1-2 weeks, disrupting program operations.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement robust cybersecurity measures, including encryption, firewalls, and intrusion detection systems. Conduct regular security audits and penetration testing. Establish a disaster recovery plan to ensure business continuity in the event of a system failure.

## Risk 4 - Technical
Inconsistencies or inaccuracies in hormonal analysis and genetic screening results across different laboratories. Variations in testing methodologies and equipment could lead to unreliable data and unfair outcomes for athletes.

**Impact:** Inaccurate eligibility assessments, unfair competition, and legal challenges from affected athletes. A delay of 2-4 weeks to investigate and resolve discrepancies.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish standardized testing protocols and quality control procedures for all participating laboratories. Implement proficiency testing programs to ensure consistent performance across laboratories. Regularly audit laboratories to verify compliance with established standards.

## Risk 5 - Financial
Budget overruns due to unforeseen expenses or inaccurate cost estimates. The initial setup cost of $50 million and annual operating budget of $15 million may be insufficient to cover all program expenses, especially considering the global scope and complex requirements.

**Impact:** Project delays, reduced program scope, and potential program termination. Cost overruns of 10-20%, requiring additional funding or budget cuts.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a detailed budget breakdown with contingency funds for unforeseen expenses. Regularly monitor program expenditures and compare them to the budget. Implement cost-control measures to minimize expenses without compromising program quality.

## Risk 6 - Operational
Logistical challenges in collecting and transporting biological samples from athletes across 214 member federations. Delays or mishandling of samples could compromise the integrity of the testing process.

**Impact:** Compromised sample integrity, inaccurate test results, and legal challenges from affected athletes. A delay of 1-3 weeks in sample processing.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a secure and efficient sample collection and transportation system. Provide clear instructions and training to personnel involved in sample handling. Implement chain-of-custody procedures to track samples from collection to analysis.

## Risk 7 - Social
Athlete resistance to mandatory hormonal analysis, genetic screening, and physical examinations. Athletes may object to the program on privacy, ethical, or religious grounds, leading to non-compliance and legal challenges.

**Impact:** Reduced athlete participation, negative publicity, and legal challenges. A decrease of 5-10% in athlete participation rates.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage with athlete representatives and advocacy groups to address their concerns and build support for the program. Provide clear and transparent information about the program's purpose, procedures, and benefits. Ensure that athletes' privacy and rights are protected.

## Risk 8 - Supply Chain
Disruptions in the supply of testing kits, reagents, and other essential materials. Shortages or delays in the supply chain could disrupt program operations and compromise the integrity of the testing process.

**Impact:** Delays in testing, inaccurate test results, and potential program suspension. A delay of 2-4 weeks in obtaining essential materials.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish relationships with multiple suppliers of essential materials. Maintain a buffer stock of critical supplies. Develop contingency plans to address potential supply chain disruptions.

## Risk 9 - Security
Cyberattacks targeting the central database or testing laboratories. Hackers could attempt to steal sensitive athlete data or disrupt program operations.

**Impact:** Data breach, system downtime, and reputational damage. A delay of 1-2 weeks to restore systems and data.

**Likelihood:** Low

**Severity:** High

**Action:** Implement robust cybersecurity measures, including firewalls, intrusion detection systems, and data encryption. Conduct regular security audits and penetration testing. Train personnel on cybersecurity best practices.

## Risk 10 - Operational
Difficulty in securing certified endocrinologists across all 214 member federations. Lack of qualified professionals could delay or compromise the physical examination component of the program.

**Impact:** Delays in athlete eligibility assessments, inconsistent examination quality, and potential legal challenges. A delay of 1-2 months in securing qualified endocrinologists in certain regions.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a certification program for endocrinologists to ensure consistent standards. Provide financial incentives to encourage endocrinologists to participate in the program. Partner with medical organizations to recruit and train qualified professionals.

## Risk 11 - Integration with Existing Infrastructure
Challenges in integrating the new biological verification program with existing anti-doping programs and data management systems. Incompatibilities or conflicts could disrupt program operations and compromise data integrity.

**Impact:** Data inconsistencies, system downtime, and increased administrative burden. A delay of 2-4 weeks to resolve integration issues.

**Likelihood:** Low

**Severity:** Medium

**Action:** Conduct a thorough assessment of existing systems and infrastructure. Develop a detailed integration plan with clear timelines and responsibilities. Implement rigorous testing and validation procedures to ensure seamless integration.

## Risk 12 - Social
Negative media coverage and public perception of the program. Concerns about privacy, fairness, or ethical implications could undermine public support and damage the reputation of World Athletics.

**Impact:** Reduced athlete participation, negative publicity, and loss of public trust. A decrease of 5-10% in athlete participation rates.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive communication strategy to address potential concerns and promote the program's benefits. Engage with media outlets and influencers to ensure accurate and balanced coverage. Be transparent and responsive to public inquiries.

## Risk 13 - Operational
Inadequate training and certification of personnel across member federations. Inconsistent implementation of testing protocols and data management practices could compromise program integrity.

**Impact:** Inaccurate test results, unfair competition, and legal challenges from affected athletes. A delay of 1-2 months to provide adequate training and certification.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive training and certification program for all personnel involved in the program. Provide ongoing training and support to ensure consistent implementation of testing protocols and data management practices. Regularly audit member federations to verify compliance with established standards.

## Risk 14 - Financial
Exchange rate fluctuations impacting the budget. The use of USD for budgeting and CHF for local transactions in Switzerland exposes the program to currency risks.

**Impact:** Budget overruns or reduced program scope. A cost increase of 5-10% due to unfavorable exchange rate movements.

**Likelihood:** Low

**Severity:** Medium

**Action:** Implement hedging strategies to mitigate exchange rate fluctuations. Monitor currency markets and adjust budget projections accordingly.

## Risk summary
The most critical risks to the 'Fair Play' program are related to regulatory compliance (GDPR and CAS challenges), technical infrastructure (secure database), and financial stability (budget overruns). Failure to adequately address these risks could significantly jeopardize the program's success. Mitigation strategies should focus on robust data protection measures, legal validation of eligibility criteria, and proactive budget management. There is a trade-off between comprehensive testing and budget constraints, requiring a tiered approach to testing modalities and athlete selection. Overlapping mitigation strategies include standardized training and certification to ensure consistent implementation across all member federations, which addresses both technical and operational risks.

# Make Assumptions


## Question 1 - What specific financial controls and reporting mechanisms will be implemented to ensure adherence to the $50 million initial setup and $15 million annual operating budget, considering the global scope and diverse operational costs across 214 member federations?

**Assumptions:** Assumption: A centralized financial management system with real-time tracking of expenditures and automated alerts for budget deviations will be implemented. Monthly financial reports will be generated and reviewed by a dedicated finance team.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of the financial controls and reporting mechanisms.
Details: Implementing a centralized financial system reduces the risk of budget overruns and ensures transparency. Real-time tracking allows for proactive adjustments. Risks include the initial cost of the system and the need for skilled personnel to manage it. Mitigation: Phased implementation of the system and training for existing staff. Potential benefit: Improved financial accountability and efficient resource allocation.

## Question 2 - What is the detailed timeline for achieving operational status across all 214 member federations within 18 months, including key milestones for infrastructure setup, personnel training, and regulatory approvals in each region?

**Assumptions:** Assumption: A phased rollout approach will be adopted, prioritizing federations with existing anti-doping infrastructure and higher athlete participation rates. Key milestones will include securing regulatory approvals within 6 months, training personnel in 12 months, and establishing testing facilities in 15 months.

**Assessments:** Title: Timeline Adherence Assessment
Description: Evaluation of the feasibility of the 18-month timeline.
Details: A phased rollout allows for iterative improvements and reduces initial logistical complexity. Risks include delays in regulatory approvals and unforeseen infrastructure challenges. Mitigation: Proactive engagement with regulatory bodies and detailed risk assessment for each region. Potential benefit: Reduced disruption to athlete participation and improved program effectiveness.

## Question 3 - What specific roles and responsibilities will be assigned to personnel at the World Athletics level and within each member federation to ensure effective program implementation, including recruitment, training, and ongoing performance monitoring?

**Assumptions:** Assumption: World Athletics will establish a central program management office responsible for overall coordination, training, and quality control. Each member federation will designate a program liaison responsible for local implementation, data collection, and communication with athletes.

**Assessments:** Title: Resource Allocation Assessment
Description: Evaluation of the personnel requirements and allocation.
Details: Clear roles and responsibilities are crucial for effective program implementation. Risks include inadequate staffing levels and lack of expertise in certain regions. Mitigation: Comprehensive training programs and resource sharing among federations. Potential benefit: Improved program efficiency and reduced errors.

## Question 4 - What specific legal frameworks and regulatory requirements, beyond GDPR and 'World Athletics Eligibility Regulations for Female Classification', must be addressed to ensure compliance in each of the 214 member federations, considering varying national laws and data privacy regulations?

**Assumptions:** Assumption: A legal compliance team will conduct a thorough review of national laws and regulations in each member federation. Standardized consent forms and data processing agreements will be developed to ensure compliance with local requirements.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Evaluation of the legal and regulatory landscape.
Details: Compliance with varying national laws is essential to avoid legal challenges. Risks include unforeseen regulatory hurdles and conflicting legal requirements. Mitigation: Proactive engagement with legal experts in each region and flexible program design to accommodate local variations. Potential benefit: Reduced legal risks and improved program acceptance.

## Question 5 - What specific safety protocols and risk mitigation strategies will be implemented to protect athletes during sample collection, physical examinations, and data handling, addressing potential risks such as adverse reactions, data breaches, and confidentiality breaches?

**Assumptions:** Assumption: Standardized safety protocols will be developed for all procedures, including emergency response plans and data encryption measures. Regular safety audits will be conducted to identify and address potential risks.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the safety protocols and risk mitigation strategies.
Details: Protecting athlete safety and data privacy is paramount. Risks include adverse reactions to testing procedures and data breaches. Mitigation: Comprehensive safety training for personnel and robust cybersecurity measures. Potential benefit: Improved athlete trust and reduced liability.

## Question 6 - What measures will be taken to minimize the environmental impact of the program, including waste disposal from testing laboratories, transportation of biological samples, and energy consumption of data centers, considering the global scale of operations?

**Assumptions:** Assumption: Environmentally friendly disposal methods will be used for laboratory waste, and transportation routes will be optimized to minimize carbon emissions. Energy-efficient data centers will be utilized to reduce energy consumption.

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluation of the program's environmental footprint.
Details: Minimizing environmental impact is a responsible practice. Risks include improper waste disposal and high energy consumption. Mitigation: Partnering with environmentally conscious vendors and implementing sustainable practices. Potential benefit: Enhanced corporate social responsibility and positive public image.

## Question 7 - What strategies will be employed to engage and communicate with athletes, advocacy groups, and other stakeholders to address their concerns, build trust in the program, and ensure their active participation in the implementation process?

**Assumptions:** Assumption: Regular communication channels will be established, including town hall meetings, online forums, and social media platforms. A dedicated stakeholder engagement team will be responsible for addressing concerns and providing updates.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluation of the stakeholder engagement strategies.
Details: Engaging stakeholders is crucial for program acceptance. Risks include resistance from athletes and advocacy groups. Mitigation: Transparent communication and addressing concerns proactively. Potential benefit: Improved program support and reduced opposition.

## Question 8 - What specific operational systems and technologies will be implemented to manage athlete data, track sample collection and analysis, and facilitate communication among stakeholders, ensuring data integrity, security, and efficient program management?

**Assumptions:** Assumption: A secure, cloud-based platform will be used to manage athlete data and track sample collection. Mobile applications will be developed to facilitate communication and data entry in the field.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluation of the operational systems and technologies.
Details: Efficient operational systems are essential for program management. Risks include system failures and data breaches. Mitigation: Robust cybersecurity measures and disaster recovery plans. Potential benefit: Improved program efficiency and data accuracy.

# Distill Assumptions

- Centralized financial system tracks expenditures against the $50M setup and $15M annual budget.
- Phased rollout prioritizes federations with existing infrastructure to achieve operational status in 18 months.
- World Athletics manages program; federations appoint liaisons for local implementation and communication.
- Legal team reviews national laws; standardized consent forms ensure compliance across 214 federations.
- Standardized safety protocols, emergency plans, and data encryption protect athletes and data.
- Environmentally friendly waste disposal, optimized transport, and efficient data centers minimize impact.
- Regular communication via meetings, forums, and social media engages stakeholders and addresses concerns.
- Secure cloud platform manages data; mobile apps facilitate communication and data entry.

# Review Assumptions

## Domain of the expert reviewer
Project Management, Risk Management, and Regulatory Compliance

## Domain-specific considerations

- Global regulatory landscape (GDPR, national laws)
- Data security and privacy
- Stakeholder engagement and communication
- Financial controls and budget management
- Logistical complexity of global operations
- Scientific validity and ethical considerations

## Issue 1 - Unrealistic Timeline for Global Implementation
The assumption that operational status can be achieved across all 214 member federations within 18 months is highly optimistic. It doesn't adequately account for the complexities of securing regulatory approvals, establishing infrastructure, training personnel, and addressing unforeseen challenges in diverse regions. The phased rollout approach, while beneficial, may still encounter significant delays due to bureaucratic hurdles, logistical bottlenecks, and cultural differences.

**Recommendation:** Conduct a detailed, bottom-up timeline analysis for each region, considering specific regulatory requirements, infrastructure limitations, and cultural factors. Develop contingency plans for potential delays and allocate additional resources to critical areas. Extend the overall project timeline to 24-30 months to allow for realistic implementation. Establish clear, measurable milestones for each phase of the rollout and track progress closely.

**Sensitivity:** A delay in achieving full operational status (baseline: 18 months) could postpone the ROI by 6-12 months. Each month of delay could increase operational costs by $500,000 - $1,000,000 due to extended project management, resource allocation, and potential penalties for non-compliance. This could reduce the overall ROI by 5-10%.

## Issue 2 - Insufficient Detail on Data Security and GDPR Compliance
While the assumption mentions standardized consent forms and data processing agreements, it lacks specific details on how GDPR principles will be upheld in practice across all 214 member federations. The plan needs to address data localization requirements, cross-border data transfer mechanisms, and the rights of athletes to access, rectify, and erase their data. Failure to comply with GDPR could result in severe penalties and reputational damage.

**Recommendation:** Develop a comprehensive data governance framework that outlines specific procedures for data collection, storage, processing, and transfer in compliance with GDPR and other relevant data privacy regulations. Implement robust data encryption and access control measures. Appoint a Data Protection Officer (DPO) responsible for overseeing data privacy compliance. Conduct regular data privacy audits and provide GDPR training to all personnel involved in data handling. Implement a robust incident response plan to address potential data breaches.

**Sensitivity:** A failure to uphold GDPR principles may result in fines ranging from 2-4% of annual global turnover or €10-20 million (whichever is greater). The cost of implementing comprehensive data security measures could range from $500,000 - $1,000,000, but this investment is crucial to mitigate the risk of costly fines and reputational damage. A data breach could also lead to legal action from affected athletes, resulting in additional costs and delays.

## Issue 3 - Lack of Contingency Planning for Athlete Resistance and Ethical Concerns
The assumption that regular communication will effectively address athlete concerns and build trust may be overly optimistic. The plan needs to anticipate potential resistance to mandatory biological verification on privacy, ethical, or religious grounds. Failure to address these concerns proactively could lead to reduced athlete participation, negative publicity, and legal challenges.

**Recommendation:** Conduct thorough stakeholder consultations to identify potential ethical concerns and address them proactively. Develop a comprehensive communication strategy that emphasizes the program's benefits for fair competition and athlete well-being. Establish an independent ethics review board to oversee the program and address ethical dilemmas. Provide athletes with access to independent legal and medical advice. Develop alternative testing protocols for athletes with religious or ethical objections, where feasible.

**Sensitivity:** 

## Review conclusion
The plan presents an ambitious and complex undertaking with significant potential benefits for fair competition in female athletics. However, the success of the program hinges on addressing the identified critical issues related to timeline realism, data security, and athlete acceptance. By implementing the recommended actions, World Athletics can mitigate potential risks, enhance program effectiveness, and ensure long-term sustainability.