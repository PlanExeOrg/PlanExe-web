**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight due to potential impact on overall project budget and scope.
Negative Consequences: Potential budget overruns, project delays, or scope reduction if not addressed strategically.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO lacks the authority or resources to effectively mitigate the risk, requiring strategic guidance and potential resource reallocation from the Steering Committee.
Negative Consequences: Project failure, legal penalties, or reputational damage if the risk is not effectively managed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO cannot reach a consensus on a critical vendor, potentially delaying project progress and requiring a higher-level decision to break the deadlock.
Negative Consequences: Project delays, increased costs, or selection of a suboptimal vendor if the deadlock is not resolved.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: A significant change to the project scope requires strategic review and approval due to potential impact on budget, timeline, and overall project objectives.
Negative Consequences: Project failure, budget overruns, or failure to meet strategic objectives if the scope change is not properly evaluated and managed.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical standards are maintained and potential conflicts of interest are addressed.
Negative Consequences: Legal penalties, reputational damage, or loss of athlete trust if ethical concerns are not properly addressed.

**Disagreement on Testing Modalities**
Escalation Level: Technical Advisory Group
Approval Process: Technical Advisory Group Review and Vote
Rationale: Requires expert technical input to ensure scientific validity and reliability of testing methodologies.
Negative Consequences: Inaccurate results, unfair competition, or legal challenges if testing methodologies are not scientifically sound.