### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, given its high budget ($50M initial, $15M annual), global scope (214 federations), and potential high-impact risks (legal challenges, GDPR compliance).

**Responsibilities:**

- Approve overall project strategy and plan.
- Approve major project milestones and deliverables.
- Approve budget allocations and monitor expenditures exceeding $1,000,000.
- Oversee strategic risk management and mitigation.
- Resolve strategic issues and conflicts.
- Ensure alignment with World Athletics strategic objectives.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review and approve initial project plan.

**Membership:**

- World Athletics President (or designated representative)
- World Athletics Chief Operating Officer (or designated representative)
- Independent Legal Counsel
- Independent Medical Expert
- Athlete Representative (appointed by World Athletics Athletes' Commission)

**Decision Rights:** Strategic decisions related to project scope, budget (above $1,000,000), timeline, and key risks.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the World Athletics President (or designated representative) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of budget and expenditures.
- Discussion of strategic risks and mitigation plans.
- Approval of major project deliverables.
- Review of stakeholder feedback.
- Review of compliance reports.

**Escalation Path:** World Athletics Executive Board
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, given the project's complexity, global scale, and tight timeline. Ensures consistent application of project management methodologies and standards.

**Responsibilities:**

- Develop and maintain project plan.
- Manage project budget and track expenditures.
- Coordinate project activities across different workstreams.
- Monitor project risks and implement mitigation plans.
- Report project progress to the Project Steering Committee.
- Manage communication with stakeholders.
- Ensure compliance with project management standards.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management plan.
- Establish project communication protocols.
- Implement project tracking and reporting systems.

**Membership:**

- Project Manager
- Workstream Leads (e.g., Testing, Data Management, Training)
- Finance Representative
- Legal Representative
- Communications Representative

**Decision Rights:** Operational decisions related to project execution, budget (below $1,000,000), and resource allocation within approved budget.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with Workstream Leads. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Coordination of project activities.
- Review of budget and expenditures.
- Review of stakeholder feedback.
- Review of compliance reports.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides specialized assurance on ethical and compliance aspects, given the sensitive nature of athlete data, potential for conflicts of interest, and stringent regulatory requirements (GDPR, World Athletics Eligibility Regulations).

**Responsibilities:**

- Oversee compliance with GDPR and other relevant regulations.
- Review and approve data protection policies and procedures.
- Monitor ethical considerations related to athlete testing and data usage.
- Investigate ethical complaints and compliance violations.
- Provide guidance on ethical dilemmas.
- Ensure fairness and impartiality in the application of the program.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethics and compliance framework.

**Membership:**

- Independent Ethics Expert (Chair)
- Data Protection Officer
- Legal Representative
- Athlete Representative (appointed by World Athletics Athletes' Commission)
- Medical Ethics Expert

**Decision Rights:** Decisions related to ethical considerations, compliance with regulations, and data protection policies.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Independent Ethics Expert (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of data protection policies and procedures.
- Discussion of ethical considerations related to athlete testing.
- Review of compliance reports.
- Investigation of ethical complaints and compliance violations.
- Review of stakeholder feedback.
- Review of relevant regulations.

**Escalation Path:** World Athletics Executive Board
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical input and assurance on the scientific validity and reliability of testing methodologies, given the complexity of hormonal analysis and genetic screening.

**Responsibilities:**

- Advise on the selection of testing modalities and hormonal analysis methodologies.
- Review and approve testing protocols and quality control procedures.
- Monitor the performance of accredited laboratories.
- Provide guidance on the interpretation of test results.
- Evaluate new technologies and methodologies.
- Ensure the scientific defensibility of the program.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Review and approve initial testing protocols.

**Membership:**

- Independent Endocrinologist (Chair)
- Independent Geneticist
- Laboratory Director (from a WADA-accredited lab)
- Biostatistician
- Sports Medicine Physician

**Decision Rights:** Decisions related to testing methodologies, quality control procedures, and the interpretation of test results.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Independent Endocrinologist (Chair) has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of testing protocols and quality control procedures.
- Discussion of the performance of accredited laboratories.
- Review of test results and interpretation.
- Evaluation of new technologies and methodologies.
- Review of relevant scientific literature.
- Review of stakeholder feedback.

**Escalation Path:** Project Steering Committee