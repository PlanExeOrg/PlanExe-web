# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Sports Medicine Physician

**Knowledge**: Endocrinology, sports physiology, athlete health, WADA regulations

**Why**: To assess the medical implications of hormonal analysis and genetic screening on athlete health and well-being.

**What**: Review the testing protocols to ensure they align with best practices in sports medicine and athlete safety.

**Skills**: Medical ethics, clinical assessment, data interpretation, communication

**Search**: sports medicine physician, endocrinology, athlete health

## 1.1 Primary Actions

- Immediately consult with a genetics expert and bioethicist to refine the genetic screening component of the program.
- Engage an endocrinologist specializing in sports medicine to develop a robust longitudinal hormonal profiling strategy.
- Prioritize the development of a comprehensive athlete education and engagement program, focusing on WADA regulations and program goals.

## 1.2 Secondary Actions

- Re-evaluate the 'Scope of Genetic Screening' decision, considering the ethical implications and potential for incidental findings.
- Conduct a pilot study to assess the feasibility of longitudinal hormonal profiling and refine testing protocols.
- Establish an athlete advisory board to provide ongoing input and guidance on the program.

## 1.3 Follow Up Consultation

In the next consultation, we will review the revised genetic screening protocol, the longitudinal hormonal profiling strategy, and the athlete education and engagement program. We will also discuss the ethical and legal implications of these changes and ensure that the program remains defensible before CAS.

## 1.4.A Issue - Lack of Specificity Regarding Genetic Screening Justification and Ethical Considerations

The plan mentions genetic screening (karyotyping) but lacks a clear justification for its inclusion, especially given the ethical complexities and potential for misinterpretation. The document does not adequately address the specific genetic variations being targeted, their relevance to female eligibility, or the potential for uncovering incidental findings with unclear clinical significance. Furthermore, the plan needs to explicitly address how genetic information will be handled, stored, and used, ensuring compliance with ethical guidelines and data privacy regulations. The 'Scope of Genetic Screening' decision is rated as 'Medium' importance, but the ethical implications warrant a higher level of scrutiny.

### 1.4.B Tags

- genetic_screening
- ethics
- data_privacy
- justification

### 1.4.C Mitigation

1. **Consult with a genetics expert and a bioethicist:** Conduct a thorough review of the scientific literature to identify specific genetic variations that are directly relevant to female eligibility in athletics. Obtain expert guidance on the ethical implications of genetic screening, including potential for discrimination, psychological distress, and incidental findings. 2. **Develop a detailed protocol for genetic screening:** Clearly define the scope of genetic screening, the specific genetic variations being targeted, and the criteria for interpreting results. Establish a process for handling incidental findings, including genetic counseling and referral to appropriate medical specialists. 3. **Implement robust data privacy and security measures:** Ensure that genetic data is stored securely and accessed only by authorized personnel. Obtain informed consent from athletes before conducting genetic screening, and clearly explain how their data will be used and protected. Consult with a legal expert to ensure compliance with GDPR and other relevant data privacy regulations.

### 1.4.D Consequence

Without proper justification and ethical safeguards, the genetic screening component of the program could face legal challenges, damage athlete trust, and lead to unintended harm.

### 1.4.E Root Cause

Insufficient expertise in genetics and bioethics during the initial planning phase.

## 1.5.A Issue - Inadequate Consideration of Longitudinal Hormonal Profiling and its Implementation Challenges

While the plan mentions hormonal analysis, it doesn't fully explore the benefits and challenges of longitudinal hormonal profiling. Single-point testosterone measurements, as suggested in some scenarios, are easily manipulated and provide limited insight into an athlete's hormonal history. Longitudinal profiling, while more informative, requires frequent testing, sophisticated data analysis, and careful consideration of individual variability and confounding factors (e.g., menstrual cycle, stress, medication). The plan needs to address the logistical and financial implications of implementing longitudinal profiling on a large scale, as well as the potential for false positives and the need for robust confirmatory testing. The 'Hormonal Analysis Methodology' decision needs a deeper dive into the practicalities of longitudinal data collection and interpretation.

### 1.5.B Tags

- hormonal_profiling
- longitudinal_data
- false_positives
- implementation

### 1.5.C Mitigation

1. **Consult with an endocrinologist specializing in sports medicine:** Obtain expert guidance on the optimal hormonal markers to measure, the frequency of testing required for longitudinal profiling, and the methods for interpreting hormonal data in the context of athletic performance. 2. **Conduct a pilot study to assess the feasibility of longitudinal profiling:** Implement longitudinal profiling on a smaller group of athletes to evaluate the logistical challenges, costs, and potential for false positives. Use the data from the pilot study to refine the testing protocols and data analysis methods. 3. **Develop clear guidelines for interpreting hormonal data:** Establish specific criteria for identifying hormonal anomalies and differentiating between natural variations and potential doping violations. Ensure that these guidelines are based on the latest scientific evidence and are defensible before CAS.

### 1.5.D Consequence

Relying solely on single-point testosterone measurements could undermine the program's effectiveness and lead to inaccurate or unfair outcomes. Failure to address the challenges of longitudinal profiling could result in logistical difficulties, budget overruns, and legal challenges.

### 1.5.E Root Cause

Overemphasis on cost-effectiveness at the expense of scientific rigor.

## 1.6.A Issue - Insufficient Focus on Athlete Education and Engagement Regarding WADA Regulations and Program Goals

The plan mentions athlete communication but lacks a comprehensive strategy for educating athletes about the program's goals, procedures, and their rights and responsibilities. Many athletes may be unfamiliar with WADA regulations and the scientific basis for biological verification. Failure to address athlete concerns and misconceptions could lead to resistance, mistrust, and legal challenges. The plan needs to include proactive measures to engage athletes in the program, address their concerns, and foster a culture of fair play and ethical conduct. The 'Athlete Communication Strategy' needs to be more robust and proactive.

### 1.6.B Tags

- athlete_education
- engagement
- communication
- WADA

### 1.6.C Mitigation

1. **Develop a comprehensive athlete education program:** Create educational materials (e.g., videos, brochures, online modules) that explain the program's goals, procedures, and the scientific basis for biological verification. Ensure that these materials are accessible in multiple languages and are tailored to different athlete populations. 2. **Conduct regular athlete workshops and focus groups:** Organize workshops and focus groups to provide athletes with opportunities to ask questions, express concerns, and provide feedback on the program. Use this feedback to improve the program's design and implementation. 3. **Establish an athlete advisory board:** Create an advisory board composed of athlete representatives to provide ongoing input and guidance on the program. Ensure that the advisory board has a diverse membership and represents the interests of all athlete populations.

### 1.6.D Consequence

Lack of athlete education and engagement could lead to resistance, mistrust, and legal challenges, undermining the program's effectiveness and credibility.

### 1.6.E Root Cause

Underestimation of the importance of athlete buy-in and a top-down approach to program design.

---

# 2 Expert: Change Management Consultant

**Knowledge**: Organizational change, stakeholder engagement, communication strategies, training programs

**Why**: To address potential athlete resistance and ensure smooth adoption of the program across diverse federations.

**What**: Develop a change management plan to address athlete concerns and promote program acceptance.

**Skills**: Communication, training, stakeholder management, conflict resolution

**Search**: change management consultant, sports organizations, athlete engagement

## 2.1 Primary Actions

- Revise the project timeline based on a detailed, bottom-up estimation of time and resources required for each phase of implementation.
- Develop a comprehensive athlete engagement strategy that includes establishing an athlete advisory board, conducting regular surveys and focus groups, and creating educational materials.
- Develop detailed and actionable risk mitigation plans for each identified risk, including specific actions, responsible parties, timelines, measurable outcomes, and contingency plans.

## 2.2 Secondary Actions

- Conduct a thorough review of the budget to identify potential cost savings and reallocate resources to athlete engagement and risk mitigation.
- Establish clear lines of communication and accountability within the Project Management Office.
- Develop a communication plan to address potential biases in testing protocols or data interpretation.

## 2.3 Follow Up Consultation

In the next consultation, we will review the revised timeline, athlete engagement strategy, and risk mitigation plans. We will also discuss the key performance indicators (KPIs) for measuring the program's success and the mechanisms in place to ensure athlete confidentiality and data security.

## 2.4.A Issue - Overly Ambitious Timeline and Scope

The plan aims for global implementation across 214 member federations within 18 months with a $50 million setup budget and $15 million annual operating budget. This is extremely ambitious and likely unrealistic. The SWOT analysis also flags this as a weakness. The pre-project assessment highlights the need for a phased rollout, but the current timeline doesn't seem to reflect this. The 'Builder's Foundation' scenario, while pragmatic, still operates within this constrained timeframe. There's a significant risk of spreading resources too thin, leading to a superficial implementation that fails to achieve the program's objectives.

### 2.4.B Tags

- timeline
- scope
- budget
- risk
- feasibility

### 2.4.C Mitigation

Conduct a detailed, bottom-up estimation of the time and resources required for each phase of implementation in a representative sample of federations (at least 10, covering different geographic regions and resource levels). This should include time for regulatory approvals, infrastructure upgrades, training, and stakeholder engagement. Consult with experienced project managers who have worked on similar global initiatives. Review the critical path and identify potential bottlenecks. Based on this analysis, revise the timeline and budget accordingly. Consider extending the timeline to 24-36 months. Provide the detailed analysis to World Athletics for approval.

### 2.4.D Consequence

Failure to meet the unrealistic timeline will result in a rushed and superficial implementation, undermining the program's credibility and effectiveness. It could also lead to budget overruns and increased athlete resistance.

### 2.4.E Root Cause

Underestimation of the complexity and logistical challenges of global implementation.

## 2.5.A Issue - Insufficient Focus on Athlete Engagement and Education

While the stakeholder analysis mentions 'transparent communication and feedback mechanisms for Athletes,' the plan lacks a concrete strategy for actively engaging athletes in the program's design and implementation. Athlete resistance is identified as a key risk, but the mitigation plan focuses primarily on providing 'transparent information' and protecting privacy. This is insufficient. Athletes need to be actively involved in shaping the program to address their concerns and build trust. The absence of a 'killer application' further exacerbates this issue, as athletes may not see the immediate benefits of the program.

### 2.5.B Tags

- athlete engagement
- communication
- risk
- trust
- ethics

### 2.5.C Mitigation

Develop a comprehensive athlete engagement strategy that includes: (1) Establishing an athlete advisory board with representatives from different regions and athletic disciplines. (2) Conducting regular surveys and focus groups to gather athlete feedback on all aspects of the program. (3) Creating educational materials that clearly explain the program's rationale, procedures, and benefits in a language that is accessible and culturally sensitive. (4) Partnering with athlete advocacy groups to promote the program and address athlete concerns. (5) Publicly communicating how athlete feedback has been incorporated into the program's design and implementation. Consult with experts in athlete communication and engagement. Review best practices from other sports organizations. Provide data on athlete concerns and preferences to the program's decision-makers.

### 2.5.D Consequence

Lack of athlete buy-in will lead to increased resistance, legal challenges, and negative media coverage, undermining the program's legitimacy and effectiveness.

### 2.5.E Root Cause

Failure to adequately consider the athlete perspective and prioritize their concerns.

## 2.6.A Issue - Vague and Insufficiently Detailed Risk Mitigation Plans

The risk assessment identifies several key risks, including GDPR compliance failures, CAS challenges, and budget overruns. However, the mitigation plans are often vague and lack specific, actionable steps. For example, the plan to 'implement robust cybersecurity measures' is insufficient without detailing the specific measures to be implemented, the frequency of security audits, and the responsible parties. Similarly, the plan to 'engage with athlete representatives' lacks specifics on how this engagement will be conducted and how athlete feedback will be incorporated into the program. The mitigation plans need to be more concrete and measurable.

### 2.6.B Tags

- risk management
- mitigation
- planning
- accountability

### 2.6.C Mitigation

For each identified risk, develop a detailed mitigation plan that includes: (1) Specific actions to be taken. (2) Responsible parties. (3) Timelines for completion. (4) Measurable outcomes. (5) Contingency plans in case the mitigation efforts fail. For example, the GDPR compliance mitigation plan should specify the data encryption methods to be used, the frequency of data security audits, and the training program for personnel. The athlete engagement mitigation plan should specify the frequency of athlete surveys, the composition of the athlete advisory board, and the process for incorporating athlete feedback into the program. Consult with experts in risk management and compliance. Review best practices from other organizations. Provide a detailed risk register with mitigation plans to the program's decision-makers.

### 2.6.D Consequence

Inadequate risk mitigation will leave the program vulnerable to unforeseen challenges, potentially leading to significant delays, budget overruns, and reputational damage.

### 2.6.E Root Cause

Lack of a systematic and rigorous approach to risk management.

---

# The following experts did not provide feedback:

# 3 Expert: Database Security Architect

**Knowledge**: GDPR compliance, data encryption, access control, cybersecurity, cloud security

**Why**: To ensure the security and integrity of the central database and compliance with GDPR regulations.

**What**: Design a secure data storage architecture and implement robust cybersecurity measures.

**Skills**: Cybersecurity, data privacy, risk assessment, cloud computing

**Search**: database security architect, GDPR, cloud security, data encryption

# 4 Expert: Logistics Coordinator

**Knowledge**: Supply chain management, international shipping, cold chain logistics, laboratory operations

**Why**: To address logistical challenges in sample collection, transport, and storage across 214 federations.

**What**: Develop a detailed logistics plan to ensure timely and secure sample handling.

**Skills**: Logistics planning, supply chain, quality control, risk management

**Search**: logistics coordinator, international shipping, cold chain, laboratory samples

# 5 Expert: Forensic Statistician

**Knowledge**: Statistical modeling, anomaly detection, data analysis, forensic science, sports analytics

**Why**: To refine athlete selection criteria and testing modalities, minimizing false positives and ensuring fairness.

**What**: Analyze testing data to identify statistical anomalies and refine testing protocols.

**Skills**: Statistical analysis, data mining, algorithm development, pattern recognition

**Search**: forensic statistician, sports analytics, anomaly detection, data analysis

# 6 Expert: Sports Lawyer

**Knowledge**: Sports law, CAS arbitration, athlete rights, GDPR, regulatory compliance

**Why**: To ensure legal defensibility of the program and compliance with relevant regulations.

**What**: Review program regulations and procedures to ensure compliance with sports law and athlete rights.

**Skills**: Legal research, contract law, dispute resolution, regulatory compliance

**Search**: sports lawyer, CAS arbitration, athlete rights, GDPR compliance

# 7 Expert: Medical Ethicist

**Knowledge**: Bioethics, medical ethics, athlete welfare, informed consent, genetic screening

**Why**: To address ethical concerns related to genetic screening, data privacy, and athlete autonomy.

**What**: Develop ethical guidelines for the program and ensure informed consent procedures are in place.

**Skills**: Ethical reasoning, conflict resolution, communication, policy development

**Search**: medical ethicist, bioethics, genetic screening, athlete welfare

# 8 Expert: Endocrine Lab Director

**Knowledge**: Hormonal analysis, laboratory accreditation, quality control, endocrinology, ISO 17025

**Why**: To ensure accuracy and reliability of hormonal analysis across accredited laboratories.

**What**: Establish standardized protocols for hormonal analysis and quality control procedures.

**Skills**: Laboratory management, quality assurance, data validation, regulatory compliance

**Search**: endocrine lab director, ISO 17025, hormonal analysis, quality control