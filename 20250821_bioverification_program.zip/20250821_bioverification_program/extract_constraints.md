## Positive Constraints

- Establish a global Biological Verification Program for female athletes
- Program for World Athletics sanctioned events
- Operational across all 214 member federations
- Timeline: 18 months
- Budget: $50 million for initial setup
- Annual operating budget of $15 million
- Mandatory hormonal analysis for testosterone levels
- Genetic screening (karyotyping)
- Standardized physical examination by a certified endocrinologist
- Align with 'World Athletics Eligibility Regulations for Female Classification'
- Defensible before the Court of Arbitration for Sport (CAS)
- Secure, GDPR-compliant central database for managing athlete biological passports and eligibility status
- Rigid, confidential protocol for communicating results to athletes
- Manage the appeals process
