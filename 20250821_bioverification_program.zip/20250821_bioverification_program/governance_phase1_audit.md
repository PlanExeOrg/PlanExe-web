
## Audit - Corruption Risks

- Bribery of endocrinologists to falsify examination results to favor certain athletes.
- Kickbacks from testing kit suppliers in exchange for exclusive contracts, potentially compromising the quality of the kits.
- Conflicts of interest within the project management office, where personnel may have undisclosed relationships with testing laboratories or suppliers.
- Nepotism in the selection of endocrinologists or laboratory personnel, leading to unqualified individuals being involved in critical processes.
- Misuse of confidential athlete data for personal gain, such as betting on competitions or selling information to third parties.

## Audit - Misallocation Risks

- Inflated invoices from testing laboratories or endocrinologists, leading to budget overruns.
- Double-billing for testing services or examinations, where the same service is charged multiple times.
- Inefficient allocation of resources to federations with low participation rates, while neglecting those with higher needs.
- Unauthorized use of project funds for personal travel or entertainment expenses.
- Misreporting of project progress or results to justify continued funding or to conceal failures.

## Audit - Procedures

- Conduct quarterly internal audits of financial records, focusing on procurement processes, expense reports, and contract compliance. Responsibility: Internal Audit Department.
- Perform annual external audits of the program's financial statements and compliance with relevant regulations (GDPR, WADA). Responsibility: Independent Audit Firm.
- Implement a contract review threshold of $100,000, requiring independent legal and financial review of all contracts exceeding this amount. Responsibility: Legal and Finance Departments.
- Establish a standardized expense workflow with mandatory approval levels based on expense amount, ensuring proper authorization and documentation. Responsibility: Finance Department.
- Conduct periodic compliance checks to ensure adherence to the World Athletics Eligibility Regulations for Female Classification and GDPR requirements. Responsibility: Compliance Officer.

## Audit - Transparency Measures

- Publish a project progress dashboard on the World Athletics website, providing updates on key milestones, budget expenditures, and program performance metrics.
- Publish minutes of key meetings of the program's governing body (e.g., steering committee) on the World Athletics website.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with clear procedures for investigation and resolution.
- Make relevant program policies and reports (e.g., data protection policy, audit reports) publicly accessible on the World Athletics website.
- Document and publish the selection criteria for major decisions, such as the selection of testing laboratories and endocrinologists, to ensure fairness and impartiality.