Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not describe any technology or process that would violate the laws of physics. The plan focuses on biological verification, data analysis, and regulatory compliance, all within the bounds of known physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of mandatory biological verification (product) across 214 federations (market) using hormonal/genetic analysis (tech/process) under GDPR (policy) without evidence of comparable scale. No independent evidence exists for this specific system combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: 6 Months


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks definitions of key strategic concepts like "biological verification program", "fair competition", and "compliance with eligibility regulations" with a business-level mechanism-of-action, owner, and measurable outcomes.

**Mitigation**: Project Manager: Produce one-pagers defining each strategic concept with value hypotheses, success metrics, owners, and decision hooks by 2027-01-01.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the risk register identifies several relevant risks (GDPR, CAS challenges, cyberattacks), but lacks explicit analysis of cascade effects. For example, a permit delay's financial consequences aren't mapped. "Detailed budget, contingency funds" is a general control, not a cascade analysis.

**Mitigation**: Risk Management Team: Expand the risk register to include cascade effects for each identified risk, mapping potential consequences and dependencies by 2027-01-15.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan aims for global implementation across 214 member federations within 18 months, but the expert review identifies this timeline as unrealistic. The SWOT analysis also flags this as a weakness. The plan lacks a detailed permit/approval matrix.

**Mitigation**: Project Management Office: Conduct a detailed timeline analysis for each region, considering regulatory requirements, infrastructure limitations, and cultural factors by 2027-01-15.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states a $50M setup and $15M annual budget, but lacks a financing plan listing sources/status, draw schedule, and covenants. The plan does not specify funding sources or runway length.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by 2027-01-15.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $50M setup and $15M annually lacks scale-appropriate benchmarks normalized by area. There are no vendor quotes or per-area cost calculations provided. The plan does not include contingency.

**Mitigation**: CFO: Benchmark (≥3), obtain quotes, normalize per-area (cost per m²/ft²), and adjust budget or de-scope by 2027-01-15.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., operational status targeted in 18 months) as a single number without providing a range, confidence interval, or discussing alternative scenarios. There is no sensitivity analysis.

**Mitigation**: Project Management Office: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the 18-month operational status projection by 2027-01-15.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specifications, interface definitions, test plans, or integration maps. The plan does not describe how the system will be built.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2027-02-01.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan claims "ISO 17025 accreditation for laboratories" but lacks evidence (certificate/link/ID) that any lab has this. The plan also claims "WADA International Standards for Laboratories" compliance, but lacks evidence of WADA approval.

**Mitigation**: Project Manager: Obtain ISO 17025 accreditation certificates for all participating labs and WADA approval documentation by 2027-01-15 or de-scope.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project mentions 'Biological Verification Program' without defining specific, verifiable qualities. The plan does not include SMART acceptance criteria or KPIs for the program's success.

**Mitigation**: Project Team: Define SMART criteria for the Biological Verification Program, including a KPI for detection rate (e.g., 10% reduction in violations) by 2027-01-15.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Genetic Screening' without a clear justification for its inclusion. It does not appear to directly support the core project goals of ensuring fair competition and compliance with eligibility regulations.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of genetic screening, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2027-01-15.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Certified Endocrinologist Coordinator' to manage recruitment/training across 214 federations. This role is essential, but securing qualified endocrinologists globally is likely difficult. The plan lacks evidence of endocrinologist availability.

**Mitigation**: Medical Affairs: Validate the talent market for certified endocrinologists in each member federation by 2027-01-15 to confirm feasibility. If infeasible, de-scope or delay.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authority, artifact, lead time, and predecessors for permits/licenses/approvals across 214 federations. The plan does not identify specific permits required.

**Mitigation**: Legal Team: Create a regulatory matrix (authority, artifact, lead time, predecessors) for each member federation by 2027-02-01. NO-GO on adverse findings.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions a $15M annual budget, but lacks a detailed operational sustainability plan. It does not address long-term funding sources, maintenance schedules, succession planning, or technology roadmaps. The plan does not include a sustainability plan.

**Mitigation**: CFO: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and a technology roadmap by 2027-02-01.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "testing locations across 214 member federations" but lacks evidence of zoning/land-use, occupancy/egress, fire load, structural limits, noise, or permit feasibility. The plan does not address these constraints.

**Mitigation**: Project Manager: Perform a fatal-flaw screen with authorities/experts; seek written confirmation where feasible; define fallback designs/sites and dated NO-GO thresholds tied to constraint outcomes by 2027-02-01.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions accredited laboratories and secure data storage, but lacks details on redundancy, failover testing, or SLAs with vendors. The plan does not describe tested failover plans.

**Mitigation**: Operations Team: Secure SLAs with key vendors (labs, data storage) and document tested failover procedures by 2027-02-01.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the stated goal of World Athletics is fair competition, while the goal of the Federation Liaison Coordinator is consistent implementation. These can conflict if consistency sacrifices local adaptation for fairness.

**Mitigation**: Project Management: Define a shared OKR for World Athletics and Federation Liaison Coordinators focused on equitable program adoption across federations by 2027-01-15.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Management Office: Establish a monthly review with a KPI dashboard and a lightweight change board with escalation thresholds by 2027-01-15.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies GDPR, CAS, and budget as high risks, but lacks a cross-impact analysis. A GDPR failure (high risk) could trigger CAS challenges (high risk) and budget overruns (medium risk), creating a multi-domain failure.

**Mitigation**: Risk Management Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2027-02-01.