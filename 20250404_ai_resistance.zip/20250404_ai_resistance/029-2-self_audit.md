Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on social and economic issues related to AI, which are outside the scope of physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (anti-AI movement) + market (global) + tech/process (online platform) + policy (legal in Switzerland) without independent evidence at comparable scale. There is no precedent for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Manager / Deliverable: Validation Report / Date: +90 days


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan uses terms like "human-centered approach to AI" and "diversified funding model" without defining their inputs, processes, customer value, owners, or measurable outcomes. The plan lacks one-pagers defining these strategic concepts.

**Mitigation**: Project Management: Create one-pagers for each strategic concept, defining the mechanism-of-action, owner, measurable outcomes, and decision hooks by end of next month.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, financial, technical, social, security) and proposes mitigation actions. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Delays could postpone fundraising" is noted, but not quantified.

**Mitigation**: Risk Manager: Create a risk cascade diagram linking initial risks to second-order impacts (e.g., financial shortfall, reputational damage) and controls within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Verein registration in Switzerland" but lacks a detailed timeline, dependencies, or authoritative lead times. This violates condition (b).

**Mitigation**: Legal Team: Create a permit/approval matrix with dependencies, lead times, and a NO-GO threshold on slip within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a financing plan listing sources/status, draw schedule, or covenants. The plan mentions a budget of €1.6M but does not specify funding sources or their status.

**Mitigation**: Finance Lead: Create a dated financing plan listing funding sources, their status (e.g., LOI, term sheet), draw schedule, covenants, and a NO-GO on missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of €1.6M lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions office space in Switzerland but omits fit-out costs or contingency. "Budget of €1,600,000 EUR" is stated without evidence.

**Mitigation**: Finance Lead: Obtain ≥3 fit-out quotes for office space in Zurich, Geneva, and Zug, normalize per m², add 20% contingency, and adjust budget or de-scope by EOM.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., fundraising targets) as single numbers without providing a range or discussing alternative scenarios. For example, the fundraising targets are presented as fixed amounts: "Online donations (50%): €800k".

**Mitigation**: Finance Lead: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the fundraising projections within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or integration maps. The plan mentions "Online platform development tools" but lacks specifics.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Prioritize immediate establishment of the 'Verein' in Switzerland to ensure legal compliance..." but lacks a legal opinion.

**Mitigation**: Legal Team: Obtain a formal legal opinion from Swiss counsel confirming the feasibility and timeline for establishing a 'Verein' within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "online platform" is mentioned without specific, verifiable qualities. The plan states, "Develop and launch Version 1.0 of the online platform" without defining acceptance criteria.

**Mitigation**: Engineering Lead: Define SMART criteria for the online platform, including a KPI for platform uptime (e.g., 99.9% availability) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'AI-driven content moderation' as a platform feature. This does not directly support the core goals of protesting AI job displacement or establishing a legal entity. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of AI-driven content moderation, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by EOM.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Platform Security Specialist" to ensure platform security and data privacy. This role is critical given the sensitive nature of the movement and the risk of cyberattacks. Finding a specialist with the right skills and experience will be difficult.

**Mitigation**: HR: Validate the talent market for a Platform Security Specialist with experience in Swiss data privacy regulations within 30 days to assess fillability.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions "Verein registration in Switzerland" but lacks a detailed timeline, dependencies, or authoritative lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with dependencies, lead times, and a NO-GO threshold on slip within 30 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan focuses on the initial 6-month phase and lacks a detailed long-term sustainability plan. The plan mentions "Long-Term Sustainability" as Risk 9, but the action is only "Long-term sustainability plan."

**Mitigation**: Project Team: Develop a detailed 3-year operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, and technology roadmap within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits a regulatory matrix mapping authorities, artifacts, lead times, and predecessors. The plan mentions "Verein registration in Switzerland" but lacks a detailed timeline, dependencies, or authoritative lead times.

**Mitigation**: Legal Team: Create a permit/approval matrix with dependencies, lead times, and a NO-GO threshold on slip within 30 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions reliance on cloud services and external vendors, but it overlooks the need for robust disaster recovery and business continuity planning. The plan states, "Vendor failures or delays" as a risk.

**Mitigation**: Operations Team: Develop a disaster recovery and business continuity plan, including tested failover procedures for critical vendors, within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the Finance Department is incentivized by budget adherence, while the Communications Team is incentivized by maximizing reach and engagement. This creates a conflict over marketing spend. The plan does not address this.

**Mitigation**: Project Team: Create a shared OKR that aligns Finance and Communications on a common outcome, such as 'Increase donor base by X% while staying within Y budget' by EOM.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process with thresholds. Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board to the project governance within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks (Financial, Technical, Legal) that are strongly coupled. A delay in Verein registration (Legal) directly impacts fundraising (Financial), which then constrains platform security (Technical).

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds within 60 days.