**Purpose:** business

**Purpose Detailed:** Establishing and launching an international anti-AI movement focused on protesting AI job displacement, including legal entity establishment, platform development, recruitment, fundraising, and strategic planning.

**Topic:** International Anti-AI Movement