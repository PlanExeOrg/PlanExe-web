## Suggestion 1 - Fairwork Foundation

The Fairwork Foundation is an action-research project based at the Oxford Internet Institute, University of Oxford. It assesses and rates working conditions in the platform economy, focusing on fair pay, fair conditions, fair contracts, and fair management. They operate internationally, evaluating digital labor platforms and advocating for better standards.

### Success Metrics

Number of platforms rated.
Engagement with platform companies to improve working conditions.
Influence on policy and regulatory discussions related to the gig economy.
Media coverage and public awareness of fair work issues.
Adoption of Fairwork principles by platforms and policymakers.

### Risks and Challenges Faced

Gaining access to platform data and internal information.
Ensuring the accuracy and reliability of assessment data.
Engaging with platform companies that may be resistant to change.
Navigating diverse regulatory environments across different countries.
Maintaining independence and credibility while working with industry stakeholders.

### Where to Find More Information

https://www.fairwork.org.uk/

### Actionable Steps

Contact the Fairwork Foundation team via their website for information on their methodology and engagement strategies.
Reach out to Dr. Mark Graham (mark.graham@oii.ox.ac.uk), the Director of the Fairwork Foundation, for insights on building an international advocacy organization.
Explore their publications and reports for detailed case studies and best practices.

### Rationale for Suggestion

The Fairwork Foundation provides a relevant example of an international organization focused on labor issues in the digital economy. Their experience in assessing and rating platforms, engaging with companies, and influencing policy can offer valuable insights for the anti-AI movement, particularly in developing its messaging, building partnerships, and advocating for policy changes. Their international scope and focus on digital labor are highly relevant. They also have experience in fundraising and managing a distributed team, which aligns with the user's project requirements.
## Suggestion 2 - AlgorithmWatch

AlgorithmWatch is a non-profit research and advocacy organization that examines and sheds light on algorithmic decision-making processes and their impact on society. Based in Germany, they conduct research, publish reports, and advocate for greater transparency and accountability in the use of algorithms. They focus on areas such as media, finance, and public services.

### Success Metrics

Number of investigations and reports published.
Media coverage and public awareness of algorithmic bias and discrimination.
Engagement with policymakers and regulators to promote algorithmic accountability.
Impact on corporate practices related to algorithmic decision-making.
Growth of the organization's network and influence.

### Risks and Challenges Faced

Obtaining access to algorithmic data and code.
Understanding and interpreting complex algorithms.
Communicating technical information to a non-technical audience.
Navigating legal and ethical challenges related to algorithmic research.
Maintaining independence and credibility while working with industry stakeholders.

### Where to Find More Information

https://algorithmwatch.org/en/

### Actionable Steps

Contact AlgorithmWatch via their website for information on their research methodology and advocacy strategies.
Reach out to Matthias Spielkamp (matthias@algorithmwatch.org), the co-founder of AlgorithmWatch, for insights on building a non-profit organization focused on algorithmic accountability.
Explore their publications and reports for detailed case studies and best practices.

### Rationale for Suggestion

AlgorithmWatch is a highly relevant example of an organization focused on the societal impacts of algorithms, including job displacement. Their experience in conducting research, publishing reports, and advocating for policy changes can offer valuable insights for the anti-AI movement. Their focus on algorithmic accountability and transparency aligns with the user's project goals. They also have experience in fundraising and managing a distributed team, which aligns with the user's project requirements. Although based in Germany, their work has international implications and can provide a model for the user's project.
## Suggestion 3 - European Digital Rights (EDRi)

EDRi is a network of civil society organisations from across Europe that defends human rights in the digital environment. They advocate for strong data protection, freedom of expression, and access to knowledge. While not exclusively focused on AI, their work on digital rights and algorithmic accountability is highly relevant to the anti-AI movement.

### Success Metrics



### Risks and Challenges Faced



### Where to Find More Information

https://edri.org/

### Actionable Steps

Contact EDRi via their website for information on their advocacy strategies and policy positions.
Explore their publications and reports for detailed analysis of digital rights issues.
Attend their events and conferences to network with other digital rights advocates.

### Rationale for Suggestion

EDRi provides a relevant example of a European network of organizations focused on digital rights. Their experience in advocating for policy changes, engaging with policymakers, and building a strong network can offer valuable insights for the anti-AI movement, particularly in navigating the European regulatory landscape and building partnerships with other organizations. Their focus on digital rights and algorithmic accountability aligns with the user's project goals. Their European focus is particularly relevant given the project's Swiss headquarters and EUR financial operations.

## Summary

The user is developing a 6-month plan to establish an international anti-AI movement, headquartered in Switzerland, with a €1.6M budget. The movement will operate primarily online and focus on protesting AI job displacement. The plan includes establishing a Swiss legal entity, developing a secure online platform, recruiting staff and volunteers, developing core messaging, building an online community, and implementing a fundraising strategy. The strategic decisions emphasize a balanced approach between cost, security, agility, and compliance. The following projects are recommended as references.