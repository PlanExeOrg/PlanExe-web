This plan involves money.

## Currencies

- **EUR:** The project's financial operations are primarily in EUR, and the budget is specified in EUR.
- **CHF:** The headquarters is in Switzerland, so CHF may be needed for local expenses.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. CHF may be used for local transactions in Switzerland. No additional international risk management is needed as the primary currency is EUR.