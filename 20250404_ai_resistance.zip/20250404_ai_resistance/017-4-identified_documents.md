
## Documents to Create

### 1. Project Charter

**ID:** 76aea37e-7a1b-4a54-81bf-06679088a653

**Description:** A formal document that initiates the project, defines its objectives, scope, and stakeholders, and authorizes the project manager to use organizational resources. It outlines the project's purpose, high-level requirements, and success criteria. It serves as a reference point throughout the project lifecycle.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project objectives and scope.
- Identify key stakeholders.
- Outline high-level requirements and deliverables.
- Establish project governance and approval process.
- Obtain sign-off from project sponsors.

**Approval Authorities:** Project Sponsors, Steering Committee

### 2. Risk Register

**ID:** 2ac23b2f-4d16-4cbc-9977-226f932c5e0a

**Description:** A document that identifies potential risks to the project, assesses their likelihood and impact, and outlines mitigation strategies. It serves as a central repository for risk-related information and is regularly updated throughout the project lifecycle.

**Responsible Role Type:** Risk and Safety Manager

**Primary Template:** PMI Risk Register Template

**Steps:**

- Identify potential risks through brainstorming and expert consultation.
- Assess the likelihood and impact of each risk.
- Develop mitigation strategies for high-priority risks.
- Assign risk owners and track mitigation progress.
- Regularly review and update the risk register.

**Approval Authorities:** Project Manager, Risk and Safety Manager

### 3. Communication Plan

**ID:** 9435f16c-dac2-4d72-aa99-fc8cc2f9c156

**Description:** A document that outlines how project information will be communicated to stakeholders, including the frequency, channels, and content of communications. It ensures that stakeholders are kept informed of project progress and any issues that may arise.

**Responsible Role Type:** Communications and Messaging Specialist

**Primary Template:** PMI Communication Plan Template

**Steps:**

- Identify project stakeholders and their communication needs.
- Define communication channels and frequency.
- Establish communication protocols and responsibilities.
- Develop a communication matrix outlining who needs to know what and when.
- Regularly review and update the communication plan.

**Approval Authorities:** Project Manager, Communications and Messaging Specialist

### 4. Stakeholder Engagement Plan

**ID:** 2dabd5ea-965c-4c8b-93cb-7e7f09c0b0ec

**Description:** A document that outlines how the project team will engage with stakeholders to ensure their support and involvement. It identifies key stakeholders, their interests and influence, and strategies for managing their expectations.

**Responsible Role Type:** Partnership Liaison

**Steps:**

- Identify key project stakeholders.
- Assess their interests, influence, and potential impact on the project.
- Develop engagement strategies for each stakeholder group.
- Establish communication channels and feedback mechanisms.
- Regularly review and update the stakeholder engagement plan.

**Approval Authorities:** Project Manager, Partnership Liaison

### 5. Change Management Plan

**ID:** e2b0445f-e043-4dd5-80c6-56168950abad

**Description:** A document that outlines how changes to the project will be managed, including the process for requesting, evaluating, and approving changes. It ensures that changes are implemented in a controlled and coordinated manner.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Change Management Plan Template

**Steps:**

- Define the change management process.
- Establish a change control board.
- Develop a change request form.
- Outline the criteria for evaluating change requests.
- Establish a process for communicating changes to stakeholders.

**Approval Authorities:** Change Control Board, Project Sponsors

### 6. High-Level Budget/Funding Framework

**ID:** 4ac72415-dc4b-4a15-afda-2d8d69032e48

**Description:** A document that outlines the overall budget for the project, including the sources of funding and the allocation of funds to different activities. It provides a high-level overview of the project's financial resources and constraints.

**Responsible Role Type:** Finance/Operations Lead

**Steps:**

- Identify all project activities and their associated costs.
- Estimate the total cost of the project.
- Identify potential sources of funding.
- Allocate funds to different activities based on priorities.
- Establish a budget tracking and reporting system.

**Approval Authorities:** Project Sponsors, Finance/Operations Lead

### 7. Funding Agreement Structure/Template

**ID:** 800c3d80-4cdd-43d1-9208-c3a969f28e67

**Description:** A template for agreements with funding sources (grants, donors, etc.), outlining terms, conditions, reporting requirements, and legal obligations. Ensures consistent and legally sound funding arrangements.

**Responsible Role Type:** Legal Counsel

**Steps:**

- Research standard funding agreement terms and conditions.
- Consult with legal counsel to ensure compliance with Swiss law.
- Develop a template that covers key legal and financial aspects.
- Include clauses on reporting, intellectual property, and termination.
- Obtain legal review and approval of the template.

**Approval Authorities:** Legal Counsel, Finance/Operations Lead

### 8. Initial High-Level Schedule/Timeline

**ID:** b466feb5-ee58-48ef-92cd-220b3c9bc13c

**Description:** A high-level timeline outlining the major project milestones and their estimated completion dates. It provides a roadmap for the project and helps to track progress.

**Responsible Role Type:** Project Manager

**Primary Template:** Gantt Chart Template

**Steps:**

- Identify major project milestones.
- Estimate the duration of each milestone.
- Sequence the milestones in a logical order.
- Assign resources to each milestone.
- Create a Gantt chart or other visual representation of the timeline.

**Approval Authorities:** Project Sponsors, Project Manager

### 9. M&E Framework

**ID:** b56fb7ef-423e-4fde-94e2-0ee60aa21faf

**Description:** A framework for monitoring and evaluating the project's progress and impact. It defines the key indicators, data collection methods, and reporting frequency. It ensures that the project is on track to achieve its objectives and that its impact is being measured effectively.

**Responsible Role Type:** Project Manager

**Primary Template:** Logical Framework Template

**Steps:**

- Define project objectives and outcomes.
- Identify key indicators for measuring progress and impact.
- Develop data collection methods and tools.
- Establish a reporting frequency and format.
- Assign responsibilities for data collection and analysis.

**Approval Authorities:** Project Sponsors, Project Manager

### 10. Anti-AI Movement Platform Development Framework

**ID:** 120b8d26-8d5e-4329-b32d-7ff755b21de1

**Description:** A high-level framework outlining the strategy for developing the online platform, including technology choices, security considerations, and feature prioritization. It guides the platform development team and ensures alignment with the movement's goals.

**Responsible Role Type:** Technical Lead/Platform Management

**Steps:**

- Define platform requirements and functionality.
- Evaluate different technology options.
- Establish security standards and protocols.
- Prioritize platform features based on user needs and budget constraints.
- Outline the platform development process and timeline.

**Approval Authorities:** Technical Lead/Platform Management, Project Manager

### 11. Anti-AI Movement Fundraising Strategy

**ID:** c43e3fff-b8ba-4f95-81b8-f82886df20b3

**Description:** A strategic plan outlining how the movement will raise funds to support its operations, including target audiences, fundraising channels, and messaging. It ensures a diversified and sustainable funding model.

**Responsible Role Type:** Fundraising Strategist

**Steps:**

- Identify potential funding sources (online donations, grants, merchandise sales).
- Develop compelling fundraising appeals and communication materials.
- Establish online donation platforms and merchandise sales channels.
- Research grant opportunities and prepare grant proposals.
- Track fundraising progress and report on results.

**Approval Authorities:** Fundraising Strategist, Finance/Operations Lead

### 12. Anti-AI Movement Legal and Compliance Framework

**ID:** 08370c64-827e-487e-80c6-97540cd3a0c9

**Description:** A framework outlining the legal structure of the movement, including the establishment of the 'Verein' in Switzerland, and compliance with relevant regulations. It ensures that the movement operates within the law and minimizes legal risks.

**Responsible Role Type:** Legal Counsel

**Steps:**

- Consult with Swiss legal counsel to determine the best legal structure for the movement.
- Prepare the necessary documentation for establishing the 'Verein'.
- Register the 'Verein' with the Swiss authorities.
- Develop policies and procedures for complying with relevant regulations (data privacy, financial reporting).
- Establish a legal advisory board to provide ongoing guidance.

**Approval Authorities:** Legal Counsel, Project Manager

### 13. Anti-AI Movement Core Narrative and Messaging Guide

**ID:** 887c0546-5fdd-4bf2-b28b-69195eb1c3d9

**Description:** A guide outlining the core message and values of the movement, including key talking points and communication strategies. It ensures consistent and effective communication across all channels.

**Responsible Role Type:** Communications and Messaging Specialist

**Steps:**

- Define the movement's core message and values.
- Develop key talking points and communication strategies.
- Identify target audiences and tailor messaging accordingly.
- Create communication materials (press releases, social media posts, website content).
- Train staff and volunteers on how to communicate the movement's message effectively.

**Approval Authorities:** Communications and Messaging Specialist, Project Manager

### 14. Anti-AI Movement Technology Infrastructure Strategy

**ID:** 20384b19-bb34-4c90-8df9-dab9608af628

**Description:** A strategy outlining the technology infrastructure that will support the movement's operations, including cloud services, in-house infrastructure, and security measures. It ensures a reliable and secure technology environment.

**Responsible Role Type:** Technical Lead/Platform Management

**Steps:**

- Assess the movement's technology needs.
- Evaluate different technology options (cloud services, in-house infrastructure).
- Establish security standards and protocols.
- Develop a technology infrastructure plan.
- Implement the technology infrastructure and provide ongoing support.

**Approval Authorities:** Technical Lead/Platform Management, Project Manager

### 15. Anti-AI Movement Recruitment and Onboarding Plan

**ID:** 2999855f-864e-4a8d-bb76-7c081c44a23b

**Description:** A plan outlining the strategy for recruiting and onboarding staff and volunteers, including job descriptions, recruitment channels, and training programs. It ensures that the movement has the necessary human resources to achieve its goals.

**Responsible Role Type:** Volunteer Coordinator

**Steps:**

- Identify staffing and volunteer needs.
- Develop job descriptions and volunteer role descriptions.
- Establish recruitment channels (online job boards, networks).
- Develop onboarding and training programs.
- Implement a recruitment and onboarding process.

**Approval Authorities:** Volunteer Coordinator, Project Manager

### 16. Current State Assessment of AI Job Displacement

**ID:** d5e836e8-ed17-48d2-986e-62f78bcf2499

**Description:** A report assessing the current state of AI-driven job displacement, including affected industries, geographic regions, and demographic groups. It provides a baseline for measuring the movement's impact.

**Responsible Role Type:** Labor Economist

**Steps:**

- Gather data on AI-driven job displacement from various sources (government reports, industry publications, academic research).
- Analyze the data to identify trends and patterns.
- Identify affected industries, geographic regions, and demographic groups.
- Prepare a report summarizing the findings.
- Disseminate the report to stakeholders.

**Approval Authorities:** Project Manager, Labor Economist

## Documents to Find

### 1. Participating Nations AI Job Displacement Statistical Data

**ID:** 293eacd6-8a1a-4502-8cca-2d0323799e8f

**Description:** Statistical data on job displacement due to AI and automation, including industry-specific breakdowns, demographic information, and geographic distribution. Used to understand the scope and impact of AI job displacement and to target the movement's efforts effectively. Intended audience: Project team, researchers, and policymakers.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Labor Economist

**Access Difficulty:** Medium: Requires contacting multiple sources and potentially submitting data requests.

**Steps:**

- Contact national statistical offices in participating nations.
- Search international databases (e.g., World Bank, OECD).
- Review academic research and industry reports.
- Submit data requests to relevant government agencies.

### 2. Participating Nations Labor Market Statistical Data

**ID:** a84679c8-ae89-4ae5-bfc9-daa9dbd95a6b

**Description:** Comprehensive labor market statistics, including employment rates, unemployment rates, wage levels, and industry trends. Used to understand the broader economic context and to assess the impact of AI on the labor market. Intended audience: Project team, researchers, and policymakers.

**Recency Requirement:** Most recent available year

**Responsible Role Type:** Labor Economist

**Access Difficulty:** Medium: Requires contacting multiple sources and potentially submitting data requests.

**Steps:**

- Contact national statistical offices in participating nations.
- Search international databases (e.g., World Bank, OECD).
- Review academic research and industry reports.
- Submit data requests to relevant government agencies.

### 3. Existing Swiss 'Verein' Laws and Regulations

**ID:** 098caa89-cdb8-465a-a5f6-b75f69f02453

**Description:** The complete text of Swiss laws and regulations governing the establishment and operation of 'Verein' (non-profit associations), including requirements for registration, governance, and financial reporting. Used to ensure compliance with Swiss law. Intended audience: Legal Counsel, Project Manager.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Easy: Publicly available online.

**Steps:**

- Search the Swiss Federal Commercial Registry Office website.
- Consult with Swiss legal counsel.
- Review the 'ZGB 60 ff.' (Swiss Civil Code) concerning 'Verein' regulations.

### 4. Existing Swiss Data Privacy Laws and Regulations (DSG)

**ID:** c3e86476-8819-471d-b0fb-f4adcde0706c

**Description:** The complete text of Swiss data privacy laws and regulations (DSG), including requirements for data collection, storage, processing, and transfer. Used to ensure compliance with Swiss data privacy law. Intended audience: Legal Counsel, Data Protection Officer.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Easy: Publicly available online.

**Steps:**

- Search the website of the Swiss Federal Data Protection and Information Commissioner (FDPIC).
- Consult with Swiss legal counsel.
- Review relevant legal databases.

### 5. Existing Swiss Financial Reporting Standards (GAAP FER)

**ID:** 721fea22-099a-4dec-bbb5-c65d1fc2faa9

**Description:** The complete text of Swiss financial reporting standards (GAAP FER), including requirements for financial reporting by non-profit organizations. Used to ensure compliance with Swiss financial reporting standards. Intended audience: Finance/Operations Lead, Legal Counsel.

**Recency Requirement:** Current standards essential

**Responsible Role Type:** Finance/Operations Lead

**Access Difficulty:** Medium: Requires access to specialized financial databases or consultation with experts.

**Steps:**

- Search the website of EXPERTsuisse, the Swiss expert association for audit, tax and fiduciary.
- Consult with Swiss financial advisors.
- Review relevant accounting databases.

### 6. Existing National AI and Automation Policies

**ID:** de7e86db-6656-42c7-9042-41165483f8ba

**Description:** Existing government policies and regulations related to AI and automation, including workforce retraining programs, unemployment benefits, and ethical guidelines. Used to understand the policy landscape and to identify opportunities for advocacy. Intended audience: Project team, policymakers.

**Recency Requirement:** Published within last 2 years

**Responsible Role Type:** Labor Economist

**Access Difficulty:** Medium: Requires searching multiple sources and potentially contacting government agencies.

**Steps:**

- Search government websites and policy databases.
- Review reports from international organizations (e.g., OECD, ILO).
- Contact government agencies and policy experts.

### 7. Official National Mental Health Survey Data

**ID:** 12907f10-5182-4f3c-80f6-51ab6a563424

**Description:** Results from official national mental health surveys, including data on anxiety, depression, and stress levels related to job security and economic uncertainty. Used to understand the psychological impact of AI job displacement and to inform the movement's messaging. Intended audience: Project team, researchers, and policymakers.

**Recency Requirement:** Published within last 5 years

**Responsible Role Type:** Labor Economist

**Access Difficulty:** Medium: Requires contacting government agencies and potentially submitting data requests.

**Steps:**

- Contact national statistical offices and health agencies.
- Search government websites and research databases.
- Review reports from international organizations (e.g., WHO).