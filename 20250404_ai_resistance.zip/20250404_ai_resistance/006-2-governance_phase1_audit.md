
## Audit - Corruption Risks

- Bribery of Swiss officials to expedite the 'Verein' registration process or obtain favorable regulatory treatment.
- Kickbacks from platform developers or cloud service providers in exchange for contract awards.
- Conflicts of interest involving core team members who may have undisclosed financial ties to vendors or partner organizations.
- Misuse of inside information regarding fundraising strategies or donor contacts for personal gain.
- Nepotism in hiring core staff or awarding contracts to friends or family members.

## Audit - Misallocation Risks

- Inflated invoices or fraudulent expense claims submitted by staff or vendors.
- Double-billing for services rendered by contractors or consultants.
- Misuse of funds allocated for platform development for unrelated expenses.
- Inefficient allocation of resources to low-impact activities or initiatives.
- Poor record-keeping and inadequate documentation of financial transactions, making it difficult to track expenses and identify discrepancies.

## Audit - Procedures

- Conduct quarterly internal audits of financial records and expense reports to identify irregularities and ensure compliance with budget guidelines. Responsibility: Finance/Operations Lead and an independent internal auditor.
- Implement a contract review process with pre-defined thresholds (e.g., contracts exceeding €10,000 require review by the Legal/Compliance Liaison and Project Management).
- Perform periodic security audits of the online platform to identify and address vulnerabilities. Frequency: Quarterly. Responsibility: Technical Lead/Platform Management and external cybersecurity consultants.
- Conduct regular compliance checks to ensure adherence to Swiss legal and regulatory requirements for non-profit organizations. Frequency: Bi-annually. Responsibility: Legal/Compliance Liaison and external legal counsel.
- Implement a whistleblower mechanism for reporting suspected fraud or misconduct, with clear procedures for investigation and resolution.

## Audit - Transparency Measures

- Publish a project progress dashboard on the movement's website, including key milestones, budget expenditures, and fundraising progress. Update frequency: Monthly.
- Publish minutes of core team meetings on the movement's website, redacting sensitive information as necessary.
- Develop and implement a publicly accessible whistleblower policy outlining procedures for reporting and investigating suspected wrongdoing.
- Document and publish the selection criteria for major decisions, such as vendor selection and partnership agreements.
- Make the movement's financial reports (summarized or detailed, depending on the chosen Financial Transparency Level) publicly available on the website.