*Roles Needed & Example People*

# Roles

## 1. Legal Counsel (Swiss Law)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Legal expertise is needed for a specific task (Verein establishment) and ongoing compliance, but not necessarily on a full-time basis. An independent contractor provides specialized knowledge without long-term commitment.

**Explanation**:
Expertise in Swiss law is crucial for establishing the 'Verein' and ensuring compliance with local regulations, including data privacy and financial reporting.

**Consequences**:
Significant delays in establishing the legal entity, potential legal liabilities, and inability to secure funding due to non-compliance.

**People Count**:
min 1, max 2, depending on the complexity of legal issues encountered.

**Typical Activities**:
Advising on Swiss legal requirements for establishing and operating a 'Verein'. Ensuring compliance with data privacy laws (DSG) and financial reporting regulations (GAAP FER). Providing guidance on lobbying regulations and potential legal challenges. Drafting and reviewing legal documents, such as contracts and policies. Representing the organization in legal matters.

**Background Story**:
Astrid Dubois, a Swiss national from Zurich, has spent the last decade immersed in the intricacies of Swiss law. After graduating from the University of Zurich with a law degree specializing in non-profit organizations, she worked for several years at a prominent Zurich law firm, advising various 'Verein' on compliance, governance, and fundraising regulations. Astrid is intimately familiar with the legal landscape surrounding non-profits in Switzerland and possesses a deep understanding of data privacy laws, financial reporting requirements, and lobbying regulations. Her expertise is particularly relevant to ensuring the anti-AI movement's legal foundation is solid and compliant from the outset.

**Equipment Needs**:
Laptop with secure internet access, legal research software (e.g., Swisslex), access to legal databases, secure communication tools.

**Facility Needs**:
Private office space for confidential consultations and document review, access to meeting rooms for client meetings.

## 2. Fundraising Strategist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Fundraising strategy development is a specialized skill that can be contracted out. An independent contractor can provide expertise in developing a fundraising plan and initial implementation, with the option to extend the contract based on performance.

**Explanation**:
A fundraising strategist is essential for developing and implementing a diversified fundraising plan to secure the necessary funding for the movement's operations.

**Consequences**:
Inability to secure sufficient funding, leading to project delays, reduced operational capacity, and potential project failure.

**People Count**:
min 1, max 3, depending on fundraising targets and channel complexity.

**Typical Activities**:
Developing and implementing a diversified fundraising plan. Identifying and cultivating potential donors, including individuals, foundations, and corporations. Crafting compelling fundraising appeals and communication materials. Managing online donation campaigns and merchandise sales. Tracking fundraising progress and reporting on results.

**Background Story**:
Jean-Pierre Moreau, originally from Paris, France, is a seasoned fundraising strategist with over 15 years of experience in the non-profit sector. He holds an MBA from HEC Paris and has a proven track record of developing and implementing successful fundraising campaigns for international organizations. Jean-Pierre specializes in diversified funding models, including online donations, grant writing, and merchandise sales. He is adept at identifying potential donors, crafting compelling fundraising appeals, and building long-term relationships with supporters. His experience in navigating the European philanthropic landscape makes him particularly relevant to securing funding for the anti-AI movement.

**Equipment Needs**:
Laptop with fundraising CRM software, online donation platform access, marketing automation tools, presentation software.

**Facility Needs**:
Dedicated workspace, access to meeting rooms for donor presentations, quiet space for research and strategy development.

## 3. Community Engagement Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Community engagement requires consistent effort and dedication to build and nurture a strong online community. A full-time employee ensures consistent engagement and alignment with the movement's goals.

**Explanation**:
This role is vital for building and nurturing a strong online community, which is essential for mobilizing support and sustaining the movement's momentum.

**Consequences**:
Limited community growth, reduced engagement, and difficulty in mobilizing support for the movement's activities.

**People Count**:
min 1, max 4, depending on the breadth of community-building efforts and the number of platforms used.

**Typical Activities**:
Developing and implementing a community engagement strategy. Creating engaging content for social media platforms and online forums. Moderating online discussions and fostering a sense of community. Recruiting and managing volunteer moderators. Tracking community growth and engagement metrics.

**Background Story**:
Aisha Khan, born and raised in Geneva, Switzerland, has a passion for community building and social activism. With a degree in Communications from the University of Geneva, she has spent the last five years working for various NGOs, building and managing online communities. Aisha is skilled in creating engaging content, moderating online discussions, and fostering a sense of belonging among community members. She is also experienced in using social media platforms and online forums to mobilize support for social causes. Her understanding of the Swiss cultural landscape and her ability to connect with diverse audiences make her particularly relevant to building a strong online community for the anti-AI movement.

**Equipment Needs**:
Laptop with social media management tools, content creation software, community forum moderation tools, analytics dashboards.

**Facility Needs**:
Dedicated workspace, access to collaboration tools, quiet space for content creation and community monitoring.

## 4. Platform Security Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Platform security is a critical area requiring specialized expertise. An independent contractor can conduct security audits, implement security measures, and provide ongoing support without the need for a full-time employee.

**Explanation**:
Ensuring the security of the online platform is critical for protecting user data and maintaining trust. This role requires expertise in cybersecurity and data privacy.

**Consequences**:
Increased risk of security breaches, data loss, and reputational damage, leading to a loss of user trust and reduced platform adoption.

**People Count**:
min 1, max 2, depending on the complexity of the platform and the level of security required.

**Typical Activities**:
Conducting security audits and vulnerability assessments. Implementing security measures, such as firewalls, intrusion detection systems, and encryption. Developing and maintaining security policies and procedures. Responding to security incidents and data breaches. Providing security training to staff and volunteers.

**Background Story**:
Kenji Tanaka, a Japanese-American cybersecurity expert based in Zug, Switzerland, has spent his career safeguarding digital assets for various organizations. After earning a Master's degree in Computer Science from ETH Zurich, he worked as a security consultant for several years, conducting security audits, implementing security measures, and responding to security incidents. Kenji is proficient in various cybersecurity technologies and methodologies, including penetration testing, vulnerability scanning, and incident response. His expertise in data privacy and security compliance, particularly in the context of Swiss regulations, makes him particularly relevant to ensuring the online platform's security.

**Equipment Needs**:
Laptop with penetration testing tools, vulnerability scanning software, security auditing tools, access to security databases.

**Facility Needs**:
Secure workspace with restricted access, isolated testing environment, access to server infrastructure for security assessments.

## 5. Communications and Messaging Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Consistent messaging and communication are vital for shaping public perception and attracting supporters. A full-time employee ensures consistent messaging and alignment with the movement's goals.

**Explanation**:
Crafting a compelling and resonant narrative is essential for attracting supporters and influencing public opinion. This role requires expertise in communications, marketing, and public relations.

**Consequences**:
Failure to resonate with the public, limited community growth, and difficulty in influencing policy decisions.

**People Count**:
min 1, max 2, depending on the scope of the communication strategy and the number of channels used.

**Typical Activities**:
Developing and implementing a communication strategy. Crafting compelling narratives and messaging. Writing press releases and managing media relations. Managing social media accounts and online communication channels. Tracking media coverage and public opinion.

**Background Story**:
Isabelle Dubois, from Lausanne, Switzerland, is a skilled communications and messaging specialist with a background in journalism and public relations. After graduating from the University of Lausanne with a degree in Communications, she worked as a journalist for a local newspaper, covering social and political issues. Isabelle is adept at crafting compelling narratives, writing press releases, and managing media relations. She is also experienced in using social media platforms to promote social causes and influence public opinion. Her understanding of the Swiss media landscape and her ability to communicate effectively in multiple languages make her particularly relevant to shaping the movement's narrative and attracting supporters.

**Equipment Needs**:
Laptop with content creation software, press release distribution tools, social media management platforms, media monitoring software.

**Facility Needs**:
Dedicated workspace, access to collaboration tools, quiet space for writing and strategic planning, access to media contact databases.

## 6. Volunteer Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Volunteer coordination requires consistent effort and dedication to recruit, train, and manage volunteers. A full-time employee ensures effective volunteer management and sustained volunteer contributions.

**Explanation**:
Effective volunteer management is crucial for maximizing the impact of volunteer contributions and sustaining the movement's operations.

**Consequences**:
Inconsistent volunteer contributions, reduced efficiency, and difficulty in coordinating volunteer efforts.

**People Count**:
min 1, max 2, depending on the number of volunteers and the complexity of the volunteer program.

**Typical Activities**:
Developing and implementing a volunteer program. Recruiting, training, and managing volunteers. Coordinating volunteer activities and providing support. Tracking volunteer hours and contributions. Recognizing and rewarding volunteers.

**Background Story**:
Liam O'Connell, an Irish national residing in Geneva, Switzerland, has a strong background in volunteer management and community organizing. After earning a degree in Social Work from Trinity College Dublin, he worked for several years at a local community center, recruiting, training, and managing volunteers. Liam is skilled in developing volunteer programs, coordinating volunteer activities, and providing support and recognition to volunteers. His experience in working with diverse populations and his ability to motivate and inspire volunteers make him particularly relevant to maximizing the impact of volunteer contributions.

**Equipment Needs**:
Laptop with volunteer management software, communication tools, training materials, scheduling software.

**Facility Needs**:
Dedicated workspace, access to meeting rooms for volunteer training, space for volunteer coordination activities.

## 7. Partnership Liaison

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Building and maintaining partnerships requires consistent effort and relationship management. A full-time employee ensures dedicated focus on partnership development and alignment with the movement's goals.

**Explanation**:
Building strategic partnerships with other organizations can expand the movement's reach and influence. This role requires expertise in networking, relationship management, and negotiation.

**Consequences**:
Limited reach, reduced access to resources, and difficulty in building a broad coalition of support.

**People Count**:
1

**Typical Activities**:
Identifying and cultivating potential partner organizations. Building and maintaining relationships with partner organizations. Negotiating partnership agreements and contracts. Coordinating joint activities and initiatives. Tracking partnership outcomes and reporting on results.

**Background Story**:
Elena Rossi, an Italian national based in Zug, Switzerland, has a strong background in international relations and partnership development. After earning a Master's degree in International Affairs from the Graduate Institute Geneva, she worked for several years at a local NGO, building and managing partnerships with other organizations. Elena is skilled in networking, relationship management, and negotiation. Her experience in working with diverse organizations and her ability to build consensus make her particularly relevant to expanding the movement's reach and influence.

**Equipment Needs**:
Laptop with CRM software, communication tools, presentation software, access to partnership databases.

**Facility Needs**:
Dedicated workspace, access to meeting rooms for partner meetings, quiet space for research and strategy development.

## 8. Risk and Safety Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Risk and safety management requires consistent monitoring and mitigation efforts. A full-time employee ensures dedicated focus on identifying and addressing potential risks associated with the movement's activities.

**Explanation**:
This role is essential for identifying and mitigating potential risks associated with the movement's activities, including protest activities and online security threats.

**Consequences**:
Increased risk of injuries, legal liabilities, and reputational damage, leading to a loss of public support and reduced operational capacity.

**People Count**:
1

**Typical Activities**:
Conducting risk assessments for all planned activities. Developing and implementing safety and security plans. Providing safety training to staff and volunteers. Establishing clear communication channels for reporting safety concerns. Coordinating with local authorities and emergency services.

**Background Story**:
Hans-Peter Weber, a Swiss national from Bern, has extensive experience in risk management and safety protocols, particularly within the context of social movements and public gatherings. After serving in the Swiss Army, he worked as a security consultant for various organizations, conducting risk assessments, developing safety plans, and providing security training. Hans-Peter is skilled in identifying potential hazards, implementing mitigation measures, and responding to emergencies. His knowledge of Swiss regulations and his ability to maintain a calm and professional demeanor under pressure make him particularly relevant to ensuring the safety and security of the movement's activities.

**Equipment Needs**:
Laptop with risk assessment software, incident reporting tools, communication devices, access to security databases.

**Facility Needs**:
Dedicated workspace, access to security monitoring systems, secure communication channels, access to emergency response resources.

---

# Omissions

## 1. Dedicated IT Support

While a Technical Lead/Platform Management role is defined, ongoing IT support for staff and volunteers is not explicitly addressed. This includes troubleshooting hardware/software issues, managing user accounts, and ensuring basic tech functionality for the team.

**Recommendation**:
Assign a portion of the Technical Lead's time or delegate to a volunteer with IT skills to provide basic IT support. Alternatively, budget for occasional external IT support services.

## 2. Content Moderation Strategy

The plan mentions building an online community but lacks a clear strategy for content moderation. Without moderation, the platform risks becoming a source of misinformation, hate speech, or spam, damaging the movement's credibility and alienating supporters.

**Recommendation**:
Develop a content moderation policy outlining acceptable behavior and consequences for violations. Assign moderation responsibilities to the Community Engagement Manager or recruit volunteer moderators. Consider using AI-based moderation tools, but with human oversight.

## 3. Accessibility Considerations

The plan doesn't explicitly address accessibility for people with disabilities. An inclusive movement should ensure its online platform and communication materials are accessible to everyone, regardless of their abilities.

**Recommendation**:
Incorporate accessibility best practices into the platform development process (e.g., WCAG guidelines). Ensure communication materials are available in accessible formats (e.g., captions for videos, alt text for images).

---

# Potential Improvements

## 1. Clarify Volunteer Roles and Responsibilities

The plan mentions recruiting volunteers but lacks detail on specific volunteer roles and responsibilities. Clear role definitions are crucial for effective volunteer management and ensuring volunteers contribute meaningfully.

**Recommendation**:
Develop a list of specific volunteer roles with clear descriptions of responsibilities, required skills, and time commitments. This will help attract the right volunteers and ensure they are effectively utilized.

## 2. Streamline Communication Channels

The plan mentions various communication channels but lacks a clear strategy for coordinating communication across these channels. Overlapping or conflicting messages can confuse supporters and reduce the movement's impact.

**Recommendation**:
Designate a central communication hub (e.g., a project management tool or shared calendar) to coordinate messaging across different channels. Establish clear guidelines for communication frequency and content.

## 3. Define Success Metrics for Partnerships

The plan mentions establishing initial partnerships but lacks specific metrics for evaluating the success of these partnerships. Clear metrics are essential for ensuring partnerships are mutually beneficial and contribute to the movement's goals.

**Recommendation**:
Define specific, measurable, achievable, relevant, and time-bound (SMART) goals for each partnership. Track progress against these goals and regularly evaluate the effectiveness of the partnerships.