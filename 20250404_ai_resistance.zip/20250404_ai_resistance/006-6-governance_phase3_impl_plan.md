### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics and Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start

### 4. Circulate Draft SteerCo ToR for review by nominated members (Executive Director, Head of Strategy, Head of Fundraising).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 5. Circulate Draft Ethics & Compliance Committee ToR for review by Legal/Compliance Liaison.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Legal/Compliance Liaison Appointed

### 6. Circulate Draft Technical Advisory Group ToR for review by Technical Lead/Platform Management.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Technical Lead/Platform Management Appointed

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 8. Project Manager finalizes the Ethics and Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 9. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. Executive Director formally appoints the Project Steering Committee Chair (Executive Director).

**Responsible Body/Role:** Executive Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Project Steering Committee members are formally confirmed (Executive Director, Head of Strategy, Head of Fundraising, Independent Legal Expert, Independent Technology Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final SteerCo ToR v1.0
- Executive Director Appointed
- Head of Strategy Appointed
- Head of Fundraising Appointed
- Independent Legal Expert Selected
- Independent Technology Expert Selected

### 12. Legal/Compliance Liaison formally appointed as Chair of the Ethics and Compliance Committee.

**Responsible Body/Role:** Executive Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 13. Ethics and Compliance Committee members are formally confirmed (Legal/Compliance Liaison, Independent Ethics Expert, Independent Financial Auditor, Data Protection Officer, Representative from the Project Steering Committee).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Legal/Compliance Liaison Appointed
- Independent Ethics Expert Selected
- Independent Financial Auditor Selected
- Data Protection Officer Appointed
- Project Steering Committee Established

### 14. Technical Lead/Platform Management formally appointed as lead of the Technical Advisory Group.

**Responsible Body/Role:** Executive Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Technical Advisory Group ToR v1.0

### 15. Technical Advisory Group members are formally confirmed (Technical Lead/Platform Management, Independent Cybersecurity Expert, Independent Software Architect, Independent Data Privacy Expert, Representative from the PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Technical Lead/Platform Management Appointed
- Independent Cybersecurity Expert Selected
- Independent Software Architect Selected
- Independent Data Privacy Expert Selected
- PMO Established

### 16. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Membership Confirmation List
- Final SteerCo ToR v1.0

### 17. Establish Project Management Office (PMO) and assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Established
- Initial Task Assignments

**Dependencies:**

- Project Manager Appointed
- Technical Lead/Platform Management Appointed
- Finance/Operations Lead Appointed
- Communications Lead Appointed
- Legal/Compliance Liaison Appointed

### 18. Hold initial Ethics and Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Code of Ethics Draft

**Dependencies:**

- Membership Confirmation List
- Final Ethics & Compliance Committee ToR v1.0

### 19. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Platform Architecture Recommendations

**Dependencies:**

- Membership Confirmation List
- Final Technical Advisory Group ToR v1.0

### 20. PMO develops project plan template.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Plan Template

**Dependencies:**

- PMO Established

### 21. PMO sets up project tracking system.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Tracking System Setup

**Dependencies:**

- PMO Established

### 22. Ethics and Compliance Committee develops code of ethics.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Code of Ethics v1.0

**Dependencies:**

- Ethics and Compliance Committee Established

### 23. Ethics and Compliance Committee establishes whistleblower policy.

**Responsible Body/Role:** Ethics and Compliance Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Whistleblower Policy v1.0

**Dependencies:**

- Ethics and Compliance Committee Established

### 24. Technical Advisory Group advises on platform architecture and development.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Platform Architecture Recommendations

**Dependencies:**

- Technical Advisory Group Established

### 25. Technical Advisory Group reviews security protocols and vulnerability assessments.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Security Protocol Review
- Vulnerability Assessment Report

**Dependencies:**

- Technical Advisory Group Established

### 26. Project Steering Committee reviews project progress against strategic goals.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Month 2

**Key Outputs/Deliverables:**

- Project Progress Report

**Dependencies:**

- Project Steering Committee Established
- PMO Established