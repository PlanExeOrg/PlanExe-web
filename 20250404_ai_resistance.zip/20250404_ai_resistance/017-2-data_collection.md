## 1. Fundraising Strategy Feasibility

Understanding the feasibility of the fundraising strategy is critical to ensure financial sustainability and avoid project delays.

### Data to Collect

- Detailed breakdown of potential funding sources
- Historical data on fundraising success rates
- Market analysis of donor demographics

### Simulation Steps

- Use fundraising software (e.g., DonorPerfect) to model different fundraising scenarios
- Conduct surveys using tools like SurveyMonkey to gauge donor interest

### Expert Validation Steps

- Consult with a fundraising strategist to review the feasibility study
- Engage with successful non-profit organizations for benchmarking

### Responsible Parties

- Finance/Operations Lead
- Fundraising Strategist

### Assumptions

- **High:** The fundraising targets are achievable within the first 6 months.

### SMART Validation Objective

By the end of month 1, validate the fundraising targets through a detailed feasibility study, aiming for at least 80% accuracy in projections.

### Notes

- Consider potential economic downturns affecting donor behavior.
- Explore alternative funding sources as a contingency.


## 2. Data Privacy Compliance

Ensuring compliance with data privacy laws is essential to avoid legal penalties and maintain user trust.

### Data to Collect

- Comprehensive data mapping of user data flows
- Details on data processing activities and storage locations
- Compliance requirements for GDPR and DSG

### Simulation Steps

- Utilize data mapping tools (e.g., OneTrust) to visualize data flows
- Conduct a mock audit using compliance checklists

### Expert Validation Steps

- Engage a data protection officer (DPO) for compliance review
- Consult with a legal expert specializing in data privacy laws

### Responsible Parties

- Legal/Compliance Liaison
- Data Protection Officer

### Assumptions

- **High:** Compliance with Swiss data privacy laws will be achieved through ongoing legal consultation.

### SMART Validation Objective

By the end of month 2, develop and implement a comprehensive data privacy policy that meets all legal requirements.

### Notes

- Monitor changes in data privacy regulations that may affect compliance.
- Ensure all staff are trained on data privacy policies.


## 3. Safety and Risk Management for Protests

Effective risk management is crucial to ensure the safety of participants and mitigate legal liabilities during protests.

### Data to Collect

- Risk assessment reports for planned protest activities
- Safety protocols and emergency response plans
- Insurance coverage details for protest activities

### Simulation Steps

- Conduct tabletop exercises to simulate protest scenarios
- Use risk assessment software (e.g., RiskWatch) to evaluate potential hazards

### Expert Validation Steps

- Consult with a protest safety coordinator for safety plan validation
- Engage local law enforcement for insights on safety protocols

### Responsible Parties

- Risk and Safety Manager
- Project Management

### Assumptions

- **High:** Safety protocols will be sufficient to mitigate risks associated with protest activities.

### SMART Validation Objective

By the end of month 1, complete a comprehensive risk assessment and develop a safety plan for all planned protests.

### Notes

- Consider potential counter-protests and their implications.
- Establish clear communication channels for safety updates.

## Summary

Immediate focus should be on validating the fundraising strategy, ensuring data privacy compliance, and developing safety protocols for protests. These areas are critical due to their high sensitivity scores and potential impact on the project's success.