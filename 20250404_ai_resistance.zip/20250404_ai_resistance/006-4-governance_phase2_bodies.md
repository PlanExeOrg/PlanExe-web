### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for the project, ensuring alignment with the overall goals of establishing an international anti-AI movement and managing strategic risks.

**Responsibilities:**

- Approve the project plan and budget.
- Monitor project progress against strategic goals.
- Approve significant changes to project scope, budget, or timeline (above €50,000).
- Oversee strategic risk management and mitigation.
- Resolve strategic conflicts and escalate issues as needed.
- Ensure alignment with the movement's core narrative and values.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define reporting requirements from the Project Management Office.

**Membership:**

- Executive Director (Chair)
- Head of Strategy
- Head of Fundraising
- Independent Legal Expert (External)
- Independent Technology Expert (External)

**Decision Rights:** Strategic decisions related to project scope, budget (above €50,000), timeline, and risk management.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Executive Director (Chair) has the deciding vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Review of key performance indicators (KPIs).
- Discussion of strategic risks and mitigation plans.
- Approval of budget changes or scope adjustments (above €50,000).
- Review of fundraising performance.
- Review of compliance status.

**Escalation Path:** Executive Director, then Board of Directors (if established).
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient resource allocation, risk management, and adherence to the project plan.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and track expenses.
- Coordinate project activities and resources.
- Monitor project risks and implement mitigation plans.
- Report project progress to the Project Steering Committee.
- Manage vendor relationships.
- Ensure compliance with project management standards.

**Initial Setup Actions:**

- Establish project management methodology.
- Develop project plan template.
- Set up project tracking system.
- Define reporting procedures.

**Membership:**

- Project Manager (Lead)
- Technical Lead/Platform Management
- Finance/Operations Lead
- Communications Lead
- Legal/Compliance Liaison

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management (below €50,000).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with the relevant team members. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Allocation of resources.
- Review of budget and expenses.
- Coordination of project activities.
- Action item tracking.

**Escalation Path:** Project Steering Committee
### 3. Ethics and Compliance Committee

**Rationale for Inclusion:** Provides oversight and guidance on ethical considerations and compliance with relevant laws and regulations, including GDPR, Swiss data privacy laws, and financial transparency standards.

**Responsibilities:**

- Develop and maintain the movement's code of ethics.
- Ensure compliance with GDPR and other data privacy regulations.
- Oversee financial transparency and accountability.
- Investigate ethical complaints and compliance violations.
- Provide training on ethical and compliance issues.
- Review and approve partnership agreements from an ethical and compliance perspective.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop code of ethics.
- Establish whistleblower policy.

**Membership:**

- Legal/Compliance Liaison (Chair)
- Independent Ethics Expert (External)
- Independent Financial Auditor (External)
- Data Protection Officer (DPO)
- Representative from the Project Steering Committee

**Decision Rights:** Decisions related to ethical conduct, compliance with laws and regulations, and financial transparency.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chair has the deciding vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of ethical complaints and compliance violations.
- Discussion of data privacy issues.
- Review of financial transparency reports.
- Approval of changes to the code of ethics.
- Review of compliance training materials.
- Review of whistleblower reports.

**Escalation Path:** Project Steering Committee, then Board of Directors (if established).
### 4. Technical Advisory Group

**Rationale for Inclusion:** Provides expert advice and guidance on technical aspects of the project, ensuring the online platform is secure, scalable, and meets the needs of the movement.

**Responsibilities:**

- Advise on platform architecture and development.
- Review security protocols and vulnerability assessments.
- Evaluate technology vendors and solutions.
- Provide guidance on data privacy and security best practices.
- Monitor platform performance and scalability.
- Advise on emerging technologies and trends.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Identify and recruit technical experts.
- Establish communication channels with the PMO.
- Define areas of expertise required.

**Membership:**

- Technical Lead/Platform Management (Internal)
- Independent Cybersecurity Expert (External)
- Independent Software Architect (External)
- Independent Data Privacy Expert (External)
- Representative from the PMO

**Decision Rights:** Provides recommendations on technical decisions related to platform development, security, and scalability. Final decisions are made by the PMO and Project Steering Committee.

**Decision Mechanism:** Recommendations are developed through consensus. Dissenting opinions are documented and presented to the PMO and Project Steering Committee.

**Meeting Cadence:** Bi-monthly

**Typical Agenda Items:**

- Review of platform architecture and development progress.
- Discussion of security vulnerabilities and mitigation plans.
- Evaluation of technology vendors and solutions.
- Review of data privacy and security best practices.
- Monitoring of platform performance and scalability.
- Discussion of emerging technologies and trends.

**Escalation Path:** Project Steering Committee