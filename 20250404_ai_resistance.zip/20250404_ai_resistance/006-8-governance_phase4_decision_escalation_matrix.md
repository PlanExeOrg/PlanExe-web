**Budget Request Exceeding PMO Authority (€50,000)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential budget overruns and misalignment with strategic priorities.

**Critical Risk Materialization (e.g., Major Data Breach)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Significant financial loss, reputational damage, and legal liabilities.

**PMO Deadlock on Vendor Selection (Conflicting Recommendations)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration and alignment with strategic objectives.
Negative Consequences: Project delays, suboptimal vendor selection, and internal conflicts.

**Proposed Major Scope Change (e.g., Significant Platform Feature Addition)**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Impacts budget, timeline, and strategic goals, requiring Steering Committee approval.
Negative Consequences: Scope creep, budget overruns, and project delays.

**Reported Ethical Concern (e.g., Conflict of Interest)**
Escalation Level: Ethics and Compliance Committee
Approval Process: Ethics Committee Investigation and Recommendation to Steering Committee
Rationale: Requires independent review and assessment to ensure ethical conduct and compliance.
Negative Consequences: Reputational damage, legal liabilities, and loss of stakeholder trust.

**Technical Advisory Group and PMO disagreement on platform architecture**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee review of both positions and final decision
Rationale: Requires strategic alignment and decision-making beyond the PMO's and TAG's authority.
Negative Consequences: Suboptimal platform architecture, security vulnerabilities, and scalability issues.