A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The initial legal setup in Switzerland will proceed without delays or unforeseen complications. | Engage legal counsel to perform a preliminary review of all required documentation and processes. | Legal counsel identifies potential roadblocks or requirements that extend the setup timeline beyond 8 weeks. |
| A2 | The selected open-source platform will seamlessly integrate with custom-developed modules. | Conduct a proof-of-concept integration test between the chosen open-source platform and a basic custom module. | The integration test reveals significant compatibility issues or requires extensive modifications to either the platform or the module. |
| A3 | The movement's human-centered narrative will resonate with a broad audience and attract significant support. | Conduct focus groups with diverse demographics to gauge their reaction to the proposed narrative. | Focus groups indicate that the narrative is perceived as too narrow, polarizing, or ineffective in addressing their concerns. |
| A4 | Key stakeholders (labor unions, AI ethics groups) will readily collaborate and align their efforts with the movement. | Initiate discussions with 3-5 key stakeholder organizations to gauge their interest in collaboration and identify potential areas of alignment. | Stakeholder organizations express reluctance to collaborate due to conflicting priorities, ideological differences, or concerns about the movement's approach. |
| A5 | The online platform will be accessible and usable by individuals with varying levels of technical proficiency and digital literacy. | Conduct usability testing with individuals representing different levels of technical skill and digital literacy. | Usability testing reveals significant barriers to access or use for individuals with limited technical skills or digital literacy. |
| A6 | The initial security measures implemented will be sufficient to deter and prevent significant cyberattacks or data breaches. | Engage a cybersecurity firm to conduct a penetration test of the online platform. | The penetration test reveals exploitable vulnerabilities that could compromise user data or disrupt platform operations. |
| A7 | The cost of acquiring new members and retaining existing ones will remain within projected budget allocations. | Track the cost per acquisition (CPA) and churn rate for new members over the first two months of the campaign. | The CPA exceeds the budgeted amount by 20%, or the churn rate exceeds 10% within the first two months. |
| A8 | The chosen technology stack will remain stable and supported throughout the project lifecycle. | Research the long-term support roadmap and community activity for each component of the technology stack. | Key components of the technology stack are nearing end-of-life, have limited community support, or are known to have unresolved security vulnerabilities. |
| A9 | The movement's message will be effectively translated and adapted for diverse cultural contexts without losing its core meaning or causing unintended offense. | Conduct cultural sensitivity reviews of translated materials with native speakers from diverse cultural backgrounds. | Reviews reveal significant cultural misunderstandings, misinterpretations, or offensive language in translated materials. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Swiss Knot | Process/Financial | A1 | Legal/Compliance Liaison | CRITICAL (16/25) |
| FM2 | The Integration Impasse | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Echo Chamber Effect | Market/Human | A3 | Communications Lead | HIGH (12/25) |
| FM4 | The Coalition Collapse | Process/Financial | A4 | Partnership Liaison | HIGH (12/25) |
| FM5 | The Digital Divide Disaster | Technical/Logistical | A5 | Head of Engineering | CRITICAL (16/25) |
| FM6 | The Cyber Insecurity Crisis | Market/Human | A6 | Platform Security Specialist | HIGH (10/25) |
| FM7 | The Membership Mirage | Process/Financial | A7 | Finance/Operations Lead | HIGH (12/25) |
| FM8 | The Technological Time Bomb | Technical/Logistical | A8 | Head of Engineering | HIGH (10/25) |
| FM9 | The Cultural Minefield | Market/Human | A9 | Communications Lead | HIGH (12/25) |


### Failure Modes

#### FM1 - The Swiss Knot

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Legal/Compliance Liaison
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project's reliance on establishing a 'Verein' in Switzerland creates a single point of failure. Unexpected legal hurdles, bureaucratic delays, or changes in Swiss regulations could significantly impact the project's timeline and budget.  Delays in legal setup directly impact the ability to secure funding, as many grantors require a formal legal entity.  This creates a cascading effect, delaying platform development, staff recruitment, and overall project momentum.  The initial budget may prove insufficient to cover unexpected legal fees or compliance costs.  The movement's credibility could be damaged if it is perceived as non-compliant with Swiss law.

##### Early Warning Signs
- Legal counsel expresses concerns about specific aspects of Swiss law.
- The 'Verein' registration process encounters unexpected delays.
- The cost of legal services exceeds initial budget estimates by 15%.

##### Tripwires
- Verein registration is not approved within 12 weeks of application.
- Legal fees exceed €50,000.
- Key legal documents are rejected by Swiss authorities more than 2 times.

##### Response Playbook
- Contain: Immediately halt all fundraising activities that require legal entity status.
- Assess: Conduct a thorough review of the legal situation with external legal experts to identify the root cause of the delay and potential solutions.
- Respond: Develop a revised legal strategy, potentially exploring alternative legal structures or jurisdictions, and adjust the project timeline and budget accordingly.


**STOP RULE:** If 'Verein' registration is denied after two attempts and alternative legal structures are deemed infeasible, the project will be cancelled.

---

#### FM2 - The Integration Impasse

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The decision to use a hybrid platform development approach, combining an existing open-source platform with custom-built modules, introduces significant technical risks.  The selected open-source platform may not seamlessly integrate with the custom modules, leading to compatibility issues, performance bottlenecks, and security vulnerabilities.  The development team may lack the necessary expertise to effectively integrate the two systems.  The integration process may require extensive modifications to either the platform or the modules, increasing development time and costs.  The resulting platform may be unstable, unreliable, and difficult to maintain.  Data flow between the open-source platform and custom modules may be insecure, exposing user data to potential breaches.

##### Early Warning Signs
- The development team reports unexpected difficulties in integrating the open-source platform with the custom modules.
- Performance testing reveals significant slowdowns or bottlenecks in the integrated platform.
- Security audits identify vulnerabilities related to the integration between the two systems.

##### Tripwires
- Integration testing reveals more than 5 critical compatibility issues.
- Platform performance degrades by more than 20% after integration.
- Security audit identifies a high-severity vulnerability related to the integration.

##### Response Playbook
- Contain: Immediately halt further development of custom modules and focus on stabilizing the existing open-source platform.
- Assess: Conduct a thorough technical review to identify the root cause of the integration issues and evaluate alternative integration strategies.
- Respond: Pivot to a fully custom platform development approach, abandoning the open-source platform, or significantly reduce the scope of the custom modules to minimize integration complexity.


**STOP RULE:** If a stable and secure integrated platform cannot be achieved within 3 months of the initial integration attempt, the project will be cancelled.

---

#### FM3 - The Echo Chamber Effect

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Communications Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The movement's core narrative, while intended to be human-centered, may fail to resonate with a broad audience.  The narrative may be perceived as too narrow, focusing solely on job displacement and neglecting other important aspects of AI's impact.  The narrative may alienate potential supporters who see AI as a source of innovation and progress.  The movement may become an echo chamber, attracting only individuals who already share its views and failing to reach a wider audience.  This could limit the movement's ability to influence public opinion and policy decisions.  The movement may be perceived as anti-technology, hindering its ability to attract support from the tech industry and academic institutions.

##### Early Warning Signs
- Social media engagement with the movement's messaging is low.
- Media coverage of the movement is negative or dismissive.
- Recruitment efforts fail to attract a diverse range of supporters.

##### Tripwires
- Social media engagement (likes, shares, comments) is less than 1% of followers.
- Negative sentiment in media coverage exceeds 50%.
- The movement fails to attract more than 500 active members within the first 3 months.

##### Response Playbook
- Contain: Immediately pause all external communication and marketing campaigns.
- Assess: Conduct a thorough review of the movement's narrative and communication strategy, gathering feedback from diverse stakeholders.
- Respond: Revise the core narrative to address the concerns and perspectives of a wider audience, and develop a new communication strategy that emphasizes inclusivity and collaboration.


**STOP RULE:** If, after a revised narrative and communication strategy are implemented, the movement continues to fail to attract significant support and influence public opinion within 6 months, the project will be cancelled or significantly pivoted.

---

#### FM4 - The Coalition Collapse

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Partnership Liaison
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The movement's success hinges on building a strong coalition of supportive organizations. If key stakeholders, such as labor unions and AI ethics groups, are unwilling to collaborate, the movement's reach, influence, and access to resources will be severely limited. Conflicting priorities, ideological differences, or concerns about the movement's approach could lead to a breakdown in negotiations and a failure to form meaningful partnerships. This could result in a fragmented advocacy landscape, with competing organizations vying for attention and resources. The movement may struggle to gain credibility and legitimacy without the backing of established organizations. Fundraising efforts may be hampered by the lack of a strong coalition.

##### Early Warning Signs
- Negotiations with key stakeholder organizations stall or break down.
- Stakeholder organizations publicly express reservations about the movement's goals or approach.
- The movement struggles to secure endorsements or partnerships from established organizations.

##### Tripwires
- Fewer than 2 key stakeholder organizations agree to formal partnerships within 3 months.
- Key stakeholder organizations publicly criticize the movement's approach.
- Partnership agreements are terminated by more than 1 organization within 6 months.

##### Response Playbook
- Contain: Immediately halt all public statements and outreach efforts related to potential partnerships.
- Assess: Conduct a thorough review of the movement's partnership strategy, identifying the root causes of the collaboration challenges.
- Respond: Revise the partnership strategy to address the concerns of potential collaborators, potentially adjusting the movement's goals or approach to align with their priorities.


**STOP RULE:** If, after a revised partnership strategy is implemented, the movement continues to fail to build a strong coalition of supportive organizations within 9 months, the project will be cancelled or significantly pivoted.

---

#### FM5 - The Digital Divide Disaster

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The movement's online platform is intended to be a central hub for communication, organization, and advocacy. If the platform is not accessible and usable by individuals with varying levels of technical proficiency and digital literacy, a significant portion of the target audience will be excluded. This could create a digital divide within the movement, with technically savvy individuals dominating the conversation and less tech-savvy individuals feeling marginalized. The movement may fail to reach and engage with workers who are most vulnerable to AI job displacement, as they may lack the skills or resources to access the online platform. This could limit the movement's reach, impact, and ability to mobilize support.

##### Early Warning Signs
- Usability testing reveals significant barriers to access or use for individuals with limited technical skills or digital literacy.
- The platform's analytics show that a disproportionate number of users are from a specific demographic group with high levels of technical proficiency.
- The movement receives complaints from users about the platform's accessibility or usability.

##### Tripwires
- Usability testing scores below 70% for users with limited technical skills.
- The platform's user base is composed of more than 80% of individuals with advanced technical skills.
- The movement receives more than 10 complaints per month about the platform's accessibility or usability.

##### Response Playbook
- Contain: Immediately halt all new feature development and focus on improving the platform's accessibility and usability.
- Assess: Conduct a thorough accessibility audit of the platform, identifying specific barriers to access and use.
- Respond: Implement accessibility best practices, such as providing alternative text for images, using clear and concise language, and offering multiple ways to navigate the platform. Provide training and support to users who need assistance.


**STOP RULE:** If, after implementing accessibility improvements, the platform continues to be inaccessible or unusable by a significant portion of the target audience within 6 months, the project will be cancelled or significantly pivoted.

---

#### FM6 - The Cyber Insecurity Crisis

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Platform Security Specialist
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The movement's online platform is a prime target for cyberattacks and data breaches, given its advocacy for potentially controversial positions. If the initial security measures implemented are insufficient, the platform could be compromised, leading to the theft of user data, disruption of operations, and damage to the movement's reputation. A successful cyberattack could erode user trust, deter potential supporters, and undermine the movement's credibility. The movement may face legal liabilities and financial penalties if user data is compromised. The platform could be used to spread misinformation or propaganda, further damaging the movement's reputation.

##### Early Warning Signs
- The platform experiences a significant increase in suspicious activity, such as login attempts from unusual locations.
- Security alerts indicate potential vulnerabilities in the platform's code or infrastructure.
- The movement receives reports of phishing attacks or other attempts to compromise user accounts.

##### Tripwires
- The penetration test reveals a critical vulnerability that could be easily exploited.
- The platform experiences a successful cyberattack that results in the theft of user data.
- The movement receives a credible threat of a cyberattack from a known source.

##### Response Playbook
- Contain: Immediately shut down the online platform and isolate affected systems.
- Assess: Conduct a thorough forensic investigation to determine the extent of the damage and identify the root cause of the security breach.
- Respond: Implement enhanced security measures, such as multi-factor authentication, intrusion detection systems, and regular security audits. Notify affected users and relevant authorities.


**STOP RULE:** If the platform experiences a major data breach that compromises the personal information of a significant number of users, the project will be cancelled.

---

#### FM7 - The Membership Mirage

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Finance/Operations Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The movement's financial sustainability relies on a steady influx of new members and the retention of existing ones. If the cost of acquiring new members exceeds the projected budget, or if the churn rate is higher than anticipated, the movement's financial resources will be depleted. This could lead to cuts in essential programs, reduced staffing, and a decline in overall effectiveness. The movement may struggle to attract and retain donors if it is perceived as financially unsustainable. A reliance on expensive marketing campaigns could further exacerbate the problem. The movement may be forced to compromise its values or mission in order to attract new members.

##### Early Warning Signs
- The cost per acquisition (CPA) for new members exceeds the budgeted amount by 10%.
- The churn rate for existing members exceeds 5% per month.
- The movement's fundraising efforts fail to meet projected targets.

##### Tripwires
- CPA exceeds budgeted amount by 20%.
- Churn rate exceeds 10% within the first two months.
- Fundraising revenue is 25% below projections after 3 months.

##### Response Playbook
- Contain: Immediately freeze all non-essential marketing and outreach activities.
- Assess: Conduct a thorough analysis of the membership acquisition and retention strategies, identifying the root causes of the cost overruns and high churn rate.
- Respond: Revise the membership acquisition and retention strategies, focusing on more cost-effective methods and improving member engagement.


**STOP RULE:** If, after implementing revised membership acquisition and retention strategies, the movement continues to experience unsustainable membership costs and high churn rates within 6 months, the project will be cancelled or significantly pivoted.

---

#### FM8 - The Technological Time Bomb

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The movement's online platform relies on a specific technology stack. If components of that stack become unsupported, unstable, or vulnerable, the platform's functionality, security, and reliability will be compromised. This could lead to disruptions in service, data breaches, and a loss of user trust. The development team may be forced to spend significant time and resources patching vulnerabilities or migrating to new technologies. The platform may become increasingly difficult to maintain and update. The movement may be unable to adapt to changing technological landscapes.

##### Early Warning Signs
- Key components of the technology stack are nearing end-of-life.
- The technology stack has limited community support or documentation.
- Security alerts indicate unresolved vulnerabilities in the technology stack.

##### Tripwires
- Key components of the technology stack are officially deprecated by their developers.
- Security audit reveals a critical vulnerability in the technology stack that cannot be patched.
- The development team spends more than 20% of its time addressing issues related to the technology stack.

##### Response Playbook
- Contain: Immediately isolate the vulnerable components of the technology stack and implement temporary security measures.
- Assess: Conduct a thorough assessment of the technology stack, identifying alternative technologies and migration strategies.
- Respond: Develop a plan to migrate to a more stable and supported technology stack, prioritizing security and functionality.


**STOP RULE:** If a critical vulnerability in the technology stack cannot be patched or mitigated within 3 months, or if a migration to a more stable technology stack is deemed infeasible, the project will be cancelled.

---

#### FM9 - The Cultural Minefield

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Communications Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The movement aims to be international, requiring its message to resonate across diverse cultures. If translations and adaptations are poorly executed, the message could be misinterpreted, lose its impact, or even cause unintended offense. This could alienate potential supporters, damage the movement's reputation, and hinder its ability to build a global coalition. Cultural misunderstandings could lead to miscommunication, conflict, and a failure to achieve the movement's goals. The movement may be perceived as insensitive, ignorant, or even culturally imperialistic.

##### Early Warning Signs
- Cultural sensitivity reviews reveal significant misunderstandings or offensive language in translated materials.
- The movement receives complaints from individuals or groups about cultural insensitivity.
- The movement's messaging fails to resonate with specific cultural groups.

##### Tripwires
- Cultural sensitivity reviews score below 70% for translated materials.
- The movement receives more than 5 complaints per month about cultural insensitivity.
- Social media engagement with the movement's messaging is significantly lower in certain cultural regions.

##### Response Playbook
- Contain: Immediately halt all communication and outreach activities in the affected cultural regions.
- Assess: Conduct a thorough review of the translated materials and communication strategies, gathering feedback from native speakers and cultural experts.
- Respond: Revise the translated materials and communication strategies to address the cultural sensitivities and ensure the message is accurately and respectfully conveyed.


**STOP RULE:** If, after implementing revised translation and adaptation strategies, the movement continues to experience significant cultural misunderstandings or alienate potential supporters within 6 months, the project will be cancelled or significantly pivoted.
