# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Construction Risk Manager

**Knowledge**: Modular construction, regulatory permitting, site logistics, federal property law

**Why**: Needed to vet the feasibility and risk associated with Phase 1 relocation and Phase 2 modular construction choices against the aggressive timeline.

**What**: Analyze Decision 6 (Phased Construction Methodology) and Decision 9 (Site Recovery Protocol) for logistical and structural feasibility.

**Skills**: Permitting acceleration, structural engineering assessment, logistical planning, risk integration

**Search**: modular construction rapid deployment federal sites, deconstructable luxury building standards

## 1.1 Primary Actions

- IMMEDIATELY REDIRECT REGULATORY POSTURE: Cease planning relying on post-facto authorization (Pioneer's Gauntlet Decision 2, Option 1). Task external counsel to execute Decision 2, Option 2 ('Comprehensive Submission') within 10 days (Deadline: 2026-05-13). No Phase 2 foundations are to be designed or permitted until conditional NTP is secured.
- FORMALLY AMEND SPONSOR AGREEMENT: Execute the contract change linking sponsor release to '60 days of continuous, verified profitability, starting on Day 8 following successful Phase 1 relocation.' This must be signed by the Sponsor Financial Representatives by 2026-05-08.
- ABORT OPAQUE FUNDING: Stop all work related to the 'National Security Surcharge.' Re-prioritize resources to formalize the 'Infrastructure Levy' on ancillary services (Decision 4, Option 1) as the sole mechanism for long-term citizen funding liability transfer.

## 1.2 Secondary Actions

- Initiate structural review of Phase 1 modular design to assess downstream impacts (durability, maintenance costs) on the Phase 2 permanent structure.
- Task the Compliance team to freeze all planning on non-fungible asset liquidation (Decision 14, Option 2) and sign off on absolute adherence to Option 1 (Bank Consortium only) by 2026-05-15 to preempt AML seizure risk.
- Begin detailed logistics planning for the container relocation, establishing a hard timeline to confirm the actual operational blackout duration, providing empirical data to refine the 60-day profitability trigger.

## 1.3 Follow Up Consultation

The next consultation must focus exclusively on the feasibility and timeline of the revised Regulatory Engagement Posture (Decision 2, Option 2). I need to see the initial GSA/DOI strategy paper drafted by external counsel, confirming if a viable, non-violative path forward exists. Secondarily, we must review the draft amendment to the Sponsor Commitment Structuring contract to ensure the financial liability shift is airtight against the newly confirmed relocation timeline.

## 1.4.A Issue - Existential Regulatory Risk: Reliance on Post-Facto Authorization

The chosen strategy ('Pioneer's Gauntlet') critically hinges on Decision 2: initiating parallel 'fast-track' construction based on 'emergency permitting precedents' and expecting high-level diplomacy to secure post-facto authorization for the demolition and repurposing of the White House East Wing. This is an extinction-level strategy for any construction project touching federal landmarks. Federal property law, particularly concerning nationally significant structures, dictates that irreversible irreversible physical changes preceding authorization are not shortcuts; they are liabilities waiting for a change in political climate to trigger catastrophic injunctions and mandatory remediation at your cost. The plan acknowledges this as the 'paramount risk lever,' which means it is the foremost point of failure. Relying on diplomacy to clean up a direct violation of property law is incompetence.

### 1.4.B Tags

- Regulatory Failure
- Federal Property Law
- Existential Risk
- Permitting Acceleration

### 1.4.C Mitigation

Immediately shift the Regulatory Engagement Posture from Option 1 (Fast-Track/Post-Facto) to Option 2 (Comprehensive Pre-Submission). Immediately contract with specialized D.C. Federal Property Law counsel (as suggested in 'Missing Information') to execute a formal, complete submission package to GSA/DOI/Federal Reserve concurrently with the mobilization of Phase 1 physical assets. The *only* on-the-ground action allowed on the site structure itself (beyond initial clearing) must cease until a conditional Notice-to-Proceed (NTP) or formal legal acceptance document is issued for the land use change. This trades 'speed' for 'survival.'

### 1.4.D Consequence

A single, well-placed lawsuit or adverse executive reorganization will trigger an immediate, permanent injunction, halting all work, seizing the containerized assets, and defaulting the $90M remediation fund obligation to cover site return costs, likely leading to project bankruptcy.

### 1.4.E Root Cause

Empty

## 1.5.A Issue - Flawed Operational/Financial Trigger Coupling in Phase 1

The plan dictates linking 75% of sponsor funding (Decision 1) to 90 days of continuous profitability, but correctly assumes an unavoidable 7-day operational blackout for logistics/relocation (Decision 6). The pre-project assessment correctly identified the need to revise this to a 60-day trigger *after* relocation, but the strategic decision framework explicitly states the sponsor funding is tied to 90 days of operation. If this financial milestone isn't rigidly agreed upon NOW, the sponsors will enforce the original 90-day requirement, which is now impossible due to the assumed relocation timeline, leading to immediate cash flow stoppage. Furthermore, tying funding so aggressively to operational profit of a temporary container venue diverts focus from engineering the *permanent* structure (Phase 2), which is where real, long-term viability lies. This is prioritizing operational noise over structural foundation.

### 1.5.B Tags

- Financial Dependency
- Logistical Conflict
- Focus Misalignment
- Modular Transition Risk

### 1.5.C Mitigation

Formally execute the negotiated contract amendment (as noted in 'pre-project assessment') with the sponsors *this week*. The milestone must be explicitly defined as '60 days of verified profitability, with the start date commencing on Day 8 post-relocation event.' Crucially, redirect Project Management focus immediately: divert 50% of Phase 1 engineering resources (post-container procurement) to Phase 2 foundational structural engineering assessments. We need to know if the modularity of Phase 1 compromises the structural integrity or long-term durability of Phase 2, which is not yet fully assessed in the documents.

### 1.5.D Consequence

Sponsor tranche funds are withheld in week 10 due to failure to meet the 90-day operational requirement, leading to a multi-month stop-work order just as Phase 2 procurement needs to accelerate, permanently damaging the timeline.

### 1.5.E Root Cause

Empty

## 1.6.A Issue - Unsustainable and Politically Toxic Long-Term Funding Mechanism

The chosen Post-Gambling Citizen Funding Capture Mechanism (Decision 5, Option 3: 'floating, variable National Security Surcharge' on federal transactions) is the political equivalent of lighting a match in a powder keg. This creates an explicit, traceable link between American taxpayer utility/transaction fees and subsidizing an *exclusive* international gambling den operating on federal land. This is not a 'surcharge'; it's a direct, visible tax subsidy for VIP entertainment. This leverage point will be seized by any legislative opponent to legally revoke the operating license almost immediately upon Phase 1 opening, nullifying the justification for the entire project (Decision 4). The recommendation in SWOT contradicts the chosen strategy, highlighting internal dissonance.

### 1.6.B Tags

- Political Liability
- Funding Fragility
- Public Relations Catastrophe
- Federal Subsidy Risk

### 1.6.C Mitigation

Immediately halt all further planning on Decision 5, Option 3. Revert the official long-term pathway to Decision 4, Option 1 ('Infrastructure Levy' on ancillary services only). This requires a complete rework of the monetization strategy, consulting immediately with D.C. lobbyists who specialize in creating dedicated, non-tax-related revenue streams (e.g., special assessment districts or specific hospitality fees decoupled from general federal transactions). Provide Q3 financial projections showing the casino *can* operate solely on projected 60/40 revenue plus the ancillary levy, isolating the operational budget from direct federal appropriation as much as possible.

### 1.6.D Consequence

Public and Congressional discovery of the opaque federal surcharge will generate immediate legislative action forcing a full audit and license revocation within the first six months of operation, resulting in the failure of the sustainability goal.

### 1.6.E Root Cause

Empty

---

# 2 Expert: International Compliance Strategist

**Knowledge**: AML/KYC regulations, sovereign asset transfer, banking consortia, OECD compliance

**Why**: To address the high risk associated with accepting non-fungible assets (Decision 14) and the implementation of the opaque citizen surcharge (Decision 5).

**What**: Audit protocols for Decision 14 (Asset Liquidation) against current international AML standards and FATF recommendations.

**Skills**: Financial crime compliance, treaty negotiation, international banking law, risk assurance

**Search**: AML compliance sovereign asset collateral, international gaming regulatory oversight, high-net-worth transaction scrutiny

## 2.1 Primary Actions

- IMMEDIATE ACTION: Halt all mobilization activities related to Phase 2 permanent construction foundations. Concentrate all resources on mitigating the existential regulatory risk by formally adopting and executing the comprehensive regulatory submission strategy (Decision 2, Option 2), aiming for a conditional Notice-to-Proceed within 30 days.
- IMMEDIATE ACTION: Formally terminate any internal or external planning involving non-fungible asset tracking or collateral. Implement Decision 14, Option 1: Restrict all patron markers exclusively to currency settled through the pre-approved International Banking Consortium.
- IMMEDIATE ACTION: Re-task the finance team to suspend all work on the 'National Security Surcharge' (Decision 5, Option 3). Pivot resources to fully engineer Decision 4, Option 1 (Ancillary Services Levy) as the sole long-term monetization fallback position.

## 2.2 Secondary Actions

- Initiate a formal, documented review of the Phase 1 profitability trigger (Decision 1). The required NOI calculation must be re-baselined to account for the operational disruption caused by the planned Phase 1 relocation lockdown, ensuring the 60-day window is realistically achievable.
- Develop a detailed timeline and cost analysis for relocating the Phase 1 container structure (Decision 6, Option 1), independent of the current operational schedule, as the current reliance on seamless transition is highly suspect.
- Task the project architect with developing a 'de-coupling' plan for the 2.5 MW microgrid (Decision 13) to ensure it can be rapidly disconnected and sold/repurposed should a regulatory injunction halt the project before Phase 2 commencement.

## 2.3 Follow Up Consultation

The next consultation must exclusively focus on the findings from the external counsel regarding **Decision 2, Option 2**. We need a quantitative risk assessment (probability of injunction within 90 days) based on the *actual* legal submission package, the timeline for securing conditional GSA approval, and confirmation of the banking consortia confirming acceptance of the AML posture defined by Decision 14, Option 1. We must confirm we have moved from dangerous posturing to a defensible legal foundation.

## 2.4.A Issue - Existential Regulatory Path Dependence on Pure Political Will

The primary strategy ('Pioneer's Gauntlet') critically depends on 'Initiate parallel 'fast-track' construction...simultaneously launching high-level diplomatic negotiations to secure post-facto authorization for the land use change' (Decision 2). Given the site is the White House East Wing—a property of immense sovereign and historical significance—relying on *post-facto* authorization for irreversible structural change (demolition) is an act of willful legal suicide. No competent international counsel would rate this higher than a 5% chance of success against a determined judicial or legislative challenge. This is not mere risk optimization; it is foundational strategic malpractice.

### 2.4.B Tags

- RegulatoryFailure
- ExistentialRisk
- SovereignAssetMismanagement

### 2.4.C Mitigation

Immediately elevate Decision 2, Option 2 ('Prioritize comprehensive submission and legal vetting') to parallel priority *one*. Divert 50% of the legal resources currently focused on fast-track diplomacy to drafting the definitive, GSA/DOI/Congressional submission package. The confidence rating of the $90M remediation fund (Decision 10) is irrelevant if a full judicial injunction halts Phase 1 within 30 days. Consult with external counsel specializing in historical preservation takings and federal property transfer treaties immediately. The mitigation plan must deliver a comprehensive legal filing package within 14 days, not just preliminary drafts.

### 2.4.D Consequence

A swift, comprehensive judicial or legislative injunction halting all physical activity within 60 days, rendering the $90M remediation fund useless as the site will be locked down, leading to the immediate clawback of sponsor funds and catastrophic reputational failure.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - AML/KYC Abrogation through High-Risk Asset Liquidation Protocol

The plan implicitly favors Decision 14, Option 2 ('Develop a specialized, auditable internal ledger system capable of tracking ownership and value transfer of unique, non-liquid commodities') to maximize revenue from the 60/40 high-roller split. This is a direct invitation for international financial crime monitors (FATF, OFAC, EU Regulators) to designate the facility as a high-risk shell or money laundering conduit. Accepting non-fungible collateral (art, mineral rights, sovereign 'favors') bypasses core principles of the jurisdiction's AML framework and international treaty compliance. This is incompatible with any banking consortia involvement.

### 2.5.B Tags

- AMLFailure
- FinancialCrimeRisk
- BankingSanctionExposure

### 2.5.C Mitigation

Immediately and publicly adopt Decision 14, Option 1 ('Restrict all 'markers' and high-value asset exchanges to fully fungible, major global currencies settled exclusively through a pre-approved consortium of neutral international banks'). A specialized internal ledger for national assets is an insurance nightmare and a compliance death sentence. Consult immediately with an AML specialist accredited by ACAMS and legal experts in US/EU extraterritorial financial sanctions law. All future contracts must mandate bank settlement only, regardless of the immediate revenue opportunity foregone.

### 2.5.D Consequence

If high-value non-fungible assets are accepted, the facility will face immediate de-risking by global correspondent banks, leading to loss of banking access, freezing of sponsor funds, and potential designation under international financial crime watchlists.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Fundamentally Flawed Long-Term Solvency Mechanism

The chosen Post-Gambling Citizen Funding Capture Mechanism is Decision 5, Option 3: a 'floating, variable 'National Security Surcharge' added to all other federal transaction fees, calibrated indirectly by monthly operational deficits.' This is politically toxic and structurally unsustainable. It links daily political funding to the unpredictable losses of a private gambling operation on federal land. It guarantees intense legislative scrutiny and guaranteed repeal once the initial political momentum fades. This undermines the stability sought by the Citizen Monetization Pathway (Decision 4).

### 2.6.B Tags

- SolvencyRisk
- PoliticalFragility
- ConflictingStrategy

### 2.6.C Mitigation

Halt all drafting related to Option 3 immediately. Reallocate resources to fully develop Decision 4, Option 1 ('Infrastructure Levy on ancillary services'). This leverages existing taxable consumption events (hospitality, non-gambling services) rather than a politically naked surcharge on federal fees. Consult with experts in OECD value-added tax structures and state-level revenue capture mechanisms. The goal must be to prove the casino *can* operate without federal subsidy if necessary, not to build the subsidy mechanism first.

### 2.6.D Consequence

Guaranteed legislative repeal of the surcharge within 12-18 months of operation, leading to an immediate, unbridgeable operational funding gap and forcing the premature closure or massive downscaling of the Phase 2 structure.

### 2.6.E Root Cause

Empty

---

# The following experts did not provide feedback:

# 3 Expert: Public Affairs / Crisis Communications Lead

**Knowledge**: Government land use controversy, high-profile infrastructure backlash, legislative lobbying

**Why**: The project involves demolishing part of the White House, requiring expert management of the political and public backlash identified in the Threats section of the SWOT.

**What**: Develop a crisis communication playbook addressing immediate public reaction to the East Wing demolition and the nature of the private gambling establishment.

**Skills**: Stakeholder mapping, legislative advocacy, political risk communication, narrative control

**Search**: managing public backlash federal landmark demolition, political perception crypto casino

# 4 Expert: Utility Infrastructure Planner

**Knowledge**: Microgrid implementation, high-density temporary power solutions, federal utility agreements

**Why**: Essential for validating the feasibility and cost impact of the dedicated 2.5 MW microgrid required for Phase 1 operations (Decision 13).

**What**: Evaluate the cost estimates and siting constraints for the dedicated 2.5 MW microgrid specified in required resources.

**Skills**: Energy grid integration, contract negotiation utilities, temporary power procurement, latency management

**Search**: deploying microgrid on historic federal site, temporary 2.5MW power solutions logistics

# 5 Expert: Diplomatic Protocol Advisor

**Knowledge**: White House event security clearance, Head of State access protocols, bilateral negotiation logistics

**Why**: Crucial for operationalizing Decision 3 (Guest Profile) and Decision 11 (Access Control) within the highly sensitive White House perimeter context.

**What**: Define the technical overlap and security buffer required between the 40% diplomatic contingent and the 60% commercial patrons.

**Skills**: Executive protection liaison, PII data security, diplomatic accreditation, classified facility access standards

**Search**: White House visitor access segmentation, diplomatic vs commercial patron separation

# 6 Expert: Federal Property & Land Use Attorney

**Knowledge**: GSA property transfer, Historic preservation law, D.C. eminent domain, executive authority precedent

**Why**: This expert is needed to assess the near-existential risk associated with relying on post-facto authorization for White House land use (Decision 2).

**What**: Provide a detailed, risk-weighted analysis of the viability of the alternative comprehensive legal submission path (Decision 2, Option 2).

**Skills**: Administrative law litigation, property law jurisprudence, federal agency negotiation, injunction defense

**Search**: GSA land transfer authorization precedent, legal challenge to federal landmark alteration

# 7 Expert: Monetization Pathway Modeler

**Knowledge**: Public finance, infrastructure levy structuring, shadow taxation analysis, long-term fiscal modeling

**Why**: To quantify the robustness of the proposed long-term citizen funding model (Decision 4) versus the rejected opaque surcharge (Decision 5).

**What**: Model the required infrastructure levy tax base/transaction volume necessary to reliably generate the projected $50M monthly operating coverage.

**Skills**: Fiscal impact analysis, public financing mechanisms, tax structure feasibility, long-term revenue forecasting

**Search**: modeling ancillary service infrastructure levy, viability shadow tax mechanisms

# 8 Expert: Sponsor Relationship Manager (High-Cap Milestones)

**Knowledge**: Front-loaded investment tranches, milestone renegotiation, shareholder expectation management

**Why**: Required to manage the relationship stress caused by revising the profitability trigger timeline (Decision 1) due to the planned relocation blackout.

**What**: Draft the internal justification brief for sponsors explaining the shift from 90 to 60 days post-relocation for milestone payment unlock.

**Skills**: Investment contract management, performance clause arbitration, capital allocation strategy, investor relations

**Search**: renegotiating sponsor milestone triggers construction project, managing front-loaded capital withdrawal