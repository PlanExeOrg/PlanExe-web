### 1. Secure formal confirmation of the strategic path chosen: 'The Pioneer's Gambit', confirming pivot from mandatory patronage to optional access (Risk 3 mitigation) and confirming VC funding structure (revolving credit preference).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Official 'Pioneer's Gambit' Confirmation Memo
- Revised Clientele Engagement Model Charter (Strategic Choice 2)
- Revised Sponsor Funding Term Sheet Directive (Preferring Credit over Equity)

**Dependencies:**

- Strategic Decisions finalized (scenarios.md review)
- Initial $600M Capital commitment secured (Decision 1)

### 2. Project Manager drafts initial Terms of Reference (ToR) for all four defined governance bodies (PEB, OMT, LRAG, REAP), incorporating roles derived from strategic decisions and risk mitigations (e.g., LRAG's focus on Executive Order risk, REAP's focus on $30M philanthropy).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1 - 2

**Key Outputs/Deliverables:**

- Draft ToR v0.1 for PEB, OMT, LRAG, REAP
- Draft Membership Roster for all Bodies

**Dependencies:**

- Confirmation of Strategic Path (Step 1)
- Defined Governance Bodies structure (governance-phase2-bodies.json context)

### 3. Project Sponsor and CFO review and approve the draft ToRs and confirm the final, voting membership list for the Project Executive Board (PEB).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final PEB ToR & Membership List
- PEB Authority Matrix signed

**Dependencies:**

- Draft ToR v0.1 (Step 2)

### 4. Project Sponsor formally appoints the Chair of the PEB (Internal Executive) and the Project Director (CEO).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal Appointment Letters for PEB Chair and CEO

**Dependencies:**

- Final PEB Membership List (Step 3)

### 5. CEO (now leading setup efforts) drafts and circulates ToRs for the subordinate bodies (OMT, LRAG, REAP) for initial review by nominated leaders.

**Responsible Body/Role:** Chief Executive Officer (CEO)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ToR v0.2 for OMT, LRAG, REAP distributed to nominated members

**Dependencies:**

- PEB setup finalized (Step 4)
- PEB approval of governance structure adoption

### 6. Conduct consolidated review session with nominated OMT, LRAG, and REAP Chairs to finalize their respective ToRs, membership appointments, and decision mechanisms.

**Responsible Body/Role:** CEO & Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized ToRs for OMT, LRAG, REAP
- Official confirmation of all governance body members in place

**Dependencies:**

- Circulated Draft ToRs (Step 5)

### 7. Project Executive Board (PEB) holds its inaugural meeting to formally ratify all governance body ToRs and decision thresholds (e.g., $50M spending limit for OMT).

**Responsible Body/Role:** Project Executive Board (PEB)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PEB Meeting Minutes: Governance Approval
- Ratified Governance Structure Documentation Signed

**Dependencies:**

- Finalized ToRs for all bodies (Step 6)

### 8. LRAG initiates immediate focus: Commission external counsel for gap analysis between Executive Order jurisdiction and required legislative/treaty authorization (Risk 1 mitigation).

**Responsible Body/Role:** Legal and Regulatory Assurance Group (LRAG)

**Suggested Timeframe:** Project Week 5 - 8

**Key Outputs/Deliverables:**

- External Legal Counsel Contract Signed (utilizing 15% allocation)
- 30-Day jurisdictional gap analysis commenced

**Dependencies:**

- LRAG formally constituted (Step 7)
- Budget allocation approved by PEB

### 9. OMT performs the critical structural risk mitigation: Selects and contracts vendor for full-depth geotechnical survey (Decision 10, Choice 2) to inform foundation remediation planning.

**Responsible Body/Role:** Operational Management Team (OMT)

**Suggested Timeframe:** Project Week 5 - 9

**Key Outputs/Deliverables:**

- Geotechnical Survey Scope of Work Finalized
- Vendor Contract Executed

**Dependencies:**

- OMT officially established (Step 7)
- Resource allocation approval from PEB

### 10. REAP organizes its inaugural session, finalizing the charter for monitoring the $30M Reputation Defense budget and establishing the initial tracking metrics for public sentiment and philanthropic deployment (Decision 6).

**Responsible Body/Role:** Reputational and Ethical Assurance Panel (REAP)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- REAP Operating Charter Issued
- Philanthropic Allocation Tracking Framework Defined

**Dependencies:**

- REAP formally constituted (Step 7)

### 11. OMT executes Phase 1 kickoff: Procure and secure shipping containers and begin installation/utility integration necessary for immediate, limited revenue generation (aligned with 18:00-04:00 core hours).

**Responsible Body/Role:** Operational Management Team (OMT)

**Suggested Timeframe:** Project Week 7 - 12 (Duration ~6 weeks)

**Key Outputs/Deliverables:**

- Phase 1 Container Site Prepared
- Internal Security Hardening protocols fully implemented in containers (Risk 4 mitigation)

**Dependencies:**

- Geotechnical Survey mobilization (Step 9)
- Approval to proceed with site preparation granted by PEB

### 12. Hold concurrent first official meetings for OMT, LRAG, and REAP to review progress on foundational setup actions and confirm staffing model deployment (e.g., OMT approving 18:00-04:00 schedule implementation).

**Responsible Body/Role:** CEO / Committee Chairs

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes documenting initial operational directives and risk status reviews for all subordinate bodies.

**Dependencies:**

- Phase 1 setup underway (Step 11)
- LRAG review of initial legal findings (Step 8)