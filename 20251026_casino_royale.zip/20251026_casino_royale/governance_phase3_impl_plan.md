### 1. Project Sponsor formally designates the Project Manager/Director to lead the governance setup and execution planning for Phase 1 readiness.

**Responsible Body/Role:** Project Sponsor Lead

**Suggested Timeframe:** Project Week 1 (Day 1)

**Key Outputs/Deliverables:**

- Governance Setup Mandate Document
- Designation of Project Director/Manager (Chair of OMB)

**Dependencies:**

- Project Kickoff and Charter Approval

### 2. Project Director (Designated OMB Chair) drafts initial Terms of Reference (ToR) for the Operational Management Board (OMB) based on defined responsibilities and membership.

**Responsible Body/Role:** Project Director / Program Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft OMB ToR v0.1
- Confirmed OMB Proposed Membership List

**Dependencies:**

- Designation of Project Director/Manager

### 3. Appoint and confirm the Project Sponsor Lead (Chair of PESC) and the CFO/Head of Finance (MBR of PESC) to ensure PESC leadership is established for strategic oversight.

**Responsible Body/Role:** Project Sponsor Lead

**Suggested Timeframe:** Project Week 1 - Week 2

**Key Outputs/Deliverables:**

- Confirmed PESC Chair and Finance Lead Appointments

**Dependencies:**

- Project Kickoff

### 4. Project Sponsor Lead (Chair of PESC) formally appoints the Lead for Regulatory Strategy (External Counsel) and the Independent Member for the PESC.

**Responsible Body/Role:** Project Sponsor Lead

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PESC Leadership Appointment Confirmation
- Engagement Letter for External Legal Counsel (Regulatory Strategy)

**Dependencies:**

- Confirmed PESC Chair and Finance Lead Appointments

### 5. The Project Manager, in consultation with Appointed Regulatory Lead, drafts the initial Terms of Reference (ToR) for the Project Executive Steering Committee (PESC).

**Responsible Body/Role:** Project Director / Program Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PESC ToR v0.1
- Recommended PESC Charter

**Dependencies:**

- Appointed Lead for Regulatory Strategy

### 6. PESC leadership reviews and formally approves the PESC ToR and Charter, establishing the highest governance body.

**Responsible Body/Role:** Project Executive Steering Committee (PESC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Project Charter (incorporating PESC Structure)
- PESC Official Kick-off Meeting Scheduled

**Dependencies:**

- Draft PESC ToR v0.1

### 7. PESC Chair mandates the establishment of the Compliance, Audit, and Regulatory Assurance Panel (CARAP), appoints its Chair (CCO) and Chief Security Officer, and approves the initial scope for the External Forensic Auditor.

**Responsible Body/Role:** Project Executive Steering Committee (PESC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- CARAP Mandate Document
- Appointment confirmation for CCO (CARAP Chair)

**Dependencies:**

- Approved Project Charter (incorporating PESC Structure)

### 8. CARAP Chair commissions the External Forensic Audit firm and executes engagement terms focusing on AML compliance criteria (Decision 14) and Contingency Fund segregation audit protocol.

**Responsible Body/Role:** Compliance, Audit, and Regulatory Assurance Panel (CARAP)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Executed Forensic Audit Contract
- Published Criteria for Asset Liquidation Compliance

**Dependencies:**

- CARAP Mandate Document
- Regulatory Engagement Posture Confirmed (Fast-Track Authorization Initiation)

### 9. OMB leadership finalizes baseline delivery schedules for Phase 1 containers and the 2.5 MW microgrid, addressing utility load management assumptions.

**Responsible Body/Role:** Operational Management Board (OMB)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Finalized Phase 1 Site Mobilization Schedule
- Contract for 2.5 MW Microgrid Finalized

**Dependencies:**

- Draft OMB ToR v0.1 Approved
- Resource Allocation Confirmed ($600M initial drawdown)

### 10. OMB formalizes operational security protocols, including the Client Access Control Matrix (CACM), and finalizes required technology procurements for Tier 2 Commercial Access (T2CA) vetting.

**Responsible Body/Role:** Operational Management Board (OMB)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved CACM Document
- T2CA Vetting Hardware Procurement Complete

**Dependencies:**

- Finalized Phase 1 Site Mobilization Schedule
- Resource Allocation Confirmed (Security Hardware)

### 11. PESC holds its inaugural meeting. Key agenda items: Ratify all established governance bodies (OMB, CARAP), officially mandate the 'Pioneer's Gauntlet' strategy, and approve the $90M Contingency Fund segregation instruction.

**Responsible Body/Role:** Project Executive Steering Committee (PESC)

**Suggested Timeframe:** End of Project Week 6

**Key Outputs/Deliverables:**

- Inaugural PESC Meeting Minutes (Ratifying Governance Structure)
- Official Mandate for 'Pioneer's Gauntlet' Strategy
- Instruction to Escrow $90 Million USD for Contingency

**Dependencies:**

- PESC ToR Approval
- Initial CARAP and OMB setups complete
- External Counsel viability report on Regulatory Posture (Phase 1 Legal Strategy)

### 12. OMB holds its inaugural meeting, focusing on locking down the Phase 1 operational launch sequence, revising the profitability trigger timeline to account for the 7-day blackout, and confirming the logistics team for the relocation plan.

**Responsible Body/Role:** Operational Management Board (OMB)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Revised Sponsor Profitability Milestone Confirmation (Accounting for 7-day blackout)
- Locked-in Phase 1 Operational Readiness Checklist

**Dependencies:**

- Inaugural PESC Meeting Minutes
- Finalized Phase 1 Site Mobilization Schedule

### 13. CARAP formally publishes the public-facing risk dashboard detailing the segregated $90M Contingency Fund and receives the first report detailing compliance adherence for Political Reversal Risk (Decision 10).

**Responsible Body/Role:** Compliance, Audit, and Regulatory Assurance Panel (CARAP)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Public Contingency Fund Risk Dashboard v1.0
- Initial AML/Security Compliance Posture Report

**Dependencies:**

- Instruction to Escrow $90 Million USD for Contingency
- Executed Forensic Audit Contract

### 14. OMB mobilizes Phase 1 construction teams utilizing the secured 2.5 MW microgrid; commence T2CA vetting trials using non-patron personnel.

**Responsible Body/Role:** Operational Management Board (OMB)

**Suggested Timeframe:** Project Week 9 onwards

**Key Outputs/Deliverables:**

- Phase 1 Container Casino Physical Construction Commencement
- T2CA Vetting System Stress Test Results

**Dependencies:**

- Contract for 2.5 MW Microgrid Finalized
- T2CA Vetting Hardware Procurement Complete

### 15. PESC oversees/approves the $5M allocation for the Diplomatic Design Integration Team (Decision 8) and ratifies the framework for the Long-Term Citizen Monetization Pathway (Infrastructure Levy concept).

**Responsible Body/Role:** Project Executive Steering Committee (PESC)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approval of $5M Stakeholder Integration Budget
- Formal Endorsement of Citizen Levy Framework (Pioneer's Gauntlet Alignment)

**Dependencies:**

- Inaugural PESC Meeting Minutes
- External Counsel viability report on Regulatory Posture

### 16. Final mobilization and testing of Phase 1 ensures operational readiness for immediate launch post-relocation window, setting the stage for the profitability trigger countdown.

**Responsible Body/Role:** Operational Management Board (OMB)

**Suggested Timeframe:** Project Week 12 (Prior to Relocation Blackout)

**Key Outputs/Deliverables:**

- Phase 1 Final Sign-off for Relocation
- Patron Load Testing Report (Simulated 999 Guests)

**Dependencies:**

- Phase 1 Site Mobilization Schedule Adherence
- T2CA Vetting System Stress Test Results