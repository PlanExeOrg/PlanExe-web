### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Manager drafts initial Terms of Reference (ToR) for the Security Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Security Advisory Group ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Circulate Draft SteerCo ToR for review by nominated members (CEO, CFO, CLO, External Advisors).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 5. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members (CLO, Compliance Officer, Independent Ethics Advisor, Gaming Commission Rep, Responsible Gambling Org Rep).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 6. Circulate Draft Security Advisory Group ToR for review by nominated members (Chief Security Officer, Independent Security Expert, Law Enforcement Rep, Intelligence Agency Rep, Casino Security Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Security Advisory Group ToR v0.1
- Nominated Members List Available

### 7. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 8. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 9. Project Manager finalizes the Security Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Security Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary

### 10. CEO formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Chief Executive Officer (CEO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 11. Chief Legal Officer (CLO) formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Legal Officer (CLO)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 12. Chief Security Officer formally appoints the Chair of the Security Advisory Group.

**Responsible Body/Role:** Chief Security Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Security Advisory Group ToR v1.0

### 13. Project Manager schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 14. Compliance Officer schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Compliance Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 15. Chief Security Officer schedules the initial Security Advisory Group kick-off meeting.

**Responsible Body/Role:** Chief Security Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email
- Final Security Advisory Group ToR v1.0

### 16. Hold initial Project Steering Committee kick-off meeting. Review ToR, approve initial project plan, and assign initial tasks.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 17. Hold initial Ethics & Compliance Committee kick-off meeting. Review ToR, develop ethical guidelines, and establish compliance monitoring processes.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Ethical Guidelines Draft
- Compliance Monitoring Process Draft

**Dependencies:**

- Meeting Invitation
- Final Ethics & Compliance Committee ToR v1.0

### 18. Hold initial Security Advisory Group kick-off meeting. Review ToR, conduct initial security risk assessment, and develop security protocols.

**Responsible Body/Role:** Security Advisory Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Security Risk Assessment
- Draft Security Protocols

**Dependencies:**

- Meeting Invitation
- Final Security Advisory Group ToR v1.0

### 19. Hold PMO Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Project Steering Committee established