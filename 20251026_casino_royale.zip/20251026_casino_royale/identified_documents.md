
## Documents to Create

### 1. Project Charter: World Leader Casino & East Wing Conversion

**ID:** e5493fc3-e8e9-48d8-91c0-c61154110c83

**Description:** Definitive document outlining project scope, objectives, high-level budget ($600M sponsor target), success criteria (999 guest capacity operation), principal constraints (federal land, executive order jurisdiction), and identified primary stakeholders. Must incorporate chosen 'Pioneer's Gambit' strategic path.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Secondary Template:** High-Risk Infrastructure Project Standard

**Steps:**

- Incorporate agreed strategic decisions (especially jurisdiction and clientele model pivots).
- Finalize measurable success criteria based on documented assumptions (e.g., Phase 1 timeline, funding trigger margin).
- Obtain sign-off from Oversight Committee and primary VC representatives.

**Approval Authorities:** Project Oversight Committee, Lead International VC Representative

### 2. Initial High-Level Risk and Mitigation Response Plan (Based on Expert Review)

**ID:** 73d165e4-4bca-4eaa-9c47-20d06b4926b5

**Description:** A foundational risk register that prioritizes and documents the responses to the eight identified critical risks, focusing specifically on the high-impact items (Regulatory Collapse, Subsurface Paralysis, Diplomatic Backlash). Must reflect recommended pivots (e.g., optional patronage, 18:00-04:00 operations).

**Responsible Role Type:** Chief Strategy Officer

**Primary Template:** Risk Register Template (High Complexity)

**Secondary Template:** Expert Mitigation Integration Report

**Steps:**

- Integrate documented risks (R1-R8) and corresponding mitigation strategies from expert reviews.
- Assign owners and initial timelines for critical mitigation efforts (e.g., Legal Task Force initiation, Geotechnical Survey prioritization).
- Establish initial risk budget allocations (e.g., 15% for Legal, $30M for Reputation Defense).

**Approval Authorities:** Chief Risk Officer, Project Oversight Committee

### 3. Sponsor Acquisition & Dilution Control Framework (SA-DCF)

**ID:** a8bef511-c565-46d1-aec5-ac17b3411da3

**Description:** Framework detailing the financial structure for the initial $600M. Must clearly articulate the mandated structure as a revolving line of credit (not equity trading) to cap VC dilution at 30%, fulfilling the sovereign control mandate and mitigating Risk 6. Includes template documentation for binding agreements.

**Responsible Role Type:** Geopolitical Sponsorship & Capitalization Manager

**Primary Template:** International Project Finance Term Sheet Template

**Secondary Template:** Revolving Credit Facility Agreement Draft

**Steps:**

- Develop the detailed structure to quantify the implications of the 30% VC equity cap.
- Draft key clauses for the financing instrument ensuring repayment terms align with Decision 8 (Profitability/Timeline Triggers).
- Review draft framework with Chief Legal Counsel for legal durability.

**Approval Authorities:** CFO, Chief Political & Regulatory Strategist

### 4. Phase 1 Operational Readiness & Hardening Protocol

**ID:** b41d24ff-43b0-44be-b4ae-dfe0f812103e

**Description:** Protocol governing the rapid deployment and security hardening of the temporary container casino (Decision 9). Must detail the adapted 18:00-04:00 operational schedule (Decision 11) and the required SCIF/redundancy checklist for temporary facilities, ensuring quality control for immediate revenue seeding.

**Responsible Role Type:** Multi-Phase Construction & Infrastructure Lead

**Primary Template:** Temporary Facility Deployment Checklist

**Secondary Template:** SCIF Compliance Standard (Interim)

**Steps:**

- Define required security hardening specifications (informed by Security Architect).
- Integrate the 18:00-04:00 staffing schedule structure into initial labor contracts.
- Map utility hookup sequence necessary for rapid commissioning within the 4-month timeline.

**Approval Authorities:** Integrated Security & Perimeter Architect, COO

### 5. Jurisdiction Legality Pathway Strategy (J-LPS)

**ID:** c1a57681-59ee-4dfd-b576-d79b98f2e3c1

**Description:** The core strategy document replacing the reliance on the Executive Order (Risk 1). This outlines the detailed sequencing, resource allocation (15% budget), and timeline dependency (T+9 months) for securing either explicit legislative authorization or a ratified international compact necessary to legitimize operations.

**Responsible Role Type:** Chief Political & Regulatory Strategist

**Primary Template:** Legislative Strategy Roadmap

**Secondary Template:** International Treaty Negotiation Framework

**Steps:**

- Identify the specific required legislative acts or target nations for bilateral compact negotiations.
- Detail resource allocation plan for the 15% legal/lobbying budget contingency.
- Establish clear, non-negotiable go/no-go milestones based on legal progress (90-day review points).

**Approval Authorities:** Project Oversight Committee, General Counsel (newly defined responsibility)

### 6. Clientele Engagement Pivot Plan (CEPP)

**ID:** bbf0b8be-5285-4069-b989-ce3bdb40c81c

**Description:** Defines the operational shift from mandatory patronage to optional, invitation-only, high-end hospitality focusing on securing the venue as an exclusive secure meeting annex ('Diplomatic Gaming/Arbitration Hub' opportunity). Must align staffing needs with new service profile.

**Responsible Role Type:** Elite Hospitality & Clientele Director

**Primary Template:** Strategic Pivot Implementation Plan

**Secondary Template:** High-Net-Worth Client Experience Mapping

**Steps:**

- Redefine service standards required for invitation-only clientele based on hospitality sourcing expertise.
- Define metrics for success based on optional utilization rather than coerced attendance.
- Liaise with Security Architect to incorporate secure meeting annex requirements into Phase 1 facility design.

**Approval Authorities:** Chief Strategy Officer, Integrated Security & Perimeter Architect

### 7. Geotechnical Survey & Foundation Remediation Contingency Plan

**ID:** ee12dcbc-eb65-482d-b0de-e6c130f08f75

**Description:** A plan detailing the immediate commissioning of the full-depth geotechnical survey (Decision 10, Choice 2) and a pre-funded contingency buffer for necessary deep-pile remediation. Must establish the 6-month foundation sign-off dependency (Missing Assumption 2) before superstructure construction permits are issued.

**Responsible Role Type:** Multi-Phase Construction & Infrastructure Lead

**Primary Template:** Geotechnical Investigation Scoping Document

**Secondary Template:** Contingency Fund Utilization Protocol

**Steps:**

- Draft the Request for Proposal (RFP) for the full-depth survey, prioritizing subsurface conditions over cost optimization.
- Allocate a budget reserve (estimated 20-35% of structural cost) explicitly for remediation.
- Integrate the mandatory 6-month completion dependency into the master project schedule.

**Approval Authorities:** Chief Engineer, CFO

### 8. Initial Stakeholder Communication Strategy

**ID:** d7a508d6-bcd8-45a8-b00a-69dea31b7472

**Description:** Defines cadence and content for internal alignment (VCs, internal security) and tailored external engagement (Diplomats, Congress). Details daily/weekly reporting structures aligned with location needs and addresses the shift to optional patronage.

**Responsible Role Type:** Reputation & Political Shield Officer

**Primary Template:** Internal and External Communications Matrix

**Secondary Template:** Stakeholder Engagement Plan (Complex Infrastructure)

**Steps:**

- Develop tailored reporting formats for the three key stakeholder groups identified (VCs, Security Agencies, Diplomatic Corps).
- Schedule the first internal alignment meeting addressing the legal pivot and clientele strategy shift.
- Formalize the schedule for providing observer-status reports to VC sponsors regarding foundation status.

**Approval Authorities:** Project Manager, Chief Political & Regulatory Strategist

### 9. Foundational Monitoring & Compliance Framework (FMCF)

**ID:** 7e811dd2-7be1-4ed3-9cdf-e30b6495bbbc

**Description:** Establishes the internal compliance structure required to satisfy international AML/KYC scrutiny given the funding sources and legal ambiguity. Incorporates provisional screening standards until formal jurisdiction is confirmed.

**Responsible Role Type:** Capital Transition & Financial Modeler

**Primary Template:** Risk-Based Compliance Program Outline

**Secondary Template:** Provisional KYC/AML Flowchart

**Steps:**

- Design provisional KYC protocols for high-net-worth international patrons, based on FATF high-risk jurisdiction equivalents.
- Integrate auditing triggers into the financial tracking system related to sponsor equity/revenue reporting.
- Define necessary reporting structure for the Financial Crimes Compliance Officer (newly assigned mandate).

**Approval Authorities:** Chief Political & Regulatory Strategist, CFO

### 10. Geotechnical Baseline Assessment Report (GBAR)

**ID:** 9cfa6542-4423-4aba-90cc-00ec7779d566

**Description:** The compiled, initial findings report from the commissioned full-depth geotechnical survey (Decision 10). This document serves as the basis for all Phase 2 foundation design choices and must explicitly quantify subsurface risk and list required deep-pile remediation specifications.

**Responsible Role Type:** Multi-Phase Construction & Infrastructure Lead

**Primary Template:** Formal Geotechnical Engineering Report Standard (ASCE/ASTM)

**Secondary Template:** Critical Path Dependency Analysis (Foundation)

**Steps:**

- Oversee and interpret raw data from the field survey contractors.
- Quantify the volume and cost estimate for necessary deep-pile reinforcement.
- Sign off on the dependency timeline (6 months completion) for the master schedule.

**Approval Authorities:** Chief Engineer, Project Oversight Committee

### 11. Internal/External Stakeholder Reporting Cadence Document

**ID:** a894a6aa-e674-42dc-bfdf-a69c5a911396

**Description:** A formal schedule defining when communications occur for each stakeholder group (VCs, Security, Diplomatic Corps, Internal Team). Specifies required content—e.g., VC reports must show foundation progress; Diplomatic reports must reflect optional patronage rates.

**Responsible Role Type:** Reputation & Political Shield Officer

**Primary Template:** Stakeholder Management Communication Schedule

**Secondary Template:** Internal Progress Reporting Standard

**Steps:**

- Map required frequency, content, and distribution channels for all identified internal and external groups.
- Establish the mandatory weekly leadership simulation drill schedule (tying to Decision 11 adjustments).
- Finalize format for observer-status reports to Venture Capital representatives.

**Approval Authorities:** Project Manager, Integrated Security & Perimeter Architect

## Documents to Find

### 1. Existing Nevada Gaming Control Board Licensing Archives (2010-2018)

**ID:** f94ec150-0620-40bc-ab16-91b3ce420e6e

**Description:** Publicly available records detailing application procedures, ownership transparency requirements, and AML controls established for high-stakes integrated resort developments like Stratosphere/Aspers. Critical input for understanding compliance mapping (Decision 4).

**Recency Requirement:** Any records pertaining to major ownership/regulatory shifts (2010-2018) are relevant.

**Responsible Role Type:** Chief Political & Regulatory Strategist

**Access Difficulty:** Medium

**Steps:**

- Search Nevada Gaming Control Board (NGCB) public records portal.
- Identify law firms specializing in Nevada gaming compliance and review their publicly available case summaries.

### 2. Olympic Venue Decommissioning and Conversion Reports

**ID:** 7a339450-5dcd-4996-bf75-c6310f221077

**Description:** Technical annexes from IOC Legacy Reports (London 2012, Rio 2016) detailing the engineering logistics, utility handover synchronization, and political management of repurposing temporary spectator facilities. Necessary for planning the Phase 1 to Phase 3 transition logistics (Decision 9 and Project Goal).

**Recency Requirement:** Last 10 years highly preferred for modern construction/utility standards.

**Responsible Role Type:** Multi-Phase Construction & Infrastructure Lead

**Access Difficulty:** Medium

**Steps:**

- Search IOC official website for 'Legacy Reports' and 'Technical Annexes'.
- Consult academic journals on 'Venue Management' for detailed engineering case studies.

### 3. US Navy Submarine Tender Deployment Security MOUs

**ID:** 6204f8b1-b58e-4452-853c-064d8d7061e3

**Description:** Official or declassified Memorandums of Understanding (MOUs) governing intelligence sharing protocols between US Navy command and allied/host-nation security details on deployed tenders (e.g., USS Emory S. Land). Crucial for drafting the shared operational security perimeter protocols (Assumption 7/Decision 13).

**Recency Requirement:** Last 5 years for current operational relevance, older documents acceptable for baseline framework understanding.

**Responsible Role Type:** Integrated Security & Perimeter Architect

**Access Difficulty:** Hard

**Steps:**

- Search Department of Defense (DoD) public affairs releases or GAO reports on naval logistics.
- Submit formal inquiry to Naval Systems Command via appropriate government channels for unclassified documentation.

### 4. Federal Property Zoning and Land Use Regulations (Washington D.C.)

**ID:** 4c808353-d1da-4b5a-a5b6-ac0aed94ee13

**Description:** Official documents detailing current zoning, subterranean use restrictions, and utility easement limitations applicable to federal land parcels adjacent to or incorporating the White House complex. Essential input for foundational engineering (Decision 10) and temporary staging permits (Location 2).

**Recency Requirement:** Current, active regulations are mandatory.

**Responsible Role Type:** Chief Political & Regulatory Strategist

**Access Difficulty:** Medium

**Steps:**

- Search official websites for the US General Services Administration (GSA) and DC Land Use/Zoning Commission.
- Consult with internal counsel regarding federal property jurisdiction overrides vs. local code.

### 5. FATF Guidelines on High-Risk Jurisdiction Casino/HNWI Compliance

**ID:** dc75b72a-2153-4b3b-bcf9-66c008a4a661

**Description:** Official publications and guidance documents from the Financial Action Task Force (FATF) related to Anti-Money Laundering (AML) and Know Your Customer (KYC) standards required for international gaming entities operating under regulatory ambiguity or in high-risk environments. Needed to draft the FMCF.

**Recency Requirement:** Most recent published guidance (last 18 months).

**Responsible Role Type:** Capital Transition & Financial Modeler

**Access Difficulty:** Easy

**Steps:**

- Download official guidelines directly from the FATF public website.
- Source interpretive notes published by major global financial regulators referencing FATF standards for gaming.

### 6. Geotechnical Baseline Data for White House East Wing Footprint

**ID:** 74eff431-137c-45c2-b756-e16f02ac781c

**Description:** Any existing (even historical) subsurface reports, geological surveys, or foundation documentation related to the original White House East Wing structure or adjacent underground utility plans. Necessary raw input to scope the modern geotechnical survey effectively (Decision 10).

**Recency Requirement:** Historical data is crucial for initial scoping, though current utility maps are mandatory.

**Responsible Role Type:** Multi-Phase Construction & Infrastructure Lead

**Access Difficulty:** Hard

**Steps:**

- Search US Army Corps of Engineers (USACE) construction archives for D.C. federal complex projects.
- Contact the White House Engineering/Facilities Management for legacy infrastructure drawings.

### 7. Targeted International Military/Governmental Maintenance MOU Templates

**ID:** 07ae9821-0e0b-449a-b270-3dc4b8054ccd

**Description:** Sample or template Memorandums of Understanding used by Western militaries or agencies (like NATO or specific DoD commands) for sharing operational security responsibilities on joint/temporary secure facilities. Provides precedent for the required intelligence-sharing structure (Assumption 7).

**Recency Requirement:** Last 5 years preferred.

**Responsible Role Type:** Integrated Security & Perimeter Architect

**Access Difficulty:** Medium

**Steps:**

- Search official publications from US Department of Defense (DoD) security manuals or joint doctrine publications.
- Review publicly available, declassified agreements related to shared command centers.