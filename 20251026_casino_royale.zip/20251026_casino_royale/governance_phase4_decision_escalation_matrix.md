**Budget Request Exceeding OMT Authority Threshold ($50M)**
Escalation Level: Project Executive Board (PEB)
Approval Process: Majority vote by voting members. Tie-breaker: Project Sponsor.
Rationale: Exceeds the $50 Million financial ceiling designated for the Operational Management Team (OMT).
Negative Consequences: Project capitalization stall or budget insolvency if resource allocation is delayed.

**Unresolved Deadlock within Operational Management Team (OMT) on Tactical Schedule**
Escalation Level: Project Executive Board (PEB)
Approval Process: CEO decision is binding for OMT consensus failure but must be documented for immediate PEB review.
Rationale: OMT requires consensus; disagreement on tactical schedule (e.g., impact of staffing hours on Phase 1 revenue) requires senior intervention to avoid operational paralysis.
Negative Consequences: Delayed Phase 1 revenue generation, directly impacting subsequent construction funding milestones.

**Legal Counsel Identification of Unmitigatable Conflict in Jurisdiction Strategy (Executive Order)**
Escalation Level: Project Executive Board (PEB)
Approval Process: Majority vote; PEB must decide on pivot to alternative legislative strategy or cease work.
Rationale: LRAG consensus failure or identification of severe, unmitigable legal conflict (Risk 1) threatens the fundamental operating legitimacy of the entire project.
Negative Consequences: Immediate injunction/seizure of assets, leading to total project failure and $600M write-off.

**Reputational Harm Warning Issued Regarding Mandatory Patronage Enforcement**
Escalation Level: Project Executive Board (PEB)
Approval Process: PEB must review and approve the immediate cessation or modification of the diplomacy/patronage strategy causing the warning.
Rationale: The finding challenges the adopted mitigation strategy (Risk 3), posing an existential diplomatic threat that overrides standard operational concerns.
Negative Consequences: Diplomatic boycotts, sponsor withdrawal, and catastrophic reputational damage forcing a strategic pivot.

**Geotechnical Survey Reveals Major Foundation Instability Requiring >20% Budget Increase for Deep-Piling**
Escalation Level: Project Executive Board (PEB)
Approval Process: PEB must approve funding augmentation which impacts the overall $600M capital plan and construction schedule.
Rationale: Foundation remediation cost/schedule impact is significant, potentially exceeding OMT change control limits and fundamentally altering the structural dependency that Phase 2 rests upon (Risk 5).
Negative Consequences: Severe Phase 2 delay (6-9 months) and high probability of budget overruns exceeding $150M, jeopardizing sponsor return expectations.

**Conflict Over Sponsor Rights: VC Consortium Demands Veto Power Exceeding Observer Status**
Escalation Level: Project Executive Board (PEB)
Approval Process: PEB vote, critical for maintaining sovereign control over security and operations (Risk 6/Assumption 6 conflict).
Rationale: Challenge to governance structure sovereignty directly conflicts with risk mitigation efforts to control asset monetization and security oversight.
Negative Consequences: Loss of long-term control over operational revenue streams or potential security compromises if veto power is granted to high-dilution investors.