**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority ($5M limit). Requires strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun, project delays, and compromised project scope.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Mitigation Plan
Rationale: The PMO cannot handle the risk with existing resources or approved plans. Requires strategic guidance and resource allocation from the Steering Committee.
Negative Consequences: Project failure, legal issues, reputational damage, and harm to stakeholders.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: The PMO members cannot agree on a vendor, potentially delaying the project. The Steering Committee needs to provide direction.
Negative Consequences: Project delays, increased costs, and selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: A significant change to the project scope requires strategic review and approval due to potential impacts on budget, timeline, and objectives.
Negative Consequences: Project delays, budget overruns, and failure to meet strategic objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Ethical violations require independent review and investigation to ensure compliance with ethical standards and regulations.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Significant Ethical Breach**
Escalation Level: Board of Directors
Approval Process: Board Review and Decision
Rationale: Significant ethical breaches require the highest level of oversight and decision-making to protect the organization's reputation and integrity.
Negative Consequences: Severe legal penalties, irreparable reputational damage, and loss of investor confidence.

**Security Expenditure Exceeding Security Advisory Group Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Security expenditures exceeding $500,000 require strategic review and approval due to potential impacts on budget and overall project objectives.
Negative Consequences: Compromised security, increased costs, and project delays.