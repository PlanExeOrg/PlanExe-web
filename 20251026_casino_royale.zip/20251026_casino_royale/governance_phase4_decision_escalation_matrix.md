**Budget Request Exceeding OMB Authority for Immediate Site Remediation/Contingency Drawdown**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: PESC voting (75% consensus required); requires justification for non-emergency status if related to political reversal.
Rationale: Any proposed drawdown from the segregated $90M Contingency Fund (Decision 10) is explicitly removed from OMB authority and requires the highest level of oversight to protect the existential political risk buffer.
Negative Consequences: Erosion of the political insurance policy, leading to inability to execute rapid site remediation if regulatory reversal occurs.

**Material Conflict on Regulatory Strategy (OMB Deadlock or Rejection of Fast-Track)**
Escalation Level: Compliance, Audit, and Regulatory Assurance Panel (CARAP)
Approval Process: Unanimous vote required by CARAP members to halt expenditure or mandate regulatory course correction (e.g., pivoting from Fast-Track to Option 2 compliance).
Rationale: The existential political/regulatory risk (Decision 2) is the project's single highest threat; operational bodies cannot resolve differences regarding compliance thresholds or legal viability.
Negative Consequences: Project halt if external counsel advises the fast-track posture is legally impossible, potentially stranding $600M Phase 1 capital.

**Failure to Meet Revised Phase 1 Profitability Trigger Within New Timeframe**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: PESC review of revised operations plan, requiring sponsor buy-in on milestone adjustment and potential collateralization proposals.
Rationale: The 60-day profitability target (critical for 75% sponsor fund release) directly controls project capitalization and velocity (Decision 1). Delays impact sponsor trust and Phase 2 funding.
Negative Consequences: Delayed release of the crucial $450M sponsor tranche, halting irreversible commitments for permanent construction (Phase 2) or triggering sponsor withdrawal clauses.

**Proposal for Non-Fungible Asset Exchange Acceptance (AML Risk)**
Escalation Level: Compliance, Audit, and Regulatory Assurance Panel (CARAP)
Approval Process: Unanimous CARAP vote required to approve the specific framework or reject the transaction based on AML compliance standards (Decision 14).
Rationale: Handling non-standard collateral introduces high AML and spionage risk, overriding the PESC’s general financial oversight and falling under CARAP’s exclusive mandate for high-value transaction auditing.
Negative Consequences: Immediate government investigation, potential asset seizure, and catastrophic failure of the core high-roller revenue model if AML is breached.

**Major Proposed Change to Guest Profile Prioritization from 60/40 Commercial Split**
Escalation Level: Project Executive Steering Committee (PESC)
Approval Process: PESC Strategic Vote (75% consensus required), as altering the 60/40 split fundamentally changes the revenue model, security requirement, and diplomatic engagement levels.
Rationale: The Guest Profile (Decision 3) dictates commercial velocity versus diplomatic overhead. Any shift requires strategic sign-off as it conflicts with both the short-term profitability goal and the long-term diplomatic integration strategy.
Negative Consequences: Deviation from the Pioneer’s Gauntlet strategy, leading to either lowered initial revenue flow or increased security/diplomatic complexity that strains operational capacity.