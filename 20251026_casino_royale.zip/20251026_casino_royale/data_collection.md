## 1. Legal Viability of Post-Facto Regulatory Approval

This data collection addresses the single existential risk (Regulatory Failure) identified by all reviews. Without a viable legal path, construction must stop, rendering all other efforts moot.

### Data to Collect

- Statutory pathway analysis for post-facto authorization of irreversible structural changes on White House land.
- Precedent mapping for GSA/DOI land-use reversal conditional Notice-to-Proceed (NTP) issuance.
- Confidence rating (0-100%) from external counsel on securing conditional NTP within 30 days via Option 2 submission.

### Simulation Steps

- Use legal research databases (e.g., Westlaw/LexisNexis) to search for cases involving Title 40 U.S.C. (Public Buildings, Property, and Works) violations on federally restricted sites.
- Model the legislative timeline required to pass a joint resolution to validate land use, comparing it against the 30-day target.

### Expert Validation Steps

- Consult with Expert 6: Federal Property & Land Use Attorney to validate the likelihood of securing conditional NTP via Decision 2, Option 2.
- Consult with Expert 1: Construction Risk Manager to assess the minimum viable legal documentation required before Phase 2 foundation design proceeds.

### Responsible Parties

- Political-Regulatory Acceleration Lead
- Risk & Decommissioning Planner (for tracking legal contingency readiness)

### Assumptions

- **High:** External counsel can map alternative legal pathways (Option 2) with a viable conditional NTP timeline within a 14-day rapid engagement window.

### SMART Validation Objective

Secure a formal, written legal opinion from specialized D.C. counsel detailing the required regulatory submission package (per Decision 2, Option 2) and providing a quantified probability of receiving a conditional Notice-to-Proceed (NTP) from GSA/DOI by 2026-05-27.

### Notes

- Immediate engagement of counsel required. This dictates all subsequent physical mobilization timelines.


## 2. Revised Phase 1 Funding Trigger Contract Amendment

The current alignment between the profit trigger and the physical relocation schedule is flawed, risking immediate cash flow stoppage. Formalizing the 'pause' mechanism is critical for financial stability.

### Data to Collect

- Draft amendment to Sponsor Commitment Structuring outlining the revised profitability trigger: 60 consecutive days of NOI at $50,000 USD/day, commencing on Day 8 post-relocation.
- Sponsor Financial Representatives' formal written acceptance of the revised trigger language.
- Timeline assessment for Phase 1 relocation logistics, confirming the minimum effective blackout duration (target < 7 days).

### Simulation Steps

- Run financial forecast models using the revised 60-day post-relocation trigger to confirm $450M tranche release timing against Phase 2 required procurement start dates.
- Use specialized logistics planning software (owned by Phased Construction Director) to simulate the container move timeline under maximum operational constraints.

### Expert Validation Steps

- Consult with Expert 8: Sponsor Relationship Manager to negotiate and confirm sponsor agreement to the revised trigger.
- Consult with Expert 1: Construction Risk Manager to validate the realistic timeline for the 7-day relocation blackout.

### Responsible Parties

- High-Stakes Financial Architect
- Casino Operations Specialist

### Assumptions

- **Medium:** The physical relocation (blackout period) can be contained within 8 calendar days.
- **High:** Sponsors will accept the 60-day post-relocation profitability measure as adequate replacement for the original 90-day operation.

### SMART Validation Objective

Obtain signed contractual amendment from all initial sponsors confirming the revised 60-day post-relocation profitability trigger by 2026-05-08.

### Notes

- Must be executed concurrently with regulatory review, as funding locks down the immediate ability to build.


## 3. Long-Term Funding Mechanism Redesign

The chosen surcharge mechanism (Decision 5, Option 3) is a political time bomb. Replacing it with a transparent, ancillary levy (Decision 4, Option 1) is necessary for securing long-term viability and legitimacy.

### Data to Collect

- Detailed financial model projecting operational costs for Phase 2 ($/year).
- Draft proposal for 'Infrastructure Levy' structure targeting only ancillary services (Decision 4, Option 1).
- Cost-to-serve analysis: required gross revenue needed solely from ancillary services to cover the projected operational deficit, excluding gambling revenue.

### Simulation Steps

- Use specialized financial modeling software (owned by Long-Term Sustainability Officer) to stress-test the ancillary levy model against various hospitality demand scenarios.
- Model the impact of the successful levy versus the projected $50M/month requirement derived from the opaque surcharge.

### Expert Validation Steps

- Consult with Expert 7: Monetization Pathway Modeler to validate the feasibility of achieving the required operational revenue solely through ancillary means.
- Consult with Expert 1: Construction Risk Manager to ensure the proposed levy structure aligns with immediate AML readiness (Decision 14 compliance).

### Responsible Parties

- Long-Term Sustainability Officer
- High-Stakes Financial Architect

### Assumptions

- **High:** A defensible 'Infrastructure Levy' based purely on on-site ancillary services (hospitality, non-gambling) can reliably generate coverage for the target operational deficit.

### SMART Validation Objective

Deliver a finalized, modeled proposal for the transparent 'Infrastructure Levy' (Decision 4, Option 1) to the Executive Steering Committee, benchmarked against the required $50M monthly coverage, by 2026-07-15.

### Notes

- All work on Decision 5, Option 3 must cease immediately.


## 4. AML Compliance Posture Enforcement

Accepting non-fungible, private collateral places the entire project at high risk of financial sanction and banking access loss. Immediate restriction to fungible currency settled via vetted banks is required to maintain operations.

### Data to Collect

- Formal sign-off policy document confirming all high-value patron markers (markers) must be settled ONLY via the pre-approved International Banking Consortium (Decision 14, Option 1).
- Formal audit trail proving the immediate cessation of planning for internal ledgers for non-fungible assets (Decision 14, Option 2).
- Consortium confirmation that Decision 14, Option 1 meets baseline AML/KYC requirements for cross-border financial transactions.

### Simulation Steps

- Run simulated high-value transaction scenarios through the Banking Consortium interface to confirm settlement time and AML flagging protocols.
- Perform an internal compliance audit simulation against the newly defined policy against FATF standards.

### Expert Validation Steps

- Consult with Expert 2: International Compliance Strategist to verify the compliance hardening of Decision 14, Option 1.
- Consult with the Ultra-Secure Patron Vetting Coordinator to ensure the banking integration works with the T2CA system.

### Responsible Parties

- Ultra-Secure Patron Vetting Coordinator
- Head of Compliance (Recommended new Personnel)

### Assumptions

- **Medium:** Restricting to bank-settled fungible currency will not immediately reduce the potential spend of the highest-tier high-rollers by more than 20%.

### SMART Validation Objective

Achieve formal, written certification from the International Banking Consortium partner detailing acceptance of Decision 14, Option 1, and fully revoke Decision 14, Option 2 planning by 2026-05-15.

### Notes

- This is a high-leverage action that reduces potential immediate revenue but eliminates an existential regulatory threat.

## Summary

The project's strategic direction ('The Pioneer's Gauntlet') is fundamentally unstable due to three critical, interrelated, high-sensitivity failures: the near-certain non-viability of post-facto regulatory approval (Existential Risk), the flawed coupling of Phase 1 funding deadlines against known operational blackouts, and the politically toxic, unsustainable plan for long-term funding. Immediate action must focus on hardening the legal foundation and stabilizing the initial cash flow milestone.

**IMMEDIATE ACTIONABLE TASKS (MUST BE COMPLETED WITHIN 14 DAYS):**
1. **Regulatory Pivot:** Immediately task specialized external counsel (Expert 6) to halt reliance on fast-track authorization and initiate the comprehensive legal submission (Decision 2, Option 2). Target: Legal strategy finalized by 2026-05-11.
2. **Financial Stabilization:** Formalize amendments to the Sponsor Commitment Structuring contract defining the profitability trigger as 60 days *after* the Phase 1 relocation blackout completes. Target: Signed amendment by 2026-05-08.
3. **De-Risk AML Exposure:** Officially prohibit all non-fungible asset collateralization (Decision 14, Option 2) and mandate settlement exclusively through the pre-approved International Banking Consortium (Decision 14, Option 1). Target: Formal policy locked down by 2026-05-15.
4. **Long-Term Funding Re-Design:** Immediately cease all work on the 'National Security Surcharge' (Decision 5, Option 3) and re-task resources to fully model the viable 'Infrastructure Levy' (Decision 4, Option 1). Target: Initial model completion by 2026-07-15.