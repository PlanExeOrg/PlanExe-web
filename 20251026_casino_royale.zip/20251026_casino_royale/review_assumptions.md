## Domain of the expert reviewer
High-Stakes Geopolitical Infrastructure Project Management & Risk Quantification

## Domain-specific considerations

- Sovereign Risk and Political Expediency
- Dual-use Public/Commercial Infrastructure Security Standards
- Complex Multi-Jurisdictional Regulatory Compliance (Federal/International)
- Rapid Capitalization and High Dilution Strategy Impact

## Issue 1 - Critical Missing Assumption: Illegality of Jurisdiction Strategy
The current plan (Pioneer's Gambit) hinges on Decision 4 (Choice 3): operating under a 'novel, temporary executive order' classifying gambling transactions as 'diplomatic exchanges.' This is the single greatest unmitigated legal assumption. Operating a commercial casino on federal land, especially one targeting heads of state for gambling revenue, likely exceeds Presidential executive authority, making the entire premise illegal from Day 1. This assumption is not 'mitigated' by planning to spend 15% on legal defense; it requires explicit external legislative or treaty authorization which is assumed to be obtained or bypassed.

**Recommendation:** Immediately halt all physical work in favor of securing a definitive, legally binding authorization framework. This requires replacing the executive order assumption with an explicit assumption: **Missing Assumption: A special legislative act (Congressional approval) or a ratified international compact guaranteeing operational legality must be secured before any construction or revenue generation commences.** This should be assigned a 9-month timeline dependency.

**Sensitivity:** Failure to secure legislative/treaty backing (Baseline: 0 months delay) will result in immediate injunction (Risk 1 escalation). This failure immediately reduces the project's ROI to 0% (total write-off of the $600M investment) and imposes a minimum 12-18 month delay for remediation/re-planning concerning the legality of jurisdiction.

## Issue 2 - Critical Missing Assumption: Ground Truth for Construction Timeline (Foundation Certainty)
The plan assumes an aggressive 4-month Phase 1 completion and immediate start to Phase 2 construction. However, Decision 10 (Structural Substitution Protocol) highlights massive uncertainty regarding the subterranean conditions of the former East Wing foundation. The project must assume that unforeseen subsurface issues (geotechnical instability, archaeological finds, utility conflicts in a legacy federal site) will halt progress. The assumption that foundation remediation will not significantly delay the schedule is dangerously optimistic.

**Recommendation:** Replace the optimistic 4-month Phase 1 timeline with a dependency on the geotechnical survey results. **Missing Assumption: The geotechnical survey (Decision 10, Choice 2) will require 3 months and, upon completion, will necessitate a minimum of 6 months of foundation remediation/reinforcement before Phase 2 main structure can commence safely.** Fund this remediation using a specific contingency reserve, not pooled sponsor capital.

**Sensitivity:** If foundation remediation requires deep-pile replacement (as suggested in Choice 2), the initial $600M construction budget will likely overrun by 20-35% ($120M - $200M) to secure structural integrity. If this remediation is delayed, Phase 2 startup is delayed by 6-9 months, increasing the time-to-ROI by 9-14 months, assuming a baseline construction period of 30 months.

## Issue 3 - Under-Explored Assumption: VC Dilution vs. Retained Sovereign Control
The chosen strategy involves high dilution via international Venture Capital (VCs) to secure rapid funding ($600M). The assumption is that VCs get minor oversight ('non-veto observer rights'). In high-dilution scenarios (which could reach 50%+ for rapid, low-conditionality capital), VCs will aggressively seek board control and veto rights over operational spending (Decision 12). The trade-off between speed and control is underestimated; this will directly conflict with sovereign control over staffing and security protocols.

**Recommendation:** Quantify the maximum acceptable dilution. **Assumption Adjustment: The project leadership must cap VC equity stake at 30%. Above 30%, the risk of losing control over security procurement (Decision 13) and operational closures (Decision 11) outweighs the benefit of speed.** If the required funding cannot be secured at 30% dilution, the 'Pioneer's Gambit' must pivot to the G7 sponsored route (Builder's Blueprint) to maintain sovereign control, accepting a 6-month funding delay.

**Sensitivity:** If dilution exceeds 40% (baseline assumed 30%), sponsors gain significant leverage. This leverage could force a halt to the mandatory federal travel expenditure rule (Risk 2) to avoid immediate audit risk, potentially leading to a 12-18 month funding gap during the transition phase (Decision 8).

## Issue 4 - Questionable Assumption: Mandating Political Patronage vs. Reputation Management
The plan mandates leadership participation via treaties (Decision 5) while simultaneously budgeting $30M for reputation defense (Assumption 5). These actions are fundamentally contradictory. Coercing participation (mandatory attendance) creates immediate, high-profile diplomatic incidents (Risk 3) that $30M in proactive PR cannot correct; it guarantees negative, sustained international coverage. The mitigation (Choice 2: optional attendance) conflicts with the core 'Gambit' strategy.

**Recommendation:** Resolve the conflict between coercion and PR by **immediately adopting Strategic Choice 2 for Clientele Engagement Model (Optional, Invitation-Only Access)**, effectively rejecting the 'mandatory' component of the Gambit. Reallocate the $30M PR budget away from reactive defense and toward funding verifiable, high-impact domestic infrastructure repair linked to the facility (Decision 6, Choice 1), thereby strengthening the foundation for later citizen funding transition.

**Sensitivity:** Maintaining mandatory patronage (Baseline: High Risk) leads to a 50% chance of key sponsor withdrawal or diplomatic boycott within 12 months, which could halt Phase 2 funding access, reducing projected ROI by 40%-60%. Pivoting to optional access reduces political friction but risks lowering Day 1 utilization by 35% against initial forecasts.

## Review conclusion
The project is founded upon an aggressively high-risk strategy ('The Pioneer's Gambit') that rests on legally dubious foundational assumptions. The three most critical weaknesses are: 1) The assumed legality of operating under an executive order for casino jurisdiction (Critical Missing Assumption 1), 2) The massive underestimation of time and cost related to unknown subsurface foundation conditions (Critical Missing Assumption 2), and 3) The irreconcilable conflict between leveraging high-dilution VC funding and retaining sovereign control over operations (Under-Explored Assumption 3). Immediate action must be taken to secure explicit legislative/treaty backing for jurisdiction and to establish realistic geotechnical timelines contingent on full site analysis, rather than assuming rapid completion in the volatile D.C. environment.