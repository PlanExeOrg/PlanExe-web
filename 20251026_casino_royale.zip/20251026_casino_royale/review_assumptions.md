## Domain of the expert reviewer
High-Risk Mega-Project Governance and Regulatory Navigation

## Domain-specific considerations

- Existential political and regulatory compliance risk (White House site)
- Financing structure dependency on highly volatile Phase 1 operational performance
- Complex dual mandate: Commercial ROI vs. Diplomatic Functionality
- Rapid, aggressive construction timeline contradicting standard permitting processes
- Long-term funding reliance on politically sensitive citizen monetization

## Issue 1 - Critical Missing Assumption: Viability of 'Post-Facto' Regulatory Approval
The core strategy ('Pioneer's Gauntlet') relies on 'Initiat[ing] parallel 'fast-track' construction... while simultaneously launching high-level diplomatic negotiations to secure post-facto authorization.' However, a critical missing assumption is *the legal and political impossibility* of obtaining authorization for demolishing and converting a portion of the White House *after* irreversible construction has begun. Relying on GSA/DOI in 15 days (Assumed) for a complete land-use reversal on federal property post-demolition is fundamentally unsound.

**Recommendation:** Immediately commission a specialized Political Risk/Eminent Domain legal team to map the precise statutory path that *would* permit this post-facto legalization. If no credible path exists, Decision 2 (Regulatory Engagement Posture) must shift immediately to Option 2 (Comprehensive Submission/Vetting) to avoid catastrophic capital stranding. Mandate that 100% of sponsor funds tied to Phase 1 success are held in escrow until a conditional 'Notice to Proceed' for Phase 2 is secured, irrespective of Phase 1 gambling revenue.

**Sensitivity:** If post-facto authorization fails entirely (near 100% probability given the scenario context), the project faces immediate, mandatory shutdown. Baseline impact: Project halted immediately upon discovery of illegality, leading to $90M contingency fund expenditure (Decision 10), an estimated 100% loss of the $510M construction budget not yet deployed, and a definitive ROI reduction of 80-100%.

## Issue 2 - Under-Explored Assumption: Operational Sustainability of Phase 1 Under Extreme Security & Revenue Stress
The plan assumes Phase 1 can achieve $50k/day NOI profit for 90 days (Assumed Q2) to unlock 75% of capital, while simultaneously accepting a 7-day operational blackout for relocation (Assumed Q5) and running a demanding new 'Tier 2 Commercial Access' security system (Assumed Q3). These elements conflict severely. The 7-day blackout directly jeopardizes the 90-day continuous profit requirement, and the new T2CA classification introduces unknown operational ramp-up time and personnel costs.

**Recommendation:** Revise the Phase 1 funding trigger. Tie 75% sponsor release to: (a) Completion of the 7-day blackout relocation AND (b) Achieving 60 days of continuous profitable operation *after* relocation. Furthermore, allocate 30% of the $5M stakeholder budget (Assumed Q7) to rapidly design and test the T2CA vetting process on a separate, non-revenue pilot site to reduce ramp-up uncertainty. Budget $2M (baseline: $0) for redundant security hardware for Phase 1 to smooth the T2CA transition.

**Sensitivity:** If the 7-day blackout causes the 90-day target to be missed (e.g., profitability is delayed by 2 weeks post-relocation), the key milestone is missed. This would delay the release of the $450M capital tranche by 1-2 months, impacting Phase 2 timelines by 1-2 months. This delay increases the cost of capital by an estimated 1-2% of the delayed amount, or $4.5M-$9M in financing costs.

## Issue 3 - Unrealistic Assumption: Long-Term Citizen Revenue Viability via Obfuscated Surcharge
The long-term strategy relies on a 'floating, variable National Security Surcharge' (Decision 5) projected at $50 Million USD *monthly* via a 0.5% national levy (Assumed Q8). A 'floating, variable' levy tied indirectly to operational deficits is definitionally unstable for funding permanent government operations; it lacks accountability and is politically fragile. Furthermore, assuming $50M/month nationally from an indirect levy related to a niche, politically controversial casino is an optimistic extrapolation reliant on Treasury compliance without explicit citizen linkage.

**Recommendation:** Decouple the long-term financial plan from a secret, variable federal levy. Revert to Decision 4, Option 1: Frame the contribution as a transparent 'Infrastructure Levy' on ancillary hospitality services *within the complex only*. If the project requires $50M/month post-sponsors, this implies $600M/year in operating costs. Estimate revenue needed from on-site patrons: If average margin is 30%, the venue must generate $2 Billion USD in gross revenue annually ($166M/month). This must be validated, as reliance on external/hidden federal taxes creates a political cliff.

**Sensitivity:** If the projected $50M/month citizen funding fails to materialize (e.g., only achieves 25% of target, or $12.5M/month), the project faces an $800M operational deficit over 20 years. To compensate this shortfall over the first 5 years (during which $300M is needed), a 10% reduction in expected sponsor ROI (initial 5-7% ROI projection) during the first 5 years is necessary, impacting investor confidence and future borrowing capacity by 15-20%.

## Review conclusion
This project is defined by extreme political risk acceleration ('The Pioneer's Gauntlet'). The three most critical failures identified are the near-certainty of regulatory collapse due to post-facto approval reliance, the operational fragility of Phase 1's funding trigger mechanism conflicting with the mandated transition blackout, and the highly unsustainable structure of the long-term citizen funding mechanism. Immediate action must focus on securing a viable legal pathway *before* construction accelerates, stabilizing the Phase 1 funding milestones against operational transition realities, and designing a transparent, resilient long-term financial structure directly tied to the asset's commercial performance rather than political subterfuge.