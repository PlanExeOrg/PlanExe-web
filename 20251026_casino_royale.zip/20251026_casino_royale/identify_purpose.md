**Purpose:** business

**Purpose Detailed:** A large-scale infrastructure project involving construction, monetization (sponsors/citizen funding), and entertainment operations targeting high-profile international figures.

**Topic:** Construction and operation of a large-scale casino in a governmental building location.