**Purpose:** business

**Purpose Detailed:** Commercial gambling venture targeting world leaders, involving construction and resource management.

**Topic:** Construction of a casino in the White House East Wing