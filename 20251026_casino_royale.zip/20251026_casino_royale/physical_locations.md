This plan implies one or more physical locations.

## Requirements for physical locations

- Site must accommodate the demolition of the existing White House East Wing.
- Site must allow for immediate construction of a temporary casino utilizing shipping containers (Phase 1).
- Site must allow for the concurrent planning and construction of a large, permanent casino structure (Phase 2).
- Site must support high-capacity operations (999 guests, 24/7) in both temporary and permanent phases.
- Site requires extreme high security and governmental/diplomatic access.

## Location 1
USA

Washington D.C.

Site of the former White House East Wing, 1600 Pennsylvania Avenue NW, Washington, D.C.

**Rationale**: This is the confirmed and required location for the project, as the plan explicitly details replacing the existing East Wing structure.

## Location 2
USA

Washington D.C. (Alternative Staging)

Joint Base Anacostia-Bolling or secure off-site contractor yards within 15 miles of the White House.

**Rationale**: Needed for pre-fabrication and staging of the Phase 1 container casino modules and storing construction materials, minimizing disruption to the immediate White House security perimeter.

## Location 3
USA

Virginia

Northern Virginia Data Center Corridor (e.g., Loudoun County)

**Rationale**: If the temporary operation (Phase 1) requires specialized, high-security IT infrastructure or dedicated servers that cannot be housed securely on the immediate White House complex, these locations offer redundant, high-security data hosting capacity.

## Location 4
USA

Washington D.C. (VIP Staging/Alternative Access)

Authorized secure holding areas near the Capitol or key embassies/federal buildings.

**Rationale**: Needed for highly controlled, secure check-in, biometric verification, and initial staging of the high-level clientele (Heads of State) before they are ferried to the highly sensitive East Wing site, adhering to Clientele Access Control Matrix.

## Location Summary
The primary, unchangeable location is the site of the former White House East Wing in Washington D.C., as specified by the plan. Three additional logistical locations are suggested: a secure staging area for temporary container construction, a high-security data center location for off-site IT support, and a nearby facility for secure initial vetting and staging of VIP clientele.