
## Audit - Corruption Risks

- Bribery of regulatory officials to expedite or overlook permit approvals.
- Kickbacks from construction contractors in exchange for awarding contracts.
- Conflicts of interest involving casino managers or White House staff using their positions for personal gain through preferential treatment of certain vendors or patrons.
- Misuse of confidential information regarding high-roller patrons for personal financial advantage.
- Trading favors with world leaders, such as offering favorable gambling terms in exchange for political influence or concessions.

## Audit - Misallocation Risks

- Inflated construction costs due to fraudulent billing practices or collusion with contractors.
- Misuse of marketing funds for personal expenses or unauthorized activities.
- Double spending on security systems or personnel through duplicate contracts or inflated invoices.
- Inefficient allocation of resources leading to cost overruns and project delays.
- Unauthorized use of casino assets, such as gaming equipment or luxury suites, for personal gain.

## Audit - Procedures

- Conduct quarterly internal audits of financial transactions, focusing on construction expenses, marketing expenditures, and security costs.
- Implement a system for tracking and verifying all invoices and payments to contractors and suppliers, with a threshold for mandatory review by senior management.
- Perform regular compliance checks to ensure adherence to gaming industry standards, anti-money laundering regulations, and security protocols.
- Conduct periodic external audits by an independent accounting firm to assess the overall financial health and compliance of the casino project.
- Establish a whistleblower mechanism for reporting suspected fraud or corruption, with clear procedures for investigation and resolution.

## Audit - Transparency Measures

- Publish a project progress dashboard that tracks key milestones, budget expenditures, and risk mitigation efforts.
- Document and publish minutes of key decision-making meetings, including those related to funding allocation, security protocols, and regulatory compliance.
- Establish a publicly accessible website that provides information about the casino project, including its goals, budget, and timeline.
- Implement a documented selection criteria for major decisions and vendors, ensuring fairness and transparency in the procurement process.
- Establish a clear and accessible whistleblower policy that protects individuals who report suspected wrongdoing.