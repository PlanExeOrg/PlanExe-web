**Primary domain:** Governmental Affairs

**Secondary domains:** Construction Engineering, Hospitality Management, Casino Operations

**Rationale:** Casino Operations and Construction Engineering are outcomes, but Governmental Affairs is prioritized as the political and location constraint will overwhelmingly dictate the feasibility and leadership of this highly sensitive project. While Casino Operations defines the service, the governmental location constraint is the defining characteristic here.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Construction Engineering | 5 | 5 | outcome | The project fundamentally involves building a large structure replacing an existing wing. |
| Casino Operations | 5 | 5 | outcome | The core project outcome involves operating a high-capacity, 24/7 gambling enterprise. |
| Hospitality Management | 4 | 4 | outcome | Operating a 24/7 casino for world leaders defines the core service outcome. |
| Financial Sponsorship | 4 | 4 | method | Securing $600M budget from sponsors is a primary financial aspect of the plan. |
| Governmental Affairs | 5 | 3 | constraint | Locating a casino within the White House grounds imposes severe political constraints. |
| Political Security | 4 | 3 | constraint | Operating an international gambling venue inside the White House demands high security. |