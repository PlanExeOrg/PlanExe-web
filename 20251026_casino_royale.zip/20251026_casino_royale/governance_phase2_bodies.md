### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for this high-risk, high-reward project, ensuring alignment with overall objectives and managing strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$5M).
- Oversee strategic risk management and mitigation.
- Resolve strategic-level issues and conflicts.
- Approve key vendor selections (>$1M).

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- Chief Executive Officer (CEO)
- Chief Financial Officer (CFO)
- Chief Legal Officer (CLO)
- Independent External Advisor (Gaming Industry Expert)
- Independent External Advisor (Security Expert)

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and risk management. Approval of expenditures exceeding $5 million. Approval of key vendor selections exceeding $1 million.

**Decision Mechanism:** Majority vote, with the CEO having the tie-breaking vote. Any decision with significant ethical implications requires unanimous approval.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review of project budget and expenditures.
- Review of strategic risks and mitigation plans.
- Discussion of strategic issues and conflicts.
- Approval of major changes to project scope, budget, or timeline.
- Review of stakeholder engagement activities.

**Escalation Path:** Board of Directors
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, operational risk management, and decisions below strategic thresholds, ensuring efficient project delivery.

**Responsibilities:**

- Develop and maintain project plans.
- Manage project budget and schedule.
- Track project progress and report on performance.
- Manage operational risks and issues.
- Coordinate project activities across different teams.
- Ensure adherence to project management standards and processes.
- Manage vendor relationships (below $1M).

**Initial Setup Actions:**

- Establish project management standards and processes.
- Develop project communication plan.
- Set up project tracking and reporting systems.
- Recruit project team members.

**Membership:**

- Project Manager
- Construction Manager
- Security Manager
- Marketing Manager
- Legal Counsel
- Finance Officer

**Decision Rights:** Operational decisions related to project execution, budget management (below $5M), and risk management. Vendor selections below $1M.

**Decision Mechanism:** Consensus among PMO members. If consensus cannot be reached, the Project Manager makes the final decision, escalating to the Project Steering Committee if necessary.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Review of project budget and expenditures.
- Review of operational risks and issues.
- Discussion of project team activities.
- Approval of minor changes to project scope or schedule.
- Review of vendor performance.

**Escalation Path:** Project Steering Committee
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** Provides specialized assurance on ethical and compliance aspects, ensuring adherence to regulations, ethical standards, and responsible gambling practices, given the sensitive nature of the project.

**Responsibilities:**

- Oversee compliance with all applicable laws and regulations, including gaming regulations, anti-money laundering regulations, and data privacy regulations (GDPR).
- Develop and implement ethical guidelines for casino operations.
- Review and approve marketing materials to ensure responsible gambling messaging.
- Investigate and resolve ethical complaints and compliance violations.
- Provide training to casino staff on ethical and compliance issues.
- Monitor and report on compliance performance.
- Ensure adherence to responsible gambling practices.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical guidelines.
- Establish compliance monitoring processes.

**Membership:**

- Chief Legal Officer (CLO)
- Compliance Officer
- Independent Ethics Advisor
- Representative from Gaming Commission
- Representative from Responsible Gambling Organization

**Decision Rights:** Decisions related to ethical and compliance matters, including approval of ethical guidelines, resolution of ethical complaints, and approval of compliance policies.

**Decision Mechanism:** Majority vote, with the Independent Ethics Advisor having veto power on decisions with significant ethical implications.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of compliance performance.
- Review of ethical complaints and investigations.
- Discussion of ethical and compliance issues.
- Approval of compliance policies and procedures.
- Review of marketing materials.
- Training on ethical and compliance issues.

**Escalation Path:** Project Steering Committee, Board of Directors (for significant ethical breaches)
### 4. Security Advisory Group

**Rationale for Inclusion:** Provides specialized input and assurance on security aspects, ensuring the safety of high-profile guests and assets, given the elevated security risks associated with the project.

**Responsibilities:**

- Develop and maintain security protocols for the casino.
- Assess security risks and vulnerabilities.
- Recommend security measures to mitigate risks.
- Oversee the implementation of security systems and procedures.
- Conduct security audits and penetration tests.
- Provide training to security personnel.
- Coordinate with intelligence agencies and law enforcement.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Conduct initial security risk assessment.
- Develop security protocols.

**Membership:**

- Chief Security Officer
- Independent Security Expert (former intelligence officer)
- Representative from Law Enforcement
- Representative from Intelligence Agency
- Casino Security Manager

**Decision Rights:** Decisions related to security protocols, security systems, and security procedures. Approval of security expenditures exceeding $500,000.

**Decision Mechanism:** Consensus among Security Advisory Group members. If consensus cannot be reached, the Chief Security Officer makes the final decision, escalating to the Project Steering Committee if necessary.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of security risks and vulnerabilities.
- Review of security incidents and breaches.
- Discussion of security measures and protocols.
- Approval of security expenditures.
- Training on security procedures.
- Coordination with intelligence agencies and law enforcement.

**Escalation Path:** Project Steering Committee