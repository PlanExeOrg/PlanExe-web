### 1. Project Executive Board (PEB)

**Rationale for Inclusion:** Given the project's extreme risk profile, high scale, foundational legal/regulatory novelty (executive order jurisdiction), and multi-phase physical execution, a dedicated supreme internal oversight body is non-negotiable. It must integrate the strategic direction set by stakeholders with the aggressive execution mandated by 'The Pioneer's Gambit'.

**Responsibilities:**

- Maintain ultimate accountability for project success against the Goal Statement.
- Approve budget thresholds exceeding $50 Million (strategic funding allocation).
- Resolve all disputes escalated from the Operational Management Team and Legal Assurance Group.
- Approve major scope changes, especially those impacting the legal jurisdiction model (Decision 4) or the clientele engagement model (Decision 5/Risk 3 mitigation).
- Oversight of the 15% Legal Task Force expenditure and its progress toward securing explicit legislative authorization.
- Final review and acceptance of Phase 3 transition completeness.

**Initial Setup Actions:**

- Finalize and ratify Terms of Reference (ToR) defining voting rights and tie-breaking mechanisms.
- Approve the revised operational schedule (18:00-04:00 core hours) based on Risk 7 mitigation.
- Establish the $50M financial threshold distinguishing its authority from operational authority.
- Formally ratify the selection of the External Assurance Auditor.

**Membership:**

- Project Sponsor (Chair, internal executive)
- Chief Executive Officer (Project Director)
- Lead Legal Counsel (Non-voting advisor on jurisdiction status)
- Chief Financial Officer
- Head of Governmental & Security Liaison
- Representative of Primary Venture Capital Consortium (Observer Status, Non-voting, per Assumption 6/Mitigation 3)

**Decision Rights:** All decisions concerning strategic funding ($50M+), legal framework modification, major phase sign-offs (Phase 1 completion, Phase 2 completion), and high-level risk acceptance.

**Decision Mechanism:** Majority vote (simple majority of voting members). Tie-breaker: The Project Sponsor's vote carries the final authority.

**Meeting Cadence:** Bi-weekly for the first 6 months (Critical Setup/Phase 1), transitioning to Monthly thereafter.

**Typical Agenda Items:**

- Legal status update regarding Executive Order legitimacy (Risk 1).
- Review of sponsor capital drawn vs. planned dilution (Risk 6).
- Phase completion gate reviews and sign-off.
- Escalation items from lower governance bodies.

**Escalation Path:** Unresolved issues are escalated for immediate review by the Governing Organization's highest executive authority (e.g., CEO/Board Chairman, if PEB Chair is not sufficiently senior).
### 2. Operational Management Team (OMT)

**Rationale for Inclusion:** Required for day-to-day execution, managing the three distinct physical phases (demolition, Phase 1 containers, Phase 2 construction) and coordinating complex cross-discipline resource allocation (Construction, Operations, Security readiness).

**Responsibilities:**

- Management of the $600M budget, controlling spending below the $50M executive threshold.
- Direct oversight of Phase 1 (Container Casino) setup and revenue generation schedule (targeting 4-month completion).
- Coordination of the Construction Engineering Lead and Hospitality Management Lead.
- Managing operational risk (e.g., staffing during 18:00-04:00 schedule, capacity allocation per Decision 7 strategy).
- Implementing security protocols defined by the Security Assurance Group.
- Managing daily cash flow and reporting variance against targets required for milestone payments.

**Initial Setup Actions:**

- Finalize and issue Level 2 Work Breakdown Structure (WBS) for Phase 1/Phase 2 interface.
- Select and contract specialized geotechnical survey vendor (Decision 10, Choice 2).
- Establish integrated risk register tracking all identified physical/operational risks (R4, R5, R7).
- Define internal reporting standards for Phase 1 operational metrics.

**Membership:**

- Chief Executive Officer (Chair)
- Project Controls Manager/Scheduler
- Lead Construction Manager
- Head of Casino Operations (Phase 1/3 Focus)
- Chief Security Officer (Non-voting liaison)

**Decision Rights:** All operational decisions, budget expenditures up to $50 Million, tactical staffing adjustments, immediate change orders within the approved engineering scope, and approval of Phase 1 revenue collection protocols.

**Decision Mechanism:** Consensus agreement required among all seated members. If consensus fails, the CEO's decision is binding, but must be formally documented for PEB review.

**Meeting Cadence:** Daily Standup (Phase 1/Early Phase 2), transitioning to three times per week.

**Typical Agenda Items:**

- Phase 1 revenue reconciliation vs. OpEx (Decision 2/Risk 7).
- Progress review of geotechnical survey status and foundation remediation schedule (Risk 5).
- Manpower utilization report against adjusted 18:00-04:00 schedule (Assumption 3).
- Review of immediate technical/logistical roadblocks.

**Escalation Path:** Any unresolved issue regarding scope changes requiring budget adjustments over $5M, conflicts impacting the legal framework, or technical risks that threaten the Phase 2 foundation completion will be escalated immediately to the Project Executive Board (PEB).
### 3. Legal and Regulatory Assurance Group (LRAG)

**Rationale for Inclusion:** Given the project deliberately operates in a high-risk, novel jurisdiction (Executive Order mandate) and relies on complex international finance/agreements (sponsors, trade treaties), dedicated, specialized assurance for compliance and legal exposure is crucial to mitigate the primary existential risk (Risk 1).

**Responsibilities:**

- Direct management and auditing of the 15% Legal Task Force budget allocated for regulatory mitigation (Assumption 1/Mitigation 1).
- Continuous monitoring and quarterly auditing of the legality/viability of the 'diplomatic exchange' operative classification.
- Drafting and negotiating the limited Memorandum of Understanding (MOU) for shared security perimeters with allied nations (Assumption 7).
- Ensuring all sponsor contracts (Decision 12) are structured as revolving credit where possible, to protect sovereign control.
- Vetting the formal language of clientele diplomacy used to enforce mandatory patronage (Decision 5), ensuring alignment with adopted mitigation strategy (optional access).

**Initial Setup Actions:**

- Formalize the role and reporting lines of the external lobbying/legal counsel funded by the 15% allocation.
- Conduct a rapid 30-day gap analysis between the Executive Order status and required International Gaming Treaty ratification path.
- Draft initial briefing documents for Congressional oversight regarding the scope of the legal strategy.

**Membership:**

- Lead Legal Counsel (Chair)
- Ethics & Compliance Officer (Crucial for GDPR/AML oversight)
- Senior Governmental Affairs Specialist
- Designated Representative from the External Assurance Auditor (for compliance checks)

**Decision Rights:** No financial approval authority. Authority rests solely in certifying the legal enforceability and regulatory adherence of project plans, vendor contracts, and operational protocols.

**Decision Mechanism:** Unanimous agreement among permanent members required to issue a 'Green Light' certification on any regulatory pathway. Dissent requires immediate PEB review.

**Meeting Cadence:** Weekly, especially during the first 6 months, to track progress on securing formal legislative backing.

**Typical Agenda Items:**

- Update on legislative blocking or challenge progress (Risk 1 status).
- AML/Transparency compliance check on Phase 1 revenue reporting.
- Review of data sharing protocols for security perimeter defined in MOU.
- Audit review of Legal Task Force expenditure vs. deliverable milestones.

**Escalation Path:** Failure to achieve consensus, or identification of a severe, unmitigable legal conflict (i.e., court injunction threat), must be escalated immediately to the Project Executive Board (PEB), requiring the PEB to activate contingency plans (e.g., immediate pivot to the Builder's Blueprint jurisdiction model).
### 4. Reputational and Ethical Assurance Panel (REAP)

**Rationale for Inclusion:** The project's inherent nature (casino on federal land) guarantees extreme reputational risk (Risk 3) and demands strict control over the philanthropic mandate (Decision 6) and staffing loyalty (Decision 14). This specialized body provides independent assurance on ethical integrity and reputational shielding.

**Responsibilities:**

- Oversee the effective deployment and auditing of the $30 Million Reputation Defense budget, ensuring funds are directed exclusively toward verifiable domestic philanthropic endeavors (Decision 6, Choice 1).
- Conduct annual reviews of the Staffing Model (Decision 14), focusing on bias, loyalty vetting, and adherence to hiring standards (avoiding politically favored hires).
- Monitor public sentiment and media narrative, reporting deviations from the adopted 'optional access' messaging.
- Certify that Capacity Management (Decision 7) allocations are transparent and non-discriminatory towards attending leaders, safeguarding against corruption/favor trading.
- Ensure compliance with ethical standards related to insider trading risks associated with high-stakes gambling involving government entities.

**Initial Setup Actions:**

- Appoint an external ethics/reputation specialist as the independent chair.
- Finalize the charter defining audit metrics for the philanthropic mandate effectiveness (measuring reduction in negative press).
- Establish independent, third-party managed whistleblower hotline for governance/staffing issues (Transparency Measure 4).

**Membership:**

- Independent Ethics & Compliance Advisor (Chair)
- Head of Public Relations / Communications Lead (Internal Liaison)
- Chief Security Officer (Liaison for staffing/insider risk context)
- Representative from External Assurance Auditor (Independent Oversight)

**Decision Rights:** Authority only extends to issuing formal 'Reputational Harm Warnings' to the PEB and recommending immediate halts on specific PR/hiring initiatives deemed too risky or conflicting with internal ethics.

**Decision Mechanism:** Supermajority vote (2/3rds) required to issue a binding warning to the PEB. Simple majority operates standard reporting.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of negative press sentiment index post-Risk 3 mitigation pivot.
- Audit of charitable expenditure vs. allocation plan.
- Review of security clearance status for newly onboarded international hospitality staff (Decision 14).
- Assessment of capacity allocation fairness during simulated high-demand scenarios.

**Escalation Path:** Any formal 'Reputational Harm Warning' not addressed satisfactorily by the OMT within 14 days (or immediately, if relating to potential corruption or illegal use of philanthropic funds) is escalated directly to the Project Executive Board (PEB).