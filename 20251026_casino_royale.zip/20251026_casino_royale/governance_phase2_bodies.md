### 1. Project Executive Steering Committee (PESC)

**Rationale for Inclusion:** Required for high-level strategic oversight, governing the project's existential risks (Political Survival and Long-Term Viability) identified in key strategic decisions (e.g., Regulatory Posture, Citizen Monetization). It must arbitrate conflicts between rapid commercial delivery and political legitimacy.

**Responsibilities:**

- Approve critical pivot points related to the Regulatory Engagement Posture (Decision 2).
- Overall financial stewardship, including approval for any drawdowns from the $90M Contingency Fund.
- Review and ratify the Long-Term Citizen Monetization Pathway (Decision 4) and its execution strategy.
- Provide final arbitration for disputes escalated from the Operational Management Board.
- Ensure adherence to the terms of the Pioneer's Gauntlet strategic path.

**Initial Setup Actions:**

- Finalize and sign the Project Charter and Terms of Reference.
- Appoint an independent Chair and Secretary from Sponsor/Executive ranks.
- Mandate the immediate external legal counsel review of the Post-Facto Regulatory Approval viability (as per audit recommendations).

**Membership:**

- Project Sponsor Lead (Chair)
- Senior Executive/Owner Representative not directly involved in execution (Independent Member)
- Lead for Regulatory Strategy (External Counsel)
- CFO/Head of Finance

**Decision Rights:** Strategic decisions, budget allocation exceeding $25 Million USD, changes to the core strategic path, acceptance/rejection of major political/regulatory risk thresholds.

**Decision Mechanism:** Consensus among 75% of voting members. Tie-breaker: The Project Sponsor Lead casts the deciding vote after requiring a mandatory 48-hour review period for dissenting members.

**Meeting Cadence:** Bi-weekly for the first 90 days, then Monthly thereafter.

**Typical Agenda Items:**

- Existential Risk Ticker Review (Regulatory & Political Viability)
- Phase Progress vs. Sponsorship Unlock Milestones (Decision 1)
- Escalation Review from Operational Management Board
- Quarterly Forensic Audit Summary (Focus on $90M Contingency integrity)

**Escalation Path:** Resolutions of the PESC are final internally. Only issues requiring external governmental intervention or legislative action are escalated beyond the PESC.
### 2. Operational Management Board (OMB)

**Rationale for Inclusion:** Required to manage the complex, phased, and aggressive execution timeline (Phase 1 start ASAP, relocation blackout, concurrent Phase 2 planning). This body links strategy to day-to-day deliverables, focusing on financial velocity and physical build milestones.

**Responsibilities:**

- Manage day-to-day execution, resource allocation, and schedule adherence for Phase 1 and Phase 2 construction.
- Monitor Temporary Venue Operational Tempo and ensure performance against the 60-day profitability target.
- Manage operational risks (utility loads, supply chain delays).
- Oversee the Client Access Control Matrix implementation for T2CA patrons.
- Approve all expenditures up to the $25 Million USD threshold.

**Initial Setup Actions:**

- Establish baseline delivery schedules for Phase 1 container modules and 2.5 MW microgrid.
- Define and lock in the operational security protocols for client check-in.
- Formalize the conflict resolution process for construction/logistics teams.

**Membership:**

- Project Director / Program Manager (Chair)
- Phase 1 Site Manager
- Phase 2 Lead Civil Engineer
- Head of Casino Operations
- Procurement Lead

**Decision Rights:** Operational decisions, logistical changes, approving expenditures up to $25 Million USD, managing deviation from the baseline schedule (up to 10 days delay).

**Decision Mechanism:** Simple majority vote of members present. Tie-breaker: The Project Director's vote carries double weight for logistical decisions; otherwise, the issue escalates.

**Meeting Cadence:** Twice Weekly.

**Typical Agenda Items:**

- Phase 1 Profitability Scorecard (Tracking $50k/day NOI)
- Critical Path Health Check (Controlling for Blackout Impact)
- Supply Chain Status and Risk Mitigation Actions
- Security Throughput Report (T2CA Vetting Performance)

**Escalation Path:** Issues requiring strategic re-prioritization, budget increases over $25M, or any political/regulatory risk threatening the project structure must be escalated to the Project Executive Steering Committee (PESC).
### 3. Compliance, Audit, and Regulatory Assurance Panel (CARAP)

**Rationale for Inclusion:** Given the unprecedented nature of the project (White House demolition for gambling) and the high-risk strategy choices (fast-track construction, hidden citizen funding), a dedicated, highly independent governance body is mandatory to manage explicit AML, political, and compliance risk exposure. This group must incorporate the necessary external audit functions.

**Responsibilities:**

- Exclusive oversight of AML compliance related to High-Value Asset Liquidation (Decision 14).
- Mandatory review of all T2CA Vetting Logs for favoritism or non-compliance (Audit Risk 2).
- Chair the external quarterly forensic audit of sponsor capital drawdown.
- Monitor legal execution of the Regulatory Engagement Posture, reporting viability status to PESC.
- Ensure the $90M Contingency Fund segregation is maintained monthly.

**Initial Setup Actions:**

- Contract and establish engagement terms with an independent Forensic Audit firm.
- Define and publish the strict operational criteria for accepting non-fungible collateral (Decision 14 Option 1 compliance).
- Publish the public risk dashboard for the $90M Contingency Fund.

**Membership:**

- Chief Compliance Officer (Chair)
- External Forensic Auditor Representative (Independent Member)
- Lead External Counsel for Regulatory Matters
- Chief Security Officer

**Decision Rights:** Authority to immediately freeze expenditure lines related to T2CA vetting or Asset Liquidation pending review, and mandate the initiation of the parallel legal submission (Option 2) if post-facto viability is deemed low by external counsel.

**Decision Mechanism:** Unanimous vote required for authorizing any halt or expenditure freeze. Other matters require a 2/3 majority. No tie-breaker; failure to reach consensus forces immediate escalation to the PESC regarding the specific compliance risk.

**Meeting Cadence:** Monthly, with ad-hoc emergency sessions required upon triggering of any security breach or major regulatory communication.

**Typical Agenda Items:**

- Review of Asset Liquidation Transaction Audit Logs
- Contingency Fund Segregation Verification and Reporting
- Status of Parallel Legal Strategy for Land Use Authorization
- T2CA Access Log Review for Conflicts of Interest

**Escalation Path:** Any finding suggesting criminal activity, material misuse of the Contingency Fund, or a catastrophic failure in AML screening must be escalated immediately and solely to the Project Executive Steering Committee (PESC) and external legal authorities.