This plan involves money.

## Currencies

- **USD:** The stated budget is $600 Million USD, making it the primary denomination for capital expenditure, procurement, and sponsor reporting.

**Primary currency:** USD

**Currency strategy:** The project is based entirely within the United States and utilizes USD exclusively for its initial $600M capital budget and subsequent planned citizen monetization. Standard US banking/fiscal reporting will be used, with no significant direct currency exchange risk exposure anticipated.