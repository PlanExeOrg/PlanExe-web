This plan involves money.

## Currencies

- **USD:** The project budget is specified in USD ($600 Million sponsors), and the location is the USA, making USD the inevitable base currency for purchasing, construction costs, and initial capitalization.

**Primary currency:** USD

**Currency strategy:** The project is entirely focused within the United States, using USD as the starting point for sponsorship acquisition and construction planning. Given the high political sensitivity and the intent to transition funding to citizen payments, USD will remain the primary currency for budgeting and reporting to maintain fiscal stability and clarity, despite the international nature of the clientele.