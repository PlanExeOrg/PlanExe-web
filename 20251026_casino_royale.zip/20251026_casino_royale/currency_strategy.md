This plan involves money.

## Currencies

- **USD:** The project budget is specified in USD.

**Primary currency:** USD

**Currency strategy:** USD will be used for all transactions. No additional international risk management is needed.