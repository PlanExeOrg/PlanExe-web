Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 0 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success requires breaking physical laws. The plan proposes a casino inside the White House, but there is no mention of how the building's structure will support the weight and vibrations of gaming equipment and crowds. The plan does not address the laws of thermodynamics related to energy consumption.

**Mitigation**: Engineering Team: Conduct a structural analysis of the White House East Wing and a detailed energy consumption study, delivering a feasibility report within 90 days.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (casino) + market (world leaders) + tech/process (security/operations in the White House) + policy (bending/breaking gambling laws) without independent evidence at comparable scale. No precedent exists for this specific combination.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates. Owner: Project Lead / Deliverable: Validation Report / Date: 180 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business‑level mechanism‑of‑action is defined for "geopolitical networking", a strategic concept driving the plan. The plan omits a one-pager with value hypotheses, success metrics, and decision hooks for this concept.

**Mitigation**: Strategy Team: Produce a one-pager defining "geopolitical networking" with a value hypothesis, success metrics, and decision hooks by EOM.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (geopolitical) is absent or minimized. The plan mentions a 'Geopolitical Fallout Management Plan' but lacks concrete details. There is no analysis of cascades.

**Mitigation**: National Security Team: Expand the risk register to include detailed geopolitical risks, map potential cascade effects, and add specific controls with a review cadence of 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions 'Regulatory Compliance' but lacks a detailed timeline for obtaining necessary permits and licenses. The plan does not include a permit/approval matrix.

**Mitigation**: Legal Team: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds, delivering it within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway or financing gates/covenants are undefined. The plan mentions securing capital through sovereign wealth funds, an NFT program, and revenue-sharing, but lacks details on their status, draw schedule, covenants, and runway length.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources, their status (LOI/term sheet/closed), draw schedule, covenants, and a NO-GO on missed financing gates within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $600 million USD conflicts with scale-appropriate benchmarks. MGM National Harbor, a similar project near D.C., cost $1.4 billion. The plan does not normalize costs per area.

**Mitigation**: Finance Team: Benchmark costs against ≥3 comparable casino projects, normalize by area (cost per m²/ft²), and adjust budget or de-scope by EOM.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because key projections are single-point estimates. The plan states a $600 million budget and a 3-year completion timeline without ranges or alternative scenarios. There is no sensitivity analysis.

**Mitigation**: Finance Team: Conduct a sensitivity analysis on the $600M budget, creating best/worst/base-case scenarios, and deliver a report within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack essential engineering artifacts such as specs, interface contracts, and acceptance tests. The plan does not provide any documentation to support the engineering depth required for the casino's construction.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states, "Partner with a reputable gaming commission to oversee the casino's operations." There is no evidence of any gaming commission agreeing to this partnership.

**Mitigation**: Project Lead: Obtain a letter of intent from a reputable gaming commission or revise the plan to remove this dependency within 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable, 'a new casino', is mentioned without specific, verifiable qualities. The plan states, "Replace the East Wing of the White House with a casino..." but does not define acceptance criteria.

**Mitigation**: Project Team: Define SMART acceptance criteria for the casino, including a KPI for guest satisfaction (e.g., average rating of 4.5 out of 5) within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a 'Temporary Casino Strategy' that does not appear to directly support the core project goals of attracting world leaders and generating revenue. The temporary casino adds complexity and cost without a clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the temporary casino, complete with a KPI, owner, and estimated cost, or else move the feature to the project backlog by EOM.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the 'High-Roller Liaison' role, but filling it requires a rare combination of skills: deep knowledge of international customs, discretion, and a network of contacts within the global elite. This role is critical for attracting high-value patrons.

**Mitigation**: HR Team: Conduct a talent market analysis for the 'High-Roller Liaison' role, assessing the availability of qualified candidates within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits critical legal and regulatory feasibility analysis. The plan states, "Ensuring full compliance with all applicable laws and regulations is crucial," but does not identify which laws apply or how compliance will be achieved.

**Mitigation**: Legal Team: Conduct a Fatal-Flaw Analysis to identify showstopper legal/regulatory issues, delivering a report with NO-GO recommendations within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a credible operational sustainability model. There is no discussion of long-term maintenance costs, technology obsolescence, or personnel succession. The plan does not address how the casino will adapt to changing conditions or manage environmental/social impacts.

**Mitigation**: Operations Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession plan, technology roadmap, and adaptation mechanisms within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence that the project satisfies hard constraints. The plan does not include zoning approvals, occupancy permits, or fire load calculations. The plan does not address noise constraints.

**Mitigation**: Engineering Team: Perform a fatal-flaw screen with authorities/experts, seek written confirmation where feasible, and define fallback designs/sites with NO-GO thresholds tied to constraint outcomes within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address external dependencies or resilience. The plan mentions securing funding from sponsors and citizen contributions, but does not discuss backup funding sources if these fail. There is no mention of SLAs with vendors.

**Mitigation**: Finance Team: Secure SLAs with key vendors and identify secondary suppliers/paths for critical resources, testing failover procedures within 120 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for 'Casino Managers' and 'Construction Manager' but does not address their conflicting incentives. Casino Managers are incentivized by revenue, while Construction Managers are incentivized by budget adherence, creating a conflict over construction quality.

**Mitigation**: Project Lead: Define a shared, measurable objective (OKR) that aligns both Casino Managers and Construction Manager on a common outcome, such as 'achieve X guest satisfaction while staying within Y budget' by EOM.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH if the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient. The plan lacks a defined review cadence, change-control process, and clear owners for KPIs.

**Mitigation**: Project Lead: Establish a monthly review meeting with a KPI dashboard, a lightweight change board, and defined thresholds for re-planning by EOM.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not assess interactions among risks. Three High risks (Regulatory & Permitting, Security, Social) are strongly coupled. Failure to obtain permits (Regulatory) can trigger public opposition (Social) and compromise security, leading to project failure.

**Mitigation**: Risk Management Team: Create an interdependency map, bow-tie analysis, and combined heatmap with owner/date and NO-GO/contingency thresholds within 90 days.