## Positive Constraints

- Replace East Wing of the white house with a casino
- World leaders can get drunk, be entertained and gamble with their resources
- Casino capacity: 999 guests
- Open 24/7
- Budget: 600 Million USD from sponsors
- Eventually have citizens pay
- East Wing has already been demolished
- Construction can begin immediately
- Phase 1: Make a temporary casino in some containers
- Phase 1 goal: Gambling can start
- Phase 2: Construct the casino
- Phase 3: Transition from the temporary casino, to the new casino
- Project start ASAP
