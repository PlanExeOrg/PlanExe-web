## Positive Constraints

- Replace East Wing of the White House with a casino
- Casino for world leaders
- Casino capacity: 999 guests
- Open 24/7
- Budget: 600 Million USD from sponsors
- Citizens will eventually pay
- Phase 1: Make a temporary casino in some containers
- Phase 2: Construct the casino
- Phase 3: Transition from the temporary casino, to the new casino
- Project start ASAP
