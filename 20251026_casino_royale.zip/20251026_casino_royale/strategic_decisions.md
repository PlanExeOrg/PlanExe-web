## Primary Decisions
The vital few decisions that have the most impact.


The five vital levers address the core strategic tensions: Funding/Risk (Sponsor Acquisition), Legal Authority (Regulatory Jurisdiction), Demand Generation (Clientele Engagement), Financial Structure (Capitalization Staging), and Political Acceptance (Reputational Risk). Collectively, they manage the high-stakes trade-offs between speed of execution, sovereign control, and political fallout inherent in operating a world-leader casino on government land.

### Decision 1: Sponsor Acquisition Strategy
**Lever ID:** `b15a39c8-13d9-4d5f-b4dd-76b4a1973e1f`

**The Core Decision:** This strategy determines the source and resulting governance structure for the critical initial $600M. Success hinges on securing capital quickly while minimizing early geopolitical binding constraints, as a state-backed focus slows intake. Key metrics involve speed of capital commitment versus the imposed level of external oversight on early operations.

**Why It Matters:** The chosen strategy to secure the initial $600 million dictates the governance structure and acceptable operational risks assumed in the early phases. Prioritizing sovereign wealth funds over private entities grants immediate capital access but subjects project execution to external geopolitical loyalties and oversight requirements. This choice directly impacts the perceived legitimacy of the facility among non-contributing nations.

**Strategic Choices:**

1. Pursue exclusive early-stage funding guaranteed by high-yield, long-term service contracts reserved solely for the initial bloc of major governmental sponsors.
2. Diversify the $600 million across a broad portfolio of international venture capital firms, accepting high dilution in exchange for rapid, low-conditionality capital injection.
3. Establish a highly selective, closed-door tender process focusing exclusively on state-backed investment vehicles from G7 nations, emphasizing verifiable national security assurances over financial terms.

**Trade-Off / Risk:** Focusing only on state-backed G7 funding creates immediate diplomatic friction and slows the initial capital intake, potentially jeopardizing the Phase 1 container startup timeline unless seed funds are secured elsewhere.

**Strategic Connections:**

**Synergy:** Synergizes with Capitalization Staging Sequence by ensuring initial funding milestones are met early, enabling accelerated progress into Phase 1 construction.

**Conflict:** Conflicts strongly with Regulatory Jurisdiction Modeling, as G7 state funding often implies adherence to established (and complex) international financial oversight norms.

**Justification:** *Critical*, This lever is critical as it resolves the initial funding gap ($600M) and establishes the foundational governance structure, directly influencing early operational speed and future geopolitical constraints.

### Decision 2: Phase 1 Viability Protocol
**Lever ID:** `ea613d03-30e2-4a96-83a3-87c801e0752f`

**The Core Decision:** Focuses on establishing immediate, low-standard revenue via the temporary container site to finance ongoing operations and initial construction milestones. Success means generating positive cash flow quickly while managing the extreme political vulnerability introduced by operating a visible casino in makeshift quarters.

**Why It Matters:** Establishing the temporary container casino (Phase 1) early allows for immediate cash flow generation necessary to offset ongoing site security costs and initiate ancillary construction payments. However, operating a high-security, visible gambling operation in makeshift quarters significantly heightens the initial political vulnerability and risks setting a low operational standard for the permanent structure.

**Strategic Choices:**

1. Limit the temporary casino functions strictly to high-stakes, private, invitation-only card games hosted within secure, converted administrative transport vehicles parked adjacent to the site.
2. Implement full slot machine and low-limit table gaming within the Phase 1 containers, advertising the 'pop-up' venue to select foreign diplomatic staff for immediate revenue seeding.
3. Use the container structure exclusively as a high-level secure briefing center and temporary operations hub, delaying all revenue-generating gambling activity until the main structure is near completion.

**Trade-Off / Risk:** Restricting Phase 1 to only high-stakes, private card games minimizes political exposure but severely underutilizes the temporary infrastructure, delaying the critical revenue stream needed for subsequent construction phases.

**Strategic Connections:**

**Synergy:** Works closely with **Interim Facility Hardening** by providing the revenue stream necessary to fund the security upgrades required for that hardening effort.

**Conflict:** Conflicts with **Reputational Risk Mitigation Layer**; implementing revenue-generating gambling (even limited) in shipping containers immediately escalates early public disapproval regarding operational standards.

**Justification:** *High*, High importance because it controls the immediate tension between needing fast, early revenue generation (Phase 1 kickoff) and the extreme political visibility risk associated with operating a makeshift casino at the site.

### Decision 3: Post-Construction Funding Transition
**Lever ID:** `c06f1b00-e04e-4611-8d64-980d70505b32`

**The Core Decision:** Defines the mechanism and criteria to shift financial responsibility from sponsors to the post-construction funding source, broadly defined as citizens. This lever manages the political risk associated with implicating domestic funding sources versus achieving pure operational self-sustainability via international clientele spending.

**Why It Matters:** The plan requires transitioning from sponsor funding to citizen payment, which necessitates defining citizens broadly—does this mean US taxpayers or global high-net-worth individuals using adjacent services? A poorly defined transition strategy risks alienating domestic political support by implicating the Treasury before sustainable operating income is demonstrated, regardless of the source definition.

**Strategic Choices:**

1. Institute a mandatory, tiered surcharge on all non-casino transactions conducted within a five-mile governmental service radius, framing it as infrastructure maintenance levy.
2. Tie the full transition to profitability directly to the percentage of high-roller winnings that are automatically repatriated to an international security stabilization fund, reducing domestic liability.
3. Immediately mandate that all federal travel and entertainment budgets include a required minimum expenditure at the facility, effectively guaranteeing a baseline revenue stream from the government sector.

**Trade-Off / Risk:** Tying transition to a stabilization fund shifts the financial focus toward external security guarantees rather than pure operational profitability, potentially exposing the project to audit by international monitoring bodies.

**Strategic Connections:**

**Synergy:** Synergizes with **Capitalization Staging Sequence** by ensuring the planned profitability targets for the final construction stages are strictly aligned with the revenue benchmarks required for fund transition.

**Conflict:** Conflicts with **Post-Construction Funding Transition**; defining domestic citizenry as the source complicates this transition by requiring domestic political buy-in for the new revenue stream.

**Justification:** *High*, This is high because it defines the long-term financial viability and manages the massive political trade-off between sponsor lock-in and securing domestic/citizen buy-in for operating costs.

### Decision 4: Regulatory Jurisdiction Modeling
**Lever ID:** `39be8c8f-25d7-42a4-8f1f-da82b89fe063`

**The Core Decision:** This lever establishes the operational legal framework, navigating conflicts between local, federal, and international gaming laws due to the unique site location. The key trade-off is accepting external oversight bodies for smooth setup versus the increased compliance burden of internalizing domestic regulations prematurely.

**Why It Matters:** Placing a casino within federal property mandates navigating deeply conflicting local, state, and federal gaming regulations, complicated by its international clientele. Establishing jurisdiction via an extraterritorial compact with a recognized international gaming authority reduces domestic legislative friction but forfeits US oversight on critical anti-money laundering controls.

**Strategic Choices:**

1. Seek immediate legislative designation of the site as a special economic zone governed entirely by a pre-existing, recognized international treaty body specializing in cross-border finance oversight.
2. Adopt the most restrictive set of regulations from the highest-compliance US jurisdiction (e.g., Nevada or New Jersey) and apply them internally, despite the lack of formal state jurisdiction.
3. Operate under a novel, temporary executive order that classifies all transactions as 'diplomatic exchanges' for the first two fiscal years, simplifying initial setup but guaranteeing severe legal challenges later.

**Trade-Off / Risk:** Applying the most restrictive US regulations unilaterally increases compliance overhead significantly in Phase 1, delaying the operational launch beyond the immediate post-demolition window provided.

**Strategic Connections:**

**Synergy:** Crucial for **Security Perimeter Redefinition**; a favorable international compact can streamline security protocols by standardizing international visitor vetting processes.

**Conflict:** Creates tension with **Interim Facility Hardening**, as establishing extraterritorial jurisdiction can conflict with the need to implement stringent, domestically controlled anti-money laundering controls on the temporary site.

**Justification:** *Critical*, Critical because it is the central hub for legal risk, determining the compliance burden needed to operate on federal land hosting international clientele, heavily impacting setup speed and security oversight.

### Decision 5: Clientele Engagement Model
**Lever ID:** `153502fe-fb4a-4fb1-8ac5-db75e4f5d468`

**The Core Decision:** This model defines how world leaders will use the casino, dictating baseline financial stability versus operational risk. The scope ranges from mandatory patronage via diplomatic fiat, which guarantees use but risks outrage, to relying solely on premium hospitality to win repeat business. Key metrics involve baseline utilization rates correlated directly to the chosen engagement mechanism.

**Why It Matters:** Defining the mandatory participation level for attending world leaders dictates the floor revenue projections for the operational phase and shapes the necessary on-site hospitality complexity. If attendance is mandatory or tied to bilateral agreements, the project secures baseline patronage but risks diplomatic backlash from leaders forced to gamble; conversely, optional attendance demands superior attraction factors to drive initial traffic.

**Strategic Choices:**

1. Mandate leadership participation by formalizing casino patronage as a required component of international summit itineraries, using diplomatic treaties to enforce compliance for initial revenue stability.
2. Treat the facility as a purely optional, invitation-only entertainment annex accessible only during bilateral meetings, relying exclusively on hospitality excellence to attract repeat engagement.
3. Establish a tiered membership structure where access levels are determined by the leader's sovereign wealth or perceived geopolitical influence, linking gambling limits directly to diplomatic rank.

**Trade-Off / Risk:** Mandatory political attendance guarantees initial volume, but conditioning diplomatic goodwill on gambling consumption creates an immediate and highly publicized diplomatic liability that shareholders will heavily scrutinize.

**Strategic Connections:**

**Synergy:** Amplifies Sponsor Acquisition Strategy by providing a clear path to securing foundational revenue commitments based on either guaranteed attendance or projected superior attraction quality.

**Conflict:** Directly clashes with Reputational Risk Mitigation Layer; mandatory attendance heightens the risk of negative global press coverage concerning gambling coercion of heads of state.

**Justification:** *Critical*, Critical as it directly dictates the baseline revenue floor and the nature of diplomatic cooperation required. It is the primary driver of the 'entertainment' aspect of the business purpose.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Reputational Risk Mitigation Layer
**Lever ID:** `0ff3d9e9-f06f-42c3-98fd-be217d7f2736`

**The Core Decision:** Involves creating a highly visible, non-monetary philanthropic mandate to absorb inevitable political backlash relating to using the East Wing location for commercial gambling. Success is measured by a quantifiable reduction in negative press coverage related to the project's perceived self-enrichment.

**Why It Matters:** Using the East Wing location for entertainment generates significant backlash regardless of security; the project must pre-emptively counter the narrative of government profiteering. Implementing a highly visible, non-monetary philanthropic mandate tied directly to the facility's function can absorb some political heat. The danger is that superficial philanthropy will be perceived as a cynical cover for illicit dealings.

**Strategic Choices:**

1. Dedicate all profits derived from games played by state actors to funding highly visible, non-controversial national infrastructure repairs outside the capital region.
2. Establish an on-site, non-public-facing research archive dedicated to diplomatic history, making all facility blueprints and operational logs available solely to certified academic historians.
3. Mandate that 50% of all hospitality service jobs be filled exclusively by individuals who have demonstrated long-term public service commitment without prior private sector experience.

**Trade-Off / Risk:** Mandating hospitality hiring based solely on public service history guarantees high levels of customer service inexperience, directly compromising the high-end hospitality management requirement for world leaders.

**Strategic Connections:**

**Synergy:** Directly enables **Clientele Engagement Model** by providing a positive, ethically justifiable narrative that world leaders can publicly support when utilizing the facility.

**Conflict:** Conflicts with **Hospitality Cadre Staffing Model**, as prioritizing public service history for hiring can directly undermine the high level of specialized, professional customer service expertise required for the clientele.

**Justification:** *High*, It's a crucial hub managing the project's core existential threat: political and public legitimacy. Success here enables successful clientele engagement, a key revenue driver for the entire plan.

### Decision 7: Capacity Management for Critical Events
**Lever ID:** `41a7fb3a-a842-4c25-82cf-b88c420ea563`

**The Core Decision:** This lever manages the non-negotiable 999-guest capacity, crucial for balancing elite security needs against projected revenue maximization. Success hinges on establishing a firm, defensible allocation policy, such as seniority-based accreditation, to prevent unplanned overruns that compromise leadership safety during major events. It directly trades off inherent revenue potential for guaranteed security assurance within the facility.

**Why It Matters:** The 999-guest capacity is a hard limit for a facility designed for high-security world leaders, forcing difficult prioritization during major global summits. Attempting to flexibly expand capacity via temporary overflow zones introduces unacceptable security gaps during peak demand periods, potentially compromising the safety requirements.

**Strategic Choices:**

1. Designate the upper structural floors as an immediate-access, crisis-response command center, ensuring that a fixed 150-person capacity is permanently held offline from commercial operation.
2. Implement a pre-emptive, seniority-based guest list accreditation system managed two years in advance by a joint diplomatic council to cap utilization at 80% during any known event overlap.
3. Utilize construction modularity to allow the casino floor area to physically expand by 25% during pre-scheduled high-demand periods, utilizing retractable, reinforced wall systems integrated into the final build.

**Trade-Off / Risk:** Reserving 150 seats for crisis response permanently sacrifices substantial revenue potential, demanding that the remaining 849 spots operate at higher margins to compensate for the fixed operational costs.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Clientele Engagement Model by determining which tiers of leaders gain access during high-demand scenarios, ensuring only top priorities are accommodated.

**Conflict:** Conflicts directly with Capitalization Staging Sequence, as permanent offline capacity reduces the realizable revenue base required to meet sponsor return expectations or citizen pay-in targets.

**Justification:** *Medium*, Important for operational integrity, but it is a secondary trade-off derived from the primary goal of attracting the right clientele (Lever 153502fe). It manages internal allocation rather than core project success factors.

### Decision 8: Capitalization Staging Sequence
**Lever ID:** `f13f0577-eae5-45f2-9782-98b534400adc`

**The Core Decision:** This governs the financial timeline, strategically sequencing sponsor commitments before shifting the burden to citizens. The goal is to secure the $600M budget rapidly while controlling external influence. A key metric is the precise timing of the citizen funding switch, balancing initial stability provided by sponsors against the political accountability introduced by public fees.

**Why It Matters:** The timing of transitioning from sponsor funding to citizen funding determines the long-term financial risk profile and the necessary public relations counter-narrative. Relying solely on foundational sponsors for the entire build shields the immediate budget from political volatility but concentrates risk with a few entities seeking eventual disproportionate operational influence; citizen fees introduce public accountability far earlier.

**Strategic Choices:**

1. Secure the entire $600 million construction budget upfront from a consortium of sovereign wealth funds willing to accept a 15-year revenue participation agreement covering all build costs.
2. Fund Phase 1 (container casino) entirely through initial sponsor deposits, while simultaneously launching an aggressive national bond initiative to cover Phase 2 construction costs.
3. Leverage the foundational sponsor commitment as collateral for immediate, low-interest government Treasury loans, repayable only after the casino achieves 80% patron utilization for three consecutive full quarters.

**Trade-Off / Risk:** Front-loading sponsor commitment resolves immediate cash flow but grants early, powerful leverage over operational design, potentially conflicting with future political interests related to citizen monetization.

**Strategic Connections:**

**Synergy:** Strongly enables Phase 1 Viability Protocol because early, secured sponsor deposits (before citizen transition) allow rapid funding for the container casino infrastructure.

**Conflict:** Creates tension with Reputational Risk Mitigation Layer, as shifting funding from private sponsors to citizens inherently signals a greater degree of local political stake and potential controversy.

**Justification:** *High*, High importance; it sequences the two primary funding sources (sponsors then citizens), governing cash flow stability and determining the exact timing of when public accountability is introduced into the project lifecycle.

### Decision 9: Interim Facility Hardening
**Lever ID:** `ab09de95-f5dc-40e9-b9c6-73a8fe84e1a5`

**The Core Decision:** This addresses the security and quality standard for the temporary container casino (Phase 1). Over-hardening the interim facility stabilizes immediate operational security but drains capital intended for the permanent build; conversely, under-investing risks staff and asset security during necessary Phase 1 operations. Success is measured by maintaining continuity across the Phase 1/Phase 3 operational handoff.

**Why It Matters:** The robustness and security profile of the Phase 1 container casino directly impact the perception of professionalism and acceptable risk during the transition. Over-engineering the temporary site adds significant upfront capital costs to the container phase and risks creating operational inertia, delaying the move to the permanent structure.

**Strategic Choices:**

1. Outfit the temporary container casino with full SCIF-compliant communication redundancy and hardened physical security measures equivalent to a permanent diplomatic bunker, mitigating immediate intelligence risks.
2. Minimize investment in the temporary facility, using only basic, easily removable barriers and standard commercial gaming equipment, accepting higher on-site security turbulence during Phase 1 operations.
3. Integrate the container structure directly into the subsurface utility network of the permanent site footprint, allowing for quicker utility transfer during the Phase 3 transition, despite potential minor construction delays.

**Trade-Off / Risk:** High security hardening of the temporary trailers ensures continuity during high-level political engagement, yet this redundant expense diverts crucial resources away from optimizing the main Phase 2 structural timelines.

**Strategic Connections:**

**Synergy:** Works directly with Interim Facility Hardening to ensure that the necessary security posture established immediately is maintained throughout the construction period, minimizing disruption.

**Conflict:** Creates a trade-off with Capitalization Staging Sequence, as significant expense in hardening the temporary site directly reduces the available capital pool for the main Phase 2 construction.

**Justification:** *Medium*, Medium importance; it primarily affects the cost balance between Phase 1 security and long-term capital, but its success is contingent on achieving the necessary revenue from Phase 1 Viability (Lever ea613d03).

### Decision 10: Structural Substitution Protocol
**Lever ID:** `0e642e29-6569-49cc-87c8-7941e14c41f0`

**The Core Decision:** This addresses the necessary engineering trade-offs stemming from repurposing the demolished East Wing's footprint for a high-load casino. Options revolve around minimizing structural remediation (modular frames) versus absolute foundational certainty (deep-pile investment). Success is judged by meeting load requirements without causing catastrophic delays due to unforeseen subsurface issues or geological assessments.

**Why It Matters:** Using the East Wing's existing physical foundations, even if demolished, for the casino structure dictates the necessary load-bearing requirements and potential subsurface archaeological impact assessments. Adapting the design to a dramatically different structural profile—from administrative offices to a high-load entertainment venue—necessitates extensive, time-consuming structural remediation under the tight government review cycle.

**Strategic Choices:**

1. Design the casino utilizing lightweight, modular steel framing above the existing foundation, accepting lower internal ceiling heights to minimize the required depth/complexity of subsurface foundational reinforcement.
2. Commission a full-depth geotechnical survey extending below the original East Wing footing, allowing for specialized deep-pile foundation replacement designed to handle triple the anticipated dynamic floor load.
3. Convert the mandate to building a completely independent, subterranean structure beneath the existing grounds, preserving the remaining surface footprint integrity for emergency government access.

**Trade-Off / Risk:** Minimizing foundation reinforcement through modular framing reduces immediate engineering complexity, but the resulting low ceiling may restrict the atmospheric grandeur required to keep high-level clientele engaged long-term.

**Strategic Connections:**

**Synergy:** Directly supports Phase 1 Viability Protocol by influencing how quickly the standardized container units can safely connect to site utilities, assuming necessary foundational work is minimally invasive.

**Conflict:** Conflicts with Capacity Management for Critical Events, as adopting lightweight framing to minimize foundation work may restrict future vertical expansion or necessary internal room heights for high-end patrons.

**Justification:** *Medium*, Medium; this is a crucial engineering trade-off impacting construction timeline versus foundational longevity, but it is subordinate to securing the funding and defining the clientele first.

### Decision 11: Operational Closure Mandate
**Lever ID:** `cefc8271-cfa3-4fae-ae82-7d233bf87dec`

**The Core Decision:** This lever dictates the casino's availability, balancing the fixed overhead risk of 24/7 operations against the maximized potential revenue of constant access. Success hinges on efficiently utilizing staff downtime for high-fidelity readiness exercises (training/simulations) rather than costly idle time, ensuring operational readiness aligns with unpredictable state visits.

**Why It Matters:** Determining the operating cadence relative to scheduled diplomatic calendars directly impacts staffing utilization and revenue potential. A 24/7 operation requires massive, fixed overhead for security and hospitality regardless of peak geopolitical activity, whereas linking hours to visiting dignitary schedules maximizes per-hour revenue but creates severe labor scheduling instability.

**Strategic Choices:**

1. Maintain the 24/7 commitment rigidly, absorbing lulls during low-diplomatic periods by running internal, classified simulations and extended staff training exercises to maintain readiness.
2. Institute a variable operational schedule that closes all public gaming floors during declared national security alerts or known G7/UN assembly periods, avoiding political interference exposure.
3. Limit initial operation hours to the standard 18:00 to 04:00 window, focusing all resources on achieving peak quality during prime evening entertainment hours before scaling up capacity commitment.

**Trade-Off / Risk:** Strict 24/7 operation guarantees constant staffing readiness, which avoids costly rapid mobilization penalties, yet it forces payroll expenditures during predictable low-traffic, mid-day governmental work cycles.

**Strategic Connections:**

**Synergy:** It directly enables Capacity Management for Critical Events by ensuring staff are always prepared, amplifying the readiness necessary for high-stakes, spontaneous diplomatic opportunities.

**Conflict:** It conflicts with Post-Construction Funding Transition by locking in high operational overhead (Payroll) prematurely, potentially straining early revenue targets which are crucial for the funding shift.

**Justification:** *Low*, Low importance as it is a tactical operational decision regarding staffing efficiency. It impacts operational overhead rather than foundational project success factors like funding or fundamental jurisdiction.

### Decision 12: Sponsor Asset Integration Scope
**Lever ID:** `5ca66383-bf4b-4ae7-bddc-f71a16ef87e0`

**The Core Decision:** This strategy defines how the immediate $600M sponsorship capital is exchanged for rights and control over future casino revenue streams or governance. Its primary goal is securing upfront capital while managing the trade-off between initial funding speed and long-term sovereign control over the asset's monetization potential.

**Why It Matters:** Binding the $600M sponsorship investment to specific, tangible assets (e.g., exclusive naming rights, control over secondary hospitality wings, or operational licensing duration) secures immediate funding but reduces future flexibility regarding operational revenue sharing. This choice determines the long-term commercial leverage held by initial backers over the government's future monetization strategy.

**Strategic Choices:**

1. Trade the first ten years of all non-casino revenue streams generated by the East Wing property exclusively to the primary financial consortium in exchange for immediate capital infusion.
2. Grant sponsors permanent, non-dilutable seats on the facility's oversight board with veto power over all vendor contracts exceeding a specific monetary threshold.
3. Structure the sponsorship as a revolving line of credit guaranteed against future tax revenue generated by legalized gambling nationwide, removing immediate political pressure for repayment.

**Trade-Off / Risk:** Trading future national tax revenue guarantees rapid upfront funding but creates a decade-long financial dependency where host nation economic stability is tied to the casino's continued operational success.

**Strategic Connections:**

**Synergy:** Strong integration scope fuels the success of Sponsor Acquisition Strategy by clearly defining the returns offered, making negotiations for high-value capital injections more attractive.

**Conflict:** Extensive integration conflicts with Post-Construction Funding Transition by potentially yielding away future revenue streams that the transition strategy intends to monetize from citizens or secondary sources.

**Justification:** *High*, High importance; this defines the financial trade-off of the initial $600M - exchanging long-term sovereign monetization rights for immediate capital infusion certainty.

### Decision 13: Security Perimeter Redefinition
**Lever ID:** `cc9d68d3-f922-4324-8ea9-5e8e3097ac25`

**The Core Decision:** This lever remodels security doctrine from protecting government infrastructure to securing a dense, transient venue for global elites, demanding novel threat assessment sharing. Success is measured by maintaining operational continuity while satisfying stringent, and potentially conflicting, demands from various attending security details.

**Why It Matters:** Altering the physical security doctrine from protecting a government office to protecting a high-value, high-traffic international entertainment venue requires fundamentally different response protocols for emergencies. This shift might necessitate collaboration with foreign intelligence agencies for VIP threat assessments, complicating existing intelligence-sharing agreements.

**Strategic Choices:**

1. Impose a triple-layered security protocol: Secret Service maintains the outer ring, a private casino security firm manages internal floor access and cash handling, and military police patrol the immediate air/ground approaches.
2. Outsource all insider threat detection and intelligence gathering to a single, pre-vetted private security contractor who reports solely to the casino’s non-governmental operational director.
3. Require all attending world leaders to relinquish all personal communication devices upon entry and utilize only provided, encrypted, facility-specific communication hardware during their stay.

**Trade-Off / Risk:** Outsourcing all insider threat detection transfers critical national security monitoring functions to a purely profit-driven entity, risking compromise if private incentives conflict with state interests.

**Strategic Connections:**

**Synergy:** Redefining the perimeter synergizes with Interim Facility Hardening by ensuring the temporary container setup immediately adopts the high-security standards required for Phase 2 construction.

**Conflict:** Complex outsourcing options conflict with Reputational Risk Mitigation Layer by introducing third-party security entities whose operational failures directly damage the government's perceived competence and control.

**Justification:** *High*, High importance because integrating foreign security protocols into a federal site is a systemic risk. It must align with Regulatory Jurisdiction (Lever 39be8c8f) to be successful.

### Decision 14: Hospitality Cadre Staffing Model
**Lever ID:** `a68a8ccd-ff3b-44d3-95f1-cd4c274d515d`

**The Core Decision:** This characterizes the sourcing and training standard for all luxury service staff, balancing the need for immediate, high-caliber international expertise against the security risks of foreign loyalties. Success means achieving world-class hospitality quality without compromising national security protocols or asset integrity.

**Why It Matters:** The choice of staffing model directly affects service quality for demanding clientele and determines the ease of rapid mobilization versus the cost of specialized, vetted personnel. Relying heavily on contracted international talent accelerates staffing but introduces significant vetting hurdles concerning loyalty and counter-intelligence risks in the sensitive environment.

**Strategic Choices:**

1. Recruit all high-touch service staff (dealers, mixologists, concierge) exclusively from established, high-security Macau and Monte Carlo operations, offering significantly above-market retention bonuses.
2. Utilize existing, security-cleared federal hospitality staff (e.g., from military bases or State Department compounds) to manage all service delivery, prioritizing political reliability over luxury experience.
3. Implement a mandatory, rapid-deployment apprenticeship program requiring all prospective service hires to complete six months of simulated high-stakes international negotiation training before floor assignment.

**Trade-Off / Risk:** Recruiting experienced staff from established jurisdictions guarantees immediate luxury service but introduces security concerns via foreign loyalties that may conflict with US state interests during sensitive diplomatic incidents.

**Strategic Connections:**

**Synergy:** A robust Staffing Model directly enhances Clientele Engagement Model by providing the expert personnel necessary to deliver the promised elite, personalized service experience.

**Conflict:** Prioritizing international recruitment for service quality conflicts with Reputational Risk Mitigation Layer, as foreign staff loyalty introduces inherent security vulnerabilities during sensitive diplomatic operations.

**Justification:** *Medium*, Medium importance as it largely supports the success of the Clientele Engagement Model (Lever 153502fe) ensuring service delivery but does not fundamentally create the revenue stream or legal authorization.
