This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *unequivocally requires* physical construction, demolition, and the operation of a physical casino. The plan *explicitly states* the demolition of the East Wing and construction of a new casino. The temporary casino also requires a physical location. This is *clearly* a physical project.