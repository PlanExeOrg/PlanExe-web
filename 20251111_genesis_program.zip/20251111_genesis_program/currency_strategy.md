This plan involves money.

## Currencies

- **USD:** The project is entirely situated within the United States, making the US Dollar the mandatory and de facto currency for local transactions, payments, and infrastructure construction.

**Primary currency:** USD

**Currency strategy:** Since the project is entirely situated within the United States, the USD will be used for all budgeting, operational costs, infrastructure development, and personnel/asset management. No international currency management is required.