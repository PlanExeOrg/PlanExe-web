## Primary Decisions
The vital few decisions that have the most impact.


The five vital levers center on establishing **legal permanence** (Constitutional Pathway), **defining the target asset** (Genetic Pool Sourcing), **setting the operational tempo** (Agency Reclamation Scope), **managing immediate physical conflict** (Child Ownership Transition), and ensuring **long-term ideological conformity** (Logistics of Rearing). Collectively, these address the core strategic tension between **Speed of Demographic Change vs. Long-Term Legitimacy and Stability**.

### Decision 1: Mandate Enforcement Velocity
**Lever ID:** `0ec33e50-f3d0-46fb-ab97-19a207fabdd9`

**The Core Decision:** Mandate Enforcement Velocity focuses on the speed of compliance with reproductive mandates, particularly targeting women aged 20 and above. Key success metrics include the rate of compliance and the efficiency of IVF processing. Rapid enforcement may signal state commitment but risks overwhelming infrastructure and data integrity during initial phases, potentially leading to civil unrest.

**Why It Matters:** Accelerating the timeline for citizen compliance, particularly for the 20-year-old cohort not yet meeting the minimum threshold, significantly increases the initial surge capacity required for mandatory IVF processing and immediate child reclamation facilities. This forces an immediate, high-cost buildout of administrative and physical infrastructure, potentially compromising data integrity during the initial wave of state acquisitions. Downstream, rapid establishment signals unwavering commitment, potentially reducing initial organized civil resistance.

**Strategic Choices:**

1. Implement a three-year phase-in period where the minimum required number of children increases linearly by one-third each year, allowing for staggered infrastructure deployment.
2. Instantly enforce the four-child mandate starting from the project launch date, immediately reclaiming all non-compliant citizens aged 20 to 40 via administrative decree.
3. Decouple enforcement from the age bracket, instead focusing initial reclamation efforts exclusively on women who have demonstrated fertility challenges or expressed prior non-compliance with smaller precursor regulations.

**Trade-Off / Risk:** Staggered enforcement smooths initial operational load but risks creating multiple, staggered waves of political opposition and organizational uncertainty over the duration of the phase-in period, delaying the demographic shift.

**Strategic Connections:**

**Synergy:** This lever amplifies the Incentivization Structure for Early Compliance by creating urgency for compliance, which can enhance the effectiveness of non-monetary rewards offered to early adopters.

**Conflict:** It conflicts with the Child Ownership Transition Management, as rapid enforcement may lead to immediate custody transfers that could provoke maternal resistance and psychological trauma, undermining compliance.

**Justification:** *High*, Crucial for achieving initial program momentum by accelerating compliance among the target age group; it directly strains (and tests) the operational capacity of custody transfer and IVF infrastructure.

### Decision 2: Genetic Pool Sourcing Strategy
**Lever ID:** `a7308f00-35f8-4f84-894c-67c18849be86`

**The Core Decision:** The Genetic Pool Sourcing Strategy determines the genetic material used for state-controlled reproduction, impacting the population's traits and societal acceptance. Success metrics include political buy-in and public perception. Prioritizing elite genetics may foster cooperation but risks alienating broader societal segments if perceived as elitist.

**Why It Matters:** The decision on which genetic material to prioritize determines the ultimate phenotypic outcome of the engineered population and directly impacts the perceived legitimacy among the elite and the general populace. Prioritizing current VIP genetics necessitates significant political buy-in from existing power structures, creating complex consent and procurement negotiations. Conversely, standardizing on synthetic profiles mitigates immediate political capture but might dilute the perceived long-term value assigned to state-owned progeny.

**Strategic Choices:**

1. Institute a lottery system for genetic donation from all currently serving elected officials and mandated cultural leaders to ensure broad elite participation and shared responsibility.
2. Exclusively utilize cryogenically preserved 'foundational' genetic samples from historical political and intellectual figures to establish a purely idealized, non-contemporary genetic baseline.
3. Limit initial sourcing strictly to verified genetic data from individuals who have already successfully demonstrated high levels of public service metrics within current state models, bypassing current political figures.

**Trade-Off / Risk:** Limiting sourcing to historical samples avoids current political friction but removes the incentive structure that might otherwise encourage cooperation from living elites who see their lineage perpetuated.

**Strategic Connections:**

**Synergy:** This lever supports the Constitutional Re-engineering Pathway by providing a scientifically backed rationale for the reproductive mandates, potentially easing legal challenges based on public support for the genetic strategy.

**Conflict:** It may conflict with the Mandate Enforcement Velocity, as prioritizing elite genetics could slow down the immediate implementation of reproductive mandates due to the need for complex negotiations with current power structures.

**Justification:** *Critical*, This lever dictates the foundational long-term goal—the composition of the engineered population. It controls legitimacy among elites and defines the quality/value metrics of the state's human capital assets.

### Decision 3: Child Ownership Transition Management
**Lever ID:** `eb87ad85-d42c-40d8-9531-9b1837b755a8`

**The Core Decision:** Child Ownership Transition Management outlines the process for transferring custody of newborns to the state, directly affecting maternal compliance and emotional responses. Key metrics include compliance rates and psychological impact assessments. Immediate transfers may streamline operations but risk creating resistance among mothers due to attachment issues.

**Why It Matters:** The protocol for transferring custody immediately post-birth dictates the initial relationship between the biological mother and the state's custodial system, directly influencing compliance stability. A fully immediate transfer minimizes maternal attachment but maximizes psychological trauma and the initial adversarial stance of the mother, potentially leading to active resistance or sabotage of medical compliance. A buffered handover period demands significant short-term medical staffing to manage dual custody scenarios.

**Strategic Choices:**

1. Institute a mandatory 72-hour neonatal incubation period within the birthing facility, supervised jointly by medical staff and immediate pre-assigned state guardians before transfer of legal ownership.
2. Enforce immediate, non-negotiable transfer of physical custody within thirty minutes of documented live birth, utilizing specialized, unemotional administrative retrieval teams at the point of delivery.
3. Pilot a system where biological mothers are administratively designated as temporary, non-biological 'Wet Nurses' for the first six weeks, reporting directly to a state overseer but with no parental rights.

**Trade-Off / Risk:** Joint custody during the initial 72 hours unnecessarily complicates the legal transfer of ownership and risks creating attachment phenomena that the ensuing administrative system is designed to prevent.

**Strategic Connections:**

**Synergy:** This lever enhances the Mandate Enforcement Velocity by ensuring that custody transitions are efficient, which can help maintain the momentum of compliance efforts during the initial phases of the project.

**Conflict:** It conflicts with the Incentivization Structure for Early Compliance, as immediate custody transfers may negate any perceived benefits of compliance, leading to resentment and resistance among mothers.

**Justification:** *High*, Governs the most contentious physical act—child seizure. Its configuration determines the immediate level of maternal resistance, directly impacting the operational safety and stability of the enforcement phase.

### Decision 4: Constitutional Re-engineering Pathway
**Lever ID:** `b97e33c1-b2ed-44d5-a4e4-a06adb531790`

**The Core Decision:** The Constitutional Re-engineering Pathway focuses on the legal mechanisms for implementing reproductive mandates, balancing speed and long-term stability. Success metrics include the speed of enactment and resilience against legal challenges. Quick legislative actions may provide immediate enforcement but risk future invalidation, while slower processes ensure judicial oversight.

**Why It Matters:** The chosen mechanism for enshrining reproductive mandates determines the speed of legal stability versus the long-term viability against future legal challenges. Legislating via emergency wartime powers provides immediate enforceability but carries the highest risk of rapid invalidation once the perceived crisis subsides. Bypassing the judiciary entirely through a direct referendum locks in the change faster than traditional amendment processes, but alienates judicial oversight bodies critical for administrative function.

**Strategic Choices:**

1. Declare a State of Immediate Demographic Emergency, utilizing executive order to circumvent existing constitutional hurdles for a period of ten years, forcing system integration.
2. Initiate a full Article V convention process focused solely on ratifying the 'Civic Duty of Reproduction' amendment, accepting the multi-year legislative timetable and anticipated legal delays.
3. Immediately rewrite the foundational civil code to redefine 'parental rights' as a revocable state utility, enforcing the change through administrative fiat rather than direct constitutional modification.

**Trade-Off / Risk:** Relying solely on administrative fiat to redefine parental rights risks empowering judicial review to dismantle the entire structure based on procedural overreach within the administrative code.

**Strategic Connections:**

**Synergy:** This lever is supported by the Genetic Pool Sourcing Strategy, as a well-defined genetic strategy can provide a strong legal foundation for the reproductive mandates, enhancing their legitimacy.

**Conflict:** It may conflict with the Mandate Enforcement Velocity, as rapid legal changes could lead to backlash and challenges that undermine the enforcement of reproductive mandates.

**Justification:** *Critical*, This is the foundational lever for long-term viability. The chosen legal mechanism determines whether the mandate survives sustained judicial review or collapses upon political shifts.

### Decision 5: Female Citizen Reproductive Agency Reclamation Scope
**Lever ID:** `78f96397-602c-435e-8da8-79a67ed1bac1`

**The Core Decision:** This defines the exact legal trigger for seizing reproductive agency, balancing speed of demographic capture against immediate logistical strain. Lowering the age (e.g., to 18) maximizes the entry pool but requires immediate, massive scaling of Child Ownership Transition Management facilities. Its core function is setting the operational tempo for the entire reproductive mandate, focusing intensity on the prime reproductive segment of the female population.

**Why It Matters:** Defining the specific age and non-compliance markers that trigger immediate state reclamation dictates the level of internal resistance and the necessary scale of the enforcement apparatus. Expanding the scope to younger ages (e.g., 18 instead of 20) reduces the window for personal choice but increases the immediate burden on state childcare infrastructure by front-loading early cohorts. Conversely, delaying the cutoff might see fewer citizens entering compulsory IVF but preserves latent capacity for self-correction.

**Strategic Choices:**

1. Lower the threshold for state reclamation to females aged 18 who have not secured an official preliminary pregnancy registration, accelerating the capture of the prime reproductive demographic.
2. Maintain the age 20 threshold but introduce tiered punitive measures for non-compliant citizens between 20 and 30 before initiating full reclamation procedures.
3. Establish an opt-out program for citizens older than 35 who have already completed the four-child mandate, guaranteeing them permanent exemption from further demographic targeting.

**Trade-Off / Risk:** Lowering the reclamation age accelerates compliance targets but immediately strains nascent state custody mechanisms, potentially degrading the quality of life for the first generation of re-prioritized infants.

**Strategic Connections:**

**Synergy:** Synergizes strongly with Mandate Enforcement Velocity, as a lower reclamation age requires authorities to act faster and with greater organizational readiness to capture compliance.

**Conflict:** It directly conflicts with the Logistics of State Child Rearing Consolidation, where lowering the reclamation age immediately overcrowds nascent state-run facilities before infrastructure is optimized.

**Justification:** *Critical*, Setting the enforcement threshold defines the initial pipeline size and tempo of the entire project; this is the primary control point for resource loading and immediate impact measurement.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Incentivization Structure for Early Compliance
**Lever ID:** `2555cf85-34d8-4b36-bda9-6527c4424f07`

**The Core Decision:** The Incentivization Structure for Early Compliance aims to encourage compliance through non-monetary rewards, focusing on social benefits rather than financial incentives. Key metrics include early compliance rates and social cohesion. While it can drive initial adoption, it risks creating divisions among compliant and non-compliant citizens if not managed carefully.

**Why It Matters:** Developing non-monetary rewards for meeting early benchmarks (e.g., one child by age 25) can drive initial adoption rates without immediate fiscal strain, but these perceived 'privileges' must be substantial enough to outweigh the loss of bodily autonomy. Offering enhanced resource allocation to the mother's immediate family unit risks creating social stratification where non-compliant groups feel explicitly punished rather than merely excluded.

**Strategic Choices:**

1. Grant full, life-long exemption from mandatory public service assignments for any woman who achieves the four-child mandate five years ahead of the age 40 deadline.
2. Establish a tiered system where the first child born before age 22 allows the mother to retain custody until the age of majority, serving as a temporary custodial incentive.
3. Offer 'Civic Priority Status' granting beneficiaries preferential access to housing, travel permits, and non-essential state resources until the birth quota is met, independent of the child's status.

**Trade-Off / Risk:** Granting custodial exemptions for early compliance creates a dangerous internal precedent where control is ceded temporarily, complicating the required eventual total state ownership of the progeny.

**Strategic Connections:**

**Synergy:** This lever works in synergy with the Mandate Enforcement Velocity by creating a supportive environment for compliance, enhancing the urgency and appeal of early compliance incentives.

**Conflict:** It conflicts with the Child Ownership Transition Management, as offering custodial incentives may complicate the state's goal of total ownership over progeny, potentially leading to legal and social challenges.

**Justification:** *Medium*, Important for smoothing the initial adoption curve, but secondary to the core mechanisms of enforcement and legal sustainability; it primarily manages internal social tension rather than systemic structure.

### Decision 7: Logistics of State Child Rearing Consolidation
**Lever ID:** `1c65aab3-9116-44f7-8f96-a716fe994edc`

**The Core Decision:** This lever models the physical infrastructure required for raising state-acquired children, directly shaping the state's ideological projection and resource partitioning. Success hinges on balancing centralization for ideological uniformity against decentralization for risk mitigation. Key metrics include per-child ideological fidelity scores and operational overhead costs per cohort. The chosen structure fundamentally determines the scalability of the human capital management aspect of the project.

**Why It Matters:** The structure chosen for housing and educating state children dictates the effectiveness of the mandated genetic engineering outcome and the required real estate footprint. Centralizing all children in massive, purpose-built National Nurturing Academies ensures uniform ideological conditioning but maximizes the impact of any single contagion event or security breach. Distributing children to localized, specialized regional centers decentralizes risk but introduces unavoidable variance in ideological messaging and resource quality.

**Strategic Choices:**

1. Immediately repurpose existing underutilized federal military training grounds into single, massive, self-contained residential cohorts optimized for high-volume, standardized ideological instruction.
2. Develop a 'Hub-and-Spoke' model where specialized genetic conditioning occurs only at three geographically separated primary centers, with day-to-day maintenance handled by local, contracted administrative units.
3. Sell off or lease existing underutilized educational infrastructure to private/non-profit entities under strict curriculum charter, focusing state resources only on high-security genetic labs.

**Trade-Off / Risk:** Contracting curriculum delivery to external entities introduces unpredictable alignment drift from the core state ideology, potentially undermining the long-term homogeneity of the engineered population.

**Strategic Connections:**

**Synergy:** This lever greatly benefits from the Genetic Pool Sourcing Strategy by creating large, purpose-built environments necessary to house and process standardized genetic cohorts efficiently.

**Conflict:** It conflicts with the Economic Integration of Non-Compliant Citizens, as massive state resource allocation here reduces the capital available for compensating or otherwise managing citizens who resist mandates.

**Justification:** *High*, It determines the effectiveness of ideological conditioning and the physical footprint of state control over the resulting progeny, directly impacting the long-term success of human capital engineering.

### Decision 8: Gender Ratio Calibration Mechanism
**Lever ID:** `253e2710-d22e-4fef-813e-9bbd667146fa`

**The Core Decision:** This lever controls the specific means by which the 75%/25% gender ratio is met, impacting both genetic quality selection and public controversy levels. Precision requires high-cost IVF technology dependence, while incentive-based approaches risk poor adherence to the exact ratio. Its success dictates how specialized the state's subsequent housing and social structuring must be for the resulting cohorts.

**Why It Matters:** Since the 75% female/25% male target necessitates active suppression of male births, the method used significantly impacts the genetic pool and subsequent societal structure pressures. Over-reliance on selective IVF technology introduces high resource strain per required outcome, whereas prioritizing male designation through mandatory selective abortion introduces profound ethical visibility challenges. Adjusting the target ratio slightly upward on males could ease resource allocation pressures in state management of the smaller cohort.

**Strategic Choices:**

1. Technologically enforce a stringent 3:1 female-to-male birth ratio at every maternity center using advanced gamete manipulation techniques to meet the demographic quota precisely.
2. Abandon artificial gender suppression and instead focus state resources on massively scaling the infrastructure necessary to support a 50/50 natural birth split, accepting demographic divergence.
3. Implement a tiered incentive system rewarding compliance with pregnancies resulting in female offspring during the initial mandatory phase, transitioning to a natural ratio post-mandate fulfillment.

**Trade-Off / Risk:** Enforcing strict technology-driven gender ratios locks the project into high initial expenditures and dependence on complex IVF processes, unlike leveraging social incentives for natural alignment.

**Strategic Connections:**

**Synergy:** It strongly amplifies the Genetic Pool Sourcing Strategy by enabling precise selection of parent demographics for the desired gender outcome during the reproductive process.

**Conflict:** This mechanism necessitates significant regulatory oversight, potentially leading to friction with the Enforcement Jurisdictional Sovereignty by requiring specialized technical mandates over purely civil law enforcement.

**Justification:** *High*, This selection directly manages the technological dependency (IVF complexity) and establishes the necessary specialization required for the subsequent state child-rearing logistics.

### Decision 9: Enforcement Jurisdictional Sovereignty
**Lever ID:** `709e8ee1-c8c6-4040-92b4-4be37abe7293`

**The Core Decision:** This determines the organizational architecture for mandate oversight and penalty application, directly affecting coherence versus agility across the nation. Centralization ensures uniformity in applying mandatory childbirth laws, which is critical for a politically sensitive mandate. Success is measured by the consistency of punitive action and the speed of response to localized compliance failures across all regions.

**Why It Matters:** Determining whether compliance monitoring and punitive actions fall under centralized federal oversight or decentralized regional administrative courts influences response speed and proportionality. Centralization ensures uniform application of the mandates across all regions, preventing jurisdictional shopping, but creates critical single points of failure susceptible to nationwide disruption or ideological drift at the top. Decentralization allows for regional adaptation to local biological variances but risks inconsistent application of mandatory penalties.

**Strategic Choices:**

1. Establish a single, super-agency with explicit constitutional authority to override all local health and administrative boards concerning reproductive compliance monitoring and enforcement actions.
2. Delegate primary enforcement and penal arbitration exclusively to geographically defined regional administrative courts, allowing bespoke interpretations of the four-child mandate's penalties.
3. Create a federated oversight model where the central authority sets maximum and minimum compliance tolerances, leaving the actual monitoring and first-level enforcement to local military governance structures.

**Trade-Off / Risk:** Centralizing sovereignty guarantees mandate uniformity but creates an immense governance complexity susceptible to slow bureaucratic response times when localized biological crises emerge.

**Strategic Connections:**

**Synergy:** It provides the operational framework necessary to effectively deploy the Mandate Enforcement Velocity, ensuring consistent legal backing regardless of regional location.

**Conflict:** Centralizing sovereignty constrains the Gender Ratio Calibration Mechanism by making it harder for regional hubs to adopt localized, low-tech solutions to meet skewed demographic targets.

**Justification:** *Medium*, This is an organizational structure lever. While important for consistency, its impact is mostly realized through how effectively it supports the critical levers like Velocity and Agency Reclamation Scope.

### Decision 10: Cadre Selection for Initial State Reclamation Operations
**Lever ID:** `f2ff8b8c-e95e-476f-8a22-63daf39fcdff`

**The Core Decision:** This addresses the composition of the initial force tasked with seizing reproductive control and children. Selecting zealots ensures immediate, ruthless adherence to the new laws but risks high-profile, incompetence-driven failures that undermine political legitimacy. Competency in administrative handling of child assets is traded against unwavering conviction required for initial systemic breaches of personal liberty.

**Why It Matters:** Selecting high-ideology but low-experience administrators for initial child seizure and relocation guarantees zealous enforcement of the letter of the law. This initial purity, however, risks catastrophic logistical errors in custody documentation and immediate high-profile public failures that could galvanize early opposition nationwide. The trade-off is immediate, strict adherence versus operational competence in the early crucial months.

**Strategic Choices:**

1. Recruit solely from newly formed, hyper-loyalist enforcement militias vetted for absolute ideological purity, bypassing established civil service structures entirely.
2. Task existing, experienced Family Services personnel with mandatory re-training and background checks, integrating the new mandates slowly into proven bureaucratic workflows.
3. Employ predictive modeling based on historical compliance data to identify and preemptively assign high-capacity, politically neutral career bureaucrats to oversee the transition.

**Trade-Off / Risk:** Using ideologically pure but inexperienced cadres prioritizes loyalty over competency, risking immediate public relations disasters that could undermine broad acceptance necessary for long-term enforcement sustainability.

**Strategic Connections:**

**Synergy:** This selection directly impacts the initial success of the Cadre Selection for Initial State Reclamation Operations, ensuring the first wave of seizures aligns perfectly with the Public Justification Narrative Framing.

**Conflict:** Using ideologically pure cadres conflicts with Constitutional Re-engineering Pathway, as their inexperience may lead to legal overreach or procedural mistakes requiring immediate high-level judicial intervention.

**Justification:** *Medium*, Crucial for initial execution quality; however, operational competence failures ($\text{Medium}$) are typically recoverable if the underlying legal structure and enforcement velocity are well-calibrated ($\text{Critical}$). They are tactical executors of strategy.

### Decision 11: Economic Integration of Non-Compliant Citizens
**Lever ID:** `2d0be03b-5182-478c-aa4d-c9ed24957053`

**The Core Decision:** This lever focuses on leveraging economic coercion against citizens failing to meet the mandatory reproductive quotas. Its primary scope is establishing financial deterrents, such as asset forfeiture or access restriction, to fund the state's demographic goals. Success is measured by the direct flow of funds/labor derived from non-compliant groups bolstering enforcement infrastructure, while minimizing parallel black-market activity.

**Why It Matters:** Implementing severe economic penalties, such as denial of public services access or progressive taxation on assets, directly finances the state's reproductive infrastructure through the non-compliant sectors. This approach risks catalyzing black-market resistance networks focused on bypassing financial monitoring, thereby creating an enforcement blind spot for tracking taxable productivity.

**Strategic Choices:**

1. Establish a parallel, tracked digital currency system for all citizens of non-compliant reproductive status, severing access to core national banking services.
2. Assign mandatory, non-transferable civic labor quotas as the sole means of avoiding direct asset forfeiture if the reproductive mandate is missed by age 35.
3. Offer significant tax abatement and housing priority to citizens who exceed the minimum four-child mandate significantly, creating a competitive advantage for 'over-producers'.

**Trade-Off / Risk:** Using direct financial leverage funds enforcement swiftly, but creating a parallel economy for non-compliers fosters untaxable, underground support systems that complicate centralized tracking and loyalty assessments.

**Strategic Connections:**

**Synergy:** Amplifies Mandate Enforcement Velocity by providing the necessary financial resources for swift deployment and sustained monitoring, bolstering the overall system's operational budget.

**Conflict:** Conflicts with Economic Integration of Non-Compliant Citizens, as aggressive financial penalties risk creating untracked, illegal support networks that undermine state oversight and tax collection.

**Justification:** *Medium*, A key resource generation and secondary control mechanism. It finances the administration but does not define the core mandate's purpose or legal basis, making it subordinate to structure and enforcement timing.

### Decision 12: Public Justification Narrative Framing
**Lever ID:** `65d1886d-630e-447c-866c-a66a5a0fcde1`

**The Core Decision:** This mechanism manages public perception by controlling the official discourse around involuntary reproduction, framing it as essential civic duty, demographic salvation, or existential necessity. Key metrics involve maintaining high reported levels of public trust and compliance rates without inducing widespread cognitive dissonance or cynicism regarding manufactured threats or appeals to abstract duty over personal rights.

**Why It Matters:** Framing the mandate solely as a matter of existential national survival (external threat model) can secure rapid, short-term compliance based on fear and duty. Sustaining this narrative over decades requires continuous invention of new, credible external threats, risking eventual cynicism when the initial crisis fades or manufacturing evidence of threats becomes too conspicuous.

**Strategic Choices:**

1. Center the public discourse exclusively on the sacred, historical duty of maintaining national biological continuity, appealing directly to conservative cultural instincts.
2. Present the mandate as the only rational, data-driven solution to an irreversible demographic collapse, using scientific language to de-politicize the bodily enforcement.
3. Develop complex, state-sponsored fictional narratives where the current generation spiritually sacrifices for a far-future, glorious hyper-nation achieved through genetic planning.

**Trade-Off / Risk:** Appealing to existential fear drives immediate compliance but requires constant escalation of declared threats, potentially leading to long-term public exhaustion and disbelief in official narratives.

**Strategic Connections:**

**Synergy:** Directly enables Constitutional Re-engineering Pathway and Female Citizen Reproductive Agency Reclamation Scope by providing the ethical pretext necessary for political acceptance.

**Conflict:** May undermine Incentivization Structure for Early Compliance if the narrative focuses solely on punitive duty rather than rewarding proactive biological contributions, leading to apathy.

**Justification:** *High*, The narrative provides the necessary political oxygen for the whole project, directly enabling the 'Constitutional Re-engineering' and ensuring public tolerance for the harsh 'Agency Reclamation'.
