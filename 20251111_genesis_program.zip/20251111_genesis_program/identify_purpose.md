**Purpose:** business

**Purpose Detailed:** Large-scale societal and governmental initiative involving mandatory public welfare, demographic engineering, and state-controlled resource (human capital) management.

**Topic:** Mandatory state-controlled reproduction to address declining birth rates and engineer specific population demographics.