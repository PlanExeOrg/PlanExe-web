**Primary domain:** Demographic Engineering

**Secondary domains:** Constitutional Law, Bioethics, Reproductive Law

**Rationale:** Demographic Engineering is the primary outcome, as the project's main success criterion is achieving the mandated population split and birth rate. While Eugenics and Societal Planning are strong outcome candidates, Demographic Engineering most precisely names this specific large-scale societal restructuring.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Demographic Engineering | 5 | 5 | outcome | The core project goal is intentionally engineering the population's gender ratio and birth rate. |
| Reproductive Law | 5 | 5 | constraint | This law dictates mandatory childbearing and state control over reproduction. |
| Eugenics | 5 | 5 | outcome | The project specifically dictates desired genetic outcomes and population traits. |
| Constitutional Law | 5 | 4 | constraint | Mandating citizen behavior regarding reproduction requires fundamental legal restructuring. |
| Bioethics | 4 | 4 | constraint | State control over genetics, IVF, and child ownership raises profound ethical dilemmas. |
| Societal Planning | 4 | 4 | outcome | The core goal is to manage and engineer the entire national population structure. |
| Public Health Policy | 4 | 4 | method | Mandating reproduction is a massive public health and welfare intervention. |
| State Governance | 5 | 3 | stakeholder | The state is the central actor enforcing all mandates and claiming ownership. |
| Administrative Law | 4 | 3 | constraint | Enforcement of legal mandates and state reclamation of citizens requires administrative frameworks. |