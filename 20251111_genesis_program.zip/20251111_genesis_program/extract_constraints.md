## Positive Constraints

- Reframing reproduction as a non-negotiable civic duty
- Every female citizen legally mandated to bear a minimum of four children by age 40
- Desired population split: 75% female, 25% male
- Female citizens reaching 20 without a child become state reclamation candidates for IVF
- Children immediately taken after birth and become property of the state
- Genes for reproduction derived from presidents and VIPs
- Project start ASAP
