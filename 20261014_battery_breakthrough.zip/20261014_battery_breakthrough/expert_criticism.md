# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Advanced Materials Electrochemist

**Knowledge**: Lithium-metal anodes, solid-state electrolytes, sulfur and conversion cathodes, interfacial degradation mechanisms, cycle-life testing protocols

**Why**: The programme's core technical path hinges on Chemistry Pathway Commitment and Electrolyte and Interface Architecture decisions. An electrochemist can validate whether the staged tournament's three chemistries (Li-S, anode-free solid-state, conversion cathode) are physically realistic for reaching 500 Wh/kg and 1000 Wh/L, and whether cycle-life thresholds (≥300 cycles at 80%) are achievable without fundamental interface engineering breakthroughs still unknown.

**What**: Review the material-level projections and cell-level mass-and-volume model (due Month 4, 2027-02-14) for each chemistry candidate; flag which candidates have credible pathways to both Wh/kg and Wh/L targets and which are likely to fail volumetric density despite gravimetric success. Validate the cycle-life gate (≥300 cycles) as realistic or propose alternative degradation mechanisms that might collapse cycle life late.

**Skills**: Cell assembly and testing, operando diagnostics (X-ray diffraction, electrochemical impedance spectroscopy), post-mortem failure forensics, lithium-metal plating reversibility, electrolyte stability at high voltage, safety threshold estimation (thermal runaway onset)

**Search**: solid-state battery materials scientist, lithium-metal anode interface, electrolyte degradation cycle life

## 1.1 Primary Actions

- By Month 3 (2027-01-14), finalize the cycle-life gate definition in writing: specify fade rate floor (<0.20%/cycle, proposed), voltage hysteresis envelope (<50 mV, proposed), and mandatory post-mortem forensics (SEM, EDS, electrochemical impedance spectroscopy) as part of gate passage. Link all cycle-life data to operando X-ray diffraction snapshots at cycles 1, 10, 50 and 100 to confirm lithium-plating reversibility (anodes) or structural stability (cathodes).
- By Month 4 (2027-02-14), enhance the mass-and-volume cell model to include chemistry-specific swelling factors (sulfur cathodes +25% volume; anode-free/lithium-metal anodes +50% thickness per plating cycle; separator compression <10% under stack pressure). Build a time-dependent volumetric projection: initial cell >=1000 Wh/L at cycle 1 → cycles 50, 100. Flag any chemistry where Wh/L drops below 950 by cycle 100.
- By Month 8 (2027-06-14), establish abuse-test calibration by running coin-cell differential scanning calorimetry AND adiabatic calorimetry AND nail-penetration tests on all three active chemistries in parallel. Document the offset between differential scanning calorimetry onset and adiabatic onset; flag chemistries with offset >60 °C as higher risk. Require finalists to achieve >=140 °C adiabatic onset (not just 120 °C differential scanning calorimetry) by Month 12 (2027-10-14).
- By Month 12 (2027-10-14), measure volumetric change ex situ on coin cells: measure swelling on 3 cells per chemistry pre-cycle and post-cycles 1, 10, 50, 100. If total volume change >30%, execute separator-thickness reduction sprint (thin to 20 μm with porosity mapping) or electrolyte-volume reduction (from 1.2 mL/Ah to 0.8 mL/Ah with wettability screening) before Month 24 (2028-10-14) pouch-cell builds.
- By Month 24 (2028-10-14), require all chemistry candidates advancing to final pouch-cell stage to provide measured volumetric-density data at cycles 1, 50 and 100 on coin cells; ensure the mass-and-volume model is updated quarterly and reconciled against measured data monthly. Publish Wh/kg and Wh/L reconciliation report; if any discrepancy >10%, trigger design investigation within 2 weeks.

## 1.2 Secondary Actions

- Establish operando X-ray diffraction beamtime agreements with at least one synchrotron facility (Advanced Photon Source, SSRL or equivalent) by Month 6 (2027-04-14); negotiate 10–20 dedicated cell-cycling experiments per chemistry (estimate 40 total across all candidates) to track lithium-plating reversibility and cathode structural changes in real time. Budget USD 150–300 K for beamtime and sample preparation.
- Hire a quantitative electrochemistry specialist with 5+ years experience in lithium-metal plating diagnostics (operando techniques, coulometry, electrochemical impedance spectroscopy) by Month 2 (2026-12-14) to design and oversee the cycle-life forensics protocol and interpret anode reversibility data.
- Commission in-house scanning-electron microscopy with energy-dispersive X-ray spectroscopy capability (USD 2–3 M capital, proposed) by Month 8 (2027-06-14) rather than deferring to Month 12 (2027-10-14), to enable 48-hour post-mortem turnaround on every failed cell and rapid feedback to design teams. Assign 0.5 FTE dedicated microscopist.
- Develop a quantitative swelling-correction algorithm for the mass-and-volume model by Month 6 (2027-04-14) using published molar-volume data for all active materials (sulfur, lithium compounds, layered oxides, conversion products); validate against in-house caliper and gravimetric measurements on coin cells to build a site-specific calibration curve.
- By Month 18 (2028-04-14), publish an internal thermal-abuse correlation atlas linking differential scanning calorimetry, adiabatic calorimetry, nail-penetration and short-circuit test results for all three active chemistries; include confidence intervals and uncertainty bounds. Use this atlas to predict pouch-cell thermal behavior and justify any exceptions to the >=140 °C adiabatic onset (proposed) rule.

## 1.3 Follow Up Consultation


Recommend scheduling a detailed consultation by Month 1.5 (2026-11-29) to review: (1) coin-cell differential scanning calorimetry, adiabatic calorimetry and electrochemical impedance spectroscopy protocols with the chemistry leads to ensure calibration; (2) the draft mass-and-volume model assumptions with the cell engineering lead, particularly swelling factors and separator thickness trade-offs; (3) operando X-ray diffraction beamtime strategy and timeline with the characterization lead. Follow-up at Month 10 (2027-08-14) to review Month 9 (2027-07-14) external abuse-test results against the established differential scanning calorimetry-to-adiabatic correlation and decide on thermal-safety deprioritizations before the Month 12 (2027-10-14) review. Third review at Month 30 (2029-04-14) to interpret third-party pouch-cell volumetric data against the time-dependent model and confirm that late-cycle swelling does not degrade the 950 Wh/L interim target below acceptance.


## 1.4.A Issue - Cycle-life threshold lacks quantitative mechanism and may not prevent low-utility cells

The >=300 cycles at 80% retention gate is stated but lacks defined degradation mechanisms. A cell could hit 300 cycles while exhibiting steady 0.27%/cycle fade (80% at cycle 300) versus another at 0.10%/cycle (98% at cycle 300). Without specifying acceptable fade rate, voltage hysteresis envelope, or Coulombic efficiency floor, the gate admits cells mechanically viable but electrochemically unsuitable for real-world duty. Operando X-ray diffraction or electrochemical impedance spectroscopy data must be linked to the gate.

### 1.4.B Tags

- cycle-life-definition
- fade-rate-unspecified
- gate-ambiguity
- validation-incomplete

### 1.4.C Mitigation

By Month 3 (2027-01-14), define cycle-life gate with three components: (1) minimum fade rate <0.20%/cycle (no worse than 95% at cycle 500); (2) voltage hysteresis <50 mV from cycle 100 to cycle 300, measured at 50% state of charge; (3) post-mortem forensics mandatory—every cell reaching gate must have SEM and EDS mapping published. Reserve chemistries must provide electrochemical impedance spectroscopy at cycle 10, 100, 250 and 350 to distinguish interface growth from lithium-ion loss. Couple gate passage to operando X-ray diffraction snapshots at cycles 1, 10, 50 and 100 on at least 2 cells per chemistry to confirm lithium-plating reversibility (for anodes) or structural stability (for cathodes).

### 1.4.D Consequence

Without mechanism-linked gates, a chemistry may pass the 300-cycle number while hiding poor Coulombic efficiency (85% instead of 98%), high voltage hysteresis (100 mV+), or irreversible lithium-ion depletion. At Month 24 (2028-10-14), when pouch cells are built and cycled at C/10, these chemistries fail under real conditions, forcing costly redesign or deprioritization. Late discovery at Month 30 (2029-04-14) third-party testing wastes 4–6 months and USD 5–10 M.

### 1.4.E Root Cause

The plan defines cycle count without specifying the failure modes that consume cycles. Lithium-sulfur cells often show polysulfide dissolution (capacity fade, reversible with additive) versus dendrite growth (hard short, irreversible). Different failure modes require different mitigation and signal different degrees of interface stability. Grouping all under '80% retention' masks the root cause and prevents targeted redesign.

## 1.5.A Issue - Volumetric density (1000 Wh/L) requires explicit dead-reckoning model and separator-swelling contingency not yet present

The plan sets an interim >=950 Wh/L gate and final >=1000 Wh/L but does not account for separator swelling, electrolyte expansion or porosity loss under charge-discharge cycles. Lithium-sulfur cathodes swell 20–30% volume on discharge (sulfur → lithium sulfide); anode-free and lithium-metal anodes exhibit 40–60% anode thickness change per cycle. The mass-and-volume model (Month 4, 2027-02-14) lacks provisioned swelling factors. A cell meeting 1000 Wh/L at cycle 1 may drop to 850–900 Wh/L by cycle 100 due to structural relaxation and electrolyte uptake. The plan risks meeting the letter of the goal at initial test but failing practical range or energy density.

### 1.5.B Tags

- volumetric-density-penalty
- swelling-unaccounted
- separator-thickness-risk
- cycle-dependent-density

### 1.5.C Mitigation

By Month 4 (2027-02-14), enhance the mass-and-volume model with (1) chemistry-specific swelling factors: sulfur cathodes +25% volume on first lithiation; anode-free or lithium-metal anodes +50% thickness per plating-stripping cycle (cumulative); separator compression <10% under stack pressure (document pressure architecture, e.g., 5–10 atm, proposed). (2) Build a time-dependent volumetric model: initial cell ≥1000 Wh/L → cycle 1, 50, 100; flag any chemistry where Wh/L drops below 950 by cycle 100. (3) By Month 12 (2027-10-14), measure volumetric change ex situ on coin cells: weigh and caliper-measure 3 cells per chemistry pre-cycle and post-cycles 1, 10, 50, 100; report swelling %; if >30% total volume change, trigger separator thickness reduction sprint (thin to 20 μm with porosity mapping) or electrolyte-volume reduction (from 1.2 mL/Ah to 0.8 mL/Ah with wettability screening).

### 1.5.D Consequence

If the team meets 1000 Wh/L at Month 30 (2029-04-14) first-cycle testing but does not measure cycle-100 volumetric change, the final pouch-pack geometry may exceed target volume once swelling is included. Licensees or end users will report 15–25% lower delivered energy density than promised. At Month 48 (2030-10-14) or later, when packs are built for application partners, the discrepancy becomes apparent and destroys credibility. Alternatively, avoiding swelling requires thinner separators (safety risk, higher dendrite penetration probability) or lower electrolyte fill (lithium-ion transport risk, higher impedance)—trades that are not yet quantified in the plan.

### 1.5.E Root Cause

The cell-level mass-and-volume model assumes static material densities and geometry. High-energy chemistries (lithium-sulfur, conversion cathodes) exhibit large molar-volume changes on lithiation. Sulfur (density 2.07 g/cm³) → Li₂S (density 1.63 g/cm³) is a 21% volume increase; lithium metal (density 0.53 g/cm³) anode growth from 50 μm bare to 150+ μm after plating and stripping cycles adds 100 μm × 1.3 g/cm³ × active area per cycle. Separator compression under stack pressure further reduces void space. The plan provides no quantitative swelling budget nor iterative pack-level volumetric constraint.

## 1.6.A Issue - Thermal-runaway onset threshold (120 °C proposed) is not chemistry-specific and safety screening lacks calibration against real abuse conditions

The plan proposes >=120 °C thermal-runaway onset (from differential scanning calorimetry at 5 °C/min heating rate) as the safety gate, but does not specify the calorimetry protocol, instrument calibration or acceptance threshold for samples. Differential scanning calorimetry onset temperatures are artifact-prone: sample mass, thermal lag, heating rate and heating atmosphere (air vs. nitrogen) shift the reported onset by 20–40 °C. A lithium-sulfur cell showing 120 °C in nitrogen at 5 °C/min may exhibit runaway at 95–100 °C in air or under battery-pack adiabatic conditions (actual heat generation rate 5–10× higher due to confined volume). The plan describes external abuse testing (Month 6–12, 2027-04-14 to 2027-10-14) but provides no link between coin-cell differential scanning calorimetry and pouch-cell nail-penetration or overcharge tests.

### 1.6.B Tags

- thermal-onset-not-calibrated
- dsc-protocol-unspecified
- abuse-test-mismatch
- adiabatic-vs-convective

### 1.6.C Mitigation

By Month 4 (2027-02-14), establish abuse-test protocol calibration: (1) Coin-cell differential scanning calorimetry protocol specification: sample mass 20–30 mg, 5 °C/min heating rate in nitrogen (inert atmosphere, standard), report onset as first exothermic peak >0.5 mW/mg (not inflection or shoulder). (2) By Month 8 (2027-06-14), conduct multi-technique correlation on all three active chemistries: coin cells + pouch cells subjected to synchronized thermal ramp (differential scanning calorimetry + adiabatic calorimetry at 2 °C/min to mimic confined geometry) + nail-penetration test + external short-circuit test. Document the offset between differential scanning calorimetry onset and adiabatic onset (expected 20–50 °C lower in adiabatic), and flag chemistries where this offset exceeds 60 °C (risk of underestimated field thermal runaway). (3) By Month 12 (2027-10-14), require all finalists to pass adiabatic calorimetry at >=140 °C onset (adiabatic) AND nail-penetration test without rupture or flame within 5 minutes. If differential scanning calorimetry-to-adiabatic offset is poorly correlated (r² <0.85), deprioritize chemistry unless redesign (electrolyte additive, thermal barrier, binder dopant) shifts both onsets upward within 2 months.

### 1.6.D Consequence

A chemistry passing the 120 °C differential scanning calorimetry gate may exhibit genuine thermal runaway at 85–95 °C in a production pouch cell or battery pack, creating serious safety and regulatory liability. Discovery of this discrepancy at Month 18 (2028-04-14) gate (Month 18 = 2028-04-14) or Month 30 (2029-04-14) forces immediate deprioritization, wasting 6–12 months and USD 3–8 M of prior synthesis, cycling and characterization. Regulators (NHTSA, CE testing bodies) and licensees will reject the cell if safety margin is insufficient, even if energy density meets spec. Late discovery (Month 48+, 2030-10-14+) is a business and legal risk.

### 1.6.E Root Cause

Differential scanning calorimetry is a low-energy technique suitable for screening but not predictive of full-cell thermal behavior. High-energy lithium chemistries (lithium-sulfur, high-nickel-oxide cathodes, prelithiated anodes) exhibit exothermic side reactions (electrolyte oxidation, lithium-oxygen reactions, dissolved polysulfide reduction) that are triggered by elevated temperature and confined geometry. A coin cell reaching 120 °C in a differential scanning calorimetry pan does not experience stack pressure, current distribution or current-collector heating—all of which accelerate thermal runaway in a real pouch cell. The plan lacks guidance on how to map coin-cell thermal data to pouch-cell abuse tolerance.

---

# 2 Expert: Regulatory and EHS Compliance Specialist

**Knowledge**: EPA hazardous-waste rules (40 CFR 260–273), OSHA reactive-materials handling, Texas environmental permitting (TCEQ), lithium-metal and organic-solvent waste streams, phased-permit strategy for new facilities

**Why**: The pre-project assessment flags permitting as a critical path risk: 6–8 month delays would compress effective work to 75–78 months. The plan's phased-permit approach (Month 3, 6, 9 = 2027-01-14, 2027-04-14, 2027-07-14 for dry-room, synthesis, abuse chambers) is only viable if regulator engagement begins immediately (Month 0 = 2026-10-14). An EHS specialist can validate permit timelines, identify hidden compliance gaps, and negotiate with Austin Fire Authority and TCEQ to enable contingency operations (e.g., outsourced synthesis) if Phase 1 or Phase 2 permits slip.

**What**: By Month 0 (2026-10-14), draft a pre-application meeting agenda with Austin Fire Authority, TCEQ and Travis County; propose phased-permit scope to minimize initial approvals and enable contingent outsourcing of reactive synthesis if Phase 2 slips. By Month 2 (2026-12-14), prepare and submit Phase 1 permit application, confirming turnaround and identifying any hidden municipal or state requirements that could delay commissioning past Month 3 (2027-01-14).

**Skills**: Regulatory interpretation and permit drafting, hazardous-materials facility design, waste-stream characterization, collaborative regulator engagement, contingency site operations, incident documentation and reporting

**Search**: EPA TCEQ hazardous materials permit battery research lab, environmental health safety officer lithium synthesis

## 2.1 Primary Actions

- Call Austin Fire Authority, TCEQ, and Travis County TODAY (Month 0 = 2026-10-14, before 17:00) to schedule collaborative pre-application meetings. Propose phased permitting (Phase 1 dry-room by Month 3 = 2027-01-14, Phase 2 synthesis by Month 6 = 2027-04-14, Phase 3 abuse test by Month 9 = 2027-07-14) and conditional-use authorization pathways to hedge 6–8 month review delays. Submit Phase 1 permit application by Month 2 (2026-12-14) limiting initial scope to non-hazardous dry-room operation.
- Hire an experienced EHS officer (>=5 years battery or chemical-manufacturing background) by Month 1 (2026-11-14). Assign immediate mandate: map EPA 40 CFR 260–273 lithium-metal and organic-solvent waste streams, OSHA reactive-materials handling (29 CFR 1910.1200, 1910.307), TCEQ air-permit thresholds for VOC and inorganic hazards, and execute standby external-synthesis contracts (<4 week turnaround, USD 2–5 M/yr budget) to preserve discovery velocity if permits slip.
- Execute modular pilot-line lease agreement by Month 1 (2026-11-14) (50–100 cells/month capacity, deployment by Month 3 = 2027-01-14). Negotiate 3-year terms with month-to-month expansion, 60-day exit clauses, and cost transparency (USD 0.6–1.2 M/yr operating lease vs. USD 30–50 M capital). Simultaneously, secure facility site in Northeast Travis County or Southeast Austin by Month 1 (2026-11-14) (5,000–10,000 m² usable space, wet chemistry and hazardous-materials rated) and confirm power (500+ kVA), HVAC, and waste handling adequate for lithium and solvent work.
- Build a live cell-level mass-and-volume model by Month 4 (2027-02-14) that back-calculates material-level targets from the 500 Wh/kg and 1000 Wh/L cell-level goals. Document current-collector, separator, electrolyte volume, and pouch-packaging assumptions using validated benchmark data (not estimates). Conduct sensitivity analysis for each of 3–4 candidate chemistries. Present finalized model and locked thresholds (>=950 Wh/L interim, >=500 Wh/kg) to the Steering Committee by Month 3 (2027-01-14) for formal approval.
- Establish hard non-negotiable gate criteria by Month 3 (2027-01-14): (a) >=300 cycles at 80% capacity retention (C/10 rate, 25 °C, 0–4.5 V window), (b) >=950 Wh/L interim threshold (Month 30 = 2029-04-14 checkpoint), (c) >=120 °C thermal-runaway onset (differential scanning calorimetry, 5 °C/min heating rate). Define root-cause forensics protocol: every failed cell post-mortem (SEM, EDX, FTIR) within 5 business days. Lock these thresholds in writing; do not defer them as proposals.
- Pre-stage reserve-chemistry contingency plans by Month 12 (2027-10-14): document precursor suppliers (>=2 per material), dry-room process conditions, pilot-line equipment reconfiguration needs, and staff retraining. By Month 24 (2028-10-14), if two leading chemistries show fundamental limitations (cycle-life <250 cycles, Wh/L <900 after 18 months engineering), place firm orders for reserve-chemistry precursors (8–12 week lead times) and pre-configure equipment. Target rapid pivot (4–6 weeks) if Month 30 (2029-04-14) third-party data confirm failure.
- Secure >=2 university or national-laboratory characterization partnerships by Month 3 (2027-01-14) with formal standing agreements: guaranteed >=10–15 characterization slots/month (operando or post-mortem), <=3 week turnaround, >=15% partner cost-sharing (USD 500 K–1 M/yr estimate), and 30–60 day exit clauses. Simultaneously, invest in one core in-house post-mortem instrument (SEM–EDX or high-resolution XRD, USD 2–3 M capital) and hire 0.5 FTE technician; operationalize by Month 8 (2027-06-14).
- Define or secure funding-top-up decision with Funder regarding pivot-runway insufficiency by Month 3 (2027-01-14): commission cost breakdown for (a) reserve-chemistry pivot (USD 5–10 M), (b) volumetric-sprint redesign (USD 8–15 M), and (c) concurrent stress case (USD 13–25 M). Present stress-case shortfall (up to USD 10 M vs. USD 15 M ring-fenced reserve) and request Funder approval for either (i) increase total reserve to USD 30 M, or (ii) one-time top-up of USD 10–15 M if Month 30 (2029-04-14) pivot and sprint coincide. Document decision formally; do not proceed to chemistry selection gate (Month 36 = 2029-10-14) without clarity.
- Establish IP-contamination safeguards and clean-room employee onboarding by Month 1 (2026-11-14): require all hires (especially from Tesla, Panasonic, Samsung, CATL) to sign non-use agreements and undergo 6-month probationary observation with no access to core synthesis, cell designs, or electrolyte formulations. Conduct IP-compliance audits (signed attestation) weekly. File >=6 provisional patents in Months 6–12 (2027-04-14 to 2027-10-14) covering anode, cathode, and electrolyte combinations; engage IP counsel experienced in battery licensing by Month 2 (2026-12-14).

## 2.2 Secondary Actions

- Set up Scientific Steering Committee by Month 1 (2026-11-14) with Programme Director, Chemistry leads, independent external advisor, Funder representative, and red-team lead (2–3 scientists). Establish gate decision cadence: decisions within 3 weeks of data arrival. Schedule monthly progress reviews; quarterly steering meetings.
- Conduct bottom-up payroll and salary-benchmark analysis by Month 2 (2026-12-14). Document realistic cost (current market rates in Austin for battery scientists, engineers, technicians). Flag the estimated USD 14.8 M/yr scenario (vs. USD 10 M/yr baseline) to the Funder; identify descope options (defer hiring, reduce team size, outsource more work) if budget is non-negotiable. Review attrition risk monthly; implement 15–20% salary premium for senior roles and 3–5 year retention agreements by Month 3 (2027-01-14).
- Initiate early licensee and prospective-partner conversations by Month 12 (2027-10-14). Conduct informal advisory meetings with potential manufacturers (e.g., Tesla, LG, Samsung, Panasonic, emerging EV suppliers) to understand licensing terms, application priorities (aviation, long-range EV, portable), and cycle-life / thermal-runaway requirements. Use findings to refine Reference Application Anchor specification. Finalize licensing framework and partnership structure by Month 24 (2028-10-14).
- Establish abuse-testing schedule and safety thresholds by Month 4 (2027-02-14). Conduct thermal-ramp screening (DSC) for all 3–4 candidates Months 6–9 (2027-04-14 to 2027-07-14) in-house or via low-cost outsourcing (<USD 5 K/sample). Contract external accredited lab (Intertek, TUV) for nail-penetration and overcharge tests (Months 6–12 = 2027-04-14 to 2027-10-14) at USD <20 K per full protocol. Publish safety rankings by Month 12 (2027-10-14). Decide on in-house abuse-testing facility (USD 3–5 M capital) by Month 12 (2027-10-14); commission by Month 18 (2028-04-14) if justified by throughput.
- Build a quarterly forensics atlas and failure-mode atlas by Month 6 (2027-04-14), updated every quarter. Document every failed cell with root-cause code (dendrite growth, polysulfide dissolution, lithium-ion depletion, cathode collapse, electrolyte oxidation, mechanical swelling, or combination). Link findings directly to next-round design changes (additive, coating, binder, separator). Publish atlas to the team by Month 12 (2027-10-14) and refresh every quarter. Use it to close the hypothesis-to-validation loop.
- Finalize cell-level third-party verification protocol by Month 9 (2027-07-14) in consultation with accredited test laboratories (e.g., MIT Energy Initiative, NREL, Intertek). Specify test conditions (C-rate, temperature, cycle-to-80% criterion, capacity measurement precision, minimum cell count and replicates). Lock the measurement standard that will be used for Month 30 (2029-04-14) and Month 72 (2032-10-14) verification to prevent scope creep or post-hoc claims.
- Commission detailed reserve-stress financial modeling by Month 3 (2027-01-14). Build a cash-flow model showing monthly spend for Months 0–84 (2026-10-14 to 2033-10-14) under base case and stress scenarios (permitting slip, chemistry pivot, volumetric sprint, supply disruption, attrition replacement). Identify which tranches (T1–T4) could be drawn early if liquidity is needed, and which contingencies would require Funder top-up approval.
- Develop a formal descope and stop rule by Month 6 (2027-04-14) with Funder and Steering Committee. Document explicit conditions under which the programme would be stopped or significantly rescoped: e.g., 'If no chemistry meets both >=500 Wh/kg AND >=950 Wh/L by Month 30 (2029-04-14), and Month 36 (2029-10-14) redesign sprint shows no path to 1000 Wh/L within remaining budget, T4 (USD 90 M) release is conditional on Steering Committee approval of descope (e.g., final delivery at 500 Wh/kg / 900 Wh/L, not full dual targets).' Publish this rule; enforce it at gates.

## 2.3 Follow Up Consultation

Next meeting (Month 0.5 ≈ 2026-10-29, 7 days): Review preliminary permitting roadmap and regulator engagement feedback. Confirm EHS-officer hiring timeline. Next review (Month 1 = 2026-11-14): Confirm modular line lease execution, facility occupancy dates, and >=2 partner agreements signed with specified characterization SLAs. Month 2 (2026-12-14) gate: Phase 1 permit application submitted; IP counsel engaged. Month 3 (2027-01-14): Cell-level model finalized, thresholds locked, gate criteria approved, contingency financing decision from Funder. Monthly progress until Month 12 (2027-10-14) gate; quarterly steering thereafter. Critical path items: permitting (regulator engagement NOW), pilot-line lease (Month 1 = 2026-11-14), cell model (Month 4 = 2027-02-14), cycle-life & volumetric thresholds (Month 3 = 2027-01-14), reserve funding clarity (Month 3 = 2027-01-14).

## 2.4.A Issue - Permitting timeline is dangerously compressed and lacks contingency buffers.

The plan assumes phased permits at Months 3, 6, and 9 (2027-01-14, 2027-04-14, 2027-07-14) with no documented pre-application coordination or lead-time hedging. Hazardous-materials facilities typically face 6–8 month reviews, not 3-month cycles. If Phase 1 slips to Month 6 (2027-04-14), operational start delays 3 months, compressing effective work from 84 to ~78 months. The plan mentions "conditional-use authorization" but does not commit to it or budget for daily compliance audits. This is a critical path item—no synthesis, no pilot line, no progress without permits.

### 2.4.B Tags

- permitting_delay_risk
- critical_path_compression
- regulatory_engagement_incomplete
- contingency_buffer_missing

### 2.4.C Mitigation

Action 1 (Month 0 = 2026-10-14, today): Call Austin Fire Authority, TCEQ, and Travis County today at 15:00 (end of business). Request a preliminary collaborative meeting (target: within 7 days). Propose phased permits and conditional-use pathways. Action 2 (Month 0.5 ≈ 2026-10-29): Submit a pre-application package to TCEQ and Fire Authority listing intended chemistry scope, dry-room parameters (humidity <–30 °C), and synthesis scale (e.g., <10 g lithium per batch, <50 L flammable solvents total on-site). Action 3 (Month 1 = 2026-11-14): Hire EHS officer with battery-lab experience and assign immediate task: map EPA 40 CFR 260–273, OSHA 1910.1200/1910.307, and TCEQ air-permit thresholds. Action 4 (Month 2 = 2026-12-14): Submit Phase 1 permit (dry-room only, non-hazardous reagents) targeting 6-week review. Simultaneously, execute standby external-synthesis contracts (<4 week turnaround, USD 2–5 M/yr budget) so synthesis does not halt if permits slip. This preserves operational credibility and allows Month 3–4 (2027-01-14 to 2027-02-14) pilot-line startup even if full permits mature in Month 9 (2027-07-14).

### 2.4.D Consequence

Permitting delays of 6–8 months compress effective work time to 75–78 months, turning a 2-year proof window (Months 30–48 = 2029-04-14 to 2030-10-14) into 1.5 years (Months 36–54 = 2029-10-14 to 2031-04-14). Late discovery of 1000 Wh/L shortfall or poor cycle-life in the final candidates forces rushed redesigns or programme failure. Alternatively, facility occupancy is delayed, synthesis is outsourced at 4–6 week turnarounds (50% productivity loss), and the Month 18 (2028-04-14) and Month 30 (2029-04-14) gates slip, jeopardizing technology transfer timelines and funder confidence.

### 2.4.E Root Cause

The plan states permitting timelines but does not ground them in documented lead times from Austin Fire Authority or TCEQ, and assumes phased approval cycles without evidence of regulator appetite for parallel or abbreviated reviews. Pre-application coordination and conditional-use fallbacks are mentioned but not locked into the schedule, leaving execution to Month 2–3 (2026-12-14 to 2027-01-14) when delay has already begun. EHS staffing is deferred to Month 1 (2026-11-14), leaving no one to drive regulator engagement at Month 0 (2026-10-14).

## 2.5.A Issue - Cell-level mass-and-volume model lacks specificity; thresholds remain proposed and unverified.

The plan requires a live cell model by Month 4 (2027-02-14) that accounts for current collectors, separator, electrolyte, and pouch packaging to back-calculate material-level targets. However, the model inputs—current-collector thickness (10–20 µm estimate), separator (25–30 µm estimate), electrolyte volume (0.5–1.5 mL/Ah estimate), pouch mass (300–400 µm aluminum laminate estimate)—are placeholder ranges, not validated against the actual candidate chemistries or cell formats being pursued. The 950 Wh/L interim threshold is proposed, not locked. If volumetric-density penalties exceed estimates by 15–20% (realistic for pouch stacking and pressure management), candidates passing gravimetric gates may fail 1000 Wh/L, revealed late (Month 30 = 2029-04-14 or later). This is a critical credibility gate—material-level claims that collapse at cell level discredit the entire programme.

### 2.5.B Tags

- model_input_uncertainty
- threshold_not_finalized
- volumetric_penalty_underestimated
- late_discovery_risk

### 2.5.C Mitigation

Action 1 (Month 1 = 2026-11-14): Assign the cell-engineering lead to conduct a bottom-up audit of inactive-mass penalties using published benchmark cells (e.g., Tesla Model 3 cell data, Panasonic 20700-equivalent pouch builds, or Battery500 reference designs). Document actual measured values for current-collector thickness, separator porosity (affects electrolyte retention), and pouch material/sealing mass. Action 2 (Month 2 = 2026-12-14): For each of the 3–4 candidate chemistries, specify the assumed cell format (single-layer pouch, multilayer, bipolar, or anode-free stack) and corresponding inactive-mass budget. Run sensitivity analysis: if separator thickness increases from 25 to 35 µm, or electrolyte volume from 0.8 to 1.2 mL/Ah, what is the Wh/L shortfall? Flag any candidate with >10% shortfall risk. Action 3 (Month 3 = 2027-01-14): Present the finalized model and sensitivity bounds to the Steering Committee. Lock the 950 Wh/L interim threshold by formal decision (not proposal) and document the reasoning: is 950 Wh/L a realistic checkpoint, or should it be 900 Wh/L or 980 Wh/L? Action 4 (Month 6–12 = 2027-04-14 to 2027-10-14): Require dual-track builds: one pouch-cell batch with conservative separator and electrolyte volume (baseline), and one with aggressive targets (thinner separator, lower electrolyte loading). Measure both; identify which path is feasible for each chemistry. Publish findings in the Month 12 (2027-10-14) forensics atlas.

### 2.5.D Consequence

Without validated model inputs and locked thresholds, the team optimizes toward material-level numbers decoupled from cell-level reality. At Month 30 (2029-04-14), third-party measured pouch cells may show >=500 Wh/kg but <950 Wh/L, forcing a 6-month volumetric sprint (Months 30–36 = 2029-04-14 to 2029-10-14) competing with the selection gate. If the sprint fails, the selected chemistry meets 500 Wh/kg but misses 1000 Wh/L, and the final delivery (Month 72 = 2032-10-14) reports an incomplete result. Alternatively, candidates are deprioritized prematurely because the model over-penalizes their volumetric potential, eliminating the most viable path.

### 2.5.E Root Cause

The plan treats the cell-level mass-and-volume model as a design tool to be built at Month 4 (2027-02-14), after chemistry candidates are already under investigation. The model inputs are placeholders drawn from generic pouch-cell literature, not calibrated to the specific chemistries, formats, and inactive-mass assumptions of the tournament. Thresholds (950 Wh/L, 300 cycles) are labeled 'proposed' in the plan, signaling they are not yet locked, yet the schedule assumes they will be fixed by Month 3 (2027-01-14). This creates ambiguity: until the model is built and sensitivity analysis is run, the thresholds cannot be credibly locked, yet the gates depend on them.

## 2.6.A Issue - Pivot-runway budget (USD 15 M) is insufficient for the stress case: pivot plus volumetric sprint can exceed USD 25 M.

The plan reserves USD 15 M (5% of the USD 300 M cap) as a ring-fenced pivot runway until Month 36 (2029-10-14). A chemistry failure at Month 24 (2028-10-14) or Month 30 (2029-04-14) may trigger two simultaneous expensive actions: (1) a pivot to the reserve chemistry (sourcing USD 5–10 M in precursors, pilot-line reconfiguration, and accelerated cycling), and (2) a 6-month volumetric sprint if a leading candidate meets Wh/kg but not 1000 Wh/L (electrode redesign, separator optimization, USD 8–15 M estimate). Combined stress case: USD 13–25 M. The USD 20 M total reserve (USD 15 M pivot + USD 5 M general) covers the best-case pivot alone, but not pivot-plus-sprint, leaving a shortfall of USD 5–10 M that must drain the general reserve or compress critical work. This undermines the plan's claim of being 'hedged' for pivot capacity.

### 2.6.B Tags

- reserve_insufficiency
- stress_case_underestimated
- concurrent_cost_exposure
- funding_contingency_gap

### 2.6.C Mitigation

Action 1 (Month 1 = 2026-11-14): Commission a detailed cost breakdown for (a) a one-chemistry pivot to the pre-staged reserve (precursor re-sourcing, process validation, 50–100 pouch builds, third-party cycling), and (b) a volumetric-density sprint (separator sourcing, electrode-coating optimization, 20–30 experimental pouch cells, operando diagnostics). Provide low/mid/high estimates for each. Action 2 (Month 3 = 2027-01-14): Present the stress case to the Steering Committee and Funder. Propose two solutions: (i) increase the unallocated reserve from USD 20 M to USD 30 M (reducing programme spend envelope to USD 270 M, requiring descope elsewhere), or (ii) clarify Funder's appetite for a one-time top-up of USD 10–15 M if pivot and volumetric sprint coincide at Month 30 (2029-04-14). Action 3 (Month 6 = 2027-04-14): If no top-up decision is reached, pre-commit to a staged descope rule: if Month 30 (2029-04-14) data triggers both a pivot and volumetric sprint, the volumetric sprint takes priority (reserve chemistry may not hit 1000 Wh/L, only 950 Wh/L interim target); pivot is allocated USD 10 M (precursor and process validation only, limited cycling). This trades complete volumetric proof for pivot capability. Action 4 (Month 24 = 2028-10-14): By the Month 24 checkpoint (2028-10-14), confirm with the Funder whether additional funds are available; if not, formally reduce the pivot runway to USD 10 M and revise gate criteria to accept 950 Wh/L interim on the finalist (final delivery may hit >=1000 Wh/L or may not, depending on optimization Months 48–72 = 2030-10-14 to 2032-10-14).

### 2.6.D Consequence

If a pivot and volumetric sprint occur concurrently and the USD 15 M runway is insufficient, the team either (1) under-funds one critical work stream (e.g., pivot gets USD 5 M instead of USD 8 M, extending it to 8–12 weeks instead of 4–6 weeks, compressing final proof time), (2) raids the USD 5 M general contingency (leaving zero buffer for permitting delays, supply disruptions, or safety surprises), or (3) requests an emergency top-up mid-programme, signaling poor planning and risking funder confidence. Alternatively, the Steering Committee defers the volumetric sprint and accepts that the finale may deliver 500 Wh/kg and 950 Wh/L (not the 1000 Wh/L secondary goal), compromising the invention scope.

### 2.6.E Root Cause

The plan compartmentalizes pivot cost (USD 5–10 M single-chemistry) and volumetric-sprint cost (USD 8–15 M) as separate risk items, but does not model their correlation. A chemistry tournament failure is most likely to be detected at Month 30 (2029-04-14) when third-party data arrive. At that moment, if two leading candidates show poor cycle-life or volumetric shortfall, both the pivot (to the third candidate) and the volumetric sprint (to fix the second-place candidate) may launch simultaneously. The plan does not address this concurrency in its reserve sizing, and the Funder's top-up appetite is not documented.

---

# 3 Expert: Pilot-Line Engineering and Cell Manufacturing Lead

**Knowledge**: Dry-room design (dew-point control, particulate filtration), pouch-cell assembly and formation, electrode coating uniformity, electrolyte dosing reproducibility, cell build yield and quality metrics, modular versus owned line trade-offs

**Why**: Pilot Line Philosophy and Dry-Room Footprint is a High-priority decision that locks USD 15 M capital (estimated) and shapes build cadence (50–100 cells/month, estimate). The plan proposes a modular, leased line for flexibility, but line commissioning (Month 3, 2027-01-14) and first pouch builds (Month 6, 2027-04-14) are on a tight path. A pilot-line engineer can validate equipment specifications, identify lead-times for modular systems, and ensure the leased line can support the chemistry tournament's different electrolytes and formats without 4–6 week reconfiguration delays.

**What**: By Month 1 (2026-11-14), evaluate modular dry-room and pouch-line vendors (estimate USD 15 M capital) for compatibility with the three candidate chemistries; confirm that electrolyte switching and electrode-coating parameter changes can be completed in ≤1 week without line downtime. By Month 3 (2027-01-14), verify on-site dry-room dew-point control (<−30 °C), electrode coating uniformity (±10 µm) and electrolyte dosing reproducibility (±2%) before first cell builds, and document any gaps requiring retrofit.

**Skills**: Dry-room commissioning, pouch-cell assembly automation, electrode coating and slurry preparation, electrolyte filling and dosing systems, cell formation and formation-curve analysis, yield and traceability tracking, equipment qualification and process validation

**Search**: pouch cell manufacturing engineering dry room commissioning, lithium battery pilot line modular flexible

## 3.1 Primary Actions

- Action 1: By 2026-11-14 at 14:00, execute a binding lease agreement with a named modular dry-room and pouch-cell fabrication vendor (e.g., Mbraun, Glove-box Company) specifying deployment on-site by 2027-01-14, equipment specs (dew-point <−30 °C, electrode-coating uniformity ±10 µm, electrolyte dosing ±2%), 60-day exit, and month-to-month expansion optionality. Simultaneously, confirm a standby pouch-line agreement with UT Austin or NREL (<USD 500/cell, 4-week turnaround) as fallback if modular line fails to commission.
- Action 2: By 2027-04-14 at 11:00, project cell-level Wh/L for all three active chemistries using the live mass-and-volume model (current collectors, separator thickness, electrolyte volume, pouch laminate overhead); flag any candidate projecting <950 Wh/L despite >=500 Wh/kg material performance for targeted 4-month 'volumetric redesign' (separator choice, electrolyte volume optimization, cathode density) in parallel with cycle-life cycling. By 2027-10-14 at 14:00 (Month 12 = 2027-10-14), require all candidates to show measured pouch-cell Wh/L data (not projections) with identified material-level targets needed to reach >=950 Wh/L; demote any candidate unable to reach interim target unless redesign is demonstrably on track.
- Action 3: By 2027-01-14 at 10:00, establish >=300 cycles at 80% capacity retention as a hard non-negotiable gate criterion for all chemistry finalists; define test protocol (C/10 discharge, 25 °C, chemistry-specific voltage window, capacity every 50 cycles). By 2027-10-14 at 14:00 (Month 12 = 2027-10-14), initiate parallel cycle-life stacks for all three candidates (>=100 cycles, >=2 replicates each); deprioritize any candidate with measured <250 cycles at 80% unless 2–4 month interface redesign (additive, coating, binder) is in progress with >10% early-cycle (50-cycle) improvement shown.
- Action 4: By 2028-10-14 at 10:00 (Month 24 = 2028-10-14), if two of three leading chemistries show fundamental limitations (e.g., both stuck <250 cycles despite 18 months interface engineering, or both unable to reach >=950 Wh/L despite gravimetric success), pre-stage reserve chemistry immediately: place firm orders for long-lead precursors (8–12 week lead times), pre-configure pilot-line electrode-coating and stacking procedures, assign 20–30% of synthesis and cell-assembly team to reserve-path training. Allocate USD 10–15 M as unallocated 'pivot runway' reserve held through 2029-04-14 (Month 30 = 2029-04-14); upon Month 30 (2029-04-14) third-party pouch-cell verification confirming one leading candidate is inferior, execute pivot within 3 weeks and begin reserve-chemistry pouch builds by 2029-06-14 (6 weeks into pivot).
- Action 5: By 2026-10-14 at 17:00 (Month 0 = 2026-10-14, today), contact Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ), and Travis County Environmental Services as collaborative partners; schedule pre-application meetings to co-design site protocols and phased-permit approach (Phase 1 dry-room/assembly by 2027-01-14; Phase 2 lithium-metal synthesis by 2027-04-14; Phase 3 abuse chambers by 2027-07-14). Hire an EHS officer with >=5 years battery-lab background by 2026-11-14 at 09:00 (Month 1 = 2026-11-14). Submit Phase 1 permit application by 2026-12-14 at 14:00 (Month 2 = 2026-12-14); negotiate conditional-use authorization from fire authority if permitting delay exceeds 4 weeks, allowing dry-room operation under enhanced monitoring while full permits process.

## 3.2 Secondary Actions

- Action 6: By 2027-02-14 at 10:00 (Month 4 = 2027-02-14), finalize and operationalize the live cell-level mass-and-volume model: account for current collectors (10–20 µm copper/aluminum), separator (25–30 µm, chemistry-specific), electrolyte volume (0.5–1.5 mL/Ah estimate), and pouch laminate (300–400 µm aluminum estimate). Back-calculate material-level Wh/kg and Wh/L targets from user-specified 500 Wh/kg and 1000 Wh/L cell targets. By 2027-04-14 at 11:00 (Month 6 = 2027-04-14), project cell-level density for all three candidates; publish quarterly updates with unexplained gaps (>10%) flagged for investigation.
- Action 7: By 2027-04-14 at 09:00 (Month 6 = 2027-04-14), initiate coin-cell thermal-ramp screening for all three chemistries (differential scanning calorimetry or contracted service, <USD 5 K/sample): measure thermal runaway onset and heat release for >=2 samples per candidate by 2027-07-14 (Month 9 = 2027-07-14). Flag any candidate with onset <100 °C for deprioritization unless redesign shows clear path to >=120 °C within 2 months. By 2027-07-14 at 14:00 (Month 9 = 2027-07-14), contract external abuse-testing facility (Intertek, TUV, or equivalent, <USD 20 K full protocol) for nail-penetration and overcharge tests on 2–3 pouch-cell candidates; report findings by 2027-09-14 (8 weeks from submission).
- Action 8: By 2027-01-14 at 11:00 (Month 3 = 2027-01-14), execute formal standing agreements with >=2 university or national-laboratory characterization partners (UT Austin, NREL, Argonne): secure >=10–15 characterization slots/month (operando or post-mortem: XRD, SEM, electrochemical impedance spectroscopy) with <=3 week turnaround; negotiate annual cost-sharing (partners fund >=15%, est. USD 0.5–1 M/yr); establish 30–60 day exit clauses. By 2027-02-14 at 09:00 (Month 4 = 2027-02-14), invest in one core in-house post-mortem instrument (SEM with EDS or high-resolution XRD, USD 2–3 M capital); operationalize by 2027-06-14 (Month 8 = 2027-06-14) with 0.5 FTE dedicated technician. By 2027-01-14 at 14:00 (Month 3 = 2027-01-14), negotiate backup characterization agreement with independent commercial lab (Intertek, TUV) for USD <=100 K/failed-cell full analysis; establish priority-queue access with 6-week commitment.
- Action 9: By 2026-11-14 at 13:00 (Month 1 = 2026-11-14), develop and publish clean-room onboarding protocol for all employees with mandatory compliance from day one: all hires from Tesla, Panasonic, Samsung, CATL or competitors sign non-use agreement (48-page legal document) before laboratory access. Competitors' hires undergo 6-month probationary observation (non-core synthesis/characterization only, no access to cell designs or electrolyte formulations); weekly IP-compliance audits with signed attestations. By 2026-12-14 at 10:00 (Month 2 = 2026-12-14), file >=6 provisional patents in Months 6–12 (2027-04-14 to 2027-10-14) covering anode, cathode, electrolyte compositions and cell architectures; establish priority before open publication. By 2028-04-14 at 16:00 (Month 18 = 2028-04-14), conduct IP-contamination risk assessment: interview all staff with prior commercial battery experience; document any inadvertent incorporation of prior-employer design principles; take corrective action (redocument from first principles, file continuation/divisional patents if independent development is clear).
- Action 10: By 2027-04-14 at 10:00 (Month 6 = 2027-04-14), establish forensics protocol: every failed cell receives standardized destructive post-mortem within 1 week of failure (SEM/EDS of anode and cathode, electrolyte-decomposition analysis via FTIR or GC); assign findings to structured root-cause code (e.g., 'lithium-ion depletion via electrolyte oxidation,' 'dendrite growth with internal short'); publish quarterly forensics atlas (internal summary of failure modes, mechanisms, and design consequences) by 2027-10-14 (Month 12 = 2027-10-14) and thereafter. Use forensics atlas to directly feed design iteration: if >=40% of failures show 'polysulfide dissolution despite barrier,' next-round candidates receive polysulfide-immobilization additives (lithium nitrate, polymer matrix, or cathode dopant).
- Action 11: By 2027-02-14 at 11:00 (Month 4 = 2027-02-14), define quantitative safety pass/fail criteria for all finalists: thermal runaway onset >=120 °C (DSC at 5 °C/min); reversibility after 150% overcharge (>=90% capacity recovery after 1 hour open-circuit; no explosion/vent); internal short survivability (nail-penetration per SAND2000-0218 shows no thermal runaway within 5 minutes). By 2027-10-14 at 15:00 (Month 12 = 2027-10-14), decide on in-house abuse-testing facility (USD 3–5 M capital: calorimetry, nail-penetration rig, overcharge supply, ventilation, fire suppression) if throughput justifies; allocate from Months 0–12 (2026-10-14 to 2027-10-14) capital budget and target commissioning by 2028-04-14 (Month 18 = 2028-04-14); otherwise defer and use contingency reserve.
- Action 12: By 2028-10-14 at 14:00 (Month 24 = 2028-10-14), finalize IP and licensing framework with battery-IP counsel: define ownership of jointly developed IP with partners (programme owns integrated cell architecture and processes; partners retain publication rights after 6-month review), scope of defensible patent estate (minimum: integrated cell architecture, key cathode compositions, electrolyte-interface designs), and licensing-term assumptions for technology transfer. By 2027-10-14 at 16:00 (Month 12 = 2027-10-14), document detailed contingency plans for reserve chemistries (precursor suppliers with >=2 per key material, process steps, dry-room conditions, pilot-line equipment reconfiguration, staff retraining estimate 1–2 weeks/person). By Month 18 (2028-04-14) and Month 30 (2029-04-14), publish cycle-life degradation curves and end-of-life failure modes to support patent claims and licensing credibility.

## 3.3 Follow Up Consultation

Next consultation should address: (1) Confirmation of the named modular-line vendor and timeline (Mbraun, Glove-box Company, or equivalent) with signed LOI and equipment delivery schedule by end of Month 1 (2026-11-14). (2) Results of the Phase 1 permitting pre-application meeting with Austin Fire Authority and TCEQ, including estimated approval timeline and any conditional-use authorization pathway if permitting delays >4 weeks. (3) Finalization of the mass-and-volume model assumptions (separator thickness by chemistry, electrolyte volume per anode/cathode pair, current-collector foil thickness for pouch format) and first projections for all three active chemistries. (4) Confirmation of at least two university/national-lab characterization partner agreements executed, with turnaround times and cost-sharing terms confirmed. (5) Progress on hiring the EHS lead and IP counsel, and publication of clean-room onboarding protocol and IP strategy by end of Month 2 (2026-12-14). (6) Decision on whether to build in-house abuse-testing facility by Month 12 (2027-10-14) or outsource; budget and timeline implications. (7) Preliminary cycle-life test protocol specification and equipment/staffing plan for parallel cycling of all three candidates from Month 12 (2027-10-14) onward.

## 3.4.A Issue - Pilot-Line Ownership Decision Deferred—Capital Risk Unresolved

The strategy assumes a 'modular' line exists ready to lease. No vendor is named. Capital cost (USD 15 M) is stated, but lease opex (USD 0.6–1.2 M/yr estimate) and equipment specs (dew-point control, electrode-coating uniformity, electrolyte dosing reproducibility) are generic. If the line is delayed or the vendor fails, pivot to owned (USD 30–50 M, 12 months) exceeds the pivot runway and strains the budget. Pouch-cell build rate targets (50–100/month by Month 24 = 2028-10-14) are optimistic without proven line throughput.

### 3.4.B Tags

- pilot-line-ownership-ambiguity
- capital-lock-risk
- vendor-dependency
- operationalization-delay

### 3.4.C Mitigation

By Month 1 (2026-11-14), name and execute a binding lease with a specific modular-line vendor (e.g., Mbraun, Glove-box Company, or equivalent) with equipment on-site by Month 3 (2027-01-14), specifying dew-point setpoint (<−30 °C), electrode-coating tolerance (±10 µm), electrolyte dosing repeatability (±2%), and commissioning success criteria. Negotiate 60-day exit and month-to-month expansion. Simultaneously, execute a standby agreement with UT Austin or NREL for backup pouch builds (USD <500/cell, 4-week turnaround) if the modular line fails to commission. If modular deployment slips beyond Month 4 (2027-02-14), invoke the standby line immediately and reallocate USD 2–3 M to accelerate characterization and reduce pouch-cycle count.

### 3.4.D Consequence

Without a named vendor and binding timeline, the line is vaporware. Delays cascade: no pouch builds until Month 9–12 (2027-07-14 to 2027-10-14) (vs. Month 6 = 2027-04-14 baseline), compression to 72–75 effective months, and forced demotion of reserve chemistry if the leading two are still iterating at Month 24 (2028-10-14). Owned-line fallback (USD 30–50 M) exhausts the pivot runway and strains the budget, forcing descope or funder top-up by Month 6 (2027-04-14).

### 3.4.E Root Cause

The plan conflates 'modular' with 'low-cost and immediately available.' Equipment modularity (containerized, portable) is real; vendor readiness to deliver and scale is assumed but not de-risked. Risk-averse approach would own by Month 0 (2026-10-14) and accept sunk cost; this plan tries to hedge cost against timeline and loses both unless vendor commitment is locked immediately.

## 3.5.A Issue - Volumetric Density (1000 Wh/L) Gate Ambiguously Deferred to Month 30 (2029-04-14)—Packaging Penalty Discovery Too Late

Cell-level Wh/L depends on inactive-mass fractions: current collectors (10–20 µm copper), separator (25–30 µm estimate), electrolyte (0.5–1.5 mL/Ah estimate), and pouch laminate (300–400 µm estimate). These are system-level decisions, not material-level fixes. A lithium-sulfur cathode might reach 600 Wh/kg gravimetrically but require thicker separator (polysulfide barrier) and high electrolyte volume, yielding <900 Wh/L cell-level. Discovering this at Month 30 (2029-04-14) after 30 months of investment is existential. The 'volumetric sprint' assumes separator and electrolyte redesigns do not erode cycle life, which is empirically false.

### 3.5.B Tags

- volumetric-target-deprioritization
- late-packaging-penalty-discovery
- simultaneous-optimization-risk
- cycle-life-trade-off-hidden

### 3.5.C Mitigation

By Month 6 (2027-04-14), compute cell-level Wh/L projections for all three active chemistries using the mass-and-volume model with fixed assumption set (separator thickness per chemistry, electrolyte volume per anode/cathode pair, current-collector foil thickness for pouch format). Flag any chemistry projecting <950 Wh/L despite >500 Wh/kg material performance. By Month 12 (2027-10-14), build one proof-of-concept coin cell for each candidate and measure actual electrolyte volume absorbed by electrode materials, separator, and pouch laminate; compare to model and adjust. By Month 18 (2028-04-14), require pouch-cell builds from all three candidates with measured Wh/L data (not projections); candidates falling <950 Wh/L enter a 4-month 'volumetric redesign' (separator choice, electrolyte formulation, cathode density targeting) in parallel with cycle-life cycling. By Month 30 (2029-04-14), require all three finalists to submit matched pouch-cell data showing >=500 Wh/kg AND >=950 Wh/L in the same cells; any candidate meeting Wh/kg but not Wh/L is demoted unless the redesign is demonstrably on track (cycle-life >=250 cycles). This forces the volumetric problem to surface by Month 18 (2028-04-14), leaving 18 months for redesign before the selection gate.

### 3.5.D Consequence

Without early volumetric discovery, one or two leading chemistries could reach the Month 36 (2029-10-14) selection gate with credible gravimetric data but unproven volumetric performance. Technology transfer and licensing would reveal the shortfall, destroying the invention's value. Conversely, late discovery at Month 36–48 (2029-10-14 to 2030-10-14) would force either (a) acceptance of a cell that meets >=500 Wh/kg but falls to <=900 Wh/L (partial delivery, licensing appeal diminished), or (b) abandonment of the leading candidates and pivot to reserve chemistry at Month 36+, consuming 4–6 months and leaving only 36–40 months for final proof (insufficient for rigorous validation).

### 3.5.E Root Cause

The plan treats gravimetric and volumetric targets as separable, when they are coupled through cell architecture (separator thickness, electrolyte volume). Material-level chemistry alone does not determine cell-level Wh/L; packaging overhead does. The mass-and-volume model is correctly identified as critical but is deferred to Month 4 (2027-02-14) with no hard gate tied to volumetric projections until Month 30 (2029-04-14). By that time, sunk cost and team momentum favor continuing with a gravimetrically strong but volumetrically weak candidate rather than pivoting.

## 3.6.A Issue - Cycle-Life Gate (>=300 Cycles) Proposed But Not Enforced—One-Cycle Cell Could Pass Energy-Density Targets

Cycle life is often the last failure mode to surface. A new electrolyte or interface may show excellent Coulombic efficiency and smooth voltage curves for 50–100 cycles, then exhibit sudden capacity fade (cathode reconstruction, lithium-ion loss via electrolyte oxidation, or dendritic internal shorts) by cycle 150–200. If cycle-life testing is not run in parallel with energy-density characterization, and if the gate criteria do not require cycle-life data before chemistry promotion, a candidate could advance based on gravimetric/volumetric performance alone, only to fail at Month 24–30 (2028-10-14 to 2029-04-14) when cycling is completed.

### 3.6.B Tags

- cycle-life-gate-unenforced
- deferred-cycling-risk
- one-cycle-cell-loophole
- late-degradation-discovery

### 3.6.C Mitigation

By Month 3 (2027-01-14), define and publish cycle-life success criteria: >=300 cycles at 80% capacity retention; test protocol: C/10 discharge rate, 25 °C ambient, chemistry-specific voltage window (e.g., 0–4.5 V for lithium-metal cells), capacity measured every 50 cycles. By Month 12 (2027-10-14), all three active-chemistry candidates must have measured cycle-life data (>=100 cycles, >=2 replicates); deprioritize any candidate with <250 cycles at 80% unless a 2–4 month redesign (electrolyte additive, protective coating, binder rework) is demonstrably in progress with early-cycle (50 cycles) improvement shown. By Month 18 (2028-04-14), require pouch-cell builds to include parallel cycle-life stacks (dedicated cells cycled to failure alongside energy-density characterization cells); publish quarterly cycle-life atlas (failure mode, degradation mechanism, design consequence). By Month 30 (2029-04-14), freeze cycle-life requirement at >=300 cycles for final third-party verification; any candidate advancing to Month 36 (2029-10-14) selection gate must show measured cycle-life data (not projections) with identified end-of-life mechanism (e.g., 'lithium-ion depletion via electrolyte oxidation'). Publish the degradation curve and failure mode as part of the final patent and licensing specification.

### 3.6.D Consequence

Without enforced cycle-life gates, one or more leading candidates could reach Month 30 (2029-04-14) with strong energy-density data but inadequate cycle-life, forcing either (a) acceptance of a cell that meets headline Wh/kg and Wh/L but fails to deliver 300 cycles (licensing appeal destroyed, technology transfer partner rejects), or (b) abandonment of the candidate at Month 30+ and pivot to reserve chemistry, consuming 4–6 months and leaving insufficient runway for validation. Discovery of poor cycle-life at Month 36–48 (2029-10-14 to 2030-10-14) is existential: it invalidates the entire chemistry path and forces descope or programme stop.

### 3.6.E Root Cause

Cycle-life testing is inherently slow (100–300 cycles = 3–9 months at C/10 rate). The plan correctly identifies >=300 cycles as a success criterion but does not mandate parallel cycling from Month 12 (2027-10-14) onward. Instead, cycle-life testing is implicitly deferred to Months 24–30 (2028-10-14 to 2029-04-14), creating a 'discovery surprise' late in the programme. Risk-averse approach would run 100-cycle stacks in parallel with energy-density characterization from Month 9 (2027-07-14) onward, accepting higher upfront opex (more cells, longer cycling equipment queues) in exchange for earlier warning and pivot opportunity.

---

# 4 Expert: Battery IP and Licensing Strategy Counsel

**Knowledge**: Battery patent landscape (lithium-metal, solid-state, conversion cathodes), patent drafting and filing strategy, technology-transfer agreements, licensing terms and exclusivity models, IP contamination risk from competitor hires, clean-room employee protocols

**Why**: Ecosystem, Talent and IP Position is a High-priority decision complicated by proximity to Tesla. The plan's non-commercial mandate and open university partnerships offer licensing appeal, but weak patent position from open sharing and IP-contamination exposure from competitor hires could reduce licence value by 30–50% (estimate). An IP counsel can design a provisional-filing strategy (≥6 filings in Months 6–12 = 2027-04-14 to 2027-10-14, proposed) that protects core chemistries and cell architectures while enabling publication, and can draft clean-room onboarding protocols and technology-transfer templates aligned with prospective licensees.

**What**: By Month 1 (2026-11-14), develop and implement mandatory clean-room onboarding (non-use agreement, 6-month probationary observation for Tesla/competitor hires, weekly IP-compliance audits). By Month 2 (2026-12-14), establish IP strategy: which compositions and architectures warrant provisional patents, which are publishable, and IP ownership terms for university/national-lab partners. By Month 24 (2028-10-14), finalize licensing framework and identify potential licensee requirements (exclusive/non-exclusive tiers, application scope, royalty terms).

**Skills**: Patent drafting and filing (batteries, materials, processes), patent landscape searches, clean-room and employee IP protocols, technology-transfer agreement drafting, licensing and royalty structures, freedom-to-operate analysis, IP contamination prevention and remediation

**Search**: battery patent attorney IP strategy solid-state lithium metal, technology transfer licensing framework

## 4.1 Primary Actions

- By Month 1 (2026-11-14), convene the Steering Committee and lock cycle-life (≥300 cycles at 80%) and volumetric (≥950 Wh/L interim) gate criteria as binding, non-negotiable thresholds. Document a signed agreement and attach to tranche-release conditions. This prevents late discovery of failure and ensures all chemistry designs optimize for both targets from Month 6 (2027-04-14) onward.
- By Month 2 (2026-12-14), execute formal MOUs with ≥2 university/national-lab partners (UT Austin, NREL, Argonne or equivalent) committing ≤3 week characterization turnaround, ≥15% co-funding, and 30–60 day exit clauses. Secure written capacity and cost-share commitments before Month 3 (2027-01-14) to avoid 4–8 week queue delays.
- By Month 0 (2026-10-14 today), conduct a bottom-up payroll recount for all 100 FTE at Austin market rates. If baseline payroll exceeds USD 10 M/yr, immediately notify the Funder and request either a USD 15–30 M budget top-up or a formal FTE reduction plan (to 70–80 FTE). Confirm Funder decision by Month 1 (2026-11-14) and update the budget-allocation estimate.
- By Month 1 (2026-11-14), engage Austin Fire Authority, TCEQ and Travis County as collaborative partners via pre-application meetings. Propose phased permits (Phase 1 dry-room by Month 3 = 2027-01-14, Phase 2 synthesis by Month 6 = 2027-04-14, Phase 3 abuse testing by Month 9 = 2027-07-14). Hire EHS lead immediately and submit Phase 1 permit application by Month 2 (2026-12-14).
- By Month 2 (2026-12-14), execute a lease or operating agreement for modular containerized dry-room and pouch-cell fabrication equipment (50–100 cells/month) with 60-day exit optionality. Deploy on-site by Month 3 (2027-01-14) and confirm dew-point control, electrode-coating uniformity and electrolyte-dosing reproducibility before first cell builds in Month 6 (2027-04-14).

## 4.2 Secondary Actions

- By Month 3 (2027-01-14), establish the cell-level mass-and-volume model with live projections for all three chemistry candidates. Flag any chemistry unable to meet ≥950 Wh/L despite ≥500 Wh/kg material performance for targeted separator and electrolyte-volume reduction work by Month 12 (2027-10-14).
- By Month 3 (2027-01-14), define and document quantitative safety pass/fail criteria for all finalists: thermal-runaway onset ≥120 °C, reversibility after 150% overcharge (≥90% capacity recovery), and internal short-circuit survivability (no thermal runaway within 5 minutes of nail penetration). Assign a designated budget (USD 2–3 M) for thermal-ramp screening and contracted abuse testing.
- By Month 1 (2026-11-14), develop and publish clean-room onboarding protocol for all employees. Require non-use agreements and 6-month probationary observation for hires from Tesla, Panasonic, Samsung, CATL or competitors. By Month 2 (2026-12-14), file ≥6 provisional patents covering anode, cathode and electrolyte combinations to establish priority and create defensible patent estate.
- By Month 24 (2028-10-14), if two of three leading chemistries show fundamental cycle-life or volumetric limitations, initiate pre-staging of reserve chemistry: place precursor orders, pre-configure pilot-line equipment and assign team members to training. Target first reserve-chemistry pouch cells by Month 30 (2029-04-14) if Month 24 (2028-10-14) data confirms need for pivot.
- By Month 30 (2029-04-14), require independent third-party measured pouch-cell data (accredited test lab, ≥100 mAh, ≥3 replicates) demonstrating both ≥500 Wh/kg and ≥950 Wh/L on the same cells. If Wh/kg is met but Wh/L is not, allocate a focused 6-month architecture sprint (Months 30–36 = 2029-04-14 to 2029-10-14) before the selection gate.
- By Month 12 (2027-10-14), publish cycle-life degradation curves and root-cause forensics for all candidates. Demote any candidate with measured <250 cycles to reserve status unless a 2–4 month interface redesign is in progress. Document the reserve-chemistry contingency plan with precursor suppliers, lead times and equipment reconfiguration requirements.
- By Month 24 (2028-10-14), finalize IP and licensing framework with legal counsel. Define ownership of jointly developed IP with partners (programme owns final integrated cell architecture and processes; partners retain publication rights after 6-month review), scope of defensible patent estate (minimum: cell architecture, key compositions, interface designs), and licensing-term assumptions for technology transfer.
- By Month 36 (2029-10-14), select one finalist meeting all Month 30 (2029-04-14) thresholds plus thermal-runaway onset ≥120 °C. Document go/no-go decision and confirm ≥USD 15 M pivot runway remains intact. If no candidate meets thresholds, escalate to Steering Committee for descope or stop decision; do not proceed to Month 36+ spending on a single unproven path.

## 4.3 Follow Up Consultation

In the next consultation (Month 1, 2026-11-14), review (1) executed partner MOUs and confirmed characterization turnaround and co-funding; (2) Steering Committee decision document on cycle-life and volumetric gate criteria; (3) bottom-up payroll recount and Funder response on budget top-up or FTE reduction; (4) Phase 1 permit application submitted and Austin Fire Authority pre-negotiation outcomes; (5) modular pilot-line lease executed with deployment timeline confirmed. Bring data and contracts, not assumptions. The plan is sound in structure but execution hinges on these five pre-Month 3 (2027-01-14) decisions.

## 4.4.A Issue - Cycle-life and volumetric thresholds remain proposed, not agreed. Risk: late discovery of 150-cycle failure or <950 Wh/L shortfall undermines the entire gate structure.

The plan sets cycle-life (≥300 cycles at 80%) and volumetric (≥950 Wh/L interim) thresholds as "proposed," not negotiated with the Funder or Steering Committee. If these criteria are not locked by Month 3 (2027-01-14), designs will continue optimizing for ≥500 Wh/kg gravimetric only. Discovery of poor cycle-life at Month 24+ or volumetric collapse at Month 30+ forces costly redesign or chemistry pivot, consuming 6–12 months and USD 10–20 M. The plan lacks a signed Steering Committee decision document confirming these thresholds are binding.

### 4.4.B Tags

- gate_criteria_not_binding
- late_failure_discovery_risk
- missing_steering_committee_sign_off

### 4.4.C Mitigation

By Month 1 (2026-11-14), convene the Steering Committee (Director, Chemistry Leads, Funder Rep, external advisor) and conduct a 2-hour structured decision meeting. Present the proposed thresholds with failure-consequence modeling: if ≥300 cycles is not met, estimate cost and time of interface redesign (USD 3–5 M, 3–4 months); if ≥950 Wh/L is missed, estimate separator-thickness and electrolyte-volume reduction sprint (USD 8–15 M, 6 months). Document a signed gate-criteria agreement by Month 2 (2026-12-14) stating these are binding and non-negotiable unless Steering Committee agrees to formal revision. Attach the agreement to the Funder's tranche-release conditions.

### 4.4.D Consequence

Without binding thresholds, the programme drifts toward a single chemistry bet on gravimetric density alone. Cycle-life or volumetric shortfalls discovered at Month 36+ are too late to fix within the 84-month timeline. The pivot runway (USD 15 M) proves insufficient; the programme either delivers a partial result (500 Wh/kg but <250 cycles or <900 Wh/L) or exhausts reserves and misses delivery. Licensing value collapses because a partner cannot commercialize an untested or single-metric cell.

### 4.4.E Root Cause

The plan documents thresholds as "proposed" because they were drafted without formal Steering Committee or Funder approval. The planning process did not include a sign-off gate; instead, thresholds were written as best-practice recommendations. This is typical in early planning, but executable programmes require binding agreement before Month 3 (2027-01-14).

## 4.5.A Issue - Partner agreements and characterization access are not yet secured. Risk: 4–8 week queue delays and partner deprioritization slow the design-build-test loop by 50–75%, pushing delivery to Month 90–96 (2034-04-14 to 2034-10-14).

The plan specifies ≥2 university/national-lab agreements by Month 3 (2027-01-14) with ≤3 week turnaround and 30–60 day exit. However, no executed letters of intent, memoranda of understanding or cost-share commitments from UT Austin, NREL, Argonne or others have been provided. Partner queues at major national labs routinely reach 6–10 weeks during peak periods. If agreements are not negotiated and signed by Month 2 (2026-12-14), the programme will face 4–8 week characterization delays starting Month 8 (2027-06-14). This directly throttles hypothesis throughput and extends discovery by 3–6 months. Loss of a partner mid-programme (deprioritization, budget reallocation) forces commercial outsourcing at USD 2–5 M/yr, further draining reserves.

### 4.5.B Tags

- partner_agreements_not_executed
- characterization_queue_risk
- partner_loss_contingency_missing

### 4.5.C Mitigation

Immediate action (Month 0, 2026-10-14): Contact UT Austin Materials Science & Engineering, NREL Electrochemistry Branch and Argonne Applied Materials Division; schedule 1-hour pre-negotiation calls with each to confirm capacity, turnaround timelines and co-funding appetite. By Month 1 (2026-11-14), prepare formal MOU templates (3–5 pages, cost-share rates, ≤3 week SLA, exit clauses) and send to all three partners. Target two signed agreements by Month 2 (2026-12-14), with a third backup by Month 3 (2027-01-14). Commit in-house characterization instrument (SEM/EDS or XRD, USD 2–3 M, operational by Month 8 = 2027-06-14) to reduce partner dependency. Negotiate commercial characterization backup (Intertek, TUV, or university contract services) with priority-queue access and 6-week commitment for overflow.

### 4.5.D Consequence

Unsigned partner agreements at Month 3 (2027-01-14) delay first full-characterization loop (hypothesis → synthesis → characterization → design iteration) by 4–8 weeks. Over 84 months, this compounds: a 6-week delay per cycle × 8–12 discovery cycles = 48–72 week net delay. Partner loss without backup forces emergency commercial outsourcing at USD 2–5 M/yr (marginal cost ~USD 0.5–2 M, estimate) plus 8–10 week queue times, reducing effective discovery to 60–72 months. Chemistry-tournament decisions slip from Month 36 (2029-10-14) to Month 42–48 (2030-04-14 to 2030-10-14), leaving insufficient runway for final validation and technology transfer.

### 4.5.E Root Cause

The plan assumes partner agreements as done, but they are not yet negotiated. This is a pre-execution task that fell into planning-document scope rather than immediate action. Most university and national-lab partnerships require 2–3 month negotiation and require a signed commitment to co-fund or provide in-kind resources before work begins.

## 4.6.A Issue - Payroll baseline (USD 10 M/yr) is understated by ~USD 4.8 M/yr. Risk: Budget exhausts by Month 48–54 (2030-10-14 to 2031-04-14), forcing staff reduction or pivot failure if payroll is corrected.

The plan allocates USD 70 M for payroll over 84 months (~USD 10 M/yr baseline) but flags a warning that bottom-up payroll could reach USD 14.8 M/yr (USD 103.6 M over 7 years), a shortfall of ~USD 33.6 M. With 100 FTE and Austin near-Tesla salary benchmarks (postdocs USD 60–75 K, senior scientists USD 120–160 K, engineers USD 90–130 K), USD 10 M/yr is unrealistic. The plan does not provide a bottom-up estimate; this is a red flag. If payroll is corrected to USD 12.9–16.6 M/yr (the flagged range), the budget envelope USD 280 M (excluding reserves) is consumed by payroll (USD 90–116 M) + capital (USD 50 M) + facilities (USD 25 M) = USD 165–191 M, leaving only USD 89–115 M for experiments, partners, testing, outsourcing and contingency. This is insufficient for a USD 15 M pivot, a USD 20 M reserve and a chemistry tournament over 7 years.

### 4.6.B Tags

- payroll_underestimated
- budget_envelope_integrity_at_risk
- reserve_depletion_scenario

### 4.6.C Mitigation

By Month 0 (2026-10-14), conduct a bottom-up payroll recount: list all planned roles (100 FTE baseline) with Austin market rates (postdocs ~USD 65 K, scientists ~USD 130 K, engineers ~USD 105 K, support ~USD 55 K, Director ~USD 200 K) and compute total annual payroll. If the result exceeds USD 12 M/yr, raise it to the Funder immediately and request a budget amendment (add USD 15–30 M to the USD 300 M cap, or descope roles). Alternatively, reduce FTE targets from 100 to 70–80 (eliminate lower-priority support roles) or lock a hiring freeze after Month 36 (2029-10-14) to control burn. Document the chosen payroll path and confirm the Funder's appetite for either a top-up or a reduced FTE model by Month 1 (2026-11-14). Update the budget-allocation estimate in the plan immediately if payroll corrections push total opex beyond USD 280 M.

### 4.6.D Consequence

If payroll is actually USD 14.8 M/yr and this is not corrected until Month 12 (2027-10-14) or later, the programme will have spent USD 105–120 M (14.8 M/yr × 7–8 months + capital), consuming 35–40% of the budget before discovering the shortfall. Months 24–48 (2028-10-14 to 2030-10-14) then face either forced staff cuts (attrition and morale damage) or budget reallocation that starves experiments, partner funding or pivot runway. A pivot at Month 36–42 (2029-10-14 to 2030-04-14) becomes impossible because reserves are depleted. The programme either descopes (reduce FTE, defer characterization, cut partners) or stops.

### 4.6.E Root Cause

The baseline payroll of USD 10 M/yr was likely a top-down constraint (USD 300 M cap ÷ 7 years ÷ multiple budget lines) rather than a bottom-up build from headcount and market rates. Austin salary benchmarks and seniority requirements (20–30% postdocs/graduates at lower cost, 70–80% experienced scientists and engineers) were not fully accounted. This is a common planning error when budgets are fixed before hiring planning is done.

---

# 5 Expert: Programme Finance and Budget Manager

**Knowledge**: R&D programme budgeting, tranche-release mechanics, capital equipment financing, payroll and FTE forecasting, contingency reserve management, burn-rate forecasting and cash-flow bridging

**Why**: The pre-project assessment and budget allocation reveal a critical opex-versus-tranche mismatch: average opex ~USD 32.9 M/yr (estimate) versus Months 36-84 (2029-10-14 to 2033-10-14) tranche rate USD 22.5 M/yr, requiring ~USD 41 M carry-forward (estimate). Payroll may reach ~USD 14.8 M/yr (estimate) versus USD 10 M/yr baseline, adding ~USD 34 M over 7 yrs (estimate). The USD 20 M unallocated reserve plus USD 15 M pivot runway can be exhausted by a concurrent pivot and volumetric sprint (USD 13-25 M stress case, estimate). A finance manager can validate the tranche schedule against confirmed payroll, equipment lead-times and gate-release conditions, and ensure contingency release triggers are clear to the Steering Committee.

**What**: By Month 1 (2026-11-14), reconcile bottom-up payroll forecasts (80-120 FTE, estimate; salary benchmarks near Tesla) against the USD 10 M/yr baseline; flag any shortfall and propose either budget augmentation, staffing cap, or deferred hiring phases. By Month 2 (2026-12-14), build a live cash-flow model tracking tranche release, payroll, capital drawdown (pilot line, instruments, abuse chambers) and burn rate; identify the Month 36 (2029-10-14) cash position and confirm whether a pivot plus volumetric sprint (USD 13-25 M, estimate) would trigger reserve depletion. By Month 12 (2027-10-14) and quarterly thereafter, review actual versus forecast; highlight any tranche-release gate slip or accelerated burn.

**Skills**: Budget forecasting and variance analysis, payroll and FTE planning, capital-equipment procurement and lead-time tracking, contingency reserve quantification and release triggers, cash-flow bridging and carry-forward mechanics, funder reporting and tranche-gate documentation

**Search**: R&D programme manager budget tranche funding, research laboratory financial planning, capital equipment project finance

## 5.1 Primary Actions

- By Month 2 (2026-12-14 at 10:00): Finance lead and programme director produce a detailed 84-month cash-flow model (monthly detail through Month 36 = 2029-10-14, quarterly thereafter) showing payroll, capex, opex and partner spending; identify the USD 41 M carry-forward requirement and jointly agree with funder on a bridge mechanism (deferral, top-up, or external co-funding) or funder commits to accept incomplete validation if carry-forward is insufficient.
- By Month 1 (2026-11-14 at 09:00): Programme director and finance lead conduct Austin-market salary benchmarking (via recruiter survey) for battery PhD (target USD 200–240 K) and postdoc (USD 120–160 K) roles; produce a bottom-up FTE roster for Months 0–36 (2026-10-14 to 2029-10-14) with named roles, start dates and total committed payroll. If payroll baseline exceeds USD 12 M/yr, agree with steering committee on hiring freeze triggers and FTE-reduction contingency.
- By Month 6 (2027-04-14 at 10:00): Chemistry and operations leads co-produce a detailed reserve-chemistry specification including named fallback chemistry, itemized BOM with ≥2 pre-qualified suppliers (lead times confirmed <3 weeks), pilot-line reconfiguration plan (coating, stacking, pressure hardware steps with person-day estimates), and named FTE allocation (20–30%) for Months 24–30 (2028-10-14 to 2029-04-14). Place non-binding LOIs with precursor suppliers by Month 12 (2027-10-14) to reserve capacity.
- By Month 1 (2026-11-14 at 14:00): Programme director initiates formal site-lease negotiation for an Austin facility (Southeast Austin or Northeast Travis County, ≥5,000 m² for wet chemistry and dry-room ops); execute lease by Month 1 (2026-11-14 at 17:00) with occupancy by Month 3 (2027-01-14). Confirm power (500+ kVA), HVAC and hazmat-waste handling infrastructure in writing.
- By Month 1 (2026-11-14 at 16:00): Programme director executes a modular pilot-line lease or operating agreement (50–100 cells/month capacity, containerized dry-room and pouch-cell line, 3-year term with month-to-month expansion and 60-day exit) with deployment on-site by Month 3 (2027-01-14); negotiate monthly operating cost not to exceed USD 60–100 K/month. Verify dry-room dew-point control (<−30 °C) and electrode-coating uniformity (±10 µm) before first cell builds by Month 6 (2027-04-14).

## 5.2 Secondary Actions

- By Month 0 (2026-10-14 at 17:00): Programme director schedules collaborative pre-application meetings with Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ) and Travis County Environmental Services to co-design phased permits (Phase 1 dry-room by Month 3 = 2027-01-14; Phase 2 synthesis by Month 6 = 2027-04-14; Phase 3 abuse testing by Month 9 = 2027-07-14).
- By Month 1 (2026-11-14 at 11:00): Hire an experienced EHS officer (≥5 years battery-lab or manufacturing background) to lead hazmat-permitting compliance; assign compilation of EPA 40 CFR 260–273, OSHA 29 CFR 1910.1200/1910.307 and TCEQ air/water permit requirements by Month 2 (2026-12-14).
- By Month 2 (2026-12-14 at 10:00): Submit Phase 1 permit application (dry-room, pouch assembly, non-hazardous reagents) to TCEQ and Austin Fire Authority; request 6-week review cycle for approval by Month 3 (2027-01-14). Negotiate conditional-use authorization with fire authority to allow operations under daily monitoring if full permits slip beyond Month 3 (2027-01-14).
- By Month 1 (2026-11-14 at 13:00): IP counsel develops and publishes clean-room onboarding protocol for all employees; all hires from commercial battery firms (Tesla, Panasonic, Samsung, CATL) sign non-use agreement and complete 6-month probationary observation before core synthesis/formulation access.
- By Month 3 (2027-01-14 at 11:00): Execute formal agreements with ≥2 university or national-laboratory characterization partners (UT Austin, NREL, Argonne) guaranteeing ≥10–15 characterization slots/month with ≤3 week turnaround (≤21 calendar days from submission to report), annual cost-sharing ≥15%, and 30–60 day exit clauses.
- By Month 3 (2027-01-14 at 10:00): Steering Committee fixes hard-gate criteria: cycle-life ≥300 cycles at 80% retention (C/10 discharge rate, 25 °C, 0–4.5 V); volumetric interim threshold ≥950 Wh/L at cell level; final thermal-runaway onset ≥120 °C (differential scanning calorimetry, 5 °C/min). Publish gate-decision rules for Month 18 (2028-04-14) and Month 36 (2029-10-14) in the steering-committee charter.
- By Month 4 (2027-02-14 at 10:00): Cell engineering lead builds and publishes a live mass-and-volume cell model (current-collector thickness, separator, electrolyte volume, pouch-packaging mass); back-calculate material-level targets from user 500 Wh/kg and 1000 Wh/L cell goals. Update model quarterly; first output by Month 6 (2027-04-14) for all three chemistry candidates.
- By Month 2 (2026-12-14 at 14:00): IP counsel files strategy document covering clean-room protocols, provisional-patent schedule (target ≥6 in Months 6–12 = 2027-04-14 to 2027-10-14), publication embargo (6 months pre-patent), and licensing framework; finalize licensing terms and target-licensee identification criteria by Month 24 (2028-10-14).
- By Month 12 (2027-10-14 at 16:00): Chemistry leads document detailed contingency plans for all reserve chemistries (BOM, precursor sources, pilot-line reconfigurations, FTE assignments); place non-binding supplier LOIs confirming <3 week precursor lead times. Identify which two of three leading chemistries are highest-priority reserves.

## 5.3 Follow Up Consultation

At the next consultation (target: Month 1 = 2026-11-14 at 14:00), confirm: (1) funder's appetite for a cash-flow bridge or top-up if carry-forward falls short by Month 36 (2029-10-14); (2) whether payroll baseline will be revised upward to USD 12–14 M/yr or whether FTE scope is constrained; (3) site lease execution status and permitting timeline from Fire Authority and TCEQ; (4) which reserve chemistry will be pre-staged by Month 24 (2028-10-14) and confirmation of precursor-supplier commitment; (5) steering-committee composition, independent red-team selection and gate-decision protocols. Review cash-flow, payroll and reserve-chemistry plans monthly; escalate any payroll overage or precursor-sourcing delays to steering committee within 2 weeks of discovery.

## 5.4.A Issue - Opex-to-Tranche Mismatch Unresolved; Cash-Flow Gap Threatens Months 36–84 (2029-10-14 to 2033-10-14) Operations

The plan projects average opex of USD 32.9 M/yr (payroll ~USD 10–14.8 M/yr + experiments, partners, testing, EHS, computing ~USD 22.9 M/yr), but the Months 36–84 (2029-10-14 to 2033-10-14) tranche is only USD 22.5 M/yr (USD 90 M / 4 yrs). This requires USD ~41 M carry-forward from Months 0–36 (2026-10-14 to 2029-10-14) underspend. No cash-flow bridge, sweep mechanism or forward-financing plan is documented. Risk: if Months 0–36 (2026-10-14 to 2029-10-14) spending is front-loaded (equipment, hiring, experiments), carry-forward shortfall appears by Month 48–54 (2030-10-14 to 2031-04-14), forcing mid-programme budget cuts, staff furlough or external borrowing.

### 5.4.B Tags

- cash-flow-gap
- opex-vs-tranche-mismatch
- financing-bridge-missing
- payroll-understatement

### 5.4.C Mitigation

By Month 2 (2026-12-14), finance lead must produce a detailed 84-month cash-flow model (monthly detail Months 0–36 = 2026-10-14 to 2029-10-14, quarterly thereafter) showing: (i) month-by-month payroll, capex, opex and partner spending; (ii) carry-forward balance and sweep to months 36–84 (2029-10-14 to 2033-10-14); (iii) decision rules if carry-forward falls below USD 5 M (e.g., hiring freeze, outsource more synthesis). By Month 6 (2027-04-14), programme director and funder must agree on either (a) deferral of Months 36+ spending to fit the tranche, (b) top-up funding, (c) external cost-sharing with partners, or (d) payroll/scope reduction. Revisit monthly and reforecast if payroll rises above USD 12 M/yr.

### 5.4.D Consequence

Without a cash-flow bridge, the programme may face a liquidity crisis by Month 48–54 (2030-10-14 to 2031-04-14) of USD 10–20 M shortfall. This would force emergency cost cuts (staff reductions, experiment delays, partner commitments broken), halt progress and trigger funder dissatisfaction. Technology transfer or final validation could slip into Month 90+ (2034-04-14+) or be incomplete.

### 5.4.E Root Cause

The budget allocation estimate (payroll 70 + capex 50 + facility 25 + experiments/partners 135 + reserve 20 = 300) does not align with the cash-release schedule. Months 0–36 (2026-10-14 to 2029-10-14) receive USD 210 M but Months 36–84 (2029-10-14 to 2033-10-14) receive only USD 90 M on a flat-rate spending profile. No mechanism (debt, external grants, funder top-up agreement, or scope deferral) is negotiated.

## 5.5.A Issue - Payroll Baseline Understated; Actual Cost May Exceed Reserve by USD 34 M Over 7 Years

Plan assumes USD 10 M/yr payroll baseline (USD 70 M over 7 yrs for ~100 FTE), but internal pre-assessment flag notes bottom-up payroll could reach USD 14.8 M/yr (USD 104 M over 7 yrs), a gap of USD 34 M. Senior battery electrochemists near Tesla command USD 200–280 K salaries; plan budgets 15–20% premiums and 3–5 yr retention but does not cost them out. No detailed FTE roster, salary bands or hiring timeline exists. Risk: by Month 12 (2027-10-14), actual committed payroll could be USD 12–15 M/yr, consuming the USD 20 M reserve and USD 5 M general contingency in Months 24–30 (2028-10-14 to 2029-04-14).

### 5.5.B Tags

- payroll-understatement
- reserve-consumption
- fte-costing-missing
- salary-benchmarking-absent

### 5.5.C Mitigation

By Month 1 (2026-11-14), programme director and finance lead must produce a bottom-up FTE roster (roles, salaries, start dates, benefits, travel) for Months 0–36 (2026-10-14 to 2029-10-14), with sensitivity cases (10% and 20% salary variance). Conduct Austin-market salary survey via recruiter or EY for battery PhD roles; lock USD 200–240 K senior-scientist band and USD 120–160 K postdoc band. By Month 3 (2027-01-14), steering committee must agree on hiring freeze triggers (if payroll exceeds USD 12 M/yr, limit new senior hires; shift to postdocs or external collaborators). Reforecast payroll monthly against actuals; if cumulative deviation exceeds USD 1 M by Month 6 (2027-04-14), negotiate funder top-up or reduce FTE scope by 10–15%.

### 5.5.D Consequence

If actual payroll reaches USD 14.8 M/yr by Month 12 (2027-10-14) and remains there through Month 36 (2029-10-14), cumulative payroll overage is USD 12–18 M, consuming most of the USD 20 M reserve and leaving <USD 5 M for chemistry pivots, equipment overruns or partner contingencies. This forces a choice: (a) cut experiments and partner spending to preserve payroll (slowing science), (b) reduce FTE by 15–20% (losing continuity), or (c) defer equipment and facility spending (delaying cell builds). Any choice compresses the 84-month timeline.

### 5.5.E Root Cause

The baseline USD 10 M/yr was set without detailed role-by-role costing or market benchmarking. Battery talent near Tesla is scarce and expensive; a recruiting premium of 15–20% alone adds USD 1–2 M/yr. The plan's goal of 80–120 FTE without a staffing ramp, benefit burden (20–25% overhead), and senior/postdoc split leaves USD 4 M/yr unaccounted.

## 5.6.A Issue - Pre-Staged Reserve Chemistry and Pivot Execution Plan Inadequately Detailed; Month 36 (2029-10-14) Gate Risk Unmitigated

Plan commits to pre-staging a reserve chemistry by Month 24 (2028-10-14) and claims pivot can execute in 4–6 weeks, but no specifications exist: which reserve chemistry (lithium-sulfur fallback? conversion cathode?)? Which supplier for lithium compounds, salts, fluorinated solvents with <2 week lead times? Which pilot-line equipment reconfiguration (electrode-coating thickness, stacking procedure)? How many FTE allocated (20–30% of synthesis/cell-assembly, estimate)? If Month 30 (2029-04-14) third-party data show one chemistry lags, the 4–6 week pivot claim is untested. Risk: if precursors take 8–12 weeks (reality for specialty reagents), or pilot-line equipment requires 4–6 weeks reconfiguration (coating heads, pressure hardware), pivot slips to Month 32–36 (2029-06-14 to 2029-10-14), overlapping the selection gate and forcing a non-data-driven decision.

### 5.6.B Tags

- reserve-chemistry-unspecified
- pivot-execution-plan-missing
- precursor-sourcing-unvetted
- month36 (2029-10-14)-gate-risk

### 5.6.C Mitigation

By Month 6 (2027-04-14), chemistry and operations leads must co-produce a detailed reserve-chemistry pivot specification: (i) named reserve chemistry (e.g., 'conversion-cathode with gel electrolyte') with projected cell-level Wh/kg and Wh/L targets; (ii) itemized BOM (anode, cathode, electrolyte, separator, current collectors) with ≥2 qualified precursor suppliers, lead times and cost; (iii) pilot-line reconfiguration steps (coating-equipment changeover, stacking-procedure edits, pressure-hardware assembly) with estimated person-days and schedule; (iv) FTE allocation (20–30%, named individuals) for Months 24–30 (2028-10-14 to 2029-04-14). By Month 12 (2027-10-14), place non-binding letters-of-intent with precursor suppliers to confirm <3 week turnarounds and reserve stock. By Month 24 (2028-10-14), if two leading chemistries show stagnation (cycle-life plateau, Wh/L shortfall), execute the pre-staging: place firm precursor orders, configure pilot-line equipment, and run 2–3 reserve-chemistry test cells by Month 28 (2029-02-14) to validate process before the Month 30 (2029-04-14) gate.

### 5.6.D Consequence

Without a detailed, executed reserve plan, a Month 30 (2029-04-14) failure (e.g., both leading chemistries stuck at 450 Wh/kg or 900 Wh/L) forces a reactive 6–10 month pivot (sourcing, setup, validation), pushing first reserve-chemistry pouch cells to Month 40–44 (2030-02-14 to 2030-06-14). This leaves only 40–44 months for final validation and technology transfer versus the planned 48 months, compressing the final proof timeline and risking incomplete data at Month 84 (2033-10-14) delivery. Alternatively, steering committee attempts to 'rescue' a failing chemistry with rushed fixes (expensive additives, new binders), burning another 6–12 months before conceding failure.

### 5.6.E Root Cause

The plan identifies pre-staging as a risk mitigation but does not operationalize it. No named reserve chemistry, no supplier engagement, no pilot-line reconfiguration plan and no FTE pre-commitment exist. The claim that 'pre-staging shortens pivot to 4–6 weeks' is unsupported by documented sourcing and setup steps.

---

# 6 Expert: Characterization and Failure Forensics Strategist

**Knowledge**: Operando electrochemistry (X-ray diffraction, operando electron microscopy, impedance spectroscopy), post-mortem analysis (scanning-electron microscopy, energy-dispersive X-ray spectroscopy, Fourier-transform infrared spectroscopy), lithium-metal and solid-state interface degradation, structured failure-mode taxonomy and autopsy protocols

**Why**: Decision 10 (Characterization Access and Failure Forensics Model) is rated Medium priority but acts as a learning-loop accelerator: the split in-house/partner discovery structure depends on <3 week characterization turnaround, and failure-mode forensics closes the design-build-test loop. Without rapid, structured forensics, the programme risks repeating the same interface-degradation modes across candidates, wasting 12-18 months (estimate). The plan proposes in-house post-mortem instruments (USD 2-3 M, estimate) operational Month 8 (2027-06-14), but instrument selection, staffing, and forensics-protocol design must begin now. A forensics strategist can build the autopsy taxonomy, design the measurement cascade (SEM first, then depth-profile XRD, then compositional mapping), and ensure forensics reports feed design iteration within 5 business days.

**What**: By Month 3 (2027-01-14), design a standardized failure-autopsy protocol: every failed cell receives SEM/energy-dispersive X-ray spectroscopy within 48 hours, classified into a structured root-cause code (e.g., 'lithium-ion depletion via electrolyte oxidation,' 'dendrite growth with internal short-circuit'). By Month 6 (2027-04-14), specify in-house post-mortem instrument package (scanning-electron microscope with energy-dispersive X-ray spectroscopy capability OR high-resolution X-ray diffraction, USD 2-3 M estimate); confirm vendor lead-time and operational commissioning by Month 8 (2027-06-14). By Month 12 (2027-10-14), publish the first quarterly forensics atlas (internal summary of failure modes and design consequences); ensure 40%+ of failed cells have assigned degradation mechanisms.

**Skills**: Operando and post-mortem measurement planning, instrument specifications and vendor selection, structured failure-mode coding and taxonomy design, root-cause analysis and design-feedback loops, characterization queue management and turnaround-time optimization, forensics-data visualization and reporting

**Search**: battery failure analysis forensics characterization SEM operando X-ray, degradation mechanism post-mortem diagnostics

## 6.1 Primary Actions

- By 2026-10-21 at 17:00 (Month 0.25 = 2026-10-22, estimate): Contact Austin Fire Authority, TCEQ and Travis County Environmental Services as collaborative partners; schedule pre-application meetings and propose phased-permit approach (Phase 1 dry-room by Month 3 = 2027-01-14, Phase 2 synthesis by Month 6 = 2027-04-14, Phase 3 abuse testing by Month 9 = 2027-07-14). Request conditional-use authorization for Phase 1 to accelerate operational start.
- By 2026-11-14 at 09:00 (Month 1 = 2026-11-14): Hire an experienced EHS lead with ≥5 years battery-lab or chemical-manufacturing background; direct them to pre-negotiate firm synthesis contracts with ≥2 contract research organizations (Albemarle, Lithium Werks CRO, UT Austin core facility, or equivalent) specifying <4 week turnaround, cost-plus pricing and 200% surge capacity by Month 1 (2026-11-14). Draft outsourcing statement of work by Month 0 (2026-10-14) and execute by Month 1 (2026-11-14).
- By 2027-01-14 at 10:00 (Month 3 = 2027-01-14): Establish hard cycle-life gate: ≥300 cycles at 80% capacity retention (C/10 discharge, 25°C, 0–4.5 V window or chemistry-specific equivalent); define deprioritization rule that any candidate measured <250 cycles by Month 15 (2028-01-14) receives no new cell builds for 4 weeks pending a 2-4 week focused interface sprint; decision point at Month 18 (2028-04-14) to demote if no >30 cycle gain achieved.
- By 2027-02-14 at 10:00 (Month 4 = 2027-02-14): Build a live mass-and-volume cell model that back-calculates material-level Wh/kg and Wh/L targets from the cell-level 500 Wh/kg and 1000 Wh/L goals; include current collectors (10–20 µm), separator (25–30 µm), electrolyte (0.5–1.5 mL/Ah-equivalent), and pouch packaging (300–400 µm); project all three active chemistries by Month 6 (2027-04-14) and flag any candidate projecting <950 Wh/L despite >500 Wh/kg material performance for targeted separator and electrolyte-volume reduction by Month 9 (2027-07-14).
- By 2027-04-14 at 11:00 (Month 6 = 2027-04-14): Initiate small-scale pouch-cell prototypes (50–100 mAh, two-layer minimum) for all three active chemistries using representative current collectors, separators and electrolyte volumes; measure volumetric density directly and compare to model projection by Month 12 (2027-10-14); any shortfall >5% versus projection triggers immediate architecture redesign (separator thickness, electrode density, electrolyte volume optimization) Months 12-18 (2027-10-14 to 2028-04-14).
- By 2027-01-14 at 14:00 (Month 3 = 2027-01-14): Execute ≥2 formal standing agreements (3–5 year terms, ≤3 week characterization turnaround, 30–60 day exit clauses) with university (UT Austin) or national-laboratory partners (NREL, Argonne) for operando and post-mortem diagnostics; negotiate ≥15% partner cost-sharing on materials and characterization (estimate USD 0.5–1 M/yr) and guaranteed monthly characterization slots (≥10–15 per month). Secure backup characterization agreement (Intertek, TUV or university contract services) with ≤6 week emergency-access commitment at USD ≤100 K per full analysis.
- By 2028-10-14 at 10:00 (Month 24 = 2028-10-14): If two of three leading chemistries show fundamental cycle-life (<250 cycles) or volumetric (<950 Wh/L despite >500 Wh/kg material) limitations after 18 months of interface engineering, initiate pre-staging of reserve chemistry: place firm precursor orders (8–12 week lead times), pre-configure pilot-line equipment and assign 20–30% of synthesis team to reserve-path training by 2028-10-31. Allocate USD 10–15 M pivot-runway reserve and hold through Month 30 (2029-04-14) for rapid execution if Month 30 (2029-04-14) verification confirms one leading chemistry is inferior.

## 6.2 Secondary Actions

- By 2027-01-14 at 10:00 (Month 3 = 2027-01-14): Publish quantitative safety pass/fail criteria for all finalists—thermal-runaway onset ≥120°C (differential scanning calorimetry, 5°C/min ramp), reversibility after 150% state-of-charge overcharge (≥90% capacity recovery), and internal-short survivability (nail penetration, no thermal runaway within 5 minutes). Deprioritize any candidate with onset <100°C unless 2-month interface redesign shows clear path to ≥120°C.
- By 2027-04-14 at 09:00 (Month 6 = 2027-04-14): Initiate coin-cell thermal-ramp screening (differential scanning calorimetry or contracted lab) for all three active chemistries; measure onset and heat-release rate for ≥2 samples per candidate; flag any with onset <100°C for deprioritization unless redesign path is clear by Month 9 (2027-07-14).
- By 2027-07-14 at 14:00 (Month 9 = 2027-07-14): Contract external accredited abuse-testing facility (Intertek, TUV or equivalent) for nail-penetration and overcharge tests on 2–3 candidate pouch cells; negotiate 8-week turnaround and cost <USD 20 K per full protocol; use results to rank chemistry safety by Month 30 (2029-04-14).
- By 2027-10-14 at 16:00 (Month 12 = 2027-10-14): Document detailed contingency plans for all reserve chemistries: list precursor suppliers (≥2 per key material), process steps, dry-room conditions, pilot-line reconfiguration and staff retraining requirements (estimate 1–2 weeks per person). Identify single-chemistry deprioritization rules based on measured cycle-life and Wh/L data.
- By 2027-04-14 at 10:00 (Month 6 = 2027-04-14): Establish forensics protocol and autopsy tracking: every failed cell receives standardized destructive post-mortem within one week; assign findings to structured root-cause codes (e.g., 'lithium-ion depletion via electrolyte oxidation,' 'dendrite growth'); publish quarterly forensics atlas by Month 12 (2027-10-14) and thereafter, feeding design iteration directly.
- By 2026-11-14 at 13:00 (Month 1 = 2026-11-14): Develop and publish clean-room onboarding protocol for all employees: non-use agreements from day one for hires from Tesla or competitors; 6-month probationary observation period (non-core synthesis only, no access to final designs) with weekly IP-compliance audits. File ≥6 provisional patents in Months 6–12 (2027-04-14 to 2027-10-14) covering anode, cathode and electrolyte combinations.
- By 2028-04-14 at 16:00 (Month 18 = 2028-04-14): Conduct IP-contamination risk assessment: interview all staff with prior commercial battery experience; document any inadvertent incorporation of prior-employer design principles; file continuation or divisional patents if independent development is clear.
- By 2028-10-14 at 14:00 (Month 24 = 2028-10-14): Finalize IP and licensing framework with legal counsel experienced in battery IP: define ownership of jointly developed IP with partners (proposed: programme owns final integrated cell architecture and manufacturing processes; partners retain publication rights after 6-month review), scope of defensible patent estate, and licensing-term assumptions for technology transfer.
- By Month 12 (2027-10-14) and monthly thereafter: Run Steering Committee gate reviews within 3 weeks of evidence submission; require measured cell-level data (not projections) before gate passage; escalate to funder if any leading chemistry misses cycle-life or volumetric thresholds.

## 6.3 Follow Up Consultation

Next meeting should address: (1) confirmation of volumetric-density gate timing (Month 18 = 2028-04-14 vs. Month 30 = 2029-04-14) and architecture-sprint resource allocation; (2) cycle-life deprioritization enforcement and stop/descope rules at Month 15–18 (2028-01-14 to 2028-04-14) if a leading candidate stalls; (3) permitting timeline and conditional-use authorization from fire authority (target: Phase 1 approval by Month 4 = 2027-02-14); (4) pre-negotiated CRO contracts and cost-plus terms to hedge 6-8 month permitting slip; (5) reserve-chemistry pre-staging plan, precursor long-lead ordering timeline and pivot-runway allocation (USD 10–15 M) by Month 24 (2028-10-14); (6) partner co-funding commitments (≥15% proposed) and backup characterization agreements by Month 3 (2027-01-14); (7) licensing-framework and prospective-licensee engagement strategy (target: Month 12 = 2027-10-14 informal contacts, Month 24 = 2028-10-14 formal framework).

## 6.4.A Issue - Volumetric density gate at Month 30 (2029-04-14) is dangerously late; risk of cascading redesign failure

The plan requires third-party pouch-cell verification of ≥950 Wh/L at Month 30 (2029-04-14), 30 months into the programme. Material-level volumetric gains collapse once current collectors, separators, electrolyte volume and packaging mass are included. If volumetric density falls short at Month 30 (2029-04-14) despite gravimetric success, a 6-month architecture sprint (Months 30-36 = 2029-04-14 to 2029-10-14) must compress separator thickness, electrolyte volume and packaging—aggressive changes that often degrade cycle life or thermal stability. The plan allocates only USD 8-15 M (estimate) for this sprint, but simultaneous cycle-life or safety rework could exceed reserves. Worse, negative results at Month 30 (2029-04-14) leave only 36 months for recovery before Month 72 (2032-10-14) delivery, risking incomplete third-party validation.

### 6.4.B Tags

- volumetric-density-gate-timing
- late-packaging-penalty-discovery
- cascading-redesign-cost
- delivery-timeline-compression

### 6.4.C Mitigation

Advance volumetric-density verification to Month 18 (2028-04-14) using small single-layer or two-layer pouch proxies (50-100 mAh) built with representative current collectors, separators and electrolyte volume. Lock the mass-and-volume model output by Month 6 (2027-04-14) and flag any chemistry projecting <950 Wh/L despite >500 Wh/kg material performance by Month 9 (2027-07-14) for immediate separator or electrolyte-volume redesign. Allocate USD 3-5 M (within opex) for early pouch prototyping Months 12-18 (2027-10-14 to 2028-04-14). If Month 18 (2028-04-14) data shows volumetric shortfall, execute architectural sprint Months 18-24 (2028-04-14 to 2028-10-14), shortening decision lead time by 12 months and preserving 48 months for final validation and cycle-life recovery.

### 6.4.D Consequence

Without early volumetric verification, a month-long architecture redesign at Month 30-36 (2029-04-14 to 2029-10-14) with poor cycle-life outcome forces either descope (dropping 1000 Wh/L target, reducing invention value) or a costly 8-12 month pivot, leaving only 24-28 months for final validation. Incomplete third-party validation by Month 72 (2032-10-14) jeopardizes licensability and forces extension beyond the 84-month cap.

### 6.4.E Root Cause

Plan assumes gravimetric and volumetric targets decouple; material-level Wh/kg gains are pursued without running in parallel pouch-cell builds to confirm Wh/L survival. Coin-cell and single-layer proxies test individual interfaces but do not reveal multi-layer stacking, electrolyte distribution or current-collector IR losses that determine volumetric density. Late discovery treats volumetric failure as a 6-month redesign rather than a 12-18 month pathway issue.

## 6.5.A Issue - Cycle-life gate is set but not enforced; no deprioritization rule until Month 24 (2028-10-14), risking 18-month sunk effort on degradation-prone candidates

The plan proposes a ≥300 cycle at 80% retention threshold by Month 3 (2027-01-14), with measured cycle data expected from Month 12 (2027-10-14). However, deprioritization of candidates with <250 cycles is deferred until Month 24 (2028-10-14)—18 months after the gate is set, and after 12-18 months of materials optimization on a degradation-prone chemistry. In a staged tournament, a candidate stuck below 250 cycles despite aggressive interface engineering (dopants, coatings, binders) typically signals an incompatible anode–cathode–electrolyte triplet, not a fixable materials defect. Continuing synthesis, cycling and characterization on such candidates burns USD 2-4 M (estimate) and consumes 25-30% of shared dry-room and characterization bandwidth. The plan offers no stopping rule or escalation at Month 12-18 (2027-10-14 to 2028-04-14) if a leading candidate misses 250 cycles early.

### 6.5.B Tags

- cycle-life-gate-unenforced
- late-deprioritization
- sunk-cost-bias
- bandwidth-starvation

### 6.5.C Mitigation

Tighten the deprioritization rule: by Month 12 (2027-10-14), all three active chemistries must show ≥250 cycles at 80% retention in at least two cell replicates. Any candidate with measured <250 cycles at Month 12-18 (2027-10-14 to 2028-04-14) is immediately downgraded to contingency status and receives no fresh cell builds or focus characterization for 4 weeks. Instead, assign a 2-4 week targeted sprint (USD 0.2-0.5 M estimate) to test one high-impact interface change (e.g., electrolyte additive, anode coating, cathode doping) with hard decision point at Month 15 (2028-01-14) or Month 18 (2028-04-14): if sprint shows no material lift (>30 cycle gain), deprioritize fully. Reallocate freed resources to the two candidates showing >300 cycles. Escalate monthly to the Steering Committee if a leading candidate misses 250 cycles.

### 6.5.D Consequence

Without strict enforcement, a degradation-prone candidate consumes dry-room, cell-assembly and characterization bandwidth through Month 24-30 (2028-10-14 to 2029-04-14) despite poor prospects. This delays the final three competitive runs needed to narrow to one finalist at Month 36 (2029-10-14). In combination with volumetric shortfall requiring a sprint, the programme loses 8-12 weeks of iteration time, compressing Months 36-72 (2029-10-14 to 2032-10-14) validation window from 36 months to 24-28 months—insufficient for three independent pouch-cell builds with cycle-life and abuse testing.

### 6.5.E Root Cause

Plan treats cycle-life as a single threshold rather than a decision point that cascades to allocation and staffing. The chemistry tournament structure assumes each candidate gets equal airtime until the Month 36 (2029-10-14) gate, but cycle-life degradation is often irreversible and is detectable by Month 12-15 (2027-10-14 to 2028-01-14) if measured rigorously. Deferring deprioritization to Month 24 (2028-10-14) reflects hope that interface engineering will cure the problem, not clear evidence of fixability.

## 6.6.A Issue - Permitting risk and operational start assumptions lack contingency; 6-8 month slip is likely and unmitigated

The plan commits to Phase 1 (dry-room) and modular line operational by Month 3 (2027-01-14), with first pouch cells by Month 6 (2027-04-14). However, typical hazardous-materials facility permitting in Texas takes 6-8 months (estimate) from Phase 1 submission (Month 2 = 2026-12-14) to approval, pushing operations to Month 8-10 (2027-06-14 to 2027-08-14). The plan mentions phased permits and external synthesis as fallback but does not pre-negotiate outsourcing contracts (e.g., with contract research organizations) or secure conditional-use authorization from the fire authority. If permitting slips 8 months and external synthesis is not pre-positioned, the effective work window compresses from 84 months to 76 months, consuming 10% of timeline. A delayed start cascades: pilot-line commissioning deferred to Month 9-12 (2027-07-14 to 2027-10-14), first pouch builds shifted to Month 12-15 (2027-10-14 to 2028-01-14), and Month 18 gate (2028-04-14) advances without statistically robust cycle-life data.

### 6.6.B Tags

- permitting-delay-unmitigated
- operational-start-assumption
- outsourcing-fallback-undefined
- timeline-compression-cumulative

### 6.6.C Mitigation

Execute permitting engagement today (Month 0 = 2026-10-14): contact Austin Fire Authority, TCEQ and Travis County within 48 hours and propose a collaborative design session (target: first meeting by 2026-10-21). Request conditional-use authorization for Phase 1 (dry-room, inert-gas handling, non-hazardous electrolyte assembly) valid within 6 weeks, with enhanced fire-authority monitoring (weekly on-site audits) in exchange for expedited approval. Simultaneously, pre-negotiate firm synthesis contracts with ≥2 contract research organizations (e.g., Albemarle, Lithium Werks contract lab, or university-affiliated CRO) by Month 1 (2026-11-14): specify key reactions (lithium-metal anode preparation, aggressive solvent synthesis, cathode doping), cost-plus pricing, ≤4 week turnaround (28 calendar days max), and written contingency for 200% capacity surge. Draft outsourcing SOW by Month 0 (2026-10-14) and execute by Month 1 (2026-11-14). If Phase 1 permit is delayed beyond Month 4 (2027-02-14), activate the pre-negotiated CRO contracts immediately (no further approval needed) so synthesis work continues off-site without pipeline stall.

### 6.6.D Consequence

Unmitigated permitting slip of 6-8 months compresses effective work to 76-78 months. Combined with Month 30 (2029-04-14) volumetric-density gate risk and Month 24 (2028-10-14) cycle-life deprioritization slowdown, the cumulative timeline loss is 12-20 months. Month 72 (2032-10-14) delivery becomes unachievable without descoping or incomplete third-party validation. Additionally, lack of pre-negotiated external synthesis forces ad-hoc outsourcing at 50-100% cost premium and 6-10 week turnaround, consuming USD 2-5 M (estimate) of the contingency reserve and slowing chemistry exploration by 30-40%.

### 6.6.E Root Cause

Plan assumes permitting will proceed on a nominal 6-month schedule without acknowledging that the earliest realistic first-approval date is 6-8 months (estimate) from submission. The fallback—external synthesis and conditional-use authorization—is mentioned in the pre-project assessment but not built into the baseline execution plan or formalized as a contractual safeguard. Permitting is treated as a gate rather than as a parallel workstream that must be de-risked by Month 0-1 (2026-10-14 to 2026-11-14) through regulator engagement and outsourcing pre-commitment.

---

# 7 Expert: Technology Transfer and Licensee Partnership Lead

**Knowledge**: Technology transfer models for R&D inventions, licensing agreements and royalty structures, prospective licensee identification and early engagement, application-specific performance and manufacturability requirements, exclusive versus non-exclusive tiers, patent-to-product lifecycle

**Why**: The programme's non-commercial mandate explicitly targets a 'licensable invention,' yet the plan lacks a clear technology-transfer partner, licensee requirements, or go-to-market model. Without early licensee engagement, the final invention risks being a proof-of-concept that nobody can commercialize (wrong form factor, application duty profile, or cost structure). Decision 11 (Reference Application Anchor) is rated Medium priority partly because the anchor is open, allowing the chemistry to reveal its natural fit—but this risks alignment issues with prospective licensees. A technology-transfer lead can identify candidate licensees (battery manufacturers, integrators, OEMs in weight-critical sectors like aerospace, high-performance vehicles, or drones) by Month 12 (2027-10-14), sketch their requirements, and ensure the final cell architecture and processes are designed for hand-off, not just laboratory proof.

**What**: By Month 6 (2027-04-14), conduct a landscape scan of prospective licensees (battery manufacturers, OEMs in aerospace, premium vehicles, drones, or high-energy portable devices) and their commercialization timelines and performance/manufacturability requirements. By Month 12 (2027-10-14), initiate informal advisory contacts with 2-3 target licensees (maintaining confidentiality, proposing a non-disclosure agreement); sketch their application duty profile (cycle count, temperature, rate, form factor) and integration challenges. By Month 24 (2028-10-14), finalize IP and licensing framework (Decision 5) with counsel, including exclusive-use tiers, royalty terms and manufacturing-process transfer requirements. By Month 30 (2029-04-14), use Month 30 (2029-04-14) third-party pouch-cell verification data to validate licensee interest and iterate cell architecture if needed to meet their manufacturability or cost thresholds.

**Skills**: Technology-transfer agreement drafting, licensing terms and royalty structure design, prospective partner identification and due diligence, application requirements translation to technical specifications, manufacturing scale-up and process-transfer planning, exclusive/non-exclusive IP tier negotiation, early-stage licensing advisory

**Search**: technology transfer licensing battery invention, commercialization pathway R&D to product, exclusive non-exclusive royalty

## 7.1 Primary Actions

- By Month 1 (2026-11-14 at 16:00), appoint a licensing counsel experienced in battery IP and technology transfer, and convene a licensing/partnerships working group with the Programme Director, IP lead and Funder representative. Establish a written IP strategy defining: (1) joint ownership with university/national-lab partners (proposed: programme owns integrated cell architecture and manufacturing processes; partners own pre-disclosure publication rights), (2) two-track filing discipline (material-science papers published after 6-month review; cell architectures, electrolyte formulations and processes filed as patents before disclosure), (3) target of ≥6 provisional patents by Month 12 (2027-10-14) covering anode, cathode and electrolyte combinations, and (4) licensing-tier structure (exclusive for integrated cell architecture and pack-level integration; non-exclusive for enabling materials).
- By Month 3 (2027-01-14 at 14:00), lock a specific Reference Application Anchor with Steering Committee and funder approval. Choose one: (A) weight-critical (aviation/UAV, target ≥200 Wh/kg, ≤200 cycle requirement), (B) vehicle-duty (automotive, ≥300 cycles at 80%, −10 to +55 °C ambient), or (C) portable consumer/energy-storage (≥200 cycles, 0–40 °C). Publish the chosen anchor, duty-cycle test protocol (discharge rate, temperature ramp, voltage window, cycle-count threshold) and alignment rationale. Identify 2–3 credible licensee candidates matching the anchor (e.g., aviation: Joby/Lilium; automotive: Hyundai/BMW; portable: consumer integrator) and issue a request for partner information (RFI) by Month 6 (2027-04-14). Require all cell verification data (Month 30 = 2029-04-14 onwards) to be collected under the locked anchor duty-cycle specification, not generic laboratory protocol.
- By Month 6 (2027-04-14 at 17:00), conduct a bottom-up reforecast of payroll and operating expenses using actual Austin market salary data (including 15–20% Tesla proximity premium). Disaggregate by role: senior scientists, postdocs, technicians, programme management, EHS, IP counsel and IT support. Reforecast payroll to USD 13–15 M/yr (USD 90–116 M over 7 yrs, reflecting realistic Austin benchmark). Reforecast total opex and prepare a revised tranche schedule or present a descoping decision memo to funder: either (1) increase the USD 300 M cap to USD 330–350 M with revised tranches to cover payroll and contingency, or (2) descope the programme to 60–80 FTE, 2 active chemistries (instead of 3) and deferred cycle-life validation (Month 42 = 2030-04-14 instead of Month 30 = 2029-04-14), or (3) maintain USD 300 M but freeze hiring and reduce scope. Specify which reserves (payroll contingency, permitting, pivot, free) are committed and which remain available. Obtain funder decision in writing by Month 9 (2027-07-14).

## 7.2 Secondary Actions

- By Month 2 (2026-12-14 at 12:00), engage with UT Austin Office of Technology Commercialization, NREL Technology Partnerships and Argonne Leadership Computing Facility to pre-negotiate joint-IP terms, publication embargo protocols and cost-sharing rates before formal partnership agreements are signed (due Month 3 = 2027-01-14). Document each partner's policy on materials and process ownership, background IP, and timing of publication versus patent filing. Identify any conflicts between the programme's non-commercial mandate and partner requirements (e.g., university desire for open publication may conflict with patent priority). Resolve conflicts in writing before Month 3 (2027-01-14) partnership execution.
- By Month 12 (2027-10-14 at 17:00), issue a non-binding term sheet to the lead identified licensee from the Month 6 (2027-04-14) RFI process. Specify: (1) technology scope (cell architecture, electrolyte family, anode and cathode compositions covered by licence), (2) exclusive versus non-exclusive territory and field of use, (3) royalty range (proposed 2–5% for exclusive core, 1–2% for non-exclusive enabling IP), (4) minimum commercialization timeline (e.g., first commercial prototype by Year 5 post-transfer), (5) force-of-life or shelf-life requirements and (6) contingency: if this licensee withdraws before Month 36 (2029-10-14), identify a backup licensee candidate or declare the anchor inoperable. Ensure the term sheet is conditional on Month 30 (2029-04-14) third-party verification meeting the locked application duty cycle.
- By Month 24 (2028-10-14 at 15:00), finalize the comprehensive licensing framework with outside counsel, incorporating the locked application, identified licensee(s), IP ownership, patent scope and royalty structure. Develop a licensing-readiness checklist tied to the Month 36 (2029-10-14) selection gate: the selected finalist chemistry must support a defensible, non-design-around patent estate covering (1) integrated cell architecture, (2) key electrolyte or interface innovations, (3) anode or cathode compositions and (4) manufacturing process steps. If the finalist cannot meet this patent-defensibility test, trigger a redesign sprint (Months 36–42 = 2029-10-14 to 2030-04-14) to add defensible technical moats before technology transfer (Months 72–84 = 2032-10-14 to 2033-10-14).
- By Month 3 (2027-01-14), revise the Cell-Level Proof Standard to specify that all third-party verification data (starting Month 30 = 2029-04-14) must be collected under the locked Reference Application Anchor duty-cycle conditions (temperature ramp, rate, voltage window, cycle protocol). Do not allow generic 'best-case' laboratory conditions. This ensures the verified cell is immediately credible to the identified licensee and reduces post-transfer redesign time from 6–12 months to <3 months.
- By Month 9 (2027-07-14), invite the identified lead licensee (or a Licensee Advisory Board of 2–3 candidates) to a quarterly progress review. Share non-confidential milestones (chemistry tournament results, cell-level energy-density projections, safety rankings) and solicit feedback on application specifications and commercialization requirements. This early engagement locks the licensee into co-authorship of success criteria and reduces the risk of Month 72 (2032-10-14) delivery rejection because requirements shifted during the 6-year development.
- By Month 30 (2029-04-14), include the identified licensee in the Month 30 (2029-04-14) gate decision and third-party verification interpretation. If the verified cell meets the locked application duty cycle and energy density, but licensee raises a secondary requirement (e.g., lower cost, faster cycle or thermal stability beyond current threshold), allocate a 6-month design sprint (Months 30–36 = 2029-04-14 to 2029-10-14) before the Month 36 (2029-10-14) selection gate to incorporate the licensee's constraint. This prevents a Month 72 (2032-10-14) situation where the cell technically meets the headline target but licensee motivation is low.

## 7.3 Follow Up Consultation


At the next consultation, be prepared to discuss: (1) Which specific application and licensee(s) the programme commits to by Month 3 (2027-01-14)—aviation, automotive, or portable—and the corresponding duty-cycle specification. (2) The revised payroll and opex forecast (bottom-up, not baseline) and funder decision on budget top-up versus descope. (3) The joint-IP ownership and publication-embargo terms negotiated with UT Austin and national-laboratory partners (not yet finalized). (4) Progress on the ≥6 provisional patent filings and whether any early-stage publications have compromised patent priority (identify by Month 6 = 2027-04-14). (5) Whether an identified licensee candidate has signed the non-binding term sheet by Month 12 (2027-10-14), or if the anchor must be revised. (6) Remediation if permitting slips beyond Month 4 (2027-02-14) or if the cost of outsourced synthesis exceeds USD 2 M/yr. (7) Contingency plan if the lead licensee candidate withdraws before Month 36 (2029-10-14). Use these data points to assess whether the plan's technology-transfer and licensing objectives remain on track, or whether the programme's focus has drifted to a 'generic' invention with no clear buyer at delivery.


## 7.4.A Issue - Critical IP and Licensing Strategy Misalignment with Technology-Transfer Goal

The plan commits to 'patenting only the final integrated cell architecture and processes' with 'sharing pre-competitive findings openly.' This inverts technology-transfer value. Licensees pay premium royalties for defensible, layered IP protecting intermediate innovations (materials, interfaces, processes), not final architectures. Open sharing of electrolyte, separator and anode breakthroughs before patent closure creates freedom-to-operate gaps for licensees and invites design-around. The plan lacks defined ownership of jointly developed IP with university/national-lab partners, timing of patent filing versus publication, and a licensing tier structure (exclusive for core cell architecture, non-exclusive for enabling materials). This weakness will reduce licensable value by 30–50% and complicate partner negotiations.

### 7.4.B Tags

- IP-strategy-misalignment
- licensing-value-erosion
- joint-IP-unclear
- partner-contamination-risk

### 7.4.C Mitigation

By Month 1 (2026-11-14), appoint a licensing counsel with battery IP experience and define joint-IP ownership with partners upfront (proposed: programme owns integrated cell architecture and manufacturing processes; partners own publication rights on materials and methods post-6-month review). Establish two publication/patent tracks: (1) Materials science papers (general synthesis, characterization methods) published openly after 6-month review; (2) cell-level architectures, electrolyte formulations, protective coatings and process parameters filed as patents before any disclosure. File ≥6 provisional patents covering anode, cathode and electrolyte combinations by Month 12 (2027-10-14). Define a licensing tier: exclusive rights for integrated cell architecture and pack-level integration (10–year term, 3–5% royalty); non-exclusive for enabling materials (lower royalty, 1–2%). By Month 24 (2028-10-14), finalize licensing framework in writing and secure a letter of intent from a credible licensee or licensor consortium. Tie T4 tranche release (Month 36 = 2029-10-14) to existence of a signed licensing-intent agreement.

### 7.4.D Consequence

Without corrected IP strategy, the licensee at Month 72+ (2032-10-14+) faces weak exclusivity. Competitors can freely design around published electrolytes and interfaces. Royalty rates drop 10–20 percentage points (industry range 2–8% narrows to 1–3%). Licensee motivation to invest in manufacturing scale-up and commercialization diminishes. Partner universities may demand joint ownership or blocking rights post-publication, stalling patent prosecution. Technology transfer stalls or is abandoned in favor of a competing (better-protected) cell from another source.

### 7.4.E Root Cause

The plan emphasizes 'non-commercial mandate' and 'open collaboration' as virtues without recognizing that a licensee cannot commercialize a cell whose core enabling materials are published and unpatented. The licensing framework was deferred to Month 24 (2028-10-14), too late to protect provisional filing priorities and partnership agreements already in place. No distinction is drawn between pre-competitive (publishable) and pre-licensing (patentable) work.

## 7.5.A Issue - Unresolved Licensee and Application Anchor Create Orphaned Technology Risk

The plan targets '500 Wh/kg and 1000 Wh/L' but does not name or commit to the application, duty cycle, or licensee that will use the result. The 'Reference Application Anchor' decision (Decision 11) remains open: 'hold the anchor open for the first phase and let early cell data reveal which application set the chemistry naturally fits.' This is a planning error. A 500 Wh/kg gravimetric cell optimized for weight-critical aviation (low cycle-life tolerance, high-rate pulse) differs fundamentally from one optimized for electric vehicles (300–500 cycle life, moderate rate, wide temperature). Chemistry pathways and proof standards diverge. Without a locked application by Month 3 (2027-01-14), the research team will optimize for a 'generic' cell that satisfies no real use case, and licensees will reject it as misaligned with their roadmap. Technology transfer fails because the licensee lacks motivation or needs a 6–12 month redesign.

### 7.5.B Tags

- application-anchor-missing
- licensee-identification-deferred
- orphaned-technology
- proof-standard-ambiguity

### 7.5.C Mitigation

By Month 3 (2027-01-14), lock a specific application anchor with Steering Committee and funder approval: either weight-critical (aviation/UAV, ≥200 Wh/kg, ≤200 cycles), or vehicle-duty (automotive, ≥300 Wh/kg, ≥500 cycles, −10 to +55 °C ambient), or portable (consumer, ≥200 cycles, 0–40 °C). Define corresponding cell-level test protocol (discharge rate, temperature ramp, cycle count, pass/fail voltage window). By Month 6 (2027-04-14), identify 2–3 credible licensees or integrators aligned with the locked anchor (e.g., if aviation: Joby, Lilium, or major aerospace OEM; if automotive: Hyundai, BMW, or cell integrator like Solid Power; if portable: consumer electronics or energy-storage integrator). Issue a request for partner information (RFI) detailing technical requirements, volume roadmap, timeline and licensing model preference. By Month 12 (2027-10-14), sign a non-binding term sheet with a lead licensee covering technology scope, royalty range (2–5%), exclusivity term and commercialization timeline. Tie the Month 30 (2029-04-14) third-party verification to the licensee's duty-cycle specification, not generic laboratory protocol. If the lead licensee withdraws by Month 36 (2029-10-14), hold T4 release pending identification of a replacement or declare the anchor inoperable and descope.

### 7.5.D Consequence

The programme delivers a cell at Month 72 (2032-10-14) meeting the stated 500 Wh/kg and 1000 Wh/L targets but not optimized for any licensed application. Prospective licensees—automotive OEMs, aerospace primes, or battery integrators—request 2–6 month redesign cycles (different thermal envelope, cycle-life profiling, cost-down) before signing technology-transfer agreements. Technology transfer slips 6–12 months, to Month 78–84 (2033-04-14 to 2033-10-14), delaying commercialization by 18–36 months industry-wide. If no licensee emerges, the invention remains a research prototype with no path to market, and the USD 300 M programme is considered a failure by funders and stakeholders despite meeting the stated energy-density targets.

### 7.5.E Root Cause

The plan treats the application anchor as a 'nice-to-have' specification input rather than a gating business prerequisite. The goal statement 'invent a better battery' is intentionally open-ended. However, technology transfer requires a specific buyer with known constraints. The plan defers licensee identification to 'informal advisory contacts from Month 12 (2027-10-14)' and does not require a binding partner commitment until Month 24 (2028-10-14). By then, chemistry choices and cell designs are locked, and pivoting to a licensee's real duty cycle costs 3–6 months and USD 5–10 M (estimate).

## 7.6.A Issue - Payroll and Cost-Control Assumptions Are Understated; Reserve Will Not Cover Stress Cases

The plan baseline payroll USD 10 M/yr (USD 70 M over 7 years) against a canonical 80–120 FTE. Bottom-up calculation: senior scientists (15–20 FTE @ USD 180–220 K/yr) = USD 2.7–4.4 M; postdocs and early-career (30–40 FTE @ USD 60–90 K/yr) = USD 1.8–3.6 M; technicians and support (20–30 FTE @ USD 50–70 K/yr) = USD 1–2.1 M; plus benefits (30%), taxes, retirement = multiplier 1.35–1.45x. Subtotal: USD 7.5–11.5 M/yr before programme management, EHS, IP counsel and IT. With a 15–20% Austin salary premium (Tesla proximity) and 3–5 year retention agreements (clawback penalties), payroll reaches USD 12.9–16.6 M/yr, or USD 90–116 M over 7 years—a USD 20–46 M overrun. The plan flags this as 'payroll understatement' but does not revise the reserve or tranche schedule. Opex (USD 32.9 M/yr) already exceeds the Months 36–84 (2029-10-14 to 2033-10-14) tranche rate (USD 22.5 M/yr), requiring USD 41 M carry-forward from early years. Adding USD 20 M payroll understatement leaves only USD 21 M free contingency—insufficient for permitting delays (6–8 months, USD 5–10 M estimate), a chemistry pivot (USD 5–10 M estimate), or an EHS incident (USD 1–3 M estimate).

### 7.6.B Tags

- budget-understatement
- reserve-inadequate
- payroll-misestimated
- contingency-stress-case

### 7.6.C Mitigation

By Month 3 (2027-01-14), conduct a bottom-up reforecast of payroll for the full 84-month timeline using actual posted salary ranges for Austin battery researchers (Texas salaries + 15–20% Tesla premium per public market data). Disaggregate by role: senior scientist, postdoc, technician, programme manager, EHS lead, IP counsel. Obtain market quotes from recruiting firms if internal data is unavailable. Revise payroll assumption to USD 13–15 M/yr (midpoint USD 14 M/yr = USD 98 M over 7 yrs). Reforecast the tranche schedule to ensure opex coverage: either increase T3 and T4 tranches to cover the USD 41 M carry-forward plus USD 20+ M payroll delta, or reduce staffing plan to 60–80 FTE (lower cost, slower throughput, longer delivery). Revise the unallocated reserve from USD 20 M to USD 35–40 M (12–13% of budget) to provide buffer for payroll, contingencies and stress cases. Explicitly allocate reserves into buckets: payroll contingency (USD 10–15 M), permitting and EHS (USD 5–10 M), chemistry pivot and redesign (USD 10–15 M), and free contingency (USD 2–5 M). Present revised budget and reserves to funder by Month 6 (2027-04-14) for decision: either top-up the cap to USD 330–350 M, or agree on a descoped outcome (e.g., 2 active chemistries, deferred cycle-life validation, or simplified cell format).

### 7.6.D Consequence

If payroll reaches USD 14.8 M/yr as flagged (a realistic scenario given Austin salary benchmarks and retention clauses), the programme exhausts contingency reserve by Month 24 (2028-10-14). Any stress event—permitting slip beyond Month 4 (2027-02-14), chemistry pivot requiring precursor re-sourcing and accelerated characterization, or an EHS incident—cannot be funded without cutting research scope, delaying gates or requesting emergency top-up funding. Funder confidence erodes. If top-up is denied, the programme descopes: reduces active chemistry tournament from 3 to 1, eliminates in-house characterization instrument and relies solely on external partners (longer queue times), or delays third-party verification from Month 30 (2029-04-14) to Month 42 (2030-04-14). Final delivery stretches beyond Month 84 (2033-10-14) or the cell is verified without full cycle-life and safety data, reducing licensable credibility.

### 7.6.E Root Cause

The plan uses 'USD 10 M/yr baseline' as a planning assumption without bottom-up validation. The flagged 'payroll understatement' (USD ~14.8 M/yr vs USD 10 M/yr baseline) implies USD 4.8 M/yr overrun, or USD 34 M over 7 years, but the budget and reserve are not revised. The tranche schedule was designed without resolving the Months 36–84 (2029-10-14 to 2033-10-14) opex shortfall (USD 41 M needed carry-forward). The plan also does not account for the cost of talent retention (clawback penalties if staff depart), EHS incident remediation, or regulatory retrofits (USD 2–5 M estimate).

---

# 8 Expert: Supply Chain and Materials Procurement Strategist

**Knowledge**: Battery precursor sourcing (lithium compounds, sulfur, cathode materials, specialty salts, fluorinated solvents), long-lead-time components (dry-room equipment, electrochemical instruments, abuse-test chambers), foreign-currency exposure and forward contracting, supplier redundancy and risk mitigation

**Why**: The SWOT analysis flags 'precursor supply disruption, price spikes and EUR/CNY equipment exposure' as a threat, and the permitting-delay fallback mentions outsourced synthesis at USD 2-5 M/yr (estimate). Yet the plan lacks a supplier strategy, lead-time contingencies, or forward-contract mechanics. The chemistry tournament involves three active chemistries with different precursor needs (lithium compounds, sulfur cathode powders, high-purity salts, specialty electrolyte solvents); a single-source shortage could delay cell fabrication by 4-8 weeks (estimate). Equipment orders in Months 2-6 (2026-12-14 to 2027-04-14) need forward-priced or USD-fixed contracts to hedge 1% FX contingency (USD 2-3 M, estimate). A procurement strategist can build supplier maps, qualify backups, and negotiate long-lead-time contracts now.

**What**: By Month 1 (2026-11-14), map precursor suppliers for the three active chemistries (lithium metal/compounds, sulfur, conversion-cathode precursors, specialty salts, fluorinated solvents); identify minimum two suppliers per critical material and confirm 8-12 week lead-times and pricing. By Month 2 (2026-12-14), negotiate forward-priced or USD-fixed equipment contracts for the modular pilot line, dry-room package, post-mortem instruments and abuse-test chambers (Orders Months 2-6 = 2026-12-14 to 2027-04-14); lock USD pricing to contain FX contingency within USD 2-3 M (estimate). By Month 6 (2027-04-14), pre-place orders for long-lead precursors (8-12 week horizon) aligned with first cell builds and chemistry tournament schedule. By Month 24 (2028-10-14), when pre-staging reserve chemistry, repeat precursor and equipment qualifications to ensure supply continuity during pivot.

**Skills**: Supplier mapping and qualification, long-lead-time procurement and order management, forward contracting and currency hedging, supply-chain risk assessment and redundancy planning, cost-plus and fixed-price negotiation, inventory and just-in-time delivery optimization

**Search**: battery materials procurement supplier lithium sulfur salts, supply chain risk management equipment lead time

## 8.1 Primary Actions

- By Month 0 (2026-10-14, today), commission a detailed supplier audit and procurement strategy from a battery-industry procurement specialist: identify ≥2 suppliers per critical precursor (lithium carbonate, lithium salts, specialty cathode powders, fluorinated solvents, separators) with verified lead times, SLAs, minimum orders and pricing; document FX exposure (EUR, CNY) and currency-hedging recommendations for equipment orders (dry-room ~USD 3–5 M, instruments ~USD 2–3 M).
- By Month 1 (2026-11-14), execute three competitive RFQs for modular dry-room + pouch-cell line lease with fixed-price, fixed-schedule terms (cost capped USD 1.2 M/yr, uptime ≥95%, 7-day build turnaround, 60-day exit rights); award to lowest qualified bid and sign lease with performance guarantees and step penalties for delays.
- By Month 2 (2026-12-14), finalize partner agreements with fixed-price SLAs: characterization ≤USD 500/sample, ≤21 day turnaround (10% cost reduction for breaches); backup characterization provider (USD 2–3 M/yr) contracted with 6-week access guarantee; synthesis subcontracting <4 week turnaround guaranteed or 20% cost credit.
- By Month 4 (2027-02-14), build a materials-demand model (cell count, candidate chemistries, monthly ramp through Month 36 = 2029-10-14) and establish JIT delivery windows (2–4 week supplier windows every 6–8 weeks synchronized to cell-build cycles); place pilot-scale orders (10–50 kg per precursor) to validate lead times and lock pricing.
- By Month 6 (2027-04-14), execute fixed-price, fixed-schedule contracts for all Year 1–2 equipment (dry-room, analytical instruments, abuse-test chambers, electrolyte dosing equipment) with 90-day payment terms, 30-day delivery, 2% early-payment discounts, and currency protection (USD-fixed or EUR forward contracts if >USD 0.5 M exposure).
- Assign a Procurement Officer (battery-industry background, ≥5 yrs) by Month 1 (2026-11-14) with accountability for supplier management, cost control, and JIT execution through Month 36 (2029-10-14); assign a Materials-Planning Officer (inventory, demand forecasting, scrap optimization) by Month 4 (2027-02-14).

## 8.2 Secondary Actions

- By Month 12 (2027-10-14), conduct a procurement performance audit: compare actual pilot-line and partner costs to fixed-price targets, FX realized against forward contracts, and precursor supply lead times against baseline; document cost variance and reserve consumption; adjust procurement strategy if costs exceed budget by >10%.
- By Month 18 (2028-04-14), execute a cell-level waste-reduction program targeting 95% synthesis and assembly yield; implement failed-cell disassembly and material recovery (lithium recycling or donation to partners) to offset precursor costs by USD 0.5–1 M by Month 36 (2029-10-14).
- By Month 24 (2028-10-14), update the materials-demand and inventory model with actual consumption data from Months 6–24 (2027-04-14 to 2028-10-14); validate supplier lead times and adjust JIT delivery windows; identify overstock (precursors for deprioritized candidates) and write-off or return decisions within 30 days; target inventory holding ≤3 months of normal burn rate.
- By Month 30 (2029-04-14), lock in Year 3–4 precursor contracts for the finalists; place non-cancellable orders for 6–12 months of supply for the two candidates most likely to survive Month 36 (2029-10-14) selection gate, with hold-or-return clauses for the reserve.
- By Month 36 (2029-10-14), finalize the pivot-contingency supply chain: if reserve chemistry is activated, confirm precursor suppliers (≥2 per material), place expedited (8–12 week) orders within 2 weeks, and confirm pilot-line reconfiguration schedule with equipment supplier (pressure hardware, electrode-coating parameters) within 1 week; pre-execute all supply contracts before the Month 36 (2029-10-14) gate decision.

## 8.3 Follow Up Consultation

In the next consultation, we should discuss: (1) Which three to four chemistry candidates have the most critical / longest-lead precursors? (e.g., lithium-sulfur cathodes require specialty sulfur and polysulfide-blocking additives; anode-free architectures require pre-lithiation chemistry and protective coatings—what is the 12–20 week lead path for each?) (2) What are the current market prices and SLA terms for a modular dry-room and pouch-line lease in the Austin area? (Name suppliers, lead times, cost estimates.) (3) Have partner (UT Austin, NREL) capacity and characterization-queue times been confirmed? If queues are >4 weeks, should the backup commercial characterization provider be pre-contracted immediately? (4) What is the currency exposure on equipment (dry-room, instruments): how much is quoted in EUR, CNY or GBP, and what forward-pricing or FX-hedging strategy fits the programme risk tolerance?

## 8.4.A Issue - Precursor supply chain and long-lead-time materials not mapped or contracted; no supplier redundancy or forward-pricing hedge for equipment.

The plan references battery precursors (lithium compounds, specialty salts, fluorinated solvents) and equipment (dry-room systems, abuse-test chambers, electrochemical instruments) but provides no supplier map, redundancy strategy, lead-time inventory, or foreign-currency forward contracts. Lithium carbonate and spodumene have 8–16 week lead times; abuse-test chambers 12–20 weeks; core analytical instruments 16–24 weeks. A hidden 8-week delay in precursor supply or a EUR/CNY equipment price spike could compress the timeline and exhaust contingency by Month 18–24 (2028-04-14 to 2028-10-14). No baseline supplier agreements or volume commitments are documented.

### 8.4.B Tags

- supply-chain-risk
- long-lead-time-components
- supplier-redundancy
- foreign-currency-exposure
- precursor-sourcing

### 8.4.C Mitigation

By Month 2 (2026-12-14), execute a detailed supplier map and redundancy audit: identify ≥2 suppliers per critical precursor (lithium salts, fluorinated solvents, specialty cathode materials) with lead times, pricing, minimum-order quantities and SLAs. By Month 3 (2027-01-14), place pilot-scale orders (10–50 kg per precursor) with first supplier to confirm lead times and lock pricing. By Month 6 (2027-04-14), execute forward-priced USD-fixed equipment contracts for dry-room, analytical instruments and abuse-test hardware with 90-day payment terms and 30-day delivery. By Month 12 (2027-10-14), establish 2–4 week supply buffers for each candidate chemistry and archive precursor prices and FX rates to enable currency-hedging decisions if EUR/CNY swings >5%. Engage a procurement officer with battery-industry experience and assign supplier management as a formal line item (USD 2–4 M over 7 years).

### 8.4.D Consequence

Without supplier mapping and redundancy, a precursor shortage, price spike or equipment delay (8–20 week lead times are common) could delay first cell builds by 4–8 weeks, compress effective work from 84 months to 76–80 months, and force cost/quality trade-offs that violate the cycle-life and volumetric thresholds. A EUR/CNY swing of 5–10% on equipment (dry-room ~USD 3–5 M, instruments ~USD 2–3 M) adds USD 0.25–0.8 M unbudgeted cost or consumes 25–80% of the USD 2–3 M FX contingency. Multi-month precursor delays discovered at Month 24–30 (2028-10-14 to 2029-04-14) compress the Month 30–36 (2029-04-14 to 2029-10-14) proof window and could force descope or stop before a chemistry is validated.

### 8.4.E Root Cause

The project plan treats precursor sourcing and equipment procurement as operational details rather than strategic risks. Chemistry tournament and pilot-line decisions were made without parallel supplier-mapping and redundancy work. No procurement strategy bridging the decision gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) and the equipment/precursor needs of each chemistry candidate was established. The pre-project assessment flagged permitting and characterization access but not supply-chain criticality.

## 8.5.A Issue - No inventory strategy or just-in-time delivery plan for chemistry-tournament candidates; risk of bottleneck or waste at scale-up.

The plan commits to a staged tournament of three active chemistries plus a pre-staged reserve by Month 24 (2028-10-14), with pouch-cell build rates of 50–100 cells/month ramping by Month 24 (2028-10-14). However, no inventory strategy, materials-staging timeline, or JIT delivery schedule was defined. A typical pouch-cell build consumes 100–500 mg of active materials per cell; at 50–100 cells/month, monthly consumption is 5–50 g per chemistry. If precursor orders are batched quarterly and lead times are 8–16 weeks, materials may arrive after demand has shifted (e.g., a candidate is deprioritized) or simultaneously, creating waste or bottlenecks. No scrap or recycling plan for failed cells or synthesis byproducts is mentioned.

### 8.5.B Tags

- inventory-management
- just-in-time-delivery
- materials-staging
- scale-up-bottleneck
- waste-and-recycling

### 8.5.C Mitigation

By Month 4 (2027-02-14), build a materials-demand model (bottom-up: target cell counts, candidate chemistries, monthly ramp profile from Month 6 = 2027-04-14 onward) that projects consumption of each precursor by quarter through Month 36 (2029-10-14). By Month 6 (2027-04-14), establish JIT delivery: for each candidate chemistry, request supplier delivery windows (2–4 week windows every 6–8 weeks) to match cell-build cycles. By Month 12 (2027-10-14), define inventory holding limits (not >3 months of supply at normal burn rate) and scrap thresholds (deprioritized candidates' precursors recycled or returned within 30 days, or written off as waste). By Month 18 (2028-04-14), execute a cell-level waste-reduction program: target 95% yield on synthesis and cell assembly; failed cells disassembled and materials recovered (lithium recycled or donated to partners) to offset precursor cost. Assign a materials-planning officer (USD 0.15–0.3 M/yr).

### 8.5.D Consequence

Without inventory strategy, the programme risks simultaneous overstock (precursors ordered for a candidate later deprioritized, waste = USD 0.5–2 M by Month 36 = 2029-10-14) and stockouts (lead-time misalignment causes 2–4 week delays waiting for restocked materials). A deprioritized candidate at Month 30 (2029-04-14) with USD 0.5–1 M of precursors on hand triggers decision: write off as waste (cash drain) or oversupply others (material inefficiency). Scale-up from 10–50 cell/month (Months 6–12 = 2027-04-14 to 2027-10-14) to 50–100 cells/month (Months 18–30 = 2028-04-14 to 2029-04-14) without demand-supply synchronization risks reagent stockouts, last-minute expedite costs (20–50% premium) and 1–2 week build delays. These delays cascade into the Month 30 (2029-04-14) verification gate and compress the final 36-month proof window.

### 8.5.E Root Cause

The chemistry-tournament structure and cell-build ramp were planned without parallel procurement and inventory modeling. Monthly build rates were estimated (50–100 cells/month) but not translated into precursor-consumption schedules or order-release windows. The pilot-line lease (modular containerized line, 50–100 cells/month capacity) was chosen for flexibility, but procurement and materials-staging timelines were not synchronized to that capacity profile. No one was assigned accountability for demand forecasting, materials staging or waste optimization.

## 8.6.A Issue - No cost-plus or fixed-price negotiation strategy for pilot-line lease, partners and equipment; budget exposure and supplier-lock-in risk.

The plan specifies a USD 15 M modular dry-room/pouch-line capital and leased operating costs of USD 0.6–1.2 M/yr, but no competitive procurement, cost-plus structures or fixed-price protections are documented. The pilot-line lease is critical to the 84-month timeline and chemistry-tournament flexibility, yet no performance guarantees, upside-sharing, or exit clauses are mentioned. Similarly, partner agreements (characterization, synthesis subcontracting) list cost-sharing (≥15% partner funding) and 3-week turnaround targets, but no fixed-price SLAs or remedies for breaches are detailed. Equipment orders (dry-room, instruments, abuse chambers) may incur 10–20% cost overruns if open-ended cost-plus or time-and-materials terms are used.

### 8.6.B Tags

- cost-negotiation
- fixed-price-contracts
- supplier-lock-in
- equipment-procurement
- partner-agreements

### 8.6.C Mitigation

By Month 0 (2026-10-14), establish procurement principles: all equipment and major services >USD 1 M use competitive RFQ (Request for Quote) with fixed-price, fixed-schedule contracts; all leases include performance guarantees (uptime ≥95%, delivery within ±1 week), step penalties for delays, and month-to-month renewal after Year 1 with 60-day exit rights; pilot-line operating cost capped at USD 1.2 M/yr with cost-reduction incentives (10% rebate if <USD 1.0 M/yr). By Month 1 (2026-11-14), solicit three competing bids for modular dry-room + pouch-line lease, with award to lowest fixed-price offer meeting performance specs (dew point <−30°C, cell-yield ≥90%, build turnaround ≤7 days). By Month 2 (2026-12-14), negotiate fixed-price partner agreements (characterization cost ≤USD 500/sample, turnaround ≤21 days, SLA breach remedies: 10% cost reduction for >21 day delays, right to redirect samples to backup within 48 hours). By Month 6 (2027-04-14), conduct equipment-cost audit against market benchmarks and execute fixed-price contracts for all Year 1–2 capital (dry-room, instruments, abuse chambers) with 90-day payment, 30-day delivery, and 2% early-payment discounts.

### 8.6.D Consequence

Without fixed-price contracting and supplier discipline, pilot-line and partner costs can overrun by USD 3–5 M (20–33% cost increase) over the programme lifetime, consuming >25% of the USD 20 M reserve by Month 24 (2028-10-14). If a pilot-line provider raises lease rates by USD 0.2 M/yr (17% increase from USD 1.2 M baseline) or extends turnaround from 7 to 10 days, cell-build schedules slip and Month 18–30 (2028-04-14 to 2029-04-14) verification timelines compress. Equipment cost overruns (dry-room, instruments) discovered at Month 6–12 (2027-04-14 to 2027-10-14) force descope (abort dry-room humidification, defer in-house post-mortem equipment) that undermines reproducibility and delays forensics learning by 4–8 weeks per failure. A partner breach (e.g., characterization turnaround exceeds 6 weeks due to queue backlog) with no penalty clause leaves the programme without recourse, extending the design-build-test cycle by 30–50% and compressing the final proof window by 3–6 months.

### 8.6.E Root Cause

The project plan treated lease and partner terms as operational contracts to be negotiated later, without defining procurement principles upfront. No cost benchmarks, competitive bid processes or cost-control gates were specified. The USD 15 M pilot-line capital and operating costs were estimated but not anchored to market rates or cost-reduction targets. The plan assumes partners will deliver ≥15% co-funding and ≤3 week turnaround, but no penalty clause, performance bond or right to redirect to backup partners if targets are missed was written into the decision.