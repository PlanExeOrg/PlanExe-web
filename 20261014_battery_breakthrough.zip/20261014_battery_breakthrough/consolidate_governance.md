# Governance Audit


## Audit - Corruption Risks

- Bribery or kickbacks in supplier selection for expensive precursor materials (lithium compounds, fluorinated solvents) or characterization equipment, particularly with competing vendors bidding for long-term contracts (Months 3–12 = 2027-01-14 to 2027-10-14 and ongoing).
- Nepotism or favoritism in hiring 80–120 FTE positions, especially senior chemistry and characterization leads, given the concentrated Austin battery talent pool and recruitment pressure near Tesla.
- Conflicts of interest: employees hired from Tesla or competing firms retain undisclosed knowledge of competitor work or supplier relationships, creating steering toward favored vendors or confidential information misuse.
- IP theft or unauthorized disclosure: programme members publish or patent pre-competitive findings via partner agreements without proper review gates, undermining patentability or licensing value.
- Kickbacks masked as inflated 'partner co-funding' contributions: universities or national laboratories claim cost-sharing (proposed ≥15% of shared costs) but provide below-value services or inflate hours/materials costs.
- Trading favors with regulators: selective compliance with Austin Fire Authority or TCEQ permitting, or delayed enforcement for favored research in exchange for regulatory officer involvement in publications or advisory roles.

## Audit - Misallocation Risks

- Budget misuse: front-loaded capital spending on pilot-line equipment (USD 30–50 M estimate), dry-room build and characterization instruments before chemistry is proven, consuming reserves needed for pivots or late-stage optimization.
- Double-spending or cost-shadowing: overlapping payments to external contractors and in-house teams for duplicate synthesis, characterization or data-analysis work without documented handoff or deduplication review.
- Inefficient precursor procurement: failing to negotiate dual-sourced suppliers by Month 3 (2027-01-14), resulting in single-vendor lock-in, price inflation (proposed risk: 20–30% above market) and USD 2–5 M/year waste.
- Misallocated staff effort: postdoctoral and graduate students (20–30% of team) assigned to routine maintenance or administrative tasks instead of high-impact discovery work, reducing hypothesis throughput by 20–30%.
- Scope creep and untracked experiment budgets: laboratory groups pursuing secondary chemistries or cell formats not formally gated or funded, consuming reagents, equipment time and staff capacity without visibility to the Steering Committee.
- Undocumented outsourced synthesis or testing: if permitting delays force external contracting (estimated USD 2–5 M/year), cost-plus pricing or invoice disputes could inflate apparent costs by 15–25% without competitive bidding records.

## Audit - Procedures

- Quarterly financial and progress audits (Months 3, 6, 9, 12 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, …, 84): review monthly spend by category (payroll, capital, consumables, partner, testing) against tranches and budget allocation (estimated USD 70 M payroll, USD 50 M capital, USD 25 M facility, USD 135 M variable); verify no line exceeds ±15% of plan without Steering Committee approval and document reallocations.
- Supplier and contract audit (Months 0, 6, 18, 30, 42, 60 = 2026-10-14, 2027-04-14, 2028-04-14, 2029-04-14, 2030-04-14, 2031-10-14): verify dual-sourced or three-sourced competitive bids for all precursors with >USD 100 K annual spend and all capital equipment >USD 1 M; confirm pricing consistency with market benchmarks and no single-vendor lock-in; reconcile invoices to purchase orders and received quantity.
- Payroll and staffing audit (Months 3, 9, 18, 30, 48, 72 = 2027-01-14, 2027-07-14, 2028-04-14, 2029-04-14, 2030-10-14, 2032-10-14): verify 80–120 FTE headcount accuracy, salary conformity with approved compensation bands (+15–20% premium for senior roles, proposed), on-time payment of sign-on bonuses and retention agreements; track attrition rate and replacement cost against the <15% target (proposed).
- IP and publication compliance audit (Months 6, 12, 24, 36, 48, 60, 72 = 2027-04-14, 2027-10-14, 2028-10-14, 2029-10-14, 2030-10-14, 2031-10-14, 2032-10-14): review all internal technical reports, conference presentations and patent applications before release to verify compliance with 6-month partner review windows (proposed) and clean-room onboarding protocols for Tesla-hired staff; confirm no unpermitted disclosure of pre-competitive findings.
- Gate and technical-data audit (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): independent red team (2–3 scientists, external to core) replicates a sample (≥1) of cell-build and cycling data reported by each chemistry team before gate decision; confirm cell-level mass-and-volume model methodology and verify no inflated Wh/kg claims from material-level artifacts.
- Partner cost-sharing and deliverable audit (Months 12, 24, 36, 48, 60, 72 = 2027-10-14, 2028-10-14, 2029-10-14, 2030-10-14, 2031-10-14, 2032-10-14): reconcile partner invoices and in-kind contributions (≥15% of shared costs proposed) to formal agreements; verify characterization turnaround (≤3 weeks proposed) and data quality; confirm backup partner capacity agreements are in place and tested by Month 6 (2027-04-14).
- EHS compliance and permitting audit (Months 1, 3, 6, 9, 12, 24, 36 = 2026-11-14, 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-10-14, 2029-10-14): verify Phase 1–3 permits obtained on schedule; confirm hazardous-materials inventory, waste handling and incident reporting per EPA, OSHA and TCEQ; document quarterly internal EHS audits and confirm no serious incidents; validate regulatory-monitoring consulting retainer is active.

## Audit - Transparency Measures

- Monthly Steering Committee financial dashboard: published summary (internal to funder and Steering Committee) of cumulative spend by budget category, remaining tranches and reserve allocation, variance from plan by ±15% threshold, and any pending reallocations requiring approval; refreshed within 10 days of month-end.
- Quarterly technical-progress report (Months 3, 6, 9 = 2027-01-14, 2027-04-14, 2027-07-14, …, 84): documented summary by chemistry team of cell builds, cycling data, Wh/kg and Wh/L measurements against the cell-level mass-and-volume model, cycle-life and safety thresholds (proposed ≥300 cycles at 80%, thermal runaway ≥120°C), with Steering Committee review; red-team replication results included at gates.
- Gate-decision documentation (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): published to funder and Steering Committee go/no-go criteria applied (Month 18 = 2028-04-14 projected cell-level ≥500 Wh/kg and ≥950 Wh/L; Month 30 = 2029-04-14 measured pouch-cell proof with ≥3 replicates; Month 36 = 2029-10-14 selection of finalist meeting all thresholds), decision rationale, and forward-plan if contingency paths activated.
- Supplier and contract register: maintained and shared with funder and governance committee; lists all vendors >USD 100 K spend (precursors, equipment, testing), contract terms, pricing benchmarks, sole-source justifications and competitive-bid documentation (or escalation approvals if sole-source is necessary).
- IP filing and publication log: published schedule of patent applications (provisional and utility), research publications and technology-transfer disclosures, with filing dates, inventor teams and review compliance status; confirms 6-month partner-review windows (proposed) and clean-room onboarding attestations.
- Staffing and retention dashboard: quarterly report to Steering Committee of headcount by role (senior, postdoctoral, graduate), attrition rate (measured; target <15%, proposed), new hires and departures with reason codes, and salary-band conformity; escalates >15% attrition for compensation review by Month 24 (2028-10-14).
- Regulatory and EHS public summary: annual statement submitted to Austin Fire Authority, TCEQ and funder describing permits held (Phase 1–3), incident history (none expected; zero reportable incidents is the target), waste-stream volumes and disposal routes, and compliance audit results; establishes community transparency and regulator confidence.

# Internal Governance Bodies

### 1. Scientific Steering Committee

**Rationale for Inclusion:** Manages strategic direction, gate decisions (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) and major resource allocation in a high-ambition, capital-constrained R&D programme with three competing chemistry pathways. Resolves disputes over chemistry advancement, budget reallocation and pivot decisions. Ensures evidence-linked tranche release and protects programme credibility through independent oversight of claims.

**Responsibilities:**

- Approve chemistry-tournament structure and success criteria by Month 3 (2027-01-14); decide funding allocation among active teams
- Conduct Month 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14) gate reviews, applying documented go/no-go criteria and independent red-team verification results
- Authorize chemistry selection at Month 36 (2029-10-14); approve reserve activation and major pivots if needed
- Approve tranche releases (T2 at Month 12 = 2027-10-14, T3 at Month 24 = 2028-10-14, T4 at Month 36 = 2029-10-14) linked to milestones; manage USD 20M reserve and pivot-runway allocation
- Oversee risk management: review technical risks (chemistry, volumetric density, cycle-life, safety), operational risks (permitting delays, talent attrition, partner dependency) and financial risks (budget burn, cost overruns) quarterly
- Review and approve IP strategy by Month 2 (2026-12-14), licensing framework by Month 24 (2028-10-14) and commercialization plan by Month 72 (2032-10-14)

**Initial Setup Actions:**

- Establish Committee membership (director, four chemistry leads, external technical advisor, funder representative) by Month 1 (2026-11-14)
- Document decision authority: financial thresholds (Steering Committee authorizes decisions >USD 2M or >20% of annual tranche; Director authorizes USD 500K-2M within approved budget), escalation path (funder for programme stop or major descope), and conflict resolution (majority vote with tie-breaker by Director)
- Set Committee meeting cadence: monthly (first 12 months) then quarterly, with 3-week gate-review cycles at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14)
- Define gate criteria and success metrics by Month 3 (2027-01-14): Month 18 (2028-04-14) = projected cell-level ≥500 Wh/kg and ≥950 Wh/L plus cycle-life data; Month 30 (2029-04-14) = measured pouch cells meeting thresholds; Month 36 (2029-10-14) = one finalist selected
- Appoint independent red team (2-3 external or in-house non-core scientists) by Month 1 (2026-11-14) reporting directly to Steering Committee
- Establish decision documentation protocol: gate decisions, financial approvals, and risk escalations recorded and shared with funder within 5 days

**Membership:**

- Programme Director (chair)
- Senior Chemistry Lead (lithium-sulfur pathway, e.g.)
- Senior Chemistry Lead (anode-free solid-state pathway, e.g.)
- Senior Chemistry Lead (conversion cathode or reserve pathway, e.g.)
- Chief Technology Officer or Deputy Director (operational oversight liaison)
- External Technical Advisor (independent expert from battery research community)
- Funder Representative (non-voting observer, approves releases and stop decisions)

**Decision Rights:** Steering Committee holds exclusive authority over chemistry tournament structure and finalist selection (Month 36 = 2029-10-14), tranche release (T2-T4) conditioned on milestones, reserve allocation and programme pivots costing >USD 5M. Director (chair) has delegated authority to approve decisions up to USD 2M within approved tranches and to reallocate within 15% of chemistry-team budgets. Funder representative approves any decision to stop or descope the programme. Red team has authority to challenge progress claims and delay gate decisions up to 3 weeks for independent verification.

**Decision Mechanism:** Majority vote among Committee members (7 members; 4 required for quorum). Tie-breaker: Director casts second vote if tie occurs. Red team replication results (pass/fail on key claims) are required inputs to Month 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14) gates and must be presented in writing ≥5 days before gate meeting. If red team flags unresolved inconsistencies, gate decision deferred ≤3 weeks for remedial verification; if unresolved after 3 weeks, gate advances but flag is escalated to funder. Financial decisions >USD 5M require unanimous consent or funder sign-off.

**Meeting Cadence:** Monthly full meetings Months 0-12 (2026-10-14 to 2027-10-14), then quarterly Months 12-84 (2027-10-14 to 2033-10-14). Emergency meetings ≤48 hours if a critical risk surfaces (e.g., major chemistry failure, permitting denial, partner loss). Gate review cycles at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) conducted over 3 weeks: Week 1 red-team verification report, Week 2 chemistry-team response and Steering Committee deliberation, Week 3 final decision and communication to funder.

**Typical Agenda Items:**

- Progress reports from each chemistry team: cell builds, cycling data, measured Wh/kg and Wh/L, cycle-life performance, safety-test results, comparison to cell-level mass-and-volume model
- Risk register review: technical (chemistry, volumetric density, cycle-life, safety), operational (permitting, talent, partner access, supply chain), financial (burn rate, cost overruns, currency exposure); escalation of any risk approaching trigger thresholds
- Red-team findings: replication results, challenged claims, unresolved discrepancies and remedial actions
- Financial dashboard: cumulative spend by category, remaining tranches, reserve utilization, variance from plan, pending reallocations
- Partnership and characterization access status: partner deliverables, queue times, backup-partner activation if needed
- IP and regulatory updates: patent applications filed, publications reviewed for compliance, permit status, EHS incidents and corrective actions

**Escalation Path:** Steering Committee escalates to the Funder (non-voting member) any decision involving: (i) programme stop or >25% descope, (ii) additional funding beyond USD 300M cap, (iii) major chemistry-path change deviating from tournament structure (e.g., adding a fourth active chemistry or abandoning one before Month 30 = 2029-04-14), (iv) financial overrun >20% of current tranche. Red team escalates directly to Steering Committee (bypassing chemistry leads) any unresolved claim inconsistency or high-risk safety issue. Steering Committee escalates to Funder within 48 hours any incident threatening permitting, safety or regulatory compliance.
### 2. Chemistry and Discovery Leadership Team

**Rationale for Inclusion:** Manages day-to-day R&D execution across three active chemistry pathways plus reserve. Owns synthesis, pouch-cell fabrication, electrochemical characterization, failure analysis and iteration pace. Reports progress, cycle-life data and safety results to Steering Committee; escalates risks and resource conflicts. Team structure hedges chemistry risk while maintaining focus and preventing runaway scope.

**Responsibilities:**

- Execute chemistry-tournament strategy: maintain three active teams (lithium-sulfur, anode-free solid-state, conversion cathode or similar) with clear leads and budgets; manage weekly team meetings, monthly progress reviews and adherence to gate criteria
- Design, build and cycle cells: execute pouch-cell fabrication (50-100 cells/month by Month 24 = 2028-10-14), manage pilot-line scheduling, document build parameters and correlate cell performance to process variables
- Measure energy density and cycle life: characterize all cells for Wh/kg, Wh/L, cycle retention at defined rates and temperatures; report data against cell-level mass-and-volume model within one week of completion
- Manage failure forensics: autopsy every failed cell within one week using standardized protocol; perform post-mortem microscopy, electrolyte analysis and impedance testing; populate forensics atlas with root causes and design-change implications
- Oversee characterization scheduling: coordinate with university and national-lab partners for operando and post-mortem analysis; manage backlogs and escalate queue delays >3 weeks to Steering Committee
- Track safety and abuse testing: schedule thermal-ramp screening and contracted abuse tests per phased plan; maintain thermal-runaway thresholds (proposed: ≥120°C for finalists); escalate any chemistry dropping below safety thresholds to red team for gate impact

**Initial Setup Actions:**

- Define chemistry-team leads and core members by Month 1 (2026-11-14); allocate budget per team proportional to strategic priority (proposed: equal initial share, rebalanced after Month 12 = 2027-10-14 based on progress)
- Establish cell-level mass-and-volume model by Month 4 (2027-02-14); project Wh/kg and Wh/L for each chemistry starting Month 6 (2027-04-14); perform monthly updates and variance analysis by Month 20 (2028-06-14)
- Commission pilot-line dry-room and pouch-cell fabrication line by Month 3 (2027-01-14); conduct trial builds and yield-optimization work Months 3-6 (2027-01-14 to 2027-04-14); reach target 50-100 cells/month by Month 24 (2028-10-14)
- Establish forensics autopsy protocol and forensics atlas by Month 6 (2027-04-14); begin weekly failure analysis by Month 9 (2027-07-14)
- Identify and contract with primary characterization partners (≥2) by Month 3 (2027-01-14); negotiate guaranteed turnaround (≤3 weeks) and schedule first external analysis by Month 9 (2027-07-14)
- Define go/no-go criteria per chemistry by Month 18 (2028-04-14): specify cycle-life target (proposed ≥300 cycles), Wh/kg and Wh/L thresholds (≥500 Wh/kg, ≥950 Wh/L interim), safety onset threshold (≥120°C) and what counts as 'pass' at Month 30 (2029-04-14)

**Membership:**

- Chemistry Lead 1 (lithium-sulfur pathway)
- Chemistry Lead 2 (anode-free solid-state pathway)
- Chemistry Lead 3 (conversion cathode or reserve pathway)
- Synthesis Team Manager (precursor sourcing, material procurement, lab safety coordination)
- Pilot-Line and Cell-Engineering Lead (pouch-cell design, fabrication, process control)
- Characterization and Forensics Lead (operando and post-mortem analysis, failure-root-cause investigation)
- Data and Modeling Engineer (cell-level mass-and-volume model maintenance, performance tracking, statistical analysis)

**Decision Rights:** Chemistry Leadership Team owns all decisions below USD 500K per chemistry per quarter and within approved tranches. Decides resource allocation among synthesis, characterization and pilot-line work; adjusts chemistry-team budgets by ≤15% per quarter without Steering Committee approval, provided total stay within approved tranches. Decides cell-build schedule, characterization priorities and failure-analysis focus. Escalates to Steering Committee: cost overruns (team spend >USD 500K/quarter), schedule slips >4 weeks, cycle-life data missing at gate thresholds, safety concerns (onset <120°C or non-reversible overcharge), and characterization queue delays >4 weeks.

**Decision Mechanism:** Chemistry Leadership Team (7 members) meets weekly; Leads and Manager form a core decision group. Decisions by consensus if possible; tie-breaker: Chemistry Lead 1 (lithium-sulfur, most mature path) casts deciding vote on inter-team resource allocation, Pilot-Line Lead decides on fabrication scheduling conflicts, Characterization Lead decides on characterization-access conflicts. Major within-team changes (>20% staffing shift, >USD 100K reallocation per month) require written justification to Steering Committee within 5 days. Monthly reports to Steering Committee include progress summary, risk flags and revised go/no-go trajectory.

**Meeting Cadence:** Weekly synthesis and characterization team meetings (within-team technical sync), monthly full Chemistry Leadership meetings with Steering Committee liaison, quarterly deep-dive reviews with Steering Committee (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14, 2029-10-14, etc.). Emergency meetings if safety issue arises or characterization bottleneck threatens timeline.

**Typical Agenda Items:**

- Cell-build status: fabrication yield, cycle-test results, Wh/kg and Wh/L measurements against model, batch-to-batch variability (target 90% within ±10%)
- Failure analysis: new failures diagnosed, root causes assigned, forensics atlas updated, design changes queued
- Characterization queue and throughput: samples processed, turnaround time, any backlog or partner delays, escalation if needed
- Chemistry-specific progress: synthesis scalability, electrolyte/interface stability, lithium-metal protection or other design focus per pathway
- Go/no-go trajectory: quarterly assessment against Month 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) criteria; updated projections if a chemistry is off-track
- Safety and abuse testing: upcoming scheduled tests, results from thermal-ramp or contracted testing, onset temperatures, any threshold violations

**Escalation Path:** Chemistry Leadership escalates to Steering Committee: (i) any chemistry showing cycle-life <250 cycles at 80% by Month 24 (2028-10-14), (ii) thermal-runaway onset <100°C at any point, (iii) measured pouch-cell Wh/L projected to fall below 950 Wh/L by Month 30 (2029-04-14), (iv) characterization queue delays exceeding 4 weeks, (v) precursor supply delays >2 weeks, (vi) cost overruns >USD 500K/quarter per team. Escalates to red team directly if a measurement discrepancy arises that undermines gate credibility (e.g., Wh/kg claims not reproducible at ≥90% consistency). Escalates to Compliance Office any safety incident (burns, chemical spill, equipment failure in abuse chamber, EHS violation).
### 3. Independent Technical Verification and Assurance Group (Red Team)

**Rationale for Inclusion:** High-ambition R&D programmes with competition between teams and high stakes (gatekeeping a USD 90M tranche or chemistry selection) face pressure to overstate progress or hide negative data. An independent red team with explicit authority to replicate key results, challenge claims and delay gate decisions protects programme credibility, patent value and funder confidence. Red team operates outside core teams to avoid bias.

**Responsibilities:**

- Replicate critical experimental results at each gate (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): build ≥1 independently chosen cell per chemistry team (or ≥3 for finalist), cycle per the original protocol and verify Wh/kg, Wh/L and cycle-life claims within ±10%
- Challenge progress claims: review monthly Chemistry Leadership reports and flag any inconsistencies (e.g., Wh/kg reported in November contradicts October data, or claimed ≥950 Wh/L but actual measured value is 920 Wh/L) within 5 days
- Verify gate-decision criteria are met before advancement: at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14), independently confirm that go/no-go threshold (e.g., ≥500 Wh/kg measured on ≥3 replicates) is satisfied or not; report findings in writing ≥5 days before Steering Committee gate meeting
- Audit cell-level mass-and-volume model methodology: review model assumptions (current-collector thickness, separator weight, inactive components), validate against actual pouch-cell teardowns (mass, volume, component count) quarterly, flag any deviations from physical reality
- Manage forensics quality: review forensic root-cause assignments (e.g., is a claimed 'dendrite growth failure' supported by SEM evidence?); escalate unfounded or inconsistent root-cause narratives to Chemistry Lead for correction
- Report directly to Steering Committee: monthly written summary of any discrepancies or concerns; gate-decision readiness memo ≥5 days before each gate

**Initial Setup Actions:**

- Recruit red team members (2-3 external or internal non-core scientists with battery expertise) by Month 1 (2026-11-14); establish independence: no reporting to chemistry leads, separate budget, authority to request data and resources from core teams
- Define replication protocol and acceptance criteria by Month 3 (2027-01-14): specify cell-build procedure (sourced materials, assembly by red-team personnel or independent third party), cycling protocol (discharge rate, temperature, cycle count) and measurement tolerance (±10% on Wh/kg, ±5% on Wh/L, ±5% on cycle-life retention)
- Establish monthly data-review cadence: receive Chemistry Leadership monthly reports within 5 days of publication, issue flag memo within 10 days if discrepancies detected
- Plan gate-verification timeline: identify ≥1 cell per team (or ≥3 for finalist) for replication ~4 weeks before gate meeting, issue replication results ≥5 days before Steering Committee meeting
- Conduct initial audit of cell-level mass-and-volume model (Month 6 = 2027-04-14): review model code, assumptions and prior pouch-cell measurements; report comparison of modeled Wh/kg vs actual measured Wh/kg for prior benchmark cells
- Set up forensics-quality review process (Month 9 = 2027-07-14): receive monthly forensics atlas updates from Chemistry Lead, spot-check ≥3 failure root-cause assignments per month against SEM/spectroscopy data

**Membership:**

- Red Team Lead (external expert or senior scientist not embedded in core teams)
- Electrochemistry Expert (post-doctoral or senior scientist: cell building, cycling, Wh/kg/L measurement)
- Characterization Specialist (operando and post-mortem analysis, failure-root-cause validation)

**Decision Rights:** Red team has exclusive authority to delay a gate decision ≤3 weeks to complete verification if core-team data is incomplete or inconsistent. Red team can request access to any chemistry-team laboratory notebook, instrument calibration records, and characterization data to validate claims. Red team cannot override Steering Committee gate decisions but can flag unresolved discrepancies to Funder, forcing resolution before tranche release. Red team can recommend demotion of a chemistry if replication consistently fails (measured <90% of claimed Wh/kg or Wh/L) or cycle-life claim is not supported.

**Decision Mechanism:** Red team decisions by consensus among the 3 members. If disagreement arises (e.g., one member thinks replication passed, two think it failed), red-team lead casts deciding vote. Red team prepares written gate-readiness memo (pass/no-pass/conditional pass with required remediation) signed by all three members. Steering Committee may override red-team no-pass recommendation only with unanimous vote and written justification to Funder.

**Meeting Cadence:** Weekly internal red-team technical meetings (30 min sync on replication status, monthly data-review findings), monthly data-review prep meetings (1 hour to plan gate verifications), gate-verification sprints at Months 17, 29, 35 (2028-03-14, 2029-03-14, 2029-09-14) (2-3 weeks focused replication work leading into Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14 gates).

**Typical Agenda Items:**

- Monthly data-review findings: discrepancies flagged in Chemistry Leadership reports, follow-up required, clarification received from chemistry leads
- Replication status: cells being built, cycling progress, preliminary Wh/kg/L and cycle-life results, on-track for gate-readiness memo delivery
- Model audit results: comparison of cell-level mass-and-volume model projections vs actual measured pouch cells, model assumptions validated or requiring revision
- Forensics quality spot-checks: failure root-cause assignments reviewed, SEM/spectroscopy evidence assessed, any unsupported claims flagged for correction
- Gate-readiness decision: pass/no-pass/conditional recommendation, required remediation if conditional, planned communication to Steering Committee

**Escalation Path:** Red team escalates directly to Steering Committee (bypassing chemistry leads) any finding suggesting: (i) systematic overstatement of Wh/kg or Wh/L (measured <85% of claimed), (ii) cycle-life data not reproducible, (iii) safety concern (onset <100°C not disclosed), (iv) forensic root-cause narratives unsupported by data. Red team escalates to Funder within 48 hours any finding suggesting programme data integrity issue or deliberate misrepresentation. If red team replication consistently fails for a chemistry, red team recommends Steering Committee demote or eliminate that chemistry path independent of chemistry-team objections.
### 4. Compliance, EHS and Regulatory Affairs Office

**Rationale for Inclusion:** High-energy lithium-rich cells require synthesis of reactive metals, flammable electrolytes and toxic precursors, plus abuse testing (thermal runaway, nail penetration, overcharge) in specialized chambers. Overlapping EPA hazardous-waste, OSHA worker-safety, TCEQ environmental, and local (Austin Fire Authority) permitting rules create complex compliance risk. A serious incident (lithium-water fire, solvent spill, overcharge thermal runaway) could shut operations for months and jeopardize the USD 300M programme. Dedicated compliance governance ensures permitting, incident prevention, regulatory monitoring and rapid response.

**Responsibilities:**

- Secure phased permits and licenses: Phase 1 dry-room and assembly (Month 3 = 2027-01-14), Phase 2 reactive-metal and solvent synthesis (Month 6 = 2027-04-14), Phase 3 abuse-test chambers (Month 9 = 2027-07-14); manage applications, regulator engagement and compliance conditions
- Maintain hazardous-materials compliance: register as EPA hazardous-waste generator, contract licensed waste handler, maintain inventory of reactive metals (lithium, sodium), flammable solvents and toxic precursors, document quantities and disposal per EPA rules
- Implement EHS operating model: document standard operating procedures for reactive-chemistry synthesis, dry-room operation, cell assembly, abuse testing and waste handling; train all staff quarterly; maintain incident log and corrective-action tracking
- Conduct quarterly internal EHS audits: inspect lab facilities, verify compliance with permits, audit waste-handling practices, test emergency response (spill kits, fire suppression, evacuation), check equipment maintenance and calibration
- Manage regulatory monitoring: retain external regulatory consultant to track federal (EPA, OSHA, DOT), state (TCEQ) and local (Austin Fire Authority) rule changes; assess impact on operations; propose adaptations or retrofits if needed
- Coordinate third-party safety testing: schedule and oversee thermal-ramp screening (Months 3-6 = 2027-01-14 to 2027-04-14), contracted abuse tests (Months 6-12 = 2027-04-14 to 2027-10-14) and in-house abuse chambers (Month 18 = 2028-04-14 onwards); verify test protocols meet ASTM or equivalent standards

**Initial Setup Actions:**

- Hire Chief EHS Officer (experienced battery-lab or chemical-manufacturing background) by Month 1 (2026-11-14); establish Compliance Office with initial 1-2 FTE
- Conduct regulatory assessment by Month 2 (2026-12-14): map all applicable EPA, OSHA, TCEQ and local rules; document current gaps (if any) relative to planned chemistry and testing scope; identify permit categories and application timelines
- Develop phased-permit strategy by Month 2 (2026-12-14): propose Phase 1 (dry-room, low-hazard assembly) by Month 3 (2027-01-14); Phase 2 (reactive synthesis) by Month 6 (2027-04-14); Phase 3 (abuse chambers) by Month 9 (2027-07-14); identify any showstoppers or long-lead items
- Initiate regulator engagement (Austin Fire Authority, TCEQ) at Month 0 (2026-10-14), before formal applications, to build collaborative relationship and identify early concerns
- Develop standard operating procedures (SOPs) for reactive chemistry, dry-room operation, waste handling and abuse testing by Month 6 (2027-04-14); review with regulatory consultant; distribute and train all staff
- Establish incident-response protocol by Month 3 (2027-01-14): define roles (EHS lead, emergency coordinator, regulator notification), communication chain, remediation steps and incident-log documentation
- Contract regulatory-monitoring consultant by Month 3 (2027-01-14); retain ongoing subscription to federal and state regulatory update services; establish quarterly regulatory-review meetings

**Membership:**

- Chief EHS Officer (full-time)
- Regulatory Affairs Manager (part-time or shared, ~0.5 FTE)
- Laboratory Safety Coordinator (on-site, ~0.5 FTE, embedded in chemistry teams)
- External EHS Advisory Committee (established by Month 6 = 2027-04-14): include representatives from Austin Fire Authority, TCEQ, a third-party safety consultant, and the programme's external technical advisor

**Decision Rights:** Chief EHS Officer has authority to halt any laboratory operation if safety or compliance concern arises (e.g., permit violation, improper chemical handling, equipment malfunction); halt remains in effect until remediated and approved by EHS Officer. Chief EHS Officer approves any synthesis of new chemical precursor or reactive material before first use on site, including review of hazard data sheets, storage requirements and waste-disposal plan. Chief EHS Officer approves in-house abuse-test protocols before chambers are commissioned. Regulatory Affairs Manager approves any external communications regarding environmental incidents or compliance status. Steering Committee must approve any decision to outsource on-site-prohibited chemistry synthesis (estimated cost USD 2-5M/yr if needed) or to defer permitting of planned facilities (e.g., delay abuse chambers from Month 9 = 2027-07-14 to Month 12 = 2027-10-14).

**Decision Mechanism:** Chief EHS Officer issues safety halt unilaterally if immediate danger is present; all other decisions by consensus with Regulatory Affairs Manager and Laboratory Safety Coordinator (3 required). If disagreement arises (e.g., EHS lead says chemistry must be outsourced, Chemistry Lead disagrees on hazard level), external EHS Advisory Committee member is consulted within 48 hours and their input informs final decision. Monthly EHS reports to Steering Committee document compliance status, any incidents (goal: zero), corrective actions and anticipated permitting milestones.

**Meeting Cadence:** Weekly EHS coordination meetings (30 min) with Chemistry Leadership Lab Safety Coordinator, monthly full Compliance Office meetings (1 hour), quarterly internal audits (2-3 days on site), annual external audit by third-party safety firm (2-3 days on site), quarterly regulator engagement meetings (with Austin Fire Authority, TCEQ representatives).

**Typical Agenda Items:**

- Permit status and timeline: Phase 1-3 application progress, regulator feedback, anticipated approval dates, any barriers or required adaptations
- Compliance findings from quarterly internal audits: violations or near-misses, root causes, corrective actions and completion status
- Incident log review: any chemical spills, equipment failures, near-misses, injuries; corrective actions taken and lessons learned
- Regulatory-update monitoring: new EPA, OSHA, TCEQ or local rules affecting operations; impact assessment and required adaptations
- Safety-testing status: scheduled thermal-ramp and abuse tests, protocol review, contractor qualifications, result review and any safety thresholds (proposed ≥120°C onset) met
- Waste-handling and inventory: hazardous-waste streams, disposal routes, contractor compliance, chemical inventory accuracy checks against permits

**Escalation Path:** Chief EHS Officer escalates to Steering Committee (within 48 hours) any: (i) serious incident (fire, chemical release, equipment failure) causing injury or environmental exposure, (ii) regulatory notice of violation (NOV) or threatened permit revocation, (iii) discovery of non-compliance requiring costly retrofit or extended downtime, (iv) regulator demand for operational change (e.g., tighter dry-room control, equipment replacement). Chief EHS Officer escalates to external EHS Advisory Committee for input on complex hazard assessment (e.g., is a newly identified precursor allowable on site?) or permitting questions. Chief EHS Officer escalates to Funder within 72 hours any serious incident and remediation cost >USD 1M.
### 5. Finance and Funding Governance (Integrated within Steering Committee)

**Rationale for Inclusion:** The fixed USD 300M budget is divided into evidence-linked tranches (USD 60/80/70/90M) with USD 20M reserve and USD 15M pivot runway. Financial governance ensures tranche release is conditional on demonstrated milestones, spending stays within tranches and allocated reserves, and budget reallocation decisions are transparent and controlled. The opex-vs-tranche mismatch (average opex ~USD 33M/yr vs Months 36-84 = 2029-10-14 to 2033-10-14 tranche of ~USD 22.5M/yr) requires careful carry-forward management and partner co-funding coordination. Integrated within Steering Committee rather than standalone to ensure financial decisions align with technical gates.

**Responsibilities:**

- Manage tranche release: T1 (USD 60M) released at project start Month 0 (2026-10-14); T2 (USD 80M) at Month 12 (2027-10-14) conditional on Phase 1 permit, operational pilot line and cell-level model live; T3 (USD 70M) at Month 24 (2028-10-14) conditional on Month 18 (2028-04-14) gate pass; T4 (USD 90M) at Month 36 (2029-10-14) conditional on chemistry selection gate and Month 30 (2029-04-14) pouch verification
- Monitor spend against tranches: monthly dashboard of cumulative spend by budget category (payroll ~USD 70M, capital ~USD 50M, facility ~USD 25M, variable ~USD 135M), remaining tranche balance, variance from plan and pending reallocations; escalate any category >±15% of plan
- Manage reserve (USD 20M unallocated) and pivot runway (USD 15M ring-fenced): hold unallocated and available for urgent redirects, pivots or cost overruns; release only with Steering Committee approval (>USD 1M requires unanimous vote); carry forward unused reserve through Month 30 (2029-04-14), available for later-stage contingencies
- Coordinate partner co-funding (proposed ≥15% of shared costs): track partner financial and in-kind contributions (characterization access, graduate-student stipends, equipment loaning); verify deliverables are met; offset programme spend where applicable
- Manage currency risk: identify major equipment and precursor purchases denominated in EUR or other foreign currency by Month 2 (2026-12-14); negotiate fixed-USD contracts or forward-exchange agreements for capital orders (Months 2-6 = 2026-12-14 to 2027-04-14); monitor EUR/USD rate; retain USD 2-3M currency contingency within the USD 5M general reserve

**Initial Setup Actions:**

- Establish Finance Governance charter by Month 1 (2026-11-14): define tranche-release conditions, spend-approval authority (Director: <USD 500K/decision, Steering Committee: USD 500K-2M, Funder: >USD 2M or reserve activation), and variance thresholds (escalate if category >±15% of quarterly plan)
- Develop detailed budget allocation model by Month 2 (2026-12-14): break down USD 300M by category and year (payroll, capital, facility lease, precursor and testing, EHS and computing, reserve); validate sum-to-total and identify any funding gaps
- Set up monthly financial-tracking dashboard by Month 3 (2027-01-14): automated spend reporting by cost center (four chemistry teams, pilot line, characterization, EHS, computing, etc.), variance flagging (±15%) and tranche-balance tracking
- Identify all major equipment and precursor purchases expected to be denominated in foreign currency (EUR, CNY, JPY) by Month 2 (2026-12-14); by Month 6 (2027-04-14), lock in fixed-USD pricing or forward-exchange contracts for capital equipment ordered in Months 2-6 (2026-12-14 to 2027-04-14)
- Negotiate partner cost-sharing agreements by Month 3 (2027-01-14): formalize contributions (≥15% of shared characterization, materials and validation costs) in writing; establish invoicing and reconciliation process; integrate partner spend tracking into financial dashboard
- Document spend-approval authority and escalation protocol by Month 1 (2026-11-14): establish approval matrices (Director approves <USD 500K, Steering Committee approves USD 500K-2M, Funder approves >USD 2M); require written justification for any variance >±15% or reallocation >USD 1M

**Membership:**

- Chief Financial Officer or Finance Manager (part-time, ~0.5 FTE, reports to Steering Committee chair or Director)
- Programme Controller (part-time or shared, ~0.3 FTE, manages monthly spend tracking and variance reporting)
- Steering Committee members (Director, chemistry leads, external advisor, funder representative) hold joint responsibility for budget-allocation decisions

**Decision Rights:** Director (Steering Committee chair) approves individual spending decisions up to USD 500K without committee vote, provided cumulative monthly spend stays within approved chemistry-team or operational budgets. Steering Committee approves reallocation between budget categories (e.g., moving USD 1M from capital to payroll for higher hiring) if reallocation is <USD 2M and total spend stays within current tranche. Steering Committee approves tranche release contingent on documented milestone achievement (Phase 1 permit, cell-level model live, Month 18 = 2028-04-14 gate pass, etc.). Funder approves any decision to access reserve (>USD 1M) or to reallocate between tranches. Finance Manager flags any monthly spend variance >±15% within 5 days; if variance is projected to exceed ±20% by quarter-end, Finance Manager and Director jointly propose corrective action to Steering Committee.

**Decision Mechanism:** Monthly spend variance flagged by Finance Manager; if <±15%, no action required. If ±15% to ±20%, Director reviews and approves corrective action (e.g., spending freeze in a category, or approval to exceed category). If >±20%, escalated to Steering Committee for review and reallocation decision. Tranche release decisions require Steering Committee majority vote (4 of 7 members) plus Funder approval. Reserve activation (>USD 1M) requires Steering Committee unanimity.

**Meeting Cadence:** Monthly financial reviews (1 hour, first Thursday of each month) with Director and Finance Manager; quarterly full Steering Committee financial briefing included in regular Steering Committee agenda; ad-hoc escalations if variance >±20% or unplanned expense >USD 500K.

**Typical Agenda Items:**

- Monthly spend dashboard: cumulative spend by category, remaining balance in current tranche, variance from plan (<±15% normal, flag if ±15%-20%, escalate if >±20%)
- Burn-rate trajectory: YTD spend, projected annualized burn, carry-forward to next tranche, any anticipated shortfalls
- Variance explanations: if a category exceeds ±15%, Finance Manager explains reason (one-time purchase, hiring acceleration, cost inflation) and proposed mitigation
- Tranche-release readiness: upcoming tranche (T2, T3, T4) milestone status (permit, gate pass, cell verification), evidence of readiness, planned release date and sign-off
- Partner co-funding status: invoices received, in-kind contributions quantified, deliverables verified, balance of cost-sharing aligned with ≥15% target
- Currency and procurement: status of major equipment orders and foreign-currency exposure, forward-contract status, any FX volatility requiring mitigation

**Escalation Path:** Finance Manager escalates to Director within 5 days if any monthly spend category exceeds ±15% of plan. Director escalates to Steering Committee within 1 week if variance >±20% or if corrective action requires reallocation >USD 1M. Steering Committee escalates to Funder within 3 days if variance suggests tranche depletion ahead of schedule or if programme is at risk of spending >USD 300M total. Finance Manager escalates to Steering Committee immediately if any evidence of financial irregularity (unsupported invoices, cost-shadowing, double-billing) is discovered.

# Governance Implementation Plan

### 1. Project Sponsor confirms programme Director (chair of Scientific Steering Committee) and appoints four Chemistry Leads (one per active chemistry pathway, one for reserve chemistry management). Director and Leads are identified by name or role descriptor; appointment confirmation letter issued.

**Responsible Body/Role:** Project Sponsor (pre-existing funder authority; not yet a constituted committee)

**Suggested Timeframe:** Month 0 (2026-10-14) (project week 1-2)

**Key Outputs/Deliverables:**

- Appointment Confirmation Letter naming Director and four Chemistry Leads
- Director acceptance memo
- Chemistry Lead CVs and conflict-of-interest declarations

**Dependencies:**

- Project Sponsor identified and authorized to commit funding
- Recruitment of Director and Chemistry Leads completed or offers accepted

### 2. Project Sponsor formally appoints the independent red team members (2-3 external or internal non-core scientists) with explicit authority to replicate results, challenge claims and delay gate decisions. Red team members are selected for independence from core chemistry teams and report directly to the Scientific Steering Committee, not to chemistry leads.

**Responsible Body/Role:** Project Sponsor in consultation with appointed Director

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Red Team Member Appointment Letters (3 members)
- Red Team Charter documenting independence, decision authority and escalation rights
- Red Team member CVs and conflict-of-interest declarations

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- External expert advisors or senior scientists identified as candidates for red team

### 3. Project Sponsor appoints Chief EHS Officer and external regulatory/EHS consultant to lead hazardous-materials compliance, permitting and incident prevention. This role is filled before formal site selection to enable immediate regulator engagement.

**Responsible Body/Role:** Project Sponsor in consultation with appointed Director

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Chief EHS Officer Appointment Letter
- EHS Consultant Engagement Letter (3-5 year contract with quarterly regulatory-update briefings)
- Chief EHS Officer acceptance memo and initial 30-day plan

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Budget USD 500K-1M/yr approved for EHS staff and consulting

### 4. Director drafts initial Terms of Reference (ToR) for the Scientific Steering Committee, including decision authority, meeting cadence (monthly Months 0-12 = 2026-10-14 to 2027-10-14, then quarterly), gate-review process (3-week cycles at Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), escalation paths and conflict-resolution mechanisms. Draft incorporates lessons from the strategic-decisions document and risk-assessment framework.

**Responsible Body/Role:** Programme Director (appointed in Month 0 = 2026-10-14)

**Suggested Timeframe:** Month 0 (2026-10-14), within 1 week of appointment

**Key Outputs/Deliverables:**

- Draft Scientific Steering Committee ToR v0.1
- Proposed decision-authority matrix (Director: <USD 500K, Committee: USD 500K-2M, Funder: >USD 2M)
- Proposed gate-review timeline and criteria checklist

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Project Sponsor guidance on escalation paths and funder sign-off thresholds provided

### 5. Director circulates draft Scientific Steering Committee ToR for review and feedback from the nominated Chemistry Leads, external technical advisor and Funder representative. Review period is 1 week; feedback consolidated into a summary memo.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), concurrent with ToR drafting

**Key Outputs/Deliverables:**

- ToR Review Feedback Summary (consolidated from all reviewers)
- Marked-up draft ToR v0.2 with Director responses to feedback

**Dependencies:**

- Draft ToR v0.1 circulated (Month 0 = 2026-10-14)
- Chemistry Leads, external advisor and Funder representative identified and available to review

### 6. Director finalizes Scientific Steering Committee ToR incorporating feedback and obtains sign-off from Funder representative. Final ToR is issued and shared with all Committee members.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 1 (2026-11-14), by the end of the week

**Key Outputs/Deliverables:**

- Approved Scientific Steering Committee ToR v1.0
- Funder sign-off email or memo
- Distribution list and meeting-calendar invitations for first Committee meeting (Month 1 = 2026-11-14)

**Dependencies:**

- ToR v0.2 and feedback summary completed (Month 0-1 = 2026-10-14 to 2026-11-14)
- Funder representative acceptance of ToR authority levels

### 7. Chief EHS Officer and Director jointly engage Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ) and EPA representatives in an initial collaborative meeting to outline the programme's chemistry scope, permitting needs (phased dry-room, synthesis, abuse-test chambers) and compliance strategy. Regulator feedback informs the phased-permit plan.

**Responsible Body/Role:** Chief EHS Officer, supported by Programme Director and external EHS consultant

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), concurrent with EHS Officer hire

**Key Outputs/Deliverables:**

- Regulator Engagement Meeting Minutes (fire authority, TCEQ, EPA)
- Regulator Feedback Summary (permit categories, application timelines, early concerns)
- Preliminary Phased-Permit Plan (Phase 1-3 timeline and required applications)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Site location selected or under review (not yet required to be final)

### 8. Director and Finance Manager jointly develop a detailed budget-allocation model breaking down the USD 300M by category (payroll, capital, facility, precursor, testing, EHS, computing, reserve) and year. The model identifies any funding gaps, carry-forward requirements (Months 36-84 = 2029-10-14 to 2033-10-14 opex shortfall) and partner co-funding offset targets (proposed ≥15%).

**Responsible Body/Role:** Programme Director, supported by Finance Manager (hired or identified by Month 2 = 2026-12-14)

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Budget Allocation Model v1.0 (Excel or equivalent, detailed by year and cost center)
- Funding-Gap Analysis (identifying Months 36-84 = 2029-10-14 to 2033-10-14 shortfall and carry-forward plan)
- Partner Co-Funding Offset Plan (proposed targets by category)

**Dependencies:**

- Director and Chemistry Leads available to confirm staffing and capital assumptions
- Finance Manager hired or identified

### 9. Director and Chief EHS Officer jointly develop a comprehensive regulatory-compliance assessment covering EPA, OSHA, TCEQ, DOT and local Austin Fire Authority rules applicable to the programme's reactive-materials, synthesis and abuse-testing operations. Assessment identifies all required permits, generators licenses, waste-contractor agreements and standard operating procedures (SOPs) by scope (dry-room, synthesis, waste handling, abuse testing).

**Responsible Body/Role:** Chief EHS Officer in collaboration with Director; external EHS consultant provides subject-matter expertise

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Regulatory Compliance Assessment Report (EPA, OSHA, TCEQ, DOT, local)
- Permit Categories and Application Checklist (required documents, lead times, decision points)
- SOP Template Library (dry-room, synthesis, waste handling, abuse testing, incident response)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Regulator engagement meeting completed (Month 0-1 = 2026-10-14 to 2026-11-14), providing initial feedback
- External EHS consultant retained (Month 1 = 2026-11-14)

### 10. Chief EHS Officer and external consultant identify all major equipment and precursor purchases expected to be denominated in foreign currencies (EUR, CNY, JPY) and develop a foreign-exchange (FX) risk-mitigation plan. Plan includes forward-exchange contracts and fixed-USD pricing for capital equipment ordered in Months 2-6 (2026-12-14 to 2027-04-14), and reserves USD 2-3M FX contingency within the USD 5M general reserve.

**Responsible Body/Role:** Finance Manager in consultation with Director and Chemistry Leads

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Foreign-Currency Exposure Inventory (major equipment and precursor purchases, estimated amounts and currencies)
- FX Risk-Mitigation Strategy (forward contracts, USD fixed-pricing, hedging plan)
- FX Contingency Reserve Allocation (USD 2-3M within USD 5M general reserve)

**Dependencies:**

- Budget allocation model complete (Month 2 = 2026-12-14)
- Preliminary equipment and precursor sourcing list available from Chemistry Leads

### 11. Director institutes the IP strategy and clean-room onboarding protocol, including confidentiality agreements, non-use clauses for employees from Tesla or competing firms, background-check procedures and a 6-month observation period before full access to sensitive designs. IP strategy document specifies filing timelines (provisional patents on key compositions and formats as they emerge, non-core materials work published in peer-reviewed journals after 6-month review).

**Responsible Body/Role:** Programme Director in consultation with Legal Counsel and appointed Chemistry Leads

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14)

**Key Outputs/Deliverables:**

- IP Strategy Document (filing scope, provisional-patent timeline, publication review process, licensing framework planned for Month 24 = 2028-10-14)
- Clean-Room Onboarding Protocol (confidentiality agreements, non-use clauses, background-check procedure)
- Employee Disclosure and Conflict-of-Interest Form Template

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Legal Counsel available for guidance
- Recruitment of core team members underway or about to begin

### 12. Director and Chemistry Leads jointly define go/no-go criteria for the Month 18 (2028-04-14), Month 30 (2029-04-14) and Month 36 (2029-10-14) gate reviews. Criteria include quantified thresholds for cell-level energy density (≥500 Wh/kg, ≥950 Wh/L interim), cycle life (≥300 cycles at 80% retention, proposed threshold), safety (thermal-runaway onset ≥120°C, proposed), and cell-level mass-and-volume model reproducibility (90% of cells within ±10%, proposed). Criteria are documented in a Gate Criteria Specification document.

**Responsible Body/Role:** Programme Director in collaboration with Chemistry Leads and independent red team (once appointed)

**Suggested Timeframe:** Month 3 (2027-01-14), to be finalized before active chemistry work reaches Month 6-9 (2027-04-14 to 2027-07-14) scale

**Key Outputs/Deliverables:**

- Gate Criteria Specification Document (Month 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14 go/no-go thresholds with quantified metrics)
- Cell-Level Mass-and-Volume Model Specification (inputs, assumptions, target accuracy ±10%)
- Success-Metrics Dashboard Template (for quarterly tracking against gate criteria)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Red team appointed (Month 1 = 2026-11-14) and briefed on gate-criteria development

### 13. Programme Director calls and chairs the first Scientific Steering Committee meeting. Agenda includes: (i) Committee ToR, decision authority and escalation paths review; (ii) red-team charter and independence agreement; (iii) chemistry-tournament structure and budget allocation per team; (iv) gate-criteria and success metrics review; (v) risk register initialization and mitigation-plan assignments; (vi) calendar and meeting logistics. Meeting concludes with Committee consensus on roles and first-action items.

**Responsible Body/Role:** Programme Director (chair of Scientific Steering Committee, now formally constituted)

**Suggested Timeframe:** Month 1 (2026-11-14), within 1 week of finalizing Committee ToR

**Key Outputs/Deliverables:**

- Scientific Steering Committee Meeting Minutes (including attendance, decisions, action items with owners and due dates)
- Committee consensus memo confirming ToR, decision authority, meeting schedule and first 90-day action plan
- Risk Register v1.0 initialized with 20+ risks, owners and mitigation plans

**Dependencies:**

- Scientific Steering Committee ToR finalized (Month 1 = 2026-11-14)
- All Committee members appointed and available to attend

### 14. Director and Chemistry Leads jointly establish the Chemistry and Discovery Leadership Team structure, confirming team leads and core members for each of the three active chemistry pathways plus reserve. Team budgets are allocated (proposed: equal initial share Months 0-12 = 2026-10-14 to 2027-10-14, rebalanced after Month 12 = 2027-10-14 based on progress). Chemistry Leadership ToR is drafted, specifying weekly team meetings, monthly progress reviews, decision authority (≤USD 500K per team per quarter), escalation thresholds and reporting to the Scientific Steering Committee.

**Responsible Body/Role:** Programme Director in consultation with appointed Chemistry Leads

**Suggested Timeframe:** Month 1 (2026-11-14), concurrent with first Steering Committee meeting

**Key Outputs/Deliverables:**

- Chemistry and Discovery Leadership Team ToR v1.0 (decision authority, meeting cadence, escalation paths)
- Chemistry-Team Budget Allocation (USD allocation per team, Month 0-12 = 2026-10-14 to 2027-10-14 and Month 12-24 = 2027-10-14 to 2028-10-14 outlook)
- Chemistry Leadership Roster (team leads, synthesis manager, pilot-line manager, characterization manager, data manager)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)

### 15. Chief EHS Officer drafts standard operating procedures (SOPs) for reactive-chemistry synthesis, dry-room operation, cell assembly, pouch-cell fabrication, waste handling and abuse testing. SOPs are reviewed by the external EHS consultant and regulator for compliance with EPA, OSHA and TCEQ rules. Draft SOPs are circulated to Chemistry Leads for feasibility and operability feedback.

**Responsible Body/Role:** Chief EHS Officer supported by external EHS consultant

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Standard Operating Procedures Library (synthesis, dry-room, cell assembly, waste handling, abuse testing, incident response)
- Regulator Review Feedback Summary (fire authority and TCEQ input on SOP compliance)
- SOP v1.0 Final (incorporating regulator and Chemistry Lead feedback)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Regulatory Compliance Assessment completed (Month 2 = 2026-12-14)
- Chemistry Leads and pilot-line manager available for feasibility review

### 16. Chief EHS Officer, Finance Manager and Director jointly establish the internal EHS Compliance Office, including designation of Laboratory Safety Coordinator (embedded with chemistry teams), incident-response protocol and internal-audit schedule. EHS Compliance Office ToR specifies: quarterly internal EHS audits, quarterly regulator-engagement meetings, incident-log maintenance and corrective-action tracking, and escalation to Steering Committee for serious incidents (injuries, chemical release, EHS violations).

**Responsible Body/Role:** Chief EHS Officer

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- EHS Compliance Office ToR v1.0 (audit schedule, regulator meetings, incident reporting, escalation paths)
- Laboratory Safety Coordinator Job Description and Reporting Structure
- Incident-Response Protocol (roles, communication chain, remediation steps, regulator notification)

**Dependencies:**

- Chief EHS Officer hired and SOP library drafted (Months 1-3 = 2026-11-14 to 2027-01-14)
- Site location secured or lease signed (Month 1-3 = 2026-11-14 to 2027-01-14)

### 17. Director and Finance Manager jointly establish the Finance and Funding Governance (integrated within Scientific Steering Committee), designating a Finance Manager and Programme Controller to manage tranche release, spend tracking, variance reporting and contingency activation. Finance governance charter specifies: (i) tranche-release conditions (T2 at Month 12 = 2027-10-14 conditional on Phase 1 permit, operational pilot line, live cell-level model; T3 at Month 24 = 2028-10-14 conditional on Month 18 = 2028-04-14 gate pass; T4 at Month 36 = 2029-10-14 conditional on chemistry-selection gate); (ii) approval authority (Director: <USD 500K, Committee: USD 500K-2M, Funder: >USD 2M); (iii) reserve and pivot-runway management; (iv) partner cost-sharing tracking (≥15% target).

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14)

**Key Outputs/Deliverables:**

- Finance and Funding Governance Charter v1.0 (tranche conditions, approval authority, variance thresholds)
- Financial-Tracking Dashboard Specification (spend by cost center, tranche balance, variance flagging, reporting frequency)
- Tranche-Release Decision Criteria Checklist (documents to verify for each T2-T4 release)

**Dependencies:**

- Budget allocation model complete (Month 2 = 2026-12-14)
- Scientific Steering Committee ToR and decision authority defined (Month 1 = 2026-11-14)

### 18. Programme Director, Chemistry Leads and Finance Manager jointly develop the Chemistry-Tournament and Contingency-Planning Strategy, including: (i) detailed roles and budgets for each of the three active chemistry pathways; (ii) pre-stage contingency plan for the reserve chemistry (precursor supplier qualification, pilot-line equipment reconfiguration, staff cross-training); (iii) pivot-runway reserve allocation (USD 15M ring-fenced until Month 36 = 2029-10-14 gate); (iv) decision rules for rebalancing chemistry-team budgets post-Month 12 (2027-10-14) if one pathway is outperforming. Strategy is documented and reviewed by the Scientific Steering Committee.

**Responsible Body/Role:** Programme Director in collaboration with Chemistry Leads

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Chemistry-Tournament and Contingency Strategy v1.0 (active chemistry roles, reserve chemistry pre-stage plan, pivot mechanics, budget-rebalancing rules)
- Reserve Chemistry Pre-Stage Checklist (by Month 24 = 2028-10-14: suppliers qualified, equipment specs documented, staff trained on reserve pathway)
- Pivot-Runway Reserve Allocation Decision (USD 15M held unallocated, release thresholds)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)
- Scientific Steering Committee first meeting held (Month 1 = 2026-11-14)

### 19. Director and Chief EHS Officer jointly initiate the site-selection and lease-execution process for an Austin R&D location (proposed: Southeast Austin, SH-71/Burleson Road area). Target lease execution is Month 1 (2026-11-14); occupancy targeted Month 3 (2027-01-14). Site must accommodate 5,000-10,000 m² (estimate) for dry-room, pouch-cell line, synthesis labs, abuse-test chambers and characterization labs. Lease includes provisions for hazardous-materials permitting (reflective of regulator engagement outcomes from Month 0-1 = 2026-10-14 to 2026-11-14), utilities (power, ventilation, water), waste handling and emergency access.

**Responsible Body/Role:** Programme Director supported by Chief EHS Officer and Finance Manager

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), lease execution target Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Site Selection and Assessment Report (location options, fit-out requirements, lease terms, hazmat-permitting feasibility)
- Executed Site Lease Agreement (3-5 year term, occupancy by Month 3 = 2027-01-14)
- Fit-Out and Commissioning Plan (dry-room build timeline, equipment installation sequence, operational readiness by Month 3 = 2027-01-14)

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Regulator engagement meeting completed (Month 0-1 = 2026-10-14 to 2026-11-14), confirming permitting feasibility
- Budget allocation model finalized (Month 2 = 2026-12-14), confirming facility lease budget

### 20. Finance Manager and Director jointly develop a Monthly Financial-Tracking Dashboard and establish the monthly spend-review process. Dashboard tracks: cumulative spend by cost center (payroll, capital, facility, precursor, testing, EHS, computing, etc.), remaining balance in current tranche, variance from plan (<±15% normal, flag if ±15-20%, escalate if >±20%), and carry-forward to next tranche. Dashboard is populated by Month 3 (2027-01-14) and reviewed monthly at the Director-Finance Manager meeting; variance findings are escalated to Scientific Steering Committee quarterly.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), operational by end of month

**Key Outputs/Deliverables:**

- Monthly Financial-Tracking Dashboard v1.0 (Excel template or equivalent, populated with Month 0-1 = 2026-10-14 to 2026-11-14 actuals)
- Financial-Review Process Documentation (monthly review meeting schedule, variance escalation thresholds, correction procedures)
- T1 (USD 60M, Months 0-12 = 2026-10-14 to 2027-10-14) Spend Projection and Burn-Rate Profile

**Dependencies:**

- Finance Manager hired (Month 2 = 2026-12-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)
- Cost-center structure and P&L accounting codes established

### 21. Programme Director and Finance Manager jointly solicit, evaluate and negotiate 3-5 year formal standing agreements with at least two university or national-laboratory partners for characterization and candidate-validation services. Agreements specify: (i) guaranteed access to operando and post-mortem instruments (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy); (ii) turnaround target ≤3 weeks (proposed); (iii) annual cost-sharing commitment (≥15% of shared materials and characterization costs borne by partners, proposed); (iv) priority scheduling for failed-cell analysis; (v) 30-60 day exit clauses if access is lost. Agreements are signed by Month 3 (2027-01-14).

**Responsible Body/Role:** Programme Director in collaboration with Finance Manager and Chemistry Leads

**Suggested Timeframe:** Month 1-3 (2026-11-14 to 2027-01-14), target signing by Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Partner Evaluation and Selection Report (institution capabilities, instrument access, cost-sharing capacity)
- Executed Partner Agreements (≥2 institutions, 3-5 year terms, turnaround and cost-sharing specifics)
- Partner Backup and Escalation Plan (if primary partner access is lost or delayed >3 weeks, secondary partner engaged within 1 week)

**Dependencies:**

- Director and Chemistry Leads available to specify instrument and characterization needs
- Finance Manager available to negotiate cost-sharing terms

### 22. Chemistry Leads and Director jointly establish the cell-level mass-and-volume model, defining: (i) material composition inputs per chemistry pathway (anode, cathode, electrolyte, separator, current collectors, packaging); (ii) inactive-mass components (current collectors, separators, packaging, cell connectors); (iii) Wh/kg and Wh/L calculation methodology; (iv) model assumptions documented and validated against published benchmark cells; (v) quarterly update schedule. Model is live by Month 4 (2027-02-14) and projections for all candidates are generated by Month 6 (2027-04-14).

**Responsible Body/Role:** Chemistry Leads and Data Engineer (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 3-4 (2027-01-14 to 2027-02-14), model live by Month 4 (2027-02-14)

**Key Outputs/Deliverables:**

- Cell-Level Mass-and-Volume Model v1.0 (Excel or equivalent, documented assumptions, benchmark validations)
- Model User Guide (inputs, outputs, interpretation guidance, quarterly-update process)
- Initial Chemistry-Candidate Projections (for each active and reserve pathway, projected cell-level Wh/kg and Wh/L)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14) and material-composition specifications available
- Data Engineer hired (Month 1-2 = 2026-11-14 to 2026-12-14)
- Benchmark published-cell data gathered for model validation

### 23. Director and Chief EHS Officer jointly submit Phase 1 permit application (dry-room and low-hazard assembly) to Austin Fire Authority and TCEQ. Application references regulator engagement from Month 0-1 (2026-10-14 to 2026-11-14) and incorporates feedback. Target permit approval is Month 3 (2027-01-14) to enable operational start by Month 3 (2027-01-14).

**Responsible Body/Role:** Chief EHS Officer with support from Finance Manager and site-lease provider

**Suggested Timeframe:** Month 2 (2026-12-14), submit application by early in month

**Key Outputs/Deliverables:**

- Phase 1 Permit Application Package (fire authority and TCEQ, dry-room and assembly scope)
- Regulator Feedback Log and Response Memos (addressing agency questions or conditions)
- Phase 1 Permit Approval (target Month 3 = 2027-01-14)

**Dependencies:**

- Site lease executed (Month 1 = 2026-11-14)
- Regulatory Compliance Assessment and SOP drafts completed (Month 2 = 2026-12-14)
- Regulator engagement meetings held (Month 0-1 = 2026-10-14 to 2026-11-14)

### 24. Finance Manager and Director jointly initiate procurement of major long-lead equipment and materials with foreign-currency exposure (estimated delivery Months 2-6 = 2026-12-14 to 2027-04-14): modular dry-room unit, pouch-cell fabrication equipment, characterization instruments (in-house post-mortem instrument), computing infrastructure, and specialized precursor suppliers. For equipment with EUR or other foreign-currency pricing, negotiate fixed-USD contracts or forward-exchange agreements by Month 6 (2027-04-14). Procurement requisitions are issued with delivery schedules keyed to site occupancy (Month 3 = 2027-01-14).

**Responsible Body/Role:** Finance Manager in collaboration with Director, Chemistry Leads and Chief EHS Officer

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14), RFQ/RFP release; Month 2-6 (2026-12-14 to 2027-04-14) contract negotiation and order placement

**Key Outputs/Deliverables:**

- Major Procurement Plan (equipment and precursor vendors, estimated delivery dates, FX exposure, contract terms)
- Executed Equipment Contracts (modular dry room, pouch-cell line, characterization instruments, computing)
- FX-Hedging Confirmations (forward-exchange contracts or USD fixed-price agreements for capital equipment)

**Dependencies:**

- Budget allocation model finalized (Month 2 = 2026-12-14)
- Chemistry Leads available to specify equipment capabilities
- Site lease executed (Month 1 = 2026-11-14), enabling delivery scheduling

### 25. Director and Finance Manager jointly finalize partner cost-sharing agreements with the ≥2 selected partner institutions. Agreements specify: (i) shared-cost categories (characterization services, materials, validation testing); (ii) partner financial or in-kind contribution targets (≥15% of shared costs, proposed); (iii) invoicing and reconciliation process; (iv) quarterly financial reconciliation meetings; (v) integration into programme financial tracking.

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Partner Cost-Sharing Agreement v1.0 (signed by both institutions and programme, contribution amounts and schedule)
- Shared-Cost Tracking Spreadsheet (partner contributions YTD, invoicing schedule, reconciliation dates)
- Financial Reconciliation Meeting Schedule (quarterly meetings with partners and Finance Manager)

**Dependencies:**

- Partner Agreements for characterization access signed (Month 3 = 2027-01-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)

### 26. Chief EHS Officer and Director jointly schedule the first EHS Compliance Office operational meeting. Agenda includes: (i) SOP review and rollout to chemistry teams; (ii) Phase 1 permit conditions and compliance requirements; (iii) incident-response protocol walkthrough; (iv) staff training and qualification schedule; (v) quarterly internal-audit plan. Meeting includes the Laboratory Safety Coordinator (embedded with chemistry teams), external EHS consultant and regulator liaison.

**Responsible Body/Role:** Chief EHS Officer

**Suggested Timeframe:** Month 3 (2027-01-14), concurrent with Phase 1 permit approval

**Key Outputs/Deliverables:**

- EHS Compliance Office Meeting Minutes (attendance, SOP rollout assignments, training schedule)
- Staff EHS Training Schedule (initial certifications, quarterly refresher plan)
- Phase 1 Compliance Checklist (permit conditions, required certifications, safety equipment verification)

**Dependencies:**

- Phase 1 permit approved (Month 3 = 2027-01-14)
- SOP library finalized (Month 2-3 = 2026-12-14 to 2027-01-14)
- Chief EHS Officer and Laboratory Safety Coordinator hired (Month 1 = 2026-11-14)

### 27. Director and Chemistry Leads jointly conduct the first Chemistry and Discovery Leadership Team meeting. Agenda includes: (i) confirmation of team structure and budgets; (ii) gate-criteria and success-metrics review; (iii) cell-level mass-and-volume model introduction and first-candidate projections; (iv) synthesis and pilot-line startup plan (weeks 1-4 of month); (v) characterization partner onboarding and schedule; (vi) risk-register review and chemistry-specific mitigation plans. Meeting establishes the weekly synthesis/characterization sync, monthly all-hands reviews and monthly Steering Committee liaison reporting.

**Responsible Body/Role:** Programme Director, now delegating to Chemistry Leads (Chemistry and Discovery Leadership Team formally constituted)

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Chemistry and Discovery Leadership Team Meeting Minutes (team structure confirmation, budget allocation, schedule confirmation)
- Monthly Chemistry Progress-Reporting Template (cell builds, Wh/kg/Wh/L measurements, cycle-life data, safety results, forensics findings)
- 12-Week Chemistry Startup and Ramp Plan (synthesis targets, cell builds/month, characterization queue schedule)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Cell-level mass-and-volume model live (Month 4 = 2027-02-14, but initial projections available for Month 3 = 2027-01-14 meeting)
- Site occupancy begins (Month 3 = 2027-01-14)
- Phase 1 permit approved (Month 3 = 2027-01-14)

### 28. Director and independent red team jointly conduct the first red-team operational meeting. Agenda includes: (i) red-team charter and independence agreement review; (ii) replication protocol and acceptance criteria (cell-build procedure, cycling protocol, measurement tolerance ±10% on Wh/kg, ±5% on Wh/L, proposed); (iii) monthly data-review process (timeline: receive Chemistry Leadership monthly reports within 5 days, issue flag memo within 10 days if discrepancies detected); (iv) gate-verification timeline (identify ≥1 cell per team for replication ~4 weeks before gate meeting, issue results ≥5 days before Committee meeting); (v) cell-level mass-and-volume model audit plan (monthly reviews of model assumptions and benchmark validations).

**Responsible Body/Role:** Programme Director in consultation with appointed red team

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Red Team Operational Meeting Minutes (protocol review, monthly process timeline, gate-verification plan)
- Red Team Data-Review and Replication Schedule (monthly reporting deadline, gate-verification sprints for Months 17, 29, 35 = 2028-03-14, 2029-03-14, 2029-09-14)
- Cell Replication Protocol v1.0 (cell-build procedure, cycling protocol, measurement tolerances, pass/fail criteria)

**Dependencies:**

- Red team appointed (Month 1 = 2026-11-14)
- Gate-criteria specification finalized (Month 3 = 2027-01-14)
- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)

### 29. Chief EHS Officer and external consultant jointly conduct a regulatory-monitoring and compliance-update briefing for the Scientific Steering Committee and Chemistry Leadership. Briefing covers: (i) federal, state and local rule changes anticipated in Months 1-12 (2026-11-14 to 2027-10-14) and beyond; (ii) any early-stage permit conditions or regulator feedback requiring programme adaptations; (iii) insurance and liability considerations; (iv) quarterly compliance-review schedule and regulator-engagement calendar.

**Responsible Body/Role:** Chief EHS Officer supported by external EHS consultant

**Suggested Timeframe:** Month 3 (2027-01-14), at or just before first full Steering Committee meeting

**Key Outputs/Deliverables:**

- Regulatory Monitoring and Compliance Update Briefing Slides (rule changes, regulator feedback, adaptations required)
- Quarterly Regulator-Engagement Calendar (standing meetings with fire authority, TCEQ, EPA liaison)
- Insurance and Liability Assessment (current coverage, gaps, quotes for expanded hazard coverage)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- External EHS consultant retained (Month 1 = 2026-11-14)
- Regulator engagement meetings completed (Month 0-1 = 2026-10-14 to 2026-11-14)

### 30. Director and Finance Manager jointly initialize the monthly financial-tracking dashboard with actual spend from Months 0-2 (2026-10-14 to 2026-12-14). Dashboard populates cost centers (payroll, capital equipment procurement, site lease, precursor supply, partner agreements, EHS, computing) and tracks remaining balance in T1 (USD 60M). First variance analysis is conducted; if any category exceeds ±15% of plan by Month 3 (2027-01-14) end, corrective action is proposed by Director to Steering Committee.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), end of month

**Key Outputs/Deliverables:**

- Monthly Financial-Tracking Dashboard v2.0 (populated with Month 0-2 = 2026-10-14 to 2026-12-14 actuals, variance analysis, tranche balance)
- T1 Spend-to-Date Report (cumulative spend Months 0-2 = 2026-10-14 to 2026-12-14, category breakdown, variance flagging)
- Projected Burn-Rate Profile (Months 3-12 = 2027-01-14 to 2027-10-14, annualized rate, tranche-depletion timeline)

**Dependencies:**

- Financial-tracking dashboard established (Month 3 = 2027-01-14)
- Chemistry startup expenses being incurred (site lease, equipment procurement, staff onboarding)

### 31. Director and Chemistry Leads jointly commission the modular, leased dry-room and pouch-cell fabrication line at the Austin site. Commissioning activities include: (i) installation and equipment setup (Weeks 1-2); (ii) trial builds and process-parameter tuning (Weeks 3-4); (iii) yield optimization (Weeks 5-8); (iv) staff training on fabrication, cell-testing and data-logging (Weeks 1-8). Target is 50-100 pouch cells per month operational by Month 6 (2027-04-14), ramping to 100-150/month by Month 9 (2027-07-14) and sustained 100-150/month through Month 12 (2027-10-14).

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 3-6 (2027-01-14 to 2027-04-14), operational by Month 6 (2027-04-14)

**Key Outputs/Deliverables:**

- Pilot-Line Commissioning Plan (installation schedule, trial-build protocol, yield-optimization targets)
- Pilot-Line Monthly Performance Report (cells built, yield %, Wh/kg and Wh/L measurements, process-parameter consistency)
- Staff Training Certificates (dry-room operation, cell assembly, safety protocols)

**Dependencies:**

- Site lease executed and occupancy begins (Month 3 = 2027-01-14)
- Modular dry-room and pouch-cell equipment delivered (Month 3-4 = 2027-01-14 to 2027-02-14)
- Phase 1 permit approved (Month 3 = 2027-01-14)
- Pilot-Line Manager and synthesis team hired (Month 1-2 = 2026-11-14 to 2026-12-14)

### 32. Chemistry Leads and Data Engineer jointly activate the cell-level mass-and-volume model, generating projections for all three active chemistry pathways (and reserve if planned). Projections include: material composition, inactive-mass breakdown, projected Wh/kg and Wh/L per chemistry at cell level. Projections are reviewed against gate criteria (≥500 Wh/kg, ≥950 Wh/L interim) by Month 6 (2027-04-14). Any chemistry projected to fall below 950 Wh/L is flagged for focused redesign by Month 18 (2028-04-14).

**Responsible Body/Role:** Chemistry Leads and Data Engineer

**Suggested Timeframe:** Month 4-6 (2027-02-14 to 2027-04-14)

**Key Outputs/Deliverables:**

- Chemistry-Candidate Projection Report (three active + reserve, projected Wh/kg and Wh/L per chemistry)
- Model-to-Reality Variance Analysis (comparison of projected vs benchmark measured Wh/kg/L, model confidence assessment)
- Volumetric-Density Focus List (candidates projected <950 Wh/L, redesign actions and schedule)

**Dependencies:**

- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)
- Chemistry compositions and material specifications finalized for each pathway

### 33. Director and partner institutions jointly conduct the first formal quarterly financial reconciliation and milestone-verification meeting. Agenda includes: (i) review of partner in-kind contributions (instrument access, staff time, materials) and financial contributions against the ≥15% target (proposed); (ii) characterization work completed (samples analyzed, turnaround times); (iii) any cost overruns or underspends in shared categories; (iv) next quarter's planned joint work and cost-sharing.

**Responsible Body/Role:** Programme Director and Finance Manager, with partner institution representatives

**Suggested Timeframe:** Month 6 (2027-04-14) (quarterly, marking end of Q1 of partnership operations)

**Key Outputs/Deliverables:**

- Partner Quarterly Reconciliation Meeting Minutes (contributions verified, cost-sharing reconciliation, upcoming milestones)
- Shared-Cost Reconciliation Report (partner contributions YTD vs ≥15% target, any invoicing discrepancies)
- Partner Delivery Scorecard (instrument access, turnaround times, sample throughput)

**Dependencies:**

- Partner agreements signed (Month 3 = 2027-01-14)
- Partner cost-sharing agreements finalized (Month 3 = 2027-01-14)
- Characterization services operational (by Month 6 = 2027-04-14)

### 34. Director and Chemistry Leads jointly initiate synthesis and characterization work across all three active chemistry pathways, meeting target cell-build rates of 50-100 cells/month by Month 6 (2027-04-14). Activities include: (i) material precursor sourcing and supply-chain coordination (dual-sourcing confirmed by Month 6 = 2027-04-14); (ii) synthesis lab operations (daily bench work, process documentation); (iii) cell assembly and cycling (pouch cells tested at defined discharge rates and temperatures); (iv) characterization scheduling with partner institutions (operando and post-mortem analysis); (v) forensics protocol implementation (failed cells autopsy'd within one week, root causes assigned).

**Responsible Body/Role:** Chemistry Leads and Chemistry and Discovery Leadership Team

**Suggested Timeframe:** Months 3-6 (2027-01-14 to 2027-04-14), sustained through Month 12 (2027-10-14) and beyond

**Key Outputs/Deliverables:**

- Monthly Chemistry Progress Report (cell builds by chemistry, Wh/kg/Wh/L measurements vs model, cycle-life performance, safety results, forensics findings)
- Precursor Supply-Chain Status Report (suppliers qualified, dual-sourcing confirmed, 3-6 month buffer inventory established)
- Forensics Atlas v1.0 (failure modes documented, root-cause assignments, design-change implications for each failure type)

**Dependencies:**

- Pilot-line commissioned (Month 6 = 2027-04-14)
- Chemistry team fully staffed (Month 1-3 = 2026-11-14 to 2027-01-14)
- Partner characterization access activated (Month 6 = 2027-04-14)
- Forensics autopsy protocol finalized (Month 3 = 2027-01-14)

### 35. Chief EHS Officer and external consultant jointly submit Phase 2 permit application (reactive-metal and solvent synthesis) to fire authority and TCEQ. Application incorporates Phase 1 permitting experience and includes expanded scope for lithium-metal handling, solvent recovery, and reactive-precursor synthesis. Target approval is Month 6 (2027-04-14); if permitting slips beyond Month 6 (2027-04-14), pre-negotiate with external synthesis facilities for cost-plus outsourcing of any on-site-prohibited steps.

**Responsible Body/Role:** Chief EHS Officer with support from Finance Manager

**Suggested Timeframe:** Month 4 (2027-02-14), submit application; Month 6 (2027-04-14) approval target

**Key Outputs/Deliverables:**

- Phase 2 Permit Application Package (reactive-metal and solvent synthesis scope, expanded SOP library)
- Regulator Feedback Memo and Response (any agency conditions or phasing requirements)
- Phase 2 Permit Approval (target Month 6 = 2027-04-14); contingency external synthesis agreements if delay occurs

**Dependencies:**

- Phase 1 permit approved (Month 3 = 2027-01-14)
- Chemistry pathways finalized (synthetic routes, precursor materials confirmed)
- Regulator relationship established (Month 0-1 = 2026-10-14 to 2026-11-14)

### 36. Director and Data Engineer jointly activate the computing infrastructure for materials screening and machine-learning candidate ranking. If using national-laboratory HPC access (NREL, Lawrence Berkeley Lab), formalize the partnership agreement and schedule initial access. If using cloud computing (AWS, Google Cloud), set up accounts and cost tracking. Integrate the data pipeline (cell-cycling measurements, post-mortem characterization results, computed properties) by Month 9 (2027-07-14). Candidate-ranking model is trained on Month 6-12 (2027-04-14 to 2027-10-14) data and validated against experimental results; only models with ≥80% predictive accuracy are used for hypothesis ranking by Month 12 (2027-10-14).

**Responsible Body/Role:** Programme Director and Data Engineer

**Suggested Timeframe:** Month 3-9 (2027-01-14 to 2027-07-14)

**Key Outputs/Deliverables:**

- Computing Infrastructure Agreement (HPC partnership or cloud-computing contract, cost and access terms)
- Data-Pipeline Specification (cell-cycling data, characterization results, computed-property definitions, database schema)
- Candidate-Ranking Model v1.0 (trained on Month 6-12 = 2027-04-14 to 2027-10-14 data, validation accuracy ≥80%, ready for hypothesis ranking by Month 12 = 2027-10-14)

**Dependencies:**

- Data Engineer hired (Month 1-2 = 2026-11-14 to 2026-12-14)
- Cell-cycling and characterization data available from Month 6 (2027-04-14) onward
- National-laboratory or cloud-computing partner identified (Month 1-3 = 2026-11-14 to 2027-01-14)

### 37. Director and red team jointly conduct the first monthly data-review cycle. Chemistry Leadership submits monthly progress reports (cell builds, Wh/kg/Wh/L measurements, cycle-life data, safety results, forensics). Red team reviews within 5 days and issues a flag memo (within 10 days) if discrepancies are detected (e.g., claimed Wh/kg contradicts prior month, or measured Wh/L falls significantly below model projection). Red team flags are reviewed by Chemistry Leads; Chemistry Leads provide clarification or correction within 3 days. Process is formalized and repeated monthly through Month 72 (2032-10-14).

**Responsible Body/Role:** Independent Red Team with Chemistry and Discovery Leadership Team

**Suggested Timeframe:** Month 6 (2027-04-14), and monthly thereafter

**Key Outputs/Deliverables:**

- Monthly Data-Review Flag Memo (any claimed inconsistencies, measurement discrepancies, model mismatches)
- Chemistry Lead Response Memo (clarification or correction to flagged discrepancies within 3 days)
- Monthly Data-Review Summary (flagged and resolved issues, trends noted, confidence in data quality)

**Dependencies:**

- Red team operational (Month 2-3 = 2026-12-14 to 2027-01-14)
- Chemistry work producing data (Month 6 = 2027-04-14 onward)
- Monthly Chemistry Progress Report template established

### 38. Chief EHS Officer and external consultant jointly conduct the first quarterly internal EHS audit. Audit scope includes: (i) lab and dry-room inspection for compliance with Phase 1 permit conditions and SOPs; (ii) chemical inventory accuracy check (actual quantities vs permits); (iii) waste-handling procedures and contractor compliance; (iv) emergency-response equipment (spill kits, fire suppression, evacuation signage) readiness; (v) incident log review (goal: zero). Audit report is issued with findings, corrective actions and completion deadlines. Quarterly audits are repeated at Months 9, 12, 15, 18 (2027-07-14, 2027-10-14, 2028-01-14, 2028-04-14), etc. (proposed schedule: quarterly).

**Responsible Body/Role:** Chief EHS Officer with support from external EHS consultant and Laboratory Safety Coordinator

**Suggested Timeframe:** Month 6 (2027-04-14) (first of quarterly audits)

**Key Outputs/Deliverables:**

- Quarterly Internal EHS Audit Report (findings, compliance observations, corrective actions required)
- Corrective Action Tracking Log (action items, owner, completion deadline, follow-up)
- Audit Presentation to Steering Committee (summary findings, any urgent risks, compliance status)

**Dependencies:**

- Phase 1 permit approved and operations ongoing (Month 3 = 2027-01-14)
- SOP library in use and staff trained (Month 3-6 = 2027-01-14 to 2027-04-14)
- Chief EHS Officer and Laboratory Safety Coordinator operational (Month 1 = 2026-11-14)

### 39. Director jointly with the external technical advisor and Chemistry Leads establish the in-house post-mortem characterization capability (e.g., scanning electron microscope or X-ray diffraction) for rapid triage of failed cells. Equipment procurement, installation and staff training are completed by Month 6 (2027-04-14). Capability is operational by Month 8 (2027-06-14), enabling rapid turnaround (within 2-3 days) for failed-cell autopsy, complementing partner operando analysis which may have longer queues.

**Responsible Body/Role:** Chemistry Leads and Characterization Manager (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 4-8 (2027-02-14 to 2027-06-14), operational by Month 8 (2027-06-14)

**Key Outputs/Deliverables:**

- In-House Post-Mortem Instrument Procurement and Installation Plan (equipment specs, vendor, delivery, installation)
- Staff Training and Qualification Plan (operator certifications, maintenance, data-quality procedures)
- Post-Mortem Characterization SOP (triage protocol, sample prep, analysis procedure, result documentation)

**Dependencies:**

- Site occupancy and laboratory space available (Month 3 = 2027-01-14)
- Capital equipment budget allocated (Month 2-3 = 2026-12-14 to 2027-01-14)
- Characterization Manager hired (Month 1-2 = 2026-11-14 to 2026-12-14)

### 40. Director and Chemistry Leads jointly commission Phase 1 pouch-cell verification with partner institutions. First independent third-party measurements of cell-level energy density (Wh/kg, Wh/L) and cycle life are conducted on early-stage candidate cells (not yet optimized, but representative of each chemistry pathway). Independent verification is completed by Month 12 (2027-10-14) to confirm measurement methodology and build confidence in data quality before the Month 18 (2028-04-14) gate review. Results are compared to in-house measurements; discrepancies trigger methodology review and calibration.

**Responsible Body/Role:** Chemistry Leads with partner institution characterization teams

**Suggested Timeframe:** Month 9-12 (2027-07-14 to 2027-10-14)

**Key Outputs/Deliverables:**

- Phase 1 Independent Verification Report (third-party measured Wh/kg, Wh/L, cycle-life data for 3-5 representative early-stage cells)
- Methodology Comparison Memo (in-house vs independent measurement results, confidence in measurement procedures)
- Calibration and Adjustment Actions (if systematic discrepancies found, corrective steps to align future measurements)

**Dependencies:**

- Partner characterization agreements operational (Month 6 = 2027-04-14)
- Early-stage candidate cells available for testing (Month 9-10 = 2027-07-14 to 2027-08-14)
- In-house pouch-cell fabrication and cycling capability established (Month 6 = 2027-04-14)

### 41. Director and Finance Manager jointly conduct quarterly financial review at end of Month 6 (2027-04-14), tracking T1 spend (Months 0-6 = 2026-10-14 to 2027-04-14 actual vs plan). Dashboard is updated with cumulative spend by cost center, variance analysis and burn-rate profile. If spend is on track or under plan, no action required; if variance exceeds ±15% in any category, corrective action is proposed. Monthly T1 spend is now ~USD 10M/month (budget = USD 60M/12 months); actual spend trend is reviewed for Months 3-6 (2027-01-14 to 2027-04-14) to forecast T2 release readiness.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-14), end of month

**Key Outputs/Deliverables:**

- T1 Midpoint Financial Review (cumulative spend Months 0-6 = 2026-10-14 to 2027-04-14, category breakdown, variance analysis)
- T2 Release Readiness Assessment (Phase 1 permit approval, operational pilot line, live cell-level model status, spend forecast)
- Corrective Action Plan (if variance >±15%), signed by Director

**Dependencies:**

- Monthly financial tracking operational (Month 3 = 2027-01-14)
- T1 expense categories being incurred (staffing, capital, lease, precursor, partner agreements)

### 42. Director and Chemistry Leads jointly submit Phase 2 permit application (if not yet submitted) or follow up on pending approvals. If Phase 2 permitting slips beyond Month 6 (2027-04-14), initiate pre-negotiated external synthesis agreements with licensed contract research organizations (est. cost USD 2-5M/yr if on-site synthesis is prohibited). External synthesis turnaround is estimated 4-6 weeks; if synthesis becomes a bottleneck, this risk is escalated to Steering Committee.

**Responsible Body/Role:** Chief EHS Officer and Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-14), concurrent with Phase 2 permit decision or continuation

**Key Outputs/Deliverables:**

- Phase 2 Permit Status Report (approval received or expected date, any regulator conditions requiring adaptation)
- External Synthesis Contingency Agreement (if Phase 2 slips, pre-negotiated contract with CRO for synthesis steps)
- Synthesis Risk Escalation Memo (if Phase 2 approval unlikely by Month 6 = 2027-04-14, document impact and mitigation)

**Dependencies:**

- Phase 2 permit application submitted (Month 4 = 2027-02-14)
- External synthesis vendors pre-identified (Month 3-4 = 2027-01-14 to 2027-02-14)

### 43. Director and Finance Manager jointly prepare the T2 release decision package for Scientific Steering Committee approval. Package includes: (i) evidence that T1 milestones are met (Phase 1 permit approved, operational pilot line producing 50-100 cells/month, cell-level mass-and-volume model live); (ii) Phase 1 monthly spend vs plan (variance <±15%); (iii) chemistry progress summary (all three active pathways producing data, cells cycling, forensics data accumulating); (iv) gate-criteria confirmation (metrics defined, baseline measurements established); (v) T2 spend forecast (Months 12-24 = 2027-10-14 to 2028-10-14, ~USD 80M). T2 release condition is Month 12 (2027-10-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 10 (2027-08-14), to enable Steering Committee decision by Month 12 (2027-10-14)

**Key Outputs/Deliverables:**

- T2 Release Decision Package (milestone evidence, financial summary, chemistry progress, gate-readiness confirmation)
- T2 Spend Forecast (Months 12-24 = 2027-10-14 to 2028-10-14 budget projection, cost-center breakdown)
- Steering Committee Release Authorization (signed by majority of Committee + Funder)

**Dependencies:**

- T1 spend tracked and reported (through Month 10 = 2027-08-14)
- Phase 1 permit and all T1 milestones achieved by Month 10-12 (2027-08-14 to 2027-10-14)
- Chemistry progress data available for summary

### 44. Director and red team jointly prepare the red-team verification plan for the Month 18 (2028-04-14) gate review. Plan includes: (i) selection of ≥1 cell per chemistry team for independent replication (weeks 1-2 of Month 17 = 2028-03-14); (ii) red-team cell builds and cycling (weeks 2-4 of Month 17 = 2028-03-14); (iii) measurement of Wh/kg, Wh/L and cycle-life retention to ±10% tolerance (proposed); (iv) write-up of replication results and gate-readiness memo (week 1 of Month 18 = 2028-04-14). Red team is resourced and scheduled to deliver results ≥5 days before Steering Committee gate meeting (target: Week 2 of Month 18 = 2028-04-14 meeting).

**Responsible Body/Role:** Independent Red Team

**Suggested Timeframe:** Month 16-17 (2028-02-14 to 2028-03-14), planning; Month 17 (2028-03-14), replication sprint

**Key Outputs/Deliverables:**

- Red Team Gate Verification Plan for Month 18 (2028-04-14) (cell selection criteria, replication timeline, measurement protocols)
- Red Team Replication Results Memo (pass/no-pass on ≥1 cell per chemistry, Wh/kg/Wh/L measurements, cycle-life confirmation)
- Gate-Readiness Assessment Memo (red team recommendation on which chemistries pass Month 18 = 2028-04-14 gate criteria)

**Dependencies:**

- Red team operational (Month 2-3 = 2026-12-14 to 2027-01-14)
- Replication protocol finalized (Month 3 = 2027-01-14)
- Month 18 (2028-04-14) gate-criteria specification locked (Month 3 = 2027-01-14)

### 45. Director, Chemistry Leads and red team jointly conduct the Month 18 (2028-04-14) gate review. Steering Committee meeting includes: (i) presentation of chemistry progress data (cell builds, Wh/kg/Wh/L measurements, cycle-life results, safety scores) vs Month 18 (2028-04-14) gate criteria (≥500 Wh/kg projected, ≥950 Wh/L interim, cycle-life data, ≥120°C thermal runaway onset for finalists); (ii) red-team replication results and any challenges to progress claims; (iii) go/no-go decision per chemistry (continue, deprioritize, or stop); (iv) rebalancing of chemistry-team budgets post-Month 18 (2028-04-14) based on progress. Gate decision is rendered within 3 weeks of meeting start (by end of Month 18 = 2028-04-14). If a chemistry fails, contingency measures (reserve chemistry pre-staging, external synthesis activation) are triggered.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with red team input

**Suggested Timeframe:** Month 18 (2028-04-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 18 (2028-04-14) Gate Review Meeting Minutes (attendance, data presentations, red-team findings, go/no-go decisions per chemistry)
- Chemistry Advancement Decision Memo (which chemistries advance to Month 24-30 = 2028-10-14 to 2029-04-14 phase, which are deprioritized or stopped)
- Post-Gate Financial Rebalancing Decision (budget reallocation among teams based on Month 18 = 2028-04-14 outcomes)
- Risk Escalation (if any chemistry has failed or is at risk, document mitigation actions required)

**Dependencies:**

- Month 18 (2028-04-14) gate-criteria specification locked (Month 3 = 2027-01-14)
- Red-team replication results delivered ≥5 days before gate meeting
- Chemistry progress data compiled and reviewed monthly (Months 6-18 = 2027-04-14 to 2028-04-14)

### 46. Director and Chemistry Leads jointly initiate a focused volumetric-density optimization sprint if early data (by Month 18 = 2028-04-14) suggests a leading chemistry may meet ≥500 Wh/kg but fall short of ≥950 Wh/L interim gate threshold. Sprint activities (Months 18-30 = 2028-04-14 to 2029-04-14) include: (i) thinner separators and reduced electrolyte volume (cell architecture changes); (ii) higher-density cathode or anode materials (materials optimization); (iii) bipolar or anode-free cell format evaluation if compatible with winning chemistry. Sprint goal is to close the volumetric-density gap before the Month 30 (2029-04-14) verification gate. If volumetric density cannot be recovered by Month 30 (2029-04-14), the chemistry may be deprioritized at Month 36 (2029-10-14) gate.

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager, with red team validation

**Suggested Timeframe:** Months 18-30 (2028-04-14 to 2029-04-14) (conditional: only if volumetric gap identified)

**Key Outputs/Deliverables:**

- Volumetric-Density Optimization Sprint Plan (architecture changes, materials alternatives, timeline, resource allocation)
- Monthly Volumetric-Density Progress Report (measured Wh/L vs target, design changes tested, results)
- Volumetric-Density Gate Readiness Report (Month 30 = 2029-04-14: ≥950 Wh/L achieved or not)

**Dependencies:**

- Month 18 (2028-04-14) gate review identifies volumetric-density gap (Month 18 = 2028-04-14)
- Chemistry team has capacity to pursue parallel architecture improvements alongside core pathway work

### 47. Director and Chemistry Leads jointly confirm that the cell-level mass-and-volume model is being updated monthly with actual measured pouch-cell data (Wh/kg, Wh/L, cycle-life, inactive-mass breakdown). Model variance (projected vs measured) is tracked; a Wh/kg or Wh/L mismatch >10% triggers root-cause analysis (e.g., separator thickness thicker than assumed, higher current-collector mass, electrolyte volume overestimate). Mismatch analysis feeds back into model calibration. Cumulative model-to-reality variance report is published by Month 20 (2028-06-14) to confirm model reliability before the Month 30 (2029-04-14) gate.

**Responsible Body/Role:** Data Engineer and Chemistry Leads

**Suggested Timeframe:** Months 6-20 (2027-04-14 to 2028-06-14), ongoing monthly

**Key Outputs/Deliverables:**

- Monthly Cell-Level Model Update (new measured data incorporated, Wh/kg/L projections recalibrated)
- Model-to-Reality Variance Report (projected vs measured, any systematic biases, model adjustment recommendations)
- Mismatch Root-Cause Analysis (if any category exceeds ±10%, identify source and corrective model adjustment)

**Dependencies:**

- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)
- Cell-level Wh/kg and Wh/L measurements available monthly (Month 6 = 2027-04-14 onward)

### 48. Director and Chemistry Leads jointly ensure that synthesis, pilot-line and characterization operations are producing measured cycle-life data (at 80% capacity retention) for all candidates by Month 24 (2028-10-14). Any candidate chemistry showing measured <250 cycles at 80% is flagged as deprioritized unless within one 2-4 month redesign of target (≥300 cycles, proposed). Chemistry team documents redesign actions and provides timeline for recovery. If a chemistry remains <250 cycles by Month 24 (2028-10-14), it is recommended for deprioritization at Month 30 (2029-04-14) gate review.

**Responsible Body/Role:** Chemistry Leads and Characterization Manager

**Suggested Timeframe:** Months 6-24 (2027-04-14 to 2028-10-14), ongoing testing

**Key Outputs/Deliverables:**

- Monthly Cycle-Life Performance Report (measured cycle retention at 80%, trend per chemistry, redesign actions for underperformers)
- Cycle-Life Deprioritization Memo (any chemistry <250 cycles at Month 24 = 2028-10-14, documented, flagged for Month 30 = 2029-04-14 gate review)

**Dependencies:**

- Cell cycling operations producing data (Month 6 = 2027-04-14 onward)
- Cycle-life gate criterion defined as ≥300 cycles at 80% (Month 3 = 2027-01-14)

### 49. Director and Finance Manager jointly develop the T3 release decision package for Scientific Steering Committee approval. T3 (USD 70M) release is conditional on Month 18 (2028-04-14) gate passing (documented go/no-go decision, at least one or two chemistries advancing). Package includes: (i) Month 18 (2028-04-14) gate decision evidence; (ii) T2 spend vs plan (Months 12-24 = 2027-10-14 to 2028-10-14, variance tracking); (iii) updated T3 and T4 spend forecast; (iv) any budget rebalancing needed based on Month 18 (2028-04-14) outcomes. T3 release is approved by Steering Committee and Funder by Month 24 (2028-10-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 22 (2028-08-14), to enable Steering Committee decision by Month 24 (2028-10-14)

**Key Outputs/Deliverables:**

- T3 Release Decision Package (Month 18 = 2028-04-14 gate evidence, T2 spend summary, T3 forecast, Funder authorization)
- T2 Final Spend Report (Months 12-24 = 2027-10-14 to 2028-10-14 cumulative, category breakdown, variance analysis)
- Corrective Action Summary (if T2 spending exceeded plan, documented mitigation actions)

**Dependencies:**

- Month 18 (2028-04-14) gate review completed (Month 18 = 2028-04-14)
- T2 spend tracked and reported through Month 22 (2028-08-14)
- Chemistry progress and risk status available for T3 forecast adjustment

### 50. Director and Chemistry Leads jointly prepare the red-team verification plan for the Month 30 (2029-04-14) third-party verification gate. Plan includes: (i) selection of ≥3 independent replicates per finalist chemistry for third-party measured pouch-cell testing (independent laboratory or university facility with external credibility); (ii) specification of measurement protocol (≥100 mAh nominal capacity, cell-level Wh/kg, Wh/L, cycle-life retention at 80% for ≥300 cycles); (iii) reproducibility criteria (≥3 replicates, 90% of cells within ±10% Wh/kg, ±5% Wh/L, proposed); (iv) measurement certification and data traceability. Third-party testing is contracted or scheduled by Month 26 (2028-12-14) to allow 4-6 week turnaround with results delivered by Month 30 (2029-04-14).

**Responsible Body/Role:** Chemistry Leads and third-party test facility (independent laboratory or university partner)

**Suggested Timeframe:** Month 26-30 (2029-02-14 to 2029-04-14), testing period

**Key Outputs/Deliverables:**

- Third-Party Pouch-Cell Testing Protocol (measurement procedures, capacity, cycle-test conditions, data quality standards)
- Third-Party Laboratory Agreement (facility contracted, measurement scope, confidentiality, data delivery timeline)
- Third-Party Verification Report (measured Wh/kg, Wh/L, cycle-life for ≥3 replicates per finalist, reproducibility summary)

**Dependencies:**

- Month 18 (2028-04-14) gate identifies finalist(s) (Month 18 = 2028-04-14)
- Month 24-26 (2028-10-14 to 2028-12-14) data confirms finalist candidates for third-party verification (Month 24-26 = 2028-10-14 to 2028-12-14)
- Third-party laboratory selected and contracted (Month 12-24 = 2027-10-14 to 2028-10-14)

### 51. Director, Chemistry Leads and red team jointly conduct the Month 30 (2029-04-14) third-party verification gate review. Steering Committee meeting includes: (i) presentation of third-party measured Wh/kg, Wh/L and cycle-life data for finalist chemistry (≥3 replicates); (ii) reproducibility assessment (90% of cells within ±10% tolerance, proposed); (iii) confirmation that finalist meets gate thresholds: ≥500 Wh/kg, ≥950 Wh/L interim, ≥300 cycles at 80%, thermal-runaway onset ≥120°C (proposed); (iv) red-team assessment of data quality and any inconsistencies with prior in-house measurements; (v) go/no-go decision on advancing to Month 36 (2029-10-14) chemistry-selection gate. If third-party data confirms finalist, gate passes and Steering Committee approves release of USD 15M contingency reserve (held through Month 30 = 2029-04-14) for later-stage sprint or pivots if needed. If verification fails, contingency measures (pivot to reserve chemistry or extended redesign) are triggered.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with third-party laboratory and red team input

**Suggested Timeframe:** Month 30 (2029-04-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 30 (2029-04-14) Third-Party Verification Gate Review Meeting Minutes (attendance, third-party data presentation, reproducibility confirmation, go/no-go decision)
- Third-Party Data Acceptance Decision (finalist confirmed or not, reserve activation decision)
- Post-Gate Contingency Reallocation Decision (USD 15M contingency reserve released or held based on gate outcome and remaining risk)

**Dependencies:**

- Third-party verification testing completed (Month 30 = 2029-04-14)
- Third-party laboratory data delivered ≥5 days before gate meeting
- Red-team replication of third-party data or verification of third-party methodology (concurrent with testing)

### 52. Chief EHS Officer and external consultant jointly submit Phase 3 permit application (abuse-test chambers: thermal-runaway, nail-penetration, overcharge testing) to fire authority and TCEQ. Application incorporates Phase 1-2 experience and includes detailed safety protocols for in-house abuse chambers. Target approval is Month 9 (2027-07-14); if permitting slips, abuse testing is outsourced to contracted third-party facility through Month 12-18 (2027-10-14 to 2028-04-14). Phased safety evaluation timeline ensures early thermal-ramp screening (Months 3-6 = 2027-01-14 to 2027-04-14) and contracted abuse tests (Months 6-12 = 2027-04-14 to 2027-10-14) for all candidates, while in-house chambers (if permitted) are operational by Month 18 (2028-04-14) for finalists.

**Responsible Body/Role:** Chief EHS Officer with support from Pilot-Line Manager

**Suggested Timeframe:** Month 6-9 (2027-04-14 to 2027-07-14), submission and approval

**Key Outputs/Deliverables:**

- Phase 3 Permit Application (in-house abuse-chamber scope, safety protocols, regulator engagement)
- Phase 3 Permit Approval or Contingency Plan (approval received or outsourcing agreement executed if permitting slips)
- Phased Safety-Evaluation Schedule (thermal-ramp screening Months 3-6 = 2027-01-14 to 2027-04-14, contracted testing Months 6-12 = 2027-04-14 to 2027-10-14, in-house chambers Months 18+)

**Dependencies:**

- Phase 1-2 permits approved (Months 3, 6 = 2027-01-14, 2027-04-14)
- Chemistry pathways and candidate count finalized
- Third-party abuse-testing vendors pre-identified (Month 3-6 = 2027-01-14 to 2027-04-14)

### 53. Director and Chemistry Leads jointly confirm that all three active chemistry pathways (and reserve if pre-staged) have detailed contingency pivot plans in place by Month 24 (2028-10-14). Contingency plans for each chemistry specify: (i) precursor suppliers (primary and backup vendors, qualification status); (ii) pilot-line equipment requirements (special drying, inert atmosphere, pressure management, etc.); (iii) process-control parameters and sensitivity analysis; (iv) staff training and cross-team familiarity. If a leading chemistry fails between Months 18-30 (2028-04-14 to 2029-04-14), a pivot to reserve chemistry can be executed within 4-6 weeks instead of 6-10 months.

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager

**Suggested Timeframe:** Month 12-24 (2027-10-14 to 2028-10-14), documentation and cross-training

**Key Outputs/Deliverables:**

- Contingency Pivot Plan per Chemistry Pathway (precursor sourcing, equipment specs, process parameters, staff cross-training schedule)
- Supplier Qualification Summary (backup vendors identified and qualified, lead times confirmed, cost estimates)
- Staff Cross-Training Schedule (20-30% of synthesis and pilot-line team trained on each pathway by Month 24 = 2028-10-14)

**Dependencies:**

- Chemistry pathways and compositions finalized (Month 6 = 2027-04-14)
- Precursor supply-chain established (Month 6-9 = 2027-04-14 to 2027-07-14)
- Pilot-line operations stable (Month 9-12 = 2027-07-14 to 2027-10-14)

### 54. Director and Finance Manager jointly track T3 spend (Months 24-36 = 2028-10-14 to 2029-10-14) monthly, comparing actual to plan. T3 budget is USD 70M (~USD 7M/month); if monthly spend exceeds ±15% of plan, corrective action is proposed by Director or Finance Manager within 5 days. End-of-T3 (Month 36 = 2029-10-14) financial review confirms total T3 spend, remaining reserves and T4 (USD 90M) release readiness.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Months 24-36 (2028-10-14 to 2029-10-14), monthly tracking

**Key Outputs/Deliverables:**

- Monthly T3 Spend Report (cumulative spend by cost center, variance analysis, corrective actions if needed)
- T3 Final Financial Review (Month 36 = 2029-10-14: cumulative T3 spend, category breakdown, reserve balance)

**Dependencies:**

- Monthly financial tracking and reporting operational (Month 3 = 2027-01-14 onward)
- Chemistry and operational spend being incurred

### 55. Director and red team jointly prepare the red-team verification plan for the Month 36 (2029-10-14) chemistry-selection gate. This is the culminating gate decision. Plan includes: (i) re-verification of Month 30 (2029-04-14) third-party data if updated cells are produced (Months 30-36 = 2029-04-14 to 2029-10-14); (ii) final cycle-life confirmation (≥300 cycles at 80% measured, no degradation below threshold); (iii) final safety confirmation (thermal-runaway onset ≥120°C, reversible after overcharge); (iv) final Wh/kg and Wh/L confirmation (≥500 Wh/kg, ≥1000 Wh/L measured, not interim threshold). Red team delivers final gate-readiness memo by Week 1 of Month 36 (2029-10-14).

**Responsible Body/Role:** Independent Red Team

**Suggested Timeframe:** Month 35-36 (2029-09-14 to 2029-10-14), verification sprint

**Key Outputs/Deliverables:**

- Month 36 (2029-10-14) Final Verification Plan (re-test protocol if needed, final measurements, gate-readiness memo)
- Final Red-Team Gate Readiness Memo (pass/fail on all Month 36 = 2029-10-14 gate criteria, recommendation on chemistry finalist selection)

**Dependencies:**

- Month 30 (2029-04-14) third-party verification completed (Month 30 = 2029-04-14)
- Month 30-36 (2029-04-14 to 2029-10-14) data (updated cell measurements, cycle-life retention, safety scores) available

### 56. Director, Chemistry Leads and red team jointly conduct the Month 36 (2029-10-14) chemistry-selection gate review. Steering Committee meeting concludes the staged tournament and selects one finalist chemistry (from three active pathways) for scaled optimization and final proof-of-concept (Months 36-72 = 2029-10-14 to 2032-10-14). Gate decision includes: (i) confirmation of finalist meeting all Month 36 (2029-10-14) thresholds (≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles, ≥120°C thermal onset); (ii) deprioritization or termination of non-finalist chemistries; (iii) reallocation of budgets to support finalist optimization and scale-up; (iv) decision to release T4 (USD 90M) for Months 36-84 (2029-10-14 to 2033-10-14) work; (v) risk management and mitigation plan for final-stage proof-of-concept and technology transfer.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with red team input

**Suggested Timeframe:** Month 36 (2029-10-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 36 (2029-10-14) Chemistry-Selection Gate Review Meeting Minutes (attendance, finalist data, selection decision, budget reallocation)
- Chemistry Finalist Selection Memo (official designation of winning chemistry, rationale, deprioritization of alternatives)
- T4 Release Authorization (USD 90M approved for Months 36-84 = 2029-10-14 to 2033-10-14, conditional on finalist confirmation)

**Dependencies:**

- Month 30 (2029-04-14) third-party verification passed (Month 30 = 2029-04-14)
- Red-team final verification completed (Month 35-36 = 2029-09-14 to 2029-10-14)
- Chemistry Leads ready to brief finalist selection rationale

### 57. Director and Finance Manager jointly develop the T4 release decision package for Scientific Steering Committee and Funder approval. T4 (USD 90M, Months 36-84 = 2029-10-14 to 2033-10-14) is released conditional on Month 36 (2029-10-14) chemistry-selection gate passing. Package includes: (i) confirmed Month 36 (2029-10-14) gate decision (finalist chemistry selected); (ii) T3 final spend report (Months 24-36 = 2028-10-14 to 2029-10-14 cumulative); (iii) revised T4 spend forecast and burn-rate profile for Months 36-84 (2029-10-14 to 2033-10-14); (iv) reserve status and contingency allocation for final-stage work; (v) technology-transfer and licensing planning (Months 72-84 = 2032-10-14 to 2033-10-14). T4 release is approved by Steering Committee and Funder by Month 36-37 (2029-10-14 to 2029-11-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 36-37 (2029-10-14 to 2029-11-14), within 1-2 weeks of gate decision

**Key Outputs/Deliverables:**

- T4 Release Decision Package (Month 36 = 2029-10-14 gate confirmation, T3 final spend, T4 forecast, Funder authorization)
- T3 Final Spend Report (Months 24-36 = 2028-10-14 to 2029-10-14 cumulative, category breakdown, variance summary)
- T4 Spend Forecast and Burn-Rate Profile (Months 36-84 = 2029-10-14 to 2033-10-14 budget projection, annual spend profile, cost-center allocation)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate completed and decision documented
- T3 spend fully accounted for

### 58. Director and Chemistry Lead (finalist) jointly transition the programme to final-stage optimization and scale-up (Months 36-72 = 2029-10-14 to 2032-10-14). Phases include: (i) Months 36-48 (2029-10-14 to 2030-10-14): cell optimization (interface engineering, electrolyte refinement, cycle-life and safety improvements); (ii) Months 48-60 (2030-10-14 to 2031-10-14): pilot-line scale-up (reproducibility demonstration, batch-to-batch consistency, yield optimization to 90% within ±10% tolerance, proposed); (iii) Months 60-72 (2031-10-14 to 2032-10-14): final verification and third-party certification (comprehensive pouch cells, abuse testing, licensing readiness). Chemistry and Discovery Leadership Team continues monthly reporting to Steering Committee; Steering Committee meetings transition to quarterly (Months 36+).

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager, with ongoing Steering Committee oversight

**Suggested Timeframe:** Months 36-72 (2029-10-14 to 2032-10-14), staged optimization and scale-up

**Key Outputs/Deliverables:**

- Final-Stage Chemistry Optimization Plan (interface and electrolyte refinement targets, timeline, resource allocation)
- Pilot-Line Scale-Up Plan (batch-to-batch reproducibility targets, yield optimization schedule, automation decisions)
- Final Verification and Certification Plan (third-party pouch-cell testing, abuse test certification, licensing-ready criteria)
- Quarterly Progress Reports (cell performance vs targets, scale-up milestones, safety and cycle-life confirmations)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate passed
- T4 funding released (Month 36-37 = 2029-10-14 to 2029-11-14)

### 59. Director and external technical advisor jointly develop the IP strategy implementation and licensing framework by Month 24 (2028-10-14). Activities include: (i) filing of provisional and utility patents on key compositions, electrolyte architectures and cell formats as they are finalized; (ii) publication strategy for non-core materials work in peer-reviewed journals (after 6-month review window); (iii) freedom-to-operate (FTO) analysis on finalist chemistry to confirm no blocking patents; (iv) licensing framework defining: exclusive or non-exclusive licensing options, royalty structures, manufacturing obligations and geographic scope; (v) preliminary discussions with prospective licensees (established battery manufacturers, automotive OEMs, energy-storage firms) to gauge interest and gather feedback on licensing terms.

**Responsible Body/Role:** Programme Director with Legal Counsel and external technical advisor

**Suggested Timeframe:** Month 12-24 (2027-10-14 to 2028-10-14), framework finalized by Month 24 (2028-10-14)

**Key Outputs/Deliverables:**

- Patent Filing Summary (provisional and utility patents filed to date, claims scope, priority dates)
- IP Strategy Implementation Report (filing timeline, publication review process, FTO analysis)
- Licensing Framework Document (exclusive/non-exclusive options, royalty structures, manufacturing terms, licensee target profiles)
- Prospective Licensee Engagement Memo (preliminary discussions, feedback on licensing terms, timeline for formal partnerships)

**Dependencies:**

- IP strategy finalized (Month 2 = 2026-12-14)
- Chemistry and cell-design innovations emerging (Months 6-24 = 2027-04-14 to 2028-10-14)

### 60. Director and Finance Manager jointly establish a project-wide governance dashboard for Scientific Steering Committee monitoring. Dashboard tracks: (i) technical metrics (Wh/kg, Wh/L, cycle-life, thermal runaway onset, cell-build yield, characterization queue time); (ii) financial metrics (cumulative spend, burn rate, reserve balance, partner cost-sharing); (iii) schedule metrics (gate completion dates, major milestone dates, personnel attrition rate); (iv) risk register status (number of open risks, escalations in month). Dashboard is updated monthly and reviewed by Steering Committee quarterly (or monthly in Months 0-12 = 2026-10-14 to 2027-10-14).

**Responsible Body/Role:** Data Engineer and Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), operational by end of month

**Key Outputs/Deliverables:**

- Project Governance Dashboard v1.0 (technical, financial, schedule and risk metrics, colour-coded status)
- Dashboard Monthly Update (first Thursday of each month, populated with latest data)
- Steering Committee Dashboard Review (included in quarterly meeting agenda, summary of trends and escalations)

**Dependencies:**

- Financial-tracking dashboard established (Month 3 = 2027-01-14)
- Chemistry work producing measurable data (Month 6 = 2027-04-14 onward)
- Risk register initialized (Month 1 = 2026-11-14)

### 61. Director and Chemistry Lead (finalist) jointly commence the technology-transfer planning phase by Month 60 (2031-10-14). Planning activities include: (i) process documentation and scaled procedure development (from lab cell to pilot scale); (ii) manufacturing feasibility studies (cost modeling, equipment requirements, facility footprint for commercial production); (iii) intellectual-property handoff preparation (patent assignments or licensing agreements); (iv) formal engagement with prospective licensee partners (negotiations on exclusive/non-exclusive terms, royalty rates, manufacturing obligations); (v) knowledge-transfer plan (staff training and deployment to licensee site if applicable). Technology transfer culminates by Month 84 (2033-10-14) delivery date.

**Responsible Body/Role:** Programme Director and Chemistry Lead (finalist), with support from Finance Manager and Legal Counsel

**Suggested Timeframe:** Months 60-84 (2031-10-14 to 2033-10-14)

**Key Outputs/Deliverables:**

- Technology-Transfer Plan v1.0 (process documentation, manufacturing feasibility, IP handoff, partner engagement timeline)
- Process Scale-Up Documentation (lab-to-pilot procedures, process-control parameters, quality-assurance protocols)
- Manufacturing Feasibility Study (cost modeling, equipment list, facility requirements, timeline to production readiness)
- Licensee Partnership Agreement (exclusive or non-exclusive, royalty structure, manufacturing obligations, territorial scope)
- Knowledge-Transfer Plan (staff secondment, training schedule, documentation handoff)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate completed (Month 36 = 2029-10-14)
- Finalist chemistry optimized and scaled (Months 36-60 = 2029-10-14 to 2031-10-14)
- Final verification data available (Months 60-72 = 2031-10-14 to 2032-10-14)
- Prospective licensees pre-identified (Month 12-24 = 2027-10-14 to 2028-10-14)

### 62. Director and red team jointly conduct a final pre-delivery verification of the winner chemistry against all stated programme goals: (i) ≥500 Wh/kg at cell level, third-party measured; (ii) ≥1000 Wh/L at cell level, third-party measured; (iii) ≥300 cycles at 80% capacity retention, third-party measured; (iv) thermal-runaway onset ≥120°C, abuse-tested; (v) ≥90% of cells reproducible within ±10% Wh/kg, ±5% Wh/L (proposed). Red team delivers final certification memo by Month 72 (2032-10-14) confirming goals are met. Programme conclusion and knowledge transfer proceed if goals are met; if any goal is not fully met, Steering Committee decides descope or extended optimization through Month 84 (2033-10-14).

**Responsible Body/Role:** Independent Red Team with Programme Director oversight

**Suggested Timeframe:** Month 72 (2032-10-14)

**Key Outputs/Deliverables:**

- Final Programme Goal Certification Report (verification of ≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles, ≥120°C thermal onset, reproducibility ≥90% within tolerances)
- Third-Party Test Reports Summary (reference to external lab data and certifications supporting each goal)
- Red Team Final Certification Memo (goals met or not met, any caveats or conditional certifications)

**Dependencies:**

- Month 60-72 (2031-10-14 to 2032-10-14) final optimization and verification completed (Months 60-72 = 2031-10-14 to 2032-10-14)
- Third-party verification and certification testing conducted (Months 60-72 = 2031-10-14 to 2032-10-14)
- All key data collected and red-team validation completed

### 63. Programme Director issues a final project close-out memo to the Scientific Steering Committee, Funder and stakeholders. Memo documents: (i) achievement of primary and secondary goals (Wh/kg, Wh/L, cycle-life, safety); (ii) final financial summary (total spend vs USD 300M cap, reserve utilization); (iii) lessons learned and recommendations for future battery R&D; (iv) IP and patent estate delivered; (v) technology-transfer status and licensee partnerships; (vi) programme team recognition and closure of employment relationships. Closing memo is issued by Month 84 (2033-10-14) and archived as the official programme record.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 84 (2033-10-14), end of programme

**Key Outputs/Deliverables:**

- Final Project Close-Out Memo (achievement summary, financial close-out, lessons learned, IP and licensing status)
- Programme Final Report (comprehensive summary of 84-month effort, outcomes, recommendations)
- Archive Package (all governance documents, gate reviews, financial reports, technical data, IP filings, team records)

**Dependencies:**

- All programme activities concluded by Month 84 (2033-10-14)
- Technology transfer to licensee partner in progress or complete
- Final financial reconciliation completed

# Decision Escalation Matrix

**Chemistry Tournament Failure or No Viable Path to 500 Wh/kg at Cell Level**
Escalation Level: Scientific Steering Committee with Funder Review
Approval Process: Steering Committee majority vote (4 of 7 members) to recommend chemistry deprioritization, pivot to reserve, or programme descope. Funder approval required if descope involves release of T4 (USD 90M) or if proceeding with only one candidate instead of two finalists at Month 36 (2029-10-14).
Rationale: A staged chemistry tournament is the core hedging strategy against dead-end chemistry risk. If two of three active chemistries fail fundamental feasibility (cycle-life collapse, dendrite growth, volume expansion) by Month 30 (2029-04-14), escalation is mandatory to activate reserve chemistry or decide whether to stop. Without escalation, wasted investment on non-viable paths consumes USD 5–10 M and compresses final-stage work from 48 to 38–42 months.
Negative Consequences: Unmanaged chemistry failure at Month 36 (2029-10-14) leaves only one or no viable finalist, forcing either a desperate pivot with 38–42 months remaining (insufficient for proof-of-concept and licensing readiness) or programme stop without a deliverable. Failure to escalate early (before Month 30 = 2029-04-14) costs USD 10–20 M in sunk effort and delays final proof 6–12 months, jeopardizing the Month 84 (2033-10-14) delivery date.

**Volumetric Energy Density Falls Below 950 Wh/L Interim Threshold or Projected Below 1000 Wh/L at Month 30 (2029-04-14)**
Escalation Level: Scientific Steering Committee with Chemistry Leadership and Red Team Input
Approval Process: Steering Committee majority vote to authorize a 6-month focused architecture sprint (Months 30–36 = 2029-04-14 to 2029-10-14) to address volumetric penalties via thinner separators, higher-density cathode, or bipolar/anode-free format; reallocation of USD 8–15 M (estimate) from other budget categories; or deprioritization of the affected chemistry. Funder sign-off if reallocation exceeds USD 5 M.
Rationale: The 1000 Wh/L target is as challenging as 500 Wh/kg but receives secondary priority in early discovery work. Material-level energy density often collapses at cell level once separator thickness, electrolyte volume and packaging overhead are included. Discovering volumetric penalties late (after Month 36 = 2029-10-14 selection gate) leaves insufficient time for redesign; escalation at Month 30 (2029-04-14) allows 6-month corrective sprint before final selection.
Negative Consequences: If volumetric shortfall is not escalated and addressed by Month 36 (2029-10-14), final delivery at Month 72 (2032-10-14) may achieve 500 Wh/kg but only 800–900 Wh/L, reducing invention value and licensing appeal by 30–40%. Programme credibility is damaged if a headline 1000 Wh/L goal is missed due to late recognition of packaging penalties. Redesign cost and timeline slip compress the Months 36–84 (2029-10-14 to 2033-10-14) optimization window from 48 to 36–42 months.

**Site Permitting Delayed More Than 6 Months or Phase 1 Permit Denied**
Escalation Level: Chief EHS Officer to Steering Committee to Funder (Critical Path Risk)
Approval Process: Chief EHS Officer escalates permit status to Steering Committee within 48 hours of learning of any delay >4 weeks or regulator notice of denial. Steering Committee authorizes contingency measures within 1 week: (i) pre-negotiated external synthesis partnerships (cost USD 2–5 M/yr, 4–6 week turnarounds) to continue chemistry work; (ii) deferral of Phase 2 synthesis to external vendors; (iii) revision of operational timeline and T2 release milestone tied to actual permit approval rather than Month 12 (2027-10-14) target. Funder approval required if delay compresses effective programme duration below 75 months or if external-synthesis costs exceed USD 10 M total.
Rationale: Permitting is on the critical path: a 6–8 month slip (plausible given overlapping EPA, TCEQ and local fire-authority processes) reduces effective work time from 84 to 76–78 months, compressing chemistry selection and final proof timelines. Phase 1 denial (dry-room/assembly operations) blocks operational start entirely. Escalation enables rapid contingency activation: pre-negotiated external synthesis partnerships allow chemistry work to continue even if on-site synthesis is prohibited.
Negative Consequences: Unmanaged permitting delay of 6–8 months pushes operational start from Month 3 (2027-01-14) to Month 9 (2027-07-14), leaving only 75 effective work months. Month 36 (2029-10-14) chemistry-selection gate compresses from 48 remaining months to 39–42 months for final proof-of-concept, risking incomplete validation or forced descope to 480 Wh/kg instead of 500. Phase 1 denial without contingency halts all operations, consuming USD 30–50 M in sunk facility and equipment capital with no recovery. External synthesis at USD 2–5 M/yr consumes USD 10–25 M over 5–7 years (5–8% of budget).

**Pilot-Line Capital Commitment Decision Unresolved or Build Overruns Beyond USD 15 M Budget**
Escalation Level: Finance Manager and Programme Director to Scientific Steering Committee
Approval Process: Finance Manager flags by Month 1 (2026-11-14) that pilot-line decision (build vs. lease vs. modular) is the single largest capital commitment before chemistry is proven. Steering Committee majority vote is required to approve any option exceeding USD 15 M or with <3-year lead time. If procurement quotes exceed USD 15 M, Director requests recompetition or reduced scope; if overrun is unavoidable, Steering Committee must approve reallocation from other capital categories (e.g., reducing characterization instrument spending) or requesting additional budget (triggering Funder escalation).
Rationale: A new-build owned pilot line costs USD 30–50 M and requires 6–12 month lead time, consuming 10–17% of total budget and 12 months of programme time before chemistry is even selected. Building now locks capital before chemistry risk is resolved and creates stranded-asset risk if winning chemistry has incompatible drying or pressure requirements. Leasing (USD 0.6–1.2 M/yr operating cost, ~USD 4–8 M over 7 years) preserves flexibility and capital for pivots. Unresolved decision delays first pouch-cell builds by 6–12 months, compressing discovery loop.
Negative Consequences: If build option is selected without escalation and later the winning chemistry requires different conditions, USD 30–50 M of equipment is partially stranded, reducing effective budget to USD 250–270 M (13–17% loss). Build timeline slippage of 6–12 months defers first pouch cells to Month 9–12 (2027-07-14 to 2027-10-14), losing discovery iterations in Months 3–9 (2027-01-14 to 2027-07-14). Leasing with queue delays of 4–8 weeks slows hypothesis testing by 50%, reducing annual candidate throughput by ~50%.

**Cycle-Life or Safety Threshold Violated: Measured <250 Cycles or Thermal Runaway Onset <100°C**
Escalation Level: Red Team to Chemistry Leadership to Scientific Steering Committee (Technical Gate Risk)
Approval Process: Red Team flags any chemistry candidate with measured cycle-life <250 cycles at 80% retention or thermal-runaway onset <100°C within 5 days of data receipt. Chemistry Lead responds within 3 days with either: (i) a documented redesign plan (interface engineering, cathode doping, electrolyte additives) with timeline and success criteria; or (ii) recommendation to deprioritize or stop. If redesign plan is credible and within 2–4 months, Steering Committee approves continued investment. If plan is not credible or redesign would consume >USD 2 M additional, Steering Committee authorizes deprioritization and budget reallocation to remaining active chemistries.
Rationale: Cycle-life <300 cycles (proposed threshold) and thermal-runaway onset <120°C are hard failure modes that make a cell non-commercial regardless of energy density. A cell meeting 500 Wh/kg but degrading below 80% capacity in 150 cycles or experiencing thermal runaway at 90°C is worse than useless—it is dangerous. Escalation enforces discipline: unmet cycle-life data by Month 24 (2028-10-14) or safety violations at any point trigger mandatory redesign or deprioritization before capital is wasted on optimization.
Negative Consequences: If cycle-life or safety violations are not escalated and addressed early, a failing chemistry can consume 6–12 months of effort and USD 5–10 M in pilot-line, characterization and optimization costs before being abandoned at Month 30 (2029-04-14) or later. A chemistry that passes energy-density targets but fails safety certification late forces either immediate deprioritization or a risky decision to accept marginal safety. Unmanaged safety discovery late in the programme (Month 48+) could trigger facility permitting revision (costs USD 2–5 M, 3–4 month downtime).

**Budget Overrun or Spend Variance >20% in Any Category or Tranche Depletion Forecast**
Escalation Level: Finance Manager to Steering Committee to Funder (Financial Gate)
Approval Process: Finance Manager flags monthly spend variance >15% within 5 days; if variance reaches 15–20%, Director proposes corrective action (spending freeze in a category, or one-time reallocation <USD 1 M). If variance exceeds 20% or is projected to persist, escalated to Steering Committee majority vote for reallocation decision (internal to current tranche, up to USD 2 M). If reallocation >USD 2 M or involves inter-tranche carry-forward shortfall, Funder approval required. Tranche depletion forecast (spending projected to exceed tranche balance >4 months before next tranche release) triggers Steering Committee review and Funder notification within 2 weeks.
Rationale: The fixed USD 300 M budget is divided into tranches (USD 60/80/70/90 M) with USD 20 M unallocated reserve. A 20% overrun in any major category (payroll USD 10 M/yr, capital USD 50 M, facility USD 25 M) compresses working capital by USD 2–10 M, threatening mid-stage pivots or final-stage optimization. Permitting delays, staff attrition, equipment cost inflation or partner loss can each add USD 2–5 M unbudgeted cost. Escalation enables rapid reallocation or Funder negotiation before spend gaps compromise programme viability.
Negative Consequences: Unmanaged budget overruns of 15–20% across Months 0–36 (2026-10-14 to 2029-10-14) leave only USD 240–255 M for critical Months 36–84 (2029-10-14 to 2033-10-14) work, reducing annual burn capacity from ~USD 33 M to ~USD 26–28 M (20–25% reduction). Front-loaded capital overruns (facility USD 30–50 M build instead of USD 15 M lease, USD 10 M characterization instruments vs. USD 2–3 M, USD 5–10 M hiring overages) compress chemistry work and optimization budgets in later years. A 10–15% cumulative overrun forces either scaling back of Months 36–84 (early stop before full proof-of-concept) or Funder request for additional funds (ruptures fixed-budget constraint).

# Monitoring Progress

### 1. Tracking Key Performance Indicators (KPIs) against Project Plan and Chemistry-Tournament Milestones
**Monitoring Tools/Platforms:**

  - Project Governance Dashboard (technical, financial, schedule and risk metrics updated monthly)
  - Chemistry-Tournament Progress Tracking Spreadsheet (cell builds, Wh/kg, Wh/L, cycle-life data per pathway)
  - Cell-Level Mass-and-Volume Model with Monthly Updates (projected vs. measured energy density, variance analysis)
  - Monthly Chemistry Leadership Progress Report Template (cell-build count, measurements, forensics findings, gate-criteria tracking)

**Frequency:** Weekly synthesis/characterization team sync meetings; monthly Chemistry Leadership progress reports; quarterly full Scientific Steering Committee reviews (monthly in Months 0-12 = 2026-10-14 to 2027-10-14); gate-review cycles at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14)

**Responsible Role:** Chemistry and Discovery Leadership Team (Chemistry Leads, Data Engineer, Pilot-Line Manager) with oversight by Programme Director and Scientific Steering Committee

**Adaptation Process:** Monthly progress data is reviewed by Chemistry Leadership and Steering Committee liaison. If a chemistry pathway is off-track against interim targets (projected Wh/kg, Wh/L, cycle-life or safety thresholds), Chemistry Leads propose corrective actions (materials redesign, electrolyte optimization, pilot-line process adjustment, characterization focus shift). Corrective actions up to USD 500K/quarter are approved by Chemistry Leads within their authority; larger redirects are escalated to Steering Committee for authorization. Quarterly Steering Committee reviews assess all three pathways against gate criteria and recommend budget rebalancing or deprioritization if progress diverges significantly. At formal gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), Steering Committee renders go/no-go decisions per chemistry based on documented evidence.

**Adaptation Trigger:** Monthly data variance >15% from quarterly projection triggers Chemistry Lead review and proposed corrective action within 5 days. Cumulative Wh/kg or Wh/L variance >10% by Month 20 (2028-06-14) initiates model recalibration. Any chemistry failing to meet Month 18 (2028-04-14) interim targets (cycle-life <250 cycles measured, thermal-runaway onset <100°C, Wh/L <900 projected at cell level) is flagged for deprioritization. Any chemistry with measured cycle-life <250 cycles at 80% retention by Month 24 (2028-10-14) is recommended for deprioritization at Month 30 (2029-04-14) gate unless redesign is within 2-4 months. Gate criteria not met by Month 30 (2029-04-14) (≥500 Wh/kg AND ≥950 Wh/L third-party verified, ≥300 cycles at 80%, thermal-runaway onset ≥120°C) trigger contingency evaluation: pivot to reserve chemistry or extended redesign sprint (Months 30-36 = 2029-04-14 to 2029-10-14) before final selection gate.

### 2. Independent Technical Verification and Red-Team Challenge of Progress Claims
**Monitoring Tools/Platforms:**

  - Red Team Replication Protocol and Cell-Build Documentation (independent replication of 1+ cell per chemistry per gate)
  - Monthly Data-Review Flag Memo (discrepancies flagged by red team within 10 days of Chemistry Leadership monthly reports)
  - Red-Team Verification Results Memo (gate readiness assessment, pass/no-pass on replication tolerance ±10% Wh/kg, ±5% Wh/L)
  - Red-Team Gate-Readiness Certification Memo (final recommendation on chemistry finalist selection at each gate: Month 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14)

**Frequency:** Monthly data-review cycles (red team review of Chemistry Leadership monthly reports within 10 days, flag memo issued within 5 days if discrepancies detected); gate-verification sprints at Months 17, 29, 35 (2028-03-14, 2029-03-14, 2029-09-14) leading into Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) gates (2-3 week replication period per gate); cell-level mass-and-volume model audit monthly with formal comparison to measured pouch-cell teardowns quarterly

**Responsible Role:** Independent Red Team (2-3 external or internal non-core scientists, reporting directly to Scientific Steering Committee, not to Chemistry Leads); Red-Team Lead coordinates replication protocol and monthly data review

**Adaptation Process:** Monthly data-review flag memos are circulated to Chemistry Leads, who respond within 3 days with clarification or correction of any claimed inconsistencies (e.g., Wh/kg measured in November contradicts October data, or claimed Wh/L falls below projected threshold). Unresolved discrepancies are escalated to Steering Committee within 1 week for adjudication. At gate reviews (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), red-team replication results (pass/no-pass on acceptance criteria: ±10% Wh/kg, ±5% Wh/L, ±5% cycle-life retention, proposed) determine gate-readiness status. If red-team replication consistently fails (measured <90% of claimed Wh/kg or Wh/L), the affected chemistry is flagged for Steering Committee review; Steering Committee may recommend deprioritization independent of Chemistry Leads' objections. If red-team identifies systematic data-quality issues or measurement methodology problems, gate decision is delayed up to 3 weeks to allow remedial verification before Steering Committee renders final go/no-go.

**Adaptation Trigger:** Monthly data discrepancies flagged by red team within 10 days of Chemistry Leadership report; Chemistry Lead response required within 3 days. Unresolved inconsistencies (Chemistry Lead cannot explain variance, or flag is not addressed) escalate to Steering Committee within 1 week. Red-team replication results differing by >10% Wh/kg or >5% Wh/L from claimed values delay gate decision up to 3 weeks for root-cause investigation. Red-team finding of <80% reproducibility (fewer than ~7 of 10 replicates meeting claimed Wh/kg and Wh/L within tolerance) triggers recommendation to deprioritize that chemistry at the next gate (Month 18, 30 or 36 = 2028-04-14, 2029-04-14, 2029-10-14).

### 3. Cycle-Life and Safety-Threshold Monitoring Against Hard Gate Criteria
**Monitoring Tools/Platforms:**

  - Monthly Cycle-Life Performance Report (measured cycles at 80% retention per chemistry, trend tracking, redesign actions flagged)
  - Safety-Test Results Database (thermal-ramp screening results, contracted abuse-test reports, in-house chamber data)
  - Cycle-Life Deprioritization Decision Log (any chemistry <250 cycles at 80%, documented, flagged for gate review)
  - Safety Threshold Compliance Tracker (thermal-runaway onset temperature, overcharge reversibility, cells failing thresholds)

**Frequency:** Monthly cycle-life data collection and trending (as cells complete cycling tests, typically 1-6 months per cell depending on test protocol); thermal-ramp screening monthly Months 3-6 (2027-01-14 to 2027-04-14); contracted abuse testing at designated milestones (Months 6, 9, 12 = 2027-04-14, 2027-07-14, 2027-10-14 estimated); in-house abuse chamber testing quarterly once commissioned (Months 18+ = 2028-04-14 onward)

**Responsible Role:** Chemistry Leads and Characterization Manager (cycle-life data tracking); Chief EHS Officer and external safety consultant (abuse-test scheduling and results review); Safety data flagged to Steering Committee monthly via Chemistry Progress Report

**Adaptation Process:** Monthly cycle-life report trends are reviewed by Chemistry Leadership and flagged to Steering Committee if any candidate shows measured retention falling toward <250 cycles at 80%. Chemistry Lead responds with redesign action plan (interface engineering, cathode doping, electrolyte additive, cell format adjustment) and estimated timeline to recovery (typically 2-4 months for one iteration). If redesign is credible and within 2-4 months, continued investment is approved. If redesign is not credible or would require >6 months, Steering Committee authorizes deprioritization and budget reallocation to remaining active chemistries. Safety-test results (thermal-ramp onset, abuse-test performance) are reviewed by Chemistry Leadership and EHS Officer; any cell with onset <100°C or non-reversible overcharge failure is flagged immediately for Chemistry Lead investigation. If a leading chemistry fails safety threshold and cannot be corrected within 2-4 months, deprioritization is recommended at the next gate (Month 18, 30 or 36 = 2028-04-14, 2029-04-14, 2029-10-14).

**Adaptation Trigger:** Measured cycle-life <250 cycles at 80% retention detected at any point; Chemistry Lead must provide redesign plan within 3 days. Lack of credible redesign plan or failure to achieve ≥300 cycles by Month 24 (2028-10-14) triggers deprioritization recommendation at Month 30 (2029-04-14) gate. Thermal-runaway onset <100°C or failure to reverse after overcharge triggers immediate escalation to Chief EHS Officer and Steering Committee; decision on deprioritization or emergency redesign within 1 week. Any safety threshold violation at Month 30 (2029-04-14) gate or later disqualifies chemistry from finalist selection unless onset can be raised to ≥120°C (proposed threshold) within the gate-to-selection window (Months 30-36 = 2029-04-14 to 2029-10-14).

### 4. Volumetric Energy Density (1000 Wh/L) Parity Monitoring and Cell-Architecture Optimization Triggers
**Monitoring Tools/Platforms:**

  - Volumetric Density Focus List (monthly update of candidates projected <950 Wh/L interim threshold, flagged for redesign)
  - Cell-Level Mass-and-Volume Model (separator thickness, electrolyte volume, current-collector mass, inactive-mass breakdown tracked per candidate)
  - Wh/L Mismatch Root-Cause Analysis (model assumptions vs. measured pouch-cell teardowns, separator thickness bias, electrolyte volume overestimate)
  - Volumetric-Density Optimization Sprint Plan (if Month 30 = 2029-04-14 data shows chemistry meeting ≥500 Wh/kg but <950 Wh/L, dedicated 6-month architecture sprint authorized Months 30-36 = 2029-04-14 to 2029-10-14)

**Frequency:** Quarterly volumetric-density review (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14, 2029-10-14); monthly model updates incorporating actual measured cell-level Wh/kg and Wh/L; pouch-cell teardown mass-and-volume audits conducted on 2-3 representative cells quarterly (Months 6, 9, 12, 18, 24, 30 = 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14) to validate model assumptions

**Responsible Role:** Chemistry Leads and Data Engineer; red team audits model assumptions and validates model-to-reality accuracy quarterly

**Adaptation Process:** If any chemistry is projected to fall below 950 Wh/L interim threshold by Month 18 (2028-04-14), Chemistry Lead initiates focused volumetric-density redesign: thinner separators, reduced electrolyte volume, higher-density cathode materials, or bipolar/anode-free cell-architecture evaluation. Progress on volumetric redesign is tracked monthly. By Month 24 (2028-10-14), all leading candidates must project ≥950 Wh/L or deprioritization is recommended. If Month 30 (2029-04-14) third-party verification shows a leading chemistry meeting ≥500 Wh/kg but measured Wh/L is <950 Wh/L (e.g., 920 Wh/L), Steering Committee authorizes a focused 6-month architecture sprint (Months 30-36 = 2029-04-14 to 2029-10-14) to close the gap through cell-format optimization (bipolar stacking, pressure management, anode-free architecture). Sprint goal is to recover Wh/L to ≥950 Wh/L by Month 36 (2029-10-14). If volumetric gap cannot be closed, the chemistry may still advance if Wh/kg target (≥500) is met, but with a conditional notation that the 1000 Wh/L target (final, not interim) is at risk.

**Adaptation Trigger:** Any chemistry projected <950 Wh/L interim at Month 18 (2028-04-14) gate triggers focused redesign work through Month 24 (2028-10-14). If chemistry is still projected <950 Wh/L at Month 24 (2028-10-14), deprioritization is recommended. If Month 30 (2029-04-14) measured Wh/L is <950 Wh/L for a leading chemistry (even if ≥500 Wh/kg), Steering Committee decision is required: either authorize a 6-month volumetric sprint (Months 30-36 = 2029-04-14 to 2029-10-14) with reallocation of USD 8-15 M (estimate) and adjusted timeline to final proof, or deprioritize the chemistry if arc-focused redesign is deemed infeasible. If final measured Wh/L at Month 72 (2032-10-14) is <950 Wh/L (falling short of 1000 Wh/L target), the invention is delivered as a partial success (500+ Wh/kg achieved, 1000 Wh/L missed), with documented root causes and design constraints.

### 5. Third-Party Verification and Cell-Level Proof-of-Concept Milestones
**Monitoring Tools/Platforms:**

  - Third-Party Pouch-Cell Testing Protocol and Laboratory Contract (independent laboratory or university partner, measurement certification)
  - Third-Party Verification Report (Month 30 = 2029-04-14: measured ≥500 Wh/kg, ≥950 Wh/L, ≥300 cycles at 80%, reproducibility ≥90% within ±10% Wh/kg, ±5% Wh/L)
  - Phase 1 Independent Verification Report (Month 12 = 2027-10-14: early-stage candidate cells tested to confirm in-house measurement methodology)
  - Final Programme Goal Certification Report (Month 72 = 2032-10-14: third-party verification of final cells meeting ≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles, ≥120°C thermal onset)

**Frequency:** Phase 1 independent verification of early-stage candidate cells: Months 9-12 (2027-07-14 to 2027-10-14); Month 30 (2029-04-14) third-party pouch-cell verification of finalist(s): testing conducted Months 26-30 (2028-12-14 to 2029-04-14) with results delivered by Month 30 (2029-04-14); final third-party certification at Months 60-72 (2031-10-14 to 2032-10-14) for delivery-ready cells

**Responsible Role:** Chemistry Leads coordinate cell selection and documentation for third-party testing; independent third-party laboratory (accredited testing organization or university partner) performs measurements and provides certified results; red team may independently verify third-party methodology or re-test if questions arise

**Adaptation Process:** Phase 1 independent verification (Month 12 = 2027-10-14) results are compared to in-house measurements. If systematic discrepancies emerge (e.g., in-house measurements consistently report Wh/kg 5-10% higher than third-party), in-house calibration procedures are reviewed and corrected by Month 15 (2028-01-14) so future measurements align with third-party standard. Month 30 (2029-04-14) third-party pouch-cell verification gates the chemistry-selection decision: Steering Committee go/no-go determination is conditional on third-party data confirming ≥500 Wh/kg AND ≥950 Wh/L in the same ≥3 replicates, ≥300 cycles at 80%, and 90% of cells within ±10% Wh/kg tolerance (proposed). If third-party verification shows measured values falling short of these thresholds (e.g., ≥480 Wh/kg but only ≥920 Wh/L, or <270 cycles), Steering Committee triggers either a 6-month redesign sprint (Months 30-36 = 2029-04-14 to 2029-10-14) or deprioritization of that chemistry. Final third-party certification (Months 60-72 = 2031-10-14 to 2032-10-14) confirms delivery-readiness; if final cells do not meet stated goals (≥500 Wh/kg, ≥1000 Wh/L final target, ≥300 cycles, ≥120°C thermal onset), Steering Committee documents partial success or descope decision.

**Adaptation Trigger:** Phase 1 independent verification results (Month 12 = 2027-10-14) differ by >5% Wh/kg or >3% Wh/L from in-house measurements trigger in-house methodology review and calibration by Month 15 (2028-01-14). Month 30 (2029-04-14) third-party data showing measured <500 Wh/kg or <950 Wh/L in the finalist chemistry triggers Steering Committee decision on 6-month sprint (reallocation of USD 8-15 M) or deprioritization. Third-party verification of <90% reproducibility (fewer than ~7 of 10 replicates meeting ±10% tolerance) flags cell-build quality issues; Chemistry Lead provides corrective action plan for pilot-line process improvement by Month 32 (2029-06-14). Final certification (Month 72 = 2032-10-14) showing Wh/L <950 Wh/L (falling short of 1000 Wh/L) is documented; if Wh/kg meets ≥500 and cycle-life meets ≥300 cycles, delivery may proceed as partial success with noted constraint; if either Wh/kg or cycle-life falls short, programme escalates to Funder for final delivery decision.

### 6. Risk Register and Contingency Management Monitoring
**Monitoring Tools/Platforms:**

  - Project Risk Register (20+ identified risks covering chemistry pathway, volumetric density, permitting, budget/burn, talent, partnerships, supply chain, regulatory, IP, manufacturing, cycle-life degradation)
  - Monthly Risk Dashboard (risk status: green/yellow/red, escalations in month, mitigation actions tracked by owner and due date)
  - Contingency Pivot Plan per Chemistry Pathway (precursor sourcing, pilot-line equipment reconfiguration, staff cross-training status)
  - Pivot-Runway Reserve Allocation Tracking (USD 15 M ring-fenced until Month 36 = 2029-10-14 gate, available for emergency redirects if two of three active chemistries fail)

**Frequency:** Risk register initialized at Month 1 (2026-11-14); monthly risk review with Chemistry Leadership (risk status update, mitigation progress tracking); quarterly full Steering Committee risk briefing (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14, 2029-10-14); escalation within 48 hours if a risk approaches trigger threshold (e.g., permitting delay exceeds 4 weeks, budget variance >15%, partner access delayed >3 weeks, chemistry fails cycle-life test)

**Responsible Role:** Programme Director maintains master risk register; Chemistry Leads own technical risks and mitigation actions; Chief EHS Officer owns permitting and regulatory risks; Finance Manager owns budget and cost-overrun risks; Programme Director escalates risks to Scientific Steering Committee when trigger threshold is approached

**Adaptation Process:** Monthly risk reviews identify which risks are trending toward trigger thresholds. Chemistry Leads propose mitigation actions (e.g., increased synthesis effort if a chemistry's cycle-life is approaching <250 cycles threshold, or pre-staging reserve chemistry if two active chemistries show fundamental limitations). Mitigation actions up to USD 500K are approved by Chemistry Leads; larger actions (contingency activation, major budget reallocation) require Steering Committee approval. At gate reviews (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), Steering Committee assesses whether any open risks have crystallized into hard failures (chemistry no longer viable, permitting denied, partner lost) and triggers contingency plans (pivot to reserve chemistry, activate outsourced synthesis, draw on pivot-runway reserve, extend timeline). Pivot-runway reserve (USD 15 M) is held unallocated until Month 30 (2029-04-14); if a chemistry fails between Months 18-30 (2028-04-14 to 2029-04-14), Steering Committee may authorize release of USD 5-10 M to support rapid pivot activation (precursor procurement, equipment reconfiguration, staff retraining for reserve chemistry) to minimize schedule slip.

**Adaptation Trigger:** Any risk trending toward or exceeding trigger threshold (e.g., permitting delay >4 weeks, monthly spend variance >15%, chemistry cycle-life <250 cycles, thermal-runaway onset falling below 100°C, partner access queue delay >3 weeks, attrition exceeding 15%/yr) is escalated by the owning team (Chemistry Lead, EHS Officer, Finance Manager, Talent Lead) to Steering Committee within 5 days of threshold breach. Steering Committee convenes within 1 week to review trigger status and authorize mitigation or contingency activation. For chemistry-related risks (pathway failure, cycle-life collapse, safety threshold breach, volumetric-density shortfall), deprioritization of the affected chemistry or reserve-chemistry activation is decided at the next formal gate (Month 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) or earlier if the risk crystallizes into confirmed failure. For operational risks (permitting denial, partner loss, supply-chain disruption), contingency measures (external synthesis activation, backup partner engagement, material re-sourcing) are implemented immediately upon Steering Committee authorization.

### 7. Financial Tracking and Budget-Reallocation Governance
**Monitoring Tools/Platforms:**

  - Monthly Financial-Tracking Dashboard (cumulative spend by cost center: payroll, capital, facility, precursor, testing, EHS, computing, reserve; remaining tranche balance; variance flagging if category >±15% of plan)
  - Tranche Release Decision Package and Evidence Checklist (T2 at Month 12 = 2027-10-14 conditional on Phase 1 permit, operational pilot line, live cell-level model; T3 at Month 24 = 2028-10-14 conditional on Month 18 = 2028-04-14 gate pass; T4 at Month 36 = 2029-10-14 conditional on chemistry-selection gate)
  - Quarterly Financial Review Report (cumulative spend, burn-rate profile, carry-forward forecast, partner cost-sharing reconciliation)
  - Currency Risk and Procurement Tracking (FX exposure on equipment orders, forward-exchange contract status, budget impact forecast)

**Frequency:** Monthly spend tracking and variance flagging (first Thursday of each month, within 5 days of month-end close); Director-Finance Manager monthly financial review (1 hour, variance discussion and corrective-action proposals if >15%); quarterly full Steering Committee financial briefing included in regular Steering Committee meeting agenda (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14, 2029-10-14); ad-hoc escalation if spend variance exceeds 20% in any month or if tranche depletion is forecast >4 months early

**Responsible Role:** Finance Manager tracks monthly spend and updates dashboard; Director reviews variance and proposes corrective action; Steering Committee approves budget reallocations >USD 1 M or affecting inter-tranche timing; Funder approves release of each tranche (T2, T3, T4) and any reallocation >USD 2 M or reserve activation >USD 1 M

**Adaptation Process:** Monthly spend variance <±15% is flagged but requires no immediate action. Variance ±15% to ±20% is reviewed by Director and Finance Manager within 5 days; if variance is projected to persist (trend analysis), Director proposes corrective action: spending freeze in an overrunning category, one-time reallocation of unspent balance from another category, or revised spend forecast. Variance >20% or projected tranche depletion >4 months early is escalated to Steering Committee within 1 week for reallocation decision. Reallocation within current tranche and <USD 1 M is approved by Director; reallocation >USD 1 M or affecting inter-tranche timing (e.g., carrying forward underspend from T1 to cover T2 shortfall) requires Steering Committee majority vote. Tranche release conditions are verified by Finance Manager and Director before authorization memo is sent to Funder (typically 2-3 weeks before month of intended release). If release conditions are not met (e.g., Phase 1 permit not approved, cell-level model not live), tranche release is deferred and revised schedule is communicated to Funder. Partner cost-sharing reconciliation is conducted quarterly (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14 onwards): partner invoices are verified against contribution commitments; any under-contribution by partners (falling below ≥15% proposed target) triggers partner discussion and revised commitment or Steering Committee decision to absorb shortfall from programme budget.

**Adaptation Trigger:** Monthly spend category variance ±15-20% flagged by Finance Manager within 5 days; Director proposes corrective action within 10 days (spending freeze, one-time reallocation <USD 1 M, or revised forecast). Variance >20% or trend toward tranche depletion >4 months early escalates to Steering Committee within 1 week; Steering Committee votes within 3 days on reallocation decision (reallocate from another category, extend tranche timeline, or request Funder top-up if cap overrun is unavoidable). Tranche release condition not met (Phase 1 permit pending, cell-level model delay, Month 18 = 2028-04-14 gate inconclusive) triggers Steering Committee decision on defer release or proceed conditionally; Funder must approve any conditional release. FX exposure on equipment orders exceeding USD 10 M triggers forward-exchange contract negotiation; if contract cost exceeds USD 500K, Steering Committee approval is required.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All five core governance components (Stage 2 internal bodies, Stage 3 implementation plan, Stage 4 escalation matrix, Stage 5 monitoring, Stage 1 audit details) are present and documented. The framework includes Scientific Steering Committee, Chemistry Leadership Team, Independent Red Team, EHS/Compliance Office, and integrated Finance governance. Implementation plan spans 40+ steps from Month 0 (2026-10-14) to Month 84 (2033-10-14). Escalation matrix covers 5 critical decision types. Monitoring approach specifies 6 distinct tracking methodologies. Audit procedures detail 8 compliance domains. Coverage appears comprehensive for a capital-constrained, high-ambition R&D programme.
2. Internal Consistency Check: Logical alignment across stages is confirmed with one caveat. Implementation plan correctly references the four governance bodies and assigns step ownership. Escalation matrix identifies Scientific Steering Committee as the primary escalation point, consistent with the Stage 2 authority definitions. Monitoring plan ties KPI tracking to gate criteria defined in Stage 3 and escalates to the correct bodies. However, one inconsistency detected: the red team's authority to 'delay gate decisions up to 3 weeks' (Stage 2, red team decision_rights) does not appear explicitly in the Stage 4 escalation matrix; this creates ambiguity about whether a red-team holdback is an escalation requiring Funder sign-off or is unilaterally enforceable. Recommendation: Stage 4 should include a line for 'Red Team Holds Gate Decision for Verification,' clarifying that up to 3-week delays are red-team-executable without Steering Committee override, but >3-week delays do require escalation.
3. Potential Gap 1—Clarity of Ultimate Project Sponsor Authority: The governance documents reference 'Project Sponsor' as the pre-existing funder authority (Stage 1, implementation plan Step 1), but do not clearly specify the Sponsor's role in the ongoing Scientific Steering Committee governance. Is the Funder representative (non-voting observer per Stage 2 Steering Committee membership) the Project Sponsor's delegate, or are they separate entities? Implementation Plan Step 1 states 'Project Sponsor confirms programme Director,' but later steps show the Director and Steering Committee making major decisions with 'Funder approval required' for thresholds >USD 2M or programme stop. Clarification needed: (i) Is 'Project Sponsor' synonymous with 'Funder'? (ii) Does the Sponsor have any unilateral halt authority, or does all stop authority flow through Steering Committee escalation to Funder? (iii) If the Sponsor is separate from Funder, what is the Sponsor's decision authority over governance changes (e.g., replacing Director, dissolving red team)?
4. Potential Gap 2—Process Definition for Conflict of Interest and Whistleblower Investigation: While Stage 1 Audit Details specify 'conflicts of interest' as part of corruption prevention and include employee disclosure forms, the governance framework does not define a formal conflict-of-interest management process for Committee members or staff. Example gap: If a Chemistry Lead's spouse works for a precursor vendor bidding for a contract, is the Lead recused from the vendor-selection decision? Who decides? If a researcher suspects deliberate data misrepresentation by a peer (potential 'whistleblower' scenario), what is the reporting path—directly to red team, to EHS Officer, to Steering Committee, or to an external ethics hotline? Implementation Plan and Escalation Matrix are silent on these governance processes. Recommendation: Add a Governance Appendix defining (i) conflict-of-interest disclosure and recusal procedures for Steering Committee and key staff, (ii) anonymous whistleblower reporting channels (e.g., external ethics consultant hotline), (iii) investigation and remediation procedures for alleged data integrity violations or misconduct.
5. Potential Gap 3—Delegation of Authority Below Committee Level and Coordinators' Decision Rights: The framework defines decision authority at three levels: Director (<USD 500K), Steering Committee (USD 500K–2M), Funder (>USD 2M). However, the plan involves 80–120 FTE, implying dozens of team leads and coordinators (synthesis manager, pilot-line manager, characterization manager, data engineer, lab safety coordinator, finance controller, etc.). None of these roles have explicit delegated decision authority defined. Example: If the Pilot-Line Manager discovers a critical equipment failure costing USD 50K to repair and requiring 1-week downtime, can the Manager authorize the repair or must it escalate to the Chemistry Lead and Director? If the Synthesis Manager identifies a precursor supplier shortage and needs to authorize emergency expedited shipping (+USD 10K), what is the approval path? Clarification needed: Develop decision-authority matrix for key staff roles (Synthesis Manager, Pilot-Line Manager, Characterization Manager, Lab Safety Coordinator) specifying (i) decision types within their authority, (ii) thresholds (monetary or schedule impact), (iii) escalation triggers. Suggest: Synthesis Manager approves material purchases <USD 20K and routine operations; Pilot-Line Manager approves equipment maintenance <USD 50K and day-to-day scheduling; Characterization Manager approves partner scheduling and equipment time; Lab Safety Coordinator halts any unsafe operation unilaterally, escalates within 48 hours.
6. Potential Gap 4—Change Control and Scope-Deviation Process: The governance framework defines gates and milestone decisions but does not articulate a formal change-control process for mid-tranche scope changes or scope deviation requests. Example scenarios: At Month 20 (2028-06-14), a Chemistry Lead proposes adding a fourth active chemistry pathway (instead of three) based on promising early data from a collaboration. Or, a partner laboratory becomes unavailable and the programme must commission a new characterization facility on-site (USD 5–10M capital, 6-month build). Or, a major equipment supplier offers a significant discount if the programme doubles its order. The Escalation Matrix covers financial overruns and risk thresholds but does not specify approval workflow for mid-tranche scope additions or reductions. Recommendation: Define a Change Control Board (subset of Steering Committee: Director, Finance Manager, Chemistry Lead, red-team lead) with authority to approve scope additions <USD 5M or schedule impacts <4 weeks within current tranche; larger changes require full Steering Committee vote and Funder sign-off. Require a change-control form documenting: (i) justification, (ii) cost/schedule impact, (iii) risk assessment, (iv) approval signature.
7. Potential Gap 5—Stakeholder Communication and Regulator Engagement Protocols: The governance documents specify that the Chief EHS Officer engages Austin Fire Authority and TCEQ (Stage 3 implementation, Month 0–1 = 2026-10-14 to 2026-11-14), and that quarterly regulator meetings are held (Stage 2 EHS Office, meeting cadence). However, the framework does not define protocols for proactive regulator communication if programme decisions might affect compliance (e.g., if a chemistry pivots to lithium-metal synthesis not previously disclosed in Phase 1 permit, or if abuse-test results reveal thermal-runaway hazards requiring permit modification). Similarly, no protocol exists for managing regulator feedback into governance decisions. Example: What if the fire authority raises a concern about dry-room humidity control that requires a USD 1–2M retrofit? Is this escalated to Steering Committee as a permitting risk, or does EHS Officer have delegated authority to approve the retrofit? Recommendation: Define Regulator Engagement Protocol (part of Stage 2 EHS Office charter) specifying: (i) quarterly standing meetings with fire authority and TCEQ (documented agenda, minutes, action items), (ii) process for notifying regulators of significant scope changes (lithium-metal synthesis, abuse-chamber commissioning, waste-stream changes), (iii) escalation trigger if regulator feedback requires >USD 1M retrofit or >4-week delay, (iv) public transparency (e.g., annual EHS public statement to community and regulators per audit procedures).

## Tough Questions

1. By Month 12 (2027-10-14), what is the probability-weighted forecast for each of the three active chemistry pathways to achieve >=500 Wh/kg and >=950 Wh/L interim threshold by the Month 18 (2028-04-14) gate? If any pathway is projected <70% likelihood of gate pass, what is the contingency timeline and cost to activate the reserve chemistry or pivot to a fourth candidate?
2. Third-party verification at Month 30 (2029-04-14) requires >=3 independent replicates per finalist chemistry to meet >=500 Wh/kg AND >=950 Wh/L in the same cells with 90% of cells within ±10% tolerance. If in-house cell builds exhibit 15–20% Wh/kg variability (not the proposed 10%), will the programme's internal measurement methodology or pilot-line process control be deemed inadequate, forcing extended qualification before Month 30 (2029-04-14) gate? Who is responsible for reconciling in-house vs. third-party measurement discrepancies if they exceed ±5%?
3. The budget allocation assumes payroll of USD 8–12 M/yr (70 M over 7 years) for 80–120 FTE. If competitive salary pressure from Tesla and other Austin firms forces payroll to USD 12–14 M/yr (+USD 4–6 M/yr overrun, ~USD 28–42 M cumulative), which budget categories will be compressed—characterization instruments, pilot-line capital, partner co-funding absorption, or contingency reserves? What is the attrition threshold (proposed 15%/yr) that would trigger a mandatory compensation review and reallocation decision by Month 24 (2028-10-14)?
4. Permitting slippage of 6–8 months (plausible risk) pushes operational start from Month 3 (2027-01-14) to Month 9 (2027-07-14), reducing effective programme duration to 75–78 months. If this occurs and no contingency outsourced-synthesis agreement is pre-negotiated by Month 6 (2027-04-14), what is the recovery plan? Will the Month 18 (2028-04-14) gate be deferred to Month 24 (2028-10-14), or will chemistry selection proceed with limited or no pouch-cell data, risking non-verification until Month 60+ (2031-10-14)?
5. The staged chemistry tournament assumes three active pathways with clear differentiation (e.g., lithium-sulfur, anode-free solid-state, conversion cathode). If by Month 12 (2027-10-14) early data shows all three pathways converging on the same electrolyte chemistry and cell-design requirements (e.g., all three benefit from identical ionic-liquid electrolyte, making them variants of one approach rather than independent hedges), does the Steering Committee have authority to collapse the three teams into one and redirect freed budget to a true reserve chemistry? Who decides and when?
6. The 1000 Wh/L volumetric target is treated as an interim 950 Wh/L threshold at Month 30 (2029-04-14) but a hard 1000 Wh/L final requirement at Month 72 (2032-10-14). If the winning chemistry demonstrably hits >=500 Wh/kg but maxes out at 880–920 Wh/L due to fundamental separator thickness and electrolyte-volume constraints, is the programme authorized to descope the volumetric target and deliver a partial success (500+ Wh/kg, ~900 Wh/L, >=300 cycles)? What is the Steering Committee's and Funder's acceptance threshold for 'missing' one of the two headline targets?
7. Red-team verification authority includes the right to delay gate decisions up to 3 weeks for independent validation, and to recommend chemistry deprioritization if replication fails. If at Month 36 (2029-10-14) the red team's replication results contradict the chemistry team's claimed Wh/kg by >10% (red team measures 480 Wh/kg, chemistry team claims 510 Wh/kg), and the chemistry team contests the red team's cell-build methodology or measurement calibration, how is the dispute resolved? Does the red-team finding override the chemistry-team claim (as stated in Stage 2 red-team decision_rights), or does Steering Committee arbitration occur? What is the escalation path if disagreement persists and jeopardizes the Month 36 (2029-10-14) gate decision timeline?

## Summary

The governance framework for a seven-year, USD 300M battery-invention programme balances hedged chemistry risk (staged tournament with formal gates at Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), rigorous system-level discipline (cell-level mass-and-volume model, dual energy-density thresholds from Month 12 = 2027-10-14), and pragmatic cost control (modular leased pilot line, partner co-funding, evidence-linked tranche release). Core strengths include clear Scientific Steering Committee decision authority, independent red-team verification to protect data integrity, phased permitting and EHS governance to de-risk regulatory slippage, and formal contingency planning for chemistry failure. The USD 20M reserve (inside the USD 300M cap) and USD 15M pivot runway preserve flexibility for mid-programme redirection if a leading chemistry fails by Month 30–36 (2029-04-14 to 2029-10-14). Cycle-life (>=300 cycles at 80% retention) and safety (thermal-runaway onset >=120°C) are hardened as gate criteria from Month 3 (2027-01-14) onwards, preventing descent into non-commercial dead ends. Technology transfer planning begins by Month 60 (2031-10-14) and concludes by Month 84 (2033-10-14), aligned with the non-commercial, invention-focused objective. Identified governance gaps—clarity of Project Sponsor authority, conflict-of-interest and whistleblower procedures, delegated authority for team coordinators, change-control process, and regulator communication protocol—are addressable through governance-procedure appendices without reshaping the core structure. Financial viability depends on (i) permitting not slipping >6 months, (ii) payroll not exceeding USD 12M/yr ceiling, (iii) at least one reserve chemistry pre-staged by Month 24 (2028-10-14) to enable 4–6 week pivots if two active chemistries fail, and (iv) partner cost-sharing sustaining >=15% of shared costs. The framework is fit-for-purpose for a capital-constrained, high-ambition, 84-month invention programme with strong emphasis on early risk identification, independent validation, and preserving optionality through formal gates.