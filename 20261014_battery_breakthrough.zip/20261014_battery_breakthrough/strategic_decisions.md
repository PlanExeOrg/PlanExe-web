## Primary Decisions
The vital few decisions that have the most impact.


The Critical and High levers address the central tensions of focus versus hedging (Chemistry Pathway, Electrolyte and Interface, Funding Rhythm), rigor versus speed (Cell-Level Proof Standard, Discovery Engine), and capital ownership versus flexibility (Pilot Line, Cell Format). Talent and IP position covers the Austin siting trade-off. Missing dimensions include explicit stage-gate go/no-go criteria, a minimum cycle-life threshold, and a manufacturability or supply-chain lens for the eventual technology transfer.

### Decision 1: Chemistry Pathway Commitment
**Lever ID:** `9518e73b-0646-4ad8-a58a-9b44baed510b`

**The Core Decision:** Selects the core cell chemistry that determines whether the 500 Wh/kg and 1000 Wh/L targets are physically reachable and which unsolved problems the programme inherits. Scope covers anode, cathode and catholyte pairing plus the timing of any narrowing. Success metrics: projected cell-level Wh/kg and Wh/L headroom, and the cost and time of any pivot.

**Why It Matters:** Choosing the core chemistry determines whether 500 Wh/kg is reachable at cell level and what failure modes the programme inherits. Lithium-metal-anode systems, sulfur or conversion cathodes, and anode-free architectures each carry different cycle-life, swelling and volumetric-density penalties. Early commitment saves money but locks the programme into one set of unsolved problems.

**Strategic Choices:**

1. Commit the full budget to a lithium-metal anode paired with a high-nickel or lithium-rich layered oxide cathode, accepting an incremental but better-understood route to the gravimetric target.
2. Run a staged tournament across three or four radically different chemistries, such as lithium-sulfur, anode-free solid-state and conversion cathodes, and cut to one finalist at a formal mid-programme gate.
3. Target a deliberately non-obvious hybrid cell, for example a prelithiated silicon-carbon composite anode with a halide-conducting catholyte, that trades the usual lithium-metal risk for interface-engineering risk.

**Trade-Off / Risk:** Picking a single chemistry early concentrates funding where progress is fastest, but a 500 Wh/kg cell may require a combination nobody has yet stabilized, so premature lock-in could burn years on a dead end.

**Strategic Connections:**

**Synergy:** Directly shapes Electrolyte and Interface Architecture, since each chemistry implies a viable electrolyte class, and sets the target list for the Discovery Engine so screening effort concentrates on the committed material space.

**Conflict:** Early lock-in competes with Funding Release Rhythm and Contingency Reserve and Competing-Team Structure and Internal Red Team: a staged tournament or parallel teams consume budget that a single-chemistry commitment would otherwise concentrate.

**Justification:** *Critical*, Critical because it decides whether 500 Wh/kg and 1000 Wh/L are physically reachable. It is a hub driving Electrolyte and Interface Architecture, Discovery Engine targets, and Cell Format, and it controls the core focus-versus-hedging trade-off against team structure and reserve.

### Decision 2: Electrolyte and Interface Architecture
**Lever ID:** `3347dd04-d7e9-4a9f-8250-5a951c12733b`

**The Core Decision:** Defines the ion-conducting medium and the interphases that govern cycle life, lithium-metal reversibility and thermal behaviour. Scope spans solid, liquid, gel and hybrid concepts, including stack-pressure hardware and separator thickness that erode cell-level density. Success metrics: interfacial resistance, Coulombic efficiency, cycle retention at cell level and added inactive mass per cell.

**Why It Matters:** The electrolyte and the interphase it forms with a lithium-rich anode or high-voltage cathode usually set cycle life and safety. Solid, liquid and hybrid choices differ in processability, stack pressure needs and dry-room requirements. The choice shapes both the materials-science effort and the pilot-line equipment list.

**Strategic Choices:**

1. Develop a sulfide or halide solid electrolyte separator, accepting dry-room handling, high stack-pressure requirements and a new pilot-line process in exchange for lithium-metal compatibility.
2. Engineer a liquid or gel electrolyte using localized high-concentration salts and fluorinated solvents, keeping conventional cell assembly while pushing voltage and lithium-metal reversibility.
3. Build a layered hybrid with a thin ceramic or polymer interlayer protecting the lithium surface inside a minimal-volume liquid electrolyte, optimizing each interface separately rather than one bulk material.

**Trade-Off / Risk:** Solid electrolytes promise safety and lithium-metal compatibility, yet thick separators and pressure hardware can erode the very Wh/kg and Wh/L gains they are meant to unlock at cell level.

**Strategic Connections:**

**Synergy:** Amplifies Abuse Tolerance and Safety Strategy because non-flammable or inorganic electrolytes deliver intrinsic safety, and defines the equipment list for Pilot Line Philosophy and Dry-Room Footprint and Cell Format and Stack Architecture.

**Conflict:** Solid-electrolyte routes with dry-room and high-pressure needs strain Pilot Line Philosophy and Dry-Room Footprint and Hazardous Materials Permitting and EHS Operating Model, and thick separators can undercut targets set by the Cell-Level Proof Standard.

**Justification:** *Critical*, Critical because the electrolyte and interphase set cycle life, safety and lithium-metal reversibility, and define equipment needs for the pilot line, cell format and permitting. Highly connected hub whose density penalty (separators, pressure hardware) directly threatens the targets.

### Decision 3: Discovery Engine: Simulation, Autonomy and Bench Work
**Lever ID:** `6c92fe27-64cd-4b4d-84a7-c3c515c566c0`

**The Core Decision:** Sets the mix of computational prediction, robotic experimentation and manual bench synthesis that governs candidate throughput and how fast hypotheses are falsified. Scope includes software, automation capital, staffing mix and partner outsourcing. Success metrics: candidates screened per year, share of predictions validated experimentally, and time from hypothesis to cell-level evidence rather than raw screening counts.

**Why It Matters:** The balance between computation, automated experimentation and manual synthesis sets how many candidate materials can be screened per year and how fast hypotheses are falsified. Heavy automation front-loads capital and software spending and may shift staffing away from experienced bench electrochemists. Computed predictions of interfacial stability still need physical validation, so the loop is only as good as its measurement fidelity.

**Strategic Choices:**

1. Invest in a closed-loop self-driving laboratory that couples machine-learning proposal of materials with robotic synthesis and electrochemical screening, concentrating spending on throughput early in the programme.
2. Keep a conventional team of bench scientists augmented by outsourced simulation and commercial materials databases, preserving flexibility and avoiding large automation commitments.
3. Fund a split structure in which an in-house computational group generates ranked candidates but validation is outsourced to university and national-laboratory partners, converting fixed cost into variable cost.

**Trade-Off / Risk:** Automation multiplies screening throughput only if the bottleneck is candidate count; if the real limit is interface degradation over hundreds of cycles, faster screening produces more hypotheses without producing a better cell.

**Strategic Connections:**

**Synergy:** Feeds Chemistry Pathway Commitment with ranked candidates and works with Characterization Access and Failure Forensics Model, because high-fidelity measurement closes the loop and keeps computed interfacial predictions honest.

**Conflict:** Heavy automation capital competes for budget with Pilot Line Philosophy and Dry-Room Footprint and Funding Release Rhythm and Contingency Reserve, and may displace experienced bench electrochemists needed for interface and cycle-life work.

**Justification:** *High*, Governs the throughput versus capital trade-off and feeds ranked candidates into chemistry choice. Strong ties to characterization, but its value depends on the interface-degradation bottleneck, so it is less foundational than chemistry and electrolyte.

### Decision 4: Cell-Level Proof Standard
**Lever ID:** `af90a1b4-e9e3-40dd-815d-a5e0621708ea`

**The Core Decision:** Defines what counts as success: the cell format, capacity, cycle count, rate and independent measurement required before a Wh/kg or Wh/L figure is credited. It is the guard against material-level numbers that vanish after packaging and inactive-mass overhead. Success metrics: stated minimum cycle life (proposed threshold needed), third-party verified cell energy density, and reproducibility across builds.

**Why It Matters:** Material-level energy density can look strong while pouch-cell Wh/kg collapses once current collectors, packaging, electrolyte mass and cell-to-cell overhead are included. The standard chosen defines what counts as success and how quickly the team confronts engineering reality. A strict standard slows headline results but prevents claiming an invention that cannot be built.

**Strategic Choices:**

1. Define success as a multi-layer pouch cell at a stated capacity with cycle-count and rate requirements, independently measured by a third-party test laboratory, from the first year of the programme.
2. Progress through coin-cell and small single-layer pouch demonstrations first, adopting full-size cell verification only in the final two years once chemistry is stabilized.
3. Adopt a dual-track metric in which a dedicated engineering team builds a mass-and-volume cell model from the start, back-calculating the material-level targets every candidate must hit.

**Trade-Off / Risk:** A strict cell-level standard exposes hidden packaging and inactive-mass penalties early, but without a stated minimum cycle life a one-cycle 500 Wh/kg cell would meet the letter of the goal while being useless.

**Strategic Connections:**

**Synergy:** Strengthens Reference Application Anchor by providing a measurable target tied to a real use case, and disciplines Cell Format and Stack Architecture by forcing early mass-and-volume accounting.

**Conflict:** A strict early pouch-cell standard collides with Discovery Engine: Simulation, Autonomy and Bench Work, whose coin-cell screening is faster, and with Funding Release Rhythm and Contingency Reserve through the earlier fabrication and third-party testing costs.

**Justification:** *Critical*, Critical because it defines what counts as success and guards against material-level numbers that vanish at cell level. It links the application anchor, cell format, red team and funding gates, and controls the speed versus rigor trade-off.

### Decision 5: Ecosystem, Talent and IP Position
**Lever ID:** `f1288f3a-332f-4883-9bb1-65c3a83ede7b`

**The Core Decision:** Sets how the programme recruits, collaborates and protects inventions while sited beside a large commercial battery employer. It covers hiring tactics, clean-room rules for incoming staff, university and national-laboratory ties, and patent scope and timing. Success metrics: time-to-fill for key scientist roles, attrition rate, IP-contamination incidents, and a defensible, licensable patent estate by the end of the programme.

**Why It Matters:** Locating near Tesla in Austin offers access to battery engineers and suppliers but also exposes the programme to talent competition and to potential IP entanglement with a neighbouring commercial player. How the programme shares or protects inventions determines both recruitment appeal and the invention's eventual value. The non-commercial aim allows open collaboration that a market-seeking firm could not afford.

**Strategic Choices:**

1. Recruit aggressively from the Austin battery and automotive community with equity-like retention incentives, and file broad patents with strict clean-room protocols for employees arriving from competitors.
2. Anchor the programme in formal partnerships with university and national-laboratory groups, sharing pre-competitive findings openly and patenting only the final integrated cell architecture and processes.
3. Structure the programme as a licensing-oriented invention entity that deliberately develops the technology to demonstration and then transfers it to an established manufacturer, with IP terms negotiated early.

**Trade-Off / Risk:** Proximity to a large employer eases hiring but also sets the salary benchmark and raises poaching and contamination risk; open collaboration attracts talent yet may weaken the exclusive patent position that gives the invention value.

**Strategic Connections:**

**Synergy:** Amplifies Characterization Access and Failure Forensics Model, since university and national-laboratory partnerships supply instrument access and expertise. Also strengthens Funding Release Rhythm and Contingency Reserve by opening co-investment and matched-grant channels.

**Conflict:** Open pre-competitive sharing conflicts with Pilot Line Philosophy and Dry-Room Footprint when unpublished materials run on third-party lines, and with Reference Application Anchor if early IP terms constrain which application partner is chosen.

**Justification:** *High*, Governs the talent and IP trade-offs of siting beside Tesla, affecting recruitment, partner access to instruments, co-funding and the licensable value of the invention. Multiple connections, but secondary to technical pathway levers.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Abuse Tolerance and Safety Strategy
**Lever ID:** `a75fa7e7-5a14-4f39-800e-f4fedab51698`

**The Core Decision:** Determines when and how thermal runaway, short-circuit and overcharge behaviour are evaluated, and whether safety is a selection criterion or a late certification step. Scope covers in-house versus contracted testing, intrinsic-safety design and test infrastructure. Success metrics: onset temperature, heat release and propagation behaviour at cell level, and the number of candidates eliminated early for safety.

**Why It Matters:** High-energy lithium-rich cells concentrate stored energy and typically worsen thermal runaway behaviour, so safety choices affect chemistry, cell design and test infrastructure. Treating safety as a late certification step risks discovering fundamental flaws after years of development. Early abuse testing consumes budget and specialist staff but narrows the viable design space sooner.

**Strategic Choices:**

1. Build an in-house abuse-testing facility with calorimetry, nail-penetration and overcharge chambers from the first year, so every candidate chemistry is ranked on safety alongside energy density.
2. Contract an accredited external laboratory for periodic abuse testing at key milestones, keeping internal capital for synthesis and cell fabrication equipment.
3. Design intrinsic safety into the chemistry itself by prioritizing non-flammable or inorganic electrolytes and thermally stable cathodes, using abuse testing mainly to confirm rather than to select.

**Trade-Off / Risk:** Early safety screening avoids late surprises, but an in-house abuse facility is a fixed cost with its own site permitting and hazard-handling burden that may be underused in a research programme.

**Strategic Connections:**

**Synergy:** Works with Electrolyte and Interface Architecture, where non-flammable electrolyte choices build in safety, and with Characterization Access and Failure Forensics Model, since abuse-test failures supply root-cause evidence for redesign.

**Conflict:** An in-house abuse facility conflicts with Hazardous Materials Permitting and EHS Operating Model through added site permitting and hazard burden, and draws capital from Pilot Line Philosophy and Dry-Room Footprint and synthesis equipment.

**Justification:** *Medium*, Important for narrowing the design space early and ties to electrolyte, forensics and permitting, but largely a derivative of chemistry and electrolyte choices. Mostly optimization of when and where testing is done rather than a core pillar.

### Decision 7: Pilot Line Philosophy and Dry-Room Footprint
**Lever ID:** `538f4517-7f50-46c6-8be9-5648e42ac7d6`

**The Core Decision:** Decides whether cell fabrication capability is owned, leased or modular, and thereby how many cell builds per month the programme can sustain. It governs dry-room dew point control, electrode coating, stacking and formation equipment, and commissioning lead time. Success metrics: cell-to-cell reproducibility, build turnaround days, capital committed before chemistry selection, and residual resale or reuse value of equipment.

**Why It Matters:** Determines whether the programme builds its own dry-room and electrode-to-cell pilot line, leases shared space, or relies on partner lines. Owning the line gives control of process variables and cell reproducibility, but capital and commissioning time are drawn from a fixed USD 300 M budget before any chemistry is proven. Renting capacity preserves cash but exposes unpublished materials to third-party schedules and process constraints.

**Strategic Choices:**

1. Build a dedicated research-scale dry-room and pouch-cell line in the Austin area, sized for hundreds of cells per month (estimate) and operated entirely in-house.
2. Lease space and equipment time at existing university, national-laboratory or contract pilot facilities, and concentrate programme capital on characterization instruments and staff.
3. Stand up a modular, relocatable dry-room line in containerized units that can be expanded, moved or sold once a winning chemistry is identified.

**Trade-Off / Risk:** A dedicated line locks in capital and lead time before the chemistry is known, while leased capacity trades control and confidentiality for flexibility; the wrong choice either strands equipment or throttles iteration speed.

**Strategic Connections:**

**Synergy:** Enables Cell-Level Proof Standard by giving controlled, reproducible builds, and supports Cell Format and Stack Architecture because in-house or modular lines can execute bipolar or pressure-managed formats that external lines may not offer.

**Conflict:** Draws fixed capital that competes with Characterization Access and Failure Forensics Model and Funding Release Rhythm and Contingency Reserve; early line commitment also narrows flexibility in Chemistry Pathway Commitment if the winning chemistry needs different dry-room conditions.

**Justification:** *High*, Controls the largest capital commitment before chemistry is proven, build cadence and reproducibility. Conflicts with chemistry flexibility, funding, characterization and safety, making it a major owned-versus-leased trade-off hub.

### Decision 8: Cell Format and Stack Architecture
**Lever ID:** `320f013c-7d73-40ec-9fa7-fb9f11bfd80e`

**The Core Decision:** Chooses the physical cell construction that determines how much active material survives packaging, current collectors, separators and pressure hardware. It largely sets the translation from material-level gains to cell-level Wh/kg and Wh/L. Success metrics: inactive-mass fraction, achieved cell-level energy density versus the 500 Wh/kg and 1000 Wh/L goals, build yield, and comparability against published benchmark cells.

**Why It Matters:** Selects the physical cell construction: conventional wound or stacked pouch, bipolar stacking, anode-free layouts, or pressure-managed formats. Inactive mass and volume (current collectors, separators, packaging, pressure hardware) largely decide whether chemistry-level gains survive at cell level and whether 1000 Wh/L is reachable. Exotic formats improve the numbers on paper but complicate fabrication and make results harder to compare with industry benchmarks.

**Strategic Choices:**

1. Standardize on a conventional multilayer pouch format so material changes are isolated and results compare directly with published cells.
2. Co-design the chemistry with a bipolar or anode-free stack architecture from the start, accepting a harder fabrication path for higher achievable cell-level density.
3. Run two formats in parallel: a plain pouch as the reference and a pressure-managed high-density format for the best chemistry candidates only.

**Trade-Off / Risk:** Format choice quietly sets the ceiling on cell-level Wh/kg and Wh/L, yet an aggressive architecture can bury a good chemistry under fabrication defects that are misread as materials failure.

**Strategic Connections:**

**Synergy:** Works with Chemistry Pathway Commitment, since anode-free or bipolar layouts unlock lithium-metal and high-voltage chemistries, and with Cell-Level Proof Standard, where a stable reference format makes density claims credible and comparable.

**Conflict:** Aggressive architectures strain Pilot Line Philosophy and Dry-Room Footprint through unfamiliar fabrication steps, and complicate Abuse Tolerance and Safety Strategy because dense, pressure-managed stacks change thermal runaway behavior and test protocols.

**Justification:** *High*, Sets the ceiling on translating material gains into cell-level Wh/kg and Wh/L, especially the 1000 Wh/L goal. Interacts with chemistry, proof standard, pilot line and safety, though it is partly derivative of chemistry commitment.

### Decision 9: Funding Release Rhythm and Contingency Reserve
**Lever ID:** `2508164a-e707-43a6-8d53-66fa89195ddb`

**The Core Decision:** Controls the timing, conditionality and reserve of the USD 300 M (user constraint) across seven years. It determines the balance between early capital build-out and later pivot capacity, and how stage gates are tied to evidence. Success metrics: reserve utilization, share of budget spent on experiments versus infrastructure, time to redirect funds after a failed gate, and absence of mid-programme funding gaps.

**Why It Matters:** Governs how the USD 300 M is released and held across the seven years: front-loaded for capital and hiring, spread evenly, or tied to technical evidence. Front-loading buys facilities and talent early but reduces capacity to redirect if the leading chemistry fails. A held reserve improves resilience to surprises but leaves money idle while competing groups progress.

**Strategic Choices:**

1. Release funds on a fixed annual schedule with a modest unallocated reserve (proposed threshold), prioritizing team stability and predictable operations.
2. Tie each tranche of funding to demonstrated technical evidence, keeping a large uncommitted pool for opportunistic pivots or acquisition of new approaches.
3. Commit most capital to facilities and core staff early, then fund later years through externally matched grants and partner co-investment.

**Trade-Off / Risk:** Evidence-linked release disciplines the programme but can starve slow-maturing breakthroughs, while fixed schedules protect continuity at the risk of funding a failing path to its end.

**Strategic Connections:**

**Synergy:** Amplifies Competing-Team Structure and Internal Red Team by letting funds shift toward the best-performing team, and reinforces Cell-Level Proof Standard by making tranche release depend on verified cell-level evidence.

**Conflict:** Evidence-gated or reserve-heavy release conflicts with Pilot Line Philosophy and Dry-Room Footprint, which needs early capital, and with Ecosystem, Talent and IP Position, where retention incentives require predictable funding.

**Justification:** *High*, Controls how the fixed budget is deployed between capital build-out and pivot capacity. Conflicts with pilot line, talent retention and chemistry lock-in, and supplies the evidence-gating mechanism, making it a key budget trade-off hub.

### Decision 10: Characterization Access and Failure Forensics Model
**Lever ID:** `e8ea0b06-4597-4cbc-80b6-b6ca8fcd9937`

**The Core Decision:** Defines how quickly and deeply the programme learns from failed cells through operando diagnostics, post-mortem analysis and structured autopsy practice. It affects the cadence of the design-build-test loop and the team's ability to separate interface, transport and mechanical failure modes. Success metrics: days from failure to root-cause report, instrument utilization, share of failures with an assigned mechanism, and design changes traced to forensics.

**Why It Matters:** Determines how the program obtains operando and post-mortem insight into why cells fail: owned instruments, shared national facilities, or vendor services. In-house tools shorten the loop between a failed cell and the next experiment, while external access gives broader capability but adds queue time and scheduling dependence. The model shapes how quickly mechanisms are understood and whether the team can distinguish interface, transport and mechanical failure.

**Strategic Choices:**

1. Acquire a core set of in-house operando and post-mortem instruments so that failed cells are analyzed within days and feed directly into the next build cycle.
2. Rely on standing agreements with university, national laboratory and vendor facilities for advanced characterization, and keep in-house capability limited to routine analysis.
3. Run a dedicated forensics team that dissects every failed cell using a standardized autopsy protocol and publishes an internal failure-mode atlas that gates new designs.

**Trade-Off / Risk:** Owning instruments accelerates learning but consumes capital and specialist staff that may sit idle between campaigns, while outsourcing saves money but makes the slowest external queue the effective pace of the whole discovery loop.

**Strategic Connections:**

**Synergy:** Amplifies Electrolyte and Interface Architecture, because interface degradation is often only visible through operando and post-mortem analysis, and Discovery Engine: Simulation, Autonomy and Bench Work, which needs failure data to calibrate models.

**Conflict:** Owning instruments competes for capital and specialist staff with Pilot Line Philosophy and Dry-Room Footprint and Funding Release Rhythm and Contingency Reserve, while external access depends on partners shaped by Ecosystem, Talent and IP Position.

**Justification:** *Medium*, Sets the learning loop speed and amplifies electrolyte and discovery work, but it is an enabling capability whose capital competes with the pilot line. Valuable for optimization, with partner access as an alternative.

### Decision 11: Reference Application Anchor
**Lever ID:** `8fe60c1a-aeeb-42f2-b9cf-8e131f627479`

**The Core Decision:** Selects the duty profile that turns the 500 Wh/kg and 1000 Wh/L headline targets into testable conditions: C-rate, temperature window, cycle count, pack-level mass allowances and form factor. Success is measured by a written specification with pass/fail thresholds, a defined lock gate if deferred, and cell data collected under those exact conditions rather than best-case laboratory protocols.

**Why It Matters:** Chooses which real use case defines the operating conditions behind the headline energy targets, such as aviation, drones, premium vehicles or portable devices. The anchor sets discharge rate, temperature window, cycle life and form factor, which in turn steer chemistry and cell design trade-offs. A weak anchor risks optimizing a cell for a spec sheet nobody needs, while a narrow anchor may exclude broader uses.

**Strategic Choices:**

1. Anchor the program on a weight-critical use such as electric aviation or unmanned aircraft, accepting limited cycle life and rate demands in exchange for the highest gravimetric payoff.
2. Anchor on a mass-market electric-vehicle duty profile, with moderate rate, wide temperature and long-life expectations that constrain how aggressively energy density can be pursued.
3. Hold the anchor open for the first phase and let early cell data reveal which application set the chemistry naturally fits, then lock the specification at a defined gate.

**Trade-Off / Risk:** A concrete application makes trade-offs decidable, but committing early may lock the team into a duty profile the eventual chemistry cannot serve, while leaving it open invites spec drift and unfalsifiable progress claims.

**Strategic Connections:**

**Synergy:** Gives Chemistry Pathway Commitment and Cell-Level Proof Standard a concrete target: the duty profile decides which chemistries are plausible and defines the test protocol that proof of 500 Wh/kg must use. It also guides Cell Format and Stack Architecture.

**Conflict:** A demanding anchor such as mass-market EV duty (long life, wide temperature) constrains Chemistry Pathway Commitment and Abuse Tolerance and Safety Strategy, since aggressive energy density usually trades against cycle life and thermal margin. Holding it open delays Cell Format and Stack Architecture decisions.

**Justification:** *Medium*, Provides duty-profile conditions that make trade-offs decidable and guides chemistry, proof standard and format. Largely a specification input that could be deferred to a gate, so less central than the structural technical levers.

### Decision 12: Competing-Team Structure and Internal Red Team
**Lever ID:** `2a46f59b-22c0-4f62-9354-ba9388a5eb89`

**The Core Decision:** Sets the organizational architecture for scientific risk: a single integrated team, parallel rival teams, or a standing verification group with authority over reported results. Key metrics include time to first verified cell-level result, share of claims surviving independent replication, staff retention, and equipment utilization. Clear decision rights between leads, verifiers and funders determine whether rivalry or scrutiny improves outcomes or merely adds friction.

**Why It Matters:** Decides how researchers are organized: one integrated team, several teams pursuing rival approaches, or a standing group whose job is to disprove claims. Competing teams create internal pressure and hedge scientific risk but duplicate equipment and dilute scarce expertise. A red team improves claim credibility but can slow morale and decision speed if its authority is unclear.

**Strategic Choices:**

1. Organize into one integrated team with a single technical lead, concentrating scarce expertise and equipment on a single path to the target.
2. Form two or three semi-independent teams with separate leads and shared infrastructure, rewarding whichever reaches verified cell-level data first.
3. Create a permanent adversarial verification group with authority to replicate, challenge and reject internal results before they are reported to funders or used in patents.

**Trade-Off / Risk:** Rivalry between teams hedges against a single wrong bet, but in a field with a small talent pool near Austin the duplication may starve each team below the critical mass needed to reach 500 Wh/kg.

**Strategic Connections:**

**Synergy:** Strengthens Cell-Level Proof Standard by giving it an independent enforcer, and pairs with Chemistry Pathway Commitment, since parallel teams can pursue different chemistries and shared Characterization Access and Failure Forensics Model supplies common, neutral measurement.

**Conflict:** Parallel teams strain Ecosystem, Talent and IP Position because the small Austin talent pool is split, and compete for Pilot Line Philosophy and Dry-Room Footprint capacity and Funding Release Rhythm and Contingency Reserve budget through duplicated equipment.

**Justification:** *Medium*, Governs how scientific risk is organized (hedging versus concentration), pairing with chemistry and proof standard. Its verification function partly overlaps with the Cell-Level Proof Standard, and the small talent pool limits parallel teams.

### Decision 13: Hazardous Materials Permitting and EHS Operating Model
**Lever ID:** `161796be-a8eb-4be3-8054-9694e1796ca6`

**The Core Decision:** Establishes how reactive metals, flammable electrolytes, toxic precursors and waste are permitted, handled and owned across city, state and federal regimes, and who is accountable for incidents. Success is measured by permit lead time, zero reportable incidents, uninterrupted lab operations, insurance terms and the range of chemistries that can legitimately be synthesized and cycled on site rather than outsourced.

**Why It Matters:** Defines how the program handles reactive metals, flammable solvents, toxic precursors and waste under local, state and federal rules, and who holds accountability for them. A conservative model reduces incident and permit risk but limits which chemistries and scales can be run on site. A permissive model widens the experimental window but increases exposure to shutdowns, insurance cost and community or regulator scrutiny.

**Strategic Choices:**

1. Adopt a conservative operating envelope that excludes the most hazardous reagents and quantities from the Austin site, and outsource those steps to licensed external facilities.
2. Build a full in-house environmental, health and safety function with its own permits, waste handling and emergency response so that reactive-material work stays on campus.
3. Engage regulators and the local fire authority early to co-design site protocols and share monitoring data, treating permitting as a collaborative design input rather than a gate.

**Trade-Off / Risk:** Tight hazard limits protect schedule from a serious incident, but they can quietly exclude the very reactive chemistries most likely to reach 500 Wh/kg, shifting risk from safety into scientific ambition.

**Strategic Connections:**

**Synergy:** Enables Pilot Line Philosophy and Dry-Room Footprint by clarifying which materials and quantities the facility may hold, and supports Abuse Tolerance and Safety Strategy since abuse testing of high-energy cells needs permitted chambers and emergency response already in place.

**Conflict:** A conservative envelope constrains Chemistry Pathway Commitment and Electrolyte and Interface Architecture by excluding reactive options such as lithium metal or aggressive solvents. In-house EHS build-out also competes with Funding Release Rhythm and Contingency Reserve for early money and schedule.

**Justification:** *Medium*, A gating constraint that can exclude reactive chemistries and affects pilot line and safety testing, but it is largely an enabling and compliance function. Matters for schedule risk more than for the core technical pathway.
