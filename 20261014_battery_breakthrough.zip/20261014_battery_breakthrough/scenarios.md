# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** High technical ambition: a rechargeable cell at >=500 Wh/kg and >=1000 Wh/L (user constraints), well beyond today's commercial cells. Organisational scale is modest: a single Austin R&D campus, USD 300 M over 7 years (user constraint), explicitly not an industrial or market-dominance play.

**Risk and Novelty:** Highly novel and high risk. Reaching both targets at cell level likely requires an interface/chemistry combination not yet stabilized, and a material-level number can collapse after packaging overhead. The risk of dead-end chemistry and of a cell that meets the letter of the goal but has poor cycle life is substantial.

**Complexity and Constraints:** Complex and physical: wet-chemistry labs, dry rooms, pilot-line cell fabrication, abuse testing and third-party verification. The budget is fixed and modest for automation, a new solid-state pilot line and early third-party testing combined. Proximity to Tesla creates talent competition and IP-contamination exposure. Start is immediate.

**Domain and Tone:** Applied strategic R&D in electrochemistry and materials science; business-framed but invention-oriented, with a pragmatic, non-commercial tone that favours collaboration and a defensible, licensable result.

**Holistic Profile:** A capital-constrained, high-ambition, non-commercial invention programme where the main danger is betting the whole budget on one unproven chemistry or on one expensive operating model. It needs hedged chemistry exploration, early system-level accounting of mass and volume, cost-efficient access to characterization and talent, and IP sufficient to enable later licensing.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Hedges chemistry risk with a staged tournament and a formal mid-programme gate, while a cell-level mass-and-volume model keeps every candidate honest about system-level Wh/kg and Wh/L. A layered hybrid interface, a split in-house/partner discovery structure and university and national-laboratory partnerships balance ambition against fixed cost and keep Austin talent and IP exposure manageable.

**Fit Score:** 8/10

**Why This Path Was Chosen:** Hedges unsolved chemistry risk with a staged tournament and gate, imposes system-level mass/volume discipline from the start, and converts fixed cost to variable cost via partners. Fits a capped budget and an invention-not-industrialization goal; weaker on full-cell proof timing and exclusive IP.

**Key Strategic Decisions:**

- **Chemistry Pathway Commitment:** Run a staged tournament across three or four radically different chemistries, such as lithium-sulfur, anode-free solid-state and conversion cathodes, and cut to one finalist at a formal mid-programme gate.
- **Electrolyte and Interface Architecture:** Build a layered hybrid with a thin ceramic or polymer interlayer protecting the lithium surface inside a minimal-volume liquid electrolyte, optimizing each interface separately rather than one bulk material.
- **Discovery Engine: Simulation, Autonomy and Bench Work:** Fund a split structure in which an in-house computational group generates ranked candidates but validation is outsourced to university and national-laboratory partners, converting fixed cost into variable cost.
- **Cell-Level Proof Standard:** Adopt a dual-track metric in which a dedicated engineering team builds a mass-and-volume cell model from the start, back-calculating the material-level targets every candidate must hit.
- **Ecosystem, Talent and IP Position:** Anchor the programme in formal partnerships with university and national-laboratory groups, sharing pre-competitive findings openly and patenting only the final integrated cell architecture and processes.

**The Decisive Factors:**

- **Matches risk profile:** the 500 Wh/kg and 1000 Wh/L targets may need a combination nobody has stabilized; a staged tournament with a formal gate hedges that, while the cell-level mass-and-volume model exposes packaging penalties early.
- **Fits budget and mandate:** the split in-house/partner discovery structure turns fixed cost into variable cost, and open university and national-laboratory partnerships suit an invention-focused, non-market-dominance goal within USD 300 M.
- **Pioneer's Gambit rejected:** it stacks automation capital, a new solid-state pilot line, year-one third-party pouch testing and aggressive hiring on one unhedged chemistry bet, so burn rate and dead-end exposure are too high.
- **Disciplined Ascent rejected:** an incremental single route with late full-size verification risks missing 1000 Wh/L and discovering failure too late.
- **Recommended safeguard:** add a minimum cycle-life requirement (proposed) and earlier pouch-cell verification before the gate.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Bets on a non-obvious hybrid cell with a solid-state interface and a self-driving laboratory to compress the discovery cycle, and applies strict third-party pouch-cell proof from the first year so inactive-mass penalties surface immediately. Aggressive Austin talent recruitment and broad patenting build an exclusive IP position, accepting high burn rate, interface-engineering risk and poaching/contamination exposure for the highest chance of a genuine step change.

**Fit Score:** 5/10

**Assessment of this Path:** Offers the highest ceiling and strong early cell-level honesty, but a self-driving lab, a new solid-state pilot line, year-one third-party pouch testing and aggressive hiring would strain a USD 300 M budget, and a single non-obvious chemistry bet has no hedge. Broad-patent and poaching posture is also at odds with the non-commercial aim.

**Key Strategic Decisions:**

- **Chemistry Pathway Commitment:** Target a deliberately non-obvious hybrid cell, for example a prelithiated silicon-carbon composite anode with a halide-conducting catholyte, that trades the usual lithium-metal risk for interface-engineering risk.
- **Electrolyte and Interface Architecture:** Develop a sulfide or halide solid electrolyte separator, accepting dry-room handling, high stack-pressure requirements and a new pilot-line process in exchange for lithium-metal compatibility.
- **Discovery Engine: Simulation, Autonomy and Bench Work:** Invest in a closed-loop self-driving laboratory that couples machine-learning proposal of materials with robotic synthesis and electrochemical screening, concentrating spending on throughput early in the programme.
- **Cell-Level Proof Standard:** Define success as a multi-layer pouch cell at a stated capacity with cycle-count and rate requirements, independently measured by a third-party test laboratory, from the first year of the programme.
- **Ecosystem, Talent and IP Position:** Recruit aggressively from the Austin battery and automotive community with equity-like retention incentives, and file broad patents with strict clean-room protocols for employees arriving from competitors.

### The Disciplined Ascent
**Strategic Logic:** Commits to the best-understood route, a lithium-metal anode with a high-nickel or lithium-rich layered oxide cathode and a conventional-assembly liquid or gel electrolyte, run by a conventional bench team to avoid large automation and new-process commitments. Full-size cell verification is deferred until chemistry is stable, and the programme is framed as a licensing-oriented invention entity, which matches the stated goal of inventing a better battery rather than becoming an industrial player. A minimum cycle-life requirement (proposed) should be written into the final-stage verification to prevent a one-cycle cell from counting as success.

**Fit Score:** 4/10

**Assessment of this Path:** Lowest cost and execution risk and a sensible licensing framing, but a single incremental lithium-metal/high-Ni route with deferred full-size verification may fall short of 1000 Wh/L and surfaces packaging penalties too late. It under-delivers on the 'invent a better battery' ambition and has no fallback if the chemistry stalls.

**Key Strategic Decisions:**

- **Chemistry Pathway Commitment:** Commit the full budget to a lithium-metal anode paired with a high-nickel or lithium-rich layered oxide cathode, accepting an incremental but better-understood route to the gravimetric target.
- **Electrolyte and Interface Architecture:** Engineer a liquid or gel electrolyte using localized high-concentration salts and fluorinated solvents, keeping conventional cell assembly while pushing voltage and lithium-metal reversibility.
- **Discovery Engine: Simulation, Autonomy and Bench Work:** Keep a conventional team of bench scientists augmented by outsourced simulation and commercial materials databases, preserving flexibility and avoiding large automation commitments.
- **Cell-Level Proof Standard:** Progress through coin-cell and small single-layer pouch demonstrations first, adopting full-size cell verification only in the final two years once chemistry is stabilized.
- **Ecosystem, Talent and IP Position:** Structure the programme as a licensing-oriented invention entity that deliberately develops the technology to demonstration and then transfers it to an established manufacturer, with IP terms negotiated early.
