A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The USD 10 M/yr payroll baseline and USD 20 M reserve (inside the USD 300 M cap, user constraint) are sufficient to fund 80-120 FTE, pivots and the ~USD 41 M carry-forward for Months 36-84 (2029-10-14 to 2033-10-14). | Build a bottom-up FTE roster with Austin salary benchmarks and an 84-month cash-flow model; present to the funder by Month 2 (2026-12-14). | Bottom-up payroll exceeds USD 12 M/yr (estimate) or the model shows carry-forward below USD 5 M before Month 36 (2029-10-14). |
| A2 | The modular leased dry-room and pouch line can be commissioned on site by Month 3 (2027-01-14), with first builds at Month 6 (2027-04-14), an interim checkpoint at Month 12 (2027-10-14) (e.g. 25-50 cells/month, >=80% yield, proposed) and 50-100 cells/month at >=90% yield by Month 24 (2028-10-14), with Phase 1 permits on schedule. | Obtain named-vendor binding quotes with lead times and hold pre-application meetings with Austin Fire Authority and TCEQ in Month 0 (2026-10-14). | Vendor lead time exceeds 16 weeks, or regulators indicate Phase 1 approval later than Month 4 (2027-02-14). |
| A3 | At least one of three active chemistries can reach >=500 Wh/kg and >=950 Wh/L in the same pouch cells with >=300 cycles at 80%, and early projections predict this reliably. | Run the mass-and-volume model for all candidates with swelling factors; build 50-100 mAh pouch proxies and compare against projections. | No candidate projects >=950 Wh/L at cell level, or measured pouch data deviate more than 10% from model. |
| A4 | Partner university and national-lab agreements will deliver <=3 week characterization turnaround and >=15% co-funding (proposed threshold) through the programme, without deprioritization or IP-term conflicts. | Request written capacity statements, queue data and draft cost-share and IP terms from UT Austin, NREL and Argonne in Month 0 (2026-10-14); sign >=2 agreements by Month 3 (2027-01-14). | Any partner quotes typical turnaround above 4 weeks, offers under 10% cost share, or demands joint ownership or blocking rights over integrated cell architecture. |
| A5 | Hiring and retaining 80-120 FTE near Tesla is feasible with 15-20% senior premiums and clean-room onboarding, keeping attrition below 15%/yr (proposed) and avoiding IP-contamination claims. | Run a recruiter survey and test-offer round for 5 key lead roles by Month 2 (2026-12-14); have IP counsel review the clean-room protocol. | Fewer than 3 of 5 key leads accept at the budgeted premium, or time-to-fill exceeds 12 weeks (estimate), or counsel finds the protocol cannot cleanly separate competitor-origin hires. |
| A6 | A licensee will exist and accept the invented cell, and licensing value will hold, given that the application anchor is open and enabling findings are shared pre-competitively. | Hold informal discussions with 3-5 prospective licensees before Month 6 (2027-04-14) to test duty-cycle, cost and form-factor requirements, and have counsel review patent-estate scope. | No prospective licensee will state requirements or sign a non-binding term sheet by Month 12 (2027-10-14), or counsel judges that enabling materials are unpatentable after planned publication. |
| A7 | Phased hazardous-materials permits (Phase 1 Month 3 = 2027-01-14, Phase 2 Month 6 = 2027-04-14, Phase 3 Month 9 = 2027-07-14) will be granted without restrictions that exclude reactive chemistries (lithium metal, sulfides, fluorinated solvents) from the Austin site. | Hold pre-application meetings with Austin Fire Authority and TCEQ in Month 0 (2026-10-14); request written scope boundaries and review timelines for lithium-metal synthesis and abuse chambers. | Regulators indicate a review time above 6 months (estimate) for Phase 2, or state that lithium-metal synthesis or abuse-chamber operation is excluded from the site. |
| A8 | Precursors and imported equipment for all three active chemistries and the reserve chemistry can be sourced from at least 2 qualified vendors each, at 8-12 week lead times and stable prices, without export-control or currency shocks. | Map critical precursors and long-lead equipment by Month 1 (2026-11-14); obtain written quotes, lead times and export-control status from at least 2 vendors per item. | Any critical precursor has a single qualified vendor, quoted lead time above 16 weeks (estimate), or an export licence requirement that adds more than 2 months (estimate). |
| A9 | The Scientific Steering Committee, funder and independent red team will enforce gate decisions within 3 weeks and accept data-driven deprioritization and stop rules, rather than letting weak candidates continue through sunk-cost pressure. | Draft the steering charter with a scoring rubric, red-team authority and a written stop rule; obtain signed funder agreement to enforce it by Month 1 (2026-11-14). | Funder or committee members decline to sign binding thresholds or the withholding of tranche T4 by Month 3 (2027-01-14), or rubric disputes remain unresolved after 3 weeks. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Payroll Mirage | Process/Financial | A1 | Financial & Operations Manager | CRITICAL (20/25) |
| FM2 | The Empty Dry Room | Technical/Logistical | A2 | Cell Engineering & Pilot-Line Manager | CRITICAL (16/25) |
| FM3 | :The Orphaned Record | Market/Human | A3 | Programme Director & Scientific Lead | CRITICAL (15/25) |
| FM4 | The Queue That Ate the Loop | Process/Financial | A4 | Partner & Ecosystem Lead | HIGH (12/25) |
| FM5 | The Contaminated Core | Technical/Logistical | A5 | Talent Recruitment & Retention Manager | HIGH (12/25) |
| FM6 | The Invention Nobody Licenses | Market/Human | A6 | Programme Director & Scientific Lead | CRITICAL (15/25) |
| FM7 | The Permit Pinch | Process/Financial | A7 | Environmental Health & Safety (EHS) Officer | CRITICAL (16/25) |
| FM8 | The Starved Line | Technical/Logistical | A8 | Financial & Operations Manager | HIGH (12/25) |
| FM9 | The Gate That Never Closed | Market/Human | A9 | Programme Director & Scientific Lead | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Payroll Mirage

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Financial & Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Payroll baseline set top-down, not bottom-up.
- Hiring near Tesla pushes payroll toward USD 14.8 M/yr (estimate).
- Payroll drift consumes ~USD 10-12 M (estimate) of the USD 20 M reserve by Month 30 (2029-04-14) and ~USD 34 M by Month 84 (2033-10-14), ~USD 14 M more than the reserve.
- Months 36-84 (2029-10-14 to 2033-10-14) tranche (USD 22.5 M/yr) cannot cover opex (~USD 32.9 M/yr).
- Forced layoffs and descope before final verification.

##### Early Warning Signs
- Committed payroll exceeds USD 10 M/yr run-rate by Month 6 (2027-04-14)
- Cumulative spend above tranche plan by >10% at Month 12 (2027-10-14)
- Funder has not decided on top-up or descope by Month 3 (2027-01-14)

##### Tripwires
- Annualized payroll >= USD 12 M by Month 6 (2027-04-14)
- Carry-forward forecast < USD 5 M at Month 24 (2028-10-14)
- Free contingency <= USD 2 M before Month 30 (2029-04-14)
- Attrition >= 15% annualized

##### Response Playbook
- Contain: Freeze new senior hires and non-critical equipment orders within 5 business days.
- Assess: Reforecast payroll and 84-month cash flow with stress cases within 3 weeks.
- Respond: Obtain funder decision on top-up, descope to 60-80 FTE, or hiring freeze after Month 36 (2029-10-14).


**STOP RULE:** If forecast cash cannot fund operations through Month 84 (2033-10-14) and the funder declines top-up or descope by Month 12 (2027-10-14), pivot to a two-chemistry reduced-scope programme.

---

#### FM2 - The Empty Dry Room

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Cell Engineering & Pilot-Line Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Phase 1 permit slips 6-8 months (estimate).
- Modular line vendor misses delivery or dew-point specs.
- First pouch builds slide from Month 6 (2027-04-14) to Month 9-12 (2027-07-14 to 2027-10-14).
- Outsourced synthesis (USD 2-5 M/yr, 4-6 week turnaround) slows iteration.
- Month 18 (2028-04-14) gate lacks measured pouch data.

##### Early Warning Signs
- No signed vendor lease by Month 1 (2026-11-14)
- Phase 1 application not accepted by Month 2 (2026-12-14)
- Commissioning dew point worse than -30 C

##### Tripwires
- Phase 1 permit not approved by Month 4 (2027-02-14)
- Line not on site by Month 4 (2027-02-14)
- First pouch build later than Month 8 (2027-06-14)
- Build yield < 80% at Month 12 (2027-10-14) (ramp checkpoint; >=90% yield expected by Month 24 (2028-10-14))

##### Response Playbook
- Contain: Activate partner standby line and outsourced synthesis contracts within 2 weeks.
- Assess: Re-baseline critical path and quantify lost months and cost within 3 weeks.
- Respond: Seek conditional-use authorization, re-source vendor, and re-time the Month 18 (2028-04-14) gate.


**STOP RULE:** If no pouch cells are built by Month 12 (2027-10-14) on any line, suspend T2 spend and re-plan the programme.

---

#### FM3 - :The Orphaned Record

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Programme Director & Scientific Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Chemistries hit Wh/kg but collapse on Wh/L or cycle life.
- Late discovery at Month 30 (2029-04-14) squeezes pivot and sprint into the same window.
- No locked application or licensee; cell misaligned with buyer needs.
- Team morale and attrition rise as candidates stall.
- Licence value eroded; result shelved.

##### Early Warning Signs
- Model projects < 950 Wh/L for leading candidates
- Measured cycle life < 250 cycles at Month 15 (2028-01-14)
- No licensee term sheet by Month 18 (2028-04-14)

##### Tripwires
- Any finalist < 950 Wh/L projected at Month 9 (2027-07-14)
- Two candidates < 250 cycles at Month 18 (2028-04-14)
- No licensee contact by Month 12 (2027-10-14)
- Model-to-measured discrepancy > 10%

##### Response Playbook
- Contain: Halt new builds on failing candidates and redirect capacity to the strongest two within 2 weeks.
- Assess: Run red-team replication and licensee requirement review within 4 weeks.
- Respond: Trigger reserve chemistry pivot or architecture sprint and lock application anchor.


**STOP RULE:** If no chemistry meets Month 30 (2029-04-14) thresholds by Month 36 (2029-10-14), do not release T4 in full; descope or stop.

---

#### FM4 - The Queue That Ate the Loop

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Partner & Ecosystem Lead
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Partner queues drift to 6-8 weeks (estimate) as national-lab priorities shift.
- Co-funding below 15% (proposed threshold) is off-budget and not netted against the budget; a shortfall is a risk that triggers the commercial backstop.
- Commercial backstop (USD 2-3 M/yr) is consumed faster than planned.
- Hypothesis throughput falls 50-75% (estimate).
- Month 18 (2028-04-14) gate runs on thin data.

##### Early Warning Signs
- Average turnaround above 21 days for 2 consecutive months
- Partner agreements unsigned at Month 3 (2027-01-14)
- Partner cost share quoted below 15%

##### Tripwires
- Turnaround >= 28 days for 2 consecutive months
- Fewer than 2 signed agreements at Month 3 (2027-01-14)
- Commercial backstop spend >= USD 1.5 M in any 12 months
- Partner cost share < 10% of shared costs

##### Response Playbook
- Contain: Route overflow failed-cell samples to the commercial backup lab within 2 weeks.
- Assess: Quantify lost hypothesis throughput and budget burn per partner within 3 weeks.
- Respond: Renegotiate terms, add a third partner, or fund a second in-house instrument from the general reserve.


**STOP RULE:** If fewer than 2 partner or backup channels sustain <=6 week turnaround by Month 12 (2027-10-14), descope to two active chemistries.

---

#### FM5 - The Contaminated Core

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Talent Recruitment & Retention Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Key chemistry and cell-engineering leads are poached or never hired.
- Competitor-origin hires bring suspected proprietary know-how.
- Contamination claim threatens patent validity and forces redocumentation.
- Loss of process knowledge hurts pilot-line reproducibility.
- Gate evidence is delayed by 2-4 months (estimate).

##### Early Warning Signs
- Time-to-fill for lead roles above 12 weeks
- Two or more lead resignations within 6 months
- Counsel flags unresolved contamination questions

##### Tripwires
- Annualized attrition >= 15%
- Any chemistry or pilot-line lead departs before Month 24 (2028-10-14)
- Open roles >= 15% of planned FTE at Month 9 (2027-07-14)

##### Response Playbook
- Contain: Invoke retention agreements and interim cover for the affected lead within 1 week.
- Assess: Audit exposure of affected designs and IP-contamination records within 3 weeks.
- Respond: Adjust compensation bands, backfill from university pipelines, and file continuation patents where independence is documented.


**STOP RULE:** If both a chemistry lead and the cell-engineering lead remain vacant for more than 6 months before Month 24 (2028-10-14), reduce the tournament to two chemistries.

---

#### FM6 - The Invention Nobody Licenses

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Programme Director & Scientific Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Open sharing publishes enabling materials before filing.
- Application anchor stays open; cell misses licensee duty cycle.
- Licensee withdraws or cost per kWh exceeds buyer thresholds.
- Licence value falls 30-50% (estimate).
- Verified cell is shelved at Month 84 (2033-10-14).

##### Early Warning Signs
- No licensee term sheet by Month 12 (2027-10-14)
- Fewer than 6 provisionals by Month 12 (2027-10-14)
- Licensee requirements diverge from the cell specification

##### Tripwires
- Zero licensee term sheets at Month 18 (2028-04-14)
- Fewer than 6 provisionals filed at Month 12 (2027-10-14)
- Licensing framework unsigned at Month 24 (2028-10-14)
- Lead licensee withdraws before Month 36 (2029-10-14)

##### Response Playbook
- Contain: Pause publication of enabling results pending counsel review within 1 week.
- Assess: Re-scope licensee requirements and patent-estate gaps within 4 weeks.
- Respond: Lock the application anchor, add filings, and open backup licensee or consortium talks.


**STOP RULE:** If no licensee commitment exists at the Month 36 (2029-10-14) selection gate, do not release T4 in full.

---

#### FM7 - The Permit Pinch

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Environmental Health & Safety (EHS) Officer
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Phase 2 and 3 permits slip beyond the planned Months 6 and 9 (2027-04-14, 2027-07-14).
- Lithium-metal synthesis restricted on site, forcing outsourcing at USD 2-5 M/yr (estimate).
- Effective work shrinks to 75-78 months (estimate).
- Outsourcing consumes free contingency of USD 2-3 M (estimate) and pressures the reserve.
- Month 18 (2028-04-14) gate data thins.

##### Early Warning Signs
- Regulator feedback quotes review time above 6 months (estimate)
- Phase 1 application returned with information requests above 2 rounds
- Outsourced synthesis spend rises above plan

##### Tripwires
- Phase 1 permit not approved by Month 4 (2027-02-14)
- Phase 2 permit not approved by Month 8 (2027-06-14)
- Outsourced synthesis spend >= USD 2 M in any 12 months
- On-site reactive synthesis days <= 50% of planned in a quarter

##### Response Playbook
- Contain: Activate pre-negotiated contract synthesis capacity within 2 weeks.
- Assess: Re-baseline the permit critical path and quantify lost months and outsourcing cost within 3 weeks.
- Respond: Negotiate conditional-use authorization, narrow site chemistry scope, and re-time the Month 18 (2028-04-14) gate.


**STOP RULE:** If Phase 2 reactive-synthesis permit is not granted by Month 12 (2027-10-14), relocate to an alternative permitted site or move all reactive work to partner facilities.

---

#### FM8 - The Starved Line

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Financial & Operations Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Single-source precursor stalls cell builds for weeks.
- Export controls or tariffs extend lead times past 16 weeks (estimate).
- Equipment priced in EUR or CNY exceeds the USD 2-3 M FX contingency.
- Pre-staged reserve chemistry cannot be activated in 4-6 weeks (estimate).
- Build cadence below the ramp (25-50 cells/month at Month 12, 50-100 cells/month by Month 24 = 2028-10-14) delays gate evidence.

##### Early Warning Signs
- Critical precursor with fewer than 2 qualified vendors
- Quoted lead times lengthen by more than 4 weeks
- Currency moves above 10% on equipment corridors

##### Tripwires
- Any critical precursor lead time >= 16 weeks
- Precursor price increase >= 20% in 12 months
- Pouch-cell builds < 25 per month at Month 12 (2027-10-14) (interim ramp checkpoint, proposed; 50-100 cells/month due by Month 24 (2028-10-14))
- FX cost drift >= USD 2 M against forward contracts

##### Response Playbook
- Contain: Place expedited orders from the backup vendor and draw buffer stock within 1 week.
- Assess: Quantify delayed builds and cost exposure per chemistry within 3 weeks.
- Respond: Qualify alternative suppliers or synthetic routes, and re-sequence builds toward finalists.


**STOP RULE:** If a critical precursor for a finalist chemistry cannot be secured within 6 months of first shortage, drop that chemistry in favour of the reserve.

---

#### FM9 - The Gate That Never Closed

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Programme Director & Scientific Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- Steering Committee defers hard calls; weak candidates keep consuming capacity.
- Red-team findings overruled by core-team enthusiasm.
- Funder reluctant to withhold tranches publicly.
- Gate slips 4-8 weeks (estimate), compressing Months 36-84 (2029-10-14 to 2033-10-14).
- Credibility with licensees and partners erodes.

##### Early Warning Signs
- Gate decision exceeds 3 weeks after data arrival
- Red-team discrepancy above 5% unresolved after 2 weeks
- Candidate below 250 cycles still receiving builds

##### Tripwires
- Gate decision delayed >= 21 days after data arrival
- Red-team vs core-team discrepancy > 5% on Wh/kg unresolved after 14 days
- Candidate < 250 cycles at 80% still funded at Month 24 (2028-10-14)
- Funder has not signed the stop rule by Month 3 (2027-01-14)

##### Response Playbook
- Contain: Freeze new builds on any candidate failing a published threshold within 1 week.
- Assess: Commission red-team replication and external advisor review within 3 weeks.
- Respond: Enforce the scoring rubric, escalate to the funder, and withhold the next tranche until evidence is accepted.


**STOP RULE:** If the funder will not enforce withholding of T4 under the written stop rule by Month 36 (2029-10-14), cancel further tranche spend pending a descope decision.
