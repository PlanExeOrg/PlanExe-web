**2 open decisions: 2 high severity.** The cap-and-timeline decision and the payroll-funding decision are urgent: both should be settled by Month 3 (2027-01-14), with a hard backstop at Month 6 (2027-04-14), since T2 release at Month 12 (2027-10-14) depends on them. Before then the plan can safely proceed with site lease, regulator engagement, partner agreements, EHS hire and the cell model at baseline payroll, without touching the ring-fenced pivot runway.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Cap and timeline: fixed or movable | 🔴 High | Funder (with Scientific Steering Committee recommendation) | Month 3 (2027-01-14) (hard backstop Month 6 = 2027-04-14): T2 planning and hiring depend on it. | T2 release at Month 12 (2027-10-14) and the 84-month cash-flow plan. |
| 2 | Payroll drift funding and trigger | 🔴 High | Funder, on Steering Committee and Finance Manager recommendation | Month 3 (2027-01-14) after the Month 2 (2026-12-14) salary survey and cash-flow model; hiring starts immediately. | T2 release and the hiring plan; a written carry-forward agreement for Months 36-84 (2029-10-14 to 2033-10-14). |

## 1. Cap and timeline: fixed or movable (🔴 High)

**Decision:** Will the funder hold USD 300 M and 84 months as fixed, or explicitly authorize a top-up, longer timeline or external funding with a named source?

**Why it is open:** Canonical facts fix USD 300 M and 84 months with no revenue or debt. Executive summary and reviews 1, 3, 9, 11 and FM1 offer a top-up to USD 330-350 M, a longer timeline or co-funding, with no payer named.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Hold cap and 84 months fixed; manage inside by descoping FTE or chemistries, hiring freeze, re-phasing. | Keeps the USD 300 M cap and Month 84 (2033-10-14) delivery; scope or active chemistries may shrink; T2 (USD 80 M) proceeds only with a descoped plan. | Remove top-up and longer-timeline mitigations from executive summary, reviews and FM1. |
| B. Authorize a top-up (USD 330-350 M) with a stated source of funds. | Breaks the user-constraint cap; closes the carry-forward gap and payroll drift; funder must name the payer. | total_budget_usd_m, tranche_schedule_usd_m, financing_and_revenue_chain, unallocated_reserve. |
| C. Extend the timeline beyond 84 months at lower annual cost. | Breaks the 84-month constraint; Month 72 (2032-10-14) verification and Month 84 (2033-10-14) delivery shift; fixed costs such as lease accrue longer. | programme_duration_months, final_delivery_criteria, gate dates. |

- **If nobody decides:** The cap and 84 months stay fixed by default; the FM1 stop rule moves to a two-chemistry reduced-scope programme if no decision by Month 12 (2027-10-14).
- **Owner:** Funder (with Scientific Steering Committee recommendation)
- **Decide by:** Month 3 (2027-01-14) (hard backstop Month 6 = 2027-04-14): T2 planning and hiring depend on it.
- **Blocks:** T2 release at Month 12 (2027-10-14) and the 84-month cash-flow plan.

## 2. Payroll drift funding and trigger (🔴 High)

**Decision:** How will payroll above the USD 10 M/yr baseline be funded or contained, and at what single trigger?

**Why it is open:** Payroll could reach ~USD 14.8 M/yr (estimate, range USD 12.9-16.6 M). Only USD 2-3 M free reserve exists; the USD 15 M pivot runway is ring-fenced until Month 36 (2029-10-14). Documents use triggers of USD 12 M/yr and USD 13+ M/yr.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Cap payroll by descoping to 60-80 FTE or fewer active chemistries; trigger USD 12 M/yr. | Drift is absorbed inside the envelope; pivot runway untouched; less parallel chemistry work. | staffing_fte_and_payroll, chemistry_tournament_structure, KPI 3 trigger. |
| B. Funder approves a written draw from underspend or non-runway reserve for drift. | Preserves 80-120 FTE; free contingency drops to zero; carry-forward need rises toward ~USD 61 M (estimate). | free_contingency_after_reserves_usd_m, opex_vs_tranche_gap, funder agreement. |
| C. Allow drift to draw on the USD 15 M pivot runway before Month 36 (2029-10-14). | Leaves ~USD 8-10 M for the pivot and sprint (USD 13-25 M stress case); raises failure risk at Month 36 (2029-10-14). | pivot_runway_usd_m, reserve_stress_case. |

- **If nobody decides:** The runway stays ring-fenced; drift is unfunded and T2 is not released as planned (descope applies).
- **Owner:** Funder, on Steering Committee and Finance Manager recommendation
- **Decide by:** Month 3 (2027-01-14) after the Month 2 (2026-12-14) salary survey and cash-flow model; hiring starts immediately.
- **Blocks:** T2 release and the hiring plan; a written carry-forward agreement for Months 36-84 (2029-10-14 to 2033-10-14).

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Chemistry Pathway Commitment | Staged tournament of 3 active chemistries plus 1 reserve, cut to one finalist at Month 36 (2029-10-14). | Commit all budget to lithium-metal with a high-nickel cathode (Disciplined Ascent). | Sets hedging against dead-end chemistry and how spend is split. | Month 18 (2028-04-14) gate |
| Electrolyte and Interface Architecture | Layered hybrid: thin ceramic or polymer interlayer in minimal-volume liquid electrolyte. | Sulfide or halide solid electrolyte with new pilot-line process (Pioneer's Gambit). | Determines pilot-line, dry-room and permit demands and Wh/L reachability. | Month 18 (2028-04-14) gate |
| Discovery Engine | In-house computation with validation outsourced to university and national-lab partners. | Closed-loop self-driving laboratory (Pioneer's Gambit). | Makes fixed cost variable but depends on partner turnaround. | Month 12 (2027-10-14) |
| Cell-Level Proof Standard | Mass-and-volume cell model from the start, with third-party pouch proof at Month 30 (2029-04-14). | Third-party pouch proof from year one, or full-size verification only in final two years. | Governs when Wh/L shortfalls surface and the cost of testing. | Month 18 (2028-04-14) gate |
| Ecosystem, Talent and IP Position | University and national-lab partnerships; open pre-competitive sharing; patent final architecture. | Aggressive Austin recruiting with broad patenting (Pioneer's Gambit) or licensing entity. | Affects licensability, talent cost and IP contamination risk. | Month 24 (2028-10-14) licensing framework |
