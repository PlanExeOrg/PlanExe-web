
## Question 1 - How will the USD 300 M be released across tranches, and what share is held as contingency versus capital build-out?

**Assumptions:** Assumption: Funds are released in evidence-linked tranches (Months 0-12 = 2026-10-14 to 2027-10-14 about USD 60 M, Months 12-24 = 2027-10-14 to 2028-10-14 about USD 80 M, Months 24-36 = 2028-10-14 to 2029-10-14 about USD 70 M, Months 36-84 = 2029-10-14 to 2033-10-14 about USD 90 M; proposed split), with a USD 15-20 M reserve (estimate, 5-7%). Typical R&D programmes hold 5-10% contingency.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates budget phasing and reserve adequacy.
Details: Front-loading of pilot line, dry room and hiring may reach USD 60-80 M in Years 1-2 (estimate), leaving roughly USD 30-34 M/year afterwards. A 20% facility overrun would cut remaining funds by 3-5%. Mitigate with modular leased equipment, partner co-funding (proposed 10-15%) and a reserve held through Month 30 (2029-04-14). Benefit: preserved pivot capacity at the Month 36 (2029-10-14) gate.

## Question 2 - What are the key milestones and gate dates, and when must independent pouch-cell proof and minimum cycle life be demonstrated?

**Assumptions:** Assumption: Gates at Month 18 (2028-04-14) (go/no-go criteria), Month 30 (2029-04-14) (third-party pouch-cell verification, both Wh/kg and Wh/L) and Month 36 (2029-10-14) (chemistry selection); delivery by Month 84 (2033-10-14). Minimum cycle life is a proposed threshold of 300 cycles at 80% retention.

**Assessments:** Title: Timeline Feasibility Assessment
Description: Evaluates gate sequencing against the 84-month horizon.
Details: A failed Month 36 (2029-10-14) gate leaves about 48 months, and a pivot costs 6-10 months (estimate). Early pouch proof at Month 30 (2029-04-14) exposes packaging penalties while a pivot is still affordable. Pre-staging the reserve chemistry by Month 24 (2028-10-14) shortens pivots to 4-6 weeks. Risk: permitting slippage of 6-8 months compresses effective work time; mitigate with phased permits.

## Question 3 - What team size, skill mix and hiring pace are needed, and how will talent be retained against Tesla competition?

**Assumptions:** Assumption: 80-120 FTE (estimate) with 20-30% postdoctoral and graduate roles, a 10-20% salary premium for senior roles, and 3-5 year retention agreements. Attrition target is below 15% annually (proposed).

**Assessments:** Title: Personnel Capacity Assessment
Description: Evaluates ability to staff and retain a specialist team in Austin.
Details: Payroll could reach USD 8-12 M/year (estimate), about 19-28% of the average annual budget. Attrition of 20% means 16-24 replacements per year and lost knowledge. Mitigate with UT Austin pipelines, publication incentives and clawback-backed retention. Opportunity: university links reduce cost and broaden the talent pool beyond Tesla alumni.

## Question 4 - What governance structure, decision rights and IP/regulatory framework will govern gate decisions, partners and technology transfer?

**Assumptions:** Assumption: A Scientific Steering Committee (director, chemistry leads, external advisor, funder representative) decides gates and reallocations within 3 weeks. An independent red team of 2-3 scientists verifies claims. IP terms and a licensing framework are set by Month 24 (2028-10-14).

**Assessments:** Title: Governance Adequacy Assessment
Description: Evaluates decision authority, verification and IP controls.
Details: Ambiguity at gates could add 4-8 weeks of delay or fund a weaker chemistry at USD 10-15 M (estimate). Clear criteria and an independent verifier protect credibility and patent value. Open partner sharing risks a 30-50% licence value loss (estimate) if filings are late; file provisionals on compositions and formats as they emerge. Clean-room onboarding limits Tesla contamination claims.

## Question 5 - What safety strategy, hazard envelope and abuse-testing approach apply to lithium metal, flammable solvents and high-energy cells?

**Assumptions:** Assumption: Phased safety evaluation: thermal-ramp screening at Months 3-6 (2027-01-14 to 2027-04-14), contracted abuse tests at Months 6-12 (2027-04-14 to 2027-10-14), in-house chambers (USD 3-5 M, estimate) from Month 12 (2027-10-14) if a chemistry passes. Finalists need thermal runaway onset of at least 120°C (proposed threshold).

**Assessments:** Title: Safety and Risk Assessment
Description: Evaluates hazard handling and early elimination of unsafe candidates.
Details: Late discovery of onset below 100°C could waste 12-18 months and USD 10-20 M (estimate). Incidents may cost USD 1-3 M and weeks of shutdown. Mitigate with a staffed EHS function by Month 1 (2026-11-14), quarterly audits, a standing EHS advisory committee and contingency of USD 3-5 M. Benefit: early safety ranking narrows the design space.

## Question 6 - What environmental obligations (waste, emissions, water, energy) arise from synthesis, dry rooms and abuse testing, and how will they be managed?

**Assumptions:** Assumption: Operations are permitted under EPA, TCEQ and local rules with a licensed hazardous-waste contractor, solvent recovery where feasible, and an annual environmental compliance budget of USD 0.5-1 M (estimate).

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluates waste, emissions and regulatory exposure.
Details: Key streams are fluorinated solvents, lithium residues, VOCs and failed cells; dry rooms carry high energy demand. Regulatory change may require USD 2-5 M retrofits (estimate). Mitigate with waste minimisation, small-batch synthesis, exhaust abatement and a regulatory monitoring retainer. Opportunity: documented low-impact practice eases permitting and partner trust.

## Question 7 - Which stakeholders (funder, universities, national labs, regulators, community, Tesla, potential licensees) need engagement, and how?

**Assumptions:** Assumption: Formal 3-5 year agreements with at least two university or national-lab partners by Month 3, early engagement with the Austin fire authority, and informal licensee advisory contacts by Month 12 (2027-10-14). Partners fund at least 15% of shared costs (proposed).

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluates partner dependency and external relationships.
Details: Partner loss could cost USD 30-50 K per sample at commercial labs and USD 5-10 M over the programme (estimate). Mitigate with backup partners per critical service, 30-60 day exit clauses and USD 2-3 M/year partnership contingency. Early licensee engagement reduces 12-24 month commercialisation delays. Community and regulator transparency lowers permit-denial risk.

## Question 8 - Which operational systems (pilot line, dry room, characterization, data/computing, supply chain) must be running, and by when?

**Assumptions:** Assumption: A modular leased dry-room and pouch line sized for 50-100 cells/month (estimate) is operating by Month 3-6 (2027-01-14 to 2027-04-14), with one in-house post-mortem instrument by Month 6 (2027-04-14), a unified data pipeline by Month 9 (2027-07-14), and dual-sourced precursors by Month 3 (2027-01-14).

**Assessments:** Title: Operational Systems Assessment
Description: Evaluates fabrication, analysis, data and supply readiness.
Details: A new owned line may cost USD 30-50 M and 12 months; modular leasing cuts lock-in. Partner queues of 4-8 weeks could cut hypothesis throughput 50-75%, so in-house triage is justified. Precursor lead times of 8-12 weeks justify 3-6 months of buffer stock. Computing at USD 0.5-2 M/year via cloud or national-lab access (estimate). Require reproducibility of 90% of cells within ±10% by Month 30 (2029-04-14).