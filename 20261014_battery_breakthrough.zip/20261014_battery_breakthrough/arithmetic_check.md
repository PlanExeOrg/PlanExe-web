21 explicit calculations found in the documents re-computed without an LLM; 1 does not match its stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Data Collection | 10-20 K per cell × 3 replicates × 3 chemistries = ~USD 180-360 K per gate cycle) | 180-360 | 9 |
