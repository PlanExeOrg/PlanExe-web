
## Documents to Create

### 1. Project Charter and Goals Statement

**ID:** 370f82e7-9a5e-4910-8409-b2402d41dec3

**Description:** Formal charter defining the programme goal (invent a >=500 Wh/kg and >=1000 Wh/L cell at cell level, third-party verified, licensable), success criteria (300 cycles at 80% retention, thermal-runaway onset >=120°C), timeline (84 months, Month 0 = 2026-10-14 to Month 84 = 2033-10-14), budget (USD 300 M fixed cap), and governance. Primary audience: Steering Committee, funder, external stakeholders. Approvals: Funder, Steering Committee.

**Responsible Role Type:** Programme Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** World Bank Logical Framework

**Steps:**

- Reconcile user constraints (500 Wh/kg, 1000 Wh/L, USD 300 M, 84 months, Austin location) with the selected Pragmatic Foundation strategy.
- Define SMART success criteria: >=500 Wh/kg, >=1000 Wh/L, >=300 cycles at 80% retention, thermal-runaway onset >=120°C, third-party verified, reproducibility >=90% within ±10%.
- Document dependencies: site lease and permitting, partner agreements, clean-room onboarding, gate decision protocols.
- Identify key risks and mitigation (chemistry failure, volumetric shortfall, permitting slip, payroll overrun, pivot cost).
- Obtain signed approval from Funder and Steering Committee by Month 1 (2026-11-14).

**Approval Authorities:** Funder, Programme Director, Steering Committee chair

### 2. Chemistry Pathway Tournament Strategy and Gate Criteria

**ID:** 5030ccde-788b-4034-b8f6-3da583b5db08

**Description:** Detailed strategy for staged tournament across 3 active chemistries (lithium-sulfur, anode-free solid-state, conversion cathode) plus 1 pre-staged reserve. Specifies chemistry selection criteria, go/no-go gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), quantitative success thresholds (>=500 Wh/kg material-level, >=950 Wh/L interim, >=300 cycles, >=120°C thermal onset), deprioritization rules, and pivot contingency. Primary audience: chemistry leads, Steering Committee.

**Responsible Role Type:** Chemistry Pathway Lead (or Lead Chemistry Team)

**Primary Template:** Stage-Gate Innovation Process (Cooper, IRI model)

**Steps:**

- Define the three active chemistries: anode, cathode, electrolyte specification for each.
- Document projected cell-level Wh/kg and Wh/L for each (using the mass-and-volume model, due Month 4 = 2027-02-14).
- Specify quantitative go/no-go criteria at Months 18 (2028-04-14), 30 (2029-04-14), 36 (2029-10-14).
- Define deprioritization rules: candidates with <250 cycles at 80% by Month 12 (2027-10-14) receive no new builds for 4 weeks pending a focused 2-4 month redesign sprint, with decision point at Month 15 (2028-01-14) or Month 18 (2028-04-14).
- Detail reserve-chemistry specification, precursor suppliers (>=2 per material), lead times and pivot timeline (4-6 weeks execution if triggered at Month 30 = 2029-04-14).
- Lock criteria by Month 3 (2027-01-14) via Steering Committee signed agreement attached to tranche-release conditions.

**Approval Authorities:** Chemistry Pathway Lead, Steering Committee, Programme Director

### 3. Cell-Level Mass-and-Volume Model and Packaging Penalty Analysis

**ID:** 87804d32-c8e2-4003-b17c-d3f38f788115

**Description:** Live parametric model that back-calculates material-level Wh/kg and Wh/L targets from the cell-level goals (>=500 Wh/kg, >=1000 Wh/L). Accounts for current collectors (10-20 µm), separator (25-30 µm, chemistry-specific), electrolyte volume (0.5-1.5 mL/Ah), pouch laminate (300-400 µm) and pressure hardware. Includes time-dependent swelling projections (sulfur +25% volume, anode-free >=50% anode thickness per cycle). Quarterly updates with variance analysis (>10% gaps flagged for investigation). Primary audience: chemistry leads, cell engineering, Steering Committee.

**Responsible Role Type:** Cell Engineering Lead

**Primary Template:** Custom parametric design spreadsheet or simulation code (MATLAB, Python)

**Steps:**

- Collect baseline data: current-collector foil thickness, separator porosity, electrolyte fill fraction, pouch material mass per cm² from published benchmarks and supplier specs.
- Define chemistry-specific swelling assumptions: lithium-sulfur cathode volume change, anode-free stack-height growth per cycle, separator compression under pressure.
- Build the model: (cell Wh/kg target) = (material Wh/kg) × (active-material mass fraction) / (total cell mass including inactive); iterate for Wh/L.
- Project cell-level Wh/L for all three candidates by Month 6 (2027-04-14); flag any <950 Wh/L despite >500 Wh/kg material performance for targeted separator/electrolyte-volume redesign.
- Publish quarterly updates with reconciliation against actual pouch-cell measured data; investigate and document any >10% discrepancy.
- Finalize and lock model assumptions by Month 3 (2027-01-14) via Steering Committee approval.

**Approval Authorities:** Cell Engineering Lead, Steering Committee

### 4. Cycle-Life and Degradation Forensics Protocol and Atlas

**ID:** 5e7b5271-acd2-47ef-bf59-7267f4c9b01c

**Description:** Standardized failure-autopsy protocol: every failed cell receives post-mortem within 1 week (SEM/EDS, FTIR or gas chromatography for electrolyte decomposition). Structured root-cause coding (e.g., 'lithium-ion depletion via electrolyte oxidation', 'dendrite growth with internal short'). Quarterly forensics atlas documenting failure modes, mechanisms and design consequences, feeding design iteration. Primary audience: characterization specialist, chemistry leads.

**Responsible Role Type:** Characterization & Forensics Specialist

**Primary Template:** Failure Mode and Effects Analysis (FMEA) combined with post-mortem imaging protocol

**Steps:**

- Define autopsy protocol: sequence of measurements (SEM surface imaging, EDS elemental mapping, FTIR or gas-chromatography analysis of electrolyte decomposition, voltage profiling at failure).
- Design structured root-cause taxonomy with >=15 coded failure modes (dendrite, lithium-ion loss, structural collapse, electrolyte oxidation, mechanical swelling, etc.).
- Establish turnaround timeline: sample intake within 24 hours, SEM triage within 48 hours, full report within 5 business days.
- Build forensics database (spreadsheet or LIMS) tracking all failed cells: chemistry, cell ID, charge/discharge profile, failure cycle, root-cause code, design action taken.
- Publish first quarterly atlas by Month 12 (2027-10-14); refresh every quarter thereafter. Require all design changes to be traceable to forensics findings.
- Lock protocol by Month 6 (2027-04-14); operationalize in-house post-mortem instrument by Month 8 (2027-06-14).

**Approval Authorities:** Characterization & Forensics Specialist, Chemistry Pathway Lead

### 5. Cell-Level Proof Standard and Third-Party Verification Protocol

**ID:** fe864f3e-71cc-45c5-857f-60cd6d7d1e12

**Description:** Specification of what constitutes success: measured third-party pouch cells (>=100 mAh, >=3 replicates) demonstrating >=500 Wh/kg, >=1000 Wh/L, >=300 cycles at 80% retention. Specifies test conditions (C/10 discharge rate, 25°C, chemistry-specific voltage window), measurement precision, accreditation (e.g., MIT Energy Initiative, NREL, Intertek). Mandatory third-party verification gates at Months 30 (2029-04-14) (interim >=950 Wh/L proof) and Month 72 (2032-10-14) (final >=1000 Wh/L proof). Primary audience: test laboratories, Steering Committee.

**Responsible Role Type:** Cell Engineering Lead

**Primary Template:** Standard test protocol (NREL cell testing, IEEE Std 1375)

**Secondary Template:** Accreditation requirements (ISO 17025 for testing labs)

**Steps:**

- Identify 2-3 accredited third-party test laboratories (national labs, university centers, contract test labs like Intertek or TUV).
- Negotiate test protocol and SLAs (turnaround, precision, reproducibility requirements) by Month 9 (2027-07-14).
- Define cell-level test conditions: discharge rate (C/10, proposed), temperature (25°C ambient), voltage window (chemistry-specific, e.g., 0-4.5 V for lithium-metal cells), capacity measurement interval (every 50 cycles).
- Specify replication: minimum 3 cells per candidate chemistry; minimum 100 mAh capacity to ensure current-collector and packaging effects are captured.
- Lock the protocol by Month 12 (2027-10-14) and use it uniformly for all verification data (Month 30 = 2029-04-14 onwards).
- Schedule first independent verification at Month 30 (2029-04-14) (interim >=950 Wh/L); final verification at Month 72 (2032-10-14) (>=1000 Wh/L, >=300 cycles).

**Approval Authorities:** Cell Engineering Lead, independent test lab, Steering Committee

### 6. Safety Evaluation and Abuse-Testing Strategy

**ID:** a52b91c2-ae74-41cc-81ba-d832cbcc0d35

**Description:** Phased safety screening strategy: thermal-ramp screening (coin-cell differential scanning calorimetry) Months 6-9 (2027-04-14 to 2027-07-14); contracted external abuse tests (nail penetration, overcharge) Months 6-12 (2027-04-14 to 2027-10-14); in-house abuse chambers decision at Month 12 (2027-10-14) if throughput justifies USD 3-5 M capital. Safety gate: finalists must achieve >=120°C thermal-runaway onset (differential scanning calorimetry, 5°C/min), reversible after 150% overcharge (>=90% recovery), internal-short survivability (no thermal runaway within 5 minutes of nail penetration). Primary audience: chemistry leads, EHS officer.

**Responsible Role Type:** EHS Officer

**Primary Template:** Lithium-ion safety test standards (SAND2000-0218 nail-penetration, IEC 62619 thermal ramp)

**Steps:**

- Define differential scanning calorimetry protocol: sample mass 20-30 mg, 5°C/min heating rate in inert atmosphere, onset defined as first exothermic peak >0.5 mW/mg.
- Establish abuse-test vendor list (Intertek, TUV, or university partner) and negotiate cost (<USD 20 K per full protocol) and turnaround (8 weeks from submission).
- Design thermal-ramp correlation study by Month 8 (2027-06-14): run differential scanning calorimetry, adiabatic calorimetry, nail-penetration and overcharge tests on the same coin cells; document offsets and build confidence intervals.
- Set deprioritization threshold: candidates with differential scanning calorimetry onset <100°C receive no new builds unless a 2-month protective-layer or additive redesign shows path to >=120°C by Month 12 (2027-10-14).
- By Month 12 (2027-10-14), decide on in-house abuse chambers (USD 3-5 M, operationalization ~Month 18 = 2028-04-14) versus continued contracted testing for the finalist(s).
- Incorporate safety findings into the Month 18 (2028-04-14) and Month 36 (2029-10-14) gates: finalists must meet >=120°C onset (differential scanning calorimetry) and pass nail-penetration without rupture or flame.

**Approval Authorities:** EHS Officer, Chemistry Pathway Lead, Steering Committee

### 7. Pilot Line and Dry-Room Operational Plan

**ID:** 7b3f9dd1-46c1-467e-95ea-4365b1300575

**Description:** Specification of the modular, leased dry-room and pouch-cell fabrication line: dew-point control (<-30°C), electrode-coating uniformity (±10 µm), electrolyte-dosing reproducibility (±2%), build turnaround (7 days baseline), monthly capacity (50-100 cells initially, scaling to 150-200 cells/month by Month 24 = 2028-10-14). Lease terms: 3-year, month-to-month after Year 1, 60-day exit, operating cost USD 0.6-1.2 M/yr. Commissioning timeline: lease signed Month 1 (2026-11-14), on-site Month 3 (2027-01-14), dew-point and electrode-coating verification before first cell builds Month 6 (2027-04-14). Primary audience: operations, chemistry leads.

**Responsible Role Type:** Cell Engineering & Pilot-Line Manager

**Primary Template:** Standard equipment lease and commissioning protocol (IEC standards for dry rooms)

**Steps:**

- Conduct market survey of modular dry-room + pouch-line vendors (Mbraun, Glove-box Company, equivalent); obtain RFQs with fixed-price, fixed-schedule terms.
- Specify equipment performance criteria: dew-point setpoint <-30°C (±2°C accuracy), electrode-coating uniformity tolerance ±10 µm measured on 10-cell sample, electrolyte dosing precision ±2% (verified gravimetrically).
- Negotiate lease: 3-year term, operating cost capped USD 1.2 M/yr, uptime >=95%, build turnaround <=7 days, step penalties for exceeding 10-day turnaround (10% monthly cost reduction per exceedance).
- Execute competitive RFQ (target >=3 vendors) and award to lowest fixed-price, qualified bid by Month 1 (2026-11-14).
- Plan deployment and commissioning: equipment on-site by Month 3 (2027-01-14), dew-point and humidification verification by Month 4 (2027-02-14), electrode-coating parameter validation (coating thickness, uniformity) by Month 5 (2027-03-14), electrolyte-dosing calibration by Month 6 (2027-04-14); first pouch-cell builds Month 6 (2027-04-14).
- Document cell-build SOP (standard operating procedure): material prep, electrode coating, electrolyte filling, cell stacking, sealing, formation protocol. Build 10-cell baseline batch by Month 6 (2027-04-14) to verify yield and reproducibility.

**Approval Authorities:** Cell Engineering & Pilot-Line Manager, Steering Committee

### 8. Partner Agreements and Characterization Access SLAs

**ID:** e3db68bd-e85e-4863-97c7-1233f06b2286

**Description:** Formal 3-5 year Memoranda of Understanding (MOU) with >=2 university or national-laboratory partners (UT Austin, NREL, Argonne, or equivalent) guaranteeing: >=10-15 characterization slots/month (operando X-ray diffraction, post-mortem SEM/EDS, electrochemical impedance spectroscopy), <=3-week turnaround (21 calendar days max from sample submission to report), >=15% annual cost-sharing (partner funds >=15% of shared materials and characterization costs, estimated USD 0.5-1 M/yr), and 30-60 day exit clauses (right to redirect samples to backup within 48 hours if queue exceeds SLA). Backup agreement with commercial characterization provider (Intertek, TUV, university contract services) with <=6 week emergency-access commitment. Primary audience: partners, Steering Committee.

**Responsible Role Type:** Partner & Ecosystem Lead

**Primary Template:** MOU template (university tech-transfer office standard)

**Secondary Template:** Statement of Work (SOW) for characterization services

**Steps:**

- Identify candidate partners (UT Austin, NREL, Argonne) and conduct preliminary capacity and interest discussions by Month 0 (2026-10-14).
- Draft MOU template covering: scope of characterization (operando and post-mortem services, monthly slot guarantee, turnaround SLA), cost-sharing rate (>=15% partner), IP ownership (programme owns results; partners retain publication rights post 6-month review), term (3-5 years, renewal automatic unless 90-day notice given), and exit clauses (30-60 day notice, redirects to backup).
- Negotiate final terms with partners by Month 2 (2026-12-14); execute MOUs by Month 3 (2027-01-14).
- Establish backup agreement with commercial lab: RFQ for full characterization services (SEM, EDS, XRD, electrochemical impedance spectroscopy) at USD <=100 K per failed-cell full analysis, 6-week turnaround commitment, priority queue for overflow from primary partners.
- Build characterization-scheduling database: monthly allocation of slots to active chemistries; track actual turnarounds and queue times; escalate breaches >21 days to Steering Committee within 1 week.
- Lock and sign all agreements by Month 3 (2027-01-14); include in Steering Committee governance dashboard for monthly monitoring.

**Approval Authorities:** Partner & Ecosystem Lead, university/national-lab partners, Steering Committee

### 9. Risk Register and Mitigation Plans

**ID:** 67d39c44-cbf2-4727-b422-14cd147fb486

**Description:** Comprehensive risk register identifying 23 key risks across technical, operational, financial, regulatory and strategic domains. For each risk: likelihood (Low/Medium/High), severity (Low/Medium/High), impact (cost and schedule implications), and mitigation actions with timelines and responsible roles. Critical risks: chemistry tournament failure (Month 36 = 2029-10-14 gate), volumetric density shortfall (Month 30 = 2029-04-14), permitting delays (6-8 months, estimate), payroll overrun (USD 20 M+), partner loss, pivot cost exceeding reserve. Updated quarterly; escalation protocol to Steering Committee if mitigation effectiveness drops. Primary audience: Steering Committee, funder, risk officer.

**Responsible Role Type:** Programme Director with Finance & Operations Manager

**Primary Template:** ISO 31010 Risk Management standard, PMI Risk Register template

**Steps:**

- Compile the 23 identified risks from the pre-project assessment and expert review into a structured register (risk ID, description, likelihood, severity, mitigation, owner, review date).
- Quantify impact for top-5 risks: chemistry failure (USD 20-40 M sunk, 6-12 month slip), volumetric shortfall (USD 8-15 M redesign), permitting slip (6-8 months work-time loss), payroll overrun (USD 20 M+), partner loss (USD 2-5 M cost shift). Map to reserve and tranche release.
- Assign mitigation ownership: Chemistry Pathway Lead (chemistry tournament risk), EHS Officer (permitting), Finance Manager (payroll, pivot cost), Partner Lead (partner loss), Characterization Lead (characterization access).
- Establish escalation protocol: if actual risk outcome (measured probability or realized impact) exceeds mitigation assumptions by >20%, notify Steering Committee within 1 week; propose revised reserve allocation or descope.
- Set monitoring cadence: chemistry and volumetric metrics tracked monthly, permitting status tracked monthly, payroll vs. budget tracked monthly, partner queue times tracked monthly. Quarterly risk-register review and reforecast at gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14).
- Finalize register by Month 3 (2027-01-14); attach to Project Charter as Appendix.

**Approval Authorities:** Programme Director, Steering Committee

### 10. Hazardous-Materials Permitting and EHS Operating Model

**ID:** 855ff5d3-7c30-4581-a0e9-f06a4da57fce

**Description:** Phased permitting strategy and operational model for handling reactive metals, flammable solvents, toxic precursors and hazardous waste under EPA, OSHA, TCEQ and local Austin Fire Authority regulations. Phase 1 (Month 3, 2027-01-14): dry-room and pouch-cell assembly (non-hazardous electrolyte fills, inert-atmosphere glovebox operations). Phase 2 (Month 6, 2027-04-14): lithium-metal synthesis, aggressive solvent handling, cathode precursor preparations. Phase 3 (Month 9, 2027-07-14): abuse-testing chambers (thermal runaway, overcharge, nail-penetration testing). Contingency: outsourced synthesis via licensed CROs if on-site synthesis permits slip beyond Month 6 (2027-04-14). EHS staffing, quarterly internal audits, zero-reportable-incident target, USD 0.5-1 M/yr EHS operating budget. Primary audience: EHS officer, regulators, site manager.

**Responsible Role Type:** EHS Officer

**Primary Template:** 40 CFR 260-273 (EPA hazardous waste), 29 CFR 1910.1200 (OSHA hazard communication), Texas Environmental Code

**Secondary Template:** Facility fire-protection and emergency-response plan

**Steps:**

- Conduct preliminary regulatory assessment by Month 1 (2026-11-14): map EPA, OSHA, TCEQ and Austin Fire Authority requirements for lithium-metal handling, organic-solvent use, hazardous-waste generation and storage, and thermal-runaway testing.
- Schedule pre-application collaborative meetings with Austin Fire Authority, TCEQ and Travis County (target Month 0.5 = 2026-10-29) to propose phased-permit approach and conditional-use authorization.
- Prepare Phase 1 permit application (dry-room, inert-atmosphere glovebox, non-hazardous operations): submit to TCEQ and Fire Authority by Month 2 (2026-12-14), targeting 6-week review and approval by Month 3 (2027-01-14).
- Pre-negotiate Phase 2 and Phase 3 permit scope with regulators: lithium-metal synthesis by Month 6 (2027-04-14), abuse chambers by Month 9 (2027-07-14). Request conditional-use authorization to allow operations under enhanced monitoring if review extends beyond target dates.
- Execute standby external-synthesis contracts with >=2 licensed CROs (USD 2-5 M/yr budget, <4 week turnaround) in case on-site synthesis permits slip.
- Build EHS compliance infrastructure: hazardous-waste contractor selection, SDS (Safety Data Sheet) management system, monthly compliance checklist, quarterly internal audits, incident-response protocols. Budget: USD 0.5-1 M/yr (staff, training, contractor services, permitting consultation, contingency retrofits).
- Establish zero-reportable-incident target and incident-response plan; document all materials, quantities and waste streams per EPA/TCEQ databases.
- Finalize EHS Operating Model document by Month 3 (2027-01-14); obtain Fire Authority and TCEQ sign-off on phased-permit roadmap.

**Approval Authorities:** EHS Officer, Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ), Steering Committee

### 11. IP Strategy, Clean-Room Onboarding and Patent Filing Plan

**ID:** 06c69ec0-6dbb-42ea-84d5-ea462fcad25f

**Description:** Comprehensive IP and technology-transfer strategy covering: joint-IP ownership with university/national-lab partners (programme owns final integrated cell architecture and manufacturing processes; partners own publication rights post 6-month review); clean-room onboarding protocol for all employees (mandatory non-use agreements from day one for hires from Tesla or competitors, 6-month probationary observation, weekly IP-compliance audits); provisional-patent filing schedule (>=6 filings in Months 6-12 = 2027-04-14 to 2027-10-14, covering anode, cathode, electrolyte combinations and cell formats); publication embargo (6 months post-filing before open disclosure); and licensing-framework setup (exclusive rights for integrated cell architecture, non-exclusive for enabling materials, royalty structure 2-5% exclusive / 1-2% non-exclusive). Primary audience: IP counsel, chemistry leads, partnership offices, funder.

**Responsible Role Type:** IP Counsel / Licensing Lead

**Primary Template:** Battery IP Landscape Analysis (Questel, Espacenet), provisional patent templates

**Secondary Template:** University Tech-Transfer OTC (Office of Technology Commercialization) standard IP agreements

**Steps:**

- Conduct battery-patent landscape analysis by Month 1 (2026-11-14): identify freedom-to-operate risk zones (existing patents on lithium-sulfur, anode-free architectures, protection layers) and defensible innovation opportunities.
- Develop joint-IP ownership framework with UT Austin, NREL and national-laboratory partners by Month 2 (2026-12-14): clarify ownership of jointly developed compositions, processes and data; set publication embargo (6 months post-filing) and revisability terms (partners may publish after review).
- Draft clean-room onboarding protocol by Month 1 (2026-11-14): non-use agreement template (30-50 pages, covering prior work at competitors), IP-compliance checklist, 6-month probationary observation rules (non-core synthesis, no access to final cell designs), weekly attestations. Deploy to all new hires by Month 2 (2026-12-14).
- Plan provisional patent filings: identify 6-8 patentable inventions from the three active chemistries (e.g., anode composition, protective interface, electrolyte formulation, cell architecture, manufacturing process step) by Month 4 (2027-02-14); file provisionals in Months 6, 8, 10, 12 (2027-04-14, 2027-06-14, 2027-08-14, 2027-10-14) as data matures. Each filing establishes priority date.
- Establish publication embargo policy: materials-science and method papers submitted to peer-reviewed journals after 6-month post-filing review by IP counsel and partners; cell-level architectures and electrolyte formulations remain confidential until manufacturing partner commits to license.
- Develop licensing-framework terms by Month 24 (2028-10-14): exclusive license for integrated cell architecture (10-year term, 3-5% royalty, first refusal to selected licensee); non-exclusive licenses for enabling materials (1-2% royalty, broader use rights). Engage licensing counsel experienced in battery technology transfer.
- Identify prospective licensees by Month 12 (2027-10-14) and conduct informal advisory meetings to understand their application requirements, commercialization timeline and licensing preferences. By Month 24 (2028-10-14), negotiate non-binding term sheet with lead licensee.
- Lock final IP strategy by Month 3 (2027-01-14) via signed governance agreement; attach to Project Charter.

**Approval Authorities:** IP Counsel, Steering Committee, university/national-lab partners

### 12. Funding Release Schedule and Tranche Gate Conditions

**ID:** b04affd3-db03-4874-bc94-523850f6a01c

**Description:** Detailed specification of the USD 300 M funding release schedule: T1 (Months 0-12, 2026-10-14 to 2027-10-14): USD 60 M (facility lease, core team hiring, equipment orders, initial cell builds); T2 (Months 12-24, 2027-10-14 to 2028-10-14): USD 80 M (pilot-line commissioning, first-chemistry gate review, cycle-life and pouch-cell data collection); T3 (Months 24-36, 2028-10-14 to 2029-10-14): USD 70 M (second-chemistry gate and mid-programme chemistry selection); T4 (Months 36-84, 2029-10-14 to 2033-10-14): USD 90 M (optimization and technology transfer). Unallocated reserve: USD 20 M (held inside the USD 300 M cap), with USD 15 M ring-fenced as pivot runway until Month 36 (2029-10-14), leaving USD 2-3 M free contingency. Tranche-release conditions: T2 conditional on Phase 1 permit approval, partner agreements signed, cell model live, cycle-life and Wh/L gates set; T3 conditional on passing Month 18 (2028-04-14) go/no-go gate; T4 conditional on chemistry-selection gate pass at Month 36 (2029-10-14). Monthly burn-rate tracking and quarterly reforecast against actuals. Primary audience: funder, Finance Manager, Steering Committee.

**Responsible Role Type:** Finance & Operations Manager

**Primary Template:** Grant management and tranche-release SOP (federal or foundation template)

**Steps:**

- Develop month-by-month cash-flow model (Months 0-84 = 2026-10-14 to 2033-10-14) showing payroll, capex, opex, partner spending and reserve drawdown. Detail for Months 0-36 (2026-10-14 to 2029-10-14) monthly; aggregate Months 36-84 (2029-10-14 to 2033-10-14) quarterly.
- Reconcile opex vs. tranche gap: average opex ~USD 32.9 M/yr vs. Months 36-84 (2029-10-14 to 2033-10-14) tranche USD 22.5 M/yr; document the USD ~41 M carry-forward requirement from Months 0-36 (2026-10-14 to 2029-10-14) underspend and identify bridge mechanism (deferral, top-up, or external co-funding).
- Specify T2 gate conditions: (1) Phase 1 hazmat permit approved by Austin Fire Authority; (2) >=2 partner characterization agreements signed with confirmed SLAs; (3) cell-level mass-and-volume model operationalized and locked; (4) cycle-life (>=300 cycles) and volumetric (>=950 Wh/L) gate criteria signed by Steering Committee; (5) site lease executed and occupancy by Month 3 (2027-01-14); (6) pilot-line equipment on-site by Month 3 (2027-01-14) and dew-point/electrode-coating specs verified.
- Specify T3 gate conditions: (1) Month 18 (2028-04-14) go/no-go data submitted and reviewed (projected Wh/kg, Wh/L, cycle-life, safety rankings for all three candidates); (2) Steering Committee gate decision documented; (3) if proceed, pilot-line builds ramped to 50-100 cells/month and pouch-cell Wh/L data collected for all candidates by Month 24 (2028-10-14).
- Specify T4 gate conditions: (1) Month 30 (2029-04-14) third-party verification data received (>=500 Wh/kg and >=950 Wh/L in same cells, >=3 replicates per candidate, cycle-life trending); (2) Month 36 (2029-10-14) selection gate decision made (one finalist selected); (3) if no finalist meets Month 30 (2029-04-14) thresholds and Month 36 (2029-10-14) remediation options are exhausted, T4 release is held pending Steering Committee descope decision; (4) if proceed with T4, USD 90 M allocated across Months 36-84 (2029-10-14 to 2033-10-14) for optimization, third-party validation and technology transfer.
- Establish monthly budget variance tracking: actual payroll, capex, partner spending and opex compared against forecast; if variance >10% cumulatively by Month 6 (2027-04-14) or >USD 1 M, escalate to Finance Manager and Steering Committee within 2 weeks.
- Lock funding schedule and gate conditions by Month 1 (2026-11-14); obtain signed approval from funder and Steering Committee.

**Approval Authorities:** Funder, Finance Manager, Steering Committee

### 13. Monitoring, Evaluation and Learning Framework (M&E)

**ID:** f041af18-8728-4a4a-bedf-6eec107c9658

**Description:** Framework for tracking progress against success criteria and gates, quantifying cost-effectiveness, and enabling course-correction. Key performance indicators: cell-level energy density (Wh/kg, Wh/L) trajectory, cycle-life and degradation trends, reproducibility (% cells within ±10%), safety metrics (thermal-runaway onset, reversibility), permitting and site-readiness, staffing and attrition, partner queue times and cost-sharing fulfillment. Data collection: monthly chemistry progress reports (projected Wh/kg/Wh/L vs. actual, cycle-life degradation curves, safety rankings, failure-mode forensics), quarterly budget variance analysis, monthly pilot-line metrics (build count, yield, dew-point control, electrode uniformity), monthly characterization queue-time tracking. Gate reviews at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14): go/no-go decisions supported by quantified data vs. locked criteria. Learning log: document every design decision, rationale and outcome; publish findings (non-confidential) to partner institutions and annual reports. Primary audience: Steering Committee, funder, external advisors, research community.

**Responsible Role Type:** Programme Director with Finance & Operations Manager

**Primary Template:** Logical Framework (Logframe) M&E approach, DAC criteria (OECD)

**Steps:**

- Define key performance indicators (KPIs) and success metrics aligned with goals: cell-level Wh/kg, Wh/L, cycle-life (80% retention threshold), thermal-runaway onset, reproducibility, third-party verification milestones, gate passage rate, cost per verified Wh/kg gain, attrition rate, partner engagement.
- Establish monthly reporting cadence: chemistry leads submit cell-level performance summaries (actual vs. projected Wh/kg/Wh/L, degradation curves, failure-mode summary, planned next steps); finance manager submits budget variance report (actual vs. forecast payroll, capex, opex, reserve consumption); operations manager submits pilot-line metrics (build count, yield, equipment uptime, dew-point and coating uniformity trending); characterization lead submits queue-time and partner fulfillment report.
- Build a live dashboard (spreadsheet or database): track each KPI monthly; flag any value deviating >10% from baseline or trend; automatically escalate alerts to Steering Committee.
- Define gate-review data package (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): quantified cell-level Wh/kg, Wh/L, cycle-life data per candidate; third-party verification results (if Month 30 = 2029-04-14); cost-effectiveness analysis (USD spent per verified Wh/kg gain); risk-register status and mitigation effectiveness; go/no-go criteria assessment (pass/fail for each candidate against locked thresholds); recommendation for advance/hold/descope. Steering Committee reviews within 3 weeks of data submission and votes on passage.
- Establish learning-log practice: every design iteration (chemistry change, additive, process step, equipment swap) documented with: hypothesis, experimental design, result, outcome (success/failure/partial), cost (USD and time), lessons learned, implication for next iteration. Publish annual learning summaries (non-confidential) to partner institutions.
- Finalize M&E framework by Month 3 (2027-01-14); operationalize dashboard and reporting by Month 6 (2027-04-14).

**Approval Authorities:** Programme Director, Steering Committee

### 14. Stakeholder Communication and Engagement Plan

**ID:** 55f7d3d9-e2c7-45d9-9610-3be20778ebac

**Description:** Strategy for transparent, regular communication with funder, Steering Committee, research teams, partner institutions, regulators (Austin Fire Authority, TCEQ), prospective licensees and the research community. Communication channels: monthly progress reports (internal) to Steering Committee; quarterly funder updates (executive summary, KPI dashboard, budget variance, gate status); semi-annual partner forums (UT Austin, NREL, national labs) with findings sharing and feedback; annual public seminars (non-confidential materials science, methods) to the battery-research community; informal licensee contacts (starting Month 12 = 2027-10-14) updating prospective commercial partners. Stakeholder engagement strategy for critical groups: funder (quarterly, detailed budget and technical review); Steering Committee (monthly, 1-hour, gate-focused); partners (quarterly forums, recognition of cost-sharing); regulators (semi-annual compliance updates, incident reporting); licenseees (annual technical advisory meetings, informal updates post-Month 12 = 2027-10-14). Confidentiality: materials-science methods and failure-mode forensics shared with partners; cell-level architectures and electrolyte formulations remain confidential until licensing term sheet signed. Primary audience: all stakeholders.

**Responsible Role Type:** Programme Director with Communications Specialist (or designated outreach lead)

**Primary Template:** Stakeholder Engagement Plan template (APM Group, PRINCE2)

**Steps:**

- Identify stakeholder groups: funder (primary), Steering Committee members (directing, advising, approving), research teams (executing), partner institutions (collaborating, co-funding), regulators (permitting, oversight), prospective licensees (future customer), research community (peer feedback, replication).
- Define communication goals for each group: funder (budget accountability, technical progress, risk mitigation assurance); Steering Committee (timely gate-decision data, conflict resolution); teams (clarity on priorities, feedback loop for learning); partners (recognition, mutual benefit, publication coordination); regulators (compliance transparency, incident prevention); licensees (technical credibility, commitment to commercialization timeline); community (science advancement, methods publication).
- Establish communication channels and cadence: monthly Steering Committee meetings (1-2 hours, live or virtual); quarterly funder calls (30-45 min, executive summary + deep dive on one technical topic); semi-annual partner forums (half-day, results sharing, collaborative problem-solving); annual public seminar (to battery-research community, open registration, non-confidential); informal bi-monthly licensee contacts (starting Month 12 = 2027-10-14).
- Draft communication templates: monthly progress report (KPI snapshot, budget status, gate readiness, risk update, action items); quarterly funder brief (1-pager summary + 5-page detailed review); partner meeting agenda (results, partner recognition, joint problem statements, co-authored publications).
- Define confidentiality boundaries: materials-science and methods shareable with partners after 6-month embargo; cell-level architectures and electrolyte formulations restricted until licensing term-sheet signed; all financial and internal strategic discussions confidential to Steering Committee.
- Establish incident-communication protocol: serious safety, financial, or schedule incidents reported to funder within 48 hours; public incidents (permitting issues, newspaper coverage) communicated to Steering Committee within 24 hours with mitigation plan.
- Finalize Communication Plan by Month 3 (2027-01-14); designate Programme Director or communications specialist as point of contact.

**Approval Authorities:** Programme Director, Steering Committee

### 15. Technology Transfer Readiness and Licensing Framework

**ID:** 3d61d424-bbd5-4557-8933-2ea70519f1e3

**Description:** Specification of the licensable result and hand-off requirements by Month 84 (2033-10-14). Deliverables: (1) complete process documentation (cell synthesis, electrode coating, cell assembly, formation protocol) with tolerance specifications (±5 µm coating thickness, ±2% electrolyte dosing, ±1 atm stack pressure); (2) material specifications and qualified suppliers (>=2 per critical precursor with negotiated pricing and SLAs); (3) pilot-line design and equipment list for replicating the line at scale; (4) cell data package (>=50 cells with full electrochemical characterization, cycle-life curves, abuse-test results, third-party verification); (5) digital models (electrochemical simulation validated within ±5% of experiment, manufacturing process models, engineering CAD); (6) failure-mode and degradation atlas with mitigation strategies tested; (7) design-freeze documentation (Months 72-84 = 2032-10-14 to 2033-10-14 locked design, no architecture changes). Licensing tiers: exclusive license for integrated cell architecture (10-year term, 3-5% royalty); non-exclusive for enabling materials. Prospective licensees identified by Month 12 (2027-10-14) from aerospace, automotive, energy-storage sectors; non-binding term sheet by Month 24 (2028-10-14); formal licensing negotiations Months 72-84 (2032-10-14 to 2033-10-14). Primary audience: licensing counsel, prospective licensees, Steering Committee.

**Responsible Role Type:** IP/Licensing Lead with Steering Committee oversight

**Primary Template:** Technology Transfer Agreement template (university OTC model, battery-industry licensing precedents)

**Steps:**

- Define 'licensable result' checklist by Month 3 (2027-01-14): (a) process documentation completeness (all steps, parameter tolerances, measurement protocols); (b) supply-chain validation (at least 2 qualified suppliers per critical precursor, pricing locked); (c) cell data reproducibility (>=50 independent builds showing >=90% within ±10%); (d) third-party verification (independent test-lab report confirming >=500 Wh/kg, >=1000 Wh/L, >=300 cycles); (e) digital models (simulation/measurement validation >80% accuracy); (f) failure-mode forensics (root-cause coding for >=80% of failed cells, mitigation strategies tested and documented); (g) design freeze (no architecture changes after Month 72 = 2032-10-14).
- Develop preliminary IP strategy by Month 2 (2026-12-14): identify defensible technical moats (compositions, interfaces, processes not obvious to competitors). Provisional patents filed Months 6-12 (2027-04-14 to 2027-10-14) covering core inventions.
- Identify prospective licensees by Month 6 (2027-04-14): 5-10 candidates in weight-critical (aviation, drone) or EV/energy-storage sectors. Conduct market scan (licensing appetite, technical roadmap, commercialization timeline). Select 3-5 for informal contact starting Month 12 (2027-10-14).
- Lock licensing-framework terms by Month 24 (2028-10-14): exclusive-license scope (core cell architecture, integrated manufacturing, specified field of use); non-exclusive scope (enabling materials, methods); royalty range (2-5% exclusive, 1-2% non-exclusive); minimum commercialization timeline (e.g., first commercial prototype within 3-5 years post-transfer); force-of-life terms (shelf-life, storage, transportation requirements).
- Negotiate non-binding term sheet with lead licensee by Month 24 (2028-10-14): confirm technical requirements and performance specs to ensure final cell architecture aligns with licensee's roadmap.
- Plan technology-transfer phase (Months 72-84 = 2032-10-14 to 2033-10-14): (1) Months 72-76 (2032-10-14 to 2033-02-14): process documentation completion, pilot-batch manufacturing (100+ cells with licensee observer present), supply-chain handoff; (2) Months 76-80 (2033-02-14 to 2033-06-14): licensing negotiations, IP transfer agreement preparation, manufacturing scale-up feasibility study with licensee engineering; (3) Months 80-84 (2033-06-14 to 2033-10-14): formal licensing-agreement execution, technology transfer, licensee team training, handoff sign-off.
- Finalize licensing-readiness checklist by Month 30 (2029-04-14); begin formal tech-transfer planning by Month 60 (2031-10-14).

**Approval Authorities:** IP/Licensing Lead, Steering Committee, prospective licensee (non-binding term-sheet counterparty)

### 16. Governance Charter and Decision-Authority Framework

**ID:** 29214f88-343b-4b6f-839a-06eed6607e59

**Description:** Specification of governance structure, decision-making authority and escalation protocols. Scientific Steering Committee (Programme Director, 3-4 Chemistry Leads, 1 external technical advisor, 1 Funder representative) meets monthly, makes gate-advance/hold/descope decisions within 3 weeks of evidence submission. Independent red team of 2-3 scientists reports directly to Steering Committee chair and funder representative (bypassing core teams); tasked with replicating key results and validating progress claims; findings are binding on gate decisions if measured data contradicts core-team claims by >5% on energy density or >10% on cycle-life (2-week resolution window for disputes). Monthly progress-review meetings (1 hour, Steering Committee + core leads) for KPI tracking and risk escalation. Gate-review meetings (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) structured as: (1) core-team technical presentation (30 min), (2) red-team independent verification report (20 min), (3) questions and discussion (20 min), (4) Steering Committee vote on gate passage (yes/hold/descope) within 3 weeks. Primary audience: Steering Committee, red team, core research teams.

**Responsible Role Type:** Programme Director

**Primary Template:** Board Charter template, corporate governance framework

**Steps:**

- Define Steering Committee composition and roles: Programme Director (chair, technical lead, break-tie vote), 3-4 Chemistry Leads (represent active chemistries, contribute technical expertise), 1 external technical advisor (battery industry/national lab expert, neutral perspective), 1 Funder representative (budget authority, funding-release signoff).
- Establish decision-authority matrix: Steering Committee votes on gate passage (advance/hold/descope), major budget reallocations (>USD 5 M), descope decisions, policy exceptions. Programme Director votes on operational decisions (hiring, procurement <USD 1 M, vendor selection). Finance Manager votes on budget variance escalation (>10% or >USD 1 M).
- Define monthly meeting agenda: KPI dashboard review (10 min), risk-register update (10 min), chemistry-progress summary per lead (20 min total), financials and budget variance (5 min), action-item review and next steps (5 min). Decisions deferred; monthly meeting is information-sharing only.
- Define gate-review meeting structure (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): (1) core-team data package submitted 2 weeks prior (cell-level Wh/kg/Wh/L/cycle-life, third-party verification results if applicable, go/no-go assessment vs. locked criteria); (2) red-team independent review completed, findings submitted 1 week prior; (3) live meeting (2-3 hours): core-team presentation, red-team findings, Q&A, Steering Committee deliberation and vote. Gate decision documented in writing within 3 days; announced to research teams within 1 week.
- Establish red-team authority: red team's measured data or findings supersede core-team claims if discrepancy >5% on energy density or >10% on cycle-life; core team has 2 weeks to provide additional evidence or acknowledge discrepancy. Steering Committee votes based on red-team findings unless core team's rebuttal is compelling. Red-team lead reports separately to Steering Committee chair and funder representative (not to core teams).
- Set escalation thresholds: if actual risk outcome (e.g., payroll breach of >USD 2 M, chemistry-tournament failure at Month 30 = 2029-04-14 check-in, partner characterization queue >6 weeks) materialized, escalate to Steering Committee within 1 week with mitigation proposal.
- Lock governance charter by Month 1 (2026-11-14); distribute to all stakeholders; confirm acceptance in writing.

**Approval Authorities:** Funder, Programme Director, Steering Committee

### 17. Current State Assessment of High-Energy Battery Technology Development and Market Context

**ID:** 53b19410-5d45-4ef4-a563-eec837a23a9d

**Description:** Baseline document assessing the current state (Month 0 = 2026-10-14) of advanced battery chemistries (lithium-sulfur, anode-free, conversion cathodes) in the R&D and near-commercialization landscape. Reviews published cell-level energy densities, cycle-life durability, thermal-runaway safety data, pilot-line readiness and commercialization timelines from public literature, national labs (Battery500, ARPA-E REFUEL), and commercial developers (Sion Power, Solid Power, EnerTech). Benchmarks the programme's targets (>=500 Wh/kg, >=1000 Wh/L, >=300 cycles) against state-of-the-art and identifies technological bottlenecks (cycle-life degradation, volumetric-density penalties, thermal-runaway onset, manufacturability). Provides context for technology-transfer and licensing landscape (battery integrators, OEMs, investment appetite). Primary audience: Steering Committee, research teams, funder, prospective licensees.

**Responsible Role Type:** Programme Director with technical-analysis support

**Primary Template:** Roadmap and landscape-analysis report (R&D survey format, e.g., IVL battery roadmap model)

**Steps:**

- Collect published cell-level energy-density data from 2020-2026 literature: lithium-sulfur (gravimetric typical 400-500 Wh/kg at coin scale, rare >=500; volumetric 600-900 Wh/L due to polysulfide migration); anode-free architectures (claimed 450-550 Wh/kg lab-scale, <100 cycle-life maturity); conversion cathodes (350-450 Wh/kg, >=100 cycles demonstrated). Document the gap between material-level and cell-level numbers (estimate 10-25% density drop after packaging).
- Document cycle-life challenges: lithium-sulfur (polysulfide dissolution, lithium-ion depletion, 200-300 cycle typical, rarely >=400); anode-free (lithium-plating reversibility, 150-250 cycles typical); conversion cathodes (structural collapse, electrolyte oxidation, 100-300 cycles typical). Identify interface-engineering approaches tested (electrolyte additives, protective coatings, binders) and success rates.
- Assess thermal-runaway safety data from published literature: lithium-sulfur (typical differential scanning calorimetry onset 100-120°C, poor reversibility post-overcharge); anode-free (110-140°C depending on protective layer); conversion cathodes (90-110°C, worsening compared to conventional oxide cathodes). Note lack of consensus on differential scanning calorimetry vs. adiabatic-calorimetry correlation for high-energy cells.
- Review pilot-line readiness: Battery500 PNNL lead lab (pouch-cell standard build, reproducibility >=90%, described in published protocols); Sion Power Licerion line (private, ~100 cells/month claimed, limited public data); Solid Power (pilot line operational, confidential terms); university and national-lab lines (queue-dependent, <50 cells/month typical academic throughput). Document lead-times and cost benchmarks for modular vs. owned lines.
- Identify commercialization landscape: battery integrators (Samsung SDI, LG, Panasonic, CATL pursuing solid-state or lithium-sulfur pilots); automotive OEMs (BMW, Hyundai, Tesla pursuing high-energy research); aerospace (Joby, Lilium pursuing weight-critical aviation cells, timelines 2028-2032); energy-storage (QuantumScape, Form Energy pursuing durability over energy density). Document licensing precedents and royalty ranges (typically 2-8% for exclusive, 0.5-2% non-exclusive).
- Document technical bottlenecks unresolved as of Month 0 (2026-10-14): volumetric penalties (separators, current-collector thickness eroding density post-packaging); cycle-life degradation mechanisms (interfacial instability, lithium-ion loss); safety thresholds (thermal-runaway onset trade-off vs. energy density); manufacturing cost (pilot-line equipment, precursor supply, yield losses at scale). Identify research gaps where the programme can differentiate.
- Publish baseline assessment by Month 6 (2027-04-14); reference in M&E framework as benchmark for assessing technology-transfer readiness and competitive positioning at delivery (Month 84 = 2033-10-14).

**Approval Authorities:** Programme Director, Steering Committee

### 18. Site Lease and Facility Operations Agreement (Austin R&D Campus)

**ID:** 9ecb83aa-3aeb-4bb4-826d-30dc1da853b9

**Description:** Legal agreement (landlord-tenant lease) for the Austin R&D facility (target: Southeast Austin, SH-71 area, 5,000-10,000 m² estimate). Specifies occupancy by Month 3 (2027-01-14), lease term (3 years minimum, renewable month-to-month), base rent, utilities, facility maintenance, hazardous-materials handling and storage permissions (reactive metals, organic solvents, inert-atmosphere glovebox operations), fire-authority inspection rights, and insurance requirements. Includes termination clauses (90-day notice permitted if operations conclude early or pivot to different location). Negotiated and executed by Month 1 (2026-11-14) to ensure on-time occupancy. Primary audience: site manager, facilities, legal counsel, landlord.

**Responsible Role Type:** Facilities Manager with Legal Counsel and EHS Officer

**Primary Template:** Commercial Real Estate Lease template (SIOR, BOMA standard form)

**Secondary Template:** Hazardous-Materials Use Addendum (facility-specific)

**Steps:**

- Identify 3-5 candidate properties in Southeast Austin or Northeast Travis County (target location per decision); request space-planning consultations and site tours by Month 0 (2026-10-14).
- Define facility requirements in writing: minimum 5,000 m² usable (estimate), zoning for light industrial/lab use, power (500+ kVA available), HVAC, hazardous-waste handling capability, ground-floor access for equipment, proximity to highways and airport.
- Negotiate lease terms: 3-year base term, 3-month renewal options thereafter, base rent (market-dependent, ~USD 10-15/sq ft/yr estimate for industrial Austin), CAM (common-area maintenance) charges, utilities (landlord or tenant responsibility, clarify for high power/HVAC use).
- Add hazardous-materials addendum: specify permitted activities (lithium-metal synthesis, organic-solvent handling in fume hoods, inert-atmosphere glovebox operations, abuse-testing chambers) and quantitative limits (e.g., max 500 L flammable solvents on-site at any time, max 10 g lithium metal per batch).
- Include fire-authority inspection-access clause and insurance requirements (general liability, hazardous-materials liability, property). Confirm landlord consent to these conditions before lease signing.
- Execute lease by Month 1 (2026-11-14), with occupancy date contractually locked at Month 3 (2027-01-14). Include 30-day fit-out period (Month 1-2 = 2026-11-14 to 2026-12-14) for facility preparation (dry-room installation, equipment delivery, utility upgrades).

**Approval Authorities:** Programme Director, Finance Manager, Legal Counsel, Landlord

### 19. Supply-Chain Procurement and Inventory Management Strategy

**ID:** 42c4f594-df16-400c-a937-0d2e03ae15a3

**Description:** Comprehensive supplier qualification, ordering and inventory-management plan for all critical precursors (lithium compounds, sulfur, cathode materials, specialty salts, fluorinated solvents, separators, current collectors) across the 84-month programme. Specifies: supplier lists (>=2 per critical material), negotiated lead-times and pricing (fixed-price contracts for high-volume items, cost-plus for volatile or small-quantity specialty materials), JIT (just-in-time) delivery windows (2-4 week windows every 6-8 weeks synchronized with cell-build cycles), inventory holding limits (not >3 months normal burn rate), scrap and failed-cell recycling/disposal strategy (lithium recovery, solvent recovery, waste cost optimization). Quarterly supplier and inventory audits (compare actual consumption to forecast, adjust orders accordingly). Intended audience: Procurement Officer, Chemistry Pathway Lead, Finance Manager.

**Responsible Role Type:** Procurement Officer (or Materials Planning Officer)

**Primary Template:** Supply-Chain Management Plan (APICS, SCOR model)

**Steps:**

- Build a materials-demand model (Month 4 = 2027-02-14 onwards): forecast monthly consumption for each candidate chemistry (anode, cathode, electrolyte, separators, current collectors) from Month 6 (2027-04-14) through Month 36 (2029-10-14), accounting for planned ramp-up (50 cells/month baseline, scaling to 200 cells/month by Month 24 = 2028-10-14) and potential deprioritization of candidates.
- Conduct supplier audits for each critical precursor by Month 1 (2026-11-14): identify >=2 qualified suppliers per material, document lead-times (weeks), minimum-order quantities, SLA terms and pricing. Confirm dual-sourcing availability and document any single-source bottleneck materials requiring early strategic inventory.
- Negotiate fixed-price and cost-plus contracts by Month 2 (2026-12-14) for high-volume items (lithium compounds, specialty salts): lock price and delivery for 12-month blocks; include quarterly price-adjustment clauses tied to commodity indices (lithium carbonate spot price, etc.) if volatility is high.
- Establish JIT delivery schedule by Month 3 (2027-01-14): work with suppliers to set 2-4 week delivery windows every 6-8 weeks; synchronize to cell-build cycles (if 100 cells/month, require 20 g per month of cathode material, so 120-160 g every 6-8 weeks in timed delivery).
- Define inventory holding limits: target 3-month buffer for normal-burn-rate items (allows one supply disruption to be absorbed without halting builds), but minimize overstock. Flag any candidate receiving <10 cells/month (rare usage) for inventory control or return-to-supplier option.
- Implement failed-cell disassembly and material-recovery program by Month 18 (2028-04-14): lithium metal recovery via licensed contractor (USD 50-100 K estimate) or internal process; solvent recovery via on-site distillation or contractor; target recovery of 15-25% of failed-cell material cost as offset to precursor budget.
- Establish quarterly audits (Month 12, 24, 36 = 2027-10-14, 2028-10-14, 2029-10-14, etc. = 2027-10-14, 2028-10-14, 2029-10-14): compare actual consumption against forecast; investigate variances >20%; adjust future procurement (increase or decrease order quantities) based on actuals.

**Approval Authorities:** Procurement Officer, Chemistry Pathway Lead, Finance Manager

### 20. Independent Red Team Operational Charter and Verification Protocol

**ID:** 89888af1-0f29-4485-84c7-8cf1216061e5

**Description:** Charter defining the independent red team's (2-3 scientists) authority, governance, verification responsibilities and escalation protocol. Red team reports directly to Steering Committee chair and funder representative (bypassing core research teams), with exclusive access to in-house post-mortem instruments (or priority slots at external characterization facilities) for independent replication of key results. Verification protocol specifies: which results are independently verified (all cell-level energy-density and cycle-life claims at gates; representative failed-cell post-mortems), turnaround (1-2 weeks for replication), acceptance criteria (measured value within ±5% on Wh/kg or ±10% on cycle-life = pass; >5%/>10% = flag for investigation and potential gate hold). Red-team findings are binding on gate decisions if discrepancy exceeds thresholds and core team cannot provide additional evidence within 2 weeks. Intended audience: red-team scientists, Steering Committee, core research teams.

**Responsible Role Type:** Independent Red Team Lead

**Primary Template:** Quality Assurance / Independent Verification charter (NASA, DoD models for mission-critical verification)

**Steps:**

- Define red-team scope: independent replication of cell-level Wh/kg and Wh/L measurements (coin-cell and pouch-cell), cycle-life degradation curves (0-100 cycles, representative sample), and failure-mode forensics (SEM/EDS on selected failed cells). Do not include novel chemistry discovery or synthesis (core-team responsibility); focus on validation.
- Hire 2-3 scientists (battery engineers, characterization specialists) with >=5 years experience and demonstrated commitment to scientific rigor. Include a lead with authority to report directly to Steering Committee chair without core-team intermediation.
- Provide exclusive or priority access to in-house post-mortem instrument (SEM/EDS or XRD, commissioned Month 8 = 2027-06-14) or negotiate priority time slots at external characterization partners (>=4 slots/month reserved for red team).
- Establish verification turnaround: replication of key results completed within 1-2 weeks of core-team data submission; findings reported to Steering Committee in writing, with graphical comparison of red-team vs. core-team results side-by-side.
- Define escalation: if red-team replication differs from core-team claim by >5% on Wh/kg or >10% on cycle-life, issue a 'findings flag'; core team has 2 weeks to respond (provide additional evidence, identify measurement error, or acknowledge discrepancy). Steering Committee votes on gate passage based on red-team findings if core team cannot satisfactorily explain discrepancy.
- Publish red-team charter and verification protocol by Month 1 (2026-11-14); ensure all research teams understand that red-team findings are independent and binding on gate decisions; establish non-punitive culture (findings are learning opportunities, not grounds for team critique).

**Approval Authorities:** Steering Committee, Funder Representative, Independent Red Team Lead

### 21. Project Execution Plan: Detailed Milestone Schedule and Resource Allocation (Months 0-36 = 2026-10-14 to 2029-10-14)

**ID:** 4af293be-3e91-41d2-8b22-ae614336ecda

**Description:** Detailed project schedule for the first 3 years (Months 0-36 = 2026-10-14 to 2029-10-14), with weekly-level granularity for critical-path items and monthly-level for supporting work. Includes: site selection and lease execution (Months 0-1 = 2026-10-14 to 2026-11-14), permitting pre-applications and Phase 1 submission (Months 0-2 = 2026-10-14 to 2026-12-14), dry-room/pilot-line deployment and commissioning (Months 1-6 = 2026-11-14 to 2027-04-14), partner-agreement negotiation and execution (Months 0-3 = 2026-10-14 to 2027-01-14), EHS onboarding and clean-room protocols (Months 1-2 = 2026-11-14 to 2026-12-14), IP strategy and provisional-patent filing (Months 2-12 = 2026-12-14 to 2027-10-14), chemistry-tournament candidate selection and coin-cell baseline characterization (Months 3-9 = 2027-01-14 to 2027-07-14), pouch-cell prototyping and Wh/L validation (Months 6-18 = 2027-04-14 to 2028-04-14), cycle-life stacking and deprioritization milestones (Months 12-24 = 2027-10-14 to 2028-10-14), Month 18 (2028-04-14) gate data preparation and review (Months 12-18 = 2027-10-14 to 2028-04-14), Month 30 (2029-04-14) third-party verification scheduling and sample submission (Months 18-30 = 2028-04-14 to 2029-04-14). Identifies critical-path items (permitting, pilot-line deployment, pouch-cell builds) and secondary items (IP filing, partner meetings) with dependencies and resource allocation (FTE, budget reservations). Intended audience: Programme Director, Steering Committee, core research teams.

**Responsible Role Type:** Programme Director with Finance & Operations Manager

**Primary Template:** Gantt chart (Microsoft Project, Smartsheet) with resource-allocation and dependency tracking

**Steps:**

- Define critical-path logic: site occupancy by Month 3 (2027-01-14) is prerequisite for pilot-line deployment; Phase 1 permit approval by Month 3 (2027-01-14) required for dry-room operations; first pouch cells cannot be built before Month 6 (2027-04-14) (pilot-line commissioning). Chemistry selection (coin-cell screening and candidate narrowing) occurs Months 3-12 (2027-01-14 to 2027-10-14) in parallel with facility setup.
- Create month-by-month milestone list: Month 0 (2026-10-14) kickoff and site-search start; Month 1 (2026-11-14) site lease signed, EHS lead hired, partner negotiations begun, clean-room protocols published; Month 2 (2026-12-14) Phase 1 permit submitted, pilot-line RFQ awarded, IP counsel engaged, >=1 provisional patent filed; Month 3 (2027-01-14) site occupancy, Phase 1 permit approval target, dry-room equipment delivery, >=2 partner agreements signed, cell-level model operationalized; ... (continuing through Month 36 = 2029-10-14).
- Identify dependencies: pilot-line commissioning (Month 3-6 = 2027-01-14 to 2027-04-14) depends on site occupancy and electrical/HVAC completion (contractor work); first pouch builds (Month 6 = 2027-04-14) depend on pilot-line dew-point and coating-uniformity commissioning; Month 18 (2028-04-14) gate (pouch-cell data) depends on having 100-200 pouch cells built and cycled (requires 6-10 months Months 6-18 = 2027-04-14 to 2028-04-14).
- Allocate resources to milestones: site setup (FTE: Facilities Manager 1.0, Finance 0.5); chemistry coin-cell work (FTE: Chemistry Lead 1.0, postdocs 2-3, technicians 1-2); pouch-cell builds (FTE: Cell Engineering Manager 1.0, technicians 2-3); characterization (FTE: Characterization Lead 1.0, with shared time from partners); finance/admin (USD spend on facilities, equipment, partner cost-sharing).
- Finalize schedule by Month 1 (2026-11-14); publish Gantt chart and monthly milestone list; distribute to all stakeholders. Update quarterly (Months 6, 12, 18, 24, 30 = 2027-04-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14) based on actual progress and variances.

**Approval Authorities:** Programme Director, Steering Committee

## Documents to Find

### 1. Lithium-Sulfur, Anode-Free and Conversion-Cathode Cell-Level Energy Density and Cycle-Life Data (2020-2026)

**ID:** 119d31a0-0e6d-4484-ad6e-09ff2dd3ec31

**Description:** Published or openly available data from peer-reviewed journals, national lab technical reports (NREL, ANL, PNNL Battery500 publications) and conference proceedings documenting measured cell-level (not material-level) Wh/kg and Wh/L for lithium-sulfur, anode-free lithium-metal, and conversion-cathode chemistries. Includes cycle-life degradation curves, thermal-runaway onset temperatures (differential scanning calorimetry and adiabatic calorimetry if available), and internal short-circuit failure modes. Intended audience: chemistry and materials teams for baseline performance understanding and identification of technological gaps relative to the programme targets (>=500 Wh/kg, >=1000 Wh/L, >=300 cycles).

**Recency Requirement:** Published within last 3 years (2023-2026 preferred; 2020-2026 acceptable for foundational results from Battery500 and related DOE programmes).

**Responsible Role Type:** Chemistry Pathway Lead with materials-science literature review support

**Access Difficulty:** Easy. Most DOE-funded Battery500 and NREL publications are freely available through OSTI.gov and journal open-access articles. Battery500.org website also hosts consortium publications and data summaries. Academic and national-lab preprints available via arXiv and ResearchGate. No authentication or fees required for government research data.

**Steps:**

- Search Google Scholar, Scopus and Web of Science using keywords: 'lithium-sulfur cell energy density', 'anode-free lithium-metal pouch cell', 'conversion cathode cycle life', 'cell-level Wh/kg'. Filter for 2020-2026.
- Download and review peer-reviewed journal articles (Journal of Power Sources, ACS Energy Letters, Nature Energy, Advanced Energy Materials) for cell-level data (not coin-cell or single-layer proxy numbers).
- Access NREL, PNNL, Argonne and LBNL technical reports and annual reports from the DOE Vehicle Technologies Office and ARPA-E REFUEL programme (publicly available via www.osti.gov, ARPA-E website).
- Contact Battery500 PNNL programme office (or equivalent DOE-funded consortia) to request published technical reports and benchmark pouch-cell data.
- Compile a spreadsheet of measured cell-level Wh/kg, Wh/L, cycle count (to 80% retention), thermal-runaway onset by chemistry and development year.

### 2. Austin-Area Battery Technology and Electrochemistry Talent Market: Salary Benchmarks and Availability

**ID:** e14dec59-0022-46af-8231-b4af7bf46f6d

**Description:** Current (2026) salary survey data for battery scientists, electrochemists, materials engineers and manufacturing technicians in the Austin metropolitan area. Includes baseline and Tesla-proximity salary premium (proposed 15-20% estimate), benefits, and talent availability/turnover rates in the local battery and EV sectors. Intended audience: Talent Recruitment & Retention Manager and Finance Manager for payroll planning and recruitment strategy validation, addressing the USD ~4.8 M/yr payroll understatement risk flagged in pre-assessment.

**Recency Requirement:** Current as of 2026 (most recent available); 2025-2026 data preferred; 2024 data acceptable if 2026 is unavailable. Salary surveys from Glassdoor, LinkedIn, Mercer or battery-industry recruiters (Kforce, Allegis Group) are typical sources.

**Responsible Role Type:** Talent Recruitment & Retention Manager with Finance & Operations Manager

**Access Difficulty:** Medium. Glassdoor and LinkedIn salary data are freely accessible but may be incomplete or aggregated nationally (requiring filtering for Austin). Professional recruiters and HR departments provide confidential data only upon request and relationship-building. Mercer and other major consulting firms' formal salary surveys are proprietary and require subscription or consulting engagement. Bottom-up estimate from 10-20 openly posted job descriptions (LinkedIn, company websites) plus informal recruiter conversations is a viable low-cost alternative.

**Steps:**

- Contact battery-industry recruiters in Austin (Kforce, Allegis Group, Robert Half Technology) and request unpublished salary benchmark data or conduct a market survey of recent placements.
- Search Glassdoor, LinkedIn Salary, Levels.fyi and Payscale using keywords: 'battery scientist Austin TX', 'electrochemist Tesla area', 'battery engineer Texas'; compile salary ranges and note any Tesla premium.
- Request the 2025-2026 salary survey report from professional organizations (Electrochemical Society, American Chemical Society) if regional Austin data is included.
- Contact UT Austin Office of Graduate Studies or McComb School of Engineering for guidance on postdoc and graduate-student salary benchmarks in Austin (lower cost, pipeline recruitment).
- Reach out to established battery manufacturers or integrators based in or near Austin (e.g., Tesla Fremont HR benchmarking, or other EV suppliers recruiting in the area) for unofficial salary guidance (via confidential conversations with HR contacts).

### 3. Austin Fire Authority and Texas TCEQ Hazardous-Materials Permitting Requirements and Timelines for Lithium-Metal and Solvent Research Facilities

**ID:** d434b270-5b22-4630-ba9c-bb11810bb337

**Description:** Current (2026) regulatory requirements, application templates, and typical approval timelines from the Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ), and Travis County Environmental Services for facilities handling lithium metal, organic solvents, and performing thermal-runaway and abuse testing. Includes Phase 1 (dry-room, inert-atmosphere glovebox operations), Phase 2 (reactive synthesis) and Phase 3 (abuse-testing chambers) permit scopes, conditional-use-authorization pathways to accelerate approvals, and hazardous-waste generator registration processes. Intended audience: EHS Officer and Programme Director for permitting-timeline and contingency-plan development, addressing the 6-8 month permitting-delay risk.

**Recency Requirement:** Current as of 2026; regulations typically stable but emergency rules or zoning changes can occur; 2024-2026 guidance documents preferred; 2020+ background acceptable.

**Responsible Role Type:** EHS Officer with Programme Director

**Access Difficulty:** Medium. Fire Authority and TCEQ staff provide guidance and published documents freely during pre-application meetings and via email. Published regulations (EPA and Texas codes) are free online. Zoning and conditional-use procedures are posted on municipal websites. However, specific timelines and internal approval processes are not always documented; direct contact with regulators and possibly a consultation with a permitting specialist or environmental attorney familiar with the Austin area may be needed to confirm realistic Phase 1 and Phase 2 approval schedules.

**Steps:**

- Contact the Austin Fire Authority Marshall's Office (Fire Code and Permitting Division) directly by phone or email; request a pre-application consultation meeting (target within 7 days) and a written summary of permitting requirements for 'lithium-metal synthesis and thermal-runaway testing facility'.
- Visit the Texas Commission on Environmental Quality (TCEQ) website (www.tceq.texas.gov); download guidance on hazardous-waste generator registration (30 CFR 260-273 federal rules as adopted by Texas) and air-permit thresholds for volatile organic compound (VOC) emissions.
- Contact Travis County Environmental Services and request zoning and facility-planning guidance for light industrial/lab use in Southeast Austin or Northeast Travis County (target locations per decision).
- Search the Austin and Travis County municipal code databases (available online) for conditional-use-authorization procedures and expedited-permitting pathways for research facilities.
- Request published timelines or case studies from TCEQ or fire authority on how long Phase 1 (dry-room only) and Phase 2 (synthesis) permits typically take (6-8 month estimate from pre-assessment; confirm or revise based on regulatory feedback).

### 4. Modular Dry-Room and Pouch-Cell Fabrication Equipment Vendors, Specifications and Lead-Times

**ID:** 61f0c338-1bf0-43a4-9b9c-537c4a2dfd3c

**Description:** Current vendor offerings and pricing for modular (containerized or relocatable) dry-room and pouch-cell fabrication systems (dew-point control <-30°C, electrode-coating uniformity ±10 µm, electrolyte-dosing precision ±2%, 50-100 cells/month capacity, estimate). Includes equipment specifications, lease vs. ownership terms, lead-times (order-to-delivery), and operating costs. Vendors: Mbraun (MOD drybox systems), Glove-box Company, or equivalent. Intended audience: Cell Engineering & Pilot-Line Manager and Finance Manager for pilot-line procurement and cost estimation, addressing the pilot-line capital-lock risk and operational-start timeline.

**Recency Requirement:** Current pricing and lead-times as of 2026 (as recent as possible; vendor quotes valid through Q1-Q2 2027 preferred).

**Responsible Role Type:** Cell Engineering & Pilot-Line Manager with Finance Manager

**Access Difficulty:** Easy. Equipment vendors publish product specifications, lead-times and general pricing on their websites. Detailed pricing and custom lease terms require direct RFQ requests, but vendors respond within 2-4 weeks. References from existing users may require confidentiality agreements or can be obtained via academic/national-lab contacts. No special access or authentication required.

**Steps:**

- Contact Mbraun (Europe and US offices) directly via website (www.mbraun.com) or sales email; request an RFQ for modular dry-room and pouch-line package (50-100 cells/month, dew point <-30°C). Obtain lease and operating-cost terms.
- Contact Glove-box Company (UK-based but supplies globally) and other dry-room system vendors (Phoenix Instrument, Inert Technology); request comparable RFQs.
- Request references from existing users of modular dry-room systems (contact NREL, national labs, university battery centers) for feedback on lead-time accuracy and equipment reliability.
- Search vendor catalogs and product datasheets (available on company websites) for specification verification (dew-point control range, coating-uniformity tolerance, electrolyte-dosing accuracy).
- Request pricing for operating leases (cost per month, service included, exit terms) and capital-purchase options; clarify whether delivery is included in lead-time quoted or adds additional weeks.

### 5. University of Texas at Austin and National Laboratory (NREL, Argonne) Characterization Facilities: Capacity, Turnaround Times and Cost-Sharing Models

**ID:** c90e5446-2cb9-4f4d-869e-e9e48b01562d

**Description:** Current (2026) characterization capability, instrument access, turnaround times and cost-sharing agreements at UT Austin (Materials Science & Engineering, Texas Materials Institute), NREL Electrochemistry Branch, and Argonne Applied Materials Division for operando and post-mortem battery diagnostics (X-ray diffraction, scanning-electron microscopy with energy-dispersive X-ray spectroscopy, electrochemical impedance spectroscopy). Includes typical queue times (weeks), cost per sample, partnership agreements and publication-embargo policies. Intended audience: Partner & Ecosystem Lead and Characterization & Forensics Specialist for partner-agreement negotiation and queue-management planning, addressing the characterization-access bottleneck risk (4-8 week delays without agreements).

**Recency Requirement:** Current as of 2026; capability and access policies can change with facility upgrades or staffing; 2024-2026 data preferred.

**Responsible Role Type:** Partner & Ecosystem Lead with Characterization & Forensics Specialist

**Access Difficulty:** Easy. University and national-lab websites publish facility descriptions, contact information, and general partnership guidelines. Initial inquiries via email or phone are answered within 2 weeks. More detailed partnership negotiations and capacity confirmation require formal meetings, but these are typically welcomed as part of building R&D relationships. No subscription or special access required; all information is publicly available or provided upon request to researchers.

**Steps:**

- Visit UT Austin Texas Materials Institute (TMI) website (tmi.utexas.edu) and contact the Institute Director or relevant faculty (e.g., materials-characterization groups) via email; request a meeting to discuss characterization access, queue times and partnership opportunities.
- Contact NREL Electrochemistry Branch (www.nrel.gov/chemistries) via the programme manager or administrator; request information on beamtime availability, turnaround times and cost-sharing models for battery research partnerships.
- Contact Argonne Applied Materials Division (www.anl.gov) and inquire about partnership models and characterization access for external R&D programmes.
- Request published partnership or user agreements (if publicly available) from existing university or national-lab battery-research partnerships; these may outline cost-sharing rates and access terms.
- Query recent publications from UT Austin, NREL or Argonne on battery materials (Google Scholar, institution repository) to identify active groups and potential partnership contacts.

### 6. Existing Battery Technology Patents and Freedom-to-Operate (FTO) Analysis for Lithium-Sulfur, Anode-Free and Conversion-Cathode Chemistries

**ID:** 5515f118-d1ae-4945-8c8a-3cbdd1ca68e6

**Description:** Patent landscape analysis (via Espacenet, Google Patents, USPTO database) identifying key patents covering lithium-sulfur cell architectures, anode-free lithium-metal cells, conversion-cathode designs, protective electrolyte interfaces and related manufacturing processes. Includes patent families, expiry dates and freedom-to-operate (FTO) risk zones (patents likely to be asserted by licensors in the battery space). Intended audience: IP Counsel and Chemistry Pathway Lead for patent-filing strategy development and FTO clearance, addressing the IP-contamination and patent-value risk.

**Recency Requirement:** Patent landscape current as of 2026; include patents filed through 2024-2025 (most recent available in public databases); foundational patents filed 2015-2020 also relevant for expired or expiring prior art.

**Responsible Role Type:** IP Counsel with Chemistry Pathway Lead

**Access Difficulty:** Easy. Patent databases are freely accessible via web browsers (Espacenet, Google Patents, USPTO). Searching is straightforward but requires technical familiarity with patent claims and citation trails. Full FTO analysis typically requires professional patent counsel ($5-20 K for a comprehensive analysis), but preliminary landscape mapping can be done in-house using free databases.

**Steps:**

- Access Espacenet (www.espacenet.com), Google Patents (patents.google.com), and USPTO PAIR database (pair.uspto.gov) directly via web browsers (free, no subscription required).
- Search for patents using keywords: 'lithium sulfur cathode', 'lithium metal anode', 'anode free cell', 'conversion cathode', 'electrolyte interface', 'solid electrolyte lithium'; filter by filing/publication date (2015-2026), patent family and assignee.
- Compile a landscape map: list key patent families by assignee (e.g., patents from Tesla, Panasonic, Samsung SDI, QuantumScape, Sion Power, solid-state battery consortia, and academic institutions); note expiry dates and citation frequency (indicating foundational vs. incremental patents).
- Engage a patent counsel with battery expertise (if not already retained) to conduct an FTO analysis: identify patents likely to be asserted in the US/EU/Asia and assess design-around risk vs. licensing cost.
- Document any overlaps with emerging Pragmatic Foundation chemistry candidates (e.g., if a competitor holds strong patents on lithium-sulfur with protective coatings, the design path may need to avoid that specific approach or pre-license).

### 7. Lithium Metal, Sulfur, High-Purity Cathode Materials and Specialty Electrolyte Salts: Supplier Lists and Lead-Times

**ID:** 2117a541-9533-4d77-831b-ad68cc2cc6ee

**Description:** Current (2026) supplier directories and capacity information for critical battery precursors: lithium metal or lithium carbonate (primary precursor), sulfur (for lithium-sulfur cathodes), high-purity metal oxides or fluorides (for conversion-cathode candidates), specialty salts (e.g., lithium tetrafluoroborate, lithium bis(trifluoromethanesulfonyl)imide), and fluorinated solvents (dimethyl carbonate, ethylene carbonate, 1,3-dioxolane, dimethoxyethane). Includes typical lead-times (weeks), minimum-order quantities, pricing ranges and dual-sourcing availability. Intended audience: Procurement Officer and Finance Manager for supplier qualification and inventory planning, addressing precursor supply-chain risks and cost control.

**Recency Requirement:** Current as of 2026; supplier lists and lead-times typically stable but can shift with geopolitical supply constraints; 2024-2026 guidance preferred.

**Responsible Role Type:** Procurement Officer (or Finance Manager) with Chemistry Pathway Lead

**Access Difficulty:** Medium. Supplier websites and technical datasheets are publicly available; lead-times and pricing require direct RFQ requests from suppliers, typically responded to within 1-2 weeks. International suppliers may require longer response times or currency conversion. Geopolitical export controls (e.g., US restrictions on Chinese suppliers) may affect sourcing options; check current trade regulations. No special access required; standard commercial procurement.

**Steps:**

- Contact major battery-materials suppliers directly via websites: Albemarle Corporation (lithium), Sigma-Aldrich / Merck (specialty salts, solvents), BASF, LG Chem, and Livent (lithium and derivatives); request technical datasheets and lead-time information for target materials.
- Search battery-industry procurement databases or consortia (if available) that maintain qualified-supplier lists (e.g., Battery Manufacturing and Recycling Consortium, if public access available).
- Query specialized chemical distributors (Avantor, VWR) and contract manufacturers (Albemarle, Lithium Werks contract-synthesis services) for availability, pricing and minimum orders.
- Contact Chinese and European suppliers (if tariff/export controls allow) to confirm dual-sourcing availability and lead-times (many specialty battery materials are sourced globally).
- Request supplier SLAs and pricing terms in writing; document lead-times for each critical precursor and identify any with >12-week lead-time requiring early orders or strategic inventory buffers.

### 8. Existing Battery Safety Testing Standards and Accreditation: Abuse-Test Protocols (Nail Penetration, Overcharge, Thermal Ramp)

**ID:** 30cd7347-2712-4c02-8b2b-3eba1da108c1

**Description:** Published safety test standards and accredited testing protocols: NREL/SNL SAND2000-0218 (nail-penetration test), IEC 62619 (thermal-runaway test via differential scanning calorimetry and adiabatic calorimetry), IEC 62620 (external short-circuit test), UL 1642 (lithium-battery safety). Includes test procedures, pass/fail criteria, equipment specifications and accredited laboratories capable of performing full-scale pouch-cell abuse testing (US, EU, Asia). Intended audience: EHS Officer and Chemistry Pathway Lead for abuse-test protocol definition and vendor qualification, addressing safety-evaluation strategy and third-party testing requirements.

**Recency Requirement:** Current standards as of 2026 (IEC and UL standards have periodic revisions); 2020-2026 versions preferred; foundational standards (2015-2020) acceptable for methodology reference.

**Responsible Role Type:** EHS Officer with Chemistry Pathway Lead

**Access Difficulty:** Medium. Standards (IEC, UL, ASTM) are proprietary and require purchase; however, key national-lab reports (SAND2000-0218) and academic publications describing the test methods are freely available. Accredited-lab information is publicly available on company websites. Methodology is well-established and not secret, so understanding the essence of nail-penetration, thermal-ramp and overcharge tests can be gained from published literature; purchasing the formal standards is recommended for regulatory compliance but not essential for initial protocol design.

**Steps:**

- Access IEC and UL standards via standards-body websites (IEC, American National Standards Institute, UL) or through standards databases (Techstreet, IHS Standards) if institutional subscription available; purchasing individual standards typically costs USD 50-200 per standard.
- Download NREL and Sandia national-lab technical reports on battery-safety test methods (SAND2000-0218 and related documents freely available via OSTI.gov).
- Search scientific literature (Google Scholar, Journal of Power Sources) for published battery-safety test procedures and methodology comparisons (e.g., differential scanning calorimetry vs. adiabatic-calorimetry correlation studies).
- Identify accredited testing laboratories (Intertek, TUV, UL laboratories) via their websites and contact them for information on abuse-test capabilities, turnaround times and cost.
- Request guidance documents from national labs (NREL, SNL) on which test standards are most relevant for lithium-metal and solid-state battery validation (academic contacts or via publications).

### 9. Independent Battery Testing Laboratories and Facilities (US-Based): Third-Party Verification Capabilities and Accreditation

**ID:** 7e4237ba-59d8-49f5-b167-b73f1411b1bc

**Description:** Directory of independent, accredited testing laboratories and research facilities in the United States capable of third-party verification of cell-level energy density (Wh/kg, Wh/L), cycle-life (80% retention), and abuse tolerance (thermal-runaway onset, overcharge reversibility, nail-penetration survivability) on pouch-cell samples. Includes facility names, accreditations (ISO 17025, UL, IEC), turnaround times, cost per test and track record with lithium-metal or advanced chemistry cells. Examples: MIT Energy Initiative, NREL, Colorado School of Mines, or contract labs (Intertek, TUV). Intended audience: Cell Engineering Lead and Characterization & Forensics Specialist for third-party-verification-protocol definition and lab selection, addressing the credibility and licensing-readiness requirements of the final cell deliverable.

**Recency Requirement:** Current as of 2026; accreditation and facility capabilities typically change slowly; 2024-2026 data preferred.

**Responsible Role Type:** Cell Engineering Lead with Characterization & Forensics Specialist

**Access Difficulty:** Easy. Testing labs publish accreditation status and general capabilities on their websites. Initial inquiries and quotes are provided without charge. Detailed discussions on turnaround times and pricing require direct contact, typically responded to within 1 week. No special access required; all information is marketing material readily shared with prospective clients.

**Steps:**

- Search ISO 17025 accreditation databases (hosted by national accreditation bodies in the US, Europe, Asia) for testing laboratories with battery-testing scope; filter for energy-density and cycle-life testing.
- Contact major contract-testing firms (Intertek, TUV SÜD, SGS) directly via their websites and request information on battery-cell testing capabilities and accreditation.
- Inquire with national laboratories (NREL, SNL, Argonne Applied Materials) regarding third-party verification services they offer to external researchers; some national labs provide this as a user facility.
- Search academic battery-research centers (MIT Energy Initiative, UC San Diego Supercomputer Center, Colorado School of Mines) for cell-testing capabilities and rates.
- Request references or case studies from prospective testing labs documenting their experience with advanced-chemistry cells (lithium-metal, conversion-cathode) and accuracy of measurements.

### 10. Prospective Battery Technology Licensees and Commercial Integrators: Market Scan and Contact Information

**ID:** 58c9b3fa-061e-48be-bbec-f3f93ac966b7

**Description:** Preliminary landscape scan of potential commercial partners and licensees for a 500 Wh/kg, 1000 Wh/L battery cell: established battery manufacturers (Tesla, Panasonic, LG, Samsung SDI, CATL, SK Innovation), emerging solid-state and lithium-metal companies (QuantumScape, Sion Power, Solid Power, EnerTech, Quantumscape), automotive OEMs (BMW, Hyundai, Audi pursuing advanced battery development), aerospace and drone companies (Joby, Lilium, Aurora Flight Sciences), and energy-storage integrators. Includes public information on their battery R&D roadmaps, technology partnerships, commercialization timelines and strategic focus (weight-critical vs. cost-optimized). Intended audience: IP/Licensing Lead and Partner & Ecosystem Lead for licensee identification and engagement planning (starting Month 12 = 2027-10-14), addressing the technology-transfer and commercial-viability risk.

**Recency Requirement:** Current as of 2026; company strategic priorities and timelines change annually; 2025-2026 public announcements, investor presentations and press releases preferred.

**Responsible Role Type:** IP/Licensing Lead with Partner & Ecosystem Lead

**Access Difficulty:** Easy. Public company information (investor presentations, press releases) is freely available on company websites. News articles and industry publications are searchable via Google News and industry databases (some require subscriptions, but free or trial access is often available). Private company information is less public; however, startup funding announcements and investor websites provide some data. Informal networking and direct inquiries to companies (via business-development contacts) is the most direct path to understanding licensing interest and partnership timelines.

**Steps:**

- Search company websites and investor-relations pages (Tesla, Panasonic, LG, Samsung, CATL, SK Innovation) for battery R&D strategy, target energy densities and commercialization timelines; extract from earnings calls and annual reports.
- Access CapitalIQ, PitchBook or similar databases (if institutional subscription available) for profiles of private battery companies and their funding, strategic roadmap and exit history.
- Search Google News and battery-industry publications (Charged.technology, InsideEVs, Battery Technology Magazine) for recent announcements from prospective licensees on technology partnerships, target applications and timelines.
- Contact venture-capital and private-equity firms focused on energy storage and battery (Breakthrough Energy, Energy Impact Partners, etc.) to solicit informal guidance on promising licensee candidates.
- Reach out informally to technical colleagues or network contacts in the battery industry to gather unpublished perspectives on which companies are actively seeking technology partnerships and which have realistic commercialization timelines for advanced-chemistry cells.

### 11. State-of-the-Art Review: Published and Proprietary Battery Performance and Cost Data from Commercial Battery Companies and R&D Consortia

**ID:** 617b0333-d011-413b-973d-70691e8f5c59

**Description:** Compilation of cell-level (not material-level) energy-density, cycle-life, safety and manufacturing-cost data from published literature and proprietary reports from commercial battery makers and R&D consortia. Sources: Tesla Battery Day presentations (official specs, claimed vs. achieved), Panasonic and LG Energy Solutions public data, Battery500 PNNL annual reports, ARPA-E REFUEL programme summaries, and academic battery-research centers. Provides benchmarks for gravimetric and volumetric energy density achieved in production (Tesla 4680, LG NCMA pouch) vs. laboratory prototypes (Battery500 targets), informing realistic goal-setting for the 500 Wh/kg and 1000 Wh/L targets. Intended audience: Chemistry Pathway Lead and Cell Engineering Lead for reality-check on target feasibility and identification of technological bottlenecks still unresolved in the industry.

**Recency Requirement:** Current data as of 2026 (most recent commercial and R&D programme data); 2023-2026 preferred; 2020-2023 acceptable for trend analysis.

**Responsible Role Type:** Chemistry Pathway Lead with Cell Engineering Lead

**Access Difficulty:** Easy to Medium. Tesla and major battery-maker investor presentations and public specifications are freely available. Battery500 and ARPA-E reports are freely available on government websites. Some detailed cost and performance data are proprietary (e.g., Tesla's actual 4680 production specs and cost) and not fully disclosed; however, enough public data exists from quarterly earnings calls, third-party teardowns (Argonne Teardown Series) and industry analyst reports to assemble a credible benchmark. Academic publications fill gaps with laboratory-scale data on emerging chemistries.

**Steps:**

- Download Tesla Battery Day 2020 and subsequent investor presentations (available via Tesla IR website) for publicly disclosed specifications on 4680 cell (claimed 300+ Wh/kg pouch-level, actual OEM pack data in annual reports).
- Access Panasonic and LG Energy Solutions public materials on NCMA and next-generation pouch-cell specifications (press releases, investor presentations).
- Download Battery500 PNNL annual reports and consortium publications (available via battery500.org and OSTI.gov) for third-party verified cell-level Wh/kg and cycle-life data.
- Search ARPA-E REFUEL programme summaries and contractor reports (available via ARPA-E website and grants.gov) for advanced-battery performance data and cost projections.
- Compile a comparative table: cell chemistry, measured Wh/kg (cell-level), measured Wh/L, measured cycle-life, manufacturing cost per kWh (if available), and commercialization timeline. Use this as a benchmark against which the programme's targets (500 Wh/kg, 1000 Wh/L, 300 cycles, licensability) can be assessed for realism.

### 12. Texas Environmental Code and EPA Hazardous-Waste Regulations (40 CFR 260-273): Lithium-Metal and Organic-Solvent Waste-Stream Classification

**ID:** 719d1bcb-761d-4fd8-84d8-f20b5702a7c4

**Description:** Current state and federal regulations governing hazardous-waste generation, characterization and disposal in Texas, with specific application to lithium-metal synthesis waste, spent electrolytes and organic-solvent residues. Specifies EPA hazardous-waste codes (e.g., D008 for lead, equivalent codes for lithium and fluorinated compounds), generator-registration requirements, manifesting and record-keeping, and disposal-method restrictions (landfill bans on certain hazardous wastes, incineration approval for flammable solvents). Intended audience: EHS Officer for facility permitting and waste-handling compliance, addressing the hazardous-materials operating-model definition.

**Recency Requirement:** Current as of 2026; EPA CFR 40 Part 260-273 and Texas Environmental Code are regularly updated; 2024-2026 versions required; historical versions (2015+) acceptable for methodology understanding.

**Responsible Role Type:** EHS Officer

**Access Difficulty:** Easy. Federal regulations (CFR) are freely available online via eCFR and govinfo. State codes are publicly available via TCEQ. EPA guidance documents and regulatory contacts are freely accessible. No subscription or special access required; all information is open to the public.

**Steps:**

- Access the US Code of Federal Regulations (CFR) online (www.ecfr.gov or govinfo.gov); retrieve 40 CFR Part 260-273 (EPA Hazardous Waste Regulations) in full text (free, publicly available).
- Visit the Texas Commission on Environmental Quality (TCEQ) website (www.tceq.texas.gov) and download the Texas Administrative Code (TAC) Title 30 Part 1 (Environmental Quality) for state-specific hazardous-waste rules.
- Access EPA's Hazardous Waste Identification System (HWIS) online tool or guidance documents describing waste-stream codes and characterization methods.
- Request technical guidance from TCEQ or EPA Region 6 (covers Texas) on specific waste-stream classification for lithium-metal synthesis residues and spent electrolytes (contact via phone or email; regulatory guidance is provided free).
- Review case-study or compliance guidance from environmental-consulting firms on battery-research waste handling (some publish white papers or guides free on their websites).

### 13. Pilot-Line Cell Fabrication Best Practices and Process Control Standards: Electrode Uniformity, Electrolyte Dosing and Cell Yield

**ID:** e6d22229-e1cd-4343-ba66-2d88faef02fd

**Description:** Published and proprietary best-practices documentation from battery-research and manufacturing organizations on achieving reproducible pouch-cell fabrication at pilot scale: electrode-coating parameter control (coating thickness uniformity ±10 µm target, precision slurry composition, drying temperature and time), electrolyte-dosing reproducibility (±2% volume variance, wettability validation, cross-linking or gelling procedures if applicable), cell-stacking and sealing consistency (layer alignment, pressure application, seal-line integrity), and formation-cycling protocols (current profile, voltage targets, end-of-charge detection). Includes case studies of pilot-line commissioning and yield-improvement strategies (defect reduction, statistical process control). Intended audience: Cell Engineering & Pilot-Line Manager for detailed operational procedure development and reproducibility target setting.

**Recency Requirement:** Current as of 2026; pilot-line best practices evolve with technology (solid-state and anode-free cells have different parameter windows); 2022-2026 guidance preferred; foundational practices (2015+) acceptable.

**Responsible Role Type:** Cell Engineering & Pilot-Line Manager

**Access Difficulty:** Medium. Academic journals and battery-manufacturing technical reports are available via institutional subscriptions or interlibrary loan. Battery500 and national-lab publications are freely available. Vendor technical documents may be proprietary but often shared upon request during procurement discussions. No special authentication required beyond standard academic database access.

**Steps:**

- Search academic battery-manufacturing journals (Journal of Power Sources, Advanced Energy Materials, ACS Applied Materials & Interfaces) for peer-reviewed papers on pouch-cell fabrication reproducibility and process control (keywords: 'pouch cell fabrication', 'electrode coating uniformity', 'electrolyte dosing'). Google Scholar and institution library access.
- Request technical reports or application notes from pouch-cell equipment vendors (Mbraun, Glove-box Company, electrode-coating system suppliers) describing their equipment capabilities and recommended process parameters.
- Contact battery manufacturers (Tesla, Panasonic, LG) indirectly via published technical presentations or patents (Google Patents, Espacenet) describing their pouch-cell manufacturing processes and control strategies.
- Access Battery500 PNNL publications and technical reports (via battery500.org and OSTI.gov) describing standardized pouch-cell build protocols and achieved reproducibility (Battery500 established a reference protocol for multi-lab comparisons).
- Query national labs (NREL, Argonne) for published or available-upon-request technical guidance on pouch-cell fabrication best practices (may require direct academic/professional contact).

### 14. Lithium-Ion Cell Cycle-Life Testing and Degradation Analysis Protocols: Standards and Case Studies

**ID:** af62ac93-8d9c-4341-8276-5510bed80c49

**Description:** Published protocols for cell-level cycle-life testing (constant-current/constant-voltage charging, controlled-current discharging at specified C-rates and temperatures), capacity-fade measurement (voltage profiles, incremental capacity analysis, differential capacity), post-mortem forensics to diagnose degradation mechanisms (SEM imaging of electrode changes, electrolyte decomposition analysis via FTIR or gas chromatography, electrochemical impedance spectroscopy to track interface resistance). Includes IEEE Std 1375 (battery testing and evaluation) and industry best practices from Battery500, national labs and commercial battery developers. Intended audience: Chemistry Pathway Lead and Characterization & Forensics Specialist for cycle-life test protocol definition and failure-forensics method validation.

**Recency Requirement:** Current protocols as of 2026; IEEE standards are revised periodically (Std 1375 updated ~2010, may have newer versions); 2020-2026 academic publications on advanced chemistries (lithium-sulfur, anode-free) preferred for methodology.

**Responsible Role Type:** Chemistry Pathway Lead with Characterization & Forensics Specialist

**Access Difficulty:** Medium. IEEE standards require purchase, but academic institutions typically maintain subscriptions. Journal articles are accessible via institutional libraries. Battery500 and national-lab publications are freely available. Commercial best practices are proprietary, but patent disclosures and published research papers contain substantial methodology detail. Academic and professional networking is often most efficient path to accessing unpublished protocols.

**Steps:**

- Access IEEE Standard 1375 (Battery Testing and Evaluation) via IEEE Xplore or IEEE Standards shop (purchase required, ~USD 150-300; alternatively, request access via academic institution library).
- Search journal literature (Journal of Power Sources, Electrochimica Acta, ACS Applied Materials & Interfaces) for published cycle-life test protocols and degradation-analysis methods (keywords: 'lithium-ion cycle life', 'incremental capacity analysis', 'degradation mechanism'). Use Google Scholar with institution access.
- Download Battery500 PNNL standardized pouch-cell testing and evaluation protocols (available via battery500.org and OSTI.gov) describing their reference cycle-life test procedure and data-reporting format.
- Access NREL and Argonne national-lab publications on degradation-mechanism diagnostics (post-mortem SEM, electrochemical impedance spectroscopy analysis) for advanced chemistries; search OSTI.gov and lab publication repositories.
- Request proprietary or unpublished cycle-life protocols from commercial battery companies (Tesla, Panasonic, LG) via collaborative research agreements or patent filings (some detail is disclosed in patents; approach via informal academic contacts for unpublished best practices).