*Roles Needed & Example People*

# Roles

## 1. Programme Director & Scientific Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Programme Director owns end-to-end technical strategy and gate management across all 84 months with continuous core accountability. Acts as Scientific Steering Committee chair and arbitrates chemistry trade-offs at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14). Requires exclusive availability, institutional knowledge retention and decision authority that only a full-time, salaried position provides. Cannot be sourced externally or part-time without fragmenting strategic continuity.

**Explanation**:
Owns the end-to-end technical strategy, chemistry pathway decisions, and gate management. Chairs the Scientific Steering Committee, arbitrates between competing teams, and maintains alignment with the 500 Wh/kg and 1000 Wh/L targets. Critical across all phases: planning (Months 0–3 = 2026-10-14 to 2027-01-14), execution (Months 3–36 = 2027-01-14 to 2029-10-14), chemistry selection (Months 30–36 = 2029-04-14 to 2029-10-14), and optimization/transfer (Months 36–84 = 2029-10-14 to 2033-10-14).

**Consequences**:
Without a clear scientific lead, chemistry and architecture trade-offs lack arbitration. Gate decisions (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) would face deadlock between competing teams; pivot decisions would be delayed or incoherent. Programme would lack strategic focus and coherence, risking budget waste and missed milestones.

**People Count**:
1

**Typical Activities**:
Leads end-to-end technical strategy and chemistry pathway decisions from Month 0 (2026-10-14) through Month 84 (2033-10-14). Chairs the Scientific Steering Committee, arbitrates trade-offs between competing chemistry teams (lithium-sulfur, anode-free solid-state, conversion cathode), and owns gate reviews at Months 18, 30, and 36 (2028-04-14, 2029-04-14, 2029-10-14). Reviews quarterly mass-and-volume model outputs and cycle-life forensics reports. Coordinates with cell engineering and characterization leads to ensure chemistry candidates are evaluated against Wh/kg, Wh/L, and cycle-life thresholds. Manages pivot decision and contingency activation if two leading chemistries fail by Month 36 (2029-10-14). Represents the programme to the funder and external advisors on technical progress and risk mitigation.

**Background Story**:
Dr. Margaret Chen is a battery electrochemistry researcher with 18 years' experience in lithium-ion and advanced chemistry development. Based in California, she earned her PhD in Materials Science from Stanford and spent 12 years at a national laboratory leading multi-institution battery consortia before a 4-year tenure at a battery-materials startup. She has published 47 peer-reviewed papers, holds 12 patents in cell design and electrolyte chemistry, and has chaired technical steering committees on government-sponsored energy-storage programs. Margaret is deeply familiar with staged chemistry tournaments, gate-based programme management, and the trade-offs between gravimetric and volumetric energy density. She is attracted to the Austin-based role because it allows her to lead an invention-focused effort with academic and national-laboratory partnerships, avoiding the commercial pressure of industry. Her track record managing complex electrochemistry research across competing teams and regulatory constraints makes her ideally suited to arbitrate chemistry pathway decisions at Months 18, 30, and 36 (2028-04-14, 2029-04-14, 2029-10-14).

**Equipment Needs**:
Access to scientific literature databases, computational modeling software (materials simulation, electrochemical modeling), presentation and visualization tools for Steering Committee meetings. Laptop with high-performance computing access (cloud or HPC node allocation) for running battery simulation models. Secure conference and meeting infrastructure for strategy discussions.

**Facility Needs**:
Office space with secure meeting room for Scientific Steering Committee (monthly review cadence). Access to shared lab spaces to observe pilot-line operations and characterization work. Connection to university and national-laboratory computational resources via secure networking. Proximity to research teams for real-time discussions during Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) gates.

## 2. Chemistry Pathway Lead (or 3 Chemistry Team Leads)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Chemistry Pathway Leads (3–4 roles) own active tournament branches from Month 3 (2027-01-14) through Month 36 (2029-10-14) selection, with winning lead carrying through Month 84 (2033-10-14). Each manages synthesis, electrochemical testing, cycle-life forensics and interface optimization—continuous, core expertise work. High specialization (lithium-sulfur, anode-free solid-state, conversion cathode) and institutional knowledge requirements justify full-time, salaried employment. Parallel teams also benefit from equity-aligned, long-term commitment.

**Explanation**:
Leads one active chemistry tournament branch (lithium-sulfur, anode-free solid-state, or conversion cathode) through material synthesis, electrochemical testing and degradation analysis. Owns cycle-life forensics and interface optimization. Present from Month 3 (2027-01-14) (exploration) through Month 36 (2029-10-14) (selection), with winning lead carrying through to Month 84 (2033-10-14) (optimization and scale).

**Consequences**:
Chemistry exploration becomes disorganized; candidates are tested in isolation without comparative rigor. Cycle-life and safety failures are discovered late (Month 48+) rather than Month 12–24 (2027-10-14 to 2028-10-14), wasting 12–18 months and USD 10–20M. No clear ownership of interface engineering or degradation mechanisms. Programme risks advancing a dead-end chemistry to the gate.

**People Count**:
min 3, max 4, depending on tournament breadth (3 active branches plus 1 reserve requires 3–4 leads; single lead cannot manage parallel efforts at the pace needed for Month 36 = 2029-10-14 gate)

**Typical Activities**:
Leads the lithium-sulfur chemistry tournament branch from Month 3 (2027-01-14) through Month 36 (2029-10-14) selection. Synthesizes sulfur cathodes with various polysulfide-blocking strategies, manages anode protection and electrolyte formulations. Conducts monthly cycling tests on coin cells and pouch-cell builds (50–100 cells/month estimate by Month 24 = 2028-10-14), records cycle-life degradation curves, and submits failed cells to the forensics team within 24 hours. Reports cycle-life data and interface-stability findings to the Programme Director and the independent red team quarterly. If lithium-sulfur advances to final selection at Month 36 (2029-10-14), leads optimization and scale-up through Month 84 (2033-10-14).

**Background Story**:
Dr. James Rodriguez has spent 14 years synthesizing and testing lithium-sulfur cathodes and anode protection layers. He earned his PhD in Electrochemistry from MIT and has worked at two battery startups and a national laboratory, with expertise in interfacial chemistry, polysulfide mitigation, and cycle-life forensics under stress conditions. James has authored 31 papers and holds 8 patents on lithium-sulfur cell designs. He is well-versed in translating material-level gains to pouch-cell proof and diagnosing why laboratory-scale performance collapses at cell level. He is motivated by the challenge of reaching 500 Wh/kg and 1000 Wh/L in a single lithium-sulfur chemistry within the Austin programme, seeing it as a chance to prove the chemistry viable despite past cycle-life and swelling challenges.

**Equipment Needs**:
Synthesis equipment for assigned chemistry (lithium-sulfur: cathode fabrication rig, polysulfide-blocking agent synthesis; anode-free: electrolyte mixing/formulation benches; conversion-cathode: metal oxide/fluoride synthesis apparatus). Electrochemical testing: potentiostat/galvanostat, temperature-controlled cycling chambers (coin-cell scale, ~USD 200 K estimate). Gas chromatography or FTIR for electrolyte stability analysis. Access to operando characterization (X-ray diffraction, electrochemical impedance spectroscopy) via partner facilities.

**Facility Needs**:
Dedicated bench space in wet-chemistry synthesis lab (fume hoods with reactive-metal capability, ~500 m² estimate per team). Inert-atmosphere glovebox (N₂ or Ar, ~USD 80-150 K estimate each, shared across team or dedicated). Environmental chambers for temperature-controlled cycling tests (25°C, ±5°C). Storage for precursor materials (lithium compounds, sulfur, metal oxides, fluorinated solvents) in compliance with hazardous-materials permitting. Access to pilot-line pouch-cell builds (50-100 cells/month per chemistry branch).

## 3. Cell Engineering & Pilot-Line Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Cell Engineering & Pilot-Line Manager owns modular dry-room and pouch-cell line deployment (Months 3–6 = 2027-01-14 to 2027-04-14) and reproducibility achievement (90% of cells within ±10% by Month 30 = 2029-04-14). Continuous operational responsibility across 84 months for batch-to-batch consistency, electrode uniformity and mass-and-volume model integrity. Pilot-line management requires on-site presence, process control expertise and long-term commissioning/optimization that part-time or contractor models cannot reliably deliver.

**Explanation**:
Owns the modular dry-room and pouch-cell fabrication line (50–100 cells/month estimate), electrode coating, electrolyte dosing, and cell assembly reproducibility. Ensures Months 3–6 (2027-01-14 to 2027-04-14) deployment, and achieves batch-to-batch reproducibility (90% of cells within ±10% by Month 30 = 2029-04-14 estimate). Bridges chemistry outputs to pouch-cell proof, tracking mass-and-volume penalties that expose packaging shortfalls early.

**Consequences**:
Pilot-line deployment slips beyond Month 3 (2027-01-14). Electrode uniformity and cell reproducibility are poor (>±20% variance), masking chemistry performance and delaying diagnosis of failure modes. Material-to-pouch conversion penalties (inactive mass, separator thickness) remain unknown until Month 48+, risking late discovery that 1000 Wh/L is unachievable. Cell builds fall behind schedule, compressing discovery cadence by 50–75%.

**People Count**:
min 1, max 2, depending on line complexity and build cadence (single manager may become bottleneck if build rate exceeds 100 cells/month or if pilot-line contingencies require dual-site operation)

**Typical Activities**:
Leads the anode-free solid-state chemistry tournament branch from Month 3 (2027-01-14) through Month 36 (2029-10-14) selection. Designs and fabricates anode-free pouch architectures with different solid-electrolyte candidates and liquid-electrolyte interlayers. Conducts coin-cell and pouch-cell cycling tests, manages thermal-ramp safety screening in collaboration with the EHS officer, and submits degradation-mode specimens to the forensics lead. Reports cycle-life, safety and interface-resistance findings to the Programme Director and the red team quarterly. Co-develops the cell mass-and-volume model with the pilot-line manager to track packaging-penalty evolution. If anode-free advances to final selection at Month 36 (2029-10-14), leads Module 2 scale-up and abuse-test validation through Month 84 (2033-10-14).

**Background Story**:
Dr. Aisha Patel holds a PhD in Materials Science from UC Berkeley and has spent 10 years in anode-free and solid-state cell development at two research institutes and a battery manufacturer. She has authored 26 papers and holds 15 patents on lithium-metal anode-free architectures, electrolyte solid-electrolyte interfaces, and pressure-managed stack designs. Aisha is familiar with the dry-room challenges and equipment modifications required for anode-free cells, and has managed pouch-cell builds at pilot scale. She is drawn to the Austin programme because it offers the chance to mature anode-free technology to third-party verified pouch-cell proof at 500 Wh/kg without commercial time-to-market constraints.

**Equipment Needs**:
Electrode coating and drying apparatus (slot-die coater or doctor-blade station with heating, ~USD 150-300 K estimate). Electrolyte dosing systems (precision volumetric pipettes, ~USD 50-100 K). Cell stacking or winding equipment (pouch layer-stack rig or spiral-wound fixture). Dew-point sensors and humidity monitoring (continuous, across all dry-room zones). Precision scales (±0.1 mg) for mass tracking. Temperature and pressure monitoring for cell assembly conditions.

**Facility Needs**:
Modular leased dry-room (5,000-10,000 m² estimate total facility, 1,000-2,000 m² dedicated dry-room space, dew point <−30°C estimate, 20-25% of facility). Electrode coating area with climate control (humidity <20% RH estimate, temperature 20-25°C). Cell-assembly workstations (laminar-flow or partially enclosed, preventing electrolyte exposure). Electrolyte storage zone (inert atmosphere, temperature controlled, fireproof cabinets). Pouch materials inventory (aluminum laminate, copper/aluminum current collectors, separators) with organized, labeled storage.

## 4. Characterization & Forensics Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Characterization & Forensics Specialist operates in-house post-mortem instruments (Month 8 = 2027-06-14 onward), conducts failure-mode autopsies within 1 week, builds forensics atlas and coordinates external partner access. Active from Month 6 (2027-04-14) through Month 84 (2033-10-14) with peak intensity during chemistry tournament (Months 12–36 = 2027-10-14 to 2029-10-14). Core expertise in microscopy, root-cause analysis and design-loop integration cannot be efficiently sourced on a part-time or project-by-project basis; institutional knowledge of failure patterns and equipment operation justifies full-time salaried position.

**Explanation**:
Operates in-house post-mortem instruments (scanning electron microscope, X-ray diffraction by Month 8 = 2027-06-14 estimate), conducts failure-mode autopsies within 1 week, and coordinates external partner access. Builds and maintains forensics atlas (root-cause database) feeding design iteration. Active from Month 6 (2027-04-14) through Month 84 (2033-10-14), with peak activity during chemistry tournament (Months 12–36 = 2027-10-14 to 2029-10-14).

**Consequences**:
Failed cells are not analyzed; root-cause mechanisms remain unknown. Design-build-test loop stalls: chemistry teams guess at failure origins instead of diagnosing them. Partner characterization queues (4–8 weeks estimate) become the bottleneck instead of hypothesis generation. Programme throughput drops 50–75%; discovery of viable candidates is delayed 3–6 months. Cycle-life and interface failures repeat without learning.

**People Count**:
1

**Typical Activities**:
Leads the conversion-cathode tournament branch from Month 3 (2027-01-14) through Month 36 (2029-10-14) selection. Synthesizes and characterizes metal-oxide and fluoride-based conversion-cathode materials, pairs them with lithium-metal anodes and optimized electrolytes. Conducts coin and pouch-cell cycling, records electrochemical impedance spectroscopy data to track interface resistance evolution, and works closely with the forensics specialist to identify structural degradation modes. Submits findings to the Programme Director and the red team quarterly. If conversion-cathode emerges as the finalist at Month 36 (2029-10-14), continues optimization and manufacturing-readiness work through Month 84 (2033-10-14).

**Background Story**:
Dr. Wei Liu earned his PhD in Electrochemistry from Tsinghua University and brings 8 years of experience in conversion-cathode materials, high-voltage cation-doping, and interfacial surface chemistry. He has authored 18 papers and holds 6 patents on conversion-cathode designs. Wei has managed laboratory synthesis of metal-oxide precursors and worked with post-mortem microscopy to diagnose structural collapse during cycling. He is motivated by the Austin programme's non-commercial framing and its emphasis on understanding degradation mechanisms rather than rushing to commercialization.

**Equipment Needs**:
In-house post-mortem instruments: scanning electron microscope with energy-dispersive X-ray spectroscopy (USD 2-3 M estimate, operational Month 8 = 2027-06-14), X-ray diffraction system or outsourced access. Fourier-transform infrared spectroscopy for electrolyte decomposition analysis. Sample preparation: cross-sectioning saw, polishing equipment, coating apparatus for electron microscopy. Database/lab information management system for forensics atlas tracking and root-cause coding.

**Facility Needs**:
Dedicated forensics and post-mortem analysis lab (~500-800 m² estimate). Scanning electron microscope room with vibration isolation, climate control (18-24°C, <40% RH), power conditioning, and ventilation for secondary-electron detection. Electrolyte decomposition analysis bench with fume hood (FTIR, gas chromatography or liquid chromatography capability). Sample storage and organization for failed cells awaiting analysis. Connection to partner characterization facilities (UT Austin, national laboratories) with formal access agreements.

## 5. Environmental Health & Safety (EHS) Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Environmental Health & Safety Officer leads permitting (Months 0–9 = 2026-10-14 to 2027-07-14) with phased compliance gates and owns ongoing audit, waste-handling and incident-response protocols throughout 84 months. Initiates regulator engagement at Month 0 (2026-10-14) and maintains quarterly compliance reviews. Continuous regulatory presence, documentation and institutional knowledge (EPA, TCEQ, OSHA, fire-authority relationships) are non-delegable and require full-time, in-house accountability. Loss of this role mid-programme risks facility closure or USD 1–3 M remediation costs.

**Explanation**:
Leads site permitting (phased Months 3, 6, 9 = 2027-01-14, 2027-04-14, 2027-07-14 gates estimate), hazardous-materials compliance (EPA, TCEQ, OSHA, fire authority), and waste handling. Negotiates with Austin Fire Authority Month 0 (2026-10-14), submits Phase 1 permit by Month 2 (2026-12-14), and maintains ongoing audit and incident-response protocols. Uninterrupted lab operations and zero reportable incidents depend on this role's diligence.

**Consequences**:
Permitting slips 6–8 months (common for hazardous-materials facilities), compressing effective work time to 75–78 months. Conservative permit terms exclude on-site lithium-metal or solvent synthesis, forcing 4–6 week outsourcing turnarounds. Serious incident (electrolyte fire, chemical release) triggers facility shutdown for 2–6 months and USD 1–3M remediation. Without proactive compliance, permitting delays alone could jeopardize delivery.

**People Count**:
1

**Typical Activities**:
Owns the modular leased dry-room and pouch-cell fabrication line deployment by Month 3 (2027-01-14) and operates it through Month 84 (2033-10-14). Negotiates lease terms with equipment vendors, oversees installation and commissioning (dew-point control, electrode coating uniformity ±10 μm estimate, electrolyte dosing accuracy ±2% estimate), and trains technicians. Manages cell builds at ramping rates: baseline 50–100 cells/month by Month 6 (2027-04-14), scaling to 200+ cells/month if multiple chemistries advance. Works with chemistry leads to resolve electrode-coating or assembly issues. Develops and maintains the live mass-and-volume cell model, updates it quarterly with packaging mass and active-material ratios, and flags any unexpected Wh/kg or Wh/L gaps to the Programme Director. Tracks batch-to-batch variance and reports to the red team. Achieves 90% of cells within ±10% specification by Month 30 (2029-04-14) and maintains it through final validation.

**Background Story**:
Dr. Sarah Kim has 12 years of experience in lithium-ion and solid-state cell engineering, dry-room design, pilot-line commissioning and manufacturing reproducibility. She earned her PhD in Mechanical Engineering from Stanford and worked at a battery cell manufacturer managing pilot-scale pouch production, electrode uniformity and electrolyte dosing precision. Sarah has commissioned three pilot lines, understands the capital and lead-time trade-offs of equipment ownership, and has managed cross-functional teams to achieve ±10% batch-to-batch reproducibility. She is attracted to the Austin programme because it values early cell-level proof and engineering discipline over production speed.

**Equipment Needs**:
Environmental and safety monitoring instruments: gas detection systems (O₂, CO₂, VOC monitors for dry-room and synthesis labs). Fire-suppression system design and maintenance (thermal sensors, inert-gas or foam discharge). Hazardous-waste handling and analysis: waste segregation bins, labeling system, disposal logistics tracking. Incident response and documentation: video surveillance, incident logbooks, safety data sheet (SDS) database and management system.

**Facility Needs**:
Dedicated EHS office (~100 m² estimate) with regulatory documentation storage, compliance database access, incident-response planning and training areas. Partnership with licensed hazardous-waste contractor (3M, Stericycle, or equivalent, ~USD 50-100 K/yr estimate). Phased permit coordination with Austin Fire Authority, TCEQ and EPA. On-site emergency eyewash and shower stations (near synthesis and abuse-test areas). Fire Authority liaison space for inspections and collaborative protocol development.

## 6. Talent Recruitment & Retention Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Talent Recruitment & Retention Manager recruits 80–120 FTE (planning estimate) across 84 months, manages competitive Austin-market compensation (15–20% premium for senior roles), coordinates UT Austin pipelines and targets attrition <15% annually (proposed). Critical during Months 0–12 (2026-10-14 to 2027-10-14) (initial team build) and Months 24–36 (2028-10-14 to 2029-10-14) (retention under pivot pressure). Ongoing payroll management, salary negotiation, benefits administration and attrition tracking require full-time HR function; outsourced recruiting cannot manage the continuous retention and compliance burden.

**Explanation**:
Recruits 80–120 FTE (planning estimate) with competitive Austin-market salaries (15–20% premium for senior roles estimate), manages sign-on bonuses and retention agreements, and coordinates UT Austin graduate pipelines. Targets attrition <15% annually (proposed) and fills vacancies within 8–12 weeks (estimate). Active across all 84 months but critical during Months 0–12 (2026-10-14 to 2027-10-14) (initial team build) and Months 24–36 (2028-10-14 to 2029-10-14) (retention under pivot pressure).

**Consequences**:
Payroll and hiring costs spiral without strategic negotiation; average salary creep could push payroll from USD 10M/yr baseline to USD 14.8M/yr (estimate), consuming USD 34M over 7 years and compressing equipment and experiment budgets. Attrition exceeds 20% annually (estimate worst case), requiring 16–24 replacements/year and wasting USD 1.5–2.5M in recruiting and onboarding. Loss of key chemistry or characterization leads at Month 18–24 (2028-04-14 to 2028-10-14) sets programme back 2–4 months. Without structured incentives (retention agreements, publication prestige, equity-like arrangements), poaching by Tesla and nearby firms starves team of senior expertise.

**People Count**:
1

**Typical Activities**:
Operates in-house post-mortem characterization instruments (scanning-electron microscope, X-ray diffraction, or equivalent) commissioned by Month 8 (2027-06-14). Receives failed cells from chemistry teams within 24 hours of failure, conducts standardized autopsy protocol (SEM surface imaging, energy-dispersive X-ray spectroscopy mapping, FTIR or gas-chromatography analysis of electrolyte decomposition), and delivers root-cause report and design recommendation within 5 business days. Builds and maintains forensics atlas (database of failure modes, mechanisms and design consequences) by Month 12 (2027-10-14) and updates it quarterly. Coordinates with external university and national-laboratory characterization partners, scheduling operando X-ray diffraction and advanced post-mortem slots, managing turnarounds <3 weeks (proposed). Prepares quarterly degradation-mechanism summaries for the Programme Director and the red team. Ensures the design-build-test loop is closed: every failed cell generates actionable learning within 1–2 weeks.

**Background Story**:
Dr. Rajesh Gopal earned his PhD in Materials Characterization from Oxford and has 11 years' experience in post-mortem and operando electrochemical diagnostics. He has operated scanning-electron microscopes, X-ray diffraction systems, electrochemical impedance spectroscopy rigs and has published 34 papers on lithium-ion failure mechanisms and interface degradation. Rajesh has managed forensics protocols at two research institutes and understands how to extract root-cause insights from degraded cells to guide design iteration. He is motivated by the chance to establish a structured forensics function that directly feeds chemistry improvement cycles.

**Equipment Needs**:
Applicant tracking system (ATS) for recruitment and hiring pipeline management. Compensation benchmarking software (salary surveys). Background-check and onboarding-documentation systems. Retention-agreement and non-use agreement templates (legal document management). UT Austin partnership coordination platform for graduate-student recruitment. Benefits administration system (health insurance, retirement, professional development budgets).

**Facility Needs**:
HR office (~150 m² estimate) with private interviewing and onboarding spaces. Access to recruitment networks (university career offices, LinkedIn, battery-science professional groups). Meeting room for retention reviews and exit interviews. Secure storage for employment contracts, background-check results, and IP-related compliance documents (clean-room onboarding records, non-use agreements). UT Austin partnership coordination office (shared or co-located with university liaison).

## 7. Financial & Operations Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Financial & Operations Manager handles USD 300 M budget across tranche releases (Months 0, 12, 24, 36 = 2026-10-14, 2027-10-14, 2028-10-14, 2029-10-14), holds USD 20 M reserve and USD 15 M pivot runway, and tracks burn-rate against gate milestones every month for 84 months. Monitors contingency reserves, negotiates vendor contracts, hedges foreign-currency exposure and authorizes spending. Continuous financial oversight, statutory compliance and funder reporting require full-time, salaried CFO/operations function; part-time or contractor accounting cannot provide the accountability or decision authority this role demands.

**Explanation**:
Manages the USD 300M budget across tranche releases (USD 60/80/70/90M at Months 0/12/24/36 = 2026-10-14, 2027-10-14, 2028-10-14, 2029-10-14 estimate), holds USD 20M reserve and USD 15M pivot runway, and tracks burn rate against gate milestones. Authorizes spending, monitors contingency reserves, negotiates vendor contracts and foreign-currency hedges, and ensures cash flow supports payroll, capital and experiments. Active every month but critical during tranch gates (Months 12, 24, 36 = 2027-10-14, 2028-10-14, 2029-10-14).

**Consequences**:
Budget discipline collapses. Early capital commitments (facility USD 30–50M, pilot line USD 15M, hiring USD 35M) could exceed available tranches, forcing mid-programme underfunding or halted operations. Reserve and pivot-runway tracking is lost; overspending in one category (payroll overruns to USD 14.8M/yr estimate) exhausts contingency without awareness, leaving no buffer for pivots or surprises. Currency exposure on equipment orders (USD 30–50M foreign) unhedged, risking 15% cost increase (USD 4.5–7.5M estimate). Funder reporting and gate decisions lack financial grounding.

**People Count**:
1

**Typical Activities**:
Leads site permitting and regulatory compliance from Month 0 (2026-10-14) through Month 84 (2033-10-14). Initiates collaborative engagement with Austin Fire Authority, TCEQ and EPA in Month 0 (2026-10-14), proposes phased-permit approach (Phase 1 dry-room by Month 3 = 2027-01-14, Phase 2 synthesis by Month 6 = 2027-04-14, Phase 3 abuse chambers by Month 9 = 2027-07-14), and submits Phase 1 application by Month 2 (2026-12-14). Manages hazardous-waste contractor selection, maintains compliance documentation (materials inventory, quantities, waste-stream tracking), and conducts quarterly internal EHS audits. Manages incident response and maintains zero-reportable-incident target. Pre-negotiates with external synthesis subcontractors for on-site-prohibited chemistry steps (lithium metal, aggressive solvents) to ensure <4 week turnarounds. Budgets and tracks USD 0.5–1 M/year for EHS staffing, training, permitting consultation, and contingency retrofits.

**Background Story**:
Ms. Elena Vasquez has 9 years of experience in environmental health and safety management at research institutions and contract laboratories. She earned a Master's degree in Environmental Engineering from UT Austin and holds credentials in OSHA hazard communication, EPA hazardous-waste compliance, and fire-safety auditing. Elena has navigated permitting for lithium-metal synthesis, organic-solvent handling and thermal-runaway abuse testing across three states. She is familiar with the Austin Fire Authority and Texas Commission on Environmental Quality (TCEQ) permitting landscape and has built phased permitting strategies that allow operations to begin while full approvals mature.

**Equipment Needs**:
Financial management software (project accounting, budget tracking, expense management). Foreign-exchange hedging tools or broker relationships for equipment purchases quoted in EUR/CNY. Vendor contract and procurement management system. Capital equipment inventory and depreciation tracking. Contingency-reserve and tranche-release tracking dashboards. Financial reporting and funder-communication templates.

**Facility Needs**:
Finance and operations office (~200 m² estimate) with secure data storage and backup systems. Vendor and supplier management contact center. Connection to banking and financial institutions for hedging operations and payment processing. Secure conference room for budget reviews with Steering Committee and funder representatives (monthly or quarterly cadence). Archive storage for contracts, purchase orders and financial records.

## 8. Partner & Ecosystem Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Partner & Ecosystem Lead negotiates 3–5 year formal agreements with ≥2 university/national-lab partners by Month 3 (2027-01-14), manages cost-sharing (≥15% of shared costs proposed), and coordinates technology-transfer discussions from Month 12 (2027-10-14) onward. Manages IP onboarding and clean-room protocols throughout. Continuous partnership maintenance, funder relations, and licensing framework development (due Month 24 = 2028-10-14) require full-time, in-house presence and institutional knowledge of each partner's priorities and constraints.

**Explanation**:
Negotiates and maintains formal 3–5 year agreements with >=2 university and national-lab partners (characterization, synthesis validation, cost-sharing >=15% proposed) by Month 3 (2027-01-14). Coordinates technology-transfer discussions with prospective licensees from Month 12 (2027-10-14) onward. Manages IP onboarding and clean-room protocols for competitor-origin hires. Bridges external partnerships and internal execution to preserve cost-sharing and instrument access.

**Consequences**:
Partner agreements remain unsigned; characterization access is ad hoc, adding 4–8 week queues and reducing hypothesis throughput by 50–75%. Loss of partner access forces commercial lab outsourcing at USD 30–50K per sample, consuming USD 5–10M/year (estimate) versus cost-shared partner access. Cost-sharing partners withdraw (10–20% loss estimate), absorbing USD 5–10M internally and compressing working capital. Prospective licensees are not identified until Month 72+, risking 12–24 month commercialization delays post-delivery. IP contamination from competitor hires occurs unchecked, jeopardizing patent validity.

**People Count**:
1

**Typical Activities**:
Leads recruitment and retention of 80–120 FTE (planning estimate) across 84 months. Benchmarks salaries against the Austin battery-technology market, targets 15–20% premium for senior chemistry and engineering roles, and structures sign-on bonuses (USD 50–150 K estimate for mid-career scientists) and professional-development budgets. Establishes recruitment partnership with UT Austin by Month 2 (2026-12-14), securing graduate-student pipeline and co-authored publication agreements. Drafts and negotiates 3–5 year retention agreements with clawback terms for key personnel (chemistry leads, forensics specialist, pilot-line manager). Tracks attrition monthly; if actual attrition exceeds 15% annually (proposed), triggers retention-plan review with the Programme Director by Month 24 (2028-10-14). Manages continuous hiring and onboarding cycles. Targets average team cost within USD 10 M/year payroll budget.

**Background Story**:
Ms. Sofia Martinez brings 10 years of human resources and talent management experience in the Austin tech and battery sectors. She has worked at two startups and a research organization recruiting and retaining specialized scientists and engineers in competitive markets. Sofia is experienced in competitive salary benchmarking, sign-on incentive structuring, retention-agreement design and graduate-student pipeline development with UT Austin. She understands the poaching pressures from Tesla and nearby firms and has built effective retention strategies around publication prestige, professional development and equity-like arrangements.

**Equipment Needs**:
Partner-relationship management (CRM) software for tracking university, national-laboratory and prospective-licensee interactions. IP database and patent-filing management system. Licensing-agreement templates and negotiation tools. Technology-transfer planning and documentation systems. Clean-room employee-onboarding database (non-use agreements, background-check records, access logs).

**Facility Needs**:
Ecosystem and partnerships office (~150 m² estimate) with secure meeting spaces for partner institution representatives and prospective licensees. Access to videoconference infrastructure for remote partner coordination (UT Austin, NREL, Argonne, etc.). Secure document repository for IP records, partner agreements and licensing terms. Legal and IP counsel access (on retainer or integrated). Contact center for managing university and national-laboratory relationship continuity.

## 9. Independent Red Team / Verification Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Independent Red Team / Verification Lead directs 2–3 scientists tasked with replicating key results and validating gate decisions from Month 12 (2027-10-14) through Month 84 (2033-10-14), with peak scrutiny at gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14). Reports directly to Steering Committee (not core teams) and provides independent verification essential to funder credibility and patent validity. Requires full-time authority, access to all programme data, and scientific autonomy that only a salaried, institutional position provides. Contractor or part-time verification creates conflict-of-interest and confidentiality exposure.

**Explanation**:
Leads 2–3 scientist verification team tasked with replicating key results, challenging progress claims, and validating gate-advancement decisions before funder reporting. Reports directly to Steering Committee (not to core teams). Active from Month 12 (2027-10-14) onward, with peak scrutiny at gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14). Ensures cell-level data meets claimed energy density and cycle-life standards, preventing inflated progress claims.

**Consequences**:
Progress claims are not independently verified; material-level numbers claimed at Month 24 (2028-10-14) may be inflated or based on incomplete data. Gate decisions lack credible external scrutiny; Steering Committee advances weaker chemistry based on team enthusiasm rather than evidence. Funder confidence erodes when third-party verification at Month 30 (2029-04-14) or Month 72 (2032-10-14) contradicts earlier claims. Patent value and licensing credibility diminish if results cannot be independently replicated. Red team prevents these failures and provides funder assurance.

**People Count**:
1 lead + 2 supporting scientists

**Typical Activities**:
Manages the USD 300 M budget across tranched releases (USD 60/80/70/90 M at Months 0/12/24/36 = 2026-10-14, 2027-10-14, 2028-10-14, 2029-10-14 estimate), holds USD 20 M total reserve and USD 15 M ring-fenced pivot runway through Month 30 (2029-04-14). Tracks burn rate monthly against operating budget (payroll ~USD 10 M/year estimate, capital ~USD 7–10 M/year estimate, experiments/partners/testing ~USD 20–25 M/year estimate). Authorizes spending within delegated authorities and flags variances >10% to the Programme Director. Negotiates capital equipment contracts with fixed-price and forward-exchange hedging for equipment ordered Months 2–6 (2026-12-14 to 2027-04-14) to lock currency exposure (USD 2–3 M FX contingency estimate). Prepares monthly financial reports and tranche-readiness assessments for the Steering Committee. At gates (Months 12, 24, 36 = 2027-10-14, 2028-10-14, 2029-10-14), certifies readiness for next tranche release based on milestone evidence. Manages contingency-reserve and pivot-runway deployment if major pivot or unexpected costs occur.

**Background Story**:
Mr. David O'Connor is a financial manager with 13 years' experience in government-funded research programmes, nonprofit R&D budgets and venture-backed deep tech. He has managed USD 50–200 M programme budgets with tranche releases, holds credentials in project accounting and foreign-exchange hedging, and has navigated cost overruns, vendor negotiations and contingency-reserve deployment. David is experienced in tracking burn rates against milestones and communicating financial health to funders and steering committees.

**Equipment Needs**:
Electrochemical testing equipment (potentiostat/galvanostat, cycling chambers) for independent replication of key chemistry results. Thermal-ramp and differential scanning calorimetry apparatus for safety-claim validation. Access to third-party characterization (X-ray diffraction, electron microscopy) for independent measurement verification. Data-analysis and statistical-validation software.

**Facility Needs**:
Independent red-team laboratory space (~400-600 m² estimate), physically or administratively separated from core chemistry teams. Electrochemical cycling lab with temperature-controlled chambers for coin-cell and pouch-cell replication testing. Access to shared characterization facilities with priority scheduling for verification work. Secure data management and confidential results repository (reporting directly to Steering Committee, not to core teams). Meeting room for red-team reports and gate-decision reviews with Steering Committee.

---

# Omissions

## 1. Missing explicit definition of manufacturing reproducibility and process robustness as a gate criterion

The plan requires 90% of cells within ±10% by Month 30 (2029-04-14), but lacks criteria for what constitutes acceptable process variability or how manufacturing robustness feeds into chemistry selection at the Month 36 (2029-10-14) gate. Process failures discovered late (Month 48–60 = 2030-10-14 to 2031-10-14) could require 6–12 months of redesign, consuming the final validation window. Without explicit manufacturing-readiness gates, a chemistry meeting energy-density and cycle-life targets could fail at scale-up.

**Recommendation**:
Define manufacturing robustness as a hard gate criterion alongside energy density and cycle life: (1) by Month 18 (2028-04-14), establish quantified process-window targets (electrode-coating thickness ±5 µm, electrolyte dosing ±2%, stack pressure ±1 atm); (2) by Month 24 (2028-10-14), require all candidates to demonstrate batch-to-batch reproducibility of ≥90% within ±10% on at least three sequential 50-cell builds; (3) at Month 30 (2029-04-14), factor manufacturing variability into the chemistry-selection decision—deprioritize any candidate showing >15% cell-to-cell performance spread or process-parameter sensitivity; (4) allocate 10–15% of discovery effort to manufacturing-science work (design-of-experiments for coating thickness, pressure, electrolyte volume) from Month 12 (2027-10-14) onward.

## 2. Absence of a formal cost-of-goods (COGS) or commercializability assessment for the winning chemistry

The plan targets invention and licensability but does not establish when or how the winning chemistry's manufacturability or cost-competitiveness is evaluated. A cell achieving 500 Wh/kg but requiring USD 500/kWh material and processing cost (versus <USD 200/kWh for commercial lithium-ion) would be a laboratory invention without licensing value. Late discovery of cost infeasibility (Month 60–72 = 2031-10-14 to 2032-10-14) forces either acceptance of a non-commercial result or a costly late-stage redesign.

**Recommendation**:
Establish a cost and manufacturability assessment gate by Month 24 (2028-10-14): (1) assign a manufacturing-cost lead to estimate material, synthesis, and pilot-line processing costs quarterly from Month 12 (2027-10-14) onward; (2) by Month 24 (2028-10-14), quantify the winning-chemistry candidate's estimated COGS per cell (material only, synthesis labor, facility amortization), targeting <USD 150/kWh or better for licensing appeal; (3) at the Month 30 (2029-04-14) and Month 36 (2029-10-14) gates, include cost/manufacturability assessment alongside energy and cycle-life gates; (4) if cost projections exceed licensing benchmarks, allocate 3–6 months for cost-reduction redesign before finalizing the chemistry selection. This ensures the licensable result is both high-performance and technically/commercially viable.

## 3. Unclear hand-off and technology-transfer timeline for Months 72–84 (2032-10-14 to 2033-10-14)

The plan labels Months 72–84 (2032-10-14 to 2033-10-14) as 'technology transfer,' but does not define what deliverables, documentation, or process-scale validation a prospective licensee requires before accepting the technology. A vague hand-off risks the final cell being demonstrated at lab scale without the engineering, documentation, or pilot-line maturity that a commercial partner demands, leaving the invention shelved or requiring costly post-delivery redesign.

**Recommendation**:
Develop a detailed technology-transfer and commercialization roadmap by Month 36 (2029-10-14): (1) by Month 12 (2027-10-14), identify 3–5 prospective licensees (established battery makers, automotive OEMs, energy-storage firms) and conduct informal technical advisory discussions to understand their cell readiness requirements; (2) by Month 24 (2028-10-14), negotiate a licensing framework (IP ownership, exclusivity, manufacturing obligations, royalty rates) with at least one strategic licensee; (3) Months 36–72 (2029-10-14 to 2032-10-14), structure the R&D to produce licensable deliverables: (a) complete process documentation (synthesis, electrode coating, cell assembly, specifications); (b) a pilot-line batch of 100+ cells demonstrating reproducibility; (c) abuse-test and cycling data at the full pouch-cell scale; (d) digital models for simulation and manufacturing scale-up; (4) Months 72–84 (2032-10-14 to 2033-10-14), execute technology-transfer activities: manufacturing feasibility studies, equipment sourcing, supply-chain validation, and training of licensee engineering team. Without this clarity, the invented cell may not transition to real-world deployment.

## 4. No explicit contingency for partial success or descent to a lower-ambition target

The plan assumes delivery of a cell meeting both ≥500 Wh/kg and ≥1000 Wh/L by Month 84 (2033-10-14), but does not define fallback success criteria if both targets cannot be met by that date. A chemistry reaching 480 Wh/kg, 950 Wh/L with excellent cycle life still represents a valuable invention, but the plan lacks guidance on whether this constitutes a valid outcome or forces a failed programme declaration.

**Recommendation**:
Define tiered success criteria and a descent path by Month 36 (2029-10-14) gate: (1) Primary success: ≥500 Wh/kg AND ≥1000 Wh/L AND ≥300 cycles by Month 84 (2033-10-14); (2) Secondary success (if primary unmet by Month 60 = 2031-10-14): ≥480 Wh/kg AND ≥950 Wh/L AND ≥300 cycles, with documented design rationale for why higher targets were not achieved; (3) Tertiary success (if secondary unmet): demonstrate a measurable advancement over state-of-the-art (e.g., longest cycle life at >400 Wh/kg, or highest volumetric density with acceptable gravimetric), with clear licensing narrative; (4) at the Month 36 (2029-10-14) chemistry-selection gate, the Steering Committee should set explicit descent thresholds and communicate them to the funder so final outcomes are not surprising. This avoids the perception of programme failure when a valuable but non-record-setting cell is delivered.

## 5. Missing criteria for candidate chemistry deprioritization or elimination during the tournament

The plan specifies Month 18 (2028-04-14) and Month 30 (2029-04-14) gates but does not detail the quantitative go/no-go thresholds for keeping or dropping individual chemistries between gates. Ambiguity invites subjective decisions or allows weak candidates to consume resources because elimination criteria are not pre-defined, risking budget waste and delayed focus on strong paths.

**Recommendation**:
Establish explicit quantified deprioritization rules by Month 6 (2027-04-14): (1) At Month 12 (2027-10-14): Deprioritize any chemistry with (a) projected cell-level <480 Wh/kg (10% below target), (b) measured cycle-life <200 cycles at 80% after 18 months of interface engineering, (c) thermal-runaway onset <100°C without a clear mitigation path; (2) At Month 18 (2028-04-14): Cut to ≤2 active branches if all three show fundamental barriers; if a candidate is clearly superior on any gate metric (e.g., 520 Wh/kg vs. 480, or 400 cycles vs. 180), shift resources toward it proportionally; (3) At Month 24 (2028-10-14): Require measured cycle-life data; any candidate with <250 cycles at 80% is moved to reserve status unless within 2–4 month redesign window; (4) At Month 30 (2029-04-14): Third-party pouch-cell verification is mandatory; if a candidate fails ≥950 Wh/L despite ≥500 Wh/kg material-level gains, allocate 6-month architecture sprint before the Month 36 (2029-10-14) final gate rather than carrying it forward. Document all deprioritization decisions in the forensics atlas and Steering Committee minutes to prevent later resurrection of weak paths.

---

# Potential Improvements

## 1. Refine the pilot-line capacity and contingency-build strategy to account for multi-chemistry builds and redundancy

The plan specifies 50–100 cells/month (estimate) modular pilot-line capacity, but does not detail how builds are distributed across three or four tournament chemistries, or how redundancy is maintained if the primary line fails. If each chemistry requires 50 cells/month to maintain discovery pace, a 100-cell/month line cannot support three active chemistries simultaneously by Month 24 (2028-10-14). Competing build requests could introduce queuing delays and bottlenecks.

**Recommendation**:
Develop a phased capacity-ramp plan by Month 3 (2027-01-14): (1) Months 3–12 (2027-01-14 to 2027-10-14): 50–100 cells/month total, split across three chemistries (roughly 20–30 cells/month each) plus reference cells; focus on material synthesis and coin-cell validation, pouch-cell builds secondary; (2) Months 12–24 (2027-10-14 to 2028-10-14): scale line to 150–200 cells/month if two chemistries remain strong, allowing 50–75 cells/month per active path plus parallel builds for safety and degradation studies; (3) Months 24–36 (2028-10-14 to 2029-10-14): maintain 150–200 cell/month capacity, with 70–80% going to finalists by Month 30 (2029-04-14); (4) Establish a secondary modular line or partner backup agreement (UT Austin, national lab) capable of 50 cells/month within 4-week notice, to provide redundancy if the primary line experiences extended downtime (equipment failure, permitting suspension). Cost this as part of the USD 15 M pilot-line capital or as part of the USD 0.6–1.2 M/year (estimate) operating lease.

## 2. Add explicit metrics and milestones for materials supply chain stability and precursor availability

The plan acknowledges precursor supply-chain risk and proposes dual sourcing by Month 3 (2027-01-14), but lacks concrete supply-chain verification, qualification timelines, or lead-time buffers. If a critical precursor (lithium compounds, fluorinated solvents, high-purity metal oxides) becomes unavailable or sees 8–12 month lead-time slippage, chemistry builds halt. Risk is particularly acute for chemistries with reactive or specialty materials (lithium sulfides, conversion-cathode fluorides).

**Recommendation**:
Establish precursor supply-chain management by Month 3 (2027-01-14): (1) Identify all critical precursors for each of the three tournament chemistries by Month 2 (2026-12-14); tier them as Tier 1 (essential, long lead time, few suppliers: lithium metal, fluorinated salts, high-purity cathode materials) and Tier 2 (common, short lead, multiple vendors); (2) Negotiate annual supply agreements for Tier 1 materials with ≥2 qualified vendors per precursor by Month 4 (2027-02-14), specifying 12-week minimum lead times and price-stability clauses (fixed pricing for ≥80% annual volume); (3) Maintain strategic inventory of Tier 1 materials (3–6 month supply estimate, budget USD 1–2 M) by Month 9 (2027-07-14) to buffer against disruption; (4) Assign a procurement lead (existing Financial & Operations Manager or dedicated role) to monitor geopolitical, supply-chain and regulatory risks quarterly from Month 6 (2027-04-14) onward; trigger expedited alternative sourcing if any vendor signals >2 month lead-time increase or >20% price increase; (5) Document supply-chain contingencies for each precursor (alternative vendors, synthetic routes, or chemistry redesigns that avoid the material) by Month 18 (2028-04-14).

## 3. Clarify the independent red team's authority and escalation path for challenging Steering Committee decisions

The plan establishes an independent red team of 2–3 scientists reporting directly to the Steering Committee with authority to 'challenge progress claims.' However, it does not specify the escalation procedure if the red team's findings conflict with core-team claims at a gate, or how disputes are resolved without delays. Ambiguous authority could result in either the red team being ignored (defeating its purpose) or gate decisions being delayed weeks while disputes are arbitrated.

**Recommendation**:
Define red-team governance by Month 1 (2026-11-14): (1) The red-team lead reports directly to the Steering Committee chair (Programme Director) and separately to the funder representative, bypassing core-team chains of command; (2) Red-team findings on cell-level metrics (energy density, cycle life, safety) are binding: if the red team's independent replication contradicts a core team's claimed result by >5% on energy density or >10% on cycle life, the gate decision is deferred 2 weeks to allow the core team to respond, provide additional evidence, or acknowledge the discrepancy; (3) If the discrepancy is not resolved within 2 weeks, the Steering Committee votes on whether to advance based on the red team's measured data rather than the core team's claimed data; (4) All gate reviews (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) include a 1-hour red-team presentation of findings and a 30-minute rebuttal/discussion period before final committee votes; (5) Document all red-team challenges and resolutions in the programme archives, forming a record of scientific rigor and funder accountability. This ensures the red team has real authority while maintaining decision velocity.

## 4. Expand the cycle-life degradation-mechanism roadmap to include actionable redesign targets

The plan requires cycle-life forensics and a quarterly forensics atlas, but does not specify how root-cause mechanisms (dendrite growth, polysulfide dissolution, electrolyte oxidation, lithium-ion depletion) translate into design actions. A forensics atlas documenting 'dendrite growth in 40% of failures' is inert unless it specifies which of 5–10 possible mitigations (electrolyte additive, anode coating, separator modification, current density reduction) is being tested and when results are expected.

**Recommendation**:
Develop a degradation-mechanism-to-redesign roadmap by Month 12 (2027-10-14): (1) For each chemistry, maintain a 'failure-mode priority matrix' (quarterly updated, Month 12 = 2027-10-14 onward): rows = root-cause mechanisms (dendrite, polysulfide dissolution, structural collapse, etc.), columns = occurrence rate, severity (cycle-life impact), and estimated redesign effort and time; (2) For each failure mode occurring in >20% of cells, pre-identify 3–5 candidate mitigation strategies (e.g., for dendrite: electrolyte additive X, anode coating Y, pressure management Z, current-limiting control W) with estimated 2–4 month test timelines; (3) At each quarterly forensics review, assign the top unresolved failure mode to a chemist lead (existing team) for immediate redesign testing: if dendrite accounts for 35% of failures, dedicate 2–3 cells/week to dendrite-mitigation experiments through the next quarter; (4) Communicate redesign progress (new additive tested, protective coating applied, next test planned) to the Steering Committee at gates, so the committee can assess whether cycle-life improvement is directional or stalled. This transforms forensics from a tracking tool into an active mechanism for driving chemistry improvement.

## 5. Establish explicit criteria for when to escalate characterization bottlenecks to partner or in-house expansion

The plan assumes <3 week turnarounds from partner facilities and specifies a 2–3 M in-house instrument by Month 8 (2027-06-14), but does not define when partner queues have become the discovery bottleneck, or when in-house capacity expansion is justified. If partner queues drift to 5–7 weeks by Month 18 (2028-04-14), the programme should escalate, but the plan lacks explicit trigger points for action.

**Recommendation**:
Establish characterization-throughput monitoring and escalation by Month 9 (2027-07-14): (1) Track monthly characterization turnaround (target ≤21 days from sample submission to report, proposed) and hypothesis-test throughput (hypothesis generation pace vs. characterization completion pace) from Month 12 (2027-10-14) onward; (2) If average turnaround exceeds 28 days or characterization becomes the bottleneck for 2 consecutive months, trigger Tier 1 escalation: contact partner facilities to expedite, increase commercial lab outsourcing budget (USD 2–3 M/year available), or evaluate whether a second in-house instrument (USD 1–1.5 M) is justified; (3) If turnaround remains >35 days despite Tier 1 actions, escalate to the Steering Committee: allocate supplemental capital from the general reserve (USD 2–3 M estimate) for a second in-house instrument or expanded commercial lab access; (4) Document these escalations in monthly programme status reports so queues do not silently slow discovery for months without decision-maker visibility.

## 6. Add data-management and open-science publication strategy to accelerate learning and establish priority

The plan emphasizes partnering and publication prestige but lacks a formal data-management system (electronic lab notebook, centralized characterization database) or publication cadence. Without structured data management, forensics insights remain scattered; without a publication plan, early findings may be scooped by competitors or lose priority-date value. Open publication also strengthens recruitment and partner collaboration.

**Recommendation**:
Establish a data-management and open-science roadmap by Month 6 (2027-04-14): (1) By Month 9 (2027-07-14), implement a unified electronic lab notebook (ELN) and characterization data repository (e.g., LabKey, Benchling, or equivalent) accessible to all core teams and (with controlled permissions) partner institutions; all cell cycling data, electrochemical measurements, post-mortem images and forensics reports are recorded in standardized format and time-stamped; (2) By Month 18 (2028-04-14), publish ≥1 peer-reviewed manuscript summarizing early coin-cell performance of the three tournament chemistries, electrolyte stability findings, or degradation-mechanism discoveries; authorship includes core team and partner institutions; (3) By Month 30 (2029-04-14), publish ≥1 additional manuscript on the winning chemistry's pouch-cell design and initial cycle-life data (subject to <6 month IP filing delay for any patentable findings); (4) Establish a pre-publication review process: all manuscripts and patents are reviewed internally 30 days before submission to allow the Steering Committee and IP counsel to flag confidential information or patent opportunities; (5) This publication pace (2–3 peer-reviewed papers over 84 months, typical for an R&D programme) establishes priority, attracts and retains talented researchers, and provides a record of methods and data that supports eventual licensing and technology transfer.

## 7. Refine the definition of 'licensable result' to include specific documentation, data-package and design-freeze requirements

The plan targets a 'licensable invention' but does not specify what documentation, process specifications, design blueprints, or data packages a prospective licensee expects to receive. Handing off a working pouch cell without complete process documentation, material supply-chain details, equipment sourcing, or digital manufacturing models is not licensable; a licensee cannot reproduce or scale the technology.

**Recommendation**:
Define 'licensable result' deliverables by Month 24 (2028-10-14): (1) Process Documentation: complete, step-by-step synthesis and assembly procedures for all active materials and cell components, with tolerance specifications for each critical parameter (coating thickness ±5 µm, electrolyte volume ±2%, stack pressure ±1 atm, thermal ramping rates, drying times, etc.); (2) Material Specifications and Supply Chain: qualified suppliers for all precursors and consumables, negotiated pricing and lead-time agreements, substitution pathways if preferred suppliers become unavailable; (3) Pilot-Line Design: equipment list, specifications, layout, and commissioning checklist for replicating the cell line at scale; (4) Cell Data Package: ≥50 cells with complete characterization (electrochemical curves, impedance spectra, cycle-life and degradation data, abuse-test results, third-party verification); (5) Digital Models: electrochemical simulation models (validated against experimental data ±5%), manufacturing process models, and engineering drawings for electrode, separator and pouch architectures; (6) Failure-Mode and Mitigation Database: documented degradation mechanisms, mitigation strategies that worked or failed, and recommendations for further optimization; (7) Design Freeze at Month 72 (2032-10-14): final cell architecture, materials and processes are locked and documented; Months 72–84 (2032-10-14 to 2033-10-14) focus on verification, documentation completion and licensee readiness, not new chemistry or architecture changes. This concrete checklist ensures the handed-over technology is genuinely reproducible and licensable.

## 8. Add a planned interim milestone or 'proof point' between Month 36 (2029-10-14) selection gate and final Month 72 (2032-10-14) verification

The plan specifies gates at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14), then jumps to Month 72 (2032-10-14) final verification without intermediate proof points. A 36-month gap (Months 36–72 = 2029-10-14 to 2032-10-14) without intermediate milestones risks drift: the winning chemistry may stall on cycle-life improvement, or architectural optimization may consume months without detectable progress, leaving insufficient runway for final validation.

**Recommendation**:
Add an intermediate 'optimization gate' at Month 54 (2031-04-14): (1) At Month 54 (2031-04-14), require the winning chemistry to demonstrate (a) ≥400 cycles at 80% capacity retention (an intermediate target toward the final ≥300 cycles; implies maturation progress), (b) ≥500 Wh/kg and ≥1000 Wh/L maintained on fresh pouch-cell builds with <5% variance month-to-month, (c) thermal-runaway onset and abuse-test pass/fail criteria consistent with Month 36 (2029-10-14) results, (d) ≥50 pouch cells manufactured and tested with reproducibility ≥90% within ±10%; (2) If Month 54 (2031-04-14) performance is on track, proceed to the final validation Months 54–72 (2031-04-14 to 2032-10-14) phase with confidence; if optimization has stalled (cycle-life <350 cycles, Wh/L <950, reproducibility <85%), escalate to Steering Committee for intensive debugging or contingency redesign; (3) This intermediate gate maintains decision-velocity and prevents the final 12-month sprint (Months 72–84 = 2032-10-14 to 2033-10-14) from being forced to rush incomplete verification work. It also signals progress to the funder and strengthens the programme narrative at mid-point.

## 9. Clarify roles and handoff between Characterization & Forensics Specialist and internal-lab red team in terms of bias and independence

The Characterization & Forensics Specialist is part of the core programme (full-time employee) and sits within the chemistry teams' operational loop, operating in-house instruments and feeding results directly to core teams. The independent red team is separate. However, the plan does not clarify who operates the red team's replication equipment, whether they have exclusive access to in-house post-mortem instruments for verification, or how to prevent the core-team forensics specialist from biasing results.

**Recommendation**:
Establish clear separation of duties and instrument access by Month 3 (2027-01-14): (1) Characterization & Forensics Specialist: operates in-house post-mortem instruments (SEM, XRD) during weekday business hours and generates forensics reports that feed core-team redesign cycles; publishes findings in the forensics atlas; (2) Red Team: has exclusive access to the in-house post-mortem instruments (or a dedicated duplicate instrument, if budget allows) on dedicated time blocks (e.g., Tuesday/Wednesday afternoons) or to external partner facilities with priority scheduling; red team independently replicates failed cells from the core teams' submitted samples without the core forensics specialist's direct involvement; (3) Red-team forensics reports are sent directly to the Steering Committee and funder, not to core teams, preventing potential bias in how findings are reported; (4) At gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), the red team presents its independent forensics findings (root-cause mechanisms, cycle-life patterns, safety observations) without prior discussion with core teams, allowing the Steering Committee to compare core-team and red-team interpretations; (5) If budget does not support a duplicate in-house instrument, the red team uses external partner facilities exclusively and has contractual priority access (≥4 slots per month, guaranteed <3 week turnaround), ensuring independence. This dual-track forensics structure preserves scientific integrity while maintaining core-team learning velocity.