### 1. Project Sponsor confirms programme Director (chair of Scientific Steering Committee) and appoints four Chemistry Leads (one per active chemistry pathway, one for reserve chemistry management). Director and Leads are identified by name or role descriptor; appointment confirmation letter issued.

**Responsible Body/Role:** Project Sponsor (pre-existing funder authority; not yet a constituted committee)

**Suggested Timeframe:** Month 0 (2026-10-14) (project week 1-2)

**Key Outputs/Deliverables:**

- Appointment Confirmation Letter naming Director and four Chemistry Leads
- Director acceptance memo
- Chemistry Lead CVs and conflict-of-interest declarations

**Dependencies:**

- Project Sponsor identified and authorized to commit funding
- Recruitment of Director and Chemistry Leads completed or offers accepted

### 2. Project Sponsor formally appoints the independent red team members (2-3 external or internal non-core scientists) with explicit authority to replicate results, challenge claims and delay gate decisions. Red team members are selected for independence from core chemistry teams and report directly to the Scientific Steering Committee, not to chemistry leads.

**Responsible Body/Role:** Project Sponsor in consultation with appointed Director

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Red Team Member Appointment Letters (3 members)
- Red Team Charter documenting independence, decision authority and escalation rights
- Red Team member CVs and conflict-of-interest declarations

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- External expert advisors or senior scientists identified as candidates for red team

### 3. Project Sponsor appoints Chief EHS Officer and external regulatory/EHS consultant to lead hazardous-materials compliance, permitting and incident prevention. This role is filled before formal site selection to enable immediate regulator engagement.

**Responsible Body/Role:** Project Sponsor in consultation with appointed Director

**Suggested Timeframe:** Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Chief EHS Officer Appointment Letter
- EHS Consultant Engagement Letter (3-5 year contract with quarterly regulatory-update briefings)
- Chief EHS Officer acceptance memo and initial 30-day plan

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Budget USD 500K-1M/yr approved for EHS staff and consulting

### 4. Director drafts initial Terms of Reference (ToR) for the Scientific Steering Committee, including decision authority, meeting cadence (monthly Months 0-12 = 2026-10-14 to 2027-10-14, then quarterly), gate-review process (3-week cycles at Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14), escalation paths and conflict-resolution mechanisms. Draft incorporates lessons from the strategic-decisions document and risk-assessment framework.

**Responsible Body/Role:** Programme Director (appointed in Month 0 = 2026-10-14)

**Suggested Timeframe:** Month 0 (2026-10-14), within 1 week of appointment

**Key Outputs/Deliverables:**

- Draft Scientific Steering Committee ToR v0.1
- Proposed decision-authority matrix (Director: <USD 500K, Committee: USD 500K-2M, Funder: >USD 2M)
- Proposed gate-review timeline and criteria checklist

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Project Sponsor guidance on escalation paths and funder sign-off thresholds provided

### 5. Director circulates draft Scientific Steering Committee ToR for review and feedback from the nominated Chemistry Leads, external technical advisor and Funder representative. Review period is 1 week; feedback consolidated into a summary memo.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), concurrent with ToR drafting

**Key Outputs/Deliverables:**

- ToR Review Feedback Summary (consolidated from all reviewers)
- Marked-up draft ToR v0.2 with Director responses to feedback

**Dependencies:**

- Draft ToR v0.1 circulated (Month 0 = 2026-10-14)
- Chemistry Leads, external advisor and Funder representative identified and available to review

### 6. Director finalizes Scientific Steering Committee ToR incorporating feedback and obtains sign-off from Funder representative. Final ToR is issued and shared with all Committee members.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 1 (2026-11-14), by the end of the week

**Key Outputs/Deliverables:**

- Approved Scientific Steering Committee ToR v1.0
- Funder sign-off email or memo
- Distribution list and meeting-calendar invitations for first Committee meeting (Month 1 = 2026-11-14)

**Dependencies:**

- ToR v0.2 and feedback summary completed (Month 0-1 = 2026-10-14 to 2026-11-14)
- Funder representative acceptance of ToR authority levels

### 7. Chief EHS Officer and Director jointly engage Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ) and EPA representatives in an initial collaborative meeting to outline the programme's chemistry scope, permitting needs (phased dry-room, synthesis, abuse-test chambers) and compliance strategy. Regulator feedback informs the phased-permit plan.

**Responsible Body/Role:** Chief EHS Officer, supported by Programme Director and external EHS consultant

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), concurrent with EHS Officer hire

**Key Outputs/Deliverables:**

- Regulator Engagement Meeting Minutes (fire authority, TCEQ, EPA)
- Regulator Feedback Summary (permit categories, application timelines, early concerns)
- Preliminary Phased-Permit Plan (Phase 1-3 timeline and required applications)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Site location selected or under review (not yet required to be final)

### 8. Director and Finance Manager jointly develop a detailed budget-allocation model breaking down the USD 300M by category (payroll, capital, facility, precursor, testing, EHS, computing, reserve) and year. The model identifies any funding gaps, carry-forward requirements (Months 36-84 = 2029-10-14 to 2033-10-14 opex shortfall) and partner co-funding offset targets (proposed ≥15%).

**Responsible Body/Role:** Programme Director, supported by Finance Manager (hired or identified by Month 2 = 2026-12-14)

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Budget Allocation Model v1.0 (Excel or equivalent, detailed by year and cost center)
- Funding-Gap Analysis (identifying Months 36-84 = 2029-10-14 to 2033-10-14 shortfall and carry-forward plan)
- Partner Co-Funding Offset Plan (proposed targets by category)

**Dependencies:**

- Director and Chemistry Leads available to confirm staffing and capital assumptions
- Finance Manager hired or identified

### 9. Director and Chief EHS Officer jointly develop a comprehensive regulatory-compliance assessment covering EPA, OSHA, TCEQ, DOT and local Austin Fire Authority rules applicable to the programme's reactive-materials, synthesis and abuse-testing operations. Assessment identifies all required permits, generators licenses, waste-contractor agreements and standard operating procedures (SOPs) by scope (dry-room, synthesis, waste handling, abuse testing).

**Responsible Body/Role:** Chief EHS Officer in collaboration with Director; external EHS consultant provides subject-matter expertise

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Regulatory Compliance Assessment Report (EPA, OSHA, TCEQ, DOT, local)
- Permit Categories and Application Checklist (required documents, lead times, decision points)
- SOP Template Library (dry-room, synthesis, waste handling, abuse testing, incident response)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Regulator engagement meeting completed (Month 0-1 = 2026-10-14 to 2026-11-14), providing initial feedback
- External EHS consultant retained (Month 1 = 2026-11-14)

### 10. Chief EHS Officer and external consultant identify all major equipment and precursor purchases expected to be denominated in foreign currencies (EUR, CNY, JPY) and develop a foreign-exchange (FX) risk-mitigation plan. Plan includes forward-exchange contracts and fixed-USD pricing for capital equipment ordered in Months 2-6 (2026-12-14 to 2027-04-14), and reserves USD 2-3M FX contingency within the USD 5M general reserve.

**Responsible Body/Role:** Finance Manager in consultation with Director and Chemistry Leads

**Suggested Timeframe:** Month 2 (2026-12-14)

**Key Outputs/Deliverables:**

- Foreign-Currency Exposure Inventory (major equipment and precursor purchases, estimated amounts and currencies)
- FX Risk-Mitigation Strategy (forward contracts, USD fixed-pricing, hedging plan)
- FX Contingency Reserve Allocation (USD 2-3M within USD 5M general reserve)

**Dependencies:**

- Budget allocation model complete (Month 2 = 2026-12-14)
- Preliminary equipment and precursor sourcing list available from Chemistry Leads

### 11. Director institutes the IP strategy and clean-room onboarding protocol, including confidentiality agreements, non-use clauses for employees from Tesla or competing firms, background-check procedures and a 6-month observation period before full access to sensitive designs. IP strategy document specifies filing timelines (provisional patents on key compositions and formats as they emerge, non-core materials work published in peer-reviewed journals after 6-month review).

**Responsible Body/Role:** Programme Director in consultation with Legal Counsel and appointed Chemistry Leads

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14)

**Key Outputs/Deliverables:**

- IP Strategy Document (filing scope, provisional-patent timeline, publication review process, licensing framework planned for Month 24 = 2028-10-14)
- Clean-Room Onboarding Protocol (confidentiality agreements, non-use clauses, background-check procedure)
- Employee Disclosure and Conflict-of-Interest Form Template

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Legal Counsel available for guidance
- Recruitment of core team members underway or about to begin

### 12. Director and Chemistry Leads jointly define go/no-go criteria for the Month 18 (2028-04-14), Month 30 (2029-04-14) and Month 36 (2029-10-14) gate reviews. Criteria include quantified thresholds for cell-level energy density (≥500 Wh/kg, ≥950 Wh/L interim), cycle life (≥300 cycles at 80% retention, proposed threshold), safety (thermal-runaway onset ≥120°C, proposed), and cell-level mass-and-volume model reproducibility (90% of cells within ±10%, proposed). Criteria are documented in a Gate Criteria Specification document.

**Responsible Body/Role:** Programme Director in collaboration with Chemistry Leads and independent red team (once appointed)

**Suggested Timeframe:** Month 3 (2027-01-14), to be finalized before active chemistry work reaches Month 6-9 (2027-04-14 to 2027-07-14) scale

**Key Outputs/Deliverables:**

- Gate Criteria Specification Document (Month 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14 go/no-go thresholds with quantified metrics)
- Cell-Level Mass-and-Volume Model Specification (inputs, assumptions, target accuracy ±10%)
- Success-Metrics Dashboard Template (for quarterly tracking against gate criteria)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Red team appointed (Month 1 = 2026-11-14) and briefed on gate-criteria development

### 13. Programme Director calls and chairs the first Scientific Steering Committee meeting. Agenda includes: (i) Committee ToR, decision authority and escalation paths review; (ii) red-team charter and independence agreement; (iii) chemistry-tournament structure and budget allocation per team; (iv) gate-criteria and success metrics review; (v) risk register initialization and mitigation-plan assignments; (vi) calendar and meeting logistics. Meeting concludes with Committee consensus on roles and first-action items.

**Responsible Body/Role:** Programme Director (chair of Scientific Steering Committee, now formally constituted)

**Suggested Timeframe:** Month 1 (2026-11-14), within 1 week of finalizing Committee ToR

**Key Outputs/Deliverables:**

- Scientific Steering Committee Meeting Minutes (including attendance, decisions, action items with owners and due dates)
- Committee consensus memo confirming ToR, decision authority, meeting schedule and first 90-day action plan
- Risk Register v1.0 initialized with 20+ risks, owners and mitigation plans

**Dependencies:**

- Scientific Steering Committee ToR finalized (Month 1 = 2026-11-14)
- All Committee members appointed and available to attend

### 14. Director and Chemistry Leads jointly establish the Chemistry and Discovery Leadership Team structure, confirming team leads and core members for each of the three active chemistry pathways plus reserve. Team budgets are allocated (proposed: equal initial share Months 0-12 = 2026-10-14 to 2027-10-14, rebalanced after Month 12 = 2027-10-14 based on progress). Chemistry Leadership ToR is drafted, specifying weekly team meetings, monthly progress reviews, decision authority (≤USD 500K per team per quarter), escalation thresholds and reporting to the Scientific Steering Committee.

**Responsible Body/Role:** Programme Director in consultation with appointed Chemistry Leads

**Suggested Timeframe:** Month 1 (2026-11-14), concurrent with first Steering Committee meeting

**Key Outputs/Deliverables:**

- Chemistry and Discovery Leadership Team ToR v1.0 (decision authority, meeting cadence, escalation paths)
- Chemistry-Team Budget Allocation (USD allocation per team, Month 0-12 = 2026-10-14 to 2027-10-14 and Month 12-24 = 2027-10-14 to 2028-10-14 outlook)
- Chemistry Leadership Roster (team leads, synthesis manager, pilot-line manager, characterization manager, data manager)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)

### 15. Chief EHS Officer drafts standard operating procedures (SOPs) for reactive-chemistry synthesis, dry-room operation, cell assembly, pouch-cell fabrication, waste handling and abuse testing. SOPs are reviewed by the external EHS consultant and regulator for compliance with EPA, OSHA and TCEQ rules. Draft SOPs are circulated to Chemistry Leads for feasibility and operability feedback.

**Responsible Body/Role:** Chief EHS Officer supported by external EHS consultant

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Standard Operating Procedures Library (synthesis, dry-room, cell assembly, waste handling, abuse testing, incident response)
- Regulator Review Feedback Summary (fire authority and TCEQ input on SOP compliance)
- SOP v1.0 Final (incorporating regulator and Chemistry Lead feedback)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- Regulatory Compliance Assessment completed (Month 2 = 2026-12-14)
- Chemistry Leads and pilot-line manager available for feasibility review

### 16. Chief EHS Officer, Finance Manager and Director jointly establish the internal EHS Compliance Office, including designation of Laboratory Safety Coordinator (embedded with chemistry teams), incident-response protocol and internal-audit schedule. EHS Compliance Office ToR specifies: quarterly internal EHS audits, quarterly regulator-engagement meetings, incident-log maintenance and corrective-action tracking, and escalation to Steering Committee for serious incidents (injuries, chemical release, EHS violations).

**Responsible Body/Role:** Chief EHS Officer

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- EHS Compliance Office ToR v1.0 (audit schedule, regulator meetings, incident reporting, escalation paths)
- Laboratory Safety Coordinator Job Description and Reporting Structure
- Incident-Response Protocol (roles, communication chain, remediation steps, regulator notification)

**Dependencies:**

- Chief EHS Officer hired and SOP library drafted (Months 1-3 = 2026-11-14 to 2027-01-14)
- Site location secured or lease signed (Month 1-3 = 2026-11-14 to 2027-01-14)

### 17. Director and Finance Manager jointly establish the Finance and Funding Governance (integrated within Scientific Steering Committee), designating a Finance Manager and Programme Controller to manage tranche release, spend tracking, variance reporting and contingency activation. Finance governance charter specifies: (i) tranche-release conditions (T2 at Month 12 = 2027-10-14 conditional on Phase 1 permit, operational pilot line, live cell-level model; T3 at Month 24 = 2028-10-14 conditional on Month 18 = 2028-04-14 gate pass; T4 at Month 36 = 2029-10-14 conditional on chemistry-selection gate); (ii) approval authority (Director: <USD 500K, Committee: USD 500K-2M, Funder: >USD 2M); (iii) reserve and pivot-runway management; (iv) partner cost-sharing tracking (≥15% target).

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14)

**Key Outputs/Deliverables:**

- Finance and Funding Governance Charter v1.0 (tranche conditions, approval authority, variance thresholds)
- Financial-Tracking Dashboard Specification (spend by cost center, tranche balance, variance flagging, reporting frequency)
- Tranche-Release Decision Criteria Checklist (documents to verify for each T2-T4 release)

**Dependencies:**

- Budget allocation model complete (Month 2 = 2026-12-14)
- Scientific Steering Committee ToR and decision authority defined (Month 1 = 2026-11-14)

### 18. Programme Director, Chemistry Leads and Finance Manager jointly develop the Chemistry-Tournament and Contingency-Planning Strategy, including: (i) detailed roles and budgets for each of the three active chemistry pathways; (ii) pre-stage contingency plan for the reserve chemistry (precursor supplier qualification, pilot-line equipment reconfiguration, staff cross-training); (iii) pivot-runway reserve allocation (USD 15M ring-fenced until Month 36 = 2029-10-14 gate); (iv) decision rules for rebalancing chemistry-team budgets post-Month 12 (2027-10-14) if one pathway is outperforming. Strategy is documented and reviewed by the Scientific Steering Committee.

**Responsible Body/Role:** Programme Director in collaboration with Chemistry Leads

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Chemistry-Tournament and Contingency Strategy v1.0 (active chemistry roles, reserve chemistry pre-stage plan, pivot mechanics, budget-rebalancing rules)
- Reserve Chemistry Pre-Stage Checklist (by Month 24 = 2028-10-14: suppliers qualified, equipment specs documented, staff trained on reserve pathway)
- Pivot-Runway Reserve Allocation Decision (USD 15M held unallocated, release thresholds)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)
- Scientific Steering Committee first meeting held (Month 1 = 2026-11-14)

### 19. Director and Chief EHS Officer jointly initiate the site-selection and lease-execution process for an Austin R&D location (proposed: Southeast Austin, SH-71/Burleson Road area). Target lease execution is Month 1 (2026-11-14); occupancy targeted Month 3 (2027-01-14). Site must accommodate 5,000-10,000 m² (estimate) for dry-room, pouch-cell line, synthesis labs, abuse-test chambers and characterization labs. Lease includes provisions for hazardous-materials permitting (reflective of regulator engagement outcomes from Month 0-1 = 2026-10-14 to 2026-11-14), utilities (power, ventilation, water), waste handling and emergency access.

**Responsible Body/Role:** Programme Director supported by Chief EHS Officer and Finance Manager

**Suggested Timeframe:** Month 0-1 (2026-10-14 to 2026-11-14), lease execution target Month 1 (2026-11-14)

**Key Outputs/Deliverables:**

- Site Selection and Assessment Report (location options, fit-out requirements, lease terms, hazmat-permitting feasibility)
- Executed Site Lease Agreement (3-5 year term, occupancy by Month 3 = 2027-01-14)
- Fit-Out and Commissioning Plan (dry-room build timeline, equipment installation sequence, operational readiness by Month 3 = 2027-01-14)

**Dependencies:**

- Director appointed (Month 0 = 2026-10-14)
- Regulator engagement meeting completed (Month 0-1 = 2026-10-14 to 2026-11-14), confirming permitting feasibility
- Budget allocation model finalized (Month 2 = 2026-12-14), confirming facility lease budget

### 20. Finance Manager and Director jointly develop a Monthly Financial-Tracking Dashboard and establish the monthly spend-review process. Dashboard tracks: cumulative spend by cost center (payroll, capital, facility, precursor, testing, EHS, computing, etc.), remaining balance in current tranche, variance from plan (<±15% normal, flag if ±15-20%, escalate if >±20%), and carry-forward to next tranche. Dashboard is populated by Month 3 (2027-01-14) and reviewed monthly at the Director-Finance Manager meeting; variance findings are escalated to Scientific Steering Committee quarterly.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), operational by end of month

**Key Outputs/Deliverables:**

- Monthly Financial-Tracking Dashboard v1.0 (Excel template or equivalent, populated with Month 0-1 = 2026-10-14 to 2026-11-14 actuals)
- Financial-Review Process Documentation (monthly review meeting schedule, variance escalation thresholds, correction procedures)
- T1 (USD 60M, Months 0-12 = 2026-10-14 to 2027-10-14) Spend Projection and Burn-Rate Profile

**Dependencies:**

- Finance Manager hired (Month 2 = 2026-12-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)
- Cost-center structure and P&L accounting codes established

### 21. Programme Director and Finance Manager jointly solicit, evaluate and negotiate 3-5 year formal standing agreements with at least two university or national-laboratory partners for characterization and candidate-validation services. Agreements specify: (i) guaranteed access to operando and post-mortem instruments (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy); (ii) turnaround target ≤3 weeks (proposed); (iii) annual cost-sharing commitment (≥15% of shared materials and characterization costs borne by partners, proposed); (iv) priority scheduling for failed-cell analysis; (v) 30-60 day exit clauses if access is lost. Agreements are signed by Month 3 (2027-01-14).

**Responsible Body/Role:** Programme Director in collaboration with Finance Manager and Chemistry Leads

**Suggested Timeframe:** Month 1-3 (2026-11-14 to 2027-01-14), target signing by Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Partner Evaluation and Selection Report (institution capabilities, instrument access, cost-sharing capacity)
- Executed Partner Agreements (≥2 institutions, 3-5 year terms, turnaround and cost-sharing specifics)
- Partner Backup and Escalation Plan (if primary partner access is lost or delayed >3 weeks, secondary partner engaged within 1 week)

**Dependencies:**

- Director and Chemistry Leads available to specify instrument and characterization needs
- Finance Manager available to negotiate cost-sharing terms

### 22. Chemistry Leads and Director jointly establish the cell-level mass-and-volume model, defining: (i) material composition inputs per chemistry pathway (anode, cathode, electrolyte, separator, current collectors, packaging); (ii) inactive-mass components (current collectors, separators, packaging, cell connectors); (iii) Wh/kg and Wh/L calculation methodology; (iv) model assumptions documented and validated against published benchmark cells; (v) quarterly update schedule. Model is live by Month 4 (2027-02-14) and projections for all candidates are generated by Month 6 (2027-04-14).

**Responsible Body/Role:** Chemistry Leads and Data Engineer (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 3-4 (2027-01-14 to 2027-02-14), model live by Month 4 (2027-02-14)

**Key Outputs/Deliverables:**

- Cell-Level Mass-and-Volume Model v1.0 (Excel or equivalent, documented assumptions, benchmark validations)
- Model User Guide (inputs, outputs, interpretation guidance, quarterly-update process)
- Initial Chemistry-Candidate Projections (for each active and reserve pathway, projected cell-level Wh/kg and Wh/L)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14) and material-composition specifications available
- Data Engineer hired (Month 1-2 = 2026-11-14 to 2026-12-14)
- Benchmark published-cell data gathered for model validation

### 23. Director and Chief EHS Officer jointly submit Phase 1 permit application (dry-room and low-hazard assembly) to Austin Fire Authority and TCEQ. Application references regulator engagement from Month 0-1 (2026-10-14 to 2026-11-14) and incorporates feedback. Target permit approval is Month 3 (2027-01-14) to enable operational start by Month 3 (2027-01-14).

**Responsible Body/Role:** Chief EHS Officer with support from Finance Manager and site-lease provider

**Suggested Timeframe:** Month 2 (2026-12-14), submit application by early in month

**Key Outputs/Deliverables:**

- Phase 1 Permit Application Package (fire authority and TCEQ, dry-room and assembly scope)
- Regulator Feedback Log and Response Memos (addressing agency questions or conditions)
- Phase 1 Permit Approval (target Month 3 = 2027-01-14)

**Dependencies:**

- Site lease executed (Month 1 = 2026-11-14)
- Regulatory Compliance Assessment and SOP drafts completed (Month 2 = 2026-12-14)
- Regulator engagement meetings held (Month 0-1 = 2026-10-14 to 2026-11-14)

### 24. Finance Manager and Director jointly initiate procurement of major long-lead equipment and materials with foreign-currency exposure (estimated delivery Months 2-6 = 2026-12-14 to 2027-04-14): modular dry-room unit, pouch-cell fabrication equipment, characterization instruments (in-house post-mortem instrument), computing infrastructure, and specialized precursor suppliers. For equipment with EUR or other foreign-currency pricing, negotiate fixed-USD contracts or forward-exchange agreements by Month 6 (2027-04-14). Procurement requisitions are issued with delivery schedules keyed to site occupancy (Month 3 = 2027-01-14).

**Responsible Body/Role:** Finance Manager in collaboration with Director, Chemistry Leads and Chief EHS Officer

**Suggested Timeframe:** Month 1-2 (2026-11-14 to 2026-12-14), RFQ/RFP release; Month 2-6 (2026-12-14 to 2027-04-14) contract negotiation and order placement

**Key Outputs/Deliverables:**

- Major Procurement Plan (equipment and precursor vendors, estimated delivery dates, FX exposure, contract terms)
- Executed Equipment Contracts (modular dry room, pouch-cell line, characterization instruments, computing)
- FX-Hedging Confirmations (forward-exchange contracts or USD fixed-price agreements for capital equipment)

**Dependencies:**

- Budget allocation model finalized (Month 2 = 2026-12-14)
- Chemistry Leads available to specify equipment capabilities
- Site lease executed (Month 1 = 2026-11-14), enabling delivery scheduling

### 25. Director and Finance Manager jointly finalize partner cost-sharing agreements with the ≥2 selected partner institutions. Agreements specify: (i) shared-cost categories (characterization services, materials, validation testing); (ii) partner financial or in-kind contribution targets (≥15% of shared costs, proposed); (iii) invoicing and reconciliation process; (iv) quarterly financial reconciliation meetings; (v) integration into programme financial tracking.

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Partner Cost-Sharing Agreement v1.0 (signed by both institutions and programme, contribution amounts and schedule)
- Shared-Cost Tracking Spreadsheet (partner contributions YTD, invoicing schedule, reconciliation dates)
- Financial Reconciliation Meeting Schedule (quarterly meetings with partners and Finance Manager)

**Dependencies:**

- Partner Agreements for characterization access signed (Month 3 = 2027-01-14)
- Budget allocation model finalized (Month 2 = 2026-12-14)

### 26. Chief EHS Officer and Director jointly schedule the first EHS Compliance Office operational meeting. Agenda includes: (i) SOP review and rollout to chemistry teams; (ii) Phase 1 permit conditions and compliance requirements; (iii) incident-response protocol walkthrough; (iv) staff training and qualification schedule; (v) quarterly internal-audit plan. Meeting includes the Laboratory Safety Coordinator (embedded with chemistry teams), external EHS consultant and regulator liaison.

**Responsible Body/Role:** Chief EHS Officer

**Suggested Timeframe:** Month 3 (2027-01-14), concurrent with Phase 1 permit approval

**Key Outputs/Deliverables:**

- EHS Compliance Office Meeting Minutes (attendance, SOP rollout assignments, training schedule)
- Staff EHS Training Schedule (initial certifications, quarterly refresher plan)
- Phase 1 Compliance Checklist (permit conditions, required certifications, safety equipment verification)

**Dependencies:**

- Phase 1 permit approved (Month 3 = 2027-01-14)
- SOP library finalized (Month 2-3 = 2026-12-14 to 2027-01-14)
- Chief EHS Officer and Laboratory Safety Coordinator hired (Month 1 = 2026-11-14)

### 27. Director and Chemistry Leads jointly conduct the first Chemistry and Discovery Leadership Team meeting. Agenda includes: (i) confirmation of team structure and budgets; (ii) gate-criteria and success-metrics review; (iii) cell-level mass-and-volume model introduction and first-candidate projections; (iv) synthesis and pilot-line startup plan (weeks 1-4 of month); (v) characterization partner onboarding and schedule; (vi) risk-register review and chemistry-specific mitigation plans. Meeting establishes the weekly synthesis/characterization sync, monthly all-hands reviews and monthly Steering Committee liaison reporting.

**Responsible Body/Role:** Programme Director, now delegating to Chemistry Leads (Chemistry and Discovery Leadership Team formally constituted)

**Suggested Timeframe:** Month 3 (2027-01-14)

**Key Outputs/Deliverables:**

- Chemistry and Discovery Leadership Team Meeting Minutes (team structure confirmation, budget allocation, schedule confirmation)
- Monthly Chemistry Progress-Reporting Template (cell builds, Wh/kg/Wh/L measurements, cycle-life data, safety results, forensics findings)
- 12-Week Chemistry Startup and Ramp Plan (synthesis targets, cell builds/month, characterization queue schedule)

**Dependencies:**

- Chemistry Leads appointed (Month 0 = 2026-10-14)
- Cell-level mass-and-volume model live (Month 4 = 2027-02-14, but initial projections available for Month 3 = 2027-01-14 meeting)
- Site occupancy begins (Month 3 = 2027-01-14)
- Phase 1 permit approved (Month 3 = 2027-01-14)

### 28. Director and independent red team jointly conduct the first red-team operational meeting. Agenda includes: (i) red-team charter and independence agreement review; (ii) replication protocol and acceptance criteria (cell-build procedure, cycling protocol, measurement tolerance ±10% on Wh/kg, ±5% on Wh/L, proposed); (iii) monthly data-review process (timeline: receive Chemistry Leadership monthly reports within 5 days, issue flag memo within 10 days if discrepancies detected); (iv) gate-verification timeline (identify ≥1 cell per team for replication ~4 weeks before gate meeting, issue results ≥5 days before Committee meeting); (v) cell-level mass-and-volume model audit plan (monthly reviews of model assumptions and benchmark validations).

**Responsible Body/Role:** Programme Director in consultation with appointed red team

**Suggested Timeframe:** Month 2-3 (2026-12-14 to 2027-01-14)

**Key Outputs/Deliverables:**

- Red Team Operational Meeting Minutes (protocol review, monthly process timeline, gate-verification plan)
- Red Team Data-Review and Replication Schedule (monthly reporting deadline, gate-verification sprints for Months 17, 29, 35 = 2028-03-14, 2029-03-14, 2029-09-14)
- Cell Replication Protocol v1.0 (cell-build procedure, cycling protocol, measurement tolerances, pass/fail criteria)

**Dependencies:**

- Red team appointed (Month 1 = 2026-11-14)
- Gate-criteria specification finalized (Month 3 = 2027-01-14)
- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)

### 29. Chief EHS Officer and external consultant jointly conduct a regulatory-monitoring and compliance-update briefing for the Scientific Steering Committee and Chemistry Leadership. Briefing covers: (i) federal, state and local rule changes anticipated in Months 1-12 (2026-11-14 to 2027-10-14) and beyond; (ii) any early-stage permit conditions or regulator feedback requiring programme adaptations; (iii) insurance and liability considerations; (iv) quarterly compliance-review schedule and regulator-engagement calendar.

**Responsible Body/Role:** Chief EHS Officer supported by external EHS consultant

**Suggested Timeframe:** Month 3 (2027-01-14), at or just before first full Steering Committee meeting

**Key Outputs/Deliverables:**

- Regulatory Monitoring and Compliance Update Briefing Slides (rule changes, regulator feedback, adaptations required)
- Quarterly Regulator-Engagement Calendar (standing meetings with fire authority, TCEQ, EPA liaison)
- Insurance and Liability Assessment (current coverage, gaps, quotes for expanded hazard coverage)

**Dependencies:**

- Chief EHS Officer hired (Month 1 = 2026-11-14)
- External EHS consultant retained (Month 1 = 2026-11-14)
- Regulator engagement meetings completed (Month 0-1 = 2026-10-14 to 2026-11-14)

### 30. Director and Finance Manager jointly initialize the monthly financial-tracking dashboard with actual spend from Months 0-2 (2026-10-14 to 2026-12-14). Dashboard populates cost centers (payroll, capital equipment procurement, site lease, precursor supply, partner agreements, EHS, computing) and tracks remaining balance in T1 (USD 60M). First variance analysis is conducted; if any category exceeds ±15% of plan by Month 3 (2027-01-14) end, corrective action is proposed by Director to Steering Committee.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), end of month

**Key Outputs/Deliverables:**

- Monthly Financial-Tracking Dashboard v2.0 (populated with Month 0-2 = 2026-10-14 to 2026-12-14 actuals, variance analysis, tranche balance)
- T1 Spend-to-Date Report (cumulative spend Months 0-2 = 2026-10-14 to 2026-12-14, category breakdown, variance flagging)
- Projected Burn-Rate Profile (Months 3-12 = 2027-01-14 to 2027-10-14, annualized rate, tranche-depletion timeline)

**Dependencies:**

- Financial-tracking dashboard established (Month 3 = 2027-01-14)
- Chemistry startup expenses being incurred (site lease, equipment procurement, staff onboarding)

### 31. Director and Chemistry Leads jointly commission the modular, leased dry-room and pouch-cell fabrication line at the Austin site. Commissioning activities include: (i) installation and equipment setup (Weeks 1-2); (ii) trial builds and process-parameter tuning (Weeks 3-4); (iii) yield optimization (Weeks 5-8); (iv) staff training on fabrication, cell-testing and data-logging (Weeks 1-8). Target is 50-100 pouch cells per month operational by Month 6 (2027-04-14), ramping to 100-150/month by Month 9 (2027-07-14) and sustained 100-150/month through Month 12 (2027-10-14).

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 3-6 (2027-01-14 to 2027-04-14), operational by Month 6 (2027-04-14)

**Key Outputs/Deliverables:**

- Pilot-Line Commissioning Plan (installation schedule, trial-build protocol, yield-optimization targets)
- Pilot-Line Monthly Performance Report (cells built, yield %, Wh/kg and Wh/L measurements, process-parameter consistency)
- Staff Training Certificates (dry-room operation, cell assembly, safety protocols)

**Dependencies:**

- Site lease executed and occupancy begins (Month 3 = 2027-01-14)
- Modular dry-room and pouch-cell equipment delivered (Month 3-4 = 2027-01-14 to 2027-02-14)
- Phase 1 permit approved (Month 3 = 2027-01-14)
- Pilot-Line Manager and synthesis team hired (Month 1-2 = 2026-11-14 to 2026-12-14)

### 32. Chemistry Leads and Data Engineer jointly activate the cell-level mass-and-volume model, generating projections for all three active chemistry pathways (and reserve if planned). Projections include: material composition, inactive-mass breakdown, projected Wh/kg and Wh/L per chemistry at cell level. Projections are reviewed against gate criteria (≥500 Wh/kg, ≥950 Wh/L interim) by Month 6 (2027-04-14). Any chemistry projected to fall below 950 Wh/L is flagged for focused redesign by Month 18 (2028-04-14).

**Responsible Body/Role:** Chemistry Leads and Data Engineer

**Suggested Timeframe:** Month 4-6 (2027-02-14 to 2027-04-14)

**Key Outputs/Deliverables:**

- Chemistry-Candidate Projection Report (three active + reserve, projected Wh/kg and Wh/L per chemistry)
- Model-to-Reality Variance Analysis (comparison of projected vs benchmark measured Wh/kg/L, model confidence assessment)
- Volumetric-Density Focus List (candidates projected <950 Wh/L, redesign actions and schedule)

**Dependencies:**

- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)
- Chemistry compositions and material specifications finalized for each pathway

### 33. Director and partner institutions jointly conduct the first formal quarterly financial reconciliation and milestone-verification meeting. Agenda includes: (i) review of partner in-kind contributions (instrument access, staff time, materials) and financial contributions against the ≥15% target (proposed); (ii) characterization work completed (samples analyzed, turnaround times); (iii) any cost overruns or underspends in shared categories; (iv) next quarter's planned joint work and cost-sharing.

**Responsible Body/Role:** Programme Director and Finance Manager, with partner institution representatives

**Suggested Timeframe:** Month 6 (2027-04-14) (quarterly, marking end of Q1 of partnership operations)

**Key Outputs/Deliverables:**

- Partner Quarterly Reconciliation Meeting Minutes (contributions verified, cost-sharing reconciliation, upcoming milestones)
- Shared-Cost Reconciliation Report (partner contributions YTD vs ≥15% target, any invoicing discrepancies)
- Partner Delivery Scorecard (instrument access, turnaround times, sample throughput)

**Dependencies:**

- Partner agreements signed (Month 3 = 2027-01-14)
- Partner cost-sharing agreements finalized (Month 3 = 2027-01-14)
- Characterization services operational (by Month 6 = 2027-04-14)

### 34. Director and Chemistry Leads jointly initiate synthesis and characterization work across all three active chemistry pathways, meeting target cell-build rates of 50-100 cells/month by Month 6 (2027-04-14). Activities include: (i) material precursor sourcing and supply-chain coordination (dual-sourcing confirmed by Month 6 = 2027-04-14); (ii) synthesis lab operations (daily bench work, process documentation); (iii) cell assembly and cycling (pouch cells tested at defined discharge rates and temperatures); (iv) characterization scheduling with partner institutions (operando and post-mortem analysis); (v) forensics protocol implementation (failed cells autopsy'd within one week, root causes assigned).

**Responsible Body/Role:** Chemistry Leads and Chemistry and Discovery Leadership Team

**Suggested Timeframe:** Months 3-6 (2027-01-14 to 2027-04-14), sustained through Month 12 (2027-10-14) and beyond

**Key Outputs/Deliverables:**

- Monthly Chemistry Progress Report (cell builds by chemistry, Wh/kg/Wh/L measurements vs model, cycle-life performance, safety results, forensics findings)
- Precursor Supply-Chain Status Report (suppliers qualified, dual-sourcing confirmed, 3-6 month buffer inventory established)
- Forensics Atlas v1.0 (failure modes documented, root-cause assignments, design-change implications for each failure type)

**Dependencies:**

- Pilot-line commissioned (Month 6 = 2027-04-14)
- Chemistry team fully staffed (Month 1-3 = 2026-11-14 to 2027-01-14)
- Partner characterization access activated (Month 6 = 2027-04-14)
- Forensics autopsy protocol finalized (Month 3 = 2027-01-14)

### 35. Chief EHS Officer and external consultant jointly submit Phase 2 permit application (reactive-metal and solvent synthesis) to fire authority and TCEQ. Application incorporates Phase 1 permitting experience and includes expanded scope for lithium-metal handling, solvent recovery, and reactive-precursor synthesis. Target approval is Month 6 (2027-04-14); if permitting slips beyond Month 6 (2027-04-14), pre-negotiate with external synthesis facilities for cost-plus outsourcing of any on-site-prohibited steps.

**Responsible Body/Role:** Chief EHS Officer with support from Finance Manager

**Suggested Timeframe:** Month 4 (2027-02-14), submit application; Month 6 (2027-04-14) approval target

**Key Outputs/Deliverables:**

- Phase 2 Permit Application Package (reactive-metal and solvent synthesis scope, expanded SOP library)
- Regulator Feedback Memo and Response (any agency conditions or phasing requirements)
- Phase 2 Permit Approval (target Month 6 = 2027-04-14); contingency external synthesis agreements if delay occurs

**Dependencies:**

- Phase 1 permit approved (Month 3 = 2027-01-14)
- Chemistry pathways finalized (synthetic routes, precursor materials confirmed)
- Regulator relationship established (Month 0-1 = 2026-10-14 to 2026-11-14)

### 36. Director and Data Engineer jointly activate the computing infrastructure for materials screening and machine-learning candidate ranking. If using national-laboratory HPC access (NREL, Lawrence Berkeley Lab), formalize the partnership agreement and schedule initial access. If using cloud computing (AWS, Google Cloud), set up accounts and cost tracking. Integrate the data pipeline (cell-cycling measurements, post-mortem characterization results, computed properties) by Month 9 (2027-07-14). Candidate-ranking model is trained on Month 6-12 (2027-04-14 to 2027-10-14) data and validated against experimental results; only models with ≥80% predictive accuracy are used for hypothesis ranking by Month 12 (2027-10-14).

**Responsible Body/Role:** Programme Director and Data Engineer

**Suggested Timeframe:** Month 3-9 (2027-01-14 to 2027-07-14)

**Key Outputs/Deliverables:**

- Computing Infrastructure Agreement (HPC partnership or cloud-computing contract, cost and access terms)
- Data-Pipeline Specification (cell-cycling data, characterization results, computed-property definitions, database schema)
- Candidate-Ranking Model v1.0 (trained on Month 6-12 = 2027-04-14 to 2027-10-14 data, validation accuracy ≥80%, ready for hypothesis ranking by Month 12 = 2027-10-14)

**Dependencies:**

- Data Engineer hired (Month 1-2 = 2026-11-14 to 2026-12-14)
- Cell-cycling and characterization data available from Month 6 (2027-04-14) onward
- National-laboratory or cloud-computing partner identified (Month 1-3 = 2026-11-14 to 2027-01-14)

### 37. Director and red team jointly conduct the first monthly data-review cycle. Chemistry Leadership submits monthly progress reports (cell builds, Wh/kg/Wh/L measurements, cycle-life data, safety results, forensics). Red team reviews within 5 days and issues a flag memo (within 10 days) if discrepancies are detected (e.g., claimed Wh/kg contradicts prior month, or measured Wh/L falls significantly below model projection). Red team flags are reviewed by Chemistry Leads; Chemistry Leads provide clarification or correction within 3 days. Process is formalized and repeated monthly through Month 72 (2032-10-14).

**Responsible Body/Role:** Independent Red Team with Chemistry and Discovery Leadership Team

**Suggested Timeframe:** Month 6 (2027-04-14), and monthly thereafter

**Key Outputs/Deliverables:**

- Monthly Data-Review Flag Memo (any claimed inconsistencies, measurement discrepancies, model mismatches)
- Chemistry Lead Response Memo (clarification or correction to flagged discrepancies within 3 days)
- Monthly Data-Review Summary (flagged and resolved issues, trends noted, confidence in data quality)

**Dependencies:**

- Red team operational (Month 2-3 = 2026-12-14 to 2027-01-14)
- Chemistry work producing data (Month 6 = 2027-04-14 onward)
- Monthly Chemistry Progress Report template established

### 38. Chief EHS Officer and external consultant jointly conduct the first quarterly internal EHS audit. Audit scope includes: (i) lab and dry-room inspection for compliance with Phase 1 permit conditions and SOPs; (ii) chemical inventory accuracy check (actual quantities vs permits); (iii) waste-handling procedures and contractor compliance; (iv) emergency-response equipment (spill kits, fire suppression, evacuation signage) readiness; (v) incident log review (goal: zero). Audit report is issued with findings, corrective actions and completion deadlines. Quarterly audits are repeated at Months 9, 12, 15, 18 (2027-07-14, 2027-10-14, 2028-01-14, 2028-04-14), etc. (proposed schedule: quarterly).

**Responsible Body/Role:** Chief EHS Officer with support from external EHS consultant and Laboratory Safety Coordinator

**Suggested Timeframe:** Month 6 (2027-04-14) (first of quarterly audits)

**Key Outputs/Deliverables:**

- Quarterly Internal EHS Audit Report (findings, compliance observations, corrective actions required)
- Corrective Action Tracking Log (action items, owner, completion deadline, follow-up)
- Audit Presentation to Steering Committee (summary findings, any urgent risks, compliance status)

**Dependencies:**

- Phase 1 permit approved and operations ongoing (Month 3 = 2027-01-14)
- SOP library in use and staff trained (Month 3-6 = 2027-01-14 to 2027-04-14)
- Chief EHS Officer and Laboratory Safety Coordinator operational (Month 1 = 2026-11-14)

### 39. Director jointly with the external technical advisor and Chemistry Leads establish the in-house post-mortem characterization capability (e.g., scanning electron microscope or X-ray diffraction) for rapid triage of failed cells. Equipment procurement, installation and staff training are completed by Month 6 (2027-04-14). Capability is operational by Month 8 (2027-06-14), enabling rapid turnaround (within 2-3 days) for failed-cell autopsy, complementing partner operando analysis which may have longer queues.

**Responsible Body/Role:** Chemistry Leads and Characterization Manager (part of Chemistry and Discovery Leadership Team)

**Suggested Timeframe:** Month 4-8 (2027-02-14 to 2027-06-14), operational by Month 8 (2027-06-14)

**Key Outputs/Deliverables:**

- In-House Post-Mortem Instrument Procurement and Installation Plan (equipment specs, vendor, delivery, installation)
- Staff Training and Qualification Plan (operator certifications, maintenance, data-quality procedures)
- Post-Mortem Characterization SOP (triage protocol, sample prep, analysis procedure, result documentation)

**Dependencies:**

- Site occupancy and laboratory space available (Month 3 = 2027-01-14)
- Capital equipment budget allocated (Month 2-3 = 2026-12-14 to 2027-01-14)
- Characterization Manager hired (Month 1-2 = 2026-11-14 to 2026-12-14)

### 40. Director and Chemistry Leads jointly commission Phase 1 pouch-cell verification with partner institutions. First independent third-party measurements of cell-level energy density (Wh/kg, Wh/L) and cycle life are conducted on early-stage candidate cells (not yet optimized, but representative of each chemistry pathway). Independent verification is completed by Month 12 (2027-10-14) to confirm measurement methodology and build confidence in data quality before the Month 18 (2028-04-14) gate review. Results are compared to in-house measurements; discrepancies trigger methodology review and calibration.

**Responsible Body/Role:** Chemistry Leads with partner institution characterization teams

**Suggested Timeframe:** Month 9-12 (2027-07-14 to 2027-10-14)

**Key Outputs/Deliverables:**

- Phase 1 Independent Verification Report (third-party measured Wh/kg, Wh/L, cycle-life data for 3-5 representative early-stage cells)
- Methodology Comparison Memo (in-house vs independent measurement results, confidence in measurement procedures)
- Calibration and Adjustment Actions (if systematic discrepancies found, corrective steps to align future measurements)

**Dependencies:**

- Partner characterization agreements operational (Month 6 = 2027-04-14)
- Early-stage candidate cells available for testing (Month 9-10 = 2027-07-14 to 2027-08-14)
- In-house pouch-cell fabrication and cycling capability established (Month 6 = 2027-04-14)

### 41. Director and Finance Manager jointly conduct quarterly financial review at end of Month 6 (2027-04-14), tracking T1 spend (Months 0-6 = 2026-10-14 to 2027-04-14 actual vs plan). Dashboard is updated with cumulative spend by cost center, variance analysis and burn-rate profile. If spend is on track or under plan, no action required; if variance exceeds ±15% in any category, corrective action is proposed. Monthly T1 spend is now ~USD 10M/month (budget = USD 60M/12 months); actual spend trend is reviewed for Months 3-6 (2027-01-14 to 2027-04-14) to forecast T2 release readiness.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-14), end of month

**Key Outputs/Deliverables:**

- T1 Midpoint Financial Review (cumulative spend Months 0-6 = 2026-10-14 to 2027-04-14, category breakdown, variance analysis)
- T2 Release Readiness Assessment (Phase 1 permit approval, operational pilot line, live cell-level model status, spend forecast)
- Corrective Action Plan (if variance >±15%), signed by Director

**Dependencies:**

- Monthly financial tracking operational (Month 3 = 2027-01-14)
- T1 expense categories being incurred (staffing, capital, lease, precursor, partner agreements)

### 42. Director and Chemistry Leads jointly submit Phase 2 permit application (if not yet submitted) or follow up on pending approvals. If Phase 2 permitting slips beyond Month 6 (2027-04-14), initiate pre-negotiated external synthesis agreements with licensed contract research organizations (est. cost USD 2-5M/yr if on-site synthesis is prohibited). External synthesis turnaround is estimated 4-6 weeks; if synthesis becomes a bottleneck, this risk is escalated to Steering Committee.

**Responsible Body/Role:** Chief EHS Officer and Finance Manager

**Suggested Timeframe:** Month 6 (2027-04-14), concurrent with Phase 2 permit decision or continuation

**Key Outputs/Deliverables:**

- Phase 2 Permit Status Report (approval received or expected date, any regulator conditions requiring adaptation)
- External Synthesis Contingency Agreement (if Phase 2 slips, pre-negotiated contract with CRO for synthesis steps)
- Synthesis Risk Escalation Memo (if Phase 2 approval unlikely by Month 6 = 2027-04-14, document impact and mitigation)

**Dependencies:**

- Phase 2 permit application submitted (Month 4 = 2027-02-14)
- External synthesis vendors pre-identified (Month 3-4 = 2027-01-14 to 2027-02-14)

### 43. Director and Finance Manager jointly prepare the T2 release decision package for Scientific Steering Committee approval. Package includes: (i) evidence that T1 milestones are met (Phase 1 permit approved, operational pilot line producing 50-100 cells/month, cell-level mass-and-volume model live); (ii) Phase 1 monthly spend vs plan (variance <±15%); (iii) chemistry progress summary (all three active pathways producing data, cells cycling, forensics data accumulating); (iv) gate-criteria confirmation (metrics defined, baseline measurements established); (v) T2 spend forecast (Months 12-24 = 2027-10-14 to 2028-10-14, ~USD 80M). T2 release condition is Month 12 (2027-10-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 10 (2027-08-14), to enable Steering Committee decision by Month 12 (2027-10-14)

**Key Outputs/Deliverables:**

- T2 Release Decision Package (milestone evidence, financial summary, chemistry progress, gate-readiness confirmation)
- T2 Spend Forecast (Months 12-24 = 2027-10-14 to 2028-10-14 budget projection, cost-center breakdown)
- Steering Committee Release Authorization (signed by majority of Committee + Funder)

**Dependencies:**

- T1 spend tracked and reported (through Month 10 = 2027-08-14)
- Phase 1 permit and all T1 milestones achieved by Month 10-12 (2027-08-14 to 2027-10-14)
- Chemistry progress data available for summary

### 44. Director and red team jointly prepare the red-team verification plan for the Month 18 (2028-04-14) gate review. Plan includes: (i) selection of ≥1 cell per chemistry team for independent replication (weeks 1-2 of Month 17 = 2028-03-14); (ii) red-team cell builds and cycling (weeks 2-4 of Month 17 = 2028-03-14); (iii) measurement of Wh/kg, Wh/L and cycle-life retention to ±10% tolerance (proposed); (iv) write-up of replication results and gate-readiness memo (week 1 of Month 18 = 2028-04-14). Red team is resourced and scheduled to deliver results ≥5 days before Steering Committee gate meeting (target: Week 2 of Month 18 = 2028-04-14 meeting).

**Responsible Body/Role:** Independent Red Team

**Suggested Timeframe:** Month 16-17 (2028-02-14 to 2028-03-14), planning; Month 17 (2028-03-14), replication sprint

**Key Outputs/Deliverables:**

- Red Team Gate Verification Plan for Month 18 (2028-04-14) (cell selection criteria, replication timeline, measurement protocols)
- Red Team Replication Results Memo (pass/no-pass on ≥1 cell per chemistry, Wh/kg/Wh/L measurements, cycle-life confirmation)
- Gate-Readiness Assessment Memo (red team recommendation on which chemistries pass Month 18 = 2028-04-14 gate criteria)

**Dependencies:**

- Red team operational (Month 2-3 = 2026-12-14 to 2027-01-14)
- Replication protocol finalized (Month 3 = 2027-01-14)
- Month 18 (2028-04-14) gate-criteria specification locked (Month 3 = 2027-01-14)

### 45. Director, Chemistry Leads and red team jointly conduct the Month 18 (2028-04-14) gate review. Steering Committee meeting includes: (i) presentation of chemistry progress data (cell builds, Wh/kg/Wh/L measurements, cycle-life results, safety scores) vs Month 18 (2028-04-14) gate criteria (≥500 Wh/kg projected, ≥950 Wh/L interim, cycle-life data, ≥120°C thermal runaway onset for finalists); (ii) red-team replication results and any challenges to progress claims; (iii) go/no-go decision per chemistry (continue, deprioritize, or stop); (iv) rebalancing of chemistry-team budgets post-Month 18 (2028-04-14) based on progress. Gate decision is rendered within 3 weeks of meeting start (by end of Month 18 = 2028-04-14). If a chemistry fails, contingency measures (reserve chemistry pre-staging, external synthesis activation) are triggered.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with red team input

**Suggested Timeframe:** Month 18 (2028-04-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 18 (2028-04-14) Gate Review Meeting Minutes (attendance, data presentations, red-team findings, go/no-go decisions per chemistry)
- Chemistry Advancement Decision Memo (which chemistries advance to Month 24-30 = 2028-10-14 to 2029-04-14 phase, which are deprioritized or stopped)
- Post-Gate Financial Rebalancing Decision (budget reallocation among teams based on Month 18 = 2028-04-14 outcomes)
- Risk Escalation (if any chemistry has failed or is at risk, document mitigation actions required)

**Dependencies:**

- Month 18 (2028-04-14) gate-criteria specification locked (Month 3 = 2027-01-14)
- Red-team replication results delivered ≥5 days before gate meeting
- Chemistry progress data compiled and reviewed monthly (Months 6-18 = 2027-04-14 to 2028-04-14)

### 46. Director and Chemistry Leads jointly initiate a focused volumetric-density optimization sprint if early data (by Month 18 = 2028-04-14) suggests a leading chemistry may meet ≥500 Wh/kg but fall short of ≥950 Wh/L interim gate threshold. Sprint activities (Months 18-30 = 2028-04-14 to 2029-04-14) include: (i) thinner separators and reduced electrolyte volume (cell architecture changes); (ii) higher-density cathode or anode materials (materials optimization); (iii) bipolar or anode-free cell format evaluation if compatible with winning chemistry. Sprint goal is to close the volumetric-density gap before the Month 30 (2029-04-14) verification gate. If volumetric density cannot be recovered by Month 30 (2029-04-14), the chemistry may be deprioritized at Month 36 (2029-10-14) gate.

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager, with red team validation

**Suggested Timeframe:** Months 18-30 (2028-04-14 to 2029-04-14) (conditional: only if volumetric gap identified)

**Key Outputs/Deliverables:**

- Volumetric-Density Optimization Sprint Plan (architecture changes, materials alternatives, timeline, resource allocation)
- Monthly Volumetric-Density Progress Report (measured Wh/L vs target, design changes tested, results)
- Volumetric-Density Gate Readiness Report (Month 30 = 2029-04-14: ≥950 Wh/L achieved or not)

**Dependencies:**

- Month 18 (2028-04-14) gate review identifies volumetric-density gap (Month 18 = 2028-04-14)
- Chemistry team has capacity to pursue parallel architecture improvements alongside core pathway work

### 47. Director and Chemistry Leads jointly confirm that the cell-level mass-and-volume model is being updated monthly with actual measured pouch-cell data (Wh/kg, Wh/L, cycle-life, inactive-mass breakdown). Model variance (projected vs measured) is tracked; a Wh/kg or Wh/L mismatch >10% triggers root-cause analysis (e.g., separator thickness thicker than assumed, higher current-collector mass, electrolyte volume overestimate). Mismatch analysis feeds back into model calibration. Cumulative model-to-reality variance report is published by Month 20 (2028-06-14) to confirm model reliability before the Month 30 (2029-04-14) gate.

**Responsible Body/Role:** Data Engineer and Chemistry Leads

**Suggested Timeframe:** Months 6-20 (2027-04-14 to 2028-06-14), ongoing monthly

**Key Outputs/Deliverables:**

- Monthly Cell-Level Model Update (new measured data incorporated, Wh/kg/L projections recalibrated)
- Model-to-Reality Variance Report (projected vs measured, any systematic biases, model adjustment recommendations)
- Mismatch Root-Cause Analysis (if any category exceeds ±10%, identify source and corrective model adjustment)

**Dependencies:**

- Cell-level mass-and-volume model live (Month 4 = 2027-02-14)
- Cell-level Wh/kg and Wh/L measurements available monthly (Month 6 = 2027-04-14 onward)

### 48. Director and Chemistry Leads jointly ensure that synthesis, pilot-line and characterization operations are producing measured cycle-life data (at 80% capacity retention) for all candidates by Month 24 (2028-10-14). Any candidate chemistry showing measured <250 cycles at 80% is flagged as deprioritized unless within one 2-4 month redesign of target (≥300 cycles, proposed). Chemistry team documents redesign actions and provides timeline for recovery. If a chemistry remains <250 cycles by Month 24 (2028-10-14), it is recommended for deprioritization at Month 30 (2029-04-14) gate review.

**Responsible Body/Role:** Chemistry Leads and Characterization Manager

**Suggested Timeframe:** Months 6-24 (2027-04-14 to 2028-10-14), ongoing testing

**Key Outputs/Deliverables:**

- Monthly Cycle-Life Performance Report (measured cycle retention at 80%, trend per chemistry, redesign actions for underperformers)
- Cycle-Life Deprioritization Memo (any chemistry <250 cycles at Month 24 = 2028-10-14, documented, flagged for Month 30 = 2029-04-14 gate review)

**Dependencies:**

- Cell cycling operations producing data (Month 6 = 2027-04-14 onward)
- Cycle-life gate criterion defined as ≥300 cycles at 80% (Month 3 = 2027-01-14)

### 49. Director and Finance Manager jointly develop the T3 release decision package for Scientific Steering Committee approval. T3 (USD 70M) release is conditional on Month 18 (2028-04-14) gate passing (documented go/no-go decision, at least one or two chemistries advancing). Package includes: (i) Month 18 (2028-04-14) gate decision evidence; (ii) T2 spend vs plan (Months 12-24 = 2027-10-14 to 2028-10-14, variance tracking); (iii) updated T3 and T4 spend forecast; (iv) any budget rebalancing needed based on Month 18 (2028-04-14) outcomes. T3 release is approved by Steering Committee and Funder by Month 24 (2028-10-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 22 (2028-08-14), to enable Steering Committee decision by Month 24 (2028-10-14)

**Key Outputs/Deliverables:**

- T3 Release Decision Package (Month 18 = 2028-04-14 gate evidence, T2 spend summary, T3 forecast, Funder authorization)
- T2 Final Spend Report (Months 12-24 = 2027-10-14 to 2028-10-14 cumulative, category breakdown, variance analysis)
- Corrective Action Summary (if T2 spending exceeded plan, documented mitigation actions)

**Dependencies:**

- Month 18 (2028-04-14) gate review completed (Month 18 = 2028-04-14)
- T2 spend tracked and reported through Month 22 (2028-08-14)
- Chemistry progress and risk status available for T3 forecast adjustment

### 50. Director and Chemistry Leads jointly prepare the red-team verification plan for the Month 30 (2029-04-14) third-party verification gate. Plan includes: (i) selection of ≥3 independent replicates per finalist chemistry for third-party measured pouch-cell testing (independent laboratory or university facility with external credibility); (ii) specification of measurement protocol (≥100 mAh nominal capacity, cell-level Wh/kg, Wh/L, cycle-life retention at 80% for ≥300 cycles); (iii) reproducibility criteria (≥3 replicates, 90% of cells within ±10% Wh/kg, ±5% Wh/L, proposed); (iv) measurement certification and data traceability. Third-party testing is contracted or scheduled by Month 26 (2028-12-14) to allow 4-6 week turnaround with results delivered by Month 30 (2029-04-14).

**Responsible Body/Role:** Chemistry Leads and third-party test facility (independent laboratory or university partner)

**Suggested Timeframe:** Month 26-30 (2029-02-14 to 2029-04-14), testing period

**Key Outputs/Deliverables:**

- Third-Party Pouch-Cell Testing Protocol (measurement procedures, capacity, cycle-test conditions, data quality standards)
- Third-Party Laboratory Agreement (facility contracted, measurement scope, confidentiality, data delivery timeline)
- Third-Party Verification Report (measured Wh/kg, Wh/L, cycle-life for ≥3 replicates per finalist, reproducibility summary)

**Dependencies:**

- Month 18 (2028-04-14) gate identifies finalist(s) (Month 18 = 2028-04-14)
- Month 24-26 (2028-10-14 to 2028-12-14) data confirms finalist candidates for third-party verification (Month 24-26 = 2028-10-14 to 2028-12-14)
- Third-party laboratory selected and contracted (Month 12-24 = 2027-10-14 to 2028-10-14)

### 51. Director, Chemistry Leads and red team jointly conduct the Month 30 (2029-04-14) third-party verification gate review. Steering Committee meeting includes: (i) presentation of third-party measured Wh/kg, Wh/L and cycle-life data for finalist chemistry (≥3 replicates); (ii) reproducibility assessment (90% of cells within ±10% tolerance, proposed); (iii) confirmation that finalist meets gate thresholds: ≥500 Wh/kg, ≥950 Wh/L interim, ≥300 cycles at 80%, thermal-runaway onset ≥120°C (proposed); (iv) red-team assessment of data quality and any inconsistencies with prior in-house measurements; (v) go/no-go decision on advancing to Month 36 (2029-10-14) chemistry-selection gate. If third-party data confirms finalist, gate passes and Steering Committee approves release of USD 15M contingency reserve (held through Month 30 = 2029-04-14) for later-stage sprint or pivots if needed. If verification fails, contingency measures (pivot to reserve chemistry or extended redesign) are triggered.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with third-party laboratory and red team input

**Suggested Timeframe:** Month 30 (2029-04-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 30 (2029-04-14) Third-Party Verification Gate Review Meeting Minutes (attendance, third-party data presentation, reproducibility confirmation, go/no-go decision)
- Third-Party Data Acceptance Decision (finalist confirmed or not, reserve activation decision)
- Post-Gate Contingency Reallocation Decision (USD 15M contingency reserve released or held based on gate outcome and remaining risk)

**Dependencies:**

- Third-party verification testing completed (Month 30 = 2029-04-14)
- Third-party laboratory data delivered ≥5 days before gate meeting
- Red-team replication of third-party data or verification of third-party methodology (concurrent with testing)

### 52. Chief EHS Officer and external consultant jointly submit Phase 3 permit application (abuse-test chambers: thermal-runaway, nail-penetration, overcharge testing) to fire authority and TCEQ. Application incorporates Phase 1-2 experience and includes detailed safety protocols for in-house abuse chambers. Target approval is Month 9 (2027-07-14); if permitting slips, abuse testing is outsourced to contracted third-party facility through Month 12-18 (2027-10-14 to 2028-04-14). Phased safety evaluation timeline ensures early thermal-ramp screening (Months 3-6 = 2027-01-14 to 2027-04-14) and contracted abuse tests (Months 6-12 = 2027-04-14 to 2027-10-14) for all candidates, while in-house chambers (if permitted) are operational by Month 18 (2028-04-14) for finalists.

**Responsible Body/Role:** Chief EHS Officer with support from Pilot-Line Manager

**Suggested Timeframe:** Month 6-9 (2027-04-14 to 2027-07-14), submission and approval

**Key Outputs/Deliverables:**

- Phase 3 Permit Application (in-house abuse-chamber scope, safety protocols, regulator engagement)
- Phase 3 Permit Approval or Contingency Plan (approval received or outsourcing agreement executed if permitting slips)
- Phased Safety-Evaluation Schedule (thermal-ramp screening Months 3-6 = 2027-01-14 to 2027-04-14, contracted testing Months 6-12 = 2027-04-14 to 2027-10-14, in-house chambers Months 18+)

**Dependencies:**

- Phase 1-2 permits approved (Months 3, 6 = 2027-01-14, 2027-04-14)
- Chemistry pathways and candidate count finalized
- Third-party abuse-testing vendors pre-identified (Month 3-6 = 2027-01-14 to 2027-04-14)

### 53. Director and Chemistry Leads jointly confirm that all three active chemistry pathways (and reserve if pre-staged) have detailed contingency pivot plans in place by Month 24 (2028-10-14). Contingency plans for each chemistry specify: (i) precursor suppliers (primary and backup vendors, qualification status); (ii) pilot-line equipment requirements (special drying, inert atmosphere, pressure management, etc.); (iii) process-control parameters and sensitivity analysis; (iv) staff training and cross-team familiarity. If a leading chemistry fails between Months 18-30 (2028-04-14 to 2029-04-14), a pivot to reserve chemistry can be executed within 4-6 weeks instead of 6-10 months.

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager

**Suggested Timeframe:** Month 12-24 (2027-10-14 to 2028-10-14), documentation and cross-training

**Key Outputs/Deliverables:**

- Contingency Pivot Plan per Chemistry Pathway (precursor sourcing, equipment specs, process parameters, staff cross-training schedule)
- Supplier Qualification Summary (backup vendors identified and qualified, lead times confirmed, cost estimates)
- Staff Cross-Training Schedule (20-30% of synthesis and pilot-line team trained on each pathway by Month 24 = 2028-10-14)

**Dependencies:**

- Chemistry pathways and compositions finalized (Month 6 = 2027-04-14)
- Precursor supply-chain established (Month 6-9 = 2027-04-14 to 2027-07-14)
- Pilot-line operations stable (Month 9-12 = 2027-07-14 to 2027-10-14)

### 54. Director and Finance Manager jointly track T3 spend (Months 24-36 = 2028-10-14 to 2029-10-14) monthly, comparing actual to plan. T3 budget is USD 70M (~USD 7M/month); if monthly spend exceeds ±15% of plan, corrective action is proposed by Director or Finance Manager within 5 days. End-of-T3 (Month 36 = 2029-10-14) financial review confirms total T3 spend, remaining reserves and T4 (USD 90M) release readiness.

**Responsible Body/Role:** Finance Manager

**Suggested Timeframe:** Months 24-36 (2028-10-14 to 2029-10-14), monthly tracking

**Key Outputs/Deliverables:**

- Monthly T3 Spend Report (cumulative spend by cost center, variance analysis, corrective actions if needed)
- T3 Final Financial Review (Month 36 = 2029-10-14: cumulative T3 spend, category breakdown, reserve balance)

**Dependencies:**

- Monthly financial tracking and reporting operational (Month 3 = 2027-01-14 onward)
- Chemistry and operational spend being incurred

### 55. Director and red team jointly prepare the red-team verification plan for the Month 36 (2029-10-14) chemistry-selection gate. This is the culminating gate decision. Plan includes: (i) re-verification of Month 30 (2029-04-14) third-party data if updated cells are produced (Months 30-36 = 2029-04-14 to 2029-10-14); (ii) final cycle-life confirmation (≥300 cycles at 80% measured, no degradation below threshold); (iii) final safety confirmation (thermal-runaway onset ≥120°C, reversible after overcharge); (iv) final Wh/kg and Wh/L confirmation (≥500 Wh/kg, ≥1000 Wh/L measured, not interim threshold). Red team delivers final gate-readiness memo by Week 1 of Month 36 (2029-10-14).

**Responsible Body/Role:** Independent Red Team

**Suggested Timeframe:** Month 35-36 (2029-09-14 to 2029-10-14), verification sprint

**Key Outputs/Deliverables:**

- Month 36 (2029-10-14) Final Verification Plan (re-test protocol if needed, final measurements, gate-readiness memo)
- Final Red-Team Gate Readiness Memo (pass/fail on all Month 36 = 2029-10-14 gate criteria, recommendation on chemistry finalist selection)

**Dependencies:**

- Month 30 (2029-04-14) third-party verification completed (Month 30 = 2029-04-14)
- Month 30-36 (2029-04-14 to 2029-10-14) data (updated cell measurements, cycle-life retention, safety scores) available

### 56. Director, Chemistry Leads and red team jointly conduct the Month 36 (2029-10-14) chemistry-selection gate review. Steering Committee meeting concludes the staged tournament and selects one finalist chemistry (from three active pathways) for scaled optimization and final proof-of-concept (Months 36-72 = 2029-10-14 to 2032-10-14). Gate decision includes: (i) confirmation of finalist meeting all Month 36 (2029-10-14) thresholds (≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles, ≥120°C thermal onset); (ii) deprioritization or termination of non-finalist chemistries; (iii) reallocation of budgets to support finalist optimization and scale-up; (iv) decision to release T4 (USD 90M) for Months 36-84 (2029-10-14 to 2033-10-14) work; (v) risk management and mitigation plan for final-stage proof-of-concept and technology transfer.

**Responsible Body/Role:** Scientific Steering Committee (Director, Chemistry Leads, external advisor, Funder rep) with red team input

**Suggested Timeframe:** Month 36 (2029-10-14), over 3 weeks

**Key Outputs/Deliverables:**

- Month 36 (2029-10-14) Chemistry-Selection Gate Review Meeting Minutes (attendance, finalist data, selection decision, budget reallocation)
- Chemistry Finalist Selection Memo (official designation of winning chemistry, rationale, deprioritization of alternatives)
- T4 Release Authorization (USD 90M approved for Months 36-84 = 2029-10-14 to 2033-10-14, conditional on finalist confirmation)

**Dependencies:**

- Month 30 (2029-04-14) third-party verification passed (Month 30 = 2029-04-14)
- Red-team final verification completed (Month 35-36 = 2029-09-14 to 2029-10-14)
- Chemistry Leads ready to brief finalist selection rationale

### 57. Director and Finance Manager jointly develop the T4 release decision package for Scientific Steering Committee and Funder approval. T4 (USD 90M, Months 36-84 = 2029-10-14 to 2033-10-14) is released conditional on Month 36 (2029-10-14) chemistry-selection gate passing. Package includes: (i) confirmed Month 36 (2029-10-14) gate decision (finalist chemistry selected); (ii) T3 final spend report (Months 24-36 = 2028-10-14 to 2029-10-14 cumulative); (iii) revised T4 spend forecast and burn-rate profile for Months 36-84 (2029-10-14 to 2033-10-14); (iv) reserve status and contingency allocation for final-stage work; (v) technology-transfer and licensing planning (Months 72-84 = 2032-10-14 to 2033-10-14). T4 release is approved by Steering Committee and Funder by Month 36-37 (2029-10-14 to 2029-11-14).

**Responsible Body/Role:** Finance Manager with support from Director

**Suggested Timeframe:** Month 36-37 (2029-10-14 to 2029-11-14), within 1-2 weeks of gate decision

**Key Outputs/Deliverables:**

- T4 Release Decision Package (Month 36 = 2029-10-14 gate confirmation, T3 final spend, T4 forecast, Funder authorization)
- T3 Final Spend Report (Months 24-36 = 2028-10-14 to 2029-10-14 cumulative, category breakdown, variance summary)
- T4 Spend Forecast and Burn-Rate Profile (Months 36-84 = 2029-10-14 to 2033-10-14 budget projection, annual spend profile, cost-center allocation)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate completed and decision documented
- T3 spend fully accounted for

### 58. Director and Chemistry Lead (finalist) jointly transition the programme to final-stage optimization and scale-up (Months 36-72 = 2029-10-14 to 2032-10-14). Phases include: (i) Months 36-48 (2029-10-14 to 2030-10-14): cell optimization (interface engineering, electrolyte refinement, cycle-life and safety improvements); (ii) Months 48-60 (2030-10-14 to 2031-10-14): pilot-line scale-up (reproducibility demonstration, batch-to-batch consistency, yield optimization to 90% within ±10% tolerance, proposed); (iii) Months 60-72 (2031-10-14 to 2032-10-14): final verification and third-party certification (comprehensive pouch cells, abuse testing, licensing readiness). Chemistry and Discovery Leadership Team continues monthly reporting to Steering Committee; Steering Committee meetings transition to quarterly (Months 36+).

**Responsible Body/Role:** Chemistry Leads and Pilot-Line Manager, with ongoing Steering Committee oversight

**Suggested Timeframe:** Months 36-72 (2029-10-14 to 2032-10-14), staged optimization and scale-up

**Key Outputs/Deliverables:**

- Final-Stage Chemistry Optimization Plan (interface and electrolyte refinement targets, timeline, resource allocation)
- Pilot-Line Scale-Up Plan (batch-to-batch reproducibility targets, yield optimization schedule, automation decisions)
- Final Verification and Certification Plan (third-party pouch-cell testing, abuse test certification, licensing-ready criteria)
- Quarterly Progress Reports (cell performance vs targets, scale-up milestones, safety and cycle-life confirmations)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate passed
- T4 funding released (Month 36-37 = 2029-10-14 to 2029-11-14)

### 59. Director and external technical advisor jointly develop the IP strategy implementation and licensing framework by Month 24 (2028-10-14). Activities include: (i) filing of provisional and utility patents on key compositions, electrolyte architectures and cell formats as they are finalized; (ii) publication strategy for non-core materials work in peer-reviewed journals (after 6-month review window); (iii) freedom-to-operate (FTO) analysis on finalist chemistry to confirm no blocking patents; (iv) licensing framework defining: exclusive or non-exclusive licensing options, royalty structures, manufacturing obligations and geographic scope; (v) preliminary discussions with prospective licensees (established battery manufacturers, automotive OEMs, energy-storage firms) to gauge interest and gather feedback on licensing terms.

**Responsible Body/Role:** Programme Director with Legal Counsel and external technical advisor

**Suggested Timeframe:** Month 12-24 (2027-10-14 to 2028-10-14), framework finalized by Month 24 (2028-10-14)

**Key Outputs/Deliverables:**

- Patent Filing Summary (provisional and utility patents filed to date, claims scope, priority dates)
- IP Strategy Implementation Report (filing timeline, publication review process, FTO analysis)
- Licensing Framework Document (exclusive/non-exclusive options, royalty structures, manufacturing terms, licensee target profiles)
- Prospective Licensee Engagement Memo (preliminary discussions, feedback on licensing terms, timeline for formal partnerships)

**Dependencies:**

- IP strategy finalized (Month 2 = 2026-12-14)
- Chemistry and cell-design innovations emerging (Months 6-24 = 2027-04-14 to 2028-10-14)

### 60. Director and Finance Manager jointly establish a project-wide governance dashboard for Scientific Steering Committee monitoring. Dashboard tracks: (i) technical metrics (Wh/kg, Wh/L, cycle-life, thermal runaway onset, cell-build yield, characterization queue time); (ii) financial metrics (cumulative spend, burn rate, reserve balance, partner cost-sharing); (iii) schedule metrics (gate completion dates, major milestone dates, personnel attrition rate); (iv) risk register status (number of open risks, escalations in month). Dashboard is updated monthly and reviewed by Steering Committee quarterly (or monthly in Months 0-12 = 2026-10-14 to 2027-10-14).

**Responsible Body/Role:** Data Engineer and Finance Manager

**Suggested Timeframe:** Month 3 (2027-01-14), operational by end of month

**Key Outputs/Deliverables:**

- Project Governance Dashboard v1.0 (technical, financial, schedule and risk metrics, colour-coded status)
- Dashboard Monthly Update (first Thursday of each month, populated with latest data)
- Steering Committee Dashboard Review (included in quarterly meeting agenda, summary of trends and escalations)

**Dependencies:**

- Financial-tracking dashboard established (Month 3 = 2027-01-14)
- Chemistry work producing measurable data (Month 6 = 2027-04-14 onward)
- Risk register initialized (Month 1 = 2026-11-14)

### 61. Director and Chemistry Lead (finalist) jointly commence the technology-transfer planning phase by Month 60 (2031-10-14). Planning activities include: (i) process documentation and scaled procedure development (from lab cell to pilot scale); (ii) manufacturing feasibility studies (cost modeling, equipment requirements, facility footprint for commercial production); (iii) intellectual-property handoff preparation (patent assignments or licensing agreements); (iv) formal engagement with prospective licensee partners (negotiations on exclusive/non-exclusive terms, royalty rates, manufacturing obligations); (v) knowledge-transfer plan (staff training and deployment to licensee site if applicable). Technology transfer culminates by Month 84 (2033-10-14) delivery date.

**Responsible Body/Role:** Programme Director and Chemistry Lead (finalist), with support from Finance Manager and Legal Counsel

**Suggested Timeframe:** Months 60-84 (2031-10-14 to 2033-10-14)

**Key Outputs/Deliverables:**

- Technology-Transfer Plan v1.0 (process documentation, manufacturing feasibility, IP handoff, partner engagement timeline)
- Process Scale-Up Documentation (lab-to-pilot procedures, process-control parameters, quality-assurance protocols)
- Manufacturing Feasibility Study (cost modeling, equipment list, facility requirements, timeline to production readiness)
- Licensee Partnership Agreement (exclusive or non-exclusive, royalty structure, manufacturing obligations, territorial scope)
- Knowledge-Transfer Plan (staff secondment, training schedule, documentation handoff)

**Dependencies:**

- Month 36 (2029-10-14) chemistry-selection gate completed (Month 36 = 2029-10-14)
- Finalist chemistry optimized and scaled (Months 36-60 = 2029-10-14 to 2031-10-14)
- Final verification data available (Months 60-72 = 2031-10-14 to 2032-10-14)
- Prospective licensees pre-identified (Month 12-24 = 2027-10-14 to 2028-10-14)

### 62. Director and red team jointly conduct a final pre-delivery verification of the winner chemistry against all stated programme goals: (i) ≥500 Wh/kg at cell level, third-party measured; (ii) ≥1000 Wh/L at cell level, third-party measured; (iii) ≥300 cycles at 80% capacity retention, third-party measured; (iv) thermal-runaway onset ≥120°C, abuse-tested; (v) ≥90% of cells reproducible within ±10% Wh/kg, ±5% Wh/L (proposed). Red team delivers final certification memo by Month 72 (2032-10-14) confirming goals are met. Programme conclusion and knowledge transfer proceed if goals are met; if any goal is not fully met, Steering Committee decides descope or extended optimization through Month 84 (2033-10-14).

**Responsible Body/Role:** Independent Red Team with Programme Director oversight

**Suggested Timeframe:** Month 72 (2032-10-14)

**Key Outputs/Deliverables:**

- Final Programme Goal Certification Report (verification of ≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles, ≥120°C thermal onset, reproducibility ≥90% within tolerances)
- Third-Party Test Reports Summary (reference to external lab data and certifications supporting each goal)
- Red Team Final Certification Memo (goals met or not met, any caveats or conditional certifications)

**Dependencies:**

- Month 60-72 (2031-10-14 to 2032-10-14) final optimization and verification completed (Months 60-72 = 2031-10-14 to 2032-10-14)
- Third-party verification and certification testing conducted (Months 60-72 = 2031-10-14 to 2032-10-14)
- All key data collected and red-team validation completed

### 63. Programme Director issues a final project close-out memo to the Scientific Steering Committee, Funder and stakeholders. Memo documents: (i) achievement of primary and secondary goals (Wh/kg, Wh/L, cycle-life, safety); (ii) final financial summary (total spend vs USD 300M cap, reserve utilization); (iii) lessons learned and recommendations for future battery R&D; (iv) IP and patent estate delivered; (v) technology-transfer status and licensee partnerships; (vi) programme team recognition and closure of employment relationships. Closing memo is issued by Month 84 (2033-10-14) and archived as the official programme record.

**Responsible Body/Role:** Programme Director

**Suggested Timeframe:** Month 84 (2033-10-14), end of programme

**Key Outputs/Deliverables:**

- Final Project Close-Out Memo (achievement summary, financial close-out, lessons learned, IP and licensing status)
- Programme Final Report (comprehensive summary of 84-month effort, outcomes, recommendations)
- Archive Package (all governance documents, gate reviews, financial reports, technical data, IP filings, team records)

**Dependencies:**

- All programme activities concluded by Month 84 (2033-10-14)
- Technology transfer to licensee partner in progress or complete
- Final financial reconciliation completed