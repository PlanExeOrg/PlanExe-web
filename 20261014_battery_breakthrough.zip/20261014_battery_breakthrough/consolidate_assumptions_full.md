# Purpose

**Purpose:** business

**Purpose Detailed:** Applied research and development programme to invent a breakthrough high-energy-density rechargeable battery technology (strategic R&D / technology development). The aim is technical invention and demonstration rather than becoming a market-dominant industrial player. Funding of USD 300 M over 7 years, with a site chosen near Tesla in Austin for talent and ecosystem access.

**Topic:** Invention of a next-generation rechargeable battery targeting at least 500 Wh/kg gravimetric and 1000 Wh/L volumetric energy density, with a USD 300 M budget over 7 years, located near Tesla in Austin, Texas

# Domain

**Primary domain:** Battery Electrochemistry

**Secondary domains:** Materials Science, Battery Cell Engineering, Research Program Management

**Rationale:** Battery Electrochemistry is the only outcome-role candidate and owns the success criterion of inventing a ≥500 Wh/kg chemistry. Materials Science, Cell Engineering, Solid-State Ionics and Research Program Management are subordinate methods; Safety and IP are constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Battery Electrochemistry | 5 | 5 | outcome | Inventing a ≥500 Wh/kg rechargeable chemistry is the core success criterion. |
| Materials Science | 4 | 4 | method | Novel electrode, electrolyte and interface materials discovery underpins energy density gains. |
| Battery Cell Engineering | 4 | 4 | method | Prototype cell design, fabrication and testing must demonstrate Wh/kg and Wh/L targets. |
| Battery Safety Engineering | 4 | 4 | constraint | High-energy-density cells face thermal runaway and abuse-tolerance certification constraints. |
| Solid-State Ionics | 4 | 4 | method | Ion transport in novel electrolytes and interfaces limits achieving 500 Wh/kg cells. |
| Research Program Management | 4 | 3 | method | Seven-year, USD 300 M R&D programme needs stage-gated technology development governance. |
| Battery Manufacturing Engineering | 3 | 4 | method | Pilot-line fabrication and scale-up needed to demonstrate cells reproducibly. |
| Computational Materials Discovery | 3 | 4 | method | Simulation and machine learning accelerate screening of high-energy electrode and electrolyte chemistries. |
| Intellectual Property Strategy | 2 | 3 | constraint | Invention-focused programme needs patent protection and freedom-to-operate analysis. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is to invent a next-generation rechargeable battery (target of at least 500 Wh/kg and 1000 Wh/L) with a USD 300 M budget over 7 years, sited near Tesla in Austin, Texas. This is unequivocally physical. It requires a physical R&D campus in the Austin area (site selection, lease or build-out, cleanroom and dry-room facilities). Battery invention depends on wet-chemistry and materials synthesis laboratories, procurement of raw materials and precursors, and electrode and cell fabrication on pilot-line equipment. Prototype cells must be physically assembled, cycled, and characterized in the lab, and tested under abuse conditions (thermal runaway, nail penetration, overcharge) in safety test chambers. Hiring and retaining scientists and engineers near Tesla's Austin ecosystem, equipment procurement, and third-party certification testing all require a physical presence. Computational materials discovery supports the effort but cannot replace experimental synthesis, cell building, and measurement of Wh/kg and Wh/L on real hardware. No part of the plan can be completed exclusively online, and the plan explicitly specifies a physical location, so it is classified as physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Within commuting distance of Tesla Gigafactory Texas, east Austin, for talent and supplier access
- Zoning permitting light industrial/lab use with wet chemistry, dry rooms and reactive metals
- Space for dry room, pilot pouch-cell line, abuse-test chambers and characterization labs (estimate 5,000-10,000 m2)
- Adequate power, ventilation, hazardous-waste handling and fire-authority access
- Proximity to University of Texas at Austin for partnerships and recruitment
- Close to Austin-Bergstrom airport and highways for equipment and materials logistics
- Ability to start lease or fit-out immediately (Month 0 = 2026-10-14)

## Location 1
USA, Texas

Northeast Travis County, Austin (Harris Branch/Manor Road corridor)

Light-industrial or flex R&D parcels near SH-130 and Tesla Gigafactory Texas, Austin, TX

**Rationale**: Closest option to the Tesla site named in the plan. Industrial zoning, large buildable lots, and easy highway access suit dry rooms and hazardous-materials handling. Talent competition and IP contamination exposure are highest here.

## Location 2
USA, Texas

Southeast Austin near Austin-Bergstrom International Airport

Industrial/R&D parks along SH-71 and Burleson Road, Austin, TX

**Rationale**: Existing light-industrial and lab-capable buildings reduce fit-out time. Airport access eases logistics of precursors and equipment. About 25-35 minutes from Tesla and central to the Austin technical workforce.

## Location 3
USA, Texas

North Austin, UT Pickle Research Campus area

Research/industrial sites near Pickle Research Campus, Burnet Road and Braker Lane, Austin, TX

**Rationale**: Adjacent to University of Texas research facilities, supporting partnerships, shared characterization access and graduate recruitment. Established lab-oriented zoning. Longer distance from Tesla reduces direct poaching pressure while remaining within the Austin ecosystem.

## Location 4
USA, Texas

Pflugerville/Hutto, Austin metro

Industrial parks in Pflugerville or Hutto, TX

**Rationale**: Lower land and lease costs and room for expansion, hazardous-use permitting often simpler. Within roughly 20-30 minutes of the Tesla site and the Austin labor pool.

## Location Summary
The plan specifies a site near Tesla in Austin, Texas. Four candidate areas are offered: northeast Austin beside Tesla, southeast Austin near the airport, north Austin near UT's Pickle campus, and Pflugerville/Hutto. They trade off proximity to Tesla, fit-out speed, university access, cost and hazardous-materials permitting.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting. User-specified budget constraint of USD 300 M over 7 years. All major capital equipment, facility lease, staff payroll and third-party testing will be denominated in USD. Simplifies accounting and aligns with US-based operations in Austin, Texas.
- **EUR:** Secondary currency for potential international procurement and partnerships. Equipment suppliers for specialized characterization instruments, pilot-line components and advanced materials often quote in EUR from European manufacturers. May be needed for university and national-laboratory partner arrangements outside the US.

**Primary currency:** USD

**Currency strategy:** All budgeting, financial reporting and burn-rate tracking will be conducted in USD, the user-specified primary constraint. Equipment and material procurement will be negotiated and paid primarily in USD; where EUR-denominated suppliers are required (e.g., specialized characterization instruments from European vendors), individual purchase orders will use spot exchange rates or fixed-price contracts to avoid currency volatility. International partnerships with universities and national laboratories will be structured to minimize multi-currency complexity; cost-sharing agreements will be denominated in USD with partner contributions valued at agreed rates. No hedging strategy is required given the domestic US focus and seven-year horizon; budget reserves will account for modest currency fluctuation on European capital purchases.

# Identify Risks


## Risk 1 - Technical - Chemistry Pathway
The staged tournament across three to four chemistries (lithium-sulfur, anode-free solid-state, conversion cathodes) may fail to identify a viable path to 500 Wh/kg and 1000 Wh/L by the mid-programme gate (Month 36 = 2029-10-14). Material-level gains often collapse at cell level once packaging overhead is included. If all three chemistries encounter unforeseen cycle-life, dendrite, or volumetric penalties, the programme faces a costly pivot or admission of technical infeasibility.

**Impact:** A failed chemistry tournament at Month 36 (2029-10-14) forces a 6–12 month redesign or chemistry restart, consuming USD 20–40 M in sunk capital and delaying cell-level proof by 12–24 months. The programme may reach Month 48–60 (2030-10-14 to 2031-10-14) before identifying a viable route, leaving insufficient time to mature it to demonstrable cell level.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish clear go/no-go criteria for each chemistry by Month 18 (2028-04-14), including quantified cycle-life (proposed: ≥500 cycles), interfacial resistance targets, and a system-level mass-and-volume model that forces early accounting of packaging penalties. Run quarterly reviews with external technical advisors to validate progress; build a contingency chemistry (fourth candidate) held in reserve, with option to accelerate it if two leading candidates fail by Month 24 (2028-10-14).

## Risk 2 - Technical - Cell-Level Proof Standard
The dual-track metric (material-level targets back-calculated from a cell model) may not translate into real pouch-cell verification early enough. If full pouch cells are not independently tested until Month 48 (2030-10-14) or later, inactive-mass surprises (current collectors, separators, pressure hardware) could reveal that the chemistry cannot meet 1000 Wh/L at cell level, despite material-level promise.

**Impact:** Late discovery of packaging penalties could consume USD 10–20 M in rework or force acceptance of a cell below target. A one-cycle cell meeting the letter of the goal but with <100 cycle life would satisfy the stated success criterion but not a usable battery, delaying real validation to Month 60+.

**Likelihood:** Medium

**Severity:** High

**Action:** Require independent third-party pouch-cell verification of at least one chemistry finalist by Month 30 (2029-04-14), before the mid-gate decision. Define minimum cycle life (proposed: ≥300 cycles at 80% capacity retention) as a hard pass/fail threshold from Month 24 (2028-10-14) onward. Use a dedicated engineering team to build a live mass-and-volume model updated each quarter; publish mismatch between predicted and actual Wh/kg by Month 20 (2028-06-14).

## Risk 3 - Operational - Pilot Line and Dry Room
Uncertainty about whether to build, lease, or modularize the dry room and pouch-cell line creates schedule and capital risk. If the decision is deferred, early months may lack the fabrication capacity to build pouch cells for proof-of-concept. A leased external line adds queue time and confidentiality exposure for unpublished materials. A new build risks 6–12 month commissioning delays and capital lock-in before chemistry is proven.

**Impact:** A delayed or underspecified pilot line could defer first pouch-cell builds to Month 8–12 (2027-06-14 to 2027-10-14), compressing the discovery loop and proof timeline. A new in-house build could consume USD 30–50 M and 12 months of lead time, leaving only USD 250–270 M for five years of operation. Leasing external capacity adds 4–8 week queues, slowing iteration to one build per month instead of one per week.

**Likelihood:** High

**Severity:** High

**Action:** By Month 1 (2026-11-14), decide on a modular, containerized dry-room and pouch-cell line (leased capacity with option to own) that can be deployed at the chosen Austin site by Month 3 (2027-01-14) and scaled or relocated as needed. Negotiate a pilot-line agreement with a university or national-laboratory partner by Month 2 (2026-12-14) to provide backup pouch-cell fabrication at cost during commissioning. Size the line for 50–100 pouch-cell builds per month to support the discovery loop; reserve USD 15–20 M and 6-month lead time in the budget.

## Risk 4 - Operational - Location and Permitting
Site selection and permitting for hazardous materials (reactive metals, flammable solvents, abuse-test chambers) may extend beyond Month 3 (2027-01-14). Local fire authority and environmental-health approvals for a new dry room and synthesis lab in the Austin area can take 4–8 months. If permitting is conservative, reactive chemistries (lithium metal, sulfides, halide electrolytes) may be excluded from on-site work, forcing outsourcing of key synthesis steps and slowing iteration.

**Impact:** A 6–8 month permitting delay would push operational start to Month 6–8 (2027-04-14 to 2027-06-14), compressing the 84-month programme to 76–78 months of effective work. Restrictive permit terms could exclude lithium-metal synthesis from the site, requiring all lithium-metal candidate work to be outsourced at cost (USD 5–10 M/year) and with 4–6 week turnarounds. Conservative zoning could also block planned abuse-test facility build-out.

**Likelihood:** High

**Severity:** Medium

**Action:** Initiate site selection, lease negotiation and permitting in Month 0 (2026-10-14), targeting site occupancy by Month 2 (2026-12-14). Engage the Austin fire authority and Texas environmental regulators in Month 0 (2026-10-14) as collaborative partners; propose a phased permit approach that allows pilot-phase dry-room operation by Month 3 (2027-01-14) and full synthesis and abuse-testing capability by Month 9 (2027-07-14). Pre-negotiate with licensed external synthesis facilities (e.g., commercial contract labs) to handle any on-site-prohibited chemistries at cost-plus terms, so synthesis is not a bottleneck if local permitting is tight.

## Risk 5 - Financial - Budget and Burn Rate
A USD 300 M budget over 7 years (approximately USD 43 M/year) must cover staff payroll (estimated 80–120 FTE at USD 2–4 M/year total), facility lease and utilities (USD 2–5 M/year), capital equipment (dry room, characterization instruments, pilot line: USD 40–60 M upfront), third-party testing and partnerships (USD 3–5 M/year), and contingency. Early capital commitments (pilot line, dry room, initial hiring) could exceed USD 60–80 M in Years 1–2, leaving insufficient working capital for later experiments, pivots or partnership cost-sharing.

**Impact:** Front-loaded capital spending could leave only USD 150–170 M for Years 3–7 (USD 30–34 M/year), throttling iteration speed and forcing staff reductions in later years when chemistry matures and iteration accelerates. A 20% cost overrun in pilot-line or facility build (USD 10–15 M) would compress the remaining budget by 3–5%. If partnerships require cost-sharing (USD 5–10 M/year), the programme may run short by Year 5–6.

**Likelihood:** High

**Severity:** Medium

**Action:** Structure funding release in tranches linked to demonstrated milestones: Month 0–12 (2026-10-14 to 2027-10-14) (USD 60 M: facility, core team, equipment orders), Month 12–24 (2027-10-14 to 2028-10-14) (USD 80 M: pilot-line commissioning, first chemistry gate), Month 24–36 (2028-10-14 to 2029-10-14) (USD 70 M: mid-programme decision and winning chemistry scale-up), Month 36–84 (2029-10-14 to 2033-10-14) (USD 90 M: proof and optimization). Reserve USD 15–20 M (5–7% contingency) for pivots, unexpected chemistry redirection or third-party testing. Negotiate matching grants or co-funding with university and national-laboratory partners (proposed: 10–15% of partnership costs) by Month 6 (2027-04-14) to offset variable costs.

## Risk 6 - Operational - Talent and Recruitment
Recruiting and retaining 80–120 specialized scientists and engineers in battery electrochemistry, materials science, and manufacturing engineering in the Austin area faces stiff competition from Tesla and other automotive/energy firms. Offering salaries and equity packages competitive with nearby industrial employers while remaining within a fixed USD 300 M budget is difficult. High turnover (proposed risk: >15% annual attrition) would force continuous re-hiring and knowledge loss, especially if early key personnel depart mid-programme.

**Impact:** If attrition reaches 20% annually, the programme would need to hire and onboard 16–24 replacements per year, consuming 10–15% of operating budget in recruitment and training. Loss of a key chemistry or characterization lead at Month 12–24 (2027-10-14 to 2028-10-14) could set the programme back 3–6 months as knowledge is re-built. Inability to match competitor salaries could force hiring below the target expertise level, reducing discovery speed by 20–30%.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a recruitment strategy by Month 1 (2026-11-14) that includes partnership with University of Texas at Austin for graduate-student pipelines (reduces salary burden), and negotiates long-term retention agreements (3–5 year commitments with clawback terms) for key leads. Offer sign-on bonuses and stock-option-like arrangements (even in a non-commercial entity) to compete with Tesla. Structure the team to include 20–30% postdoctoral and graduate-student roles to lower average cost. Build a 'stay' plan: by Month 6 (2027-04-14), publish early findings in peer-reviewed journals to enhance researcher prestige and reduce poaching risk.

## Risk 7 - Regulatory & Permitting - Hazardous Materials
Synthesis of reactive precursors, handling of lithium metal, flammable organic electrolytes, and operation of abuse-test chambers (thermal runaway, nail penetration, overcharge) face overlapping federal (EPA, DOT, OSHA), state (Texas Commission on Environmental Quality) and local (Austin Fire Authority, Travis County) permitting and safety rules. Failure to secure or maintain permits could halt operations. Changes in environmental or safety regulations during the 7-year period could force costly retroactive upgrades.

**Impact:** A permitting delay or rejection could stop synthesis, cell assembly or abuse testing for 2–6 months during Year 1–2, compressing the early chemistry evaluation phase. Retrofitting the facility to meet new EHS standards (e.g., stricter lithium-ion cell storage rules, VOC limits) could cost USD 2–5 M and require 3–4 month downtime. A serious incident (e.g., electrolyte fire, chemical release) could trigger investigative closure and USD 1–3 M in remediation, plus reputational and insurance cost.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage Texas environmental and Austin fire authorities in Month 0 (2026-10-14) as collaborative partners; establish a standing EHS advisory committee including external regulatory consultants. Develop a tiered permitting strategy that allows pilot-phase dry-room operation by Month 3 (2027-01-14) (low hazard) and defers high-hazard synthesis and abuse testing to Month 6–9 (2027-04-14 to 2027-07-14) once full permits are in place. Maintain a USD 3–5 M contingency reserve for permitting delays or retroactive upgrades. Document all processes, materials and quantities in compliance with federal and state databases; conduct internal audits quarterly to catch drift early.

## Risk 8 - Technical - Characterization and Forensics
The split in-house/partner discovery structure depends on reliable access to advanced operando and post-mortem characterization (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy) at universities and national laboratories. If partner access is delayed or unavailable, failed cells cannot be analyzed quickly, slowing the design-build-test loop. In-house capability is costly (USD 5–10 M for core instruments) and risks underutilization if it duplicates partner capabilities.

**Impact:** A 4–8 week queue at a partner characterization facility would slow the discovery loop from 1–2 weeks (in-house) to 6–10 weeks, reducing the number of testable hypotheses per year by 50–75%. If a critical partner facility becomes unavailable (e.g., closure, staff turnover, competing priority), alternative characterization could cost USD 50–100 K per failed cell at commercial labs, quickly exhausting the characterization budget. A chemistry with a subtle failure mechanism (interface kinetics, electrolyte decomposition) might not be detected without rapid operando analysis, leading to months of wasted builds.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Negotiate formal standing agreements with at least two university or national-laboratory characterization facilities by Month 3 (2027-01-14), with guaranteed turnaround (proposed: ≤3 weeks) and priority scheduling for failed-cell analysis. Invest in one core in-house post-mortem capability (scanning electron microscope or X-ray diffraction: USD 2–3 M) by Month 6 (2027-04-14) for rapid triage of failed cells; outsource deeper operando work. Establish a forensics protocol: every failed cell receives a standardized autopsy within one week of failure, with a structured root-cause report that feeds directly into the next design iteration. Budget USD 2–3 M/year for commercial characterization services as a backstop.

## Risk 9 - Technical - Abuse Tolerance and Safety
High-energy lithium-rich cells typically exhibit worsen thermal runaway and short-circuit safety margins compared to conventional cells. Early safety evaluation is needed to avoid spending months on a chemistry that later fails abuse tests (thermal runaway, nail penetration, overcharge). Building an in-house abuse-testing facility (calorimetry, nail-penetration chambers, overcharge test stations) requires specialized equipment (USD 3–5 M), permits, and trained staff. Outsourcing abuse testing to external labs adds queue time and cost (USD 20–30 K per full abuse test) and may delay discovery.

**Impact:** If abuse testing is deferred until Year 2–3, a chemistry that is discovered in Month 18 (2028-04-14) to have a thermal runaway onset below 100°C would waste 12–18 months of development and USD 10–20 M in prior material, synthesis and cell work. Discovering safety issues late could force the programme to abandon a leading chemistry candidate at Month 36 mid-gate, leaving only one or two alternatives with insufficient time for maturation. Conversely, early in-house abuse testing requires USD 3–5 M capital and 4–6 month facility build, competing with other capital priorities.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a phased safety-evaluation strategy: Month 3–6 (2027-01-14 to 2027-04-14), coin-cell and small pouch-cell thermal-ramp tests (inexpensive, in-house or outsourced) to rank chemistries for safety. Month 6–12 (2027-04-14 to 2027-10-14), contract or lease access to an established abuse-testing facility for nail-penetration and overcharge on selected candidates. Month 12 (2027-10-14) onward, if a chemistry passes early gates, build or acquire dedicated in-house abuse chambers (USD 3–5 M) for rapid iteration on safety-critical designs. Require every chemistry finalist to pass defined safety thresholds (proposed: thermal runaway onset ≥120°C, reversible after overcharge) before advancing to the mid-gate decision.

## Risk 10 - Strategic - IP and Collaboration Risk
The Pragmatic Foundation strategy emphasizes open partnership with universities and national laboratories, sharing pre-competitive findings and patenting only the final integrated cell architecture. This approach aligns with the non-commercial invention goal but risks a weak patent position if the final integrated design draws heavily on openly published partner work. Also, employees hired from Tesla or nearby firms may carry implicit knowledge of competing work, creating IP-contamination exposure despite clean-room protocols.

**Impact:** A patent estate limited to the final integrated design (rather than enabling compositions, processes and cell formats) could reduce licensing value by 30–50% and invite competitors to design around the claims. If an employee departing Tesla brings proprietary knowledge (intentionally or unconsciously) and contaminates the design, Tesla could claim prior art or misappropriation, jeopardizing patent validity. Conversely, strict clean-room protocols and limited IP sharing could deter university and national-laboratory partners, reducing cost-sharing and characterization access.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a clear IP strategy by Month 2 (2026-12-14): file provisional patents on key compositions, electrolyte architectures and cell formats as they emerge (not just the final integration), while publishing non-core materials work in peer-reviewed journals to establish priority and academic prestige. Implement strict IP-onboarding protocols for hires from Tesla: background checks, signed non-use agreements for competing knowledge, and a 6-month observation period before access to sensitive designs. Structure university and national-laboratory agreements to permit publication of materials and methods after 6-month review windows, reserving claims on final cell architectures and processes for in-house patents.

## Risk 11 - Operational - External Partnership Dependency
The strategy relies heavily on university and national-laboratory partners for characterization, candidate validation and cost-sharing. Partners may have competing priorities, shifting staffing or funding. If a key partner (e.g., Argonne National Lab, UT Austin materials group) deprioritizes the battery work or experiences budget cuts, validation could be delayed or outsourced to commercial labs at much higher cost. No contractual guarantee can fully insulate a research programme from academic schedules.

**Impact:** Loss of a key partner's access to operando X-ray diffraction (a critical diagnostic) at Month 18 (2028-04-14) could force USD 30–50 K per sample at commercial labs, consuming USD 5–10 M/year in characterization budget if samples accumulate. A 6-month partner facility downtime (renovation, staff turnover) could halt characterization and delay the design loop by one chemistry cycle (6–12 months). If cost-sharing partners withdraw (proposed risk: 10–20% loss of matched funding), the programme would need to absorb those costs internally, compressing working capital by USD 5–10 M over the 7-year period.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Negotiate formal long-term agreements (3–5 year) with at least two primary partner institutions by Month 3 (2027-01-14), specifying guaranteed access, turnaround, and upfront cost-sharing commitments (proposed: ≥15% of materials and characterization costs). Identify one backup partner for each critical service (operando diagnostics, computational screening, synthesis validation) so that loss of a primary partner does not halt work. Structure agreements with escape clauses (30–60 day notice) to allow rapid transition to alternative providers. Reserve USD 2–3 M/year as a 'partnership contingency' for unexpected partner cost increases or loss-of-access scenarios.

## Risk 12 - Technical - Materials Supply and Sourcing
Synthesis and testing of advanced battery chemistries depends on a steady supply of specialized precursors: lithium compounds, high-purity metal oxides, fluorinated solvents, salts and other reactive materials. Supply chains for these materials are often long (Asia-based, 8–12 week lead times) and subject to geopolitical disruption, export controls (lithium, cobalt, rare-earth precursors) and price volatility. A critical precursor shortage could halt synthesis for weeks to months.

**Impact:** A 4–8 week delay in receiving a key precursor (e.g., high-purity lithium carbonate, fluorinated electrolyte salt) would halt synthesis and push chemistry validation back by one cycle (6–8 weeks). A sudden 20–30% price increase in a strategic material (lithium salts, high-nickel oxide) could add USD 2–5 M to material costs over the 7-year period, compressing other budget areas. Geopolitical export controls (e.g., US restrictions on Chinese precursor suppliers) could force expensive re-sourcing or certification of new suppliers, adding 2–4 months to each precursor qualification.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-14), establish supplier relationships with at least two qualified vendors for each critical precursor; negotiate annual supply agreements with price-stability clauses (e.g., fixed pricing for ≥80% of annual volume) and 12-week minimum lead times. Maintain a strategic inventory of key long-lead precursors (3–6 month supply) to buffer against disruption; budget USD 1–2 M for precursor inventory carry. Monitor geopolitical and supply-chain risks quarterly; establish a 'precursor contingency team' to identify alternative suppliers or synthetic routes if a primary supplier becomes unavailable. Factor USD 500 K–1 M/year into the contingency reserve for price volatility and emergency re-sourcing.

## Risk 13 - Organizational - Governance and Decision Authority
A complex R&D programme with multiple chemistry pathways, external partners and stage-gate funding decisions needs clear governance: Who decides whether a chemistry advances to the next gate? Who has authority over budget redirection after a failed hypothesis? Ambiguous decision rights create delays, cost overruns and demoralization. The plan mentions an internal red team or verification function in one scenario but does not clarify its role in the chosen Pragmatic Foundation path.

**Impact:** Unclear decision authority at the Month 24–30 mid-gate review could delay the go/no-go decision by 4–8 weeks, compressing the remaining timeline for the chosen chemistry. If three chemistry teams disagree on which candidate to advance, deadlock could force a costly compromise (continuing two chemistries instead of one), wasting USD 10–15 M on the weaker candidate. Ambiguous authority over major redirects (e.g., adding a fourth chemistry candidate or outsourcing synthesis) could lead to ad hoc spending that balloons contingency burn without strategic review.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a clear governance structure by Month 1 (2026-11-14): define a Scientific Steering Committee (Programme Director, four chemistry leads, an external technical advisor, and the funder representative) with explicit authority over chemistry advancement, gate decisions and budget reallocation. Document go/no-go criteria for each gate (Month 18 = 2028-04-14: cell-level Wh/kg feasibility, Month 30 = 2029-04-14: pouch-cell cycle-life proof, Month 36: mid-gate chemistry selection). Create a 'red team' function: a standing independent verification group (2–3 scientists, external to core teams) tasked with replicating key results and challenging progress claims before they are reported to funders. Establish a decision timeline: all gate reviews must conclude within 3 weeks to avoid downstream compression.

## Risk 14 - Financial - Currency and International Procurement
Specialized characterization instruments, pilot-line equipment and advanced materials often come from European or Asian suppliers and are quoted in EUR or CNY. A fixed USD 300 M budget faces foreign-exchange risk if the USD weakens against EUR over the 7-year period. A 10–15% depreciation of USD against EUR would increase the cost of imported equipment by USD 5–10 M.

**Impact:** If EUR-denominated equipment purchases (e.g., X-ray diffraction chamber from a German supplier, solid-electrolyte separator manufacturing line) total USD 30–50 M equivalent at Month 2 (2026-12-14), a 15% USD depreciation would add USD 4.5–7.5 M to those costs by Month 36 (2029-10-14), compressing other budget areas by 1.5–2.5%. Conversely, a strengthening USD would provide a tailwind but is unpredictable. Price-lock agreements with suppliers mitigate risk but add upfront cost (2–5% premium for fixed pricing).

**Likelihood:** Medium

**Severity:** Low

**Action:** Identify all major equipment and material purchases with expected EUR or other foreign-currency costs by Month 2 (2026-12-14); negotiate fixed-price contracts in USD or with forward exchange agreements to lock in rates for capital equipment orders placed in Months 2–6 (2026-12-14 to 2027-04-14). For ongoing material purchases, use a hedging strategy: request supplier pricing in USD where feasible, and budget USD 2–3 M (1% contingency) for currency fluctuation on necessary foreign-currency purchases. Monitor exchange rates quarterly and, if USD weakens beyond 10% on key procurement corridors, trigger a budget review to defer non-critical equipment or seek alternative domestic suppliers.

## Risk 15 - Strategic - Mid-Programme Pivot Cost and Timing
The staged tournament strategy assumes the programme can pivot from a failed chemistry to a backup option at Month 36 (2029-10-14) with minimal lost time. In practice, a pivot requires re-establishing supply chains for new precursors (2–4 months), rebuilding chemistry-specific equipment or pilot-line settings (2–3 months), and retraining staff on new processes (1–2 months). The effective pivot cost and time could be 6–10 months, not a clean gate decision.

**Impact:** A pivot at Month 36 (2029-10-14) from lithium-sulfur (failed) to anode-free solid-state would cost USD 5–10 M in retooling (dry-room settings, new separator equipment) and burn 6–10 months, pushing the programme to Month 42–46 (2030-04-14 to 2030-08-14) before solid-state proof is in hand. With only 38–42 months remaining in the 84-month timeline, there would be insufficient time to mature the new chemistry to production-ready cell level. The programme could deliver a proof-of-concept but not a hand-off ready for licensing.

**Likelihood:** Medium

**Severity:** High

**Action:** Build detailed pivot plans for each of the three reserve chemistries by Month 12 (2027-10-14): pre-qualify precursor suppliers, document process variations and equipment needs, and cross-train 20–30% of the synthesis and pilot-line team on each reserve path. Establish a 'pivot runway' reserve in the budget: USD 10–15 M (3–5% of total) held unallocated through Month 30 (2029-04-14), available for rapid pivots if a leading chemistry fails. By Month 24 (2028-10-14), if two of the three leading chemistries show signs of fundamental limitations, pre-stage the third chemistry (order long-lead precursors, prepare equipment) so the Month 30 (2029-04-14) gate decision can be executed within 4–6 weeks instead of 6–10 months.

## Risk 16 - Technical - Volumetric Energy Density (1000 Wh/L) Feasibility
The 1000 Wh/L volumetric target is as challenging as the 500 Wh/kg gravimetric target, yet the strategy emphasizes gravimetric density more heavily in its chemistry choices. Lithium-sulfur and conversion-cathode chemistries can achieve high Wh/kg but often require thick separators, large electrolyte volumes or low-density cathode structures that erode volumetric density. The risk is that a chemistry that hits 500 Wh/kg may only achieve 700–800 Wh/L because of volumetric penalties not captured in material-level calculations.

**Impact:** If the winning chemistry at Month 36 (2029-10-14) demonstrates 520 Wh/kg but only 850 Wh/L, the programme would need 6–12 months of redesign (thinner separators, higher-density cathode) to close the 150 Wh/L gap, or risk delivering a partial success. Redesign could require a new chemistry iteration (anode-free with higher volumetric density) or aggressive cell architecture changes (bipolar stacking, pressure hardware) that themselves need 6–12 months to stabilize.

**Likelihood:** Medium

**Severity:** High

**Action:** Include volumetric energy density as an explicit gate criterion alongside gravimetric density from Month 12 (2027-10-14) onward. Require the dedicated mass-and-volume model to track not only Wh/kg but also Wh/L for every candidate; any chemistry that projects <950 Wh/L at cell level is flagged for focused redesign by Month 18 (2028-04-14). By Month 30 (2029-04-14), require pouch-cell data showing both ≥500 Wh/kg and ≥950 Wh/L measured in the same cells, not separate demonstrations. If a chemistry meets gravimetric but not volumetric targets by Month 36 (2029-10-14), allocate a 6-month architecture-focused sprint (bipolar, anode-free optimization) before the mid-gate decision, rather than deferring volumetric work to later phases.

## Risk 17 - Regulatory & Permitting - State and Federal EHS Compliance
The programme handles hazardous materials (lithium metal, fluorinated solvents, toxic precursors) and runs abuse tests (thermal runaway, overcharge) that generate regulatory reporting obligations. Violations of EPA hazardous-waste rules, OSHA worker safety standards or state environmental permitting could result in fines, operational closure or loss of license. The 7-year timeline includes potential regulatory changes (e.g., stricter VOC limits, new lithium-handling rules) that could force costly retrofits.

**Impact:** A serious EHS incident (e.g., lithium-water reaction fire, solvent spill) could trigger a 2–4 week facility shutdown, investigation and USD 1–3 M in remediation costs, plus reputational damage and insurance premium increases (proposed: 20–30% for 2–3 years). A surprise regulatory change (e.g., new federal rules on lithium-ion battery recycling or thermal-runaway test standards) in Year 3 could force USD 2–5 M in facility upgrades and 2–3 month process adjustments. Failure to maintain permits could prohibit synthesis or testing for 1–3 months while compliance is restored.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish an in-house EHS compliance function by Month 1 (2026-11-14), led by an experienced environmental health and safety officer with battery-lab credentials. Conduct a comprehensive regulatory assessment by Month 2 (2026-12-14) covering EPA, OSHA, Texas Commission on Environmental Quality, Department of Transportation (for materials shipping) and local fire codes. Implement quarterly internal audits and annual compliance reviews; budget USD 500 K–1 M/year for EHS staff, training and compliance services. Establish a standing relationship with a regulatory consulting firm to monitor evolving federal and state rules and prepare adaptation plans. Allocate USD 1–2 M contingency for unexpected retrofit or remediation costs.

## Risk 18 - Operational - Austin Market Talent Saturation and Poaching
The Austin area has a concentrated battery and EV engineering community around Tesla, Austin Energy Storage, and automotive suppliers. While this offers recruitment advantages, it also means competing firms (Tesla, other EV startups) are actively recruiting the same talent pool. Salaries for senior battery scientists and cell-design engineers have risen 20–30% in recent years. The programme's non-commercial, research-focused framing may appeal to some candidates but deter others seeking equity upside or higher industrial salaries.

**Impact:** If the programme offers competitive salaries (proposed: 10–20% premium on industry baseline to offset non-commercial status), payroll for 80–120 FTE could reach USD 8–12 M/year, consuming 19–28% of the USD 43 M annual budget. Losing a key chemistry lead or pilot-line manager to a rival firm mid-programme (Month 18–36 = 2028-04-14 to 2029-10-14) could cost USD 1–2 M in replacement hiring and 2–4 month knowledge-transfer delays. If attrition exceeds 15% annually, continuous turnover could degrade institutional knowledge and reproducibility.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Structure compensation to compete: offer 15–20% salary premium over market baseline for senior roles (chemistry leads, characterization experts), augmented with signing bonuses (USD 50–150 K for mid-career scientists) and professional-development budgets (USD 10–20 K/person/year for conferences, training). Build retention agreements with key personnel (3–5 year terms, clawback for early departure). Establish a 'stay' plan: publish early wins in peer-reviewed journals (boosting researcher prestige), and offer leadership roles (publication authorship, internal committee participation) that increase job satisfaction. Partner with UT Austin for graduate recruitment (reduced overhead, early career development) to offset senior-hire dependency.

## Risk 19 - Strategic - Long-Term Sustainability and Technology Transfer
The programme is explicitly not aimed at becoming an industrial player, but at inventing and demonstrating a technology. However, there is no clear hand-off or licensing plan for the final result. If the 500 Wh/kg, 1000 Wh/L cell is demonstrated by Month 72 (2032-10-14), who manufactures it at scale? Who commercializes the patents? A weak or unclear exit strategy could leave a successful invention without a clear path to real-world impact, or result in unfavorable licensing terms.

**Impact:** An invention delivered at Month 72 (2032-10-14) without a pre-negotiated licensing or technology-transfer agreement could delay commercial deployment by 12–24 months while potential manufacturers evaluate, negotiate and finalize agreements. Poor licensing terms (e.g., exclusive license to a single competitor, royalty rates that undervalue the invention) could reduce the economic return on the USD 300 M investment. Alternatively, lack of clear commercialization could result in the invention being shelved or licensed at a steep discount.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 12 (2027-10-14), identify potential licensing or manufacturing partners (e.g., established battery makers, automotive OEMs, energy-storage firms) and engage them in informal technical advisory relationships. Develop a licensing framework by Month 24 (2028-10-14) that clarifies IP ownership, royalty structures, manufacturing obligations and exclusivity terms. Structure the final 12 months (Months 72–84 = 2032-10-14 to 2033-10-14) as a technology-transfer phase: documentation, process scale-up guidance, manufacturing feasibility studies and partnerships with a likely licensee. Consider a 'tiered' exit: exclusive license to a single strategic partner for core automotive/aviation applications, non-exclusive license for energy-storage and other secondary uses, to maximize reach and return.

## Risk 20 - Technical - Cycle-Life and Degradation Mechanisms
Reaching 500 Wh/kg and 1000 Wh/L often comes at the cost of reduced cycle life. Lithium-metal anodes suffer dendrite growth and lithium-ion loss, sulfur cathodes polysulfide dissolution, and high-voltage cathodes electrolyte oxidation. A cell that achieves the energy targets but has <200 cycles of usable life (80% capacity retention) would not be a practical battery. The plan does not explicitly define a minimum cycle-life threshold, risking a 'one-cycle wonder' that meets the letter of the goal but not real-world utility.

**Impact:** A chemistry that demonstrates 520 Wh/kg, 1050 Wh/L but degrades to 80% capacity in 150 cycles would require 6–12 months of redesign (stable interface engineering, cathode doping, electrolyte additives) to extend cycle life. If the redesign is not successful, the programme would need to pivot to a different chemistry, compressing the final optimization window. A published result showing high energy density but poor cycle life would also damage the programme's credibility.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a minimum cycle-life requirement as a hard gate criterion by Month 6 (2027-04-14): proposed threshold of ≥300 cycles at 80% capacity retention at the cell level. Include cycle-life performance in every gate review from Month 18 (2028-04-14) onward. By Month 24 (2028-10-14), all chemistry candidates must demonstrate cycle-life data; any candidate with <250 cycles at 80% is deprioritized unless it is within one iteration (2–4 month redesign) of target. Allocate 15–20% of discovery effort to interface stability and degradation-mechanism research; characterize failure modes quarterly (SEMs of cycled electrodes, electrolyte decomposition analysis) to catch cycle-life limitations early and guide mitigation.

## Risk 21 - Technical - Manufacturing Scale and Process Control
A cell demonstrated at lab scale (100–500 cells built and tested) may not translate to pilot scale (1,000+ cells) without discovering process-control issues. Dry-room humidity, electrode coating uniformity, cell stacking precision and electrolyte dosing all affect reproducibility. Cells built by hand or with limited automation can hide process variability that becomes critical when scaled. If the winning chemistry requires ultra-tight process windows (e.g., lithium-metal protection layer thickness within ±5 µm), pilot-line commissioning and reproducibility could stretch to 6–12 months.

**Impact:** Discovering at Month 60 (2031-10-14) that the lab-scale cell's 500 Wh/kg result cannot be replicated at pilot scale (builds drop to 480 Wh/kg, or 50% of cells are non-functional) would require 6–12 month process-development effort, compressing the final optimization window. The programme would risk missing the Month 84 (2033-10-14) delivery date or delivering a result that is not reproducible. Alternatively, scaling to a less demanding process (thicker separators, lower current density) to ensure reproducibility would sacrifice the Wh/kg and Wh/L targets.

**Likelihood:** Medium

**Severity:** High

**Action:** Begin process-scale-up work by Month 18 (2028-04-14) for the leading chemistry candidate, building at least 50–100 full pouch cells per month by Month 24 (2028-10-14) to expose scaling issues early. Establish a process-control discipline: document cell-build parameters (humidity, temperature, coating thickness, electrolyte volume) for every cell by Month 20 (2028-06-14), and correlate performance variation to process variability. By Month 30 (2029-04-14), require the pilot line to demonstrate batch-to-batch reproducibility (90% of cells meeting target Wh/kg within ±10%) as a gate criterion. Allocate 10–15% of discovery effort to manufacturing-science work: process optimization, design-of-experiments for key parameters, and pilot-line automation where it reduces variability.

## Risk 22 - Operational - Computing and Simulation Infrastructure
The discovery-engine strategy relies on computational materials screening and machine-learning proposal of candidates. This requires high-performance computing (HPC) resources, validated simulation codes and trained staff. Building or accessing sufficient HPC capacity and integrating it with robotic synthesis and characterization data pipelines is complex and often underestimated. If computing infrastructure lags, the discovery loop becomes data-limited rather than hypothesis-limited, negating the throughput benefit of automation.

**Impact:** Inadequate HPC capacity or poor data integration could reduce discovery throughput by 30–50%, delaying identification of viable candidates by 3–6 months. A computational model that is not validated experimentally (e.g., a machine-learning predictor of interfacial stability that correlates poorly with real cycled cells) could lead to wasted synthesis effort on predicted candidates that do not perform. Building or leasing HPC capacity could cost USD 5–10 M upfront and USD 1–2 M/year in operating cost, competing with other budget priorities.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-14), establish a computing infrastructure plan: identify a partnership with a national laboratory (e.g., NREL, Lawrence Berkeley Lab) for HPC access, or commit to cloud computing (AWS, Google Cloud) for scalable capacity (estimated USD 500 K–2 M/year). Dedicate a 2–3 person computational-chemistry team to validate simulation codes against experimental data by Month 12 (2027-10-14); any model with <80% predictive accuracy for key properties (interfacial resistance, voltage stability) is not used for candidate ranking until validated. Integrate data pipelines by Month 9 (2027-07-14): automated collection of cell-cycling data, post-mortem characterization results and computed properties into a searchable database that feeds machine-learning model retraining monthly.

## Risk 23 - Technical - Third-Party Certification and Benchmarking
Claiming a cell has achieved 500 Wh/kg and 1000 Wh/L requires independent verification that the numbers are real, not inflated by measurement artifacts or optimistic assumptions. Third-party testing (e.g., by an accredited independent lab such as one affiliated with an automotive safety organization) can cost USD 20–50 K per full-characterization protocol and adds 6–12 week turnarounds. If the programme waits until Month 60–72 (2031-10-14 to 2032-10-14) to commission third-party validation, late-discovered issues could delay publication.

**Impact:** Third-party testing of 10–15 candidate cells (multiple chemistries, to ensure reproducibility) over the 7-year period could cost USD 200–750 K, which is manageable but adds execution risk. If third-party testing uncovers measurement discrepancies (e.g., actual measured Wh/kg is 480 instead of claimed 510), the programme must either redesign or accept a lower headline number. Late discovery (Month 66+) would leave insufficient time to remedy. Industry skepticism about undocumented in-house measurements could undermine patent value and licensing appeal.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish third-party verification protocols by Month 12 (2027-10-14): identify 2–3 independent labs or test facilities capable of full cell characterization and abuse testing (e.g., accredited battery-testing organizations, university partnerships with external credibility). Conduct first independent verification of a pouch cell by Month 30 (early milestone cell, not necessarily the ultimate goal cell) to catch any measurement methodology issues and build confidence. Plan for final third-party validation of the goal cell by Month 72 (2032-10-14), allowing 6-month review and publication before the Month 84 (2033-10-14) end date. Budget USD 50–100 K/year for third-party testing; reserve capacity for rapid validation if a breakthrough cell is achieved ahead of schedule.

## Risk summary
This battery-invention programme faces three critical risks that, if not actively managed, could jeopardize delivery of a 500 Wh/kg, 1000 Wh/L cell by Month 84 (2033-10-14). First, the staged chemistry tournament could fail to identify a viable path, leaving the programme at Month 36 (2029-10-14) with three exhausted candidates and insufficient runway for a meaningful pivot; establishing clear go/no-go criteria by Month 18 (2028-04-14) and requiring independent pouch-cell proof by Month 30 (2029-04-14) are essential safeguards. Second, packaging and volumetric-density penalties could emerge late, threatening the 1000 Wh/L target; treating volumetric density as a gate criterion from Month 12 (2027-10-14) and requiring measured pouch-cell data on both Wh/kg and Wh/L by Month 30 (2029-04-14) will force early discipline. Third, the fixed USD 300 M budget and early capital commitments (pilot line, facility, hiring) could leave insufficient working capital for later iterations and pivots; structuring funding release in tranches tied to demonstrated milestones and holding a USD 15–20 M contingency reserve will provide flexibility. Operational risks (site permitting delays, talent attrition, partner dependency) are secondary but should be managed through early regulatory engagement, competitive compensation, and formal agreements with backup partners. The strategy's emphasis on hedging chemistry risk and imposing system-level discipline early is sound for a high-ambition, capital-constrained, non-commercial invention programme.

# Make Assumptions


## Question 1 - How will the USD 300 M be released across tranches, and what share is held as contingency versus capital build-out?

**Assumptions:** Assumption: Funds are released in evidence-linked tranches (Months 0-12 = 2026-10-14 to 2027-10-14 about USD 60 M, Months 12-24 = 2027-10-14 to 2028-10-14 about USD 80 M, Months 24-36 = 2028-10-14 to 2029-10-14 about USD 70 M, Months 36-84 = 2029-10-14 to 2033-10-14 about USD 90 M; proposed split), with a USD 15-20 M reserve (estimate, 5-7%). Typical R&D programmes hold 5-10% contingency.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates budget phasing and reserve adequacy.
Details: Front-loading of pilot line, dry room and hiring may reach USD 60-80 M in Years 1-2 (estimate), leaving roughly USD 30-34 M/year afterwards. A 20% facility overrun would cut remaining funds by 3-5%. Mitigate with modular leased equipment, partner co-funding (proposed 10-15%) and a reserve held through Month 30 (2029-04-14). Benefit: preserved pivot capacity at the Month 36 (2029-10-14) gate.

## Question 2 - What are the key milestones and gate dates, and when must independent pouch-cell proof and minimum cycle life be demonstrated?

**Assumptions:** Assumption: Gates at Month 18 (2028-04-14) (go/no-go criteria), Month 30 (2029-04-14) (third-party pouch-cell verification, both Wh/kg and Wh/L) and Month 36 (2029-10-14) (chemistry selection); delivery by Month 84 (2033-10-14). Minimum cycle life is a proposed threshold of 300 cycles at 80% retention.

**Assessments:** Title: Timeline Feasibility Assessment
Description: Evaluates gate sequencing against the 84-month horizon.
Details: A failed Month 36 (2029-10-14) gate leaves about 48 months, and a pivot costs 6-10 months (estimate). Early pouch proof at Month 30 (2029-04-14) exposes packaging penalties while a pivot is still affordable. Pre-staging the reserve chemistry by Month 24 (2028-10-14) shortens pivots to 4-6 weeks. Risk: permitting slippage of 6-8 months compresses effective work time; mitigate with phased permits.

## Question 3 - What team size, skill mix and hiring pace are needed, and how will talent be retained against Tesla competition?

**Assumptions:** Assumption: 80-120 FTE (estimate) with 20-30% postdoctoral and graduate roles, a 10-20% salary premium for senior roles, and 3-5 year retention agreements. Attrition target is below 15% annually (proposed).

**Assessments:** Title: Personnel Capacity Assessment
Description: Evaluates ability to staff and retain a specialist team in Austin.
Details: Payroll could reach USD 8-12 M/year (estimate), about 19-28% of the average annual budget. Attrition of 20% means 16-24 replacements per year and lost knowledge. Mitigate with UT Austin pipelines, publication incentives and clawback-backed retention. Opportunity: university links reduce cost and broaden the talent pool beyond Tesla alumni.

## Question 4 - What governance structure, decision rights and IP/regulatory framework will govern gate decisions, partners and technology transfer?

**Assumptions:** Assumption: A Scientific Steering Committee (director, chemistry leads, external advisor, funder representative) decides gates and reallocations within 3 weeks. An independent red team of 2-3 scientists verifies claims. IP terms and a licensing framework are set by Month 24 (2028-10-14).

**Assessments:** Title: Governance Adequacy Assessment
Description: Evaluates decision authority, verification and IP controls.
Details: Ambiguity at gates could add 4-8 weeks of delay or fund a weaker chemistry at USD 10-15 M (estimate). Clear criteria and an independent verifier protect credibility and patent value. Open partner sharing risks a 30-50% licence value loss (estimate) if filings are late; file provisionals on compositions and formats as they emerge. Clean-room onboarding limits Tesla contamination claims.

## Question 5 - What safety strategy, hazard envelope and abuse-testing approach apply to lithium metal, flammable solvents and high-energy cells?

**Assumptions:** Assumption: Phased safety evaluation: thermal-ramp screening at Months 3-6 (2027-01-14 to 2027-04-14), contracted abuse tests at Months 6-12 (2027-04-14 to 2027-10-14), in-house chambers (USD 3-5 M, estimate) from Month 12 (2027-10-14) if a chemistry passes. Finalists need thermal runaway onset of at least 120°C (proposed threshold).

**Assessments:** Title: Safety and Risk Assessment
Description: Evaluates hazard handling and early elimination of unsafe candidates.
Details: Late discovery of onset below 100°C could waste 12-18 months and USD 10-20 M (estimate). Incidents may cost USD 1-3 M and weeks of shutdown. Mitigate with a staffed EHS function by Month 1 (2026-11-14), quarterly audits, a standing EHS advisory committee and contingency of USD 3-5 M. Benefit: early safety ranking narrows the design space.

## Question 6 - What environmental obligations (waste, emissions, water, energy) arise from synthesis, dry rooms and abuse testing, and how will they be managed?

**Assumptions:** Assumption: Operations are permitted under EPA, TCEQ and local rules with a licensed hazardous-waste contractor, solvent recovery where feasible, and an annual environmental compliance budget of USD 0.5-1 M (estimate).

**Assessments:** Title: Environmental Impact Assessment
Description: Evaluates waste, emissions and regulatory exposure.
Details: Key streams are fluorinated solvents, lithium residues, VOCs and failed cells; dry rooms carry high energy demand. Regulatory change may require USD 2-5 M retrofits (estimate). Mitigate with waste minimisation, small-batch synthesis, exhaust abatement and a regulatory monitoring retainer. Opportunity: documented low-impact practice eases permitting and partner trust.

## Question 7 - Which stakeholders (funder, universities, national labs, regulators, community, Tesla, potential licensees) need engagement, and how?

**Assumptions:** Assumption: Formal 3-5 year agreements with at least two university or national-lab partners by Month 3, early engagement with the Austin fire authority, and informal licensee advisory contacts by Month 12 (2027-10-14). Partners fund at least 15% of shared costs (proposed).

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Evaluates partner dependency and external relationships.
Details: Partner loss could cost USD 30-50 K per sample at commercial labs and USD 5-10 M over the programme (estimate). Mitigate with backup partners per critical service, 30-60 day exit clauses and USD 2-3 M/year partnership contingency. Early licensee engagement reduces 12-24 month commercialisation delays. Community and regulator transparency lowers permit-denial risk.

## Question 8 - Which operational systems (pilot line, dry room, characterization, data/computing, supply chain) must be running, and by when?

**Assumptions:** Assumption: A modular leased dry-room and pouch line sized for 50-100 cells/month (estimate) is operating by Month 3-6 (2027-01-14 to 2027-04-14), with one in-house post-mortem instrument by Month 6 (2027-04-14), a unified data pipeline by Month 9 (2027-07-14), and dual-sourced precursors by Month 3 (2027-01-14).

**Assessments:** Title: Operational Systems Assessment
Description: Evaluates fabrication, analysis, data and supply readiness.
Details: A new owned line may cost USD 30-50 M and 12 months; modular leasing cuts lock-in. Partner queues of 4-8 weeks could cut hypothesis throughput 50-75%, so in-house triage is justified. Precursor lead times of 8-12 weeks justify 3-6 months of buffer stock. Computing at USD 0.5-2 M/year via cloud or national-lab access (estimate). Require reproducibility of 90% of cells within ±10% by Month 30 (2029-04-14).

# Distill Assumptions

- Goal: invent a battery at ≥500 Wh/kg and ≥1000 Wh/L (user constraint), not market dominance.
- Budget is USD 300 M over 7 years (Months 0-84 = 2026-10-14 to 2033-10-14), sited near Tesla in Austin.
- Funds release in evidence-linked tranches: about USD 60/80/70/90 M, with USD 15-20 M reserve (proposed).
- Partners co-fund at least 15% of shared costs (proposed); reserve held through Month 30 (2029-04-14).
- Staged tournament across three or four chemistries, cut to one finalist at Month 36 (2029-10-14) gate.
- Gates: Month 18 (2028-04-14) go/no-go, Month 30 (2029-04-14) third-party pouch verification, Month 36 (2029-10-14) chemistry selection.
- Minimum cycle life is 300 cycles at 80% retention (proposed threshold).
- Layered hybrid electrolyte with thin ceramic or polymer interlayer in minimal-volume liquid.
- In-house computation ranks candidates; university and national-lab partners validate, converting fixed to variable cost.
- Cell-level mass-and-volume model back-calculates material targets from the start.
- Team of 80-120 FTE (estimate), payroll USD 8-12 M/year, attrition below 15% (proposed).
- Formal agreements with at least two university or national-lab partners by Month 3 (2027-01-14).
- Scientific Steering Committee decides gates within 3 weeks; 2-3 scientist independent red team verifies claims.
- IP and licensing framework set by Month 24 (2028-10-14); provisional patents filed as compositions emerge.
- Modular leased dry-room and pouch line, 50-100 cells/month (estimate), operating by Months 3-6 (2027-01-14 to 2027-04-14).
- Reproducibility of 90% of cells within ±10% required by Month 30 (2029-04-14).
- Phased safety testing; finalists need thermal runaway onset of at least 120°C (proposed).
- Staffed EHS function by Month 1 (2026-11-14); permitted under EPA, TCEQ and local rules.
- Dual-sourced precursors by Month 3 (2027-01-14); permitting slippage of 6-8 months is a key risk.
- Reserve chemistry pre-staged by Month 24 (2028-10-14) shortens pivots; delivery by Month 84 (2033-10-14).

# Review Assumptions

## Domain of the expert reviewer
Applied Strategic R&D Programme Management, with expertise in electrochemistry, materials science commercialization, and technology-invention risk across capital-constrained, non-commercial research environments. Focus on translating laboratory breakthroughs to demonstrated prototypes and defensible IP while managing scientific, operational, and financial risk over multi-year timelines.

## Domain-specific considerations

- Chemistry-to-cell translation penalties: material-level energy density often collapses 15–30% once packaging, current collectors, electrolyte mass and pressure hardware are included; volumetric density constraints are especially harsh and often treated as secondary
- Cycle-life and degradation mechanisms: high-energy lithium-rich cells commonly sacrifice cycle life; a 500 Wh/kg cell with <200 cycles is not a functional battery, yet the plan lacks a non-negotiable minimum threshold until Month 6 (2027-04-14)
- Interface engineering risk: solid electrolytes, high-voltage cathodes and lithium-metal anodes all depend critically on stable interphase chemistry that is often discovered only after hundreds of test cells; early forensics access is essential
- Permitting and site readiness: hazardous-materials synthesis and thermal-runaway testing in the Austin area face multi-agency approvals (EPA, TCEQ, local fire authority); a 6–8 month delay is plausible and compresses the effective 84-month timeline
- Talent concentration and IP contamination: proximity to Tesla creates both advantage (recruitment) and risk (poaching, implicit knowledge transfer); clean-room protocols and retention mechanics need explicit design
- Pilot-line capital lock-in: a new dry-room and pouch-cell line costs USD 30–60 M and requires 6–12 months to commission; committing that capital before a winning chemistry is proven is a major bet, but leasing adds queue time and confidentiality exposure

## Issue 1 - Missing Explicit Minimum Cycle-Life Requirement and Late-Discovery Risk
The plan states 500 Wh/kg and 1000 Wh/L targets but does not define a minimum cycle-life threshold (e.g., ≥300 cycles at 80% capacity retention) until Month 6 (2027-04-14), and even then only as a proposal. A cell meeting the gravimetric and volumetric targets but cycling <150 times would satisfy the letter of the success criteria while being commercially unusable. This absence creates the risk of a 'one-cycle wonder' that wastes 12–18 months of development before cycle-life inadequacy is discovered.

**Recommendation:** Establish a hard minimum cycle-life requirement by Month 3 (2027-01-14) as a non-negotiable gate criterion: propose ≥300 cycles at 80% capacity retention at the pouch-cell level. Include cycle-life data collection and degradation-mechanism forensics (post-mortem SEMs of cycled electrodes, electrolyte decomposition analysis) from Month 6 (2027-04-14) onward for every candidate chemistry. Require every chemistry finalist advancing past Month 24 (2028-10-14) to demonstrate measured cycle-life evidence, not projections. If a leading candidate fails this threshold by Month 30 (2029-04-14), demote it immediately and accelerate the reserve chemistry into testing.

**Sensitivity:** Baseline assumption: a viable chemistry is discovered by Month 30 (2029-04-14) with ≥300 cycles. If cycle-life is discovered to be inadequate only at Month 48 (2030-10-14) (late discovery), a redesign cycle or chemistry pivot would cost USD 10–25 M and delay delivery by 6–12 months. Late-discovered cycle-life issues would also reduce the programme's credibility and patent value by an estimated 20–30%, as a documented poor-cycle-life result is harder to license and commercialize than early-caught and remedied limitations.

## Issue 2 - Volumetric Energy Density (1000 Wh/L) Secondary Treatment and Cell-Architecture Risk
The strategy emphasizes gravimetric density (500 Wh/kg) in chemistry and discovery choices, yet volumetric density (1000 Wh/L) is equally challenging and depends on thin separators, low dead-volume architectures, and high-density cathode structures. Lithium-sulfur and conversion-cathode chemistries can hit Wh/kg but often require thick electrolyte layers or low-density materials that erode Wh/L. The plan's dual-track mass-and-volume model is a good safeguard, but the model is not verified experimentally until Month 30 (2029-04-14), risking 18 months of wasted effort on a chemistry that fundamentally cannot achieve 1000 Wh/L at cell level.

**Recommendation:** Elevate volumetric density to parity with gravimetric density from Month 12 (2027-10-14) onward. Require the live mass-and-volume model to project Wh/L alongside Wh/kg for every candidate; flag any chemistry projecting <950 Wh/L at pouch level by Month 18 (2028-04-14) for immediate redesign (bipolar stacking, anode-free optimization, or aggressive separator thinning). Mandate independent third-party measured pouch-cell data showing both ≥500 Wh/kg and ≥950 Wh/L in the same cells by Month 30 (2029-04-14), not separate demonstrations. If a chemistry hits the Wh/kg target but falls short of 950 Wh/L by Month 36 (2029-10-14), allocate a focused 6-month architecture sprint before the mid-gate decision rather than deferring volumetric work to later phases.

**Sensitivity:** Baseline: a winning chemistry achieves both 500 Wh/kg and 1000 Wh/L by Month 36 (2029-10-14). Downside scenario: if volumetric penalties (thick separators, large electrolyte volume) limit a leading chemistry to 850 Wh/L despite 520 Wh/kg, and this is discovered at Month 36 (2029-10-14), a 6–12 month redesign cycle consuming USD 8–15 M would compress the final optimization window. Worst case (late discovery at Month 60 = 2031-10-14): the programme would deliver a partial success (500 Wh/kg but only 800 Wh/L), missing one of two co-equal targets and reducing the invention's value by an estimated 30–40% as a licensing asset.

## Issue 3 - Site Permitting, Regulatory Approval and Operational-Readiness Schedule Compression
The plan assumes site selection, lease negotiation and permitting can be completed by Month 3 (2027-01-14), allowing pilot-line deployment by Months 3–6 (2027-01-14 to 2027-04-14). In practice, EPA hazardous-waste permits, TCEQ air and water permits, and Austin Fire Authority approvals for lithium-metal synthesis and thermal-runaway abuse testing typically require 4–8 months, especially if the site is new to such materials. A permitting delay of 6–8 months (plausible and common in R&D facilities) would push operational start to Month 6–8 (2027-04-14 to 2027-06-14), compressing the 84-month timeline to 76–78 months of effective work. Conservative permitting also risks excluding reactive chemistries (lithium metal, sulfides, halide electrolytes) from on-site synthesis, forcing outsourcing of key chemistry work at cost and with 4–6 week turnarounds, slowing iteration 50–70%.

**Recommendation:** Initiate site selection, lease negotiation and permitting engagement with Texas environmental and Austin fire authorities in Month 0 (2026-10-14), not Month 1 (2026-11-14). Treat regulators as collaborative partners, not gatekeepers; propose a tiered permitting strategy with the fire authority: Phase 1 (dry-room and pouch-cell assembly, low-hazard) by Month 3 (2027-01-14), Phase 2 (lithium-metal and solvent synthesis) by Month 6 (2027-04-14), Phase 3 (abuse-testing chambers) by Month 9 (2027-07-14). Pre-negotiate with licensed external synthesis facilities (e.g., contract research organizations in Texas or California) to handle any on-site-prohibited chemistry steps at cost-plus terms with <4 week turnarounds, so synthesis is not a bottleneck if local permitting is restrictive. By Month 1 (2026-11-14), establish an EHS compliance function led by an experienced battery-lab engineer who can navigate overlapping EPA, TCEQ and local rules.

**Sensitivity:** Baseline: operational start by Month 3 (2027-01-14); effective programme work spans Months 3–84 (2027-01-14 to 2033-10-14) = 81 months. Downside scenario (6-month permitting delay): operational start at Month 9 (2027-07-14), effective work = 75 months. Impact on timeline: with a Month 36 (2029-10-14) chemistry gate, a 6-month delay compresses the post-gate window from 48 months to 42 months. A chemistry pivot triggered at the gate would then have only ~36 months to maturation and proof—risking incomplete validation. Cost impact: outsourced synthesis of lithium-metal and sulfide candidate batches at USD 50–100 K per batch could consume USD 2–5 M/year if on-site synthesis is prohibited, reducing remaining capital budget by 5–12%.

## Issue 4 - Pilot-Line Capital Commitment Before Chemistry is Proven: Ownership Versus Leasing Trade-Off
The plan specifies a modular, containerized dry-room and pouch-cell line sized for 50–100 cells/month but does not explicitly decide whether to build (~USD 30–50 M, 6–12 month lead time), lease (~USD 2–5 M/year operational cost, 4–8 week queue times), or modularize (~USD 15–25 M, 3–4 month deployment). Building a line early (Month 0–3 = 2026-10-14 to 2027-01-14) locks USD 30–50 M of the fixed USD 300 M budget before a winning chemistry is known, leaving USD 250–270 M for 6.5 years of operation. Leasing preserves capital for pivots but adds queue time and confidentiality exposure for unpublished materials. A new-build line also creates stranded-asset risk if the winning chemistry requires fundamentally different dry-room conditions (e.g., inert atmosphere versus moisture control) than initially assumed.

**Recommendation:** By Month 1 (2026-11-14), commit to a modular, leased dry-room and pouch-cell line (not owned) to preserve capital flexibility and pivot capacity. Target deployment by Month 3 (2027-01-14); negotiate a 3-year lease with expansion and early-exit options. Simultaneously, negotiate a standby pilot-line agreement with a university or national-laboratory partner by Month 2 (2026-12-14) to provide backup pouch-cell fabrication at cost during modular-line commissioning or if primary line capacity is exceeded. This converts a large fixed cost (owned line) into a variable, scalable cost (leased line). Reserve USD 15–20 M and 6-month lead time in the budget for pilot-line capital needs. If a winning chemistry by Month 24 (2028-10-14) emerges with high-throughput demands (e.g., parallel screening of 200+ cells/month), then evaluate building a dedicated line at that point with concrete chemistry-driven specifications.

**Sensitivity:** Baseline: modular leased line, ~USD 50–100 K/month operational cost, ~USD 0.6–1.2 M/year. Downside scenario (owned line): USD 40 M upfront commitment at Month 3 (2027-01-14), reducing available working capital by 13% and increasing sunk-cost risk. If the winning chemistry (discovered Month 36 = 2029-10-14) has dry-room requirements not met by the built line (e.g., aggressive lithium-metal work requires <10 ppm water, existing line cannot achieve), a redesign of the owned line could cost USD 5–10 M and lose 3–4 months to retrofit. Benefit of leasing: if a pivot is needed at Month 36 (2029-10-14), switching line vendors takes 2–4 weeks instead of 6–12 months for owned-line recommissioning.

## Issue 5 - Chemistry-Tournament Contingency Planning and Mid-Gate Pivot Cost
The Pragmatic Foundation strategy runs a staged tournament across three or four chemistries with a formal go/no-go gate at Month 36 (2029-10-14). If two of the three leading candidates fail by Month 36 (2029-10-14) for fundamental reasons (cycle-life collapse, dendrite growth, volume expansion), the programme must pivot to a reserve chemistry with only 48 months remaining. However, pivoting from one chemistry to another (e.g., lithium-sulfur to anode-free solid-state) requires 6–10 months of precursor re-sourcing, pilot-line retooling, and staff retraining. The plan assumes pivots are 'clean,' but in practice a pivot discovered at Month 36 (2029-10-14) might not complete chemistry commissioning until Month 42–46 (2030-04-14 to 2030-08-14), leaving only 38–42 months for proof and optimization—insufficient for a chemistry reaching its first stable pouch cells.

**Recommendation:** By Month 12 (2027-10-14), develop detailed contingency plans for each reserve chemistry: pre-qualify precursor suppliers, document process variations and equipment reconfiguration needs, and cross-train 20–30% of the synthesis and pilot-line team on each backup path. Establish a 'pivot runway' contingency reserve of USD 10–15 M (3–5% of total budget) held unallocated through Month 30 (2029-04-14), earmarked for rapid chemistry pivots. By Month 24 (2028-10-14), if two of the three leading candidates show fundamental limitations (e.g., both stuck below 250 cycles despite 18 months of interface engineering), pre-stage the third chemistry: order long-lead precursors, prepare pilot-line equipment and train staff. This shortens the pivot execution time from 6–10 months to 4–6 weeks, allowing a Month 30–36 (2029-04-14 to 2029-10-14) decision to translate into Month 36–42 (2029-10-14 to 2030-04-14) commissioning of the pivoted chemistry, preserving 42 months for proof.

**Sensitivity:** Baseline: successful chemistry identified by Month 30 (2029-04-14), no pivot needed. Downside scenario (pivot at Month 36 = 2029-10-14): if pivot requires 6–10 months of retooling and commissioning, the programme reaches Month 42–46 (2030-04-14 to 2030-08-14) before the new chemistry is building pouch cells. With only 38–42 months remaining, proof-of-concept (Wh/kg and Wh/L) might be achieved but with insufficient time for reliability testing (500+ cycles, abuse tests, third-party verification). Cost of late pivot: USD 5–10 M in retooling, precursor qualification and staff retraining, reducing working capital by 1.7–3.3%. Worst case (no contingency plan): a pivot at Month 36 (2029-10-14) with unprepared suppliers and untrained staff could stretch to Month 50+, leaving only 34 months for final proof, risking an incomplete demonstration.

## Issue 6 - Talent Recruitment, Retention and Payroll Budget Allocation Under Tesla Competition
The plan assumes 80–120 FTE (estimate) with payroll of USD 8–12 M/year, approximately 19–28% of the average annual budget. However, this estimate lacks detail on salary competitiveness, sign-on incentives, retention mechanics and graduate-student cost scaling. In the Austin area, senior battery scientists and manufacturing engineers earn USD 150–250 K/year in industry (Tesla, other EV firms), compared to USD 120–180 K in academic or research settings. To recruit and retain specialized talent while remaining within 25% of annual budget requires either: (a) offering industry-competitive salaries (pushing payroll toward the upper 28% estimate) and accepting reduced capital spending on equipment, or (b) offsetting lower base salaries with graduate-student pipelines, publication prestige, and retention agreements—all requiring active management. Unmanaged, payroll could exceed budget and attrition could reach 20% annually, requiring continuous re-hiring and knowledge loss.

**Recommendation:** Structure compensation to compete with local industry: pay a 15–20% premium over baseline academic salaries for senior chemistry and engineering leads (estimated incremental cost: USD 1–2 M/year across 5–8 key roles). Augment with signing bonuses (USD 50–150 K for mid-career scientists) and professional-development budgets (USD 10–20 K/person/year). For cost control, target 20–30% of the team as postdoctoral and graduate-student roles, reducing average payroll cost. By Month 2 (2026-12-14), negotiate a formal recruitment pipeline with University of Texas at Austin graduate and postdoctoral groups, offering stipend supplements and co-authorship on publications. Establish 3–5 year retention agreements with key personnel (chemistry leads, characterization experts) that include clawback terms for early departure. Implement a 'stay' plan: publish early wins (Month 6–12 = 2027-04-14 to 2027-10-14) in peer-reviewed journals to enhance researcher prestige and reduce poaching risk. Target attrition below 15% (proposed); if actual attrition exceeds 15%, trigger a retention review and compensation adjustment by Month 24 (2028-10-14).

**Sensitivity:** Baseline: average payroll USD 10 M/year (25% of annual budget), attrition <15%, turnover cost ~USD 1–2 M/year. Downside scenario (high attrition): if attrition reaches 20%, the programme must hire 16–24 replacements annually, consuming USD 1.5–2.5 M/year in recruiting, onboarding, and training (~3 months ramp-up per new hire). Loss of a key chemistry lead at Month 12–24 (2027-10-14 to 2028-10-14) could set the programme back 2–4 months as knowledge and tribal understanding is re-built. Salary-competition pressure: if competing firms raise offers by 20% (plausible in a tight Austin market), the programme would need USD 1–2 M incremental annually to retain competitiveness, compressing equipment or partner budgets by 2–5%.

## Issue 7 - Characterization and Forensics Access: Partner Dependency and Queue-Time Risk
The Pragmatic Foundation strategy relies on university and national-laboratory partnerships for operando and post-mortem characterization (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy) to keep in-house instrument costs low. However, academic facilities have competing priorities, shifting schedules and occasional closures or staff departures. A 4–8 week queue at a partner facility would slow the design-build-test loop from 1–2 weeks (in-house) to 6–10 weeks, reducing the number of testable hypotheses per year by 50–75%. If a critical partner facility becomes unavailable (renovation, competing project priority, staff turnover), characterization would be outsourced to commercial labs at USD 50–100 K per failed cell, quickly exhausting a characterization budget.

**Recommendation:** Negotiate formal standing agreements with at least two university or national-laboratory characterization facilities by Month 3 (2027-01-14), specifying guaranteed access, turnaround (proposed: ≤3 weeks) and annual cost-sharing commitments (proposed: ≥15% of shared materials and characterization costs borne by partners). Invest in one core in-house post-mortem instrument (scanning electron microscope or X-ray diffraction: USD 2–3 M) by Month 6 (2027-04-14) for rapid triage of failed cells; outsource deeper operando work (operando XRD, in situ TEM) to partners with specialized equipment. Establish a forensics protocol by Month 3 (2027-01-14): every failed cell receives a standardized autopsy within one week of failure, with a structured root-cause report that feeds directly into the next design iteration. Develop a 'forensics atlas' (internal database of failure modes, their mechanisms and design consequences) by Month 12 (2027-10-14), so patterns across multiple cells can be identified and mitigated. Budget USD 2–3 M/year for commercial characterization services as a backstop if partner access is lost.

**Sensitivity:** Baseline: partner access with ≤3 week turnarounds, in-house triage capability, cost-sharing covered by partners. Downside scenario (loss of primary partner): if a key partner facility becomes unavailable at Month 18 (2028-04-14), outsourcing characterization at USD 80 K/cell for 50 cells/year would cost USD 4 M/year vs. ~USD 1.5 M with partner access, consuming USD 2.5 M/year additional budget (~6% of annual spend). Secondary scenario (queue delays): if partner queues extend to 6–8 weeks, the discovery loop slows to 1 hypothesis per 2 months instead of per 2 weeks, reducing annual hypothesis throughput by 50% and delaying identification of viable candidates by 3–6 months.

## Review conclusion
This battery-invention programme targets a 500 Wh/kg, 1000 Wh/L cell within a fixed USD 300 M, 7-year timeline through a staged chemistry tournament and risk-hedged operations. The Pragmatic Foundation strategy is sound in its emphasis on hedging chemistry risk with a formal gate and on imposing system-level (mass-and-volume) discipline early. However, five critical gaps emerge: (1) minimum cycle-life is undefined as a hard threshold until Month 6 (2027-04-14), risking months of wasted effort on non-functional cells; (2) volumetric density (1000 Wh/L) is subordinate to gravimetric density in discovery priorities, yet emerging as equally challenging; (3) site permitting and regulatory readiness are assumed complete by Month 3 (2027-01-14), but 6–8 month delays are plausible and would compress effective work time 5–10%; (4) the pilot-line ownership-versus-leasing decision is unresolved, risking either USD 30–50 M of sunk capital before chemistry is proven or prolonged queue times that slow discovery 50%; and (5) talent recruitment and retention rely on untested compensation models in a competitive Austin market and assume <15% attrition without concrete mechanics. The programme should: establish cycle-life and volumetric-density thresholds by Month 3 (2027-01-14); prioritize site permitting engagement in Month 0 (2026-10-14); commit to leased (not owned) pilot-line capacity by Month 1 (2026-11-14); pre-stage reserve chemistry contingencies by Month 24 (2028-10-14); and detail compensation, partnership agreements and governance by Month 2 (2026-12-14). The fixed USD 300 M budget is adequate only if early capital commitments (facility, pilot line, hiring) are controlled, permits are secured without major delays, and partner relationships provide cost-sharing and instrument access. A 20–30% overrun in any single area (permitting delays, pilot-line build, partner loss) would compress working capital by 5–15%, risking incomplete final validation or forced descent to a lower-ambition result (e.g., 480 Wh/kg instead of 500, or skipped abuse testing).