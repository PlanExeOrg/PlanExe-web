## Positive Constraints

- Invent a next-generation rechargeable battery that meets or beats the stated goals
- Primary goal: gravimetric energy density ≥ 500 Wh/kg
- Secondary goal: volumetric energy density ≥ 1000 Wh/L
- The goal is to invent a better battery
- Budget: USD 300 million
- Timeline: 7 years
- Location: near Tesla in Austin, Texas
- Project start as soon as possible (Month 0 = 2026-10-14)

## Negative Constraints

- Do not aim to become a major market-dominant industrial player
- Do not present invented numbers as facts; mark non-user, non-benchmark figures as '(proposed threshold)' or '(estimate)'
- Do not turn example values from input documents ('e.g. ...') into requirements
- Do not refer to the writer or its process (no 'I', 'my knowledge', 'I could not verify'); use impersonal planning-document voice
- Do not write calendar dates; refer to points in time as month offsets from project start (e.g. 'Month 3 = 2027-01-14')
