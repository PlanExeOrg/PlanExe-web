### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A USD 300 M, 7-year program whose only success test is a 500 Wh/kg and 1000 Wh/L energy-density figure, with market relevance explicitly disclaimed, aims at a number that cell makers already report and that is detached from the cycle life, cost and safety that determine whether a battery is better.**

**Bottom Line:** REJECT: The plan spends USD 300 M to chase an energy-density number that others already claim, with no durability, cost or adoption test and no reason tied to its Austin location.


#### Reasons for Rejection

- The headline target is not an open frontier: Amprius advertises 450 Wh/kg and 950 Wh/L commercial silicon-anode cells with third-party validation reported near 500 Wh/kg and 1,300 Wh/L, and Sion Power says its lithium-metal cells exceed 500 Wh/kg, so the 'invention' is largely a re-demonstration.
- The goal is stated as 'meets or beats' two energy-density figures (user constraint) with no cycle-life, power, calendar-life, cost or abort-safety criterion, so a few dozen-cycle pouch cell that dies on the bench would count as success while being useless as a battery.
- Disclaiming market relevance ('NOT to become a major market-dominant industrial player') removes the only test that separates a better battery from a laboratory record; the USD 300 M buys a result with no manufacturing, qualification or buyer behind it.
- Siting 'near Tesla in Austin' supplies no scientific input: the stated need is chemistry and cell-level invention, and the plan names no Tesla relationship, offtake, or access that proximity would create, so the location is a branding choice rather than a premise-bearing fact.
- A 7-year horizon at USD 300 M (user constraint) with a single-metric target invites the pattern seen in publicly funded programs: milestones are met on small, hand-built cells, while scaling and durability remain unresolved.

#### Second-Order Effects

- 0–6 months: Hiring and equipment orders concentrate on chemistries already known to reach 500 Wh/kg on paper (lithium-metal, silicon-dominant), while the team is pulled to the same Austin talent pool Tesla and other cell makers recruit from.
- 1–3 years: The program reports gravimetric milestones on 1 Ah-class pouch cells; because no durability or cost gate exists, internal incentives reward energy-density headlines over cycle count, and the gap to a usable product is hidden.
- 5–10 years: The program ends with a published 500 Wh/kg result and no owner for scale-up; IP sits with a non-commercial entity while incumbents with production lines ship comparable cells, leaving the USD 300 M as a record rather than a battery.

#### Evidence

- Case/Incident — DOE Battery500 Consortium (2016): USD 50 M, then USD 75 M for a second phase, targeted 500 Wh/kg with 1,000 cycles and reported roughly 350 Wh/kg with limited cycle life, showing cycle life, not initial energy density, was the binding constraint.
- Case/Incident — Amprius SiCore 450 Wh/kg cell launch (2025): a company already sells cells claiming 450 Wh/kg and 950 Wh/L, which undercuts the novelty of the plan's target.
- Case/Incident — Sion Power Licerion lithium-metal cells (2025): the company announced cells engineered to exceed 500 Wh/kg for defense and aerospace, with shipments expected in late 2026.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Invention By Invoice: the plan buys a discovery on a fixed budget and calendar (USD 300 M, 7 years) while naming a single cell-level number (500 Wh/kg) as success and explicitly disclaiming any path to use, so even a hit produces a spec-sheet entry and nothing a person can buy or rely on.**

**Bottom Line:** REJECT: Invention By Invoice treats a scientific breakthrough as a deliverable that can be ordered with money and a calendar, then removes the only mechanism, a product that must survive customers, that would show whether it worked. A number on a spec sheet is not a battery.


#### Reasons for Rejection

- Workers on a lithium-metal or similar high-energy pilot line, and neighbors of a lab in Austin, would carry fire and toxic-release risk for a programme that by its own statement has no intent to deliver a product, so their exposure buys nothing but a number.
- Success is defined only by the inventor's own gravimetric and volumetric figures, with no named independent test body, no cycle-life or safety pass mark, and no stated condition under which the programme is declared failed, so no one can be held to account for seven years of spending.
- A headline 500 Wh/kg result without durability invites a wave of copycat spec-sheet claims, and the USD 300 M, once spent on cell-building, cannot be recovered if the chemistry dies after a few dozen cycles.
- Siting the effort 'near Tesla' is rent-seeking on a neighbor's reputation and talent pool rather than a technical reason, and the goal of 'beating a number' while refusing to become a producer misallocates capital toward the one metric the industry has already shown to be the easy part.

#### Second-Order Effects

- **Months 0–12 (2026-10-14 to 2027-10-14) — The Poaching Spiral:** hiring in Austin pulls the same scarce cell engineers from neighbors and incumbents at inflated pay, so the budget is consumed by salaries before a single reproducible cell exists.
- **Months 12–36 (2027-10-14 to 2029-10-14) — The Demo Cell Trap:** hand-built cells hit the headline figure for a handful of cycles, the team reports it, and the programme is pressured to keep that number alive instead of testing what actually fails.
- **Months 36–84 (2029-10-14 to 2033-10-14) — The Orphan Chemistry:** with no commercial mandate by design, no manufacturer inherits the result, and the technology sits in a patent file while the market moves to cheaper, longer-lived cells.
- **Months 84+ — The Reckoning:** the programme is cited as a cautionary case for treating battery discovery as a procurement line item, and funders become warier of the next serious long-horizon materials effort.

#### Evidence

- Case/Report — The US DOE Battery500 consortium, launched in 2017 with the same 500 Wh/kg aim, reported lithium-metal pouch cells at about 350 Wh/kg with more than 350 cycles, and a PNNL cell retaining 76% of capacity after 600 cycles at 350 Wh/kg, i.e. a multi-institution programme was still short of 500 Wh/kg years in (https://chargedevs.com/newswire/battery500-consortium-steadily-increases-energy-density-and-cycle-life-of-li-metal-cells/).
- Case/Report — Amprius announced its SiCore cell in April 2025 at 450 Wh/kg and 950 Wh/L with a manufacturing-partner route to production, showing that the incumbent frontier is built by firms that commit to manufacturing, which this plan explicitly refuses (https://www.businesswire.com/news/home/20250424560971/en/Amprius-Launches-SiCore-450-Whkg-High-Energy-Cell-with-Near-Term-Mass-Production-Capability-to-Scale).
- Law/Standard — UN Manual of Tests and Criteria, Section 38.3 (lithium battery transport testing): any new high-energy cell must pass it before it can legally be shipped, and the plan names no budget line or owner for this gate (not verified for the plan's cell type).
- Narrative — Front-Page Test: 'USD 300 M spent near Tesla to build a battery nobody can buy, with no one responsible for the result' is the headline the plan's own scope statement writes.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] A $300M, seven-year hunt for 500 Wh/kg that specifies no cycle life, cost or manufacturability is a trophy chase for a number rivals already demonstrated.**

**Bottom Line:** REJECT: Spending USD 300M to chase a density number that rivals have already shipped, with no durability, cost or manufacturing criteria and no intent to scale, buys a press release rather than a battery.


#### Reasons for Rejection

- The headline target is already met: Amprius announced a 500 Wh/kg cell at 1C on conventional manufacturing equipment, with commercial availability expected Q4 2026, so a program that begins at Month 0 (2026-10-14) and runs to Month 84 (2033-10-14) 'inventing' that threshold is chasing a finished race.
- The success criteria are only gravimetric (≥500 Wh/kg) and volumetric (≥1000 Wh/L) density, with nothing on cycle life, power, safety or cost, so a cell that dies in a few dozen cycles would formally count as victory while being worthless as a battery.
- USD 300M over 84 months works out to roughly USD 3.6M per month (recomputed), which must fund materials discovery, cell engineering, pilot-scale pouch production and independent validation at once, a budget that is thin for each task and absurd for all of them together (estimate).
- Siting the lab near Tesla in Austin adds no technical value to electrochemistry research, and it exposes a small team to poaching by a far richer neighbour and to trade-secret disputes over any hire who crosses the fence.
- The stated aim of explicitly NOT becoming a market player leaves the invention with no path to manufacture, so a chemistry that works only in lab-built cells ends as an orphaned patent portfolio, because only scaled production proves a battery.

#### Second-Order Effects

- 0–6 months: Recruiting electrochemists and cell engineers in Austin collides with Tesla-adjacent employers, driving salary inflation and early retention fights that consume a visible share of the first-year budget (estimate).
- 1–3 years: Small-format prototypes post headline Wh/kg and Wh/L figures, while cycle life, swelling and safety data are absent from the goal, so the team redefines success mid-program and the original target becomes a formality.
- 5–10 years: By about Month 84 (2033-10-14) the USD 300M is spent, commercial rivals have shipped cells at or above 500 Wh/kg, and the program leaves behind papers and patents that no manufacturer has a reason to license.

#### Evidence

- Report/Guidance — Amprius SiCore500 product announcement (2026): a 500 Wh/kg cell at 1C on conventional lithium-ion lines, with commercial availability expected Q4 2026, shows the primary goal is not a new frontier.
- Report/Guidance — Sion Power Licerion-EV milestone release (2022): more than 2,500 cycles to 70% capacity, with an independently verified 400 Wh/kg and 780 Wh/L cell, shows the density figure alone is not what makes a battery usable.
- Case/Incident — OXIS Energy lithium-sulfur announcements (2020): the company reported 471 Wh/kg prototypes and targeted 500 Wh/kg by 2021 while still at an early technology readiness level, an example of density-first targets running ahead of a commercially viable cell.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**Strategic flaw: "invent a battery that beats 500 Wh/kg and 1000 Wh/L" is not a goal. It is two cell-level numbers with no cycle life, rate, safety, cost or customer attached, and a threshold that existing lab and niche-commercial cells already approach. A $300 M, 7-year program built on that spec will either "succeed" with a worthless cell or fail on every unstated dimension that actually defines a better battery.**

**Bottom Line:** Abandon the premise as written: a pair of energy-density numbers, already reached by others in lab or niche products, is not a definition of a better battery, and no budget or location fixes a target that omits cycle life, cost and application. The failure is in the goal itself, which is satisfiable by a useless cell and silent on everything that would make a cell worth inventing.


#### Reasons for Rejection

- The Two-Number Mirage: Wh/kg and Wh/L are the easiest battery metrics to hit and the least meaningful in isolation. Without a minimum cycle life, charge rate, temperature window, abuse-tolerance test or cost ceiling, a hand-built pouch cell that dies in a few dozen cycles satisfies the charter. The program can declare victory and still have invented nothing usable.
- The Already-Cleared Bar Paradox: a 500 Wh/kg cell has already been independently verified (Amprius silicon-anode, and Sion Power lithium-metal claims up to 500 Wh/kg). A project whose headline target is already met by others is not 'inventing' anything. Either it is a replication with a seven-year delay, or it silently needs the missing constraints (e.g., 500 Wh/kg AND long life AND low cost) that the plan never states.
- The Cell-vs-Pack Shell Game: gravimetric and volumetric density are unspecified as to cell, pack or system level, and as to whether measurement includes the stack pressure, thick-cathode and excess-lithium penalties that lithium-metal cells need to cycle. The same prototype can pass or fail depending on the accounting, and nothing in the plan defines the accounting.
- The Customer-Free Chemistry Bet: drones/HAPS, EVs and aviation want opposite trade-offs (a drone tolerates low cycle life and high cost; an EV does not). With no target application, there is no way to choose a chemistry, a form factor or a validation protocol. The team will optimize whatever is easiest to demonstrate.
- The Tesla-Adjacency Illusion: being 'near Tesla in Austin' buys no technology access. It buys a hot, bid-up local market for battery process engineers, a proximity that invites trade-secret and poaching disputes (estimate of risk, not verified), and a visible comparison against a company with in-house cell programs and manufacturing scale. Co-location is a recruiting cost center, not an asset, for a program that explicitly rejects industrial scale.
- The Seven-Year Single-Shot Problem: a fixed envelope (about USD 43 M/yr, recomputed from 300 M / 7) with one invention target invites early chemistry lock-in. The decisive failures in lithium-metal and silicon systems (dendrites, swelling, electrolyte consumption) appear only after many hundreds of cycles, i.e., after most of the money is already committed to a path.

#### Second-Order Effects

- Within Months 0-6 (2026-10-14 to 2027-04-14): the site, lease and hiring ramp absorb the first tranche before any success criterion exists. Without a defined test protocol, the team begins debating what counts as '500 Wh/kg' (cell vs. pack, beginning-of-life vs. cycled, C-rate) rather than building cells.
- Months 6-18 (2027-04-14 to 2028-04-14): the team picks a chemistry (lithium-metal, silicon, solid-state or hybrid) to hit the headline number fastest. Early coin-cell and small-pouch results look strong and become the internal narrative, while cycle life, gas evolution and swelling data are collected only on a handful of cells.
- Months 18-36 (2028-04-14 to 2029-10-14): scale-up from single-layer to multilayer pouch cells exposes the gap. Energy density falls as stack pressure, separators, tabs and packaging are added, and the cycle life that was never specified becomes the real wall. Salary pressure from Tesla and other Austin-area employers causes attrition among the process engineers who matter most.
- Months 36-60 (2029-10-14 to 2031-10-14): a mid-program re-scope is forced. The goal is either quietly relaxed (e.g., to 400-450 Wh/kg or to a short-life 'research cell') or redefined around a niche such as drones or HAPS where the target is already served commercially. Roughly half the budget (estimate) is spent by this point with no fielded cell.
- Months 60-84 (2031-10-14 to 2033-10-14): the program ends with a cell that is demonstrably 'record' on a narrow protocol but cannot be reproduced by an outside lab, cannot be built on standard equipment, and has no licensee. Intellectual property is stranded because no customer, cost model or manufacturing partner was ever part of the design brief.

#### Evidence

- DOE Battery500 Consortium (launched 2017 per available summaries): targeted up to 500 Wh/kg and 1,000 cycles in lithium-metal cells. Reported outcomes were about 350 Wh/kg with more than 600 stable cycles, and about 400 Wh/kg with only more than 100 cycles. The program started from 300 Wh/kg cells that cycled about 10 times, showing that density and life trade off sharply and that the density number alone is cheap.
- Amprius Technologies: an independent test lab verified a 500 Wh/kg silicon-anode cell (InsideEVs, 2022 report), and its SiCore 500 platform is described as reaching 500 Wh/kg at 1C on conventional lithium-ion equipment, with commercial availability expected Q4 2026, aimed at HAPS and long-endurance drones. The headline number is already commercial in a niche, so it cannot define a new invention.
- Sion Power Licerion: lithium-metal cells described as reaching up to 500 Wh/kg, with a 17 Ah cell independently verified at 400 Wh/kg and a 6 Ah EV cell exceeding 800 cycles. The gap between claimed peak density, verified density and cycle life in a large format is exactly the gap the plan leaves undefined.
- Austin-adjacent positioning: Tesla's cell activity in Texas is a proprietary manufacturing and materials operation (details of what is located where: not verified). No public mechanism gives a neighboring independent lab access to it, so the proximity premise has no documented precedent as a research advantage.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — Spec-Sheet Mirage: the plan defines "a better battery" as two energy-density numbers that have already been claimed on commercial datasheets, so a USD 300 M (user constraint) invention mandate is chartered to chase a headline figure while omitting every property (cycle life, safety, power, cost, manufacturability) that decides whether a cell is better at all.**

**Bottom Line:** REJECT: A USD 300 M (user constraint) charter to "invent" a battery by hitting two energy-density figures already claimed commercially, scored by its own authors and silent on life, safety, and cost, is a headline chase and not an invention. The gate is closed.


#### Reasons for Rejection

- Rights/dignity: a mandate that explicitly disclaims market relevance still places lithium-metal-class or silicon-class hazards in the hands of technicians, neighbors in an urban Austin research zone, and eventual test-flight or vehicle users, with no stated duty of care to any of them — the people who bear the thermal-runaway risk are given no voice in a goal defined purely by Wh/kg and Wh/L.
- Accountability/oversight: the only success criteria are two self-reported energy-density figures, so the program is both the author and sole judge of its own victory; without an externally binding test protocol, 'meets or beats' collapses into whichever cell, discharge rate, and temperature flatters the number.
- Systemic risk/scale: investing USD 300 M (user constraint) over 7 years in a single-chemistry moonshot concentrates all technical, schedule, and talent risk in one bet, and siting it beside Tesla's Texas operations pits it for scarce cell engineers against the best-funded manufacturer in the region, so attrition and poaching become a structural hazard rather than an incident.
- Value-proposition rot: the target is no longer frontier — Amprius has publicly reported silicon-anode cells above 500 Wh/kg and above 1,300 Wh/L, and the DOE Battery500 consortium has pursued the same 500 Wh/kg figure since 2017 — so 'invent a battery that meets these goals' is either a redundant rediscovery or a quiet bait-and-switch in which an unstated cycle-life, cost, or safety claim carries the real novelty.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Months 0-6 (2026-10-14 to 2027-04-14) are consumed by site fit-out, hiring against Austin's established battery employers, and procurement of dry-room and cell-assembly equipment; the first coin cells post impressive Wh/kg readings, and the absence of any agreed cycle-life or abuse-test gate is read internally as freedom rather than a defect.
- T+1–3 years — Copycats Arrive: Months 12-36 (2027-10-14 to 2029-10-14) bring hand-built pouch cells that touch 500 Wh/kg for a few dozen cycles, press releases that cite the headline figure, and rival labs and start-ups reproducing the same short-life demonstrations, which the 'meets the goal' framing rewards instead of exposing.
- T+5–10 years — Norms Degrade: Months 60-120 (2031-10-14 to 2036-10-14) see the program's own benchmark become field-standard shorthand; 'beats 500 Wh/kg' is cited without cycle count, rate, or temperature, funders and journals accept energy density alone as proof of invention, and safety and longevity data stop being demanded as a precondition of the claim.
- T+10+ years — The Reckoning: Beyond Month 120 (2036-10-14), the prototype family sits in a patent portfolio and a few demonstration packs because the cells that hit the number cannot survive the duty cycle, the 7-year budget (about USD 43 M per year, recomputed) is spent, and the lesson drawn is that the field optimized the wrong variable for a decade.

#### Evidence

- Case/Report — Amprius Technologies: the company has publicly reported silicon-anode cells exceeding 500 Wh/kg and 1,300 Wh/L (an independent test lab verification was reported by InsideEVs), meaning both stated targets already appear on a commercial datasheet and are not an open invention frontier.
- Case/Report — U.S. DOE Battery500 Consortium (launched 2017, led by Pacific Northwest National Laboratory): a multi-lab, multi-university program targeting 500 Wh/kg lithium-metal cells, whose reported milestones reached roughly 350-400 Wh/kg pouch cells with cycle lives in the tens to hundreds of cycles — showing that the hard problem is energy density sustained over life, not the peak number.
- Principle/Analogue — Goodhart's Law (economics/measurement): when a single metric becomes the target it ceases to be a good measure, so a program chartered around Wh/kg and Wh/L will optimize cells for the metric at the expense of longevity, safety, and manufacturability.
- Principle/Analogue — Battery engineering, energy-versus-cycle-life trade-off: higher gravimetric energy is typically obtained by thinner separators, leaner electrolyte, higher-capacity anodes and lithium-metal or silicon swelling, each of which shortens life and tightens thermal margins; a headline figure without paired cycle and abuse data conveys little.