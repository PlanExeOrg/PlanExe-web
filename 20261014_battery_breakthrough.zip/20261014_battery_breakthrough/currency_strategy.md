This plan involves money.

## Currencies

- **USD:** Primary currency for budgeting and reporting. User-specified budget constraint of USD 300 M over 7 years. All major capital equipment, facility lease, staff payroll and third-party testing will be denominated in USD. Simplifies accounting and aligns with US-based operations in Austin, Texas.
- **EUR:** Secondary currency for potential international procurement and partnerships. Equipment suppliers for specialized characterization instruments, pilot-line components and advanced materials often quote in EUR from European manufacturers. May be needed for university and national-laboratory partner arrangements outside the US.

**Primary currency:** USD

**Currency strategy:** All budgeting, financial reporting and burn-rate tracking will be conducted in USD, the user-specified primary constraint. Equipment and material procurement will be negotiated and paid primarily in USD; where EUR-denominated suppliers are required (e.g., specialized characterization instruments from European vendors), individual purchase orders will use spot exchange rates or fixed-price contracts to avoid currency volatility. International partnerships with universities and national laboratories will be structured to minimize multi-currency complexity; cost-sharing agreements will be denominated in USD with partner contributions valued at agreed rates. No hedging strategy is required given the domestic US focus and seven-year horizon; budget reserves will account for modest currency fluctuation on European capital purchases.