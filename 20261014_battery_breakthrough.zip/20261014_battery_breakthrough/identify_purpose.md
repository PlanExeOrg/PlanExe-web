**Purpose:** business

**Purpose Detailed:** Applied research and development programme to invent a breakthrough high-energy-density rechargeable battery technology (strategic R&D / technology development). The aim is technical invention and demonstration rather than becoming a market-dominant industrial player. Funding of USD 300 M over 7 years, with a site chosen near Tesla in Austin for talent and ecosystem access.

**Topic:** Invention of a next-generation rechargeable battery targeting at least 500 Wh/kg gravimetric and 1000 Wh/L volumetric energy density, with a USD 300 M budget over 7 years, located near Tesla in Austin, Texas