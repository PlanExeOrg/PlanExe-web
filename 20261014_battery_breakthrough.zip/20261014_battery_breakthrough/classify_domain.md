**Primary domain:** Battery Electrochemistry

**Secondary domains:** Materials Science, Battery Cell Engineering, Research Program Management

**Rationale:** Battery Electrochemistry is the only outcome-role candidate and owns the success criterion of inventing a ≥500 Wh/kg chemistry. Materials Science, Cell Engineering, Solid-State Ionics and Research Program Management are subordinate methods; Safety and IP are constraints.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Battery Electrochemistry | 5 | 5 | outcome | Inventing a ≥500 Wh/kg rechargeable chemistry is the core success criterion. |
| Materials Science | 4 | 4 | method | Novel electrode, electrolyte and interface materials discovery underpins energy density gains. |
| Battery Cell Engineering | 4 | 4 | method | Prototype cell design, fabrication and testing must demonstrate Wh/kg and Wh/L targets. |
| Battery Safety Engineering | 4 | 4 | constraint | High-energy-density cells face thermal runaway and abuse-tolerance certification constraints. |
| Solid-State Ionics | 4 | 4 | method | Ion transport in novel electrolytes and interfaces limits achieving 500 Wh/kg cells. |
| Research Program Management | 4 | 3 | method | Seven-year, USD 300 M R&D programme needs stage-gated technology development governance. |
| Battery Manufacturing Engineering | 3 | 4 | method | Pilot-line fabrication and scale-up needed to demonstrate cells reproducibly. |
| Computational Materials Discovery | 3 | 4 | method | Simulation and machine learning accelerate screening of high-energy electrode and electrolyte chemistries. |
| Intellectual Property Strategy | 2 | 3 | constraint | Invention-focused programme needs patent protection and freedom-to-operate analysis. |