## Suggestion 1 - Battery500 Consortium (US DOE, led by Pacific Northwest National Laboratory)

DOE Vehicle Technologies Office programme launched in 2016 to reach 500 Wh/kg lithium-metal pouch cells with 1,000 cycles at the cell level. Multi-university and national-lab consortium with a phase structure and a shared cell-fabrication and testing capability. Renewed for a second phase. Focused on lithium-metal anodes with high-nickel cathodes, electrolytes and cell engineering.

### Success Metrics

Reported pouch cells at roughly 350-500 Wh/kg-class levels with limited cycle life (approximate, not verified)
Publication output and patents across partner institutions
Standardized pouch-cell protocols used for cross-team comparison

### Risks and Challenges Faced

Cycle life collapse at high energy density: addressed via electrolyte and pressure-engineering research and a cell-level test standard.
Material-level numbers not transferring to cells: mitigated by common pouch-cell fabrication at the lead lab.
Coordination across many institutions: managed by a central leadership and thrust-area structure.

### Where to Find More Information

https://www.battery500.org
https://www.energy.gov/eere/vehicles/battery-500-consortium

### Actionable Steps

Contact the Battery500 consortium leadership via the website contact form (PNNL programme office).
Ask the PNNL battery group for cell-build protocol and pouch-cell metrics documentation.
Approach the DOE Vehicle Technologies Office battery R&D programme managers about gate design lessons.

### Rationale for Suggestion

Closest public analogue: same 500 Wh/kg cell-level target, pouch-cell proof standard and consortium partnering model. Lessons on cycle-life gates and shared fabrication directly inform the staged tournament and cycle-life threshold. Geographically distant (Washington State) but US-based.
## Suggestion 2 - Sion Power Licerion lithium-metal cell development (Tucson, Arizona)

Tucson-based company developing protected lithium-metal anode cells (Licerion) with lithium-sulfur heritage, targeting very high gravimetric energy density, with US DOE and other funding and a pilot-scale line. Demonstrates a layered protective-interface approach similar to the hybrid interlayer concept.

### Success Metrics

Publicly claimed cell energy density in the 400+ Wh/kg class (approximate, not verified)
Operation of a pilot line in Tucson
Multi-year development programme with customer and government funding

### Risks and Challenges Faced

Lithium dendrites and cycle life: mitigated through protective layer engineering.
Scaling from lab to pilot: addressed via a dedicated pilot production line.
Balancing energy density with cycle life across applications: managed by segmenting target markets.

### Where to Find More Information

https://sionpower.com
Company press releases and DOE ARPA-E / VTO project listings

### Actionable Steps

Contact Sion Power business development through the company website.
Request a technical briefing on protected lithium interface design and pilot-line lessons.
Explore a licensing or evaluation discussion through the corporate contact channel.

### Rationale for Suggestion

Southwest US organization with Li-S and lithium-metal heritage and a pilot line; a practical template for interface protection, pilot scaling and licensing-oriented operation. Limited public detail on cycle data, so verify claims directly.
## Suggestion 3 - Solid Power sulfide solid-electrolyte pilot programme (Colorado)

Colorado-based developer of sulfide solid electrolytes and all-solid-state cells, operating a pilot cell line and electrolyte production line, with automaker development partnerships (BMW, Ford) and a licensing-oriented model for cell designs and electrolyte supply.

### Success Metrics

Operating pilot electrolyte and cell lines (documented in company filings)
Automaker joint development agreements
Delivery of A-sample cells to partners for validation

### Risks and Challenges Faced

Dry-room and sulfide handling: addressed with dedicated dry-room line.
Stack-pressure and interface resistance: tackled via cell design and partner validation.
Path to commercialization without owning mass production: pursued through licensing and partner-manufacturing.

### Where to Find More Information

https://solidpowerbattery.com
SEC filings and investor presentations (company site)

### Actionable Steps

Contact the investor relations or business development team via the company site.
Request a discussion on pilot-line sizing and dry-room design.
Ask about licensing terms and technology-transfer structure.

### Rationale for Suggestion

Mirrors the anode-free/solid-state tournament entry and the invent-then-license model. Provides pilot-line and dry-room cost and timeline references, and a US-based licensing precedent.
## Suggestion 4 - Secondary: UT Austin Texas Materials Institute / Goodenough-lineage battery research

University of Texas at Austin battery materials research groups with solid-state and lithium-metal expertise and shared characterization facilities, located in the programme's own city.

### Success Metrics

Publication record in solid-state and lithium-metal materials (not verified in detail)
Availability of shared characterization facilities

### Risks and Challenges Faced

Academic queue times: negotiate priority agreements.
IP terms with universities: settle in advance.

### Where to Find More Information

https://tmi.utexas.edu
https://cockrell.utexas.edu

### Actionable Steps

Contact the Texas Materials Institute and the Cockrell School of Engineering research office.
Approach the UT Austin Office of Technology Commercialization on IP terms.

### Rationale for Suggestion

Secondary suggestion: local partner and talent pipeline rather than a completed analogue project.

## Summary

Reference projects for a USD 300 M (user constraint), 84-month programme targeting >=500 Wh/kg and >=1000 Wh/L cells near Austin. Selected for relevance to lithium-metal, solid-state and lithium-sulfur work, cell-level proof discipline, and stage-gated public R&D. Few Texas-local analogues exist; UT Austin (Goodenough lineage) is the closest. Figures are approximate and not verified unless stated; contact organizations or roles, not named individuals.