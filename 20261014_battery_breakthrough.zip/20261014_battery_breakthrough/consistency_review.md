## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Has the funder decided in writing how the payroll understatement (~USD 34 M over 7 yrs) and the ~USD 41 M Months 36-84 (2029-10-14 to 2033-10-14) carry-forward will be covered inside the USD 300 M hard cap (descope, hiring freeze, or a separately financed top-up)? | Bottom-up payroll at or below USD 12 M/yr (premortem A1 trigger; baseline USD 10 M/yr) AND an 84-month cash-flow model showing carry-forward at or above USD 5 M before Month 36 (2029-10-14) with USD 2-3 M free contingency intact; funder decision signed by Month 3 (2027-01-14) (not Month 6 = 2027-04-14). | Austin salary survey and bottom-up FTE roster (Month 2 = 2026-12-14); 84-month cash-flow model and funder decision letter (Month 3 = 2027-01-14); signed stop rule (Month 1-3 = 2026-11-14 to 2027-01-14). | Do not release T2 at Month 12 (2027-10-14) on the current scope: descope to 60-80 FTE or a hiring freeze after Month 36 (2029-10-14); if still unresolved by Month 12 (2027-10-14), run the premortem stop rule (two-chemistry reduced-scope programme). A top-up above USD 300 M is not available inside the user constraint and would need a separate funding decision. |
| 2 | Is Phase 1 permitted (or conditional-use authorised) with the leased modular line on site, and do regulators confirm lithium-metal synthesis and abuse chambers are not excluded from the Southeast Austin site? | Phase 1 approval by Month 4 (2027-02-14) at the latest (tripwire; baseline Month 3 = 2027-01-14); line on site by Month 4 (2027-02-14); Phase 2 reactive-synthesis permit by Month 8 (2027-06-14); first pouch build no later than Month 8 (2027-06-14); no regulator statement excluding reactive chemistry. | Pre-application meeting minutes with Austin Fire Authority/TCEQ (Month 0-1 = 2026-10-14 to 2026-11-14); signed pilot-line lease and standby agreement (Month 1-2 = 2026-11-14 to 2026-12-14); permit decision (Month 3-4 = 2027-01-14 to 2027-02-14). | Delay: activate outsourced synthesis (USD 2-5 M/yr, 4-6 week turnaround) and the partner standby line, re-baseline the Month 18 (2028-04-14) gate; effective work falls to 75-78 months. If Phase 2 is not granted by Month 12 (2027-10-14), relocate or move reactive work to partner facilities; if no pouch cells exist by Month 12 (2027-10-14), suspend T2 spend. |
| 3 | Are at least two university/national-lab characterization agreements signed with usable turnaround and cost share, plus a commercial backup lab? | >=2 signed 3-5 yr agreements by Month 3 (2027-01-14) with <=3 week turnaround (tripwire: >=28 days for 2 months) and >=15% partner cost share (tripwire: <10%); 30-60 day exit clauses; commercial backstop USD 2-3 M/yr. | Written capacity statements (Month 1 = 2026-11-14); signed MOUs/agreements (Month 3 = 2027-01-14); queue data from Month 4 (2027-02-14) onward; Month 12 (2027-10-14) checkpoint. | Downsize: fund the in-house post-mortem instrument (USD 2-3 M) first and route overflow to the commercial backup lab; if fewer than 2 channels sustain <=6 week turnaround by Month 12 (2027-10-14), descope to two active chemistries. |
| 4 | At the Month 18 (2028-04-14) gate, does at least one chemistry project >=500 Wh/kg and >=950 Wh/L at cell level on a model validated against measured pouch cells, with measured cycle-life data and safety ranking? | >=500 Wh/kg and >=950 Wh/L projected; model-to-measured discrepancy <=10%; measured (not projected) cycle data; candidates <250 cycles at 80% deprioritised from Month 24 (2028-10-14) unless within one 2-4 month redesign; thermal screening onset not <100 C. | Mass-and-volume model (Month 4 = 2027-02-14), pouch proxies and first builds (Month 6-12 = 2027-04-14 to 2027-10-14), Wh/kg mismatch report (Month 20 = 2028-06-14 as canonical; should be pulled earlier), gate review within 3 weeks (Month 18 = 2028-04-14). | Delay/split: withhold T3 (USD 70 M) for failing candidates, start an architecture sprint on Wh/L shortfalls, concentrate builds on the strongest two and pre-stage the reserve chemistry by Month 24 (2028-10-14). |
| 5 | Do third-party measured pouch cells (>=100 mAh, >=3 replicates) show >=500 Wh/kg AND >=950 Wh/L in the same cells with >=300 cycles at 80% and 90% of cells within +/-10%? | >=500 Wh/kg and >=950 Wh/L in the same cells, >=300 cycles at 80% retention, 90% of cells within +/-10%, measured by an accredited third-party lab. | Independent lab report (Month 30 = 2029-04-14); red-team replication; model reconciliation. | If only Wh/L fails: 6-month architecture sprint in Months 30-36 (2029-04-14 to 2029-10-14) (USD 8-15 M; with a pivot, USD 13-25 M vs the USD 15 M pivot runway). If cycle life or both targets fail: activate the pre-staged reserve chemistry (4-6 weeks) and prepare the Month 36 (2029-10-14) stop/descope decision. |
| 6 | At the Month 36 (2029-10-14) selection gate, does one finalist (including the reserve) meet the Month 30 (2029-04-14) thresholds plus thermal-runaway onset >=120 C and reversibility after overcharge, so T4 (USD 90 M) can be released? | Finalist meets all Month 30 (2029-04-14) thresholds, thermal onset >=120 C (candidates <100 C dropped), funding path for Months 36-84 (2029-10-14 to 2033-10-14) confirmed (~USD 41 M carry-forward), and licensee interest evidenced if the funder makes it a T4 condition. | Third-party abuse-test report, Month 30 (2029-04-14) data, sprint results (Months 30-36 = 2029-04-14 to 2029-10-14), funder confirmation of carry-forward and licensee status (Month 36 = 2029-10-14). | Stop or downsize: T4 is not released in full; the Steering Committee decides descope or stop. An un-staged pivot (6-10 months, first new cells Month 42-46 = 2030-04-14 to 2030-08-14) is not credible within 84 months. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive_summary / review_plan / self_audit
    canonical: total_budget_usd_m = USD 300 M total, hard cap (user constraint)
    observed:  budget top-up to USD 330-350 M
HIGH CF-002  document: executive_summary / review_plan / premortem FM1 / self_audit
    canonical: payroll_understatement_flag = ~USD 14.8 M/yr (+USD ~4.8 M/yr, ~USD 34 M over 7 yrs) vs USD 10 M/yr baseline; reserve USD 20 M incl. USD 15 M pivot runway
    observed:  reserves exhausted by Month 24-30 (2028-10-14 to 2029-04-14)
MEDIUM CF-003  document: canonical_facts / executive_summary / self_audit
    canonical: permitting_delay_fallback = 6-8 month permitting slip: operations start Month 6-9 (2027-04-14 to 2027-07-14); effective work 75-78 months
    observed:  Phase 1 approved Month 3 (2027-01-14) vs typical 6-8 months; first pouch builds Month 9-12 (2027-07-14 to 2027-10-14)
MEDIUM CF-004  document: canonical_facts mass_volume_model_milestones
    canonical: mass_volume_model_milestones = Wh/kg mismatch published by Month 20 (2028-06-14)
    observed:  validation at Month 20 (2028-06-14), after the Month 18 (2028-04-14) gate
MEDIUM CF-005  document: self_audit / review_plan
    canonical: month18_gate = projected >=500 Wh/kg and >=950 Wh/L, cycle-life data, safety ranking
    observed:  measured both targets in same cells by Month 18 (2028-04-14); no-go at Month 24 (2028-10-14)
MEDIUM CF-006  document: pitch Call to Action / premortem FM8
    canonical: month18_gate = pouch-cell build rate of 50-100/month reached by Month 24 (2028-10-14)
    observed:  reached at Month 18 (2028-04-14); <50/month tripwire at Month 12 (2027-10-14)
MEDIUM CF-007  document: pitch
    canonical: permitting_phases = Phase 1 Month 3 (2027-01-14); Phase 2 Month 6 (2027-04-14); Phase 3 Month 9 (2027-07-14); EHS lead Month 1 (2026-11-14)
    observed:  Phase 1 permitting begins Month 3 (2027-01-14); Phase 2 permitting begins Month 6 (2027-04-14)
MEDIUM CF-008  document: review_plan / self_audit
    canonical: opex_vs_tranche_gap = ~USD 41 M carry-forward from Months 0-36 (2026-10-14 to 2029-10-14) underspend (estimate)
    observed:  USD 34 M + USD 41 M = USD 75 M pressure; exhausted by Month 30 (2029-04-14)
MEDIUM CF-009  document: self_audit
    canonical: unallocated_reserve_usd_m = USD 20 M (6.7% of cap) inside the USD 300 M
    observed:  buckets of USD 10-15 M + 5-10 M + 10-15 M + 2-5 M
MEDIUM CF-010  document: review_plan Review 11 / premortem FM4
    canonical: capital_financing_ownership = partner in-kind and co-funding are off-budget and not counted toward the cap
    observed:  partner share reduces in-house opex; shortfall consumes the reserve
MEDIUM CF-011  document: premortem FM6 / self_audit item 18
    canonical: tranche_release_conditions = T4 at Month 36 (2029-10-14) on chemistry-selection gate (proposed threshold)
    observed:  T4 not released in full without licensee commitment; term sheet by Month 12/18/24 (2027-10-14, 2028-04-14, 2028-10-14)
```

### 1. Hard USD 300 M cap vs proposed USD 330-350 M top-up (🔴 High) — needs a project decision

- **Canonical facts total_budget_usd_m; executive_summary Timeline and Budget:** USD 300 M total, hard cap (user constraint); executive summary: 'USD 300 M fixed cap over 84 months'.
- **executive_summary Feedback and Takeaway; review_plan Review 1, 3, 9; self_audit items 6-7:** 'budget top-up to USD 330-350 M' offered as option A for the funder.
- **Why it conflicts:** The USD 300 M budget is a user constraint, yet the plan treats a USD 30-50 M increase as an in-plan option and ties T2 to it. Nothing says who would finance the extra money or whether the constraint can move.
- **Suggested resolution:** Treat the cap as binding. Present the funder with the real options: (A) stay at USD 300 M and descope (60-80 FTE, hiring freeze after Month 36 = 2029-10-14, or fewer chemistries); (B) a separately financed top-up, which breaches the user constraint and needs the user's/funder's explicit decision. Do not write the top-up as a planning assumption.

### 2. Funder budget decision deadline: Month 3 (2027-01-14) vs Month 6 (2027-04-14) (🔴 High)

- **executive_summary Risks, Action Orientation, Feedback; review_plan Review 9; premortem FM1:** 'funder decision on top-up vs. descope by Month 3 (2027-01-14)'; 'Obtain written decision by Month 3 (2027-01-14) before T2'; premortem tripwire: funder has not decided by Month 3 (2027-01-14).
- **executive_summary Timeline and Budget; review_plan Review 1 and Review 3 title:** 'funder decision ... by Month 6 (2027-04-14)'; 'request funder decision ... by Month 6 (2027-04-14)'.
- **Why it conflicts:** The same decision has two deadlines, one inside the Month 3 (2027-01-14) threshold-lock window and one three months later, with payroll/hiring commitments running in between. Month 6 (2027-04-14) is also after first hires and capital orders.
- **Suggested resolution:** Use Month 3 (2027-01-14) everywhere: the salary survey is due Month 2 (2026-12-14), the reforecast Month 3 (2027-01-14), and thresholds lock at Month 3 (2027-01-14). Month 6 (2027-04-14) can remain only as a hard backstop for implementation of the decision.

### 3. Reserve 'exhausted by Month 24-30 (2028-10-14 to 2029-04-14)' does not follow from the payroll overrun (🔴 High)

- **executive_summary Risks (3); review_plan Review 1, 11; premortem FM1; self_audit items 4, 6:** Payroll ~USD 4.8 M/yr over baseline 'exhausts reserves by Month 24-30 (2028-10-14 to 2029-04-14)'; 'USD 20 M reserve and USD 15 M pivot runway exhausted by Month 24-30 (2028-10-14 to 2029-04-14) against payroll drift alone'.
- **Canonical facts unallocated_reserve_usd_m, pivot_runway_usd_m, payroll_understatement_flag:** Reserve USD 20 M includes the USD 15 M pivot runway; USD 4.8 M/yr x 2-2.5 yrs = ~USD 10-12 M (recomputed), well under USD 20 M.
- **Why it conflicts:** At USD 4.8 M/yr, payroll drift alone would take ~4 years (about Month 50 = 2030-12-14) to consume USD 20 M, and the pivot runway is a subset of the reserve, not additional. The Month 24-30 (2028-10-14 to 2029-04-14) date and the 'reserve plus runway' sum overstate the burn. The total ~USD 34 M over 7 yrs does exceed the USD 20 M reserve by ~USD 14 M.
- **Suggested resolution:** Restate: payroll drift consumes ~USD 10-12 M by Month 30 (2029-04-14) (about half to 60% of the reserve) and ~USD 34 M by Month 84 (2033-10-14), i.e. ~USD 14 M more than the reserve; use only the USD 2-3 M free contingency as the near-term buffer. If an earlier date is intended, show the cash-flow model that produces it.

### 4. Phase 1 permit by Month 3 (2027-01-14) vs the plan's own 6-8 month permitting estimate (🟡 Medium) — needs a project decision

- **Canonical permitting_phases; executive_summary Action Orientation; self_audit items 14, 16:** Phase 1 submitted by Month 2 (2026-12-14) and approved by Month 3 (2027-01-14); self-audit mitigation asks for a '4-6 week review'.
- **review_plan Review 1 (2); self_audit items 14, 16; canonical permitting_delay_fallback:** 'Typical Texas hazardous-materials permitting takes 6-8 months'; realistic Phase 1 approval Month 8-10 (2027-06-14 to 2027-08-14); canonical fallback 'operations start Month 6-9 (2027-04-14 to 2027-07-14)' for a '6-8 month slip' (Month 3 = 2027-01-14 + 6-8 = Month 9-11 = 2027-07-14 to 2027-09-14).
- **Why it conflicts:** The base-case schedule assumes a review of about one month while the same documents call 6-8 months typical, so the 'baseline' is really the optimistic case. The fallback also mixes 'slip' and 'total duration': a 6-8 month slip on a Month 3 (2027-01-14) baseline gives Month 9-11 (2027-07-14 to 2027-09-14), not Month 6-9 (2027-04-14 to 2027-07-14); documents elsewhere use first pouch builds at Month 9-12 (2027-07-14 to 2027-10-14).
- **Suggested resolution:** Decide which timeline is the planning baseline: (a) Month 3 (2027-01-14) conditional-use/phased authorisation, to be confirmed in writing by regulators in Month 0-1 (2026-10-14 to 2026-11-14); or (b) a 6-8 month review with outsourced synthesis planned from Month 1 (2026-11-14). State the slip as total duration or as delay from baseline, not both; align operations-start and effective-work numbers to that definition.

### 5. Month 18 (2028-04-14) gate relies on a model that is validated only at Month 20 (2028-06-14) (🟡 Medium) — needs a project decision

- **Canonical month18_gate; pitch Call to Action; executive_summary:** Month 18 (2028-04-14) gate: go/no-go on projected >=500 Wh/kg and >=950 Wh/L from the live mass-and-volume model.
- **Canonical mass_volume_model_milestones; review_plan Review 3 (1); self_audit item 9:** Wh/kg mismatch published / model-to-measured discrepancy reconciled by Month 20 (2028-06-14); self-audit: model 'unvalidated until Month 20 (2028-06-14)'.
- **Why it conflicts:** The gate decision uses projections two months before the first formal check that the model matches measured cells, so the prerequisite follows the decision.
- **Suggested resolution:** Pull the model-to-measured reconciliation (<=10% discrepancy) ahead of the gate, e.g. via the 50-100 mAh pouch proxies at Month 12 (2027-10-14) and a published mismatch by Month 15-16 (2028-01-14 to 2028-02-14); keep Month 20 (2028-06-14) only for the refreshed report.

### 6. Volumetric criterion at Month 18 (2028-04-14): projected vs measured in same cells (🟡 Medium)

- **Canonical month18_gate, month30_verification; pitch Call to Action:** Month 18 (2028-04-14): projected >=500 Wh/kg and >=950 Wh/L; measured third-party pouch data in the same cells at Month 30 (2029-04-14).
- **self_audit item 2; review_plan Review 1 (3), Review 2 (2), Review 13 (3):** 'Require measured BOTH >=500 Wh/kg AND >=950 Wh/L from same pouch cells by Month 18 (2028-04-14), not deferred to Month 30 (2029-04-14)'; 'if no candidate meets dual targets by Month 24 (2028-10-14), halt non-finalists'; reviews call the volumetric gate 'deferred to Month 30 (2029-04-14)'.
- **Why it conflicts:** Documents disagree on whether Month 18 (2028-04-14) is a projection gate or a measured gate, and whether non-finalists are cut at Month 24 (2028-10-14) or one finalist at Month 36 (2029-10-14). The reviews also describe a Month 18 (2028-04-14) volumetric check as missing although the plan already has it as a projection.
- **Suggested resolution:** Keep canonical: Month 18 (2028-04-14) = projected >=950 Wh/L plus pouch-proxy evidence; Month 30 (2029-04-14) = third-party measured same-cell proof; Month 36 (2029-10-14) = single finalist. Rewrite the self-audit/review wording as an optional early proxy check, not a gate.

### 7. Pouch-build rate and yield milestones differ by month (🟡 Medium)

- **Canonical month18_gate; pitch Metrics; review_plan Review 13 (2):** Build rate of 50-100 cells/month reached by Month 24 (2028-10-14).
- **pitch Call to Action (Month 18 = 2028-04-14); premortem FM8, A2; review_plan Review 5 (2):** 'Month 18 (2028-04-14): pouch-cell build rate 50-100/month reached'; tripwire 'builds < 50 per month at Month 12 (2027-10-14)'; A2 'sustain 50-100 cells/month at >=90% yield' from Month 3 (2027-01-14); Review 5 'through Month 36 (2029-10-14)'.
- **Why it conflicts:** The same capacity milestone is set at Month 3, 12, 18 and 24 (2027-01-14, 2027-10-14, 2028-04-14, 2028-10-14), and the yield target (>=90%) appears as both a commissioning condition and a Month 24 (2028-10-14) target while a tripwire uses 80% at Month 12 (2027-10-14).
- **Suggested resolution:** Use the canonical Month 24 (2028-10-14) for 50-100 cells/month and >=90% defect-free; define interim ramp tripwires (e.g. Month 12 = 2027-10-14 rate and 80% yield) explicitly as ramp checkpoints, and remove 'Month 18 (2028-04-14) reached' from the pitch.

### 8. Pitch call-to-action milestones ahead of or behind canonical schedule (🟡 Medium)

- **Canonical preferred_site_area, permitting_phases, partner_and_characterization_access, currency_contingency:** Lease executed by Month 1 (2026-11-14); EHS lead hired Month 1 (2026-11-14); >=2 partner agreements by Month 3 (2027-01-14); Phase 1 permit by Month 3 (2027-01-14); Phase 2 permit by Month 6 (2027-04-14); equipment contracts Months 2-6 (2026-12-14 to 2027-04-14).
- **pitch Call to Action; executive_summary Action Orientation (1):** Month 0 (2026-10-14): secure lease, hire EHS lead; Month 1 (2026-11-14): sign >=2 partner agreements; Month 2 (2026-12-14): equipment vendors locked; Month 3 (2027-01-14): 'Phase 1 permitting begins'; Month 6 (2027-04-14): 'Phase 2 permitting begins'. Exec summary: EHS lead hire 'by Month 2 (2026-12-14)'.
- **Why it conflicts:** Permitting is shown as starting at the month by which the permit should already be granted, and the lease, hires and agreements are pulled earlier than the canonical dates. The pitch also lists gates at Months 18 and 36 (2028-04-14, 2029-10-14) only, omitting Month 30 (2029-04-14), and says 'standing agreements with MIT, NREL, Argonne' as if signed.
- **Suggested resolution:** Align the pitch to canonical dates: submit Phase 1 by Month 2 (2026-12-14), granted by Month 3 (2027-01-14); Phase 2 granted by Month 6 (2027-04-14); lease by Month 1 (2026-11-14); EHS lead Month 1 (2026-11-14); agreements by Month 3 (2027-01-14); gates at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14); describe partner agreements as targets.

### 9. Payroll overrun and carry-forward added together as 'USD 75 M pressure' (🟡 Medium)

- **Canonical opex_vs_tranche_gap:** Carry-forward ~USD 41 M is a timing gap: Months 36-84 (2029-10-14 to 2033-10-14) opex ~USD 32.9 M/yr vs tranche USD 22.5 M/yr, funded by Months 0-36 (2026-10-14 to 2029-10-14) underspend within the cap.
- **review_plan Review 2 (3), Review 11 (2), KPI 3; self_audit item 20:** 'Payroll overrun (USD 34 M) and opex carry-forward gap (USD 41 M) sum to USD 75 M pressure against USD 300 M'; 'carry-forward is exhausted by Month 30 (2029-04-14)'; elsewhere the shortfall 'appears by Month 48-54 (2030-10-14 to 2031-04-14)'.
- **Why it conflicts:** The carry-forward is a cash-timing transfer inside the 300 M, not an extra cost, so adding it to the payroll overrun double-counts. A balance that is built up until Month 36 (2029-10-14) cannot be 'exhausted by Month 30 (2029-04-14)' and also first short at Month 48-54 (2030-10-14 to 2031-04-14).
- **Suggested resolution:** Separate the two: payroll drift is a real USD ~34 M cost; carry-forward is a mechanism that requires unspent tranche cash to be rolled forward (see tranche rules). Give one consistent date for when the carry-forward balance would run out, from the 84-month cash-flow model.

### 10. Reserve buckets proposed in self-audit exceed the USD 20 M reserve (🟡 Medium)

- **Canonical unallocated_reserve_usd_m, pivot_runway_usd_m, free_contingency_after_reserves_usd_m:** Unallocated reserve USD 20 M (incl. USD 15 M pivot runway; USD 5 M general of which USD 2-3 M FX; USD 2-3 M free).
- **self_audit item 4 mitigation:** Split reserve into payroll USD 10-15 M, permitting/EHS USD 5-10 M, pivot/sprint USD 10-15 M, free general USD 2-5 M (= USD 27-45 M).
- **Why it conflicts:** The proposed buckets total USD 27-45 M, up to more than double the USD 20 M reserve inside the cap, and re-allocate the ring-fenced USD 15 M pivot runway.
- **Suggested resolution:** Keep the canonical split (USD 15 M pivot runway, USD 5 M general incl. USD 2-3 M FX). Any additional bucket needs a funder decision on what is cut elsewhere or what is descoped.

### 11. Partner co-funding is off-budget but reviews treat it as an opex offset (🟡 Medium)

- **Canonical capital_financing_ownership, partner_cofunding_floor:** Partner in-kind and co-funding are off-budget and not counted toward the cap; floor >=15% of shared costs, est. USD 0.5-1 M/yr.
- **review_plan Review 11 (3); premortem FM4:** Partners' >=15% share 'reduces in-house opex burden'; shortfall 'adds USD 3.5-7 M over 84 months, consuming half the USD 20 M reserve'; co-funding below 15% 'leaves cost on-budget'.
- **Why it conflicts:** If co-funding is outside the budget, its shortfall does not raise programme opex unless the programme chooses to buy replacement services; the reviews count it as budgeted income. Review 11 also mixes a 7-year total with 'over 84 months' as two different framings of the same range.
- **Suggested resolution:** Follow canonical: do not net partner co-funding against the budget. Treat a shortfall as a risk that triggers the USD 2-3 M/yr commercial backstop, and size that backstop explicitly within the USD 135 M experiments line.

### 12. What conditions T4 release and what licensee milestones apply (🟡 Medium) — needs a project decision

- **Canonical tranche_release_conditions, programme_stop_rule, ip_milestones; pitch:** T4 on the chemistry-selection gate; stop rule only if no chemistry meets Month 30 (2029-04-14) thresholds by Month 36 (2029-10-14). Licensee contacts Month 12 (2027-10-14); licensing framework Month 24 (2028-10-14).
- **premortem FM6, FM9, FM3; self_audit item 18; review_plan Review 2 (1), Review 9 (2):** 'No licensee commitment at Month 36 (2029-10-14) -> do not release T4 in full'; funder stop rule signature as a gate; licensee term sheet due Month 12 (2027-10-14) (self-audit, review 9), Month 18 (2028-04-14) (FM3 early warning) or 'locked by Month 24 (2028-10-14)' (pitch, review 2).
- **Why it conflicts:** A licensee commitment is made an extra T4 condition in one document and not in the canonical conditions, and its due date is Month 12, 18 or 24 (2027-10-14, 2028-04-14, 2028-10-14). Funders and the team cannot tell whether T4 hinges on technical data only or also on a licensee.
- **Suggested resolution:** Decision needed: either (a) T4 depends only on the technical gate (canonical) and licensee progress is a reported milestone: non-binding term sheet by Month 12 (2027-10-14), licensing framework and commitment by Month 24 (2028-10-14); or (b) licensee commitment becomes a formal second T4 condition, which must be added to the canonical conditions and funder agreement.

## Summary

The plan is largely consistent on the core structure: the USD 300 M envelope, the 60/80/70/90 tranches, 84 months, the three gates and the 500 Wh/kg / 1000 Wh/L targets. The inconsistencies are concentrated in the funding story (a USD 330-350 M top-up against a hard cap, two funder-decision deadlines, a reserve-exhaustion date that does not follow from the payroll arithmetic, and double-counted carry-forward) and in schedule details (permitting baseline, model validation after the Month 18 = 2028-04-14 gate, build-rate milestones, pitch dates). Most are repairable text fixes to canonical values. The real open decisions are how any funding gap beyond USD 300 M is financed or descoped, which permitting baseline to plan on, and whether a licensee commitment is a T4 condition.