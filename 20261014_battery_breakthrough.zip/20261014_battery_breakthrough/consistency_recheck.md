_Consistency: first pass found 2 high / 6 medium / 0 low contradictions. Repair: round 1: 28 edits → 1 high / 5 medium; round 2: 20 edits → 0 high / 7 medium. Published: round 2 (fewest high-severity issues). Shown below: the final check of the repaired documents (0 high / 7 medium / 2 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Has the funder signed a written decision on the payroll and carry-forward gap that keeps the programme inside the USD 300 M cap and 84 months? | Bottom-up payroll reforecast at or below USD 12 M/yr (premortem A1 trigger; baseline USD 10 M/yr), and a written carry-forward arrangement covering ~USD 41 M for Months 36-84 (estimate), with no draw on the ring-fenced USD 15 M pivot runway before Month 36. | Austin salary survey and 84-month cash-flow model by Month 2; funder decision and signed stop rule by Month 3 (hard backstop Month 6). | Do not release T2 as planned. Descope (60-80 FTE or fewer active chemistries) or request a cap change, which is a user-constraint decision. FM1 stop rule: if the funder has not decided by Month 12, move to a two-chemistry reduced-scope programme. |
| 2 | Are at least two university/national-laboratory agreements signed with <=3 week turnaround, >=15% cost-share and 30-60 day exit clauses? | >=2 signed 3-5 year agreements by Month 3; partner cost share >=10% (tripwire below that) and quoted turnaround <=4 weeks; backup commercial lab contracted. | Signed MOUs and written capacity statements (requested Months 0-1, executed by Month 3); first 2 months of measured turnaround data. | Delay the Month 18 data window or fund the in-house post-mortem instrument and commercial backstop (USD 2-3 M/yr) from the general reserve; if fewer than 2 channels sustain <=6 weeks by Month 12, descope to two active chemistries (FM4). |
| 3 | Is the Phase 1 permit granted and the leased pilot line on site, with no restriction excluding reactive chemistry from the site? | Phase 1 permit approved and line on site by Month 4; first pouch builds by Month 8; Phase 2 reactive-synthesis permit by Month 8 (tripwire) and no later than Month 12. | Regulator pre-application minutes (Month 0), permit decisions, signed lease (Month 1) and commissioning acceptance test (dew point at or below -30 C). | Activate pre-contracted external synthesis (USD 2-5 M/yr, 4-6 week turnaround) and standby line, re-time the Month 18 gate, and hold T2 spend. If no pouch cells exist at Month 12, suspend T2 and re-plan. If the Phase 2 permit is not granted by Month 12, relocate or move reactive work to partner facilities. |
| 4 | At Month 12, is the line building cells at the ramp checkpoint, with the cell model live and the cycle-life and Wh/L criteria signed, so T2 can be released? | T2 conditions: lease, Phase 1 permit, live mass-and-volume model (Month 4), criteria locked. Ramp checkpoint: >=25 cells/month and >=80% yield (proposed); >=6 provisionals filed by Month 12. | Build logs, model validation report, signed Steering Committee criteria decision, patent filing record. | Withhold or stage T2 (USD 80 M); re-baseline the critical path and shift the Month 18 gate. A persistent miss triggers the FM2 stop rule. |
| 5 | At the Month 18 gate, does at least one chemistry project >=500 Wh/kg and >=950 Wh/L at cell level with acceptable measured cycle data and safety ranking? | Projected >=500 Wh/kg and >=950 Wh/L per chemistry (model validated against measured pouch proxies); measured cycle data trending toward >=300 cycles at 80% (candidates <250 cycles deprioritized from Month 24); thermal-runaway onset not below 100 C. | Pouch-proxy data and model reconciliation (Month 20 mismatch report), forensics atlas, red-team replication, abuse-test results (Months 6-12 contracted tests). | Deprioritize failing candidates; activate the pre-staged reserve chemistry (4-6 weeks if staged by Month 24); withhold T3 (USD 70 M) from non-passing candidates; run the architecture sprint only if Wh/kg is met and Wh/L is short. |
| 6 | At Months 30-36, do third-party measured pouch cells meet all selection thresholds so T4 can be released? | >=100 mAh pouch cells, >=3 replicates, >=500 Wh/kg AND >=950 Wh/L in the same cells, >=300 cycles at 80%, 90% of cells within +/-10%, thermal-runaway onset >=120 C and reversible after overcharge. | Accredited third-party report at Month 30; red-team replication; selection gate at Month 36. | If only Wh/L is short, run the 6-month sprint (Months 30-36) before selection. If no chemistry (including reserve) qualifies by Month 36, T4 (USD 90 M) is not released in full and the Steering Committee decides descope or stop. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: executive summary, Review 1/3/9/11, self-audit #6/#7
    canonical: total_budget_usd_m = USD 300 M total, hard cap (user constraint)
    observed:  top-up to USD 330-350 M; descope with longer timeline; external co-funding bridge
HIGH CF-002  document: executive summary / Review 1, 6, 8, 11 / pitch
    canonical: free_contingency_after_reserves_usd_m = USD 2-3 M free general reserve; USD 15 M pivot runway ring-fenced and not free
    observed:  drift USD 10-12 M by Month 30 and ~USD 34 M by Month 84 absorbed by 'reserve'; triggers USD 12 M vs USD 13+ M/yr; free contingency '<USD 5 M'
MEDIUM CF-003  document: premortem A1/FM1, Review 2/11
    canonical: opex_vs_tranche_gap = Average opex ~USD 32.9 M/yr vs tranche USD 22.5 M/yr; ~USD 41 M carry-forward (estimate)
    observed:  carry-forward trigger USD 5 M; USD 41 M treated as independent of payroll drift
MEDIUM CF-004  document: Review 1 #2/Review 8/self-audit #5, #14, #16
    canonical: permitting_delay_fallback = operations start Month 6-9; effective work 75-78 months (estimate)
    observed:  approval Month 8-10; startup Month 9-12; effective work 76-78 or 66-72 months
MEDIUM CF-005  document: Review 1/2/4/5/13/16
    canonical: volumetric_sprint = 6-month architecture sprint Months 30-36 before the selection gate
    observed:  sprint Months 18-24 or Months 15-21; Month 18 'verification' as a new gate
MEDIUM CF-006  document: premortem FM6 / Review 2 / self-audit #18 / pitch
    canonical: tranche_release_conditions = T4 at Month 36 on chemistry-selection gate; licensee contacts Month 12; framework Month 24
    observed:  licensee commitment as T4 condition; term sheet at Month 12/18/24
MEDIUM CF-007  document: Review 6 KPI 2 / Review 15
    canonical: cycle_life_deprioritization = >=300 cycles at 80%; <250 deprioritized unless within one 2-4 month redesign
    observed:  fade <0.20%/cycle; 2-4 week redesign sprint
MEDIUM CF-008  document: executive summary / self-audit #10, #17 / Review 10
    canonical: permitting_phases = EHS lead hired Month 1; partner agreements by Month 3
    observed:  EHS lead by Month 2; MOUs by Month 1 or Month 2
MEDIUM CF-009  document: Review 5 #2 / Review 8 #3
    canonical: month18_gate = pouch-cell build rate of 50-100/month reached by Month 24 (proposed threshold)
    observed:  50-100 cells/month at >=90% yield sustained from Month 3
LOW CF-010  document: self-audit #9 / Review 13
    canonical: mass_volume_model_milestones = model Month 4; projections Month 6; mismatch published Month 20
    observed:  +/-5% reconciliation target; model unvalidated until Month 20
LOW CF-011  document: Review 10 #1
    canonical: budget_allocation_estimate_usd_m = facility lease/utilities USD 25 M (estimate)
    observed:  line consumed by Month 18-24
```

### 1. Hard USD 300 M cap / 84 months vs funder options (top-up, longer timeline, external co-funding) (🔴 High) — needs a project decision

- **Canonical facts; project plan Goal Statement:** USD 300 M total is a hard cap and 84 months is the duration (user constraints); co-funding is off-budget and there is no revenue or debt.
- **Executive summary (Timeline and Budget, Feedback); Review 1, 3, 9, 11; Self-audit #6, #7; Premortem FM1:** Funder is asked to choose a top-up to USD 330-350 M, a descope 'lower cost, longer timeline', or external co-funding to bridge the carry-forward gap.
- **Why it conflicts:** A top-up breaks the cap and a longer timeline breaks 84 months. External co-funding conflicts with the 100% grant-funded chain and the rule that partner co-funding is not counted toward the cap. No document says who would pay the extra USD 30-50 M or whether the constraints can move.
- **Suggested resolution:** Keep USD 300 M and 84 months as fixed. Present the funder only with options inside the constraints (descope FTE or chemistries, hiring freeze, re-phasing within the cap). Treat a top-up or timeline change as an explicit user decision, with the source of funds stated, not as a baseline mitigation.

### 2. Payroll drift vs ring-fenced pivot runway, 'free contingency' and payroll triggers (🔴 High) — needs a project decision

- **Canonical facts; executive summary Overall Takeaway; pitch Risks:** USD 15 M pivot runway is ring-fenced until the Month 36 gate; free general reserve is only USD 2-3 M; the exec summary lists the pivot runway and USD 2-3 M free contingency as protected contingencies.
- **Executive summary Risks; Review 1, 8, 11; Review 6 KPI 3; Premortem A1/FM1; Self-audit #20:** Payroll drift consumes ~USD 10-12 M of the USD 20 M reserve by Month 30 and ~USD 34 M by Month 84; the exec summary offers no source for the USD ~14 M beyond the reserve. Trigger levels differ: USD 12 M/yr (premortem A1, FM1), USD 13+ M/yr (KPI 3), range 'USD 12-15 M' / '13-15 M'.
- **Why it conflicts:** With only USD 5 M of general reserve, USD 10-12 M of drift necessarily eats into the ring-fenced runway (leaving ~USD 8-10 M, recomputed) and drives free contingency to zero, so the runway cannot also fund the pivot and sprint (USD 13-25 M). Payroll triggers and ranges differ and do not match the canonical range (USD 12.9-16.6 M, midpoint USD 14.8 M). KPI 3's '<USD 5 M free contingency' also exceeds the canonical USD 2-3 M free amount.
- **Suggested resolution:** State one payroll trigger (the premortem's USD 12 M/yr) and one range (USD 12.9-16.6 M, estimate). State that payroll drift is not funded from the ring-fenced runway: it requires a funder decision, descope or underspend. Remove 'free contingency' from the list of protections once drift occurs. Note that the pivot runway is ring-fenced until Month 36, not released at Month 30 (pitch wording 'if a finalist survives Month 30').

### 3. Carry-forward size under payroll drift, 5 M trigger and financing mechanism (🟡 Medium)

- **Canonical facts; Review 2, 6 (KPI 3), 11:** Carry-forward requirement is ~USD 41 M for Months 36-84 (avg opex ~USD 32.9 M/yr vs tranche USD 22.5 M/yr).
- **Premortem A1/FM1; Review 2 Interaction; Review 11 #2:** Same documents add USD 4.8 M/yr payroll drift as a separate item and set tripwires at 'carry-forward below USD 5 M' (A1, FM1 at Month 24). Roll-forward of unspent tranche cash is described as undefined.
- **Why it conflicts:** Recomputed: at USD 14.8 M/yr payroll the Months 36-84 gap is ~USD 15.2 M/yr x 4 = ~USD 61 M, not USD 41 M, so the two are not independent. A USD 5 M trigger cannot monitor a USD 41-61 M need, and the date at which the balance runs out is left blank.
- **Suggested resolution:** Show the carry-forward as USD ~41 M at baseline payroll and ~USD 61 M at the USD 14.8 M/yr scenario (recomputed, estimate). Set the tripwire as 'forecast carry-forward below the required amount', and fix the roll-forward mechanism in the funder agreement by Month 3. Do not rely on external co-funding.

### 4. Phase 1 permit review time and slip values (🟡 Medium)

- **Canonical facts; project plan; pitch Call to Action; Self-audit #14, #16:** Phase 1 submitted by Month 2 and granted by Month 3 (self-audit asks for a 4-6 week review); permit slip yields operations start at Month 6-9.
- **Review 1 #2; Review 2 and FM2; Self-audit #5, #14, #16; Review 8 #3:** 6-8 months typical review gives approval at Month 8-10; pilot-line startup or first builds at Month 9-12; effective work 76-78 months (self-audit) or 66-72 months (Review 8).
- **Why it conflicts:** The base case assumes about one month of review while the same documents call 6-8 months typical. The same slip event is dated Month 6-9, Month 8-10 and Month 9-12, and effective work is 75-78, 76-78 or 66-72 months.
- **Suggested resolution:** Keep the canonical range: operations start Month 6-9 and effective work 75-78 months. Label Month 9-12 as the first-build date if the line also slips. State that the Month 3 Phase 1 approval is a best case contingent on conditional-use authorization. Keep the 66-72 months figure only as a labelled compound stress case.

### 5. Volumetric verification timing and sprint window (🟡 Medium)

- **Canonical facts; pitch; Executive summary:** Month 18 gate uses projected >=950 Wh/L; measured third-party proof at Month 30; volumetric sprint is Months 30-36 before the selection gate.
- **Review 1 #3, Review 2 #2, Review 4 #3, Review 5 #3, Review 13 #3, Review 16:** Reviews say Wh/L verification is 'deferred to Month 30' and propose advancing it to Month 18 with sprints at Months 18-24 (Review 1, 13) or Months 15-21 (Review 4, 5), while Review 2 and Review 6 still use Months 30-36.
- **Why it conflicts:** Four different sprint windows are given. The Months 18-24 and 15-21 windows overlap the Month 24 deprioritization and reserve-staging, and use up pivot runway before the Month 36 ring-fence ends. Month 18 already includes a volumetric projection, so 'missing' is inaccurate.
- **Suggested resolution:** Keep the canonical design: projected Wh/L at Month 18, optional pouch-proxy check (50-100 mAh) that is not a gate, measured proof at Month 30, sprint Months 30-36. Remove or label the Months 15-24 sprint windows as optional early checks funded from the same USD 13-25 M stress envelope.

### 6. T4 conditions and licensee commitment due date (🟡 Medium)

- **Canonical facts; pitch Month 36 entry:** T4 releases on the Month 36 chemistry-selection gate (technical thresholds); licensee contacts from Month 12 and licensing framework by Month 24.
- **Premortem FM3/FM6; Review 2 #1, Review 9 #2; Self-audit #18; Pitch metrics:** No licensee commitment at Month 36 means T4 is not released in full (FM6); selection tied to licensee interest (Review 2); licensee term sheet due Month 12 (self-audit #18, Review 9), Month 18 (FM3, FM6), Month 24 (pitch, Review 2).
- **Why it conflicts:** A licensee condition is added to T4 that is not in the canonical conditions, and the same commitment has three due dates (Months 12, 18, 24). The funder cannot tell whether T4 depends on technical data only.
- **Suggested resolution:** Keep T4 on the technical selection gate and the stop rule only. Treat licensee contact at Month 12 and the framework at Month 24 as separate non-tranche milestones. If a licensee condition on T4 is wanted, it needs an explicit funder decision with one date.

### 7. KPI fade rate and redesign window inconsistent with the cycle-life threshold (🟡 Medium)

- **Canonical facts; Review 6 KPI 2 (target):** >=300 cycles at 80% capacity retention; deprioritize <250 cycles unless within one 2-4 month redesign.
- **Review 6 KPI 2; Review 15 #1:** KPI 2 pairs it with 'fade <0.20%/cycle' and a '2-4 week redesign sprint'; Review 15 also describes closure within 2-4 weeks.
- **Why it conflicts:** Fade of 0.20%/cycle reaches 80% retention in about 100 cycles (recomputed), so the KPI would pass cells that fail 300 cycles; 80% at 300 cycles means <=~0.067%/cycle. The redesign window is a factor of ~4 shorter than canonical.
- **Suggested resolution:** Use <=0.067%/cycle (equivalent to 80% at 300 cycles, recomputed) or drop the rate, and use a 2-4 month redesign window.

### 8. Deadlines for EHS lead, partner agreements and pilot-line lease (🟡 Medium)

- **Canonical facts; project plan; pitch:** EHS lead hired Month 1; >=2 partner agreements by Month 3; pilot-line lease signed Month 1, partner standby Month 2.
- **Executive summary Action Orientation; Self-audit #10, #17; Review 10 #2:** Exec summary: 'EHS lead hire ... by Month 2'; Self-audit #10: MOUs by Month 1; Self-audit #17: partner agreements and pilot-line lease by Month 2; Review 10: capacity commitments by Month 2.
- **Why it conflicts:** The same milestones carry Month 1, 2 and 3 dates, so owners cannot tell which is binding; the Month 2 EHS date postpones the lead needed for the Month 2 Phase 1 submission.
- **Suggested resolution:** Use canonical dates: EHS lead Month 1; lease Month 1; standby line Month 2; partner agreements Month 3 (written capacity statements by Month 1 as pre-work).

### 9. Pilot-line throughput and yield required from Month 3 vs ramp to Month 24 (🟡 Medium)

- **Canonical facts; Premortem A2/FM2/FM8; Pitch metrics:** Line on site Month 3, first builds Month 6, interim checkpoint 25-50 cells/month at >=80% yield at Month 12, 50-100 cells/month at >=90% yield by Month 24.
- **Review 5 #2; Review 8 #3:** Line 'sustains 50-100 cells/month with <7 day turnaround and >=90% yield' and is assumed with those specs 'by Month 3'.
- **Why it conflicts:** The same full-rate capacity and yield are demanded at Month 3 (before first builds at Month 6) and as a Month 24 target, and 90% yield is also a lease guarantee. The Month 12 ramp checkpoint does not appear in these reviews.
- **Suggested resolution:** Keep the ramp: commissioning acceptance by Month 3 (dew point, first article), first builds Month 6, 25-50 cells/month and >=80% yield at Month 12 (proposed), 50-100 cells/month and >=90% by Month 24. Rewrite lease guarantees to the ramp.

### 10. Model reconciliation tolerance and validation after the gate that uses it (⚪ Low)

- **Canonical facts; Premortem A3; Review 3 #1; Review 6:** Model live Month 4, projections Month 6, Month 18 gate on projected values; mismatch published Month 20; tolerance <10% (A3, Review 3, KPI 1).
- **Self-audit #9; Review 13 #1:** Technical specification requires a +/-5% reconciliation target; model 'unvalidated until Month 20' while the gate at Month 18 relies on it.
- **Why it conflicts:** Two tolerances (<10% vs +/-5%) are in force, and the first formal match to measured cells comes two months after the gate that uses the projections.
- **Suggested resolution:** Use one tolerance (<10%, with escalation above 10%) and require a validation against pouch proxies before the Month 18 gate (by Month 12-15), keeping Month 20 as the published mismatch report.

### 11. Facility lease overrun arithmetic (⚪ Low)

- **Canonical facts; Review 10 #1:** Facility lease/utilities allocation is USD 25 M over 7 years (~USD 3.6 M/yr).
- **Review 10 #1:** At USD 4.3-4.8 M/yr the USD 25 M line is 'consumed by Month 18-24'.
- **Why it conflicts:** Recomputed: USD 25 M lasts ~5.2-5.8 years (about Month 62-70) at USD 4.3-4.8 M/yr, not 1.5-2 years; the 7-year overrun is only ~USD 5-9 M, which matches the USD 5-10 M reallocation request but not the stated exhaustion date. The 10-20% rent rise also gives ~USD 3.9-4.3 M/yr, not 4.3-4.8.
- **Suggested resolution:** Correct the exhaustion date to ~Month 62-70 and describe a ~USD 5-9 M (recomputed, estimate) overrun over 7 years.

## Summary

The core plan (tranches, gates at Months 18/30/36, pilot-line decision, canonical thresholds) is largely consistent after repair, and the executive summary, project plan and pitch now follow the canonical values for most items. The remaining problems are concentrated in the financial headroom chain (hard cap vs top-up options, payroll drift vs ring-fenced runway, carry-forward size and triggers) and in the review documents, which still carry alternative sprint windows, permit slip dates and full-rate pilot-line requirements. Several of these are decisions the funder must make rather than text fixes; the rest are repairable by aligning dates and arithmetic to the canonical facts.