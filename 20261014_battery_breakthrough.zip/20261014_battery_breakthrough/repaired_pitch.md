Persuasive elevator pitch.

# Advanced Battery Cell Innovation Programme

## Project Overview

This seven-year, USD 300 M programme will **demonstrate a rechargeable battery cell at ≥500 Wh/kg gravimetric energy density and ≥1000 Wh/L volumetric energy density**—a step change to be proven at cell level, third-party verified, and prepared for licensing. Today's best cells reach approximately 250 Wh/kg; this invention targets a doubling of performance to unlock weight-critical and power-hungry applications currently impossible with existing technology.

The programme operates a **staged chemistry tournament** that hedges risk: three radical candidate chemistries (lithium-sulfur, anode-free solid-state, and conversion cathode) race in parallel through Month 36 (2029-10-14), with formal go/no-go gates at Month 18 (2028-04-14) and Month 36 (2029-10-14). One finalist is selected at Month 36 (2029-10-14) for optimization through Month 84 (2033-10-14), with final technology-transfer readiness delivered by Month 84 (2033-10-14).

The team remains **lean, capital-efficient and science-led**. An Austin R&D campus near Tesla Gigafactory Texas in Southeast Austin (SH-71/Burleson Rd area) leverages regional battery talent and suppliers. University and national-laboratory partnerships supply characterization access and High-Performance Computing without fixed overhead. The result is a **licensable invention** that moves the needle on energy density and opens markets no battery manufacturer can reach today.

## Target Audience

- **Primary:** Programme funders (government/foundation bodies), R&D leadership and steering committees, battery manufacturers and technology-transfer partners
- **Secondary:** University and national-laboratory directors, Austin-area talent and investors watching battery innovation, regulators requiring upfront buy-in

**Tone:** Science-driven, pragmatic, outcome-focused, non-commercial, collaborative

## Risks and Mitigation Strategies

**Chemistry dead-end**

- *Risk:* No candidate chemistry meets ≥500 Wh/kg + ≥1000 Wh/L + ≥300 cycles
- *Mitigation:* Stage a tournament of three active chemistries plus one pre-staged reserve chemistry; formal gates at Month 18 (2028-04-14) and Month 36 (2029-10-14); USD 15 M pivot runway ring-fenced if a finalist survives Month 30 (2029-04-14); if no chemistry meets thresholds by Month 36 (2029-10-14), Steering Committee decides descope or stop

**Packaging collapse**

- *Risk:* Material-level gains vanish once current collectors, separators and inactive mass are added to the chemistry
- *Mitigation:* Live cell-level mass-and-volume model operational by Month 4 (2027-02-14); all candidates projected by Month 6 (2027-04-14); quarterly updates; ≥950 Wh/L interim gate threshold at Month 18 (2028-04-14); 6-month volumetric sprint (Months 30–36, 2029-04-14 to 2029-10-14) available if chemistry meets Wh/kg but not volumetric targets

**Permitting slip**

- *Risk:* 6–8 month delay in hazardous-materials permits or site occupancy
- *Mitigation:* EHS lead hired Month 1 (2026-11-14); regulator engagement starting Month 0 (2026-10-14); phased Phase 1–3 permitting; outsourced synthesis contingency (USD 2–5 M/yr, 4–6 week turnaround) deployed if on-site work delays

**Budget burn and payroll overrun**

- *Risk:* Payroll could reach approximately USD 14.8 M/yr vs. USD 10 M/yr baseline; pivots and sprints stress the USD 20 M reserve
- *Mitigation:* Evidence-linked tranches (T2 at Month 12 = 2027-10-14, T3 at Month 24 = 2028-10-14, T4 at Month 36 = 2029-10-14); USD 20 M reserve held unallocated inside the USD 300 M cap; USD 15 M pivot runway ring-fenced separately; attrition monitoring (<15%/yr) with compensation review by Month 24 (2028-10-14) if breached; formal stop rule at Month 36 (2029-10-14) if no finalist qualifies

## Metrics for Success

**Primary cell-level metrics**

- ≥500 Wh/kg gravimetric energy density, third-party verified pouch cells by Month 72 (2032-10-14)
- ≥1000 Wh/L volumetric energy density
- ≥300 cycles at 80% capacity retention
- Thermal-runaway onset ≥120 °C; candidates with onset <100 °C deprioritized

**Programme execution metrics**

- Month 18 (2028-04-14) and Month 36 (2029-10-14) gates executed on schedule with measured data
- ≥90% pouch-cell defect-free build rate by Month 24 (2028-10-14); pouch-cell build rate of 50–100 cells/month reached by Month 24 (2028-10-14)
- Third-party batch reproducibility ±10% Wh/kg by Month 30 (2029-04-14)
- ≥100 mAh pouch cells, ≥3 replicates, meeting ≥500 Wh/kg AND ≥950 Wh/L in the same cells by Month 30 (2029-04-14)

**IP and licensing metrics**

- ≥6 provisional patents filed by Month 12 (2027-10-14)
- Licensing framework and licensee commitment locked by Month 24 (2028-10-14)
- Technology-transfer readiness package (complete manufacturing SOPs, supply-chain data, defensible IP estate) targeted for delivery by Month 84 (2033-10-14), at the end of the Months 72–84 (2032-10-14 to 2033-10-14) transfer window

**Team and partnerships metrics**

- Attrition <15%/yr; review by Month 24 (2028-10-14) if exceeded
- ≥2 university/national-laboratory partner agreements active by Month 3 (2027-01-14) with ≤3 week turnaround
- Independent red-team verification of all claimed results; 2–3 scientists with authority to challenge internal data

## Stakeholder Benefits

**For funders**

- A capital-efficient, de-risked pathway to a genuine step change in battery energy density
- Hedged by a staged tournament and disciplined by formal gates
- Technology transfer to a manufacturer is targeted in Months 72–84 (2032-10-14 to 2033-10-14) to help the invention reach market

**For battery manufacturers**

- A licensable, third-party-verified cell design with complete manufacturing standard operating procedures (SOPs)
- Supply-chain data and a defensible IP estate
- First-mover advantage in weight-critical and volume-constrained applications

**For national laboratories and universities**

- Formal 3–5 year partnerships supply operando and post-mortem characterization, High-Performance Computing access for materials simulation, and co-authored publications
- Partners contribute ≥15% of shared materials and characterization costs
- Neutral, credible measurement reduces fixed capital overhead

**For Austin-area talent**

- Proximity to Gigafactory Texas offers rare access to a high-ambition, non-commercial R&D mission
- Competitive pay, 3–5 year retention agreements with clawback provisions, and publication rights
- A training ground for the next generation of electrochemists and cell engineers

**For regulators**

- Early, collaborative engagement and transparent, phased permitting reduce surprise and incident risk
- Builds confidence in a de-risked, science-led programme

## Ethical Considerations

**IP and openness**

- The programme shares pre-competitive findings openly with university and national-laboratory partners
- The final integrated cell design is protected through provisional filings and licensing framework
- This balances scientific collaboration against a defensible, licensable result

**Safety-first chemistry**

- High-energy cells carry thermal-runaway risk; the programme embeds **safety screening from Month 3 (2027-01-14)** (2027-01-14), not deferred to certification
- Prioritizes non-flammable or inorganic electrolytes
- Validates abuse tolerance in qualified chambers using contracted testing (Months 6–12, 2027-04-14 to 2027-10-14) and in-house chambers (commissioned Month 18, 2028-04-14)
- Candidates with thermal onset <100 °C are deprioritized

**Talent stewardship**

- Clean-room IP onboarding protocols protect incoming staff from contamination risk
- 3–5 year retention agreements with clawback provisions ensure stability and fairness
- Attrition <15%/yr monitored; if breached by Month 24 (2028-10-14), compensation and working conditions are reviewed
- 15–20% salary premium for senior roles

**Environmental and regulatory compliance**

- All hazardous materials, synthesis steps and waste handled under permit
- Phased Phase 1–3 permitting engages regulators collaboratively
- Reduces unplanned shutdowns that could waste funding and talent

## Collaboration Opportunities

**University and national-laboratory partnerships**

- Formal 3–5 year agreements for operando and post-mortem characterization, High-Performance Computing access for materials simulation, and co-authored publications
- Partners contribute ≥15% of shared costs
- Aim to sign agreements with university and national-laboratory partners (e.g. MIT, NREL, Argonne, UT Austin) by Month 3 (2027-01-14) to supply neutral, credible measurement
- In-house post-mortem instrument (USD 2–3 M) operational Month 8 (2027-06-14); commercial backstop USD 2–3 M/yr

**Competing-team and red-team structure**

- An independent verification group of 2–3 scientists with authority to challenge internal results
- Ensures claim credibility and builds funder confidence
- Successful teams compete for additional tranches

**Technology-transfer partnerships**

- Informal licensee contacts from Month 12 (2027-10-14)
- Licensing framework locked by Month 24 (2028-10-14)
- Exclusive and non-exclusive licensing terms proposed: 2–5% exclusive, 1–2% non-exclusive
- Multiple manufacturers may adopt the design

**Supplier and equipment partnerships**

- Contract pilot-line operators stand by as capacity backup
- Equipment vendors locked into fixed-price, USD-denominated contracts (Months 2–6, 2026-12-14 to 2027-04-14) to manage foreign exchange and lead-time risk
- Partner standby line agreed Month 2 (2026-12-14); modular, leased dry-room and pouch line (50–100 cells/month) lease signed Month 1 (2026-11-14), on-site Month 3 (2027-01-14)

## Long-term Vision

**Immediate impact (Months 0–36 = 2026-10-14 to 2029-10-14)**

- Prove that ≥500 Wh/kg + ≥1000 Wh/L is reachable at cell level in a real pouch format, third-party verified
- Establish a defensible IP estate and a team capable of bridging materials science and manufacturing discipline
- Deliver measured, independent data showing one chemistry survives all gates

**Medium term (Months 36–72 = 2029-10-14 to 2032-10-14)**

- Optimize the finalist chemistry
- Reach ≥1000 Wh/L
- Confirm ≥300 cycles at 80% retention under demanding real-world duty profiles
- Develop manufacturing SOPs and supply-chain qualified suppliers
- Aim to have a third-party verified cell by Month 72 (2032-10-14), ready to enter technology transfer

**Long term (Months 72–84 = 2032-10-14 to 2033-10-14 and beyond)**

- Technology transfer to a licensee targeted in Months 72–84 (2032-10-14 to 2033-10-14), with the readiness package at the end of that window; the licensee may then scale to commercial production
- Cells power weight-critical aircraft, drones, premium electric vehicles and portable devices currently energy-starved
- The invention unlocks markets where today's approximately 250 Wh/kg cells are too heavy or bulky
- The programme establishes Austin as a centre for advanced battery invention
- A training ground for the next generation of electrochemists and cell engineers pushing energy density, cycle life and safety forward in tandem

## Call to Action

**Commit to the staged tournament and formal gates.**

- **Month 0 (2026-10-14):** Initial USD 60 M tranche (T1); hire the Programme Director; regulator engagement initiated; Southeast Austin lease (SH-71/Burleson Rd, 5,000–10,000 m² estimate) to be executed by Month 1 (2026-11-14) and EHS lead hired Month 1 (2026-11-14)
- **Month 1 (2026-11-14):** Establish governance and IP protocols; target ≥2 university/national-laboratory agreements by Month 3 (2027-01-14); lease signed with pilot-line operator; clean-room/non-use IP onboarding protocols in place
- **Month 2 (2026-12-14):** IP strategy finalized; equipment vendors locked into fixed-price, USD-denominated contracts; partner standby line agreed
- **Month 3 (2027-01-14):** Phase 1 permit granted (submitted by Month 2 = 2026-12-14); pouch-cell line commissioning begins; site occupancy achieved; safety screening protocol starts
- **Month 6 (2027-04-14):** First pouch builds (baseline); mass-and-volume model projected for all candidates; Phase 2 reactive-synthesis permit granted
- **Month 12 (2027-10-14):** ≥6 provisional patents filed; measured cycle-life data from Month 12 (2027-10-14) onward; T2 (USD 80 M) released upon lease, Phase 1 permit, live cell model, and cycle-life/Wh/L criteria set
- **Month 18 (2028-04-14):** **Execute the first go/no-go gate on measured cell-level data** (≥500 Wh/kg projected, ≥950 Wh/L interim threshold, cycle-life data, safety ranking); in-house abuse chambers commissioned; Steering Committee approves gate decision
- **Month 24 (2028-10-14):** **T3 (USD 70 M) released** upon passing Month 18 (2028-04-14) gate; ≥90% defect-free build rate achieved; licensing framework and licensee commitment locked; attrition review if >15%/yr
- **Month 30 (2029-04-14):** Third-party batch reproducibility ±10% Wh/kg verified; ≥100 mAh pouch cells (≥3 replicates) measured, showing ≥500 Wh/kg AND ≥950 Wh/L, ≥300 cycles at 80%; 6-month volumetric sprint triggered if needed
- **Month 36 (2029-10-14):** **Execute the chemistry-selection gate** (select one finalist meeting Month 30 = 2029-04-14 thresholds plus ≥120 °C thermal-runaway onset); **T4 (USD 90 M) released** if finalist qualifies; Months 36–84 (2029-10-14 to 2033-10-14) dedicated to optimization and technology transfer
- **Month 72 (2032-10-14):** Third-party verified cell ≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles at 80% targeted; technology transfer begins (Months 72–84 = 2032-10-14 to 2033-10-14)
- **Month 84 (2033-10-14):** Programme delivery; technology-transfer readiness package delivered, aiming for a licensee ready for scale-up

**Contact the Programme Director or Steering Committee chair to discuss commitment terms and funding schedule.**