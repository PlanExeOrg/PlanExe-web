
## Strengths 👍💪🦾
- Clear, measurable cell-level targets (>=500 Wh/kg, >=1000 Wh/L, user constraint) with third-party verification and a cycle-life gate (>=300 cycles at 80%, proposed threshold).
- Hedged staged tournament: 3 active chemistries plus 1 pre-staged reserve, with gates at Months 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14).
- Capital-light pilot line: modular leased dry-room and pouch line (USD 15 M, estimate) preserves pivot capacity.
- Tranche funding (60/80/70/90 M) with USD 20 M unallocated reserve and USD 15 M ring-fenced pivot runway.
- Early cell-level mass-and-volume model and independent red team protect credibility against material-level claims.
- Austin location offers UT Austin partnerships, battery talent and supplier access.
- Non-commercial mandate enables open collaboration and licensing-oriented IP strategy.

## Weaknesses 👎😱🪫⚠️
- Reserve is thin against stress case: pivot plus volumetric sprint (USD 13-25 M, estimate) can exceed the USD 15 M pivot runway.
- Payroll may reach ~USD 14.8 M/yr (estimate) versus USD 10 M/yr baseline, about USD 34 M more over 7 years.
- Opex (~USD 32.9 M/yr) exceeds the Months 36-84 (2029-10-14 to 2033-10-14) tranche rate (USD 22.5 M/yr), needing ~USD 41 M carry-forward (estimate).
- Split in-house/partner discovery makes iteration speed depend on partner queues (4-8 weeks without agreements).
- Open pre-competitive sharing and patenting only the final architecture risks a weak patent estate (30-50% licence value loss, estimate).
- Several thresholds (cycle life, 950 Wh/L, 120 C onset) are still proposed, not agreed.
- Licensing/technology-transfer partner not yet identified.

## Opportunities 🌈🌐
- Collaborate with Battery500 (PNNL) for pouch-cell protocols and gate-design lessons.
- Learn pilot-line and dry-room sizing from Solid Power and protected-lithium interface work from Sion Power.
- UT Austin and national-lab co-funding (>=15% of shared costs, proposed) and graduate-student pipelines lower cost.
- Peer-reviewed publication boosts recruitment and retention, and priority via provisional filings.
- Early licensee contacts from Month 12 (2027-10-14) enable pre-negotiated tiered licensing (exclusive for core uses, non-exclusive for others).
- Computational screening via cloud or national-lab HPC (USD 0.5-2 M/yr, estimate) raises throughput cheaply.

## Threats ☠️🛑🚨☢︎💩☣︎
- No chemistry may reach both targets at cell level; material gains often collapse at packaging.
- Permitting slips of 6-8 months (estimate) cut effective work to 75-78 months.
- Tesla-driven talent competition raises salaries and attrition; IP contamination claims from competitor hires.
- Late discovery of poor cycle life, volumetric shortfall or low thermal-runaway onset forces costly pivots.
- Partner deprioritization or loss of characterization access.
- Precursor supply disruption, price spikes and EUR/CNY equipment exposure.
- Serious EHS incident causing shutdown, remediation (USD 1-3 M, estimate) and insurance cost.
- Regulatory change forcing retrofits (USD 2-5 M, estimate).

## Recommendations 💡✅
- Month 0-1 (2026-10-14 to 2026-11-14): Programme Director and EHS lead open regulator talks and execute lease and modular line agreements; submit Phase 1 permit by Month 2 (2026-12-14).
- By Month 3 (2027-01-14): Steering Committee fixes cycle-life (>=300 cycles) and >=950 Wh/L gates and signs two partner agreements with backups (owner: Programme Director).
- By Month 4 (2027-02-14): cell engineering lead launches live mass-and-volume model; quarterly updates verified by red team.
- By Month 12 (2027-10-14): chemistry leads document reserve-chemistry pivot plans; by Month 24 (2028-10-14) pre-stage the reserve.
- By Month 6 (2027-04-14): Finance lead resizes budget for payroll understatement and reserve stress case; Funder decides whether to top up pivot runway.
- By Month 12 (2027-10-14): IP counsel files >=6 provisionals and implements clean-room onboarding; licensing lead opens licensee talks.

## Strategic Objectives 🎯🔭⛳🏅
- By Month 3 (2027-01-14), execute lease, Phase 1 permit pathway and >=2 partner agreements with <=3 week characterization turnaround.
- By Month 30 (2029-04-14), third-party measured pouch cells show >=500 Wh/kg and >=950 Wh/L in the same cells with >=300 cycles at 80%.
- By Month 36 (2029-10-14), select one finalist with thermal-runaway onset >=120 C, with spending within the tranche and >=USD 15 M pivot runway intact.
- By Month 72 (2032-10-14), third-party verify a cell at >=500 Wh/kg, >=1000 Wh/L, >=300 cycles at 80%, reporting cost per verified Wh/kg gain.
- By Month 84 (2033-10-14), hand off a licensable patent estate and executed technology-transfer agreement, with attrition kept below 15%/yr.

## Assumptions 🤔🧠🔍
- USD 300 M is a hard cap, with no revenue or debt.
- Modular leased line is operational by Month 3 (2027-01-14) and first pouch builds by Month 6 (2027-04-14).
- Phased permits obtained at Months 3, 6 and 9 (2027-01-14, 2027-04-14, 2027-07-14).
- Partners provide >=15% co-funding and access.
- Tranche releases occur on gate passage.
- A suitable licensee will exist at Month 72 (2032-10-14).

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Chemistry-specific projected cell-level Wh/kg and Wh/L headroom from the mass-and-volume model.
- Confirmed permit timelines from Austin Fire Authority and TCEQ.
- Bottom-up payroll and market salary benchmarks.
- Partner capacity, queue times and IP terms (UT Austin, national labs).
- Safety data on candidate chemistries.
- Identity and requirements of prospective licensees and target application.
- Funder appetite for top-up if reserves are drained.

## Questions 🙋❓💬📌
- Which of the three active chemistries has realistic headroom to reach 1000 Wh/L, not just 500 Wh/kg, after packaging?
- Is a USD 15 M pivot runway sufficient if a pivot and a volumetric sprint coincide, and who decides on top-up?
- What would trigger stopping or descoping at Month 36 (2029-10-14), and is the funder prepared to enforce it?
- How will partner access and IP terms hold up if a partner deprioritizes the programme?
- Which licensee and application would make the result usable, and how early should their requirements shape the specification?