Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 13 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 3 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a seven-year battery R&D programme aimed at achieving 500 Wh/kg and 1000 Wh/L cell-level energy density through established electrochemical routes (Li-S, anode-free solid-state, conversion cathode). These targets are consistent with known physics and have been demonstrated in laboratory prototypes; the plan funds empirical research to scale and optimize proven chemistry families, not to break conservation laws or invoke non-physical mechanisms.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan targets a novel combination—simultaneous achievement of >=500 Wh/kg AND >=1000 Wh/L at cell level with >=300 cycles and >=120°C thermal onset—without independent evidence at comparable scale. Individual components have been demonstrated in research (e.g., Battery500 ~350-500 Wh/kg, Sion Power protected-lithium cells), but the dual-target system with reproducibility (90% within ±10%) and full cycle-life/safety validation remains unproven. Failure of this combination would be existential to the programme.

**Mitigation**: Parallel validation tracks: (1) Market/Demand: Licensee confirms acceptance of dual-target specs and duty cycle by Month 12 (2027-10-14); (2) Technical: Require measured BOTH >=500 Wh/kg AND >=950 Wh/L interim from same pouch cells by Month 18 (2028-04-14), not deferred to Month 30 (2029-04-14); (3) Safety: Thermal-runaway onset >=120°C validated by Month 12 (2027-10-14) via adiabatic calorimetry benchmarking; (4) NO-GO gate: If no candidate meets dual targets by Month 24 (2028-10-14), halt non-finalists and activate reserve chemistry within 4 weeks.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names five strategic decisions (Chemistry Pathway, Electrolyte and Interface, Discovery Engine, Cell-Level Proof, Ecosystem/IP) with some business-level mechanism-of-action outlined, yet critical strategic concepts remain proposed rather than locked: cycle-life threshold (>=300 cycles proposed, not signed by Month 3 = 2027-01-14), volumetric-density gate (>=950 Wh/L interim proposed, decision deferred to Month 30 = 2029-04-14), application anchor (held open; duty cycle undefined), and licensing model (framework not finalized until Month 24 = 2028-10-14). These ambiguities create decision-timing risks: gate criteria set only as proposals risk deprioritizing viable chemistries prematurely; deferred application anchor compounds licensee-misalignment risk. Owners and measurable outcomes are partially specified but not fully binding.

**Mitigation**: Steering Committee and Funder: Execute signed one-pagers by Month 3 (2027-01-14) for each of the five strategic decisions, each specifying: (i) owner, (ii) mechanism-of-action (how this decision unlocks the 500/1000 target), (iii) go/no-go quantified criteria, (iv) success metrics and tracking cadence, (v) decision hooks (when/how to pivot). Bind cycle-life >=300, volumetric >=950, thermal onset >=120°C, and application anchor in writing.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because second-order risks are partially identified but lack enforcement mechanisms and quantified cascades. The pre-project assessment documents 23 discrete risks (permitting slip, payroll overrun, partner loss, EHS incident, supply disruption, IP contamination, licensee withdrawal) but does not bind go/no-go criteria, reserve allocation to specific hazards, or escalation rules to gate decisions. For example: (1) permitting slip of 6–8 months compresses effective work by 10% and cascades to pilot-line delay, yet no escalation to T2 withhold at Month 12 (2027-10-14) is documented; (2) payroll overrun of USD ~4.8 M/yr (estimate) exhausts the USD 20 M reserve by Month 30 (2029-04-14), yet no hiring freeze trigger is locked; (3) chemical pivot at Month 36 (2029-10-14) concurrent with volumetric sprint (USD 13–25 M, estimate) exceeds the USD 15 M pivot runway, yet no decision rule specifies whether the programme halts or descopes. Notably, the risk register omits cascading interactions: permitting slip + partner queue delays + precursor supply disruption simultaneously could compress 84 months to ~66 months, rendering the final proof window insufficient.

**Mitigation**: Risk Register Lead and Steering Committee: (1) Expand risk register from 23 to include explicit second-order cascades (e.g., permitting slip + external synthesis cost + discovery loop slowdown = X month effective compression, Y USD impact); (2) Allocate the USD 20 M unallocated reserve into explicit buckets: payroll contingency USD 10–15 M, permitting/EHS USD 5–10 M, chemistry pivot/sprint USD 10–15 M, free general USD 2–5 M; (3) Lock escalation rules for each risk: if permitting approval slips past Month 4 (2027-02-14), activate T2 hold pending external-synthesis and pilot-line-delay reassessment within 2 weeks; (4) Define a "stress-case trigger": if any two of [payroll overrun >=USD 2 M cumulative, permitting slip >=6 months, partner characterization queue >=6 weeks] occur simultaneously, escalate to Steering Committee for formal descope decision within 3 weeks. Within 90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because while the plan specifies a phased permitting strategy (Phase 1 by Month 3 = 2027-01-14, Phase 2 by Month 6 = 2027-04-14, Phase 3 by Month 9 = 2027-07-14, 2027-04-14, 2027-07-14) and includes volumetric verification at Month 18 (2028-04-14), critical dependencies remain unmapped and aggressive. The plan assumes pilot-line deployment by Month 3 (2027-01-14) and first pouch builds by Month 6 (2027-04-14)—plausible timelines if vendors are locked and permits granted on schedule. However, permitting slip of 6–8 months (realistic estimate for Texas hazardous-materials facilities) would compress effective work from 84 to 76–78 months; no explicit NO-GO threshold is documented if permits slip past Month 4 (2027-02-14). Additionally, concurrent volumetric-density verification (Month 18 = 2028-04-14) and chemistry-deprioritization (Month 24 = 2028-10-14) are sequenced tightly; a volumetric shortfall discovered at Month 18 (2028-04-14) triggers a 6-month architecture sprint overlapping the deprioritization window, compressing the selection-gate buffer. The plan also carries implicit carry-forward risk (USD ~41 M required Months 36–84 = 2029-10-14 to 2033-10-14 to cover opex vs. available tranche); if payroll overrun depletes carry-forward early, Months 60–84 (2031-10-14 to 2033-10-14) spending is underfunded without mid-programme top-up or descope. These are material but not insurmountable: regulator engagement starting immediately (Month 0 = 2026-10-14) and pre-staged external-synthesis fallback reduce permitting delay impact; and early volumetric verification (rather than deferral to Month 30 = 2029-04-14) preserves architecture-sprint runway. The plan's aggressive but plausible character fits MEDIUM: explicit dependencies exist, some are pre-negotiated, but cascading failure scenarios (permitting slip + volumetric shortfall + payroll overrun concurrently) could compress timeline beyond recovery by Month 84 (2033-10-14)."

**Mitigation**: Steering Committee and Programme Director: Publish a critical-path milestone tracker by Month 2 (2026-12-14) listing every serial and parallel dependency (regulator approval, vendor delivery, partner agreement execution, chemistry gate pass criteria). For each, assign: (i) owner, (ii) baseline date, (iii) NO-GO threshold (e.g., permitting approval slip past Month 4 = 2027-02-14 triggers T2 hold and external-synthesis contingency activation within 2 weeks), (iv) escalation rule if threshold is breached. Lock vendor lease, partner MOUs, and external-synthesis contracts by Month 1 (2026-11-14) with firm delivery dates. Within 60 days."


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because committed funding sources and draw schedule are partially documented (tranches T1–T4: USD 60/80/70/90 M), but critical structural gaps undermine runway integrity. The opex-vs-tranche mismatch requires ~USD 41 M carry-forward Months 36–84 (2029-10-14 to 2033-10-14) vs. average opex ~USD 32.9 M/yr; this underfunding mechanism is flagged as an assumption but remains unresolved with the funder. Payroll baseline USD 10 M/yr contradicts bottom-up estimate ~USD 14.8 M/yr (USD ~34 M shortfall over 7 years); corrected payroll would exhaust the USD 20 M unallocated reserve by Month 30 (2029-04-14). Financing gates and covenants (no-go thresholds) are proposed but not formalized: cycle-life >=300 cycles, thermal onset >=120°C, Wh/L >=950 interim are stated as proposals, not signed Steering Committee decisions. Reserve allocation (USD 15 M pivot, USD 5 M general) is declared but not bound to specific contingencies or escalation rules. No formal go/no-go on missed financing gates is documented; T4 release (Month 36 = 2029-10-14) condition on chemistry selection is proposed, not locked.

**Mitigation**: Financial & Operations Manager and Steering Committee: (1) Reconcile bottom-up payroll vs. USD 10 M/yr baseline by Month 3 (2027-01-14) using Austin salary benchmarks; present funder decision on budget top-up to USD 330–350 M or formal FTE descope within 60 days. (2) Formalize opex-vs-tranche carry-forward mechanics by Month 2 (2026-12-14): document which costs are front-loaded (capital, hiring Months 0–36 = 2026-10-14 to 2029-10-14) and which are deferred (optimization Months 36–84 = 2029-10-14 to 2033-10-14), with explicit sweep mechanism or external co-funding commitments to bridge the USD 41 M gap; obtain funder sign-off on carry-forward assumptions or approve descope. (3) Lock financing gates in signed Steering Committee decision: tranche release T2 (Month 12 = 2027-10-14), T3 (Month 24 = 2028-10-14), T4 (Month 36 = 2029-10-14) conditioned on passing third-party-verified thresholds (Wh/kg >=500, Wh/L >=950 interim by Month 30 = 2029-04-14, cycles >=300, thermal onset >=120°C). (4) Define hard no-go rule: if no chemistry meets Month 30 (2029-04-14) thresholds by Month 36 (2029-10-14), T4 is not released in full without Funder approval of descope.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated USD 300 M budget lacks vendor quotes for major capital (pilot line ~USD 15 M, equipment ~USD 10–15 M, facility fit-out), no cost benchmarking against Battery500 or peer programmes, and contradicts internal payroll analysis by ~USD 34 M (USD 14.8 M/yr vs USD 10 M/yr baseline). Contingency is 6.7% (USD 20 M) against 10–20% industry benchmark. Carry-forward gap (~USD 41 M) for Months 36–84 (2029-10-14 to 2033-10-14) is unresolved.

**Mitigation**: Procurement Lead and Finance: By Month 2 (2026-12-14), execute ≥3 RFQs for pilot line and facility, conduct Austin salary survey, benchmark against Battery500 and peers. Present realism assessment to Funder and request budget increase to USD 330–350 M or formal descope approval by Month 3 (2027-01-14).


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single point estimates without ranges or confidence intervals. Cell-level energy density targets (500 Wh/kg, 1000 Wh/L) are stated as fixed thresholds, not as ranges. Gate criteria (cycle life >=300 cycles, thermal onset >=120°C) lack stated confidence or sensitivity bounds. Timeline milestones (Month 18, 30, 36, 72, 84 = 2028-04-14, 2029-04-14, 2029-10-14, 2032-10-14, 2033-10-14 gates) assume no schedule variance. Critical cost projections (pilot line USD 15 M, payroll USD 10 M/yr, opex USD 32.9 M/yr baseline) present single numbers; only the payroll undergoes informal sensitivity flagging (USD 14.8 M/yr scenario) buried in assumptions. No formal worst-case, best-case, or conservative-case projections exist for the most critical dimensions: if the 500 Wh/kg target is actually reachable only at 480 Wh/kg after scaling, or if cycle-life plateau at 250 instead of 300, the contingency architecture fails.

**Mitigation**: Steering Committee and Programme Director: Commission a formal sensitivity analysis document by Month 3 (2027-01-14) for the three highest-impact projections: (1) cell-level dual-target achievability (best/base/worst-case Wh/kg and Wh/L ranges with rationale for each), (2) cycle-life trajectory (measured fade rate and cycle count with 80% confidence bounds derived from literature and early coin-cell data), (3) programme timeline compression (baseline 84 months vs. permitting-slip, pilot-line-delay, and partner-queue scenarios). Publish sensitivity results and decision rules: if Month 18 (2028-04-14) measured data fall outside the base-case projection by >10%, escalate to Steering Committee for chemistry re-ranking within 2 weeks.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because build-critical components (chemistry pathways, cell-level proof standard, pilot-line fabrication, characterization and forensics) have partial specifications documented, yet essential engineering artifacts remain incomplete or deferred. The plan defines success criteria (≥500 Wh/kg, ≥1000 Wh/L, ≥300 cycles), but detailed interface contracts, acceptance-test protocols, and integration maps lack binding timelines and ownership. Specifically: (1) cell-level mass-and-volume model promised by Month 4 (2027-02-14) is foundational but unvalidated until Month 20 (2028-06-14); (2) cycle-life forensics protocol and failure-mode taxonomy are proposed but lack documented structure and SOP until Month 12 (2027-10-14); (3) pilot-line specifications (dew point <−30°C, coating uniformity ±10 µm, electrolyte dosing ±2%) are stated, but commissioning acceptance tests are not formalized; (4) non-functional requirements (throughput 50–100 cells/month, reproducibility 90% within ±10%, turnaround <7 days) lack measurable pass/fail criteria and responsible owners.

**Mitigation**: Engineering Lead and Chemistry Pathway Leads: By Month 2 (2026-12-14), produce a unified Technical Specification Package covering (i) cell-level mass-and-volume model inputs and validation protocol (current collectors, separator, electrolyte, packaging mass assumptions, ±5% reconciliation target); (ii) cycle-life and degradation-mechanism forensics SOP (post-mortem workflow, root-cause taxonomy, weekly reporting cadence, integration to design iteration); (iii) pilot-line acceptance-test protocol (dew-point verification, electrode-coating uniformity mapping, electrolyte-dosing precision measurement, first-article build proof); (iv) integration map listing all chemistry-to-cell handoff points with named owners (synthesis → pilot-line transfer day, characterization data flows, design-loop closure criteria). Establish and document non-functional requirements as measurable gates (e.g., "90% of cells within ±10% Wh/kg by Month 30 = 2029-04-14, measured and verified in-house and independently").Within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes five critical operational/legal/contract claims—partner agreements (>=2 by Month 3 = 2027-01-14), pilot-line lease (deployed Month 3 = 2027-01-14, dew point <−30 °C, turnaround <7 days), external-synthesis subcontracts (<=4 week turnaround, USD 2–5 M/yr), payroll-scale assumptions (Austin market USD 10 M/yr baseline), and EHS permitting timeline (Phase 1–3 Months 3/6/9 = 2027-01-14, 2027-04-14, 2027-07-14)—yet provides no executed artifacts (MOUs, lease agreements, signed subcontracts, salary surveys, pre-application meeting minutes, written regulatory scope). The pre-project assessment flags "partner agreements not executed," "vendor not named," and "payroll understatement" as unresolved. These are load-bearing claims; missing artifacts mean the 84-month timeline and USD 300 M budget are unvalidated.

**Mitigation**: Evidence Lead: Execute or obtain by Month 1 (2026-11-14) (i) signed MOUs with >=2 partners specifying turnaround and cost-share; (ii) named pilot-line vendor lease with performance SLAs and delivery date; (iii) signed subcontracts with >=2 CROs for reactive synthesis; (iv) Austin salary survey (Glassdoor, recruiter RFI) locking payroll band; (v) written pre-application meeting notes and regulator scope from Austin Fire Authority and TCEQ. If any artifact is missing by Month 2 (2026-12-14), escalate to Steering Committee for scope reduction or timeline extension.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the technology-transfer readiness deliverable (Months 72-84 = 2032-10-14 to 2033-10-14) lacks specific, verifiable acceptance criteria. The plan lists document types (synthesis SOPs, fabrication SOPs, supply-chain agreements, pilot-line design, cell-data package) but does not define: (i) detail level or completeness metrics for each SOP, (ii) what constitutes "qualified suppliers" or acceptable lead-time commitments, (iii) minimum cell-count or statistical-power requirements for the data package, (iv) licensee approval gates or sign-off criteria. "Process documentation" and "pilot-line design" are abstract; no measurable KPIs exist for transfer readiness (e.g., "licensee engineering team successfully reproduces the cell within 6 months" or "all critical process parameters documented to ±5% tolerance"). Without verifiable acceptance criteria, the Month 84 (2033-10-14) delivery could be claimed as complete despite incomplete or non-reproducible specifications, jeopardizing licensee hand-off and commercialization.

**Mitigation**: Technology Transfer Lead: Define SMART technology-transfer acceptance criteria by Month 60 (2031-10-14), including: (i) synthesis SOP detail (ingredient masses ±0.1%, thermal ramps ±2°C, hold times ±5 min), (ii) supply-chain qualification (≥2 pre-qualified vendors per critical precursor, documented lead times and pricing, binding agreements), (iii) pilot-line design (equipment list with model numbers, dew-point control ±2°C, coating uniformity ±5 µm, demonstrable via first-article build), (iv) cell-data package (≥50 cells measured independently by licensee's lab, reproducibility ≥90% within ±10% Wh/kg), (v) licensee sign-off gate (written confirmation that transferred package is sufficient to begin manufacturing scale-up by Month 84 = 2033-10-14).


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: ✅ Low

**Justification**: Rated LOW because all major cost and complexity investments—pilot line (~USD 15 M), characterization partnerships, cell fabrication, safety testing, third-party verification—directly support the two primary stated objectives: achieving ≥500 Wh/kg and ≥1000 Wh/L at cell level with ≥300 cycles at 80% retention. The in-house post-mortem characterization instrument (USD 2–3 M, proposed Month 8 = 2027-06-14 commissioning) accelerates forensics turnaround from 4–8 weeks (external partners) to <1 week, enabling faster design-loop closure during the critical Months 12–36 (2027-10-14 to 2029-10-14) chemistry-tournament phase. This directly supports gravimetric and volumetric target discovery.

**Mitigation**: Conditional deployment: Implement a checkpoint review at Month 12 (2027-10-14) to confirm partner characterization agreements deliver ≤3 week turnaround as proposed. If actual turnaround averages ≤3 weeks, defer in-house instrument to Month 18 (2028-04-14) and reinvest the saved USD 2–3 M in reserve contingency or partner co-funding. If turnaround exceeds 4 weeks, fund and commission the instrument immediately from the general contingency reserve (USD 5 M estimate).


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Advanced Electrochemistry Lead (lithium-metal interface and cycle-life diagnostics) is both essential—all three chemistry candidates depend on solving anode-metal-stability and degradation-mechanism problems unique to lithium systems—and rare: fewer than ~200 practitioners globally with operando diagnostics and dendrite-reversal expertise. Austin salary premium (15–20% proposed) and Tesla poaching create recruitment risk. Loss of this role at Month 12–24 (2027-10-14 to 2028-10-14) would set the programme back 6–12 months (estimate).

**Mitigation**: Procurement Lead and Talent Recruitment Manager: Validate the electrochemistry talent market by Month 2 (2026-12-14) via recruiter survey of (i) active job postings for lithium-metal electrochemists in Austin/Bay Area/East Coast, (ii) identified candidates at universities and national labs (MIT, Stanford, NREL, Argonne), (iii) competitive salary benchmarks, (iv) typical time-to-hire (offer to start). Report go/no-go decision: if <3 credible candidates are identified or typical offer acceptance requires salary >USD 250 K, escalate to Steering Committee for descope or partner-hire contingency by Month 3 (2027-01-14).


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because permitting for a hazardous-materials battery research facility in Austin, Texas involves overlapping federal (EPA 40 CFR 260–273), state (TCEQ air/water), and local (Austin Fire Authority) jurisdictions. The plan assumes phased permits at Months 3, 6, 9 (2027-01-14, 2027-04-14, 2027-07-14), yet Texas permitting typically requires 6–8 months per phase (estimate). No pre-application meetings with regulators or draft permit applications are documented as completed. The plan's Phase 1 (dry-room, non-hazardous assembly) is lowest-risk, but Phase 2 (lithium-metal synthesis, fluorinated solvents) and Phase 3 (abuse-test chambers: thermal runaway, nail penetration) face material permitting uncertainty. A 6–8 month slip compresses effective work from 84 to 76–78 months (~10% loss). The pre-project assessment flags "permitting delay risk" as CRITICAL (16/25 likelihood×impact). Fallback outsourced synthesis (USD 2–5 M/yr, 4–6 week turnarounds) is mentioned but not pre-contracted.

**Mitigation**: Environmental Health & Safety Officer and Programme Director: Initiate regulator collaborative engagement with Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ), and Travis County within 48 hours (Month 0, 2026-10-14). Request pre-application meetings by 2026-10-29 to co-design Phase 1–3 scope and conditional-use-authorization pathways. Submit Phase 1 permit application (dry-room, non-hazardous operation) by Month 2 (2026-12-14) targeting 4–6 week review. Execute binding synthesis subcontracts (≥2 contract research organizations, <4 week turnaround, USD 2–5 M/yr, 200% surge capacity) by Month 1 (2026-11-14) to hedge permitting delays. Lock site lease occupancy by Month 3 (2027-01-14) with Phase 1 permit approval or conditional-use authorization as occupancy condition within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan's 84-month delivery scope is well-defined with clear gates and measurable cell-level proof. Post-delivery sustainability gaps exist (IP prosecution, operator training, supply continuity), but the plan explicitly targets a licensable invention, not industrial operation. Mitigations are feasible within Months 72–84 (2032-10-14 to 2033-10-14) technology-transfer window and cost <USD 2 M/yr post-delivery, modest against the USD 300 M investment.

**Mitigation**: Partner & Ecosystem Lead: Develop and execute a Post-Delivery Operational Sustainability Plan by Month 60 (2031-10-14) covering: (1) Licensee support agreement (USD 0.5–1 M/yr, 3–5 years, technical troubleshooting, training); (2) IP prosecution roadmap (provisional → issued patents by Month 72 = 2032-10-14); (3) Supplier continuity (5–10 year agreements, >=2 vendors per material, price caps); (4) Operator certification (5–10 licensee engineers, 2–3 month intensive training, Months 72–84 = 2032-10-14 to 2033-10-14); (5) Forward-technology roadmap and upgrade protocol; (6) Circular-economy partnerships for end-of-life recycling.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the programme's site-enablement path depends critically on hazardous-materials permitting across three phased gates (Phase 1 dry-room by Month 3 = 2027-01-14, Phase 2 reactive synthesis by Month 6 = 2027-04-14, Phase 3 abuse-test chambers by Month 9 = 2027-07-14), yet no pre-application meetings with Austin Fire Authority, TCEQ, or Travis County are documented as completed, and typical Texas hazardous-materials facility permitting requires 6–8 months per phase (estimate). The plan states Phase 1 should be approved by Month 3 (2027-01-14), requiring Phase 1 submission by Month 2 (2026-12-14)—less than 4 months away. A permitting slip of 6–8 months would compress effective work from 84 to 76–78 months (~10% timeline loss). The plan mentions external-synthesis fallback (USD 2–5 M/yr, 4–6 week turnarounds) as a contingency, but no subcontracts are pre-negotiated or signed. Zoning in Southeast Austin (SH-71/Burleson Rd) permits light industrial and lab use, but dry-room dew-point control, lithium-metal synthesis, and abuse-test chambers (thermal runaway, nail penetration) constitute hazardous operations requiring explicit permits covering EPA 40 CFR 260–273 (waste), OSHA 1910.1200/1910.307 (materials), TCEQ air/water, and Austin Fire Authority flammable/reactive-material rules. No written scope confirmation from regulators exists. This is a critical-path item: failure to secure Phase 1 approval by Month 4 (2027-02-14) cascades to pilot-line occupancy slip (Month 6 = 2027-04-14 baseline to Month 9–12 = 2027-07-14 to 2027-10-14), compressing the Month 18 (2028-04-14) gate data window by 6–8 weeks and forcing deferral to Month 24 (2028-10-14). Combined with a potential volumetric-density shortfall requiring a 6-month architecture sprint at Month 30–36 (2029-04-14 to 2029-10-14), the permitting delay cascades to compress the selection gate and threaten the final proof timeline.

**Mitigation**: Steering Committee and Environmental Health & Safety Officer: (1) Initiate regulator collaborative engagement with Austin Fire Authority, Texas Commission on Environmental Quality (TCEQ), and Travis County within 48 hours (Month 0 = 2026-10-14). Schedule pre-application meetings to co-design Phase 1–3 scope, conditional-use-authorization pathways, and written scope boundaries for lithium-metal synthesis, fluorinated solvent handling, and abuse-test operation. (2) Hire EHS lead with ≥5 years battery-lab or hazmat experience by Month 1 (2026-11-14); assign compilation of EPA 40 CFR 260–273, OSHA 1910.1200/1910.307, TCEQ air/water, and Austin Fire Code requirements by Month 2 (2026-12-14). (3) Execute binding synthesis subcontracts (≥2 CROs, <4 week turnaround, USD 2–5 M/yr, 200% surge capacity) by Month 1 (2026-11-14) to hedge permitting delays; trigger activation if Phase 1 approval slips past Month 4 (2027-02-14). (4) Submit Phase 1 permit application (dry-room, non-hazardous operation) by Month 2 (2026-12-14), requesting 4–6 week review. Propose conditional-use authorization from fire authority to allow Phase 1 operations under enhanced daily monitoring while full Phase 2–3 permits mature. (5) Lock site lease occupancy by Month 3 (2027-01-14) with Phase 1 permit approval (or conditional-use authorization) as occupancy condition. Within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies three critical external dependencies—university/national-laboratory characterization partnerships, modular leased pilot-line capacity, and precursor/equipment sourcing—yet provides no executed binding agreements, vendor names, or performance guarantees as of Month 0 (2026-10-14). The characterization-access assumption (≤3 week turnaround, ≥15% cost-sharing from ≥2 partners by Month 3 = 2027-01-14) lacks written capacity statements or SLAs; typical national-lab queues extend 4–8 weeks during peak demand, which would reduce discovery-loop throughput by 50–75% and delay the Month 18 (2028-04-14) gate by 6–8 weeks. The modular pilot-line lease is unvetted (no named vendor, no performance specifications locked, no commissioning acceptance protocol), risking a 6–12 month deployment slip that compresses effective work from 84 to 72–78 months. Precursor sourcing lacks dual-source qualification for critical materials (lithium compounds, fluorinated solvents); a single-vendor shortage or 8–12 week lead-time extension could halt synthesis for 4–6 weeks. No tested fallback mechanisms exist: external synthesis subcontracts are mentioned in assumptions but not pre-signed; pilot-line backup agreements are proposed but unsigned. A concurrent failure of two dependencies (characterization queue delay + pilot-line commissioning slip + supply disruption) would compress timeline by 10–15% and exhaust the USD 2–3 M free contingency by Month 24 (2028-10-14), leaving zero buffer for stress cases.

**Mitigation**: Programme Director and Procurement Lead: Execute binding agreements and vendor contracts by Month 2 (2026-12-14) for (1) ≥2 University/National-Lab Partnerships: signed 3–5 year MOUs specifying ≤21 day characterization turnaround SLA, ≥15% annual cost-sharing commitment, and 30–60 day exit clause; (2) Pilot-Line Lease: named vendor, fixed-price ≤USD 1.2 M/yr cap, dew-point <−30 °C performance guarantee, first-article commissioning acceptance protocol, 60-day exit option; (3) Precursor Sourcing: ≥2 qualified suppliers per critical material (lithium, fluorinated solvents, specialty salts), 8–12 week lead-time confirmation, pricing locked via annual agreements; (4) External Synthesis Fallback: ≥2 CROs with signed subcontracts, <4 week turnaround guarantee, USD 2–5 M/yr budget, 200% capacity surge clause. Simultaneously, negotiate Backup Characterization (Intertek, TUV, or university contract lab) with ≤6 week guaranteed emergency access. Establish Dependency Monitoring Dashboard (real-time queue tracking, supplier lead-time alerts, partner budget/staffing changes) by Month 6 (2027-04-14); escalate any ≥2 week drift in turnaround or ≥4 week lead-time extension to Steering Committee within 3 business days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan defers the Reference Application Anchor specification (duty-cycle definition: C-rate, temperature range, cycle-life requirement, form factor) to 'let early cell data reveal which application naturally fits' (Decision 11, rated Medium priority in strategic_decisions.md). Without a locked application anchor by Month 3 (2027-01-14), the final cell design risks misalignment with prospective licensee requirements. A cell optimized for weight-critical aviation (low cycle-life tolerance, high rate) differs fundamentally from one optimized for mass-market automotive (>=500 cycles, -20 to +55°C). Discovery of duty-cycle misalignment at Month 72 (2032-10-14) technology transfer forces 6–12 month redesign or licensee rejection, delaying commercialization 18–36 months. No prospective licensee has been formally engaged, and no term sheet exists specifying application scope or licensee acceptance criteria.

**Mitigation**: Partner & Ecosystem Lead: Identify and conduct non-binding RFI conversations with 3–5 prospective licensees (aerospace, automotive OEM, energy-storage integrator) by Month 9 (2027-07-14); lock a named licensee with signed non-binding term sheet specifying application duty cycle, royalty structure, and commercialization timeline by Month 12 (2027-10-14).


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks binding feedback-loop enforcement mechanisms. Gates (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) have proposed thresholds but no signed Steering Committee charter, explicit escalation rules, monthly SPC tracking, or formalized change-control process. Reserve-allocation triggers and pivot-activation rules are stated as examples, not locked procedures. No monthly reporting of KPIs, variance detection, or automatic contingency activation exists; discovery of failures is deferred to gate reviews, compressing response time.

**Mitigation**: Steering Committee: Execute signed governance charter by Month 1 (2026-11-14) specifying (i) gate decision authority and 3-week vote rule, (ii) monthly KPI dashboard (build yield, characterization queue, payroll variance, permitting status, reserve burn-rate) with variance thresholds triggering escalation within 3 business days, (iii) automated change-control process: any chemistry deprioritization, partner switch, or reserve draw >USD 1 M requires documented decision memo within 2 weeks, (iv) explicit stop rule with USD/timeline thresholds. Within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan carries three strongly coupled HIGH risks that interact to create multi-domain failure: (1) Payroll overstatement (USD ~14.8 M/yr vs USD 10 M/yr baseline, ~USD 34 M shortfall) + opex-vs-tranche gap (~USD 41 M carry-forward required) → reserve depletion by Month 30 (2029-04-14), zero free contingency; (2) Permitting slip (6–8 months realistic, compressing effective work to 75–78 months) + pilot-line commissioning delay (Month 9–12 = 2027-07-14 to 2027-10-14 vs Month 3 = 2027-01-14 baseline) + characterization queue slowdown (4–8 weeks vs ≤3 week SLA) → Month 18 (2028-04-14) gate data incomplete, discovery loop slows 50–75%, verification deferred; (3) Chemistry failure rate unknown; dual-target (≥500 Wh/kg AND ≥1000 Wh/L) unproven at cell level; concurrent pivot (USD 5–10 M) + volumetric sprint (USD 8–15 M) = USD 13–25 M vs USD 15 M runway = shortfall up to USD 10 M. Single critical node: Month 30 (2029-04-14) third-party verification gate; if two chemistries fail (cycle-life collapse + volumetric shortfall), both pivot and sprint activate concurrently, exhausting reserve and compressing final 48 months to 30–36 months (insufficient for proof and transfer).

**Mitigation**: Risk Integration Lead: Develop and publish an interdependency map by Month 3 (2027-01-14) showing: (1) stress-case cascade (payroll overrun + permitting slip + chemistry failure concurrently) with month-by-month cash-flow and schedule impact; (2) bow-tie diagram for Month 30 (2029-04-14) gate (antecedents: cycle-life and volumetric targets; consequences: pivot, sprint, descope decisions); (3) combined reserve-burn heatmap (payroll contingency, permitting/EHS, pivot/sprint, free general) with owner and no-go/contingency thresholds (e.g., "if payroll ≥USD 13 M/yr AND permitting slip ≥6 months, descope to 2 chemistries by Month 12 = 2027-10-14"). Owner: Risk Integration Lead. Deliverable: Cross-impact matrix + bow-tie diagram + heatmap. Date: Month 3 (2027-01-14).