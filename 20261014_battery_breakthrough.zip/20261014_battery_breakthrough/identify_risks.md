
## Risk 1 - Technical - Chemistry Pathway
The staged tournament across three to four chemistries (lithium-sulfur, anode-free solid-state, conversion cathodes) may fail to identify a viable path to 500 Wh/kg and 1000 Wh/L by the mid-programme gate (Month 36 = 2029-10-14). Material-level gains often collapse at cell level once packaging overhead is included. If all three chemistries encounter unforeseen cycle-life, dendrite, or volumetric penalties, the programme faces a costly pivot or admission of technical infeasibility.

**Impact:** A failed chemistry tournament at Month 36 (2029-10-14) forces a 6–12 month redesign or chemistry restart, consuming USD 20–40 M in sunk capital and delaying cell-level proof by 12–24 months. The programme may reach Month 48–60 (2030-10-14 to 2031-10-14) before identifying a viable route, leaving insufficient time to mature it to demonstrable cell level.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish clear go/no-go criteria for each chemistry by Month 18 (2028-04-14), including quantified cycle-life (proposed: ≥500 cycles), interfacial resistance targets, and a system-level mass-and-volume model that forces early accounting of packaging penalties. Run quarterly reviews with external technical advisors to validate progress; build a contingency chemistry (fourth candidate) held in reserve, with option to accelerate it if two leading candidates fail by Month 24 (2028-10-14).

## Risk 2 - Technical - Cell-Level Proof Standard
The dual-track metric (material-level targets back-calculated from a cell model) may not translate into real pouch-cell verification early enough. If full pouch cells are not independently tested until Month 48 (2030-10-14) or later, inactive-mass surprises (current collectors, separators, pressure hardware) could reveal that the chemistry cannot meet 1000 Wh/L at cell level, despite material-level promise.

**Impact:** Late discovery of packaging penalties could consume USD 10–20 M in rework or force acceptance of a cell below target. A one-cycle cell meeting the letter of the goal but with <100 cycle life would satisfy the stated success criterion but not a usable battery, delaying real validation to Month 60+.

**Likelihood:** Medium

**Severity:** High

**Action:** Require independent third-party pouch-cell verification of at least one chemistry finalist by Month 30 (2029-04-14), before the mid-gate decision. Define minimum cycle life (proposed: ≥300 cycles at 80% capacity retention) as a hard pass/fail threshold from Month 24 (2028-10-14) onward. Use a dedicated engineering team to build a live mass-and-volume model updated each quarter; publish mismatch between predicted and actual Wh/kg by Month 20 (2028-06-14).

## Risk 3 - Operational - Pilot Line and Dry Room
Uncertainty about whether to build, lease, or modularize the dry room and pouch-cell line creates schedule and capital risk. If the decision is deferred, early months may lack the fabrication capacity to build pouch cells for proof-of-concept. A leased external line adds queue time and confidentiality exposure for unpublished materials. A new build risks 6–12 month commissioning delays and capital lock-in before chemistry is proven.

**Impact:** A delayed or underspecified pilot line could defer first pouch-cell builds to Month 8–12 (2027-06-14 to 2027-10-14), compressing the discovery loop and proof timeline. A new in-house build could consume USD 30–50 M and 12 months of lead time, leaving only USD 250–270 M for five years of operation. Leasing external capacity adds 4–8 week queues, slowing iteration to one build per month instead of one per week.

**Likelihood:** High

**Severity:** High

**Action:** By Month 1 (2026-11-14), decide on a modular, containerized dry-room and pouch-cell line (leased capacity with option to own) that can be deployed at the chosen Austin site by Month 3 (2027-01-14) and scaled or relocated as needed. Negotiate a pilot-line agreement with a university or national-laboratory partner by Month 2 (2026-12-14) to provide backup pouch-cell fabrication at cost during commissioning. Size the line for 50–100 pouch-cell builds per month to support the discovery loop; reserve USD 15–20 M and 6-month lead time in the budget.

## Risk 4 - Operational - Location and Permitting
Site selection and permitting for hazardous materials (reactive metals, flammable solvents, abuse-test chambers) may extend beyond Month 3 (2027-01-14). Local fire authority and environmental-health approvals for a new dry room and synthesis lab in the Austin area can take 4–8 months. If permitting is conservative, reactive chemistries (lithium metal, sulfides, halide electrolytes) may be excluded from on-site work, forcing outsourcing of key synthesis steps and slowing iteration.

**Impact:** A 6–8 month permitting delay would push operational start to Month 6–8 (2027-04-14 to 2027-06-14), compressing the 84-month programme to 76–78 months of effective work. Restrictive permit terms could exclude lithium-metal synthesis from the site, requiring all lithium-metal candidate work to be outsourced at cost (USD 5–10 M/year) and with 4–6 week turnarounds. Conservative zoning could also block planned abuse-test facility build-out.

**Likelihood:** High

**Severity:** Medium

**Action:** Initiate site selection, lease negotiation and permitting in Month 0 (2026-10-14), targeting site occupancy by Month 2 (2026-12-14). Engage the Austin fire authority and Texas environmental regulators in Month 0 (2026-10-14) as collaborative partners; propose a phased permit approach that allows pilot-phase dry-room operation by Month 3 (2027-01-14) and full synthesis and abuse-testing capability by Month 9 (2027-07-14). Pre-negotiate with licensed external synthesis facilities (e.g., commercial contract labs) to handle any on-site-prohibited chemistries at cost-plus terms, so synthesis is not a bottleneck if local permitting is tight.

## Risk 5 - Financial - Budget and Burn Rate
A USD 300 M budget over 7 years (approximately USD 43 M/year) must cover staff payroll (estimated 80–120 FTE at USD 2–4 M/year total), facility lease and utilities (USD 2–5 M/year), capital equipment (dry room, characterization instruments, pilot line: USD 40–60 M upfront), third-party testing and partnerships (USD 3–5 M/year), and contingency. Early capital commitments (pilot line, dry room, initial hiring) could exceed USD 60–80 M in Years 1–2, leaving insufficient working capital for later experiments, pivots or partnership cost-sharing.

**Impact:** Front-loaded capital spending could leave only USD 150–170 M for Years 3–7 (USD 30–34 M/year), throttling iteration speed and forcing staff reductions in later years when chemistry matures and iteration accelerates. A 20% cost overrun in pilot-line or facility build (USD 10–15 M) would compress the remaining budget by 3–5%. If partnerships require cost-sharing (USD 5–10 M/year), the programme may run short by Year 5–6.

**Likelihood:** High

**Severity:** Medium

**Action:** Structure funding release in tranches linked to demonstrated milestones: Month 0–12 (2026-10-14 to 2027-10-14) (USD 60 M: facility, core team, equipment orders), Month 12–24 (2027-10-14 to 2028-10-14) (USD 80 M: pilot-line commissioning, first chemistry gate), Month 24–36 (2028-10-14 to 2029-10-14) (USD 70 M: mid-programme decision and winning chemistry scale-up), Month 36–84 (2029-10-14 to 2033-10-14) (USD 90 M: proof and optimization). Reserve USD 15–20 M (5–7% contingency) for pivots, unexpected chemistry redirection or third-party testing. Negotiate matching grants or co-funding with university and national-laboratory partners (proposed: 10–15% of partnership costs) by Month 6 (2027-04-14) to offset variable costs.

## Risk 6 - Operational - Talent and Recruitment
Recruiting and retaining 80–120 specialized scientists and engineers in battery electrochemistry, materials science, and manufacturing engineering in the Austin area faces stiff competition from Tesla and other automotive/energy firms. Offering salaries and equity packages competitive with nearby industrial employers while remaining within a fixed USD 300 M budget is difficult. High turnover (proposed risk: >15% annual attrition) would force continuous re-hiring and knowledge loss, especially if early key personnel depart mid-programme.

**Impact:** If attrition reaches 20% annually, the programme would need to hire and onboard 16–24 replacements per year, consuming 10–15% of operating budget in recruitment and training. Loss of a key chemistry or characterization lead at Month 12–24 (2027-10-14 to 2028-10-14) could set the programme back 3–6 months as knowledge is re-built. Inability to match competitor salaries could force hiring below the target expertise level, reducing discovery speed by 20–30%.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a recruitment strategy by Month 1 (2026-11-14) that includes partnership with University of Texas at Austin for graduate-student pipelines (reduces salary burden), and negotiates long-term retention agreements (3–5 year commitments with clawback terms) for key leads. Offer sign-on bonuses and stock-option-like arrangements (even in a non-commercial entity) to compete with Tesla. Structure the team to include 20–30% postdoctoral and graduate-student roles to lower average cost. Build a 'stay' plan: by Month 6 (2027-04-14), publish early findings in peer-reviewed journals to enhance researcher prestige and reduce poaching risk.

## Risk 7 - Regulatory & Permitting - Hazardous Materials
Synthesis of reactive precursors, handling of lithium metal, flammable organic electrolytes, and operation of abuse-test chambers (thermal runaway, nail penetration, overcharge) face overlapping federal (EPA, DOT, OSHA), state (Texas Commission on Environmental Quality) and local (Austin Fire Authority, Travis County) permitting and safety rules. Failure to secure or maintain permits could halt operations. Changes in environmental or safety regulations during the 7-year period could force costly retroactive upgrades.

**Impact:** A permitting delay or rejection could stop synthesis, cell assembly or abuse testing for 2–6 months during Year 1–2, compressing the early chemistry evaluation phase. Retrofitting the facility to meet new EHS standards (e.g., stricter lithium-ion cell storage rules, VOC limits) could cost USD 2–5 M and require 3–4 month downtime. A serious incident (e.g., electrolyte fire, chemical release) could trigger investigative closure and USD 1–3 M in remediation, plus reputational and insurance cost.

**Likelihood:** Medium

**Severity:** High

**Action:** Engage Texas environmental and Austin fire authorities in Month 0 (2026-10-14) as collaborative partners; establish a standing EHS advisory committee including external regulatory consultants. Develop a tiered permitting strategy that allows pilot-phase dry-room operation by Month 3 (2027-01-14) (low hazard) and defers high-hazard synthesis and abuse testing to Month 6–9 (2027-04-14 to 2027-07-14) once full permits are in place. Maintain a USD 3–5 M contingency reserve for permitting delays or retroactive upgrades. Document all processes, materials and quantities in compliance with federal and state databases; conduct internal audits quarterly to catch drift early.

## Risk 8 - Technical - Characterization and Forensics
The split in-house/partner discovery structure depends on reliable access to advanced operando and post-mortem characterization (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy) at universities and national laboratories. If partner access is delayed or unavailable, failed cells cannot be analyzed quickly, slowing the design-build-test loop. In-house capability is costly (USD 5–10 M for core instruments) and risks underutilization if it duplicates partner capabilities.

**Impact:** A 4–8 week queue at a partner characterization facility would slow the discovery loop from 1–2 weeks (in-house) to 6–10 weeks, reducing the number of testable hypotheses per year by 50–75%. If a critical partner facility becomes unavailable (e.g., closure, staff turnover, competing priority), alternative characterization could cost USD 50–100 K per failed cell at commercial labs, quickly exhausting the characterization budget. A chemistry with a subtle failure mechanism (interface kinetics, electrolyte decomposition) might not be detected without rapid operando analysis, leading to months of wasted builds.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Negotiate formal standing agreements with at least two university or national-laboratory characterization facilities by Month 3 (2027-01-14), with guaranteed turnaround (proposed: ≤3 weeks) and priority scheduling for failed-cell analysis. Invest in one core in-house post-mortem capability (scanning electron microscope or X-ray diffraction: USD 2–3 M) by Month 6 (2027-04-14) for rapid triage of failed cells; outsource deeper operando work. Establish a forensics protocol: every failed cell receives a standardized autopsy within one week of failure, with a structured root-cause report that feeds directly into the next design iteration. Budget USD 2–3 M/year for commercial characterization services as a backstop.

## Risk 9 - Technical - Abuse Tolerance and Safety
High-energy lithium-rich cells typically exhibit worsen thermal runaway and short-circuit safety margins compared to conventional cells. Early safety evaluation is needed to avoid spending months on a chemistry that later fails abuse tests (thermal runaway, nail penetration, overcharge). Building an in-house abuse-testing facility (calorimetry, nail-penetration chambers, overcharge test stations) requires specialized equipment (USD 3–5 M), permits, and trained staff. Outsourcing abuse testing to external labs adds queue time and cost (USD 20–30 K per full abuse test) and may delay discovery.

**Impact:** If abuse testing is deferred until Year 2–3, a chemistry that is discovered in Month 18 (2028-04-14) to have a thermal runaway onset below 100°C would waste 12–18 months of development and USD 10–20 M in prior material, synthesis and cell work. Discovering safety issues late could force the programme to abandon a leading chemistry candidate at Month 36 mid-gate, leaving only one or two alternatives with insufficient time for maturation. Conversely, early in-house abuse testing requires USD 3–5 M capital and 4–6 month facility build, competing with other capital priorities.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a phased safety-evaluation strategy: Month 3–6 (2027-01-14 to 2027-04-14), coin-cell and small pouch-cell thermal-ramp tests (inexpensive, in-house or outsourced) to rank chemistries for safety. Month 6–12 (2027-04-14 to 2027-10-14), contract or lease access to an established abuse-testing facility for nail-penetration and overcharge on selected candidates. Month 12 (2027-10-14) onward, if a chemistry passes early gates, build or acquire dedicated in-house abuse chambers (USD 3–5 M) for rapid iteration on safety-critical designs. Require every chemistry finalist to pass defined safety thresholds (proposed: thermal runaway onset ≥120°C, reversible after overcharge) before advancing to the mid-gate decision.

## Risk 10 - Strategic - IP and Collaboration Risk
The Pragmatic Foundation strategy emphasizes open partnership with universities and national laboratories, sharing pre-competitive findings and patenting only the final integrated cell architecture. This approach aligns with the non-commercial invention goal but risks a weak patent position if the final integrated design draws heavily on openly published partner work. Also, employees hired from Tesla or nearby firms may carry implicit knowledge of competing work, creating IP-contamination exposure despite clean-room protocols.

**Impact:** A patent estate limited to the final integrated design (rather than enabling compositions, processes and cell formats) could reduce licensing value by 30–50% and invite competitors to design around the claims. If an employee departing Tesla brings proprietary knowledge (intentionally or unconsciously) and contaminates the design, Tesla could claim prior art or misappropriation, jeopardizing patent validity. Conversely, strict clean-room protocols and limited IP sharing could deter university and national-laboratory partners, reducing cost-sharing and characterization access.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a clear IP strategy by Month 2 (2026-12-14): file provisional patents on key compositions, electrolyte architectures and cell formats as they emerge (not just the final integration), while publishing non-core materials work in peer-reviewed journals to establish priority and academic prestige. Implement strict IP-onboarding protocols for hires from Tesla: background checks, signed non-use agreements for competing knowledge, and a 6-month observation period before access to sensitive designs. Structure university and national-laboratory agreements to permit publication of materials and methods after 6-month review windows, reserving claims on final cell architectures and processes for in-house patents.

## Risk 11 - Operational - External Partnership Dependency
The strategy relies heavily on university and national-laboratory partners for characterization, candidate validation and cost-sharing. Partners may have competing priorities, shifting staffing or funding. If a key partner (e.g., Argonne National Lab, UT Austin materials group) deprioritizes the battery work or experiences budget cuts, validation could be delayed or outsourced to commercial labs at much higher cost. No contractual guarantee can fully insulate a research programme from academic schedules.

**Impact:** Loss of a key partner's access to operando X-ray diffraction (a critical diagnostic) at Month 18 (2028-04-14) could force USD 30–50 K per sample at commercial labs, consuming USD 5–10 M/year in characterization budget if samples accumulate. A 6-month partner facility downtime (renovation, staff turnover) could halt characterization and delay the design loop by one chemistry cycle (6–12 months). If cost-sharing partners withdraw (proposed risk: 10–20% loss of matched funding), the programme would need to absorb those costs internally, compressing working capital by USD 5–10 M over the 7-year period.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Negotiate formal long-term agreements (3–5 year) with at least two primary partner institutions by Month 3 (2027-01-14), specifying guaranteed access, turnaround, and upfront cost-sharing commitments (proposed: ≥15% of materials and characterization costs). Identify one backup partner for each critical service (operando diagnostics, computational screening, synthesis validation) so that loss of a primary partner does not halt work. Structure agreements with escape clauses (30–60 day notice) to allow rapid transition to alternative providers. Reserve USD 2–3 M/year as a 'partnership contingency' for unexpected partner cost increases or loss-of-access scenarios.

## Risk 12 - Technical - Materials Supply and Sourcing
Synthesis and testing of advanced battery chemistries depends on a steady supply of specialized precursors: lithium compounds, high-purity metal oxides, fluorinated solvents, salts and other reactive materials. Supply chains for these materials are often long (Asia-based, 8–12 week lead times) and subject to geopolitical disruption, export controls (lithium, cobalt, rare-earth precursors) and price volatility. A critical precursor shortage could halt synthesis for weeks to months.

**Impact:** A 4–8 week delay in receiving a key precursor (e.g., high-purity lithium carbonate, fluorinated electrolyte salt) would halt synthesis and push chemistry validation back by one cycle (6–8 weeks). A sudden 20–30% price increase in a strategic material (lithium salts, high-nickel oxide) could add USD 2–5 M to material costs over the 7-year period, compressing other budget areas. Geopolitical export controls (e.g., US restrictions on Chinese precursor suppliers) could force expensive re-sourcing or certification of new suppliers, adding 2–4 months to each precursor qualification.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-14), establish supplier relationships with at least two qualified vendors for each critical precursor; negotiate annual supply agreements with price-stability clauses (e.g., fixed pricing for ≥80% of annual volume) and 12-week minimum lead times. Maintain a strategic inventory of key long-lead precursors (3–6 month supply) to buffer against disruption; budget USD 1–2 M for precursor inventory carry. Monitor geopolitical and supply-chain risks quarterly; establish a 'precursor contingency team' to identify alternative suppliers or synthetic routes if a primary supplier becomes unavailable. Factor USD 500 K–1 M/year into the contingency reserve for price volatility and emergency re-sourcing.

## Risk 13 - Organizational - Governance and Decision Authority
A complex R&D programme with multiple chemistry pathways, external partners and stage-gate funding decisions needs clear governance: Who decides whether a chemistry advances to the next gate? Who has authority over budget redirection after a failed hypothesis? Ambiguous decision rights create delays, cost overruns and demoralization. The plan mentions an internal red team or verification function in one scenario but does not clarify its role in the chosen Pragmatic Foundation path.

**Impact:** Unclear decision authority at the Month 24–30 mid-gate review could delay the go/no-go decision by 4–8 weeks, compressing the remaining timeline for the chosen chemistry. If three chemistry teams disagree on which candidate to advance, deadlock could force a costly compromise (continuing two chemistries instead of one), wasting USD 10–15 M on the weaker candidate. Ambiguous authority over major redirects (e.g., adding a fourth chemistry candidate or outsourcing synthesis) could lead to ad hoc spending that balloons contingency burn without strategic review.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish a clear governance structure by Month 1 (2026-11-14): define a Scientific Steering Committee (Programme Director, four chemistry leads, an external technical advisor, and the funder representative) with explicit authority over chemistry advancement, gate decisions and budget reallocation. Document go/no-go criteria for each gate (Month 18 = 2028-04-14: cell-level Wh/kg feasibility, Month 30 = 2029-04-14: pouch-cell cycle-life proof, Month 36: mid-gate chemistry selection). Create a 'red team' function: a standing independent verification group (2–3 scientists, external to core teams) tasked with replicating key results and challenging progress claims before they are reported to funders. Establish a decision timeline: all gate reviews must conclude within 3 weeks to avoid downstream compression.

## Risk 14 - Financial - Currency and International Procurement
Specialized characterization instruments, pilot-line equipment and advanced materials often come from European or Asian suppliers and are quoted in EUR or CNY. A fixed USD 300 M budget faces foreign-exchange risk if the USD weakens against EUR over the 7-year period. A 10–15% depreciation of USD against EUR would increase the cost of imported equipment by USD 5–10 M.

**Impact:** If EUR-denominated equipment purchases (e.g., X-ray diffraction chamber from a German supplier, solid-electrolyte separator manufacturing line) total USD 30–50 M equivalent at Month 2 (2026-12-14), a 15% USD depreciation would add USD 4.5–7.5 M to those costs by Month 36 (2029-10-14), compressing other budget areas by 1.5–2.5%. Conversely, a strengthening USD would provide a tailwind but is unpredictable. Price-lock agreements with suppliers mitigate risk but add upfront cost (2–5% premium for fixed pricing).

**Likelihood:** Medium

**Severity:** Low

**Action:** Identify all major equipment and material purchases with expected EUR or other foreign-currency costs by Month 2 (2026-12-14); negotiate fixed-price contracts in USD or with forward exchange agreements to lock in rates for capital equipment orders placed in Months 2–6 (2026-12-14 to 2027-04-14). For ongoing material purchases, use a hedging strategy: request supplier pricing in USD where feasible, and budget USD 2–3 M (1% contingency) for currency fluctuation on necessary foreign-currency purchases. Monitor exchange rates quarterly and, if USD weakens beyond 10% on key procurement corridors, trigger a budget review to defer non-critical equipment or seek alternative domestic suppliers.

## Risk 15 - Strategic - Mid-Programme Pivot Cost and Timing
The staged tournament strategy assumes the programme can pivot from a failed chemistry to a backup option at Month 36 (2029-10-14) with minimal lost time. In practice, a pivot requires re-establishing supply chains for new precursors (2–4 months), rebuilding chemistry-specific equipment or pilot-line settings (2–3 months), and retraining staff on new processes (1–2 months). The effective pivot cost and time could be 6–10 months, not a clean gate decision.

**Impact:** A pivot at Month 36 (2029-10-14) from lithium-sulfur (failed) to anode-free solid-state would cost USD 5–10 M in retooling (dry-room settings, new separator equipment) and burn 6–10 months, pushing the programme to Month 42–46 (2030-04-14 to 2030-08-14) before solid-state proof is in hand. With only 38–42 months remaining in the 84-month timeline, there would be insufficient time to mature the new chemistry to production-ready cell level. The programme could deliver a proof-of-concept but not a hand-off ready for licensing.

**Likelihood:** Medium

**Severity:** High

**Action:** Build detailed pivot plans for each of the three reserve chemistries by Month 12 (2027-10-14): pre-qualify precursor suppliers, document process variations and equipment needs, and cross-train 20–30% of the synthesis and pilot-line team on each reserve path. Establish a 'pivot runway' reserve in the budget: USD 10–15 M (3–5% of total) held unallocated through Month 30 (2029-04-14), available for rapid pivots if a leading chemistry fails. By Month 24 (2028-10-14), if two of the three leading chemistries show signs of fundamental limitations, pre-stage the third chemistry (order long-lead precursors, prepare equipment) so the Month 30 (2029-04-14) gate decision can be executed within 4–6 weeks instead of 6–10 months.

## Risk 16 - Technical - Volumetric Energy Density (1000 Wh/L) Feasibility
The 1000 Wh/L volumetric target is as challenging as the 500 Wh/kg gravimetric target, yet the strategy emphasizes gravimetric density more heavily in its chemistry choices. Lithium-sulfur and conversion-cathode chemistries can achieve high Wh/kg but often require thick separators, large electrolyte volumes or low-density cathode structures that erode volumetric density. The risk is that a chemistry that hits 500 Wh/kg may only achieve 700–800 Wh/L because of volumetric penalties not captured in material-level calculations.

**Impact:** If the winning chemistry at Month 36 (2029-10-14) demonstrates 520 Wh/kg but only 850 Wh/L, the programme would need 6–12 months of redesign (thinner separators, higher-density cathode) to close the 150 Wh/L gap, or risk delivering a partial success. Redesign could require a new chemistry iteration (anode-free with higher volumetric density) or aggressive cell architecture changes (bipolar stacking, pressure hardware) that themselves need 6–12 months to stabilize.

**Likelihood:** Medium

**Severity:** High

**Action:** Include volumetric energy density as an explicit gate criterion alongside gravimetric density from Month 12 (2027-10-14) onward. Require the dedicated mass-and-volume model to track not only Wh/kg but also Wh/L for every candidate; any chemistry that projects <950 Wh/L at cell level is flagged for focused redesign by Month 18 (2028-04-14). By Month 30 (2029-04-14), require pouch-cell data showing both ≥500 Wh/kg and ≥950 Wh/L measured in the same cells, not separate demonstrations. If a chemistry meets gravimetric but not volumetric targets by Month 36 (2029-10-14), allocate a 6-month architecture-focused sprint (bipolar, anode-free optimization) before the mid-gate decision, rather than deferring volumetric work to later phases.

## Risk 17 - Regulatory & Permitting - State and Federal EHS Compliance
The programme handles hazardous materials (lithium metal, fluorinated solvents, toxic precursors) and runs abuse tests (thermal runaway, overcharge) that generate regulatory reporting obligations. Violations of EPA hazardous-waste rules, OSHA worker safety standards or state environmental permitting could result in fines, operational closure or loss of license. The 7-year timeline includes potential regulatory changes (e.g., stricter VOC limits, new lithium-handling rules) that could force costly retrofits.

**Impact:** A serious EHS incident (e.g., lithium-water reaction fire, solvent spill) could trigger a 2–4 week facility shutdown, investigation and USD 1–3 M in remediation costs, plus reputational damage and insurance premium increases (proposed: 20–30% for 2–3 years). A surprise regulatory change (e.g., new federal rules on lithium-ion battery recycling or thermal-runaway test standards) in Year 3 could force USD 2–5 M in facility upgrades and 2–3 month process adjustments. Failure to maintain permits could prohibit synthesis or testing for 1–3 months while compliance is restored.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish an in-house EHS compliance function by Month 1 (2026-11-14), led by an experienced environmental health and safety officer with battery-lab credentials. Conduct a comprehensive regulatory assessment by Month 2 (2026-12-14) covering EPA, OSHA, Texas Commission on Environmental Quality, Department of Transportation (for materials shipping) and local fire codes. Implement quarterly internal audits and annual compliance reviews; budget USD 500 K–1 M/year for EHS staff, training and compliance services. Establish a standing relationship with a regulatory consulting firm to monitor evolving federal and state rules and prepare adaptation plans. Allocate USD 1–2 M contingency for unexpected retrofit or remediation costs.

## Risk 18 - Operational - Austin Market Talent Saturation and Poaching
The Austin area has a concentrated battery and EV engineering community around Tesla, Austin Energy Storage, and automotive suppliers. While this offers recruitment advantages, it also means competing firms (Tesla, other EV startups) are actively recruiting the same talent pool. Salaries for senior battery scientists and cell-design engineers have risen 20–30% in recent years. The programme's non-commercial, research-focused framing may appeal to some candidates but deter others seeking equity upside or higher industrial salaries.

**Impact:** If the programme offers competitive salaries (proposed: 10–20% premium on industry baseline to offset non-commercial status), payroll for 80–120 FTE could reach USD 8–12 M/year, consuming 19–28% of the USD 43 M annual budget. Losing a key chemistry lead or pilot-line manager to a rival firm mid-programme (Month 18–36 = 2028-04-14 to 2029-10-14) could cost USD 1–2 M in replacement hiring and 2–4 month knowledge-transfer delays. If attrition exceeds 15% annually, continuous turnover could degrade institutional knowledge and reproducibility.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Structure compensation to compete: offer 15–20% salary premium over market baseline for senior roles (chemistry leads, characterization experts), augmented with signing bonuses (USD 50–150 K for mid-career scientists) and professional-development budgets (USD 10–20 K/person/year for conferences, training). Build retention agreements with key personnel (3–5 year terms, clawback for early departure). Establish a 'stay' plan: publish early wins in peer-reviewed journals (boosting researcher prestige), and offer leadership roles (publication authorship, internal committee participation) that increase job satisfaction. Partner with UT Austin for graduate recruitment (reduced overhead, early career development) to offset senior-hire dependency.

## Risk 19 - Strategic - Long-Term Sustainability and Technology Transfer
The programme is explicitly not aimed at becoming an industrial player, but at inventing and demonstrating a technology. However, there is no clear hand-off or licensing plan for the final result. If the 500 Wh/kg, 1000 Wh/L cell is demonstrated by Month 72 (2032-10-14), who manufactures it at scale? Who commercializes the patents? A weak or unclear exit strategy could leave a successful invention without a clear path to real-world impact, or result in unfavorable licensing terms.

**Impact:** An invention delivered at Month 72 (2032-10-14) without a pre-negotiated licensing or technology-transfer agreement could delay commercial deployment by 12–24 months while potential manufacturers evaluate, negotiate and finalize agreements. Poor licensing terms (e.g., exclusive license to a single competitor, royalty rates that undervalue the invention) could reduce the economic return on the USD 300 M investment. Alternatively, lack of clear commercialization could result in the invention being shelved or licensed at a steep discount.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 12 (2027-10-14), identify potential licensing or manufacturing partners (e.g., established battery makers, automotive OEMs, energy-storage firms) and engage them in informal technical advisory relationships. Develop a licensing framework by Month 24 (2028-10-14) that clarifies IP ownership, royalty structures, manufacturing obligations and exclusivity terms. Structure the final 12 months (Months 72–84 = 2032-10-14 to 2033-10-14) as a technology-transfer phase: documentation, process scale-up guidance, manufacturing feasibility studies and partnerships with a likely licensee. Consider a 'tiered' exit: exclusive license to a single strategic partner for core automotive/aviation applications, non-exclusive license for energy-storage and other secondary uses, to maximize reach and return.

## Risk 20 - Technical - Cycle-Life and Degradation Mechanisms
Reaching 500 Wh/kg and 1000 Wh/L often comes at the cost of reduced cycle life. Lithium-metal anodes suffer dendrite growth and lithium-ion loss, sulfur cathodes polysulfide dissolution, and high-voltage cathodes electrolyte oxidation. A cell that achieves the energy targets but has <200 cycles of usable life (80% capacity retention) would not be a practical battery. The plan does not explicitly define a minimum cycle-life threshold, risking a 'one-cycle wonder' that meets the letter of the goal but not real-world utility.

**Impact:** A chemistry that demonstrates 520 Wh/kg, 1050 Wh/L but degrades to 80% capacity in 150 cycles would require 6–12 months of redesign (stable interface engineering, cathode doping, electrolyte additives) to extend cycle life. If the redesign is not successful, the programme would need to pivot to a different chemistry, compressing the final optimization window. A published result showing high energy density but poor cycle life would also damage the programme's credibility.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish a minimum cycle-life requirement as a hard gate criterion by Month 6 (2027-04-14): proposed threshold of ≥300 cycles at 80% capacity retention at the cell level. Include cycle-life performance in every gate review from Month 18 (2028-04-14) onward. By Month 24 (2028-10-14), all chemistry candidates must demonstrate cycle-life data; any candidate with <250 cycles at 80% is deprioritized unless it is within one iteration (2–4 month redesign) of target. Allocate 15–20% of discovery effort to interface stability and degradation-mechanism research; characterize failure modes quarterly (SEMs of cycled electrodes, electrolyte decomposition analysis) to catch cycle-life limitations early and guide mitigation.

## Risk 21 - Technical - Manufacturing Scale and Process Control
A cell demonstrated at lab scale (100–500 cells built and tested) may not translate to pilot scale (1,000+ cells) without discovering process-control issues. Dry-room humidity, electrode coating uniformity, cell stacking precision and electrolyte dosing all affect reproducibility. Cells built by hand or with limited automation can hide process variability that becomes critical when scaled. If the winning chemistry requires ultra-tight process windows (e.g., lithium-metal protection layer thickness within ±5 µm), pilot-line commissioning and reproducibility could stretch to 6–12 months.

**Impact:** Discovering at Month 60 (2031-10-14) that the lab-scale cell's 500 Wh/kg result cannot be replicated at pilot scale (builds drop to 480 Wh/kg, or 50% of cells are non-functional) would require 6–12 month process-development effort, compressing the final optimization window. The programme would risk missing the Month 84 (2033-10-14) delivery date or delivering a result that is not reproducible. Alternatively, scaling to a less demanding process (thicker separators, lower current density) to ensure reproducibility would sacrifice the Wh/kg and Wh/L targets.

**Likelihood:** Medium

**Severity:** High

**Action:** Begin process-scale-up work by Month 18 (2028-04-14) for the leading chemistry candidate, building at least 50–100 full pouch cells per month by Month 24 (2028-10-14) to expose scaling issues early. Establish a process-control discipline: document cell-build parameters (humidity, temperature, coating thickness, electrolyte volume) for every cell by Month 20 (2028-06-14), and correlate performance variation to process variability. By Month 30 (2029-04-14), require the pilot line to demonstrate batch-to-batch reproducibility (90% of cells meeting target Wh/kg within ±10%) as a gate criterion. Allocate 10–15% of discovery effort to manufacturing-science work: process optimization, design-of-experiments for key parameters, and pilot-line automation where it reduces variability.

## Risk 22 - Operational - Computing and Simulation Infrastructure
The discovery-engine strategy relies on computational materials screening and machine-learning proposal of candidates. This requires high-performance computing (HPC) resources, validated simulation codes and trained staff. Building or accessing sufficient HPC capacity and integrating it with robotic synthesis and characterization data pipelines is complex and often underestimated. If computing infrastructure lags, the discovery loop becomes data-limited rather than hypothesis-limited, negating the throughput benefit of automation.

**Impact:** Inadequate HPC capacity or poor data integration could reduce discovery throughput by 30–50%, delaying identification of viable candidates by 3–6 months. A computational model that is not validated experimentally (e.g., a machine-learning predictor of interfacial stability that correlates poorly with real cycled cells) could lead to wasted synthesis effort on predicted candidates that do not perform. Building or leasing HPC capacity could cost USD 5–10 M upfront and USD 1–2 M/year in operating cost, competing with other budget priorities.

**Likelihood:** Medium

**Severity:** Medium

**Action:** By Month 3 (2027-01-14), establish a computing infrastructure plan: identify a partnership with a national laboratory (e.g., NREL, Lawrence Berkeley Lab) for HPC access, or commit to cloud computing (AWS, Google Cloud) for scalable capacity (estimated USD 500 K–2 M/year). Dedicate a 2–3 person computational-chemistry team to validate simulation codes against experimental data by Month 12 (2027-10-14); any model with <80% predictive accuracy for key properties (interfacial resistance, voltage stability) is not used for candidate ranking until validated. Integrate data pipelines by Month 9 (2027-07-14): automated collection of cell-cycling data, post-mortem characterization results and computed properties into a searchable database that feeds machine-learning model retraining monthly.

## Risk 23 - Technical - Third-Party Certification and Benchmarking
Claiming a cell has achieved 500 Wh/kg and 1000 Wh/L requires independent verification that the numbers are real, not inflated by measurement artifacts or optimistic assumptions. Third-party testing (e.g., by an accredited independent lab such as one affiliated with an automotive safety organization) can cost USD 20–50 K per full-characterization protocol and adds 6–12 week turnarounds. If the programme waits until Month 60–72 (2031-10-14 to 2032-10-14) to commission third-party validation, late-discovered issues could delay publication.

**Impact:** Third-party testing of 10–15 candidate cells (multiple chemistries, to ensure reproducibility) over the 7-year period could cost USD 200–750 K, which is manageable but adds execution risk. If third-party testing uncovers measurement discrepancies (e.g., actual measured Wh/kg is 480 instead of claimed 510), the programme must either redesign or accept a lower headline number. Late discovery (Month 66+) would leave insufficient time to remedy. Industry skepticism about undocumented in-house measurements could undermine patent value and licensing appeal.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish third-party verification protocols by Month 12 (2027-10-14): identify 2–3 independent labs or test facilities capable of full cell characterization and abuse testing (e.g., accredited battery-testing organizations, university partnerships with external credibility). Conduct first independent verification of a pouch cell by Month 30 (early milestone cell, not necessarily the ultimate goal cell) to catch any measurement methodology issues and build confidence. Plan for final third-party validation of the goal cell by Month 72 (2032-10-14), allowing 6-month review and publication before the Month 84 (2033-10-14) end date. Budget USD 50–100 K/year for third-party testing; reserve capacity for rapid validation if a breakthrough cell is achieved ahead of schedule.

## Risk summary
This battery-invention programme faces three critical risks that, if not actively managed, could jeopardize delivery of a 500 Wh/kg, 1000 Wh/L cell by Month 84 (2033-10-14). First, the staged chemistry tournament could fail to identify a viable path, leaving the programme at Month 36 (2029-10-14) with three exhausted candidates and insufficient runway for a meaningful pivot; establishing clear go/no-go criteria by Month 18 (2028-04-14) and requiring independent pouch-cell proof by Month 30 (2029-04-14) are essential safeguards. Second, packaging and volumetric-density penalties could emerge late, threatening the 1000 Wh/L target; treating volumetric density as a gate criterion from Month 12 (2027-10-14) and requiring measured pouch-cell data on both Wh/kg and Wh/L by Month 30 (2029-04-14) will force early discipline. Third, the fixed USD 300 M budget and early capital commitments (pilot line, facility, hiring) could leave insufficient working capital for later iterations and pivots; structuring funding release in tranches tied to demonstrated milestones and holding a USD 15–20 M contingency reserve will provide flexibility. Operational risks (site permitting delays, talent attrition, partner dependency) are secondary but should be managed through early regulatory engagement, competitive compensation, and formal agreements with backup partners. The strategy's emphasis on hedging chemistry risk and imposing system-level discipline early is sound for a high-ambition, capital-constrained, non-commercial invention programme.