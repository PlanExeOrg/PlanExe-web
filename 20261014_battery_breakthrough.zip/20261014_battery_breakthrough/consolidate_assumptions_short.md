# Purpose
and

# Domain
# Battery Electrochemistry Research Programme

## Primary Domain

Battery Electrochemistry is the outcome domain and owns the success criterion of inventing a ≥500 Wh/kg chemistry.

## Secondary Domains

Materials Science, Battery Cell Engineering, and Research Program Management are subordinate methods.

## Disciplines Involved

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Battery Electrochemistry | 5 | 5 | outcome | Core success criterion: inventing a ≥500 Wh/kg rechargeable chemistry. |
| Materials Science | 4 | 4 | method | Novel electrode, electrolyte and interface materials discovery underpins energy density gains. |
| Battery Cell Engineering | 4 | 4 | method | Prototype cell design, fabrication and testing must demonstrate Wh/kg and Wh/L targets. |
| Battery Safety Engineering | 4 | 4 | constraint | High-energy-density cells face thermal runaway and abuse-tolerance certification constraints. |
| Solid-State Ionics | 4 | 4 | method | Ion transport in novel electrolytes and interfaces limits achieving 500 Wh/kg cells. |
| Research Program Management | 4 | 3 | method | Seven-year, USD 300 M R&D programme requires stage-gated technology development governance. |
| Battery Manufacturing Engineering | 3 | 4 | method | Pilot-line fabrication and scale-up needed to demonstrate cells reproducibly. |
| Computational Materials Discovery | 3 | 4 | method | Simulation and machine learning accelerate screening of high-energy electrode and electrolyte chemistries. |
| Intellectual Property Strategy | 2 | 3 | constraint | Invention-focused programme needs patent protection and freedom-to-operate analysis. |

# Plan Type
# Battery R&D Project Plan

## Overview

Next-generation rechargeable battery development with a target of at least 500 Wh/kg and 1000 Wh/L energy density. USD 300 M budget over 7 years, sited near Tesla in Austin, Texas.

## Rationale for Physical Location

The plan requires a physical R&D campus in the Austin area. Battery invention depends on:

- Wet-chemistry and materials synthesis laboratories
- Procurement of raw materials and precursors
- Electrode and cell fabrication on pilot-line equipment
- Prototype cell assembly, cycling, and characterization
- Testing under abuse conditions (thermal runaway, nail penetration, overcharge) in safety test chambers
- Hiring and retaining scientists and engineers in Tesla's Austin ecosystem
- Equipment procurement and third-party certification testing

Computational materials discovery supports the effort but cannot replace experimental synthesis, cell building, and measurement of energy density on real hardware. No part of the plan can be completed exclusively online.

# Physical Locations
# Physical Location Requirements

- Within commuting distance of Tesla Gigafactory Texas, east Austin, for talent and supplier access
- Zoning permitting light industrial/lab use with wet chemistry, dry rooms and reactive metals
- Space for dry room, pilot pouch-cell line, abuse-test chambers and characterization labs (estimate 5,000-10,000 m2)
- Adequate power, ventilation, hazardous-waste handling and fire-authority access
- Proximity to University of Texas at Austin for partnerships and recruitment
- Close to Austin-Bergstrom airport and highways for equipment and materials logistics
- Ability to start lease or fit-out immediately (Month 0 = 2026-10-14)

## Location 1: Northeast Travis County, Austin

Light-industrial or flex R&D parcels near SH-130 and Tesla Gigafactory Texas, Austin, TX

Closest option to Tesla site. Industrial zoning, large buildable lots, and easy highway access suit dry rooms and hazardous-materials handling. Highest talent competition and IP contamination exposure.

## Location 2: Southeast Austin

Industrial/R&D parks along SH-71 and Burleson Road, Austin, TX

Existing light-industrial and lab-capable buildings reduce fit-out time. Airport access eases logistics of precursors and equipment. About 25-35 minutes from Tesla and central to the Austin technical workforce.

## Location 3: North Austin, UT Pickle Research Campus Area

Research/industrial sites near Pickle Research Campus, Burnet Road and Braker Lane, Austin, TX

Adjacent to University of Texas research facilities, supporting partnerships, shared characterization access and graduate recruitment. Established lab-oriented zoning. Longer distance from Tesla reduces direct poaching pressure while remaining within the Austin ecosystem.

## Location 4: Pflugerville/Hutto, Austin Metro

Industrial parks in Pflugerville or Hutto, TX

Lower land and lease costs and room for expansion. Hazardous-use permitting often simpler. Within roughly 20-30 minutes of the Tesla site and the Austin labor pool.

## Location Summary

Four candidate areas near Tesla in Austin, Texas trade off proximity to Tesla, fit-out speed, university access, cost and hazardous-materials permitting.

# Currency Strategy
and

# Identify Risks
# Risk 1 - Technical - Chemistry Pathway

Medium likelihood, High severity.

The staged tournament across three to four chemistries (lithium-sulfur, anode-free solid-state, conversion cathodes) may fail to identify a viable path to 500 Wh/kg and 1000 Wh/L by Month 36 (2029-10-14). Material-level gains often collapse at cell level once packaging overhead is included.

Impact: Failed chemistry tournament at Month 36 (2029-10-14) forces 6–12 month redesign or restart, consuming USD 20–40 M in sunk capital and delaying cell-level proof by 12–24 months. Programme may reach Month 48–60 (2030-10-14 to 2031-10-14) before identifying viable route, leaving insufficient time to mature to demonstrable cell level.

Action: Establish clear go/no-go criteria for each chemistry by Month 18 (2028-04-14), including quantified cycle-life (proposed: ≥500 cycles), interfacial resistance targets, and system-level mass-and-volume model accounting for packaging penalties. Quarterly reviews with external technical advisors. Build contingency chemistry held in reserve; option to accelerate if two leading candidates fail by Month 24 (2028-10-14).

# Risk 2 - Technical - Cell-Level Proof Standard

Medium likelihood, High severity.

Dual-track metric (material-level targets back-calculated from cell model) may not translate into real pouch-cell verification early enough. If full pouch cells are not independently tested until Month 48 (2030-10-14) or later, inactive-mass surprises could reveal chemistry cannot meet 1000 Wh/L at cell level.

Impact: Late discovery of packaging penalties consumes USD 10–20 M in rework or forces acceptance below target. One-cycle cell meeting goal but with <100 cycle life would satisfy stated criterion but not practical utility, delaying validation to Month 60+.

Action: Require independent third-party pouch-cell verification of at least one chemistry finalist by Month 30 (2029-04-14), before mid-gate decision. Define minimum cycle life (proposed: ≥300 cycles at 80% capacity retention) as hard pass/fail threshold from Month 24 (2028-10-14) onward. Dedicated team builds live mass-and-volume model updated quarterly; publish Wh/kg mismatch by Month 20 (2028-06-14).

# Risk 3 - Operational - Pilot Line and Dry Room

High likelihood, High severity.

Uncertainty about whether to build, lease, or modularize dry room and pouch-cell line creates schedule and capital risk. If decision is deferred, early months lack fabrication capacity to build pouch cells for proof-of-concept. Leased external line adds queue time and confidentiality exposure. New build risks 6–12 month commissioning delays and capital lock-in before chemistry is proven.

Impact: Delayed or underspecified pilot line defers first pouch-cell builds to Month 8–12 (2027-06-14 to 2027-10-14), compressing discovery loop. New in-house build consumes USD 30–50 M and 12 months, leaving only USD 250–270 M for five years of operation. External leasing adds 4–8 week queues, slowing iteration to one build per month instead of per week.

Action: By Month 1 (2026-11-14), decide on modular, containerized dry-room and pouch-cell line (leased capacity with ownership option) deployed at Austin site by Month 3 (2027-01-14) and scalable as needed. Negotiate pilot-line agreement with university or national-laboratory partner by Month 2 (2026-12-14) for backup pouch-cell fabrication at cost during commissioning. Size line for 50–100 pouch-cell builds per month; reserve USD 15–20 M and 6-month lead time in budget.

# Risk 4 - Operational - Location and Permitting

High likelihood, Medium severity.

Site selection and permitting for hazardous materials (reactive metals, flammable solvents, abuse-test chambers) may extend beyond Month 3 (2027-01-14). Local fire authority and environmental-health approvals in Austin area can take 4–8 months. Conservative permitting may exclude reactive chemistries from on-site work, forcing outsourcing and slowing iteration.

Impact: 6–8 month permitting delay pushes operational start to Month 6–8 (2027-04-14 to 2027-06-14), compressing 84-month programme to 76–78 months of effective work. Restrictive permit terms exclude lithium-metal synthesis from site, requiring outsourcing at USD 5–10 M/year cost with 4–6 week turnarounds. Conservative zoning blocks planned abuse-test facility build-out.

Action: Initiate site selection, lease negotiation and permitting in Month 0 (2026-10-14), targeting occupancy by Month 2 (2026-12-14). Engage Austin fire authority and Texas environmental regulators in Month 0 (2026-10-14) as collaborative partners. Propose phased permit approach: pilot-phase dry-room operation by Month 3 (2027-01-14); full synthesis and abuse-testing capability by Month 9 (2027-07-14). Pre-negotiate with licensed external synthesis facilities to handle any on-site-prohibited chemistries at cost-plus terms.

# Risk 5 - Financial - Budget and Burn Rate

High likelihood, Medium severity.

USD 300 M budget over seven years (approximately USD 43 M/year) must cover staff payroll (estimated 80–120 FTE at USD 2–4 M/year total), facility lease and utilities (USD 2–5 M/year), capital equipment (dry room, characterization instruments, pilot line: USD 40–60 M upfront), third-party testing and partnerships (USD 3–5 M/year), and contingency. Early capital commitments could exceed USD 60–80 M in Years 1–2, leaving insufficient working capital for later experiments.

Impact: Front-loaded capital spending leaves only USD 150–170 M for Years 3–7 (USD 30–34 M/year), throttling iteration speed and forcing staff reductions in later years. Twenty percent cost overrun in pilot-line or facility (USD 10–15 M) compresses remaining budget by 3–5%. If partnerships require cost-sharing (USD 5–10 M/year), programme may run short by Year 5–6.

Action: Structure funding release in tranches linked to demonstrated milestones: Month 0–12 (2026-10-14 to 2027-10-14) (USD 60 M: facility, core team, equipment orders), Month 12–24 (2027-10-14 to 2028-10-14) (USD 80 M: pilot-line commissioning, first chemistry gate), Month 24–36 (2028-10-14 to 2029-10-14) (USD 70 M: mid-programme decision and winning chemistry scale-up), Month 36–84 (2029-10-14 to 2033-10-14) (USD 90 M: proof and optimization). Reserve USD 15–20 M (5–7% contingency) for pivots and unexpected redirection. Negotiate matching grants or co-funding with university and national-laboratory partners (proposed: 10–15% of partnership costs) by Month 6 (2027-04-14) to offset variable costs.

# Risk 6 - Operational - Talent and Recruitment

Medium likelihood, Medium severity.

Recruiting and retaining 80–120 specialized scientists and engineers in battery electrochemistry, materials science, and manufacturing engineering in Austin faces stiff competition from Tesla and other automotive/energy firms. Offering competitive salaries while remaining within fixed USD 300 M budget is difficult. High turnover (proposed risk: >15% annual attrition) forces continuous re-hiring and knowledge loss.

Impact: If attrition reaches 20% annually, programme hires 16–24 replacements per year, consuming 10–15% of operating budget. Loss of key chemistry or characterization lead at Month 12–24 (2027-10-14 to 2028-10-14) sets programme back 3–6 months. Inability to match competitor salaries forces hiring below target expertise level, reducing discovery speed by 20–30%.

Action: Establish recruitment strategy by Month 1 (2026-11-14) including partnership with University of Texas at Austin for graduate-student pipelines (reduces salary burden), and long-term retention agreements (3–5 year commitments with clawback terms) for key leads. Offer sign-on bonuses and stock-option-like arrangements to compete with Tesla. Structure team with 20–30% postdoctoral and graduate-student roles to lower average cost. Build 'stay' plan: by Month 6 (2027-04-14), publish early findings in peer-reviewed journals to enhance researcher prestige and reduce poaching risk.

# Risk 7 - Regulatory & Permitting - Hazardous Materials

Medium likelihood, High severity.

Synthesis of reactive precursors, handling of lithium metal, flammable organic electrolytes, and operation of abuse-test chambers (thermal runaway, nail penetration, overcharge) face overlapping federal (EPA, DOT, OSHA), state (Texas Commission on Environmental Quality), and local (Austin Fire Authority, Travis County) permitting and safety rules. Changes in regulations during seven years could force costly retroactive upgrades.

Impact: Permitting delay or rejection stops synthesis, cell assembly or abuse testing for 2–6 months during Year 1–2, compressing early chemistry evaluation. Retrofitting facility to meet new EHS standards costs USD 2–5 M and requires 3–4 month downtime. Serious incident (electrolyte fire, chemical release) triggers investigative closure and USD 1–3 M in remediation, plus reputational and insurance cost.

Action: Engage Texas environmental and Austin fire authorities in Month 0 (2026-10-14) as collaborative partners; establish standing EHS advisory committee including external regulatory consultants. Develop tiered permitting strategy: pilot-phase dry-room operation by Month 3 (2027-01-14) (low hazard), high-hazard synthesis and abuse testing by Month 6–9 (2027-04-14 to 2027-07-14) once full permits in place. Maintain USD 3–5 M contingency reserve for permitting delays or upgrades. Document all processes, materials and quantities per federal and state databases; conduct internal audits quarterly.

# Risk 8 - Technical - Characterization and Forensics

Medium likelihood, Medium severity.

Split in-house/partner discovery structure depends on reliable access to advanced operando and post-mortem characterization (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy) at universities and national laboratories. If partner access is delayed or unavailable, failed cells cannot be analyzed quickly, slowing design-build-test loop. In-house capability is costly (USD 5–10 M) and risks underutilization.

Impact: Four to eight week queue at partner facility slows discovery loop from 1–2 weeks to 6–10 weeks, reducing testable hypotheses per year by 50–75%. If critical partner facility becomes unavailable, alternative characterization costs USD 50–100 K per failed cell at commercial labs, quickly exhausting characterization budget. Chemistry with subtle failure mechanism may not be detected without rapid operando analysis, leading to months of wasted builds.

Action: Negotiate formal standing agreements with at least two university or national-laboratory characterization facilities by Month 3 (2027-01-14), with guaranteed turnaround (proposed: ≤3 weeks) and priority scheduling for failed-cell analysis. Invest in one core in-house post-mortem capability (scanning electron microscope or X-ray diffraction: USD 2–3 M) by Month 6 (2027-04-14) for rapid triage; outsource deeper operando work. Establish forensics protocol: every failed cell receives standardized autopsy within one week of failure, with structured root-cause report feeding next design iteration. Budget USD 2–3 M/year for commercial characterization services as backstop.

# Risk 9 - Technical - Abuse Tolerance and Safety

Medium likelihood, High severity.

High-energy lithium-rich cells typically exhibit worsened thermal runaway and short-circuit safety margins compared to conventional cells. Early safety evaluation is needed to avoid spending months on chemistry that later fails abuse tests. Building in-house abuse-testing facility requires specialized equipment (USD 3–5 M), permits, and trained staff. Outsourcing adds queue time and cost (USD 20–30 K per full test).

Impact: If abuse testing deferred until Year 2–3, chemistry discovered at Month 18 (2028-04-14) to have thermal runaway onset below 100°C wastes 12–18 months and USD 10–20 M in prior work. Discovering safety issues late forces abandonment of leading candidate at Month 36 mid-gate, leaving only one or two alternatives with insufficient maturation time. Early in-house abuse testing requires USD 3–5 M capital and 4–6 month facility build, competing with other capital priorities.

Action: Establish phased safety-evaluation strategy: Month 3–6 (2027-01-14 to 2027-04-14), coin-cell and small pouch-cell thermal-ramp tests (inexpensive, in-house or outsourced) to rank chemistries. Month 6–12 (2027-04-14 to 2027-10-14), contract or lease access to established abuse-testing facility for nail-penetration and overcharge on selected candidates. Month 12 (2027-10-14) onward, if chemistry passes early gates, build or acquire dedicated in-house abuse chambers (USD 3–5 M) for rapid iteration. Require every chemistry finalist to pass defined safety thresholds (proposed: thermal runaway onset ≥120°C, reversible after overcharge) before advancing to mid-gate decision.

# Risk 10 - Strategic - IP and Collaboration Risk

Medium likelihood, Medium severity.

Pragmatic Foundation strategy emphasizes open partnership with universities and national laboratories, sharing pre-competitive findings and patenting only final integrated cell architecture. Approach aligns with non-commercial invention goal but risks weak patent position if final design draws heavily on openly published partner work. Employees hired from Tesla or nearby firms may carry implicit knowledge of competing work, creating IP-contamination exposure.

Impact: Patent estate limited to final integrated design (rather than enabling compositions, processes and cell formats) reduces licensing value by 30–50% and invites design-around by competitors. If employee from Tesla brings proprietary knowledge and contaminates design, Tesla could claim prior art or misappropriation, jeopardizing patent validity. Strict clean-room protocols and limited IP sharing could deter university and national-laboratory partners, reducing cost-sharing and characterization access.

Action: Develop clear IP strategy by Month 2 (2026-12-14): file provisional patents on key compositions, electrolyte architectures and cell formats as they emerge, while publishing non-core materials work in peer-reviewed journals to establish priority. Implement strict IP-onboarding protocols for hires from Tesla: background checks, signed non-use agreements, 6-month observation period before access to sensitive designs. Structure university and national-laboratory agreements to permit publication of materials and methods after 6-month review windows, reserving claims on final cell architectures and processes for in-house patents.

# Risk 11 - Operational - External Partnership Dependency

Medium likelihood, Medium severity.

Strategy relies heavily on university and national-laboratory partners for characterization, candidate validation and cost-sharing. Partners may have competing priorities or shifting staffing. If key partner (e.g., Argonne National Lab, UT Austin materials group) deprioritizes work or experiences budget cuts, validation could be delayed or outsourced to commercial labs at much higher cost.

Impact: Loss of key partner's operando X-ray diffraction access at Month 18 (2028-04-14) forces USD 30–50 K per sample at commercial labs, consuming USD 5–10 M/year if samples accumulate. Six-month partner facility downtime (renovation, staff turnover) halts characterization and delays design loop by one cycle (6–12 months). If cost-sharing partners withdraw (proposed risk: 10–20% loss of matched funding), programme absorbs costs internally, compressing working capital by USD 5–10 M.

Action: Negotiate formal long-term agreements (3–5 year) with at least two primary partner institutions by Month 3 (2027-01-14), specifying guaranteed access, turnaround, and upfront cost-sharing commitments (proposed: ≥15% of materials and characterization costs). Identify one backup partner for each critical service (operando diagnostics, computational screening, synthesis validation) so loss of primary partner does not halt work. Structure agreements with escape clauses (30–60 day notice) for rapid transition to alternative providers. Reserve USD 2–3 M/year as partnership contingency for unexpected cost increases or loss-of-access.

# Risk 12 - Technical - Materials Supply and Sourcing

Medium likelihood, Medium severity.

Synthesis and testing depends on steady supply of specialized precursors: lithium compounds, high-purity metal oxides, fluorinated solvents, salts and reactive materials. Supply chains are often long (Asia-based, 8–12 week lead times) and subject to geopolitical disruption, export controls and price volatility.

Impact: Four to eight week delay in key precursor (high-purity lithium carbonate, fluorinated electrolyte salt) halts synthesis, pushing chemistry validation back by one cycle (6–8 weeks). Sudden 20–30% price increase in strategic material adds USD 2–5 M to material costs, compressing other budget areas. Geopolitical export controls force expensive re-sourcing or certification of new suppliers, adding 2–4 months per precursor qualification.

Action: By Month 3 (2027-01-14), establish supplier relationships with at least two qualified vendors for each critical precursor; negotiate annual supply agreements with price-stability clauses (fixed pricing for ≥80% of annual volume) and 12-week minimum lead times. Maintain strategic inventory of key long-lead precursors (3–6 month supply) to buffer against disruption; budget USD 1–2 M for precursor inventory carry. Monitor geopolitical and supply-chain risks quarterly; establish precursor contingency team to identify alternative suppliers or synthetic routes. Factor USD 500 K–1 M/year into contingency reserve for price volatility and emergency re-sourcing.

# Risk 13 - Organizational - Governance and Decision Authority

Low likelihood, Medium severity.

Complex R&D programme with multiple chemistry pathways, external partners and stage-gate funding decisions needs clear governance. Ambiguous decision rights create delays, cost overruns and demoralization. Plan does not clarify role of internal red team or verification function in chosen Pragmatic Foundation path.

Impact: Unclear decision authority at Month 24–30 mid-gate review delays go/no-go decision by 4–8 weeks, compressing remaining timeline. If three chemistry teams disagree on which candidate to advance, deadlock forces costly compromise (continuing two chemistries instead of one), wasting USD 10–15 M on weaker candidate. Ambiguous authority over major redirects (adding fourth chemistry candidate or outsourcing synthesis) leads to ad hoc spending without strategic review.

Action: Establish clear governance structure by Month 1 (2026-11-14): define Scientific Steering Committee (Programme Director, four chemistry leads, external technical advisor, funder representative) with explicit authority over chemistry advancement, gate decisions and budget reallocation. Document go/no-go criteria for each gate (Month 18 = 2028-04-14: cell-level Wh/kg feasibility; Month 30 = 2029-04-14: pouch-cell cycle-life proof; Month 36: mid-gate chemistry selection). Create red team function: standing independent verification group (2–3 scientists, external to core teams) tasked with replicating key results and challenging progress claims before funder reporting. Establish decision timeline: all gate reviews conclude within 3 weeks to avoid downstream compression.

# Risk 14 - Financial - Currency and International Procurement

Medium likelihood, Low severity.

Specialized characterization instruments, pilot-line equipment and advanced materials often come from European or Asian suppliers quoted in EUR or CNY. Fixed USD 300 M budget faces foreign-exchange risk if USD weakens. Ten to fifteen percent USD depreciation against EUR increases imported equipment cost by USD 5–10 M.

Impact: If EUR-denominated equipment purchases (X-ray diffraction chamber, solid-electrolyte separator line) total USD 30–50 M equivalent at Month 2 (2026-12-14), 15% USD depreciation adds USD 4.5–7.5 M by Month 36 (2029-10-14), compressing other budget areas by 1.5–2.5%. Conversely, strengthening USD provides tailwind but is unpredictable. Price-lock agreements add 2–5% upfront premium.

Action: Identify all major equipment and material purchases with expected EUR or foreign-currency costs by Month 2 (2026-12-14); negotiate fixed-price contracts in USD or with forward exchange agreements to lock rates for capital equipment orders in Months 2–6 (2026-12-14 to 2027-04-14). For ongoing material purchases, request supplier pricing in USD where feasible; budget USD 2–3 M (1% contingency) for currency fluctuation on necessary foreign-currency purchases. Monitor exchange rates quarterly; if USD weakens beyond 10% on key procurement corridors, trigger budget review to defer non-critical equipment or seek alternative domestic suppliers.

# Risk 15 - Strategic - Mid-Programme Pivot Cost and Timing

Medium likelihood, High severity.

Staged tournament strategy assumes programme can pivot from failed chemistry to backup option at Month 36 (2029-10-14) with minimal lost time. In practice, pivot requires re-establishing supply chains (2–4 months), rebuilding chemistry-specific equipment (2–3 months), and retraining staff (1–2 months). Effective pivot cost and time could be 6–10 months.

Impact: Pivot at Month 36 (2029-10-14) from lithium-sulfur to anode-free solid-state costs USD 5–10 M in retooling and burns 6–10 months, pushing to Month 42–46 (2030-04-14 to 2030-08-14) before solid-state proof is in hand. With only 38–42 months remaining in 84-month timeline, insufficient time exists to mature chemistry to production-ready cell level. Programme delivers proof-of-concept but not hand-off ready for licensing.

Action: Build detailed pivot plans for each reserve chemistry by Month 12 (2027-10-14): pre-qualify precursor suppliers, document process variations and equipment needs, cross-train 20–30% of synthesis and pilot-line team on each reserve path. Establish pivot runway reserve in budget: USD 10–15 M (3–5% of total) held unallocated through Month 30 (2029-04-14), available for rapid pivots if leading chemistry fails. By Month 24 (2028-10-14), if two of three leading chemistries show fundamental limitations, pre-stage third chemistry (order long-lead precursors, prepare equipment) so Month 30 (2029-04-14) gate decision executes within 4–6 weeks instead of 6–10 months.

# Risk 16 - Technical - Volumetric Energy Density (1000 Wh/L) Feasibility

Medium likelihood, High severity.

One thousand Wh/L volumetric target is as challenging as 500 Wh/kg gravimetric target, yet strategy emphasizes gravimetric more heavily. Lithium-sulfur and conversion-cathode chemistries achieve high Wh/kg but require thick separators, large electrolyte volumes or low-density cathode structures that erode volumetric density. Winning chemistry may hit 500 Wh/kg but only 700–800 Wh/L due to volumetric penalties not captured in material-level calculations.

Impact: Winning chemistry at Month 36 (2029-10-14) demonstrates 520 Wh/kg but only 850 Wh/L, requiring 6–12 month redesign (thinner separators, higher-density cathode) to close 150 Wh/L gap, or forcing partial success. Redesign could require new chemistry iteration (anode-free with higher volumetric density) or aggressive cell architecture changes (bipolar stacking, pressure hardware) needing 6–12 month stabilization.

Action: Include volumetric energy density as explicit gate criterion alongside gravimetric from Month 12 (2027-10-14) onward. Require mass-and-volume model to track both Wh/kg and Wh/L for every candidate; flag any chemistry projecting <950 Wh/L at cell level for focused redesign by Month 18 (2028-04-14). By Month 30 (2029-04-14), require pouch-cell data showing both ≥500 Wh/kg and ≥950 Wh/L measured in same cells, not separate demonstrations. If chemistry meets gravimetric but not volumetric targets by Month 36 (2029-10-14), allocate 6-month architecture-focused sprint (bipolar, anode-free optimization) before mid-gate decision rather than deferring volumetric work to later phases.

# Risk 17 - Regulatory & Permitting - State and Federal EHS Compliance

Medium likelihood, Medium severity.

Programme handles hazardous materials (lithium metal, fluorinated solvents, toxic precursors) and runs abuse tests (thermal runaway, overcharge) generating regulatory reporting obligations. Violations of EPA hazardous-waste rules, OSHA worker safety standards or state environmental permitting result in fines, operational closure or loss of license. Seven-year timeline includes potential regulatory changes forcing costly retrofits.

Impact: Serious EHS incident (lithium-water reaction fire, solvent spill) triggers 2–4 week facility shutdown, investigation and USD 1–3 M in remediation, plus reputational damage and insurance premium increases (proposed: 20–30% for 2–3 years). Surprise regulatory change (new federal rules on lithium-ion battery recycling or thermal-runaway test standards) in Year 3 forces USD 2–5 M in facility upgrades and 2–3 month process adjustments. Failure to maintain permits prohibits synthesis or testing for 1–3 months.

Action: Establish in-house EHS compliance function by Month 1 (2026-11-14), led by experienced environmental health and safety officer with battery-lab credentials. Conduct comprehensive regulatory assessment by Month 2 (2026-12-14) covering EPA, OSHA, Texas Commission on Environmental Quality, Department of Transportation and local fire codes. Implement quarterly internal audits and annual compliance reviews; budget USD 500 K–1 M/year for EHS staff, training and compliance services. Establish standing relationship with regulatory consulting firm to monitor evolving rules and prepare adaptation plans. Allocate USD 1–2 M contingency for unexpected retrofit or remediation.

# Risk 18 - Operational - Austin Market Talent Saturation and Poaching

Medium likelihood, Medium severity.

Austin area has concentrated battery and EV engineering community around Tesla and automotive suppliers, offering recruitment advantages but also meaning competing firms actively recruit same talent pool. Salaries for senior battery scientists and cell-design engineers have risen 20–30% in recent years. Non-commercial, research-focused framing appeals to some candidates but deters others seeking equity upside or higher industrial salaries.

Impact: If programme offers competitive salaries (proposed: 10–20% premium on industry baseline), payroll for 80–120 FTE reaches USD 8–12 M/year, consuming 19–28% of USD 43 M annual budget. Losing key chemistry lead or pilot-line manager mid-programme (Month 18–36 = 2028-04-14 to 2029-10-14) costs USD 1–2 M in replacement hiring and 2–4 month knowledge-transfer delays. If attrition exceeds 15% annually, continuous turnover degrades institutional knowledge and reproducibility.

Action: Structure compensation to compete: offer 15–20% salary premium over market baseline for senior roles, augmented with sign-on bonuses (USD 50–150 K for mid-career scientists) and professional-development budgets (USD 10–20 K/person/year). Build retention agreements with key personnel (3–5 year terms, clawback for early departure). Establish stay plan: publish early wins in peer-reviewed journals (boosting researcher prestige), and offer leadership roles (publication authorship, internal committee participation) that increase job satisfaction. Partner with UT Austin for graduate recruitment (reduced overhead, early career development) to offset senior-hire dependency.

# Risk 19 - Strategic - Long-Term Sustainability and Technology Transfer

Medium likelihood, Medium severity.

Programme is explicitly not aimed at becoming industrial player, but at inventing and demonstrating technology. However, no clear hand-off or licensing plan exists for final result. If 500 Wh/kg, 1000 Wh/L cell is demonstrated by Month 72 (2032-10-14), who manufactures at scale? Who commercializes patents? Weak or unclear exit strategy leaves successful invention without clear path to real-world impact.

Impact: Invention delivered at Month 72 (2032-10-14) without pre-negotiated licensing or technology-transfer agreement delays commercial deployment by 12–24 months. Poor licensing terms (exclusive license to single competitor, undervalued royalty rates) reduce economic return on USD 300 M investment. Lack of clear commercialization leaves invention shelved or licensed at steep discount.

Action: By Month 12 (2027-10-14), identify potential licensing or manufacturing partners (established battery makers, automotive OEMs, energy-storage firms) and engage in informal technical advisory relationships. Develop licensing framework by Month 24 (2028-10-14) clarifying IP ownership, royalty structures, manufacturing obligations and exclusivity terms. Structure final 12 months (Months 72–84 = 2032-10-14 to 2033-10-14) as technology-transfer phase: documentation, process scale-up guidance, manufacturing feasibility studies and partnerships with likely licensee. Consider tiered exit: exclusive license to strategic partner for core automotive/aviation applications, non-exclusive license for energy-storage and secondary uses, to maximize reach and return.

# Risk 20 - Technical - Cycle-Life and Degradation Mechanisms

Medium likelihood, High severity.

Reaching 500 Wh/kg and 1000 Wh/L often comes at cost of reduced cycle life. Lithium-metal anodes suffer dendrite growth and lithium-ion loss, sulfur cathodes polysulfide dissolution, and high-voltage cathodes electrolyte oxidation. Cell achieving energy targets but with <200 cycles of usable life (80% capacity retention) would not be practical battery. Plan does not explicitly define minimum cycle-life threshold.

Impact: Chemistry demonstrating 520 Wh/kg, 1050 Wh/L but degrading to 80% capacity in 150 cycles requires 6–12 month redesign (stable interface engineering, cathode doping, electrolyte additives). If redesign unsuccessful, programme pivots to different chemistry, compressing final optimization window. Published result of high energy density but poor cycle life damages programme credibility.

Action: Establish minimum cycle-life requirement as hard gate criterion by Month 6 (2027-04-14): proposed threshold of ≥300 cycles at 80% capacity retention at cell level. Include cycle-life performance in every gate review from Month 18 (2028-04-14) onward. By Month 24 (2028-10-14), all chemistry candidates must demonstrate cycle-life data; candidates with <250 cycles at 80% are deprioritized unless within one iteration (2–4 month redesign) of target. Allocate 15–20% of discovery effort to interface stability and degradation-mechanism research; characterize failure modes quarterly (SEMs of cycled electrodes, electrolyte decomposition analysis) to catch cycle-life limitations early and guide mitigation.

# Risk 21 - Technical - Manufacturing Scale and Process Control

Medium likelihood, High severity.

Cell demonstrated at lab scale (100–500 cells built and tested) may not translate to pilot scale (1,000+ cells) without discovering process-control issues. Dry-room humidity, electrode coating uniformity, cell stacking precision and electrolyte dosing affect reproducibility. Cells built by hand or with limited automation hide process variability that becomes critical when scaled. If winning chemistry requires ultra-tight process windows (e.g., lithium-metal protection layer thickness within ±5 µm), pilot-line commissioning could stretch to 6–12 months.

Impact: Discovering at Month 60 (2031-10-14) that lab-scale 500 Wh/kg result cannot be replicated at pilot scale (builds drop to 480 Wh/kg, or 50% of cells non-functional) requires 6–12 month process-development effort, compressing final optimization window. Programme risks missing Month 84 (2033-10-14) delivery date or delivering non-reproducible result. Alternatively, scaling to less demanding process (thicker separators, lower current density) sacrifices Wh/kg and Wh/L targets.

Action: Begin process-scale-up work by Month 18 (2028-04-14) for leading chemistry candidate, building at least 50–100 full pouch cells per month by Month 24 (2028-10-14) to expose scaling issues early. Establish process-control discipline: document cell-build parameters (humidity, temperature, coating thickness, electrolyte volume) for every cell by Month 20 (2028-06-14), and correlate performance variation to process variability. By Month 30 (2029-04-14), require pilot line to demonstrate batch-to-batch reproducibility (90% of cells meeting target Wh/kg within ±10%) as gate criterion. Allocate 10–15% of discovery effort to manufacturing-science work: process optimization, design-of-experiments for key parameters, and pilot-line automation where it reduces variability.

# Risk 22 - Operational - Computing and Simulation Infrastructure

Medium likelihood, Medium severity.

Discovery-engine strategy relies on computational materials screening and machine-learning proposal of candidates. This requires high-performance computing (HPC) resources, validated simulation codes and trained staff. Building or accessing sufficient HPC capacity and integrating it with robotic synthesis and characterization data pipelines is complex and often underestimated. If computing infrastructure lags, discovery loop becomes data-limited rather than hypothesis-limited.

Impact: Inadequate HPC capacity or poor data integration reduces discovery throughput by 30–50%, delaying identification of viable candidates by 3–6 months. Computational model not validated experimentally (machine-learning predictor of interfacial stability correlating poorly with real cycled cells) leads to wasted synthesis effort on predicted candidates. Building or leasing HPC capacity costs USD 5–10 M upfront and USD 1–2 M/year operating, competing with other budget priorities.

Action: By Month 3 (2027-01-14), establish computing infrastructure plan: identify partnership with national laboratory (e.g., NREL, Lawrence Berkeley Lab) for HPC access, or commit to cloud computing (AWS, Google Cloud) for scalable capacity (estimated USD 500 K–2 M/year). Dedicate 2–3 person computational-chemistry team to validate simulation codes against experimental data by Month 12 (2027-10-14); any model with <80% predictive accuracy for key properties is not used for candidate ranking until validated. Integrate data pipelines by Month 9 (2027-07-14): automated collection of cell-cycling data, post-mortem characterization results and computed properties into searchable database feeding machine-learning model retraining monthly.

# Risk 23 - Technical - Third-Party Certification and Benchmarking

Low likelihood, Medium severity.

Claiming cell has achieved 500 Wh/kg and 1000 Wh/L requires independent verification that numbers are real, not inflated by measurement artifacts or optimistic assumptions. Third-party testing (e.g., accredited independent lab) can cost USD 20–50 K per full-characterization protocol and adds 6–12 week turnarounds. If programme waits until Month 60–72 (2031-10-14 to 2032-10-14) to commission third-party validation, late-discovered issues could delay publication.

Impact: Third-party testing of 10–15 candidate cells (multiple chemistries, to ensure reproducibility) over seven years could cost USD 200–750 K, manageable but adds execution risk. If third-party testing uncovers measurement discrepancies (actual measured Wh/kg is 480 instead of claimed 510), programme must either redesign or accept lower headline number. Late discovery (Month 66+) leaves insufficient time to remedy. Industry skepticism about undocumented in-house measurements could undermine patent value and licensing appeal.

Action: Establish third-party verification protocols by Month 12 (2027-10-14): identify 2–3 independent labs or test facilities capable of full cell characterization and abuse testing (accredited battery-testing organizations, university partnerships with external credibility). Conduct first independent verification of pouch cell by Month 30 (early milestone cell, not necessarily ultimate goal cell) to catch any measurement methodology issues and build confidence. Plan final third-party validation of goal cell by Month 72 (2032-10-14), allowing 6-month review and publication before Month 84 (2033-10-14) end date. Budget USD 50–100 K/year for third-party testing; reserve capacity for rapid validation if breakthrough cell achieved ahead of schedule.

## Risk summary

Three critical risks could jeopardize delivery of a 500 Wh/kg, 1000 Wh/L cell by Month 84 (2033-10-14) if not actively managed. First, staged chemistry tournament could fail to identify viable path, leaving programme at Month 36 (2029-10-14) with three exhausted candidates and insufficient runway for meaningful pivot; establishing clear go/no-go criteria by Month 18 (2028-04-14) and requiring independent pouch-cell proof by Month 30 (2029-04-14) are essential safeguards. Second, packaging and volumetric-density penalties could emerge late, threatening 1000 Wh/L target; treating volumetric density as gate criterion from Month 12 (2027-10-14) and requiring measured pouch-cell data on both Wh/kg and Wh/L by Month 30 forces early discipline. Third, fixed USD 300 M budget and early capital commitments (pilot line, facility, hiring) could leave insufficient working capital for later iterations and pivots; structuring funding release in tranches tied to demonstrated milestones and holding USD 15–20 M contingency reserve provides flexibility. Operational risks (site permitting delays, talent attrition, partner dependency) are secondary but managed through early regulatory engagement, competitive compensation, and formal agreements with backup partners. Strategy's emphasis on hedging chemistry risk and imposing system-level discipline early is sound for high-ambition, capital-constrained, non-commercial invention programme.

# Make Assumptions
# Financial Feasibility

## Budget Phasing and Release

Funds released in evidence-linked tranches:

- Months 0-12 (2026-10-14 to 2027-10-14): USD 60 M
- Months 12-24 (2027-10-14 to 2028-10-14): USD 80 M
- Months 24-36 (2028-10-14 to 2029-10-14): USD 70 M
- Months 36-84 (2029-10-14 to 2033-10-14): USD 90 M

Reserve: USD 15-20 M (5-7% of total).

## Capacity and Risk

Front-loading of pilot line, dry room and hiring may reach USD 60-80 M in Years 1-2 (estimate), leaving roughly USD 30-34 M/year afterwards. A 20% facility overrun would cut remaining funds by 3-5%.

## Mitigation

- Modular leased equipment
- Partner co-funding (proposed 10-15%)
- Reserve held through Month 30 (2029-04-14), preserving pivot capacity at the Month 36 (2029-10-14) gate

# Timeline and Gates

## Key Milestones

- Month 18 (2028-04-14): Go/no-go gate
- Month 30 (2029-04-14): Third-party pouch-cell verification (Wh/kg and Wh/L)
- Month 36 (2029-10-14): Chemistry selection gate
- Month 84 (2033-10-14): Delivery

## Cycle Life Requirement

Minimum 300 cycles at 80% retention (proposed threshold).

## Timeline Feasibility

A failed Month 36 (2029-10-14) gate leaves about 48 months; a pivot costs 6-10 months (estimate). Early pouch proof at Month 30 (2029-04-14) exposes packaging penalties while a pivot is still affordable. Pre-staging reserve chemistry by Month 24 (2028-10-14) shortens pivots to 4-6 weeks.

## Risk Mitigation

Permitting slippage of 6-8 months (estimate) compresses effective work time; mitigate with phased permits.

# Personnel and Retention

## Staffing

80-120 FTE (estimate) with 20-30% postdoctoral and graduate roles. Payroll: USD 8-12 M/year (estimate), about 19-28% of average annual budget.

## Retention

- 10-20% salary premium for senior roles
- 3-5 year retention agreements
- Attrition target: below 15% annually (proposed)

## Attrition Risk

20% attrition means 16-24 replacements per year and lost knowledge.

## Mitigation and Opportunity

- UT Austin pipelines
- Publication incentives
- Clawback-backed retention
- University links reduce cost and broaden talent pool beyond Tesla alumni

# Governance and IP

## Decision Structure

Scientific Steering Committee (director, chemistry leads, external advisor, funder representative) decides gates and reallocations within 3 weeks. Independent red team of 2-3 scientists verifies claims.

## IP and Regulatory Framework

IP terms and licensing framework set by Month 24 (2028-10-14).

## Gate and Patent Risk

Ambiguity at gates could add 4-8 weeks of delay or fund a weaker chemistry at USD 10-15 M (estimate). Clear criteria and independent verification protect credibility and patent value.

## Filing Strategy

File provisionals on compositions and formats as they emerge. Open partner sharing risks 30-50% licence value loss (estimate) if filings are late. Clean-room onboarding limits Tesla contamination claims.

# Safety and Abuse Testing

## Phased Evaluation

- Months 3-6 (2027-01-14 to 2027-04-14): Thermal-ramp screening
- Months 6-12 (2027-04-14 to 2027-10-14): Contracted abuse tests
- Month 12 (2027-10-14) onwards: In-house chambers (USD 3-5 M estimate) if chemistry passes

## Thermal Runaway Threshold

Finalists need thermal runaway onset of at least 120°C (proposed threshold).

## Late Discovery Risk

Discovery of onset below 100°C could waste 12-18 months and USD 10-20 M (estimate). Incidents may cost USD 1-3 M and weeks of shutdown.

## Mitigation

- Staffed EHS function by Month 1 (2026-11-14)
- Quarterly audits
- Standing EHS advisory committee
- Contingency of USD 3-5 M
- Early safety ranking narrows design space

# Environmental Management

## Operations and Permits

Operations permitted under EPA, TCEQ and local rules with licensed hazardous-waste contractor, solvent recovery where feasible. Annual environmental compliance budget: USD 0.5-1 M (estimate).

## Key Waste Streams

Fluorinated solvents, lithium residues, VOCs and failed cells. Dry rooms carry high energy demand.

## Regulatory and Retrofit Risk

Regulatory change may require USD 2-5 M retrofits (estimate).

## Mitigation and Opportunity

- Waste minimisation
- Small-batch synthesis
- Exhaust abatement
- Regulatory monitoring retainer
- Documented low-impact practice eases permitting and partner trust

# Stakeholder Engagement

## Partners and Timelines

- Formal 3-5 year agreements with at least two university or national-lab partners by Month 3 (2027-01-14)
- Early engagement with Austin fire authority
- Informal licensee advisory contacts by Month 12 (2027-10-14)
- Partners fund at least 15% of shared costs (proposed)

## Partner Loss Risk

Partner loss could cost USD 30-50 K per sample at commercial labs and USD 5-10 M over the programme (estimate).

## Mitigation

- Backup partners per critical service
- 30-60 day exit clauses
- USD 2-3 M/year partnership contingency
- Early licensee engagement reduces 12-24 month commercialisation delays
- Community and regulator transparency lowers permit-denial risk

# Operational Systems

## Readiness Timeline

- Month 3-6 (2027-01-14 to 2027-04-14): Modular leased dry-room and pouch line (50-100 cells/month estimate)
- Month 6 (2027-04-14): One in-house post-mortem instrument
- Month 9 (2027-07-14): Unified data pipeline
- Month 3 (2027-01-14): Dual-sourced precursors

## Fabrication Approach

A new owned line may cost USD 30-50 M and 12 months; modular leasing cuts lock-in.

## Throughput and Buffering

Partner queues of 4-8 weeks could cut hypothesis throughput 50-75%, justifying in-house triage. Precursor lead times of 8-12 weeks justify 3-6 months of buffer stock.

## Computing and Reproducibility

Computing: USD 0.5-2 M/year (estimate) via cloud or national-lab access. Require reproducibility of 90% of cells within ±10% by Month 30 (2029-04-14).

# Distill Assumptions
# Battery Development Project Plan

## Project Goal and Constraints

- Invent a battery at ≥500 Wh/kg and ≥1000 Wh/L (user constraint)
- Budget: USD 300 M over 7 years (Months 0-84 = 2026-10-14 to 2033-10-14)
- Location: near Tesla in Austin
- Funds release in evidence-linked tranches: approximately USD 60/80/70/90 M, with USD 15-20 M reserve (proposed)
- Partners co-fund at least 15% of shared costs (proposed)
- Reserve held through Month 30 (2029-04-14)

## Governance and Decision Gates

- Month 18 (2028-04-14): Go/no-go gate
- Month 30 (2029-04-14): Third-party pouch verification; reserve release decision
- Month 36 (2029-10-14): Chemistry selection gate (cut to one finalist)
- Scientific Steering Committee decides gates within 3 weeks
- 2-3 scientist independent red team verifies claims

## Chemistry Approach

- Staged tournament across three or four chemistries
- Layered hybrid electrolyte with thin ceramic or polymer interlayer in minimal-volume liquid
- Reserve chemistry pre-staged by Month 24 (2028-10-14) shortens pivots
- Dual-sourced precursors by Month 3 (2027-01-14); permitting slippage of 6-8 months is a key risk

## Performance and Testing Requirements

- Minimum cycle life: 300 cycles at 80% retention (proposed threshold)
- Thermal runaway onset of at least 120°C for finalists (proposed)
- Reproducibility of 90% of cells within ±10% required by Month 30 (2029-04-14)
- Cell-level mass-and-volume model back-calculates material targets from the start

## Infrastructure and Operations

- Modular leased dry-room and pouch line, 50-100 cells/month (estimate), operating by Months 3-6 (2027-01-14 to 2027-04-14)
- In-house computation ranks candidates; university and national-lab partners validate
- Staffed EHS function by Month 1 (2026-11-14); permitted under EPA, TCEQ and local rules
- Phased safety testing

## Team and Partnerships

- Team of 80-120 FTE (estimate)
- Payroll USD 8-12 M/year
- Attrition below 15% (proposed)
- Formal agreements with at least two university or national-lab partners by Month 3 (2027-01-14)

## IP and Licensing

- IP and licensing framework set by Month 24 (2028-10-14)
- Provisional patents filed as compositions emerge


# Review Assumptions
# Battery-Invention Programme: Expert Review and Risk Assessment

## Domain Context
Applied Strategic R&D Programme Management in electrochemistry, materials science commercialization, and technology-invention risk across capital-constrained research environments.

## Issue 1 – Missing Explicit Minimum Cycle-Life Requirement and Late-Discovery Risk

The plan targets 500 Wh/kg and 1000 Wh/L but does not define a minimum cycle-life threshold as a hard requirement until Month 6 (2027-04-14). A cell meeting energy-density targets but cycling <150 times would satisfy stated success criteria while remaining commercially unusable, wasting 12–18 months of development.

Recommendation:

- Establish ≥300 cycles at 80% capacity retention as a non-negotiable gate criterion by Month 3 (2027-01-14)
- Include cycle-life data collection and degradation-mechanism forensics (post-mortem microscopy, electrolyte decomposition analysis) from Month 6 (2027-04-14) onward for every candidate chemistry
- Require measured cycle-life evidence, not projections, from all finalists advancing past Month 24 (2028-10-14)
- Demote any candidate failing this threshold by Month 30 (2029-04-14) and accelerate the reserve chemistry

Sensitivity:

- Baseline: viable chemistry with ≥300 cycles discovered by Month 30 (2029-04-14)
- Late discovery (Month 48 = 2030-10-14): redesign or pivot costs USD 10–25 M; timeline slips 6–12 months; patent value and licensing credibility reduce 20–30%

## Issue 2 – Volumetric Energy Density (1000 Wh/L) Secondary Treatment and Cell-Architecture Risk

The plan emphasizes gravimetric density (500 Wh/kg) over volumetric density (1000 Wh/L), yet both are equally challenging. Lithium-sulfur and conversion-cathode chemistries may hit Wh/kg while requiring thick electrolyte layers that erode Wh/L. The dual-track model is not verified experimentally until Month 30 (2029-04-14), risking 18 months of wasted effort on fundamentally incompatible chemistries.

Recommendation:

- Elevate volumetric density to parity with gravimetric density from Month 12 (2027-10-14) onward
- Project Wh/L alongside Wh/kg for every candidate; flag any chemistry projecting <950 Wh/L at pouch level by Month 18 (2028-04-14) for redesign
- Mandate independent third-party measured pouch-cell data showing both ≥500 Wh/kg and ≥950 Wh/L in the same cells by Month 30 (2029-04-14)
- If a chemistry hits Wh/kg but falls short of 950 Wh/L by Month 36 (2029-10-14), allocate a focused 6-month architecture sprint before the mid-gate decision

Sensitivity:

- Baseline: winning chemistry achieves both targets by Month 36 (2029-10-14)
- Downside: if a leading chemistry reaches 520 Wh/kg but only 850 Wh/L due to thick separators or large electrolyte volume, and is discovered at Month 36 (2029-10-14), a 6–12 month redesign consumes USD 8–15 M and compresses the final optimization window
- Late discovery (Month 60 = 2031-10-14): programme delivers partial success (500 Wh/kg but 800 Wh/L), reducing invention value as a licensing asset by 30–40%

## Issue 3 – Site Permitting, Regulatory Approval and Operational-Readiness Schedule Compression

The plan assumes site selection, lease and permitting completion by Month 3 (2027-01-14) and pilot-line deployment by Months 3–6 (2027-01-14 to 2027-04-14). In practice, EPA hazardous-waste permits, TCEQ air and water permits, and Austin Fire Authority approvals typically require 4–8 months, especially for new facilities. A 6–8 month delay (plausible and common) would push operational start to Month 6–8 (2027-04-14 to 2027-06-14), compressing the 84-month effective timeline to 76–78 months. Conservative permitting may also force outsourcing of reactive-chemistry synthesis (lithium metal, sulfides, halides) at cost and with 4–6 week turnarounds, slowing iteration 50–70%.

Recommendation:

- Initiate site selection, lease and permitting engagement with Texas environmental and Austin fire authorities in Month 0 (2026-10-14), not Month 1 (2026-11-14)
- Propose tiered permitting with the fire authority: Phase 1 (dry-room and pouch-cell assembly, low-hazard) by Month 3 (2027-01-14); Phase 2 (lithium-metal and solvent synthesis) by Month 6 (2027-04-14); Phase 3 (abuse-testing chambers) by Month 9 (2027-07-14)
- Pre-negotiate with licensed external synthesis facilities (contract research organizations in Texas or California) for any on-site-prohibited chemistry steps at cost-plus terms with <4 week turnarounds
- Establish an EHS compliance function led by an experienced battery-lab engineer by Month 1 (2026-11-14)

Sensitivity:

- Baseline: operational start by Month 3 (2027-01-14); effective programme work = 81 months
- Downside (6-month permitting delay): operational start at Month 9 (2027-07-14); effective work = 75 months. A Month 36 (2029-10-14) chemistry gate compresses the post-gate window from 48 months to 42 months; a pivoted chemistry would have only ~36 months to maturation
- Cost impact: outsourced synthesis at USD 50–100 K per batch could consume USD 2–5 M/year if on-site synthesis is prohibited, reducing remaining budget by 5–12%

## Issue 4 – Pilot-Line Capital Commitment Before Chemistry is Proven: Ownership Versus Leasing Trade-Off

The plan specifies a modular, containerized dry-room and pouch-cell line (50–100 cells/month) without explicitly deciding ownership (~USD 30–50 M, 6–12 month lead time), leasing (~USD 2–5 M/year operational cost, 4–8 week queue), or modularization (~USD 15–25 M, 3–4 month deployment). Building early (Month 0–3 = 2026-10-14 to 2027-01-14) locks USD 30–50 M before a winning chemistry is known, leaving USD 250–270 M for 6.5 years. Leasing preserves capital for pivots but adds queue time and confidentiality exposure. A new-build line also creates stranded-asset risk if the winning chemistry requires fundamentally different conditions (inert atmosphere versus moisture control).

Recommendation:

- By Month 1 (2026-11-14), commit to a modular, leased dry-room and pouch-cell line (not owned) to preserve capital flexibility and pivot capacity
- Target deployment by Month 3 (2027-01-14); negotiate a 3-year lease with expansion and early-exit options
- By Month 2 (2026-12-14), negotiate a standby pilot-line agreement with a university or national-laboratory partner for backup pouch-cell fabrication at cost
- Reserve USD 15–20 M and 6-month lead time in the budget for pilot-line capital needs
- If a winning chemistry emerges by Month 24 (2028-10-14) with high-throughput demands (200+ cells/month), then evaluate building a dedicated line with concrete chemistry-driven specifications

Sensitivity:

- Baseline: modular leased line, ~USD 50–100 K/month operational cost (~USD 0.6–1.2 M/year)
- Downside (owned line): USD 40 M upfront at Month 3 (2027-01-14), reducing available working capital by 13%; sunk-cost risk increases
- If the winning chemistry (Month 36 = 2029-10-14) has dry-room requirements not met by the built line (e.g., <10 ppm water for aggressive lithium-metal work), redesign could cost USD 5–10 M and lose 3–4 months
- Benefit of leasing: a pivot at Month 36 (2029-10-14) requires 2–4 weeks to switch vendors instead of 6–12 months for owned-line recommissioning

## Issue 5 – Chemistry-Tournament Contingency Planning and Mid-Gate Pivot Cost

The Pragmatic Foundation strategy runs a staged tournament across three or four chemistries with a formal gate at Month 36 (2029-10-14). If two of three leading candidates fail by Month 36 (2029-10-14) for fundamental reasons (cycle-life collapse, dendrite growth, volume expansion), the programme must pivot to a reserve chemistry with only 48 months remaining. A pivot from one chemistry to another requires 6–10 months of precursor re-sourcing, pilot-line retooling and staff retraining. A pivot discovered at Month 36 (2029-10-14) might not reach stable pouch-cell production until Month 42–46 (2030-04-14 to 2030-08-14), leaving only 38–42 months for proof—potentially insufficient for a novel chemistry.

Recommendation:

- By Month 12 (2027-10-14), develop detailed contingency plans for each reserve chemistry: pre-qualify suppliers, document process variations and equipment reconfiguration, and cross-train 20–30% of synthesis and pilot-line team on each backup path
- Establish a 'pivot runway' contingency reserve of USD 10–15 M (3–5% of total budget) held unallocated through Month 30 (2029-04-14)
- By Month 24 (2028-10-14), if two of three leading candidates show fundamental limitations (e.g., both stuck below 250 cycles despite 18 months of interface engineering), pre-stage the third chemistry: order long-lead precursors, prepare equipment and train staff
- Shorten pivot execution time from 6–10 months to 4–6 weeks, allowing a Month 30–36 (2029-04-14 to 2029-10-14) decision to translate into Month 36–42 (2029-10-14 to 2030-04-14) commissioning, preserving 42 months for proof

Sensitivity:

- Baseline: successful chemistry identified by Month 30 (2029-04-14), no pivot needed
- Downside (pivot at Month 36 = 2029-10-14): if pivot requires 6–10 months, programme reaches Month 42–46 (2030-04-14 to 2030-08-14) before building pouch cells with new chemistry. With only 38–42 months remaining, proof-of-concept might be achieved but with insufficient time for reliability testing (500+ cycles, abuse tests, third-party verification). Cost: USD 5–10 M in retooling, precursor qualification and retraining (1.7–3.3% of budget)
- Worst case (no contingency plan): pivot at Month 36 (2029-10-14) stretches to Month 50+, leaving only 34 months for final proof, risking incomplete demonstration

## Issue 6 – Talent Recruitment, Retention and Payroll Budget Allocation Under Tesla Competition

The plan assumes 80–120 FTE (estimate) with payroll of USD 8–12 M/year (19–28% of average annual budget) but lacks detail on salary competitiveness, sign-on incentives and retention mechanics. In the Austin area, senior battery scientists and manufacturing engineers earn USD 150–250 K/year in industry (Tesla, other EV firms) versus USD 120–180 K in academic or research settings. Competing for talent while remaining within 25% of annual budget requires either industry-competitive salaries (pushing payroll to 28%) and reduced capital spending, or offsetting lower base pay with graduate-student pipelines, publication prestige and retention agreements—all requiring active management. Unmanaged, payroll could exceed budget and attrition could reach 20% annually, requiring continuous re-hiring and causing knowledge loss.

Recommendation:

- Pay a 15–20% premium over baseline academic salaries for senior chemistry and engineering leads (estimated incremental cost: USD 1–2 M/year across 5–8 key roles)
- Offer signing bonuses (USD 50–150 K for mid-career scientists) and professional-development budgets (USD 10–20 K/person/year)
- Target 20–30% of team as postdoctoral and graduate-student roles to reduce average payroll cost
- By Month 2 (2026-12-14), negotiate a formal recruitment pipeline with University of Texas at Austin, offering stipend supplements and co-authorship on publications
- Establish 3–5 year retention agreements with key personnel (chemistry leads, characterization experts) including clawback terms for early departure
- Publish early wins (Month 6–12 = 2027-04-14 to 2027-10-14) in peer-reviewed journals to enhance researcher prestige and reduce poaching risk
- Target attrition below 15% (proposed); if actual attrition exceeds 15%, trigger a retention review and compensation adjustment by Month 24 (2028-10-14)

Sensitivity:

- Baseline: average payroll USD 10 M/year (25% of annual budget), attrition <15%, turnover cost ~USD 1–2 M/year
- Downside (high attrition): if attrition reaches 20%, programme must hire 16–24 replacements annually, consuming USD 1.5–2.5 M/year in recruiting, onboarding and training (~3 months ramp-up per hire). Loss of a key chemistry lead at Month 12–24 (2027-10-14 to 2028-10-14) could set the programme back 2–4 months
- Salary-competition pressure: if competing firms raise offers by 20%, programme needs USD 1–2 M incremental annually, compressing equipment or partner budgets by 2–5%

## Issue 7 – Characterization and Forensics Access: Partner Dependency and Queue-Time Risk

The Pragmatic Foundation strategy relies on university and national-laboratory partnerships for operando and post-mortem characterization (X-ray diffraction, scanning electron microscopy, electrochemical impedance spectroscopy) to keep in-house instrument costs low. Academic facilities have competing priorities, shifting schedules and occasional closures or staff departures. A 4–8 week queue at a partner facility would slow the design-build-test loop from 1–2 weeks (in-house) to 6–10 weeks, reducing testable hypotheses per year by 50–75%. Loss of a critical partner facility forces outsourcing to commercial labs at USD 50–100 K per failed cell.

Recommendation:

- By Month 3 (2027-01-14), negotiate formal standing agreements with at least two university or national-laboratory characterization facilities, specifying guaranteed access, ≤3 week turnaround (proposed) and annual cost-sharing commitments (≥15% of shared materials and characterization costs borne by partners)
- Invest in one core in-house post-mortem instrument (scanning electron microscope or X-ray diffraction: USD 2–3 M) by Month 6 (2027-04-14) for rapid triage of failed cells; outsource operando work to partners with specialized equipment
- Establish a forensics protocol by Month 3 (2027-01-14): every failed cell receives standardized autopsy within one week, with root-cause report feeding directly into next design iteration
- Develop a 'forensics atlas' (internal database of failure modes, mechanisms and design consequences) by Month 12 (2027-10-14)
- Budget USD 2–3 M/year for commercial characterization services as a backstop if partner access is lost

Sensitivity:

- Baseline: partner access with ≤3 week turnarounds, in-house triage capability, cost-sharing covered by partners
- Downside (loss of primary partner): if a key facility becomes unavailable at Month 18 (2028-04-14), outsourcing characterization at USD 80 K/cell for 50 cells/year would cost USD 4 M/year versus ~USD 1.5 M with partner access, consuming USD 2.5 M/year additional budget (~6% of annual spend)
- Secondary scenario (queue delays): if partner queues extend to 6–8 weeks, discovery loop slows to 1 hypothesis per 2 months instead of per 2 weeks, reducing annual hypothesis throughput by 50% and delaying identification of viable candidates by 3–6 months

## Review Conclusion

The battery-invention programme targets 500 Wh/kg, 1000 Wh/L within a fixed USD 300 M, 7-year timeline through staged chemistry tournament and risk-hedged operations. The Pragmatic Foundation strategy is sound in hedging chemistry risk with a formal gate and imposing system-level discipline early. However, seven critical gaps emerge:

- Minimum cycle-life is undefined as a hard threshold until Month 6 (2027-04-14), risking months of wasted effort on non-functional cells
- Volumetric density (1000 Wh/L) is subordinate to gravimetric density in discovery priorities, yet emerging as equally challenging
- Site permitting and regulatory readiness are assumed complete by Month 3 (2027-01-14), but 6–8 month delays are plausible and would compress effective work time 5–10%
- Pilot-line ownership-versus-leasing decision is unresolved, risking either USD 30–50 M sunk capital before chemistry is proven or prolonged queue times that slow discovery 50%
- Chemistry-tournament contingency planning lacks pre-staged reserve chemistries and allocated pivot capital
- Talent recruitment and retention rely on untested compensation models in a competitive Austin market and assume <15% attrition without concrete mechanics
- Characterization and forensics access depend on academic partners with competing priorities and no guaranteed access or cost-sharing

Critical actions:

- Establish cycle-life (≥300 cycles at 80% retention) and volumetric-density (≥950 Wh/L) thresholds by Month 3 (2027-01-14)
- Prioritize site permitting engagement in Month 0 (2026-10-14)
- Commit to leased (not owned) pilot-line capacity by Month 1 (2026-11-14)
- Pre-stage reserve chemistry contingencies by Month 24 (2028-10-14)
- Detail compensation, partnership agreements and forensics access by Month 2 (2026-12-14)

The fixed USD 300 M budget is adequate only if early capital commitments (facility, pilot line, hiring) are controlled, permits are secured without major delays, and partner relationships provide cost-sharing and instrument access. A 20–30% overrun in any single area (permitting delays, pilot-line build, partner loss) would compress working capital by 5–15%, risking incomplete final validation or forced descent to a lower-ambition result (e.g., 480 Wh/kg instead of 500, or skipped abuse testing).