**Goal Statement:** Invent and demonstrate a rechargeable battery cell with at least 500 Wh/kg and at least 1000 Wh/L at cell level, third-party verified with at least 300 cycles at 80% retention, within USD 300 M and 84 months, as a licensable invention near Tesla Gigafactory Texas, Austin.

## SMART Criteria

- **Specific:** Invent a rechargeable cell reaching >=500 Wh/kg (primary) and >=1000 Wh/L (secondary) at cell level, with a licensable result. The aim is invention, not industrial or market dominance.
- **Measurable:** Third-party measured pouch cells show >=500 Wh/kg, >=1000 Wh/L and >=300 cycles at 80% retention (proposed threshold), with thermal-runaway onset >=120 C (proposed threshold).
- **Achievable:** A staged tournament of 3 active chemistries plus 1 reserve, a leased modular pilot line, partner characterization access and USD 300 M (user constraint) make it feasible but high risk. Reaching both targets at cell level is unproven.
- **Relevant:** A cell beyond today's commercial energy density would be a licensable invention for weight- and volume-critical applications. Cell-level proof prevents material-level claims that vanish after packaging.
- **Time-bound:** Project start Month 0 (2026-10-14). Verified cell by Month 72 (2032-10-14), technology transfer Months 72-84 (2032-10-14 to 2033-10-14), delivery Month 84 (2033-10-14). Gates at Months 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14).

## Dependencies

- Secure lease and phased hazardous-materials permits for an Austin R&D site
- Stand up a modular leased dry-room and pouch-cell line with a partner standby line
- Execute university and national-laboratory agreements for characterization and validation
- Build a live cell-level mass-and-volume model and set cycle-life and Wh/L gate criteria
- Hire the research team under clean-room IP onboarding protocols

## Resources Required

- USD 300 M tranche funding (60/80/70/90 M) with USD 20 M reserve
- Modular dry-room and pouch-cell line (USD 15 M, estimate)
- Characterization instruments and abuse-test access
- Computing capacity (cloud or national-lab HPC)
- 80-120 FTE scientists and engineers (estimate)

## Related Goals

- Establish a defensible, licensable patent estate
- Technology transfer to an established manufacturer
- Build a university and national-laboratory partnership network
- Develop safe high-energy lithium-metal and solid-state cell practice

## Tags

- battery
- 500 Wh/kg
- lithium-sulfur
- solid-state
- R&D programme

## Risk Assessment and Mitigation Strategies


### Key Risks

- Chemistry tournament fails to find a path to 500 Wh/kg and 1000 Wh/L at cell level
- Volumetric density or cycle life falls short once packaging and inactive mass are included
- Permitting slips 6-8 months (estimate), compressing effective work to 75-78 months
- Budget pressure: payroll may reach ~USD 14.8 M/yr (estimate) against a USD 10 M/yr baseline, and a pivot plus sprint could exceed reserves
- Thermal-runaway or safety failure found late in a leading candidate

### Diverse Risks

- Talent competition and poaching near Tesla, attrition above 15% (proposed)
- Partner access loss or queue delays slowing the design-build-test loop
- IP contamination from competitor hires, or weak patent position from open sharing
- Precursor supply disruption and foreign-currency exposure on equipment
- Lack of a clear technology-transfer path at delivery

### Mitigation Plans

- Set Month 18 (2028-04-14) and Month 30 (2029-04-14) gates with measured data, a pre-staged reserve chemistry by Month 24 (2028-10-14), USD 15 M pivot runway and a stop/descope rule at Month 36 (2029-10-14)
- Run the mass-and-volume model from Month 4 (2027-02-14); require >=950 Wh/L interim, cycle-life gate by Month 3 (2027-01-14), and a 6-month architecture sprint if only Wh/kg is met
- Engage regulators at Month 0 (2026-10-14), hire the EHS lead at Month 1 (2026-11-14), use phased permits and pre-negotiated external synthesis
- Release funds in evidence-linked tranches, hold USD 20 M reserve, and lock USD or forward-priced equipment contracts in Months 2-6 (2026-12-14 to 2027-04-14)
- Hire with 15-20% senior premiums and 3-5 year retention agreements; sign at least 2 partner agreements with backups and 30-60 day exits; run clean-room onboarding and provisional filings

## Stakeholder Analysis


### Primary Stakeholders

- Programme Director and Scientific Steering Committee
- Chemistry leads and cell engineering team
- Independent red team (2-3 scientists)
- EHS lead
- Funder representative

### Secondary Stakeholders

- University of Texas at Austin and national laboratories
- Austin Fire Authority, TCEQ and federal regulators
- Precursor and equipment suppliers
- Third-party test laboratories
- Prospective licensees and manufacturers

### Engagement Strategies

- Steering Committee: gate decisions within 3 weeks, with quarterly progress reports to the funder
- Research teams: regular reviews, model updates and failure-mode atlas sharing
- Partners: formal 3-5 year agreements, shared cost (>=15%, proposed) and milestone updates
- Regulators: early collaborative engagement, phased permits and regular compliance reporting
- Prospective licensees: informal advisory contacts from Month 12 (2027-10-14), licensing framework by Month 24 (2028-10-14)

## Regulatory and Compliance Requirements


### Permits and Licenses

- Phase 1 dry-room and assembly permit (Austin Fire Authority, TCEQ) by Month 3 (2027-01-14)
- Phase 2 reactive-metal and solvent synthesis permit by Month 6 (2027-04-14)
- Phase 3 abuse-test chamber permit by Month 9 (2027-07-14)
- Hazardous-waste generator registration and licensed waste contractor
- Lab zoning and certificate of occupancy for light-industrial use

### Compliance Standards

- EPA hazardous-waste rules
- OSHA hazard communication and reactive-materials handling standards
- Texas environmental air and water permitting requirements
- DOT rules for shipping lithium cells and materials
- Local fire code for flammable and reactive materials

### Regulatory Bodies

- Austin Fire Authority
- Texas Commission on Environmental Quality (TCEQ)
- US EPA
- OSHA
- Travis County

### Compliance Actions

- Meet regulators at Month 0 (2026-10-14) and hire the EHS lead at Month 1 (2026-11-14)
- Submit the Phase 1 permit application by Month 2 (2026-12-14) and sequence Phases 2-3
- Run quarterly internal audits and retain a regulatory-monitoring consultant
- Maintain contingency for retrofits and permitting delays
- Document materials and quantities and keep contracts for outsourced hazardous synthesis