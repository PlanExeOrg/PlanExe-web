## 1. Chemistry Pathway Viability and Cell-Level Energy-Density Projections

The chemistry pathway is the highest-leverage decision: it determines whether 500 Wh/kg and 1000 Wh/L are physically reachable at cell level, and what unsolved problems the programme inherits. Material-level gains often collapse once packaging is included; cycle-life often fails between cycles 50-300. Early validation (Months 6-12 = 2027-04-14 to 2027-10-14) exposes non-viable chemistries before sunk cost exceeds USD 5 M per candidate, enabling deprioritization and pivot opportunity at Month 18 (2028-04-14) without timeline loss.

### Data to Collect

- Material-level gravimetric (Wh/kg) and volumetric (Wh/L) projections for all three active chemistries (Li-S, anode-free solid-state, conversion cathode) using electrochemical and structural characterization
- Cell-level mass-and-volume model inputs (current-collector thickness, separator, electrolyte volume, pouch-packaging mass) with sensitivity bounds for each candidate chemistry
- Cycle-life trajectory data (coin cells, >=100 cycles, >=2 replicates per candidate) and identified degradation mechanisms (dendrite growth, polysulfide dissolution, lithium-ion loss, structural collapse)
- Thermal-safety screening results (differential scanning calorimetry onset temperature, heat-release rate) for all candidates; adiabatic-calorimetry correlation if available
- Measured small-scale pouch-cell (50-100 mAh) Wh/kg and Wh/L data reconciled against model projections (target: <10% discrepancy)

### Simulation Steps

- Use electrochemical simulation software (COMSOL, ANSYS or equivalent battery modelling platform) to compute material-level Wh/kg from tabulated electrochemical properties (open-circuit voltage, specific capacity, density) of anode, cathode and electrolyte candidates; validate against published benchmarks (e.g., Battery500 consortium data, literature)
- Build a parameterized Excel or Python mass-and-volume model (current collectors 10-20 µm Cu/Al, separator 25-30 µm, electrolyte volume 0.5-1.5 mL/Ah, pouch laminate 300-400 µm) and back-calculate material targets for 500 Wh/kg and 1000 Wh/L cell goals; run sensitivity analysis for ±20% variation in each parameter
- Process coin-cell cycling data (voltage, capacity, resistance) from in-house or partner labs using Python/MATLAB; fit exponential or logarithmic fade models to project cycle-life to >=300 cycles; compare early-cycle (cycles 1-50) improvement to Month 24 (2028-10-14) measured data to assess redesign efficacy
- Compile thermal-ramp data (differential scanning calorimetry external heat-flow rate vs. temperature) from in-house screening or contracted service (Intertek, TUV); compute onset as first peak >0.5 mW/mg; cross-reference with adiabatic-calorimetry or nail-penetration test outcomes if available to calibrate differential scanning calorimetry-to-adiabatic offset

### Expert Validation Steps

- Advanced-materials electrochemist (e.g., battery-lab professor from Stanford, MIT, UC Berkeley or NREL) reviews material-level projections and cycle-life trajectories; validates whether coin-cell performance is consistent with known interface degradation mechanisms for Li-S, anode-free and conversion-cathode chemistries; flags unrealistic targets
- Manufacturing engineer (e.g., Tesla cell-design or Solid Power pilot-line lead) reviews the mass-and-volume model assumptions and pouch-cell prototyping strategy; confirms whether model inputs (separator thickness, electrolyte volume, current-collector foil) are aligned with commercial practice and whether small-scale pouch results validate the model
- Thermal-safety specialist (abuse-test facility or regulatory body, e.g., Intertek, TUV or NHTSA lab) interprets differential scanning calorimetry and adiabatic-calorimetry data; validates that onset thresholds (>=120 C proposed) are appropriate for lithium-metal or high-energy chemistries and aligned with regulatory expectations (DOT, CE marking)

### Responsible Parties

- Chemistry pathway leads (in-house: 3-4 FTE)
- Cell engineering and pilot-line manager (in-house: 1-2 FTE)
- Partner characterization labs (UT Austin, NREL, Argonne: proportional FTE)
- External electrochemistry expert advisor (0.1-0.2 FTE contract, ~USD 50-100 K/yr)

### Assumptions

- **High:** Material-level gravimetric and volumetric projections from electrochemical models are within ±10% of measured coin-cell data. If larger deviation is found, model inputs (coulombic efficiency, voltage hysteresis, density assumptions) are re-calibrated.
- **High:** Cycle-life degradation mechanisms (dendrite, polysulfide, lithium-ion loss) are correctly identified via post-mortem forensics by Month 12 (2027-10-14). If root causes are missed, ineffective redesigns consume 4-6 months without improvement.
- **High:** Small-scale pouch-cell (50-100 mAh) Wh/L projections correlate with large-scale pouch targets (>=500 mAh) within 5-10%. If stacking or current-distribution losses introduce >15% volumetric penalty at scale, a candidate meeting material targets fails cell-level verification.
- **Medium:** Thermal-runaway onset differential scanning calorimetry data translate to field adiabatic behavior within ±20 C. If offset is larger (e.g., 50+ C difference), differential scanning calorimetry ranking is misleading and safety candidates are misranked.

### SMART Validation Objective

By Month 30 (2029-04-14), all three active-chemistry candidates shall be ranked by measured cell-level Wh/kg, Wh/L and cycle-life metrics from >=100 mAh, >=3-cell pouch-cell replicates independently tested by accredited third-party lab. All data reconciled against Month 4 (2027-02-14) mass-and-volume model with documented <10% discrepancy for finalists, or model revisions documented. Candidates meeting >=500 Wh/kg AND >=950 Wh/L AND >=300 cycles advance to Month 36 (2029-10-14) selection gate; others are deprioritized.

### Notes

- Electrochemical simulation is necessary but not sufficient: coin-cell performance does not guarantee pouch-cell success. Dual-track validation (material + coin + pouch) is critical.
- Cycle-life forensics (SEM/EDS post-mortem) must be run on every failed cell within 48-72 hours. Quarterly forensics-atlas updates prevent repeated failures.
- Volumetric-density verification must occur by Month 18 (2028-04-14), not deferred to Month 30 (2029-04-14). Late discovery forces a 6-month sprint that overlaps the selection gate.
- Safety screening (thermal, abuse) should begin in parallel with energy-density work (Month 6 = 2027-04-14), not sequentially. Early deprioritization of unsafe candidates avoids downstream waste.
- Cost benchmarking against Battery500 and Solid Power projects will anchor commercial feasibility expectations and reduce licensee pushback at technology transfer.


## 2. Cell-Level Proof Standard and Reproducibility Validation

Material-level claims routinely collapse at cell level due to current-collector IR losses, separator moisture absorption, electrolyte-distribution variability and pouch-sealing mass. Third-party verification prevents credibility damage and licensing rejection at technology transfer. Reproducibility (90% within ±10%) flags whether a breakthrough is real or a laboratory artifact. Late discovery of poor reproducibility at Month 60+ (estimate) forces costly manufacturing-science redesign.

### Data to Collect

- Live cell-level mass-and-volume model (current collectors, separator, electrolyte volume, pouch-packaging mass) with projected and measured Wh/kg and Wh/L for all candidates at cell level (not material level)
- Measured pouch-cell data (>=100 mAh, >=3 cell replicates per candidate) from in-house pilot line showing >=500 Wh/kg AND >=950 Wh/L in the same cells, with batch-to-batch reproducibility (90% within ±10% by Month 30 = 2029-04-14)
- Third-party independent verification (accredited battery-test lab: MIT, NREL, Intertek, TUV or equivalent) of cell-level energy density, cycle life (>=300 cycles at 80%) and safety parameters (thermal onset, abuse tolerance) using locked protocol
- Cell-build yield, defect rates and failure modes (open circuit, short, swelling, gas venting) tracked monthly from Month 6 (2027-04-14) onward; manufacturability risk assessment by Month 24 (2028-10-14)

### Simulation Steps

- Build and maintain a live Excel/Python cell-level mass-and-volume model that accepts material-level Wh/kg and density inputs, applies inactive-mass penalties (current collectors, separator, electrolyte absorption, pouch laminate, pressure hardware if any) and outputs projected cell-level Wh/kg and Wh/L. Update quarterly with measured coin-cell swelling data and post-mortem separator porosity.
- Simulate multi-layer pouch-cell current distribution and voltage hysteresis using COMSOL or 3D battery-pack simulation (e.g., Ansys Fluent) to estimate added resistive penalty (5-15% Wh/kg loss estimate) vs. coin cells; compare simulation to measured data and adjust model accordingly
- Process measured pouch-cell discharge curves (voltage vs. capacity, cycle 1, 10, 50, 100, 300) from pilot line using Python MATLAB to compute fade rate (%/cycle), coulombic efficiency (%), and voltage hysteresis (mV). Fit exponential fade models to project cycle-life to 300 cycles; identify candidate cells projected to fail <300 cycles and flag for forensics.
- Track pilot-line build data (cell ID, materials batch, coating parameters, yield/fail status) in a centralized database; compute monthly yield by candidate chemistry and coating batch; correlate defect mode with process parameters (humidity, coating thickness, electrolyte volume) using design-of-experiments software (e.g., JMP, Minitab) to identify process-control tightening opportunities

### Expert Validation Steps

- Battery-cell engineering expert (e.g., from Tesla, Solid Power or national-lab pilot-line programme) reviews the mass-and-volume model assumptions (current-collector thickness, separator porosity, electrolyte distribution) and compares against published pouch-cell designs (e.g., Panasonic 20700 or Battery500 reference cells); validates that model predictions align with commercial practice
- Manufacturing and yield engineer (e.g., battery-pack integrator or pilot-line operator) audits pilot-line build protocols (dew-point control, electrode-coating uniformity, electrolyte-dosing precision) and reviews yield-vs.-process-parameter correlations; flags process-control gaps that could undermine reproducibility or enlarge cell-level Wh/kg variance
- Accredited third-party test laboratory (e.g., MIT Energy Initiative, NREL Electrochemistry Branch, Intertek or equivalent) defines and executes cell-level verification protocol (measurement precision, ±5% accuracy on Wh/kg and Wh/L, cycle-life test rate and termination criteria, safety-threshold interpretation); reports findings to Steering Committee without core-team bias

### Responsible Parties

- Cell engineering and pilot-line manager (in-house: 1-2 FTE)
- Manufacturing-engineering specialist (in-house: 0.5-1 FTE, may be shared with pilot-line ops)
- Independent red team (in-house or external: 2-3 FTE, external verification ~0.5 FTE)
- Partner characterization labs (UT Austin, NREL: proportional FTE for method development)

### Assumptions

- **High:** Cell-level mass-and-volume model inputs (current-collector thickness 10-20 µm, separator 25-30 µm, electrolyte volume 0.5-1.5 mL/Ah, pouch mass 300-400 µm) are validated against measured benchmark cells (e.g., published Tesla or Panasonic pouch data) within ±5%. If model is off by >10%, all cell-level projections are unreliable.
- **High:** Pilot-line batch-to-batch reproducibility can achieve 90% within ±10% Wh/kg variance by Month 30 (2029-04-14) with disciplined electrode-coating and electrolyte-dosing control. If pilot-line variance exceeds ±15% despite process tightening, the chemistry is not production-ready.
- **High:** Third-party measured cell-level Wh/kg and Wh/L align with in-house measurements within ±5%. If third-party finds >=10% discrepancy, in-house measurement methodology is flawed (calibration, calculation error) and all prior claims are questioned.
- **Medium:** Pilot-line yield on multi-layer pouch cells reaches >=90% defect-free builds by Month 24 (2028-10-14) for the active chemistries. If yield is <80%, process-control issues prevent reliable cycle-life data collection and gate decisions lack statistical power.

### SMART Validation Objective

By Month 30 (2029-04-14), independent third-party test lab shall measure >=3 pouch-cell replicates (>=100 mAh each) from each of the three finalists, and report: (a) cell-level Wh/kg measured to ±5% accuracy (target >=500 Wh/kg), (b) cell-level Wh/L measured to ±5% accuracy (target >=950 Wh/L interim), (c) cycle-life to 80% capacity retention (target >=300 cycles). All data reconciled against the Month 4 (2027-02-14) cell-level mass-and-volume model; discrepancies >10% trigger model revision. In-house pilot-line builds demonstrate 90% of cells within ±10% of median Wh/kg across >=30 cells per candidate per month for Months 20-30 (2028-06-14 to 2029-04-14).

### Notes

- The cell-level proof standard is the primary gate against material-level inflation. Do not defer to Month 48+ (2030-10-14+); validate by Month 30 (2029-04-14) to preserve pivot capacity.
- Third-party measurement must use a locked, published protocol (specify C-rate, temperature, voltage window, cycle-count definition) to ensure reproducibility across labs and across future licensees.
- Reproducibility (batch-to-batch variance) is a manufacturing-readiness metric. If variance is high (>15%), investigate dry-room humidity, electrode-coating uniformity and electrolyte-dosing precision; tighten process controls or accept that the chemistry is intrinsically variable.
- Yield tracking (% defect-free) is essential. A 70% yield means 30% of synthesis and cell-assembly effort is lost to scrap; at 100 cells/month, 30 cells/month waste is unacceptable and signals process immaturity.
- Cost-per-measured-Wh/kg from third-party testing should be published (e.g., USD 10-20 K per cell × 3 replicates × 3 chemistries = ~USD 180-360 K per gate cycle); this legitimizes the testing cost and shows funder discipline.


## 3. Cycle-Life and Degradation-Mechanism Validation

Cycle-life is often the last failure mode discovered. A chemistry meeting gravimetric and volumetric targets but capable of only 150-200 cycles is not licensable. Early (Month 12 = 2027-10-14) parallel cycle-life testing exposes non-viable candidates before 12-18 months of sunk effort. Forensics (SEM/EDS/FTIR) transforms failure data into actionable redesign targets and closes the hypothesis loop, shortening redesign cycles from 6-8 weeks to 2-4 weeks.

### Data to Collect

- Measured cycle-life data for all three active chemistries (coin cells >=100 cycles, pouch cells >=300 cycles at 80% retention by Month 30 = 2029-04-14) with quantified fade rate (%/cycle), coulombic efficiency (%) and voltage hysteresis (mV)
- Degradation-mechanism forensics for every failed cell: post-mortem SEM/EDS mapping of anode and cathode interfaces, FTIR or GC analysis of electrolyte decomposition, structural characterization (XRD, porosity) of degraded electrodes
- Cycle-dependent swelling data (caliper measurement, weight change) for all candidates at cycles 1, 10, 50, 100, 300 to quantify volume change and assess separator compression and electrolyte retention over life
- Quarterly forensics atlas (root-cause taxonomy, failure-mode frequencies, design-consequence recommendations) fed directly to next-round designs to close the hypothesis-to-validation loop

### Simulation Steps

- Process coin-cell cycling data (voltage, capacity, impedance vs. cycle number) using Python/MATLAB; fit fade models (linear, exponential, power-law) to project cycle-life to Month 24 (2028-10-14) and Month 30 (2029-04-14) targets; compute fade rate and identify early-cycle (1-50) vs. late-cycle (100-300) degradation regimes
- Compile post-mortem SEM/EDS images and elemental maps from failed cells (in-house or partner labs); classify anode surface (lithium-plating reversibility, SEI thickness, lithium-ion depletion) and cathode surface (polysulfide residue, structural collapse, cation dissolution) into a standardized failure-mode code (e.g., 'Li-ion loss via electrolyte oxidation', 'dendrite growth'); tally occurrence frequency by chemistry and cycle regime
- Fit volumetric swelling data (caliper measurement, weight change) to a power-law or exponential model; project cumulative volume change at 300 cycles and assess impact on cell-level Wh/L (estimate volumetric penalty = measured swelling × inactive-mass fraction). Flag candidates with >30% cumulative swelling as requiring separator or electrolyte-volume redesign.
- Build a degradation-mechanism tree (fishbone diagram) for each candidate chemistry, linking observed failure modes (dendrite, polysulfide, structural collapse) to electrochemical root causes (plating reversibility, ion transport, interface stability) and proposed design mitigations (additive, coating, binder, pressure); use this tree to prioritize the next 2-4 week redesign sprints

### Expert Validation Steps

- Advanced-materials electrochemist or failure-forensics specialist (e.g., from NREL, Argonne, or battery-lab university) reviews quarterly forensics atlas; validates root-cause assignments (dendrite vs. lithium-ion loss, polysulfide dissolution vs. structural collapse) against literature and mechanistic understanding; flags misclassifications that could misdirect future redesigns
- Cell-engineering and materials-science expert (e.g., Tesla, Solid Power or national lab) interprets the degradation mechanisms and proposes design mitigations (electrolyte additive, protective coating, binder dopant, pressure management); estimates efficacy and timeline for testing each mitigation (propose >=30% cycle-life improvement within 2-4 weeks or demote candidate)
- Cycle-life and calendar-life testing specialist (e.g., contract lab like Intertek, TUV or battery OEM QA) validates that coin-cell cycling methodology (C/10 rate, 25 C ambient, 0-4.5 V window) is aligned with industry standard (IEC 62660, USABC) and that fade-rate calculations are correct; audits post-mortem sample handling (no degradation during storage/transport).

### Responsible Parties

- Chemistry pathway leads (in-house: 3-4 FTE, responsible for cycle-life testing and interpretation)
- Characterization and forensics specialist (in-house: 1 FTE, responsible for SEM/EDS, FTIR, forensics-atlas maintenance)
- Partner characterization labs (UT Austin, NREL: proportional FTE for operando XRD support)
- External failure-forensics expert (0.1-0.2 FTE contract, quarterly atlas review)

### Assumptions

- **High:** Coin-cell cycle-life data (>=100 cycles per candidate by Month 12 = 2027-10-14) are statistically representative of pouch-cell behavior. If pouch cells show >20% higher fade rate, coin-cell scaling factors are re-calibrated or pouch-cell testing is accelerated.
- **High:** Degradation mechanisms (dendrite growth, polysulfide dissolution, lithium-ion loss) are correctly identified via SEM/EDS within 5 business days of cell failure, allowing a 2-4 week redesign sprint before the next cycle-life batch. If forensics turnaround exceeds 2 weeks, hypothesis-to-validation loop slows and candidates remain stranded in redesign limbo.
- **Medium:** Electrolyte or interface redesigns (additive, coating, binder) targeting identified degradation modes deliver >=30% cycle-life improvement within 2-4 weeks. If improvement is <20%, the degradation mechanism may not be correctly identified or the mitigation strategy is ineffective; candidate is demoted.
- **Medium:** Volumetric swelling (measured caliper, weight change) scales linearly or power-law from coin cells to pouch cells. If pouch-cell swelling is >2× higher due to stacking or pressure effects, cell-level Wh/L projection from coin-cell swelling is invalidated.

### SMART Validation Objective

By Month 30 (2029-04-14), all three active-chemistry candidates shall achieve measured >=300 cycles at 80% capacity retention in pouch cells (>=3 replicates, >=100 mAh each, validated by third-party lab). Fade rate shall not exceed 0.25%/cycle (80% at 320 cycles). Coulombic efficiency shall remain >=98%. Post-mortem forensics (SEM/EDS, FTIR) shall identify root-cause degradation mechanisms for >=80% of failed cells. Quarterly forensics atlas (Month 12, 18, 24, 30 = 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14) shall document design improvements traced to forensics findings.

### Notes

- Cycle-life testing is inherently slow (>=100 cycles at C/10 = 10+ weeks per cell). Begin Month 12 (2027-10-14) cycle-life stacks in parallel with energy-density optimization to avoid late discovery.
- Forensics (SEM/EDS) must occur within 48-72 hours of cell failure to prevent interface artifacts from storage. Designate a dedicated microscopist (0.5 FTE) with rapid-turnaround SOP.
- Quarterly forensics atlas must be published and circulated to chemistry teams within 1 week of data completion. Use the atlas to deprioritize candidates stuck on the same failure mode (e.g., >=40% dendrite growth despite 18 months of anode engineering).
- Distinguish reversible fade (SEI growth, interface resistance) from irreversible loss (lithium-ion depletion, structural collapse). Design mitigations accordingly: reversible failure may be fixed by additives; irreversible failure requires architecture change.
- Establish a 'stop rule' by Month 24 (2028-10-14): if a candidate is measured <250 cycles by Month 12-15 (2027-10-14 to 2028-01-14) and a 2-4 week redesign sprint does not yield >=30% improvement, deprioritize immediately and reallocate resources to the two stronger candidates.


## 4. Permitting, EHS Compliance and Operational Readiness

Permitting is the critical path. A 6-8 month delay (plausible and common for hazardous-materials facilities) compresses effective work from 84 to 76-78 months, directly threatening the Month 36 (2029-10-14) chemistry-selection gate and Month 72 (2032-10-14) final verification. Pre-negotiated external-synthesis fallback (contracts signed by Month 1 = 2026-11-14) preserves synthesis velocity if on-site permitting slips. Conditional-use authorization (enhanced fire-authority monitoring in exchange for early Phase 1 approval) buys 4-8 weeks of critical path time.

### Data to Collect

- Phase 1 (dry-room, pouch-cell assembly) permit status and approval timeline from Austin Fire Authority and Texas Commission on Environmental Quality; conditional-use authorization if expedited approval is negotiated
- Phase 2 (lithium-metal and reactive-solvent synthesis) permit scope and lead-time estimate; pre-negotiated external synthesis contracts (cost, turnaround, capacity surge provisions)
- Phase 3 (abuse-testing chambers: thermal, nail-penetration, overcharge) permit and facility design; timeline for commissioning (in-house vs. contracted external)
- Site-lease agreement signed (location: Southeast Austin or Northeast Travis County, >=5,000-10,000 m2, power/HVAC/waste handling confirmed) with occupancy by Month 3 (2027-01-14)
- Modular pilot-line (dry-room, pouch-cell line) lease or operating agreement signed with equipment on-site and first pouch-cell builds by Month 6 (2027-04-14); performance SLAs (dew point <−30 C, electrode uniformity ±10 µm, electrolyte dosing ±2%)

### Simulation Steps

- Obtain permitting timelines and requirements from Austin Fire Authority and Texas Commission on Environmental Quality via pre-application meetings (Month 0 = 2026-10-14); map EPA 40 CFR 260-273 hazardous-waste rules, OSHA 1910.1200/1910.307 reactive-materials handling, and local air/water-permit thresholds using regulatory databases (e.g., EPA Enforcement and Compliance Tracker, TCEQ online permitting)
- Model permitting scenarios in a Gantt-chart tool: baseline (6-month Phase 1, 6-month Phase 2, 4-month Phase 3), accelerated (phased conditional-use authorization, 2-month Phase 1, 4-month Phase 2), and delayed (8-month Phase 1, slip to Month 9 = 2027-07-14 operational start). Calculate effective work-time impact on 84-month programme (84 months minus permitting slip = compressed timeline).
- Collect vendor quotes for modular dry-room and pouch-line equipment (3-4 vendors: Mbraun, Glove-box Company, or equivalent); model cost, lead time, performance guarantees (dew-point control, coating uniformity, electrolyte-dosing accuracy) and exit clauses. Identify USD 15 M capital contingency and USD 0.6-1.2 M/yr operating-lease cost.
- Develop outsourcing SOWs for external synthesis (4-6 week turnarounds, cost-plus pricing, USD 2-5 M/yr budget for contingent use if permitting slips); identify >=2 contract research organizations (Albemarle, Lithium Werks CRO, or UT Austin core facility) with firm commitments and signed LOIs by Month 1 (2026-11-14)

### Expert Validation Steps

- Regulatory and EHS specialist (e.g., environmental-compliance consultant, battery-lab EHS officer, or state environmental agency liaison) reviews Phase 1-3 permit strategies and provides realistic timeline estimates; identifies any hidden municipal or state requirements that could delay approval beyond the nominal 6-8 months (estimate); recommends accelerated or conditional-use pathways
- Battery-industry permitting expert (e.g., from Tesla, Solid Power, or established battery manufacturer) shares precedent timelines for lithium-metal synthesis and abuse-testing facilities in Texas; documents conditional-use authorization and phased-operation protocols proven to work elsewhere
- Site-facility engineer (HVAC, power, hazardous-waste handling) audits candidate locations (Southeast Austin, Northeast Travis County) for infrastructure adequacy (500+ kVA power, ventilation for VOCs and reactive-metal fumes, hazmat-waste contractor access within 50 miles); confirms lease terms and occupancy timeline

### Responsible Parties

- Environmental Health & Safety (EHS) lead (in-house: 1 FTE, hired Month 1 = 2026-11-14)
- Programme director and facilities manager (in-house: 0.2-0.3 FTE for regulator negotiations)
- Regulatory consultant (external: 0.1-0.2 FTE contract, USD 50-100 K, for Phase 1-3 strategy)
- External synthesis and pilot-line vendors (contract providers: cost-plus terms, turnaround SLAs)

### Assumptions

- **High:** Austin Fire Authority and Texas Commission on Environmental Quality are willing to engage in collaborative pre-application discussions and propose phased or conditional-use authorization pathways. If regulators demand full Phase 1-3 approval in sequence (standard 6-month timelines per phase), operational start slips to Month 18 (2028-04-14), compressing effective work from 84 to 66 months.
- **High:** Modular dry-room and pouch-cell line are available from named vendors with 8-12 week lead times and specified performance (dew point <−30 C, ±10 µm coating uniformity) by Month 1 (2026-11-14) order. If vendor lead time exceeds 16 weeks or performance specs are not met, first pouch builds slip from Month 6 (2027-04-14) to Month 9-12 (2027-07-14 to 2027-10-14).
- **High:** External synthesis subcontractors (contract research organizations) confirm <4 week turnaround and USD 2-5 M/yr budget availability by Month 1 (2026-11-14). If external sourcing is not pre-positioned, synthesis delays to Month 9+ (2027-07-14+) if on-site permitting slips.
- **Medium:** Site lease (Southeast Austin or Northeast Travis County) is secured with occupancy by Month 3 (2027-01-14) and adequate power (500+ kVA), ventilation and hazmat-waste handling. If site search extends beyond Month 2 (2026-12-14) or lease negotiations fail, fit-out and operational start slip 2-4 months.

### SMART Validation Objective

By Month 2 (2026-12-14), Phase 1 permit application (dry-room, pouch-cell assembly, non-hazardous operation) shall be submitted to Austin Fire Authority and Texas Commission on Environmental Quality. By Month 3 (2027-01-14), Phase 1 permit approval or conditional-use authorization shall be in effect. By Month 4 (2027-02-14), site lease shall be executed and occupancy scheduled for Month 6 (2027-04-14). By Month 1 (2026-11-14), external synthesis and pilot-line vendor contracts shall be signed with equipment delivery by Month 3 (2027-01-14) and first pouch cells built by Month 6 (2027-04-14). Zero reportable environmental or safety incidents through Month 84 (2033-10-14).

### Notes

- Permitting is a show-stopper. Initiate regulator engagement at Month 0 (2026-10-14), not Month 1 (2026-11-14). Request phased approval and conditional-use authorization explicitly in pre-application conversations.
- EHS lead hire must occur by Month 1 (2026-11-14). Assign them to pre-negotiation with fire authority and TCEQ before Month 0.5 (2026-10-29). Do not delay permitting initiation by waiting for EHS hire.
- External-synthesis fallback contracts must be signed by Month 1 (2026-11-14) with firm turnaround and cost commitments. Do not leave synthesis capacity as a 'maybe' to be negotiated reactively if permitting slips.
- Document all regulator engagement (meeting notes, email correspondence) and maintain a permitting-status tracker (Gantt chart) updated monthly. Escalate delays >2 weeks to Steering Committee.
- Conditional-use authorization (enhanced fire-authority monitoring, weekly audits, daily compliance logs) is a legitimate pathway to early Phase 1 approval. Propose it explicitly in pre-application meetings.


## 5. Payroll, Budget Adequacy and Financial Contingency Validation

Payroll is the largest uncontrolled cost driver. Bottom-up estimates suggest USD 12.9-16.6 M/yr (vs. USD 10 M/yr baseline), a USD 34 M overrun over 7 years. This alone consumes USD 34 M of the USD 20 M reserve plus USD 15 M pivot runway plus free contingency, leaving zero buffer for permitting delays, chemistry pivots, EHS incidents or supply disruptions. Early reconciliation (Month 1 = 2026-11-14) avoids a funding crisis at Month 24-36 (2028-10-14 to 2029-10-14). Cash-flow shortfall (opex exceeds tranches by USD 41 M carry-forward requirement) is a known risk but has no mitigation strategy; funder must decide on top-up, descope or deferral of later-stage work.

### Data to Collect

- Bottom-up FTE roster and salary benchmarks for Austin-area battery research roles (senior scientist, postdoc, technician, programme management, EHS, IP counsel) with 15-20% Tesla proximity premium
- Revised payroll forecast (Months 0-84 = 2026-10-14 to 2033-10-14) by role and start date, with total annual cost and cumulative burn-rate projection; comparison to USD 10 M/yr baseline and USD 14.8 M/yr (proposed) high case
- Detailed cash-flow model (monthly Months 0-36 = 2026-10-14 to 2029-10-14, quarterly Months 36-84 = 2029-10-14 to 2033-10-14) showing tranche release (60/80/70/90 M), payroll, capital drawdown (pilot line, instruments, facility), opex (experiments, partners, testing, EHS, IT) and monthly carry-forward balance
- Reserve allocation (USD 20 M total: USD 15 M pivot runway, USD 2-3 M FX contingency, USD 2-5 M free general reserve) and release triggers (pivot decision at Month 30 = 2029-04-14, volumetric sprint at Month 30 = 2029-04-14 if needed, permitting overrun, EHS incident, supply disruption)
- Stress-case analysis: pivot (USD 5-10 M) + volumetric sprint (USD 8-15 M) concurrent reserve requirements and shortfall scenarios

### Simulation Steps

- Build a bottom-up FTE roster in Excel specifying all planned roles (senior scientists, postdocs, technicians, EHS lead, IP counsel, programme manager, finance lead, procurement officer, administrative support), start dates (Month 0-6 = 2026-10-14 to 2027-04-14), salaries (postdoc ~USD 65-90 K/yr, senior scientist ~USD 150-220 K/yr, engineer ~USD 90-130 K/yr, support ~USD 50-70 K/yr) and benefits multiplier (30-35% for payroll tax, health insurance, retirement); compute total payroll by month and cumulative cost through Month 84 (2033-10-14)
- Conduct external salary benchmarking for Austin battery-research roles using publicly available data (Glassdoor, Levels.fyi, EY salary surveys, university job postings) and adjust for 15-20% Tesla proximity premium (documented in recent hiring data from local firms); validate assumptions with external recruiter survey if budget allows (USD 2-5 K cost)
- Build a detailed 84-month cash-flow model in Excel: rows = months, columns = tranche in, payroll, capital (pilot line, instruments, facility fit-out, EHS/IT setup), opex (experiments, characterization, partners, testing, computing, outsourcing, contingencies), and running balance. Monthly detail for Months 0-36 (2026-10-14 to 2029-10-14), quarterly thereafter. Compute carry-forward required to bridge Months 36-84 (2029-10-14 to 2033-10-14).
- Model stress cases: (1) permitting slip 6-8 months (external synthesis costs USD 2-5 M/yr for 12-24 months), (2) chemistry pivot at Month 30 (2029-04-14) (USD 5-10 M precursor re-sourcing, USD 2-3 M accelerated characterization), (3) volumetric sprint (USD 8-15 M electrode redesign, separator sourcing, pouch builds), (4) payroll overrun (USD 2-4 M/yr additional vs. baseline). Run all stress cases; compute maximum reserve consumption and shortfall scenarios.
- Develop funder-decision memo for Month 1 (2026-11-14) presenting baseline budget, revised payroll forecast, cash-flow shortfall (if any), and three decision options: (A) increase USD 300 M cap to USD 330-350 M with revised tranches, (B) reduce FTE scope from 100 to 60-80 or descope to 2 active chemistries, or (C) maintain USD 300 M but implement hiring freeze after Month 36 (2029-10-14) and accept longer delivery timeline

### Expert Validation Steps

- Finance and programme-management expert (e.g., R&D programme manager from national lab, government research office, or venture-backed deep-tech firm) reviews the bottom-up payroll roster and cash-flow model; validates that salary assumptions are realistic for Austin market and that funding-release conditions are measurable and achievable; flags any inconsistencies or missing opex categories
- Battery-industry hiring expert (e.g., recruiter, talent manager from Tesla, Solid Power or battery OEM) reviews salary benchmarks and advises on Austin battery-market compensation (base, signing bonus, retention incentives, equity-like arrangements); identifies likely attrition risk and retention cost implications for the 7-year programme
- Funder or institutional-finance representative reviews cash-flow model and stress-case outcomes; confirms appetite for budget augmentation (to USD 330-350 M) if payroll is higher than baseline, or confirms willingness to descope if budget is non-negotiable; documents decision in writing by Month 3 (2027-01-14)

### Responsible Parties

- Financial and operations manager (in-house: 1 FTE, hired by Month 1 = 2026-11-14)
- Programme director (in-house: 0.2-0.3 FTE for tranche and funding decisions)
- External finance consultant (0.1-0.2 FTE contract, USD 30-50 K, for cash-flow modelling and stress analysis)
- Funder or institutional finance representative (0.1-0.2 FTE for decision approval)

### Assumptions

- **High:** Bottom-up payroll (USD 13-15 M/yr estimate) is realistic for 100 FTE in Austin with 15-20% Tesla premium and 3-5 year retention agreements. If actual hiring reaches USD 16 M/yr, reserve is exhausted by Month 30 (2029-04-14) and no contingency remains for stress cases.
- **High:** Opex (experiments, characterization, outsourcing, partners, EHS, IT) totals USD 22.9 M/yr (average). If partners charge >USD 1.5 M/yr for characterization access or synthesis subcontracting costs USD 5-7 M/yr (not USD 2-5 M/yr), opex rises and free contingency is consumed.
- **High:** Carry-forward balance remains positive through Month 36 (2029-10-14) and >=USD 5-10 M is available for pivots or stress-case absorption. If Months 0-36 (2026-10-14 to 2029-10-14) spending is front-loaded (capital, hiring, equipment), carry-forward dips below USD 5 M by Month 24 (2028-10-14) and funder must approve draw from T3 or authorize top-up.
- **Medium:** Attrition remains below 15%/yr (proposed). If attrition reaches 20%, recruiting and onboarding costs add USD 0.5-1 M/yr and team continuity is compromised, slowing discovery by 15-20%.

### SMART Validation Objective

By Month 3 (2027-01-14), a revised bottom-up payroll forecast (USD 12.9-16.6 M/yr range, midpoint USD 14 M/yr) and detailed 84-month cash-flow model shall be approved by Steering Committee and funder. If revised payroll exceeds USD 12 M/yr, funder shall approve either (A) increase total budget cap from USD 300 M to USD 330-350 M (with revised tranches), (B) descope to 60-80 FTE (with reduced throughput and delivery timeline adjustment), or (C) implement hiring freeze after Month 36 (2029-10-14) and formal FTE-reduction contingency. Carry-forward balance shall remain positive (>USD 5 M) through Month 36 (2029-10-14). Reserve allocation (USD 15 M pivot, USD 2-3 M FX, USD 2-5 M free) shall be locked in writing.

### Notes

- Do NOT use the USD 10 M/yr baseline for Month 3+ planning. Conduct bottom-up salary survey and revise by Month 2 (2026-12-14). This is a show-stopper for funder approval of T2 release at Month 12 (2027-10-14).
- Cash-flow shortfall (USD 41 M carry-forward requirement for Months 36-84 = 2029-10-14 to 2033-10-14) is a known issue. Document the shortfall clearly and present three options: top-up, descope, or deferral of later-stage work. Do not hide it.
- Attrition tracking is essential. Monitor actual vs. target (<15%/yr) monthly. If attrition exceeds 15% by Month 12 (2027-10-14), trigger a retention review (compensation adjustment, leadership changes, scope re-negotiation).
- Payroll contingency should be explicitly allocated within the USD 20 M reserve: propose USD 10-15 M reserved for payroll overrun, leaving USD 5-10 M for other contingencies. This prevents payroll surprise from consuming the entire reserve.
- FX contingency (USD 2-3 M for EUR/CNY equipment) should be treated separately. Lock equipment prices in USD or forward contracts by Month 6 (2027-04-14) to minimize FX exposure.


## 6. Volumetric Energy Density (1000 Wh/L) Verification and Architecture-Redesign Feasibility

Volumetric density (1000 Wh/L) is as challenging as gravimetric (500 Wh/kg), yet is often deprioritized during chemistry exploration. Material-level gains (high energy-density materials) often require thick separators (polysulfide barriers, cathode protection layers) and high electrolyte volumes, eroding volumetric density from 1000+ Wh/L material-level to 800-900 Wh/L cell-level. Late discovery (Month 30 = 2029-04-14) forces a 6-month architecture sprint overlapping the selection gate. Early verification (Month 18 = 2028-04-14) exposes volumetric shortfalls and enables targeted redesign (separator thinning, electrolyte reduction, pressure management) before sunk cost exceeds USD 10 M per candidate.

### Data to Collect

- Measured cell-level volumetric energy density (Wh/L) projections for all three active chemistries (material-level + packaging overhead) at Month 6 (2027-04-14) and measured pouch-cell Wh/L data by Month 18 (2028-04-14) with >=3 cell replicates per candidate
- Comparative cell-level mass-and-volume accounting: breakdown of inactive mass (current collectors, separator, electrolyte, pouch laminate, pressure hardware if any) and cumulative volumetric penalty vs. material-level projections for each chemistry
- Separator thickness, electrolyte volume and current-collector foil specifications for each candidate, with sensitivity analysis on Wh/L if separator is reduced 5-10 µm or electrolyte volume is cut 20% (simulate via mass-and-volume model)
- Small-scale pouch-cell (50-100 mAh) swelling data (caliper measurement, pre/post-cycle 1, 10, 50, 100) showing volumetric change over cycling; comparison to material-level predictions
- Architecture-redesign sprint outcomes (Month 30-36 = 2029-04-14 to 2029-10-14 if needed): measured pouch-cell Wh/L after separator thinning or electrolyte-volume reduction, with cycle-life impact (trade-off analysis)

### Simulation Steps

- Use the live cell-level mass-and-volume model (Month 4 = 2027-02-14) to project cell-level Wh/L for all three candidates by Month 6 (2027-04-14). Inputs: material-level energy density (Wh/L) from electrochemical simulation, current-collector thickness (10-20 µm Cu/Al, density 9.0 g/cm³ for Cu, 2.7 for Al), separator (25-30 µm, porosity 30-50%, assume electrolyte-saturated thickness ~35-50 µm), electrolyte volume (0.5-1.5 mL/Ah, density ~1.2 g/mL), pouch laminate (300-400 µm Al, density 2.7 g/cm³, ~30-40 mg per cell). Output: cell-level Wh/L accounting for inactive-mass fraction. Flag any candidate projecting <950 Wh/L despite >500 Wh/kg material performance.
- Parametrize the model to accept variable separator thickness (15-35 µm), electrolyte volume (0.4-2.0 mL/Ah) and pressure-hardware mass (if applicable) and run sensitivity analysis: compute Wh/L impact if separator is reduced 5-10 µm or electrolyte is cut 20%. Identify the thinnest sustainable separator and lowest electrolyte volume before cycle-life or safety metrics are violated.
- Build a pouch-cell stacking simulation (3D or reduced 2D model) to estimate current-distribution losses and resistive heating penalty at multi-layer configuration (3-5 layers, typical pouch architecture). Estimate voltage hysteresis and heating penalty vs. coin cells (expect 2-5% Wh/kg loss); feed into revised cell-level Wh/kg and Wh/L projections.
- Collect measured coin-cell swelling data (caliper pre/post-lithiation on 3-6 cells per candidate, cycles 1-100) and fit to a power-law or exponential model. Project cumulative swelling at cycle 300 and estimate volumetric penalty on pouch-cell Wh/L (cumulative swelling × fraction of cell volume occupied by electrodes). Flag candidates with >30% cumulative volume change as requiring separator compression or stress-relief design.

### Expert Validation Steps

- Battery-cell engineering expert (e.g., from Tesla, LG, Solid Power or national-lab cell-design team) reviews the mass-and-volume model assumptions and small-scale pouch-cell data; validates that separator thickness, electrolyte volume and current-collector foil are realistic for the target chemistry and form factor; flags any model assumptions that underestimate packaging penalties
- Manufacturing engineer (pilot-line or pouch integrator) audits the separator-thinning and electrolyte-reduction redesign plan; estimates process-control tightening needed to maintain coating uniformity and electrolyte distribution with reduced margins; assesses yield impact and cost implications
- Safety and thermal expert (abuse-test lab, OEM safety engineer) reviews the proposed separator-thinning and electrolyte-reduction changes and assesses impact on thermal stability (lower electrolyte volume = higher current density, faster lithium-plating kinetics, potential dendrite acceleration) and safety margin (thermal runaway onset); estimates whether changes would require compensatory thermal-management redesign (thicker SEI, higher-stability binder)

### Responsible Parties

- Cell engineering and pilot-line manager (in-house: 1-2 FTE, owns mass-and-volume model and pouch-cell measurements)
- Chemistry pathway leads (in-house: 3-4 FTE, provide material-level projections and advise on separator/electrolyte trade-offs)
- External battery-cell-engineering expert (0.1-0.2 FTE contract, USD 30-50 K, for model validation and redesign strategy)

### Assumptions

- **High:** Cell-level volumetric penalty (current collectors, separator, electrolyte, packaging) totals 200-300 Wh/L (estimate) reduction from material-level projections. If actual penalty exceeds 350 Wh/L on any candidate, material-level Wh/L target was unrealistic for the chosen cell format.
- **High:** Separator thickness can be reduced from 30 µm to 20 µm without significant porosity loss or mechanical weakness, if pore-size distribution and binder-resin level are optimized. If separator thinning causes yield loss (mechanical rupture during stacking) or cycle-life collapse (dendrite penetration), thin-separator path is not viable.
- **High:** Electrolyte volume can be reduced from 1.2 mL/Ah to 0.8 mL/Ah without lithium-ion-transport degradation (impedance rise) or safety risk (reduced thermal mass). If reduced electrolyte causes >50% impedance rise or thermal runaway onset drops >20 C, low-electrolyte path is not viable.
- **Medium:** Pouch-cell stacking and pressure-hardware overhead (3-5 cell layers, stack pressure 5-10 atm, pressure plates ~200 mg) adds <150 Wh/L penalty. If actual overhead exceeds 200 Wh/L, current-collector foil and pouch laminate are the dominant inactive-mass contributors and require material substitution (thinner foil, lightweight laminate).

### SMART Validation Objective

By Month 18 (2028-04-14), all three active-chemistry candidates shall show measured cell-level Wh/L from small-scale pouch cells (50-100 mAh, >=3 replicates per candidate). Candidates meeting >=500 Wh/kg AND >=950 Wh/L advance to Month 24 (2028-10-14); candidates meeting Wh/kg but not Wh/L enter a 4-month volumetric-redesign sprint (Month 18-22 = 2028-04-14 to 2028-08-14) targeting separator and electrolyte optimization. By Month 30 (2029-04-14), third-party pouch-cell verification (>=100 mAh, >=3 replicates) shall show >=500 Wh/kg AND >=950 Wh/L in the same cells for all finalists; candidates unable to meet interim >=950 Wh/L are demoted. Final targets (>=500 Wh/kg, >=1000 Wh/L) verified independently by Month 72 (2032-10-14).

### Notes

- Do not defer volumetric validation to Month 30 (2029-04-14). Small-scale pouch proof by Month 18 (2028-04-14) is essential to trigger early redesign if needed.
- Separator thickness and electrolyte volume are coupled to safety (dendrite risk, thermal margin). Any redesign for volumetric gain must include thermal-abuse validation (differential scanning calorimetry, nail-penetration) to confirm no safety regression.
- Cost-per-volumetric-Wh/L should be tracked alongside cost-per-gravimetric-Wh/kg. A cell at 500 Wh/kg but 800 Wh/L is not a complete invention and has limited licensee appeal for volume-constrained applications (aerospace, portable electronics).
- Pressure-managed architectures (bipolar stacks, anode-free with pressure hardware) can improve volumetric density but add complexity and manufacturing challenges. Evaluate pressure options by Month 12 (2027-10-14) to decide if they are worth the added risk.


## 7. Technology Transfer Partner Readiness and Licensing Framework Validation

An invented cell with no identified licensee and no pre-agreed technology-transfer terms is an orphaned invention. Licensing discussions must begin by Month 12 (2027-10-14) to lock in partner requirements and ensure the cell design is aligned with real commercialization pathways. Late licensee engagement (Month 60+) risks discovering that the cell's form factor, cost structure, or process complexity does not match the licensee's manufacturing roadmap, forcing a 6-12 month redesign or license rejection. Technology-transfer readiness (Months 72-84 = 2032-10-14 to 2033-10-14) is often underestimated; inadequate documentation, missing supply-chain qualification or unproven manufacturing processes extend hand-off by 12+ months.

### Data to Collect

- Identified prospective licensees (battery manufacturers, OEMs, energy-storage integrators) with stated requirements (application duty cycle, cycle-life, thermal range, pack-integration form factor) by Month 12 (2027-10-14)
- Reference Application Anchor specification (locked by Month 3 = 2027-01-14): application domain (aviation, automotive, portable), duty-cycle test protocol (C-rate, temperature range, cycle-count target, pass/fail thresholds), and alignment with licensee requirements
- Non-binding term sheet from lead licensee candidate (Month 12 = 2027-10-14) detailing technology scope, exclusivity tier, royalty range, minimum commercialization timeline and contingency (if licensee withdraws, backup identified)
- IP and licensing framework (Month 24 = 2028-10-14): ownership of jointly developed IP with university/national-lab partners, patent-filing scope and timing (provisional filings in Months 6-12 = 2027-04-14 to 2027-10-14), publication embargo (6 months pre-filing), and two-tier licensing structure (exclusive for integrated cell architecture, non-exclusive for enabling materials)
- Technology-transfer readiness checklist (Months 60-72 = 2031-10-14 to 2032-10-14): process documentation (step-by-step synthesis, fabrication, assembly with tolerances), material supply-chain (qualified suppliers, pricing, lead-times), pilot-line design (equipment list, specifications, commissioning plan), cell-data package (>=50 cells with complete electrochemical characterization, abuse-test results, third-party verification), and digital models (simulation codes, manufacturing process models)

### Simulation Steps

- Conduct a prospective-licensee landscape analysis using industry databases (battery OEMs, automotive suppliers, aerospace integrators) and published roadmaps (company investor presentations, product announcements, supply-chain disclosures). Filter for companies with stated energy-density targets aligned with >=500 Wh/kg and >=1000 Wh/L. Identify 5-10 candidate licensees and their known technical requirements (cycle-life, thermal range, form factor, cost targets). Prepare a summary matrix (licensee name, application focus, stated Wh/kg/Wh/L target, cycle-life, thermal range, pack-integration requirements).
- Model the Reference Application Anchor decision outcomes: if anchor is 'aviation' (C-rate 1C, −40 to +60 C, 200+ cycles, volumetric priority), simulate cell-level requirements (cycle-life floor, voltage hysteresis floor, thermal stability floor) vs. 'automotive' anchor (C/2 rate, −20 to +50 C, 500+ cycles, gravimetric priority) or 'portable' anchor (2C rate, 0-40 C, 300 cycles, cost priority). Estimate which of the three active chemistries is best aligned with each anchor scenario.
- Draft a non-binding term-sheet template covering: (1) technology scope (cell architecture, electrolyte family, anode and cathode compositions), (2) exclusive vs. non-exclusive rights and field-of-use (e.g., exclusive for automotive cells, non-exclusive for aerospace), (3) royalty structure (tiered: 2-5% on integrated cell architecture if exclusive, 1-2% on enabling materials if non-exclusive), (4) commercialization timeline (first commercial prototype by Year 5 post-licensing, minimum volume ramp by Year 7), (5) force-of-life and warranty terms, and (6) contingency (what happens if licensee deprioritizes, or if programme fails to deliver by Month 72 = 2032-10-14). Develop two or three term-sheet scenarios (exclusive, tiered, non-exclusive) for discussion.
- Build a technology-transfer readiness checklist in a spreadsheet with deliverable categories: (A) process documentation (synthesis SOP, fabrication SOP, assembly SOP, quality-assurance protocol), (B) material supply-chain (qualified suppliers per material, pricing, long-lead-time management, recycling/recovery plan), (C) pilot-line design and commissioning (equipment list, O&M manuals, scale-up guidance), (D) cell-level data package (raw cycling data, abuse-test reports, third-party verification reports, failure-mode atlas), (E) digital models (electrochemical simulation code, manufacturing process-optimization models, cost-modeling spreadsheet). Track completion status monthly from Month 48 (2030-10-14) onward; finalize deliverables by Month 72 (2032-10-14).

### Expert Validation Steps

- Technology-transfer and licensing specialist (e.g., university TLO, national-lab partnerships office, battery OEM licensing counsel) reviews the prospective-licensee landscape and term-sheet framework; advises on typical exclusive/non-exclusive split, royalty ranges (industry benchmarks: 1-8% for battery IP depending on exclusivity and defensibility), and commercialization timelines (typically 3-5 years from licensing to first commercial cell); flags any unrealistic licensing expectations
- Prospective licensee representative (from one of the top 3-5 identified candidates, e.g., business development or R&D lead from Tesla, LG, Samsung, Panasonic, emerging EV maker, or aerospace integrator) participates in informal advisory meetings (Months 12, 18, 24 = 2027-10-14, 2028-04-14, 2028-10-14); provides candid feedback on cell specifications, manufacturability concerns, cost targets and commercialization readiness; iterates on the Reference Application Anchor to ensure licensee alignment
- Legal counsel experienced in battery technology transfer and IP licensing reviews the joint-IP ownership framework with university/national-lab partners; validates that the programme's ownership of integrated cell architecture and manufacturing processes is defensible and free from partner claims; drafts licensing-agreement templates for use at technology-transfer phase (Months 72-84 = 2032-10-14 to 2033-10-14)

### Responsible Parties

- Partner and ecosystem lead (in-house: 1 FTE, owns licensee engagement and IP framework)
- IP counsel (in-house or external: 0.5-1 FTE for licensing-agreement drafting and joint-IP negotiation)
- Programme director (in-house: 0.1-0.2 FTE for licensee relationship management)
- External technology-transfer specialist (0.1 FTE contract, USD 20-30 K, for term-sheet development and licensing benchmarking)

### Assumptions

- **High:** A credible prospective licensee can be identified and engaged by Month 12 (2027-10-14) and will commit to a non-binding term sheet by Month 12 (2027-10-14) outlining technology scope, exclusivity tier and royalty range. If no licensee is interested by Month 18 (2028-04-14), the Reference Application Anchor may be misaligned with market demand and must be revised.
- **High:** Joint-IP ownership with university and national-lab partners can be negotiated by Month 24 (2028-10-14) such that the programme retains ownership of integrated cell architecture and manufacturing processes, while partners retain publication rights (post-6-month embargo). If partners demand joint ownership of final designs or blocking rights, licensing value is diminished by 30-50%.
- **Medium:** Technology-transfer deliverables (process documentation, supply-chain qualification, pilot-line design, data package) can be completed in a 12-month sprint (Months 72-84 = 2032-10-14 to 2033-10-14) after the cell is third-party verified. If deliverables are more extensive or require external manufacturing partners to validate scale-up, 12 months is insufficient and hand-off slips to Month 96+ (2034-10-14+).
- **Medium:** Licensee requirements (cycle-life, thermal stability, cost-per-Wh, form factor, pack-integration constraints) are stable during Months 12-30 (2027-10-14 to 2029-04-14) and do not change significantly. If licensee's roadmap shifts (e.g., EV maker deprioritizes high-energy cells in favour of lower-cost commodity cells), cell specifications must be re-negotiated, potentially triggering a chemistry pivot.

### SMART Validation Objective

By Month 12 (2027-10-14), >=2 prospective licensees (battery OEMs, integrators, or OEMs) shall be identified and contacted with a non-binding RFI. By Month 18 (2028-04-14), at least one lead licensee shall have signed a non-binding term sheet (3-5 pages) specifying technology scope, exclusivity tier (exclusive for core, non-exclusive for enabling materials proposed), royalty range (2-5% for exclusive, 1-2% for non-exclusive), and minimum commercialization timeline (first prototype by Year 5 post-licensing). By Month 24 (2028-10-14), a comprehensive IP and licensing framework shall be finalized with legal counsel, covering joint-IP ownership with partners, patent-filing strategy and publication embargo. By Month 30 (2029-04-14), licensee shall have reviewed Month 30 (2029-04-14) third-party verification data and confirmed continued interest (or identified re-negotiation items). By Month 72 (2032-10-14), technology-transfer readiness checklist shall be 90%+ complete; licensing agreement shall be signed or ready for signature at Month 84 (2033-10-14).

### Notes

- Do not treat licensee engagement as a 'nice-to-have' or post-delivery activity. Informal partner contact by Month 12 (2027-10-14) is critical to validate that the cell design aligns with real commercialization demand.
- Reference Application Anchor is not a free choice. Co-design the anchor with the lead licensee (Month 12 = 2027-10-14 onward) to ensure the cell's duty-cycle specification (C-rate, temperature, cycle-life) matches the licensee's manufacturing roadmap and end-use constraints.
- IP ownership and publication rights must be negotiated with university and national-lab partners upfront (Month 1-3 = 2026-11-14 to 2027-01-14), not after joint work is completed. Include IP terms in the partnership agreements.
- Technology-transfer readiness is often forgotten. Allocate USD 2-3 M (estimate) and 12-month effort (Months 72-84 = 2032-10-14 to 2033-10-14) for documentation, supply-chain validation, pilot-line design and commissioning guidance. Under-investing in transfer leads to licensee friction and extended hand-off.
- If the identified licensee withdraws before Month 36 (2029-10-14), have a backup licensee or licensing consortium identified. Do not proceed to chemistry selection at Month 36 (2029-10-14) without at least one committed licensee.

## Summary

Battery invention R&D programme (USD 300 M, 84 months, 500 Wh/kg and 1000 Wh/L target). Five to seven critical data collection areas identified to validate the most sensitive programme assumptions: chemistry pathway feasibility, cell-level proof standards, pilot-line operationalization, permitting timeline, payroll and budget adequacy, cycle-life and volumetric thresholds, and technology-transfer partner readiness. Data validation prioritizes early cycle-life and volumetric-density gates (Months 3-30 = 2027-01-14 to 2029-04-14), permitting de-risking (Months 0-3 = 2026-10-14 to 2027-01-14), and budget reconciliation (Month 1-6 = 2026-11-14 to 2027-04-14) to preserve pivot capacity and compressed timeline. Simulation steps leverage internal modelling, partner characterization access and commercial testing; expert validation engages battery electrochemists, regulatory specialists, manufacturing engineers and licensing counsel. Most sensitive assumptions require binding decisions by Month 3 (2027-01-14) to avoid late-stage discovery risks.