This plan implies one or more physical locations.

## Requirements for physical locations

- Within commuting distance of Tesla Gigafactory Texas, east Austin, for talent and supplier access
- Zoning permitting light industrial/lab use with wet chemistry, dry rooms and reactive metals
- Space for dry room, pilot pouch-cell line, abuse-test chambers and characterization labs (estimate 5,000-10,000 m2)
- Adequate power, ventilation, hazardous-waste handling and fire-authority access
- Proximity to University of Texas at Austin for partnerships and recruitment
- Close to Austin-Bergstrom airport and highways for equipment and materials logistics
- Ability to start lease or fit-out immediately (Month 0 = 2026-10-14)

## Location 1
USA, Texas

Northeast Travis County, Austin (Harris Branch/Manor Road corridor)

Light-industrial or flex R&D parcels near SH-130 and Tesla Gigafactory Texas, Austin, TX

**Rationale**: Closest option to the Tesla site named in the plan. Industrial zoning, large buildable lots, and easy highway access suit dry rooms and hazardous-materials handling. Talent competition and IP contamination exposure are highest here.

## Location 2
USA, Texas

Southeast Austin near Austin-Bergstrom International Airport

Industrial/R&D parks along SH-71 and Burleson Road, Austin, TX

**Rationale**: Existing light-industrial and lab-capable buildings reduce fit-out time. Airport access eases logistics of precursors and equipment. About 25-35 minutes from Tesla and central to the Austin technical workforce.

## Location 3
USA, Texas

North Austin, UT Pickle Research Campus area

Research/industrial sites near Pickle Research Campus, Burnet Road and Braker Lane, Austin, TX

**Rationale**: Adjacent to University of Texas research facilities, supporting partnerships, shared characterization access and graduate recruitment. Established lab-oriented zoning. Longer distance from Tesla reduces direct poaching pressure while remaining within the Austin ecosystem.

## Location 4
USA, Texas

Pflugerville/Hutto, Austin metro

Industrial parks in Pflugerville or Hutto, TX

**Rationale**: Lower land and lease costs and room for expansion, hazardous-use permitting often simpler. Within roughly 20-30 minutes of the Tesla site and the Austin labor pool.

## Location Summary
The plan specifies a site near Tesla in Austin, Texas. Four candidate areas are offered: northeast Austin beside Tesla, southeast Austin near the airport, north Austin near UT's Pickle campus, and Pflugerville/Hutto. They trade off proximity to Tesla, fit-out speed, university access, cost and hazardous-materials permitting.