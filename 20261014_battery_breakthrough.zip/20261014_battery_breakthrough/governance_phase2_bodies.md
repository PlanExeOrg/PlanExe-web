### 1. Scientific Steering Committee

**Rationale for Inclusion:** Manages strategic direction, gate decisions (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14) and major resource allocation in a high-ambition, capital-constrained R&D programme with three competing chemistry pathways. Resolves disputes over chemistry advancement, budget reallocation and pivot decisions. Ensures evidence-linked tranche release and protects programme credibility through independent oversight of claims.

**Responsibilities:**

- Approve chemistry-tournament structure and success criteria by Month 3 (2027-01-14); decide funding allocation among active teams
- Conduct Month 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14) gate reviews, applying documented go/no-go criteria and independent red-team verification results
- Authorize chemistry selection at Month 36 (2029-10-14); approve reserve activation and major pivots if needed
- Approve tranche releases (T2 at Month 12 = 2027-10-14, T3 at Month 24 = 2028-10-14, T4 at Month 36 = 2029-10-14) linked to milestones; manage USD 20M reserve and pivot-runway allocation
- Oversee risk management: review technical risks (chemistry, volumetric density, cycle-life, safety), operational risks (permitting delays, talent attrition, partner dependency) and financial risks (budget burn, cost overruns) quarterly
- Review and approve IP strategy by Month 2 (2026-12-14), licensing framework by Month 24 (2028-10-14) and commercialization plan by Month 72 (2032-10-14)

**Initial Setup Actions:**

- Establish Committee membership (director, four chemistry leads, external technical advisor, funder representative) by Month 1 (2026-11-14)
- Document decision authority: financial thresholds (Steering Committee authorizes decisions >USD 2M or >20% of annual tranche; Director authorizes USD 500K-2M within approved budget), escalation path (funder for programme stop or major descope), and conflict resolution (majority vote with tie-breaker by Director)
- Set Committee meeting cadence: monthly (first 12 months) then quarterly, with 3-week gate-review cycles at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14)
- Define gate criteria and success metrics by Month 3 (2027-01-14): Month 18 (2028-04-14) = projected cell-level ≥500 Wh/kg and ≥950 Wh/L plus cycle-life data; Month 30 (2029-04-14) = measured pouch cells meeting thresholds; Month 36 (2029-10-14) = one finalist selected
- Appoint independent red team (2-3 external or in-house non-core scientists) by Month 1 (2026-11-14) reporting directly to Steering Committee
- Establish decision documentation protocol: gate decisions, financial approvals, and risk escalations recorded and shared with funder within 5 days

**Membership:**

- Programme Director (chair)
- Senior Chemistry Lead (lithium-sulfur pathway, e.g.)
- Senior Chemistry Lead (anode-free solid-state pathway, e.g.)
- Senior Chemistry Lead (conversion cathode or reserve pathway, e.g.)
- Chief Technology Officer or Deputy Director (operational oversight liaison)
- External Technical Advisor (independent expert from battery research community)
- Funder Representative (non-voting observer, approves releases and stop decisions)

**Decision Rights:** Steering Committee holds exclusive authority over chemistry tournament structure and finalist selection (Month 36 = 2029-10-14), tranche release (T2-T4) conditioned on milestones, reserve allocation and programme pivots costing >USD 5M. Director (chair) has delegated authority to approve decisions up to USD 2M within approved tranches and to reallocate within 15% of chemistry-team budgets. Funder representative approves any decision to stop or descope the programme. Red team has authority to challenge progress claims and delay gate decisions up to 3 weeks for independent verification.

**Decision Mechanism:** Majority vote among Committee members (7 members; 4 required for quorum). Tie-breaker: Director casts second vote if tie occurs. Red team replication results (pass/fail on key claims) are required inputs to Month 18, 30 and 36 (2028-04-14, 2029-04-14, 2029-10-14) gates and must be presented in writing ≥5 days before gate meeting. If red team flags unresolved inconsistencies, gate decision deferred ≤3 weeks for remedial verification; if unresolved after 3 weeks, gate advances but flag is escalated to funder. Financial decisions >USD 5M require unanimous consent or funder sign-off.

**Meeting Cadence:** Monthly full meetings Months 0-12 (2026-10-14 to 2027-10-14), then quarterly Months 12-84 (2027-10-14 to 2033-10-14). Emergency meetings ≤48 hours if a critical risk surfaces (e.g., major chemistry failure, permitting denial, partner loss). Gate review cycles at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) conducted over 3 weeks: Week 1 red-team verification report, Week 2 chemistry-team response and Steering Committee deliberation, Week 3 final decision and communication to funder.

**Typical Agenda Items:**

- Progress reports from each chemistry team: cell builds, cycling data, measured Wh/kg and Wh/L, cycle-life performance, safety-test results, comparison to cell-level mass-and-volume model
- Risk register review: technical (chemistry, volumetric density, cycle-life, safety), operational (permitting, talent, partner access, supply chain), financial (burn rate, cost overruns, currency exposure); escalation of any risk approaching trigger thresholds
- Red-team findings: replication results, challenged claims, unresolved discrepancies and remedial actions
- Financial dashboard: cumulative spend by category, remaining tranches, reserve utilization, variance from plan, pending reallocations
- Partnership and characterization access status: partner deliverables, queue times, backup-partner activation if needed
- IP and regulatory updates: patent applications filed, publications reviewed for compliance, permit status, EHS incidents and corrective actions

**Escalation Path:** Steering Committee escalates to the Funder (non-voting member) any decision involving: (i) programme stop or >25% descope, (ii) additional funding beyond USD 300M cap, (iii) major chemistry-path change deviating from tournament structure (e.g., adding a fourth active chemistry or abandoning one before Month 30 = 2029-04-14), (iv) financial overrun >20% of current tranche. Red team escalates directly to Steering Committee (bypassing chemistry leads) any unresolved claim inconsistency or high-risk safety issue. Steering Committee escalates to Funder within 48 hours any incident threatening permitting, safety or regulatory compliance.
### 2. Chemistry and Discovery Leadership Team

**Rationale for Inclusion:** Manages day-to-day R&D execution across three active chemistry pathways plus reserve. Owns synthesis, pouch-cell fabrication, electrochemical characterization, failure analysis and iteration pace. Reports progress, cycle-life data and safety results to Steering Committee; escalates risks and resource conflicts. Team structure hedges chemistry risk while maintaining focus and preventing runaway scope.

**Responsibilities:**

- Execute chemistry-tournament strategy: maintain three active teams (lithium-sulfur, anode-free solid-state, conversion cathode or similar) with clear leads and budgets; manage weekly team meetings, monthly progress reviews and adherence to gate criteria
- Design, build and cycle cells: execute pouch-cell fabrication (50-100 cells/month by Month 24 = 2028-10-14), manage pilot-line scheduling, document build parameters and correlate cell performance to process variables
- Measure energy density and cycle life: characterize all cells for Wh/kg, Wh/L, cycle retention at defined rates and temperatures; report data against cell-level mass-and-volume model within one week of completion
- Manage failure forensics: autopsy every failed cell within one week using standardized protocol; perform post-mortem microscopy, electrolyte analysis and impedance testing; populate forensics atlas with root causes and design-change implications
- Oversee characterization scheduling: coordinate with university and national-lab partners for operando and post-mortem analysis; manage backlogs and escalate queue delays >3 weeks to Steering Committee
- Track safety and abuse testing: schedule thermal-ramp screening and contracted abuse tests per phased plan; maintain thermal-runaway thresholds (proposed: ≥120°C for finalists); escalate any chemistry dropping below safety thresholds to red team for gate impact

**Initial Setup Actions:**

- Define chemistry-team leads and core members by Month 1 (2026-11-14); allocate budget per team proportional to strategic priority (proposed: equal initial share, rebalanced after Month 12 = 2027-10-14 based on progress)
- Establish cell-level mass-and-volume model by Month 4 (2027-02-14); project Wh/kg and Wh/L for each chemistry starting Month 6 (2027-04-14); perform monthly updates and variance analysis by Month 20 (2028-06-14)
- Commission pilot-line dry-room and pouch-cell fabrication line by Month 3 (2027-01-14); conduct trial builds and yield-optimization work Months 3-6 (2027-01-14 to 2027-04-14); reach target 50-100 cells/month by Month 24 (2028-10-14)
- Establish forensics autopsy protocol and forensics atlas by Month 6 (2027-04-14); begin weekly failure analysis by Month 9 (2027-07-14)
- Identify and contract with primary characterization partners (≥2) by Month 3 (2027-01-14); negotiate guaranteed turnaround (≤3 weeks) and schedule first external analysis by Month 9 (2027-07-14)
- Define go/no-go criteria per chemistry by Month 18 (2028-04-14): specify cycle-life target (proposed ≥300 cycles), Wh/kg and Wh/L thresholds (≥500 Wh/kg, ≥950 Wh/L interim), safety onset threshold (≥120°C) and what counts as 'pass' at Month 30 (2029-04-14)

**Membership:**

- Chemistry Lead 1 (lithium-sulfur pathway)
- Chemistry Lead 2 (anode-free solid-state pathway)
- Chemistry Lead 3 (conversion cathode or reserve pathway)
- Synthesis Team Manager (precursor sourcing, material procurement, lab safety coordination)
- Pilot-Line and Cell-Engineering Lead (pouch-cell design, fabrication, process control)
- Characterization and Forensics Lead (operando and post-mortem analysis, failure-root-cause investigation)
- Data and Modeling Engineer (cell-level mass-and-volume model maintenance, performance tracking, statistical analysis)

**Decision Rights:** Chemistry Leadership Team owns all decisions below USD 500K per chemistry per quarter and within approved tranches. Decides resource allocation among synthesis, characterization and pilot-line work; adjusts chemistry-team budgets by ≤15% per quarter without Steering Committee approval, provided total stay within approved tranches. Decides cell-build schedule, characterization priorities and failure-analysis focus. Escalates to Steering Committee: cost overruns (team spend >USD 500K/quarter), schedule slips >4 weeks, cycle-life data missing at gate thresholds, safety concerns (onset <120°C or non-reversible overcharge), and characterization queue delays >4 weeks.

**Decision Mechanism:** Chemistry Leadership Team (7 members) meets weekly; Leads and Manager form a core decision group. Decisions by consensus if possible; tie-breaker: Chemistry Lead 1 (lithium-sulfur, most mature path) casts deciding vote on inter-team resource allocation, Pilot-Line Lead decides on fabrication scheduling conflicts, Characterization Lead decides on characterization-access conflicts. Major within-team changes (>20% staffing shift, >USD 100K reallocation per month) require written justification to Steering Committee within 5 days. Monthly reports to Steering Committee include progress summary, risk flags and revised go/no-go trajectory.

**Meeting Cadence:** Weekly synthesis and characterization team meetings (within-team technical sync), monthly full Chemistry Leadership meetings with Steering Committee liaison, quarterly deep-dive reviews with Steering Committee (Months 3, 6, 9, 12, 18, 24, 30, 36 = 2027-01-14, 2027-04-14, 2027-07-14, 2027-10-14, 2028-04-14, 2028-10-14, 2029-04-14, 2029-10-14, etc.). Emergency meetings if safety issue arises or characterization bottleneck threatens timeline.

**Typical Agenda Items:**

- Cell-build status: fabrication yield, cycle-test results, Wh/kg and Wh/L measurements against model, batch-to-batch variability (target 90% within ±10%)
- Failure analysis: new failures diagnosed, root causes assigned, forensics atlas updated, design changes queued
- Characterization queue and throughput: samples processed, turnaround time, any backlog or partner delays, escalation if needed
- Chemistry-specific progress: synthesis scalability, electrolyte/interface stability, lithium-metal protection or other design focus per pathway
- Go/no-go trajectory: quarterly assessment against Month 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14) criteria; updated projections if a chemistry is off-track
- Safety and abuse testing: upcoming scheduled tests, results from thermal-ramp or contracted testing, onset temperatures, any threshold violations

**Escalation Path:** Chemistry Leadership escalates to Steering Committee: (i) any chemistry showing cycle-life <250 cycles at 80% by Month 24 (2028-10-14), (ii) thermal-runaway onset <100°C at any point, (iii) measured pouch-cell Wh/L projected to fall below 950 Wh/L by Month 30 (2029-04-14), (iv) characterization queue delays exceeding 4 weeks, (v) precursor supply delays >2 weeks, (vi) cost overruns >USD 500K/quarter per team. Escalates to red team directly if a measurement discrepancy arises that undermines gate credibility (e.g., Wh/kg claims not reproducible at ≥90% consistency). Escalates to Compliance Office any safety incident (burns, chemical spill, equipment failure in abuse chamber, EHS violation).
### 3. Independent Technical Verification and Assurance Group (Red Team)

**Rationale for Inclusion:** High-ambition R&D programmes with competition between teams and high stakes (gatekeeping a USD 90M tranche or chemistry selection) face pressure to overstate progress or hide negative data. An independent red team with explicit authority to replicate key results, challenge claims and delay gate decisions protects programme credibility, patent value and funder confidence. Red team operates outside core teams to avoid bias.

**Responsibilities:**

- Replicate critical experimental results at each gate (Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14): build ≥1 independently chosen cell per chemistry team (or ≥3 for finalist), cycle per the original protocol and verify Wh/kg, Wh/L and cycle-life claims within ±10%
- Challenge progress claims: review monthly Chemistry Leadership reports and flag any inconsistencies (e.g., Wh/kg reported in November contradicts October data, or claimed ≥950 Wh/L but actual measured value is 920 Wh/L) within 5 days
- Verify gate-decision criteria are met before advancement: at Months 18, 30, 36 (2028-04-14, 2029-04-14, 2029-10-14), independently confirm that go/no-go threshold (e.g., ≥500 Wh/kg measured on ≥3 replicates) is satisfied or not; report findings in writing ≥5 days before Steering Committee gate meeting
- Audit cell-level mass-and-volume model methodology: review model assumptions (current-collector thickness, separator weight, inactive components), validate against actual pouch-cell teardowns (mass, volume, component count) quarterly, flag any deviations from physical reality
- Manage forensics quality: review forensic root-cause assignments (e.g., is a claimed 'dendrite growth failure' supported by SEM evidence?); escalate unfounded or inconsistent root-cause narratives to Chemistry Lead for correction
- Report directly to Steering Committee: monthly written summary of any discrepancies or concerns; gate-decision readiness memo ≥5 days before each gate

**Initial Setup Actions:**

- Recruit red team members (2-3 external or internal non-core scientists with battery expertise) by Month 1 (2026-11-14); establish independence: no reporting to chemistry leads, separate budget, authority to request data and resources from core teams
- Define replication protocol and acceptance criteria by Month 3 (2027-01-14): specify cell-build procedure (sourced materials, assembly by red-team personnel or independent third party), cycling protocol (discharge rate, temperature, cycle count) and measurement tolerance (±10% on Wh/kg, ±5% on Wh/L, ±5% on cycle-life retention)
- Establish monthly data-review cadence: receive Chemistry Leadership monthly reports within 5 days of publication, issue flag memo within 10 days if discrepancies detected
- Plan gate-verification timeline: identify ≥1 cell per team (or ≥3 for finalist) for replication ~4 weeks before gate meeting, issue replication results ≥5 days before Steering Committee meeting
- Conduct initial audit of cell-level mass-and-volume model (Month 6 = 2027-04-14): review model code, assumptions and prior pouch-cell measurements; report comparison of modeled Wh/kg vs actual measured Wh/kg for prior benchmark cells
- Set up forensics-quality review process (Month 9 = 2027-07-14): receive monthly forensics atlas updates from Chemistry Lead, spot-check ≥3 failure root-cause assignments per month against SEM/spectroscopy data

**Membership:**

- Red Team Lead (external expert or senior scientist not embedded in core teams)
- Electrochemistry Expert (post-doctoral or senior scientist: cell building, cycling, Wh/kg/L measurement)
- Characterization Specialist (operando and post-mortem analysis, failure-root-cause validation)

**Decision Rights:** Red team has exclusive authority to delay a gate decision ≤3 weeks to complete verification if core-team data is incomplete or inconsistent. Red team can request access to any chemistry-team laboratory notebook, instrument calibration records, and characterization data to validate claims. Red team cannot override Steering Committee gate decisions but can flag unresolved discrepancies to Funder, forcing resolution before tranche release. Red team can recommend demotion of a chemistry if replication consistently fails (measured <90% of claimed Wh/kg or Wh/L) or cycle-life claim is not supported.

**Decision Mechanism:** Red team decisions by consensus among the 3 members. If disagreement arises (e.g., one member thinks replication passed, two think it failed), red-team lead casts deciding vote. Red team prepares written gate-readiness memo (pass/no-pass/conditional pass with required remediation) signed by all three members. Steering Committee may override red-team no-pass recommendation only with unanimous vote and written justification to Funder.

**Meeting Cadence:** Weekly internal red-team technical meetings (30 min sync on replication status, monthly data-review findings), monthly data-review prep meetings (1 hour to plan gate verifications), gate-verification sprints at Months 17, 29, 35 (2028-03-14, 2029-03-14, 2029-09-14) (2-3 weeks focused replication work leading into Months 18, 30, 36 = 2028-04-14, 2029-04-14, 2029-10-14 gates).

**Typical Agenda Items:**

- Monthly data-review findings: discrepancies flagged in Chemistry Leadership reports, follow-up required, clarification received from chemistry leads
- Replication status: cells being built, cycling progress, preliminary Wh/kg/L and cycle-life results, on-track for gate-readiness memo delivery
- Model audit results: comparison of cell-level mass-and-volume model projections vs actual measured pouch cells, model assumptions validated or requiring revision
- Forensics quality spot-checks: failure root-cause assignments reviewed, SEM/spectroscopy evidence assessed, any unsupported claims flagged for correction
- Gate-readiness decision: pass/no-pass/conditional recommendation, required remediation if conditional, planned communication to Steering Committee

**Escalation Path:** Red team escalates directly to Steering Committee (bypassing chemistry leads) any finding suggesting: (i) systematic overstatement of Wh/kg or Wh/L (measured <85% of claimed), (ii) cycle-life data not reproducible, (iii) safety concern (onset <100°C not disclosed), (iv) forensic root-cause narratives unsupported by data. Red team escalates to Funder within 48 hours any finding suggesting programme data integrity issue or deliberate misrepresentation. If red team replication consistently fails for a chemistry, red team recommends Steering Committee demote or eliminate that chemistry path independent of chemistry-team objections.
### 4. Compliance, EHS and Regulatory Affairs Office

**Rationale for Inclusion:** High-energy lithium-rich cells require synthesis of reactive metals, flammable electrolytes and toxic precursors, plus abuse testing (thermal runaway, nail penetration, overcharge) in specialized chambers. Overlapping EPA hazardous-waste, OSHA worker-safety, TCEQ environmental, and local (Austin Fire Authority) permitting rules create complex compliance risk. A serious incident (lithium-water fire, solvent spill, overcharge thermal runaway) could shut operations for months and jeopardize the USD 300M programme. Dedicated compliance governance ensures permitting, incident prevention, regulatory monitoring and rapid response.

**Responsibilities:**

- Secure phased permits and licenses: Phase 1 dry-room and assembly (Month 3 = 2027-01-14), Phase 2 reactive-metal and solvent synthesis (Month 6 = 2027-04-14), Phase 3 abuse-test chambers (Month 9 = 2027-07-14); manage applications, regulator engagement and compliance conditions
- Maintain hazardous-materials compliance: register as EPA hazardous-waste generator, contract licensed waste handler, maintain inventory of reactive metals (lithium, sodium), flammable solvents and toxic precursors, document quantities and disposal per EPA rules
- Implement EHS operating model: document standard operating procedures for reactive-chemistry synthesis, dry-room operation, cell assembly, abuse testing and waste handling; train all staff quarterly; maintain incident log and corrective-action tracking
- Conduct quarterly internal EHS audits: inspect lab facilities, verify compliance with permits, audit waste-handling practices, test emergency response (spill kits, fire suppression, evacuation), check equipment maintenance and calibration
- Manage regulatory monitoring: retain external regulatory consultant to track federal (EPA, OSHA, DOT), state (TCEQ) and local (Austin Fire Authority) rule changes; assess impact on operations; propose adaptations or retrofits if needed
- Coordinate third-party safety testing: schedule and oversee thermal-ramp screening (Months 3-6 = 2027-01-14 to 2027-04-14), contracted abuse tests (Months 6-12 = 2027-04-14 to 2027-10-14) and in-house abuse chambers (Month 18 = 2028-04-14 onwards); verify test protocols meet ASTM or equivalent standards

**Initial Setup Actions:**

- Hire Chief EHS Officer (experienced battery-lab or chemical-manufacturing background) by Month 1 (2026-11-14); establish Compliance Office with initial 1-2 FTE
- Conduct regulatory assessment by Month 2 (2026-12-14): map all applicable EPA, OSHA, TCEQ and local rules; document current gaps (if any) relative to planned chemistry and testing scope; identify permit categories and application timelines
- Develop phased-permit strategy by Month 2 (2026-12-14): propose Phase 1 (dry-room, low-hazard assembly) by Month 3 (2027-01-14); Phase 2 (reactive synthesis) by Month 6 (2027-04-14); Phase 3 (abuse chambers) by Month 9 (2027-07-14); identify any showstoppers or long-lead items
- Initiate regulator engagement (Austin Fire Authority, TCEQ) at Month 0 (2026-10-14), before formal applications, to build collaborative relationship and identify early concerns
- Develop standard operating procedures (SOPs) for reactive chemistry, dry-room operation, waste handling and abuse testing by Month 6 (2027-04-14); review with regulatory consultant; distribute and train all staff
- Establish incident-response protocol by Month 3 (2027-01-14): define roles (EHS lead, emergency coordinator, regulator notification), communication chain, remediation steps and incident-log documentation
- Contract regulatory-monitoring consultant by Month 3 (2027-01-14); retain ongoing subscription to federal and state regulatory update services; establish quarterly regulatory-review meetings

**Membership:**

- Chief EHS Officer (full-time)
- Regulatory Affairs Manager (part-time or shared, ~0.5 FTE)
- Laboratory Safety Coordinator (on-site, ~0.5 FTE, embedded in chemistry teams)
- External EHS Advisory Committee (established by Month 6 = 2027-04-14): include representatives from Austin Fire Authority, TCEQ, a third-party safety consultant, and the programme's external technical advisor

**Decision Rights:** Chief EHS Officer has authority to halt any laboratory operation if safety or compliance concern arises (e.g., permit violation, improper chemical handling, equipment malfunction); halt remains in effect until remediated and approved by EHS Officer. Chief EHS Officer approves any synthesis of new chemical precursor or reactive material before first use on site, including review of hazard data sheets, storage requirements and waste-disposal plan. Chief EHS Officer approves in-house abuse-test protocols before chambers are commissioned. Regulatory Affairs Manager approves any external communications regarding environmental incidents or compliance status. Steering Committee must approve any decision to outsource on-site-prohibited chemistry synthesis (estimated cost USD 2-5M/yr if needed) or to defer permitting of planned facilities (e.g., delay abuse chambers from Month 9 = 2027-07-14 to Month 12 = 2027-10-14).

**Decision Mechanism:** Chief EHS Officer issues safety halt unilaterally if immediate danger is present; all other decisions by consensus with Regulatory Affairs Manager and Laboratory Safety Coordinator (3 required). If disagreement arises (e.g., EHS lead says chemistry must be outsourced, Chemistry Lead disagrees on hazard level), external EHS Advisory Committee member is consulted within 48 hours and their input informs final decision. Monthly EHS reports to Steering Committee document compliance status, any incidents (goal: zero), corrective actions and anticipated permitting milestones.

**Meeting Cadence:** Weekly EHS coordination meetings (30 min) with Chemistry Leadership Lab Safety Coordinator, monthly full Compliance Office meetings (1 hour), quarterly internal audits (2-3 days on site), annual external audit by third-party safety firm (2-3 days on site), quarterly regulator engagement meetings (with Austin Fire Authority, TCEQ representatives).

**Typical Agenda Items:**

- Permit status and timeline: Phase 1-3 application progress, regulator feedback, anticipated approval dates, any barriers or required adaptations
- Compliance findings from quarterly internal audits: violations or near-misses, root causes, corrective actions and completion status
- Incident log review: any chemical spills, equipment failures, near-misses, injuries; corrective actions taken and lessons learned
- Regulatory-update monitoring: new EPA, OSHA, TCEQ or local rules affecting operations; impact assessment and required adaptations
- Safety-testing status: scheduled thermal-ramp and abuse tests, protocol review, contractor qualifications, result review and any safety thresholds (proposed ≥120°C onset) met
- Waste-handling and inventory: hazardous-waste streams, disposal routes, contractor compliance, chemical inventory accuracy checks against permits

**Escalation Path:** Chief EHS Officer escalates to Steering Committee (within 48 hours) any: (i) serious incident (fire, chemical release, equipment failure) causing injury or environmental exposure, (ii) regulatory notice of violation (NOV) or threatened permit revocation, (iii) discovery of non-compliance requiring costly retrofit or extended downtime, (iv) regulator demand for operational change (e.g., tighter dry-room control, equipment replacement). Chief EHS Officer escalates to external EHS Advisory Committee for input on complex hazard assessment (e.g., is a newly identified precursor allowable on site?) or permitting questions. Chief EHS Officer escalates to Funder within 72 hours any serious incident and remediation cost >USD 1M.
### 5. Finance and Funding Governance (Integrated within Steering Committee)

**Rationale for Inclusion:** The fixed USD 300M budget is divided into evidence-linked tranches (USD 60/80/70/90M) with USD 20M reserve and USD 15M pivot runway. Financial governance ensures tranche release is conditional on demonstrated milestones, spending stays within tranches and allocated reserves, and budget reallocation decisions are transparent and controlled. The opex-vs-tranche mismatch (average opex ~USD 33M/yr vs Months 36-84 = 2029-10-14 to 2033-10-14 tranche of ~USD 22.5M/yr) requires careful carry-forward management and partner co-funding coordination. Integrated within Steering Committee rather than standalone to ensure financial decisions align with technical gates.

**Responsibilities:**

- Manage tranche release: T1 (USD 60M) released at project start Month 0 (2026-10-14); T2 (USD 80M) at Month 12 (2027-10-14) conditional on Phase 1 permit, operational pilot line and cell-level model live; T3 (USD 70M) at Month 24 (2028-10-14) conditional on Month 18 (2028-04-14) gate pass; T4 (USD 90M) at Month 36 (2029-10-14) conditional on chemistry selection gate and Month 30 (2029-04-14) pouch verification
- Monitor spend against tranches: monthly dashboard of cumulative spend by budget category (payroll ~USD 70M, capital ~USD 50M, facility ~USD 25M, variable ~USD 135M), remaining tranche balance, variance from plan and pending reallocations; escalate any category >±15% of plan
- Manage reserve (USD 20M unallocated) and pivot runway (USD 15M ring-fenced): hold unallocated and available for urgent redirects, pivots or cost overruns; release only with Steering Committee approval (>USD 1M requires unanimous vote); carry forward unused reserve through Month 30 (2029-04-14), available for later-stage contingencies
- Coordinate partner co-funding (proposed ≥15% of shared costs): track partner financial and in-kind contributions (characterization access, graduate-student stipends, equipment loaning); verify deliverables are met; offset programme spend where applicable
- Manage currency risk: identify major equipment and precursor purchases denominated in EUR or other foreign currency by Month 2 (2026-12-14); negotiate fixed-USD contracts or forward-exchange agreements for capital orders (Months 2-6 = 2026-12-14 to 2027-04-14); monitor EUR/USD rate; retain USD 2-3M currency contingency within the USD 5M general reserve

**Initial Setup Actions:**

- Establish Finance Governance charter by Month 1 (2026-11-14): define tranche-release conditions, spend-approval authority (Director: <USD 500K/decision, Steering Committee: USD 500K-2M, Funder: >USD 2M or reserve activation), and variance thresholds (escalate if category >±15% of quarterly plan)
- Develop detailed budget allocation model by Month 2 (2026-12-14): break down USD 300M by category and year (payroll, capital, facility lease, precursor and testing, EHS and computing, reserve); validate sum-to-total and identify any funding gaps
- Set up monthly financial-tracking dashboard by Month 3 (2027-01-14): automated spend reporting by cost center (four chemistry teams, pilot line, characterization, EHS, computing, etc.), variance flagging (±15%) and tranche-balance tracking
- Identify all major equipment and precursor purchases expected to be denominated in foreign currency (EUR, CNY, JPY) by Month 2 (2026-12-14); by Month 6 (2027-04-14), lock in fixed-USD pricing or forward-exchange contracts for capital equipment ordered in Months 2-6 (2026-12-14 to 2027-04-14)
- Negotiate partner cost-sharing agreements by Month 3 (2027-01-14): formalize contributions (≥15% of shared characterization, materials and validation costs) in writing; establish invoicing and reconciliation process; integrate partner spend tracking into financial dashboard
- Document spend-approval authority and escalation protocol by Month 1 (2026-11-14): establish approval matrices (Director approves <USD 500K, Steering Committee approves USD 500K-2M, Funder approves >USD 2M); require written justification for any variance >±15% or reallocation >USD 1M

**Membership:**

- Chief Financial Officer or Finance Manager (part-time, ~0.5 FTE, reports to Steering Committee chair or Director)
- Programme Controller (part-time or shared, ~0.3 FTE, manages monthly spend tracking and variance reporting)
- Steering Committee members (Director, chemistry leads, external advisor, funder representative) hold joint responsibility for budget-allocation decisions

**Decision Rights:** Director (Steering Committee chair) approves individual spending decisions up to USD 500K without committee vote, provided cumulative monthly spend stays within approved chemistry-team or operational budgets. Steering Committee approves reallocation between budget categories (e.g., moving USD 1M from capital to payroll for higher hiring) if reallocation is <USD 2M and total spend stays within current tranche. Steering Committee approves tranche release contingent on documented milestone achievement (Phase 1 permit, cell-level model live, Month 18 = 2028-04-14 gate pass, etc.). Funder approves any decision to access reserve (>USD 1M) or to reallocate between tranches. Finance Manager flags any monthly spend variance >±15% within 5 days; if variance is projected to exceed ±20% by quarter-end, Finance Manager and Director jointly propose corrective action to Steering Committee.

**Decision Mechanism:** Monthly spend variance flagged by Finance Manager; if <±15%, no action required. If ±15% to ±20%, Director reviews and approves corrective action (e.g., spending freeze in a category, or approval to exceed category). If >±20%, escalated to Steering Committee for review and reallocation decision. Tranche release decisions require Steering Committee majority vote (4 of 7 members) plus Funder approval. Reserve activation (>USD 1M) requires Steering Committee unanimity.

**Meeting Cadence:** Monthly financial reviews (1 hour, first Thursday of each month) with Director and Finance Manager; quarterly full Steering Committee financial briefing included in regular Steering Committee agenda; ad-hoc escalations if variance >±20% or unplanned expense >USD 500K.

**Typical Agenda Items:**

- Monthly spend dashboard: cumulative spend by category, remaining balance in current tranche, variance from plan (<±15% normal, flag if ±15%-20%, escalate if >±20%)
- Burn-rate trajectory: YTD spend, projected annualized burn, carry-forward to next tranche, any anticipated shortfalls
- Variance explanations: if a category exceeds ±15%, Finance Manager explains reason (one-time purchase, hiring acceleration, cost inflation) and proposed mitigation
- Tranche-release readiness: upcoming tranche (T2, T3, T4) milestone status (permit, gate pass, cell verification), evidence of readiness, planned release date and sign-off
- Partner co-funding status: invoices received, in-kind contributions quantified, deliverables verified, balance of cost-sharing aligned with ≥15% target
- Currency and procurement: status of major equipment orders and foreign-currency exposure, forward-contract status, any FX volatility requiring mitigation

**Escalation Path:** Finance Manager escalates to Director within 5 days if any monthly spend category exceeds ±15% of plan. Director escalates to Steering Committee within 1 week if variance >±20% or if corrective action requires reallocation >USD 1M. Steering Committee escalates to Funder within 3 days if variance suggests tranche depletion ahead of schedule or if programme is at risk of spending >USD 300M total. Finance Manager escalates to Steering Committee immediately if any evidence of financial irregularity (unsupported invoices, cost-shadowing, double-billing) is discovered.