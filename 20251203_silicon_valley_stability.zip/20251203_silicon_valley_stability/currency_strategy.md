This plan involves money.

## Currencies

- **USD:** The project is based in the USA and involves significant financial transactions.

**Primary currency:** USD

**Currency strategy:** The project is based in the USA, and all transactions will be conducted in USD. No additional international risk management is needed.