### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Project Charter Approved

### 2. Project Manager circulates Draft SteerCo ToR for review by Senior representatives from Law Enforcement Agencies, the National Guard, Local Government, Social Services, the Project Director, the Ethics Officer, and Legal Counsel.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulated Draft SteerCo ToR
- List of Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager consolidates feedback on the SteerCo ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised SteerCo ToR v0.2

**Dependencies:**

- Circulated Draft SteerCo ToR
- Feedback from Nominated Members

### 4. Project Sponsor formally approves the Project Steering Committee Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Revised SteerCo ToR v0.2

### 5. Project Sponsor formally appoints the Project Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Manager coordinates with the appointed SteerCo Chair to schedule the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email

### 7. Hold the initial Project Steering Committee kick-off meeting to review the project charter, discuss strategic objectives, and establish communication protocols.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SteerCo Kick-off Meeting Invitation

### 8. Project Manager establishes the Project Management Office (PMO) structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Defined
- PMO Staffing Plan

**Dependencies:**

- Project Start
- Project Charter Approved

### 9. Project Manager develops project management templates and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Templates
- Project Management Tools

**Dependencies:**

- PMO Structure Defined

### 10. Project Manager defines project reporting requirements for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Project Reporting Requirements Document

**Dependencies:**

- Project Management Templates

### 11. Project Manager establishes communication protocols with project stakeholders for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Communication Protocols Document

**Dependencies:**

- Project Reporting Requirements Document

### 12. Project Manager holds the initial PMO kick-off meeting to review project plans, assign initial tasks, and establish communication cadences.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Communication Protocols Document

### 13. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 14. Project Manager circulates Draft Ethics & Compliance Committee ToR for review by the Independent Legal Counsel (Civil Liberties), Ethics Officer, and representatives from the Community Advisory Board, Law Enforcement Agencies, and Social Services.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Circulated Draft Ethics & Compliance Committee ToR
- List of Nominated Members

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 15. Project Manager consolidates feedback on the Ethics & Compliance Committee ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Circulated Draft Ethics & Compliance Committee ToR
- Feedback from Nominated Members

### 16. Project Steering Committee formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Revised Ethics & Compliance Committee ToR v0.2

### 17. Project Steering Committee formally appoints the Ethics & Compliance Committee Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Ethics & Compliance Committee ToR v1.0

### 18. Project Manager coordinates with the appointed Ethics & Compliance Committee Chair to schedule the initial kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email

### 19. Hold the initial Ethics & Compliance Committee kick-off meeting to review the project charter, discuss ethical guidelines, and establish a code of ethics.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Code of Ethics

**Dependencies:**

- Ethics & Compliance Committee Kick-off Meeting Invitation

### 20. Project Manager drafts initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 21. Project Manager circulates Draft Technical Advisory Group ToR for review by the Chief Technology Officer (or equivalent), Cybersecurity Expert, Data Architect, Software Engineer, and representatives from the IT department of a participating agency.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Circulated Draft Technical Advisory Group ToR
- List of Nominated Members

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1

### 22. Project Manager consolidates feedback on the Technical Advisory Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised Technical Advisory Group ToR v0.2

**Dependencies:**

- Circulated Draft Technical Advisory Group ToR
- Feedback from Nominated Members

### 23. Project Steering Committee formally approves the Technical Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Technical Advisory Group ToR v1.0

**Dependencies:**

- Revised Technical Advisory Group ToR v0.2

### 24. Project Steering Committee formally appoints the Technical Advisory Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Technical Advisory Group ToR v1.0

### 25. Project Manager coordinates with the appointed Technical Advisory Group Chair to schedule the initial kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Technical Advisory Group Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email

### 26. Hold the initial Technical Advisory Group kick-off meeting to review the project charter, discuss technical architecture, and identify key technical risks.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Initial Technical Risk Assessment

**Dependencies:**

- Technical Advisory Group Kick-off Meeting Invitation

### 27. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Steering Committee established

### 28. Project Manager circulates Draft Stakeholder Engagement Group ToR for review by the Communications Manager, Community Liaison Officer, representatives from the Community Advisory Board, Social Services, and Law Enforcement Agencies.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Circulated Draft Stakeholder Engagement Group ToR
- List of Nominated Members

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1

### 29. Project Manager consolidates feedback on the Stakeholder Engagement Group ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised Stakeholder Engagement Group ToR v0.2

**Dependencies:**

- Circulated Draft Stakeholder Engagement Group ToR
- Feedback from Nominated Members

### 30. Project Steering Committee formally approves the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Revised Stakeholder Engagement Group ToR v0.2

### 31. Project Steering Committee formally appoints the Stakeholder Engagement Group Chair.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved Stakeholder Engagement Group ToR v1.0

### 32. Project Manager coordinates with the appointed Stakeholder Engagement Group Chair to schedule the initial kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Invitation

**Dependencies:**

- Appointment Confirmation Email

### 33. Hold the initial Stakeholder Engagement Group kick-off meeting to review the project charter, discuss stakeholder engagement strategies, and develop a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Draft Stakeholder Engagement Plan

**Dependencies:**

- Stakeholder Engagement Group Kick-off Meeting Invitation