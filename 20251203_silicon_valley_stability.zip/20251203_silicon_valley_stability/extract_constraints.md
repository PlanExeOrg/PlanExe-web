## Positive Constraints

- Multi-agency stability framework
- Location: Silicon Valley
- Manage civil unrest and social instability
- Stress scenario: AI-driven workforce displacement reaching 15%+ mass unemployment in 2026–2027
- Budget: $1.5 billion
- Proportional allocation model
- Coordinate law enforcement, the National Guard, local government, social services, and mutual aid partners
- Prioritize prevention
- Prioritize economic support mechanisms
- Prioritize the protection of civil liberties
- Phased strategic plan
- Clear inter-agency governance protocols
- Risk analysis
- Measurable outcomes
- Explicit contingencies
- Be as realistic as possible

## Negative Constraints

- Avoid bloat
- Do not use Blockchain
- Do not use VR
- Do not use AR
- Do not use DAO
- Do not use GDPR
- Do not use Digital ID
- Do not use UBI
- Do not use Universal Basic Services
