**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority, requiring strategic review and approval at a higher level.
Negative Consequences: Potential for budget overruns, delayed project milestones, and insufficient resources for critical activities.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: The risk has a high impact on project objectives and requires strategic decisions and resource allocation beyond the PMO's authority.
Negative Consequences: Project failure, significant delays, reputational damage, and potential harm to stakeholders.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Inability to reach consensus within the PMO necessitates a higher-level decision to ensure project progress.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: Significant changes to the project scope require strategic alignment and approval from the Steering Committee.
Negative Consequences: Scope creep, budget overruns, project delays, and failure to meet original objectives.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance with legal requirements.
Negative Consequences: Legal penalties, reputational damage, loss of public trust, and potential harm to stakeholders.

**Unresolved Technical Design Disagreement**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of TAG Recommendation and Final Decision
Rationale: Technical Advisory Group (TAG) unable to reach consensus on a critical design element, requiring strategic guidance.
Negative Consequences: Technical flaws, system instability, project delays, and increased costs.

**Stakeholder Opposition to Key Initiative**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Stakeholder Engagement Group's Assessment and Decision on Mitigation Strategy
Rationale: Significant stakeholder resistance threatens project success and requires strategic intervention.
Negative Consequences: Project delays, reduced community support, increased social unrest, and potential project failure.