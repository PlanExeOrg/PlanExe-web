### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for the entire 'AI Unrest Prep' project, given its significant budget, multi-agency involvement, and potential impact on civil liberties.

**Responsibilities:**

- Approve the overall project strategy and plan.
- Approve major project milestones and budget allocations.
- Monitor project progress against strategic objectives.
- Address and resolve strategic risks and issues.
- Ensure alignment with organizational goals and policies.
- Oversee inter-agency coordination and resolve conflicts.
- Approve changes to project scope or budget exceeding $5 million USD.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Review and approve the project charter and initial risk assessment.

**Membership:**

- Senior representatives from Law Enforcement Agencies
- Senior representatives from the National Guard
- Senior representatives from Local Government
- Senior representatives from Social Services
- Independent Expert in Crisis Management
- Independent Legal Counsel (Civil Liberties)
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (above $5 million USD), timeline, and key risks. Approval of major changes to the project plan.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Committee Chair has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion and approval of budget requests.
- Review and mitigation of strategic risks.
- Updates on inter-agency coordination.
- Review of compliance with civil liberties protection protocols.
- Review of audit reports.

**Escalation Path:** Escalate unresolved issues to the Governor's Office or relevant state-level authority.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** To manage the day-to-day execution of the 'AI Unrest Prep' project, ensuring efficient resource allocation, risk management, and adherence to project plans.

**Responsibilities:**

- Develop and maintain the project plan.
- Manage project budget and track expenditures.
- Monitor project progress and report to the Steering Committee.
- Identify and manage project risks and issues.
- Coordinate project activities across different agencies.
- Ensure adherence to project governance protocols.
- Manage changes to project scope or budget below $5 million USD.
- Facilitate communication and collaboration among project stakeholders.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management templates and tools.
- Define project reporting requirements.
- Establish communication protocols with project stakeholders.

**Membership:**

- Project Manager
- Finance Manager
- Risk Manager
- Communications Manager
- Representatives from each participating agency

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of budget status and expenditure tracking.
- Identification and mitigation of project risks and issues.
- Updates on inter-agency coordination.
- Review of project change requests.
- Review of resource utilization.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee.
### 3. Ethics & Compliance Committee

**Rationale for Inclusion:** To ensure the 'AI Unrest Prep' project adheres to the highest ethical standards and complies with all relevant laws and regulations, particularly regarding civil liberties, data privacy, and transparency.

**Responsibilities:**

- Develop and maintain a code of ethics for the project.
- Review and approve project activities for ethical and legal compliance.
- Investigate and address ethical concerns and compliance violations.
- Provide training to project staff on ethical and legal requirements.
- Monitor compliance with civil liberties protection protocols.
- Ensure compliance with data privacy regulations (e.g., GDPR principles, though GDPR itself is banned, the principles are not).
- Oversee the implementation of transparency measures.
- Review and approve all public communications for accuracy and ethical considerations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Develop a code of ethics for the project.
- Establish a confidential reporting mechanism for ethical concerns.

**Membership:**

- Independent Legal Counsel (Civil Liberties)
- Ethics Officer
- Representative from the Community Advisory Board
- Data Privacy Officer
- Representative from Law Enforcement Agencies
- Representative from Social Services

**Decision Rights:** Decisions related to ethical and legal compliance, including the approval of project activities, policies, and communications. Authority to halt project activities that violate ethical or legal standards.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Committee Chair has the deciding vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical issues.

**Typical Agenda Items:**

- Review of project activities for ethical and legal compliance.
- Discussion of ethical concerns and compliance violations.
- Updates on civil liberties protection protocols.
- Review of data privacy practices.
- Review of public communications for accuracy and ethical considerations.
- Review of whistleblower reports.

**Escalation Path:** Escalate unresolved issues to the Project Steering Committee or relevant legal authorities.
### 4. Technical Advisory Group

**Rationale for Inclusion:** To provide expert technical guidance and assurance on the design, implementation, and security of the project's technical infrastructure, including the early warning system and shared information platform.

**Responsibilities:**

- Review and approve the technical design of the early warning system and shared information platform.
- Provide guidance on cybersecurity best practices.
- Assess the technical feasibility and scalability of project solutions.
- Monitor the performance and reliability of the technical infrastructure.
- Identify and address technical risks and issues.
- Provide technical support to the PMO and other project teams.
- Ensure compliance with relevant technical standards and regulations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Group Chair.
- Establish meeting schedule and communication protocols.
- Review the technical architecture of the project.
- Identify key technical risks and issues.

**Membership:**

- Chief Technology Officer (or equivalent)
- Cybersecurity Expert
- Data Architect
- Software Engineer
- Representative from the IT department of a participating agency
- Independent Technical Consultant

**Decision Rights:** Decisions related to the technical design, implementation, and security of the project's technical infrastructure. Authority to recommend changes to the technical architecture or implementation plan.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Group Chair facilitates discussion and seeks to find a mutually acceptable solution. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical technical issues.

**Typical Agenda Items:**

- Review of the technical design of project components.
- Discussion of cybersecurity threats and vulnerabilities.
- Updates on the performance and reliability of the technical infrastructure.
- Identification and mitigation of technical risks and issues.
- Review of technical change requests.
- Review of compliance with technical standards and regulations.

**Escalation Path:** Escalate unresolved technical issues to the Project Steering Committee.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** To ensure effective communication and engagement with all key stakeholders, including affected communities, displaced workers, and the general public, fostering trust and cooperation.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct regular consultations with key stakeholders.
- Provide timely and accurate information to stakeholders.
- Address stakeholder concerns and feedback.
- Monitor stakeholder sentiment and identify potential issues.
- Coordinate communication activities across different agencies.
- Ensure that stakeholder perspectives are considered in project decision-making.
- Organize public forums and community meetings.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Group Chair.
- Establish meeting schedule and communication protocols.
- Identify key stakeholders and their communication needs.
- Develop a stakeholder engagement plan.

**Membership:**

- Communications Manager
- Community Liaison Officer
- Representative from the Community Advisory Board
- Representative from Social Services
- Representative from Law Enforcement Agencies
- Public Relations Specialist

**Decision Rights:** Decisions related to stakeholder engagement strategies, communication plans, and public relations activities. Authority to recommend changes to project plans based on stakeholder feedback.

**Decision Mechanism:** Decisions made by consensus. In case of disagreement, the Group Chair facilitates discussion and seeks to find a mutually acceptable solution. Unresolved issues are escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical stakeholder issues.

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder concerns and feedback.
- Updates on communication plans and public relations activities.
- Identification and mitigation of stakeholder risks and issues.
- Review of stakeholder sentiment and media coverage.
- Planning for public forums and community meetings.

**Escalation Path:** Escalate unresolved stakeholder issues to the Project Steering Committee.