A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Île aux Cygnes has a stable subsurface that can support the statue's weight after expansion. | Conduct a thorough geotechnical survey of the island, including core sampling and load-bearing tests. | The survey reveals significant soil instability or insufficient load-bearing capacity requiring extensive and costly remediation. |
| A2 | The Statue of Liberty can be disassembled and reassembled without significant damage or loss of historical integrity. | Perform a detailed structural analysis and create a 3D model to simulate the disassembly and reassembly process, identifying potential stress points. | The analysis reveals critical structural weaknesses or stress points that make safe disassembly and reassembly impossible without risking significant damage. |
| A3 | The US and French governments will maintain a strong, cooperative relationship throughout the project's duration. | Secure formal, written agreements of support from key government agencies in both the US and France, outlining their commitment to the project. | Either government withdraws its support or imposes conditions that significantly impede the project's progress (e.g., denial of key permits). |
| A4 | The project team possesses the necessary expertise and experience to successfully manage a project of this scale and complexity. | Conduct a thorough review of the project team's qualifications and experience, including past performance on similar large-scale infrastructure projects. | The review reveals significant gaps in expertise or experience, particularly in areas such as international logistics, historic preservation, or large-scale construction management. |
| A5 | The local Parisian community will embrace the relocated Statue of Liberty and integrate it into their cultural identity. | Conduct surveys and focus groups within the local Parisian community to gauge their attitudes towards the project and their willingness to embrace the statue. | The surveys reveal widespread resistance or indifference towards the project, indicating a failure to connect with the local community's cultural values. |
| A6 | The project can attract sufficient private investment to supplement public funding and ensure financial sustainability. | Actively solicit commitments from potential private investors, presenting a detailed business plan outlining the project's potential for revenue generation and return on investment. | The project fails to secure significant private investment commitments, indicating a lack of confidence in its financial viability and reliance on potentially unstable public funding. |
| A7 | The necessary specialized equipment (cranes, heavy-lift vessels, etc.) will be readily available and function as expected throughout the project. | Secure firm contracts with equipment suppliers, including detailed maintenance schedules and backup plans for equipment failures. | Key equipment becomes unavailable due to unforeseen circumstances (e.g., prior commitments, mechanical failures), causing significant delays. |
| A8 | The weather conditions during transportation and reassembly will be generally favorable, minimizing delays and risks to the statue. | Analyze historical weather data for the planned transportation and reassembly periods, identifying potential risks (e.g., storms, high winds) and developing contingency plans. | Severe weather events (e.g., hurricanes, prolonged periods of high winds) cause significant delays or damage to the statue during transportation or reassembly. |
| A9 | The project will generate sufficient positive media coverage to maintain public support and attract tourism. | Develop a comprehensive media relations strategy and actively pitch positive stories about the project to major news outlets and travel publications. | The project receives predominantly negative media coverage, focusing on cost overruns, delays, or environmental concerns, leading to a decline in public support. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Diplomatic Deep Freeze | Process/Financial | A3 | Regulatory Affairs Specialist | CRITICAL (20/25) |
| FM2 | The Copper Catastrophe | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Shifting Sands of Île aux Cygnes | Market/Human | A1 | Permitting Lead | HIGH (10/25) |
| FM4 | The Empty Coffers Catastrophe | Process/Financial | A6 | Funding Lead | CRITICAL (20/25) |
| FM5 | The Incompetence Implosion | Technical/Logistical | A4 | Project Manager | CRITICAL (15/25) |
| FM6 | The Parisian Rejection | Market/Human | A5 | Public Relations Manager | HIGH (10/25) |
| FM7 | The Equipment Exodus | Technical/Logistical | A7 | Head of Logistics | CRITICAL (15/25) |
| FM8 | The Weather Whiplash | Process/Financial | A8 | Risk Manager | CRITICAL (16/25) |
| FM9 | The Media Meltdown | Market/Human | A9 | Public Relations Manager | HIGH (12/25) |


### Failure Modes

#### FM1 - The Diplomatic Deep Freeze

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Regulatory Affairs Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's reliance on international cooperation makes it vulnerable to shifts in political relations. A diplomatic rift between the US and France could lead to: 
*   Sudden withdrawal of French government support.
*   Denial of critical permits for island expansion or river transport.
*   Freezing of jointly allocated funds.
*   Public condemnation of the project, leading to investor flight.

##### Early Warning Signs
- Public disagreements between US and French officials regarding the project.
- Delays in scheduled meetings with key regulatory agencies.
- Negative media coverage highlighting political tensions.

##### Tripwires
- French government publicly expresses reservations about the project = True
- Key permit approvals delayed by > 180 days due to political reasons
- Joint funding allocation reduced by >= 25% due to political factors

##### Response Playbook
- Contain: Immediately initiate high-level diplomatic discussions to address concerns.
- Assess: Evaluate the extent of the damage to the project's political support and financial viability.
- Respond: Develop a revised project plan that addresses the political concerns, potentially involving a scaled-down scope or alternative funding sources.


**STOP RULE:** Formal withdrawal of support from either the US or French government.

---

#### FM2 - The Copper Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the Statue of Liberty can be safely disassembled proves false. The structural analysis overlooks critical weaknesses, leading to:
*   Cracking and deformation of copper panels during disassembly.
*   Damage to the internal iron framework due to unforeseen stress points.
*   Inability to safely detach certain components without risking collapse.
*   Significant delays and cost overruns due to the need for extensive repairs and redesign of the disassembly process.

##### Early Warning Signs
- Unexpected cracking or deformation observed during initial disassembly attempts.
- Stress levels exceeding predicted values during disassembly simulations.
- Discovery of previously undocumented corrosion or structural damage.

##### Tripwires
- Damage to >= 5% of copper panels during disassembly
- Stress levels exceeding design limits by >= 15% during disassembly
- Disassembly process delayed by > 60 days due to structural issues

##### Response Playbook
- Contain: Immediately halt disassembly operations and reinforce the affected areas.
- Assess: Conduct a thorough re-evaluation of the structural analysis and disassembly plan.
- Respond: Revise the disassembly methodology to address the identified weaknesses, potentially involving a more component-level approach and specialized tools.


**STOP RULE:** Irreversible structural damage to the Statue of Liberty rendering reassembly impossible.

---

#### FM3 - The Shifting Sands of Île aux Cygnes

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Permitting Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The geotechnical survey fails to accurately assess the subsurface conditions of Île aux Cygnes. After expansion, the island proves unstable, leading to:
*   Settling and shifting of the expanded landmass.
*   Cracking and subsidence of the pedestal foundation.
*   Tilting or collapse of the Statue of Liberty.
*   Public outcry and loss of confidence in the project's safety and viability.

##### Early Warning Signs
- Visible settling or cracking observed on the expanded island surface.
- Measurements indicating movement or instability in the pedestal foundation.
- Negative media coverage highlighting concerns about the island's stability.

##### Tripwires
- Settlement of the expanded island exceeding 10 cm within 30 days of completion
- Tilt of the pedestal foundation exceeding 0.1 degrees
- Public opinion polls showing > 50% disapproval of the project due to safety concerns

##### Response Playbook
- Contain: Immediately halt all construction activities and restrict public access to the island.
- Assess: Conduct a comprehensive re-evaluation of the geotechnical data and foundation design.
- Respond: Implement extensive ground stabilization measures, potentially involving deep soil mixing or pile driving, and redesign the pedestal foundation to accommodate the unstable conditions.


**STOP RULE:** Uncontrollable soil instability rendering the island unsuitable for supporting the Statue of Liberty.

---

#### FM4 - The Empty Coffers Catastrophe

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Funding Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that private investment will materialize proves false, leading to:
*   A shortfall in project funding, forcing drastic scope reductions.
*   Inability to secure necessary resources for critical tasks like structural reinforcement or environmental mitigation.
*   Increased reliance on public funding, leading to political opposition and potential budget cuts.
*   Project delays and eventual abandonment due to lack of financial viability.

##### Early Warning Signs
- Low response rates to fundraising appeals from private investors.
- Failure to meet fundraising targets within established deadlines.
- Withdrawal of initial commitments from potential private sponsors.

##### Tripwires
- Private funding commitments fall below 50% of target by [Date - 6 months from now]
- Key private sponsor withdraws commitment due to financial concerns
- Public funding allocation reduced by >= 10% due to budget constraints

##### Response Playbook
- Contain: Immediately launch an aggressive fundraising campaign targeting alternative private investors.
- Assess: Re-evaluate the project's financial model and identify potential cost-saving measures.
- Respond: Develop a revised project plan that reduces the project's scope to align with available funding, potentially involving a less ambitious island expansion or a simpler pedestal design.


**STOP RULE:** Total project funding falls below 75% of the revised budget.

---

#### FM5 - The Incompetence Implosion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Project Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the project team possesses the necessary expertise proves false, leading to:
*   Critical errors in structural analysis, resulting in damage during disassembly or transport.
*   Inefficient logistics management, causing delays and cost overruns.
*   Inadequate risk mitigation, leading to unforeseen challenges and project disruptions.
*   Overall mismanagement and a loss of confidence from stakeholders.

##### Early Warning Signs
- Frequent errors or omissions in technical reports.
- Inability to meet project deadlines or stay within budget.
- Lack of clear communication and coordination among team members.

##### Tripwires
- Critical engineering errors identified by independent review
- Project timeline delayed by > 90 days due to logistical issues
- Risk mitigation plans prove ineffective in addressing unforeseen challenges

##### Response Playbook
- Contain: Immediately bring in external consultants with expertise in relevant areas to provide guidance and support.
- Assess: Conduct a thorough review of the project team's performance and identify areas for improvement.
- Respond: Reorganize the project team, reassign responsibilities, and provide additional training to address identified skill gaps.


**STOP RULE:** Multiple critical failures attributed to team incompetence, jeopardizing the project's safety and viability.

---

#### FM6 - The Parisian Rejection

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Public Relations Manager
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the local Parisian community will embrace the relocated Statue of Liberty proves false, leading to:
*   Widespread protests and opposition to the project.
*   Refusal of local businesses to support the project or cater to tourists.
*   Vandalism and acts of sabotage targeting the statue or related infrastructure.
*   A decline in tourism and a failure to integrate the statue into the city's cultural identity.

##### Early Warning Signs
- Large-scale protests organized by local community groups.
- Negative sentiment expressed in local media and online forums.
- Refusal of local businesses to participate in project-related activities.

##### Tripwires
- Public opinion polls showing > 60% disapproval of the project among Parisian residents
- Significant acts of vandalism targeting the statue or related infrastructure
- Local businesses refusing to participate in project-related events or promotions

##### Response Playbook
- Contain: Immediately launch a targeted public relations campaign to address community concerns and highlight the project's benefits.
- Assess: Conduct a thorough review of the public engagement strategy and identify areas for improvement.
- Respond: Revise the project plan to address community concerns, potentially involving modifications to the island expansion or pedestal design, or increased investment in local community initiatives.


**STOP RULE:** Persistent and widespread community opposition rendering the project politically and socially untenable.

---

#### FM7 - The Equipment Exodus

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Head of Logistics
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of readily available specialized equipment proves false, leading to:
*   Critical delays in disassembly, transport, or reassembly due to equipment unavailability.
*   Increased costs associated with sourcing alternative equipment or paying premium rates for expedited delivery.
*   Compromised safety due to the use of substandard or untested equipment.
*   Overall disruption of the project timeline and budget.

##### Early Warning Signs
- Delays in securing contracts with equipment suppliers.
- Reports of equipment shortages or increased rental rates in the heavy-lift industry.
- Mechanical failures or maintenance issues with key equipment during initial testing.

##### Tripwires
- Heavy-lift crane unavailable for >= 30 days due to prior commitment
- Specialized transport vessel delayed by >= 45 days due to mechanical failure
- Replacement equipment costs exceed initial budget by >= 20%

##### Response Playbook
- Contain: Immediately activate backup plans for sourcing alternative equipment, potentially involving expedited delivery or rental from international suppliers.
- Assess: Re-evaluate the project schedule and identify critical tasks that are dependent on the unavailable equipment.
- Respond: Revise the project plan to accommodate the equipment delays, potentially involving a re-sequencing of tasks or a temporary reduction in scope.


**STOP RULE:** Unavailability of critical equipment for > 90 days, jeopardizing the project's timeline and safety.

---

#### FM8 - The Weather Whiplash

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Risk Manager
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption of favorable weather conditions proves false, leading to:
*   Significant delays in transportation and reassembly due to storms, high winds, or other adverse weather events.
*   Increased costs associated with weather-related delays, including storage fees, labor costs, and potential damage to the statue.
*   Compromised safety for workers and the statue due to hazardous working conditions.
*   Overall disruption of the project timeline and budget.

##### Early Warning Signs
- Extended periods of unfavorable weather conditions predicted by meteorological forecasts.
- Increased frequency of weather-related delays during initial project phases.
- Damage to equipment or materials due to severe weather events.

##### Tripwires
- Transportation delayed by >= 14 days due to severe weather
- Reassembly halted for >= 7 consecutive days due to high winds
- Weather-related damage to statue components exceeding $500,000

##### Response Playbook
- Contain: Immediately implement weather-related safety protocols, including halting operations and securing equipment and materials.
- Assess: Re-evaluate the project schedule and identify critical tasks that are dependent on favorable weather conditions.
- Respond: Revise the project plan to accommodate weather-related delays, potentially involving a re-sequencing of tasks or a temporary relocation of operations to a more sheltered location.


**STOP RULE:** Cumulative weather-related delays exceeding 120 days, jeopardizing the project's timeline and budget.

---

#### FM9 - The Media Meltdown

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Public Relations Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The assumption of positive media coverage proves false, leading to:
*   A decline in public support for the project due to negative press coverage.
*   Difficulty attracting tourists and generating revenue.
*   Increased scrutiny from regulatory agencies and government officials.
*   Overall damage to the project's reputation and long-term viability.

##### Early Warning Signs
- Predominantly negative tone in media coverage of the project.
- Declining public opinion poll numbers related to the project.
- Increased scrutiny from regulatory agencies and government officials.

##### Tripwires
- Negative sentiment in media coverage exceeding 60% based on sentiment analysis
- Public opinion polls showing < 40% approval of the project
- Significant decline in website traffic and social media engagement

##### Response Playbook
- Contain: Immediately launch a proactive media relations campaign to address negative coverage and highlight the project's benefits.
- Assess: Conduct a thorough review of the media relations strategy and identify areas for improvement.
- Respond: Revise the communication plan to address public concerns, potentially involving increased transparency, community engagement, or modifications to the project's scope.


**STOP RULE:** Irreversible damage to the project's reputation due to sustained negative media coverage, rendering it politically and socially untenable.
