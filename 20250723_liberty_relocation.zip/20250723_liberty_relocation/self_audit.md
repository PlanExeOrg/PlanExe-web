Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project involves engineering and logistics, not physics-defying concepts. I can’t name a specific law/limit.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (Statue of Liberty) + market (Paris) + tech/process (disassembly/reassembly/transport) + policy (international agreements) without independent evidence at comparable scale. There is no precedent for relocating a monument of this size and cultural significance.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Reports / Date: 6 months


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a clear mechanism-of-action for how buzzwords like "legacy" and "innovative" translate into business value. There is no owner assigned to define these terms or measure their impact. The plan does not define measurable outcomes.

**Mitigation**: Innovation Team: Create one-pagers for each strategic concept, defining value hypotheses, success metrics, and decision hooks. Owner: Innovation Team / Deliverable: One-pagers / Date: 30 days


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "weather delays, equipment malfunctions, and security threats" and includes a "Risk Assessment and Mitigation Strategies" section. However, it lacks explicit analysis of cascade effects or second-order risks like permit delays leading to financial shortfalls.

**Mitigation**: Risk Management Specialist: Expand the risk register to include cascade effects and second-order risks, and add controls with a dated review cadence. Deliverable: Updated risk register. Date: 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes 24 months for US and French approvals, but lacks a permit/approval matrix with authoritative lead times. The plan does not include evidence that this allocation is sufficient, and the 'Regulatory Approval Pathway' decision lacks detail.

**Mitigation**: Regulatory Affairs Specialist: Build a permit/approval matrix with dated predecessors and authoritative lead times from relevant jurisdictions. Set a NO-GO threshold on slip. Due date: 90 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a $500M budget but lacks a detailed financial model. The 'Builder's Foundation' scenario relies on this flawed assumption. There is no draw schedule, no mention of covenants, and no runway calculation.

**Mitigation**: Funding Team: Develop a detailed financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due date: 90 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes a $500M budget but lacks a detailed financial model. The 'Builder's Foundation' scenario relies on this flawed assumption. There is no draw schedule, no mention of covenants, and no runway calculation.

**Mitigation**: Funding Team: Develop a detailed financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due date: 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., 5 years) as a single number without providing a range or discussing alternative scenarios. The plan states, "The project is estimated to take 5 years."

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the project timeline. Deliverable: Scenario analysis report. Date: 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks engineering artifacts for build-critical components. There are no technical specs, interface definitions, test plans, or an integration map. The plan mentions "detailed disassembly methodology" but lacks specifics.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Due date: 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes several critical claims without providing verifiable evidence. For example, it states, "Secure necessary permits from US and French authorities" but lacks evidence of prior success or existing relationships.

**Mitigation**: Regulatory Affairs Specialist: Obtain letters of intent or preliminary approval from key regulatory bodies in the US and France. Due date: 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "relocating the Statue of Liberty to a revitalized Île aux Cygnes" without defining "revitalized". There are no SMART criteria for this deliverable.

**Mitigation**: Project Team: Define SMART criteria for "revitalized Île aux Cygnes", including a KPI for visitor satisfaction. Deliverable: SMART criteria document. Date: 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "Enhance cultural exchange between the United States and France" as a related goal, but this does not directly support the core goals of moving the statue and ensuring its integrity. It adds cost without a clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of 'Enhance cultural exchange', complete with a KPI, owner, and estimated cost, or move it to the backlog. Date: 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a 'Historical Conservator' to oversee disassembly, restoration, and reassembly, ensuring historical integrity. This role is critical and requires specialized expertise, making it difficult to fill. The plan states, "ensuring its historical integrity is preserved."

**Mitigation**: HR Team: Validate the talent market for historical conservators specializing in large-scale metal structures and preservation. Deliverable: Talent market assessment. Date: 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear and required approvals are unmapped. The plan lacks a regulatory matrix detailing necessary permits and timelines, creating a potential showstopper.

**Mitigation**: Regulatory Affairs Specialist: Develop a comprehensive regulatory matrix outlining required permits, lead times, and responsible authorities. Complete within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Long-Term Sustainability" as a risk and includes "Corrosion prevention coatings" in the resources. However, it lacks a detailed maintenance plan, funding strategy, or technology roadmap for long-term operations. The plan does not address personnel succession.

**Mitigation**: Engineering Team: Develop an operational sustainability plan including a maintenance schedule, funding/resource strategy, succession planning, and technology roadmap. Due date: 120 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not address zoning, land-use, or structural limits for Île aux Cygnes. The plan assumes the island can support the statue without evidence. There is no fatal-flaw screen with authorities.

**Mitigation**: Engineering Team: Perform a fatal-flaw screen with French authorities regarding zoning, land-use, and structural limits for Île aux Cygnes. Due date: 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not specify redundancy or tested failover for critical vendors, data, or facilities. The plan mentions "Heavy-lift vessel" but lacks a backup plan. The plan does not mention SLAs.

**Mitigation**: Logistics Team: Secure SLAs with key vendors (heavy-lift vessel, cranes) including redundancy and tested failover. Owner: Logistics Team / Deliverable: Vendor SLAs / Date: 90 days


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan assumes alignment between the Finance Department and R&D Team, but their conflicting incentives (short-term budget vs. long-term innovation) are not addressed. This could lead to project misalignment.

**Mitigation**: Project Manager: Facilitate a workshop to create shared OKRs that align both stakeholders on common outcomes, ensuring mutual understanding and commitment. Due date: 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with thresholds for re-planning/stopping. Due date: 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has ≥3 High risks strongly coupled: (1) Regulatory Approval delays cascade into (2) Financial shortfalls, which then trigger (3) Technical compromises that damage the statue. The plan lacks a cross-impact analysis.

**Mitigation**: Risk Management Specialist: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due date: 90 days.