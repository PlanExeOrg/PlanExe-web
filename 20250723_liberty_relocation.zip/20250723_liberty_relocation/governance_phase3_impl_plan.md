### 1. Project Sponsor (CEO) identifies and appoints an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Interim Chair Appointment Confirmation

**Dependencies:**

- Project Initiated
- Project Sponsor Identified

### 2. Interim Chair of the Project Steering Committee drafts the initial Terms of Reference (ToR) for the Project Steering Committee, based on the pre-defined responsibilities.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Interim Chair Appointment Confirmation

### 3. Interim Chair circulates the Draft SteerCo ToR v0.1 to the proposed members (CEO, CFO, CLO, Independent External Advisor, Project Sponsor) for review and feedback.

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Circulation Email
- Feedback from Nominated Members

**Dependencies:**

- Draft SteerCo ToR v0.1
- Proposed Members List Available

### 4. Interim Chair consolidates feedback and finalizes the Project Steering Committee Terms of Reference (ToR).

**Responsible Body/Role:** Interim Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0
- Feedback Summary

**Dependencies:**

- Feedback from Nominated Members

### 5. Project Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Project Sponsor formally confirms the membership of the Project Steering Committee (CEO, CFO, CLO, Independent External Advisor, Project Sponsor).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 7. Chair schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Chair, Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- SteerCo Kick-off Meeting Agenda
- SteerCo Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Membership Confirmation Email

### 8. Project Steering Committee reviews and approves the initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Project Plan

**Dependencies:**

- SteerCo Kick-off Meeting Minutes with Action Items
- Project Plan Draft Available

### 9. Project Manager drafts the initial PMO structure, processes, project management templates, tools, reporting requirements and communication protocols.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft PMO Structure
- Draft PMO Processes
- Draft Project Management Templates and Tools
- Draft Project Reporting Requirements
- Draft Communication Protocols

**Dependencies:**

- Project Initiated
- Project Manager Appointed

### 10. Project Manager recruits and trains PMO staff (Project Coordinator, Risk Manager, Finance Officer, Communications Officer, Technical Leads).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PMO Staff Onboarded
- Training Records

**Dependencies:**

- Draft PMO Structure
- Draft PMO Processes

### 11. Project Manager schedules and holds the initial PMO kick-off meeting & assigns initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- PMO Kick-off Meeting Agenda
- PMO Kick-off Meeting Minutes with Action Items

**Dependencies:**

- PMO Staff Onboarded

### 12. Project Manager defines the scope of technical review and assurance for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Technical Review Scope Document

**Dependencies:**

- PMO Kick-off Meeting Minutes with Action Items

### 13. Project Manager, in consultation with the Project Steering Committee, recruits and onboards independent technical experts for the Technical Advisory Group (Structural Engineer, Corrosion Expert, Transportation Engineer, Materials Scientist, Construction Expert, Historical Preservation Expert).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- TAG Members Onboarded
- TAG Member Contracts

**Dependencies:**

- Technical Review Scope Document
- Approved Project Plan

### 14. Project Manager establishes communication protocols and develops technical review checklists and reporting requirements for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- TAG Communication Protocols
- TAG Technical Review Checklists
- TAG Reporting Requirements

**Dependencies:**

- TAG Members Onboarded

### 15. Project Manager schedules and facilitates the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- TAG Kick-off Meeting Agenda
- TAG Kick-off Meeting Minutes with Action Items

**Dependencies:**

- TAG Communication Protocols
- TAG Technical Review Checklists
- TAG Reporting Requirements

### 16. Chief Legal Officer (CLO) and Compliance Officer develop ethics and compliance policies and procedures for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Legal Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Ethics and Compliance Policies and Procedures

**Dependencies:**

- Project Initiated

### 17. Chief Legal Officer (CLO) establishes reporting mechanisms for ethical concerns and compliance violations.

**Responsible Body/Role:** Chief Legal Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Whistleblower Policy
- Reporting Channels Defined

**Dependencies:**

- Draft Ethics and Compliance Policies and Procedures

### 18. Chief Legal Officer (CLO) recruits and trains committee members for the Ethics & Compliance Committee (Compliance Officer, Ethics Officer, Data Protection Officer, Representative from the Public Relations Team).

**Responsible Body/Role:** Chief Legal Officer

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Members Onboarded
- Training Records

**Dependencies:**

- Whistleblower Policy
- Reporting Channels Defined

### 19. Chief Legal Officer (CLO) defines the scope of compliance review and establishes communication protocols for the Ethics & Compliance Committee.

**Responsible Body/Role:** Chief Legal Officer

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Compliance Review Scope Document
- Ethics & Compliance Committee Communication Protocols

**Dependencies:**

- Ethics & Compliance Committee Members Onboarded

### 20. Chief Legal Officer (CLO) schedules and facilitates the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Chief Legal Officer

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Ethics & Compliance Committee Kick-off Meeting Agenda
- Ethics & Compliance Committee Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Compliance Review Scope Document
- Ethics & Compliance Committee Communication Protocols

### 21. Communications Officer develops a stakeholder engagement plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Plan

**Dependencies:**

- Project Initiated

### 22. Communications Officer identifies key stakeholders and develops communication channels and feedback mechanisms.

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Key Stakeholder List
- Communication Channels Defined
- Feedback Mechanisms Established

**Dependencies:**

- Draft Stakeholder Engagement Plan

### 23. Communications Officer recruits and trains engagement team members for the Stakeholder Engagement Group (Public Relations Specialist, Government Relations Specialist, Community Liaison, Representative from the Legal Team).

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Members Onboarded
- Training Records

**Dependencies:**

- Key Stakeholder List
- Communication Channels Defined
- Feedback Mechanisms Established

### 24. Communications Officer defines reporting requirements for the Stakeholder Engagement Group.

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Reporting Requirements

**Dependencies:**

- Stakeholder Engagement Group Members Onboarded

### 25. Communications Officer schedules and facilitates the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Communications Officer

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Stakeholder Engagement Group Kick-off Meeting Agenda
- Stakeholder Engagement Group Kick-off Meeting Minutes with Action Items

**Dependencies:**

- Stakeholder Engagement Group Reporting Requirements