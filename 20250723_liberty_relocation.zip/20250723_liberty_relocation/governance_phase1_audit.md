
## Audit - Corruption Risks

- Bribery of regulatory officials to expedite permit approvals, potentially overlooking environmental or safety concerns.
- Kickbacks from contractors in exchange for favorable treatment in the bidding process for island expansion or pedestal construction.
- Conflicts of interest involving project team members with undisclosed financial ties to suppliers of materials or transportation services.
- Misuse of confidential project information for personal gain, such as insider trading based on knowledge of land values near the project site.
- Nepotism in the awarding of contracts or employment opportunities, favoring unqualified individuals based on personal relationships rather than merit.

## Audit - Misallocation Risks

- Inflated invoices from contractors or suppliers, with the excess funds diverted for personal use or unauthorized purposes.
- Double-billing for services or materials, with the same expenses claimed multiple times.
- Inefficient allocation of resources, such as overspending on unnecessary features of the island expansion or pedestal design.
- Unauthorized use of project assets, such as using construction equipment for personal projects or diverting materials for private gain.
- Misreporting of project progress or results, concealing delays or cost overruns to maintain the appearance of success.

## Audit - Procedures

- Conduct periodic internal audits of project finances, including a review of all invoices, contracts, and expense reports, at least quarterly.
- Engage an independent external auditor to conduct a comprehensive review of project activities, finances, and compliance with regulations, both during and after project completion.
- Implement a contract review process with multiple levels of approval for all contracts exceeding a specified threshold (e.g., $100,000), ensuring transparency and accountability.
- Establish a detailed expense workflow with clear guidelines for reimbursement and approval, requiring supporting documentation for all expenses.
- Perform regular compliance checks to ensure adherence to all applicable environmental, safety, and regulatory requirements, with documented findings and corrective actions.

## Audit - Transparency Measures

- Create a public project dashboard displaying key progress metrics, budget information, and risk assessments, updated monthly.
- Publish minutes of key project meetings, including those of the project steering committee and regulatory review boards, on a publicly accessible website.
- Establish a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with clear procedures for investigation and resolution.
- Make relevant project policies and reports, such as environmental impact assessments and risk management plans, publicly available online.
- Document and publish the selection criteria and rationale for all major decisions, including vendor selection and design choices, ensuring transparency and accountability.