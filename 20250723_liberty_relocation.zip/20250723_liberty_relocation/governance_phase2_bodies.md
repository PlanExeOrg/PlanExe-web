### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and direction for this high-risk, high-complexity project, ensuring alignment with organizational goals and managing strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic guidance and direction.
- Monitor project progress against strategic objectives.
- Approve major changes to project scope, budget, or timeline (>$10 million USD).
- Oversee strategic risk management and mitigation.
- Resolve high-level conflicts and escalate issues as needed.
- Ensure alignment with organizational strategy and stakeholder expectations.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation procedures.
- Review and approve initial project plan.

**Membership:**

- Chief Executive Officer (CEO)
- Chief Financial Officer (CFO)
- Chief Legal Officer (CLO)
- Independent External Advisor (Infrastructure Project Management)
- Project Sponsor

**Decision Rights:** Strategic decisions related to project scope, budget (>$10 million USD), timeline, and strategic risks.

**Decision Mechanism:** Decisions made by majority vote, with the CEO having the tie-breaking vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Quarterly, or more frequently as needed.

**Typical Agenda Items:**

- Review of project progress against strategic objectives.
- Review of project budget and financial performance.
- Review of strategic risks and mitigation plans.
- Approval of major changes to project scope, budget, or timeline.
- Discussion of stakeholder concerns and communication strategies.
- Review of compliance with regulatory requirements.

**Escalation Path:** Board of Directors
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution of the project, ensuring adherence to project plans, managing operational risks, and providing project support.

**Responsibilities:**

- Develop and maintain project plans, schedules, and budgets.
- Manage day-to-day project execution.
- Monitor project progress and performance.
- Identify and manage operational risks.
- Coordinate project resources and activities.
- Provide project support to team members.
- Report project status to the Project Steering Committee.
- Manage project documentation and communication.

**Initial Setup Actions:**

- Establish PMO structure and processes.
- Develop project management templates and tools.
- Recruit and train PMO staff.
- Define project reporting requirements.
- Establish communication protocols.

**Membership:**

- Project Manager
- Project Coordinator
- Risk Manager
- Finance Officer
- Communications Officer
- Technical Leads (Disassembly, Transportation, Reassembly)

**Decision Rights:** Operational decisions related to project execution, resource allocation, and risk management (below $10 million USD).

**Decision Mechanism:** Decisions made by the Project Manager, in consultation with the PMO team. Escalation to the Project Steering Committee for decisions exceeding their authority.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of project risks and issues.
- Review of project budget and financial performance.
- Coordination of project resources and activities.
- Review of project documentation and communication.
- Action item tracking.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and assurance on key project aspects, ensuring the structural integrity and safety of the Statue of Liberty during relocation.

**Responsibilities:**

- Review and approve technical designs and plans.
- Provide technical guidance and support to the project team.
- Assess the structural integrity of the Statue of Liberty.
- Develop and implement risk mitigation strategies related to technical aspects.
- Oversee the disassembly, transportation, and reassembly processes.
- Ensure compliance with relevant engineering standards and regulations.
- Provide independent technical assurance.

**Initial Setup Actions:**

- Define scope of technical review and assurance.
- Recruit and onboard technical experts.
- Establish communication protocols.
- Develop technical review checklists.
- Define reporting requirements.

**Membership:**

- Structural Engineer (Independent)
- Corrosion Expert (Independent)
- Transportation Engineer
- Materials Scientist
- Construction Expert
- Historical Preservation Expert

**Decision Rights:** Technical approval of designs, plans, and processes related to the structural integrity and safety of the Statue of Liberty.

**Decision Mechanism:** Decisions made by consensus of the Technical Advisory Group. Dissenting opinions are formally recorded and escalated to the Project Steering Committee.

**Meeting Cadence:** Monthly, or more frequently as needed during critical phases.

**Typical Agenda Items:**

- Review of technical designs and plans.
- Assessment of structural integrity.
- Discussion of technical risks and mitigation strategies.
- Review of disassembly, transportation, and reassembly processes.
- Review of compliance with engineering standards and regulations.
- Discussion of technical issues and challenges.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures compliance with ethical standards, relevant regulations (including GDPR), and anti-corruption policies throughout the project lifecycle.

**Responsibilities:**

- Develop and implement an ethics and compliance program.
- Ensure compliance with relevant regulations, including GDPR, environmental regulations, and anti-corruption laws.
- Investigate and resolve ethical concerns and compliance violations.
- Provide training to project team members on ethical standards and compliance requirements.
- Monitor project activities for potential ethical and compliance risks.
- Report compliance status to the Project Steering Committee.
- Oversee the whistleblower mechanism.

**Initial Setup Actions:**

- Develop ethics and compliance policies and procedures.
- Establish reporting mechanisms for ethical concerns and compliance violations.
- Recruit and train committee members.
- Define scope of compliance review.
- Establish communication protocols.

**Membership:**

- Chief Legal Officer (CLO)
- Compliance Officer (Independent)
- Ethics Officer (Independent)
- Data Protection Officer (DPO)
- Representative from the Public Relations Team

**Decision Rights:** Decisions related to ethical conduct, compliance with regulations, and investigation of potential violations.

**Decision Mechanism:** Decisions made by majority vote, with the CLO having the tie-breaking vote. Dissenting opinions are formally recorded.

**Meeting Cadence:** Bi-monthly, or more frequently as needed.

**Typical Agenda Items:**

- Review of ethics and compliance policies and procedures.
- Discussion of potential ethical and compliance risks.
- Review of compliance status with relevant regulations.
- Investigation of ethical concerns and compliance violations.
- Review of whistleblower reports.
- Training on ethical standards and compliance requirements.

**Escalation Path:** Project Steering Committee
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the public, government agencies, and cultural heritage organizations, ensuring transparency and addressing concerns.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Communicate project information to stakeholders.
- Solicit feedback from stakeholders.
- Address stakeholder concerns.
- Manage public relations.
- Coordinate with government agencies and regulatory bodies.
- Engage with cultural heritage organizations.
- Monitor stakeholder sentiment.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop communication channels.
- Establish feedback mechanisms.
- Recruit and train engagement team members.
- Define reporting requirements.

**Membership:**

- Communications Officer
- Public Relations Specialist
- Government Relations Specialist
- Community Liaison
- Representative from the Legal Team

**Decision Rights:** Decisions related to stakeholder communication, engagement strategies, and public relations.

**Decision Mechanism:** Decisions made by the Communications Officer, in consultation with the Stakeholder Engagement Group. Escalation to the Project Steering Committee for decisions with significant strategic implications.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement plan.
- Discussion of stakeholder feedback and concerns.
- Review of public relations activities.
- Coordination with government agencies and regulatory bodies.
- Engagement with cultural heritage organizations.
- Monitoring of stakeholder sentiment.

**Escalation Path:** Project Steering Committee