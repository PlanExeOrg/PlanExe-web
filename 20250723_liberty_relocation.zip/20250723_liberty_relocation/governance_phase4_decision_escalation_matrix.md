**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic oversight.
Negative Consequences: Potential budget overruns and financial instability.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: Requires strategic decision-making and resource allocation beyond the PMO's capacity.
Negative Consequences: Project delays, increased costs, or project failure.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: Requires higher-level arbitration to resolve conflicting priorities or perspectives.
Negative Consequences: Delays in procurement and potential impact on project timeline.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval Based on Impact Assessment
Rationale: Significantly alters project objectives and requires strategic alignment.
Negative Consequences: Scope creep, budget overruns, and misalignment with strategic goals.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and investigation to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Design Dispute within Technical Advisory Group**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews dissenting opinions and makes a final determination, potentially seeking external expert advice.
Rationale: Lack of consensus within the Technical Advisory Group on a critical technical aspect requires resolution at a higher level to avoid project delays or safety risks.
Negative Consequences: Compromised structural integrity, safety hazards, or project delays due to unresolved technical issues.

**Stakeholder Opposition Threatening Project Viability**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee reviews stakeholder engagement strategy and approves revised approach, potentially involving direct negotiations or concessions.
Rationale: Significant stakeholder resistance requires strategic intervention to maintain project support and avoid potential cancellation.
Negative Consequences: Project delays, increased costs due to mitigation efforts, or project cancellation due to insurmountable opposition.