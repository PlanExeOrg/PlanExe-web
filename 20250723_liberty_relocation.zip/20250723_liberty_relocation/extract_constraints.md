## Positive Constraints

- Relocate the Statue of Liberty
- Destination: Île aux Cygnes in Paris, France
- Disassemble into 500 pieces
- Ship from New York Harbor to Le Havre
- Transport up the Seine River
- Reassemble on an expanded island with a new pedestal
- Project start ASAP
