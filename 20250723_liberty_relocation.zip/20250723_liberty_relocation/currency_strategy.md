This plan involves money.

## Currencies

- **USD:** Starting location is in the United States.
- **EUR:** Destination location is in France.

**Primary currency:** USD

**Currency strategy:** USD will be used for consolidated budgeting and reporting. EUR will be used for local transactions in France. Hedging against exchange rate fluctuations between USD and EUR is recommended.