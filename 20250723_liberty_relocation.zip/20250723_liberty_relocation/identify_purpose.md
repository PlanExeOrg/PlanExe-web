**Purpose:** business

**Purpose Detailed:** Infrastructure project involving relocation of a major monument.

**Topic:** Relocation of the Statue of Liberty