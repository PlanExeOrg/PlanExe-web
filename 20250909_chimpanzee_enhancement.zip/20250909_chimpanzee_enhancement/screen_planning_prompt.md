**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a concrete, albeit unethical, project with specific details about budget, timeline, location, and desired outcomes, making it suitable for generating a plan. The prompt provides enough detail to generate a multi-step plan, even though the project is highly unconventional and raises ethical concerns.