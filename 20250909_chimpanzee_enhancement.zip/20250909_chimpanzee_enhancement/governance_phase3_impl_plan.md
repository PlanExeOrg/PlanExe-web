### 1. Project Director drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Plan Approved

### 2. Project Director drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Plan Approved

### 3. Project Director drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Plan Approved

### 4. Project Director drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 5. Project Director drafts initial Terms of Reference for the Security Oversight Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Security Oversight Committee ToR v0.1

**Dependencies:**

- Project Plan Approved

### 6. Circulate Draft SteerCo ToR for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft PMO ToR for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft TAG ToR for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Nominated Members List Available

### 9. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 10. Circulate Draft Security Oversight Committee ToR for review by nominated members.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Security Oversight Committee ToR v0.1
- Nominated Members List Available

### 11. Project Director finalizes Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 12. Project Director finalizes Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft PMO ToR v0.1

### 13. Project Director finalizes Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft TAG ToR v0.1

### 14. Project Director finalizes Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.1

### 15. Project Director finalizes Terms of Reference for the Security Oversight Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Security Oversight Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Security Oversight Committee ToR v0.1

### 16. Senior Representative from Funding Source formally appoints Steering Committee Chair.

**Responsible Body/Role:** Senior Representative from Funding Source

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 17. Project Director formally appoints Project Manager.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final PMO ToR v1.0

### 18. Chief Scientist formally appoints Lead Geneticist and Lead Neuroscientist.

**Responsible Body/Role:** Chief Scientist

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final TAG ToR v1.0

### 19. Project Director formally appoints Independent Ethicist (Chair) of the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 20. Head of Security formally appoints Cybersecurity Expert, Physical Security Specialist, and Counterintelligence Officer.

**Responsible Body/Role:** Head of Security

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Security Oversight Committee ToR v1.0

### 21. Hold initial Project Steering Committee Kick-off Meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 22. Hold initial Project Management Office (PMO) Kick-off Meeting & assign initial tasks.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Final PMO ToR v1.0

### 23. Hold initial Technical Advisory Group Kick-off Meeting.

**Responsible Body/Role:** Lead Geneticist

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final TAG ToR v1.0

### 24. Hold initial Ethics & Compliance Committee Kick-off Meeting.

**Responsible Body/Role:** Independent Ethicist (Chair)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email
- Final Ethics & Compliance Committee ToR v1.0

### 25. Hold initial Security Oversight Committee Kick-off Meeting.

**Responsible Body/Role:** Head of Security

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails
- Final Security Oversight Committee ToR v1.0

### 26. The Project Steering Committee reviews and approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Project Budget

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Project Plan Draft
- Initial Project Budget Draft

### 27. The Project Management Office (PMO) develops and maintains project plans, schedules, and budgets.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Ongoing

**Key Outputs/Deliverables:**

- Updated Project Plans
- Updated Project Schedules
- Updated Project Budgets

**Dependencies:**

- Approved Project Plan
- Approved Project Budget

### 28. The Technical Advisory Group reviews and approves research protocols and experimental designs.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Ongoing

**Key Outputs/Deliverables:**

- Approved Research Protocols
- Approved Experimental Designs

**Dependencies:**

- Meeting Minutes with Action Items

### 29. The Ethics & Compliance Committee reviews and approves research protocols from an ethical perspective and monitors the welfare of the chimpanzees.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Ongoing

**Key Outputs/Deliverables:**

- Approved Research Protocols (Ethically)
- Chimpanzee Welfare Reports

**Dependencies:**

- Meeting Minutes with Action Items

### 30. The Security Oversight Committee develops and maintains comprehensive security protocols for the project.

**Responsible Body/Role:** Security Oversight Committee

**Suggested Timeframe:** Ongoing

**Key Outputs/Deliverables:**

- Updated Security Protocols

**Dependencies:**

- Meeting Minutes with Action Items