This plan involves money.

## Currencies

- **SGD:** Singapore is the primary location mentioned in the plan.
- **USD:** A stable international currency for budgeting and reporting, especially given the project's scale and potential for unforeseen expenses.

**Primary currency:** USD

**Currency strategy:** Given the project's scale and clandestine nature, USD is recommended for budgeting and reporting to mitigate risks. SGD may be used for local transactions within Singapore. Hedging strategies may be necessary to manage exchange rate fluctuations between USD and SGD.