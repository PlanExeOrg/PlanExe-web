Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 18 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 1 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not inherently violate any laws of physics. The project involves genetic modification and neural implants, which are within the realm of possibility, even if ethically questionable. No perpetual motion or faster-than-light travel is proposed.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines novel elements (product + market + tech/process + policy) without independent evidence at comparable scale. There is no precedent for creating ultra-intelligent chimpanzees for strategic intelligence gathering, lacking empirical/engineering validity and legal/compliance clearance.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Authoritative Source / +90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the strategic concepts driving the plan. The plan mentions 'strategic intelligence gathering' but lacks a clear explanation of how this translates to customer value or measurable outcomes.

**Mitigation**: Strategy Team: Develop one-pagers for each strategic concept (e.g., 'strategic intelligence gathering') outlining the mechanism-of-action, value hypothesis, success metrics, and decision hooks. Due: +60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (ethical) is minimized. The plan acknowledges ethical concerns but lacks robust mitigation, relying on internal oversight. There is no explicit analysis of cascades involving ethical breaches leading to reputational/financial damage.

**Mitigation**: Ethics Team: Expand the risk register to include ethical hazards, map potential cascades (e.g., ethical breach → public outcry → funding withdrawal), and add controls with a quarterly review. Due: +90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions securing necessary (illegal) permits but lacks a detailed timeline or assessment of feasibility. The plan assumes that the project can operate outside Singaporean law.

**Mitigation**: Legal Team: Develop a permit/approval matrix, including typical lead times in Singapore, and assess the feasibility of obtaining necessary approvals (legal or illegal). Due: +60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not include a funding plan or runway calculation. The plan mentions a '$1 billion' budget but does not specify the sources of funding, draw schedule, or any financing gates/covenants. Without this information, runway integrity cannot be assessed.

**Mitigation**: Finance Team: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO-GO on missed financing gates. Due: +30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with scale-appropriate benchmarks. The plan states a '$1 billion' budget for a 10-year project, but lacks per-area cost normalization or vendor quotes to substantiate the figure.

**Mitigation**: Finance Team: Benchmark (≥3), obtain quotes, normalize per-area, and adjust budget or de-scope by a set date. Due: +90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., budget, timeline) as single numbers without providing a range or discussing alternative scenarios. For example, the goal statement mentions a '$1 billion black-ops program' without any sensitivity analysis.

**Mitigation**: Project Management: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the total budget and timeline. Due: +60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions CRISPR-Cas9, neural implants, and BSL-4 facilities, but lacks technical specifications, interface definitions, test plans, or an integration map.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for CRISPR-Cas9, neural implants, and BSL-4 facilities. Due: +90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, the plan states the goal is to 'forcibly elevate chimpanzee intelligence beyond human levels' but lacks evidence of feasibility or prior success.

**Mitigation**: R&D Team: Produce a feasibility study, including literature review and preliminary experimental design, to support the claim of elevating chimpanzee intelligence beyond human levels. Due: +90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the abstract deliverable 'a new breed of strategic asset' is mentioned without specific, verifiable qualities. The plan lacks SMART acceptance criteria for this deliverable.

**Mitigation**: Project Management: Define SMART criteria for the 'new breed of strategic asset,' including a KPI for intelligence gathering effectiveness (e.g., 20% more effective than existing methods). Due: +30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes a 'remote-activated kill switch' which adds significant ethical complexity without clear justification. The core project goals are strategic intelligence gathering and technological breakthroughs in cognitive enhancement.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the kill switch, complete with a KPI, owner, and estimated cost, or else move the feature to the project backlog. Due: +30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Neural Implant Specialist' role is essential for cognitive enhancement and data extraction, requiring specialized skills and constant availability. The plan lacks evidence validating the talent market for this role.

**Mitigation**: HR Team: Conduct a talent market analysis for Neural Implant Specialists, assessing availability, salary expectations, and required expertise. Due: +60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions securing necessary (illegal) permits but lacks a detailed timeline or assessment of feasibility. The plan assumes that the project can operate outside Singaporean law.

**Mitigation**: Legal Team: Develop a permit/approval matrix, including typical lead times in Singapore, and assess the feasibility of obtaining necessary approvals (legal or illegal). Due: +60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a dedicated lever focusing on long-term resource sustainability. The plan mentions a 10-year timeline and a $1 billion budget, but it does not address the ongoing operational costs beyond this period.

**Mitigation**: Project Management: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Due: +90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits critical zoning, occupancy, and permit details. The plan mentions acquiring land and constructing a BSL-4 bunker but lacks evidence of zoning compliance, occupancy limits, or fire load assessments. Success hinges on unlikely approvals.

**Mitigation**: Real Estate Team: Perform a fatal-flaw screen with Singaporean authorities/experts regarding zoning, occupancy, and permits. Define fallback sites and NO-GO thresholds. Deliverable: Written summary within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions a 'Bunker Redundancy Strategy' but only considers constructing additional bunkers or mobile research units. There is no mention of SLAs with external vendors for critical services like power, water, or data.

**Mitigation**: Operations Team: Secure SLAs with secondary vendors for power, water, and data, including tested failover procedures and timelines. Due: +90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Finance Department is incentivized by budget adherence, while the R&D Team is incentivized by breakthrough results, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Executive Team: Create a shared OKR that aligns Finance and R&D on a common outcome, such as 'achieve X% cognitive enhancement within budget Y by date Z'. Due: +30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. There are no KPIs, review cadence, owners, or a change-control process. Vague 'we will monitor' is insufficient. The plan lacks a mechanism for tracking progress.

**Mitigation**: Project Management: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Lead. Deliverable: Schedule and process within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because ≥3 High risks are strongly coupled. Security breaches (Risk 2), ethical violations (Risk 3), and subject compliance (Risk 12) are tightly linked. A security breach could expose ethical violations, leading to subject resistance.

**Mitigation**: Risk Management: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Due: +90 days.