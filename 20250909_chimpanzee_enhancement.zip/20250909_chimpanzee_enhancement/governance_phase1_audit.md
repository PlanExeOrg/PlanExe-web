
## Audit - Corruption Risks

- Bribery of Singaporean officials to secure the remote enclave and maintain operational secrecy.
- Kickbacks from suppliers of BSL-4 equipment, chimpanzee feed, or security infrastructure in exchange for inflated contracts.
- Nepotism or favoritism in hiring geneticists, neuroscientists, or security personnel, potentially compromising project quality and security.
- Conflicts of interest involving project personnel with undisclosed financial ties to suppliers or competing research institutions.
- Misuse of classified project information for personal gain, such as insider trading or leaking sensitive data to external parties.

## Audit - Misallocation Risks

- Diversion of project funds for personal use by project managers or personnel, disguised as research expenses or operational costs.
- Double-billing or fraudulent invoicing by suppliers of equipment, materials, or services.
- Inefficient allocation of resources to less critical areas, such as excessive spending on security infrastructure at the expense of research and development.
- Unauthorized use of project assets, such as BSL-4 laboratory equipment or chimpanzees, for personal research or commercial purposes.
- Misreporting of project progress or results to justify continued funding or conceal failures, leading to further misallocation of resources.

## Audit - Procedures

- Conduct periodic internal audits of financial records and expense reports to detect irregularities or fraudulent activities (quarterly, internal audit team).
- Implement a whistle-blower mechanism with guaranteed anonymity to encourage reporting of suspected corruption or misallocation (ongoing, external legal counsel).
- Establish contract review thresholds requiring independent legal and financial review for all contracts exceeding a specified value (e.g., $100,000) (before contract signing, legal/finance department).
- Implement strict expense approval workflows with multiple levels of authorization and supporting documentation requirements (for all expenses, finance department).
- Conduct regular compliance checks to ensure adherence to security protocols and ethical guidelines, including unannounced inspections of the BSL-4 bunker (monthly, internal security team).

## Audit - Transparency Measures

- Establish a secure, compartmentalized project dashboard displaying key performance indicators (KPIs) related to budget, timeline, and research progress, accessible only to authorized personnel (real-time, project management office).
- Publish sanitized minutes of key project meetings (e.g., scientific review board, security committee) to promote accountability and transparency within the project team (monthly, project management office).
- Implement a documented selection criteria and justification process for all major decisions, including vendor selection, research priorities, and personnel appointments (before decision, project management office).
- Establish a clear and accessible policy outlining ethical guidelines and conflict-of-interest procedures for all project personnel (upon onboarding, HR department).
- Maintain a comprehensive record of all research data, experimental protocols, and ethical review board decisions, accessible to authorized auditors and oversight bodies (ongoing, research team).