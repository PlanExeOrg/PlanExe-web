**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's approved financial limit of $1 million, requiring strategic review and approval at a higher level.
Negative Consequences: Potential budget overrun and project delays if not addressed promptly.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Strategy
Rationale: Materialization of a critical risk (e.g., security breach, ethical violation) requires strategic reassessment and resource allocation beyond the PMO's authority.
Negative Consequences: Project termination, reputational damage, legal repercussions, threats, loss of funding.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Director
Approval Process: Project Director's Final Decision
Rationale: Inability of the PMO to reach a consensus on a key operational decision necessitates intervention by the Project Director to ensure timely progress.
Negative Consequences: Project delays and potential cost increases due to unresolved vendor selection.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant alterations to the project's scope require strategic evaluation and approval by the Steering Committee due to potential impacts on budget, timeline, and objectives.
Negative Consequences: Misalignment with strategic objectives, budget overruns, and project delays.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics & Compliance Committee Investigation & Recommendation
Rationale: Allegations of ethical misconduct or violations of animal welfare standards necessitate independent review and investigation by the Ethics & Compliance Committee.
Negative Consequences: Reputational damage, legal challenges, loss of funding, and potential harm to subjects.

**Technical Advisory Group Deadlock on Research Protocol**
Escalation Level: Chief Scientist
Approval Process: Chief Scientist's Final Decision, considering Bioethics Representative's input
Rationale: Inability of the Technical Advisory Group to reach a consensus on a research protocol necessitates intervention by the Chief Scientist to ensure timely progress, with consideration of ethical implications.
Negative Consequences: Project delays and potential compromise of research integrity.