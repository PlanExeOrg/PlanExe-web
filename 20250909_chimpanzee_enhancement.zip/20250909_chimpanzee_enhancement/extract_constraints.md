## Positive Constraints

- 10-year program
- Budget: $1 billion
- Elevate chimpanzee intelligence beyond human levels
- Use invasive genetic modifications
- Use neural implants
- Fortified underground BSL-4 bunker
- Remote Singaporean enclave
- Use CRISPR-Cas9 edits
- Constant surveillance interfaces
- Replicable protocol for mass production
- Remote-activated kill-switch
- Deploy at least 10 ultra-intelligent chimpanzees by Year 10
- Project start ASAP
