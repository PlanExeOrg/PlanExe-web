## Domain of the expert reviewer
Biotechnology Project Management and Risk Assessment

## Domain-specific considerations

- Regulatory compliance for germline editing in South Korea
- Longitudinal biological stability (20-year constraint)
- Financial control over a high-cost, high-novelty technology stack (CRISPR/Prime)
- Ethical and public perception management of neuro-pathway targeting
- Complex IP structuring in an international joint venture

## Issue 1 - Critical Missing Assumption: Regulatory Pathway for Direct Neuro-Pathway Interventions
The plan aggressively selects the 'Pioneer' route, including 'Implement direct, high-expression transcription factor overexpression targeting the primary neural pathways responsible for oxytocin signaling magnitude in human observers' (Decision 4). The provided assumptions explicitly note that *no formal, high-level regulatory discussions* have occurred regarding this highly controversial intervention (Assumption 4 Assessment). Regulatory bodies, especially in sensitive jurisdictions, treat engineered alterations of human neurochemical response triggers with extreme scrutiny, likely mandating levels of preclinical toxicology and ethical review far exceeding standard animal husbandry protocols (IACUC).

**Recommendation:** Immediately halt any explicit planning for *in vivo* human testing until a comprehensive Regulatory Impact Assessment (RIA) is completed by specialized bioethics counsel in conjunction with the South Korean MFDS expectations *for this specific intervention type*. Develop a mandatory phased fallback: If direct pathway intervention yields a regulatory halt in Year 2, the project must pivot immediately to the 'Cognitive Cue Optimization' pathway (Decision 4, Strategic Choice 2, which requires less regulatory heat).

**Sensitivity:** A delay in obtaining the necessary regulatory go-ahead for the neuro-pathway trial (baseline: Q4 Year 2) could introduce a 12-24 month regulatory hold. This delay, compounded by associated sustainment costs ($15M noted in Risk 3), would reduce the overall project ROI by an estimated 25%-45% compared to the baseline expectation derived from the $100M budget and projected commercial timeline, assuming the pivot (Decision 4 fallback) is successful.

## Issue 2 - Critical Missing Assumption: Quantification of 20-Year Longevity Maintenance Cost Structure
The success hinges on a 20-year lifespan maintenance constraint (Decision 3), with a dedicated $5M contingency for *pathology* (Assumption 5). However, there is no assumption detailing the operational budget breakdown required to *sustain* 10+ healthy, specially housed dogs for 20 years post-initial editing success. Standard canine care costs are inadequate (Risk 5 noted a 150% increase over projections). The financial model must account for 20 years of highly specialized care, feed, veterinary services, and longitudinal biomarker monitoring (Assumption 8 notes a $500K/year DLM cost, but not equivalent husbandry costs). This omission threatens the long-term financial viability long after the initial $100M is spent.

**Recommendation:** Establish a mandatory post-development funding mechanism *now*. Calculate the projected 20-year housing/husbandry cost for the expected number of successful carrier lines (e.g., 5 lines). If this exceeds $10M, secure an external endowment or structure a mechanism within the Joint Venture (Decision 2) to cover these costs, perhaps by securing an early license fee linked specifically to long-term animal liabilities, protecting the initial $100M investment from becoming a liability sinkhole.

**Sensitivity:** If total 20-year projected husbandry costs (excluding the $500K data budget) are conservatively estimated at $4M per animal line, and 5 lines are successful, baseline costs for longevity management post-initial R&D phase could reach $20M. A failure to secure this funding stream will devalue the final product by $20M (20% of the initial budget value) as the owners would bear crippling operational liability.

## Issue 3 - Under-Explored Assumption: IP/JV Structure Conflict with Technical Velocity
The plan chooses the 'Pioneer' path, which entails developing a *custom RNP delivery system* (Decision 1) and structuring the IP as a *Joint Venture granting 90% IP rights* contingent on timely delivery (Decision 2). The assumption allocates $15M for IP negotiation (Assumption 1). The conflict is that developing proprietary RNP tools (high engineering cost) while simultaneously giving away 90% of downstream commercial rights creates a massive financial disconnect. The investment (time, technical resource drain, component cost) required to build a novel toolset is not adequately recouped if 90% of the resulting commercial value immediately flows externally.

**Recommendation:** Re-negotiate Decision 2 structure concerning proprietary tooling. If the external entity utilizes the custom RNP system (Decision 1 achievement), IP vesting must be weighted: 90% rights contingent on timely delivery, but ownership of the *background IP developed within this project* (i.e., the custom RNP system itself) should vest 50/50 or be licensed back to the primary developer for a fixed fee. If the RNP system fails and the backup vector is used, the 90% vesting remains acceptable as less proprietary investment was made.

**Sensitivity:** If the high-cost, custom RNP system is successful (leading to the projected timeline boost), but the 90% IP split remains, the net ROI realized by the primary funding organization could drop from a projected 500% (baseline) to approximately 50%-100% due to limited downstream revenue capture on a highly valuable asset.

## Review conclusion
This 'Pioneer' project is technically ambitious, validated by high-risk choices like custom RNP development and direct neuro-pathway targeting. The review identified three critical weaknesses centered on unsupported operationalization: 1) The unaddressed, high-stakes regulatory pathway for human neuro-pathway manipulation; 2) The lack of a cost model for the 20-year operational sustainment post-R&D; and 3) A major financial misalignment where high investment in proprietary tools is paired with near-total cession of future IP rights. Immediate action must focus on securing a regulatory fallback, defining the 20-year liability budget, and rebalancing the IP agreement to ensure the massive R&D expenditure yields commensurate financial return.