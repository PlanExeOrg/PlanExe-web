## Domain of the expert reviewer
Risk Management and Strategic Planning in High-Complexity Biotechnology R&D

## Domain-specific considerations

- Bioethics and Regulatory Compliance for Germline Editing
- Supply Chain Volatility for Specialized Reagents (Prime Editing)
- Longitudinal Data Integrity for 20-Year Asset Lifespan
- Geopolitical Concentration Risk for Core IP and Assets

## Issue 1 - Missing Assumption: Regulatory Approval Timelines and Contingency Funding for Iterative Editing
The plan assumes successful adherence to local KR regulations and targets confidential non-governmental pre-approval by EOY 2027. It lacks an explicit assumption regarding the *timeline* required by official governmental bodies (e.g., S. Korean Veterinary/Bioethics Boards) for *actual operational licensing* necessary for embryo implantation and rearing. The assumed budget split (30% infrastructure/reagents) is highly optimistic for advanced Prime Editing trials, leaving the buffer vulnerable if validation takes longer; Risk 3 highlights this financial strain.

**Recommendation:** Assume a minimum of 9-15 months of administrative delay post-technical validation for final governmental permissions required to start implantation. The budget allocation assumption must be stress-tested: Cap Prime Editing reagent spending at 65% of the allocated 30% until the *government* operational license is secured. If the license is delayed beyond the assumed 15-month window, immediately reallocate 15% of the personnel budget (40% allocation) to extend the expatriate validation team contract for 6 extra months to maintain data integrity, preventing a hard stop.

**Sensitivity:** If governmental licensing introduces an 18-month delay (baseline assumed 9 months total admin time), the project completion date shifts by 9 months. This requires an additional $7.5M - $12.5M USD to sustain contracted personnel/infrastructure past the initial funding horizon, leading to an estimated 8-12% reduction in final projected ROI due to delayed market entry.

## Issue 2 - Missing Assumption: Endocrine Stability Threshold Beyond Juvenile Phenotype
The plan assumes an endocrine deceleration switch can maintain a 4-month-old phenotype for 20 years (Decision 5) based on a Year 2 safety trigger (telomerase/senescence). Critically missing is the assumption about *metabolic load* required to sustain this engineered state. Maintaining perpetual juvenility will place immense, unmodeled stress on major organ systems (cardiovascular, renal) far beyond predictable oncological risks.

**Recommendation:** Introduce a formalized, medium-term operational assumption: Successful maintenance of the juvenile metabolic rate beyond Year 5 is contingent on *zero* required intervention into cardiovascular or renal health pathways. If any renal/cardiac abnormality requiring intervention is detected between Years 3 and 5, immediately deprioritize aggressive aesthetic/neurochemical refinement (Decisions 2 & 9) and allocate 20% of the 30% validation budget toward retrofitting metabolic governance pathways, accepting a compromise on the 'puppy energy' level.

**Sensitivity:** If metabolic failure necessitates retrofitting metabolic governance between Years 3-5, the time required for this secondary complex editing cycle will stall progress on market-facing traits (aesthetics/neurochemistry) by 6-9 months. This directly impacts the perceived novelty and marketing hook, potentially reducing projected Year 2 revenue by 25-35% compared to the target expectation.

## Issue 3 - Under-Explored Assumption: Intellectual Property (IP) Ownership Transfer Mechanism
The IP strategy (Decision 10) is aggressive, aiming for maximal patent granularity, and relies on a secondary, non-primary jurisdiction facility (Location 3). However, there is no explicit assumption or mechanism detailed for *how* the core genetic constructs developed *at* Sooam (using their infra/personnel) are legally and technically transferred to the project owner's control (Location 3) without triggering substantial mandatory profit-sharing or licensing fees dictated by South Korean IP law or Sooam's initial contract terms.

**Recommendation:** Immediately contract specialized international IP law counsel to develop a 'Step-In Acquisition Clause' for the primary contract with Sooam. Assume that achieving 100% IP ownership transfer requires a fixed buy-out fee equivalent to 15% of the projected Year 1 net revenue, or a minimum of $5M USD, whichever is greater. This cost must be pre-allocated within the 30% validation budget or explicitly secured via a financing commitment.

**Sensitivity:** If the transfer requires a negotiated fee exceeding the assumed $5M, the project faces a 5-10% ROI hit immediately post-launch due to early capital outflow. More critically, without a guaranteed clear transfer mechanism, Risk 5 (Geopolitical Risk) materializes into unmitigated legal blockage, rendering the entire R&D investment non-monetizable, resulting in 100% loss of potential profit.

## Review conclusion
The project's technical ambition, driven by the 'Pioneer' strategy, introduces critical planning gaps related to regulatory administration, long-term metabolic viability, and IP commercial control. The greatest threats are not purely scientific feasibility, but the *administrative overhead* and *long-term systemic stability* not explicitly covered by current assumptions. Priority must be given to securing binding, pre-defined timelines and costs for governmental approval, engineering metabolic redundancy beyond oncological risk, and formalizing the IP exit strategy to de-risk the reliance on the single operational hub in Seoul.