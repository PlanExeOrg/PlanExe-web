This plan implies one or more physical locations.

## Requirements for physical locations

- Access to cutting-edge CRISPR-Cas9/Prime Editing laboratory facilities
- Expertise in large-scale canine genetic modification and cloning
- Ability to construct secure, specialized animal husbandry units for long-term maintenance (20+ years)
- Proximity to international scientific personnel (for expatriate team collaboration)

## Location 1
South Korea

Seoul

Sooam Biotech Research Foundation

**Rationale**: This is the explicitly designated primary research site. It is recommended due to its established infrastructure, proven expertise in somatic cell nuclear transfer and large-scale canine research, which is critical for leveraging Decision 4 and Decision 15.

## Location 2
USA

Boston/Cambridge, Massachusetts

A specialized, high-security bio-containment lab near major biotechnology hubs

**Rationale**: Suggested as the anticipated location for the 'rapid-response expatriate team' (Decision 4) to co-locate. This area provides necessary Western standards for cross-validation and access to advanced reagent supply chains supporting Prime Editing (Decision 1).

## Location 3
Singapore or Switzerland

Biotech Research Park

Neutral jurisdiction research park with strong IP enforcement

**Rationale**: A secondary, geographically diverse site (as suggested by Decision 15, Strategy 3) for establishing internal IP control over subsequent generations, mitigating geopolitical concentration risk associated with the primary site.

## Location Summary
The primary operational location is confirmed as the Sooam Biotech Research Foundation in Seoul, South Korea, leveraging their genetic expertise. Two additional suggestions focus on establishing operational hubs for the expatriate validation team (Boston/Cambridge) and securing centralized IP ownership outside the primary jurisdiction (Singapore/Switzerland).