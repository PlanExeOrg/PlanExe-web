# Purpose
# Project Plan: Emotionally Responsive Genome Modification in Dogs

## Purpose

- Business
- Large-scale biological engineering project.
- Investment for research/commercialization in a biotech/research institution.
- Goal: Novel outcome.

## Topic

- Genome modification of a dog for maximal human emotional response


# Plan Type
# Physical Requirements

- Requires one or more physical locations. Cannot be executed digitally.
- Complex, large-scale biological engineering project (CRISPR-Cas9, Prime Editing genetic modification of a dog).
- Absolutely requires a physical laboratory, specialized equipment, biological materials, and physical presence at Sooam Biotech Research Foundation, Seoul.
- Execution depends entirely on specialized physical facilities and manipulation of biological samples.


# Physical Locations
# Requirements for physical locations

- Access to advanced molecular biology/CRISPR/Prime Editing lab facilities
- Institutional partnership with established veterinary/canine genetics research capabilities
- Compliance with South Korean regulatory bodies for advanced genetic engineering

## Location 1

- South Korea, Seoul
- Sooam Biotech Research Foundation
- Rationale: Required research institution for genomic modifications (CRISPR-Cas9/Prime Editing).

## Location 2

- South Korea, Seoul Metropolitan Area
- Proximity to specialized canine research/veterinary hospitals
- Rationale: Required for long-term behavioral validation (20 years) and housing of canine subjects, needing close veterinary support.

## Location 3

- Global (e.g., Boston, San Francisco Bay Area, Singapore)
- International Biotech Hubs
- IP/Regulatory Consulting Offices
- Rationale: Recommended secondary administrative/legal presence to manage international IP claims and commercialization outside South Korea (Critical Decisions 2 & 7).

## Location Summary
Primary location: Sooam Biotech Research Foundation, Seoul, South Korea (for genetic engineering). Secondary locations needed: Proximity to specialized canine care in Seoul (for 20-year validation) and a major international biotech hub (for IP/global compliance).

# Currency Strategy
## Currencies

- KRW: Local operational expenses, labor, services in Seoul.
- USD: Project budget ($100M), international procurement, IP licensing fees, risk mitigation.

Primary currency: USD

Currency strategy:

- USD: Primary for budgeting, reporting, major international procurement ($100M budget, high-risk research).
- KRW: Localized operational spending in Seoul.
- Reporting: Maintain USD parity to stabilize valuation.


# Identify Risks
## Risk 1 - Technical/Genomics
Failure of custom RNP delivery system (Pioneer strategy) to achieve high on-target efficiency in canine zygotes.

- Impact: Efficiency < 10% requires 5-10x breeding cohorts; budget overrun > $30M USD or 12-month delay pending new delivery method.
- Likelihood: High
- Severity: High
- Action: Initiate parallel validation for off-the-shelf viral vectors. Define minimum viable editing efficiency (e.g., 20%) by Month 6, triggering pivot to backup vector system.

## Risk 2 - Technical/Longevity
Aggressive manipulation of telomerase/GH pathways for 20-year constraint causes unforeseen pathology (oncogenesis, metabolic dysregulation).

- Impact: Complete project failure; sunk cost $\sim$ $50M USD if pathology manifests late (Year 5+).
- Likelihood: Medium
- Severity: High
- Action: Implement stringent, parallel biomarker monitoring (Decision 5 alignment) for senescence/proliferation markers from utero. Allocate $5M USD for specialized pathology consultation (oncology/endocrinology) from Year 1.

## Risk 3 - Regulatory & Permitting
Neuro-pathway engineering for oxytocin release (Decision 4) triggers opposition or moratorium from South Korean authorities (MFDS).

- Impact: Full operational shutdown in Seoul for 18-36 months pending review; $15M USD fixed sustainment costs.
- Likelihood: High
- Severity: High
- Action: Fund dual legal/regulatory tracks. Proceed in Seoul under strictest exemption while securing preliminary, confidential regulatory assessments in a globally accepted jurisdiction (US/EU) regarding the *methodology*.

## Risk 4 - Financial/Budget Overrun
High-IP-share joint venture (Decision 2) and proprietary tooling (Decision 4) deplete reserves needed for carriers and personnel retention.

- Impact: Projected $10M-$20M USD shortfall in Year 3 without perfect milestones. Loss of validated lines if carrier upkeep fails.
- Likelihood: High
- Severity: Medium
- Action: Tie 30% of IP Joint Venture equity vesting to successful operational funding status at monthly intervals in Year 2/3. Pursue targeted pre-seed funding based on initial germline success.

## Risk 5 - Operational/Animal Husbandry
Complexity of maintaining 'acts like a 4-month-old puppy' phenotype for 20 years strains budget for specialized behavioral enrichment/housing.

- Impact: Operational costs 150% over standard projections; potential extra $50,000 USD per animal per year post-juvenile phase.
- Likelihood: Medium
- Severity: Medium
- Action: Develop scientifically verifiable, less resource-intensive proxy for the 20-year juvenile state (Decision 8). Cap maximum long-term housing units based on remaining $100M margin after Year 5.

## Risk 6 - Technical/Aesthetics & Emotion Conflict
Novel aesthetic targets ('seal pup,' 'cartoon' - Decision 9) disrupt sensory organs needed for maximal human oxytocin/dopamine release.

- Impact: Fails primary commercial value proposition ('beautiful failure'); 100% loss of market potential.
- Likelihood: Medium
- Severity: High
- Action: Mandate early, qualitative human-animal interaction trials concurrent with aesthetic editing (Decision 6 alignment). If emotional response score (Decision 5 Metric) drops below 75% baseline with high aesthetic deviation, halt aesthetic layering to stabilize core genes.

## Risk 7 - Supply Chain
Cost volatility or unavailability of proprietary, cutting-edge RNP/Prime Editing components (Decision 10) from niche suppliers.

- Impact: Project continuity stops for 2-3 months or requires unplanned $1M-$3M USD expenditure.
- Likelihood: Medium
- Severity: Medium
- Action: Secure 18 months of critical reagent buffer stock by Year 1 Q2. Lock in pricing structures for recurring consumables using the USD budget portion.

## Risk 8 - Social/Ethical Concerns
Intense public backlash against engineered organism leads to non-regulatory operational interference (protests) at the Seoul site.

- Impact: Reputational damage halting investor confidence; potential site closure (1-4 weeks).
- Likelihood: Medium
- Severity: Medium
- Action: Develop proactive, transparent communications strategy highlighting scientific rigor and therapeutic benefit, leveraging Sooam expertise. Prepare crisis communication plan focused on 'responsible evolution.'

## Risk summary
This project is a 'Pioneer' moonshot with aggressive targets (20-year longevity, maximal emotional engineering) relying on high-risk choices (custom RNP, neuro-pathway targeting). The three most critical risks (High/High) threaten core objectives:
1. Technical Failure of Custom Editing System: Reliance on proprietary tooling threatens efficacy; risks $30M+ overrun.
2. Regulatory Blockade on Emotional Engineering: Direct neuro-pathway manipulation risks operational shutdown in Seoul.
3. Longevity Pathology: Aggressive epigenetic strategy might cause inherent disease, voiding the 20-year proposition.
Mitigation requires immediate parallel planning (backup editing tools, dual regulatory tracks) despite short-term strain on the $100M budget to safeguard long-term viability against catastrophic failure.

# Make Assumptions
## Question 1 - IP Establishment Costs (Sooam Biotech)

- Budget: $100M USD.
- Planned allocation for upfront IP costs (JV structuring, licensing fees): 15% ($15M USD) over 12 months.
- Assessment Details: $15M is appropriate for high-leverage JV but strains the operating buffer for reagent costs (Risk 7).
- Recommendation: Negotiate milestone payments tied to genetic stability (Decision 4) instead of fixed upfront cash to smooth Year 1 cash flow.

## Question 2 - Target Date for First Successful Germline Modification (Custom RNP)

- Start Date: 2026-Apr-28.
- Target Date (Month 8): December 31, 2026 (Validated, stable germline insertion).
- Assessment Details: 8-month timeline is highly aggressive (Time Constraint Risk).
- Consequence: Failure beyond Month 10 requires shifting to backup viral vector system, impacting Longevity Constraint edits (Decision 3).

## Question 3 - FTE Allocation for Custom RNP Development vs. Behavioral Validation (Year 1)

- Allocation Split: 60/40 (Pioneer strategy).
- RNP Development (Decision 1): 60% (e.g., 12 FTEs) for engineering/delivery optimization.
- Behavioral Validation (Decision 8): 40% (e.g., 8 FTEs) for Long-Term Behavioral Validation support.
- Risk: Personnel burnout/skill gaps combining exotic aesthetics (Decision 9) and neurochemistry monitoring.

## Question 4 - Preliminary Regulatory Discussions for Direct Neuro-Pathway Targeting (Decision 4)

- Status: No formal high-level regulatory discussions yet.
- Initial Step: Structuring internal review to align research with South Korean bio-ethics counsel by Month 3.
- Risk: Risk 3 severity is critically high due to novelty (potential shift to therapeutic human application areas).
- Opportunity: Frame initial testing on objective markers (cortisol/oxytocin - Decision 5) to navigate governance.

## Question 5 - Dedicated Contingency Budget for Oncogenesis/Metabolic Disorder (Risk 2)

- Dedicated Contingency Budget: $5M USD (5% of total budget).
- Purpose: Specialist pathological consultation, advanced longitudinal monitoring hardware, and rapid response intervention trials (Decision 3 constraints).
- Benefit: Mitigates sunk cost potential ($50M loss projected by Risk 2) and allows refinement of Prime Editing targets.

## Question 6 - Quantifiable Non-Mammalian Biological Markers for 'Chinchilla Feel'

- Target Metrics: Maintain specific dermal surface roughness and hair/fur density profile. Aim for 90% match to control chinchilla samples via fractal dimension analysis.
- Risk Impact: If complexity necessitates non-standard nutrient inputs or specialized climate control beyond standard canine care (Risk 5), operational costs escalate due to specialized housing.

## Question 7 - Milestones for Secondary IP/Regulatory Office (Location 3 - Decision 7)

- Milestone Date: Year 1, Q3.
- Resources Allocated (Year 1): $1.5M USD for initial legal fees and operations; 1 dedicated senior International IP Counsel hired.
- Significance: Early allocation crucial to managing IP structure conflict (Decision 2) and shaping global regulatory submissions.

## Question 8 - Dedicated Maintenance Contract for 20-Year Digital Monitoring/Data Retention

- Contract Secured: Year 2 (following initial germline success).
- Annual Budget: $500,000 USD (20-year Data Lifecycle Management - DLM).
- Funding Mitigation: DLM system must be insulated from potential Year 3 budget shortfalls (Risk 4) by funding from the dedicated $15M IP allocation if necessary.


# Distill Assumptions
# Project Plan Summary

## Budget

- $15M USD ring-fenced for initial IP negotiation and upfront payments with Sooam.
- $5M USD allocated for oncogenesis/metabolic disorder risk contingency.
- Year 1 Q3 milestone: Allocate $1.5M for establishing the secondary IP office.

## Timeline

- Validated germline insertion target launch date: December 31, 2026 (Month 8).

## Resource Allocation

- Year 1 FTE: 12 for genetics, 8 for long-term behavioral validation.

## Technical Requirements

- Tactile success: 90% match to chinchilla surface fractal dimension and density.

## Regulatory Strategy

- No formal high-level regulatory discussions for direct neuro-pathway manipulation.

## Operations

- $500,000 annual data lifecycle management contract starts in Year 2 for 20 years.


# Review Assumptions
## Domain of the expert reviewer
Biotechnology Project Management and Risk Assessment

## Domain-specific considerations

- Regulatory compliance: germline editing (South Korea)
- Biological stability: 20-year constraint
- Financial control: high-cost, high-novelty tech (CRISPR/Prime)
- Ethical management: neuro-pathway targeting
- IP structuring: complex international joint venture

## Issue 1 - Critical Missing Assumption: Regulatory Pathway for Direct Neuro-Pathway Interventions

- Plan selects 'Pioneer' route: direct, high-expression transcription factor overexpression targeting oxytocin signaling (Decision 4).
- Assumption 4: No formal, high-level regulatory discussions held for this controversial intervention.
- Regulatory bodies scrutinize engineered alterations of human neurochemical response triggers, requiring extensive preclinical toxicology/ethics review.

Recommendation: Halt *in vivo* human testing planning until comprehensive Regulatory Impact Assessment (RIA) by specialized bioethics counsel aligns with South Korean MFDS expectations for this intervention. Develop mandatory phased fallback: If direct pathway yields regulatory halt (Year 2), pivot immediately to 'Cognitive Cue Optimization' (Decision 4, Choice 2).

Sensitivity: Regulatory go-ahead delay (baseline Q4 Year 2) risks 12-24 month hold, adding $15M sustainment cost (Risk 3), reducing ROI 25%-45% if pivot is successful.

## Issue 2 - Critical Missing Assumption: Quantification of 20-Year Longevity Maintenance Cost Structure

- Success depends on 20-year lifespan constraint (Decision 3). $5M pathology contingency exists (Assumption 5).
- No assumption details operational budget to *sustain* 10+ specially housed dogs for 20 years. Standard care inadequate (Risk 5 noted 150% increase).
- Model lacks 20 years of specialized care, feed, vet services, and longitudinal biomarker monitoring (Assumption 8 notes $500K/year DLM cost, excluding husbandry).

Recommendation: Establish mandatory post-development funding mechanism now. Calculate projected 20-year housing/husbandry cost for successful carrier lines (e.g., 5 lines). If >$10M, secure external endowment or structure JV mechanism (Decision 2) to cover costs (e.g., early license fee linked to liabilities).

Sensitivity: Conservative estimate: $4M per animal line husbandry (excluding $500K data budget). 5 lines = $20M post-R&D liability. Failure to secure funding devalues product by $20M (20% of budget).

## Issue 3 - Under-Explored Assumption: IP/JV Structure Conflict with Technical Velocity

- Plan chooses 'Pioneer' path: develops *custom RNP delivery system* (Decision 1).
- IP structured as a Joint Venture granting *90% IP rights* contingent on timely delivery (Decision 2). Assumption 1 allocates $15M for IP negotiation.
- Conflict: High investment in proprietary RNP tools is not recouped if 90% of commercial value flows externally upon delivery.

Recommendation: Re-negotiate Decision 2 structure regarding proprietary tooling. If custom RNP system (Decision 1) is utilized, IP vesting must be weighted: 90% rights contingent on delivery, but ownership of *background IP* (custom RNP system) should vest 50/50 or be licensed back for a fixed fee. If backup vector is used, 90% vesting remains acceptable.

Sensitivity: If custom RNP succeeds (boosting timeline), but 90% split remains, primary funding organization ROI could drop from 500% baseline to 50%-100% due to limited downstream revenue capture.

## Review conclusion
'Pioneer' project is ambitious (custom RNP, neuro-pathway targeting). Three weaknesses: 1) Unaddressed regulatory pathway for human neuro-pathway manipulation; 2) Lack of cost model for 20-year operational sustainment post-R&D; 3) Financial misalignment: high proprietary tool investment leads to near-total cession of future IP rights. Immediate action: secure regulatory fallback, define 20-year liability budget, and rebalance IP agreement for commensurate financial return.