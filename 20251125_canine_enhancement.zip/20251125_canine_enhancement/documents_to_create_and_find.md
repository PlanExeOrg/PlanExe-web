# Documents to Create

## Create Document 1: Project Charter (CRISPR/Prime Editing Project)

**ID**: f96b7c2b-21d1-4396-b849-d5b362d70258

**Description**: Formal authorization document defining the project scope, objectives (including the 20-year longevity goal and maximal emotional outcome), budget ceiling ($100M USD), primary stakeholders, and preliminary success metrics (Decision 5). Type: Foundational Project Management Document. Audience: Executive Steering Committee, Sooam Leadership.

**Responsible Role Type**: Project Lead

**Primary Template**: PMI Project Charter Template

**Secondary Template**: None

**Steps to Create**:

- Confirm alignment with 'Pioneer' strategic path and core decision points.
- Incorporate the initial $100M budget and the December 31, 2026, foundational milestone.
- Secure initial sign-off from Sooam Executive Management and Project Sponsor.
- Document the initial high-level stakeholder list.

**Approval Authorities**: Project Sponsor, Sooam Biotech Executive Management

**Essential Information**:

- Define the 'vital few' decisions impacting efficacy, budget stability ($100M), and long-term viability (20-year promise).
- Detail the core trade-offs for Decision 1 (CRISPR vs. Prime Editing): Speed vs. Validation Overhead, linking directly to the budget ceiling.
- Quantify the IP alignment structure in Decision 2 (Sooam JV): Specify the exact revenue split contingent on development funding to ascertain long-term ROI vs. immediate capital demands.
- Explicitly state the commitment for Decision 3 (20-Year Longevity): Detail the engineering complexity required (multi-stage gene expression switches) necessitated by the Pioneer strategy.
- Differentiate the mechanism chosen for Decision 4 (Emotional Outcome): Contrast direct neuro-pathway targeting versus indirect cognitive tuning, highlighting associated regulatory/ethical risks.
- Establish clear linkage between each of the 12 levers and the 'Pioneer' strategic selection, justifying why the chosen path for each decision supports Maximal Performance Engineering.
- List all identified synergies and conflicts between the primary decisions (e.g., Decision 1 conflicts with Decision 2 concerning proprietary tools).

**Risks of Poor Quality**:

- Inadequate articulation of trade-offs prevents executive steering committee from making informed, high-stakes go/no-go decisions on core technology selection (e.g., CRISPR pathway).
- Ambiguous definition of IP/JV terms leads to immediate financial disputes with Sooam, potentially freezing operational funds allocated for carriers and experiments.
- Failure to explicitly document the Pioneer strategy's high-risk choices (like direct neuro-pathway engineering) exposes the project to immediate ethics review derailment if internal risk assessments (Assumptions Review Issue 1) are ignored.
- Lack of clear strategic connection between decisions results in conflicted resource allocation (e.g., diverting funds from longevity stability to rapid aesthetic iteration, violating core goals).
- Inability to trace the current state back to the foundational 'Pioneer' logic hampers necessary course corrections when encountering technical roadblocks.

**Worst Case Scenario**: A fractured strategic baseline where decisions conflict (e.g., adopting proprietary tools while agreeing to a 90% revenue split with Sooam for those tools), leading to a premature budget exhaustion ($100M ceiling breached by Year 3) without achieving the foundational 20-year longevity or the maximal emotional release criteria, resulting in total loss of investor capital and reputational damage.

**Best Case Scenario**: The document serves as the definitive strategic playbook, enabling rapid alignment (within one week) across executive stakeholders and technical leads regarding the high-risk, high-reward 'Pioneer' trajectory. It allows the team to immediately prioritize mitigation efforts against regulatory blocks for neuro-pathway engineering and secure contingency funding for the 20-year liability, accelerating go-forward technical design.

**Fallback Alternative Approaches**:

- If consensus on high-risk levers (Decision 1 & 4) is impossible, initiate a mandatory, 2-week 'Forced Trade-Off Workshop' specifically targeting the efficacy vs. regulatory impact of these two levers, documenting the rationale for whichever path is abandoned.
- If conflict analysis is too complex, reduce the document scope immediately to only cover the three 'Critical' decisions (Decision 3, 4, and 2) and utilize the Builder scenario choices as the default fallback position until clarity is achieved on the Pioneer path.
- If justification for Pioneer alignment across all 12 levers cannot be established, defer the document creation and revert to the 'Project Charter' (document.json) as the temporary controlling document until strategic coherence is restored.

## Create Document 2: Initial Technical Pathway Specification: Editing System & Longevity Integration

**ID**: d722dfcc-18d0-436d-a2d8-bc22207ad07b

**Description**: High-level technical plan detailing the architecture for Decision 1 (CRISPR/Prime Selection) and Decision 3 (Longevity Integration). Must explicitly state the custom RNP development pathway chosen and the required scope for initial telomerase/GH pathway manipulation. Type: Technical Strategy Document.

**Responsible Role Type**: Lead Genomic Architect & Editor

**Primary Template**: Biotech Technology Selection Framework

**Secondary Template**: None

**Steps to Create**:

- Formalize the technical blueprint for the custom RNP system.
- Map the required genomic loci for 20-year longevity onto the chosen editing platform.
- Identify necessary parallel validation steps for AAV backup system (mitigation of Risk 1).
- Integrate initial performance threshold required for cohort progression.

**Approval Authorities**: Lead Genomic Architect & Editor, Longevity & Pathology Specialist

**Essential Information**:

- Define the chosen editing platform: Explicitly confirm the selection of the 'custom ribonuclear protein delivery system' (Decision 1, Choice 3) as the primary pathway, despite high risk.
- Detail the scope of Longevity Constraint integration (Decision 3, Choice 1): List the specific telomerase and growth hormone (GH) signaling pathways targeted for aggressive manipulation.
- Quantify the minimum viable editing efficiency (%) required by Month 6 (June 2026) for the custom RNP system before triggering the pivot to the backup AAV vector system (Risk 1 mitigation).
- Specify the initial performance metrics required for initial cohort progression, linking RNP fidelity to the required aesthetic/behavioral success profile.
- Outline the integration complexity: Describe how the Longevity targets (Decision 3) will be sequenced or layered alongside the primary aesthetic edits (Decision 9) using the custom RNP tools.

**Risks of Poor Quality**:

- Failure to clearly define the custom RNP architecture will halt integration with the Longevity Constraint work, leading to immediate timeline slips past the aggressive December 31, 2026, target.
- If the required scope of telomerase/GH manipulation is understated, the resulting engineering complexity will exceed available RNP capacity, triggering Risk 2 (pathology) due to rushed or insufficient editing.
- Inability to specify the AAV backup trigger point makes Risk 1 mitigation ambiguous, meaning the project might persist with an inefficient toolset, draining the $100M budget without adequate statistical learning.
- Lack of sequenced integration plan between editing system and longevity targets compromises the scientific integrity needed for later regulatory submissions regarding the 20-year promise.

**Worst Case Scenario**: Adopting an improperly defined custom RNP system leads to persistent low efficacy (<10% insertion efficiency), forcing the team to pivot to the backup AAV system months late. This pivot compromises the ability to integrate the complex, aggressive epigenetic strategy required for the 20-year longevity goal, effectively nullifying the project's core differential value proposition and potentially locking $50M+ of R&D sunk costs.

**Best Case Scenario**: The document confirms the high-risk custom RNP path is technically feasible and precisely maps the genomic loci required to begin aggressive modulation of the 20-year longevity pathways immediately. This clear technical blueprint enables the Genomic Architect to optimize the RNP design cycle and provides necessary checkpoints for the Longevity Specialist, accelerating the path toward the December 2026 germline target while safeguarding against immediate pathology risks.

**Fallback Alternative Approaches**:

- If RNP architecture design stalls, immediately utilize the established Prime Editing framework (Decision 1 backup) specifically targeting Longevity pathways (Decision 3) while assigning a small, dedicated team to parallel design the custom RNP infrastructure for Phase 2.
- If genomic locus mapping for longevity proves impossible via current RNP scope, immediately freeze aesthetic edits and shift 60% of the genomic FTEs to focusing solely on developing the less-risky neuro-pathway optimization (Decision 4, Choice 2) as the primary value driver.
- Engage external expert consulting (using $5M Risk 2 contingency budget if necessary) to rapidly vet the feasibility and sequencing requirements of the proposed telomerase/GH integration against the custom RNP capabilities.

## Create Document 3: IP Joint Venture Negotiation Strategy & Custom RNP Vesting Proposal

**ID**: 0994ef06-7c94-4418-be75-4be668c8e9e5

**Description**: Document outlining the mandatory re-negotiated terms for Decision 2 (IP Alignment). Must prioritize retaining ownership/co-ownership of the custom RNP tooling value against the 90% revenue cession structure. Type: Legal/Negotiation Strategy Document.

**Responsible Role Type**: Financial Controller & IP Negotiator

**Primary Template**: Technology Transfer Negotiation Mandate

**Secondary Template**: Standard JV Agreement Outline

**Steps to Create**:

- Model ROI under current 90% cession and determine minimum acceptable revenue capture.
- Draft specific legal language proposing co-ownership/buy-back for the custom RNP system (Recommendation 1).
- Define milestone triggers for IP vesting tied to technical delivery.
- Integrate required escrow structure for 20-year liability funding (Issue 2 mitigation).

**Approval Authorities**: Financial Controller & IP Negotiator, Project Lead, Sooam Biotech Executive Management (for final review)

**Essential Information**:

- Define the minimum acceptable revenue capture percentage for the primary organization based on the current 90% cession structure for Decision 2.
- Draft specific, actionable legal language proposing co-ownership or a guaranteed buy-back mechanism specifically for the value attributed to the custom RNP system (Decision 1 tooling).
- Define precise technical milestone triggers tied to successful germline delivery (validated by Dec 31, 2026) that must be met to initiate staggered IP vesting schedules.
- Incorporate necessary legal clauses and escrow structures identified in Issue 2 review to ensure dedicated funding mechanisms are established for the projected 20-year specialized canine husbandry liability (covering projected $20M+ liability).
- Outline alternative IP structures/revenue sharing models contingent upon whether the custom RNP system (Decision 1) or the off-the-shelf backup vector is ultimately utilized.

**Risks of Poor Quality**:

- Failure to retain significant financial upside (ROI) despite developing high-value proprietary technology (custom RNP), leading to poor return on initial R&D investment.
- Legal deadlock or project delay during negotiations with Sooam Biotech if new terms are not clearly defined and justified upfront, risking Milestone 1 failure.
- Creation of an unenforceably structured joint venture that fails to ring-fence funds necessary for long-term operational liabilities (20-year care costs), exposing the project to eventual operational failure.
- Loss of control over key enabling technology (custom RNP), preventing future independent commercial exploitation or licensing of the core scientific advancement.

**Worst Case Scenario**: Accepting the initial 90% revenue cession structure without modification, resulting in the primary organization developing foundational, high-value proprietary technology (custom RNP) only to surrender nearly all commercial upside to the JV partner, severely limiting future reinvestment capital and shareholder return.

**Best Case Scenario**: Successful negotiation secures co-ownership or a fixed-fee buy-back right for the custom RNP technology utilized in Decision 1, ensuring substantial, protected ROI, while stabilizing the 20-year operational liability funding via required escrow mechanisms within the finalized JV agreement structure.

**Fallback Alternative Approaches**:

- If renegotiation on RNP ownership stalls, immediately proceed using the fixed $15M allocation for the initial JV agreement structure tied only to the 90% revenue cession, assuming technical failure will necessitate the backup vector, thus de-risking the proprietary tool investment.
- Engage external, high-leverage technology transfer legal counsel specializing in complex biotech joint ventures to rapidly redline the draft agreement based on the specific conflict identified in Issue 3.
- If Sooam demands an unacceptably high price for RNP co-ownership, formally trigger the backup plan (Risk 1 mitigation) by immediately funding the parallel viral vector validation track and adjusting IP negotiations to reflect the reduced reliance on proprietary tooling.

## Create Document 4: Regulatory Protocol & Ethical Impact Assessment (RIA) Framework (Neuro-Pathway Focus)

**ID**: 8c713a0e-a2b4-49db-8863-440bd13d2ebd

**Description**: Framework outlining the schedule and specific scope for engaging specialized counsel to assess the regulatory risk associated with Decision 4 (Direct Neuro-Pathway Targeting). Must include the mandated structure for the Cognitive Cue Optimization fallback pathway. Type: Compliance & Strategy Report.

**Responsible Role Type**: Regulatory & Bioethics Strategist (Seoul Focus)

**Primary Template**: Regulatory Impact Assessment (RIA) Template

**Secondary Template**: Dual-Jurisdiction Compliance Mapping

**Steps to Create**:

- Define scope/mandate for specialized bioethics counsel engagement (Issue 1 update).
- Document the technical specifications and required genetic targets for the Cognitive Cue Optimization fallback strategy (Decision 4, Choice 2).
- Establish the Yes/No/Pivot regulatory decision gates for Q1/Q2 Year 2.
- Define schedule for securing secondary jurisdiction consultation.

**Approval Authorities**: Regulatory & Bioethics Strategist (Seoul Focus), Project Lead

**Essential Information**:

- Must define the precise scope and mandate for specialized bioethics counsel engagement concerning Decision 4 (Direct Neuro-Pathway Targeting).
- Document the technical specifications required for the Cognitive Cue Optimization fallback strategy (Decision 4, Choice 2) to enable a pivot.
- Establish clear 'Yes/No/Pivot' regulatory decision gates, specifically targeted for Q1/Q2 Year 2, based on MFDS reaction to neuro-pathway intervention.
- Define a clear schedule for initiating confidential regulatory consultation in a secondary jurisdiction (US/EU) as mandated by Risk 3 mitigation.

**Risks of Poor Quality**:

- A poorly defined RIA framework will fail to accurately predict the regulatory shutdown risk associated with Decision 4, leading to operational halt in Seoul.
- Vague documentation of the Cognitive Cue Optimization fallback strategy will result in critical delay (12-24 months) if a pivot is required, severely impacting timeline and ROI.
- Failure to secure necessary preliminary secondary jurisdiction consultation will eliminate the regulatory risk hedge against MFDS, making the project vulnerable to complete project failure if the primary track stalls.

**Worst Case Scenario**: A delayed or absent RIA combined with the failure to pre-validate the fallback strategy leads to a complete operational shutdown in Seoul by Year 2 due to prohibition on direct neuro-pathway engineering, forcing an unplanned, costly pivot that exceeds the $15M sustainment cost buffer and devalues the core product proposition.

**Best Case Scenario**: The RIA clearly defines the acceptable regulatory bounds, allowing execution of the Pioneer strategy (Decision 4, Choice 1) to proceed confidently, or provides an immediate, pre-documented pivot path (using Cognitive Cue Optimization) validated against secondary jurisdictions, preventing regulatory-induced timeline slippage and maintaining investor confidence.

**Fallback Alternative Approaches**:

- If specialized counsel engagement is slow, immediately commission an internal 'Regulatory Impact Matrix' linking each genetic modification component (Longevity, Aesthetics, Emotion) against known MFDS guidelines for non-human, non-therapeutic applications.
- If the direct neuro-pathway strategy (Choice 1) faces immediate pushback in preliminary review, immediately shift all current R&D resource focus (FTEs) toward finalizing the technical specifications for the Cognitive Cue Optimization fallback (Choice 2) to expedite pivot readiness.
- Leverage Sooam Biotech's existing regulatory history to frame the project exclusively as animal enhancement, deferring explicit discussion of human pharmaceutical interaction until later stages (Risk 3 management).

## Create Document 5: 20-Year Operational Liability Funding Model & Escrow Structure Plan

**ID**: 619227ec-dfdc-4c2e-9d86-5553082fae65

**Description**: Detailed financial calculation documenting the projected operational costs (husbandry, veterinary care, specialized housing) required to sustain successful cohorts for the full 20-year longevity requirement (Risk 5, Issue 2). Must propose the concrete mechanism for isolating and perpetually funding this liability via escrow/trust, tied to the IP agreement (Recommendation 3). Type: Financial Risk Mitigation Plan.

**Responsible Role Type**: Financial Controller & IP Negotiator

**Primary Template**: Long-Term Liability Funding Model

**Secondary Template**: Financial Escrow Requirement Document

**Steps to Create**:

- Calculate the estimated $20M liability based on specialist input (Risk 5).
- Propose the percentage of future revenue/JV share required to fund a suitable escrow/trust.
- Draft the structural requirements for making this fund irrevocable post-R&D success.
- Integrate this structure into the IP Negotiation Strategy Document.

**Approval Authorities**: Financial Controller & IP Negotiator, Longevity & Pathology Specialist

**Essential Information**:

- Quantify the total projected 20-year husbandry and specialized care cost (estimated $20M liability) based on specialized feeding, veterinary support, and environmental controls needed for five successful cohort lines (Risk 5, Issue 2).
- Define the precise financial mechanism (e.g., percentage of future licensing revenue, fixed upfront allocation from the $15M IP budget) required to perpetually fund an irrevocable escrow/trust to cover this liability.
- Draft the structural outline for the Irrevocable Escrow Account, detailing trigger conditions for fund release (e.g., successful confirmation of 20-year juvenile behavior proxy success).
- Integrate the escrow funding trigger directly into the Intellectual Property and Institutional Alignment Structure (Decision 2) to ensure IP vesting is contingent on both technical success AND liability funding establishment.
- Specify which currency (USD/KRW) will denominate the operational float within the escrow structure, maintaining USD parity as the primary budget currency.

**Risks of Poor Quality**:

- Failure to adequately fund the 20-year liability results in the primary funding organization inheriting massive, unfunded long-term operational risk post-development.
- An unclear or incomplete escrow structure allows the JV partner (Sooam) to potentially delay funding release, jeopardizing the long-term care of the research subjects.
- Inaccurate cost calculation (underestimation) leads to the total $100M budget being effectively depleted by post-R&D operational costs, collapsing projected ROI.
- Lack of integration with the IP agreement means the financial risk mitigation fails to provide the necessary leverage during Decision 2 negotiations.

**Worst Case Scenario**: The project successfully delivers the genetically modified organism, but the resulting 20-year operational liability goes unfunded, immediately creating a crisis requiring an emergency capital raise of over $10M concurrently with commercialization efforts, leading to significant loss of long-term revenue capture due to desperation financing or failure to maintain the subject animals.

**Best Case Scenario**: The financial controller establishes a fully funded, irrevocable 20-year liability escrow at the outset, insulated from operational budget strains, allowing the main $100M to focus purely on R&D successes. This proactive mechanism provides massive leverage in negotiating Decision 2, potentially securing better IP terms by proving fiscal responsibility regarding long-term welfare liabilities.

**Fallback Alternative Approaches**:

- If detailed 20-year cost modeling proves too complex initially, immediately assign 5% of the total budget ($5M) to a separate, restricted 'Longevity Operational Contingency' fund, managed separately from R&D burn rate, until definitive cost models are delivered at Year 2 Q1.
- Leverage the structure defined in Decision 2 to negotiate an immediate, small milestone payment from Sooam conditional upon the establishment of a provisional long-term care contract, even without final cost quantification.
- Utilize external liability/insurance modeling consultants familiar with long-term institutional animal care contracts to rapidly derive a high-confidence estimate for the initial escrow requirement.


# Documents to Find

## Find Document 1: South Korean Bioethics and Biosafety Act Governing Germline Modification

**ID**: 2bce88fc-88b1-439c-bf50-3218d68f6f55

**Description**: The foundational legal text governing all germline editing activities in South Korea. Essential for establishing initial non-controversial compliance tracks and understanding MFDS jurisdiction regarding animal modification. Type: Official Legislation.

**Recency Requirement**: Current, active legislation essential

**Responsible Role Type**: Regulatory & Bioethics Strategist (Seoul Focus)

**Steps to Find**:

- Search official portals of the South Korean Ministry of Health and Welfare or relevant legislative database.
- Consult with local Korean counsel to obtain the most recent ratified version.
- Analyze specific sections related to heritable changes in non-therapeutic applications.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the precise legal requirements and authorization steps mandated by the South Korean Bioethics and Biosafety Act specifically for non-therapeutic, heritable genome modification in canines.
- Identify the exact jurisdictional scope of the Ministry of Food and Drug Safety (MFDS) regarding advanced genetic engineering (CRISPR/Prime) and how it intersects with the project's chosen 'Pioneer' pathway (custom RNP, neuro-pathway targeting).
- List explicit reporting obligations and required data presentation standards for longevity (20-year) and behavioral validation protocols (Decision 8) to meet MFDS transparency requirements.
- Specify any prohibitions or special consent requirements related to modifications targeting cognitive/neurotransmitter pathways (Decision 4), as this represents the highest regulatory risk.

**Risks of Poor Quality**:

- Immediate operational shutdown in Seoul if the initial operational design violates jurisdictional mandates concerning germline modification or neuro-pathway targeting.
- Failure to establish the initial compliance footing, leading to mandatory project delays exceeding the 8-month germline target date, thus straining the $100M budget buffer.
- Introduction of unforeseen legal liabilities or mandated line culling due to non-compliance with animal welfare standards relating to the complex behavioral manifestation requirements (Risk 5).
- Inability to prepare legally sound defense/pivot strategy for Decision 4 (Neuro-pathway engineering) if MFDS guidelines are inadequately assessed.

**Worst Case Scenario**: A full operational moratorium imposed by South Korean authorities within Year 1 or 2 due to non-compliance concerning the direct neuro-pathway engineering (Decision 4), resulting in $15M+ in sustained operational costs with zero progress toward primary commercial goals.

**Best Case Scenario**: Rapid establishment of the minimal viable regulatory compliance footprint in South Korea, allowing the engineering team to proceed efficiently with the high-risk Pioneer strategy while creating a legally robust foundation for future international IP negotiation (Decision 2) and commercialization.

**Fallback Alternative Approaches**:

- Immediately initiate consultation with on-site legal counsel specialized in Korean Bioethics Law to conduct a formal Regulatory Impact Assessment (RIA) on Decision 4's neuro-pathway targeting by Month 3, per identified assumption gaps.
- Develop and internally approve a phased regulatory fallback plan pivoting all neuro-pathway work to secondary, lower-risk cognitive cue optimization (Decision 4, Choice 2) if the initial RIA indicates high risk of official moratorium.
- Align all data recording protocols from Day 1 to meet the most stringent known South Korean standards for longitudinal animal studies, accommodating potential later audits regarding the 20-year constraint without requiring large-scale reformatting.

## Find Document 2: MFDS/Bioethics Committee Precedents for Novel Non-Therapeutic Mammal Modification

**ID**: dbe5f5a9-7f73-4061-8c3e-3fd3402ab4f4

**Description**: Existing guidance, rulings, or precedents from South Korean regulatory bodies specifically concerning genetically modified companion animals or non-human research subjects that might inform the regulatory strategy for Decision 7 and Risk 3 mitigation, particularly regarding controversial modifications.

**Recency Requirement**: Last 5 years, if available

**Responsible Role Type**: Regulatory & Bioethics Strategist (Seoul Focus)

**Steps to Find**:

- Search public records or scholarly analyses referencing MFDS rulings on animal GMOs.
- Engage external regulatory counsel familiar with South Korean internal review board processes.
- Check for published white papers from related Asian government science ministries.

**Access Difficulty**: Hard

**Essential Information**:

- Identify all existing precedents, rulings, or formal guidance issued by the South Korean MFDS or associated Bioethics Committees regarding non-therapeutic germline modification in non-human mammals.
- Determine the specific threshold or justification required by MFDS for reviewing controversial modifications, especially those impacting neurochemistry (as per Decision 4).
- List precedents related to the *scale* of modification deemed acceptable (i.e., compare to simpler genetic fixes vs. complex 20-year longevity pathways).
- Identify the required documentation timeline/lead time for submitting novel intervention protocols (like direct neuro-pathway targeting) under Korean Bioethics guidelines.

**Risks of Poor Quality**:

- Failure to accurately model regulatory concerns causes the project to proceed down a pathway (e.g., direct neuro-editing) that will face immediate, unresolvable moratorium from MFDS (Risk 3 realization).
- Inaccurate assessment of submission requirements leads to critical paperwork errors, causing mandatory 18-36 month delays in obtaining approval for initial animal testing.
- Underestimating the stringency of protocols results in unnecessary resource dedication to internal ethical reviews that do not satisfy external MFDS reviewers, wasting up to $15M in sustainment costs.
- Lack of documented precedent prevents the Regulatory Strategist from successfully framing the project as 'advanced research' rather than 'unregulated human enhancement,' leading to public/political backlash (Risk 8).

**Worst Case Scenario**: A complete and immediate operational shutdown at the primary Seoul facility for over 3 years due to regulatory prohibition on the chosen neuro-pathway engineering, leading to the mandated termination of experimental cohorts, resulting in the loss of sunk costs ($50M+).

**Best Case Scenario**: Clear evidence of favorable or predictable regulatory pathways allows the project team to front-load the controversial neuro-pathway (Decision 4) with confidence, securing necessary permits ahead of schedule (by Year 2 Q1) and immediately de-risking the core commercial value proposition, enabling aggressive acceleration into primate testing.

**Fallback Alternative Approaches**:

- Immediately commission an urgent (4-week) deep-dive engagement with specialized South Korean bioethics counsel to interpret the 'spirit' of existing precedents regarding non-therapeutic modifications.
- If direct neuro-pathway precedents are silent or highly restrictive, immediately pivot Decision 4 to the 'Focus exclusively on optimizing visual and auditory cues' alternative choice, adhering strictly to the 'Builder' pathway's approach to emotional sourcing.
- Develop a comprehensive Regulatory Impact Assessment (RIA) document outlining the safety buffers (e.g., $5M pathology contingency) specifically to counter ethical concerns around Decision 4, using this documentation as the foundational counter-argument in initial low-level MFDS inquiries.

## Find Document 3: Validated Canine AAV Vector Titers and Tropism Data for Somatic Insertion

**ID**: 873ceb24-3de1-40c2-9141-b4ae5f484abc

**Description**: Raw technical specifications and efficacy data (titers, on-target rates) for established, off-the-shelf AAV or viral systems applicable to canine zygotes. This is crucial for rapidly scaling the backup plan for the longevity pathway if the custom RNP fails (Risk 1 mitigation). Type: Scientific Performance Data / Vector Specification Sheets.

**Recency Requirement**: Published within last 3 years for high fidelity

**Responsible Role Type**: Lead Genomic Architect & Editor

**Steps to Find**:

- Search databases like PubMed or specific vector platform provider repositories (e.g., Addgene, Thermo Fisher) for canine-specific data.
- Contact leaders of known xenotransplantation pig editing consortia (Suggestion 1 reference) for protocol transfer inquiries.
- Review publications related to human inherited retinal disease gene therapy (Luxturna pathway, Suggestion 3) for relevant AAV use cases.

**Access Difficulty**: Medium

**Essential Information**:

- What are the specific titers and tropism data for established AAV or viral systems applicable to canine zygotes?
- What are the on-target rates for these viral systems when used in canine genome editing?
- What are the performance benchmarks for these vectors in terms of efficiency and safety for somatic insertion?

**Risks of Poor Quality**:

- Inaccurate or outdated titers and tropism data could lead to ineffective vector selection, resulting in failed experiments and wasted resources.
- Failure to identify the correct viral system may delay the project timeline significantly, impacting the overall budget and project viability.

**Worst Case Scenario**: The project fails to achieve the necessary somatic insertion efficiency, leading to a complete halt in progress and a potential loss of $30M in sunk costs due to reliance on ineffective delivery systems.

**Best Case Scenario**: High-quality, validated data leads to the successful selection of an optimal AAV vector, enabling rapid scaling of the backup plan for the longevity pathway, thus maintaining project momentum and budget integrity.

**Fallback Alternative Approaches**:

- Engage with experts in the field to conduct targeted interviews for insights on alternative viral systems that may not be published yet.
- Consider developing a custom AAV vector based on existing knowledge if off-the-shelf options prove inadequate.
- Utilize existing collaborations with other research institutions to access unpublished data or proprietary vector specifications.

## Find Document 4: Existing South Korean Guidelines for Animal Welfare and Specialized Housing (Post-Juvenile)

**ID**: 227767b9-8a4b-455e-88a9-f598685290e1

**Description**: Official guidelines or standards detailing mandatory infrastructure, veterinary resources, and enrichment protocols required for housing research dogs long-term (up to 20 years), necessary for calculating the operational liability (Issue 2/Risk 5).

**Recency Requirement**: Current National Standards

**Responsible Role Type**: Advanced Animal Husbandry & Logistics Manager

**Steps to Find**:

- Contact the Korean Ministry of Agriculture, Food and Rural Affairs (or equivalent) for national animal welfare mandates.
- Obtain facility audit checklists used by local veterinary oversight bodies in Seoul.
- Search for institutional standards (e.g., Seoul National University) regarding long-term specialized canine environments.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the precise mandatory infrastructure specifications (caging type, environmental controls, square footage per animal) required for research dogs housed beyond standard juvenile phases (e.g., 5+ years) under current South Korean law.
- List the minimum required frequency and scope of veterinary check-ups, advanced biomarker monitoring (for longevity assessment), and specialized nutritional provision mandates for long-term canine subjects.
- Quantify the allowed maximum operational contingency (in terms of facility capacity or budgetary threshold) linked to supporting enriched housing necessary for maintaining the '20-year juvenile behavior' requirement (Risk 5).
- Detail protocols or guidelines governing the retirement or euthanasia criteria for long-term research subjects housed under these specialized conditions.

**Risks of Poor Quality**:

- Inaccurate assessment of the 20-year husbandry liability, leading to a massive underestimation of post-R&D operational costs (potential $20M deficit identified in review).
- Non-compliance with mandatory animal welfare standards results in immediate seizure of experimental lines and potential litigation against Sooam Biotech and the project.
- Failure to budget for required specialized environmental controls leads to substandard care, compromising the integrity of the 20-year behavioral validation data (Risk 5).
- Delayed identification of necessary infrastructure upgrades stalls the transition from initial cohort testing to long-term maintenance staging.

**Worst Case Scenario**: Failure to secure accurate guidelines results in discovering post-R&D that the $500k/year data management budget is grossly insufficient, requiring immediate cessation of long-term housing for all successful lines due to unsustainable operational costs or regulatory intervention over inadequate welfare conditions. This effectively zeros out the value of the primary scientific achievement ($100M sunk cost).

**Best Case Scenario**: Precise adherence to official guidelines allows for the immediate, cost-optimized design of the longitudinal housing units, integrating regulatory compliance into the CAPEX planning (Year 2/3) and providing a definitive, auditable liability ceiling for the required 20-year support structure.

**Fallback Alternative Approaches**:

- Commission an emergency, targeted legal review engagement (using $150k from the IP negotiation buffer) focused solely on eliciting written confirmation from MFDS regarding post-5-year canine care mandates.
- Conduct on-site auditing walkthroughs with facilities managers at competing, established South Korean research institutions (e.g., major universities) known for long-term large animal studies to gather empirical, practical operational benchmarks.
- If the primary document remains elusive, extrapolate housing costs based on published EU/US (AAALAC equivalent) standards for geriatric large companion animals, applying a 1.5x multiplier to account for KRW labor costs and novelty surcharge.

## Find Document 5: Baseline Canine Telomerase and Growth Hormone Signaling Expression Profiles (Wild Type)

**ID**: e1b19a0e-33ae-4ceb-84d5-caaba198fb2b

**Description**: Raw qPCR, sequencing, or physiological data sets from genetically normal adult and juvenile canines establishing the natural epigenetic expression curves for telomerase and GH pathways, required for creating the modification targets for Decision 3.

**Recency Requirement**: Most recent available canine genomic/aging studies

**Responsible Role Type**: Longevity & Pathology Specialist

**Steps to Find**:

- Search NIH/NCBI repositories (GEO) for publicly available canine tissue expression data related to aging.
- Acquire datasets from large veterinary genomics projects (e.g., Canine Genome Project outputs).
- Consult academic resources referenced by the Epigenetic Longevity Scientist expertise search.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the specific, measured baseline expression levels (qPCR counts, sequencing reads, or normalized physiological indices) for Telomerase Reverse Transcriptase (TERT) and Growth Hormone Receptor (GHR) in the target Golden Retriever model across juvenile (0-2 years) and mature (5+ years) stages.
- Identify established canine-specific biomarkers for cellular senescence and metabolic regulation (e.g., p53 activation, IGF-1 levels) that are correlated with natural lifespan decline.
- List the acceptable variability (standard deviation) for these wild-type expression profiles to allow subsequent measurement of modification efficacy against the 20-year longevity constraint (Decision 3).
- Provide verified citation/source links for all raw data supporting these baseline expression profiles.

**Risks of Poor Quality**:

- If baseline profiles are outdated or derived from different breeds, the calculated 'modification targets' for Decision 3 will be inaccurate, leading to either insufficient longevity extension or excessive, risky manipulation (Risk 2).
- Poor quality data prevents the Longevity Specialist from setting accurate thresholds for identifying pathological failure markers (oncogenesis/metabolic dysregulation) during monitoring.
- Inability to adequately justify the scope of effort required for the longevity constraint to external regulatory bodies or investors, weakening the project's foundational scientific basis.

**Worst Case Scenario**: Implementing the aggressive epigenetic strategy based on incorrect baseline profiles leads to the creation of organisms that either fail to achieve the 20-year lifespan or develop severe, costly, and project-ending pathologies (oncogenesis) due to over-correction on flawed targets.

**Best Case Scenario**: High-fidelity baseline data allows the Longevity Team to precisely calibrate the initial Prime Editing intervention, minimizing off-target epigenetic risks, validating the feasibility of the 20-year constraint, and insulating the $5M pathology contingency from immediate burnout.

**Fallback Alternative Approaches**:

- Initiate resource-intensive, internal longitudinal study on a small cohort of wild-type canines (utilizing $5M pathological contingency if necessary) to generate project-specific baseline data, accepting an 8-month delay to the Decision 3 timeline.
- Engage leading veterinary endocrinology experts to perform a focused meta-analysis of existing literature, using expert judgment to adjust current wild-type parameters by a predefined variance factor (e.g., +/- 15%) to guide initial editing targets.
- Defer Decision 3 implementation until Decision 1 (CRISPR pathway) is finalized, ensuring the editing technology used matches the data requirements of the longevity pathways, even if it slightly delays the RNP development schedule.

## Find Document 6: South Korean Guidelines for Animal Welfare and Specialized Housing (Post-Juvenile)

**ID**: 7d30f0c4-7cb3-4957-a1a8-8d18a8fc4da0

**Description**: Official guidelines or standards detailing mandatory infrastructure, veterinary resources, and enrichment protocols required for housing research dogs long-term (up to 20 years), necessary for calculating the operational liability (Issue 2/Risk 5). This is a duplicate entry to ensure critical operational data is sourced.

**Recency Requirement**: Current National Standards

**Responsible Role Type**: Advanced Animal Husbandry & Logistics Manager

**Steps to Find**:

- Contact the Korean Ministry of Agriculture, Food and Rural Affairs (or equivalent) for national animal welfare mandates.
- Obtain facility audit checklists used by local veterinary oversight bodies in Seoul.
- Search for institutional standards (e.g., Seoul National University) regarding long-term specialized canine environments.

**Access Difficulty**: Medium

**Essential Information**:

- Detail the exact infrastructure specifications (e.g., required square footage per animal, specialized climate control, air filtration standards related to 'chinchilla feel' requirements) for long-term housing.
- List mandatory veterinary oversight schedules and required specialist availability (e.g., avian/mammalian oncologist, endocrinologist) aligned with the 20-year longevity monitoring plan (Risk 2/Decision 3).
- Quantify the maximum allowable deviation from standard feeding/enrichment protocols before an animal line is flagged for excessive operational cost (Risk 5 threshold).
- Identify specific protocols required by South Korean regulation for the terminal euthanasia or long-term ethical management of genetically modified, non-viable lines after Year 5.

**Risks of Poor Quality**:

- Inaccurate cost estimation leads to a severe understatement of the $20M+ operational liability for 20-year specialized husbandry (Issue 2), threatening budget depletion post-R&D.
- Non-compliance with specialized infrastructure requirements forces external regulatory action or internal ethical review delays, halting longitudinal validation.
- Failure to meet environment standards compromises the 'chinchilla feel' and juvenile behavior metrics, invalidating core product promises (Risk 5/Decision 8).
- Unexpected high operational costs deplete contingency funds reserved for technical failure mitigation (Risk 1/Risk 2).

**Worst Case Scenario**: A failure to accurately budget and secure funding for the 20-year specialized canine housing liability results in a mandatory cessation of all long-term behavioral validation cohorts around Year 6 due to insolvency, rendering the 20-year longevity claim unprovable and devaluing the entire R&D investment.

**Best Case Scenario**: Securing precise regulatory and husbandry requirements allows the project to establish a scientifically rigorous, compliant, and fully costed 20-year operational plan anchored by a defined contingency budget, immediately de-risking the largest post-R&D liability and assuring investors of long-term viability.

**Fallback Alternative Approaches**:

- Immediately initiate high-level consultations with three specialized international animal welfare consulting firms to develop a conservative, worst-case P&L projection for 20 years of specialized care.
- Structure Decision 2 (IP alignment) to include an escrow/endowment mechanism where a portion of early licensing revenue is legally earmarked solely for covering the long-term husbandry of proof-of-concept lines.
- Pilot test operational costs by placing the first three successful edited lines into three different qualified, specialized external care facilities in South Korea to obtain verifiable, direct cost quotes.

## Find Document 7: Literature Review: Historical Canine Cloning/Genomic Engineering IP Agreements (Sooam Context)

**ID**: 664d8deb-1d35-4d7c-8a31-004888564585

**Description**: Any publicly accessible summaries, legal analyses, or press releases detailing the Intellectual Property (IP) structures Sooam Biotech has previously established in major genome-related projects, providing context for Decision 2 negotiations.

**Recency Requirement**: Last 10 years

**Responsible Role Type**: Financial Controller & IP Negotiator

**Steps to Find**:

- Search academic databases for legal papers analyzing Sooam IP structures.
- Review press archives for announcements related to licensing agreements stemming from their cloning/genetics work.
- Consult resources related to Suggestion 2.

**Access Difficulty**: Medium

**Essential Information**:

- List the specific IP splits, royalty structures, and milestone payment triggers utilized in Sooam Biotech's last three major genome engineering projects.
- Detail any pre-existing clauses in past agreements that governed ownership of background IP (e.g., delivery vectors) when using third-party optimization factors.
- Identify the standard duration and territorial scope for non-commercial research licenses granted by Sooam within these historical agreements.
- Quantify any previously negotiated fixed upfront payments versus contingent royalty rates utilized in agreements comparable to Decision 2's choices.

**Risks of Poor Quality**:

- Negotiating Suboptimal IP Terms: Failure to benchmark against historical agreements may result in accepting less favorable upfront capital terms or excessively capping future revenue streams.
- Misalignment with Custom RNP Ownership: Inaccurate historical data could lead to agreeing to a 90% JV split (Pioneer choice) without securing appropriate ownership transfer for the proprietary RNP system developed in-house (Risk/Assumption 3 conflict).
- Timeline Delays in Legal Finalization: Incomplete precedent analysis slows down the negotiation phase for Decision 2, delaying the start date for critical R&D.

**Worst Case Scenario**: Accepting an IP structure fundamentally misaligned with the high initial investment in proprietary tooling (custom RNP), resulting in minimal long-term ROI (potential ROI drop from 500% baseline to <100%) because nearly all commercialization value flows to the external partner.

**Best Case Scenario**: Securing a historically informed, leverageable IP agreement that protects the organization's investment in custom technology (RNP system) while meeting the critical timeline demands of the Pioneer strategy, maximizing long-term revenue capture.

**Fallback Alternative Approaches**:

- Initiate immediate targeted engagement with specialized international IP legal counsel familiar with South Korean genomic IP structuring, allocating $500k from the $15M IP budget towards expedited external review.
- Perform rapid comparative analysis against publicly known agreements involving competitors utilizing similar proprietary delivery systems in animal models.
- If direct historical data is unattainable, structure Decision 2 choice 3 (Complete transfer with fixed payment) but explicitly carve out background IP related to newly developed RNP factors.

## Find Document 8: Reference Data on Human Oxytocin/Dopamine Release Thresholds Triggered by Known Stimuli

**ID**: 9724f146-2c26-4187-ab13-505db9592bf7

**Description**: Validated, quantifiable neurochemical data sets used as benchmarks for defining the 'maximal release' sought in Decision 5 and Decision 4. This serves as the baseline measurement target against which the engineered canine's efficacy will be compared.

**Recency Requirement**: Published within last 5 years for precise hormonal assay relevance

**Responsible Role Type**: Behavioral & Emotional Metric Validation Lead

**Steps to Find**:

- Query scientific literature for established HRI (Human-Robot Interaction) or affective neuroscience studies specifying baseline dopamine/oxytocin spikes from high-appeal stimuli (e.g., infants, pets).
- Obtain the specific NIH or equivalent data sets referenced in the Emotional Response Validation Protocol.
- Consult data referenced in clinical trials for companion animal interaction studies.

**Access Difficulty**: Medium

**Essential Information**:

- Establish the exact, quantified baseline thresholds (in pg/mL or validated index scores) for dopamine and oxytocin release in human subjects exposed to high-appeal stimuli (e.g., human infants or baseline companion animals).
- List the specific assay methodologies (e.g., ELISA, mass spectrometry protocols) used to derive the benchmark data, ensuring compatibility with planned physiological measurement protocols (Decision 5).
- Detail the correlation factor between the numerical spike/index and the subjective definition of 'maximal' emotional release used by the project team.
- Identify the specific emotional/behavioral input vectors (visual, auditory, tactile) that correspond to the measured baseline neurochemical release values.

**Risks of Poor Quality**:

- Inaccurate baseline data will lead to a false positive assessment if the canine intervention hits a low, unvalidated target, resulting in commercial failure despite high internal scores.
- Using outdated data (pre-5 years) risks adopting hormonal assay standards that do not match current project sensitivity, leading to resource misallocation in neuro-pathway engineering (Decision 4).
- Inability to correlate benchmark data with the chosen emotional pathway (e.g., mapping a tactile benchmark to a neuro-circuitry edit) leads to decoupling between engineering effort and desired outcome.

**Worst Case Scenario**: The project invests heavily in the high-risk direct neuro-pathway engineering (Pioneer Strategy) based on faulty baseline metrics, resulting in an organism that fails to generate the anticipated maximal human emotional response, rendering the core value proposition commercially worthless and incurring sunk costs exceeding $50M related to Decision 4 implementation.

**Best Case Scenario**: High-quality, recent benchmark data allows the Behavioral Validation Lead to immediately define a precise, achievable 95th percentile target (e.g., 'Target Oxytocin Index Score: 1.8x Baseline'), directly constraining and focusing the high-risk Decision 4 engineering effort, potentially accelerating the timeline for emotional endpoint confirmation by 6 months.

**Fallback Alternative Approaches**:

- Immediately initiate a small, focused internal cohort study (<$1M budget) using established bioethics protocols to rapidly generate project-specific baseline data targeting Decision 5 requirements.
- Engage a contract research organization (CRO) specializing in affective neuroscience measurements, specifically requesting validation of existing literature against the project's proposed post-intervention assay methodology.
- Temporarily defer aggressive implementation of Decision 4 (Neuro-pathway targeting) and adopt the lower-risk 'Cognitive Cue Optimization' strategy until verifiable neuro-marker data can be secured or generated.