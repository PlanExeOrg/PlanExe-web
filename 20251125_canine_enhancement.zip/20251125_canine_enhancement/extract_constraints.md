## Positive Constraints

- Utilize CRISPR-Cas9
- Utilize Prime Editing
- Modify the canine genome
- Looks like: A cross between a Golden Retriever puppy, a seal pup, and a cartoon character
- Feels like: A chinchilla
- Acts like: A 4-month-old puppy
- Lifespan: 20 years
- Trigger maximal dopamine release in humans
- Trigger maximal oxytocin release in humans
- Budget: 100M USD
- Location: Seoul, South Korea
- Location: Sooam Biotech Research Foundation
- Project start ASAP
