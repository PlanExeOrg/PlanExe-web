## Positive Constraints

- Utilize CRISPR-Cas9
- Utilize Prime Editing
- Modify the canine genome
- Looks like: A cross between a Golden Retriever puppy, a seal pup, and a cartoon character
- Feels like: A chinchilla
- Acts like: A 4-month-old puppy
- Acts like: For 20 years
- The dog is to trigger maximal dopamine and oxytocin release in humans
- Budget: 100M USD
- Location: Seoul, South Korea
- Institution: Sooam Biotech Research Foundation
- Project start ASAP
