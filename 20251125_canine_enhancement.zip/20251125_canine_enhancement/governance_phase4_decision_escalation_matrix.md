**Technical Deadlock on Implementing Custom RNP Delivery System (Decision 1)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Majority vote of PSC members, with PSC Chair holding the deciding vote in a tie.
Rationale: The choice between custom RNP and backup viral vectors impacts core technical architecture and risks exceeding the 'Project Week 6' timeline for selection.
Negative Consequences: If the deadlock persists beyond established pivot timelines, it risks a 12-month delay or severe budget overrun (Risk 1).

**Proposed IP Joint Venture Structure Granting 90% External Rights (Decision 2)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Final ratification requires consensus agreement from PSC members, factoring in CFO's assessment of ROI deviation.
Rationale: This decision dictates long-term financial returns and resource control, potentially sacrificing significant future revenue against upfront capital demands, which requires the CFO and CSO's joint strategic approval.
Negative Consequences: If the successful custom RNP is developed, the organization risks capturing minimal ROI due to unfavorable vesting terms (Critical Missing Assumption 3).

**Regulatory Moratorium on Direct Neuro-Pathway Engineering (Decision 4)**
Escalation Level: Bioethics, Compliance, and Regulatory Review Board (BCRRB)
Approval Process: BCRRB Veto Power or immediate halt of related activities pending review; if unresolved, escalation to PSC.
Rationale: Direct manipulation of human neurochemical triggers is the highest ethical and regulatory risk (Risk 3). The BCRRB has veto power over activities impacting human subject testing compliance.
Negative Consequences: Operational shutdown in Seoul for 18-36 months, resulting in potential $15M sustainment cost and severe project timeline delay (Risk 3).

**Emerging Pathology Requires Termination of Established Longevity Cohorts (Risk 2)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC vote required following assessment by the Senior Pathologist/Toxicologist member of the BCRRB.
Rationale: Termination of cohorts due to oncogenesis (Risk 2) represents a potential $50M sunk cost and failure of the core 20-year product proposition, exceeding CPET's expenditure authority.
Negative Consequences: Complete project failure with projected $50M sunk cost if pathology manifests late, invalidating the entire long-term investment.

**Budgetary Projection Indicates Inability to Fund 20-Year Husbandry Liability (Missing Assumption 2)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: CFO and Executive Sponsor must present a remediation plan for securing future operational liability funding, approved by PSC consensus.
Rationale: The operational cost model for 20 years of specialized housing ($20M projected liability) impacts long-term viability and requires strategic financial commitment outside the initial R&D budget.
Negative Consequences: Failure to secure funding devalues the viable derived product/lines by the extent of the uncovered liability (estimated $20M).

**Technical Deadlock on Aesthetic Synthesis Leading to Emotional Score Below 75% Baseline**
Escalation Level: Bioethics, Compliance, and Regulatory Review Board (BCRRB)
Approval Process: BCRRB audit and mandatory review regarding conflict between aesthetics (Decision 9) and emotional outcome (Decision 5). Can issue a 'Halt Layering' directive.
Rationale: When aesthetic goals actively undermine the commercial value proposition (maximal emotional release), the decision shifts from technical execution (CPET) to ethical assurance regarding product goal alignment.
Negative Consequences: Failure to satisfy the primary commercial value proposition (emotional trigger), resulting in a 'beautiful failure' and 100% loss of market potential due to unpredictable human response.