### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic oversight given the project's revolutionary ambition, $100M budget, and critical dependency on fundamental technical choices (e.g., Prime Editing vs. CRISPR, Longevity vs. Youthfulness). This body provides the necessary strategic control over the core 'Pioneer' path.

**Responsibilities:**

- Approve Phase Gate transitions and commitment release for subsequent budget tranches.
- Review critical risk profiles (Technical, Geopolitical, Ethical) and authorize mitigation funding releases.
- Final authority on any decision requiring budget fluctuation exceeding $5M or timeline extension beyond 3 months.
- Oversight of overall project alignment with the business purpose (maximal human emotional release).
- Approve major changes to the Intellectual Property Capture Strategy (Decision 10).

**Initial Setup Actions:**

- Formalize and ratify the Project Charter and Terms of Reference (ToR).
- Elect the Chair and define quorum requirements.
- Establish the $5M financial threshold for escalation.

**Membership:**

- Project Sponsor (Chair)
- Project Principal Investigator (PI)
- Head of Finance/Budget Controller (Internal)
- Chief Legal Counsel (Internal, focusing on IP/Regulatory Strategy)
- External Strategic Advisor (Independent chairing the audit functions)

**Decision Rights:** Strategic direction, major scope changes, budget expenditures over $5M, approval of Phase 1 completion leading to operational licensing application, and ratification of Longevity Threshold (Decision 13).

**Decision Mechanism:** Majority vote (51%). In case of a tie, the Project Sponsor (Chair) has the casting vote, documented with justification.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of Critical Path Status vs. Timeline (Longevity & Neurochemistry Progress)
- High-Level Risk Register Review and Approval of Mitigation Spending
- Financial Burn Rate Audit vs. Allocation Assumptions (Decision 16)
- Review of Bioethics Consortium feedback (Decision 6)

**Escalation Path:** Issues that require immediate organizational mandate or compromise the 20-year lifespan goal are escalated from the PSC directly to the ultimate approving board/Executive Committee of the funding organization.
### 2. Core Project Management Team (CPMT)

**Rationale for Inclusion:** Necessary for managing the day-to-day execution of the highly complex, integrated 'Pioneer' strategy, balancing the dual technological tracks (CRISPR/Prime Editing) and managing the expatriate validation team interface.

**Responsibilities:**

- Manage operational aspects of the $100M budget, releasing funds <= $500k/transaction.
- Oversee day-to-day integration between the Sooam team and the Expatriate Validation Team (Risk 6 mitigation).
- Manage inventory, particularly high-cost Prime Editing reagents (Decision 12), ensuring expenditure aligns with efficiency targets.
- Coordinate technical efforts across all engineering disciplines (Morphology, Longevity, Neurochemistry).
- Maintain auditable logs for all waste stream neutrality procedures (Assumption Q6).

**Initial Setup Actions:**

- Develop detailed, integrated Work Breakdown Structure (WBS) aligned with key strategic decisions.
- Finalize SOPs for inter-team communication and data exchange with the Expatriate Team Lead.
- Establish the $500,000 operational expenditure threshold for internal approval.

**Membership:**

- Project Manager (Chair/Lead)
- Lead Molecular Biologist (Sooam)
- Expatriate Validation Team Lead (Location 2)
- Lead Systems Bioinformatician (Responsible for sequencing fidelity)

**Decision Rights:** Operational scheduling, resource allocation adjustments below $500k, technical protocol adjustments provided they do not alter the core strategic choices ratified by the PSC (e.g., modality choice or longevity threshold).

**Decision Mechanism:** Consensus among the four core members. Disputes are escalated immediately to the Project PI.

**Meeting Cadence:** Daily Stand-up (Technical Focus); Bi-weekly Detailed Status Review

**Typical Agenda Items:**

- Review of Day's Lab Workload and Resource Needs
- Reagent Consumption Tracking vs. Budget Buffer (Decision 16)
- Review of Bi-weekly technical progress reports from both Sooam and Expatriate teams
- Compliance Check: Waste Stream Inactivation Logs Verification

**Escalation Path:** Any inter-disciplinary technical conflict, resource request exceeding $500k, or discovery of early failure in a critical marker (e.g., telomerase activity shift, Risk 4) must be escalated immediately to the Project Steering Committee (PSC).
### 3. Bioethics, Compliance, and Regulatory Assurance Group (BCRAG)

**Rationale for Inclusion:** Due to the extremely high risk associated with non-therapeutic germline editing and the project's reliance on geopolitical alignment (Sooam/Korea), a dedicated, impartial assurance body is mandatory to manage Decision 6 and enforce ethical boundaries required for long-term viability and funding continuity.

**Responsibilities:**

- Ensure continuous compliance with South Korean bio-safety regulations and international ethical guidelines.
- Audit and validate the process for achieving confidential non-governmental pre-approval (Assumption Q4).
- Provide independent technical review of the Life-Markers Thresholds (Assumption Q5) before any implantation of critical longevity edits.
- Oversee the IP transfer documentation integrity between Sooam and Location 3 (Review Issue 3).
- Vet all communications materials concerning the project's goals prior to external release (Risk 8 mitigation).

**Initial Setup Actions:**

- Establish formal communication channels with the International Bioethics Oversight Consortium.
- Review and approve the initial ethical risk assessment document.
- Define the scope and reporting structure for external audits of containment protocols (Assumption Q6).

**Membership:**

- Chief Legal Counsel (PSC Member, Chairing)
- Lead Regulatory Liaison (Expatriate Team Member)
- Internal Bioethics Officer (If applicable, otherwise an independent external legal expert)
- A designated observer from the Financial Backers group (Non-voting assurance role)

**Decision Rights:** Authority to issue 'Stop Work' directives concerning specific batches of experimental embryos or specific operational protocols if immediate non-compliance with established environmental or ethical mandates is detected (subject to PSC override). Formal recommendation on regulatory filing strategy.

**Decision Mechanism:** Unanimous agreement required on 'Stop Work' directives. Standard review decisions passed by two-thirds majority.

**Meeting Cadence:** Bi-monthly, aligning closely with PSC scheduling.

**Typical Agenda Items:**

- Review of Regulatory Application Status and Timeline Projections (vs. Administrative Risks)
- Report on Waste Stream Neutralization Audit Findings
- Review of Life-Markers Protocol Adherence (Longevity Governance)
- Assessment of Public Relations Stance vs. Ethical Commitments

**Escalation Path:** Immediate escalation to the PSC Chair upon discovery of any evidence suggesting willful bypassing of BSL-2+ containment, or failure to secure the necessary governmental operational license within the established contingency timeline.