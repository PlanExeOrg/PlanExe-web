### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Required for high-level strategic governance over a $100M moonshot project involving extreme novelty (neuro-engineering, 20-year lifespan). The PSC must manage the primary tension between achieving 'maximal performance' (Pioneer Strategy) and adhering to the fixed budget and time constraints.

**Responsibilities:**

- Approve major strategic shifts outside defined tolerance bands (e.g., pivoting away from Pioneer strategy, changing the 20-year longevity target).
- Review and approve capital expenditure thresholds exceeding $5M USD or deviations in the RNP development timeline exceeding 3 months.
- Overall risk appetite setting and oversight of catastrophic risks (e.g., Regulatory Blockade on Neuro-Pathway Targeting).
- Final decision authority on IP/JV terms ratification (Decision 2) post-negotiation, ensuring alignment with projected ROI.
- Approve the final 'Maximal Emotional Release' success metric (Decision 5) before commitment to Phase 2 trials.

**Initial Setup Actions:**

- Finalize and approve the Project Charter and Governance Terms of Reference (ToR).
- Establish and communicate the $5M expenditure threshold for strategic review.
- Elect a neutral Chair from the senior organizational sponsors.
- Review and approve the initial $15M IP negotiation budget allocation.

**Membership:**

- Chief Scientific Officer (Chair)
- Chief Financial Officer (Budget Authority)
- Executive Sponsor for Innovation Portfolio
- Lead Legal/IP Counsel (Non-voting advisor on IP structure)
- External Biotechnology Advisor (Independent Assurance Role)

**Decision Rights:** Strategic direction, budget approval > $5M, major scope/timeline changes, final ratification of IP structure and regulatory pivot points.

**Decision Mechanism:** Consensus preferred. Majority vote (simple majority of voting members) required for approval. In case of a tie, the Chief Scientific Officer (Chair) casts the deciding vote, advised by the External Biotechnology Advisor.

**Meeting Cadence:** Bi-weekly during the first 6 months (Phase 1 setup), monthly thereafter.

**Typical Agenda Items:**

- Review of catastrophic risks (R1, R2, R3) and critical path health.
- Approval of milestone payments related to Sooam JV vesting.
- Review of regulatory status for Neuro-Pathway Targeting (Decision 4).
- Verification of budget burn rate against $100M ceiling.

**Escalation Path:** Decisions requiring organizational mandates outside the immediate project budget or involving external regulatory intervention beyond the Project Lead's authority are escalated to the sponsoring organization's Executive Committee.
### 2. Core Project Execution Team (CPET)

**Rationale for Inclusion:** Directly responsible for the day-to-day management and technical execution of the Pioneer strategy, including RNP development, aesthetic synthesis, and initial behavioral validation, operating below the strategic financial threshold.

**Responsibilities:**

- Manage technical path for implementing custom RNP delivery system (Decision 1).
- Oversee the Aesthetic Definition Iteration Cycle (Decision 6) and prioritize genomic layering (Decision 9).
- Manage operational budget, including procurement of reagents (Decision 10) up to threshold.
- Implement and manage the Behavioral Manifestation Trigger Validation Schedule (Decision 8).
- Manage operational risks (R1, R5, R7) and report status to the PSC weekly.

**Initial Setup Actions:**

- Establish detailed Work Breakdown Structure (WBS) for RNP development sprints.
- Define and document the 6-month pivot criteria for the RNP system (R1 Mitigation).
- Formalize internal technical sign-off procedures for cohort selection based on genomic purity.
- Appoint a dedicated Risk Manager focusing on operational (R5, R7) and technical execution (R1, R6).

**Membership:**

- Project Director (Chair, day-to-day authority)
- Lead Genomic Engineer (RNP/Prime Editing Specialist)
- Lead Bioethicist/Regulatory Coordinator (Responsible for internal compliance)
- Animal Husbandry Lead (Responsible for carrier/cohort management)
- Budget Controller (Tracking expenditure < $5M threshold)

**Decision Rights:** Operational decisions, technical execution paths below the $5M threshold, selection of surrogate carriers, minor scope adjustments within the approved Project Charter tolerances, all budget expenditures up to $5M.

**Decision Mechanism:** Majority vote of CPET members. The Project Director breaks ties on operational matters. Consensus required for deviations from the validated genomic target loci.

**Meeting Cadence:** Daily stand-ups; Technical Working Group meetings three times per week.

**Typical Agenda Items:**

- Review of editing efficiency metrics (on/off-target rates).
- Status update on RNP stability and reagent stock (R7).
- Review of behavioral/aesthetic results from active cohorts (R6 check).
- Operational budget tracking against monthly burn rate.

**Escalation Path:** Unresolved technical deadlock, budget variance projections exceeding 15% of monthly spend, or any emerging risk with High/High severity (R1, R2, R3) are escalated immediately to the Project Steering Committee (PSC).
### 3. Bioethics, Compliance, and Regulatory Review Board (BCRRB)

**Rationale for Inclusion:** Absolutely necessary due to the high-risk decisions involving germline editing, direct neuro-pathway manipulation (Decision 4), and the unique 20-year longevity constraint. This body provides independent assurance on ethical implementation and regulatory navigation in sensitive jurisdictions (South Korea).

**Responsibilities:**

- Oversee compliance with South Korean Bioethics Act and MFDS requirements (Risk 3).
- Provide binding internal sign-off on all testing involving human observers for emotional outcomes (Decision 4/5 compliance).
- Audit adherence to standards for animal welfare during long-term juvenile maintenance (Risk 5).
- Review and sign off on the regulatory pivot plan should direct neuro-pathway targeting (Pioneer Choice) face a moratorium. (Addresses Assumption Issue 1).
- Oversee the external validation audit of the Human Emotional Outcome Pathway results.

**Initial Setup Actions:**

- Retain specialized international Bioethics Counsel to conduct the mandated Regulatory Impact Assessment (RIA) on Decision 4 within 90 days.
- Establish formal relationship with Sooam's internal ethics board.
- Define the formal escalation criteria for internal reporting on ethical violations or conflicts of interest (leveraging audit findings).

**Membership:**

- Designated Institutional Legal/Compliance Officer (Chair)
- Lead Bioethicist (from CPET, non-voting status for CPET operations)
- External Bioethics & Regulatory Specialist (Independent Member)
- Senior Pathologist/Toxicologist (Focus on Risk 2 mitigation)

**Decision Rights:** The BCRRB has veto power over any project activity deemed non-compliant with South Korean Bioethics Law or which fails to satisfy preparatory requirements for human subject testing related to neuro-pathway manipulation. Can halt specific cohorts/protocols pending remediation.

**Decision Mechanism:** Requires unanimous approval for decisions impacting regulatory filings or human trials. Standard compliance verification decisions are approved by 2/3 majority.

**Meeting Cadence:** Monthly for the first year, shifting to quarterly review once stable germline is achieved, with immediate ad-hoc sessions triggered by regulatory inquiries or adverse event reports.

**Typical Agenda Items:**

- Review of RIA progress on Decision 4 feasibility.
- Audit findings review from CPET's internal compliance logs.
- Review of animal welfare standards for longevity cohorts (Risk 5).
- Assessment of public disclosures relating to germline modification.

**Escalation Path:** If a compliance deadlock prevents the project from meeting critical regulatory milestones (e.g., MFDS application deadlines), the BCRRB escalates the conflict, along with specific mitigation recommendations, directly to the Project Steering Committee (PSC) for strategic resolution.