### 1. Project Sponsor drafts initial Terms of Reference (ToR) for Project Steering Committee (PSC)

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**


### 2. Circulate Draft PSC ToR for review by nominated members

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary on PSC ToR

**Dependencies:**

- Draft PSC ToR v0.1

### 3. Senior Management formally appoints Chair of the PSC

**Responsible Body/Role:** Senior Management

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for PSC Chair

**Dependencies:**

- Feedback Summary on PSC ToR

### 4. Hold initial PSC meeting to finalize ToR and establish governance structure

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC ToR
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email for PSC Chair

### 5. Project Sponsor drafts initial Terms of Reference (ToR) for Core Project Execution Team (CPET)

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft CPET ToR v0.1

**Dependencies:**

- Approved PSC ToR

### 6. Circulate Draft CPET ToR for review by nominated members

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary on CPET ToR

**Dependencies:**

- Draft CPET ToR v0.1

### 7. PSC formally appoints Chair of the CPET

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for CPET Chair

**Dependencies:**

- Feedback Summary on CPET ToR

### 8. Hold initial CPET meeting to finalize ToR and establish operational tasks

**Responsible Body/Role:** Core Project Execution Team (CPET)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved CPET ToR
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email for CPET Chair

### 9. Project Sponsor drafts initial Terms of Reference (ToR) for Bioethics, Compliance, and Regulatory Review Board (BCRRB)

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Draft BCRRB ToR v0.1

**Dependencies:**

- Approved CPET ToR

### 10. Circulate Draft BCRRB ToR for review by nominated members

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Feedback Summary on BCRRB ToR

**Dependencies:**

- Draft BCRRB ToR v0.1

### 11. PSC formally appoints Chair of the BCRRB

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for BCRRB Chair

**Dependencies:**

- Feedback Summary on BCRRB ToR

### 12. Hold initial BCRRB meeting to finalize ToR and establish compliance oversight tasks

**Responsible Body/Role:** Bioethics, Compliance, and Regulatory Review Board (BCRRB)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved BCRRB ToR
- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Email for BCRRB Chair