### 1. Project Sponsor formally issues the mandate for establishing the Governance Framework and appoints the Project Manager (PM) and the Interim Chair for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1, Day 1

**Key Outputs/Deliverables:**

- Formal Appointment Letters (PM & Interim PSC Chair)
- Project Kick-off Authorization Document

**Dependencies:**

- Project Charter Finalized

### 2. Interim PSC Chair, supported by the newly appointed Project Manager, directs the drafting of the Governance Implementation Plan for all defined bodies.

**Responsible Body/Role:** Interim PSC Chair / Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Governance Implementation Roadmap (This Document Structure)

**Dependencies:**

- Formal Appointment Letters Issued

### 3. Project Manager drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), including membership definition and decision thresholds (e.g., $5M financial threshold).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1 - Week 2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Draft Governance Implementation Roadmap Complete
- Governance Body Definitions Available

### 4. Project Sponsor formally appoints the identified PSC Chair and confirms the initial membership list.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Formal PSC Appointment Notification Issued
- Final PSC Membership List Confirmed

**Dependencies:**

- Draft PSC ToR v0.1 Completed

### 5. The newly constituted Project Steering Committee (PSC) formally ratifies its own Terms of Reference (ToR) and approves initial expenditures required for establishing secondary governance structures.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3 (PSC First Meeting)

**Key Outputs/Deliverables:**

- Ratified PSC ToR
- Approval of Governance Setup Budget

**Dependencies:**

- Formal PSC Appointment Notification Issued

### 6. Project Manager drafts initial ToR and Member Appointment Notices for the Core Project Management Team (CPMT) and the Bioethics, Compliance, and Regulatory Assurance Group (BCRAG), based on ratified PSC guidelines.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft CPMT ToR v0.1
- Draft BCRAG ToR v0.1

**Dependencies:**

- Ratified PSC ToR

### 7. PSC Chair reviews and approves the draft ToRs for CPMT and BCRAG, and authorizes the Project Manager to issue formal confirmations to the nominated members.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved CPMT/BCRAG ToRs
- Issued Membership Confirmation Letters for CPMT and BCRAG

**Dependencies:**

- Draft CPMT/BCRAG ToR v0.1 Completed

### 8. The newly confirmed members of the Core Project Management Team (CPMT) convene to formally elect the Project Manager as Chair and ratify the CPMT operational procedures.

**Responsible Body/Role:** Core Project Management Team (CPMT)

**Suggested Timeframe:** Project Week 5 (CPMT First Meeting)

**Key Outputs/Deliverables:**

- Ratified CPMT ToR (including $500k operational spending threshold)
- Finalized Initial Integrated WBS

**Dependencies:**

- Issued Membership Confirmation Letters for CPMT and BCRAG

### 9. The Chief Legal Counsel (as BCRAG Chair) directs the drafting of mandatory compliance sign-offs, linking the BCRAG charter directly to the Bioethics/Regulatory Milestones (Assumption Q4) and Safety Triggers (Risk 4).

**Responsible Body/Role:** Chief Legal Counsel (Chairing BCRAG)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- BCRAG Compliance Mandate Document
- Initial Protocol for Ethical Review Submission Timelines

**Dependencies:**

- Approved CPMT/BCRAG ToRs
- BCRAG Membership Confirmed

### 10. The Bioethics, Compliance, and Regulatory Assurance Group (BCRAG) holds its inaugural meeting to ratify its Charter and establish formal reporting channels with the International Bioethics Oversight Consortium.

**Responsible Body/Role:** Bioethics, Compliance, and Regulatory Assurance Group (BCRAG)

**Suggested Timeframe:** Project Week 6 (BCRAG First Meeting)

**Key Outputs/Deliverables:**

- Ratified BCRAG ToR and Operating Procedures
- Documented communication link to External Bioethics Consortium

**Dependencies:**

- BCRAG Compliance Mandate Document

### 11. CPMT develops the detailed budget tracking mechanism, specifically ring-fencing the contingency buffer funds as per Decision 16 and allocating initial overhead for the Expatriate Validation Team (Risk 3 mitigation).

**Responsible Body/Role:** Core Project Management Team (CPMT)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Budget Tracking & Contingency Allocation System v1.0
- Initial Procurement Request for Expatriate Team Mobilization Costs

**Dependencies:**

- Ratified CPMT ToR
- PSC Approval of Governance Setup Budget

### 12. PSC formally authorizes the CPMT to commence operational activities, including the hiring/mobilization of the Expatriate Validation Team and the initiation of the bacteriophage delivery system R&D track (Pioneer Strategy).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Operational Green Light Authorization
- Approved Mobilization Plan (Including Location 2 setup commencement)

**Dependencies:**

- Budget Tracking & Contingency Allocation System v1.0 Complete
- CPMT & BCRAG fully constituted