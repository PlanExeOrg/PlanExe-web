## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers address the core tensions between efficacy, budget stability, and long-term viability. Critical levers focus on defining success (Emotional Metric), ensuring the 20-year promise (Longevity Constraint), and engineering the core value function (Emotional Pathway Sourcing). High impact levers control the technical implementation (Editing Pathway) and financial structure (IP Alignment/Budget Allocation vs. Carriers), which manage risks to the budget and future commercialization.

### Decision 1: CRISPR-Cas9 implementation pathway selection
**Lever ID:** `44608151-cc7d-41f2-a5fc-f951a91394b5`

**The Core Decision:** This lever governs the foundational choice between established CRISPR-Cas9 protocols or more advanced, proprietary editing systems like Prime Editing for performing the genome modifications. Key success is measured by the efficiency of germline insertion validated against off-target effects. Choosing standard CRISPR accelerates initial velocity but increases validation overhead, directly impacting the budget ceiling.

**Why It Matters:** Choosing standard CRISPR-Cas9 allows immediate leveraging of established protocols and potentially faster throughput for initial germline insertion validation. However, this high-precision editing pathway may necessitate more off-target validation cycles, consuming significant budget resources before primate testing stabilizes the phenotype linkage. The trade-off involves accepting higher downstream risk of unintended consequences for the benefit of faster initial developmental velocity.

**Strategic Choices:**

1. Deploy base CRISPR-Cas9 system focused solely on the target locus known for aesthetic markers and validated oxytocin pathway genes.
2. Begin with Prime Editing targeting only the 'act like' behavioral phenotype, treating the aesthetic features as secondary, achievable modifications later.
3. Develop a custom ribonuclear protein delivery system optimized for canine zygotes, bypassing standard viral vectors to maximize integration efficiency but requiring proprietary tooling.

**Trade-Off / Risk:** Focusing exclusively on established CRISPR risks missing the subtle combinatory edits required for the 'cartoon/seal' appearance, whereas proprietary tooling increases initial setup risk against the strict $100M ceiling.

**Strategic Connections:**

**Synergy:** It directly influences Aesthetic Synthesis via Directed Mutagenesis Layering by dictating the toolset available for complex phenotypic expression.

**Conflict:** It conflicts with Sourcing of Proprietary Editing Complementary Factors, as standardized CRISPR bypasses the need to develop or procure custom delivery systems.

**Justification:** *High*, This determines the foundational technology (CRISPR vs. Prime Editing) for all genetic changes. It directly dictates initial speed versus downstream validation cost, representing a core technical trade-off impacting the $100M budget ceiling.

### Decision 2: Intellectual Property and Institutional Alignment Structure
**Lever ID:** `48438a7e-f010-4052-bd3a-3b8a95991d66`

**The Core Decision:** This structures the financial and operational relationship with Sooam Biotech, determining future revenue streams and resource access. Success relies on securing favorable IP terms without jeopardizing the immediate project timeline or exceeding the $100M budget cap. This sets the ground rules for commercialization and intellectual control over the novel genome construct.

**Why It Matters:** Formalizing the ownership structure regarding the final germline construct immediately dictates future commercialization pathways and required regulatory navigation in South Korea and potential export markets. A 50/50 split with Sooam reduces upfront capital outlay but permanently caps the institution's share of the eventual licensing revenue, whereas full ownership requires substantially more upfront negotiation and potentially delays the start date awaiting legal clearance.

**Strategic Choices:**

1. Negotiate a royalty-free licensing agreement from Sooam in exchange for immediate top-tier access to all resultant cell lines for non-commercial research endeavors globally.
2. Structure the relationship as a joint venture where the budget funds all primary development, granting the external entity 90% of IP rights contingent on timely delivery of the phenotype.
3. Insist on complete transfer of all background IP related to the specific editing vectors used by Sooam, trading a larger fixed upfront milestone payment for future operating flexibility.

**Trade-Off / Risk:** The IP structure determines long-term monetization potential against the immediate need for rapid resource access; high upfront transfer demands significant immediate cash reserves that strain the $100M limit.

**Strategic Connections:**

**Synergy:** It synergizes with Budget Allocation Between Iteration Cohorts and Surrogate Carriers by defining how much future revenue the project can leverage for upfront investment.

**Conflict:** It directly conflicts with Regulatory Pathway for Germline Modification, as aggressive IP demands can delay or complicate critical necessary approvals in the host country.

**Justification:** *High*, This lever governs commercial viability and long-term monetization by defining the relationship and IP ownership with Sooam. It creates a major tension between upfront capital demands ($100M) and future revenue stream control.

### Decision 3: Management of the 20-Year Behavioral Longevity Constraint
**Lever ID:** `8f5a2535-693f-4830-ac6e-cccdf72094d2`

**The Core Decision:** This focuses on embedding stable epigenetic mechanisms necessary to maintain youthful canine physiology for two decades. Success requires designing complex, multi-stage gene expression switches within the initial editing payload. Failure here means the project yields an adult dog phenotype, invalidating the core longevity promise and requiring costly future somatic maintenance.

**Why It Matters:** Committing operational resources to maintaining juvenile canine physiology for two decades necessitates a specific, intensive epigenetic maintenance protocol beyond the initial germline modification success. This requires designing multi-stage gene expression switches that must remain stable across aging cycles, significantly complicating the initial editing phase and consuming critical optimization cycles early on.

**Strategic Choices:**

1. Integrate the 20-year longevity requirement directly into the initial Prime Editing strategy, focusing on manipulating the telomerase and growth hormone signaling pathways aggressively.
2. Treat the longevity as a post-launch maintenance problem, achieving the initial aesthetic and emotional goals first, and planning for a less expensive, non-germline somatic intervention later.
3. Limit the target lifespan to 10 years initially, accepting that the product will require full re-engineering or replacement sooner to minimize complexity in the initial proof-of-concept phase.

**Trade-Off / Risk:** Front-loading the 20-year longevity requirement dramatically increases the complexity of target validation, potentially consuming the entire budget before the aesthetic traits are even reliably expressed.

**Strategic Connections:**

**Synergy:** It demands tight integration with CRISPR-Cas9 implementation pathway selection to ensure the chosen editing tool can handle the complexity of multi-gene longevity targets.

**Conflict:** It severely constrains Aesthetic Definition Iteration Cycle, as engineering for 20-year stability consumes significant editing capacity that could otherwise be used for rapid aesthetic tuning.

**Justification:** *Critical*, This is a foundational technical/design constraint critical to the 20-year promise. Failure here invalidates the entire product proposition, forcing complex, early epigenetic engineering that conflicts with rapid aesthetic iteration.

### Decision 4: Human Emotional Outcome Pathway Sourcing
**Lever ID:** `819df18c-310c-4442-a8b7-8c9a6a60d274`

**The Core Decision:** This lever determines the mechanism used to generate the core project value: maximizing human emotional response via dopamine/oxytocin release. It forces a critical tradeoff between high-efficacy but high-risk direct neuro-pathway manipulation and lower-risk, indirect cognitive/sensory cue optimization. Success relies on quantifiable, sustained emotional scoring in human observation trials.

**Why It Matters:** The core value proposition relies on the 'maximal dopamine and oxytocin release' mechanism, which can be engineered through direct receptor up-regulation or through indirect cognitive triggers related to cuteness perception. Directly targeting neurotransmitter pathways might offer higher efficacy but introduces extreme regulatory risk and ethical complexity, whereas indirect cognitive tuning might be safer but yield lower quantifiable emotional impact.

**Strategic Choices:**

1. Implement direct, high-expression transcription factor overexpression targeting the primary neural pathways responsible for oxytocin signaling magnitude in human observers.
2. Focus exclusively on optimizing visual and auditory cues known to reliably trigger innate human nurturing responses, such as large eyes and high-frequency vocalization patterns.
3. Incorporate a novel, non-mammalian biochemical signaling mechanism that interfaces uniquely with human olfactory receptors to create a novel, addictive chemical signature.

**Trade-Off / Risk:** Directly upregulating human neurotransmitter pathways offers the strongest potential effect, but this shifts the project from advanced genetics into high-risk neuropharmacology impacting human users directly.

**Strategic Connections:**

**Synergy:** It is closely amplified by Defining the 'Maximal Emotional Release' Success Metric, as the chosen pathway dictates the complexity of the required measurement protocols.

**Conflict:** Conflict arises with Regulatory Pathway for Germline Modification, as direct neuropharmacological intervention introduces exponentially higher ethical and regulatory hurdles than purely aesthetic alterations.

**Justification:** *Critical*, This defines the *mechanism* for achieving the core value proposition (maximal emotional response). The choice between direct neuro-pathway targeting or indirect cognitive tuning is a fundamental ethical and efficacy trade-off.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 5: Defining the 'Maximal Emotional Release' Success Metric
**Lever ID:** `741fc8b9-d20d-4955-9751-72c02903234e`

**The Core Decision:** This lever defines the project's ultimate measure of success: the quantifiable neural response in humans. Anchoring on biological markers limits scope creep from subjective aesthetic demands, ensuring resources prioritize dopamine/oxytocin pathways. Success metrics must be established early to serve as hard decision gates, preventing indefinite pursuit of the 'cartoon character' feature.

**Why It Matters:** Establishing a quantifiable, externally validated proxy for 'maximal dopamine/oxytocin release' early anchors the project scope and provides clear Go/No-Go points, protecting the budget from indeterminate aesthetic development. Conversely, relying on subjective, qualitative human testimonials to gauge success introduces significant subjective drift and extends timelines indefinitely as aesthetic targets constantly shift toward the undefined 'cartoon character' goal.

**Strategic Choices:**

1. Anchor success exclusively on validated, quantifiable biological markers tracking cortisol reduction and standardized oxytocin spike measurements observed during controlled human interaction trials.
2. Adopt a tiered subjective rating scale where 80% of independent testers must score the experience above the 95th percentile of existing known stimuli (e.g., human infant holding).
3. De-prioritize the 'maximal release' clause initially, focusing only on achieving the two required physical traits (retention of puppy physicality and novel appearance) as minimum viable product.

**Trade-Off / Risk:** Quantifying emotional release provides necessary project gates, but rigid biological metrics might inadvertently select for a less appealing phenotype, contradicting the commercial goal of widespread adoption.

**Strategic Connections:**

**Synergy:** Strong metrics enable clear direction for Human Emotional Outcome Pathway Sourcing, ensuring interventions are biologically relevant to the desired response.

**Conflict:** It constrains Aesthetic Definition Iteration Cycle, as rigid biological gates may reject phenotypes that humans subjectively find appealing but fall outside the precise measurement window.

### Decision 6: Aesthetic Definition Iteration Cycle
**Lever ID:** `c338db9f-9e25-4b3c-939f-ea97bccbd4d7`

**The Core Decision:** This lever addresses the subjective visual goals ('seal pup', 'cartoon') through rapid feedback loops, requiring fast, parallel phenotypic screening. Success is defined by the speed at which human perception converges on the desired aesthetic. High iteration frequency helps meet market expectations but requires dedicating resources away from foundational genomic stability work.

**Why It Matters:** The subjective aesthetic goals ('seal pup' and 'cartoon character') require rapid, iterative testing against real-world stimuli to converge on a reproducible phenotype. Implementing high-frequency, low-fidelity visual screening dramatically speeds convergence but requires parallelizing animal husbandry, which stresses the operational budget allocated for the primary genetic work.

**Strategic Choices:**

1. Establish a rapid prototyping cohort using non-integrated gene expression to test aesthetic features via temporary modulation before committing to permanent germline targets.
2. Freeze the aesthetic target design immediately based on initial predictive 3D modeling and proceed with editing, accepting that user feedback will only occur post-delivery.
3. Dedicate a substantial portion of the available editing resources solely to phenotypic display features, accepting lower fidelity in the stability or longevity targets.

**Trade-Off / Risk:** Rapid aesthetic iteration speeds user acceptance but drains resources from the core, more difficult modifications relating to longevity and behavioral stability, introducing schedule risk to primary goals.

**Strategic Connections:**

**Synergy:** It maximizes utility when paired with Behavioral Manifestation Trigger Validation Schedule, allowing quick visualization of resulting behavioral/aesthetic combinations.

**Conflict:** It imposes high trade-offs against Management of the 20-Year Behavioral Longevity Constraint, as focusing iterative cycles on appearance diverts resources from complex, long-term epigenetic stability.

**Justification:** *Medium*, While important for market acceptance, the subjective aesthetics are secondary to the core biological goals (longevity, emotional release). This lever primarily manages the speed of subjective convergence versus stability goals.

### Decision 7: Regulatory Pathway for Germline Modification
**Lever ID:** `d165ab06-d94e-4c54-ac95-3d331ff90949`

**The Core Decision:** This lever governs the legal framework for the project, balancing rapid domestic progress in Seoul against the future commercial viability across global markets. Success prioritizes establishing a minimal viable regulatory compliance footprint quickly. Key metrics involve lead time until first animal testing approval versus the cost burden of maintaining parallel international standards readiness throughout the program.

**Why It Matters:** The choice of regulatory jurisdiction for initial clinical trials—either relying strictly on South Korean domestic frameworks or seeking early partnership with a US/EU lab for parallel path validation—incurs different costs and timeline risks. Strict adherence to the Seoul location may offer speed advantages due to existing institutional relationships but limits future global market entry without extensive re-validation.

**Strategic Choices:**

1. Limit all initial trials and public disclosures strictly to South Korean regulatory acceptance, avoiding immediate international scrutiny until the phenotype is fully stabilized and defensible.
2. Immediately initiate parallel regulatory filings with the FDA’s CBER, using the $100M budget to fund simultaneous compliance audits required by competing international standards.
3. Pursue a 'research-only' exemption pathway for the first three years, delaying commercial license applications to defer significant regulatory capital expenditure until technical proof is undeniable.

**Trade-Off / Risk:** Delaying international regulatory work simplifies near-term compliance but builds a massive future hurdle that may invalidate the investment if entry into larger Western markets is subsequently blocked.

**Strategic Connections:**

**Synergy:** It strongly synergizes with Intellectual Property and Institutional Alignment Structure by defining the jurisdictional scope for protecting novel genetic constructs immediately.

**Conflict:** It directly conflicts with Budget Allocation Between Iteration Cohorts and Surrogate Carriers, as advanced parallel international compliance drastically increases immediate capital expenditure demands.

**Justification:** *High*, The location (South Korea) and project type necessitate managing regulatory risk. This choice restricts market access and determines if concurrent compliance streams will rapidly consume the $100M budget.

### Decision 8: Behavioral Manifestation Trigger Validation Schedule
**Lever ID:** `27252fa5-2421-4ea2-bece-0ae8336e953c`

**The Core Decision:** This defines the testing schedule for achieving the complex behavioral outcomes: 'acts like a 4-month-old puppy for 20 years.' The schedule must validate subjective human interactions against objective physiological markers across a protracted timeframe. Success hinges on developing reliable early-stage proxies that accurately forecast long-term neurobehavioral stability and efficacy, minimizing wasted cohort investment.

**Why It Matters:** Adjusting when the 'chinchilla' tactile experience and '4-month puppy' activity are validated affects the project's critical path, as behavioral metrics are inherently subjective and longitudinal. Rushing this validation compresses the required developmental timeline, demanding premature culling of less successful lines, which risks discarding early genetic combinations necessary for the 20-year stability modeling.

**Strategic Choices:**

1. Implement a rolling, continuous behavioral challenge protocol starting immediately upon successful embryonic implantation, using predictive biometric proxies rather than waiting for full functional maturation.
2. Defer all significant 'acts like' validation until the offspring reach 18 months of age, ensuring the 20-year longevity hypothesis is tested against near-adult neurochemistry, despite the extensive time sink.
3. Establish surrogate mammalian models, perhaps early-onset primates, to simulate the required neurological response to the 'looks and feels' parameters to rapidly screen candidate lines before investing in full canine gestation.

**Trade-Off / Risk:** Using early biometric proxies accelerates the timeline to select candidates, but these proxies may fail to capture the nuanced neurochemical release dynamics required for the ultimate human interaction objective.

**Strategic Connections:**

**Synergy:** It crucially enables Management of the 20-Year Behavioral Longevity Constraint by providing the checkpoints needed to stress-test the long-term activity claims early on.

**Conflict:** Rushing this schedule conflicts with Aesthetic Synthesis via Directed Mutagenesis Layering, as concurrent focus on complex morphology interferes with the dedicated longitudinal observation windows needed.

**Justification:** *Medium*, This is the management schedule for one of the three core success criteria (behavior). It is highly dependent on the longevity constraint, making it important for risk mitigation, but not the absolute foundational choice.

### Decision 9: Aesthetic Synthesis via Directed Mutagenesis Layering
**Lever ID:** `6e2a9304-de8f-4471-a934-a9e688a4d52a`

**The Core Decision:** This involves the combinatorial strategy for integrating disparate aesthetic traits (mammalian realism, cartoon stylization) using sequential or parallel genetic manipulation passes. The scope covers skeletal, dermal, and expressive features necessary to achieve the desired novel appearance. Success metric is achieving the visual target while maintaining functional biological coherence required for the behavioral objectives.

**Why It Matters:** Achieving the required aesthetic blend ('Golden Retriever puppy, seal pup, cartoon character') necessitates layering edits affecting skeletal, dermal, and vocal structures, each presenting a unique biological interaction risk. Prioritizing the highly visible 'seal pup' morphology may require substantial perturbation of subcutaneous fat deposition pathways, which could inadvertently interfere with the required thermoregulation needed for prolonged lifespan activity.

**Strategic Choices:**

1. Employ a phased aesthetic approach, first stabilizing the overall canine structure analogous to the Golden Retriever base, then introducing 'seal pup' dermal thinning, and finally refining 'cartoon' features via minor facial proportion tuning.
2. Attempt massively parallel, simultaneous editing across all aesthetic targets in the first generation embryos, accepting high rates of catastrophic embryonic failure in exchange for potentially rapid convergence on the target look.
3. Focus initial efforts on editing the non-structural Hox genes known to influence cranial/facial soft tissue development, seeking pleiotropic effects that yield the 'cartoon' appearance without extensive bone manipulation.

**Trade-Off / Risk:** Massive parallel editing accelerates visual convergence but risks creating non-viable embryos or animals with compounded, unmanageable structural defects that contradict the 'chinchilla feel' comfort requirement.

**Strategic Connections:**

**Synergy:** This lever is highly dependent on Sourcing of Proprietary Editing Complementary Factors to ensure the necessary multi-site, high-fidelity edits can be reliably layered onto the embryo.

**Conflict:** Attempting to aggressively pursue this, especially via parallel editing, creates significant conflict with the Management of the 20-Year Behavioral Longevity Constraint due to compounding, unknown genetic instabilities.

**Justification:** *Medium*, This is the technical execution plan for the aesthetics. It is driven by the overarching Morphological Prioritization and constrained by the foundational editing pathway selection, making it a secondary consequence lever.

### Decision 10: Sourcing of Proprietary Editing Complementary Factors
**Lever ID:** `8c165407-39f9-40c5-aa65-0b281e982f5c`

**The Core Decision:** This addresses tool selection: relying on institutionally available reagents versus sourcing cutting-edge, optimized external editing systems for CRISPR/Prime Editor delivery. The scope is the immediate input purity and efficacy for the foundational edits. Success is measured by minimizing on-target failure rates and off-target mutations during the initial germline modifications, directly impacting cohort viability.

**Why It Matters:** Deciding whether to rely solely on Sooam's internal stock of specialized guide RNAs and cas-enzymes or to license optimized, third-party high-fidelity reagents for the initial modification passes. Internal reliance reduces immediate capital outlay but limits access to cutting-edge modifications that might improve editing specificity, potentially increasing off-target effects that require costly downstream clean-up or failed cohorts.

**Strategic Choices:**

1. Exclusively utilize pre-existing, established CRISPR/Prime Editor machinery resident at the Sooam facility to maintain operational simplicity and fixed cost expenditure.
2. Contractually procure cutting-edge, high-fidelity, third-party effector complexes validated for mammalian systems to maximize editing efficiency in the first generation.
3. Develop a parallel, in-house micro-synthesis pipeline specifically for novel guide RNA scaffolds optimized against the target sequence pool, sacrificing speed for control.

**Trade-Off / Risk:** Exclusively using internal reagents simplifies logistics, but licensing superior third-party components could significantly reduce off-target mutations, accelerating the time until stable phenotype expression.

**Strategic Connections:**

**Synergy:** Superior factors directly enhance the execution of CRISPR-Cas9 implementation pathway selection by maximizing the efficiency and accuracy of the initial genetic blueprint changes.

**Conflict:** Procuring high-cost, third-party factors immediately strains the Budget Allocation Between Iteration Cohorts and Surrogate Carriers by increasing upfront, non-recoverable component costs.

**Justification:** *Medium*, This controls the quality of the input tools for genetic editing, impacting error rates. It is strongly coupled with the Implementation Pathway Selection but is a sourcing decision rather than a core architectural choice.

### Decision 11: Morphological Trait Expression Prioritization Focus
**Lever ID:** `7ef76112-6fc7-4e36-8fa1-8409e7cabcc2`

**The Core Decision:** This lever determines the resource weight distribution across the three aesthetic templates defining the look. It manages the trade-off between maintaining the familiar (Retriever base) and introducing novelty (seal/cartoon traits). The key decision is how much genetic perturbation is acceptable to push towards novelty without sacrificing the viability or the underlying mammalian comfort factor.

**Why It Matters:** The aesthetic goal involves harmonizing three distinctly different visual baselines (Golden Retriever, seal pup, cartoon character), meaning resources must be heavily skewed toward defining which component dominates the final look. Over-allocating resources to the seal-pup contouring, for instance, risks violating the 'Golden Retriever' baseline expectation, which might alienate core target investors accustomed to established breeds.

**Strategic Choices:**

1. Aggressively prioritize the 'cartoon character' visual component through extreme morphological adjustments, accepting high deviation from mammalian structural plausibility for maximal novelty.
2. Divide modification efforts equally across the three source templates to ensure balanced, statistically average expression of each component in the resulting phenotype.
3. Anchor all modification efforts to the Golden Retriever structure, treating the seal pup and cartoon elements only as subtle, low-impact surface texture and feature accents.

**Trade-Off / Risk:** Prioritizing the 'cartoon' element risks creating a biologically incoherent form, which, despite novelty, may fail to satisfy the underlying mammalian comfort sought by the emotional response driver mechanism.

**Strategic Connections:**

**Synergy:** It must align closely with Aesthetic Synthesis via Directed Mutagenesis Layering, as this focus dictates the sequencing and intensity of editing passes performed across the genome.

**Conflict:** Aggressive prioritization of 'Cartoon' morphology conflicts with Human Emotional Outcome Pathway Sourcing, as extreme novelty might generate unpredictable, rather than maximal, designer human oxytocin spikes.

**Justification:** *Medium*, This governs resource skew among the visual components. It informs the necessary complexity of the layering effort but is subordinate to defining the core desired emotional outcome via Metric selection.

### Decision 12: Budget Allocation Between Iteration Cohorts and Surrogate Carriers
**Lever ID:** `1d0d754a-1aa1-43ce-a5aa-56a0b6e1d63e`

**The Core Decision:** This lever manages the $100M capital distribution between conducting extensive experimental breeding cohorts (statistical validation) and securing the necessary high-quality surrogate carrier capacity for gestation. Aggressive cohort scaling speeds up learning but depletes resources for physical execution, directly impacting the project's ability to gestate successful lines quickly.

**Why It Matters:** The $100M budget must balance the cost of multiple full-scale breeding cohorts (necessary for error correction) against the cost of acquiring and maintaining specialized, high-grade surrogate mothers required for gestation. Increasing the cohort size allows rapid statistical validation of editing efficacy but places extreme strain on the limited capital available for securing high-quality gestational services required to keep the timeline aggressive.

**Strategic Choices:**

1. Dedicate 70% of the budget exclusively to funding five simultaneous, large-scale breeding cohorts to maximize statistical assurance in the first two years of editing.
2. Invest heavily in optimizing non-invasive, artificial uterine environment technology to reduce reliance on live surrogate carriers, lowering operational overhead substantially.
3. Minimize cohort redundancy by only advancing lines that exceed a 95% purity threshold on single-cell sequencing, accepting a higher initial failure rate in early embryogenesis.

**Trade-Off / Risk:** Focusing majority capital on multiple breeding cohorts ensures rapid statistical insight, but it severely limits the budget available for securing the scarce, high-cost specialized surrogate capacity needed to gestate those successes.

**Strategic Connections:**

**Synergy:** This allocation directly affects the pace of Statistical Validation, which is key when paired with CRISPR-Cas9 implementation pathway selection, as more cohorts mean faster data acquisition on editing success.

**Conflict:** This lever strongly conflicts with Management of the 20-Year Behavioral Longevity Constraint, as accelerating cohort breeding to meet timelines risks skipping long-term monitoring required for longevity confirmation.

**Justification:** *High*, This is the primary control lever for managing the hard $100M budget against the critical path timeline. It forces a direct trade-off between statistical validation volume and successful physical execution/gestation.
