
## Documents to Create

### 1. Project Charter (CRISPR/Prime Editing Project)

**ID:** f96b7c2b-21d1-4396-b849-d5b362d70258

**Description:** Formal authorization document defining the project scope, objectives (including the 20-year longevity goal and maximal emotional outcome), budget ceiling ($100M USD), primary stakeholders, and preliminary success metrics (Decision 5). Type: Foundational Project Management Document. Audience: Executive Steering Committee, Sooam Leadership.

**Responsible Role Type:** Project Lead

**Primary Template:** PMI Project Charter Template

**Steps:**

- Confirm alignment with 'Pioneer' strategic path and core decision points.
- Incorporate the initial $100M budget and the December 31, 2026, foundational milestone.
- Secure initial sign-off from Sooam Executive Management and Project Sponsor.
- Document the initial high-level stakeholder list.

**Approval Authorities:** Project Sponsor, Sooam Biotech Executive Management

### 2. Initial Technical Pathway Specification: Editing System & Longevity Integration

**ID:** d722dfcc-18d0-436d-a2d8-bc22207ad07b

**Description:** High-level technical plan detailing the architecture for Decision 1 (CRISPR/Prime Selection) and Decision 3 (Longevity Integration). Must explicitly state the custom RNP development pathway chosen and the required scope for initial telomerase/GH pathway manipulation. Type: Technical Strategy Document.

**Responsible Role Type:** Lead Genomic Architect & Editor

**Primary Template:** Biotech Technology Selection Framework

**Steps:**

- Formalize the technical blueprint for the custom RNP system.
- Map the required genomic loci for 20-year longevity onto the chosen editing platform.
- Identify necessary parallel validation steps for AAV backup system (mitigation of Risk 1).
- Integrate initial performance threshold required for cohort progression.

**Approval Authorities:** Lead Genomic Architect & Editor, Longevity & Pathology Specialist

### 3. IP Joint Venture Negotiation Strategy & Custom RNP Vesting Proposal

**ID:** 0994ef06-7c94-4418-be75-4be668c8e9e5

**Description:** Document outlining the mandatory re-negotiated terms for Decision 2 (IP Alignment). Must prioritize retaining ownership/co-ownership of the custom RNP tooling value against the 90% revenue cession structure. Type: Legal/Negotiation Strategy Document.

**Responsible Role Type:** Financial Controller & IP Negotiator

**Primary Template:** Technology Transfer Negotiation Mandate

**Secondary Template:** Standard JV Agreement Outline

**Steps:**

- Model ROI under current 90% cession and determine minimum acceptable revenue capture.
- Draft specific legal language proposing co-ownership/buy-back for the custom RNP system (Recommendation 1).
- Define milestone triggers for IP vesting tied to technical delivery.
- Integrate required escrow structure for 20-year liability funding (Issue 2 mitigation).

**Approval Authorities:** Financial Controller & IP Negotiator, Project Lead, Sooam Biotech Executive Management (for final review)

### 4. Regulatory Protocol & Ethical Impact Assessment (RIA) Framework (Neuro-Pathway Focus)

**ID:** 8c713a0e-a2b4-49db-8863-440bd13d2ebd

**Description:** Framework outlining the schedule and specific scope for engaging specialized counsel to assess the regulatory risk associated with Decision 4 (Direct Neuro-Pathway Targeting). Must include the mandated structure for the Cognitive Cue Optimization fallback pathway. Type: Compliance & Strategy Report.

**Responsible Role Type:** Regulatory & Bioethics Strategist (Seoul Focus)

**Primary Template:** Regulatory Impact Assessment (RIA) Template

**Secondary Template:** Dual-Jurisdiction Compliance Mapping

**Steps:**

- Define scope/mandate for specialized bioethics counsel engagement (Issue 1 update).
- Document the technical specifications and required genetic targets for the Cognitive Cue Optimization fallback strategy (Decision 4, Choice 2).
- Establish the Yes/No/Pivot regulatory decision gates for Q1/Q2 Year 2.
- Define schedule for securing secondary jurisdiction consultation.

**Approval Authorities:** Regulatory & Bioethics Strategist (Seoul Focus), Project Lead

### 5. 20-Year Operational Liability Funding Model & Escrow Structure Plan

**ID:** 619227ec-dfdc-4c2e-9d86-5553082fae65

**Description:** Detailed financial calculation documenting the projected operational costs (husbandry, veterinary care, specialized housing) required to sustain successful cohorts for the full 20-year longevity requirement (Risk 5, Issue 2). Must propose the concrete mechanism for isolating and perpetually funding this liability via escrow/trust, tied to the IP agreement (Recommendation 3). Type: Financial Risk Mitigation Plan.

**Responsible Role Type:** Financial Controller & IP Negotiator

**Primary Template:** Long-Term Liability Funding Model

**Secondary Template:** Financial Escrow Requirement Document

**Steps:**

- Calculate the estimated $20M liability based on specialist input (Risk 5).
- Propose the percentage of future revenue/JV share required to fund a suitable escrow/trust.
- Draft the structural requirements for making this fund irrevocable post-R&D success.
- Integrate this structure into the IP Negotiation Strategy Document.

**Approval Authorities:** Financial Controller & IP Negotiator, Longevity & Pathology Specialist

### 6. Emotional Response Validation Protocol (ERVP)

**ID:** 50e31d26-e95e-4cef-81d1-1cc28f7cbd87

**Description:** Detailed Standard Operating Procedure (SOP) defining the methodology for quantifying Decision 5 (Maximal Emotional Release Success Metric). This must detail human trial structure, necessary hormonal assay frequency (oxytocin/cortisol), and the baseline against which success is measured. Type: Measurement Framework Document.

**Responsible Role Type:** Behavioral & Emotional Metric Validation Lead

**Primary Template:** Clinical Trial Protocol Template (Non-Therapeutic)

**Secondary Template:** Hormonal Assay SOP

**Steps:**

- Finalize the exact biological markers and quantifiable thresholds for 'maximal release'.
- Design the SOP for conducting controlled human-animal interaction trials (IRB planning input).
- Define the method for cross-validating objective biological markers against subjective rating scales (Decision 5).
- Establish the requirements for early success proxies that correlate with this ultimate metric.

**Approval Authorities:** Behavioral & Emotional Metric Validation Lead, Regulatory & Bioethics Strategist (Seoul Focus) [for human trials planning]

### 7. Aesthetic Synthesis Genetic Target Map (ASGTM)

**ID:** 05b419ec-96aa-44e2-8172-64b544299573

**Description:** Translates the subjective visual goals (Golden Retriever, seal pup, cartoon character) into a prioritized sequence of candidate genes/Hox clusters for the Lead Genomic Architect (Decision 9). Must indicate which edits are structural (skeleton) vs. soft tissue (dermal/fur). Type: Technical Specification Document.

**Responsible Role Type:** Aesthetics & Sensory Modeler

**Primary Template:** Gene Target Prioritization Matrix

**Secondary Template:** 3D Morphological Modeling Report Summary

**Steps:**

- Develop initial 3D models illustrating the convergence of the three aesthetic requirements.
- Map aesthetic features to specific genetic pathways (e.g., growth factors for dermal thinning for 'seal pup').
- Prioritize edits based on potential conflict with longevity/behavioral stability (Risk 6 analysis).
- Deliver final prioritized list to the Lead Genomic Architect for incorporation into the overall blueprint.

**Approval Authorities:** Aesthetics & Sensory Modeler, Lead Genomic Architect & Editor

### 8. Draft Regulatory Pivot Strategy: Cognitive Cue Optimization

**ID:** d9017fb2-be6f-4d0b-9169-355806d029d0

**Description:** Detailed plan specifying the immediate technical shift required in editing targets if the direct neuro-pathway approach (Decision 4, Choice 1) is halted by regulation. Focuses on defining the necessary modifications for optimizing visual/auditory cues (Choice 2) based on existing ethological data. Type: Technical Contingency Plan.

**Responsible Role Type:** Aesthetics & Sensory Modeler

**Primary Template:** Contingency Plan Template

**Secondary Template:** Behavioral Trigger Specification Outline

**Steps:**

- Review established ethology literature on known high-efficacy 'cuteness' cues in humans.
- Translate these cues into preliminary genetic targets for the Aesthetics Modeler.
- Outline the resource reallocation required from the Lead Genomic Architect if this pivot is triggered.
- Formalize the measurement requirements for the Behavioral Validation Lead for this fallback metric.

**Approval Authorities:** Lead Genomic Architect & Editor, Regulatory & Bioethics Strategist (Seoul Focus)

### 9. Risk/Reward Matrix: IP Vesting Scenarios vs. RNP Performance

**ID:** 3944e3ad-4fe5-4a43-b24f-07a71f225164

**Description:** Financial and technical matrix modeling the internal Return on Investment (ROI) for various outcomes of the custom RNP tool (Decision 1) mapped against the negotiated IP split (Decision 2). It must quantify the ROI penalty if the tool succeeds but the 90% IP cession remains intact. Type: Financial Analysis & Scenario Planning.

**Responsible Role Type:** Financial Controller & IP Negotiator

**Primary Template:** Decision Analysis Matrix (DAM)

**Secondary Template:** IP Value Partitioning Model

**Steps:**

- Define the cost basis for the custom RNP development effort.
- Model projected commercial value realization under the current 90/10 split vs. the proposed 50/50 split for the tool IP.
- Establish the minimum acceptable internal ROI threshold that justifies the Pioneer strategy.
- Generate clear recommendation on whether to proceed with negotiations or halt RNP development if terms are not adjusted.

**Approval Authorities:** Financial Controller & IP Negotiator, Project Lead

## Documents to Find

### 1. South Korean Bioethics and Biosafety Act Governing Germline Modification

**ID:** 2bce88fc-88b1-439c-bf50-3218d68f6f55

**Description:** The foundational legal text governing all germline editing activities in South Korea. Essential for establishing initial non-controversial compliance tracks and understanding MFDS jurisdiction regarding animal modification. Type: Official Legislation.

**Recency Requirement:** Current, active legislation essential

**Responsible Role Type:** Regulatory & Bioethics Strategist (Seoul Focus)

**Access Difficulty:** Medium

**Steps:**

- Search official portals of the South Korean Ministry of Health and Welfare or relevant legislative database.
- Consult with local Korean counsel to obtain the most recent ratified version.
- Analyze specific sections related to heritable changes in non-therapeutic applications.

### 2. MFDS/Bioethics Committee Precedents for Novel Non-Therapeutic Mammal Modification

**ID:** dbe5f5a9-7f73-4061-8c3e-3fd3402ab4f4

**Description:** Existing guidance, rulings, or precedents from South Korean regulatory bodies specifically concerning genetically modified companion animals or non-human research subjects that might inform the regulatory strategy for Decision 7 and Risk 3 mitigation, particularly regarding controversial modifications.

**Recency Requirement:** Last 5 years, if available

**Responsible Role Type:** Regulatory & Bioethics Strategist (Seoul Focus)

**Access Difficulty:** Hard

**Steps:**

- Search public records or scholarly analyses referencing MFDS rulings on animal GMOs.
- Engage external regulatory counsel familiar with South Korean internal review board processes.
- Check for published white papers from related Asian government science ministries.

### 3. Validated Canine AAV Vector Titers and Tropism Data for Somatic Insertion

**ID:** 873ceb24-3de1-40c2-9141-b4ae5f484abc

**Description:** Raw technical specifications and efficacy data (titers, on-target rates) for established, off-the-shelf AAV or viral systems applicable to canine zygotes. This is crucial for rapidly scaling the backup plan for the longevity pathway if the custom RNP fails (Risk 1 mitigation). Type: Scientific Performance Data / Vector Specification Sheets.

**Recency Requirement:** Published within last 3 years for high fidelity

**Responsible Role Type:** Lead Genomic Architect & Editor

**Access Difficulty:** Medium

**Steps:**

- Search databases like PubMed or specific vector platform provider repositories (e.g., Addgene, Thermo Fisher) for canine-specific data.
- Contact leaders of known xenotransplantation pig editing consortia (Suggestion 1 reference) for protocol transfer inquiries.
- Review publications related to human inherited retinal disease gene therapy (Luxturna pathway, Suggestion 3) for relevant AAV use cases.

### 4. Existing South Korean Guidelines for Animal Welfare and Specialized Housing (Post-Juvenile)

**ID:** 227767b9-8a4b-455e-88a9-f598685290e1

**Description:** Official guidelines or standards detailing mandatory infrastructure, veterinary resources, and enrichment protocols required for housing research dogs long-term (up to 20 years), necessary for calculating the operational liability (Issue 2/Risk 5).

**Recency Requirement:** Current National Standards

**Responsible Role Type:** Advanced Animal Husbandry & Logistics Manager

**Access Difficulty:** Medium

**Steps:**

- Contact the Korean Ministry of Agriculture, Food and Rural Affairs (or equivalent) for national animal welfare mandates.
- Obtain facility audit checklists used by local veterinary oversight bodies in Seoul.
- Search for institutional standards (e.g., Seoul National University) regarding long-term specialized canine environments.

### 5. Baseline Canine Telomerase and Growth Hormone Signaling Expression Profiles (Wild Type)

**ID:** e1b19a0e-33ae-4ceb-84d5-caaba198fb2b

**Description:** Raw qPCR, sequencing, or physiological data sets from genetically normal adult and juvenile canines establishing the natural epigenetic expression curves for telomerase and GH pathways, required for creating the modification targets for Decision 3.

**Recency Requirement:** Most recent available canine genomic/aging studies

**Responsible Role Type:** Longevity & Pathology Specialist

**Access Difficulty:** Medium

**Steps:**

- Search NIH/NCBI repositories (GEO) for publicly available canine tissue expression data related to aging.
- Acquire datasets from large veterinary genomics projects (e.g., Canine Genome Project outputs).
- Consult academic resources referenced by the Epigenetic Longevity Scientist expertise search.

### 6. Publicly Available Data on Canine Dermal Collagen Density and Hair Follicle Geometry

**ID:** 9e39b221-3831-4c3c-8040-fb8307e7d05a

**Description:** Raw anatomical or histological data specific to wild-type canine skin structure, necessary for the Aesthetics Modeler to quantify the required density and structural changes needed to achieve the 'chinchilla feel' (Assumption 6/Decision 9). Type: Raw Biological Measurement Data.

**Recency Requirement:** As detailed as possible, historical data acceptable

**Responsible Role Type:** Aesthetics & Sensory Modeler

**Access Difficulty:** Medium

**Steps:**

- Search specialized veterinary dermatology databases or journals for canine skin biomechanical analysis.
- Acquire reference data on chinchilla pelts (if available publicly) for comparative fractal analysis.
- Consult with external Biometric/Anatomy specialists for initial parameter setting.

### 7. South Korean Guidelines for Animal Welfare and Specialized Housing (Post-Juvenile)

**ID:** 7d30f0c4-7cb3-4957-a1a8-8d18a8fc4da0

**Description:** Official guidelines or standards detailing mandatory infrastructure, veterinary resources, and enrichment protocols required for housing research dogs long-term (up to 20 years), necessary for calculating the operational liability (Issue 2/Risk 5). This is a duplicate entry to ensure critical operational data is sourced.

**Recency Requirement:** Current National Standards

**Responsible Role Type:** Advanced Animal Husbandry & Logistics Manager

**Access Difficulty:** Medium

**Steps:**

- Contact the Korean Ministry of Agriculture, Food and Rural Affairs (or equivalent) for national animal welfare mandates.
- Obtain facility audit checklists used by local veterinary oversight bodies in Seoul.
- Search for institutional standards (e.g., Seoul National University) regarding long-term specialized canine environments.

### 8. Literature Review: Historical Canine Cloning/Genomic Engineering IP Agreements (Sooam Context)

**ID:** 664d8deb-1d35-4d7c-8a31-004888564585

**Description:** Any publicly accessible summaries, legal analyses, or press releases detailing the Intellectual Property (IP) structures Sooam Biotech has previously established in major genome-related projects, providing context for Decision 2 negotiations.

**Recency Requirement:** Last 10 years

**Responsible Role Type:** Financial Controller & IP Negotiator

**Access Difficulty:** Medium

**Steps:**

- Search academic databases for legal papers analyzing Sooam IP structures.
- Review press archives for announcements related to licensing agreements stemming from their cloning/genetics work.
- Consult resources related to Suggestion 2.

### 9. Reference Data on Human Oxytocin/Dopamine Release Thresholds Triggered by Known Stimuli

**ID:** 9724f146-2c26-4187-ab13-505db9592bf7

**Description:** Validated, quantifiable neurochemical data sets used as benchmarks for defining the 'maximal release' sought in Decision 5 and Decision 4. This serves as the baseline measurement target against which the engineered canine's efficacy will be compared.

**Recency Requirement:** Published within last 5 years for precise hormonal assay relevance

**Responsible Role Type:** Behavioral & Emotional Metric Validation Lead

**Access Difficulty:** Medium

**Steps:**

- Query scientific literature for established HRI (Human-Robot Interaction) or affective neuroscience studies specifying baseline dopamine/oxytocin spikes from high-appeal stimuli (e.g., infants, pets).
- Obtain the specific NIH or equivalent data sets referenced in the Emotional Response Validation Protocol.
- Consult data referenced in clinical trials for companion animal interaction studies.