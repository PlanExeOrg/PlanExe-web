## 1. Custom RNP Delivery System Viability & Backup Vector Performance

Decision 1 is the foundational technical lever. Failure of the custom RNP (high-risk choice) threatens the entire timeline and budget integrity. Establishing a validated backup pathway is critical for mitigating the most critical technical risk (Risk 1).

### Data to Collect

- On-target integration efficiency (%) for primary viability locus using Custom RNP (Target: >25%).
- Off-target mutation rate (%) for Custom RNP system.
- On-target integration efficiency (%) for Longevity Loci using validated AAV backup system.
- Cost and time metric for AAV vector optimization versus continued Custom RNP refinement.

### Simulation Steps

- Perform in silico modeling using bioinformatics software (e.g., Benchling, specialized Python libraries) to predict RNP vs. AAV integration success rates based on canine zygote models.
- Simulate budget impact of shifting resources from RNP optimization to AAV production pipeline setup ($5M re-allocation scenario).

### Expert Validation Steps

- Consult Lead Genomic Architect (Role 1) and Viral Vector Specialist (Expert 5) to validate the projected 25% pivot threshold for RNP efficiency and AAV readiness.
- Consult Financial Controller & IP Negotiator (Role 3) on the financial implications of parallel funding tracks against the $100M ceiling.

### Responsible Parties

- Lead Genomic Architect (Role 1)
- Financial Controller & IP Negotiator (Role 3)

### Assumptions

- **High:** The required technical pivot efficiency threshold (>25%) is an accurate operational indicator for RNP failure.
- **Medium:** A validated, high-fidelity AAV system can be procured/optimized within 4 months to handle the Longevity Loci edits if the RNP fails.

### SMART Validation Objective

By 2026-09-01, confirm Custom RNP insertion efficiency is >= 25% for viability loci, OR finalize AAV backup system integration performance data indicating feasibility of achieving Longevity Loci modification target efficiency (>40%) while staying within the initial $5M parallel development budget.

### Notes

- This data collection directly addresses the highest technical risk identified.
- If RNP fails threshold, mandatory pivot timeline locks in 2026-09-15.


## 2. Neuro-Pathway Engagement: Regulatory Impact Assessment (RIA) Status

Decision 4 is a critical commercial differentiator but poses an existential regulatory threat (Risk 3 in Seoul). Understanding the legal path or confirming the necessary pivot to the 'Cognitive Cue' backup is immediately necessary to prevent operational shutdown.

### Data to Collect

- Formal written opinion from specialized South Korean bioethics counsel regarding Risk 3 (Neuro-Pathway targeting).
- Comparative analysis of the most stringent international (FDA/EMA) precedents for germline modification affecting neurochemistry.
- Projected timeline (best/worst case) for MFDS approval of Decision 4, Choice 1 vs. Decision 4, Choice 2.

### Simulation Steps

- Regulatory Strategist runs an internal 'Mock Review' simulation based on known MFDS/Bioethics Committee structures, scoring the neuro-pathway intervention on a scale of 1 to 10 (10 being immediate halt).
- Model the cost and time required to fully prepare the technical package for the backup 'Cognitive Cue Optimization' pathway (Decision 4, Choice 2) to assess pivot readiness.

### Expert Validation Steps

- Consult Regulatory & Bioethics Strategist (Role 2) and Bioethics/Regulatory Strategist (Expert 1) to assess RIA findings.
- Consult Financial Controller (Role 3) on the sustained cost buffer required if a 12-24 month regulatory delay occurs.

### Responsible Parties

- Regulatory & Bioethics Strategist (Role 2)
- Financial Controller & IP Negotiator (Role 3)

### Assumptions

- **High:** Specialized bioethics counsel engagement (funded implicitly within startup/overhead) is sufficient to generate a reliable RIA.
- **Medium:** The 'Cognitive Cue Optimization' pivot (Decision 4, Choice 2) is scientifically viable for reaching the emotional metric threshold if the direct pathway is blocked.

### SMART Validation Objective

By 2026-10-30, obtain a codified Regulatory Impact Assessment (RIA) from specialized counsel that explicitly rates the likelihood of a regulatory halt on Decision 4, Strategy 1 as 'Yellow' or 'Red', thereby triggering the documented operational readiness plan for assessing Strategy 2.

### Notes

- This directly addresses Critical Missing Assumption/Issue 1 identified by Experts.
- The 'Yellow' status must trigger immediate, dedicated resource allocation toward validating the fallback strategy.


## 3. 20-Year Liability Funding Structure & RNP IP Vesting Agreement

This addresses the severe financial disconnect identified by experts: the project aims for 20-year viability but lacks post-R&D funding, and high proprietary investment (RNP) is not protected financially (Expert 2, Issue 2/3). This stabilizes ROI and guarantees subject welfare.

### Data to Collect

- Finalized projection model detailing 20-year Opex for 5 stable candidate lines (including specialized husbandry, veterinary care, and DLM costs, estimated $20M+ total liability).
- Draft amendment language for Decision 2 (IP Alignment) isolating ownership of the successful Custom RNP system (Decision 1) from general commercial IP, ideally securing 50% joint ownership.
- Legal agreement draft establishing an irrevocable, ring-fenced escrow/trust mechanism funded by a defined percentage of Year 3 projected licensing revenue, dedicated solely to the 20-year Opex liability.

### Simulation Steps

- Finance team models two scenarios for the escrow funding: A) 50% of projected Year 3 revenue earmarked, vs. B) A fixed $15M R&D success bonus from the external partner tied to a 5-year longevity milestone.
- Legal team runs simulations on the enforceability of the dedicated escrow mechanism under South Korean JV law for safeguarding future Opex.

### Expert Validation Steps

- Consult Financial Controller/IP Negotiator (Role 3) and Epigenetic Longevity Scientist (Expert 2) on the liability model ($20M+).
- Consult International IP Attorney (Expert 8) on the feasibility and enforceability of carving out RNP IP ownership and mandatory liability escrow structures within the Sooam JV framework.

### Responsible Parties

- Financial Controller & IP Negotiator (Role 3)
- Regulatory & Bioethics Strategist (Role 2)

### Assumptions

- **Medium:** A minimum of 5 successful, genetically stable lines will require support post-R&D validation, justifying the $20M liability estimate.
- **High:** South Korean or relevant international contract law permits the establishment of a non-dissolvable escrow mechanism tied to future revenue streams for animal welfare liability.

### SMART Validation Objective

By 2027-03-30 (within 1 year of project start), finalize and legally embed the 20-year husbandry liability financing mechanism (escrow/trust) covering the full projected Opex, and achieve a revised JV draft where RNP ownership vesting grants the developing entity at least 50% joint control/revenue share over that specific technology.

### Notes

- This is the most critical financial/legal action required post-strategy selection.
- Requires immediate engagement with Expert 8 and heavy lifting by Role 3/Role 2, as per Expert recommendations.


## 4. Aesthetic Synthesis Target Definition & Sensory Feedback Loop Readiness

While secondary to longevity/emotion, successful aesthetic synthesis is critical for commercial viability (Risk 6). This data ensures the iterative process (Decision 6) is targeted and does not compromise biological stability goals.

### Data to Collect

- Quantified target parameters for 'Seal Pup' morphology (e.g., epidermal thickness variance, fat deposition metrics) and 'Cartoon' facial kinematics (e.g., eye proportion ratios).
- SOP draft for initiating rapid sensory feedback trials using non-integrated gene expression models (Decision 6, Choice 1).
- Biometric data (fractal dimension analysis) collected on engineered *controls* showing initial dermal editing success against 'chinchilla feel' target (Assumption 6: 90% match).

### Simulation Steps

- Aesthetics Modeler (Role 7) uses simulation software (e.g., Biomechanical modeling tools) to predict structural failure risk (Risk 6) if Aesthetic Synthesis prioritizes depth (seal) over stability (retriever base).
- Behavioral Lead (Role 5) models the required testing resources (FTEs/time) for continuous iteration cycle management (Decision 6).

### Expert Validation Steps

- Consult Aesthetics & Sensory Modeler (Role 7) to finalize quantifiable trait targets.
- Consult Behavioral & Emotional Metric Validation Lead (Role 5) to confirm feasibility of rapid, low-fidelity functional testing loops.
- Consult Epigenetic Longevity Scientist (Expert 2) to verify that the proposed dermal edits (chinchilla feel) do not conflict with required subcutaneous fat profiles needed for long-term thermal regulation.

### Responsible Parties

- Aesthetics & Sensory Modeler (Role 7)
- Behavioral & Emotional Metric Validation Lead (Role 5)

### Assumptions

- **Medium:** The aesthetic goals ('seal pup,' 'cartoon') are biologically translatable into a discrete, non-contradictory set of genetic targets.
- **Low:** A low-fidelity, non-integrated expression system (Decision 6, Choice 1) can accurately predict final germline phenotype appearance.

### SMART Validation Objective

By 2026-11-30, finalize the actionable genetic target parameter set for all three aesthetic components (Decision 9) and obtain signed approval from the Longevity Specialist (Expert 2) confirming no imminent conflict with thermal regulation requirements for the 20-year phenotype.

### Notes

- Requires explicit feedback from Role 7 to Role 1 before major editing passes begin.
- The chinchilla feel metric (Assumption 6 verification) must be explicitly tested here.

## Summary

The current plan, based on 'The Pioneer' strategy, prioritizes maximal performance via unproven, high-risk technology (Custom RNP) and controversial neuro-engineering. Validation must immediately focus on mitigating the existential financial and regulatory threats stemming from this high-ambition choice before extensive R&D burn occurs.

**Immediate Actionable Tasks:**
1. **Technical Redundancy (High Sensitivity):** The Lead Genomic Architect (Role 1) must immediately initiate validation tracks for established AAV backup vectors to establish the Decision 1 pivot readiness threshold (Target: 25% RNP efficiency failure by 2026-09-01).
2. **Financial/Legal Security (High Sensitivity):** The Financial Controller (Role 3) must immediately engage Legal Counsel (Role 3/Expert 8) to draft the required enforceable IP vesting transfer language (protecting RNP ROI) and structure the irrevocable escrow mechanism to fund the projected 20-year operational liability (Issue 2/3).
3. **Regulatory Viability Assessment (High Sensitivity):** The Regulatory Strategist (Role 2) must commission the confidential Regulatory Impact Assessment (RIA) on the direct neuro-pathway engineering (Decision 4) to confirm pathway viability and determine the exact trigger point for pivoting to the 'Cognitive Cue Optimization' fallback.