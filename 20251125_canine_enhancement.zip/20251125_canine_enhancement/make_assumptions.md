
## Question 1 - Given the $100M USD budget, what specific percentage allocation is planned for upfront Intellectual Property (IP) establishment costs, including joint venture structuring and background IP licensing fees with Sooam Biotech?

**Assumptions:** Assumption: Due to the complexity of Decision 2 (IP Alignment) and the high-risk Pioneer strategy selected, 15% of the total budget ($15M USD) will be ring-fenced for initial IP negotiation, legal counsel, and upfront milestone payments to Sooam within the first 12 months.

**Assessments:** Title: Funding & Budget Allocation Assessment
Description: Evaluation of the initial capital allocation against high-impact, non-technical upfront mandatory costs.
Details: A $15M initial IP allocation is appropriate for establishing the JV structure under a high-leverage scenario, but it strains the operating buffer needed for unexpected reagent costs (Risk 7). Opportunity exists to negotiate milestone payments tied to genetic stability (Decision 4) rather than fixed upfront cash to smooth cash flow across Year 1, potentially mitigating the immediate high depletion rate associated with the Pioneer strategy's proprietary tooling.

## Question 2 - What is the target date for achieving the first successful germline modification using the custom RNP system, considering the aggressive 'start ASAP' directive and the high technical risk of Decision 1?

**Assumptions:** Assumption: Given the start date of 2026-Apr-28, and the critical nature of the custom RNP development, the target date for validated, stable germline insertion (first successful cohort launch) is set for Month 8 (December 31, 2026).

**Assessments:** Title: Timeline & Milestone Assessment
Description: Review of the feasibility of the initial critical technical milestone given the high-risk technology choice.
Details: An 8-month timeline for achieving validated germline modification with a custom RNP system is highly aggressive (Time Constraint Risk). Failure to meet this milestone by Month 10 forces a transition to the backup viral vector system, impacting the complexity of subsequent Longevity Constraint edits (Decision 3). Benefit: Meeting this date rapidly validates the custom tooling, providing a significant operational advantage.

## Question 3 - How many dedicated full-time equivalent (FTE) research staff (genomic engineers, biotechnologists) will be dedicated solely to the custom RNP delivery development (Decision 1) versus behavioral validation (Decision 8) in Year 1?

**Assumptions:** Assumption: The high-risk Pioneer strategy requires a 60/40 split in Year 1 FTE allocation: 60% (e.g., 12 FTEs) dedicated to core genetic engineering/delivery optimization, and 40% (e.g., 8 FTEs) dedicated to establishing the complex Long-Term Behavioral Validation schedule (Location 2 support).

**Assessments:** Title: Resources & Personnel Assessment
Description: Analysis of resource allocation between foundational technology development and long-term operational support.
Details: A 60% focus on the custom RNP toolset (Decision 1) appropriately balances the recognized high risk of technical failure (Risk 1). The remaining 40% dedicated to behavioral validation ensures early planning for the 20-year constraint. Risk: Personnel burnout or skill gaps in combining exotic aesthetics (Decision 9) with neurochemistry monitoring may be high if FTEs are not cross-trained.

## Question 4 - What specific certifications or preliminary regulatory discussions (beyond standard institutional IRB/IACUC equivalents) are already underway at Sooam regarding the highly novel direct neuro-pathway targeting required by Decision 4?

**Assumptions:** Assumption: No formal, high-level regulatory discussions regarding direct pathway manipulation in a companion animal have occurred yet; initial steps involve structuring internal review to align research with South Korean bio-ethics counsel by Month 3, preparing for inevitable scrutiny (Risk 3).

**Assessments:** Title: Governance & Regulations Assessment
Description: Review of readiness concerning the highest regulatory hurdle: engineering human neuro-pathway influence.
Details: Assuming no preliminary discussions exist, Risk 3 severity is critically high, as this move potentially shifts the project into highly controlled areas usually reserved for therapeutic human applications. Opportunity exists by framing the initial testing entirely around objective markers (cortisol/oxytocin metrics - Decision 5) rather than subjective 'happiness' to navigate initial governance stages within the existing research framework in Seoul.

## Question 5 - Beyond standard institutional safety protocols, what specific, dedicated risk contingency budget line item is set aside to address the high probability of oncogenesis or severe metabolic disorder stemming from the aggressive 20-year longevity edits (Risk 2)?

**Assumptions:** Assumption: Based on Risk 2 severity, $5M USD (5% of the total budget) will be explicitly allocated via Decision 3 constraints for specialist pathological consultation, advanced longitudinal monitoring hardware, and rapid response drug compounding/intervention trials.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Quantification of the dedicated financial buffer against the most severe biological technical risk (cancer/pathology).
Details: Establishing a $5M specialized fund directly addresses the high-severity cancer/longevity risk. This proactive spending mitigates the sunk cost potential ($50M loss projected by Risk 2). Benefit: Early consultation helps refine the Prime Editing targets to avoid known oncogenic drivers, improving safety without sacrificing the 20-year performance target.

## Question 6 - What specific, quantifiable, non-mammalian biological markers associated with the 'chinchilla feel' tactile requirement must be measured in early-stage phenotyping trials to ensure operational consistency?

**Assumptions:** Assumption: The 'chinchilla feel' translates to maintaining a specific dermal surface roughness and hair/fur density profile. Target metrics will involve standardized surface profiling (e.g., fractal dimension analysis) aiming for a 90% match to control chinchilla samples for pilot cohorts.

**Assessments:** Title: Environmental Impact Assessment (Proxy)
Description: Analysis of the impact of specific aesthetic engineering requirements on biological consistency and resource usage.
Details: While direct environmental impact is low, ensuring the required dermal morphology (part of the aesthetic goal) is replicable is crucial. If the required dermal layer complexity necessitates highly specific, non-standard nutrient inputs or specialized climate-controlled housing beyond standard canine care (Risk 5), this could escalate operational costs disproportionately, potentially increasing the 'environmental footprint' of specialized animal housing exponentially.

## Question 7 - Considering the necessary administrative and regulatory complexity of Decision 7 (Global IP/Regulation), what tangible milestones are scheduled for establishing the secondary IP/Regulatory office (Location 3) and what resources are allocated for this in Year 1?

**Assumptions:** Assumption: The IP office establishment (Location 3) is defined as a Year 1, Q3 milestone, requiring the immediate hiring of 1 dedicated senior International IP Counsel and allocating $1.5M USD for initial legal fees and establishing basic operational presence alongside Sooam's legal team.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the structured engagement with external legal stakeholders necessary for global commercialization.
Details: Allocating $1.5M early for specialized counsel (Decision 7) is vital to manage the conflict between proprietary tooling costs and IP structuring (Decision 2). Failure to embed international legal expertise early risks making the proprietary Joint Venture structure financially unfavorable upon global licensing. Opportunity: Early engagement allows proactive shaping of regulatory submissions to satisfy multiple jurisdictions, reducing future re-validation costs.

## Question 8 - Since the project runs for 20 years, what specific maintenance contract or budget line item is established to sustain the required specialized digital monitoring and data retention systems (e.g., longitudinal behavioral performance logs) required until Year 20?

**Assumptions:** Assumption: A dedicated 20-year data lifecycle management (DLM) contract will be secured in Year 2 (following initial germline success), budgeted at $500,000 USD annually, covering secure, redundant data storage in both USD-denominated international hubs (Location 3) and local Seoul servers.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the long-term viability and cost modeling for essential data infrastructure supporting the 20-year constraint.
Details: Committing to a $500K/year DLM contract starting in Year 2 front-loads a significant operational expense but directly mitigates the massive risk of data loss impacting the 20-year proof requirement. This operational system must be explicitly insulated from potential Year 3 budget shortfalls (Risk 4) by being funded from the dedicated $15M IP allocation if necessary, ensuring data integrity remains paramount.