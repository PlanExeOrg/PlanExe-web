This plan involves money.

## Currencies

- **KRW:** Local currency for daily operational expenses, local labor, and services within Seoul, South Korea.
- **USD:** The project budget is denominated in USD ($100M) and it is the recommended currency for high-value international procurement, IP licensing fees, and risk mitigation against KRW volatility.

**Primary currency:** USD

**Currency strategy:** Due to the extremely large budget ($100M USD) and the high-risk, high-novelty nature of the research, USD will serve as the primary currency for budgeting, reporting, and major international procurement (e.g., proprietary RNP systems). KRW will be used for localized, day-to-day operational spending in Seoul. Budget reporting will maintain USD parity to stabilize valuation against potential economic shifts in South Korea.