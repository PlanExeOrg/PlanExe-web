This plan involves money.

## Currencies

- **KRW:** Local currency for South Korean operational expenses (salaries, utilities, local procurement).
- **USD:** The project budget is denominated in USD ($100M). This stable international currency should be used for major international contracts, specialized reagent purchases (e.g., Prime Editing kits), and expatriate team contractor payments to hedge against KRW fluctuations.
- **CHF:** Potential currency if the secondary facility is established in Switzerland for IP consolidation.

**Primary currency:** USD

**Currency strategy:** The primary budgeting and reporting currency will be USD, reflecting the stated project capitalization. Local operational costs in Seoul will be managed by converting necessary amounts from USD to KRW. Payments for international scientific personnel and high-value reagents (Prime Editing components) should be invoiced and paid directly in USD to mitigate exposure to local economic volatility and ensure budgetary control over specialized equipment.