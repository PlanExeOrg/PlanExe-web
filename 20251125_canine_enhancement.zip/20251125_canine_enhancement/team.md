*Roles Needed & Example People*

# Roles

## 1. Lead Genomic Architect (Prime/CRISPR Specialist)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: This highly specialized role requires deep expertise in cutting-edge modalities (Prime Editing/CRISPR) often sourced via short-term, project-specific contracts for maximum technical skill acquisition, as reflected by the Pioneer strategy.

**Explanation**:
Responsible for designing and optimizing the multi-locus editing strategy, specifically focusing on the complex trade-offs between standard CRISPR-Cas9 and high-precision Prime Editing. Directly addresses Decision 1 and Decision 12.

**Consequences**:
Suboptimal modality choice leads to high off-target edits, significant budget overrun due to Prime Editing reagent waste, or failure to achieve the necessary insertion density for multi-trait goals.

**People Count**:
min 1, max 2, depending on bench workload

**Typical Activities**:
Designing and optimizing Prime Editing guide RNAs and donor templates for simultaneous multi-locus integration across the canine genome; validating the efficiency and accuracy of the engineered bacteriophage delivery system; supervising high-throughput sequencing validation runs to quantify on-target versus off-target edits; troubleshooting low-yield integration events by iterating on editing modality parameters.

**Background Story**:
Dr. Alistair Vance, hailing from the Swiss Alps region of Geneva, is a veteran molecular geneticist whose early career was defined by pioneering work in personalized oncology, gaining deep expertise in both CRISPR-Cas9 efficiency mapping and the nascent field of Prime Editing technology. His doctoral work focused on achieving single-nucleotide precision across large, non-dividing cell populations, skills he now applies to optimizing multi-locus integration in complex eukaryotic genomes. Dr. Vance is intimately familiar with the trade-offs outlined in Decision 1, as he designed the initial Prime Editing guide/template systems used in this very project's proof-of-concept. His relevance stems from his ability to directly translate the Strategic Choice (Pioneer Path) into executable, high-fidelity laboratory protocols, minimizing off-target effects critical for the longevity and neurochemical targets.

**Equipment Needs**:
High-performance computing cluster access for iterative Prime Editing template design and simulation; dual-supplier inventory of Prime Editing reagents, guide RNAs, and specialized nucleases; high-throughput DNA sequencer (e.g., Illumina NovaSeq access time).

**Facility Needs**:
Access to a dedicated laboratory suite within Sooam with BSL-2+ capability for guide RNA synthesis and vector production; Secure, localized IT environment for simulation data storage.

## 2. Neurobehavioral Systems Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Translating subjective neurochemical goals into precise genetic targets is a niche, high-value integration task. Best secured as an independent expert specializing in CNS/behavioral pathway translation given the critical nature of Decision 2.

**Explanation**:
Designs and validates the genetic modifications targeting the human dopamine/oxytocin release mechanism (Decision 2, 14). This role translates subjective human emotional targets into specific, verifiable genetic cascade requirements.

**Consequences**:
Failure to meet the primary business objective: the engineered dog will not reliably trigger the maximal emotional state in handlers, rendering the entire project commercially or scientifically defunct.

**People Count**:
1

**Typical Activities**:
Modeling the cascade effects of proposed genetic edits on canine neurochemistry; designing in-vitro assays to screen engineered genes for appropriate receptor affinity kinetics; coordinating with the expatriate validation team to structure blinded human interaction tests (18-month milestone); refining the exact target sequences for dopamine/oxytocin upregulation pathways.

**Background Story**:
Dr. Lena Petrova grew up in St. Petersburg, Russia, where her initial fascination with human emotion evolved into a career studying the neurochemistry of bonding and affection, culminating in advanced post-doctoral work at the Salk Institute focusing on mapping behavioral drivers to specific receptor expression levels. Her expertise bridges computational neuroscience and behavioral pharmacology, allowing her to translate subjective human phenomena—like achieving 'maximal dopamine and oxytocin release'—into quantifiable genetic targets within the canine CNS. Highly familiar with Decision 2 and Decision 14, she designed the triple-redundant neural pathway strategy chosen by the Pioneer group, ensuring that failure in one pathway does not compromise the core emotional delivery mechanism.

**Equipment Needs**:
In-vitro assay kits for receptor screening (dopamine/oxytocin pathway quantification); access to advanced instrumentation for in-vivo neurochemical monitoring (e.g., microdialysis equipment, PET scanner time for validation).

**Facility Needs**:
Dedicated BSL-2 animal housing/interaction rooms for blinded human observer trials; secure computational environment for running neurological interaction models based on Decision 2 and Decision 14.

## 3. Longevity & Metabolic Modeler

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Managing the complex trade-off between 20-year lifespan and perpetual juvenility (Lever 5) requires deep simulation and modeling expertise, often sourced externally for specific project phases where internal headcount is insufficient for novel modeling.

**Explanation**:
Focuses exclusively on the 20-year lifespan and perpetual juvenile state (Decision 5, 13). This role manages the metabolic simulation, tracks oncological risk markers, and designs the deceleration switch protocols. Linked to Suggestion 3.

**Consequences**:
Catastrophic systemic failure or oncological collapse within the first few years due to unchecked metabolic conflict between extended lifespan and forced juvenility (Risk 4).

**People Count**:
1

**Typical Activities**:
Running complex simulations to predict metabolic divergence rates under perpetual juvenile expression profiles; designing the operational parameters and monitoring thresholds for the 'deceleration switch' (Decision 5); tracking and reporting on long-term oncological biomarkers (telomerase activity, senescence markers) in relation to the juvenile state maintenance; consulting on necessary cardiovascular/renal pathway interventions.

**Background Story**:
Kaelen O’Connell, originally from Dublin, Ireland, specialized in comparative gerontology and metabolic systems modeling, trained under pioneers in the 'Methuselah' longevity research projects. His expertise is centered on maintaining long-term cellular homeostasis in genetically modified organisms, making him uniquely suited to the conflicting demands of a 20-year lifespan combined with perpetual juvenile metabolism (Lever 5). Kaelen developed the complex simulation software used to predict oncological stress resulting from forced endocrine deceleration, which is central to his relevance in ensuring the animal's viability past the initial few years of editing.

**Equipment Needs**:
Advanced metabolic modeling simulation software licenses; specialized diagnostic equipment (e.g., high-resolution MRI/PET access) for monitoring oncological and cardiovascular biomarkers; reagents for cellular senescence assays.

**Facility Needs**:
Access to the secure, specialized husbandry unit at Sooam capable of long-term (20+ year) life support, equipped with specialized environmental controls to synchronize with the deceleration switch.

## 4. Institutional Liaison & IP Navigator (Seoul Expert)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: This role demands unique local knowledge of South Korean regulations, IP law, and Sooam operations. Such expertise is typically engaged via a contingent or consulting 'Navigator' contract rather than a full-time employee status.

**Explanation**:
Manages the day-to-day operational interface with Sooam Biotech, handles local regulatory navigation (South Korea), and proactively executes the Intellectual Property capture strategy (Decision 4, 10, Risk 5). Requires deep familiarity with local practices.

**Consequences**:
Severe geopolitical and IP risk exposure, operational bottlenecks due to cultural misunderstanding, or loss of proprietary assets developed on-site.

**People Count**:
1

**Typical Activities**:
Serving as the primary liaison for all regulatory filings and inspections with South Korean authorities; negotiating local facility use contracts and security clearances with Sooam management; drafting and executing the IP transfer protocols to the secondary jurisdiction (Location 3); managing customs and logistical approvals for the expatriate team's specialized equipment.

**Background Story**:
Min-Jae Park is a South Korean national from Busan who built his career navigating the unique intersection of advanced biotechnology research and Seoul's specific regulatory landscape, possessing extensive experience working directly within the Sooam Biotech ecosystem. His professional life has been a constant negotiation between proprietary R&D and national bioethics mandates, making him the perfect candidate to manage the high-stakes geopolitical and IP risks associated with the project’s primary location. Min-Jae is directly responsible for ensuring the successful execution of Decision 4 and protecting the project’s assets against potential disputes suggested by Risk 5.

**Equipment Needs**:
Secure digital communication encryption suite; legal and contractual documentation systems compliant with South Korean and international IP law; specialized logistics tracking hardware for equipment transfer.

**Facility Needs**:
Dedicated office space co-located at Sooam for daily interface management; secure, geographically separate data repository instance in a neutral jurisdiction (Location 3) for IP backup.

## 5. Expatriate Protocol Validator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The expatriate validator team is explicitly defined for a limited, high-intensity collaboration period (first six months) to cross-validate protocols already established at the primary site, aligning with an independent contractor engagement model.

**Explanation**:
Works alongside the Seoul team, ensuring that all emergent protocols meet external validation standards (Decision 4). This role provides necessary skepticism and cross-checks against Western methodologies to reduce data ambiguity.

**Consequences**:
Internal bias in validation metrics; acceptance of sub-optimal protocols developed entirely within the host institution, increasing long-term technical debt (Risk 6).

**People Count**:
2

**Typical Activities**:
Running parallel, shadow experiments using the primary genetic constructs delivered by the Seoul team to confirm fidelity; auditing Sooam's BSL-2+ waste stream inactivation protocols (Assumption 6); developing the initial standardized SOPs for external data interpretation; collaborating on the technological transfer documentation for the secondary IP site.

**Background Story**:
Drs. Chloe and Ben Carter, a married couple specializing in applied molecular validation, hail from Boston, Massachusetts, where they trained side-by-side in rigorous cross-institutional protocol auditing. They were specifically recruited to form the expatriate validation team, bringing an independent, externally benchmarked standard to the development occurring at Sooam. Their backgrounds in FDA/EMA protocol compliance mean they view all internal Sooam procedures through a lens of external reproducibility, directly addressing the potential integration failure highlighted in Risk 6 and ensuring the Pioneer strategy holds up to external scrutiny.

**Equipment Needs**:
Identical, high-precision fluidics and sequencing hardware setup as the primary Sooam lab for running parallel 'shadow' validation experiments; secure remote access terminals to peer with Sooam systems.

**Facility Needs**:
Dedicated, secure laboratory space near Boston/Cambridge (Location 2) capable of handling precursor biological materials shipped from Seoul for immediate validation and cross-checking of protocols.

## 6. Advanced Biologistics & Supply Chain Manager

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Supply chain management for specialized, high-cost reagents like Prime Editing components, especially under tight lead-time constraints (Risk 7), is often managed by specialized external consultants who can leverage global contacts and negotiate complex material contracts.

**Explanation**:
Manages the procurement, quality control, and inventory burn rate for high-cost, low-volume specialized reagents (especially Prime Editing components, Decision 12). Also handles complex import/export for the expatriate team supplies.

**Consequences**:
Project stalls due to critical reagent shortages, or the budget buffer is exhausted prematurely due to uncontrolled purchasing of specialized consumables (Risk 3, Risk 7).

**People Count**:
1

**Typical Activities**:
Negotiating 12-month supply contracts with vendors for Prime Editing nucleases and proprietary delivery vectors; monitoring the burn rate of consumables against the 30% infrastructure budget allocation; implementing quality control checkpoints for every novel reagent batch received; coordinating rapid customs clearance for time-sensitive equipment imports required by the expatriate team.

**Background Story**:
Rajesh Singh, based out of Bangalore, India, is a master of complex resource logistics, having managed supply chains for large-scale pharmaceutical clinical trials where lead times and consumable costs were critical failure points. His expertise is invaluable given the project’s high reliance on expensive, specialty reagents inherent to Prime Editing (Decision 1) and the risk of early budget depletion (Risk 3). Rajesh is tasked with applying his rigorous inventory controls and dual-sourcing strategies to ensure a continuous, cost-managed supply of all molecular biology components necessary for iterative editing cycles.

**Equipment Needs**:
Enterprise inventory management software integrated with budget tracking (Decision 16); secured consignment agreements and hard-lead-time contracts for Prime Editing components; specialized shipping containers for high-value reagents.

**Facility Needs**:
Secure, climate-controlled local storage area within the Boston/Cambridge location to house incoming critical reagents before shipment to Seoul or utilization by the expatriate team.

## 7. Bioethics and Public Affairs Strategist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Managing proactive ethical PR and navigating complex regulatory landscapes (Decision 6) benefits from external consultants specializing in high-risk/controversial biotech public affairs, who offer specific, time-bound expertise.

**Explanation**:
Develops and executes the proactive regulatory and public relations roadmap, managing sensitive interactions with non-governmental consortiums and preparing messaging to preempt ethical backlash regarding enhancement editing (Decision 6, Risk 8).

**Consequences**:
Sudden regulatory shutdown or intense public backlash that halts project momentum, resulting in sunk costs and potential asset seizure/loss.

**People Count**:
1

**Typical Activities**:
Developing and deploying the communications strategy that frames the project primarily around veterinary welfare improvement; coordinating all interactions with the International Bioethics Oversight Consortium; preparing data-release packages timed explicitly with longevity milestones to maximize positive media framing; lobbying for regulatory clarity on enhancement research.

**Background Story**:
Senator (ret.) Evelyn Reed, operating from Washington D.C., pivoted her political acumen into bioethics strategy after a distinguished career in policy-making related to emerging medical technologies. Evelyn is responsible for the proactive shielding of the project from public regulatory jeopardy by managing the narrative around non-therapeutic germline enhancement. She is uniquely positioned to secure the confidential pre-approval from the non-governmental consortium as outlined in Decision 6, a critical step to maintain operational momentum against inevitable public scrutiny (Risk 8).

**Equipment Needs**:
Budget allocation ($2M) for external communications consulting contracts; secure multimedia production tools for creating simplified project narratives; specialized legal review software for international regulatory scanning.

**Facility Needs**:
Secure communication hub (office space) suitable for handling sensitive external media interaction and managing confidential ethical review submissions, independent of the wet lab environment.

## 8. Longitudinal Data Steward

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Data stewardship for a 20-year longitudinal asset requires continuous, consistent oversight, maintenance, and guaranteed oversight continuity, making a permanent, dedicated internal resource ('full-time employee') essential for asset integrity.

**Explanation**:
Designs and maintains the secure, centralized 20-year data architecture required for longevity milestones and behavioral tracking (Assumption 8). Ensures compliance and accessibility across potential future dispersal locations.

**Consequences**:
Loss of critical longitudinal efficacy data necessary to prove the 20-year mandate, rendering the asset non-verifiable and preventing future commercialization or scaling.

**People Count**:
1

**Typical Activities**:
Designing the secure cloud architecture compliant with global PII/biometric standards; establishing APIs for continuous, remote biometric monitoring from dispersed locations; overseeing the automated archival and version control of all genomic sequencing data; reporting data reliability metrics to the expatriate operations coordinator.

**Background Story**:
Dr. Samuel 'Sam' Chen, based out of Palo Alto, California, is a software architect specializing in secure, high-availability data systems designed for long-term scientific fidelity. His primary mission is establishing the enterprise-grade, centralized, encrypted cloud platform required to aggregate and safeguard two decades of biometric, genomic, and behavioral data generated by the canine cohort, regardless of future dispersal (Assumption 8). Sam's background ensures the longitudinal data integrity necessary to validate the $100M investment against the 20-year lifespan mandate.

**Equipment Needs**:
Enterprise-grade, highly secure, encrypted cloud storage infrastructure with guaranteed 50+ year data retention service level agreements; specialized biometric sensors and telemetry hardware for remote animal monitoring.

**Facility Needs**:
Dedicated server allocation within a certified, highly secure data center compliant with global standards (managed remotely from Location 2), to host the longitudinal data platform.

---

# Omissions

## 1. Missing Dedicated Bioinformatic Execution Lead

The project relies heavily on complex iterative editing (Prime Editing) and validation across 15 strategic decisions, requiring massive sequencing data analysis, genomic assembly, and simulation validation for longevity modeling. The current team has architects and modelers, but no dedicated role focused solely on the computational heavy lifting required to execute iterative editing cycles against the genomic blueprint.

**Recommendation**:
Integrate a dedicated 'Lead Computational Geneticist' role. This individual should report to the Lead Genomic Architect (Role 1) and focus 100% on pipeline execution, quality control metrics for Decision 1, and running the simulations required by the Longevity Modeler (Role 3), rather than relying on the Architects or Modelers to execute the bulk computational tasks.

## 2. Lack of Defined Veterinary Surgical/Implantation Specialist

The project involves genetic modification, embryo creation, and ultimately, the long-term management of a 20-year-old engineered canine (Decision 5, 13). While Sooam provides core husbandry, the *introduction* of the modified embryo/fetus and potential necessary surgical interventions (for longevity pathway monitoring or tissue sampling) requires specialized expertise explicitly assigned to the project.

**Recommendation**:
Assign a high-level 'Lead Veterinary Science Consultant' (perhaps integrated part-time with the expatriate team, or fully subcontracted via Sooam) whose sole responsibility is the implantation protocol, post-birth pathology assessment, and maintaining the operational plan for the 20-year longevity threshold (Decision 13).

## 3. Missing Dedicated Experiment and Protocol Management Role

With 15 critical decision levers, 9 identified risks, and the Pioneer strategy demanding parallel testing (phage delivery, shadow validation by expatriate team), there is a significant risk of protocol drift, conflicting priorities, and delayed escalation pathways between the Seoul team and the Boston team (Risk 6).

**Recommendation**:
Establish a 'Project Systems Coordinator' role (potentially one of the two Expatriate Validators, e.g., the Operations Coordinator mentioned in Assumption 3, but formalized). This role must own the master SOP repository, manage the bi-weekly review cadence (as noted in the project plan), and be the single point of escalation for protocol ambiguity.

---

# Potential Improvements

## 1. Clarify Ownership of the 'Deceleration Switch' Protocol

Decision 5 mandates a complex endocrine deceleration switch to enforce perpetual juvenility for 20 years, a key differentiating factor. The Longevity Modeler (Role 3) simulates this, but ownership of the final, reproducible genetic sequence implementation and its interaction with the Neurobehavioral Engineer's cascade (Role 2) is unclear.

**Recommendation**:
Explicitly assign the final design and technical sign-off for the Decision 5 deceleration switch firmware implementation to the Lead Genomic Architect (Role 1), with mandatory functional cross-validation reports delivered to the Longevity Modeler (Role 3) and Neurobehavioral Systems Engineer (Role 2) prior to Phase II editing.

## 2. Formalize IP Transfer Checkpoints Against Budget Burn

Risk 5 highlights severe geopolitical and IP concentration risks at Sooam. The Institutional Liaison (Role 4) is tasked with mitigating this, but the trigger for accelerating resource commitment to the secondary IP facility (Location 3) needs clearer linkage to budget/technical markers rather than being solely reactive.

**Recommendation**:
Require the Institutional Liaison (Role 4) to deliver a binding cost estimate for the 'Step-In Acquisition Clause' buyout (minimum $5M USD, per Assumption Review Issue 3) within the first 9 months. If the genomic architecture (Decision 1) is validated >70% successful by that point, reallocate $5M from the Budget Buffer (Decision 16) into securing the Location 3 IP vault infrastructure immediately.

## 3. Streamline Aesthetics/Morphology Responsibility Clarity

Morphology involves three polygenic traits (Look, Feel, Behavior/Act Like) managed partially by the Architect (genomics), the Neurobehavioral Engineer (behavior), and the Supply Chain Manager (reagent sourcing for feel). This overlap risks inefficiency, as highlighted by Risk 9.

**Recommendation**:
Designate the Lead Genomic Architect (Role 1) as the sole Decision Authority for the *finalized genetic sequence* dictating morphological traits (Decision 9). The Neurobehavioral Systems Engineer (Role 2) must sign off *only* on the 'acts like' behavioral component, ensuring no functional editing is misattributed to purely aesthetic goals.