*Roles Needed & Example People*

# Roles

## 1. Lead Genomic Architect & Editor

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Lead Genomic Architect must be a specialized expert hired specifically for their knowledge of custom RNP optimization and complex, multi-trait editing (Pioneer Strategy). This role requires high autonomy and specialized technical skill likely not found within standard organizational structure, justifying an Independent Contractor agreement.

**Explanation**:
Responsible for the high-level blueprinting of all genetic modifications (aesthetics, longevity, emotion pathways) and direct oversight of the CRISPR/Prime Editing execution, ensuring synergy between Decision 1 and Decision 3.

**Consequences**:
Critical failure to integrate the disparate genetic requirements (longevity conflicts with aesthetics), leading to inefficient cohort usage and potential catastrophic technical failure of the custom RNP system.

**People Count**:
min 1, max 2, depending on scale

**Typical Activities**:
Designing and modeling the multi-locus genetic roadmap required to combine aesthetics, longevity pathways (telomerase/GH), and neuro-expression targets; directly overseeing the fabrication and validation of custom RNP delivery systems; optimizing guide RNA specificity to minimize off-target effects during initial germline injection; performing real-time analysis of single-cell sequencing data to establish the minimum viable efficiency threshold for cohort advancement.

**Background Story**:
Dr. Aris Thorne, originally from Cambridge, Massachusetts, developed an obsession with the combinatorial complexity of genetic coding after witnessing his mother's work on early combinatorial chemistry arrays; he holds a Ph.D. in Computational Genomics from MIT, specializing in high-throughput multiplexed editing optimization, and has significant published experience in applying Prime Editing to large mammalian models, mastering the engineering of novel ribonuclear protein (RNP) complexes for precision delivery outside of viral carriers, making him intimately familiar with Decision 1 and Decision 3. His relevance lies in his unique capability to architect the integrated genomic blueprint required to satisfy all three high-level constraints simultaneously, a prerequisite for the Pioneer strategic path.

**Equipment Needs**:
High-performance computational cluster (for in silico modeling), Specialized microinjection system compatible with custom RNP complexes, Access to high-throughput single-cell sequencing platform (e.g., 10x Genomics or similar) for immediate off-target/mosaicism screening.

**Facility Needs**:
Dedicated, sterile Molecular Biology/Embryology Laboratory capable of supporting large animal zygote handling and manipulation, Secured, climate-controlled server room access for computational workload (Decision 1/9).

## 2. Regulatory & Bioethics Strategist (Seoul Focus)

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Regulatory Strategist must possess deep, specific knowledge of South Korean bioethics (MFDS) concerning novel germline editing and controversial neuro-pathway modification. This niche expertise, coupled with the high risk (Risk 3) driving the need for dual regulatory tracks, mandates hiring a specialized, external consultant/contractor.

**Explanation**:
Manages all domestic (South Korean) permitting, bioethics compliance, and strategic engagement with MFDS/Bioethics Committees, specifically focusing on mitigating the existential risk associated with Decision 4 (Neuro-Pathway Targeting) and Decision 7.

**Consequences**:
Operational shutdown or project moratorium (Risk 3), potentially leading to the immediate termination of the most ambitious technical goals (Decision 4) due to non-compliance.

**People Count**:
1

**Typical Activities**:
Conducting confidential Regulatory Impact Assessments (RIA) for the direct neuro-pathway engineering component; drafting initial, compliant documentation for standard germline modification submissions to the MFDS; establishing parallel regulatory briefing packages for secondary jurisdictions (US/EU) as a contingency plan against local moratoriums; advising leadership on bioethics framing for high-novelty genetic alterations.

**Background Story**:
Jihye Park established her career in Seoul, South Korea, after earning a Master's in Law and Bioethics from Yonsei University, followed by a decade consulting directly within the Ministry of Food and Drug Safety (MFDS) regulatory framework, gaining unparalleled insight into the governance of novel biotechnologies; her experience navigating precedent-setting cases for advanced assisted reproductive technologies makes her acutely aware of the tightrope walk required by Decision 4 (Neuro-Pathway Targeting). Jihye is essential because the high-risk 'Pioneer' strategy hinges entirely on her ability to manage the existential threat of regulatory shutdown in the project's primary operating location, Seoul.

**Equipment Needs**:
Secure, encrypted digital communication suite for handling confidential RIA documents, Access to established global regulatory databases (FDA/EMA/MFDS precedents).

**Facility Needs**:
Office space within the Sooam Biotech or a nearby secure administrative building in Seoul to facilitate frequent, direct consultation with MFDS liaisons and IRB boards; A dedicated, soundproof meeting room for confidential bioethics strategy sessions.

## 3. Financial Controller & IP Negotiator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Financial Controller/IP Negotiator handles high-stakes, bespoke negotiations ($100M budget, complex JV structures, proprietary tech vesting). This requires specialized legal/financial acumen, which is best sourced from an external expert rather than placing a full-time employee in such a sensitive fiduciary/negotiation role.

**Explanation**:
Accountable for the $100M budget, managing the complex Joint Venture structure (Decision 2), and ensuring IP vesting aligns with technology investment (rebalancing proprietary RNP ownership). Critical for controlling cash flow against operational burn rates (Decision 12).

**Consequences**:
Massive ROI erosion if proprietary tech succeeds but IP is ceded (Issue 3), or rapid budget depletion leading to failure to fund necessary long-term carrier upkeep (Issue 2).

**People Count**:
1

**Typical Activities**:
Leading negotiations with Sooam Biotech to rebalance IP vesting terms, specifically isolating ownership of the custom RNP delivery system; monitoring the $100M burn rate against milestone achievement schedules; structuring off-take agreements and calculating projections for the 20-year liability funding mechanism (Issue 2); ensuring upfront IP allocation ($15M) is tied to performance milestones rather than fixed cash transfer.

**Background Story**:
Marcus 'Marc' Varela, who began his career negotiating complex pharmaceutical licensing deals in San Francisco before moving to specialized biotech M&A, brings a rigorous focus on capital preservation and return on investment; he earned an MBA from Wharton and has direct experience structuring joint ventures where proprietary technology development clashes with fixed budget ceilings, making him an expert in Issue 3. Marcus is vital because he is tasked with ensuring that the massive investment in proprietary tooling (Custom RNP) under the Pioneer strategy yields an equitable return, directly challenging the initial 90% IP cession proposed in Decision 2, while managing the strict $100M ceiling.

**Equipment Needs**:
Advanced financial modeling and accounting software capable of tracking cross-currency transactions (USD/KRW) and complex vesting schedules; Secure digital vault for holding critical IP documentation and negotiation strategy briefs.

**Facility Needs**:
Small, dedicated contractual office space or executive suite access near the main project management hub in Seoul, suitable for hosting sensitive legal/financial negotiations with Sooam representatives.

## 4. Longevity & Pathology Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Longevity/Pathology Specialist is critical for mitigating the high risk associated with aggressive epigenetic manipulation (Risk 2). This specialized role in gerontology/oncology niche is highly specialized and best secured on a consultancy or project-based contract linked to milestone monitoring.

**Explanation**:
Expert in gerontology, telomerase signaling, and oncogenesis in canines. Responsible for designing and rigorously monitoring the biomarkers necessary to validate the 20-year longevity constraint (Decision 3, Risk 2 mitigation).

**Consequences**:
Failure to detect early-stage oncogenesis or metabolic failure resulting from aggressive editing, leading to long-term project failure after significant sunk costs (Risk 2).

**People Count**:
1

**Typical Activities**:
Designing the specific panel of biomarkers (p53, telomere length variance) to monitor all early-stage embryos for divergence from longevity targets; advising the Genomic Architect on acceptable levels of initial growth perturbation; managing the specialized pathology consultation budget ($5M contingency); developing the termination protocol for lines showing early signs of metabolic dysregulation.

**Background Story**:
Dr. Elara Vance, based out of Austin, Texas, is a leading veterinary gerontologist with a focus on canine aging models and signaling pathway manipulation, having spent years studying the long-term effects of modified growth hormone treatments in sporting breeds; she specialized in designing non-invasive biomarker panels to track senescence and oncogenic risk in preclinical trials, directly informing the necessity of Assumption 5. Dr. Vance is irreplaceable because the 20-year behavioral promise (Decision 3) is scientifically the weakest link, and her expertise is required to design the necessary fail-safes that mitigate the catastrophic risk of late-stage pathology manifesting across extended timelines.

**Equipment Needs**:
Specialized longitudinal monitoring hardware (e.g., continuous metabolic sensors, advanced telemetry equipment for monitoring small mammal respiration/temperature variation); High-throughput biochemical assay machines capable of precise, recurring telomere length and p53 profiling.

**Facility Needs**:
Access to a dedicated, secure small animal pathology suite with cutting-edge histological preparation tools; Close proximity to a specialized veterinary oncology/endocrinology referral hospital for planned external consultations.

## 5. Behavioral & Emotional Metric Validation Lead

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Behavioral/Emotional Metric Validation Lead is responsible for creating and executing unique measurement protocols (Decision 5) linking genetics to psycho-emotional output. This innovative, high-variability research requirement suits an external contractor specializing in psychometrics or neuro-testing integration.

**Explanation**:
Designs the testing protocols to quantify the 'maximal dopamine/oxytocin release' (Decision 5) and establish reliable, early proxies for the 20-year juvenile behavior (Decision 8). Focuses on the link between genetics and human outcome.

**Consequences**:
The primary success metric (emotional release) cannot be verified, rendering the entire technical endeavor commercially useless ('beautiful failure').

**People Count**:
min 1, max 2, depending on trial complexity

**Typical Activities**:
Developing the standardized operating procedure (SOP) for the human observation trials measuring cortisol reduction and oxytocin spikes; cross-validating the success metric against subjective scoring scales (Decision 5 Choice 2); designing early behavioral tests (Decision 8 proxies) that correlate with the eventual emotional payoff; providing iterative feedback to the Aesthetics Modeler regarding phenotype adjustments that enhance emotional scoring.

**Background Story**:
Dr. Lena Hanson, who trained in comparative psychology in the Netherlands, is a specialist in quantifying transient human emotional states using advanced fMRI and hormonal analysis, dedicating her career to translating subjective stimuli into objective neurochemical signatures, directly informing the requirements of Decision 5; she was involved in precursor studies that mapped visual cuteness triggers to oxytocin release in primates. Dr. Hanson's role is to provide the only verifiable measure of commercial success for the project: ensuring that the engineered dog triggers **maximal** dopamine/oxytocin release, thereby bridging the gap between successful genetic engineering and market utility.

**Equipment Needs**:
Functional Near-Infrared Spectroscopy (fNIRS) or functional MRI (fMRI) equipment capable of monitoring localized brain response in human observers; Commercial-grade hormonal assay platform for high-frequency measurement of Oxytocin and Cortisol spikes.

**Facility Needs**:
Access to a certified, IRB-approved Human Subject Testing Facility (Clinical Research Unit) equipped to handle the controlled psychological/biometric testing protocols required to validate Decision 5.

## 6. Advanced Animal Husbandry & Logistics Manager

**Contract Type**: `agency_temp`

**Contract Type Justification**: The Advanced Animal Husbandry/Logistics Manager oversees operational needs, including securing surrogate carriers and managing high-cost long-term housing (Risk 5, Issue 2). While critical, the high volume of associated tasks (carrier sourcing, facilities oversight) is often best managed by leveraging specialized labor or agencies familiar with local Seoul veterinary/husbandry logistics.

**Explanation**:
Oversees all physical resources: securing and auditing surrogate carriers, managing specialized housing facilities required for the 'chinchilla feel' and 20-year juvenile environment (Risk 5), and allocating cohort resources (Decision 12).

**Consequences**:
Operational bottlenecks preventing gestation of edited embryos, or catastrophic cost overruns due to inadequate/non-specialized housing solutions, jeopardizing the 20-year sustainment plan (Issue 2).

**People Count**:
2

**Typical Activities**:
Securing Memorandums of Understanding (MOUs) with specialized Seoul-area veterinary clinics for surrogate carrier access; calculating and enforcing the operational burn-rate ceiling for specialized 'chinchilla feel' housing environments (Risk 5); sourcing and auditing initial batches of surrogate females; managing the interface between the genetic engineering lab and the long-term husbandry facilities.

**Background Story**:
Joon-Ho Kim spent his early career managing complex logistical supply chains for high-value agricultural exports across East Asia before specializing in managing large-scale, high-security animal facilities near Seoul for a specialized biomedical institute; he is uniquely adept at navigating South Korea's local veterinary specialist capacity and sourcing high-grade, non-standard animal housing solutions required by Risk 5 and Issue 2. Joon-Ho is critical for translating the R&D success into physical reality, responsible for securing the necessary surrogate carriers and establishing the expensive, specialized long-term housing required to sustain the 20-year behavioral trials.

**Equipment Needs**:
Logistics planning software optimized for tracking specialized veterinary supplies and carrier capacity timelines; Environmental monitoring sensors necessary to verify 'chinchilla feel' housing stability (dermal roughness/temperature/humidity control systems).

**Facility Needs**:
Secured, off-site specialized animal husbandry facilities near Seoul capable of climate control and providing customized enrichment environments (compliant with Risk 5 projections); MOUs and accessible facilities at partner veterinary clinics capable of handling specialized canine surgical recovery post-embryo transfer.

## 7. Aesthetics & Sensory Modeler

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Aesthetics/Sensory Modeler's role focuses on translating abstract visual goals into actionable genetic targets (Decision 9) using computational tools. This niche intersection of biology and advanced modeling is ideal for a specialized contractor whose services can be engaged until the aesthetic framework is locked down.

**Explanation**:
Translates the subjective aesthetic goals ('seal pup,' 'cartoon') into quantifiable genomic targets for the editing team (Decision 9, Decision 6), leveraging computational/3D modeling to guide iterative phenotypic synthesis.

**Consequences**:
The aesthetic editing process becomes purely trial-and-error, drastically increasing cohort failure rates and potentially creating a phenotype that actively counteracts the desired emotional response (Risk 6).

**People Count**:
1

**Typical Activities**:
Creating computational models illustrating the genomic architecture required for the three-part aesthetic synthesis (Decision 9); developing low-fidelity predictive 3D reconstructions based on simulated edits to guide the Aesthetics Iteration Cycle (Decision 6); analyzing interaction risks between aesthetic edits and structural viability to prevent biological incoherence (Risk 6).

**Background Story**:
Priya Sharma, based virtually from a remote consulting hub in Singapore, is a computational biologist whose expertise lies in mapping complex, disparate aesthetic features onto coherent genetic expression patterns using physics-informed modeling, bridging the gap between descriptive goals and actionable genomic targets; she has extensive experience optimizing gene expression profiles for pleiotropic effects, essential for achieving the 'seal pup' dermal characteristics alongside canine skeletal structure (Decision 9). Priya is essential as she converts the subjective, aspirational look ('Golden Retriever puppy, seal pup, cartoon character') into the specific gene modulation targets required by the Lead Genomic Architect.

**Equipment Needs**:
High-fidelity 3D modeling and simulation software (e.g., packages used in CGI or advanced biophysics) for predictive phenotype generation; Licensed software suite for computational analysis of Hox gene expression outcomes relating to craniofacial morphology (Decision 9).

**Facility Needs**:
Dedicated remote workstation connectivity suitable for high-demand modeling tasks, likely requiring access to cloud computing resources or a dedicated workstation within the main R&D facility if physical modeling is required.

## 8. Long-Term Data & Operations Sustainability Officer

**Contract Type**: `part_time_employee`

**Contract Type Justification**: The Long-Term Data/Operations Sustainability Officer, responsible for securing the 20-year liability funding plan (Issue 2), has immediate high-priority setup tasks but a long tail of oversight. This role requires core institutional continuity, making part-time employment suitable initially, shifting to full-time if long-term funding escrow is secured, or remaining part-time for monitoring.

**Explanation**:
Focuses solely on the 20-year operational liability, securing maintenance contracts for monitoring data (DLM - Assumption 8), and structuring contingency plans to ensure post-R&D funding continuity for the successful carrier lines.

**Consequences**:
Project success results in immediate financial insolvency once the 20-year care liability comes due; the successful animals risk being abandoned or re-purposed due to a funding cliff (Issue 2).

**People Count**:
1

**Typical Activities**:
Contracting and managing the 20-year Data Lifecycle Management (DLM) system to safeguard longitudinal behavioral and pathology data; ensuring data streams automatically feed into the Longevity Specialist’s monitoring protocols; structuring the funding escrow mechanism (in coordination with the Financial Controller) specifically to cover the ongoing DLM costs post-development phase.

**Background Story**:
Kenji Tanaka, based in Tokyo, possesses a rare specialization in establishing long-term data governance frameworks for high-value, low-frequency biological outputs in life sciences, focusing particularly on structuring data lifecycle management (DLM) for decades-spanning research cohorts, making him the expert on Assumption 8; his experience comes from overseeing multi-generational studies in regenerative medicine where data integrity over 20+ years is crucial. Kenji’s primary function is to ensure that when the project succeeds biochemically, the ensuing 20 years of legacy data—essential for proving the longevity claim—is securely and affordably maintained, thus mitigating the financial liability cliff identified in Issue 2.

**Equipment Needs**:
Enterprise-level Data Lifecycle Management (DLM) contract and secure, long-term digital archive infrastructure (off-site cold storage) capable of guaranteeing 20 years of data accessibility; Financial tracking tools to isolate and manage the long-term liability escrow account (Issue 2).

**Facility Needs**:
Secure data storage location (physical or certified cloud service) compliant with long-term scientific data retention standards; Small, dedicated workspace for periodic review meetings with the Financial Controller.

---

# Omissions

## 1. Missing Quality Assurance/Control (QA/QC) Role

Given the extreme complexity (Pioneer strategy), reliance on custom RNP delivery, and the critical nature of the 20-year longevity and neuro-pathway targets, there is no dedicated role explicitly responsible for enforcing independent quality gates (beyond the input from the Pathology Specialist). This is crucial for validating germline purity before expensive cohort rearing begins.

**Recommendation**:
Integrate a formal Quality Assurance function, even if it is only 25% dedicated time from the Lead Genomic Architect or as a dedicated sub-task within one contractor's mandate. This entity must approve all Go/No-Go decisions related to editing efficiency (e.g., moving past the hypothetical 25% threshold) before incurring significant husbandry costs.

## 2. Undefined Role for Iterative Sensory/Aesthetic Testing Execution

The Aesthetics & Sensory Modeler (Role 7) handles *modeling*, and the Emotional Metric Validation Lead (Role 5) handles *human testing*. There is no dedicated operational staff to physically execute the rapid, low-fidelity sensory interaction trials required by Decision 6, or to prepare the necessary cohort animals for these ongoing feedback loops, leading to delays.

**Recommendation**:
Allocate resource management or assign a subset of the Advanced Animal Husbandry Manager's (Role 6) team (perhaps 1 FTE technician) to be the primary executor for all Decision 6 iteration cycles, ensuring rapid setup and teardown of sensory testing environments.

## 3. Lack of Dedicated South Korean (KRW) Financial/Procurement Liaison

The Financial Controller (Role 3) focuses highly on USD budget tracking and high-stakes IP negotiations. However, managing high-volume local transactions (KRW payments for housing, vet services, local staffing) while mitigating currency risk is complex and risks distracting the high-value Financial Controller.

**Recommendation**:
Empower the Advanced Animal Husbandry Manager (Role 6), given their local expertise, to manage day-to-day KRW expenditure tracking against allocated budgets for housing and local operational support, reporting summary burn rates weekly to the Financial Controller.

---

# Potential Improvements

## 1. Clarify Ownership/Risk Transfer for Custom RNP Tooling

The team chose the Pioneer strategy, heavily investing in custom RNP development (Decision 1). The Financial Controller is negotiating to retain IP rights for this proprietary tool, but the current roles do not explicitly define the handover protocol post-validation success.

**Recommendation**:
The Lead Genomic Architect (Role 1) must formally transfer the validated, proprietary RNP construction blueprint and fabrication methodology to the Financial Controller/Legal team (Role 3) or a specified escrow agent immediately upon meeting the Month 8 germline benchmark (Assumption 2), ensuring vesting conditions can be met.

## 2. Strengthen Link between Longevity Pathology Monitoring and Editing Protocol

The Longevity Specialist (Role 4) monitors pathology, and the Genomic Architect (Role 1) sets the editing blueprint. The process needs a mandatory, formalized feedback loop to dynamically adjust editing parameters mid-cycle based on pathological findings.

**Recommendation**:
Institute a mandatory Bi-Weekly Protocol Review Meeting involving Role 1 and Role 4. Any pathology indication exceeding a preset sub-threshold tolerance must trigger an immediate, documented pause in cohort embryo injection until Role 1 reviews the feasibility of tightening Decision 3 genomic targets based on Role 4's real-time pathology data.

## 3. Formalize Contingency Pivot Strategy for Decision 4 (Neuro-Pathway)

Due to the existential regulatory risk (Risk 3) associated with direct neuro-pathway engineering, the plan must clearly define the operational steps to pivot to 'Cognitive Cue Optimization' if the Regulatory Strategist (Role 2) indicates a high probability of failure.

**Recommendation**:
The Regulatory Strategist (Role 2) must deliver the formal 'Pivot Readiness Report' by Year 2 Q1. This report must immediately trigger a mandatory reallocation of 50% of the Aesthetic/Sensory Modeler’s (Role 7) scheduled work time to focus exclusively on defining the genetic targets for the auditory/visual cognitive cues outlined in Decision 4, Choice 2.