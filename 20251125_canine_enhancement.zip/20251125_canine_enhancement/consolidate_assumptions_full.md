# Purpose

**Purpose:** business

**Purpose Detailed:** Large-scale biological engineering project with significant financial investment, likely intended for research, commercialization, or application within a biotech/research institution aiming for a novel outcome.

**Topic:** Genome modification of a dog for maximal human emotional response

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan is an extremely complex, large-scale biological engineering project involving genetic modification (CRISPR-Cas9, Prime Editing) of a living organism (a dog). This *absolutely requires* a physical laboratory, specialized equipment, biological materials, and a physical presence at the specified research institution (Sooam Biotech Research Foundation in Seoul). Even if the *design* aspects could be conceptualized digitally, the *execution* is entirely dependent on specialized physical facilities and manipulation of biological samples.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Access to advanced molecular biology/CRISPR/Prime Editing lab facilities
- Institutional partnership with established veterinary/canine genetics research capabilities
- Compliance with South Korean regulatory bodies for advanced genetic engineering

## Location 1
South Korea

Seoul

Sooam Biotech Research Foundation

**Rationale**: This location is explicitly named in the plan as the required research institution to execute the complex genomic modifications (CRISPR-Cas9/Prime Editing).

## Location 2
South Korea

Seoul Metropolitan Area

Proximity to specialized canine research/veterinary hospitals

**Rationale**: The project requires long-term behavioral validation (20 years) and housing of canine subjects, necessitating close access to high-quality veterinary support systems near the primary lab.

## Location 3
Global

International Biotech Hubs (e.g., Boston, San Francisco Bay Area, or Singapore)

IP/Regulatory Consulting Offices

**Rationale**: Given the critical Decision 2 (IP structure) and Decision 7 (Regulatory Pathway), establishing a secondary, specialized administrative/legal presence in a global biotech hub is recommended to manage international IP claims and future commercialization outside of South Korea.

## Location Summary
The primary required location is the Sooam Biotech Research Foundation in Seoul, South Korea, as specified for executing the genetic engineering. Secondary suggestions include proximity to specialized canine care facilities in Seoul for the 20-year behavioral constraint and a presence in a major international biotech hub for managing the high-stakes IP and global regulatory compliance.

# Currency Strategy

This plan involves money.

## Currencies

- **KRW:** Local currency for daily operational expenses, local labor, and services within Seoul, South Korea.
- **USD:** The project budget is denominated in USD ($100M) and it is the recommended currency for high-value international procurement, IP licensing fees, and risk mitigation against KRW volatility.

**Primary currency:** USD

**Currency strategy:** Due to the extremely large budget ($100M USD) and the high-risk, high-novelty nature of the research, USD will serve as the primary currency for budgeting, reporting, and major international procurement (e.g., proprietary RNP systems). KRW will be used for localized, day-to-day operational spending in Seoul. Budget reporting will maintain USD parity to stabilize valuation against potential economic shifts in South Korea.

# Identify Risks


## Risk 1 - Technical/Genomics
Failure of the custom RNP delivery system (selected via Pioneer strategy) to achieve high on-target efficiency in canine zygotes, leading to low rates of viable, correctly modified embryos.

**Impact:** If efficiency is below 10% for germline modification, the project will require launching 5-10 times the planned breeding cohorts, leading to a mandatory budget overrun exceeding $30M USD or a minimum 12-month delay pending development of a new delivery method.

**Likelihood:** High

**Severity:** High

**Action:** Immediately initiate parallel validation tracks for off-the-shelf viral vectors, even while developing the proprietary RNP system. Define a 'minimum viable editing efficiency' threshold (e.g., 20%) at which the RNP system must perform by Month 6, triggering mandatory pivot to the backup vector system.

## Risk 2 - Technical/Longevity
The selected aggressive manipulation of telomerase/growth hormone pathways for the 20-year constraint results in unforeseen pathology, such as oncogenesis (cancer) or severe metabolic dysregulation, rendering the engineered animal non-viable or unsuitable for human interaction.

**Impact:** Complete project failure, as the 20-year promise is invalidated. If pathology manifests late (Year 5+), the sunk cost, including carrier maintenance and personnel wages, will approach $50M USD.

**Likelihood:** Medium

**Severity:** High

**Action:** Implement stringent, parallel biomarker monitoring (Decision 5 alignment) focused specifically on cellular senescence and proliferation markers across all cohorts, starting from utero. Allocate $5M USD for specialized pathology consultation (oncology/endocrinology) from Year 1.

## Risk 3 - Regulatory & Permitting
The decision to pursue high-efficacy direct neuro-pathway engineering for oxytocin release (Decision 4) triggers severe domestic opposition or an immediate regulatory moratorium from South Korean authorities (e.g., MFDS) regarding inherent risk to human subjects in testing.

**Impact:** If foreign regulatory bodies are not simultaneously courted (Decision 7 choice), the project could face a full operational shutdown in Seoul for 18-36 months pending bio-ethical review escalation, incurring $15M USD in fixed sustainment costs during non-work periods.

**Likelihood:** High

**Severity:** High

**Action:** Immediately fund dual legal/regulatory tracks. While proceeding under the strictest allowable research exemption in Seoul, deploy resources (per Location 3 rationale) to secure preliminary, confidential regulatory assessments in a globally accepted jurisdiction (e.g., US/EU) concerning the *methodology* (CRISPR) independent of the *outcome* (neuro-pathway target).

## Risk 4 - Financial/Budget Overrun
The high-IP-share joint venture strategy (Decision 2) combined with the necessary proprietary tooling (Decision 4) depletes operational cash reserves quickly, leading to shortfalls in covering the high costs associated with specialized surrogate carriers and personnel retention.

**Impact:** A core budget shortfall of $10M-$20M USD can be projected for Year 3 unless milestones are met perfectly. Failure to fund carrier upkeep translates directly to loss of validated animal lines.

**Likelihood:** High

**Severity:** Medium

**Action:** Structure the IP Joint Venture payment milestones critically. Tie 30% of the external entity’s equity vesting to the successful operational funding status at monthly intervals in Year 2 and Year 3. Aggressively pursue targeted pre-seed funding rounds based on initial germline success to augment the $100M buffer.

## Risk 5 - Operational/Animal Husbandry
The complexity of maintaining the 'acts like a 4-month-old puppy' phenotype for 20 years requires specialized, high-energy behavioral enrichment that exceeds standard canine care costs and stresses the allocated budget for Location 2 support facilities.

**Impact:** Operational costs for long-term housing and behavioral management could increase by 150% over standard geriatric canine care projections, potentially costing an extra $50,000 USD per animal per year post-juvenile phase.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a scientifically verifiable proxy for the 20-year juvenile state (Decision 8) that is less resource-intensive than constant physical supervision. Calculate the expected number of failure cohorts (due to longevity issues) and cap the maximum number of long-term housing units budgeted based on the remaining $100M margin after Year 5.

## Risk 6 - Technical/Aesthetics & Emotion Conflict
The highly novel aesthetic targets ('seal pup,' 'cartoon') created by sequential layering (Decision 9) might inadvertently disrupt the subtle behavioral expression or sensory organs required for triggering maximal human oxytocin/dopamine release.

**Impact:** The animal is aesthetically novel but fails to generate the target emotional response, rendering the primary commercial value proposition void. This results in a 'beautiful failure' and a 100% loss of market potential.

**Likelihood:** Medium

**Severity:** High

**Action:** Mandate early, qualitative human-animal interaction trials (even with placeholder phenotypes) concurrent with aesthetic editing (Decision 6 alignment). If the emotional response score (Decision 5 Metric) drops below 75% of the established baseline when aesthetic deviation is high, immediately halt aesthetic layering to stabilize core behavioral genes.

## Risk 7 - Supply Chain
Inability to secure or high cost volatility for necessary proprietary, cutting-edge RNP/Prime Editing components (Decision 10), especially if they rely on niche suppliers outside of South Korea.

**Impact:** If high-fidelity effector complexes are held up or surge in price post-initial contract (due to low initial commitment), project continuity stops for 2-3 months or requires an unplanned $1M-$3M USD procurement expenditure.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Secure 18 months of critical reagent buffer stock immediately upon contract signing (Year 1 Q2). Lock in pricing structures for recurring, high-value consumables using the USD portion of the budget, transferring currency risk away from the KRW operational budget.

## Risk 8 - Social/Ethical Concerns
Intense public backlash and social pushback against the 'unnaturalness' of creating an organism with highly engineered aesthetic and neurochemical manipulation qualities, leading to protests or non-regulatory operational interference at the physical site in Seoul.

**Impact:** Reputational damage halting investor confidence, potentially leading to cessation of funding, irrespective of regulatory approval. Could lead to increased security costs or temporary site closure (1-4 weeks).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a proactive, transparent communications strategy focused on the scientific rigor and therapeutic benefit (emotional well-being) of the research, leveraging the expertise of the partner institution (Sooam). Prepare a crisis communication plan focusing on 'responsible evolution of companion species research.'

## Risk summary
This project represents a 'Pioneer' moonshot endeavor due to its aggressive performance targets (20-year longevity, maximal emotional engineering) demanding high-risk technical choices, such as custom RNP delivery and direct neuro-pathway targeting. The three most critical risks all carry High Likelihood/High Severity ratings and center on the core objectives: 

1. **Technical Failure of Custom Editing System:** The reliance on proprietary tooling (RNP/Prime) for the foundational work makes it the primary point of technical failure, directly threatening efficacy and budget ($30M+ overrun risk). 
2. **Regulatory Blockade on Emotional Engineering:** The choice to directly manipulate human neuro-pathways via the animal vector is an extreme regulatory hurdle, risking operational shutdown in the primary location.
3. **Longevity Pathology:** Failure of the aggressive epigenetic strategy to maintain youthfulness without causing inherent disease (e.g., cancer) invalidates the entire 20-year value proposition.

Mitigation requires immediate parallel planning (backup editing tools, dual regulatory tracks) even if it strains the $100M budget initially, illustrating a necessary trade-off: accepting short-term budgetary pressure to safeguard long-term viability against catastrophic technical or ethical failure.

# Make Assumptions


## Question 1 - Given the $100M USD budget, what specific percentage allocation is planned for upfront Intellectual Property (IP) establishment costs, including joint venture structuring and background IP licensing fees with Sooam Biotech?

**Assumptions:** Assumption: Due to the complexity of Decision 2 (IP Alignment) and the high-risk Pioneer strategy selected, 15% of the total budget ($15M USD) will be ring-fenced for initial IP negotiation, legal counsel, and upfront milestone payments to Sooam within the first 12 months.

**Assessments:** Title: Funding & Budget Allocation Assessment
Description: Evaluation of the initial capital allocation against high-impact, non-technical upfront mandatory costs.
Details: A $15M initial IP allocation is appropriate for establishing the JV structure under a high-leverage scenario, but it strains the operating buffer needed for unexpected reagent costs (Risk 7). Opportunity exists to negotiate milestone payments tied to genetic stability (Decision 4) rather than fixed upfront cash to smooth cash flow across Year 1, potentially mitigating the immediate high depletion rate associated with the Pioneer strategy's proprietary tooling.

## Question 2 - What is the target date for achieving the first successful germline modification using the custom RNP system, considering the aggressive 'start ASAP' directive and the high technical risk of Decision 1?

**Assumptions:** Assumption: Given the start date of 2026-Apr-28, and the critical nature of the custom RNP development, the target date for validated, stable germline insertion (first successful cohort launch) is set for Month 8 (December 31, 2026).

**Assessments:** Title: Timeline & Milestone Assessment
Description: Review of the feasibility of the initial critical technical milestone given the high-risk technology choice.
Details: An 8-month timeline for achieving validated germline modification with a custom RNP system is highly aggressive (Time Constraint Risk). Failure to meet this milestone by Month 10 forces a transition to the backup viral vector system, impacting the complexity of subsequent Longevity Constraint edits (Decision 3). Benefit: Meeting this date rapidly validates the custom tooling, providing a significant operational advantage.

## Question 3 - How many dedicated full-time equivalent (FTE) research staff (genomic engineers, biotechnologists) will be dedicated solely to the custom RNP delivery development (Decision 1) versus behavioral validation (Decision 8) in Year 1?

**Assumptions:** Assumption: The high-risk Pioneer strategy requires a 60/40 split in Year 1 FTE allocation: 60% (e.g., 12 FTEs) dedicated to core genetic engineering/delivery optimization, and 40% (e.g., 8 FTEs) dedicated to establishing the complex Long-Term Behavioral Validation schedule (Location 2 support).

**Assessments:** Title: Resources & Personnel Assessment
Description: Analysis of resource allocation between foundational technology development and long-term operational support.
Details: A 60% focus on the custom RNP toolset (Decision 1) appropriately balances the recognized high risk of technical failure (Risk 1). The remaining 40% dedicated to behavioral validation ensures early planning for the 20-year constraint. Risk: Personnel burnout or skill gaps in combining exotic aesthetics (Decision 9) with neurochemistry monitoring may be high if FTEs are not cross-trained.

## Question 4 - What specific certifications or preliminary regulatory discussions (beyond standard institutional IRB/IACUC equivalents) are already underway at Sooam regarding the highly novel direct neuro-pathway targeting required by Decision 4?

**Assumptions:** Assumption: No formal, high-level regulatory discussions regarding direct pathway manipulation in a companion animal have occurred yet; initial steps involve structuring internal review to align research with South Korean bio-ethics counsel by Month 3, preparing for inevitable scrutiny (Risk 3).

**Assessments:** Title: Governance & Regulations Assessment
Description: Review of readiness concerning the highest regulatory hurdle: engineering human neuro-pathway influence.
Details: Assuming no preliminary discussions exist, Risk 3 severity is critically high, as this move potentially shifts the project into highly controlled areas usually reserved for therapeutic human applications. Opportunity exists by framing the initial testing entirely around objective markers (cortisol/oxytocin metrics - Decision 5) rather than subjective 'happiness' to navigate initial governance stages within the existing research framework in Seoul.

## Question 5 - Beyond standard institutional safety protocols, what specific, dedicated risk contingency budget line item is set aside to address the high probability of oncogenesis or severe metabolic disorder stemming from the aggressive 20-year longevity edits (Risk 2)?

**Assumptions:** Assumption: Based on Risk 2 severity, $5M USD (5% of the total budget) will be explicitly allocated via Decision 3 constraints for specialist pathological consultation, advanced longitudinal monitoring hardware, and rapid response drug compounding/intervention trials.

**Assessments:** Title: Safety & Risk Management Assessment
Description: Quantification of the dedicated financial buffer against the most severe biological technical risk (cancer/pathology).
Details: Establishing a $5M specialized fund directly addresses the high-severity cancer/longevity risk. This proactive spending mitigates the sunk cost potential ($50M loss projected by Risk 2). Benefit: Early consultation helps refine the Prime Editing targets to avoid known oncogenic drivers, improving safety without sacrificing the 20-year performance target.

## Question 6 - What specific, quantifiable, non-mammalian biological markers associated with the 'chinchilla feel' tactile requirement must be measured in early-stage phenotyping trials to ensure operational consistency?

**Assumptions:** Assumption: The 'chinchilla feel' translates to maintaining a specific dermal surface roughness and hair/fur density profile. Target metrics will involve standardized surface profiling (e.g., fractal dimension analysis) aiming for a 90% match to control chinchilla samples for pilot cohorts.

**Assessments:** Title: Environmental Impact Assessment (Proxy)
Description: Analysis of the impact of specific aesthetic engineering requirements on biological consistency and resource usage.
Details: While direct environmental impact is low, ensuring the required dermal morphology (part of the aesthetic goal) is replicable is crucial. If the required dermal layer complexity necessitates highly specific, non-standard nutrient inputs or specialized climate-controlled housing beyond standard canine care (Risk 5), this could escalate operational costs disproportionately, potentially increasing the 'environmental footprint' of specialized animal housing exponentially.

## Question 7 - Considering the necessary administrative and regulatory complexity of Decision 7 (Global IP/Regulation), what tangible milestones are scheduled for establishing the secondary IP/Regulatory office (Location 3) and what resources are allocated for this in Year 1?

**Assumptions:** Assumption: The IP office establishment (Location 3) is defined as a Year 1, Q3 milestone, requiring the immediate hiring of 1 dedicated senior International IP Counsel and allocating $1.5M USD for initial legal fees and establishing basic operational presence alongside Sooam's legal team.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the structured engagement with external legal stakeholders necessary for global commercialization.
Details: Allocating $1.5M early for specialized counsel (Decision 7) is vital to manage the conflict between proprietary tooling costs and IP structuring (Decision 2). Failure to embed international legal expertise early risks making the proprietary Joint Venture structure financially unfavorable upon global licensing. Opportunity: Early engagement allows proactive shaping of regulatory submissions to satisfy multiple jurisdictions, reducing future re-validation costs.

## Question 8 - Since the project runs for 20 years, what specific maintenance contract or budget line item is established to sustain the required specialized digital monitoring and data retention systems (e.g., longitudinal behavioral performance logs) required until Year 20?

**Assumptions:** Assumption: A dedicated 20-year data lifecycle management (DLM) contract will be secured in Year 2 (following initial germline success), budgeted at $500,000 USD annually, covering secure, redundant data storage in both USD-denominated international hubs (Location 3) and local Seoul servers.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the long-term viability and cost modeling for essential data infrastructure supporting the 20-year constraint.
Details: Committing to a $500K/year DLM contract starting in Year 2 front-loads a significant operational expense but directly mitigates the massive risk of data loss impacting the 20-year proof requirement. This operational system must be explicitly insulated from potential Year 3 budget shortfalls (Risk 4) by being funded from the dedicated $15M IP allocation if necessary, ensuring data integrity remains paramount.

# Distill Assumptions

- Fifteen million USD is ring-fenced for initial IP negotiation and upfront payments with Sooam.
- Validated germline insertion target launch date is December 31, 2026 (Month 8).
- Year 1 FTE allocation is 12 for genetics and 8 for long-term behavioral validation.
- No formal high-level regulatory discussions exist for direct neuro-pathway manipulation.
- $5 million USD is explicitly allocated for oncogenesis/metabolic disorder risk contingency.
- Tactile success requires 90% match to chinchilla surface fractal dimension and density.
- A Year 1 Q3 milestone requires allocating $1.5M for establishing the secondary IP office.
- A $500,000 annual data lifecycle management contract starts in Year 2 for 20 years.

# Review Assumptions

## Domain of the expert reviewer
Biotechnology Project Management and Risk Assessment

## Domain-specific considerations

- Regulatory compliance for germline editing in South Korea
- Longitudinal biological stability (20-year constraint)
- Financial control over a high-cost, high-novelty technology stack (CRISPR/Prime)
- Ethical and public perception management of neuro-pathway targeting
- Complex IP structuring in an international joint venture

## Issue 1 - Critical Missing Assumption: Regulatory Pathway for Direct Neuro-Pathway Interventions
The plan aggressively selects the 'Pioneer' route, including 'Implement direct, high-expression transcription factor overexpression targeting the primary neural pathways responsible for oxytocin signaling magnitude in human observers' (Decision 4). The provided assumptions explicitly note that *no formal, high-level regulatory discussions* have occurred regarding this highly controversial intervention (Assumption 4 Assessment). Regulatory bodies, especially in sensitive jurisdictions, treat engineered alterations of human neurochemical response triggers with extreme scrutiny, likely mandating levels of preclinical toxicology and ethical review far exceeding standard animal husbandry protocols (IACUC).

**Recommendation:** Immediately halt any explicit planning for *in vivo* human testing until a comprehensive Regulatory Impact Assessment (RIA) is completed by specialized bioethics counsel in conjunction with the South Korean MFDS expectations *for this specific intervention type*. Develop a mandatory phased fallback: If direct pathway intervention yields a regulatory halt in Year 2, the project must pivot immediately to the 'Cognitive Cue Optimization' pathway (Decision 4, Strategic Choice 2, which requires less regulatory heat).

**Sensitivity:** A delay in obtaining the necessary regulatory go-ahead for the neuro-pathway trial (baseline: Q4 Year 2) could introduce a 12-24 month regulatory hold. This delay, compounded by associated sustainment costs ($15M noted in Risk 3), would reduce the overall project ROI by an estimated 25%-45% compared to the baseline expectation derived from the $100M budget and projected commercial timeline, assuming the pivot (Decision 4 fallback) is successful.

## Issue 2 - Critical Missing Assumption: Quantification of 20-Year Longevity Maintenance Cost Structure
The success hinges on a 20-year lifespan maintenance constraint (Decision 3), with a dedicated $5M contingency for *pathology* (Assumption 5). However, there is no assumption detailing the operational budget breakdown required to *sustain* 10+ healthy, specially housed dogs for 20 years post-initial editing success. Standard canine care costs are inadequate (Risk 5 noted a 150% increase over projections). The financial model must account for 20 years of highly specialized care, feed, veterinary services, and longitudinal biomarker monitoring (Assumption 8 notes a $500K/year DLM cost, but not equivalent husbandry costs). This omission threatens the long-term financial viability long after the initial $100M is spent.

**Recommendation:** Establish a mandatory post-development funding mechanism *now*. Calculate the projected 20-year housing/husbandry cost for the expected number of successful carrier lines (e.g., 5 lines). If this exceeds $10M, secure an external endowment or structure a mechanism within the Joint Venture (Decision 2) to cover these costs, perhaps by securing an early license fee linked specifically to long-term animal liabilities, protecting the initial $100M investment from becoming a liability sinkhole.

**Sensitivity:** If total 20-year projected husbandry costs (excluding the $500K data budget) are conservatively estimated at $4M per animal line, and 5 lines are successful, baseline costs for longevity management post-initial R&D phase could reach $20M. A failure to secure this funding stream will devalue the final product by $20M (20% of the initial budget value) as the owners would bear crippling operational liability.

## Issue 3 - Under-Explored Assumption: IP/JV Structure Conflict with Technical Velocity
The plan chooses the 'Pioneer' path, which entails developing a *custom RNP delivery system* (Decision 1) and structuring the IP as a *Joint Venture granting 90% IP rights* contingent on timely delivery (Decision 2). The assumption allocates $15M for IP negotiation (Assumption 1). The conflict is that developing proprietary RNP tools (high engineering cost) while simultaneously giving away 90% of downstream commercial rights creates a massive financial disconnect. The investment (time, technical resource drain, component cost) required to build a novel toolset is not adequately recouped if 90% of the resulting commercial value immediately flows externally.

**Recommendation:** Re-negotiate Decision 2 structure concerning proprietary tooling. If the external entity utilizes the custom RNP system (Decision 1 achievement), IP vesting must be weighted: 90% rights contingent on timely delivery, but ownership of the *background IP developed within this project* (i.e., the custom RNP system itself) should vest 50/50 or be licensed back to the primary developer for a fixed fee. If the RNP system fails and the backup vector is used, the 90% vesting remains acceptable as less proprietary investment was made.

**Sensitivity:** If the high-cost, custom RNP system is successful (leading to the projected timeline boost), but the 90% IP split remains, the net ROI realized by the primary funding organization could drop from a projected 500% (baseline) to approximately 50%-100% due to limited downstream revenue capture on a highly valuable asset.

## Review conclusion
This 'Pioneer' project is technically ambitious, validated by high-risk choices like custom RNP development and direct neuro-pathway targeting. The review identified three critical weaknesses centered on unsupported operationalization: 1) The unaddressed, high-stakes regulatory pathway for human neuro-pathway manipulation; 2) The lack of a cost model for the 20-year operational sustainment post-R&D; and 3) A major financial misalignment where high investment in proprietary tools is paired with near-total cession of future IP rights. Immediate action must focus on securing a regulatory fallback, defining the 20-year liability budget, and rebalancing the IP agreement to ensure the massive R&D expenditure yields commensurate financial return.