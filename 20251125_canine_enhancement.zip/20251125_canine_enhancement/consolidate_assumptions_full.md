# Purpose

**Purpose:** business

**Purpose Detailed:** Large-scale biotechnology project involving advanced genetic editing (CRISPR/Prime Editing) with a significant budget ($100M USD), intended for creation/research, fitting the scope of a large-scale scientific or commercial endeavor.

**Topic:** Genetic engineering of a companion animal for enhanced human emotional response

# Domain

**Primary domain:** Genetic Engineering

**Secondary domains:** Molecular Biology, Biotechnology Research, Veterinary Medicine

**Rationale:** Genetic Engineering is the primary outcome, as the core success is creating the specifically modified canine genome. While Neuroscience and Behavioral Science define the target effect, they are means to achieve the engineered outcome. Molecular Biology is a technique used by Genetic Engineering.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Molecular Biology | 5 | 5 | method | The techniques CRISPR-Cas9 and Prime Editing are core molecular biology methods. |
| Neuroscience | 5 | 5 | method | Directly relates to engineering the animal to trigger specific human neurochemical releases. |
| Genetic Engineering | 5 | 4 | outcome | The goal is specifically to modify (engineer) the canine genome. |
| Behavioral Science | 4 | 5 | outcome | The main goal is engineering specific emotional/behavioral responses in humans. |
| Bioethics | 5 | 4 | constraint | The project involves significant germline modification in an animal requiring ethical oversight. |
| Animal Morphology | 4 | 5 | method | Designing the aesthetic qualities (look, feel) of the resulting animal requires morphological design. |
| Veterinary Medicine | 4 | 4 | outcome | The successful creation requires long-term health and development of the canine. |
| Biotechnology Research | 4 | 3 | stakeholder | The project takes place at a well-known biotechnology research institution. |
| Animal Husbandry | 3 | 4 | method | Managing the growth and behavior of the modified canine requires specialized animal care expertise. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is to genetically engineer a canine utilizing advanced techniques (CRISPR-Cas9, Prime Editing) at a specific physical research institution (Sooam Biotech Research Foundation in Seoul, South Korea). This involves extensive laboratory work, handling of physical biological materials, operating complex laboratory equipment, and maintaining the resulting animal specimen. The location is explicitly stated and is essential for the execution of the physical laboratory work. Therefore, the plan is overwhelmingly physical.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Access to cutting-edge CRISPR-Cas9/Prime Editing laboratory facilities
- Expertise in large-scale canine genetic modification and cloning
- Ability to construct secure, specialized animal husbandry units for long-term maintenance (20+ years)
- Proximity to international scientific personnel (for expatriate team collaboration)

## Location 1
South Korea

Seoul

Sooam Biotech Research Foundation

**Rationale**: This is the explicitly designated primary research site. It is recommended due to its established infrastructure, proven expertise in somatic cell nuclear transfer and large-scale canine research, which is critical for leveraging Decision 4 and Decision 15.

## Location 2
USA

Boston/Cambridge, Massachusetts

A specialized, high-security bio-containment lab near major biotechnology hubs

**Rationale**: Suggested as the anticipated location for the 'rapid-response expatriate team' (Decision 4) to co-locate. This area provides necessary Western standards for cross-validation and access to advanced reagent supply chains supporting Prime Editing (Decision 1).

## Location 3
Singapore or Switzerland

Biotech Research Park

Neutral jurisdiction research park with strong IP enforcement

**Rationale**: A secondary, geographically diverse site (as suggested by Decision 15, Strategy 3) for establishing internal IP control over subsequent generations, mitigating geopolitical concentration risk associated with the primary site.

## Location Summary
The primary operational location is confirmed as the Sooam Biotech Research Foundation in Seoul, South Korea, leveraging their genetic expertise. Two additional suggestions focus on establishing operational hubs for the expatriate validation team (Boston/Cambridge) and securing centralized IP ownership outside the primary jurisdiction (Singapore/Switzerland).

# Currency Strategy

This plan involves money.

## Currencies

- **KRW:** Local currency for South Korean operational expenses (salaries, utilities, local procurement).
- **USD:** The project budget is denominated in USD ($100M). This stable international currency should be used for major international contracts, specialized reagent purchases (e.g., Prime Editing kits), and expatriate team contractor payments to hedge against KRW fluctuations.
- **CHF:** Potential currency if the secondary facility is established in Switzerland for IP consolidation.

**Primary currency:** USD

**Currency strategy:** The primary budgeting and reporting currency will be USD, reflecting the stated project capitalization. Local operational costs in Seoul will be managed by converting necessary amounts from USD to KRW. Payments for international scientific personnel and high-value reagents (Prime Editing components) should be invoiced and paid directly in USD to mitigate exposure to local economic volatility and ensure budgetary control over specialized equipment.

# Identify Risks


## Risk 1 - Technical / Gene Editing Modality
Failure of the engineered bacteriophage delivery system (Pioneer Strategy) to successfully co-deliver both CRISPR-Cas9 and Prime Editing components simultaneously to the necessary cell lines with sufficient transduction efficiency across all required loci for multi-trait integration.

**Impact:** If transduction fails or efficiency is below 30% for complex loci, achieving the required aesthetic and functional traits will require repeated, expensive trials. This could lead to a 4-6 month delay per subsequent iteration and a budget overrun of $5M - $15M USD due to specialized reagent consumption.

**Likelihood:** High

**Severity:** High

**Action:** Implement parallel testing immediately: dedicate a smaller budget stream to validating two distinct delivery methods (e.g., lentiviral vectors vs. bacteriophage) for the most complex edits. Develop stringent, real-time tracking metrics for co-delivery success post-transfection to allow early pivot away from the failing phage system.

## Risk 2 - Technical / Neurochemical Fidelity
The three redundant neurochemical edits (Pioneer Strategy) designed to trigger maximal human dopamine/oxytocin release interact unexpectedly (epistasis or synergistic toxicity), resulting in an animal that either exhibits severe unanticipated neurological pathology or fails to reliably elicit the target human emotional response.

**Impact:** Failure to meet the 'maximal release' criterion invalidates the primary business purpose. If pathology occurs, it forces a resource-intensive pivot to life support or remediation (Decision 11), consuming 30% of the buffer budget and delaying functional validation by 9-12 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Prioritize Decision 8 (Target Neurochemical Cascade Specificity) by focusing validation efforts on in-vitro functional assays modeling human receptor response *before* achieving full in-vivo stability. Utilize the sequestered budget buffer (Decision 16) to fund rapid, specialized neuroimaging of test subjects.

## Risk 3 - Financial / Budget Overrun
The high operational complexity dictated by the Pioneer strategy—specifically the reliance on expensive Prime Editing reagents, the need for an expatriate validation team (Decision 4), and extensive genomic validation—depletes the contingency funds (Decision 16) prematurely.

**Impact:** If the budget buffer is exhausted before the first viable prototype is confirmed (estimated 18 months), the project faces immediate suspension or a downgrade in technical scope (e.g., abandoning Prime Editing for Cas9), resulting in a 6-12 month delay while emergency funding ($10M - $20M USD) is secured.

**Likelihood:** High

**Severity:** Medium

**Action:** Strictly monitor Decision 12 (Resource Allocation): Cap Prime Editing reagent expenditure at 60% of the allocated budget until Phase I validation milestones are met. Renegotiate expatriate team contracts for fixed-price deliverables opposed to time-and-materials to control costs.

## Risk 4 - Technical / Longevity & Juvenile State Conflict
The implementation of the Deceleration Switch (Pioneer Strategy) to enforce perpetual juvenility alongside the 20-year lifespan mandate leads to oncological instability or metabolic collapse due to unchecked cellular proliferation or endocrine runaway.

**Impact:** Increased incidence of neoplastic disease or severe metabolic syndrome in initial cohorts. This forces failure of the 20-year mandate and necessitates emergency palliative or remediation efforts, potentially costing $500K USD per affected animal in specialized care, and destroying public confidence.

**Likelihood:** Medium

**Severity:** High

**Action:** Establish mandatory Life-Markers Thresholds (Decision 13): If any cohort animal shows biomarker evidence of uncontrolled cell division (high telomerase activity without corresponding senescence control) before Year 3, immediately pause enhancement edits and dedicate resources to stabilizing the core cancer defense pathways.

## Risk 5 - Regulatory & Permitting / Geopolitical & IP Concentration
Concentrating initial, high-value IP creation at Sooam Biotech (Decision 4 & 15) makes the project highly vulnerable to changes in South Korean bio-regulations or disputes over IP ownership rights, especially since the IP strategy is aggressive (Decision 10).

**Impact:** A regulatory shutdown or an unfavorable IP ruling could halt all primary R&D for 12-24 months, preventing scale-up or forcing the relocation of personnel and critical initial data sets ($10M+ in transfer costs).

**Likelihood:** Medium

**Severity:** High

**Action:** Expedite the establishment of the secondary IP holding facility (Location 3, Singapore/Switzerland) and immediately transfer all documentation related to novel vector designs (Decision 1) to Legal counsel in that jurisdiction. The expatriate team (Location 2) must focus 25% of time on establishing secondary protocol viability in a non-KR jurisdiction.

## Risk 6 - Operational / Expatriate Team Integration
Failure of the expatriate validation team (Decision 4) to integrate smoothly with the established Sooam protocols due to cultural differences, language barriers, or inherent conflicts between Western and local validation standards regarding complex genetic assays.

**Impact:** Protocol invalidation, data ambiguity, and significant friction slowing down the initial validation phase by 2-3 months. This results in inefficient use of the expatriate team's high salary overhead, potentially wasting $1.5M - $2M USD in coordination costs.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mandate a 4-week, highly structured initial 'Protocol Harmonization Workshop' managed by a dedicated, bilingual project manager reporting directly to the PI. Establish clear, technology-agnostic, documented SOPs (Standard Operating Procedures) signed off by both Sooam leads and the expatriate team prior to embryo work.

## Risk 7 - Supply Chain
Difficulty securing a consistent, high-quality, and timely supply of specialized reagents for Prime Editing protocols, which are known to have limited commercial volume as of 2026.

**Impact:** Project stagnation if supply chain disruption occurs. A shortage could lead to a 6-week delay while sourcing alternative vendors or awaiting synthesis, costing $500,000 in idle lab time and contractor overhead.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Immediately dual-source all critical Prime Editing enzymes and specialized guide molecule scaffolds from at least two distinct, globally recognized biotech suppliers (not just the manufacturer). Negotiate 12-month supply agreements with hard limits on lead time for specialized components.

## Risk 8 - Social / Ethical Backlash & Public Perception
Public or activist backlash against the ambitious, non-therapeutic enhancement goals (aesthetic modification, extreme longevity, psychoactive trigger) resulting in negative media coverage or governmental intervention targeting the project's business structure.

**Impact:** If perception is negative, commercialization may be blocked, immediately collapsing the business case. Even if legal, negative PR can deter initial high-end customers, reducing projected Year 1 revenue by 40% ($X million, based on market size unknown).

**Likelihood:** High

**Severity:** High

**Action:** Execute Decision 6 (Ethical Strategy) proactively: Dedicate $2M to a specialized communications team focused on framing the work as 'advanced veterinary science' aimed at maximizing companion animal quality of life, heavily emphasizing the stabilization of foundational canine health metrics before showcasing aesthetics/neurochemistry.

## Risk 9 - Technical / Morphological Fidelity (Feel)
Inability to reliably engineer the specified 'Chinchilla feel,' which relies on subtle, polygenic modulation of dermal peptides (Decision 9, Strategy 1), as the underlying genetics are poorly characterized in canines.

**Impact:** If the feel cannot be achieved, a key differentiator for market penetration is lost, potentially reducing the perceived value of the resulting animal by 20%-30% compared to the expectation set by the bizarre goal.

**Likelihood:** High

**Severity:** Low

**Action:** If after 9 months of focused peptide pathway editing, correlation between genetic change and tactile analysis fails to exceed 60% fidelity, pivot Strategy 9 from deep editing to transient epigenetic modulation for surface traits only, thus saving genomic bandwidth for longevity/neurochemistry.

## Risk summary
The project faces **Extremely High Risk**, driven primarily by the technical ambition dictated by the 'Pioneer' strategic path. The top three critical risks are: 1) **Technical Failure of Phage Delivery System (High Likelihood/High Severity)**, which stops the foundational editing process; 2) **Neurochemical Interaction Toxicity (Medium Likelihood/High Severity)**, which invalidates the core business objective; and 3) **Geopolitical/IP Concentration Risk (Medium Likelihood/High Severity)**, which jeopardizes asset control and continuity due to reliance on a single foreign location for primary R&D. Mitigation efforts must heavily prioritize parallel experimentation for the delivery system and establishing robust external legal/data pathways immediately to counteract the geographical concentration risk inherent in using Sooam Biotech.

# Make Assumptions


## Question 1 - Given the $100M USD budget and high complexity (Prime Editing usage), what specific breakdown of capital allocation is assumed between initial infrastructure setup/reagents (Decision 12), personnel/expatriate team overhead (Decision 4), and the long-term Life-Markers validation for longevity (Decision 13)?

**Assumptions:** Assumption: The budget allocation will follow a 30% Infrastructure/Reagents, 40% Personnel/Operations (including expatriate team for 1.5 years), and 30% Iterative Validation/Longevity Testing split, designed to provide adequate buffer (Decision 16) adherence while supporting the labor-intensive Pioneer strategy.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluation of budget allocation resilience against specialized costs.
Details: The assumed 30% in Infrastructure/Reagents is conservative given the heavy reliance on expensive Prime Editing components and specialized delivery vectors (Risk 3). If Reagent consumption exceeds 70% of this 30% allocation during Phase I, the project buffer will deplete 3 months faster than forecast, requiring immediate cost control actions on the expatriate team overhead (40% allocation).

## Question 2 - Considering the mandate to stabilize behavior at a 4-month-old level for 20 years (Decision 5), what is the assumed timeline for achieving successful endocrine stabilization and implementing the 'deceleration switch' relative to the start date of May 2, 2026?

**Assumptions:** Assumption: Successful implementation and validation of the endocrine deceleration switch will require a minimum of 3 years (until mid-2029) post-initial germline editing, assuming the first viable embryo implantation occurs 10 months post-start due to development/validation cycles.

**Assessments:** Title: Timeline and Milestone Convergence Assessment
Description: Analyzing milestone feasibility based on technical complexity.
Details: A 3-year timeline for stabilizing the juvenile endocrine state (Decision 5) is aggressive. If complex neurochemical edits (Decision 2) delay implantation by more than 6 months, the 20-year functional lifespan target will be compromised relative to the business case timeline. Milestone tracking must center on the cellular senescence biomarkers by the end of Year 2, rather than animal readiness.

## Question 3 - Given the use of an expatriate validation team (Decision 4) co-locating in Boston/Cambridge (Location 2), what specific internal personnel cap (in FTEs) is planned for this external team, and how will their activities be integrated with the primary R&D team at Sooam?

**Assumptions:** Assumption: The expatriate team will consist of 4 highly specialized FTEs (2 Genomic Validation, 1 Regulatory Liaison, 1 Operations Coordinator), integrated via a 'shadow protocol validation' mandate running parallel to Sooam's primary execution, focusing 25% of effort on secondary jurisdiction resilience (Risk 5).

**Assessments:** Title: Resources and Personnel Integration Assessment
Description: Evaluation of co-location efficiency and functional overlaps.
Details: A 4-FTE team structure is reasonable for specialized validation but risks communication overhead (Risk 6). Success hinges on the Regulatory Liaison (1 FTE) proactively addressing IP transfer documentation for Location 3, ensuring seamless data integration rather than process duplication. If the coordination overhead exceeds 20% of the team's time, immediate investment in shared simulation environments is required.

## Question 4 - To address the high regulatory risk associated with non-therapeutic germline modification (Decision 6), what specific regulatory milestones are prioritized for achievement or disclosure by the end of 2027, and which specific South Korean guidelines govern the initial animal handling?

**Assumptions:** Assumption: The primary regulatory milestone targeted before end-2027 is securing confidential bioethics 'pre-approval' (Decision 6, Strategy 3) from a non-governmental consortium, based on the foundational health/longevity data, while adhering strictly to South Korea's existing guidelines for genetically modified animal welfare (assuming current standards as a baseline for handling).

**Assessments:** Title: Governance and Regulations Compliance Assessment
Description: Analyzing proactive regulatory engagement planning against high-risk scope.
Details: Focusing on confidential pre-approval mitigates immediate public scandal (Risk 8) but concentrates regulatory risk on the final public disclosure gateway. The foundational stability must prove effectiveness against the Longevity Threshold (Decision 13) before pre-approval can proceed; failure to stabilize basic vital functions to 15 years by Q4 2027 halts the release of communications strategy funds ($2M).

## Question 5 - In compliance with Risk 4 (Oncological Instability), what quantifiable safety threshold (e.g., maximum allowed telomerase activity deviation or specific oncogene upregulation level) will trigger an immediate halt of the juvenile deceleration editing (Decision 5) to focus solely on Life-Markers stabilization (Decision 13)?

**Assumptions:** Assumption: An immediate halt is triggered if any subject exhibits a telomerase activity increase exceeding 150% of the baseline control group *concurrently* with a failure of the senescence monitoring panel over three consecutive bi-weekly checks, forcing focus onto the 15-year longevity threshold.

**Assessments:** Title: Safety and Risk Management Protocol Assessment
Description: Defining hard technical stops for inherent biological risks.
Details: This threshold provides a measurable trigger for Risk 4 mitigation. If this safety trigger is hit, the immediate resource reallocation must divert 60% of the Iterative Editing Buffer (Decision 16) to deep sequencing required to map the oncogenic pathway, delaying morphological refinement (Decision 9) by an estimated 4 months.

## Question 6 - To mitigate Environmental Impact beyond facility management, what specific bio-containment protocols are mandated by Sooam for the genetically modified waste streams (viral vectors, biological byproducts) resulting from the combined CRISPR/Prime Editing delivery system (Risk 1)?

**Assumptions:** Assumption: All biological waste streams (viral vectors, unused reagents) will undergo mandatory, three-stage thermal inactivation followed by chemical neutralization specific to nucleic acids, in compliance with Sooam's existing high-containment laboratory (BSL-2 equivalent or higher) procedures, ensuring zero environmental release of active genetic material.

**Assessments:** Title: Environmental Impact and Containment Assessment
Description: Ensuring ecological safety given advanced genetic tools.
Details: Given the reliance on bacteriophage delivery (Risk 1), the primary environmental risk shifts from material disposal to the potential accidental release of engineered vectors into the local biosphere. Regular external audits (quarterly) must verify the efficacy of the chemical neutralization phase, as failure here represents a high-severity, low-likelihood ecological contamination event.

## Question 7 - In context of the project's business purpose, what is the planned cadence and format (e.g., private demonstration, scientific publication) for engaging external high-net-worth human stakeholders to confirm the 'maximal dopamine/oxytocin release' target (Decision 2) before scaling production?

**Assumptions:** Assumption: Stakeholder confirmation will occur in two phases: Phase 1 (internal/confidential) after the first viable prototype reaches 6 months of age, using proprietary neuro-feedback validated against a standard against which 'maximal' is defined. Phase 2 involves confidential white-glove demonstrations for potential initial investors 12 months later.

**Assessments:** Title: Stakeholder Involvement and Value Realization Assessment
Description: Measuring progress against the primary subjective success criterion.
Details: The success of Phase 1 hinges entirely on achieving the necessary Target Neurochemical Cascade Specificity (Decision 14) output at that 6-month mark. If the neurochemical signature is only 70% of the target, stakeholder confidence will drop significantly, jeopardizing the $100M follow-on funding necessary for scaling beyond the initial cohort.

## Question 8 - What operational system is mandated to manage the long-term (20-year) longitudinal biometric data streams essential for verifying the Longevity Trait Stabilization Threshold (Decision 13) and the behavioral phenotype, especially considering the decentralized nature of Potential Location 3?

**Assumptions:** Assumption: A centralized, cloud-based, encrypted data platform (leveraging USD budget for secure storage infrastructure) will be established immediately, managed by the expatriate team's Operations Coordinator (Location 2), designed for compliance with future international PII/Biometric data transfer protocols.

**Assessments:** Title: Operational Systems Reliability Assessment
Description: Evaluating the infrastructure required for 20-year longitudinal data integrity.
Details: The 20-year lifespan necessitates enterprise-grade data archiving (a system with projected failure rates below 0.01% over two decades). The security architecture must be validated against US/EU standards (as implied by Location 2) to ensure that data integrity is maintained even if the primary Sooam facility (Location 1) undergoes operational disruption, directly linking operational resilience to Risk 5 mitigation.

# Distill Assumptions

- Budget split: 30% infrastructure, 40% personnel, 30% validation/longevity testing.
- Endocrine stabilization switch requires a minimum of 3 years post-implantation.
- Expatriate team requires 4 specialized FTEs to validate protocols in parallel.
- Regulatory goal: secure confidential non-governmental pre-approval by end-2027.
- Editing halts if telomerase activity exceeds 150% baseline concurrently with senescence failure.
- Waste streams require three-stage thermal/chemical inactivation complying with Sooam BSL-2.
- Stakeholder confirmation occurs in two phases: internal at 6 months, investor demos at 18 months.
- Centralized, encrypted cloud platform manages all 20-year longitudinal biometric data streams.

# Review Assumptions

## Domain of the expert reviewer
Risk Management and Strategic Planning in High-Complexity Biotechnology R&D

## Domain-specific considerations

- Bioethics and Regulatory Compliance for Germline Editing
- Supply Chain Volatility for Specialized Reagents (Prime Editing)
- Longitudinal Data Integrity for 20-Year Asset Lifespan
- Geopolitical Concentration Risk for Core IP and Assets

## Issue 1 - Missing Assumption: Regulatory Approval Timelines and Contingency Funding for Iterative Editing
The plan assumes successful adherence to local KR regulations and targets confidential non-governmental pre-approval by EOY 2027. It lacks an explicit assumption regarding the *timeline* required by official governmental bodies (e.g., S. Korean Veterinary/Bioethics Boards) for *actual operational licensing* necessary for embryo implantation and rearing. The assumed budget split (30% infrastructure/reagents) is highly optimistic for advanced Prime Editing trials, leaving the buffer vulnerable if validation takes longer; Risk 3 highlights this financial strain.

**Recommendation:** Assume a minimum of 9-15 months of administrative delay post-technical validation for final governmental permissions required to start implantation. The budget allocation assumption must be stress-tested: Cap Prime Editing reagent spending at 65% of the allocated 30% until the *government* operational license is secured. If the license is delayed beyond the assumed 15-month window, immediately reallocate 15% of the personnel budget (40% allocation) to extend the expatriate validation team contract for 6 extra months to maintain data integrity, preventing a hard stop.

**Sensitivity:** If governmental licensing introduces an 18-month delay (baseline assumed 9 months total admin time), the project completion date shifts by 9 months. This requires an additional $7.5M - $12.5M USD to sustain contracted personnel/infrastructure past the initial funding horizon, leading to an estimated 8-12% reduction in final projected ROI due to delayed market entry.

## Issue 2 - Missing Assumption: Endocrine Stability Threshold Beyond Juvenile Phenotype
The plan assumes an endocrine deceleration switch can maintain a 4-month-old phenotype for 20 years (Decision 5) based on a Year 2 safety trigger (telomerase/senescence). Critically missing is the assumption about *metabolic load* required to sustain this engineered state. Maintaining perpetual juvenility will place immense, unmodeled stress on major organ systems (cardiovascular, renal) far beyond predictable oncological risks.

**Recommendation:** Introduce a formalized, medium-term operational assumption: Successful maintenance of the juvenile metabolic rate beyond Year 5 is contingent on *zero* required intervention into cardiovascular or renal health pathways. If any renal/cardiac abnormality requiring intervention is detected between Years 3 and 5, immediately deprioritize aggressive aesthetic/neurochemical refinement (Decisions 2 & 9) and allocate 20% of the 30% validation budget toward retrofitting metabolic governance pathways, accepting a compromise on the 'puppy energy' level.

**Sensitivity:** If metabolic failure necessitates retrofitting metabolic governance between Years 3-5, the time required for this secondary complex editing cycle will stall progress on market-facing traits (aesthetics/neurochemistry) by 6-9 months. This directly impacts the perceived novelty and marketing hook, potentially reducing projected Year 2 revenue by 25-35% compared to the target expectation.

## Issue 3 - Under-Explored Assumption: Intellectual Property (IP) Ownership Transfer Mechanism
The IP strategy (Decision 10) is aggressive, aiming for maximal patent granularity, and relies on a secondary, non-primary jurisdiction facility (Location 3). However, there is no explicit assumption or mechanism detailed for *how* the core genetic constructs developed *at* Sooam (using their infra/personnel) are legally and technically transferred to the project owner's control (Location 3) without triggering substantial mandatory profit-sharing or licensing fees dictated by South Korean IP law or Sooam's initial contract terms.

**Recommendation:** Immediately contract specialized international IP law counsel to develop a 'Step-In Acquisition Clause' for the primary contract with Sooam. Assume that achieving 100% IP ownership transfer requires a fixed buy-out fee equivalent to 15% of the projected Year 1 net revenue, or a minimum of $5M USD, whichever is greater. This cost must be pre-allocated within the 30% validation budget or explicitly secured via a financing commitment.

**Sensitivity:** If the transfer requires a negotiated fee exceeding the assumed $5M, the project faces a 5-10% ROI hit immediately post-launch due to early capital outflow. More critically, without a guaranteed clear transfer mechanism, Risk 5 (Geopolitical Risk) materializes into unmitigated legal blockage, rendering the entire R&D investment non-monetizable, resulting in 100% loss of potential profit.

## Review conclusion
The project's technical ambition, driven by the 'Pioneer' strategy, introduces critical planning gaps related to regulatory administration, long-term metabolic viability, and IP commercial control. The greatest threats are not purely scientific feasibility, but the *administrative overhead* and *long-term systemic stability* not explicitly covered by current assumptions. Priority must be given to securing binding, pre-defined timelines and costs for governmental approval, engineering metabolic redundancy beyond oncological risk, and formalizing the IP exit strategy to de-risk the reliance on the single operational hub in Seoul.