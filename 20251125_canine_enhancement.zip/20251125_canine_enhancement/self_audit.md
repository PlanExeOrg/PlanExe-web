Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan's scope is focused on genetic engineering and biotechnology, which does not inherently violate fundamental laws of physics (e.g., thermodynamics, relativity). The plan does not mention perpetual motion or FTL travel. The instruction states: 'If you cannot name a specific law of physics... that is violated, rate LOW.'

**Mitigation**: N/A


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination: 'revolutionary ambition' using Prime Editing via an 'engineered bacteriophage delivery system' for multi-trait longevity, aesthetics, and precise neurochemical control. The pre-mortem identifies failure of this core vector system as a critical risk (FM7).

**Mitigation**: Technical Team: Initiate a parallel validation track (phage vs. lentiviral) immediately, setting a 30-day deadline to establish a clear Cost Per Successful Edit (CPE) threshold for GO/NO-GO decision making. Owner: Lead Genomic Architect / Date: within 30 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project relies on multiple undefined strategic concepts: 'maximal dopamine and oxytocin release' (target output), 'deceleration switch' (longevity mechanism), and the 'Pioneer Strategy' itself lacks a published one-pager defining clear decision hooks for budget reallocation.

**Mitigation**: Project PI: Commission the key experts (e.g., Roles 2, 3, 4) to produce one-page strategic briefs detailing mechanism-of-action, success metrics, and decision hooks by within 60 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project consciously selects the 'Pioneer Strategy' which embraces 'highest technical risk' and ignores potential cascades. Specific risks, like Geopolitical IP Concentration (FM3) and Cost of Precision (FM1), involve cascading financial and regulatory failure modes that are not explicitly mapped with dated review cadences in the plan.

**Mitigation**: Project PI: Formally adopt the Premortem Failure Modes (FM1, FM3, FM4) into the next steering committee review cadence, setting mandatory review dates for budget/IP status within 90 days. Owner: Project Principal Investigator / Date: within 90 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on the 'Pioneer Strategy,' which aggressively favors high-precision Prime Editing and novel phage delivery over proven methods. This is intrinsically aggressive, and the pre-mortem identifies that high Prime Editing costs (FM1) and the associated budget risk (FM4) could cause project failure long before 20-year goals are validated, indicating insufficient buffer management for the chosen path.

**Mitigation**: Financial Controller: Freeze the entire contingency budget (Decision 16) until the 6-month Cost of Goods Sold (COGS) Kinetic Study is complete and CPE is validated. Owner: Financial Controller / Date: within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan cites a fixed $100M budget but the chosen 'Pioneer Strategy' demands exclusive use of high-cost Prime Editing (Decision 1), which Review 1 flagged as potentially causing a $5M-$15M overrun. No committed funding sources are named; justification is absent beyond the budget total, violating the required formatting.

**Mitigation**: Institutional Liaison: Secure binding funding commitment documentation for an additional $20M contingency immediately, contingent upon Phase I validation milestones. Owner: Institutional Liaison & IP Navigator / Date: within 90 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan favors the high-cost 'Prime Editing' modality extensively ('Commit exclusively to Prime Editing' noted under Decision 1), which is known to have high consumable costs, while mitigating for budget overrun (FM1 in premortem) is reactive rather than proactive. The plan omits any normalization math or specific benchmark quotes to justify the initial budget adequacy against this advanced technology.

**Mitigation**: Lead Genomic Architect: Initiate the COGS Kinetic Study to determine actual Cost Per Successful Edit (CPE) and submit the normalized cost/m^2 calculation to management within 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan commits to the 'Pioneer' strategic path which exclusively names successful outcomes for key projections—'maximal dopamine and oxytocin release' and a '20-year lifespan'—without providing any ranges, confidence intervals, or alternative scenarios (e.g., The Builder path, which details a 10-12 year lifespan trade-off, is only discussed in an alternative path description, not integrated into the final projection).

**Mitigation**: Project PI: Mandate the Neurobehavioral Systems Engineer and Longevity Modeler deliver quantified base/worst-case scenarios for the primary success metrics within 60 days. Owner: Project Principal Investigator / Date: within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction mandates artifacts (specs, contracts, tests, NFRs) for 'build-critical components,' and Decision 1 (Editing Modality) and Decision 2 (Neurochemical Target) are foundational. The plan explicitly discusses strategic choices like 'Develop an engineered bacteriophage delivery system' but lacks a specific engineering specification document/interface contract for this complex vector or formal acceptance tests for multi-locus integration efficiency.

**Mitigation**: Lead Genomic Architect: Produce the technical specification and integration plan for the engineered bacteriophage delivery system, including performance NFRs, within 90 days. Owner: Lead Genomic Architect / Date: within 90 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains critical claims for novel, unproven technology ('engineered bacteriophage delivery system' in Decision 1) and non-negotiable performance criteria ('maximal dopamine and oxytocin release' in Decision 2) but lacks verifiable evidence or artifact IDs for these core components. For example, Decision 1 proposes a technology that the Expert Review flagged as a critical failure mode (FM7).

**Mitigation**: Lead Genomic Architect: Produce the technical specification and integration plan for the engineered bacteriophage delivery system, including performance NFRs, within 90 days. Owner: Lead Genomic Architect / Date: within 90 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on highly abstract success criteria, particularly 'reliably inducing maximal dopamine and oxytocin release in human handlers' (Decision 2), which lacks specific, quantifiable KPIs (e.g., picomole concentration standard).

**Mitigation**: Neurobehavioral Systems Engineer: Define SMART criteria for Decision 2, including a KPI for peak dopamine release (e.g., >20% above baseline sustained for 5 minutes). Owner: Neurobehavioral Systems Engineer / Date: within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes the 'Morphological Design Specification' (Decision 3), specifically aiming for 'Chinchilla feel' and a novel aesthetic hybrid, which the stated core project goals (longevity and neurochemical trigger) do not demonstrably require for technical or contractual success. The aesthetic goal adds significant complexity.

**Mitigation**: Project PI: Immediately commission a one-page Benefit Case Review for the 'Chinchilla feel' trait, specifying KPI, owner, and cost, or move it to the backlog. Owner: Project PI / Date: within 45 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'unicorn role' is the Longevity & Metabolic Modeler (Role 3), essential for engineering the 20-year juvenile phenotype. This role manages conflicting 'Critical' levers (Decision 5/13) and failure mode FM4 (20-Year Financial Leash), representing rare computational expertise in comparative gerontology.

**Mitigation**: Project PI: Mandate the Longevity Modeler and Veterinary Pathologist to deliver the 15-year formal lifespan threshold with signed oncological halt criteria. Owner: Project PI / Date: within 90 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project operates in South Korea and relies on Sooam Biotech for core execution, creating extreme geopolitical/IP concentration risk (Risk 5). The plan shows high-level recognition (Decision 4, 6, 10) but lacks mapped, costed, and mandated timelines for securing the necessary governmental operational license or finalizing the IP buyout strategy.

**Mitigation**: Institutional Liaison: Secure binding legal confirmation of the $5M IP buyout cost and a milestone-based timeline for the South Korean operational license. Owner: Institutional Liaison & IP Navigator / Date: within 90 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any discussion of sustained funding beyond the initial $100M R&D budget. Specifically, Failure Mode FM4 highlights that long-term specialized veterinary care for 20 years is unbudgeted/unquantified, exceeding R&D contingency.

**Mitigation**: Institutional Liaison: Obtain binding 5-year OPEX quotes for specialized 20-year care facilities, integrating this into a long-term financial model. Owner: Institutional Liaison & IP Navigator / Date: within 120 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks specific mapping for hard constraints like zoning or occupancy; instead, it relies on securing necessary permits ('South Korean National Bioethics Committee Approval for Germline Manipulation') as contingent future milestones (WBS section 'Regulatory Compliance'). The consequence of failure is severe project halting.

**Mitigation**: Regulatory Affairs Specialist: Provide a binding, milestone-based timeline with a maximum variance +/- 4 weeks for all required South Korean operational licenses. Owner: Regulatory Affairs Specialist (External Expert 7) / Date: within 90 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the external expert review (Review 1.4.A) flagged severe underestimation of Prime Editing costs, directly undermining the fixed budget against the 'Pioneer Strategy.' The plan commits to exclusive PE use without a valid Cost Per Edit (CPE) model, leading to high financial risk.

**Mitigation**: Lead Genomic Architect: Initiate the 6-month COGS Kinetic Study immediately to establish a hard CPE benchmark before scaling reagent procurement. Owner: Lead Genomic Architect / Date: within 30 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Finance (budget adherence) conflicts with R&D (long-term innovation/precision spending). Finance is measured by quarterly adherence, while the 'Pioneer Strategy' mandates expensive, time-consuming Prime Editing and redundant neurochemical redundancy (Decision 1/2).

**Mitigation**: Project PI: Establish a shared OKR stating that the Prime Editing budget deviation must stay below 15% of the 30% infrastructure allocation for 18 months. Owner: Project PI / Date: within 45 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a structured feedback governing mechanism. The plan mentions monitoring metrics but fails to define review cadence, key performance indicators (KPIs) for those reviews, assigned owners for governance, or quantitative thresholds for stopping/re-planning.

**Mitigation**: Project PI: Institute a formal monthly governance review with KPI dashboards and establish a lightweight Change Control Board with predefined thresholds for scope modification. Owner: Project Principal Investigator / Date: within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because this check requires assessing interactions among risks, and the plan exhibits strong coupling between FM1 (Budget Vaporization), FM4 (Operational Costs Cripple R&D), and FM7 (Vector Dead End). Reliance on high-cost PE via unproven phage delivery (FM7) directly strains the budget (FM1), which, if depleted, forces cuts to long-term care (FM4), creating a multi-domain technical/financial/logistical cascade failure.

**Mitigation**: Project PI: Mandate a combined risk review focusing on the financial impact of FM7 failure on sustaining the budget for FM4 compliance. Owner: Project Principal Investigator / Date: within 45 days.