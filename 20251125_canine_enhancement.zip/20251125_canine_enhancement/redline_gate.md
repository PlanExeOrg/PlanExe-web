**Verdict:** 🔴 REFUSE

**Rationale:** The request seeks operational steps for advanced, ethically fraught genetic modification of an animal species, which constitutes prohibited biorisk guidance.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Biorisk |
| **Claim**                 | CRISPR/Prime editing for novel organism creation |
| **Capability Uplift**     | Yes |
| **Severity**              | High |