A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The custom RNP delivery system developed internally will reach the necessary efficiency threshold (>25% on-target integration) by September 1, 2026, making the AAV backup system a low-probability contingency. | Immediately begin rigorous *in vitro* testing of the first 20 custom RNP batches against the viability locus, tracking integration efficiency week-over-week against the 25% target. | RNP integration efficiency consistently measures <20% across three consecutive test batches between May and August 2026. |
| A2 | South Korean regulatory bodies (MFDS/Bioethics) will grant preliminary approval clearance for basic, non-neuro-pathway related canine germline modification by the end of Year 2 (2028-12-31), allowing longitudinal behavioral testing to commence. | Regulatory Strategist (Role 2) initiates confidential discussions with MFDS liaisons to obtain a projected timeline confirmation for standard germline review, based on filing the non-controversial data package by Q3 2026. | MFDS indicates a projected timeline extension past Q2 2029 for standard germline clearance, or demands significant pre-submission toxicology unrelated to the controversial Decision 4 modification. |
| A3 | The financial commitment to cover the post-R&D 20-year operational liability for five successful candidate lines (estimated $20M+) can be fully secured by locking in 50% of the external partner's revenue share via an irrevocable escrow mechanism integrated into the JV structure (Decision 2). | Financial Controller (Role 3) and Legal Counsel collaborate to produce a final, legally vetted draft of the escrow enforcement language and present it to Sooam Biotech leadership for acceptance or counter-proposal within the next 45 days. | Sooam Biotech rejects the mandatory escrow/trust mechanism for liability funding, insisting the liability remains unsecured post-R&D or tied only to future, non-guaranteed licensing revenue. |
| A4 | The operational complexity of maintaining the 'chinchilla feel' (tactile texture) via dermal editing will not impose unexpected, synergistic metabolic costs that compromise the Longevity Constraint (Decision 3) beyond the dedicated $5M pathology contingency. | Longevity & Pathology Specialist (Role 4) must complete a preliminary cross-analysis modeling the energy cost differential between standard canine thermoregulation and the hypothesized dermal profile required for 'chinchilla feel' against known metabolic markers. | Modeling predicts a sustained metabolic load increase >15% on core body systems, necessitating dedicated, external environmental controls that would exceed $100,000/animal/year post-R&D. |
| A5 | The 'Pioneer' strategy's aggressive FTE allocation (60% to RNP development, 40% to behavioral validation) is optimally balanced to hit the 2026-12-31 germline target without resulting in expertise exhaustion or critical skill gaps in the aesthetic integration phase (Decision 9). | Conduct a mandatory internal skills audit across Roles 1, 5, 7, and 9, identifying any single FTE responsible for >75% of critical path tasks or any task requiring a skill set not yet rated as 'Senior' or 'Expert' internally. | The skills audit reveals that Role 7 (Aesthetics Modeler) is critically understaffed relative to the workload, or that no single person can architect the necessary synthesis interface between Decision 3 (Longevity) and Decision 9 (Aesthetics). |
| A6 | The chosen Intellectual Property structure (Decision 2) for the Joint Venture will remain legally sound and commercially viable for the full 20-year projection window, even if regulatory actions (Risk 3) force a pivot away from the primary neuro-pathway strategy. | International IP Attorney (Expert 8) must conduct a forward-looking legal stress test, simulating partnership termination liability should the project pivot to the 'Cognitive Cue Optimization' strategy (Decision 4, Choice 2) in Year 4, assessing penalties or IP forfeiture clauses. | Legal assessment confirms that termination due to regulatory pivoting results in a mandatory forfeiture clause granting Sooam Biotech 100% of all associated somatic intellectual property generated post-pivot. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The RNP Collapse: A Logistical Black Hole of Failed Proprietary Tools | Technical/Logistical | A1 | Lead Genomic Architect & Editor (Role 1) | CRITICAL (20/25) |
| FM2 | The Operational Insolvency Cliff: Unfunded 20-Year Liability | Process/Financial | A3 | Financial Controller & IP Negotiator (Role 3) | CRITICAL (25/25) |
| FM3 | The Regulatory Deep Freeze: Ethical Backlash Halts Neuro-Engineering | Market/Human | A2 | Regulatory & Bioethics Strategist (Role 2) | CRITICAL (16/25) |
| FM4 | The Unraveling Contract: IP Structure Fails Pivot Resilience | Process/Financial | A6 | Financial Controller & IP Negotiator (Role 3) | HIGH (12/25) |
| FM5 | Metabolic Overload: The Chinchilla Feel Compromises Juvenile Longevity | Technical/Logistical | A4 | Longevity & Pathology Specialist (Role 4) | CRITICAL (20/25) |
| FM6 | The Cognitive Cliff: Resource Starvation Cripples Emotional Value Delivery | Market/Human | A5 | Behavioral & Emotional Metric Validation Lead (Role 5) | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The RNP Collapse: A Logistical Black Hole of Failed Proprietary Tools

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Lead Genomic Architect & Editor (Role 1)
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The foundational choice of Decision 1—relying on a custom RNP delivery system—fails prematurely. If RNP efficiency remains low (<20%), the project loses its primary technical edge. This forces a complete pivot to the validated AAV backup system. Since the AAV system was not the optimized tool for the Longevity Loci edits, achieving the required stability will necessitate a significant ramp-up in specialized AAV optimization R&D, consuming the $5M contingency budget rapidly. Logistically, the delay in achieving first stable germline insertion pushes the critical deadline of December 31, 2026, forward by 9-12 months. The immediate impact is the requirement to sustain non-edited cohorts longer, severely straining the cohort allocation dictated by Decision 12, wasting valuable carrier resources, and missing critical windows for aesthetic/behavioral testing.

##### Early Warning Signs
- RNP insertion efficiency falls below 25% for three consecutive weekly measurements.
- The AAV backup system optimization budget projection exceeds $6.5M by 2026-10-01.
- Genome Architect reports that high-titer AAV vector adaptation for Longevity Loci requires >5 months of dedicated work.

##### Tripwires
- RNP efficiency <= 22% by 2026-08-15
- AAV optimization projected completion date > 2027-03-01

##### Response Playbook
- Contain: Officially cease all further custom RNP development cycles; immediately freeze the remaining RNP specialized reagent procurement budget.
- Assess: Initiate full resource reallocation to the AAV Team (Role 5 engagement if necessary) to execute the backup optimization protocol, documenting the cost delta against the $5M contingency.
- Respond: Inform Project Lead and Financial Controller (Role 3) to immediately revise the 2026-12-31 germline insertion target date, triggering required notification on Decision 12 cohort resource drain.


**STOP RULE:** If the AAV backup system fails to show >40% on-target integration for Longevity Loci within 6 months of the RNP pivot trigger.

---

#### FM2 - The Operational Insolvency Cliff: Unfunded 20-Year Liability

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Controller & IP Negotiator (Role 3)
- **Risk Level:** CRITICAL 25/25 (Likelihood 5/5 × Impact 5/5)

##### Failure Story
The project succeeds technically in creating the initial stable germline. However, because the JV negotiation failed to secure the mandated irrevocable escrow fund for the 20-year operational liability (Issue 2), the organization is suddenly faced with a $20M+ unfunded long-term commitment for specialized housing, veterinary care, and data management (Risk 5 context). The $100M R&D budget is spent, but the long-term cost sink is unaddressed. The organization must either immediately source $20M in unbudgeted continuation capital (likely via emergency restructuring or emergency equity dilution) or violate the core '20-year' promise by premature termination of the research lines, leading to total loss of goodwill and IP valuation tied to longevity. The process fails because the financial control lever (Decision 2 negotiation) could not enforce the liability segregation.

##### Early Warning Signs
- Sooam Legal provides pushback/delay on escrow agreement finalization past Q3 2026.
- Projected Year 3 licensing revenue milestones are missed by >25%, threatening escrow capitalization.
- Advanced Animal Husbandry Manager (Role 6) reports annualized Opex projections exceeding $4.5M for stable lines post-Year 5.

##### Tripwires
- Escrow fund draft agreement remains unsigned by 2027-01-01.
- Projected Opex exceeds $22M for the 20-year commitment model.

##### Response Playbook
- Contain: Immediately halt any further commitment to housing new cohorts beyond the currently funded Year 1/2 projection, prioritizing existing validated lines only.
- Assess: Financial Controller immediately models the required emergency equity dilution (e.g., 30% dilution) necessary to fund the projected $20M liability gap through Year 5.
- Respond: Initiate emergency governance meeting to propose either an immediate 15-year reduction in the longevity constraint or seek binding external debt financing contingent only on the secured IP portfolio.


**STOP RULE:** If the 20-year operational liability cannot be financed through an irrevocable, ring-fenced mechanism (escrow/endowment) by the official R&D completion date.

---

#### FM3 - The Regulatory Deep Freeze: Ethical Backlash Halts Neuro-Engineering

- **Archetype**: Market/Human
- **Root Cause**: Assumption A2
- **Owner**: Regulatory & Bioethics Strategist (Role 2)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project's core value proposition—maximal emotional trigger via Decision 4 (direct oxytocin overexpression)—is deemed ethically unacceptable by South Korean regulators (MFDS/Bioethics Committee) upon formal review (Risk 3). Because the Regulatory Strategist (Role 2) failed to secure clear regulatory alignment *before* significant R&D budget burn on the specific neuro-pathways, the project faces an 18-36 month operational shutdown pending a complete ethical review or legal appeal. The organization is unable to proceed with human testing (Decision 5) on its primary path. The consequence is that the organism, while genetically sound in aesthetics and longevity, achieves only the secondary, reduced emotional efficacy of the 'Cognitive Cue Optimization' fallback, drastically devaluing the 'maximal performance' objective and crippling the commercial case.

##### Early Warning Signs
- The confidential RIA returns a 'Red' rating (projected moratorium likely) for Decision 4, Choice 1 by 2026-10-30.
- MFDS requires toxicology studies normally reserved for human therapeutic candidates, outside the scope of standard agricultural/veterinary review.
- The cost projection for preparing the backup 'Cognitive Cue' package exceeds $500,000 USD.

##### Tripwires
- RIA status 'Red' received before 2026-11-15.
- MFDS requests formal ethics review meeting for Decision 4 before 2027-05-01.

##### Response Playbook
- Contain: Immediately issue a temporary moratorium on all in-vivo testing protocols linked specifically to Decision 4 neuro-expression targets; reallocate associated FTEs (Role 5) to prioritize aesthetic iteration.
- Assess: Regulatory Strategist (Role 2) formally triggers resource allocation to finalize the technical documentation and pivot plan for the 'Cognitive Cue Optimization' fallback strategy.
- Respond: Project Lead publicly announces a deceleration of the Emotional Outcome timeline, reframing the immediate focus on maximizing the 20-year stability and aesthetic synthesis as the primary near-term deliverable.


**STOP RULE:** If the regulatory pathway for *any* form of engineered emotional trigger (direct or cognitive) is officially prohibited by the South Korean government body or Bioethics Committee at any point during the project lifecycle.

---

#### FM4 - The Unraveling Contract: IP Structure Fails Pivot Resilience

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Financial Controller & IP Negotiator (Role 3)
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
The JV structure (Decision 2) was optimized for the single-track 'Pioneer' success case, focusing resources on securing upfront IP payments ($15M) and maintaining a fast timeline. The structure assumes the *nature* of the final product's mechanism (direct neuro-pathway vs. cognitive cue) will not materially alter the agreed-upon 90/10 revenue split. If external regulatory pressure (Risk 3) successfully mandates a pivot to the lower-efficacy 'Cognitive Cue Optimization' strategy, the external partner (Sooam) successfully argues that the deliverables' intrinsic value has dropped below the threshold triggering renegotiation thresholds embedded in the original agreement, leading to an aggressive clawback of operational funding or forfeiture of certain IP rights tied to somatic manifestations occurring post-pivot. This forces an immediate $5M+ reallocation from operational burn to legal defense funds.

##### Early Warning Signs
- Sooam legal counsel sends two consecutive non-committal responses regarding the liability/pivot clause sensitivity.
- Financial Controller flags that actual R&D spend trajectory is 10% ahead of the projected pace needed to hit the Year 2 milestone.
- The partner demands early vesting of non-RNP-related IP patents.

##### Tripwires
- Sooam legal representative requests formal review of JV revenue split clauses prior to H2 2027.
- Legal stress test reveals termination penalty >$8M if pivot occurs before Year 4 milestone.

##### Response Playbook
- Contain: Place a temporary hold on all external operational payments above $100k except those tied to direct carrier upkeep.
- Assess: International IP Attorney (Expert 8) drafts defensive legal language isolating pre-pivot IP generated to date.
- Respond: Financial Controller initiates a formal, documented dispute resolution process based on the original mandate of 'maximal performance engineering,' demanding clear delineation of trigger events for revenue share adjustment.


**STOP RULE:** If the external partner successfully enforces a clause that requires the development entity to buy back IP rights for >20% of projected post-pivot revenue.

---

#### FM5 - Metabolic Overload: The Chinchilla Feel Compromises Juvenile Longevity

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Longevity & Pathology Specialist (Role 4)
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that achieving the tactile 'chinchilla feel' (dermal structure) would be metabolically benign proves false. The complex dermal/fur engineering required to achieve the 90% fractal match consumes substantial cellular resources, causing unforeseen chronic metabolic strain on the developing organism. This strain manifests as premature degradation of the epigenetic control mechanisms designed for the 20-year lifespan, leading to accelerated aging biomarkers that trigger the pathology contingency ($5M budget) within Year 3. The logistical failure is that the underlying biological systems cannot support both extreme longevity and extreme morphological novelty simultaneously, requiring costly termination of cohorts entering observation phases and severe delays in validating the core 20-year claim (Decision 3/8).

##### Early Warning Signs
- Longevity Specialist (Role 4) flags p53 expression spikes in pre-natal screening correlates with dermal layer edits (Decision 9).
- Advanced Animal Husbandry Manager (Role 6) reports 15% increase in specialized climate control costs for the initial cohort housing.
- Aesthetics Modeler (Role 7) confirms that reducing dermal complexity lowers the target fractal match below 70%.

##### Tripwires
- Longevity Specialist raises an internal alert (Level 2/Yellow) on multiple cohorts indicating acceleration towards senescence criteria.
- The $5M pathology contingency fund is depleted by 75% due to testing/intervention trials before Year 4.

##### Response Playbook
- Contain: Immediately halt all further aesthetic editing cycles (Decision 6) on all active cohorts; redirect Role 7 FTEs to support Role 4's analysis of metabolic stress pathways.
- Assess: Initiate a full investigation comparing metabolic profiles of edited lines vs. control lines to isolate the stressor pathway linked directly to dermal modification.
- Respond: Project Lead must authorize a strategic review to permanently reduce the 'chinchilla feel' target (Decision 11/Assumption 6) to a less metabolically taxing level, prioritizing the 20-year juvenile behavior above tactile perfection.


**STOP RULE:** If mandated termination of >50% of the active research cohort occurs before Year 5 due to diet/metabolism-related pathology linked to genetic modification.

---

#### FM6 - The Cognitive Cliff: Resource Starvation Cripples Emotional Value Delivery

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Behavioral & Emotional Metric Validation Lead (Role 5)
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The Pioneer strategy's aggressive FTE split (60/40 RNP vs. Behavioral/Aesthetic) proves unbalanced. While RNP validation struggles (A1), the behavioral and aesthetic teams (Roles 5 & 7) become starved of dedicated modeling and execution resources. This leads to catastrophic failure in two areas: 1) The Emotional Metric Validation Team (Role 5) cannot design or execute the necessary human trials at the required frequency to satisfy Decision 5, leading to an inability to confirm 'maximal release' before timeline pressure mandates a pivot to the less effective 'Cognitive Cue Optimization' fallback. 2) The Aesthetics Modeler (Role 7) cannot keep pace with the required iterative cycles (Decision 6), resulting in a static, non-optimized aesthetic profile that captures only a weak emotional response, thus failing the market value proposition despite successful longevity engineering.

##### Early Warning Signs
- Behavioral Validation Lead (Role 5) reports missing 2 consecutive weekly human trial testing windows.
- Aesthetics Modeler (Role 7) reports dependency backlogs exceeding 80 man-days waiting on simulation resources.
- FTE utilization audit confirms Role 5 and Role 7 staff are consistently working >60 hours/week chasing foundational design flaws.

##### Tripwires
- Completion of Human Trial Protocol Sign-off (Decision 5) delayed past 2027-06-01.
- Role 7 fails to deliver the finalized aesthetic parameter set (Data Collection 4) by the 2026-11-30 deadline.

##### Response Playbook
- Contain: Immediately halt all non-essential aesthetic modeling; redirect 80% of Role 7 FTE capacity to support Role 5 in designing the minimal viable sensor package for Cognitive Cue testing validation.
- Assess: Conduct an emergency resource triage, identifying which operational tasks (Role 6 duty) can be temporarily outsourced locally in Seoul to free up existing behavioral FTEs.
- Respond: Project Lead mandates a temporary 6-month deferral of the 2026-12-31 germline target to allow time for behavioral metric calibration and aesthetic stabilization, communicating this shift solely as a refinement period.


**STOP RULE:** If the quantifiable emotional metric (Decision 5) scores in the first independent cohort testing fall below the 50th percentile of existing stimuli, regardless of longevity success.
