**Purpose:** business

**Purpose Detailed:** Large-scale biological engineering project with significant financial investment, likely intended for research, commercialization, or application within a biotech/research institution aiming for a novel outcome.

**Topic:** Genome modification of a dog for maximal human emotional response