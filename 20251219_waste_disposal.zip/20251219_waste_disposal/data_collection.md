## 1. BSL-3 Waste Chemical Composition and Reactivity Matrix

This data is critical because it scientifically defines the baseline requirement for containment integrity (Decision 13). Without chemical profile, the $1.2M geotechnical validation fund is being misallocated against an undefined hazard profile.

### Data to Collect

- Precise chemical makeup (constituents and percentage concentration)
- Reactivity matrix against standard steel (55-gallon drum) and high-density grout materials
- Infectivity profile and required containment half-life for biological agents
- Corrosivity index toward standard construction materials (concrete, rebar)

### Simulation Steps

- Use CHEMCAD or similar process simulation software (if component data is available) to model chemical compatibility under long-term, low-temperature subterranean burial conditions.
- Develop input parameters for a contaminant transport model (e.g., MODFLOW/MT3DMS) simulating a worst-case breach of the chosen shaft geometry using known hazard scores.

### Expert Validation Steps

- Consult a Chemical Engineer specializing in High-Activity/BSL-3 waste handling (referencing Hanford WTP parallels) to establish the definitive long-term containment standard.
- Consult with the Forensic Document Examiner (Expert Reviewer 1) to ensure chemical data aligns with required sealing specifications before locking in grout procurement.

### Responsible Parties

- Executive Sponsor
- Geotechnical & Containment Specialist
- Financial Structuring & Budget Oversight

### Assumptions

- **High:** Accurate chemical profiles are obtainable for the BSL-3 derived waste.

### SMART Validation Objective

Obtain, review, and approve the BSL-3 Waste Chemical Reactivity Matrix (CRM) defining minimum required containment integrity score (C-Score >= 0.95) within 10 calendar days.

### Notes

- This addresses Recommendation 1.1 from Expert Reviewer 1 and Expert Reviewer 2.
- If CRM data confirms high biological threat, the default choice for Decision 13 MUST become Option 1 (High-Density Grout).


## 2. Geotechnical Suitability of Candidate Nevada Shafts (Location 1)

Selecting the correct shaft is critical (Decision 1). Given the BSL-3 waste, preliminary surveys are insufficient; on-site hydrological and seismic validation is required to prevent long-term liability transfer.

### Data to Collect

- Real-time micro-seismic data (48+ hours) for candidate shaft clusters (post-federal map verification)
- Groundwater flow gradient data from installed monitoring wells (7-day minimum assessment)
- Geophysical contractor assessment of geological layer stability post-micro-seismic survey

### Simulation Steps

- Run the MODFLOW simulation (from Data Collection 1) using real-time groundwater data to model plume migration risk specific to the chosen shaft coordinates.
- Use the collected micro-seismic data as input to update structural failure probability models for the selected site.

### Expert Validation Steps

- Consult the Environmental Liability Modeler (Expert Reviewer 2) to interpret groundwater data and validate that the 7-day monitoring window provides sufficient predictive validity.
- Consult certified Geotechnical Engineers (via the Geotechnical & Containment Specialist) to verify that the chosen sealing mechanism cost aligns with the site's structural needs.

### Responsible Parties

- Geotechnical & Containment Specialist
- Executive Sponsor

### Assumptions

- **High:** The $1.2M geotechnical validation budget is sufficient to cover micro-seismic analysis plus 7 days of environmental monitoring wells.
- **High:** The selected Nevada shaft will be structurally sound enough to justify the lower-cost, higher-risk sealing mechanism if the high-density grout costs exceed projections.

### SMART Validation Objective

Finalize the Nevada Mineshaft Selection (Lever 3098ea75) by confirming its Long-Term Stability Score (LTSS) is above 0.85 based on integrated seismic and hydrological data within D+20 days.

### Notes

- This addresses Assumption Issue 3 and Expert Reviewer 2's concerns about inadequate contingency.


## 3. Transport Chain Security and Redundancy Confirmation

The 'Ghost Run' is deemed a fatal flaw by external experts (Reviewers 1 & 2). Primary reliance must shift immediately to the redundant Option 2, and validation must confirm this path is viable within the timeline.

### Data to Collect

- Completed and signed contracts for Option 2 transport fleet (6 rental vans) and contingency funding release clauses.
- Detailed I-15 corridor route profiles, including known weigh station locations and historical state patrol scheduling data.
- Signed contract and confirmation of immediate funding ($500k) for the Emergency Transport Fallback Team (Off-Ramp Protocol).

### Simulation Steps

- The Logistics Manager must simulate the 6-vehicle staggered run (Decision 2, Option 2) to verify if the 45-day deadline can still be met without needing the 'Ghost Run'.
- The OPSEC Architect must map the spoofing effectiveness (Decision 9, Option 1) against the intended travel times for the 6 non-commercial vehicles.

### Expert Validation Steps

- Consult a Logistics Security Expert (Reviewer 4, if necessary, or internal equivalent) to validate the redundancy provided by the 6-truck staggered run vs. the single-point-of-failure of the 'Ghost Run'.
- The Executive Sponsor must receive formal sign-off from the Finance Manager confirming the $500k release for the immediate activation capability of the fallback transport team.

### Responsible Parties

- Logistics and Transport Chain Manager
- Financial Structuring & Budget Oversight
- Operational Security (OPSEC) Architect

### Assumptions

- **High:** Switching from 'Ghost Run' to Option 2 (6 small vans) is logistically feasible within the 45-day window, even with increased loading/unloading overhead.
- **Medium:** The dedicated $500k provided for the Emergency Transport Fallback Team guarantees immediate, 12-hour readiness activation.

### SMART Validation Objective

Execute the pivot from primary 'Ghost Run' reliance to the 6-vehicle Option 2 redundancy plan, with the fallback team contractor secured and funded, by D+5 days.

### Notes

- This directly implements Recommendation 1.1 (Pivot transport) and 1.4 (Fund Off-Ramp Protocol).


## 4. Human Capital Loyalty Hardening Verification

Insiders are the highest probability failure vector (Risk 6, Review Issue 3). Hardening loyalty via immediate funding of long-term silence payoff is more critical than maximizing initial cash gratification.

### Data to Collect

- Confirmation of $300k reallocation from initial labor cash pool to the post-operation crypto-silence incentive escrow.
- Documentation detailing the specific triggers, vesting schedule, and non-negotiable 90-day silence clauses for the crypto-escrow contract.
- Verification that the Labor & Loyalty Manager has appointed an 'On-Site Execution Lead' for Location 1 emplacement.

### Simulation Steps

- Financial Manager simulates the immediate impact of reducing the initial labor cash payout (from 60% to 45%) on union contracting negotiations to ensure initial participation is not jeopardized.
- Labor Manager simulates a stress scenario where the On-Site Execution Lead enforces the RF blackout against non-compliant union workers.

### Expert Validation Steps

- Consult a Covert Labor Relations Specialist (Reviewer 7) to vet the strength of the revised, larger, delayed crypto-silence incentive against the initial high cash outlay.
- The Executive Sponsor must verify the appointment and awareness of the On-Site Execution Lead.

### Responsible Parties

- Labor & Loyalty Manager
- Financial Structuring & Budget Oversight

### Assumptions

- **Medium:** The reduction in initial cash incentive (from 60% to 45%) will not cause specialized union labor teams to defect during initial contracting.
- **High:** The crypto-silence incentive structure creates sufficient financial deterrence to maintain silence post-operation against interrogation.

### SMART Validation Objective

Secure and fully fund the $750k crypto-silence escrow pool, documented by Finance, by D+15 days, ensuring the Labor Manager confirms the identification of the On-Site Execution Lead by D+10 days.

### Notes

- Addresses Review Issue #2 and Recommendation 1.2/2.2.

## Summary

Immediate focus must shift to mitigating the fundamental technical and logistical risks identified as 'High' sensitivity by expert reviewers. The plan's reliance on the 'Ghost Run' manifest forgery (Risk 1, Reviewer 1/2) poses an unacceptable forensic trace risk, necessitating an immediate pivot to the decentralized, 6-vehicle transport contingency (Data Collection 3). Simultaneously, the absolute scientific parameters of the BSL-3 waste must be defined (Data Collection 1) before any final decision on the long-term shaft sealing mechanism can be made, as containment integrity supersedes all other concerns. Finally, human capital loyalty must be hardened by redirecting funds from upfront labor cash payouts into the long-term silence incentive pool (Data Collection 4) before mobilization.