### 1. Project Start: Confirm availability of $10M capital and finalize the 'Builder's Balance' strategic path.

**Responsible Body/Role:** Project Executive Sponsor (PES)

**Suggested Timeframe:** Project Week 1 (2026-May-28)

**Key Outputs/Deliverables:**

- Confirmation of $10M USD fund readiness.
- Official documentation confirming adoption of 'Builder's Balance' strategy.

**Dependencies:**

- Project Kickoff Approval

### 2. PES designates and tasks an Interim Formation Lead (Project Manager equivalent) to establish committee charters and leadership.

**Responsible Body/Role:** Project Executive Sponsor (PES)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formation Lead designated.
- Initial draft charters distributed to nominated committee leads.

**Dependencies:**

- Step 1: Strategy Confirmation

### 3. Formation Lead drafts: 1. Final Terms of Reference (ToR) for Operational Control Board (OCB). 2. Final ToR for Technical Assurance & Compliance Committee (TACC).

**Responsible Body/Role:** Interim Formation Lead

**Suggested Timeframe:** Project Week 1 - Week 2

**Key Outputs/Deliverables:**

- Draft OCB ToR v0.1
- Draft TACC ToR v0.1
- Initial tactical budget allocation draft (under $500k threshold definitions).

**Dependencies:**

- Step 2: Lead Designated

### 4. PES reviews and finalizes ToRs for OCB and TACC, and formally appoints the designated Chairs for both proposed committees.

**Responsible Body/Role:** Project Executive Sponsor (PES)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Approved OCB ToR & TACC ToR.
- Formal appointment notices sent to Logistics Lead (OCB Chair) and Chief Geotechnical Engineer (TACC Chair).

**Dependencies:**

- Step 3: Draft ToRs Complete
- Decision 3: Budget Allocation Strategy finalized

### 5. Appointed Chairs (OCB & TACC) compile and submit final lists of nominated functional members per the defined governance structure.

**Responsible Body/Role:** OCB Chair & TACC Chair

**Suggested Timeframe:** Project Week 2 - Week 3

**Key Outputs/Deliverables:**

- Finalized OCB member roster.
- Finalized TACC member roster.
- Nomination confirmation for External Fiduciary (PEIF).

**Dependencies:**

- Step 4: Chairs Appointed

### 6. PES formally constitutes the OCB and TACC by approving the full membership lists, thereby establishing them as operational bodies.

**Responsible Body/Role:** Project Executive Sponsor (PES)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Formal OCB establishment confirmation.
- Formal TACC establishment confirmation.
- PES formally assigns roles (Chair/Members/Advisors).

**Dependencies:**

- Step 5: Member Lists Submitted

### 7. OCB holds its initial kick-off meeting, focusing on finalizing tactical budget controls ($500k threshold) and setting protocols for asset acquisition (Decision 8).

**Responsible Body/Role:** Operational Control Board (OCB)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- OCB Meeting Minutes #1.
- Established operational weekly spend plan.
- Initial directive issued to Procurement Manager to begin transport asset sourcing.

**Dependencies:**

- Step 6: OCB Established

### 8. TACC holds its initial kick-off meeting, prioritizing external engagement for geotechnical specialists and setting acceptance criteria for forged documentation (Issue 1 Review).

**Responsible Body/Role:** Technical Assurance & Compliance Committee (TACC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- TACC Meeting Minutes #1.
- Geotechnical Specialist Engagement Contract (Draft).
- Acceptance criteria document for Ghost Run manifest quality.

**Dependencies:**

- Step 6: TACC Established

### 9. PES finalizes the structure and documentation for the Project Executive & Isolation Firewall (PEIF), confirming the Independent Fiduciary role.

**Responsible Body/Role:** Project Executive Sponsor (PES)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- PEIF Charter finalized.
- Independent Fiduciary secured/contracted.
- Finalized high-threshold disbursement protocols (>$500k).

**Dependencies:**

- Step 4: Chairs Appointed (for independence review)

### 10. OCB finalizes the 'Ghost Run' contract with the licensed hauler (incorporating Decision 2 requirements) and secures the initial transport asset lease/purchase.

**Responsible Body/Role:** Operational Control Board (OCB)

**Suggested Timeframe:** Project Week 4 - Week 5

**Key Outputs/Deliverables:**

- Signed Ghost Run Contract.
- Initial transport assets secured or leased (Decision 8 alignment).

**Dependencies:**

- Step 7: OCB Initial Meeting Complete
- Decision 2: Logistical Chain Selected

### 11. TACC finalizes criteria and requirements for site prep, specifically dictating the required parameters for seismic monitoring and sealing materials based on geotechnical risk prioritization (Decision 13).

**Responsible Body/Role:** Technical Assurance & Compliance Committee (TACC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Finalized Shaft Sealing Specification (Grout/Debris mix type determined).
- RF Silence Enforcement SOP (5km radius).
- Geotechnical testing plan for Location 1 approved.

**Dependencies:**

- Step 8: TACC Initial Meeting Complete
- Decision 1: NV Mineshaft Selection Finalized

### 12. OCB initiates mass contracting/cash disbursement protocols for specialized union labor teams, ensuring compartmentalization as per Decision 4.

**Responsible Body/Role:** Labor Contracts Manager (under OCB)

**Suggested Timeframe:** Project Week 5 - Week 6

**Key Outputs/Deliverables:**

- Confirmation of three non-contiguous labor pools sourced.
- Initial cash disbursements released to secure immediate commitment.
- Protocol for analog burner phones distribution established.

**Dependencies:**

- Step 9: Ghost Run Contract Finalized
- Decision 4: Team Assembly Strategy Selected

### 13. PEIF authorizes the budget draw for the required security hardening (forgery acquisition and $500k silence incentive fund setup).

**Responsible Body/Role:** Project Executive & Isolation Firewall (PEIF)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Authorization for forgery engagement.
- Crypto wallets established/seeded for silence contingency ($500k allocation).

**Dependencies:**

- Step 12: TACC Finalizes Forgery Criteria
- Review Conclusion: Issue 1 & 2 Addressed

### 14. OCB coordinates the first physical movement: Transport Assets move from staging (Location 2) to final staging prior to state line crossing.

**Responsible Body/Role:** Operational Control Board (OCB)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Manifests loaded onto transport assets.
- Deployment readiness sign-off from Head of Field Security Operations.

**Dependencies:**

- Step 10: TACC Technical Prep Finalized
- Step 11: Labor Secured

### 15. TACC verifies all field teams are adhering to Control over Information Leakage Vector Security (analog communication) and prepares the command center for RF silence enforcement.

**Responsible Body/Role:** Technical Assurance & Compliance Committee (TACC)

**Suggested Timeframe:** Project Week 7 (Coinciding with Transport Readiness)

**Key Outputs/Deliverables:**

- Final communications compliance audit passed.
- RF monitoring equipment deployed at Location 1 perimeter.

**Dependencies:**

- Step 11: TACC Finalizes Forgery Criteria
- Decision 5: Communication Security Selected (Burner phones)

### 16. Kinetic Phase Commencement: OCB authorizes the start of the interstate 'Ghost Run' transport across Location 3.

**Responsible Body/Role:** Operational Control Board (OCB)

**Suggested Timeframe:** Project Week 8 (Start of 45-day window)

**Key Outputs/Deliverables:**

- Confirmation of State Line Crossing (Initial Status Report).
- Daily kinetic status reports filed to PEIF.

**Dependencies:**

- Step 13: Transport Assets Mobilized
- Step 14: Full OPSEC Readiness Confirmed

### 17. Upon arrival at Location 1 (Nevada Mine Site), TACC oversees micro-seismic monitoring and confirmation of site stability prior to unloading.

**Responsible Body/Role:** TACC (Chief Geotechnical Engineer)

**Suggested Timeframe:** 48 hours following arrival (Within Project Week 8)

**Key Outputs/Deliverables:**

- Final Geotechnical Site Stability Sign-Off.
- Confirmation to OCB to proceed with unloading.

**Dependencies:**

- Step 15: Kinetic Phase Commenced
- Review Conclusion: Geological Validation Stipulation Met

### 18. OCB directs On-Site Prep team to begin waste unloading and emplacement sequence according to Decision 13 sealing specifications.

**Responsible Body/Role:** Operational Control Board (OCB)

**Suggested Timeframe:** Immediately following TACC sign-off

**Key Outputs/Deliverables:**

- Waste transfer completed.
- Energy Sourcing (Decision 6) generators/batteries operational.

**Dependencies:**

- Step 16: Site Stability Confirmed

### 19. TACC directs final shaft sealing procedures. OCB enforces full RF Blackout (5km zone) for the 24-hour duration of sealing.

**Responsible Body/Role:** TACC & OCB (Joint Execution)

**Suggested Timeframe:** Following Emplacement (Within 45-day window)

**Key Outputs/Deliverables:**

- Shaft Seal Complete Confirmation.
- RF Blackout End Confirmation.

**Dependencies:**

- Step 17: Waste Unloaded

### 20. OCB directs field security to execute the 48-hour asset destruction SOP for all transport vehicles and disposable equipment.

**Responsible Body/Role:** Procurement & Asset Manager (under OCB)

**Suggested Timeframe:** Within 48 hours post-sealing

**Key Outputs/Deliverables:**

- Transport Asset Destruction Certificates (via shredding vendor).
- Final operational spend report submitted to PEIF.

**Dependencies:**

- Step 18: Final Seal Complete

### 21. PEIF convenes to receive the 'All Clear' signal from OCB and TACC, authorizing release of the *first tranche* of the $500k silence incentive pool to core personnel.

**Responsible Body/Role:** Project Executive & Isolation Firewall (PEIF)

**Suggested Timeframe:** Upon completion of Step 19

**Key Outputs/Deliverables:**

- Project Completion Milestone documented.
- Initial crypto transfer initiation authorized.

**Dependencies:**

- Step 19: Asset Destruction Complete