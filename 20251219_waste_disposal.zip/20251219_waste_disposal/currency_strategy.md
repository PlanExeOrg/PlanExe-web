This plan involves money.

## Currencies

- **USD:** The project budget is explicitly set in US Dollars ($10 million), and operations are confined entirely within the United States (California and Nevada).

**Primary currency:** USD

**Currency strategy:** The budget is fixed in USD, and all planned expenditures (labor, logistics, asset acquisition) are domestic. Therefore, no foreign exchange risk is present, and USD will be used for all budgeting, contracting, and operational payments.