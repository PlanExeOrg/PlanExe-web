**Purpose:** business

**Purpose Detailed:** Large-scale, potentially criminal project involving the disposal of a significant volume of hazardous industrial waste, aimed at cost management and secrecy, which fits the criteria of a large-scale project potentially involving illegal commercial or infrastructural activities.

**Topic:** Disposal of hazardous chemical/biological waste via illegal dumping