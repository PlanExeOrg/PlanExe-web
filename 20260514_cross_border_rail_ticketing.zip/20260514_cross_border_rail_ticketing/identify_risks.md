
## Risk 1 - Regulatory & Permitting
Political resistance or insufficient legal enforcement posture from one or more key national rail operators or member states, leading to non-compliance with binding data exposure or ticketing standards by the mandate deadlines.

**Impact:** If a state or major operator (e.g., SNCF or DB) drags their feet, it invalidates the 'continuity-of-journey' principle for large segments of the network, potentially leading to a delay of 6–12 months for full functionality on key routes and jeopardizing the 40% through-ticket target.

**Likelihood:** Medium

**Severity:** High

**Action:** Maintain a strong Enforcement Posture (Decision 12) by leveraging the EU Agency for Railways to conduct mandatory, pre-launch technical audits. Ensure the linkage between adherence to standards and access to the shared clearing/settlement mechanism is legally unambiguous.

## Risk 2 - Technical
Integration challenges leading to an unstable OSDM-compatible shared real-time data layer, specifically regarding data quality, latency, or semantic mismatches between operator inventory systems, despite provisional binding standards being established early.

**Impact:** If data is unreliable, distributors cannot sell accurate through-tickets, leading to high rates of failed bookings, customer complaints (target requires halving complaints), and erosion of passenger trust. This could cause a 2–3 month delay in commercial rollout on the initial four corridors until data quality improves.

**Likelihood:** High

**Severity:** High

**Action:** Aggressively apply early incentives (Decision 6) for high data uptime compliance on core routes. Utilize the Public Reference Distributor (Decision 11) as a specialized real-time validation sandbox to aggressively stress-test cross-carrier data transmission before mandatory exposure.

## Risk 3 - Financial
Under-capitalization or insufficient liquidity within the inter-carrier clearing and settlement mechanism due to the chosen transactional fee model (The Builder scenario), resulting in settlement delays or disputes between carriers.

**Impact:** Settlement failures undermine the single-payment settlement requirement. This could stall carrier participation or force the EU public budget to cover short-term float gaps, estimated at an extra €50–€200 million in working capital support beyond the initial coordination budget.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Closely monitor the balance of the rolling reserve fund (Decision 5). If transaction volume velocity lags or reserve balances drop below a pre-defined safety buffer (e.g., 20% of expected peak daily settlement volume), trigger a swift request for targeted, temporary capitalization from the public budget or mandate higher initial bank guarantees.

## Risk 4 - Supply Chain / Integration
National operators focusing their limited IT resources predominantly on achieving the mandatory API deadline (30 months) at the expense of harmonizing complex post-sale or ancillary services, specifically accessibility reservations or bicycle rules.

**Impact:** While basic ticketing might launch, failure to integrate accessibility (Decision 9) or reduction cards (Decision 8) causes the key success metric (improving on-board experience) to fail, leading to regulatory non-compliance on equity grounds and limiting overall modal shift gain by 10–15%.

**Likelihood:** High

**Severity:** Medium

**Action:** Use the phased standardization approach (Decision 4) to allocate mandatory conformance testing milestones for accessibility data (Decision 9) immediately following the provisional binding standards being set (6 months), ensuring these complex elements are developed in parallel, not sequentially, with core ticketing APIs.

## Risk 5 - Operational/Governance
Overly complex or slow governance structure for amending OSDM standards post-launch leads to an inability to rapidly address unforeseen technical bugs or incorporate necessary refinements needed after initial corridor launches.

**Impact:** Necessary security patches or minor functional improvements could take 6–9 months to pass the dual-approval threshold, leading to prolonged operational vulnerabilities or customer frustration in the early phases (e.g., buggy refund processing).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Ensure the initial mandate for the Governance Structure (Decision 10) gives the technical steering committee (or equivalent body) expedited authority to issue 'clarification notices' to the Public Reference Distributor for immediate implementation, pending formal ratification later.

## Risk 6 - Social / Stakeholder Management
National operators resist the defined liability framework (Decision 3), finding the tiered model too punitive, leading to internal lobbying efforts that attempt to water down the Passenger Rights Backstop, undermining consumer trust.

**Impact:** If the backstop is weakened (e.g., liability is pushed back onto the distributor or passenger), the promise of 'continuity-of-journey rights' fails, directly threatening the goal of reducing consumer complaints and achieving the 40% adoption target.

**Likelihood:** Medium

**Severity:** High

**Action:** Frame the tiered liability model (Decision 3) not as a penalty, but as a necessary risk pooling mechanism supported by the data transparency achieved through the shared API layer. Provide clear, early actuarial modeling showing how the pooled risk is lower than unmanaged individual carrier risk.

## Risk 7 - Market / Competition
Distributors fail to rapidly adopt the new system, preferring established legacy methods or focusing on national markets, potentially failing to meet the 5-year goal of 40% single through-tickets sold.

**Impact:** If adoption is slow, the economic justification for the €1.5B public investment diminishes. If only 20% adoption is reached, the operational success metric is missed, and the program is deemed a failure.

**Likelihood:** Medium

**Severity:** High

**Action:** Aggressively implement Decision 2 (Capped Royalty Structure). Ensure commercial terms are fair enough to encourage integration while allowing distributors to build viable business models, thus maximizing their incentive to push cross-border sales.

## Risk 8 - Environmental/Scope Creep
Overly ambitious integration of non-core transport modes (buses, ferries) too early in the five-year plan, diverting resources from stabilizing the core rail ticketing framework.

**Impact:** Delay in achieving corridor through-ticketing, pushing the core objective back by 9–12 months due to engineering complexity spillover. This would directly conflict with the 'realistic scenario' constraint.

**Likelihood:** Low

**Severity:** Medium

**Action:** Adhere strictly to Decision 7: De-scope non-core integrations from the Phase 1 mandate (first 60 months). Focus capacity building exclusively on rail-to-rail OSDM compliance in the initial phase.

## Risk summary
The project faces high inherent risks due to its regulatory mandate, complex multi-stakeholder setup (20+ carriers), and critical dependency on novel IT standardization (OSDM APIs). Given the chosen 'Pragmatic Harmonization' scenario, the primary existential threats are **Stakeholder Non-Compliance (Regulatory Risk)** and **Shared Data Layer Instability (Technical Risk)**. Political resistance from national operators could derail the entire project if enforcement posture is perceived as weak, while unreliable real-time data renders the core ticketing functionality unusable regardless of governance. The chosen mitigation strategies rely heavily on leveraging tight deadlines, phased implementation (Decision 4), and financial incentives linked to data quality (Decision 6) to ensure that behavioral change precedes technical perfection. Crucially, the trade-off made by selecting the Builder scenario—accepting tiered liability over centralized risk absorption—amplifies the need for robust technical validation to minimize failures that lead to liability disputes.