### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Essential for strategic oversight, high-level decision-making (especially concerning financial thresholds and regulatory alignment), and resolving major risks, ensuring the project remains aligned with the EU Regulation mandate. Its existence clearly separates strategic control from day-to-day execution.

**Responsibilities:**

- Approve annual program strategy, budget allocations deviating more than 10% from the baseline plan, and major scope changes.
- Receive and approve reports on strategic risk status (especially regulatory compliance and enforcement posture).
- Formally sanction operator inclusion/exclusion from the clearing/settlement mechanism.
- Resolve formal disputes escalated from the Operational Management Group regarding policy interpretation or inter-carrier commercial terms.

**Initial Setup Actions:**

- Finalize and approve the Terms of Reference (ToR), defining explicit strategic decision thresholds.
- Appoint the Executive Sponsor (Chair) and establish the conflict resolution mechanism.
- Review and formally approve the initial Capitalization Plan for the Clearing Mechanism.

**Membership:**

- High-level representatives from DG MOVE (Chair)
- Director of the EU Agency for Railways
- Chief Legal Officer (Project Sponsor)
- Designated representative from National Regulators' Forum (Non-voting)
- Chair of the Technical Advisory Group (Invited)

**Decision Rights:** Decisions with financial impact exceeding €5 million, significant changes to the binding timeline (Decision 4), or approval of operator exclusionary actions (Decision 12). Sets the maximum liability cap for the Passenger Rights Backstop (Decision 1).

**Decision Mechanism:** Weighted Majority Vote. DG MOVE representative holds the deciding vote in case of a tie, mandated by the regulatory underpinning. Conflicts between DG MOVE and Member State representatives escalate immediately to the relevant EU Director-General.

**Meeting Cadence:** Quarterly, or on urgent call for critical milestone approvals (e.g., standards ratification milestones).

**Typical Agenda Items:**

- Review of 5-Year Target Progress (40% Through-Ticket Metric).
- Strategic Risk Review (Focus on Regulatory Compliance/Enforcement Viability).
- Approval of major releases/conformance testing outcomes.
- Review of projected utilization vs. clearing mechanism float stability (Risk 3).

**Escalation Path:** Unresolved issues or disputes that cannot reconcile within the PSC due to stakeholder impasse are escalated directly to the relevant DG MOVE Director-General for executive political resolution.
### 2. Operational Management Group (OMG)

**Rationale for Inclusion:** This body is required to manage the day-to-day execution, compliance monitoring, dependency tracking, and resource allocation necessary to deliver the technical integration and operational benchmarks (T+5 latency, 30-month API deadline). It ensures coherence between the standards body and the testing coordination.

**Responsibilities:**

- Manage the 35 dedicated FTEs, coordinating the standards and testing streams.
- Monitor and report on operator performance against API exposure deadlines (Decision 12) and latency benchmarks (T+5).
- Oversee the validation roadmap for the Public Reference Distributor (Decision 11).
- Manage weekly budget burn rate for operational expenditure.
- Coordinate capacity building grant distribution reviews with the relevant technical/auditing bodies.

**Initial Setup Actions:**

- Establish the centralized reporting dashboard linking technical milestones to the timeline (Decision 4/14).
- Finalize the Statement of Work (SOW) for the external auditing firm managing royalty verification (Assumption Q3).
- Develop and distribute weekly progress templates to all primary technical stakeholders (SNCF, DB, etc.).

**Membership:**

- Project Director/Program Manager (Chair)
- Head of Technical Integration (Responsible for OSDM/API)
- Head of Financial Operations (Clearing/Settlement oversight)
- Compliance & Audit Lead
- Stakeholder Relations Manager

**Decision Rights:** Decisions concerning resource shifts within the approved operational budget (<€500k); resolution of day-to-day technical blockers below the threshold requiring PSC intervention; managing the queue for conformance testing slots.

**Decision Mechanism:** Consensus required among all core functional leads. Conflicts are resolved by the Project Director; if irreconcilable within 48 hours, they are escalated to the PSC as an 'Operational Blockade.'

**Meeting Cadence:** Weekly (Operational Stand-up); Bi-weekly (Detailed Review).

**Typical Agenda Items:**

- Review of Critical Path Dependencies (Standards vs. Testing).
- Operator Compliance Report (API Uptime, Latency Checks).
- Clearing Mechanism Liquidity Status (Tracking against €200M float).
- Capacity Grant Utilization Review.

**Escalation Path:** Issues requiring financial approval >€500k, policy reinterpretation, or failure to secure operator cooperation that risks a key deadline (e.g., failure to adhere to the 'three strikes' policy) are escalated to the Project Steering Committee (PSC).
### 3. Technical Assurance & Standards Group (TASG)

**Rationale for Inclusion:** Given the absolute reliance on the novel, complex OSDM standard for real-time data, booking, and clearing, a dedicated body is needed to manage technical development agility, conformance testing, and mandatory governance evolution (Decision 10) without bureaucratic hindrance.

**Responsibilities:**

- Manage the evolution and formal ratification of OSDM V1.0 standards (Decision 4/10).
- Oversee the lifecycle of API functional compliance testing, ensuring T+5 latency is met.
- Provide technical advice to the PSC on all integration risks (Risk 2).
- Govern the immediate operational directives under the emergency review mandate (Assumption Q8).
- Ensure binding conformance testing for Accessibility Reservations (Decision 9) precedes core v1.0 finalization.

**Initial Setup Actions:**

- Establish the technical voting baseline for OSDM amendment consensus (65% agility threshold activated).
- Define the standardized, detailed test cases for T+5 latency validation.
- Appoint an independent Standards Review Board Chair.

**Membership:**

- Head of Technical Integration (Chair)
- Lead Architect (OSDM Focus)
- External Independent Technical Consultants (Ensuring Vendor Neutrality)
- Representative from the EU Agency for Railways (Testing Oversight)
- Two nominated Technical Leads from major Independent Distributors (for API consumer perspective)

**Decision Rights:** Binding approval on technical specifications for all OSDM V1.0 components; issuing of 'Provisional Operational Directives' under the 12-month emergency review mandate; setting technical criteria for operator certification.

**Decision Mechanism:** Dual Approval Threshold: 75% of internal members AND 65% among invited Member State technical representatives (where applicable). Emergency directives (first 12 months) require 65% consensus among core members only.

**Meeting Cadence:** Bi-weekly (during development phases); Monthly (post-ratification stabilization).

**Typical Agenda Items:**

- Review of Amendments/Change Requests to OSDM Specification.
- Conformance Testing Results Analysis (Focus on T+5 latency performance per operator).
- Accessibility Reservation Data Schema Validation Status (Decision 9 check-in).
- Technical Mitigation Plan Review for known integration bugs.

**Escalation Path:** Technical disagreements that threaten the 18-month binding deadline, or specifications that cause unworkable commercial terms (potential conflict with Decision 2), are immediately escalated to the Operational Management Group (OMG) for policy resolution or to the PSC if financial thresholds are impacted.
### 4. Compliance and Liability Assurance Board (CLAB)

**Rationale for Inclusion:** Due to the high regulatory burden, the critical nature of passenger rights (Decision 1/13), and the complexity of non-discriminatory commercial terms (Decision 2), a dedicated assurance body is necessary to enforce accountability, manage compliance audits, and govern the crucial financial liability framework independently of operations.

**Responsibilities:**

- Oversee compliance with the Passenger Rights Backstop activation thresholds (Decision 13).
- Conduct/commission compliance audits against the 'three strikes' enforcement posture (Decision 12), particularly on SNCF, DB, ÖBB.
- Verify national carrier adherence to cost-recovery royalty caps (Assumption Q3) via annual report review.
- Ensure non-discriminatory access to APIs and settlement mechanism liquidity.
- Provide independent assessment on determinations of 'gross distributor negligence' (Decision 3).

**Initial Setup Actions:**

- Formalize the charter for auditing IT cost allocations from national carriers.
- Establish the protocol for triggering the forensic audit upon 'three strikes' enforcement action.
- Develop the compliance reporting matrix linking Decision 2 (Commercial Terms) to Decision 5 (Clearing Mechanism).

**Membership:**

- Chief Compliance Officer (Chair)
- Internal Audit Lead
- External Regulatory Counsel (Independent)
- Risk Manager (Responsible for Clearing Float Stress Testing)
- Representative from National Regulatory Bodies (Non-voting, for local context)

**Decision Rights:** Binding determination on whether an operator has met compliance thresholds for continued participation in the clearing mechanism; recommendations for applying enforcement actions (subject to PSC final approval). Sole authority on validating compensation payout correlation data post-audit.

**Decision Mechanism:** Consensus among the Chair and Independent Counsel. The Risk Manager can raise a procedural objection requiring PSC review if audit findings directly threaten clearing mechanism solvency.

**Meeting Cadence:** Monthly, with immediate emergency session called upon the triggering of a 'three strikes' policy against a primary participant.

**Typical Agenda Items:**

- Review of Audit Findings on Cost Recovery Reporting.
- Assessment of Passenger Rights Backstop Utilization (Correlation with T+90 threshold).
- Status of Enforcement Actions against Primary Participants (SNCF, DB, ÖBB).
- Reviewing impact of TASG decisions on regulatory compliance.

**Escalation Path:** Any determination leading to suspension of clearing access, or any finding indicating potential misuse of the public budget or sustained non-compliance by a primary carrier, is immediately escalated to the Project Steering Committee (PSC) for sanctioning.