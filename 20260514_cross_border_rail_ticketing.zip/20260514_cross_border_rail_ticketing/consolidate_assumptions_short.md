# Purpose
# Coordinated European cross-border rail booking and ticketing infrastructure

## Purpose

- Developing and implementing a unified technical, commercial, and governance framework for seamless cross-border train travel across the EU.
- Improving market efficiency, passenger rights, and modal shift from air travel.
- Creating shared APIs, clearing mechanisms, and standardization aligned with EU regulation.


# Domain
# Project Structure Summary

## Primary Domains

- Financial Clearing Mechanisms

## Secondary Domains

- Digital Transport Regulation
- Rail Infrastructure Management
- Interoperability Standards

## Rationale
Financial Clearing Mechanisms is primary (single-payment settlement success). Financial Settlement Systems is secondary but related. Digital Transport Regulation and Interoperability Standards are foundational constraints/methods.

## Involved Disciplines

### Core (Outcome/Method/Constraint)

- Digital Transport Regulation (5/5): Constraint, aligned with proposed EU Regulation on Digital Booking.
- Interoperability Standards (5/5): Method, requires OSDM-compatible APIs and binding standards.
- Financial Clearing Mechanisms (5/5): Outcome, establishing inter-carrier clearing/settlement.
- Digital Distribution Systems (5/5): Method, building shared OSDM-compatible APIs.

### Supporting (Stakeholder/Method/Outcome)

- Rail Infrastructure Management (4/4): Stakeholder, National rail operators/infrastructure bodies.
- Passenger Rights Advocacy (4/4): Stakeholder, Disability rights/consumer groups.
- IT System Integration (4/4): Method, relies on unified APIs and system integration.
- Financial Settlement Systems (4/4): Outcome, single-payment inter-carrier clearing/settlement.
- European Union Law (4/3): Constraint, alignment with proposed EU Regulation on Digital Booking.


# Plan Type
# Project Planning Summary

## Execution Requirement

- Requires one or more physical locations.
- Cannot be executed digitally.

## Execution Justification

- Develop and implement multi-year program: shared technical standards (OSDM-compatible APIs), governance, and new financial clearing mechanisms across European countries.
- Requires extensive physical collaboration: stakeholders (DG MOVE, EU Agency for Railways, national operators, regulators) in physical meetings, workshops, and governance bodies.
- Necessary activities: define standards, perform conformance testing, manage rollout.
- Success relies on physical integration into real-world operator IT systems and testing end-to-end process (purchasing, journey execution, refunds).
- Inherently a physical process involving rail networks and passengers.
- Budget allocation and capacity building imply physical coordination.
- Plan is overwhelmingly physical due to implementation, governance, and real-world system integration.


# Physical Locations
# Requirements for physical locations

- Proximity to major EU institutions (DG MOVE, EU Agency for Railways)
- Facilities for high-level governance meetings and standards workshops
- Access to central European transport hubs for corridor testing coordination

## Location 1

- Belgium, Brussels (European Quarter/Near EU Institutions)
- Rationale: Ideal administrative/coordination hub for standards-setting/governance due to host of EC (DG MOVE) and proximity to initial launch corridor (Paris–Brussels–Amsterdam–Köln).

## Location 2

- France/Germany/Benelux (Paris–Brussels–Amsterdam–Köln Corridor Region)
- Testing facilities within central cluster areas (e.g., Lille, Frankfurt, or Rotterdam)
- Rationale: Critical for initial conformance testing and resolving early technical issues proximal to operators/infrastructure in the very first corridor slated for roll-out.

## Location 3

- Austria/Germany/Switzerland (Wien–München–Zürich Corridor Region)
- Munich or Vienna (as central connection points)
- Rationale: To facilitate parallel coordination/testing for the second primary corridor; a central base allows engagement with ÖBB, DB, and Swiss partners without diverting focus from Brussels.

## Location Summary
Physical locations must serve administrative coordination and initial corridor testing due to the multi-national nature of the program. Brussels is essential for EU body engagement. Additional locations are near the two highest-priority initial corridors (Paris-Amsterdam-Cologne and Vienna-Munich-Zurich) to facilitate on-the-ground testing and localized operational alignment.

# Currency Strategy
## Currencies

- EUR: Primary currency for EU-centered project.

- Primary currency: EUR
- Currency strategy: Budget in EUR. Local expenditures reconciled to EUR using standard FX procedures; no complex hedging assumed.


# Identify Risks
## Risk 1 - Regulatory & Permitting

- Political resistance or insufficient legal enforcement from rail operators/states leads to non-compliance with data/ticketing standards by deadlines.
- Impact: Invalidates 'continuity-of-journey' for large segments, 6–12 month delay on key routes, jeopardizes 40% through-ticket target.
- Likelihood: Medium, Severity: High
- Action: Maintain strong Enforcement Posture (Decision 12) via EU Agency for Railways mandatory pre-launch audits. Ensure linkage between standard adherence and clearing/settlement access is legally unambiguous.

## Risk 2 - Technical

- Integration challenges causing unstable OSDM-compatible real-time data layer (quality, latency, semantic mismatches).
- Impact: Distributors sell inaccurate tickets, high failed bookings/complaints (target requires halving), trust erosion. 2–3 month delay in commercial rollout on initial four corridors.
- Likelihood: High, Severity: High
- Action: Aggressively apply early incentives (Decision 6) for high data uptime. Use Public Reference Distributor (Decision 11) as validation sandbox to stress-test data transmission.

## Risk 3 - Financial

- Under-capitalization/insufficient liquidity in clearing/settlement due to the Builder transactional fee model, causing settlement delays/disputes.
- Impact: Stalls single-payment settlement, forces EU budget to cover float gaps (€50–€200 million in working capital support).
- Likelihood: Medium, Severity: Medium
- Action: Monitor rolling reserve fund balance (Decision 5). If below safety buffer, trigger swift request for temporary capitalization or mandate higher bank guarantees.

## Risk 4 - Supply Chain / Integration

- National operators prioritize mandatory API deadline (30 months) over harmonizing post-sale/ancillary services (accessibility, bicycle rules).
- Impact: Basic ticketing launches, but failure to integrate accessibility (Decision 9) or reduction cards (Decision 8) limits modal shift gain by 10–15% and causes regulatory non-compliance on equity grounds.
- Likelihood: High, Severity: Medium
- Action: Use phased standardization approach (Decision 4). Allocate mandatory conformance testing for accessibility data (Decision 9) immediately post-standards, ensuring parallel development with core APIs.

## Risk 5 - Operational/Governance

- Overly complex governance structure for OSDM amendment prevents rapid response to unforeseen bugs or refinements post-launch.
- Impact: Security patches or functional improvements take 6–9 months via dual-approval, leading to prolonged vulnerabilities (e.g., buggy refunds).
- Likelihood: Medium, Severity: Medium
- Action: Empower technical steering committee with expedited authority to issue 'clarification notices' for immediate implementation pending formal ratification (Decision 10).

## Risk 6 - Social / Stakeholder Management

- Operators resist defined liability framework (Decision 3), lobbying to weaken the Passenger Rights Backstop.
- Impact: Backstop failure (liability pushed to distributor/passenger) threatens reduced consumer complaints goal and 40% adoption target.
- Likelihood: Medium, Severity: High
- Action: Frame tiered liability (Decision 3) as necessary risk pooling supported by data transparency. Provide early actuarial modeling showing pooled risk is lower than unmanaged individual risk.

## Risk 7 - Market / Competition

- Distributors fail to rapidly adopt new system, preferring legacy methods, jeopardizing the 40% single through-tickets goal (5-year target).
- Impact: Economic justification for €1.5B investment diminishes. 20% adoption misses operational success metric.
- Likelihood: Medium, Severity: High
- Action: Aggressively implement Decision 2 (Capped Royalty Structure) to ensure fair commercial terms maximize distributor incentive for cross-border sales.

## Risk 8 - Environmental/Scope Creep

- Overly ambitious integration of non-core modes (buses, ferries) too early, diverting resources from stabilizing core rail ticketing.
- Impact: Core objective (corridor through-ticketing) delayed by 9–12 months due to engineering complexity spillover.
- Likelihood: Low, Severity: Medium
- Action: Adhere strictly to Decision 7: De-scope non-core integrations from Phase 1 (first 60 months). Focus on rail-to-rail OSDM compliance.

## Risk summary
Project faces high inherent risks due to regulatory mandate, multi-stakeholder complexity (20+ carriers), and dependency on novel OSDM APIs. Primary existential threats are Stakeholder Non-Compliance (Regulatory) and Shared Data Layer Instability (Technical). Political resistance endangers the project if enforcement is weak, while unreliable data functional failure. Mitigations rely on tight deadlines, phased implementation (Decision 4), and financial incentives (Decision 6). Builder scenario acceptance heightens need for technical validation to manage liability disputes.

# Make Assumptions
## Question 1 - Capitalization and Settlement Duration

- Initial capitalization requirement (float): €200 million.
- Acceptable settlement reconciliation duration: T+3 (99% of transactions).

Assumptions:

- Initial float set at €200 million based on busiest corridors.
- T+3 standard assumed manageable for 99% of transactions.

Assessments:

- Title: Financial Mechanism Viability Assessment
- Monitioring float (€200M) is necessary under transactional fee model.
- Risk: Low velocity depletes float, requiring public top-up (Risk 3).
- Opportunity: T+3 aligns with B2B standards, boosting carrier confidence.
- Mitigation: Weekly monitoring trigger on reserve fund balance.

## Question 2 - Standardization Grace Period

- Mandated grace period for legacy systems (reduction cards/accessibility booking): Additional 12 months (Total 30 months from start) after core APIs stabilize at 18 months.

Assumptions:

- Phased standardization: Core APIs stable by month 18 (final binding).
- Ancillary services (Accessibility/Reduction Cards) get an additional 12 months grace (30 months total mandate).

Assessments:

- Title: Harmonization Implementation Timeline Assessment
- Deferring complex features to month 30 provides necessary time for national operators (Risk 4 mitigation).
- Benefit: Prevents immediate overload jeopardizing core OSDM stability (month 18).
- Risk: Delaying accessibility risks early regulatory challenges on equity.

## Question 3 - API Data Access Audit Mechanism

- Mechanism: Annual audit via balance sheets focusing on IT operational costs attributable to OSDM data maintenance.
- Metric: Cost-recovery royalty rate capped at 5% of maintenance expenditure for the API endpoint.

Assumptions:

- Verification via annual audited balance sheets for IT operational costs.
- Standard cost-recovery royalty capped at 5% of required OSDM endpoint maintenance expenditure.

Assessments:

- Title: Commercial Governance Effectiveness Assessment
- Capped royalties necessitate robust audit capability (Decision 2).
- Risk: Operators inflating indirect IT costs, requiring strong regulatory challenge.
- Opportunity: Fair pricing lowers entry barriers for distributors (Risk 7), supporting 40% sales target.

## Question 4 - Primary Participants for Initial Audit Cycle

- Primary participants for first thirty-month audit cycle concerning 'Enforcement Posture': SNCF, Deutsche Bahn (DB), and ÖBB.

Assumptions:

- Mandated participants are SNCF, DB, and ÖBB due to centrality in two highest-volume initial corridors.
- Enforcement actions applied first to these three.

Assessments:

- Title: Regulatory Compliance Risk Management
- Focusing initial high-stakes enforcement (Risk 1) on these three is pragmatic.
- Benefit: Early success sets a strong operational precedent.
- Risk: Strong resistance from major players could trigger political friction.

## Question 5 - Public Funding Allocation

- Capacity building allocation: 60% (€900M) of €1.5B budget for IT grants/testing support.
- Ring-fenced percentage for the public reference distributor: 10% (€150M) for establishment and initial five-year running costs (Decision 11).

Assumptions:

- 60% (€900M) allocated to capacity building (IT grants/testing).
- 10% (€150M) reserved for the reference distributor (Decision 11).

Assessments:

- Title: Budget Allocation and Sustainable Operations Assessment
- Allocating 60% for grants mitigates resource strain (Risk 4).
- Fixed cost base from 10% reservation for reference distributor must be managed against usage fees.

## Question 6 - Real-Time Disruption Data Integration

- Operational Plan: Mandatory real-time latency benchmark required.
- Latency Benchmark: T+5 minutes (from event occurrence to API availability).

Assumptions:

- Mandatory real-time latency benchmark of T+5 minutes established via provisional binding standards (Decision 4, Month 6).
- T+5 is essential for automatically triggering passenger rights backstop (Decision 13).

Assessments:

- Title: Operational Data Interoperability Assessment
- T+5 latency benchmark forces high operational standards (Risk 2 mitigation).
- Benefit: Clear thresholds (Decision 13) enable automated backstop activation.
- Risk: Older infrastructure carriers might struggle with T+5, increasing enforcement pressure (Decision 12).

## Question 7 - Governance Body Staffing Plan

- Staffing Plan (First two years): 35 FTEs.

    - Standards management: 10 FTEs.
    - Conformance testing coordination: 15 FTEs (focused on physical locations).
    - Stakeholder relations: 10 FTEs.

Assumptions:

- Total required FTEs: 35 (Standards: 10, Testing Coordination: 15, Relations: 10).
- Testing coordination heavily focused on identified physical locations.

Assessments:

- Title: Resource Deployment and Physical Coordination Assessment
- Deploying 15 FTEs to testing coordination across physical locations is critical for resolving integration technical risks (Risk 2).
- Staffing 35 FTEs requires immediate operational budget allocation, separate from IT grants.

## Question 8 - Governance Structure for Rapid Adjustments

- Mechanism for rapid adjustments: Emergency review mandate granted to the Technical Steering Committee for the first twelve months post-launch (Decision 10).
- Amendment Process: Allows immediate enactment of 'provisional operational directives' via 65% consensus, requiring later final ratification.

Assumptions:

- Governance Structure (Decision 10) grants emergency review power to the Technical Steering Committee for 12 months post-launch.
- Amendments require only 65% consensus for provisional directives.

Assessments:

- Title: Governance Agility and Risk Tolerance Assessment
- Emergency override mitigates Risk 5 (slow amendments) and allows rapid adaptation to issues with liability (Decision 3) or data access (Decision 2).
- Benefit: Balances stability with necessary agility.


# Distill Assumptions
# Project Planning Summary

## Financial Allocations & Funding

- Initial clearing mechanism float: €200 million.
- Capacity building grants: €900M (60% of €1.5B) for national operators.
- Public reference distributor running costs: 10% (€150M) of €1.5B fund.
- Initial capitalization financed via transactional fee collateral.
- API access royalties capped at 5% of attributable IT O&M expenditure; strictly cost-recovery, regulator overseen.

## Governance & Standards

- Central governance body requires 35 dedicated FTEs for the first two years.
- Governing structure allows 65% consensus for emergency amendments for the first twelve months post-launch.
- Technical specifications achieve provisional binding status within six months.
- Core OSDM data exchange standards mandate formal binding status within eighteen months.
- Provisional binding status required at six months, finalization at eighteen months.

## Operational Assumptions & Benchmarks

- Settlement reconciliation delays assumed manageable within T+3 for 99% of transactions.
- Mandatory real-time latency benchmark (T+5 minutes) established at month 6.
- Full harmonization of accessibility and reduction cards granted a 30-month grace period.

## Enforcement & Liability

- Primary participants for initial audit: SNCF, DB, and ÖBB.
- Enforcement posture: 'three strikes' rule leading to suspension of through-ticketing sales.
- Tiered liability: segment carrier fully responsible for compensation costs unless negligence is proven.
- Initial operators bear 100% compensation costs unless gross distributor negligence is proven.
- Backstop protection activates only for connections cancelled or delayed/missed exceeding 90 minutes.
- EU backstop limits compensation to connecting failures between the first and last known segment failures.


# Review Assumptions
# Domain of the expert reviewer
Multi-Jurisdictional Project Governance and Infrastructure Integration

## Domain-specific considerations

- Regulatory Harmonization Across Sovereign Entities
- Financial Clearing Mechanism Solvency
- IT Standards Adoption (OSDM) Across Legacy Systems
- Commercial Non-Discrimination and Cost Recovery
- Critical Path Dependencies (Data Layer before Clearing/Ticketing)

## Issue 1 - Unrealistic Grace Period for Ancillary Harmonization (Accessibility/Loyalty)
The 30-month grace period for ancillary systems (Accessibility/Loyalty) conflicts with the 18-month mandate for core ticketing APIs. Accessibility (Decision 9) is a non-negotiable equity requirement; delay risks non-compliance and undermines modal shift goals.

Recommendation: Adjust governance (Decision 10) to require functional conformance testing for Accessibility Reservations (Decision 9) completion *before* core ticketing APIs reach final binding status at month 18. Provisional binding at month 6 must require PRM data schema finalization.

Sensitivity: Delaying accessibility past Month 24 risks regulatory fines (3-7% operational budget annually), reducing ROI by 8-12% (brand damage/legal costs).

## Issue 2 - Insufficient Contingency for Clearing Mechanism Float Depletion
The plan relies on a provisional €200M float financed by transactional collateral (Decision 5, Builder Scenario), settling at T+3. Low initial velocity risks insufficient collateral to cover peak risk or liquidity gaps before the reserve fund capitalizes, jeopardizing the financial backbone.

Recommendation: Ring-fence 20% of the €1.5B coordination budget (€300M total) as an 'Emergency Float Reserve' for the clearing mechanism, accessible if T+3 fails for 48 hours or collateral drops below 150% of peak daily obligation.

Sensitivity: If the initial €200M float requires a public €50M injection, CapEx increases by 3.3% (€50M / €1.5B), reducing ROI by 2-4 points via overhead.

## Issue 3 - Lack of Assumption on Key Operator Behavioral Response to Enforcement
Success hinges on aggressive Enforcement Posture (Decision 12—'three strikes' suspension) against major operators (SNCF, DB, ÖBB). No mitigation is planned for political fallout or coordinated resistance if majors lobby to weaken governance (Decision 10) or delay compliance past 18 months.

Recommendation: Develop a 'Political De-escalation' plan prioritized over technical mitigation. Pre-negotiate short-term (90-day) technical assistance packages funded by the capacity budget (€900M) for the first operator facing the third strike, maintaining the threat of exclusion.

Sensitivity: If lobbying causes a 6-month delay in enforcing posture against the top 3 operators, technical integration risk (Risk 2) rises, likely causing a 4-6 month delay in achieving 40% through-ticket sales (15-20% Year 2 revenue shortfall).

## Review conclusion
The plan shows excessive optimism regarding ancillary system alignment and clearing mechanism self-sufficiency. Critical missing factors involve managing regulatory pushback on enforcement, securing day-one clearing mechanism stability, and resolving accessibility integration without early regulatory risk. Immediate focus must be on contingency funding for clearing and integrating accessibility compliance testing into the core standard ratification timeline.