*Roles Needed & Example People*

# Roles

## 1. EU Regulatory & Governance Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The EU Regulatory & Governance Architect must maintain constant alignment with DG MOVE/Agency for Railways and anchor operational decisions, requiring deep internal commitment and continuous presence, suitable for a full-time role.

**Explanation**:
Responsible for ensuring compliance with the proposed EU Regulation, managing stakeholder reporting to DG MOVE and the EU Agency for Railways, and anchoring the project's operational decisions within the political and legal framework.

**Consequences**:
Risk of misalignment with final legal text, slow approvals on binding standards (Decision 4), and failure to establish functional enforcement posture (Risk 1).

**People Count**:
min 1, max 2, depending on workload for DG MOVE liaisons

**Typical Activities**:
Leading monthly alignment sessions between the Project Steering Committee and DG MOVE; drafting legal instruments making OSDM specifications provisionally and formally binding; establishing the legal basis for cross-border enforcement mechanisms (the 'Three Strikes' policy); managing liaison reporting schedules for the Agency for Railways.

**Background Story**:
Dr. Elara Vancini, hailing from Rome, Italy, brings a formidable background forged through years at the intersection of EU transport law and digital policy implementation; she holds a dual Ph.D. in European Public Law and Information Systems from Leiden and Bologna Universities, enabling her to bridge complex regulatory mandates with technical realities. Her extensive experience includes serving as a senior advisor during the initial drafting phases of several major EU digital service regulations, giving her firsthand knowledge of how mandates translate (or fail to translate) into binding technical standards, and she is intimately familiar with the consensus-building required among Member States. Elara is exceptionally relevant because her expertise ensures that the project’s governance (Decision 4 & 10) and enforcement posture (Decision 12) are legally defensible and politically robust, preventing the kind of stakeholder stalling that plagued earlier infrastructure projects.

**Equipment Needs**:
Access to secure EU network infrastructure for sensitive policy document exchange and DG MOVE/Agency for Railways secure digital reporting portals.

**Facility Needs**:
Dedicated office space with high-security classification in Brussels (Location 1) for continuous governance presence and confidential policy workshops.

## 2. Interoperability Standards Lead (OSDM/Technical Governance)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Interoperability Standards Lead needs to drive OSDM finalization and manage continuous governance changes. This requires dedicated, long-term organizational commitment to ensure technical stability throughout the five-year lifespan.

**Explanation**:
Drives the definition, finalization, and amendment process for the OSDM-compatible APIs, ensuring the technical specifications meet the T+5 latency benchmark and address ancillary requirements like accessibility data structures.

**Consequences**:
Technical divergence between operators, unstable data layer (Risk 2), failure to meet API exposure deadlines (Decision 14), leading to platform instability.

**People Count**:
3, to cover standards definition, technical drafting, and drafting procedural documentation for governance amendments efficiently.

**Typical Activities**:
Chairing the Technical Working Group for OSDM finalization; overseeing the drafting and release of the Provisional Binding Specification V0.9; designing the data validation protocols ensuring T+5 latency compliance for real-time inventory feeds; analyzing system proposals from rail operators for OSDM-backward compatibility.

**Background Story**:
Kenji Ito, originally from Tokyo but having completed his Master’s in Computer Science at ETH Zurich, specializes in high-throughput, distributed ledger technologies and API standardization, having previously worked on designing transactional messaging systems for global logistics firms coordinating supply chains across Asia. Kenji possesses deep, practical experience with high-velocity data layers, specifically ensuring latency metrics like the T+5 minute benchmark are technically achievable and verifiable under real-world load, making him the perfect lead for OSDM implementation. He is relevant because the entire project hinges on the technical success of the shared real-time data layer; Kenji’s ability to shepherd the OSDM specification through provisional binding status and manage necessary post-launch amendments (Decision 10) is crucial to mitigating technical risk (Risk 2).

**Equipment Needs**:
High-performance, isolated testing environment (sandboxed OSDM V0.9 instance) capable of simulating high-volume, multi-party data exchanges (T+5 latency testing). Access to advanced API monitoring and debugging tools.

**Facility Needs**:
Primary workspace in Brussels (Location 1) and guaranteed functional access to dedicated testing labs at either Location 2 or Location 3 for physical integration checks.

## 3. Financial Clearing & Settlement Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Financial Clearing & Settlement Specialist is responsible for the core financial backbone, including critical infrastructure ($200M float, transactional models). This demands sustained, dedicated oversight and fiduciary responsibility best suited to an FTE.

**Explanation**:
Designs, capitalizes, and manages the ongoing solvency of the inter-carrier clearing mechanism. This role models the transactional fee structure, monitors the Emergency Float Reserve (€300M), and advises on settlement reconciliation (T+3 assumption).

**Consequences**:
Financial instability leading to settlement delays, failure of single-payment settlement objective, and potential depletion of the security float (Risk 3).

**People Count**:
2, due to the critical nature of finance and the need for simultaneous simulation/design during the setup phase.

**Typical Activities**:
Developing the definitive algorithm for the variable transactional fee ('R') applied to ticket sales; modeling liquidity requirements for the €200M operational float under various velocity scenarios; managing due diligence procedures for external bank guarantees; coordinating with the Risk Manager to authorize drawdown protocols for the Emergency Float Reserve.

**Background Story**:
Sofia Rossi, a financial engineer from Milan, Italy, arrived with a reputation for stabilizing complex inter-institutional transactions, having spent a decade at a major European investment bank designing counterparty risk mitigation models for emerging EU-wide financial services legislation. Her expertise lies in creating solvent mechanisms from scratch, a skill honed during the post-crisis mandate to ensure liquidity in cross-border finance; she is highly familiar with capitalization modeling, collateralization, and transaction fee structures, aligning perfectly with Decision 5 and the Builder scenario's transactional fee approach. Sofia is indispensable because the clearing mechanism is the operational heart of the single-payment objective; her role is to ensure its solvency using the transactional fees while monitoring the €300M emergency float reserve against low early velocity (Risk 3).

**Equipment Needs**:
Specialized financial modeling software (e.g., Monte Carlo simulation tools for liquidity stress testing) and access to escrow/guarantor bank portals for monitoring collateral.

**Facility Needs**:
Secure, shielded working environment for managing financial float data; primary base ideally near central European financial hubs, though Brussels (Location 1) suffices for governance alignment.

## 4. Rail Operator Liaison & Integration Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Rail Operator Liaison must manage high-stakes, ongoing relationships with 20+ operators, driving adoption and compliance reporting. This sustained engagement and political navigation require a dedicated, integrated FTE.

**Explanation**:
The primary interface for the 20+ national rail operators (SNCF, DB, ÖBB, etc.). Responsible for driving adoption, verifying commercial cost-recovery reporting, and managing compliance auditing for the primary enforcement targets.

**Consequences**:
Political resistance hardening (Risk 1, Risk 6), failure to enforce data exposure, and inability to track IT operational costs for royalty calculation (Decision 2).

**People Count**:
min 1, max 3, depending on the complexity/number of initial operators engaged.

**Typical Activities**:
Conducting quarterly compliance verification workshops with SNCF and DB representatives, focusing on IT cost attribution for royalty calculations; leading negotiations on the tiered liability model (Decision 3) with national regulatory bodies; serving as the primary contact for implementing the 'Three Strikes' enforcement posture.

**Background Story**:
Mathias Weber, a seasoned manager raised near Frankfurt, Germany, spent twenty years at Deutsche Bahn’s corporate strategy division, specializing in navigating national regulatory hurdles and negotiating integration compromises between domestic mandates and EU-level interoperability goals post-2010. His deep institutional memory of operator hesitations regarding data sharing and his established relationships with IT directors at major lines make him the vital bridge between the centralized project team and the 20+ decentralized national carriers. Mathias is essential because he is tasked with achieving buy-in and ensuring compliance from the very entities most likely to resist external control (SNCF, DB, ÖBB); his success governs the feasibility of both the data exposure deadlines and the layered liability framework (Risk 1 and Risk 6 mitigation).

**Equipment Needs**:
Secure communication channels (encrypted lines primarily) for confidential negotiations with national carrier executives (SNCF, DB, ÖBB). Access to operator IT team contact lists and organizational charts.

**Facility Needs**:
Flexible meeting facilities capable of hosting workshops with operators, potentially requiring travel to host countries (France, Germany, Austria) for targeted engagement sessions.

## 5. Passenger Rights & Equity Policy Analyst

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Passenger Rights & Equity Policy Analyst focuses on complex regulatory interpretation (90-min threshold, accessibility) crucial for success, but this specialized legal/policy expertise is often sourced externally via short-to-medium term contracts for specific policy drafting.

**Explanation**:
Focuses entirely on the consumer-facing elements: setting the 90-minute continuity threshold (Decision 13), designing the structure of the pooled backstop, and ensuring compliance with accessibility harmonization (Decision 9) and reduction card recognition (Decision 8).

**Consequences**:
Failure to meet consumer trust goals, regulatory non-compliance on equity grounds (Risk 4), and potential legal challenges regarding the 90-minute trigger threshold.

**People Count**:
1, as the area requires deep policy knowledge but is distinct from the primary financial/technical integration work.

**Typical Activities**:
Analyzing the actuarial impact of the 90-minute continuity threshold (Decision 13) against disability rights advocacy group submissions; drafting policy guidance for integrating national reduction card value conversion (Decision 8); serving as the primary liaison with BEUC and disability rights bodies to validate the fairness of the pooled backstop structure.

**Background Story**:
Anya Petrova, based out of Warsaw, Poland, transitioned into policy analysis after starting her career lobbying for robust consumer protection in the telecommunications sector, giving her a sharp focus on regulatory fairness and equitable access. She holds advanced degrees in International Consumer Law and is deeply familiar with the political sensitivity surrounding national loyalty programs and accessibility mandates across Eastern and Western European markets. Anya is crucially relevant because the success metrics include halving distributor complaints and improving modal attractiveness, both of which rely heavily on consumer trust derived from fair dealings regarding delays and discounts. She is responsible for translating complex legal requirements for PRM booking (Decision 9) and discount recognition (Decision 8) into practical, enforceable operational thresholds (Decision 13).

**Equipment Needs**:
Access to regulatory drafting software and comparative law databases focused on EU consumer rights directives. Tools for modelling the impact of various delay/refund thresholds on passenger trust metrics.

**Facility Needs**:
Dedicated meeting space for consultations with consumer advocacy groups (BEUC) and disability rights bodies, likely based within the Brussels administrative hub (Location 1) for ease of engagement.

## 6. Digital Distributor & Market Adoption Strategist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Digital Distributor & Market Adoption Strategist focuses on commercial terms and uptake metrics (40% target). This role benefits from external insights from market-facing entities (like FinTech/OTA perspectives) and may be contracted for specific commercial modeling/engagement periods.

**Explanation**:
Represents the needs of platforms (Trainline, Omio) and the public reference distributor. This role drives adoption by ensuring commercial terms (Decision 2) are fair and API usability is maximized, directly tracking progress toward the 40% sales target.

**Consequences**:
Distributors may reject the system due to high integration costs/poor API stability (Risk 7), jeopardizing the 40% sales metric.

**People Count**:
min 1, max 2, depending on the competitive landscape analysis required.

**Typical Activities**:
Validating the proposed capped royalty structure (Decision 2) against market expectations for data access costs; designing incentive frameworks for the Public Reference Distributor's uptake; modeling distributor dependency curves based on API usability and commercial terms; reporting progress against the 40% market penetration target.

**Background Story**:
Chloe Dubois, an independent consultant from Paris, France, specialized in Digital Marketplaces and Platform Economics, having previously advised European OTAs (Online Travel Agencies) on scaling customer acquisition and managing dynamic pricing across complex inventory systems. Chloe brings an external market perspective, understanding that the 40% through-ticket goal relies entirely on distributors finding the new APIs commercially viable and easy to integrate. Her expertise in commercial structuring (Decision 2) and adoption strategies is necessary to counteract platform friction (Risk 7). She is relevant because she ensures the project output is competitive and attractive to the third-party distributors who must sell the final product, balancing their integration costs against the capped royalty structure.

**Equipment Needs**:
Access to distributor API sandbox environments for usability testing; market analysis software for tracking cross-border ticket sales velocity and competitor performance.

**Facility Needs**:
Flexible collaboration space suitable for joint workshops with independent distributors (e.g., in a central European business/tech hub).

## 7. Program Risk Manager & Contingency Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Program Risk Manager & Contingency Coordinator owns the integrated risk register and manages immediate contingency activation protocols (like Emergency Float release). This necessary organizational continuity and rapid response capability demands a dedicated, embedded FTE.

**Explanation**:
Owns the integrated risk register, tracks adherence to the five-year deadlines, manages the relationship between the rapid amendment governance (Decision 10) and the emergency float release protocols (Contingency Action), ensuring agility and swift response to critical failures.

**Consequences**:
Critical risks (like clearing float depletion or political enforcement failure) are not escalated or addressed with contingency plans quickly enough, leading to cascading delays (Risk 5).

**People Count**:
1, this is a dedicated oversight function central to the 'Builder' scenario's pragmatic, risk-managed execution.

**Typical Activities**:
Chairing the bi-weekly risk review board; coordinating immediate technical response drills when T+5 latency spikes threaten the continuity threshold; managing the formal governance process for enacting provisional operational directives under the emergency mandate; ensuring all regulatory reporting milestones are flagged in advance for mandatory DG MOVE sign-offs.

**Background Story**:
Dr. Liam O’Connell, based in Dublin, Ireland, has a background in enterprise risk management methodologies, specializing in regulatory compliance monitoring across multinational, multi-year infrastructure programs funded by the EU. Liam’s specialty lies in tracking complex critical path dependencies, particularly the reliance of financial mechanisms on technical milestones, and creating the operational procedures to activate contingency plans swiftly. He is responsible for owning the integrated risk register and ensuring that the governance agility measures (Decision 10) are properly aligned with the financial backstops (the Emergency Float). Liam’s role is central to the 'Builder' scenario, as his focus prevents unforeseen technical or political issues from causing cascading delays or financial insolvency (Risk 5 and Risk 3).

**Equipment Needs**:
Access to the integrated risk register visualization dashboard and automated alerting system linked to contingency triggers (e.g., float depletion, governance deadline breaches).

**Facility Needs**:
A dedicated, secure office location (Brussels preferred) allowing for rapid mobilization of crisis response teams when contingency plans are enacted.

## 8. Cross-Corridor Conformance Testing Coordinator

**Contract Type**: `agency_temp`

**Contract Type Justification**: The Cross-Corridor Conformance Testing Coordinator manages a large team (15 FTEs) conducting intensive, short-to-medium term technical validation across physical hubs. This project-specific, surge capacity requirement is best filled by experienced technical staff supplied via an agency contract.

**Explanation**:
Manages the 15 assigned testing FTEs, coordinating physical testing logistics across the three designated hub locations (Brussels, Corridor 1 Area, Corridor 2 Area) to resolve integration issues (Risk 2) and validate T+5 latency benchmarks.

**Consequences**:
Testing becomes siloed or uncoordinated, leading to prolonged technical instability and failure to certify core APIs by the 18-month deadline.

**People Count**:
2, to provide operational redundancy and cover logistics across multiple physical testing sites simultaneously.

**Typical Activities**:
Designing and executing end-to-end integration test suites across simulated and live environments for the initial corridors; coordinating the physical logistics for testing teams deployed to Location 2 and Location 3; verifying operator compliance with the T+5 minute latency benchmark through dedicated monitoring tools; creating final conformance certification reports for the EU Agency for Railways.

**Background Story**:
Dr. Benjamin Koo, who took his doctorate in Logistics Engineering from Delft in the Netherlands, is an expert in large-scale testing orchestration, having managed the deployment QA for complex European rail signaling projects like ERTMS. He knows precisely how to coordinate technical testing across disparate physical environments, making him ideal for coordinating the 15 dedicated testing FTEs across the Brussels hub and the two initial corridor testing grounds. Benjamin is critical for mitigating major technical risk (Risk 2) by designing test scenarios that force failures in data latency (T+5) and cross-operator fault attribution; his teams validate the feasibility of the hard deadlines mandated for API exposure (Decision 14).

**Equipment Needs**:
Logistics management suite for coordinating the 15 testing FTEs across multiple physical sites (Location 2 and 3). Budget tracking for travel, local access permits, and testing infrastructure deployment.

**Facility Needs**:
Dedicated logistics and coordination office access at Location 2 and/or Location 3 to manage on-the-ground testing operations proximal to core corridor infrastructure.

---

# Omissions

## 1. Missing Dedicated Standards Maintenance/Evolution Team

The team has an Interoperability Standards Lead group (3 FTEs) focused on *finalizing* OSDM V1.0. However, given the binding timeline (18 months) and the need for rapid post-launch amendments (Decision 10 concerns), there is no dedicated resource aligned with Risk 5 (slow governance) specifically tasked with the ongoing maintenance, testing, and iteration/V2.0 planning post-launch.

**Recommendation**:
Add one dedicated Technical Standards Engineer (perhaps agency_temp for high initial burst) whose sole mandate is maintaining the OSDM specification documentation and coordinating the Technical Steering Committee's provisional directives post-launch, ensuring technical agility without burdening the initial design team.

## 2. Lack of Dedicated IT Audit/Compliance Verification Team

The success of Decision 2 (Capped Royalties at 5% IT Cost Recovery) relies on rigorous annual auditing of operator IT maintenance costs. The existing team focuses on *enforcement* (Liaison Manager) and *core design*, but staff dedicated specifically to complex IT cost attestation, against potentially resistant national operators (SNCF, DB, ÖBB), are missing.

**Recommendation**:
Allocate budget to contract specialized IT forensic accountants or IT auditors (perhaps linked to the Conformance Testing Coordinator's external support structure) for a 6-month engagement annually, specifically to scrutinize operator cost submissions against the 5% royalty cap.

## 3. No Dedicated Cross-Corridor Testing Infrastructure/Logistics Support

The Conformance Testing Coordinator manages 15 FTEs spread across three physical locations (Brussels, Corridor 1 Area, Corridor 2 Area). This role risks becoming purely administrative, lacking dedicated logistical support to manage travel, hardware deployment, and localized testing environments specific to national differences outside Brussels.

**Recommendation**:
Assign one administrative/logistics assistant (perhaps Agency_Temp) reporting to the Conformance Testing Coordinator. This individual will focus exclusively on managing facility access, hardware movement between Locations 2 & 3, and travel arrangements for the 15 testing staff, freeing up the Coordinator for technical oversight.

## 4. Undefined Relationship between Public Fund Manager and Clearing Mechanism Operations

While the Financial Specialist drives the design (Decision 5) and the Risk Manager monitors the Emergency Float (€300M), there is no explicit role responsible for the day-to-day operational administration of disbursing public funds for capacity building (€900M) or managing the strict reporting requirements for the Emergency Float access protocols.

**Recommendation**:
Integrate the operational accounting tasks related to the €1.5B budget drawdown and tracking grants against the capacity building plan into the responsibilities of the Financial Clearing & Settlement Specialist, clarifying that this specialist manages both the private-sector clearing float *and* the public-sector contingency/grant execution.

---

# Potential Improvements

## 1. Clarify Timeline Risk Between Core API Binding and Ancillary Harmonization

The plan assumes a 12-month grace period (ending at 30 months) for full accessibility/reduction cards (as per Assumption 2), but Risk 4 notes these must be harmonized earlier to avoid limiting modal shift. The current team structure separates the Policy Analyst (responsible for Decision 8/9) from the Standards Lead, creating a coordination gap.

**Recommendation**:
Mandate a joint working session (chaired by the EU Regulatory & Governance Architect) bi-monthly for the first year, forcing the Interoperability Standards Lead and the Passenger Rights & Equity Policy Analyst to integrate finalized accessibility/discount data schemas directly into the Provisional Binding Specification (V0.9) released at month 6.

## 2. Strengthen Engagement with Key Enforcement Targets (SNCF, DB, ÖBB)

The Rail Operator Liaison is tasked with enforcing compliance and auditing costs against the major players (SNCF, DB, ÖBB), but there is no dedicated mechanism to handle foreseen political resistance or coordinated lobbying (Risk 6).

**Recommendation**:
The Rail Operator Liaison & Integration Manager should formally delegate accountability for managing political de-escalation negotiation support (as recommended in Review Assumption Issue 3) to the EU Regulatory & Governance Architect, leveraging their primary relationship with DG MOVE to counter political friction proactively.

## 3. Formalize the Distributor Feedback Mechanism into Governance

The Digital Distributor Strategist manages adoption and commercial feedback (Risk 7), reporting on the 40% target. This feedback is crucial but sits outside the primary governance loops (TSC/Steering Committee) that manage technical standards and risk.

**Recommendation**:
Ensure the TSC formally reviews the Digital Distributor & Market Adoption Strategist’s adoption metrics and key usability feedback from distributors quarterly, granting the TSC the right to issue provisional directives (under its emergency mandate) specifically addressing API usability issues, ensuring technical focus remains market-relevant.

## 4. Clarify Physical Testing Site Ownership and Cross-Site Coordination

Testing spans Brussels (Location 1) and two remote corridor hubs (Location 2 & 3). Without clear ownership, handover of testing artifacts, hardware deployment, and resolution tracking between the Brussels-based Standards team, the Coordinator, and the remote testing crews risks delays.

**Recommendation**:
Establish a standardized 'Test Wave Handoff Protocol' owned by the Cross-Corridor Conformance Testing Coordinator. This protocol must dictate the exact data package (logs, configuration files, issue tickets) required from Location 2/3 teams before they demobilize, which must be immediately reviewed by the Standards Lead team in Brussels upon receipt.