## Domain of the expert reviewer
Multi-Jurisdictional Project Governance and Infrastructure Integration

## Domain-specific considerations

- Regulatory Harmonization Across Sovereign Entities
- Financial Clearing Mechanism Solvency
- IT Standards Adoption (OSDM) Across Legacy Systems
- Commercial Non-Discrimination and Cost Recovery
- Critical Path Dependencies (Data Layer before Clearing/Ticketing)

## Issue 1 - Unrealistic Grace Period for Ancillary Harmonization (Accessibility/Loyalty)
The assumption grants a 30-month grace period for complex ancillary systems (Accessibility/Reduction Cards) while core ticketing APIs are mandated binding at 18 months. Accessibility (Decision 9) is a non-negotiable regulatory/equity requirement. Delaying harmonization risks early regulatory non-compliance and undermines the modal shift objective by penalizing existing loyal customers. This deferral is a significant tactical omission of risk.

**Recommendation:** Immediately adjust the governance structure (Decision 10) to mandate that full functional conformance testing for Accessibility Reservations (Decision 9) must pass *before* final binding status is granted to core ticketing APIs at month 18. The provisional binding status at month 6 must explicitly require the standardized PRM data schema be finalized, even if backend infrastructure rollout is staggered. This shifts the focus from avoiding an IT load to ensuring compliance meets legal intent.

**Sensitivity:** If full accessibility compliance is delayed beyond Month 24 (baseline 30 months), the project faces regulatory fines estimated at 3-7% of the operational budget annually, potentially reducing overall ROI by 8-12% due to brand damage and legal costs, even if ticketing revenue meets targets.

## Issue 2 - Insufficient Contingency for Clearing Mechanism Float Depletion
The assumption relies on a provisional €200M float financed solely by transactional collateral (Decision 5, Builder Scenario), with settlement targeted at T+3. The inherent risk is that during the initial ramp-up (first 9-12 months), transaction velocity will be low, and the initial collateral may prove insufficient to cover peak settlement risk or temporary liquidity gaps caused by systemic failures before the reserve fund self-capitalizes effectively. This jeopardizes the financial backbone of the entire system.

**Recommendation:** Mandate that 20% of the total €1.5B coordination budget (€300M total) be ring-fenced immediately, not just for the reference distributor, but as a guaranteed, immediately accessible liquidity backstop for the clearing mechanism. This 'Emergency Float Reserve' should only be activated if the T+3 target fails for 48 consecutive hours or the transactional collateral dips below 150% of the baseline peak daily obligation.

**Sensitivity:** If the initial €200M float proves insufficient and requires a public injection of €50M (baseline: fully self-funded), the project's total capital expenditure increases by 3.3% (€50M on €1.5B), potentially reducing final ROI by 2-4 percentage points through increased program overhead.

## Issue 3 - Lack of Assumption on Key Operator Behavioral Response to Enforcement
The success relies heavily on an aggressive Enforcement Posture (Decision 12—'three strikes' leading to suspension) against key players like SNCF, DB, and ÖBB (Assumed Primary Participants). There is no explicit assumption or mitigation planned for the political fallout or coordinated resistance if these majors actively lobby to weaken the governance structure (Decision 10) or delay full compliance past the 18-month core mandate, viewing suspension as an unacceptable commercial threat.

**Recommendation:** Develop a structured 'Political De-escalation' plan prioritized over technical mitigation. This plan must include pre-negotiated, short-term (90-day) technical assistance packages funded by the capacity budget (€900M) earmarked only for the first operator facing the third strike, instead of immediate suspension. This buys time for negotiation while maintaining the implicit threat of commercial exclusion.

**Sensitivity:** If political lobbying forces a 6-month delay in applying the enforcement posture against the top 3 operators (baseline: immediate enforcement), the technical integration risk (Risk 2) rises significantly, likely causing a 4-6 month delay in achieving 40% through-ticket sales, translating to a 15-20% shortfall in projected Year 2 revenue.

## Review conclusion
The current plan exhibits excessive optimism regarding the alignment of complex, mandatory ancillary systems (accessibility/loyalty) and relies too heavily on the self-sufficiency of the initial financial clearing mechanism float. The three most critical missing considerations relate to managing regulatory pushback on enforcement, ensuring the financial stability required for day-one settlement, and addressing the non-negotiable equity issues of accessibility integration without creating early regulatory risk. Immediate action must focus on creating contingency funding for the clearing mechanism and integrating accessibility compliance testing directly into the core standard ratification timeline.