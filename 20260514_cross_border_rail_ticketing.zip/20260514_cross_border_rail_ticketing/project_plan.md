**Goal Statement:** Deliver a coordinated European program making cross-border train travel as easy to search, book, and refund as national travel, achieving 40% of eligible cross-border journeys sold as single through-tickets within five years.

## SMART Criteria

- **Specific:** Establish the technical, commercial, and governance arrangements for compliant distributors to sell single through-tickets across all participating carriers with continuity-of-journey rights, single-payment settlement, and harmonized refunds.
- **Measurable:** Success will be measured by achieving 40% of cross-border journeys sold as single through-tickets, a 50% reduction in distributor complaints, and making the train the more attractive option than flying on competitive short-haul routes.
- **Achievable:** The goal is achievable through the strategic adoption of the 'Pragmatic Harmonization and Shared Burden' scenario, utilizing phased standardization, regulator-mandated data exposure (OSDM), and a structured €1.5 billion public coordination budget to bridge implementation gaps.
- **Relevant:** This is necessary to fulfill the EU Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail, significantly improving consumer experience, ensuring passenger rights, and promoting modal shift away from air travel.
- **Time-bound:** Five years for the 40% adoption target; binding standards within eighteen months; mandatory API exposure within thirty months.

## Dependencies

- Establish common technical specifications (OSDM-compatible APIs) across all participating carriers.
- Define and agree upon non-discriminatory commercial terms for data access and API exposure.
- Establish and capitalize the inter-carrier clearing and settlement mechanism.
- Formalize the governance structure for standard adoption, amendment, and enforcement.
- Establish the liability framework and fund the passenger-rights backstop.

## Resources Required

- €1.5 billion public coordination budget (for standards work, testing, clearing fund, public reference distributor)
- Defined OSDM version 1.0 standard documentation
- Personnel capacity (35 FTEs for governance/standards/testing in the first two years)
- Legal and regulatory mandate from DG MOVE

## Related Goals

- Achieve timely harmonization of reduction card recognition.
- Ensure full accessibility mandates (PRM booking) are integrated into the V1.0 standard.
- Integrate provisional API hooks for buses, ferries, and short-haul air (post five-year target).

## Tags

- Rail
- Ticketing
- Interoperability
- OSDM
- Passenger Rights
- EU Regulation
- Digitalization

## Risk Assessment and Mitigation Strategies


### Key Risks

- Political resistance or insufficient legal enforcement from state operators delaying standard compliance past deadlines.
- Integration challenges causing unstable OSDM-compatible real-time data layer (latency, semantic errors).
- Under-capitalization or low liquidity in the clearing/settlement mechanism due to slow initial transactional velocity.
- National operators prioritizing core API compliance over harmonizing mandatory ancillary services (Accessibility/Reduction Cards).
- Slow governance structure preventing timely technical pivots post-launch.

### Diverse Risks

- Coordinated lobbying by major incumbent operators to weaken the tiered liability framework.
- Over-ambitious scope creep via early integration of non-core transport modes.
- Distributors failing to rapidly adopt the new system due to perceived friction, jeopardizing the 40% sales goal.
- Inflation of IT operational costs by carriers to justify higher cost-recovery royalties for data access.

### Mitigation Plans

- Implement a clear 'three strikes' enforcement posture, leading to suspension of through-ticketing sales for non-compliant carriers (SNCF, DB, ÖBB targeted first).
- Apply early incentives (funding grants) tied to achieving high uptime (90%+) on test systems for the shared data layer.
- Implement a transactional fee model for clearing capitalization, backed by a ring-fenced €300 million 'Emergency Float Reserve' available if the operational float drops below 150% of peak daily obligation.
- Require functional conformance testing for Accessibility Reservation data schemas to complete concurrently with core API finalization at month 18, despite the longer service rollout grace period.
- Empower the Technical Steering Committee with an emergency review mandate (65% consensus) for the first twelve months post-launch to issue provisional operational directives for immediate change.

## Stakeholder Analysis


### Primary Stakeholders

- DG MOVE (European Commission Directorate-General for Mobility and Transport)
- EU Agency for Railways (Technical oversight, testing coordination)
- National Rail Operators (SNCF, DB, Trenitalia, Renfe, ÖBB, NS, SJ, etc. - IT providers and commercial entities)
- Independent Distributors (e.g., Trainline, Omio - API consumers)

### Secondary Stakeholders

- CER (Community of European Railways - Industry representative)
- BEUC (European Consumer Organisation)
- National Regulatory Bodies
- Disability Rights Bodies / Consumer Groups

### Engagement Strategies

- DG MOVE/Agency for Railways: Provide weekly progress reports focused on governance adoption and adherence to binding standard timelines.
- National Rail Operators (Primary): Engage via structured workshops for OSDM specification finalization; enforce commercial terms (cost recovery) via annual audited reporting; apply enforcement posture decisively.
- Independent Distributors: Conduct monthly technical feedback sessions focusing on API stability and commercial cost structures (Decision 2).
- BEUC/Disability Groups: Hold mandated quarterly review sessions specifically on the 90-minute continuity threshold and accessibility integration progress (Decision 9/13).

## Regulatory and Compliance Requirements


### Permits and Licenses

- Authorization for management of centralized financial clearing/settlement mechanism float
- Legal basis for enforcing data sharing requirements on sovereign entities

### Compliance Standards

- Alignment with proposed EU Regulation on Digital Booking and Ticketing Services for Rail
- OSDM technical standard adherence (binding timeline at 18 months)
- Compliance with all EU passenger rights regulations (T+90 min threshold defines activation)
- Non-discriminatory commercial terms for API access

### Regulatory Bodies

- European Commission (DG MOVE)
- EU Agency for Railways
- National Competent Authorities (National Regulators)

### Compliance Actions

- Draft legal framework mandating OSDM API exposure (T+30 months deadline).
- Schedule external conformance testing audits based on phased standardization progress (provisional binding at 6 months).
- Implement compliance plan for accessibility standardization by incorporating PRM data schema validation into the core binding standard sign-off process.
- Obtain DG MOVE legal pre-approval for the 'Three Strikes' enforcement template.