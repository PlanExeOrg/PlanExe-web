**Proposed decision to deviate >10% from approved annual budget allocation.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review of strategic necessity/ROI; Weighted Majority Vote with DG MOVE tie-breaker.
Rationale: Exceeds the Project Director's financial decision rights (<€500k) and impacts strategic resource distribution from the overall €1.5B scope.
Negative Consequences: Budget overrun; potential need to delay critical capacity building or testing coordination expenditures.

**Inability of the Operational Management Group (OMG) to reach consensus on resource allocation shifts exceeding €500k or resolving an operational blockade.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Urgent call; review necessity and strategic impact; majority vote overseen by the PSC Chair.
Rationale: The OMG consensus deadlock requires intervention at the next governance level to prevent a failure in hitting critical path technical deadlines (e.g., T+5 latency testing or standards adoption pace).
Negative Consequences: Project timeline slippage; failure to meet mandatory binding standard deadlines (18 or 30 months).

**Technical Assurance & Standards Group (TASG) deadlock requiring amendment to OSDM specification that creates significant commercial detriment or contradicts non-discrimination principles.**
Escalation Level: Operational Management Group (OMG) for policy resolution, then PSC if policy required.
Approval Process: OMG resolves policy conflicts via Consensus; if policy conflict is irreconcilable or impacts financial targets (e.g., justifying cost-recovery royalties), it escalates to PSC for strategic mandate.
Rationale: Technical disagreements impact established commercial terms (Decision 2) or the finality of standards (Decision 4). This requires policy-level judgment on trade-offs between technical perfection and commercial viability.
Negative Consequences: Protracted technical uncertainty; potential conflict between technical agility and carrier cooperation.

**Compliance and Liability Assurance Board (CLAB) determination leading to recommendation for sanctioning SNCF, DB, or ÖBB regarding repeated failure to comply with API exposure deadlines ('Three Strikes' threshold met).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB recommendation, assesses political risk (Risk 1/Issue 3 mitigation), and votes on formal sanction (suspension of clearing access).
Rationale: Sanctioning a primary participant carries severe political and operational risk. It exceeds CLAB's mandate to recommend and requires the PSC for formal executive authorization.
Negative Consequences: Potential legal challenge/political pushback from that Member State; temporary fracturing of the network if service suspension is enacted.

**Determination by CLAB that clearing mechanism collateral structure (float) has dropped below 150% of peak daily obligation, posing a liquidity risk to financial settlement.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Executive session for immediate review of solvency risk; PSC must decide on accessing the 'Emergency Float Reserve' or mandating increased bank guarantees.
Rationale: Direct threat to the financial backbone of the project (single-payment settlement) requiring immediate executive financial stewardship that surpasses the operational risk monitoring of the OMG.
Negative Consequences: Settlement failure (T+3 breach); high risk of triggering public funding top-up from the coordination budget (Risk 3).

**Major policy interpretation dispute regarding scope of 'gross distributor negligence' in cross-border failure attribution (Decision 3).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB's assessment against the PSC's established liability cap, providing a binding interpretation that settles the dispute for all future claims.
Rationale: This interpretation defines the burden of financial risk in complex failure scenarios, directly impacting carrier financial risk models and the viability of the backstop. It requires strategic policy setting.
Negative Consequences: Inconsistent handling of passenger rights claims; potential for one stakeholder group (e.g., distributors) to shift undue financial burden post-implementation.