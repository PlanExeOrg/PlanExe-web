
## Question 1 - What is the defined initial capitalization requirement (float) for the inter-carrier clearing and settlement mechanism, and what is the acceptable duration for settlement reconciliation delays under the transactional fee model?

**Assumptions:** Assumption: Based on the transaction volume estimates for the busiest corridors, the initial float required for the clearing mechanism will be provisionally set at €200 million. Settlement reconciliation delays are assumed to be manageable if resolved within T+3 (Transaction plus three days) for 99% of transactions.

**Assessments:** Title: Financial Mechanism Viability Assessment
Description: Evaluation of the initial funding and liquidity profile of the clearing mechanism chosen under the Builder scenario.
Details: Relying on a transactional fee model (Decision 5) necessitates careful monitoring of the initial €200M float. Risk: If transaction velocity is too low initially, the float could deplete, requiring public top-up (Risk 3). Opportunity: A T+3 standard aligns with standard high-value B2B bank clearing, improving carrier confidence over slower national processes. Mitigation requires setting a weekly monitoring trigger on the reserve fund balance.

## Question 2 - Considering the phased standardization approach (provisional binding at 6 months), what is the mandated grace period for national operators to upgrade their legacy reduction card and accessibility booking systems before full harmonized service is required?

**Assumptions:** Assumption: The 'phased standardization' (Decision 4) dictates that core ticketing APIs must be stable by 18 months (final binding), but complex ancillary services like accessibility (Feature Set B) and reduction cards (Feature Set C) are allocated an additional 12 months grace period, resulting in a 30-month mandate for their full harmonization.

**Assessments:** Title: Harmonization Implementation Timeline Assessment
Description: Analysis of the timeline pressure on complex, secondary feature implementation relative to core data exposure.
Details: Deferring full harmonization of accessibility and reduction cards until month 30 (Risk 4 mitigation) provides necessary breathing room for national operators. Benefit: This prevents immediate technical overload that could jeopardize the stability of the core OSDM data layer mandated by month 18. Risk: Delaying accessibility features beyond the initial corridor rollout risks early regulatory challenges regarding equity concerns.

## Question 3 - What precise mechanism and metric will the EU Agency for Railways use to audit and certify compliance with the non-discriminatory commercial terms established for API data access, particularly concerning incumbent carrier IT cost recovery?

**Assumptions:** Assumption: Compliance will be verified annually through audited balance sheets submitted by operators, focusing on IT operational costs directly attributable to OSDM data maintenance. The standard cost-recovery royalty rate is assumed to be capped at 5% of the operating/maintenance expenditure required for the API endpoint.

**Assessments:** Title: Commercial Governance Effectiveness Assessment
Description: Evaluation of the regulatory oversight mechanism ensuring fair financial terms for data access (Decision 2).
Details: Capped, cost-recovery royalties (Decision 2) necessitate robust audit capability. Risk: Operators may inflate indirect IT costs to increase recoverable fees, requiring strong regulatory challenge capabilities. Opportunity: If audits confirm low, fair pricing, it significantly lowers the barrier to entry for independent distributors (Risk 7), supporting the 40% sales target.

## Question 4 - Which specific national operators are designated as primary participants in the first thirty-month compliance audit cycle for the 'Enforcement Posture' concerning the busiest cross-border corridors (Paris-Brussels-etc., Wien-Munich-etc.)?

**Assumptions:** Assumption: The primary participants for the initial 30-month audit cycle are mandated to be SNCF, Deutsche Bahn (DB), and ÖBB due to their central role in the two highest-volume initial corridors. Enforcement actions will be applied first to these entities.

**Assessments:** Title: Regulatory Compliance Risk Management
Description: Gauging the intent and immediacy of applying the enforcement posture (Decision 12) against key infrastructure providers.
Details: Focusing initial high-stakes enforcement (Risk 1) on SNCF, DB, and ÖBB is pragmatic given their corridor centrality. Benefit: Early compliance success here sets a strong operational precedent across the EU. Risk: If these major players resist strongly, enforcement actions could trigger significant political friction undermining coordination.

## Question 5 - How will the public funding component of the €1.5 billion budget be allocated to support capacity building for national operators to meet the OSDM technical integration standards, and what percentage is ring-fenced for the public reference distributor?

**Assumptions:** Assumption: 60% of the €1.5B fund (€900M) is allocated to capacity building (IT grants/testing support), and 10% (€150M) is reserved for the establishment and initial five-year running costs of the public reference distributor (Decision 11).

**Assessments:** Title: Budget Allocation and Sustainable Operations Assessment
Description: Analyzing the budgetary support structure for IT upgrades and the long-term running of the reference platform.
Details: Allocating 60% for grants directly mitigates the resource strain on operators (Risk 4). However, reserving 10% for the reference distributor (Decision 11) creates a fixed cost base that must be managed, potentially conflicting with the goal of minimal long-term drain if usage fees lag.

## Question 6 - What is the operational plan for integrating real-time disruption data between operators required for 'continuity-of-journey rights,' and does this require all carriers to adopt a shared real-time latency benchmark (e.g., maximum 5-minute delay in reporting)?

**Assumptions:** Assumption: A mandatory real-time latency benchmark of T+5 minutes (5 minutes from event occurrence to API availability) will be established as part of the provisional binding standards at month 6 (Decision 4). This is essential for automatically triggering the passenger rights backstop (Decision 13).

**Assessments:** Title: Operational Data Interoperability Assessment
Description: Evaluation of the technical requirements for real-time system interaction needed to support integrated journey protection.
Details: Mandating a T+5 latency benchmark forces high operational standards (Risk 2 mitigation). Benefit: Clear thresholds (Decision 13) enable automated backstop activation, directly supporting the reduction in distributor complaints. Risk: Carriers with older infrastructure may struggle to meet T+5, increasing enforcement pressure (Decision 12).

## Question 7 - Given the need for physical coordination and testing in Brussels and corridor regions, what is the staffing plan for the central governance body (e.g., number of dedicated full-time equivalents) required to manage standards, testing, and stakeholder engagement for the first two years?

**Assumptions:** Assumption: The initial governance body will require 35 FTEs dedicated to standards management (10), conformance testing coordination (15, focused heavily on the physical locations identified), and stakeholder relations (10), spread across the Brussels HQ and corridor liaison offices.

**Assessments:** Title: Resource Deployment and Physical Coordination Assessment
Description: Analyzing the personnel needs required to execute governance and physical testing across multiple EU locations (Physical Locations Rationale).
Details: Deploying 15 FTEs to testing coordination across the identified physical locations (Location 2 & 3) is critical for resolving integration technical risks (Risk 2). However, staffing 35 FTEs requires immediate allocation of operational budget, which must be factored into the €1.5B program management slice, distinct from IT grants.

## Question 8 - How will the governance structure ensure that the necessary adjustments to the liability model (Decision 3) or data access terms (Decision 2) can be rapidly processed if initial corridor tests reveal systemic issues that exceed expected risk tolerances?

**Assumptions:** Assumption: The Governance Structure (Decision 10) will grant an emergency review mandate to the Technical Steering Committee for the first twelve months post-launch, allowing immediate, non-unanimous amendments (requiring only 65% consensus) to be enacted as 'provisional operational directives' before final ratification.

**Assessments:** Title: Governance Agility and Risk Tolerance Assessment
Description: Assessing the procedural flexibility to adapt fundamental rules once implementation starts revealing systemic risk.
Details: Granting emergency override power (Decision 10) mitigates Risk 5 (slow amendments) and allows rapid adaptation if the tiered liability model (Decision 3) proves inadequate or if data access terms (Decision 2) cause distributor pushback. Benefit: This balances stability with necessary agility for a novel, high-pressure program.