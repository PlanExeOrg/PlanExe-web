This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to major EU institutions (DG MOVE, EU Agency for Railways)
- Facilities for high-level governance meetings and standards workshops
- Access to central European transport hubs for corridor testing coordination

## Location 1
Belgium

Brussels

European Quarter/Near EU Institutions

**Rationale**: As the host of the European Commission (DG MOVE) and central to the proposed initial launch corridor (Paris–Brussels–Amsterdam–Köln), Brussels is the ideal administrative and coordination hub for standards-setting and governance body meetings.

## Location 2
France/Germany/Benelux

Paris–Brussels–Amsterdam–Köln Corridor Region

Testing facilities within central cluster areas (e.g., Lille, Frankfurt, or Rotterdam)

**Rationale**: As the very first corridor slated for roll-out, having a physical presence or testing command center proximal to operators and infrastructure in this region is critical for initial conformance testing and resolving early technical issues.

## Location 3
Austria/Germany/Switzerland

Wien–München–Zürich Corridor Region

Munich or Vienna (as central connection points)

**Rationale**: To facilitate the parallel coordination and testing required for the second primary corridor, a central operating base in the core of this region (e.g., Munich) allows engagement with ÖBB, DB, and Swiss partners without diverting all focus from the main Brussels hub.

## Location Summary
Since this is a multi-national regulatory and technical implementation program, physical locations must serve administrative coordination and initial corridor testing. Brussels is essential for stakeholder engagement with EU bodies. Additional locations are suggested near the two highest-priority initial corridors (Paris-Amsterdam-Cologne and Vienna-Munich-Zurich) to facilitate on-the-ground testing and localized operational alignment required for the phased rollout.