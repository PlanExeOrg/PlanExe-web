Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a large-scale regulatory, technical integration, and commercial coordination project among established transport entities, requiring software development, API standardization, and contractual agreements; it does not require violating any known laws of physics or relying on non-physical causal mechanisms for its success. The plan involves creating interoperable software systems and defining commercial/governance processes.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of regulatory enforcement, complex IT standardization (OSDM), and new financial clearing/liability models, demanding unprecedented compliance from established national operators without sufficient validation precedent for the *entire system* in the EU rail domain. This lack of scaled proof justifies the high rating.

**Mitigation**: Technology Lead/Governance Architect: Launch concurrent validation tracks for (1) T+5 latency adherence with PRM data load and (2) Legal vetting outcome of tiered liability vs. collective pool by within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly names strategic concepts ('Pacing Standard Adoption', 'Data Exposure', 'Passenger Rights Liability') but fails to define their business-level mechanism-of-action (inputs→process→customer value), nor assign owners or measurable outcomes *except* for citing the final 40% adoption goal. For instance, Decision 1 details the complexity but lacks a single owner.

**Mitigation**: EU Regulatory & Governance Architect: Produce 5 one-pagers detailing mechanism-of-action, owner, KPIs, and decision hooks for each of the five primary decisions within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly relies on aggressive enforcement ('Three Strikes') against established incumbents (SNCF, DB) while assuming their behavioral compliance regarding liability (Decision 3) and cost auditing (Decision 2) is manageable. Premortems show these regulatory/cost assumptions are the primary critical failure modes (FM1, FM3), indicating second-order political and compliance risks are severely underestimated.

**Mitigation**: EU Regulatory & Governance Architect: Initiate preemptive high-level lobbying engagement to secure DG MOVE commitment regarding the 'Three Strikes' policy insulation from Council override within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project relies on strict timelines for technical standards (18 months binding), but the expert review flagged the concurrency of ancillary harmonization (Accessibility/Loyalty—30-month grace assumed) as conflicting with core binding deadlines, indicating aggressive scheduling without sufficient predecessor mapping.

**Mitigation**: Interoperability Standards Lead: Mandate that the PRM data schema validation must be formally signed off before the core OSDM standard achieves final binding status at month 18.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's reliance on a transactional fee model for capitalization (Decision 5) is directly flagged as a weakness (Risk 3) sensitive to low initial velocity. The plan commits to a €200M float financed via collateral, which the expert review flagged as requiring immediate contingency ($300M Emergency Float Reserve) due to settlement delay assumptions (T+3). The status of this critical contingency funding is not detailed.

**Mitigation**: Program Risk Manager/Financial Clearing Specialist: Formally document the commitment and funding source for the $300M Emergency Float Reserve within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan selects the 'Builder' scenario, which uses a 'transactional fee model' for capitalization (Decision 5, Choice 2). This relies on future transaction velocity, which is an untested assumption that introduces financial risk if velocity is low, as noted in Risk 3, pending a full cost-benefit analysis.

**Mitigation**: Financial Clearing Specialist: Finalize and present the minimum required transaction velocity needed by Month 48 for self-sustainability by within 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Builder scenario relies exclusively on single numeric targets for projection, such as '40% of cross-border journeys sold as single through-tickets within five years' (Goal Statement). No sensitivity analysis or worst-case scenario is presented for this critical adoption metric, indicating optimism.

**Mitigation**: Digital Distributor Strategist/Program Risk Manager: Produce a best/base/worst-case scenario for the 40% adoption KPI, using the projected impact of the FM3/FM9 failure mode as the worst-case basis, within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction notes that core components may lack specs, interface contracts, acceptance tests, integration plans, and NFRs. The inputs confirm the dependence on novel standards (OSDM) and complex financial/data integrations (Clearing Mechanism, T+5 latency), but lack specific evidence (e.g., 'OSDM V1.0 Interface Contract v2.1') addressing these critical components.

**Mitigation**: Interoperability Standards Lead/Program Risk Manager: Deliver the complete OSDM V1.0 interface contract, integration map, and acceptance test suite for the core ticketing/disruption endpoints within 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Checklist Item 10 explicitly requires verifiable artifacts for critical claims. Critical claims exist regarding mandatory legal enforcement ('Three Strikes' Policy, Decision 12) and financial backing (Clearing Mechanism capitalization, Decision 5). No verifiable artifact (link/ID) is currently cited for the 'legally vetted 'Three Strikes' suspension charter' (Premortem A4) or the 'formal commitment letter' for the Emergency Float Reserve (Review Q3-2's required action).

**Mitigation**: EU Regulatory & Governance Architect: Secure formal DG MOVE written pre-approval for the 'Three Strikes' charter within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains several major milestones and key decisions (e.g., Passenger Rights Backstop, Pacing Binding Standard) that are abstractly defined, lacking specific, quantifiable KPI targets in their descriptions.

**Mitigation**: EU Regulatory & Governance Architect: Define SMART acceptance criteria for Decision 1, including KPI for backstop claim processing time (e.g., 90% processed within T+7 days) within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly details several features whose costs/benefits are insufficiently justified relative to core goals: 'Offer the first two years of API access entirely free of charge' shifts cost to the public budget, conflicting with sustainability goals, as stated in Decision 2.

**Mitigation**: Digital Distributor & Market Adoption Strategist: Produce a one-page benefit case for free API access justifying inclusion vs. cost-recovery royalty model within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the mission-critical role is the EU Regulatory & Governance Architect, whose failure causes alignment breakdown, stalled standards, and legally indefensible enforcement. This role requires deep, rare expertise spanning EU transport law, digital policy, and multisovereign governance.

**Mitigation**: EU Regulatory & Governance Architect: Commissions an external market analysis validating the availability of candidates matching Dr. Vancini's profile within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the legality of enforcing data sharing and financial mandates on sovereign entities is unclear, and the pre-approval of the 'Three Strikes' enforcement template by DG MOVE is a critical unmapped approval artifact.

**Mitigation**: EU Regulatory & Governance Architect: Secure formal DG MOVE written pre-approval for the 'Three Strikes' charter within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any explicit documentation regarding ongoing operational costs versus projected revenue/funding post-completion, particularly concerning the long-term funding for the Public Reference Distributor (Decision 11, 10% fixed budget commitment) and ongoing maintenance of the OSDM standards.

**Mitigation**: EU Regulatory & Governance Architect: Define the 5-year operational funding sunset clause for the Public Reference Distributor based on usage fee targets within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions hard constraints (e.g., Regulation compliance, OSDM standards) but lacks explicit, written confirmation or risk assessment for site-specific physical constraints like zoning or local occupancy limits relevant to the proposed testing facilities (Location 2 and 3).

**Mitigation**: Cross-Corridor Conformance Testing Coordinator: Initiate contact with local authorities near testing sites (Location 2/3) to confirm basic operational permits and zoning overlays within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan addresses external resilience by choosing a liability model (Strict Tiered Liability, Decision 3/Choice 1) that the Intermodal Architect argues contradicts the 'realistic' Builder scenario by imposing high unilateral risk on carriers, which is a single point of failure for operator buy-in. No tested failover structure (like the recommended Collective Insurance Pool) is selected for this critical financial risk.

**Mitigation**: EU Regulatory & Governance Architect: Immediately mandate the pivot for Decision 3 to Strategic Choice 2 (Mandatory Collective Insurance Pool) and secure legal sign-off within 45 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Financial Department (incentive: budget adherence) conflicts with R&D/Technical (implicit incentive: robust standards adoption), visible in Decision 2's choice to offer two years of free API access, shifting cost to the public budget.

**Mitigation**: EU Regulatory & Governance Architect: Finalize an OKR linking R&D's API stability certification timeline to the Finance Department's measurable reduction in public subsidy drawdowns within 90 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit definition of KPIs, review cadence, owners, and change control thresholds as required. Although the 'SWOT Recommendations' suggest future KPIs, the core plan lacks documented feedback loops for ongoing monitoring and adjustment.

**Mitigation**: EU Regulatory & Governance Architect: Establish a monthly Governance Review Board charter defining KPIs, owners, and change thresholds (e.g., 10% KPI deviation triggers light-weight review) within 45 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits strong coupling between the technical stability (T+5 latency via Decision 14/Assumptions A3, FM2/FM5), the liability regime (Strict Tiered Liability, Decision 3, FM1/FM4/FM7), and the distributor adoption rate (Decision 2/A1, FM3/FM9). The chosen 'Builder' scenario is highly vulnerable to deadlock if operators contest the liability structure, which will inevitably strain technical compliance efforts.

**Mitigation**: EU Regulatory & Governance Architect: Immediately mandate the pivot for Decision 3 to Collective Insurance and secure legal sign-off within 45 days to de-risk litigation.