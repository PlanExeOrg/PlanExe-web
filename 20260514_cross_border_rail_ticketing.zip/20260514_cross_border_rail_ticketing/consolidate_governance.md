# Governance Audit


## Audit - Corruption Risks

- Kickbacks or undue influence from incumbent national operators seeking preferential terms in the standardized, capped royalty structure for API data access (Decision 2), potentially leading to inflated cost-recovery claims.
- Nepotism or conflicts of interest among personnel coordinating capacity building grants (€900M allocated), favoring specific national operator IT modernisation projects in exchange for personal benefits or favors.
- Bribery of regulatory staff or staff in the EU Agency for Railways to receive a favorable ruling during the initial alignment of the Passenger Rights Backstop (Decision 1) or to overlook non-compliance thresholds during the mandated conformance testing phases.
- Misuse of information regarding the financial health or upcoming audit findings of specific national carriers (SNCF, DB, ÖBB) by internal personnel to gain leverage in commercial negotiations or regulatory discussions.
- Trading favors with national regulators to secure leniency on the 'three strikes' enforcement posture (Decision 12) or to delay the final binding adoption of sensitive standards like reduction card harmonization (Decision 8).

## Audit - Misallocation Risks

- Misallocation of the €1.5 billion coordination budget: Directly diverting funds intended for the clearing mechanism float or public reference distributor operation into unauthorized capacity building initiatives based on non-objective stakeholder relations rather than technical need.
- Inflating IT operational expenditure reports by national carriers specifically to maximize cost-recovery royalties for data provision, misusing the regulator-overseen cap (Assumption Q3).
- Inefficient utilization of the 35 dedicated FTEs, with excessive staffing allocated to stakeholder relations instead of core standards management or coordination of physical conformance testing at site locations (Assumption Q7).
- Double spending by national operators claiming public capacity building grants (€900M pool) for IT modernization work that is simultaneously being paid for or guaranteed through other existing national or EU infrastructure investments.
- Misreporting progress on functional compliance for ancillary services (accessibility/PRM reservation data—Decision 9) to meet internal deadlines, thus drawing down capacity funding prematurely while actual integration capability remains unstable.

## Audit - Procedures

- Quarterly detailed audit of the Inter-Carrier Clearing Mechanism float balance, checking collateral provision against the transactional fee model (Decision 5) and triggering an immediate external review if the rolling reserve falls below 150% of the calculated peak daily obligation.
- Annual external audit review of cost-recovery royalty claims submitted by the primary participants (SNCF, DB, ÖBB) to verify IT operational expenditures attributed to OSDM data maintenance against specified cost standards (Assumption Q3).
- Mandatory forensic examination of any operator triggering the 'three strikes' enforcement policy (Decision 12) to confirm that the underlying API failures necessitating suspension were technical and not due to fabricated data or deliberate non-compliance.
- Post-implementation (Month 30) audit of the Passenger Rights Backstop pool to verify the activation criteria (90-minute threshold/inter-segment failure) correlated accurately with actual compensation payouts, assessing 'gross distributor negligence' determinations (Decision 3).
- Periodic (Bi-annual during the first 18 months) audit by the EU Agency for Railways focusing specifically on the integration status of PRM reservation data schemas (Decision 9) to ensure they meet provisional binding status requirements at month 6, regardless of the later service rollout.

## Audit - Transparency Measures

- Publication of monthly utilization and performance dashboards for the shared real-time data layer (OSDM APIs), showing latency benchmarks (T+5 minutes) broken down by operator and route corridor.
- Public disclosure of the standardized, regulator-approved royalty fee structure utilized for API access, immediately following the finalization of Decision 2, ensuring distributors can verify commercial fairness.
- Mandatory publication of minutes from the Technical Steering Committee's emergency review sessions (Decision 10), redacted only for essential security details, showing which provisional operational directives were enacted under the 65% consensus rule.
- Establishment of a secure, independently managed whistleblower channel specifically for reporting suspicious cost-inflation claims related to API cost-recovery reporting or misuse of capacity building grants.
- Public reporting of the capital reserve drawdown schedule and replenishment triggers for the clearing mechanism float, traceable against the initially provisioned €200 million, accessible via the Public Reference Distributor platform (Decision 11).

# Internal Governance Bodies

### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Essential for strategic oversight, high-level decision-making (especially concerning financial thresholds and regulatory alignment), and resolving major risks, ensuring the project remains aligned with the EU Regulation mandate. Its existence clearly separates strategic control from day-to-day execution.

**Responsibilities:**

- Approve annual program strategy, budget allocations deviating more than 10% from the baseline plan, and major scope changes.
- Receive and approve reports on strategic risk status (especially regulatory compliance and enforcement posture).
- Formally sanction operator inclusion/exclusion from the clearing/settlement mechanism.
- Resolve formal disputes escalated from the Operational Management Group regarding policy interpretation or inter-carrier commercial terms.

**Initial Setup Actions:**

- Finalize and approve the Terms of Reference (ToR), defining explicit strategic decision thresholds.
- Appoint the Executive Sponsor (Chair) and establish the conflict resolution mechanism.
- Review and formally approve the initial Capitalization Plan for the Clearing Mechanism.

**Membership:**

- High-level representatives from DG MOVE (Chair)
- Director of the EU Agency for Railways
- Chief Legal Officer (Project Sponsor)
- Designated representative from National Regulators' Forum (Non-voting)
- Chair of the Technical Advisory Group (Invited)

**Decision Rights:** Decisions with financial impact exceeding €5 million, significant changes to the binding timeline (Decision 4), or approval of operator exclusionary actions (Decision 12). Sets the maximum liability cap for the Passenger Rights Backstop (Decision 1).

**Decision Mechanism:** Weighted Majority Vote. DG MOVE representative holds the deciding vote in case of a tie, mandated by the regulatory underpinning. Conflicts between DG MOVE and Member State representatives escalate immediately to the relevant EU Director-General.

**Meeting Cadence:** Quarterly, or on urgent call for critical milestone approvals (e.g., standards ratification milestones).

**Typical Agenda Items:**

- Review of 5-Year Target Progress (40% Through-Ticket Metric).
- Strategic Risk Review (Focus on Regulatory Compliance/Enforcement Viability).
- Approval of major releases/conformance testing outcomes.
- Review of projected utilization vs. clearing mechanism float stability (Risk 3).

**Escalation Path:** Unresolved issues or disputes that cannot reconcile within the PSC due to stakeholder impasse are escalated directly to the relevant DG MOVE Director-General for executive political resolution.
### 2. Operational Management Group (OMG)

**Rationale for Inclusion:** This body is required to manage the day-to-day execution, compliance monitoring, dependency tracking, and resource allocation necessary to deliver the technical integration and operational benchmarks (T+5 latency, 30-month API deadline). It ensures coherence between the standards body and the testing coordination.

**Responsibilities:**

- Manage the 35 dedicated FTEs, coordinating the standards and testing streams.
- Monitor and report on operator performance against API exposure deadlines (Decision 12) and latency benchmarks (T+5).
- Oversee the validation roadmap for the Public Reference Distributor (Decision 11).
- Manage weekly budget burn rate for operational expenditure.
- Coordinate capacity building grant distribution reviews with the relevant technical/auditing bodies.

**Initial Setup Actions:**

- Establish the centralized reporting dashboard linking technical milestones to the timeline (Decision 4/14).
- Finalize the Statement of Work (SOW) for the external auditing firm managing royalty verification (Assumption Q3).
- Develop and distribute weekly progress templates to all primary technical stakeholders (SNCF, DB, etc.).

**Membership:**

- Project Director/Program Manager (Chair)
- Head of Technical Integration (Responsible for OSDM/API)
- Head of Financial Operations (Clearing/Settlement oversight)
- Compliance & Audit Lead
- Stakeholder Relations Manager

**Decision Rights:** Decisions concerning resource shifts within the approved operational budget (<€500k); resolution of day-to-day technical blockers below the threshold requiring PSC intervention; managing the queue for conformance testing slots.

**Decision Mechanism:** Consensus required among all core functional leads. Conflicts are resolved by the Project Director; if irreconcilable within 48 hours, they are escalated to the PSC as an 'Operational Blockade.'

**Meeting Cadence:** Weekly (Operational Stand-up); Bi-weekly (Detailed Review).

**Typical Agenda Items:**

- Review of Critical Path Dependencies (Standards vs. Testing).
- Operator Compliance Report (API Uptime, Latency Checks).
- Clearing Mechanism Liquidity Status (Tracking against €200M float).
- Capacity Grant Utilization Review.

**Escalation Path:** Issues requiring financial approval >€500k, policy reinterpretation, or failure to secure operator cooperation that risks a key deadline (e.g., failure to adhere to the 'three strikes' policy) are escalated to the Project Steering Committee (PSC).
### 3. Technical Assurance & Standards Group (TASG)

**Rationale for Inclusion:** Given the absolute reliance on the novel, complex OSDM standard for real-time data, booking, and clearing, a dedicated body is needed to manage technical development agility, conformance testing, and mandatory governance evolution (Decision 10) without bureaucratic hindrance.

**Responsibilities:**

- Manage the evolution and formal ratification of OSDM V1.0 standards (Decision 4/10).
- Oversee the lifecycle of API functional compliance testing, ensuring T+5 latency is met.
- Provide technical advice to the PSC on all integration risks (Risk 2).
- Govern the immediate operational directives under the emergency review mandate (Assumption Q8).
- Ensure binding conformance testing for Accessibility Reservations (Decision 9) precedes core v1.0 finalization.

**Initial Setup Actions:**

- Establish the technical voting baseline for OSDM amendment consensus (65% agility threshold activated).
- Define the standardized, detailed test cases for T+5 latency validation.
- Appoint an independent Standards Review Board Chair.

**Membership:**

- Head of Technical Integration (Chair)
- Lead Architect (OSDM Focus)
- External Independent Technical Consultants (Ensuring Vendor Neutrality)
- Representative from the EU Agency for Railways (Testing Oversight)
- Two nominated Technical Leads from major Independent Distributors (for API consumer perspective)

**Decision Rights:** Binding approval on technical specifications for all OSDM V1.0 components; issuing of 'Provisional Operational Directives' under the 12-month emergency review mandate; setting technical criteria for operator certification.

**Decision Mechanism:** Dual Approval Threshold: 75% of internal members AND 65% among invited Member State technical representatives (where applicable). Emergency directives (first 12 months) require 65% consensus among core members only.

**Meeting Cadence:** Bi-weekly (during development phases); Monthly (post-ratification stabilization).

**Typical Agenda Items:**

- Review of Amendments/Change Requests to OSDM Specification.
- Conformance Testing Results Analysis (Focus on T+5 latency performance per operator).
- Accessibility Reservation Data Schema Validation Status (Decision 9 check-in).
- Technical Mitigation Plan Review for known integration bugs.

**Escalation Path:** Technical disagreements that threaten the 18-month binding deadline, or specifications that cause unworkable commercial terms (potential conflict with Decision 2), are immediately escalated to the Operational Management Group (OMG) for policy resolution or to the PSC if financial thresholds are impacted.
### 4. Compliance and Liability Assurance Board (CLAB)

**Rationale for Inclusion:** Due to the high regulatory burden, the critical nature of passenger rights (Decision 1/13), and the complexity of non-discriminatory commercial terms (Decision 2), a dedicated assurance body is necessary to enforce accountability, manage compliance audits, and govern the crucial financial liability framework independently of operations.

**Responsibilities:**

- Oversee compliance with the Passenger Rights Backstop activation thresholds (Decision 13).
- Conduct/commission compliance audits against the 'three strikes' enforcement posture (Decision 12), particularly on SNCF, DB, ÖBB.
- Verify national carrier adherence to cost-recovery royalty caps (Assumption Q3) via annual report review.
- Ensure non-discriminatory access to APIs and settlement mechanism liquidity.
- Provide independent assessment on determinations of 'gross distributor negligence' (Decision 3).

**Initial Setup Actions:**

- Formalize the charter for auditing IT cost allocations from national carriers.
- Establish the protocol for triggering the forensic audit upon 'three strikes' enforcement action.
- Develop the compliance reporting matrix linking Decision 2 (Commercial Terms) to Decision 5 (Clearing Mechanism).

**Membership:**

- Chief Compliance Officer (Chair)
- Internal Audit Lead
- External Regulatory Counsel (Independent)
- Risk Manager (Responsible for Clearing Float Stress Testing)
- Representative from National Regulatory Bodies (Non-voting, for local context)

**Decision Rights:** Binding determination on whether an operator has met compliance thresholds for continued participation in the clearing mechanism; recommendations for applying enforcement actions (subject to PSC final approval). Sole authority on validating compensation payout correlation data post-audit.

**Decision Mechanism:** Consensus among the Chair and Independent Counsel. The Risk Manager can raise a procedural objection requiring PSC review if audit findings directly threaten clearing mechanism solvency.

**Meeting Cadence:** Monthly, with immediate emergency session called upon the triggering of a 'three strikes' policy against a primary participant.

**Typical Agenda Items:**

- Review of Audit Findings on Cost Recovery Reporting.
- Assessment of Passenger Rights Backstop Utilization (Correlation with T+90 threshold).
- Status of Enforcement Actions against Primary Participants (SNCF, DB, ÖBB).
- Reviewing impact of TASG decisions on regulatory compliance.

**Escalation Path:** Any determination leading to suspension of clearing access, or any finding indicating potential misuse of the public budget or sustained non-compliance by a primary carrier, is immediately escalated to the Project Steering Committee (PSC) for sanctioning.

# Governance Implementation Plan

### 1. Project Sponsor (DG MOVE/Executive Lead) formally authorizes the establishment of all defined governance bodies based on agreed strategic decisions.

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Charter documents for PSC, OMG, TASG, CLAB circulation

**Dependencies:**

- Strategic Path (Builder Scenario) Confirmed
- Governance Body Definitions Finalized

### 2. Project Manager (via assumed interim coordination role) drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating PSC's specific decision thresholds and conflict resolution mechanisms.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Project Sponsor formally appoints the Executive Sponsor (Chair of PSC) and proposes the full PSC membership list for circular approval by key stakeholders (DG MOVE, EU Agency for Railways, Regulators Forum).

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PSC Chair Appointment Confirmation
- Nominated PSC Member List

**Dependencies:**

- Draft PSC ToR v0.1

### 4. PSC membership is formally confirmed, and the PSC Chair initiates the charter review/approval process.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Approved PSC ToR
- PSC Kick-off Meeting scheduled

**Dependencies:**

- PSC Membership Confirmed

### 5. Hold the inaugural meeting of the Project Steering Committee (PSC). Primary agenda item: Formal approval of the final structure and appointments for the subordinate bodies (OMG, TASG, CLAB).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC Meeting Minutes
- Endorsement of OMG, TASG, CLAB Charters and Initial Appointments

**Dependencies:**

- Final Approved PSC ToR

### 6. Project Manager proceeds to draft ToRs and finalize nominations for the Operational Management Group (OMG), Technical Assurance & Standards Group (TASG), and Compliance and Liability Assurance Board (CLAB), based on PSC endorsement.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- Draft OMG ToR/Membership List
- Draft TASG ToR/Membership List
- Draft CLAB ToR/Membership List

**Dependencies:**

- Endorsement of OMG, TASG, CLAB Charters

### 7. Confirm nomination of Chairs for OMG, TASG, and CLAB. These Chairs, advised by the Project Manager, secure final functional membership confirmations required for their groups to operate.

**Responsible Body/Role:** PSC Chair (via Project Manager)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Chairs for OMG, TASG, CLAB
- Final OMG, TASG, CLAB Membership Roster

**Dependencies:**

- Draft OMG/TASG/CLAB ToRs

### 8. Hold the inaugural meetings for the OMG, TASG, and CLAB. Key initial tasks: internal ratification of their respective ToRs and assigning immediate setup actions (e.g., dashboard setup for OMG, testing case definition for TASG, audit protocol drafting for CLAB).

**Responsible Body/Role:** Chairs of OMG, TASG, CLAB

**Suggested Timeframe:** Project Week 7-8

**Key Outputs/Deliverables:**

- Ratified ToRs for OMG, TASG, CLAB
- Initial Action Plan for each group (e.g., Draft SOW for OMG audit firm, TASG Test Cases)

**Dependencies:**

- Confirmed Chairs and Final Membership Roster

### 9. OMG initiates Project Reporting Framework setup: Establish centralized dashboard linking to timelines (Decision 4/14) and schedule initial weekly operational stand-ups.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Operational Reporting Dashboard v1.0 operational
- First OMG Weekly Stand-up Minutes

**Dependencies:**

- Ratified OMG ToR

### 10. TASG defines the standardized, detailed test cases required for OSDM compliance and the T+5 latency validation benchmark (Assumption Q6). This feeds directly into capacity grant planning.

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Finalized OSDM V1.0 Test Case Matrix
- T+5 Latency Validation Protocol

**Dependencies:**

- Ratified TASG ToR
- Agreement on Provisional Binding Status Timeline (M+6)

### 11. CLAB finalizes the protocol for auditing national carrier IT cost allocations (to enforce Capped Royalty, Decision 2 / Assumption Q3) and establishes the compliance reporting matrix linking commercial terms to clearing mechanism stability.

**Responsible Body/Role:** Compliance and Liability Assurance Board (CLAB)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Signed Charter for External Auditing Firm (SOW)
- Compliance Audit Framework v1.0

**Dependencies:**

- Ratified CLAB ToR
- PSC Approval of Initial Budget Allocation (for external audit costs)

### 12. OMG issues initial capacity building grants/technical assistance packages, prioritizing operators identified by CLAB for early audit focus (SNCF, DB, ÖBB) to accelerate OSDM integration.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Disbursement Record for Initial Capacity Building Grants (€900M fund deployment commences)
- Compliance Roadmap signed by SNCF, DB, ÖBB

**Dependencies:**

- Finalized OSDM V1.0 Test Case Matrix (TASG)
- Operator Compliance Roadmap (CLAB)

### 13. TASG begins work on harmonizing PRM reservation schema (Decision 9), ensuring the data schema validation is locked down before the provisional binding standard deadline (M+6).

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Month 2 (Week 9 Ongoing)

**Key Outputs/Deliverables:**

- Draft PRM Data Schema integrated into OSDM Specification Branch

**Dependencies:**

- T+5 Latency Validation Protocol
- Governance mandate to prioritize PRM schema conformance over ancillary grace period

### 14. PSC reviews the governance setup completeness, confirms readiness for standards ratification process, and formally signs off on the financial stabilization strategy for the Clearing Mechanism Float (€200M collateral structure).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Governance Structure Final Stability Report
- Clearing Mechanism Capitalization Approval (Decision 5)

**Dependencies:**

- OMG budget burn aligned with plan
- CLAB Compliance Framework established

# Decision Escalation Matrix

**Proposed decision to deviate >10% from approved annual budget allocation.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review of strategic necessity/ROI; Weighted Majority Vote with DG MOVE tie-breaker.
Rationale: Exceeds the Project Director's financial decision rights (<€500k) and impacts strategic resource distribution from the overall €1.5B scope.
Negative Consequences: Budget overrun; potential need to delay critical capacity building or testing coordination expenditures.

**Inability of the Operational Management Group (OMG) to reach consensus on resource allocation shifts exceeding €500k or resolving an operational blockade.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Urgent call; review necessity and strategic impact; majority vote overseen by the PSC Chair.
Rationale: The OMG consensus deadlock requires intervention at the next governance level to prevent a failure in hitting critical path technical deadlines (e.g., T+5 latency testing or standards adoption pace).
Negative Consequences: Project timeline slippage; failure to meet mandatory binding standard deadlines (18 or 30 months).

**Technical Assurance & Standards Group (TASG) deadlock requiring amendment to OSDM specification that creates significant commercial detriment or contradicts non-discrimination principles.**
Escalation Level: Operational Management Group (OMG) for policy resolution, then PSC if policy required.
Approval Process: OMG resolves policy conflicts via Consensus; if policy conflict is irreconcilable or impacts financial targets (e.g., justifying cost-recovery royalties), it escalates to PSC for strategic mandate.
Rationale: Technical disagreements impact established commercial terms (Decision 2) or the finality of standards (Decision 4). This requires policy-level judgment on trade-offs between technical perfection and commercial viability.
Negative Consequences: Protracted technical uncertainty; potential conflict between technical agility and carrier cooperation.

**Compliance and Liability Assurance Board (CLAB) determination leading to recommendation for sanctioning SNCF, DB, or ÖBB regarding repeated failure to comply with API exposure deadlines ('Three Strikes' threshold met).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB recommendation, assesses political risk (Risk 1/Issue 3 mitigation), and votes on formal sanction (suspension of clearing access).
Rationale: Sanctioning a primary participant carries severe political and operational risk. It exceeds CLAB's mandate to recommend and requires the PSC for formal executive authorization.
Negative Consequences: Potential legal challenge/political pushback from that Member State; temporary fracturing of the network if service suspension is enacted.

**Determination by CLAB that clearing mechanism collateral structure (float) has dropped below 150% of peak daily obligation, posing a liquidity risk to financial settlement.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Executive session for immediate review of solvency risk; PSC must decide on accessing the 'Emergency Float Reserve' or mandating increased bank guarantees.
Rationale: Direct threat to the financial backbone of the project (single-payment settlement) requiring immediate executive financial stewardship that surpasses the operational risk monitoring of the OMG.
Negative Consequences: Settlement failure (T+3 breach); high risk of triggering public funding top-up from the coordination budget (Risk 3).

**Major policy interpretation dispute regarding scope of 'gross distributor negligence' in cross-border failure attribution (Decision 3).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB's assessment against the PSC's established liability cap, providing a binding interpretation that settles the dispute for all future claims.
Rationale: This interpretation defines the burden of financial risk in complex failure scenarios, directly impacting carrier financial risk models and the viability of the backstop. It requires strategic policy setting.
Negative Consequences: Inconsistent handling of passenger rights claims; potential for one stakeholder group (e.g., distributors) to shift undue financial burden post-implementation.

# Monitoring Progress

### 1. Tracking adherence to Phased Standardization Timeline (Binding vs. Provisional)
**Monitoring Tools/Platforms:**

  - TASG OSDM Specification Version Tracker
  - PSC Milestone Report

**Frequency:** Bi-weekly alignment checks; Formal review Monthly

**Responsible Role:** Technical Assurance & Standards Group (TASG)

**Adaptation Process:** If the provisional binding status (M+6) is at risk, TASG immediately recommends prioritizing PRM data schema finalization over other ancillary system integration updates. If final binding status (M+18) is at risk, the matter is escalated to the PSC for potential emergency directive approval via the OMG.

**Adaptation Trigger:** Delay in locking down specification drafts exceeding 2 calibration weeks relative to the M+6 (Provisional) or M+18 (Final Binding) mandates (Decision 4).

### 2. Real-Time API Performance and Latency Monitoring (Critical Technical Risk)
**Monitoring Tools/Platforms:**

  - OMG Centralized Reporting Dashboard
  - T+5 Latency Validation Protocol Logs

**Frequency:** Daily operational checks; Weekly OMG review

**Responsible Role:** Operational Management Group (OMG)

**Adaptation Process:** If an operator breaches the T+5 latency benchmark for two consecutive reporting cycles, OMG issues a formal 'Technical Alert' to the operator, assigns targeted technical assistance from the Capacity Building fund, and flags the operator's status in CLAB's compliance report.

**Adaptation Trigger:** Any primary participant (SNCF, DB, ÖBB) failing the T+5 latency benchmark for 7 consecutive days, indicating Risk 2 (Data Layer Instability).

### 3. Enforcement Posture Compliance Monitoring (Critical Regulatory Success Factor)
**Monitoring Tools/Platforms:**

  - CLAB Compliance Audit Report
  - Operator Service Suspension Register

**Frequency:** Monthly for primary operators; Quarterly for all others

**Responsible Role:** Compliance and Liability Assurance Board (CLAB)

**Adaptation Process:** If an operator meets the 'three strikes' threshold, CLAB compiles a suspension recommendation report, including suggested duration and political risk assessment, and immediately escalates it to the PSC for formal sanctioning according to the escalation matrix.

**Adaptation Trigger:** CLAB formally documents the third validated, un-remediated API failure event against a primary participant (Risk 1 mitigation fulfillment).

### 4. Clearing Mechanism Liquidity and Float Stress Testing (Critical Financial Risk)
**Monitoring Tools/Platforms:**

  - Financial Operations Daily Liquidity Report
  - Emergency Float Reserve Utilization Tracker

**Frequency:** Daily monitoring by Financial Operations; Weekly OMG Review

**Responsible Role:** Head of Financial Operations (via OMG)

**Adaptation Process:** If the rolling reserve fund balance drops below 150% of peak daily obligation, the OMG Chair initiates an immediate executive session with the PSC to secure access to the ring-fenced 'Emergency Float Reserve' (€300M contingency) or mandate increased bank guarantees from non-compliant carriers.

**Adaptation Trigger:** Collateral level drops below the pre-defined solvency threshold (Risk 3 mitigation trigger).

### 5. Commercial Terms Adherence (Cost Recovery Royalty Verification)
**Monitoring Tools/Platforms:**

  - External Auditing Firm Reports (Annual)
  - CLAB Royalty Verification Tracker

**Frequency:** Annual (Audit Cycle); Quarterly (Interim Check)

**Responsible Role:** CLAB (Oversight) / OMG (Coordination)

**Adaptation Process:** If the external audit reveals that carrier-reported IT operational costs used for calculating the 5% royalty cap are inflated, CLAB recommends specific adjustments to the PSC. The PSC can mandate the rejection of inflated costs, potentially leading to temporary withholding of clearing mechanism access until accurate accounting is provided.

**Adaptation Trigger:** Annual audit findings indicating royalties deviating more than 5% from expected transaction volume yields, suggesting cost inflation (Assumption Q3).

### 6. Passenger Rights Backstop Utilization Tracking (Service Level Success Factor)
**Monitoring Tools/Platforms:**

  - Backstop Utilization Ledger (Linked to T+90 threshold implementation)
  - Distributor Complaint Log (Target: -50% reduction)

**Frequency:** Monthly

**Responsible Role:** Compliance and Liability Assurance Board (CLAB)

**Adaptation Process:** If utilization of the backstop (claims paid out) is disproportionately high relative to expected delays (i.e., many successful claims are occurring below the 90-minute threshold in practice), CLAB advises the PSC to review the 'Continuity-of-Journey Failure Thresholds' (Decision 13) for necessary tightening, or investigate potential procedural manipulation.

**Adaptation Trigger:** Utilization spikes by >20% QoQ or if distributor complaints regarding resolution failure do not show a declining trend year-over-year.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All requested core components of the governance framework—Bodies (Stage 2), Implementation Plan (Stage 3), Escalation Matrix (Stage 4), and Monitoring Plan (Stage 5)—appear to be generated and substantially detailed.
2. Internal Consistency Check: The framework demonstrates strong consistency. The OMG monitors T+5 latency, which ties directly to TASG's defined protocol and the need for Decision 13 (Failure Thresholds). The CLAB enforces Decision 12 (Enforcement Posture) against the targeted primary participants identified in the assumptions (SNCF, DB, ÖBB). The PSC's role as the critical arbitrator in the Escalation Matrix is clearly defined across financial, policy, and enforcement domains.
3. Potential Gaps / Areas for Enhancement 1 (Role Clarity): The role and authority of the 'Project Sponsor (DG MOVE)' as Chair of the PSC is noted, but the specific line between the 'Project Director/Program Manager' (who manages daily operations through the OMG) and the 'Executive Sponsor' (PSC Chair) needs explicit demarcation regarding operational accountability vs. strategic oversight authority, especially concerning budget management delegated from the Sponsor.
4. Potential Gaps / Areas for Enhancement 2 (Process Depth - Conflict of Interest): While the Audit Details (provided as context) list corruption risks, the governance bodies lack an explicitly defined, mandatory *proactive* Conflict of Interest (CoI) declaration and management protocol integrated into the membership onboarding (Initial Setup Actions of PSC/OMG/TASG/CLAB).
5. Potential Gaps / Areas for Enhancement 3 (Delegation Specificity): The OMG has authority over budget shifts up to €500k. It is unclear if this delegation extends to authorizing the initial deployment of Capacity Building Grants (part of the €900M fund) before the PSC formally approves the overall grant framework, which is a key risk area identified in the audit assumptions.
6. Potential Gaps / Areas for Enhancement 4 (Integration of Policy Decisions): Strong links exist between implementation and monitoring, but the formal process for integrating the chosen strategic decisions (e.g., Decision 3: Tiered Liability Model) into the operational frameworks (e.g., CLAB's audit criteria post-launch) needs a mandatory checkpoint within the OMG/CLAB charter ratification phase, beyond just initial setup actions.
7. Potential Gaps / Areas for Enhancement 5 (Specificity of Enforcement Appeal): The Escalation Matrix correctly routes CLAB recommendations for sanctioning primary operators to the PSC. However, the mechanism for the sanctioned operator (e.g., SNCF) to appeal this sanction before execution lacks explicit procedural definition within the matrix; it currently jumps straight to PSC vote, potentially bypassing necessary dialogue.

## Tough Questions

1. Given Decision 5 (transactional fee model for capitalization) and the explicit assumption of needing a €300M Emergency Float Reserve, what is the modelled trigger frequency for drawing on this public contingency fund if initial transaction velocity is 50% lower than expected in Q1 post-launch?
2. For the primary operators (SNCF, DB, ÖBB), what specific behavioral indicators (beyond API uptime) will the CLAB use to determine if their cost recovery royalty claims (Assumption Q3) represent 'inflated IT operational expenditure' requiring the PSC to sanction withholding clearing mechanism access?
3. If the TASG is prioritizing PRM data schema finalization (Issue 1) to meet the 18-month binding deadline, what is the pre-approved Plan B for ensuring basic accessibility flagging can still operate functionally on the initial corridors if the complex two-way reservation system falls behind schedule past month 18?
4. Per Decision 13, the backstop activates at 90 minutes. If the monitoring plan consistently shows high utilization correlating with delays just *under* 90 minutes, what is the mandated review mechanism for the PSC to tighten this threshold within the first two years to meet the goal of halving distributor complaints?
5. What is the established contingency plan for the Project Director if the political de-escalation strategy (Issue 3) fails, and a major market participant, facing a 'three strikes' suspension, successfully lobbies DG MOVE leadership to halt the PSC's sanctioning process?
6. How does the OMG plan to reconcile the need for governance agility (Emergency review for 12 months, Assumption Q8) with the need for strict accountability and audit trails when issuing Provisional Operational Directives with only 65% technical consensus?
7. If the T+5 minute latency rule proves technically unsustainable for one major participant (Risk 2), is the Builder scenario policy (Decision 14) firm on maintaining the standardized T+5 requirement or is there a pre-approved, documented variance allowance (e.g., T+8 minutes for 12 months) that the PSC can utilize to prevent operational fragmentation?
8. How often (and at what level of detail) will the PSC formally review the Financial Operations Daily Liquidity Report to ensure the Head of Financial Operations is effectively managing the €200M float, given the high-stakes nature of the clearing mechanism?

## Summary

The project governance framework is robustly structured across four defined bodies (PSC, OMG, TASG, CLAB) designed to manage the intense complexity stemming from regulatory mandates, novel technical standards (OSDM), and critical financial settlement mechanisms. The chosen 'Builder' scenario emphasizes pragmatic harmonization through phased timelines and cost-sharing. Key strengths include the segregation of duties (CLAB for assurance, TASG for technical agility) and a clear escalation path to the PSC. However, success hinges on managing significant foreseen risks, particularly the political resistance to enforcement, ensuring the solvency of the transactional clearing mechanism, and rigorously following through on the challenging ancillary harmonization requirements (accessibility/loyalty) concurrently with core IT integration.