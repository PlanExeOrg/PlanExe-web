### 1. Project Sponsor (DG MOVE/Executive Lead) formally authorizes the establishment of all defined governance bodies based on agreed strategic decisions.

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Charter documents for PSC, OMG, TASG, CLAB circulation

**Dependencies:**

- Strategic Path (Builder Scenario) Confirmed
- Governance Body Definitions Finalized

### 2. Project Manager (via assumed interim coordination role) drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating PSC's specific decision thresholds and conflict resolution mechanisms.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Project Sponsor formally appoints the Executive Sponsor (Chair of PSC) and proposes the full PSC membership list for circular approval by key stakeholders (DG MOVE, EU Agency for Railways, Regulators Forum).

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PSC Chair Appointment Confirmation
- Nominated PSC Member List

**Dependencies:**

- Draft PSC ToR v0.1

### 4. PSC membership is formally confirmed, and the PSC Chair initiates the charter review/approval process.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Approved PSC ToR
- PSC Kick-off Meeting scheduled

**Dependencies:**

- PSC Membership Confirmed

### 5. Hold the inaugural meeting of the Project Steering Committee (PSC). Primary agenda item: Formal approval of the final structure and appointments for the subordinate bodies (OMG, TASG, CLAB).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC Meeting Minutes
- Endorsement of OMG, TASG, CLAB Charters and Initial Appointments

**Dependencies:**

- Final Approved PSC ToR

### 6. Project Manager proceeds to draft ToRs and finalize nominations for the Operational Management Group (OMG), Technical Assurance & Standards Group (TASG), and Compliance and Liability Assurance Board (CLAB), based on PSC endorsement.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- Draft OMG ToR/Membership List
- Draft TASG ToR/Membership List
- Draft CLAB ToR/Membership List

**Dependencies:**

- Endorsement of OMG, TASG, CLAB Charters

### 7. Confirm nomination of Chairs for OMG, TASG, and CLAB. These Chairs, advised by the Project Manager, secure final functional membership confirmations required for their groups to operate.

**Responsible Body/Role:** PSC Chair (via Project Manager)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Chairs for OMG, TASG, CLAB
- Final OMG, TASG, CLAB Membership Roster

**Dependencies:**

- Draft OMG/TASG/CLAB ToRs

### 8. Hold the inaugural meetings for the OMG, TASG, and CLAB. Key initial tasks: internal ratification of their respective ToRs and assigning immediate setup actions (e.g., dashboard setup for OMG, testing case definition for TASG, audit protocol drafting for CLAB).

**Responsible Body/Role:** Chairs of OMG, TASG, CLAB

**Suggested Timeframe:** Project Week 7-8

**Key Outputs/Deliverables:**

- Ratified ToRs for OMG, TASG, CLAB
- Initial Action Plan for each group (e.g., Draft SOW for OMG audit firm, TASG Test Cases)

**Dependencies:**

- Confirmed Chairs and Final Membership Roster

### 9. OMG initiates Project Reporting Framework setup: Establish centralized dashboard linking to timelines (Decision 4/14) and schedule initial weekly operational stand-ups.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Operational Reporting Dashboard v1.0 operational
- First OMG Weekly Stand-up Minutes

**Dependencies:**

- Ratified OMG ToR

### 10. TASG defines the standardized, detailed test cases required for OSDM compliance and the T+5 latency validation benchmark (Assumption Q6). This feeds directly into capacity grant planning.

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Finalized OSDM V1.0 Test Case Matrix
- T+5 Latency Validation Protocol

**Dependencies:**

- Ratified TASG ToR
- Agreement on Provisional Binding Status Timeline (M+6)

### 11. CLAB finalizes the protocol for auditing national carrier IT cost allocations (to enforce Capped Royalty, Decision 2 / Assumption Q3) and establishes the compliance reporting matrix linking commercial terms to clearing mechanism stability.

**Responsible Body/Role:** Compliance and Liability Assurance Board (CLAB)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Signed Charter for External Auditing Firm (SOW)
- Compliance Audit Framework v1.0

**Dependencies:**

- Ratified CLAB ToR
- PSC Approval of Initial Budget Allocation (for external audit costs)

### 12. OMG issues initial capacity building grants/technical assistance packages, prioritizing operators identified by CLAB for early audit focus (SNCF, DB, ÖBB) to accelerate OSDM integration.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Disbursement Record for Initial Capacity Building Grants (€900M fund deployment commences)
- Compliance Roadmap signed by SNCF, DB, ÖBB

**Dependencies:**

- Finalized OSDM V1.0 Test Case Matrix (TASG)
- Operator Compliance Roadmap (CLAB)

### 13. TASG begins work on harmonizing PRM reservation schema (Decision 9), ensuring the data schema validation is locked down before the provisional binding standard deadline (M+6).

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Month 2 (Week 9 Ongoing)

**Key Outputs/Deliverables:**

- Draft PRM Data Schema integrated into OSDM Specification Branch

**Dependencies:**

- T+5 Latency Validation Protocol
- Governance mandate to prioritize PRM schema conformance over ancillary grace period

### 14. PSC reviews the governance setup completeness, confirms readiness for standards ratification process, and formally signs off on the financial stabilization strategy for the Clearing Mechanism Float (€200M collateral structure).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Governance Structure Final Stability Report
- Clearing Mechanism Capitalization Approval (Decision 5)

**Dependencies:**

- OMG budget burn aligned with plan
- CLAB Compliance Framework established