**Primary domain:** Financial Clearing Mechanisms

**Secondary domains:** Digital Transport Regulation, Rail Infrastructure Management, Interoperability Standards

**Rationale:** Financial Clearing Mechanisms is the primary outcome, defining successful single-payment settlement, while Financial Settlement Systems is a closely related but secondary outcome. Digital Transport Regulation and Interoperability Standards are foundational constraints/methods, not the project's main success criterion.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Digital Transport Regulation | 5 | 5 | constraint | The project is explicitly aligned with a proposed EU Regulation on Digital Booking. |
| Interoperability Standards | 5 | 5 | method | The core technical requirement is using OSDM-compatible APIs and setting binding standards. |
| Financial Clearing Mechanisms | 5 | 5 | outcome | Establishing an inter-carrier clearing and settlement mechanism is a core deliverable. |
| Digital Distribution Systems | 5 | 5 | method | Building shared OSDM-compatible APIs is central to the project's technical delivery. |
| Rail Infrastructure Management | 4 | 4 | stakeholder | National rail operators and infrastructure bodies are key stakeholders and implementers. |
| Passenger Rights Advocacy | 4 | 4 | stakeholder | Disability rights bodies and consumer groups are explicitly listed stakeholders. |
| IT System Integration | 4 | 4 | method | The project relies heavily on exposing unified APIs and integrating various booking systems. |
| Financial Settlement Systems | 4 | 4 | outcome | Creating a single-payment, inter-carrier clearing and settlement mechanism is a key deliverable. |
| European Union Law | 4 | 3 | constraint | The entire program must align with the proposed EU Regulation on Digital Booking. |