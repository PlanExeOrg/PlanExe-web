# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Regulatory Economist (EU Transport Focus)

**Knowledge**: Cost recovery models, non-discrimination mandates, CAPEX/OPEX allocation, EU funding oversight

**Why**: Needed to scrutinize the 'standardized, capped royalty structure' (Decision 2) for true cost recovery vs. profit generation by operators.

**What**: Analyze the proposed capped royalty structure to ensure it meets non-discriminatory principles while covering carrier IT costs fairly.

**Skills**: Financial modeling, regulatory impact assessment, State Aid compliance, economic viability studies

**Search**: EU transport regulatory economist, royalty structure transport APIs, rail data cost recovery EU

## 1.1 Primary Actions

- Establish the Technical Steering Committee (TSC) by 2026-06-14.
- Draft the legally binding framework for conditional third-party bank guarantees by 2026-08-30.
- Mandate the integration of accessibility features into the OSDM standards by 2026-12-31.

## 1.2 Secondary Actions

- Engage with potential guarantor banks to secure financial backing for the clearing mechanism.
- Conduct regular stakeholder meetings to ensure alignment on governance and compliance.
- Implement a public communication strategy to raise awareness of accessibility features and their importance.

## 1.3 Follow Up Consultation

Discuss the progress on establishing the governance structure, the financial framework for the clearing mechanism, and the integration of accessibility features in the next consultation.

## 1.4.A Issue - Insufficient Governance Structure

The project lacks a clearly defined governance structure to oversee the implementation of the OSDM standards and ensure compliance from national operators. Without this, there is a risk of delays and inconsistencies in the adoption of standards.

### 1.4.B Tags

- governance
- compliance
- risk

### 1.4.C Mitigation

Establish a Technical Steering Committee (TSC) by 2026-06-14 with representatives from key stakeholders, including DG MOVE and major operators. This committee should be responsible for monitoring compliance and facilitating communication among stakeholders.

### 1.4.D Consequence

Failure to establish a robust governance structure may lead to fragmented implementation, resulting in delays and increased resistance from national operators.

### 1.4.E Root Cause

Lack of urgency in forming a governance body and unclear accountability for compliance.

## 1.5.A Issue - Under-capitalization of the Clearing Mechanism

The financial model for the inter-carrier clearing mechanism is not adequately defined, risking under-capitalization and liquidity issues, especially if initial transactional velocity is low.

### 1.5.B Tags

- finance
- liquidity
- risk

### 1.5.C Mitigation

Draft the legally binding framework for conditional third-party bank guarantees by 2026-08-30. Additionally, implement a transactional fee model to ensure ongoing capitalization of the clearing mechanism.

### 1.5.D Consequence

If the clearing mechanism is under-capitalized, it could lead to operational failures, impacting the entire ticketing system and eroding consumer trust.

### 1.5.E Root Cause

Inadequate financial planning and lack of immediate engagement with potential guarantor banks.

## 1.6.A Issue - Delayed Accessibility Integration

The integration of accessibility features into the OSDM standards is not prioritized, risking non-compliance with EU regulations and alienating passengers with reduced mobility.

### 1.6.B Tags

- accessibility
- regulatory
- risk

### 1.6.C Mitigation

Mandate that the OSDM data fields related to PRM booking must demonstrate functional mapping against the most restrictive standard by 2026-12-31. Conduct independent audits to ensure compliance with accessibility requirements.

### 1.6.D Consequence

Delaying accessibility integration could lead to regulatory penalties and a negative public perception of the project, undermining its goals.

### 1.6.E Root Cause

Insufficient focus on accessibility during the initial planning phases and lack of stakeholder engagement with disability rights groups.

---

# 2 Expert: Intermodal Logistics Architect

**Knowledge**: API integration for diverse transport modes, multi-modal data mapping, federated inventory systems

**Why**: Crucial for reviewing Decision 7 on integrating buses, ferries, and air, ensuring OSDM hooks are architecturally sound for non-rail modes.

**What**: Map the proposed OSDM API structure's flexibility against the known complexities of bus/ferry reservation data (e.g., luggage capacity).

**Skills**: Systems architecting, multi-modal data standards, API contract design, transport network integration

**Search**: Multi-modal ticketing API standards, OSDM extension, transport integration architect

## 2.1 Primary Actions

- Immediately revise the strategic choice for Decision 3 ('Mechanism for Handling Incomplete Cross-Border Journey Data') from Strict Tiered Liability (Option 1) to Mandatory Collective Insurance Pool (Option 2), to align financial reality with the chosen 'Pragmatic Harmonization' scenario.
- Elevate Decision 9 ('Approach to Harmonizing Accessibility Reservations Infrastructure') to immediate primary focus. Select Strategic Choice 1 (Mandate most restrictive schema immediately) and ensure PRM data mapping validation is fully integrated into the Provisional Binding Specification V0.9 release target of 2026-11-14.
- Revise Decision 10 ('Governance Structure for Binding vs. Non-Binding Standards Amendments'). Immediately implement the 'Fast-Track' subcommittee model (Choice 2) for technical amendments for the first two years post-binding status to ensure necessary operational agility.

## 2.2 Secondary Actions

- Recalibrate the resource allocation for Conformance Testing FTEs: dedicate 20% of initial testing capacity specifically to validating PRM data schema functional mapping concurrently with core inventory testing.
- Initiate immediate commercial/legal consultation to restructure Decision 5 ('Financing the Clearing Mechanism') to account for the shift from carrier collateral guarantees to public budget capitalization of the initial float, as required by the pivot in Decision 3.
- Schedule a mandatory joint workshop between the Liability/Backstop team and the Accessibility team to model the impact of Decision 9's chosen path on the required capitalization of the collective insurance pool (new Decision 3, Option 2).

## 2.3 Follow Up Consultation

The next consultation must focus exclusively on operationalizing the revised liability framework (Decision 3/Option 2) and stress-testing the proposed mandatory PRM integration against the aggressive binding standard timeline. We must confirm the revised capitalization strategy for the clearing mechanism float given the shift in risk pooling and confirm the exact scope and vetting process for the fast-track governance procedures established in the revised Decision 10.

## 2.4.A Issue - Scenario Selection Undermines Core Technical Enforcement

The client selected 'The Builder' scenario (pragmatic harmonization), which defers full financial risk centralization and adopts a phased standardization timeline (provisional binding at 6 months). However, the underlying strategic decisions selected within this scenario (especially Decision 3: Strict Tiered Liability, and Decision 12: Strong 'Three Strikes' Enforcement) are fundamentally contradictory to the 'realistic' pace selected. By choosing a strict, high-liability model (Option 1 in Decision 3) without socializing the risk (unlike The Pioneer), operators will inevitably resist the aggressive enforcement defined in Decision 12, leading to early political deadlock. You are planning maximal enforcement on minimal technical buy-in.

### 2.4.B Tags

- Scenario_Inconsistency
- Liability_Conflict
- Enforcement_Risk

### 2.4.C Mitigation

Consult Decision 3 and immediately pivot the chosen strategic option from 'Strict, Tiered Liability' to 'Option 2: Mandatory Collective Insurance Pool'. This is the correct mitigation for a 'realistic' scenario that still requires high technical compliance (Decision 12). Mitigation requires consulting DG MOVE legal counsel on structuring the pool and revising the initial capitalization strategy (Decision 5) to reflect pooled risk rather than unilateral carrier risk.

### 2.4.D Consequence

The strict tiered liability model, combined with aggressive enforcement (Three Strikes), will cause key operators (DB, SNCF) to contest the resulting liabilities immediately, freezing OSDM integration progress and rendering the 30-month API exposure deadline unreachable due to protracted legal/commercial standoffs.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - Ignoring Critical Dependency: Accessibility Data Schema Integration Pacing

The client's assessment suggests prioritizing core ticketing functionality first, with accessibility integration (Decision 9) being relegated to a secondary concern addressed late in the cycle, even though the 'pre-project assessment' correctly identified mandatory PRM schema validation by 2026-12-31. The selected Builder scenario does not explicitly address how Decision 9 will be paced against Decision 4 (Pacing Binding Standards). If standards become binding (provisional at 6 months, final at 18 months) before accessibility schema is validated internally, the system architecture will be fundamentally broken from an equity standpoint, forcing a costly retrofit or regulatory failure.

### 2.5.B Tags

- Regulatory_NonCompliance
- Equity_Delay
- Technical_Dependency

### 2.5.C Mitigation

Immediately elevate Decision 9 ('Approach to Harmonizing Accessibility Reservations Infrastructure') to Primary status. The client MUST select Strategic Choice 1 ('Mandatory, standardized PRM schema based on most restrictive requirement') for immediate binding adoption. Consult with disability rights bodies (referenced in Stakeholder Analysis) for rapid validation of the requirements definition against the provisional standard released in November 2026. This requires reallocating 20% of the initial testing FTEs (from the 35 total) specifically to PRM data mapping, documented via weekly reports to the TSC.

### 2.5.D Consequence

Failing to integrate accessibility compliance (PRM booking/assistance notification) into the binding standard means the final product violates the legislative intent of the Digital Booking Regulation, inviting immediate regulatory intervention from consumer protection bodies and potentially invalidating the entire passenger rights backstop mechanism designed for *all* passengers.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Underestimating Governance Agility for Post-Launch Stability

The client selected Decision 10, Choice 1, establishing a dual-approval governance structure (75% carriers + PRD) for binding amendments post-18 months. While this balances power, the initial plan suggests a five-year horizon with a high risk of discovering unforeseen interoperability issues on the complex initial corridors. A 75% threshold for binding changes is too high for effective post-launch correction when early adopters require rapid pivots identified during the first year of live operation. This structure guarantees technical stagnation, conflicting directly with the need for agility implied by the tight timeline.

### 2.6.B Tags

- Governance_Inflexibility
- Technical_Stagnation
- Iteration_Speed

### 2.6.C Mitigation

Immediately revise Decision 10 to implement the 'rotating Fast-Track subcommittee' (Choice 2) for the initial 24 months post-binding status (i.e., until Month 42). This grants necessary agility for minor fixes. Consult the EU Agency for Railways technical leads on defining the scope criteria for amendments assignable to this fast-track group (e.g., only schema clarifications or minor latency fixes). Revert to the 75% dual-approval for any substantive changes to liability, settlement, or commercial terms.

### 2.6.D Consequence

If the initial OSDM implementation reveals critical but minor technical flaws on the Paris-Brussels corridor, the 75% consensus requirement will lead to months of operational instability while the rigid governance structure debates necessary protocol updates. This will immediately trigger distributor complaints and undermine confidence in the T+90 minute guarantee.

### 2.6.E Root Cause

Empty

---

# The following experts did not provide feedback:

# 3 Expert: Public Sector Governance Specialist

**Knowledge**: Large-scale public consortium management, stakeholder coordination protocols, grant management compliance

**Why**: Required to validate the proposed governance structure (Decision 10) for amending binding standards amidst diverse national regulatory bodies and political pressure.

**What**: Develop clear delegation matrix and voting protocols for the Technical Steering Committee amendments post-binding status.

**Skills**: Consensus building, governance framework design, public investment oversight, stakeholder management

**Search**: EU public project governance framework, standards amendment voting protocols, multi-national regulatory steering committee

# 4 Expert: Special Counsel for EU Consumer Protection Law

**Knowledge**: EC Regulation 261/2004 (Air), Rail Passenger Rights (Regulation 1371/2007), liability attribution, redress mechanisms

**Why**: Essential for reviewing the legal robustness of the liability decisions (Decisions 1 & 3) concerning passenger rights backstop and fault attribution.

**What**: Review the tiered liability model against existing EU passenger rights case law to ensure the backstop is legally sound and not easily circumvented.

**Skills**: EU passenger rights directive compliance, liability definition, regulatory risk mapping, compensation framework construction

**Search**: EU rail passenger rights backstop legal review, carrier liability framework EU, Regulation 1371/2007 interpretation

# 5 Expert: Behavioral Scientist (Travel Adoption)

**Knowledge**: Modal choice modeling, friction reduction in booking, consumer inertia, value perception in travel

**Why**: Needed to assess if the proposed features and the definition of continuity thresholds (Decision 13) will genuinely drive the 'attractive than flying' goal (modal shift).

**What**: Quantify the necessary perceived value increase from unified ticketing to overcome existing consumer inertia related to cross-border train travel.

**Skills**: Choice modeling, consumer behavior analysis, UX/UI impact assessment, travel demand forecasting

**Search**: Behavioral science modal shift rail, consumer friction cross-border travel, perceived value single ticket

# 6 Expert: Financial Settlement Specialist (Clearing & Reconciliation)

**Knowledge**: Real-time gross settlement (RTGS), security/collateral requirements, transaction velocity risk management

**Why**: Essential for scrutinizing the complex capitalization and operational mechanism of the clearing fund (Decision 5) under the transactional fee model.

**What**: Design the automated velocity triggers and collateral reporting requirements needed to manage the contingent liability for the clearing mechanism float.

**Skills**: Payment systems engineering, financial reconciliation, collateral management, cross-border settlement

**Search**: Transactional fee clearing mechanism design, railway financial settlement specialist, contingent capital requirement

# 7 Expert: Accessibility Compliance Auditor (EU Transport)

**Knowledge**: Particularly EU Directive 2008/164/EC, PRM accommodation standards, operational vs reservation compliance

**Why**: To verify that Decision 9's proposed unified schema aligns with mandated physical accessibility requirements across national networks under the 'phased' approach.

**What**: Audit the schema mapping requirements against the most restrictive national physical infrastructure readiness levels for high-speed corridors.

**Skills**: Accessibility auditing, disability impact assessment, non-discrimination technical implementation, PRM seating protocols

**Search**: EU rail PRM booking requirement audit, physical accessibility compliance TEN-T network, OSDM accessibility standard

# 8 Expert: IT Compliance and Enforcement Strategist

**Knowledge**: Mandatory API rollout enforcement, conformity assessment procedures, sanctioning procedures for IT non-compliance

**Why**: Required to ensure Decision 12's 'three strikes' policy is practical, legally defensible, and effective against skeptical, powerful incumbent IT monopolies.

**What**: Draft the specific technical failure criteria (uptime, latency, semantic error rate) that immediately trigger the first warning in the enforcement posture.

**Skills**: IT regulatory enforcement, API conformance testing, digital service act compliance, sanctioning frameworks

**Search**: Mandatory IT API enforcement strategy, sanctioning for non-compliant rail operators, technical compliance audit railway