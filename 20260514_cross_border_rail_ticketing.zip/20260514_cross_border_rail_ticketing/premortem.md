A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A4 | The EU Commission will successfully enforce the 'Three Strikes' suspension policy against major national operators (SNCF, DB, ÖBB) without triggering immediate, paralyzing political intervention from the Council of Ministers. | The EU Regulatory & Governance Architect will present the finalized, legally vetted 'Three Strikes' suspension charter to DG MOVE for official pre-approval, checking for safeguards against Council override mechanisms by 2027-06-01. | DG MOVE indicates that enforcement on any single major operator requires unanimous Council approval rather than simple DG MOVE sanctioning authority. |
| A5 | The €1.5 Billion public coordination budget will remain fully available and unreduced throughout the initial 3-year critical implementation phase for capacity building grants and contingency funds. | The Program Risk Manager will secure a formal financial commitment letter from the European Parliament's budgetary authority confirming zero planned reallocation or reduction of the €1.5B tranche earmarked for the first 36 months of operations by 2027-07-01. | A significant Member State successfully lobbies to ring-fence or reallocate „100 Million from the grants pool for domestic infrastructure projects, reducing the incentive budget. |
| A6 | National operators possess the latent IT capacity (even if currently unbudgeted) to undertake the necessary system modifications to implement the final OSDM V1.0 binding standard within the 18-month deadline, requiring only financial support via available grants. | The Interoperability Standards Lead will conduct a 10-day diagnostic sprint with the IT heads of the 5 largest operators to map OSDM V1.0 technical gaps against current legacy architecture roadmaps, looking for major architectural incompatibility rather than simple coding gaps. | The diagnostic sprint reveals that 3 of the 5 largest operators require a fundamental replacement of their core booking engine (not just API wrapping) to achieve OSDM compliance, rendering the 18-month timeline infeasible regardless of grant funding. |
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A4 | The EU Commission will successfully enforce the 'Three Strikes' suspension policy against major national operators (SNCF, DB, ÖBB) without triggering immediate, paralyzing political intervention from the Council of Ministers. | The EU Regulatory & Governance Architect will present the finalized, legally vetted 'Three Strikes' suspension charter to DG MOVE for official pre-approval, checking for safeguards against Council override mechanisms by 2027-06-01. | DG MOVE indicates that enforcement on any single major operator requires unanimous Council approval rather than simple DG MOVE sanctioning authority. |
| A5 | The €1.5 Billion public coordination budget will remain fully available and unreduced throughout the initial 3-year critical implementation phase for capacity building grants and contingency funds. | The Program Risk Manager will secure a formal financial commitment letter from the European Parliament's budgetary authority confirming zero planned reallocation or reduction of the €1.5B tranche earmarked for the first 36 months of operations by 2027-07-01. | A significant Member State successfully lobbies to ring-fence or reallocate €100 Million from the grants pool for domestic infrastructure projects, reducing the incentive budget. |
| A6 | National operators possess the latent IT capacity (even if currently unbudgeted) to undertake the necessary system modifications to implement the final OSDM V1.0 binding standard within the 18-month deadline, requiring only financial support via available grants. | The Interoperability Standards Lead will conduct a 10-day diagnostic sprint with the IT heads of the 5 largest operators to map OSDM V1.0 technical gaps against current legacy architecture roadmaps, looking for major architectural incompatibility rather than simple coding gaps. | The diagnostic sprint reveals that 3 of the 5 largest operators require a fundamental replacement of their core booking engine (not just API wrapping) to achieve OSDM compliance, rendering the 18-month timeline infeasible regardless of grant funding. |
| A7 | The general public possesses sufficient awareness and understanding of the complex passenger rights guarantees (especially the 90-minute continuity threshold) to generate reliable, positive feedback leading to modal shift. | The Passenger Rights & Equity Policy Analyst will execute a pre-launch public perception survey measuring awareness of the new 90-minute delay guarantee and willingness to book a multi-leg journey based on this feature alone, targeting 60% recall rate among frequent short-haul air travelers. | The survey shows less than 30% recall of the new 90-minute rule, and respondents primarily rely on existing, fragmented national guarantees rather than the unified system feature. |
| A8 | The governance structure agreed upon (TSC with fast-track subcommittees) will successfully resolve inevitable specification conflicts without fracturing or empowering a single dominant incumbent operator to veto necessary changes. | The EU Regulatory & Governance Architect will run a historical simulation exercise using the records from the ERTMS/Shift2Rail governance board to model adversarial voting patterns on a hypothetical V1.1 feature change, requiring a decision by a 65% fast-track quorum. | The simulation reveals that two major states, acting in concert, can consistently block the required 65% threshold on critical technical pivots five times out of ten attempts, suggesting systemic gridlock even with the fast-track mechanism. |
| A9 | The centralized clearing mechanism float, fully capitalized by transactional fees and backed by bank guarantees, will maintain sufficient liquidity (150% buffer) without requiring drawdowns from the Emergency Float Reserve (€300M) during the first 18 months of operation. | The Financial Clearing & Settlement Specialist will report the rolling 4-week average liquidity buffer status against the 150% threshold, demanding automated alerts if it dips below 165% for two consecutive weeks, rather than the stop-rule 150% trigger. | The rolling average liquidity buffer consistently registers between 130% and 149% for 6 continuous weeks, indicating that transactional velocity is too low to support the T+3 settlement window without tapping the emergency reserve. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM2 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM3 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Market/Human | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |
| FM4 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM5 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM6 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Market/Human | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |
| FM7 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM8 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM9 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Process/Financial | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM2 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption that T+5 latency was achievable (A3) proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes an urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM3 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20%).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.

---

#### FM4 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM5 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption (A3) that T+5 latency was achievable proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM6 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20% power curve).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.

---

#### FM7 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM8 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption (A3) that T+5 latency was achievable proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM9 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20% power curve).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.
