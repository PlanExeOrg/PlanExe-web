## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers center on establishing the immutable foundations: Pacing Standard Adoption (12), enforcing Data Exposure (25), funding the Clearing Mechanism (7), defining Passenger Rights Liability (1), and setting fair Commercial Terms for Operators (4). Collectively, these address the core trade-off between Speed vs. Technical Robustness, and Regulator Control vs. Private Sector Buy-in, while resolving the fundamental issues of financial settlement and consumer protection required for any valid through-ticket service.

### Decision 1: Defining Liability and Passenger Rights Backstop Scope
**Lever ID:** `1f32c7c8-c66d-46fe-bf44-e0c87ba19003`

**The Core Decision:** This lever defines the financial and operational commitment for insulating passengers from complex inter-carrier disputes when journey segments fail. The goal is to establish a simple, consolidated EU backstop mechanism, likely pooled, to ensure immediate compensation payout aligning with consumer expectation. Key metrics involve the speed of fault attribution versus passenger payout, and the overall financial stability of the pool, crucial for underpinning passenger trust metrics.

**Why It Matters:** When a single ticket is sold but the journey involves multiple operators, determining who pays compensation for delays or cancellations becomes critical for consumer trust. Establishing a single, overarching backstop funded by all carriers significantly simplifies this for the passenger by making the distributor's interaction clear. This, however, forces high-performing carriers to subsidize the systemic failures of poorly managed operators within the clearing pool.

**Strategic Choices:**

1. Establish a pooled, mandatory insurance or reserve fund managed operationally by the EU Agency for Railways, which pays the passenger upfront for all validated rights claims, then recoups costs based on fault attribution.
2. Require the initial seller (distributor) to assume 100% of the passenger rights liability for the entire journey, irrespective of fault, forcing them to negotiate complex secondary reinsurance contracts with every carrier separately.
3. Limit the EU backstop only to instances where the connecting failure occurs between the first and last known segments, leaving disputes regarding segments managed entirely within existing national compensation frameworks.

**Trade-Off / Risk:** A unified EU backstop maximizes passenger confidence and distribution simplicity, but risks creating a moral hazard where the most reliable national carriers pay disproportionately for others' systemic delays.

**Strategic Connections:**

**Synergy:** Directly supports Defining Continuity-of-Journey Failure Thresholds by providing the mechanism through which penalties and payouts for exceeding those thresholds are actually managed and executed.

**Conflict:** Creates tension with Enforcement Posture for Non-Compliant Operator IT Integration, as a robust backstop can reduce the immediate financial penalty risk for carriers whose systems cause validated failures.

**Justification:** *Critical*, This is a core pillar of the passenger experience and regulatory compliance. Defining the backstop resolves the fundamental tension between consumer trust/simplicity and carrier financial risk attribution, making it central to market adoption.

### Decision 2: Governing Commercial Terms for Data Exposure and API Access
**Lever ID:** `c4680d31-2fda-49c5-9471-36fac751a32d`

**The Core Decision:** This concerns setting the non-discriminatory cost structure for commercial access to real-time inventory data held by national operators. The objective is to balance recovering essential IT costs for data providers against ensuring low barriers to entry for competing distributors. Success rests on establishing transparent, regulator-approved pricing that maximizes the diversity of distributors selling through-tickets, directly supporting the market uptake goal.

**Why It Matters:** The commercial terms dictating access fees for real-time inventory directly influence the pace and scope of independent distributor participation, which is vital for hitting the adoption target. If the terms are strictly cost-recovery only, smaller innovative platforms may lack the capital to rapidly integrate, concentrating market power with incumbents who already have legacy access. Conversely, heavily subsidized API access might lead to disputes over preferential treatment versus the non-discriminatory principle.

**Strategic Choices:**

1. Implement a standardized, capped royalty structure based on transaction volume, ensuring all API access fees are strictly cost-recovery for the national carrier's data provisioning, overseen by the regulators.
2. Offer the first two years of API access entirely free of charge for all certified third-party distributors to maximize market penetration initially, shifting the cost burden entirely onto the €1.5 billion public budget.
3. Empower national regulators to impose maximum commercial fees on inventory access, with any carrier exceeding this threshold being temporarily barred from the centralized clearing settlement mechanism until compliance is confirmed.

**Trade-Off / Risk:** Free initial API access strongly stimulates distributor adoption and competitive pricing, but it places the cost burden onto taxpayer funding rather than the commercial value generated by the data access.

**Strategic Connections:**

**Synergy:** Works to enable Incentivizing Early Carrier Participation in the Shared Data Layer by ensuring that, once data is exposed, the commercial relationship between provider and consumer is clear and fair.

**Conflict:** Creates a trade-off with Cost Allocation for Public Reference Distributor Operation; heavily subsidized API access may be viewed as unfair competition against a publicly funded distributor operating under cost-recovery terms.

**Justification:** *Critical*, This lever controls distributor participation and competitive market structure. Setting commercial terms dictates barrier-to-entry, directly impacting the success metric of achieving 40% single through-tickets sold by empowering or constraining distributors.

### Decision 3: Mechanism for Handling Incomplete Cross-Border Journey Data
**Lever ID:** `7e10ade0-7b0b-4c1b-bf46-0f46d50263f2`

**The Core Decision:** This lever addresses financial exposure when a multi-carrier journey fails due to technical faults or data lapses. Defining liability division is crucial for motivating carrier compliance and ensuring passenger compensation funds remain solvent. The goal is balancing risk assignment to incentivize data quality versus ensuring the backstop remains viable and doesn't unduly deter new market entrants from embracing the unified system.

**Why It Matters:** When a booking fails mid-chain or an operator fails to transmit required disruption data, the common passenger rights backstop must intervene, requiring an agreed liability split among parties. A 'maximum residual liability' cap placed on the initiating distributor simplifies their risk model but incentivizes them to offload complex failure scenarios onto the public backstop, straining its solvency. High operator-borne initial liability strongly encourages compliance but may discourage newer carriers from joining the network initially.

**Strategic Choices:**

1. Establish a strict, tiered liability model where the carrier whose segment experienced the technical failure bears one hundred percent of compensation costs unless gross distributor negligence is proven.
2. Create a mandatory collective insurance pool, pre-funded by all participants proportional to journey volume, to cover all unknown-cause or multi-party failure compensation claims up to a defined ceiling.
3. Insist that the initial distributor (the entity contracting with the passenger) retains full, un-capped liability for the entire journey, regardless of failure point, promoting rigorous downstream vetting.

**Trade-Off / Risk:** Placing un-capped liability on the initiating distributor heavily penalizes innovative third-party platforms lacking control over backend carrier fulfillment, which discourages market entry despite the primary objective.

**Strategic Connections:**

**Synergy:** This lever is strongly amplified by Defining Liability and Passenger Rights Backstop Scope, as the data failures addressed here directly inform the structure and required capitalization of the backstop.

**Conflict:** It conflicts with Incentivizing Early Carrier Participation in the Shared Data Layer; overly punitive liability models may cause potential participants to delay joining the shared data layer until risk models stabilize.

**Justification:** *Critical*, This lever sets the operational risk profile for the entire system. It dictates how unexpected failures are resolved, directly influencing both carrier compliance incentives and the viability of the passenger rights backstop.

### Decision 4: Pacing the Binding Standard Adoption Timeline
**Lever ID:** `aabd9b95-58b1-4d9c-ab1e-487c8549949b`

**The Core Decision:** This lever sets the timeline pressure for formalizing the technical exchange specifications (OSDM) into mandatory requirements. An aggressive timeline forces immediate system modifications across operators, aligning development quickly but raising rework risk if the standards prove brittle. The pace must balance the need for quick market access against ensuring technical specifications are validated through early implementation phases.

**Why It Matters:** Establishing binding technical standards within the first eighteen months allows distributors to rapidly gain access to necessary API functionality for the initial four corridors. However, this aggressive timeline forces carriers to freeze development on unverified specifications, potentially requiring costly re-engineering if DG MOVE mandates late-stage amendments based on early corridor feedback.

**Strategic Choices:**

1. Mandate that all core OSDM data exchange and transaction processing standards achieve full formal binding status within twelve months, necessitating immediate, high-risk operator system modification.
2. Implement a phased standardization approach where technical specifications achieve provisional binding status at six months, followed by regulatory finalization after the first set of corridors demonstrate operational stability at eighteen months.
3. Defer the formal binding adoption of reduction card and accessibility reservation schemas until the full TEN-T network integration phase, allowing initial corridors to operate with nationally negotiated, non-harmonized parameters.

**Trade-Off / Risk:** Accelerating binding standards commits operators to potentially incomplete specifications, requiring rework; deferring harmonization of critical features like accessibility risks undermining legislative intent for an equitable system from the outset.

**Strategic Connections:**

**Synergy:** An accelerated timeline accelerates the foundation for Financing the Inter-Carrier Clearing Mechanism Capitalization, as clearing mechanisms rely on finalized data exchange protocols.

**Conflict:** It creates tension with Governance Structure for Binding vs. Non-Binding Standards Amendments; binding standards established too early reduce the governance body's flexibility post-launch for necessary pivots.

**Justification:** *Critical*, This sets the primary pace constraints for all technical development across the entire network. It controls the fundamental tension between speed-to-market (18 months) and technical refinement/risk mitigation.

### Decision 5: Financing the Inter-Carrier Clearing Mechanism Capitalization
**Lever ID:** `7e412293-f431-4566-be78-c84535afc0b1`

**The Core Decision:** This lever determines the source of funds to capitalize the critical inter-carrier clearing mechanism, which facilitates single-payment settlement and automated fund transfers. The choice significantly impacts carrier liquidity versus program expenditure. Success hinges on establishing a self-sustaining, solvent structure that processes billions in payments without burdening operators' working capital during the critical integration phase.

**Why It Matters:** Deciding how to capitalize the clearing mechanism dictates the initial cash flow impact on participating national carriers versus the program budget. A system financed primarily through prepaid collateral requires large upfront capital lockup from operators, restricting their liquidity for other IT modernization projects.

**Strategic Choices:**

1. Capitalize the initial float required for the settlement mechanism entirely through the €1.5 billion public coordination budget, treating it as infrastructure investment to minimize carrier working capital strain.
2. Implement a transactional fee model where each ticket sale contributes a small, variable percentage to a rolling reserve fund, requiring carriers to provide conditional third-party bank guarantees instead of direct capital injection.
3. Require that only the initiating carrier posts 100% of the required settlement collateral for a given transaction, with automated subrogation mechanisms to reclaim funds from downstream carriers within seven business days.

**Trade-Off / Risk:** Funding float via the public budget eases carrier capital constraint but centralizes a significant financial risk within the EU program funding structure; relying solely on bank guarantees adds external financing overhead to the core payment process.

**Strategic Connections:**

**Synergy:** Financing the Inter-Carrier Clearing Mechanism Capitalization synergizes with Cost Allocation for Public Reference Distributor Operation, as public funding of one mechanism can free up private funds for the other.

**Conflict:** This lever conflicts with Enforcement Posture for Non-Compliant Operator IT Integration; demanding large upfront capital locks up carrier funds needed to pay for necessary IT upgrades and compliance efforts.

**Justification:** *Critical*, The clearing mechanism is the financial backbone enabling single-payment settlement. Its capitalization choice fundamentally dictates the liquidity strain on national carriers versus the program budget, critically enabling transactional reality.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Incentivizing Early Carrier Participation in the Shared Data Layer
**Lever ID:** `bbb8d8f0-68c8-4932-912e-9c1dbe444120`

**The Core Decision:** This lever aims to accelerate the construction of the core technical foundation—the shared real-time data layer—by using targeted financial incentives linked to early API compliance. Success is measured by the percentage of API compliance metrics met ahead of the mandatory deadline on initial corridor routes. This strategy directly catalyzes distributors' ability to offer accurate pricing and inventory, shifting focus from standard-setting negotiation to functional system readiness.

**Why It Matters:** Offering preferred treatment in public funding allocations (e.g., capacity building grants) to national operators who fully expose real-time inventory via OSDM-compatible APIs significantly ahead of the mandatory deadline. This accelerates the creation of the unified data foundation necessary for through-ticketing across the initial busiest corridors. However, early adopters may be forced to use preliminary, less stable API specifications, potentially leading to higher mid-term IT resolution costs to fix discrepancies before final standards stabilize.

**Strategic Choices:**

1. Implement a tiered funding model where early adopters demonstrating 90% API uptime on test systems receive disproportionately larger allocations of the €1.5 billion coordination budget for their domestic upgrade paths.
2. Establish a 'Regulatory Fast-Track' status for compliant carriers, simplifying their national permitting processes for existing cross-border routes not covered by the new regulation until the full framework is live.
3. Require all participating distributors to give a 12-month contractual priority window only to carriers whose real-time data exposure exceeds 95% compliance on the core corridor routes, effectively penalizing laggards through lost immediate sales volume.

**Trade-Off / Risk:** Prioritizing funding based on API uptime creates a compelling financial pull for carriers, but may divert scarce initial capital towards integration rather than comprehensive post-sale rights harmonization.

**Strategic Connections:**

**Synergy:** Amplifies Financing the Inter-Carrier Clearing Mechanism Capitalization by providing the necessary real-time data feed required for the clearing mechanism to function accurately from day one.

**Conflict:** Trades off against Pacing the Binding Standard Adoption Timeline; rushing API exposure may lead to early integration against preliminary non-finalized standards, requiring costly rework later.

**Justification:** *High*, This lever directly addresses the primary technical dependency (real-time data layer). Incentives accelerate the foundation for ticketing and clearing, creating significant early momentum, even though it risks integration rework due to standard finalization lag.

### Decision 7: Adoption Strategy for Non-Core Transport Modes Integration Hooks
**Lever ID:** `8b26b7f3-cf3a-4074-9408-275dca23f431`

**The Core Decision:** This strategy governs whether the project maintains a strict focus on core rail-to-rail interoperability or strategically expands early integration to include associated transport modes like buses or ferries. The scope involves creating provisional API hooks and negotiating supplementary commercial rules. Success here is defined by achieving targeted pilot integrations without jeopardizing the core timeline for rail ticketing availability on the main corridors.

**Why It Matters:** Integrating bus, ferry, and airport connections drastically improves the utility of the cross-border rail product, fulfilling the modal shift objective, but vastly expands the scope of required API adaptation and commercial negotiation. Delaying these integrations to focus solely on rail interoperability first ensures meeting the five-year core ticketing target with higher certainty. However, non-rail connections present unique ticketing complexities (e.g., variable loading rules for luggage/bicycles) that could slow down the development of clean, harmonized accessibility standards required for rail itself.

**Strategic Choices:**

1. De-scope all bus, ferry, and air integration hooks from the initial five-year mandate, focusing strictly on carrier-to-carrier rail connectivity and postponing secondary mode standards until binding rail standards are fully adopted.
2. Select a single, high-volume ferry operator and a single bus operator on each of the four initial launch corridors to pilot combined ticketing integration within the first three years, using their unique data structures to refine resilience.
3. Force the OSDM specification body to reserve specific, mandatory data fields for flexible integration requirements (e.g., loading capacity for bikes/luggage) by all transport modes simultaneously to preempt future fragmentation.

**Trade-Off / Risk:** Delaying integration of secondary modes ensures core rail timelines are protected, yet it sacrifices immediate market utility benefits and locks in system architecture before accommodating necessary adjacent transport realities.

**Strategic Connections:**

**Synergy:** Synergizes with Adoption Strategy for Non-Core Transport Modes Integration Hooks by providing the critical, dedicated scope and pilot strategy necessary for non-rail mode integration success.

**Conflict:** Directly conflicts with Pacing the Mandatory API Exposure Timeline, as extending the scope to multi-modal data requirements will inherently strain the development resources allocated to core rail APIs.

**Justification:** *Medium*, While important for the overall modal shift goal, this lever scopes additions outside the core rail mandate. Delaying it allows focus on core ticketing, marking it less central than the foundational technical and financial levers.

### Decision 8: Approach to Harmonizing Reduction Cards and Loyalty Schemes
**Lever ID:** `a9fb8a6d-0648-4587-9ab3-84072764e094`

**The Core Decision:** This lever addresses the politically sensitive task of making national discount and loyalty cards valuable for cross-border sales. The strategy dictates the degree of immediate harmonization versus deferral. Achieving high adoption requires customers to transfer existing value; therefore, the success metric is the percentage of eligible passengers who successfully apply a recognized discount on their first cross-border ticket via the new system.

**Why It Matters:** Recognizing and integrating national discount cards (like BahnCard or Carte Avantage) drives immediate passenger adoption by translating existing value to cross-border journeys, but harmonizing these inherently specific national schemes is bureaucratically complex and politically sensitive. Delaying complex harmonization allows the basic ticketing function to launch faster, but delays the critical modal shift objective because loyal customers cannot realize existing benefits, thus creating a fragile initial user base.

**Strategic Choices:**

1. Mandate immediate, universal recognition of the top three highest-volume national reduction cards across all four launch corridors, deferring the process of reconciling smaller national schemes until the second rollout phase.
2. Temporarily substitute all national discount cards with a single, standardized EU 'Cross-Border Discount Voucher' distributed automatically at the point of sale, payable from a temporary EU fund, bypassing carrier-specific scheme integration.
3. Require all national operators to convert the monetary value of their top discount card into a simple, time-limited percentage reduction applicable only to the final single through-ticket price, regardless of the underlying national scheme rules.

**Trade-Off / Risk:** Substituting national cards with a generic EU voucher achieves rapid perceived fairness for customers, but risks alienating national operators who rely on unique loyalty schemes for baseline domestic revenue protection.

**Strategic Connections:**

**Synergy:** Amplifies Governing Commercial Terms for Data Exposure and API Access because if discounts are recognized, distributors are more incentivized to integrate, as it increases the comparative value proposition of through-tickets.

**Conflict:** Creates friction with Approach to Harmonizing Accessibility Reservations Infrastructure, as immediate focus on complex fare/discount harmonization drains resources needed for the equally complex, but mandatory, accessibility standardization work.

**Justification:** *High*, Harmonization directly addresses passenger inertia and adoption challenges inherited from national systems. Successful integration maximizes the value proposition for existing loyal users, critically supporting the modal shift objective.

### Decision 9: Approach to Harmonizing Accessibility Reservations Infrastructure
**Lever ID:** `7381da62-7b8b-403e-b3c6-7f02117f676a`

**The Core Decision:** This lever focuses on establishing a unified, pan-European mechanism for booking and managing reservations for Persons with Reduced Mobility (PRM). Success hinges on achieving interoperable data exchange for assistance and specialized seating across disparate national infrastructures. The key metric is the seamlessness of multi-operator PRM bookings, ensuring regulatory compliance is met without crippling carriers lacking advanced physical accommodation updates immediately.

**Why It Matters:** Integrating specific booking flows for Persons with Reduced Mobility (PRM) requirements (e.g., wheelchair space booking, assistance notification) is highly complex due to varying physical asset availability across national infrastructures. Prioritizing a unified pan-European reservation flow simplifies the distributor interface but may demand costly, non-standardized physical accommodation updates by the least technically prepared infrastructure owner. Delaying full unification reduces initial implementation scope but maintains regulatory compliance risk in specific operational niches.

**Strategic Choices:**

1. Establish a mandatory, standardized PRM reservation schema based on the most restrictive national requirements across the initial four corridors, enforcing immediate adoption across the entire network.
2. Limit initial system capability to flagging assistance needs through a standardized distress code, deferring actual inventory booking and resource deployment coordination to validated, operator-specific ancillary services.
3. Pilot deep, two-way PRM data integration only on the busiest north-south corridor first, treating assistance reservation as a decoupled, bilateral operational signaling exchange rather than a unified ticketing feature.

**Trade-Off / Risk:** Forcing the most restrictive national PRM schema onto all operators immediately risks technical deadlock or non-compliance from carriers lacking the physical infrastructure to support the imposed standard immediately.

**Strategic Connections:**

**Synergy:** It synergizes with Approach to Harmonizing Accessibility Reservations Infrastructure by providing the necessary technical groundwork for unified data exchange, enabling integrated booking flows.

**Conflict:** It conflicts with Cost Allocation for Public Reference Distributor Operation, as high initial investment in complex PRM schemas may inflate the operation costs that need to be funded.

**Justification:** *High*, Accessibility is a non-negotiable regulatory requirement. This lever governs the complexity of embedding mandatory equity concerns ('accessibility for persons with reduced mobility') into the technically demanding unified booking flow.

### Decision 10: Governance Structure for Binding vs. Non-Binding Standards Amendments
**Lever ID:** `c756bf68-aaad-4f78-84e6-29a84d7a9f3a`

**The Core Decision:** This lever determines the procedural agility for evolving the OSDM technical standards post-launch. A robust governance structure ensures necessary adaptation while preventing any single dominant stakeholder from arbitrarily vetoing beneficial changes. Success is measured by the speed and acceptance rate of beneficial standard amendments needed as initial corridors reveal operational realities, balancing iteration against stability.

**Why It Matters:** Alterations to the OSDM API specification after the initial binding period require a robust, efficient approval process to maintain agility, yet overly centralized power risks vetoes from dominant national operators. A system weighted towards the majority of paying carriers encourages rapid iteration but may ignore critical, specialized infrastructure constraints held by minority carriers. Unanimous consent protects incumbents but guarantees slow, incremental technical evolution that misses emerging market needs.

**Strategic Choices:**

1. Implement a technical steering committee where amendments passing the initial 18-month deadline require a dual-approval threshold: 75% of signatory incumbent carriers plus approval from the public reference distributor.
2. Establish a rotating 'Fast-Track' subcommittee, composed only of distributors and one representative from the two smallest participating carriers, empowered to make binding, non-emergency amendments for six-month cycles.
3. Freeze the initial OSDM V1.0 standard for the full five-year horizon, allowing only clarifications of existing documentation but demanding all new features be managed through a completely separate V2.0 specification track.

**Trade-Off / Risk:** Empowering a small, rotating subcommittee risks marginalizing the largest financial contributors (incumbent carriers) whose infrastructure investments dictate operational reality, potentially causing non-cooperation.

**Strategic Connections:**

**Synergy:** It directly governs the evolution of the shared data layer, making it crucial for the effective implementation of Governing Commercial Terms for Data Exposure and API Access over time.

**Conflict:** It can conflict with Pacing the Mandatory API Exposure Timeline; a slow, overly consensus-driven governance structure will delay necessary API changes mandated by the exposure schedule.

**Justification:** *Medium*, Important for long-term agility, but less immediately critical than setting the initial technical foundation or commercial structure. It dictates *how* standards change, rather than defining the initial, high-stakes standards themselves.

### Decision 11: Cost Allocation for Public Reference Distributor Operation
**Lever ID:** `52436de8-dba8-4bdd-afa6-5c2f387ea79f`

**The Core Decision:** This lever defines the long-term financial viability and operational posture of the public reference distributor, which serves as an independent audit and reference point. Funding methodology determines its independence and commercial competitiveness—subsidized use encourages equal access, while usage fees drive operational self-sufficiency. Success means maintaining a robust, trusted reference platform without becoming a perpetual drain on the program budget.

**Why It Matters:** The public reference distributor is crucial for leveling the playing field and providing a fallback audit mechanism, but its operational funding must be secured. If funded entirely by the €1.5 billion public budget, it becomes a fixed drain regardless of network usage and may lack commercial agility. Requiring all commercial distributors to pay usage fees immediately shifts costs to the private sector but may disincentivize smaller players from utilizing a publicly subsidized asset.

**Strategic Choices:**

1. Fund the public reference distributor entirely through annual direct grants from the EU Program Budget for the full five years, keeping its use free and fully independent of commercial transactions.
2. Charge a modest, per-transaction administrative fee (below €0.01 per booking) collected via the clearing mechanism, rebating these fees to smaller distributors who process fewer than ten thousand bookings monthly.
3. Treat the public distributor as an open-source reference implementation, requiring only initial setup funding, and mandate that future maintenance and scale costs must be covered by optional, subscription-based support contracts.

**Trade-Off / Risk:** Funding the reference distributor solely through fixed public grants disconnects its operational incentives from network performance, potentially leading to feature stagnation if maintenance needs balloon unexpectedly.

**Strategic Connections:**

**Synergy:** This lever's funding choice impacts the viability of the public reference distributor, which acts as a key operational backup for Enforcement Posture for Non-Compliant Operator IT Integration.

**Conflict:** If funded entirely by public grants, it creates a dependency that strains the overall budget earmarked for program activities like Capacity Building, potentially reducing scope elsewhere.

**Justification:** *Medium*, This addresses the long-term operational posture of the audit mechanism. While important for maintaining a level playing field, the initial strategic success hinges on private sector development and adoption, not the subsidized reference model's fee structure.

### Decision 12: Enforcement Posture for Non-Compliant Operator IT Integration
**Lever ID:** `256244ca-5c5d-4ff6-b021-e0f301af21bf`

**The Core Decision:** This defines the regulatory teeth used to compel national carriers to implement OSDM-compliant APIs by the mandated deadline. A hardline approach forces rapid market entry for distributors but risks operational chaos if integration is incomplete. The key metric is near-100% uptime of compliant data feeds across high-priority corridors within two years.

**Why It Matters:** The approach to enforcing mandatory API exposure dictates the speed of market access for distributors and the willingness of skeptical national monopolies to upgrade their systems. Threatening service suspension guarantees compliance speed but risks fracturing the network during the critical rollout phase on the core corridors.

**Strategic Choices:**

1. Implement a clear 'three strikes' policy where the regulator automatically suspends an operator's ability to sell through-tickets on major corridors after three documented, non-remediated API failures within a quarter.
2. Leverage the EU Agency for Railways to apply graduated financial penalties, withholding certain public funding related to infrastructure modernization until full OSDM conformance is verified via external audit.
3. Introduce a market-forcing mechanism where the Public Reference Distributor is granted preferential, temporary access to inventory for non-compliant carriers, effectively penalizing the incumbent's direct sales channels.

**Trade-Off / Risk:** Immediate suspension of service severely compromises passenger flow during integration, yet relying solely on financial penalties may be too slow to meet the thirty-month mandatory exposure deadline for the busiest routes.

**Strategic Connections:**

**Synergy:** A strong Enforcement Posture directly supports Pacing the Mandatory API Exposure Timeline, ensuring that the strategic deadlines set for system availability are met through credible operational consequences.

**Conflict:** Aggressive Enforcement Posture conflicts with Financing the Inter-Carrier Clearing Mechanism Capitalization; carriers facing service suspension threats will hoard operational cash, making them resistant to large collateral requirements.

**Justification:** *Critical*, Given the hard regulatory deadlines (30 months for API exposure), enforcement is the lever that translates paper compliance into actual market readiness. It directly controls operator behavior regarding the core data layer dependency.

### Decision 13: Definition of Continuity-of-Journey Failure Thresholds
**Lever ID:** `16b05ab5-1e11-4f45-84c3-a77585c45aad`

**The Core Decision:** This sets the legal and technical floor for when a disruption crosses the threshold requiring the program's integrated passenger rights protections (rebooking, refunds) to activate. A clear, objective threshold is crucial for automating remedies and governing the backstop fund. Success is measured by the reduction in distributor complaints regarding unresolved passenger rights issues.

**Why It Matters:** Establishing a high threshold means more journeys are declared 'continuous' even with minor delays or service interruptions, simplifying initial technical rollout and minimizing immediate liabilities for carriers. Conversely, setting a very low threshold mandates robust, real-time monitoring and immediate automated remedy provisions, increasing complexity and the projected cost of the passenger-rights backstop fund.

**Strategic Choices:**

1. Define continuity protection only for full end-to-end ticket cancellations exceeding ninety minutes or outright missed connections triggering an alternative carrier booking.
2. Implement a sliding scale of consumer remediation linked directly to the cumulative delay seconds across all segments, requiring automated, real-time micro-compensation events.
3. Delegate the specific threshold determination for each primary corridor to the relevant national regulatory body for the initial two years of operation.

**Trade-Off / Risk:** Delegating the failure threshold determination risks fracturing harmonization goals across the initial corridors, yet local context might prevent an intractable EU-wide standard from being accepted upstream.

**Strategic Connections:**

**Synergy:** This lever strongly supports Defining Liability and Passenger Rights Backstop Scope, as a precise failure threshold determines the triggered events and expected capital draw on the backstop pool.

**Conflict:** Setting overly tight Definition of Continuity-of-Journey Failure Thresholds conflicts with Governing Commercial Terms for Data Exposure and API Access, as accurate real-time monitoring required for fine thresholds demands more complex and immediate data feeds.

**Justification:** *High*, This defines the product's 'service contract' regarding delays. It directly influences customer satisfaction/complaints (a success metric) and drives the required complexity/capitalization of the parallel liability backstop mechanism.

### Decision 14: Pacing the Mandatory API Exposure Timeline
**Lever ID:** `ec6b6f45-c08f-4458-a0ca-cd6806967598`

**The Core Decision:** This lever defines the chronological relationship between validating the technical specifications and mandating their use in live environments by all carriers. It governs the risk-reward trade-off between speed-to-market and robustness, ensuring APIs are stable before distributors rely on them for high-volume transactional sales across core routes.

**Why It Matters:** Advancing the mandatory exposure date closer to the binding standards deadline compresses the crucial window for iterative conformance testing between the two activities. This accelerates overall program timelines but disproportionately burdens smaller operators who lack dedicated internal resources for parallel development streams.

**Strategic Choices:**

1. Set the API exposure deadline eighteen months after binding standards ratification, allowing operators time to build to the final specification before system integration is mandated.
2. Stagger exposure by corridor importance, requiring the busiest corridors (Paris-Amsterdam) to expose stable APIs twelve months before less trafficked routes, using the budget for targeted technical assistance.
3. Require all operators to expose a read-only legacy API based on the draft standard immediately, while the final OSDM-compatible write API is due at the later mandated date.

**Trade-Off / Risk:** Staggering exposure based on corridor volume prioritizes the highest revenue routes but risks creating an unstable, partially compliant system where the market's densest traffic faces the highest integration risk.

**Strategic Connections:**

**Synergy:** Pacing the Mandatory API Exposure Timeline directly enables Incentivizing Early Carrier Participation in the Shared Data Layer by providing clear short- and medium-term goals for achieving initial interoperability milestones.

**Conflict:** A very aggressive Pacing the Mandatory API Exposure Timeline pressures operators, potentially leading them to oppose Governance Structure for Binding vs. Non-Binding Standards Amendments by demanding immediate finality on loose specifications.

**Justification:** *High*, This lever sets the timeline for the critical technical rollout (30 months). It governs the necessary overlap (and resource tension) between finalizing standards and forcing implementation, directly impacting the risk of premature integration.
