# Documents to Create

## Create Document 1: Project Charter (Cross-Border Ticketing Integration)

**ID**: c5da177c-eb6d-4c9b-b213-47bc049843f2

**Description**: The foundational document authorizing the project, defining high-level scope, objectives against the five-year target (40% adoption), initial budget (€1.5B), and success metrics (50% reduction in distributor complaints). Includes alignment with the 'Builder' Scenario.

**Responsible Role Type**: EU Regulatory & Governance Architect

**Primary Template**: PMI Project Charter Template

**Secondary Template**: DG MOVE Program Initiation Template

**Steps to Create**:

- Finalize SMART criteria based on Goal Statement.
- Incorporate key strategic decisions (e.g., phased standardization, Builder scenario choices) as scope baseline.
- Obtain initial internal mandate sign-off from key initiating bodies (implied DG MOVE).
- Establish initial dependency mapping for critical path items (OSDM finalization, Clearing Mechanism capitalization).

**Approval Authorities**: DG MOVE Leadership

**Essential Information**:

- Define the 'vital few' decisions: Pacing Standard Adoption, Data Exposure Terms, Clearing Mechanism Funding, Passenger Rights Liability (Backstop Scope), and Commercial Terms for Operators.
- For each of the 14 identified 'Lever IDs', explicitly document the selected strategic choice based on the 'Builder' Scenario ('Pragmatic Harmonization and Shared Burden').
- For each of the 5 primary strategic decisions selected by the Builder scenario, detail the specific trade-offs (e.g., Speed vs. Robustness, Regulator Control vs. Private Buy-in) that were accepted.
- Integrate justifications for why the selected choices align with the 'realistic' path rather than the 'Pioneer' or 'Consolidator' alternatives, referencing required inputs (e.g., 'Builder' acceptance of phased standardization).
- Document the precise linkages (Synergy/Conflict) between the 5 primary strategic decisions and the 9 secondary decisions that are affected by them.
- Explicitly document the rationale for choosing the Builder scenario, referencing the 'scenarios.md' analysis and the high-level constraints outlined in 'assumptions.md' (e.g., avoiding overly aggressive timelines).

**Risks of Poor Quality**:

- Inconsistency between the documented strategic decisions and the overarching 'Builder' scenario selected, leading to conflicting execution guidance.
- Failure to detail the specific trade-offs accepted results in subsequent decision-makers being unable to resolve inevitable conflicts between levers (e.g., aggressive pacing vs. shared funding).
- Missing explicit connections (Synergy/Conflict) will result in unforeseen negative interactions between critical components like Liability Backstop (Decision 1) and Enforcement Posture (Decision 12).
- If the document only lists the five primary decisions without detailing the justification rooted in the realism constraint, the project might drift back toward the rejected 'Pioneer' scenario.
- Failure to capture all 14 levers, even the secondary ones affected by the primary levers, leads to an incomplete project baseline for governance.

**Worst Case Scenario**: Lack of a unified, clearly justified strategic document results in execution teams reverting to competing internal priorities (e.g., some treating standards as binding immediately while others defer them), causing critical implementation paths to diverge, ultimately leading to non-compliance with the 18-month binding standard deadline and failure to secure necessary cross-border settlement functionality.

**Best Case Scenario**: This document serves as the immutable baseline for all subsequent execution documentation (like the 'project-plan.md' mitigations) and governance meetings, ensuring that all technical requirements, financial models, and enforcement schedules are perfectly aligned with the politically selected 'Pragmatic Harmonization and Shared Burden' strategy, accelerating stakeholder agreement on implementation roadmaps.

**Fallback Alternative Approaches**:

- Conduct an immediate 'Strategy Alignment Workshop' involving the Governance Architect and key DG MOVE/Agency for Railways representatives to ratify the subset of 5 primary decisions, documenting concurrence via annotated minutes.
- If documenting all 14 levers proves too complex initially, create a simplified 'Core Decision Matrix' containing only the 5 chosen levers and their immediate dependencies/conflicts, with a mandatory review slot scheduled within 30 days to incorporate the remaining 9.
- Utilize the final decisions listed in the 'Key Strategic Decisions' section of the Builder Scenario as the mandatory first draft, focusing gap analysis solely on ensuring all conflicts/synergies mentioned in 'strategic_decisions.md' are explicitly resolved or documented.

## Create Document 2: High-Level Infrastructure & Technical Roadmap (OSDM Focus)

**ID**: af5a22aa-682f-4101-867a-066c4c1cda5e

**Description**: A strategic, phased timeline document detailing the relationships between technical milestones: OSDM V0.9 Draft (Month 6), Provisional Binding Status (Month 6), Final Binding Status (Month 18), and Mandatory API Exposure deadline (Month 30). Crucially maps Decision 4/14.

**Responsible Role Type**: Interoperability Standards Lead (OSDM/Technical Governance)

**Primary Template**: Program Milestone Tracking Template

**Secondary Template**: Shift2Rail Technical Implementation Plan Structure

**Steps to Create**:

- Incorporate mandated timelines: Provisional Binding (M6), Final Binding (M18), Exposure Deadline (M30).
- Map dependency chain showing required completion of Accessibility Schema Validation (Decision 9) prerequisite to achieving Final Binding Status (M18).
- Integrate testing phases managed by the Conformance Testing Coordinator across the three physical locations.

**Approval Authorities**: Technical Steering Committee (TSC)

**Essential Information**:

- Detail the exact relationship between Pacing the Binding Standard Adoption Timeline (Decision 4) and Pacing the Mandatory API Exposure Timeline (Decision 14).
- Explicitly define the technical milestone (e.g., what specific API endpoints/transaction types) that must be completed to qualify for 'Provisional Binding Status' at Month 6.
- Specify which Decision points (e.g., Liability Backstop parameters, Commercial Terms structure) must be finalized *before* Final Binding Status (Month 18) can be achieved.
- Map the Dependency Chain, explicitly showing how Accessibility Schema Validation (from Decision 9) prerequisites completion before Final Binding Status (Month 18).
- List the required data exchange standards (OSDM version) relevant to the Mandatory API Exposure Deadline (Month 30).
- Detail the handoff/coordination plan for integrating the results from initial testing phases managed across the three defined physical locations.

**Risks of Poor Quality**:

- Inaccurate timeline mapping will cause major schedule slippage, as mandatory exposure (M30) cannot be met if standards binding (M18) is delayed due to unvalidated dependencies.
- Failure to align technical milestones with financial/liability decisions prevents the Legal/Governance team from securing necessary authorizations for the clearing mechanism float based on technical readiness.
- If the accessibility schema validation dependency is missed or wrongly phased, the project faces regulatory non-compliance despite core ticketing launch (Risk 1/Issue 1).
- Poor dependency mapping leads to incorrect resource allocation for the 35 FTEs dedicated to standards management and testing coordination.

**Worst Case Scenario**: The technical roadmap fails to align standards finalization (M18) with the exposure deadline (M30), resulting in a de facto M30 delay for commercial launch due to dependency failure (especially regarding accessibility integration), thereby missing the 40% adoption target within the five-year limit and leading to significant legislative scrutiny.

**Best Case Scenario**: A perfectly sequenced roadmap enables Provisional Binding (M6) to confirm readiness for the initial two corridors, allowing smooth transition into Final Binding (M18) for core features, thus enabling distributors to integrate confidently and meet the Mandatory API Exposure Deadline (M30), accelerating time-to-market for single through-tickets.

**Fallback Alternative Approaches**:

- If dependency mapping proves intractable, adopt the Phase 1 schedule from the 'Consolidator' scenario—deferring complex dependencies (like Accessibility) entirely past M18, focusing only on the minimum viable ticketing standard required for M30 exposure.
- Request an immediate emergency roadmap review workshop with the TSC and OSDM governance leads to lock down the M6 and M18 boundary definitions, using assumptions (Q2/Q6) as the initial blueprint.
- Develop two parallel roadmap timelines: one adhering strictly to the Builder scenario dependencies, and one optimized for an aggressive, Pioneer-style timeline, to test sensitivity boundaries.

## Create Document 3: Financial Mechanism Design & Capitalization Framework (Builder Scenario)

**ID**: c89a653a-5ae8-42b1-b8d8-88c383dab5d0

**Description**: Framework detailing the transactional fee model (Decision 5) for funding the Clearing Mechanism float, including the formula for the variable transaction fee ('R'), the target €200M operational float, and the operational procedure for accessing the €300M Emergency Float Reserve.

**Responsible Role Type**: Financial Clearing & Settlement Specialist

**Primary Template**: Financial Instrument Design Document

**Secondary Template**: Payment Services Directive (PSD2) Financial Modeling Structure

**Steps to Create**:

- Develop the specific algorithm/formula for the variable transaction fee ('R') based on target cost recovery.
- Define the specific on/off triggers for accessing the €300M Emergency Float Reserve, coordinating with the Risk Manager.
- Draft necessary documentation for engaging third-party guarantor banks for conditional collateral.

**Approval Authorities**: EU Regulatory & Governance Architect; TSC

**Essential Information**:

- Define the specific algorithm/formula for the variable transaction fee ('R') that contributes to the rolling reserve fund, ensuring it aligns with the Builder Scenario's goal of sustainability based on transaction volume.
- Quantify the acceptable minimum reserve level (absolute minimum and trigger point for 150% peak daily obligation) of the rolling reserve fund before accessing the Emergency Float Reserve.
- Detail the exact operational procedure and access criteria for drawing upon the ring-fenced €300 Million Emergency Float Reserve, coordinated with the Risk Manager.
- Draft contractual requirements and procedural workflow for obtaining conditional third-party bank guarantees from participating carriers instead of direct capital injection.
- Model the expected impact of the T+3 settlement reconciliation duration on the required total float (€200M target) under low initial transaction velocity scenarios.

**Risks of Poor Quality**:

- An incorrectly defined transaction fee ('R') results in either market friction (if too high) or failure to self-sustain the clearing mechanism, forcing reliance on public funds unexpectedly (violating Builder Scenario logic).
- Ambiguous triggers for accessing the €300M Emergency Reserve lead to inappropriate fund usage, threatening the solvency of the mechanism during peak operational stress.
- Complex or non-standard documentation for bank guarantees deters carriers from participation or causes significant delays in securing the necessary collateral backing.
- Inaccurate modeling of T+3 impacts could lead to an inadequate target float (€200M or less), causing immediate settlement failures upon system launch.

**Worst Case Scenario**: Delayed initial settlement due to under-capitalization or collateral disputes, forcing the immediate depletion of the €300M Emergency Float Reserve and requiring a politically difficult, high-profile injection of public funds to cover shortfalls, severely undermining trust in the financial backbone of the entire project.

**Best Case Scenario**: A mathematically robust, self-sustaining transactional fee model is implemented, ensuring the €200M float is efficiently capitalized via carrier guarantees, enabling seamless T+3 settlement for 99% of transactions from day one and preserving the public budget for core infrastructure grants.

**Fallback Alternative Approaches**:

- If formula definition stalls, immediately adopt a simpler, fixed percentage fee (e.g., 0.5% per transaction) for a 6-month period, funded entirely by the public budget initially, while the specialized Financial Clearing Specialist develops the precise variable 'R' algorithm.
- If bank guarantee negotiation proves slow, temporarily substitute the required collateral with escrow accounts funded proportionally from the operational budget capacity grants (€900M), with the mandate to replace it with guarantees within 12 months.
- If the specialized modeling proves too complex, revert to the 'Pioneer' scenario's default mechanism—a full public capitalization of the €200M float—and focus this document only on the governance/audit mechanisms for that public fund.

## Create Document 4: Tiered Liability & Passenger Backstop Governance Protocol

**ID**: 23f442a2-8bbb-442a-becc-d3727e3a466e

**Description**: Protocol defining the structure and management of the pooled liability backstop mechanism, based on the chosen 'Collective Insurance Pool' model (revised Decision 3). It must detail the recoupment rules from segment carriers and the scope limit (first/last segment failure).

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Primary Template**: Risk Transfer & Insurance Protocol Template

**Secondary Template**: EU Agency for Railways Financial Backstop Mandate Draft

**Steps to Create**:

- Draft the legal language for the mandatory collective insurance pool structure (Decision 3, Choice 2).
- Define the precise actuarial model used to apportion pool contribution based on journey volume.
- Establish the initial scope limitation (first/last segment failure) for backstop activation.

**Approval Authorities**: Legal Counsel (implied); EU Regulatory & Governance Architect

**Essential Information**:

- Detail the legal language mandating the structure of the collective insurance pool for covering unknown-cause or multi-party failure compensation claims (Based on Decision 3, Choice 2).
- Define the precise, auditable actuarial model used to apportion mandatory pool contribution based on participating carrier's journey volume.
- Explicitly establish the ceiling/limit for liability covered by the EU backstop pool, as defined by the strategic decision: coverage applies only up to the connecting failure between the first and last known segments.
- Outline the complete operational workflow and timeline (e.g., T+X days) for the EU Agency for Railways to recoup covered compensation costs from the segment carrier at fault.
- Specify the trigger conditions and evidence required for a failure scenario to be classified as 'unknown-cause' warranting backstop activation.

**Risks of Poor Quality**:

- Inaccurate assessment of carrier risk exposure leading to inequitable contribution allocations, causing significant political resistance from major operators (SNCF, DB, ÖBB).
- Ambiguous recoupment rules resulting in settlement delays (violating T+3 assumption) and draining the pool's immediate liquidity, jeopardizing consumer trust metrics.
- Unclear scope limitation resulting in invalid claims against the backstop, leading to unexpected financial burden on the public budget (Risk 3).
- A weak protocol undermines the perceived strength of the Passenger Rights framework, failing to incentivize carrier compliance with data requirements (conflicts with Decision 12).

**Worst Case Scenario**: The poorly defined protocol triggers a solvency crisis in the collective insurance pool due to over-payouts on non-covered claims or protracted, complex recoupment disputes with major carriers, forcing an emergency, non-budgeted capital injection (Risk 3 realization) and undermining the core passenger confidence target.

**Best Case Scenario**: A legally robust, transparent protocol enables maximum operational efficiency for the backstop, swiftly compensating passengers within stated recovery parameters, thereby strengthening stakeholder confidence in the shared financial mechanism and supporting the overall consumer trust objective.

**Fallback Alternative Approaches**:

- Adopt the Distributor-Assumes-All-Liability model (Decision 3, Choice 3) temporarily until the complexities of pooling and recoupment can be legally finalized, shifting immediate risk management burden.
- Delegate initial operational scope to the EU Agency for Railways to manage pilot pool liquidity using a simplified, flat-rate carrier contribution derived from the expected cost of the 'Tiered Liability Model' (Decision 3, Choice 1) as a proxy.
- Utilize the 'Risk Transfer & Insurance Protocol Template' entirely, focusing only on defining the maximum acceptable loss threshold and deferring the complex recoupment workflow logic until post-provisional binding standards (Month 6).

## Create Document 5: OSDM Data Exposure Commercial Terms & Cost Recovery Policy

**ID**: f54ce20c-d35d-46a8-b64f-1b81d02a7a02

**Description**: Policy document establishing the non-discriminatory capped royalty structure for API access (Decision 2). It must define the precise methodology for auditing operator IT maintenance costs attributable to OSDM maintenance (5% cap constraint).

**Responsible Role Type**: Digital Distributor & Market Adoption Strategist

**Primary Template**: Commercial Access Policy Framework

**Secondary Template**: Cost Allocation Methodology Report Standard

**Steps to Create**:

- Define the specific cost categories considered 'attributable IT O&M expenditure' for royalty calculation.
- Develop the mandatory annual reporting template for operators to submit these audited costs.
- Establish the review cycle and escalation path (via Rail Operator Liaison) for disputes over cost attribution.

**Approval Authorities**: Regulatory Economist (Implied Review); TSC

**Essential Information**:

- Define the specific cost categories considered 'attributable IT O&M expenditure' for royalty calculation, based on the assumption that royalties are capped at 5% of this expenditure.
- Detail the standardized, non-discriminatory commercial access royalty structure, specifying the exact transaction-volume-based rate or method.
- Develop the mandatory annual reporting template for operators to submit their audited OSDM maintenance costs for regulatory review.
- Establish the precise regulatory review cycle, escalation path, and appeal process for disputes over cost attribution, aligning with TSC oversight.
- Confirm mechanism for regulator oversight ensuring that access fees strictly adhere to 'cost-recovery' principles, avoiding profit generation.
- Integrate language confirming that failure to comply with cost reporting will result in temporary barring from the centralized clearing settlement mechanism (as per Decision 2, Choice 3).

**Risks of Poor Quality**:

- If cost categories are ill-defined, operators may inflate indirect IT costs, leading to unfair/excessive royalties imposed on distributors, increasing market entry barriers.
- Lack of a clear, auditable reporting template prevents verification of the 5% cost-recovery cap, risking regulatory non-compliance and legal challenges to the commercial fairness principle.
- Ambiguous dispute resolution mechanics will slow down commercial agreement finalization, delaying distributor integration and hindering the 40% through-ticket adoption target.
- If the structure isn't non-discriminatory, it undermines the mandate for competitive market structure, concentrating power with incumbents.

**Worst Case Scenario**: The policy is successfully challenged by major national operators claiming unfair cost auditing or discriminatory application, forcing an immediate re-negotiation of the entire API access framework, causing a minimum 6-month delay to distributor onboarding and jeopardizing market uptake goals.

**Best Case Scenario**: The clearly defined, auditable, capped cost-recovery mechanism is swiftly adopted, providing regulatory certainty, maximizing distributor confidence due to low, predictable entry costs, and accelerating market penetration necessary to meet the 40% single through-ticket goal by encouraging rapid integration with OSDM APIs.

**Fallback Alternative Approaches**:

- Adopt Decision 2, Choice 2 initially: Offer API access free for two years using the public budget (€1.5B fund) to maximize penetration, postponing the complex cost-recovery audit requirement until after the initial testing phase.
- Develop a simplified template based only on direct external hosting costs related to OSDM endpoints, deferring complex internal IT cost attribution until the reference distributor (Decision 11) establishes a baseline operational maintenance budget.
- Engage external IT auditing experts immediately to draft a preliminary, legally robust audit methodology draft for immediate review by the TSC and primary stakeholders.

## Create Document 6: Enforcement & Non-Compliance Action Matrix (Three Strikes)

**ID**: 1a111cf9-bbe6-49f5-8529-707fa0dd4d78

**Description**: Detailed matrix defining the operational triggers for the 'Three Strikes' enforcement posture (Decision 12). Specifies the measurable thresholds (T+5 latency breaches, semantic error rates, downtime) that constitute a 'strike' for SNCF, DB, and ÖBB.

**Responsible Role Type**: Program Risk Manager & Contingency Coordinator

**Primary Template**: Regulatory Compliance Sanctioning Matrix

**Secondary Template**: IT Failure Reporting Standard

**Steps to Create**:

- Collaborate with the Interoperability Standards Lead to quantify specific technical failure criteria equivalent to a 'strike'.
- Map the consequences (suspension of through-ticketing sales) to the specific IT failure type/duration (Risk 2 mitigation).
- Formalize the notification procedures delivered by the Rail Operator Liaison.

**Approval Authorities**: EU Regulatory & Governance Architect; EU Agency for Railways

**Essential Information**:

- Define the precise, measurable technical criteria for a 'strike' related to OSDM API failure (e.g., T+5 latency breach count, Semantic Error Rate threshold, total downtime percentage over a quarter).
- Detail the specific consequences (the 'action') associated with Strike 1, Strike 2, and Strike 3, specifically stating which functionalities (e.g., selling new through-tickets, handling refunds) are suspended for the non-compliant operator (SNCF, DB, ÖBB).
- Establish the formal, documented process for notifying the targeted operator (SNCF, DB, ÖBB) upon the issuance of each strike, including response deadlines (e.g., 7-day remediation window).
- Identify the specific responsible entity (from the Program Risk Manager team) for logging, verifying, and reporting the data required to trigger a strike.
- Confirm the necessary legal alignment (referenced from DG MOVE) that validates the right to suspend commercial sales against sovereign rail operators.

**Risks of Poor Quality**:

- Ambiguous strike criteria will lead to challenges from compliant operators claiming unfair targeting, stalling enforcement.
- Lack of clear, documented consequence mapping will result in weak political pressure, allowing major operators to ignore deadlines (Exacerbates Risk 1).
- Ineffective notification procedures will invalidate enforcement actions on legal grounds, rendering Decision 12 moot and failing to compel timely IT integration.
- Inaccurate operational data logging will expose the Program Risk Manager team to high legal risk and expose the project to significant delays if enforcement stalls.

**Worst Case Scenario**: Ambiguous or poorly documented enforcement triggers allow the top three incumbent operators (SNCF, DB, ÖBB) to successfully lobby DG MOVE to halt the 'Three Strikes' suspension mechanism within the first year, leading to a 6-12 month delay in data layer stability and effectively neutralizing the primary behavioral lever required to meet the 30-month API exposure deadline.

**Best Case Scenario**: The clearly defined, legally sound 'Three Strikes' matrix enables decisive action against non-compliant operators (SNCF, DB, ÖBB). This predictability forces rapid investment in OSDM integration, ensuring the stability of the real-time data layer (Risk 2 mitigation) and achieving binding compliance on core corridors by the 18-month deadline, directly enabling the clearing mechanism stability.

**Fallback Alternative Approaches**:

- If technical quantification of strikes proves too slow (i.e., definitive metrics cannot be agreed by Interoperability Lead), adopt a pre-approved 'Compliance Scorecard' based on subjective regulatory audit ratings for the first 12 months, pending technical metric finalization.
- If DG MOVE approval on sales suspension is delayed, immediately substitute the enforcement action with ring-fencing capacity building funds (€900M budget) from the non-compliant operator until satisfactory audit completion.
- Utilize the European Agency for Railways to issue an immediate, non-appealable technical directive requiring alignment with the current OSDM 'Provisional Binding Status' (Month 6) for the targeted carriers, shifting the legal burden to infrastructure adherence rather than commercial suspension.

## Create Document 7: Accessibility Reservation Data Specification Requirements (PRM Integration)

**ID**: b55c7121-fd16-4012-805c-a2d2f1812801

**Description**: The technical requirements document detailing the mandatory OSDM data fields and schemas required for PRM booking and assistance notification, designed to align with the 'most restrictive national requirements' (Decision 9, Choice 1) required for Provisional Binding Status.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Primary Template**: OSDM Data Specification Addendum (Non-Core/Equity)

**Secondary Template**: Accessibility Directive Compliance Checklist

**Steps to Create**:

- Define the mandatory data fields necessary to signal assistance needs and book limited accessibility inventory.
- Map these requirements directly into the OSDM iteration planned for Provisional Binding release (Month 6).
- Develop the validation criteria for conformance testing teams.

**Approval Authorities**: Technical Steering Committee (TSC); Disability Advocacy Group Liaison

**Essential Information**:

- Detail the mandatory OSDM data fields and schemas required for Persons with Reduced Mobility (PRM) booking and assistance notification.
- Explicitly define the data requirements to align with the 'most restrictive national requirements' chosen under Decision 9, Choice 1.
- Specify the interoperability requirements necessary to support 'seamlessness of multi-operator PRM bookings' across the initial four corridors.
- List the validation criteria necessary for conformance testing teams to verify compliance against the established technical standard (to be integrated at Month 6).
- Identify the specific sections or data elements that are intentionally deferred for two-way resource deployment coordination until after the initial binding period finishes at Month 18, referencing Decision 9, Choice 2 constraints.

**Risks of Poor Quality**:

- Failure to capture the most restrictive national requirements will lead to immediate regulatory non-compliance regarding accessibility equity upon launch.
- Inaccurate mapping into the OSDM schema will cause PRM booking failures, leading to operational chaos, customer complaints against distributors, and rapid erosion of passenger trust.
- Vague validation criteria will lead to subjective conformance testing, resulting in an unstable, partially compliant data layer and creating conflict with the 'three strikes' enforcement posture.
- If the requirement for unified data exchange is misunderstood, it will necessitate costly rework post-launch when attempting to integrate fringe modes later (Risk 8 mitigation failure).

**Worst Case Scenario**: The document imposes a flawed or incomplete data standard that fails to meet mandatory EU equity regulations, resulting in immediate legal challenges against the Commission, suspension of the core ticketing system due to regulatory halt on accessibility compliance, and severe reputational damage to the entire regulatory project.

**Best Case Scenario**: The specification clearly dictates the highly restrictive, yet compliant, data schema required at Month 6, enabling the Technical Steering Committee to ratify the standard early, thus satisfying non-negotiable regulatory mandates (Decision 9) and ensuring that core ticketing and accessibility integration proceed in lockstep, mitigating Risk 4.

**Fallback Alternative Approaches**:

- Immediately revert to a simplified signal/flag mechanism (paraphrased from Decision 9, Choice 2) based only on mandatory assistance notification codes, deferring complex inventory booking until V1.1 is approved after the initial 18-month stabilization period.
- Engage the Disability Advocacy Group Liaison and a Subject Matter Expert from the most restrictive national rail operator in an intensive, three-day standards workshop to rapidly define and lock down the necessary schema placeholders for Provisional Binding status.
- If schema definition stalls, publish a 'Minimum Viable Representation' (MVR) document listing required fields only, deferring the detailed schema documentation (mapping/validation) until after the feasibility testing at Month 12.


# Documents to Find

## Find Document 1: Existing EU Legal Text on Digital Booking and Ticketing Services for Rail

**ID**: 9acbebc0-6f87-4e9c-8209-eb6ed94d973d

**Description**: The full text of the proposed or final EU Regulation governing the project scope, essential for defining regulatory constraints, success criteria, and the legal basis for enforcement and standardization.

**Recency Requirement**: Must be the most current official legislative text or draft.

**Responsible Role Type**: EU Regulatory & Governance Architect

**Steps to Find**:

- Search the European Parliament and Council official publication websites (EUR-Lex) for the latest legislative proposal draft.
- Consult DG MOVE documentation archives for internal regulatory summaries.

**Access Difficulty**: Easy

**Essential Information**:

- Identify the precise, mandated definition for 'continuity-of-journey failure' that triggers passenger rights activation (Decision 13).
- Extract the final, ratified text imposing the **binding** adoption timeline for core OSDM data exchange and transaction processing standards (Decision 4).
- Detail the legal language establishing the non-discriminatory, cost-recovery cap for API access fees overseen by regulators (Decision 2).
- List the exact regulatory leverage points permitting the suspension of a carrier's through-ticket sales capability for non-compliance (Decision 12).
- Define the official scope and limits of the EU backstop mechanism concerning which segments of a denied journey it must cover (Decision 1).
- Specify the legal mandate and governance structure defining which stakeholder groups (e.g., incumbents vs. distributors) have voting power on post-launch standard amendments (Decision 10).

**Risks of Poor Quality**:

- Failure to incorporate critical regulatory limitations (e.g., on the EU backstop scope) leads to misallocation of operational budget or over-promising consumer benefits.
- An outdated or incorrect binding standard timeline (Decision 4) results in investment freezes based on obsolete technical pathways, necessitating rework at month 18.
- Misinterpreting the terms for mandated cost-recovery royalties (Decision 2) opens the project to legal challenges from operators regarding fair compensation for data provision.
- Ambiguity in mandatory enforcement severity (Decision 12) leads to weak initial posture, encouraging widespread non-compliance from major carriers (SNCF, DB, ÖBB).

**Worst Case Scenario**: The project proceeds based on outdated or misread legal constraints, leading to immediate regulatory non-compliance on passenger rights equity or technical standards adherence upon mandatory deadline, resulting in the revocation of the €1.5B budget authorization and subsequent project collapse.

**Best Case Scenario**: The project is launched with technical requirements and financial models built precisely upon the ratified legal baseline, leading to immediate, auditable compliance by pilot operators and securing necessary authorization for the centralized financial clearing mechanism.

**Fallback Alternative Approaches**:

- Initiate an emergency legal task force comprising external EU regulatory counsel to conduct a rapid, high-assurance review of the top 5 most interconnected decisions (1, 2, 4, 10, 12).
- Require the DG MOVE Legal Counsel to formally sign off on the interpretation of all enforcement and liability clauses before committing budget beyond the governance setup phase (Decision 10).
- If binding timeline specifications are unclear, prioritize physical implementation (Testing Locations 2 & 3) using the provisional standards (Month 6 target) while delaying commitment for full capitalization of the clearing mechanism (Decision 5).

## Find Document 2: OSDM Technical Specification Documentation (Current Version)

**ID**: 957008dd-8084-40f4-8c5e-cd0ed419a83a

**Description**: The foundational technical documents outlining the current OSDM API structure, data dictionaries, semantic definitions, and any prior technical governance models used for standard amendments.

**Recency Requirement**: Most recent stable release candidate available.

**Responsible Role Type**: Interoperability Standards Lead (OSDM/Technical Governance)

**Steps to Find**:

- Obtain documentation from the European Union Agency for Railways (ERA) or the associated Technical Body.
- Search Shift2Rail/INNOWAI technical repositories for foundational standards related to digital operations.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the precise version number and release date of the current stable OSDM API structure and data dictionaries.
- Detail the complete set of semantic definitions and payloads required for core transaction processing (booking, cancellation, settlement feed).
- Extract the established governance model for technical standard amendments (relevant to Decision 10), specifically identifying the entities responsible for initial draft and final ratification.
- List all pre-existing technical governance protocols or prior models referenced or superseded by the current version that affect Decision 4 (Pacing Timeline).

**Risks of Poor Quality**:

- Using an outdated API specification leads to immediate integration failure when attempting to generate binding OSDM V1.0 compliant feeds, causing critical delay to the 18-month binding standard deadline.
- Inaccurate or incomplete semantic definitions lead to data mismatch errors in the interoperability layer (Risk 2), resulting in unstable real-time data feeds and failed passenger rights activations.
- Misunderstanding the amendment governance structure delays necessary post-launch technical pivots (Risk 5), locking the system into suboptimal configurations.
- Failure to align integration work with the *current* version forces expensive rework across all operator IT landscapes, creating resistance to enforcement (Risk 1).

**Worst Case Scenario**: Adopting a specification that is functionally obsolete or incomplete will result in all national operators building incompatible systems (Risk 2), forcing a complete halt to the binding standardization effort at the 18-month mark and delaying the core cross-border ticketing launch by 12+ months.

**Best Case Scenario**: Access to the definitive, latest standard immediately harmonizes stakeholder understanding of the technical baseline, allowing the Interoperability Standards Lead to finalize implementation plans, secure commitment from the three primary auditors (SNCF, DB, ÖBB), and accurately plan necessary capacity building grants.

**Fallback Alternative Approaches**:

- Initiate immediate, high-priority joint workshop with the EU Agency for Railways and the technical leads from SNCF/DB to cross-validate the three most critical OSDM messages against manual reconciliation results.
- Immediately mandate the 35 FTE Governance Team to produce a formal 'Delta Report' comparing the presumed current standard against the specification documents available internally across the two initial physical testing locations.
- If internal access fails, formally request DG MOVE utilize its regulatory oversight to compel the ERA/Technical Body to deliver the definitive documentation within 7 days, framed as a prerequisite for executing Decision 12 (Enforcement).

## Find Document 3: PSD2 Implementation Guidelines and Payment Cost Benchmarks

**ID**: b645a8e7-3c35-4bf9-8944-c03f2a716554

**Description**: Official specifications, cost recovery models, and settlement speed data related to the European Banking Authority's (EBA) implementation of payment standards (PSD2/SEPA), used to benchmark the clearing mechanism design (Decision 5).

**Recency Requirement**: Documents detailing T+1/T+3 settlement finality and cost recovery mechanics.

**Responsible Role Type**: Financial Clearing & Settlement Specialist

**Steps to Find**:

- Search the European Central Bank (ECB) and European Banking Authority (EBA) portals for detailed technical specifications and RTS documents.
- Review EPC working papers on intra-zone transfer cost structures.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact permissible settlement finality benchmarks (T+1, T+3) specified by EBA/EPC for commercial transfers, as this directly informs the viability of the T+3 assumption for the clearing mechanism.
- List the regulator-approved, non-discriminatory cost recovery benchmarks defined for PSD2/SEPA payment processing, specifically noting any caps or tiered structures for transaction-based fees.
- Detail the documented liquidity and collateral management procedures outlined for capitalizing the reserve/float (€200M assumed) within the clearing structure, referencing corresponding EBA guidelines.
- Provide concrete data on *actual* average intra-bank and inter-bank transfer costs observed under the current SEPA schemes to validate the assumption that a transactional fee model (Decision 5) is sustainable.

**Risks of Poor Quality**:

- Inaccurate cost benchmarking leads to under-capitalization of the project's clearing mechanism float, forcing reliance on the €300M emergency reserve sooner than planned (Risk 3).
- Misunderstanding settlement finality rules (T+3 vs. T+1 mandates) results in the designed clearing mechanism failing to meet the critical T+3 reconciliation goal, eroding carrier trust.
- Unclear cost recovery models result in the project either overcharging distributors (violating Decision 2 Commercial Terms) or under-charging, leading to disputes during the annual audit (Assumption Q3).

**Worst Case Scenario**: Adopting a flawed financial benchmark causes the clearing mechanism to experience a catastrophic capital shortfall during peak operations, leading to immediate suspension of single-payment settlement and triggering a political crisis requiring the EU budget to absorb hundreds of millions in working capital support.

**Best Case Scenario**: The document validates that industry standards allow for the project's proposed transactional fee model to be sustainable and compliant with T+3 settlement, confirming the viability of the Builder Scenario's financial dependency and reducing perceived operational solvency risk.

**Fallback Alternative Approaches**:

- Initiate targeted engagement with the EPC/EBA liaison officers to secure ad-hoc clarification sessions regarding specific operational transaction benchmarks (T+3 fidelity).
- Commission an independent forensic cost analysis comparing existing legacy inter-carrier settlement costs versus projected PSD2 transaction costs to establish a conservative, defensible internal cost floor.
- Prioritize the establishment of the €300M 'Emergency Float Reserve' buffer immediately, assuming the worst-case cost structure until definitive EBA documentation is secured.

## Find Document 4: EU Directive on Accessibility Requirements for Transport Products - National Transposition Status Reports

**ID**: 8ae75179-e77b-4612-9deb-e70ea44f8f7d

**Description**: Official documentation detailing the status of national transposition of EU accessibility laws relevant to booking/assistance services, crucial for defining the 'most restrictive requirement' for PRM data (Decision 9).

**Recency Requirement**: Current status reports or comparative analysis publications from DG MOVE/ERA.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Search DG MOVE public consultations or reports on Directive 2019/882 implementation in rail.
- Contact relevant disability advocacy liaison groups for their assessment of current national booking system gaps.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact, legally binding transposition status (Date of Adoption, Scope of Coverage) for EU accessibility laws relevant to booking across all primary participating nations (SNCF, DB, ÖBB, etc.).
- Detail the specific national requirements that represent the 'most restrictive' criteria for Persons with Reduced Mobility (PRM) data points (e.g., required lead time for assistance notification, detailed specifications for accessible seating inventory data).
- Quantify the gap between the current, most restrictive operational requirement and the proposed OSDM V1.0 accessibility schema requirements to determine necessary modification effort.
- List all national requirements that conflict or exceed the proposed OSDM accessibility schema to inform the 'most restrictive' standard adopted per Decision 9.

**Risks of Poor Quality**:

- Inaccurate definition of the 'most restrictive' requirement will lead to the adoption of an OSDM accessibility schema that is non-compliant in certain high-volume jurisdictions (Risk of non-compliance on equity grounds).
- Adopting an overly lenient standard (if transposition status is outdated) will fail to satisfy regulatory mandates, risking fines or legal challenge against the program's core operation.
- Failure to accurately map integration needs will result in the Accessibility Reservations Infrastructure (Decision 9) being built incorrectly, forcing costly, late-stage rework that delays the 18-month binding standard deadline.

**Worst Case Scenario**: The developed unified PRM booking system fails compliance audits in key jurisdictions (e.g., Germany or France) immediately post-launch (Month 18-30), leading to regulatory fines (Risk Issue 1 mitigation failure) and requiring immediate, resource-intensive decoupling or emergency fixes that halt progress on other critical integration streams.

**Best Case Scenario**: Precise documentation enables a seamless integration of the 'most restrictive' PRM requirements into the OSDM schema at the 18-month mark, ensuring 100% regulatory equity compliance from the launch of core ticketing, thus maximizing the value proposition for users with accessibility needs and avoiding remediation costs entirely.

**Fallback Alternative Approaches**:

- Initiate direct bilateral consultations with the National Competent Authorities (NCAs) of SNCF, DB, and ÖBB to obtain the most recent, internal technical manuals regarding PRM service provisioning, bypassing potentially outdated public reports.
- Engage the Passenger Rights Advocacy Stakeholder Group to conduct a rapid gap analysis comparing their observed system limitations against the theoretical scope of the EU Directive.
- If transposition data is unobtainable, default the OSDM requirement to the single highest defined lead-time (e.g., 72 hours) for all assistance requests until official validation confirms a lower, harmonized baseline.

## Find Document 5: National Rail Operator IT Cost Attribution Policies (SNCF, DB, ÖBB)

**ID**: 77bc3d8d-e987-43fb-b466-68658e0dd70d

**Description**: Internal or publicly documented guidelines used by primary incumbent operators (SNCF, DB, ÖBB) for attributing maintenance and operational expenditure (OPEX) related to their internal IT systems, required to verify fair cost-recovery royalties (Decision 2).

**Recency Requirement**: Most recent publicly stated accounting standards or disclosures.

**Responsible Role Type**: Rail Operator Liaison & Integration Manager

**Steps to Find**:

- Search annual financial reports or sustainability/IT strategic documents published by SNCF, DB, and ÖBB.
- Contact the CER for consolidated, non-public datasets detailing typical IT cost allocation methodologies in rail.

**Access Difficulty**: Hard

**Essential Information**:

- Obtain the specific Opex/IT maintenance cost attribution policies used by SNCF, Deutsche Bahn (DB), and ÖBB for systems supporting data provisioning (API endpoints).
- Identify the internal methodology or formula used by each operator to allocate costs (e.g., direct assignment vs. rolling overhead allocation) related to maintaining the OSDM-compatible API infrastructure.
- Determine the documented accounting practice for isolating 'IT operational costs attributable to OSDM data maintenance' to verify the 5% cost-recovery royalty cap (Assumption Q3).
- Verify if the reported metrics align with the most recent publicly stated accounting standards or regulatory disclosures.

**Risks of Poor Quality**:

- Inability to accurately audit compliance with the mandated 5% cost-recovery royalty cap for API access, potentially leading to overcharging commercial distributors (Decision 2).
- If attribution policies are opaque or use inflated indirect costs, the project leadership cannot confidently defend the royalty structure against distributor challenges (Risk 7).
- Failure to establish a baseline cost structure prevents effective negotiation or enforcement against the primary initial audit participants (SNCF, DB, ÖBB) (Assumption Q4).
- Regulatory dispute regarding the fairness of data access billing, potentially eroding regulator oversight of commercial terms.

**Worst Case Scenario**: Carriers successfully inflate IT cost allocations, resulting in excessive royalties charged to distributors; this undermines the commitment to low barriers to entry, directly jeopardizing the 40% single through-ticket adoption target due to unfair commercial terms.

**Best Case Scenario**: Clear, verifiable cost attribution policies are secured for SNCF, DB, and ÖBB, allowing immediate, credible application of the regulated 5% cost-recovery royalty cap, which establishes commercial governance certainty and accelerates distributor confidence in the shared data layer.

**Fallback Alternative Approaches**:

- Initiate a mandatory, regulator-led cost audit procedure (using the EU Agency for Railways technical team) on the three primary operators to establish a standardized, externally benchmarked cost allocation methodology for OSDM maintenance.
- Temporarily implement a standardized, fixed-rate transactional fee for data access (as an alternative to cost-recovery) based on a benchmark derived from publicly available telecom API usage rates, pending receipt of audited operator data.
- Require all three major affected operators to submit their full operational expenditure reports related to IT modernization for centralized analysis by the governance body's dedicated financial team.

## Find Document 6: European Consumer Organization (BEUC) Position Papers on Through-Ticketing Friction

**ID**: 928dfd4f-d2b7-4a87-83ee-5cf8696e14cf

**Description**: Existing analysis from consumer advocacy groups detailing specific points of friction passengers currently face booking cross-border journeys (e.g., refund complexity, accessibility difficulties), essential for validating the 90-minute threshold (Decision 13) and prioritizing enhancements.

**Recency Requirement**: Documents focusing on rail/transport published within the last 3 years.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Search the official BEUC website and publications portal for transport sector reports.
- Cross-reference findings with official reports from national consumer protection bodies.

**Access Difficulty**: Medium

**Essential Information**:

- List specific instances of customer friction documented by BEUC related to cross-border rail refunds/rebooking complexity.
- Quantify the observed difficulty (e.g., average time taken, number of contacts required) for passengers encountering journey failures under current national frameworks.
- Detail specific pain points identified regarding accessibility booking integration (PRM) that must be addressed by Decision 9.
- Identify specific findings that directly inform or challenge the preliminary '90-minute continuity failure threshold' (Decision 13).

**Risks of Poor Quality**:

- Inaccurate characterization of current passenger friction leads to setting the continuity threshold (Decision 13) too high, resulting in consumer mistrust and failure to meet the goal of a 50% reduction in complaints.
- If accessibility issues are underrepresented, the framework may launch with insufficient harmonization on PRM booking (Decision 9), triggering regulatory conflict immediately.
- Failure to incorporate binding evidence from BEUC allows incumbent operators to successfully lobby for weaker liability rules (Decision 3) or less stringent enforcement (Decision 12).

**Worst Case Scenario**: The project launches with a continuity failure threshold (Decision 13) that is too lenient, leading to widespread public backlash, widespread regulatory intervention against the EU Agency for Railways, and jeopardizing the overall goal of achieving consumer trust necessary for the 40% adoption target.

**Best Case Scenario**: Precise quantification of current booking/refund friction allows the team to calibrate Decision 13 (90-minute threshold) optimally for maximum consumer benefit while managing backstop liability costs, leading to immediate positive media coverage and strengthening stakeholder support for the program's equity goals.

**Fallback Alternative Approaches**:

- Initiate targeted, structured interviews with 5-10 independent travel distributors known for high cross-border volume to generate anecdotal evidence on current friction points.
- Commission a rapid, targeted analysis focusing solely on comparing refund/rebooking SLAs between the primary pilot carriers (SNCF, DB, ÖBB) for recent multi-carrier failures.
- Engage Passenger Rights Advocacy stakeholders directly to draft an 'evidence summary statement' enumerating required minimum functionality for Decision 13 and Decision 9 compliance.

## Find Document 7: Benchmark Data on Real-Time Latency for Current Rail Operations (T+5 Data)

**ID**: b23b2f5c-ab17-4d0f-b4b1-5c70e912b10c

**Description**: Existing internal performance data or benchmark studies from major operators (or ERA studies) showing the typical end-to-end latency performance for current disruption notification systems, necessary to assess the feasibility of the mandated T+5 minute benchmark.

**Recency Requirement**: Data capturing performance under peak operational load, last 1-2 years.

**Responsible Role Type**: Cross-Corridor Conformance Testing Coordinator

**Steps to Find**:

- Liaise with the Interoperability team to request operational telemetry data shared previously via Shift2Rail testing programs.
- Engage IT consulting firms who have worked on ERTMS integration for proprietary performance insights.

**Access Difficulty**: Hard

**Essential Information**:

- Quantify the typical end-to-end latency (in minutes) for current disruption notification systems across major operators (SNCF, DB, ÖBB) for events leading to potential passenger rights activation.
- Identify the operational load factor under which the benchmark data was collected (e.g., typical vs. peak holiday traffic).
- List specific studies or internal reports (e.g., Shift2Rail telemetry output) confirming the source and date of the latency figures.
- Detail the gap between the current recorded maximum latency and the mandated T+5 minute benchmark, quantifying the required technical improvement per segment.

**Risks of Poor Quality**:

- Inaccurate benchmark data (e.g., using off-peak figures) leads to an overly optimistic assessment of the T+5 minute target feasibility, masking severe integration challenges (Risk 2).
- Using outdated data (pre-COVID/pre-2022 capacity changes) results in mandating a T+5 requirement that is technically impossible given current infrastructure limits.
- If the data is internal/proprietary and lacks comprehensive coverage (e.g., missing ÖBB), the enforcement posture against non-compliant operators will lack foundational evidence.
- Failure to verify the source leads to reliance on unverified metrics, undermining the credibility of the entire Conformance Testing Coordination effort.

**Worst Case Scenario**: Adopting an overly optimistic benchmark leads to setting the provisional binding standard (Month 6) and mandatory T+5 requirement based on false premises, resulting in mass technical failure during the main API rollout (Month 30), jeopardizing the entire data layer stability and leading to severe enforcement backlash (Risk 1 and Risk 2).

**Best Case Scenario**: High-quality, recent data confirms that the T+5 latency benchmark is achievable through focused technical assistance (Decision 6/Capacity Budget), allowing the Conformance Testing Coordinator to confidently proceed with setting aggressive, but achievable, operational readiness milestones, building initial trust with stakeholders.

**Fallback Alternative Approaches**:

- Initiate immediate, narrowly scoped technical spikes (PoCs) with DB and SNCF focusing *only* on measuring current real-time path latency for a predefined disruption scenario (e.g., signal failure).

- Engage the EU Agency for Railways to commission a rapid, targeted performance audit on the two pilot corridors, focusing specifically on the data chain between disruption detection and current central system notification.
- Temporarily adopt the most conservative (slowest) available performance metric from any primary participant (SNCF, DB, ÖBB) as the assumed baseline to protect the T+5 requirement from being overly optimistic, thereby forcing a safer implementation path, even if it stresses the Governance structure (Decision 10).

## Find Document 8: National Rail Discount/Loyalty Scheme Rule Books (Top 3 Volume Schemes)

**ID**: 32724029-5c61-4e66-9430-279c738aa2e3

**Description**: The complete legal rulebooks for the highest-volume national reduction cards (e.g., BahnCard, Carte Avantage), required to understand the complexity of converting monetary value or functionality for cross-border recognition (Decision 8).

**Recency Requirement**: Current, official rulebooks applicable as of the current year.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Visit the official websites of the major operators (SNCF, DB, ÖBB) and navigate their loyalty/discount sections.
- Consult with the Rail Operator Liaison to obtain definitive, consolidated handbooks if public versions are incomplete.

**Access Difficulty**: Medium

**Essential Information**:

- List the exact, specific monetary value or percentage discount applied by Decision 8's chosen strategy (Strategy 1, 2, or 3) on the base, full-fare ticket price for the top three national reduction cards (BahnCard, Carte Avantage, etc.).
- Detail the operational steps required for a distributor to verify if a customer's reduction card eligibility translates into a correctly applied discount via the new clearing mechanism for the first cross-border transaction.
- Quantify the revenue differential (in Euros/Transaction) between recognizing the full national loyalty benefit versus applying the temporary EU 'Cross-Border Discount Voucher' substitute, as this informs the risk analysis for Decision 8.
- Identify the specific data fields within the OSDM standard that must be populated by the carrier to confirm the validity status of the recognized discount card, ensuring compliance with harmonization efforts (Decision 8 synergy).

**Risks of Poor Quality**:

- Implementing the wrong conversion mechanism (e.g., using the substitute voucher instead of direct rule reconciliation) leads to over- or under-compensation, resulting in immediate financial disputes with national operators.
- Inaccurate understanding of complex national scheme rules (e.g., blackout dates, eligibility co-pays) causes the system to reject valid loyalty claims, leading to the high consumer complaint target miss (50% reduction goal failure).
- Failure to secure current rulebooks prevents accurate technical mapping, resulting in the adoption of an outdated schema that is immediately incompatible when national rules change.

**Worst Case Scenario**: If the rulebooks are inaccessible or misunderstood, the project defaults to the most difficult (but rejected) strategy of full, immediate, complex harmonization, leading to a resource drain, a 6-month delay in core ticketing launch to resolve discount conflicts, and alienating loyal customer bases, thereby jeopardizing the 40% adoption target.

**Best Case Scenario**: Precise knowledge of the top three schemes allows the immediate, high-quality implementation of the chosen Builder strategy (likely substitution or simple monetary application), maximizing immediate customer value realization, directly supporting the synergy with data exposure terms, and accelerating initial distributor adoption by maximizing the value proposition for existing loyal customers.

**Fallback Alternative Approaches**:

- Immediately implement the fallback Strategic Choice 2: Temporarily substitute all national discount cards with a single, standardized EU 'Cross-Border Discount Voucher' distributed automatically, while policy analysis continues in the background.
- Engage the National Regulatory Bodies (NRBs) for the top three operators (DB, SNCF, ÖBB) via the mandated National Competent Authorities channel to demand expedited delivery of the specific cross-border conversion logic required for system integration.
- Isolate the accessibility harmonization work (Decision 9) and allocate dedicated integration FTEs to it, ensuring the discount decision (Decision 8) does not block the delivery of mandatory equity compliance.