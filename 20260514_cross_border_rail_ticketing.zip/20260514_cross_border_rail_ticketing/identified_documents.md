
## Documents to Create

### 1. Project Charter (Cross-Border Ticketing Integration)

**ID:** c5da177c-eb6d-4c9b-b213-47bc049843f2

**Description:** The foundational document authorizing the project, defining high-level scope, objectives against the five-year target (40% adoption), initial budget (€1.5B), and success metrics (50% reduction in distributor complaints). Includes alignment with the 'Builder' Scenario.

**Responsible Role Type:** EU Regulatory & Governance Architect

**Primary Template:** PMI Project Charter Template

**Secondary Template:** DG MOVE Program Initiation Template

**Steps:**

- Finalize SMART criteria based on Goal Statement.
- Incorporate key strategic decisions (e.g., phased standardization, Builder scenario choices) as scope baseline.
- Obtain initial internal mandate sign-off from key initiating bodies (implied DG MOVE).
- Establish initial dependency mapping for critical path items (OSDM finalization, Clearing Mechanism capitalization).

**Approval Authorities:** DG MOVE Leadership

### 2. High-Level Infrastructure & Technical Roadmap (OSDM Focus)

**ID:** af5a22aa-682f-4101-867a-066c4c1cda5e

**Description:** A strategic, phased timeline document detailing the relationships between technical milestones: OSDM V0.9 Draft (Month 6), Provisional Binding Status (Month 6), Final Binding Status (Month 18), and Mandatory API Exposure deadline (Month 30). Crucially maps Decision 4/14.

**Responsible Role Type:** Interoperability Standards Lead (OSDM/Technical Governance)

**Primary Template:** Program Milestone Tracking Template

**Secondary Template:** Shift2Rail Technical Implementation Plan Structure

**Steps:**

- Incorporate mandated timelines: Provisional Binding (M6), Final Binding (M18), Exposure Deadline (M30).
- Map dependency chain showing required completion of Accessibility Schema Validation (Decision 9) prerequisite to achieving Final Binding Status (M18).
- Integrate testing phases managed by the Conformance Testing Coordinator across the three physical locations.

**Approval Authorities:** Technical Steering Committee (TSC)

### 3. Financial Mechanism Design & Capitalization Framework (Builder Scenario)

**ID:** c89a653a-5ae8-42b1-b8d8-88c383dab5d0

**Description:** Framework detailing the transactional fee model (Decision 5) for funding the Clearing Mechanism float, including the formula for the variable transaction fee ('R'), the target €200M operational float, and the operational procedure for accessing the €300M Emergency Float Reserve.

**Responsible Role Type:** Financial Clearing & Settlement Specialist

**Primary Template:** Financial Instrument Design Document

**Secondary Template:** Payment Services Directive (PSD2) Financial Modeling Structure

**Steps:**

- Develop the specific algorithm/formula for the variable transaction fee ('R') based on target cost recovery.
- Define the specific on/off triggers for accessing the €300M Emergency Float Reserve, coordinating with the Risk Manager.
- Draft necessary documentation for engaging third-party guarantor banks for conditional collateral.

**Approval Authorities:** EU Regulatory & Governance Architect; TSC

### 4. Tiered Liability & Passenger Backstop Governance Protocol

**ID:** 23f442a2-8bbb-442a-becc-d3727e3a466e

**Description:** Protocol defining the structure and management of the pooled liability backstop mechanism, based on the chosen 'Collective Insurance Pool' model (revised Decision 3). It must detail the recoupment rules from segment carriers and the scope limit (first/last segment failure).

**Responsible Role Type:** Passenger Rights & Equity Policy Analyst

**Primary Template:** Risk Transfer & Insurance Protocol Template

**Secondary Template:** EU Agency for Railways Financial Backstop Mandate Draft

**Steps:**

- Draft the legal language for the mandatory collective insurance pool structure (Decision 3, Choice 2).
- Define the precise actuarial model used to apportion pool contribution based on journey volume.
- Establish the initial scope limitation (first/last segment failure) for backstop activation.

**Approval Authorities:** Legal Counsel (implied); EU Regulatory & Governance Architect

### 5. OSDM Data Exposure Commercial Terms & Cost Recovery Policy

**ID:** f54ce20c-d35d-46a8-b64f-1b81d02a7a02

**Description:** Policy document establishing the non-discriminatory capped royalty structure for API access (Decision 2). It must define the precise methodology for auditing operator IT maintenance costs attributable to OSDM maintenance (5% cap constraint).

**Responsible Role Type:** Digital Distributor & Market Adoption Strategist

**Primary Template:** Commercial Access Policy Framework

**Secondary Template:** Cost Allocation Methodology Report Standard

**Steps:**

- Define the specific cost categories considered 'attributable IT O&M expenditure' for royalty calculation.
- Develop the mandatory annual reporting template for operators to submit these audited costs.
- Establish the review cycle and escalation path (via Rail Operator Liaison) for disputes over cost attribution.

**Approval Authorities:** Regulatory Economist (Implied Review); TSC

### 6. Enforcement & Non-Compliance Action Matrix (Three Strikes)

**ID:** 1a111cf9-bbe6-49f5-8529-707fa0dd4d78

**Description:** Detailed matrix defining the operational triggers for the 'Three Strikes' enforcement posture (Decision 12). Specifies the measurable thresholds (T+5 latency breaches, semantic error rates, downtime) that constitute a 'strike' for SNCF, DB, and ÖBB.

**Responsible Role Type:** Program Risk Manager & Contingency Coordinator

**Primary Template:** Regulatory Compliance Sanctioning Matrix

**Secondary Template:** IT Failure Reporting Standard

**Steps:**

- Collaborate with the Interoperability Standards Lead to quantify specific technical failure criteria equivalent to a 'strike'.
- Map the consequences (suspension of through-ticketing sales) to the specific IT failure type/duration (Risk 2 mitigation).
- Formalize the notification procedures delivered by the Rail Operator Liaison.

**Approval Authorities:** EU Regulatory & Governance Architect; EU Agency for Railways

### 7. Accessibility Reservation Data Specification Requirements (PRM Integration)

**ID:** b55c7121-fd16-4012-805c-a2d2f1812801

**Description:** The technical requirements document detailing the mandatory OSDM data fields and schemas required for PRM booking and assistance notification, designed to align with the 'most restrictive national requirements' (Decision 9, Choice 1) required for Provisional Binding Status.

**Responsible Role Type:** Passenger Rights & Equity Policy Analyst

**Primary Template:** OSDM Data Specification Addendum (Non-Core/Equity)

**Secondary Template:** Accessibility Directive Compliance Checklist

**Steps:**

- Define the mandatory data fields necessary to signal assistance needs and book limited accessibility inventory.
- Map these requirements directly into the OSDM iteration planned for Provisional Binding release (Month 6).
- Develop the validation criteria for conformance testing teams.

**Approval Authorities:** Technical Steering Committee (TSC); Disability Advocacy Group Liaison

### 8. Capacity Building Grant Allocation Strategy (Initial Phase)

**ID:** 563330bf-4cf4-418f-8dbd-acf78c8f2afb

**Description:** Plan detailing the distribution methodology for the €900M capacity building budget, specifying the criteria for awarding IT grants to national rail operators, weighted heavily towards early API compliance demonstrated uptime (Decision 6).

**Responsible Role Type:** Rail Operator Liaison & Integration Manager

**Primary Template:** Public Funding Disbursement Framework

**Secondary Template:** Capacity Building Needs Assessment Report Structure

**Steps:**

- Determine specific percentage splits of the €900M based on projected integration complexity for the initial 5 high-priority operators (SNCF, DB, ÖBB, etc.).
- Define the technical milestones (linked to OSDM roadmap) that trigger grant installment releases.
- Integrate audit requirements for cost-recovery reporting into the grant agreement structure.

**Approval Authorities:** Program Risk Manager & Contingency Coordinator; DG MOVE

### 9. Stakeholder Communication Strategy & Enforcement Escalation Plan

**ID:** 757c0c69-89fe-4adf-8d65-3cd941f8dc34

**Description:** Comprehensive plan detailing engagement channels for Primary and Secondary Stakeholders, including the specific sequence and messaging for applying enforcement actions (escalating from warning to suspension) against major operators (SNCF, DB, ÖBB).

**Responsible Role Type:** EU Regulatory & Governance Architect

**Primary Template:** Integrated Stakeholder Engagement Plan

**Secondary Template:** Regulatory Escalation Protocol Template

**Steps:**

- Map specific messaging tailored for DG MOVE (compliance focus) vs. BEUC/Disability Groups (equity focus).
- Document the 90-day political de-escalation support offer narrative (per expert review recommendation).
- Finalize the precise notification timing coordinated with the Enforcement Action Matrix.

**Approval Authorities:** DG MOVE

### 10. Public Reference Distributor (PRD) Operating Model & Funding Schedule

**ID:** 1608c7ca-8078-45f9-8095-e69c3b211b5e

**Description:** Defines the operational scope, service catalog, and funding schedule for the public reference distributor, allocating the Ring-fenced 10% (€150M) of the budget across setup and five years of running costs, ensuring independence from commercial transaction fees.

**Responsible Role Type:** Digital Distributor & Market Adoption Strategist

**Primary Template:** Public Service Entity Operating Agreement

**Secondary Template:** Five-Year Reference Service Cost Projection

**Steps:**

- Detail specific features to be prioritized for launch (e.g., real-time refund demonstration).
- Schedule the budget drawdown necessary to cover the 35 FTE setup costs related to standards coordination.
- Create the performance metrics for reporting PRD usage velocity back to the TSC quarterly.

**Approval Authorities:** EU Regulatory & Governance Architect; DG MOVE

## Documents to Find

### 1. Existing EU Legal Text on Digital Booking and Ticketing Services for Rail

**ID:** 9acbebc0-6f87-4e9c-8209-eb6ed94d973d

**Description:** The full text of the proposed or final EU Regulation governing the project scope, essential for defining regulatory constraints, success criteria, and the legal basis for enforcement and standardization.

**Recency Requirement:** Must be the most current official legislative text or draft.

**Responsible Role Type:** EU Regulatory & Governance Architect

**Access Difficulty:** Easy

**Steps:**

- Search the European Parliament and Council official publication websites (EUR-Lex) for the latest legislative proposal draft.
- Consult DG MOVE documentation archives for internal regulatory summaries.

### 2. OSDM Technical Specification Documentation (Current Version)

**ID:** 957008dd-8084-40f4-8c5e-cd0ed419a83a

**Description:** The foundational technical documents outlining the current OSDM API structure, data dictionaries, semantic definitions, and any prior technical governance models used for standard amendments.

**Recency Requirement:** Most recent stable release candidate available.

**Responsible Role Type:** Interoperability Standards Lead (OSDM/Technical Governance)

**Access Difficulty:** Medium

**Steps:**

- Obtain documentation from the European Union Agency for Railways (ERA) or the associated Technical Body.
- Search Shift2Rail/INNOWAI technical repositories for foundational standards related to digital operations.

### 3. Historical ERTMS/Shift2Rail Stakeholder Resistance & Governance Reports

**ID:** 1f68baac-3b55-495c-a3fe-42bf05fa5f4a

**Description:** Existing reports detailing instances of political resistance, slow adoption timelines, and the specific governance structures used to overcome stakeholder stall tactics during previous major cross-border rail interoperability projects.

**Recency Requirement:** Preferably reports published within the last 5-10 years.

**Responsible Role Type:** Program Risk Manager & Contingency Coordinator

**Access Difficulty:** Medium

**Steps:**

- Contact the European Union Agency for Railways (ERA) directly regarding lessons learned from ERTMS deployment.
- Review public findings from the INNOWAI/Successor organization regarding standards amendment challenges.

### 4. PSD2 Implementation Guidelines and Payment Cost Benchmarks

**ID:** b645a8e7-3c35-4bf9-8944-c03f2a716554

**Description:** Official specifications, cost recovery models, and settlement speed data related to the European Banking Authority's (EBA) implementation of payment standards (PSD2/SEPA), used to benchmark the clearing mechanism design (Decision 5).

**Recency Requirement:** Documents detailing T+1/T+3 settlement finality and cost recovery mechanics.

**Responsible Role Type:** Financial Clearing & Settlement Specialist

**Access Difficulty:** Medium

**Steps:**

- Search the European Central Bank (ECB) and European Banking Authority (EBA) portals for detailed technical specifications and RTS documents.
- Review EPC working papers on intra-zone transfer cost structures.

### 5. EU Directive on Accessibility Requirements for Transport Products - National Transposition Status Reports

**ID:** 8ae75179-e77b-4612-9deb-e70ea44f8f7d

**Description:** Official documentation detailing the status of national transposition of EU accessibility laws relevant to booking/assistance services, crucial for defining the 'most restrictive requirement' for PRM data (Decision 9).

**Recency Requirement:** Current status reports or comparative analysis publications from DG MOVE/ERA.

**Responsible Role Type:** Passenger Rights & Equity Policy Analyst

**Access Difficulty:** Medium

**Steps:**

- Search DG MOVE public consultations or reports on Directive 2019/882 implementation in rail.
- Contact relevant disability advocacy liaison groups for their assessment of current national booking system gaps.

### 6. National Rail Operator IT Cost Attribution Policies (SNCF, DB, ÖBB)

**ID:** 77bc3d8d-e987-43fb-b466-68658e0dd70d

**Description:** Internal or publicly documented guidelines used by primary incumbent operators (SNCF, DB, ÖBB) for attributing maintenance and operational expenditure (OPEX) related to their internal IT systems, required to verify fair cost-recovery royalties (Decision 2).

**Recency Requirement:** Most recent publicly stated accounting standards or disclosures.

**Responsible Role Type:** Rail Operator Liaison & Integration Manager

**Access Difficulty:** Hard

**Steps:**

- Search annual financial reports or sustainability/IT strategic documents published by SNCF, DB, and ÖBB.
- Contact the CER for consolidated, non-public datasets detailing typical IT cost allocation methodologies in rail.

### 7. European Consumer Organization (BEUC) Position Papers on Through-Ticketing Friction

**ID:** 928dfd4f-d2b7-4a87-83ee-5cf8696e14cf

**Description:** Existing analysis from consumer advocacy groups detailing specific points of friction passengers currently face booking cross-border journeys (e.g., refund complexity, accessibility difficulties), essential for validating the 90-minute threshold (Decision 13) and prioritizing enhancements.

**Recency Requirement:** Documents focusing on rail/transport published within the last 3 years.

**Responsible Role Type:** Passenger Rights & Equity Policy Analyst

**Access Difficulty:** Medium

**Steps:**

- Search the official BEUC website and publications portal for transport sector reports.
- Cross-reference findings with official reports from national consumer protection bodies.

### 8. Benchmark Data on Real-Time Latency for Current Rail Operations (T+5 Data)

**ID:** b23b2f5c-ab17-4d0f-b4b1-5c70e912b10c

**Description:** Existing internal performance data or benchmark studies from major operators (or ERA studies) showing the typical end-to-end latency performance for current disruption notification systems, necessary to assess the feasibility of the mandated T+5 minute benchmark.

**Recency Requirement:** Data capturing performance under peak operational load, last 1-2 years.

**Responsible Role Type:** Cross-Corridor Conformance Testing Coordinator

**Access Difficulty:** Hard

**Steps:**

- Liaise with the Interoperability team to request operational telemetry data shared previously via Shift2Rail testing programs.
- Engage IT consulting firms who have worked on ERTMS integration for proprietary performance insights.

### 9. National Rail Discount/Loyalty Scheme Rule Books (Top 3 Volume Schemes)

**ID:** 32724029-5c61-4e66-9430-279c738aa2e3

**Description:** The complete legal rulebooks for the highest-volume national reduction cards (e.g., BahnCard, Carte Avantage), required to understand the complexity of converting monetary value or functionality for cross-border recognition (Decision 8).

**Recency Requirement:** Current, official rulebooks applicable as of the current year.

**Responsible Role Type:** Passenger Rights & Equity Policy Analyst

**Access Difficulty:** Medium

**Steps:**

- Visit the official websites of the major operators (SNCF, DB, ÖBB) and navigate their loyalty/discount sections.
- Consult with the Rail Operator Liaison to obtain definitive, consolidated handbooks if public versions are incomplete.