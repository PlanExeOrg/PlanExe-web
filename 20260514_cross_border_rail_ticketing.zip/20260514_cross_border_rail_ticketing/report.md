# Cross-Border Rail Ticketing

Generated on: 2026-05-14 00:36:38 with PlanExe. [Discord](https://planexe.org/discord.html), [GitHub](https://github.com/PlanExeOrg/PlanExe)

# Executive Summary

## Focus and Context
How do we mandate complex pan-European rail IT convergence while ensuring financial stability and operator buy-in? This plan establishes the core technical, financial, and governance foundations required to deliver seamless cross-border ticketing, moving from fragmented national systems to a unified, regulatory-compliant service capable of supporting significant modal shift.

## Purpose and Goals
The primary goals are achieving 40% single through-ticket adoption within five years, completing binding OSDM standardization within 18 months, and establishing a solvent clearing mechanism supported by a robust passenger rights backstop. Success is measured by these adoption/timeline metrics and a 50% reduction in distributor complaints.

## Key Deliverables and Outcomes
1. Finalized OSDM V1.0 specification with concurrently validated PRM accessibility schema (Month 18). 2. Fully capitalized Inter-Carrier Clearing Mechanism (initial €200M float secured). 3. Operationalized 'Three Strikes' enforcement template against primary operators (SNCF, DB, ÖBB). 4. Governance structure finalized, featuring an agile Fast-Track subcommittee for essential post-launch amendments.

## Timeline and Budget
Five-year execution window. Key technical milestone: Binding Standards achieved at Month 18; Full API Exposure at Month 30. Budget: €1.5 Billion coordination fund, with €900M allocated primarily to IT capacity building grants and €150M reserved for the Public Reference Distributor.

## Risks and Mitigations
High risks include Stakeholder Non-Compliance (mitigated by 'Three Strikes' enforcement and political de-escalation planning) and Unstable Data Layer (mitigated by aggressive T+5 latency testing and early adopter incentives). Financial solvency of the clearing mechanism is protected via transactional fees and a ring-fenced €300M Emergency Float Reserve.

## Audience Tailoring
The summary is tailored for senior regulatory and operational executives (DG MOVE, Agency for Railways, National Operator CTOs). The language is direct, policy-aware, and emphasizes decision synthesis, cross-dependencies, risk management, and alignment with the mandated 'Pragmatic Harmonization' strategy ('The Builder' scenario').

## Action Orientation
Immediate action is required to pivot the liability model (Decision 3) from strict tiered risk to a Collective Insurance Pool to align with the pragmatic pace. Simultaneously, grant formal authority to the Technical Steering Committee for rapid provisional amendments (Decision 10 modification) and prioritize functional conformance testing of PRM accessibility data mapping alongside core API load testing (T+5 validation).

## Overall Takeaway
The Pragmatic Harmonization strategy successfully balances ambitious regulatory requirements with operational realism by sequencing standardized technical delivery, sharing financial risk via collective pooling, and embedding agile governance, making the five-year 40% adoption goal highly achievable.

## Feedback
To increase persuasive impact, explicitly quantify the expected ROI of the 40% adoption target against the €1.5B investment. Strengthen the financial integrity by confirming the long-term sustainability model for the clearing mechanism post-initial float exhaustion (e.g., required transaction velocity). Detail the specific scope of the OSDM V2.0 contingency planning, as governance flexibility implies future unbudgeted CAPEX.

# Pitch

Persuasive elevator pitch.

# Seamless European Rail Journeys: Pragmatic Harmonization

## Project Overview

The core mandate of this project is to integrate the highly fragmented European rail network across **commercial, technical, and legal frameworks**. We aim to transform cross-border travel from a persistent complexity into a reliable utility. We are consciously avoiding a high-risk, rapid overhaul by adopting the **'Builder: Pragmatic Harmonization'** strategy.

This strategy focuses on several key deliverable areas:

- Establishing **phased yet binding** technical standards.
- Creating a financially sustainable, **transactional clearing mechanism**.
- Implementing a robust, shared liability backstop to champion **passenger trust**.

This approach prioritizes stability and promotes necessary private sector buy-in, setting a realistic path toward our primary goal of achieving **40% single through-ticket sales within five years**. This is the necessary foundation for Europe’s green mobility future.

## Target Audience

This proposition is directed toward key decision-makers who shape the future of European transport governance and operations:

- **EU Regulators (DG MOVE)**
- European Agency for Railways leadership
- National Rail Operators (CEO/CTO level)
- Major Independent Digital Distributors

## Stakeholder Benefits

Harmonization delivers concrete advantages across the ecosystem:

- **For Operators:** They will benefit from streamlined financial settlement via the Clearing Mechanism and clear liability attribution, significantly **reducing litigation risk**.
- **For Distributors:** Guaranteed standardized, non-discriminatory access to data at cost-recovery rates, which will **unlock vast new sales potential**.
- **For Passengers:** Immediate, tangible benefits including unified refunds, consolidated rights, and ultimately, easier access to booking multi-modal journeys, enhancing overall **customer experience**.

## Risks and Mitigation Strategies

We acknowledge significant risks, particularly political resistance from incumbent operators and the challenge of specification volatility. Our mitigation is intrinsically woven into our strategy:

- To manage political risk, we enforce compliance via a clear, credible **'Three Strikes' suspension policy** for through-ticketing rights (Decision 12). This approach avoids crippling financial penalties.
- To combat specification drift, we adopt **phased standardization**. We aim for provisional binding status early (6 months) to accelerate development, followed by structured stabilization testing before final regulatory sign-off at 18 months, balancing **speed and robustness**.

## Metrics for Success

Measuring success goes beyond the 40% through-ticket sales target. Short-term metrics include:

- Operator adherence to the **18-month binding standard timeline**.
- Achieving **90%+ uptime** on core OSDM APIs in the shared test environment.
- Maintaining the financial health of the pooled Passenger Rights Backstop (measured by maximum draw against the projected float), ensuring **financial resilience**.

## Ethical Considerations

Our commitment to passenger trust is paramount. The design incorporates two key ethical pillars:

- Mandatory **pooled Passenger Rights Backstop** (Decision 1) ensures no passenger is left stranded due to carrier disputes.
- Integration of **accessibility features** (Decision 9) is treated as a *Critical* pillar, ensuring that the resulting harmonization is equitable and non-discriminatory from its inception.

## Collaboration Opportunities

We actively seek **collaboration opportunities** with leading digital distributors and FinTech expertise experienced with PSD2 harmonization. This partnership is sought to optimize the transactional fee model and refine the governance structure for standard amendments (Decision 10/2). Their real-world integration experience is vital for iterating the OSDM specifications.

## Long-term Vision

This project establishes the core nervous system for European rail commerce. Once the initial foundation is laid—including the harmonized APIs, the clearing house, and the governance model—it becomes the platform ready for the seamless integration of non-core modes (bus/ferry pilots are underway). This ultimately supports the vision of true high-speed, **sustainable pan-European mobility**, making rail travel strongly competitive with short-haul aviation.

## Call to Action

We request immediate endorsement of the **'Pragmatic Harmonization' strategic playbook**. This endorsement will allow us to formally launch the governance structure for Binding Standard V1.0 and finalize the capitalization structure for the Inter-Carrier Clearing Mechanism by Q3. We must align the necessary legal mandates immediately to commence the crucial **18-month standardization rush**.

# Project Plan

**Goal Statement:** Deliver a coordinated European program making cross-border train travel as easy to search, book, and refund as national travel, achieving 40% of eligible cross-border journeys sold as single through-tickets within five years.

## SMART Criteria

- **Specific:** Establish the technical, commercial, and governance arrangements for compliant distributors to sell single through-tickets across all participating carriers with continuity-of-journey rights, single-payment settlement, and harmonized refunds.
- **Measurable:** Success will be measured by achieving 40% of cross-border journeys sold as single through-tickets, a 50% reduction in distributor complaints, and making the train the more attractive option than flying on competitive short-haul routes.
- **Achievable:** The goal is achievable through the strategic adoption of the 'Pragmatic Harmonization and Shared Burden' scenario, utilizing phased standardization, regulator-mandated data exposure (OSDM), and a structured €1.5 billion public coordination budget to bridge implementation gaps.
- **Relevant:** This is necessary to fulfill the EU Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail, significantly improving consumer experience, ensuring passenger rights, and promoting modal shift away from air travel.
- **Time-bound:** Five years for the 40% adoption target; binding standards within eighteen months; mandatory API exposure within thirty months.

## Dependencies

- Establish common technical specifications (OSDM-compatible APIs) across all participating carriers.
- Define and agree upon non-discriminatory commercial terms for data access and API exposure.
- Establish and capitalize the inter-carrier clearing and settlement mechanism.
- Formalize the governance structure for standard adoption, amendment, and enforcement.
- Establish the liability framework and fund the passenger-rights backstop.

## Resources Required

- €1.5 billion public coordination budget (for standards work, testing, clearing fund, public reference distributor)
- Defined OSDM version 1.0 standard documentation
- Personnel capacity (35 FTEs for governance/standards/testing in the first two years)
- Legal and regulatory mandate from DG MOVE

## Related Goals

- Achieve timely harmonization of reduction card recognition.
- Ensure full accessibility mandates (PRM booking) are integrated into the V1.0 standard.
- Integrate provisional API hooks for buses, ferries, and short-haul air (post five-year target).

## Tags

- Rail
- Ticketing
- Interoperability
- OSDM
- Passenger Rights
- EU Regulation
- Digitalization

## Risk Assessment and Mitigation Strategies


### Key Risks

- Political resistance or insufficient legal enforcement from state operators delaying standard compliance past deadlines.
- Integration challenges causing unstable OSDM-compatible real-time data layer (latency, semantic errors).
- Under-capitalization or low liquidity in the clearing/settlement mechanism due to slow initial transactional velocity.
- National operators prioritizing core API compliance over harmonizing mandatory ancillary services (Accessibility/Reduction Cards).
- Slow governance structure preventing timely technical pivots post-launch.

### Diverse Risks

- Coordinated lobbying by major incumbent operators to weaken the tiered liability framework.
- Over-ambitious scope creep via early integration of non-core transport modes.
- Distributors failing to rapidly adopt the new system due to perceived friction, jeopardizing the 40% sales goal.
- Inflation of IT operational costs by carriers to justify higher cost-recovery royalties for data access.

### Mitigation Plans

- Implement a clear 'three strikes' enforcement posture, leading to suspension of through-ticketing sales for non-compliant carriers (SNCF, DB, ÖBB targeted first).
- Apply early incentives (funding grants) tied to achieving high uptime (90%+) on test systems for the shared data layer.
- Implement a transactional fee model for clearing capitalization, backed by a ring-fenced €300 million 'Emergency Float Reserve' available if the operational float drops below 150% of peak daily obligation.
- Require functional conformance testing for Accessibility Reservation data schemas to complete concurrently with core API finalization at month 18, despite the longer service rollout grace period.
- Empower the Technical Steering Committee with an emergency review mandate (65% consensus) for the first twelve months post-launch to issue provisional operational directives for immediate change.

## Stakeholder Analysis


### Primary Stakeholders

- DG MOVE (European Commission Directorate-General for Mobility and Transport)
- EU Agency for Railways (Technical oversight, testing coordination)
- National Rail Operators (SNCF, DB, Trenitalia, Renfe, ÖBB, NS, SJ, etc. - IT providers and commercial entities)
- Independent Distributors (e.g., Trainline, Omio - API consumers)

### Secondary Stakeholders

- CER (Community of European Railways - Industry representative)
- BEUC (European Consumer Organisation)
- National Regulatory Bodies
- Disability Rights Bodies / Consumer Groups

### Engagement Strategies

- DG MOVE/Agency for Railways: Provide weekly progress reports focused on governance adoption and adherence to binding standard timelines.
- National Rail Operators (Primary): Engage via structured workshops for OSDM specification finalization; enforce commercial terms (cost recovery) via annual audited reporting; apply enforcement posture decisively.
- Independent Distributors: Conduct monthly technical feedback sessions focusing on API stability and commercial cost structures (Decision 2).
- BEUC/Disability Groups: Hold mandated quarterly review sessions specifically on the 90-minute continuity threshold and accessibility integration progress (Decision 9/13).

## Regulatory and Compliance Requirements


### Permits and Licenses

- Authorization for management of centralized financial clearing/settlement mechanism float
- Legal basis for enforcing data sharing requirements on sovereign entities

### Compliance Standards

- Alignment with proposed EU Regulation on Digital Booking and Ticketing Services for Rail
- OSDM technical standard adherence (binding timeline at 18 months)
- Compliance with all EU passenger rights regulations (T+90 min threshold defines activation)
- Non-discriminatory commercial terms for API access

### Regulatory Bodies

- European Commission (DG MOVE)
- EU Agency for Railways
- National Competent Authorities (National Regulators)

### Compliance Actions

- Draft legal framework mandating OSDM API exposure (T+30 months deadline).
- Schedule external conformance testing audits based on phased standardization progress (provisional binding at 6 months).
- Implement compliance plan for accessibility standardization by incorporating PRM data schema validation into the core binding standard sign-off process.
- Obtain DG MOVE legal pre-approval for the 'Three Strikes' enforcement template.

# Strategic Decisions

## Primary Decisions
The vital few decisions that have the most impact.


The vital few levers center on establishing the immutable foundations: Pacing Standard Adoption (12), enforcing Data Exposure (25), funding the Clearing Mechanism (7), defining Passenger Rights Liability (1), and setting fair Commercial Terms for Operators (4). Collectively, these address the core trade-off between Speed vs. Technical Robustness, and Regulator Control vs. Private Sector Buy-in, while resolving the fundamental issues of financial settlement and consumer protection required for any valid through-ticket service.

### Decision 1: Defining Liability and Passenger Rights Backstop Scope
**Lever ID:** `1f32c7c8-c66d-46fe-bf44-e0c87ba19003`

**The Core Decision:** This lever defines the financial and operational commitment for insulating passengers from complex inter-carrier disputes when journey segments fail. The goal is to establish a simple, consolidated EU backstop mechanism, likely pooled, to ensure immediate compensation payout aligning with consumer expectation. Key metrics involve the speed of fault attribution versus passenger payout, and the overall financial stability of the pool, crucial for underpinning passenger trust metrics.

**Why It Matters:** When a single ticket is sold but the journey involves multiple operators, determining who pays compensation for delays or cancellations becomes critical for consumer trust. Establishing a single, overarching backstop funded by all carriers significantly simplifies this for the passenger by making the distributor's interaction clear. This, however, forces high-performing carriers to subsidize the systemic failures of poorly managed operators within the clearing pool.

**Strategic Choices:**

1. Establish a pooled, mandatory insurance or reserve fund managed operationally by the EU Agency for Railways, which pays the passenger upfront for all validated rights claims, then recoups costs based on fault attribution.
2. Require the initial seller (distributor) to assume 100% of the passenger rights liability for the entire journey, irrespective of fault, forcing them to negotiate complex secondary reinsurance contracts with every carrier separately.
3. Limit the EU backstop only to instances where the connecting failure occurs between the first and last known segments, leaving disputes regarding segments managed entirely within existing national compensation frameworks.

**Trade-Off / Risk:** A unified EU backstop maximizes passenger confidence and distribution simplicity, but risks creating a moral hazard where the most reliable national carriers pay disproportionately for others' systemic delays.

**Strategic Connections:**

**Synergy:** Directly supports Defining Continuity-of-Journey Failure Thresholds by providing the mechanism through which penalties and payouts for exceeding those thresholds are actually managed and executed.

**Conflict:** Creates tension with Enforcement Posture for Non-Compliant Operator IT Integration, as a robust backstop can reduce the immediate financial penalty risk for carriers whose systems cause validated failures.

**Justification:** *Critical*, This is a core pillar of the passenger experience and regulatory compliance. Defining the backstop resolves the fundamental tension between consumer trust/simplicity and carrier financial risk attribution, making it central to market adoption.

### Decision 2: Governing Commercial Terms for Data Exposure and API Access
**Lever ID:** `c4680d31-2fda-49c5-9471-36fac751a32d`

**The Core Decision:** This concerns setting the non-discriminatory cost structure for commercial access to real-time inventory data held by national operators. The objective is to balance recovering essential IT costs for data providers against ensuring low barriers to entry for competing distributors. Success rests on establishing transparent, regulator-approved pricing that maximizes the diversity of distributors selling through-tickets, directly supporting the market uptake goal.

**Why It Matters:** The commercial terms dictating access fees for real-time inventory directly influence the pace and scope of independent distributor participation, which is vital for hitting the adoption target. If the terms are strictly cost-recovery only, smaller innovative platforms may lack the capital to rapidly integrate, concentrating market power with incumbents who already have legacy access. Conversely, heavily subsidized API access might lead to disputes over preferential treatment versus the non-discriminatory principle.

**Strategic Choices:**

1. Implement a standardized, capped royalty structure based on transaction volume, ensuring all API access fees are strictly cost-recovery for the national carrier's data provisioning, overseen by the regulators.
2. Offer the first two years of API access entirely free of charge for all certified third-party distributors to maximize market penetration initially, shifting the cost burden entirely onto the €1.5 billion public budget.
3. Empower national regulators to impose maximum commercial fees on inventory access, with any carrier exceeding this threshold being temporarily barred from the centralized clearing settlement mechanism until compliance is confirmed.

**Trade-Off / Risk:** Free initial API access strongly stimulates distributor adoption and competitive pricing, but it places the cost burden onto taxpayer funding rather than the commercial value generated by the data access.

**Strategic Connections:**

**Synergy:** Works to enable Incentivizing Early Carrier Participation in the Shared Data Layer by ensuring that, once data is exposed, the commercial relationship between provider and consumer is clear and fair.

**Conflict:** Creates a trade-off with Cost Allocation for Public Reference Distributor Operation; heavily subsidized API access may be viewed as unfair competition against a publicly funded distributor operating under cost-recovery terms.

**Justification:** *Critical*, This lever controls distributor participation and competitive market structure. Setting commercial terms dictates barrier-to-entry, directly impacting the success metric of achieving 40% single through-tickets sold by empowering or constraining distributors.

### Decision 3: Mechanism for Handling Incomplete Cross-Border Journey Data
**Lever ID:** `7e10ade0-7b0b-4c1b-bf46-0f46d50263f2`

**The Core Decision:** This lever addresses financial exposure when a multi-carrier journey fails due to technical faults or data lapses. Defining liability division is crucial for motivating carrier compliance and ensuring passenger compensation funds remain solvent. The goal is balancing risk assignment to incentivize data quality versus ensuring the backstop remains viable and doesn't unduly deter new market entrants from embracing the unified system.

**Why It Matters:** When a booking fails mid-chain or an operator fails to transmit required disruption data, the common passenger rights backstop must intervene, requiring an agreed liability split among parties. A 'maximum residual liability' cap placed on the initiating distributor simplifies their risk model but incentivizes them to offload complex failure scenarios onto the public backstop, straining its solvency. High operator-borne initial liability strongly encourages compliance but may discourage newer carriers from joining the network initially.

**Strategic Choices:**

1. Establish a strict, tiered liability model where the carrier whose segment experienced the technical failure bears one hundred percent of compensation costs unless gross distributor negligence is proven.
2. Create a mandatory collective insurance pool, pre-funded by all participants proportional to journey volume, to cover all unknown-cause or multi-party failure compensation claims up to a defined ceiling.
3. Insist that the initial distributor (the entity contracting with the passenger) retains full, un-capped liability for the entire journey, regardless of failure point, promoting rigorous downstream vetting.

**Trade-Off / Risk:** Placing un-capped liability on the initiating distributor heavily penalizes innovative third-party platforms lacking control over backend carrier fulfillment, which discourages market entry despite the primary objective.

**Strategic Connections:**

**Synergy:** This lever is strongly amplified by Defining Liability and Passenger Rights Backstop Scope, as the data failures addressed here directly inform the structure and required capitalization of the backstop.

**Conflict:** It conflicts with Incentivizing Early Carrier Participation in the Shared Data Layer; overly punitive liability models may cause potential participants to delay joining the shared data layer until risk models stabilize.

**Justification:** *Critical*, This lever sets the operational risk profile for the entire system. It dictates how unexpected failures are resolved, directly influencing both carrier compliance incentives and the viability of the passenger rights backstop.

### Decision 4: Pacing the Binding Standard Adoption Timeline
**Lever ID:** `aabd9b95-58b1-4d9c-ab1e-487c8549949b`

**The Core Decision:** This lever sets the timeline pressure for formalizing the technical exchange specifications (OSDM) into mandatory requirements. An aggressive timeline forces immediate system modifications across operators, aligning development quickly but raising rework risk if the standards prove brittle. The pace must balance the need for quick market access against ensuring technical specifications are validated through early implementation phases.

**Why It Matters:** Establishing binding technical standards within the first eighteen months allows distributors to rapidly gain access to necessary API functionality for the initial four corridors. However, this aggressive timeline forces carriers to freeze development on unverified specifications, potentially requiring costly re-engineering if DG MOVE mandates late-stage amendments based on early corridor feedback.

**Strategic Choices:**

1. Mandate that all core OSDM data exchange and transaction processing standards achieve full formal binding status within twelve months, necessitating immediate, high-risk operator system modification.
2. Implement a phased standardization approach where technical specifications achieve provisional binding status at six months, followed by regulatory finalization after the first set of corridors demonstrate operational stability at eighteen months.
3. Defer the formal binding adoption of reduction card and accessibility reservation schemas until the full TEN-T network integration phase, allowing initial corridors to operate with nationally negotiated, non-harmonized parameters.

**Trade-Off / Risk:** Accelerating binding standards commits operators to potentially incomplete specifications, requiring rework; deferring harmonization of critical features like accessibility risks undermining legislative intent for an equitable system from the outset.

**Strategic Connections:**

**Synergy:** An accelerated timeline accelerates the foundation for Financing the Inter-Carrier Clearing Mechanism Capitalization, as clearing mechanisms rely on finalized data exchange protocols.

**Conflict:** It creates tension with Governance Structure for Binding vs. Non-Binding Standards Amendments; binding standards established too early reduce the governance body's flexibility post-launch for necessary pivots.

**Justification:** *Critical*, This sets the primary pace constraints for all technical development across the entire network. It controls the fundamental tension between speed-to-market (18 months) and technical refinement/risk mitigation.

### Decision 5: Financing the Inter-Carrier Clearing Mechanism Capitalization
**Lever ID:** `7e412293-f431-4566-be78-c84535afc0b1`

**The Core Decision:** This lever determines the source of funds to capitalize the critical inter-carrier clearing mechanism, which facilitates single-payment settlement and automated fund transfers. The choice significantly impacts carrier liquidity versus program expenditure. Success hinges on establishing a self-sustaining, solvent structure that processes billions in payments without burdening operators' working capital during the critical integration phase.

**Why It Matters:** Deciding how to capitalize the clearing mechanism dictates the initial cash flow impact on participating national carriers versus the program budget. A system financed primarily through prepaid collateral requires large upfront capital lockup from operators, restricting their liquidity for other IT modernization projects.

**Strategic Choices:**

1. Capitalize the initial float required for the settlement mechanism entirely through the €1.5 billion public coordination budget, treating it as infrastructure investment to minimize carrier working capital strain.
2. Implement a transactional fee model where each ticket sale contributes a small, variable percentage to a rolling reserve fund, requiring carriers to provide conditional third-party bank guarantees instead of direct capital injection.
3. Require that only the initiating carrier posts 100% of the required settlement collateral for a given transaction, with automated subrogation mechanisms to reclaim funds from downstream carriers within seven business days.

**Trade-Off / Risk:** Funding float via the public budget eases carrier capital constraint but centralizes a significant financial risk within the EU program funding structure; relying solely on bank guarantees adds external financing overhead to the core payment process.

**Strategic Connections:**

**Synergy:** Financing the Inter-Carrier Clearing Mechanism Capitalization synergizes with Cost Allocation for Public Reference Distributor Operation, as public funding of one mechanism can free up private funds for the other.

**Conflict:** This lever conflicts with Enforcement Posture for Non-Compliant Operator IT Integration; demanding large upfront capital locks up carrier funds needed to pay for necessary IT upgrades and compliance efforts.

**Justification:** *Critical*, The clearing mechanism is the financial backbone enabling single-payment settlement. Its capitalization choice fundamentally dictates the liquidity strain on national carriers versus the program budget, critically enabling transactional reality.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Incentivizing Early Carrier Participation in the Shared Data Layer
**Lever ID:** `bbb8d8f0-68c8-4932-912e-9c1dbe444120`

**The Core Decision:** This lever aims to accelerate the construction of the core technical foundation—the shared real-time data layer—by using targeted financial incentives linked to early API compliance. Success is measured by the percentage of API compliance metrics met ahead of the mandatory deadline on initial corridor routes. This strategy directly catalyzes distributors' ability to offer accurate pricing and inventory, shifting focus from standard-setting negotiation to functional system readiness.

**Why It Matters:** Offering preferred treatment in public funding allocations (e.g., capacity building grants) to national operators who fully expose real-time inventory via OSDM-compatible APIs significantly ahead of the mandatory deadline. This accelerates the creation of the unified data foundation necessary for through-ticketing across the initial busiest corridors. However, early adopters may be forced to use preliminary, less stable API specifications, potentially leading to higher mid-term IT resolution costs to fix discrepancies before final standards stabilize.

**Strategic Choices:**

1. Implement a tiered funding model where early adopters demonstrating 90% API uptime on test systems receive disproportionately larger allocations of the €1.5 billion coordination budget for their domestic upgrade paths.
2. Establish a 'Regulatory Fast-Track' status for compliant carriers, simplifying their national permitting processes for existing cross-border routes not covered by the new regulation until the full framework is live.
3. Require all participating distributors to give a 12-month contractual priority window only to carriers whose real-time data exposure exceeds 95% compliance on the core corridor routes, effectively penalizing laggards through lost immediate sales volume.

**Trade-Off / Risk:** Prioritizing funding based on API uptime creates a compelling financial pull for carriers, but may divert scarce initial capital towards integration rather than comprehensive post-sale rights harmonization.

**Strategic Connections:**

**Synergy:** Amplifies Financing the Inter-Carrier Clearing Mechanism Capitalization by providing the necessary real-time data feed required for the clearing mechanism to function accurately from day one.

**Conflict:** Trades off against Pacing the Binding Standard Adoption Timeline; rushing API exposure may lead to early integration against preliminary non-finalized standards, requiring costly rework later.

**Justification:** *High*, This lever directly addresses the primary technical dependency (real-time data layer). Incentives accelerate the foundation for ticketing and clearing, creating significant early momentum, even though it risks integration rework due to standard finalization lag.

### Decision 7: Adoption Strategy for Non-Core Transport Modes Integration Hooks
**Lever ID:** `8b26b7f3-cf3a-4074-9408-275dca23f431`

**The Core Decision:** This strategy governs whether the project maintains a strict focus on core rail-to-rail interoperability or strategically expands early integration to include associated transport modes like buses or ferries. The scope involves creating provisional API hooks and negotiating supplementary commercial rules. Success here is defined by achieving targeted pilot integrations without jeopardizing the core timeline for rail ticketing availability on the main corridors.

**Why It Matters:** Integrating bus, ferry, and airport connections drastically improves the utility of the cross-border rail product, fulfilling the modal shift objective, but vastly expands the scope of required API adaptation and commercial negotiation. Delaying these integrations to focus solely on rail interoperability first ensures meeting the five-year core ticketing target with higher certainty. However, non-rail connections present unique ticketing complexities (e.g., variable loading rules for luggage/bicycles) that could slow down the development of clean, harmonized accessibility standards required for rail itself.

**Strategic Choices:**

1. De-scope all bus, ferry, and air integration hooks from the initial five-year mandate, focusing strictly on carrier-to-carrier rail connectivity and postponing secondary mode standards until binding rail standards are fully adopted.
2. Select a single, high-volume ferry operator and a single bus operator on each of the four initial launch corridors to pilot combined ticketing integration within the first three years, using their unique data structures to refine resilience.
3. Force the OSDM specification body to reserve specific, mandatory data fields for flexible integration requirements (e.g., loading capacity for bikes/luggage) by all transport modes simultaneously to preempt future fragmentation.

**Trade-Off / Risk:** Delaying integration of secondary modes ensures core rail timelines are protected, yet it sacrifices immediate market utility benefits and locks in system architecture before accommodating necessary adjacent transport realities.

**Strategic Connections:**

**Synergy:** Synergizes with Adoption Strategy for Non-Core Transport Modes Integration Hooks by providing the critical, dedicated scope and pilot strategy necessary for non-rail mode integration success.

**Conflict:** Directly conflicts with Pacing the Mandatory API Exposure Timeline, as extending the scope to multi-modal data requirements will inherently strain the development resources allocated to core rail APIs.

**Justification:** *Medium*, While important for the overall modal shift goal, this lever scopes additions outside the core rail mandate. Delaying it allows focus on core ticketing, marking it less central than the foundational technical and financial levers.

### Decision 8: Approach to Harmonizing Reduction Cards and Loyalty Schemes
**Lever ID:** `a9fb8a6d-0648-4587-9ab3-84072764e094`

**The Core Decision:** This lever addresses the politically sensitive task of making national discount and loyalty cards valuable for cross-border sales. The strategy dictates the degree of immediate harmonization versus deferral. Achieving high adoption requires customers to transfer existing value; therefore, the success metric is the percentage of eligible passengers who successfully apply a recognized discount on their first cross-border ticket via the new system.

**Why It Matters:** Recognizing and integrating national discount cards (like BahnCard or Carte Avantage) drives immediate passenger adoption by translating existing value to cross-border journeys, but harmonizing these inherently specific national schemes is bureaucratically complex and politically sensitive. Delaying complex harmonization allows the basic ticketing function to launch faster, but delays the critical modal shift objective because loyal customers cannot realize existing benefits, thus creating a fragile initial user base.

**Strategic Choices:**

1. Mandate immediate, universal recognition of the top three highest-volume national reduction cards across all four launch corridors, deferring the process of reconciling smaller national schemes until the second rollout phase.
2. Temporarily substitute all national discount cards with a single, standardized EU 'Cross-Border Discount Voucher' distributed automatically at the point of sale, payable from a temporary EU fund, bypassing carrier-specific scheme integration.
3. Require all national operators to convert the monetary value of their top discount card into a simple, time-limited percentage reduction applicable only to the final single through-ticket price, regardless of the underlying national scheme rules.

**Trade-Off / Risk:** Substituting national cards with a generic EU voucher achieves rapid perceived fairness for customers, but risks alienating national operators who rely on unique loyalty schemes for baseline domestic revenue protection.

**Strategic Connections:**

**Synergy:** Amplifies Governing Commercial Terms for Data Exposure and API Access because if discounts are recognized, distributors are more incentivized to integrate, as it increases the comparative value proposition of through-tickets.

**Conflict:** Creates friction with Approach to Harmonizing Accessibility Reservations Infrastructure, as immediate focus on complex fare/discount harmonization drains resources needed for the equally complex, but mandatory, accessibility standardization work.

**Justification:** *High*, Harmonization directly addresses passenger inertia and adoption challenges inherited from national systems. Successful integration maximizes the value proposition for existing loyal users, critically supporting the modal shift objective.

### Decision 9: Approach to Harmonizing Accessibility Reservations Infrastructure
**Lever ID:** `7381da62-7b8b-403e-b3c6-7f02117f676a`

**The Core Decision:** This lever focuses on establishing a unified, pan-European mechanism for booking and managing reservations for Persons with Reduced Mobility (PRM). Success hinges on achieving interoperable data exchange for assistance and specialized seating across disparate national infrastructures. The key metric is the seamlessness of multi-operator PRM bookings, ensuring regulatory compliance is met without crippling carriers lacking advanced physical accommodation updates immediately.

**Why It Matters:** Integrating specific booking flows for Persons with Reduced Mobility (PRM) requirements (e.g., wheelchair space booking, assistance notification) is highly complex due to varying physical asset availability across national infrastructures. Prioritizing a unified pan-European reservation flow simplifies the distributor interface but may demand costly, non-standardized physical accommodation updates by the least technically prepared infrastructure owner. Delaying full unification reduces initial implementation scope but maintains regulatory compliance risk in specific operational niches.

**Strategic Choices:**

1. Establish a mandatory, standardized PRM reservation schema based on the most restrictive national requirements across the initial four corridors, enforcing immediate adoption across the entire network.
2. Limit initial system capability to flagging assistance needs through a standardized distress code, deferring actual inventory booking and resource deployment coordination to validated, operator-specific ancillary services.
3. Pilot deep, two-way PRM data integration only on the busiest north-south corridor first, treating assistance reservation as a decoupled, bilateral operational signaling exchange rather than a unified ticketing feature.

**Trade-Off / Risk:** Forcing the most restrictive national PRM schema onto all operators immediately risks technical deadlock or non-compliance from carriers lacking the physical infrastructure to support the imposed standard immediately.

**Strategic Connections:**

**Synergy:** It synergizes with Approach to Harmonizing Accessibility Reservations Infrastructure by providing the necessary technical groundwork for unified data exchange, enabling integrated booking flows.

**Conflict:** It conflicts with Cost Allocation for Public Reference Distributor Operation, as high initial investment in complex PRM schemas may inflate the operation costs that need to be funded.

**Justification:** *High*, Accessibility is a non-negotiable regulatory requirement. This lever governs the complexity of embedding mandatory equity concerns ('accessibility for persons with reduced mobility') into the technically demanding unified booking flow.

### Decision 10: Governance Structure for Binding vs. Non-Binding Standards Amendments
**Lever ID:** `c756bf68-aaad-4f78-84e6-29a84d7a9f3a`

**The Core Decision:** This lever determines the procedural agility for evolving the OSDM technical standards post-launch. A robust governance structure ensures necessary adaptation while preventing any single dominant stakeholder from arbitrarily vetoing beneficial changes. Success is measured by the speed and acceptance rate of beneficial standard amendments needed as initial corridors reveal operational realities, balancing iteration against stability.

**Why It Matters:** Alterations to the OSDM API specification after the initial binding period require a robust, efficient approval process to maintain agility, yet overly centralized power risks vetoes from dominant national operators. A system weighted towards the majority of paying carriers encourages rapid iteration but may ignore critical, specialized infrastructure constraints held by minority carriers. Unanimous consent protects incumbents but guarantees slow, incremental technical evolution that misses emerging market needs.

**Strategic Choices:**

1. Implement a technical steering committee where amendments passing the initial 18-month deadline require a dual-approval threshold: 75% of signatory incumbent carriers plus approval from the public reference distributor.
2. Establish a rotating 'Fast-Track' subcommittee, composed only of distributors and one representative from the two smallest participating carriers, empowered to make binding, non-emergency amendments for six-month cycles.
3. Freeze the initial OSDM V1.0 standard for the full five-year horizon, allowing only clarifications of existing documentation but demanding all new features be managed through a completely separate V2.0 specification track.

**Trade-Off / Risk:** Empowering a small, rotating subcommittee risks marginalizing the largest financial contributors (incumbent carriers) whose infrastructure investments dictate operational reality, potentially causing non-cooperation.

**Strategic Connections:**

**Synergy:** It directly governs the evolution of the shared data layer, making it crucial for the effective implementation of Governing Commercial Terms for Data Exposure and API Access over time.

**Conflict:** It can conflict with Pacing the Mandatory API Exposure Timeline; a slow, overly consensus-driven governance structure will delay necessary API changes mandated by the exposure schedule.

**Justification:** *Medium*, Important for long-term agility, but less immediately critical than setting the initial technical foundation or commercial structure. It dictates *how* standards change, rather than defining the initial, high-stakes standards themselves.

### Decision 11: Cost Allocation for Public Reference Distributor Operation
**Lever ID:** `52436de8-dba8-4bdd-afa6-5c2f387ea79f`

**The Core Decision:** This lever defines the long-term financial viability and operational posture of the public reference distributor, which serves as an independent audit and reference point. Funding methodology determines its independence and commercial competitiveness—subsidized use encourages equal access, while usage fees drive operational self-sufficiency. Success means maintaining a robust, trusted reference platform without becoming a perpetual drain on the program budget.

**Why It Matters:** The public reference distributor is crucial for leveling the playing field and providing a fallback audit mechanism, but its operational funding must be secured. If funded entirely by the €1.5 billion public budget, it becomes a fixed drain regardless of network usage and may lack commercial agility. Requiring all commercial distributors to pay usage fees immediately shifts costs to the private sector but may disincentivize smaller players from utilizing a publicly subsidized asset.

**Strategic Choices:**

1. Fund the public reference distributor entirely through annual direct grants from the EU Program Budget for the full five years, keeping its use free and fully independent of commercial transactions.
2. Charge a modest, per-transaction administrative fee (below €0.01 per booking) collected via the clearing mechanism, rebating these fees to smaller distributors who process fewer than ten thousand bookings monthly.
3. Treat the public distributor as an open-source reference implementation, requiring only initial setup funding, and mandate that future maintenance and scale costs must be covered by optional, subscription-based support contracts.

**Trade-Off / Risk:** Funding the reference distributor solely through fixed public grants disconnects its operational incentives from network performance, potentially leading to feature stagnation if maintenance needs balloon unexpectedly.

**Strategic Connections:**

**Synergy:** This lever's funding choice impacts the viability of the public reference distributor, which acts as a key operational backup for Enforcement Posture for Non-Compliant Operator IT Integration.

**Conflict:** If funded entirely by public grants, it creates a dependency that strains the overall budget earmarked for program activities like Capacity Building, potentially reducing scope elsewhere.

**Justification:** *Medium*, This addresses the long-term operational posture of the audit mechanism. While important for maintaining a level playing field, the initial strategic success hinges on private sector development and adoption, not the subsidized reference model's fee structure.

### Decision 12: Enforcement Posture for Non-Compliant Operator IT Integration
**Lever ID:** `256244ca-5c5d-4ff6-b021-e0f301af21bf`

**The Core Decision:** This defines the regulatory teeth used to compel national carriers to implement OSDM-compliant APIs by the mandated deadline. A hardline approach forces rapid market entry for distributors but risks operational chaos if integration is incomplete. The key metric is near-100% uptime of compliant data feeds across high-priority corridors within two years.

**Why It Matters:** The approach to enforcing mandatory API exposure dictates the speed of market access for distributors and the willingness of skeptical national monopolies to upgrade their systems. Threatening service suspension guarantees compliance speed but risks fracturing the network during the critical rollout phase on the core corridors.

**Strategic Choices:**

1. Implement a clear 'three strikes' policy where the regulator automatically suspends an operator's ability to sell through-tickets on major corridors after three documented, non-remediated API failures within a quarter.
2. Leverage the EU Agency for Railways to apply graduated financial penalties, withholding certain public funding related to infrastructure modernization until full OSDM conformance is verified via external audit.
3. Introduce a market-forcing mechanism where the Public Reference Distributor is granted preferential, temporary access to inventory for non-compliant carriers, effectively penalizing the incumbent's direct sales channels.

**Trade-Off / Risk:** Immediate suspension of service severely compromises passenger flow during integration, yet relying solely on financial penalties may be too slow to meet the thirty-month mandatory exposure deadline for the busiest routes.

**Strategic Connections:**

**Synergy:** A strong Enforcement Posture directly supports Pacing the Mandatory API Exposure Timeline, ensuring that the strategic deadlines set for system availability are met through credible operational consequences.

**Conflict:** Aggressive Enforcement Posture conflicts with Financing the Inter-Carrier Clearing Mechanism Capitalization; carriers facing service suspension threats will hoard operational cash, making them resistant to large collateral requirements.

**Justification:** *Critical*, Given the hard regulatory deadlines (30 months for API exposure), enforcement is the lever that translates paper compliance into actual market readiness. It directly controls operator behavior regarding the core data layer dependency.

### Decision 13: Definition of Continuity-of-Journey Failure Thresholds
**Lever ID:** `16b05ab5-1e11-4f45-84c3-a77585c45aad`

**The Core Decision:** This sets the legal and technical floor for when a disruption crosses the threshold requiring the program's integrated passenger rights protections (rebooking, refunds) to activate. A clear, objective threshold is crucial for automating remedies and governing the backstop fund. Success is measured by the reduction in distributor complaints regarding unresolved passenger rights issues.

**Why It Matters:** Establishing a high threshold means more journeys are declared 'continuous' even with minor delays or service interruptions, simplifying initial technical rollout and minimizing immediate liabilities for carriers. Conversely, setting a very low threshold mandates robust, real-time monitoring and immediate automated remedy provisions, increasing complexity and the projected cost of the passenger-rights backstop fund.

**Strategic Choices:**

1. Define continuity protection only for full end-to-end ticket cancellations exceeding ninety minutes or outright missed connections triggering an alternative carrier booking.
2. Implement a sliding scale of consumer remediation linked directly to the cumulative delay seconds across all segments, requiring automated, real-time micro-compensation events.
3. Delegate the specific threshold determination for each primary corridor to the relevant national regulatory body for the initial two years of operation.

**Trade-Off / Risk:** Delegating the failure threshold determination risks fracturing harmonization goals across the initial corridors, yet local context might prevent an intractable EU-wide standard from being accepted upstream.

**Strategic Connections:**

**Synergy:** This lever strongly supports Defining Liability and Passenger Rights Backstop Scope, as a precise failure threshold determines the triggered events and expected capital draw on the backstop pool.

**Conflict:** Setting overly tight Definition of Continuity-of-Journey Failure Thresholds conflicts with Governing Commercial Terms for Data Exposure and API Access, as accurate real-time monitoring required for fine thresholds demands more complex and immediate data feeds.

**Justification:** *High*, This defines the product's 'service contract' regarding delays. It directly influences customer satisfaction/complaints (a success metric) and drives the required complexity/capitalization of the parallel liability backstop mechanism.

### Decision 14: Pacing the Mandatory API Exposure Timeline
**Lever ID:** `ec6b6f45-c08f-4458-a0ca-cd6806967598`

**The Core Decision:** This lever defines the chronological relationship between validating the technical specifications and mandating their use in live environments by all carriers. It governs the risk-reward trade-off between speed-to-market and robustness, ensuring APIs are stable before distributors rely on them for high-volume transactional sales across core routes.

**Why It Matters:** Advancing the mandatory exposure date closer to the binding standards deadline compresses the crucial window for iterative conformance testing between the two activities. This accelerates overall program timelines but disproportionately burdens smaller operators who lack dedicated internal resources for parallel development streams.

**Strategic Choices:**

1. Set the API exposure deadline eighteen months after binding standards ratification, allowing operators time to build to the final specification before system integration is mandated.
2. Stagger exposure by corridor importance, requiring the busiest corridors (Paris-Amsterdam) to expose stable APIs twelve months before less trafficked routes, using the budget for targeted technical assistance.
3. Require all operators to expose a read-only legacy API based on the draft standard immediately, while the final OSDM-compatible write API is due at the later mandated date.

**Trade-Off / Risk:** Staggering exposure based on corridor volume prioritizes the highest revenue routes but risks creating an unstable, partially compliant system where the market's densest traffic faces the highest integration risk.

**Strategic Connections:**

**Synergy:** Pacing the Mandatory API Exposure Timeline directly enables Incentivizing Early Carrier Participation in the Shared Data Layer by providing clear short- and medium-term goals for achieving initial interoperability milestones.

**Conflict:** A very aggressive Pacing the Mandatory API Exposure Timeline pressures operators, potentially leading them to oppose Governance Structure for Binding vs. Non-Binding Standards Amendments by demanding immediate finality on loose specifications.

**Justification:** *High*, This lever sets the timeline for the critical technical rollout (30 months). It governs the necessary overlap (and resource tension) between finalizing standards and forcing implementation, directly impacting the risk of premature integration.


# Scenarios

# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** High ambition: Creating a coordinated, integrated technical and commercial framework for pan-European cross-border rail travel, mandated by EU regulation, aiming for significant modal shift.

**Risk and Novelty:** High risk/Novelty: Requires complex IT integration (OSDM APIs), new financial clearing mechanisms, and harmonizing divergent national policies across numerous established operators.

**Complexity and Constraints:** Very high complexity: Involves numerous sovereign stakeholders (DG MOVE, regulators, 20+ national operators), stringent timeline (five years total, 18 months for binding standards), a large public budget (€1.5B), and deep technical/legal harmonization requirements.

**Domain and Tone:** Public Policy, Regulatory, and Large-Scale Infrastructure/IT implementation. Tone is urgent, comprehensive, and regulatory-driven.

**Holistic Profile:** A mandated, highly complex, multi-year regulatory effort to overhaul cross-border rail ticketing infrastructure across the EU, involving significant technical integration, governance challenges, and balancing public funding with commercial imperatives. The constraint is explicit: 'Pick a realistic scenario, not the most aggressive one.'

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder: Pragmatic Harmonization and Shared Burden
**Strategic Logic:** This scenario aims for scalable, verifiable progress by balancing public investment with carrier accountability. It enforces high standards through structured timelines and cost-sharing models that promote sustainability without freezing out market players.

**Fit Score:** 10/10

**Why This Path Was Chosen:** This scenario perfectly aligns with the requirement for a 'realistic' approach while matching the plan's required scope. It utilizes phased standardization, capped cost recovery for data, and shared liability, balancing ambition with operational reality across complex, diverse stakeholders.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Limit the EU backstop only to instances where the connecting failure occurs between the first and last known segments, leaving disputes regarding segments managed entirely within existing national compensation frameworks.
- **Governing Commercial Terms for Data Exposure and API Access:** Implement a standardized, capped royalty structure based on transaction volume, ensuring all API access fees are strictly cost-recovery for the national carrier's data provisioning, overseen by the regulators.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Establish a strict, tiered liability model where the carrier whose segment experienced the technical failure bears one hundred percent of compensation costs unless gross distributor negligence is proven.
- **Pacing the Binding Standard Adoption Timeline:** Implement a phased standardization approach where technical specifications achieve provisional binding status at six months, followed by regulatory finalization after the first set of corridors demonstrate operational stability at eighteen months.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Implement a transactional fee model where each ticket sale contributes a small, variable percentage to a rolling reserve fund, requiring carriers to provide conditional third-party bank guarantees instead of direct capital injection.

**The Decisive Factors:**

The plan is highly ambitious, involving massive regulatory overhaul and technical risk, yet explicitly requires a *realistic* path over the 'most aggressive' one. The Builder scenario is the superior fit because it manages this tension.

*   **Alignment with Realism:** It adopts a phased standardization timeline (provisional binding at 6 months, finalization after corridor testing), aligning perfectly with the request to avoid overly aggressive adoption, unlike The Pioneer's 12-month hard mandate.
*   **Shared Burden:** It implements cost-recovery royalties for data access and a tiered liability model, balancing the need for market entry with carrier accountability, which is more sustainable than The Pioneer's complete reliance on the public budget.
*   **Contrast with Other Scenarios:** The Pioneer is too aggressive, demanding immediate freezing of core standards and socializing all financial risk. The Consolidator is too passive, pushing excessive liability onto distributors and deferring critical harmonization elements, jeopardizing the core objective of seamless, equitable travel.

---
## Alternative Paths
### The Pioneer: Maximum Dominance & Risk Absorption
**Strategic Logic:** This path aggressively pursues complete harmonization and passenger trust by centralizing risk and forcing rapid technological adoption. It prioritizes market disruption and regulatory success over short-term cost containment or operational comfort for incumbent carriers.

**Fit Score:** 6/10

**Assessment of this Path:** This scenario matches the high ambition and novelty of the plan but is explicitly rejected by the instruction to avoid the 'most aggressive' approach. It mandates the fastest timelines (12 months binding) and centralizes nearly all risk onto the public budget.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Establish a pooled, mandatory insurance or reserve fund managed operationally by the EU Agency for Railways, which pays the passenger upfront for all validated rights claims, then recoups costs based on fault attribution.
- **Governing Commercial Terms for Data Exposure and API Access:** Offer the first two years of API access entirely free of charge for all certified third-party distributors to maximize market penetration initially, shifting the cost burden entirely onto the €1.5 billion public budget.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Create a mandatory collective insurance pool, pre-funded by all participants proportional to journey volume, to cover all unknown-cause or multi-party failure compensation claims up to a defined ceiling.
- **Pacing the Binding Standard Adoption Timeline:** Mandate that all core OSDM data exchange and transaction processing standards achieve full formal binding status within twelve months, necessitating immediate, high-risk operator system modification.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Capitalize the initial float required for the settlement mechanism entirely through the €1.5 billion public coordination budget, treating it as infrastructure investment to minimize carrier working capital strain.

### The Consolidator: Stability and Cost Control
**Strategic Logic:** This conservative path prioritizes minimizing public financial outlay and avoiding operational surprises by favoring established best practices and delayed adoption of complex elements. It relies heavily on existing regulatory structures and national liability frameworks.

**Fit Score:** 3/10

**Assessment of this Path:** This scenario is too conservative. It shifts excessive liability to distributors, defers harmonization of key features (accessibility), and would likely fail to meet the mandated five-year goal of 40% single ticketing penetration due to operational friction.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Require the initial seller (distributor) to assume 100% of the passenger rights liability for the entire journey, irrespective of fault, forcing them to negotiate complex secondary reinsurance contracts with every carrier separately.
- **Governing Commercial Terms for Data Exposure and API Access:** Empower national regulators to impose maximum commercial fees on inventory access, with any carrier exceeding this threshold being temporarily barred from the centralized clearing settlement mechanism until compliance is confirmed.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Insist that the initial distributor (the entity contracting with the passenger) retains full, un-capped liability for the entire journey, regardless of failure point, promoting rigorous downstream vetting.
- **Pacing the Binding Standard Adoption Timeline:** Defer the formal binding adoption of reduction card and accessibility reservation schemas until the full TEN-T network integration phase, allowing initial corridors to operate with nationally negotiated, non-harmonized parameters.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Require that only the initiating carrier posts 100% of the required settlement collateral for a given transaction, with automated subrogation mechanisms to reclaim funds from downstream carriers within seven business days.


# Assumptions

# Purpose

**Purpose:** business

**Purpose Detailed:** Developing and implementing a unified technical, commercial, and governance framework for seamless cross-border train travel across the EU, aimed at improving market efficiency, passenger rights, and modal shift from air travel. This involves creating shared APIs, clearing mechanisms, and standardization aligned with EU regulation.

**Topic:** Coordinated European cross-border rail booking and ticketing infrastructure

# Domain

**Primary domain:** Financial Clearing Mechanisms

**Secondary domains:** Digital Transport Regulation, Rail Infrastructure Management, Interoperability Standards

**Rationale:** Financial Clearing Mechanisms is the primary outcome, defining successful single-payment settlement, while Financial Settlement Systems is a closely related but secondary outcome. Digital Transport Regulation and Interoperability Standards are foundational constraints/methods, not the project's main success criterion.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Digital Transport Regulation | 5 | 5 | constraint | The project is explicitly aligned with a proposed EU Regulation on Digital Booking. |
| Interoperability Standards | 5 | 5 | method | The core technical requirement is using OSDM-compatible APIs and setting binding standards. |
| Financial Clearing Mechanisms | 5 | 5 | outcome | Establishing an inter-carrier clearing and settlement mechanism is a core deliverable. |
| Digital Distribution Systems | 5 | 5 | method | Building shared OSDM-compatible APIs is central to the project's technical delivery. |
| Rail Infrastructure Management | 4 | 4 | stakeholder | National rail operators and infrastructure bodies are key stakeholders and implementers. |
| Passenger Rights Advocacy | 4 | 4 | stakeholder | Disability rights bodies and consumer groups are explicitly listed stakeholders. |
| IT System Integration | 4 | 4 | method | The project relies heavily on exposing unified APIs and integrating various booking systems. |
| Financial Settlement Systems | 4 | 4 | outcome | Creating a single-payment, inter-carrier clearing and settlement mechanism is a key deliverable. |
| European Union Law | 4 | 3 | constraint | The entire program must align with the proposed EU Regulation on Digital Booking. |

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** The plan is to develop and implement a complex, multi-year program that creates shared technical standards (OSDM-compatible APIs), governance structures, and new financial clearing mechanisms across multiple European countries. This effort requires extensive physical collaboration between stakeholders (DG MOVE, EU Agency for Railways, national operators, regulators) in physical meetings, workshops, and governance bodies to define standards, perform conformance testing, and manage the rollout. Furthermore, the ultimate success relies on physical integration into real-world operator IT systems and testing the end-to-end process of purchasing, journey execution, and refunds, which is inherently a physical process involving physical rail networks and passengers. Even the budget allocation and capacity building imply physical coordination efforts. Therefore, this plan is overwhelmingly `physical` due to the required implementation, physical governance, and real-world system integration.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Proximity to major EU institutions (DG MOVE, EU Agency for Railways)
- Facilities for high-level governance meetings and standards workshops
- Access to central European transport hubs for corridor testing coordination

## Location 1
Belgium

Brussels

European Quarter/Near EU Institutions

**Rationale**: As the host of the European Commission (DG MOVE) and central to the proposed initial launch corridor (Paris–Brussels–Amsterdam–Köln), Brussels is the ideal administrative and coordination hub for standards-setting and governance body meetings.

## Location 2
France/Germany/Benelux

Paris–Brussels–Amsterdam–Köln Corridor Region

Testing facilities within central cluster areas (e.g., Lille, Frankfurt, or Rotterdam)

**Rationale**: As the very first corridor slated for roll-out, having a physical presence or testing command center proximal to operators and infrastructure in this region is critical for initial conformance testing and resolving early technical issues.

## Location 3
Austria/Germany/Switzerland

Wien–München–Zürich Corridor Region

Munich or Vienna (as central connection points)

**Rationale**: To facilitate the parallel coordination and testing required for the second primary corridor, a central operating base in the core of this region (e.g., Munich) allows engagement with ÖBB, DB, and Swiss partners without diverting all focus from the main Brussels hub.

## Location Summary
Since this is a multi-national regulatory and technical implementation program, physical locations must serve administrative coordination and initial corridor testing. Brussels is essential for stakeholder engagement with EU bodies. Additional locations are suggested near the two highest-priority initial corridors (Paris-Amsterdam-Cologne and Vienna-Munich-Zurich) to facilitate on-the-ground testing and localized operational alignment required for the phased rollout.

# Currency Strategy

This plan involves money.

## Currencies

- **EUR:** The project is centered across the European Union, where the Euro is the primary currency for most participating member states.

**Primary currency:** EUR

**Currency strategy:** The primary currency budget will be managed in EUR due to the consolidated European scope. Local operational expenditures in non-Eurozone EU countries (if any are involved in the initial corridors, though none are immediately obvious from the primary routes mentioned) should be reconciled to EUR, utilizing routine foreign exchange procedures without complex hedging due to Eurozone stability.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Political resistance or insufficient legal enforcement posture from one or more key national rail operators or member states, leading to non-compliance with binding data exposure or ticketing standards by the mandate deadlines.

**Impact:** If a state or major operator (e.g., SNCF or DB) drags their feet, it invalidates the 'continuity-of-journey' principle for large segments of the network, potentially leading to a delay of 6–12 months for full functionality on key routes and jeopardizing the 40% through-ticket target.

**Likelihood:** Medium

**Severity:** High

**Action:** Maintain a strong Enforcement Posture (Decision 12) by leveraging the EU Agency for Railways to conduct mandatory, pre-launch technical audits. Ensure the linkage between adherence to standards and access to the shared clearing/settlement mechanism is legally unambiguous.

## Risk 2 - Technical
Integration challenges leading to an unstable OSDM-compatible shared real-time data layer, specifically regarding data quality, latency, or semantic mismatches between operator inventory systems, despite provisional binding standards being established early.

**Impact:** If data is unreliable, distributors cannot sell accurate through-tickets, leading to high rates of failed bookings, customer complaints (target requires halving complaints), and erosion of passenger trust. This could cause a 2–3 month delay in commercial rollout on the initial four corridors until data quality improves.

**Likelihood:** High

**Severity:** High

**Action:** Aggressively apply early incentives (Decision 6) for high data uptime compliance on core routes. Utilize the Public Reference Distributor (Decision 11) as a specialized real-time validation sandbox to aggressively stress-test cross-carrier data transmission before mandatory exposure.

## Risk 3 - Financial
Under-capitalization or insufficient liquidity within the inter-carrier clearing and settlement mechanism due to the chosen transactional fee model (The Builder scenario), resulting in settlement delays or disputes between carriers.

**Impact:** Settlement failures undermine the single-payment settlement requirement. This could stall carrier participation or force the EU public budget to cover short-term float gaps, estimated at an extra €50–€200 million in working capital support beyond the initial coordination budget.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Closely monitor the balance of the rolling reserve fund (Decision 5). If transaction volume velocity lags or reserve balances drop below a pre-defined safety buffer (e.g., 20% of expected peak daily settlement volume), trigger a swift request for targeted, temporary capitalization from the public budget or mandate higher initial bank guarantees.

## Risk 4 - Supply Chain / Integration
National operators focusing their limited IT resources predominantly on achieving the mandatory API deadline (30 months) at the expense of harmonizing complex post-sale or ancillary services, specifically accessibility reservations or bicycle rules.

**Impact:** While basic ticketing might launch, failure to integrate accessibility (Decision 9) or reduction cards (Decision 8) causes the key success metric (improving on-board experience) to fail, leading to regulatory non-compliance on equity grounds and limiting overall modal shift gain by 10–15%.

**Likelihood:** High

**Severity:** Medium

**Action:** Use the phased standardization approach (Decision 4) to allocate mandatory conformance testing milestones for accessibility data (Decision 9) immediately following the provisional binding standards being set (6 months), ensuring these complex elements are developed in parallel, not sequentially, with core ticketing APIs.

## Risk 5 - Operational/Governance
Overly complex or slow governance structure for amending OSDM standards post-launch leads to an inability to rapidly address unforeseen technical bugs or incorporate necessary refinements needed after initial corridor launches.

**Impact:** Necessary security patches or minor functional improvements could take 6–9 months to pass the dual-approval threshold, leading to prolonged operational vulnerabilities or customer frustration in the early phases (e.g., buggy refund processing).

**Likelihood:** Medium

**Severity:** Medium

**Action:** Ensure the initial mandate for the Governance Structure (Decision 10) gives the technical steering committee (or equivalent body) expedited authority to issue 'clarification notices' to the Public Reference Distributor for immediate implementation, pending formal ratification later.

## Risk 6 - Social / Stakeholder Management
National operators resist the defined liability framework (Decision 3), finding the tiered model too punitive, leading to internal lobbying efforts that attempt to water down the Passenger Rights Backstop, undermining consumer trust.

**Impact:** If the backstop is weakened (e.g., liability is pushed back onto the distributor or passenger), the promise of 'continuity-of-journey rights' fails, directly threatening the goal of reducing consumer complaints and achieving the 40% adoption target.

**Likelihood:** Medium

**Severity:** High

**Action:** Frame the tiered liability model (Decision 3) not as a penalty, but as a necessary risk pooling mechanism supported by the data transparency achieved through the shared API layer. Provide clear, early actuarial modeling showing how the pooled risk is lower than unmanaged individual carrier risk.

## Risk 7 - Market / Competition
Distributors fail to rapidly adopt the new system, preferring established legacy methods or focusing on national markets, potentially failing to meet the 5-year goal of 40% single through-tickets sold.

**Impact:** If adoption is slow, the economic justification for the €1.5B public investment diminishes. If only 20% adoption is reached, the operational success metric is missed, and the program is deemed a failure.

**Likelihood:** Medium

**Severity:** High

**Action:** Aggressively implement Decision 2 (Capped Royalty Structure). Ensure commercial terms are fair enough to encourage integration while allowing distributors to build viable business models, thus maximizing their incentive to push cross-border sales.

## Risk 8 - Environmental/Scope Creep
Overly ambitious integration of non-core transport modes (buses, ferries) too early in the five-year plan, diverting resources from stabilizing the core rail ticketing framework.

**Impact:** Delay in achieving corridor through-ticketing, pushing the core objective back by 9–12 months due to engineering complexity spillover. This would directly conflict with the 'realistic scenario' constraint.

**Likelihood:** Low

**Severity:** Medium

**Action:** Adhere strictly to Decision 7: De-scope non-core integrations from the Phase 1 mandate (first 60 months). Focus capacity building exclusively on rail-to-rail OSDM compliance in the initial phase.

## Risk summary
The project faces high inherent risks due to its regulatory mandate, complex multi-stakeholder setup (20+ carriers), and critical dependency on novel IT standardization (OSDM APIs). Given the chosen 'Pragmatic Harmonization' scenario, the primary existential threats are **Stakeholder Non-Compliance (Regulatory Risk)** and **Shared Data Layer Instability (Technical Risk)**. Political resistance from national operators could derail the entire project if enforcement posture is perceived as weak, while unreliable real-time data renders the core ticketing functionality unusable regardless of governance. The chosen mitigation strategies rely heavily on leveraging tight deadlines, phased implementation (Decision 4), and financial incentives linked to data quality (Decision 6) to ensure that behavioral change precedes technical perfection. Crucially, the trade-off made by selecting the Builder scenario—accepting tiered liability over centralized risk absorption—amplifies the need for robust technical validation to minimize failures that lead to liability disputes.

# Make Assumptions


## Question 1 - What is the defined initial capitalization requirement (float) for the inter-carrier clearing and settlement mechanism, and what is the acceptable duration for settlement reconciliation delays under the transactional fee model?

**Assumptions:** Assumption: Based on the transaction volume estimates for the busiest corridors, the initial float required for the clearing mechanism will be provisionally set at €200 million. Settlement reconciliation delays are assumed to be manageable if resolved within T+3 (Transaction plus three days) for 99% of transactions.

**Assessments:** Title: Financial Mechanism Viability Assessment
Description: Evaluation of the initial funding and liquidity profile of the clearing mechanism chosen under the Builder scenario.
Details: Relying on a transactional fee model (Decision 5) necessitates careful monitoring of the initial €200M float. Risk: If transaction velocity is too low initially, the float could deplete, requiring public top-up (Risk 3). Opportunity: A T+3 standard aligns with standard high-value B2B bank clearing, improving carrier confidence over slower national processes. Mitigation requires setting a weekly monitoring trigger on the reserve fund balance.

## Question 2 - Considering the phased standardization approach (provisional binding at 6 months), what is the mandated grace period for national operators to upgrade their legacy reduction card and accessibility booking systems before full harmonized service is required?

**Assumptions:** Assumption: The 'phased standardization' (Decision 4) dictates that core ticketing APIs must be stable by 18 months (final binding), but complex ancillary services like accessibility (Feature Set B) and reduction cards (Feature Set C) are allocated an additional 12 months grace period, resulting in a 30-month mandate for their full harmonization.

**Assessments:** Title: Harmonization Implementation Timeline Assessment
Description: Analysis of the timeline pressure on complex, secondary feature implementation relative to core data exposure.
Details: Deferring full harmonization of accessibility and reduction cards until month 30 (Risk 4 mitigation) provides necessary breathing room for national operators. Benefit: This prevents immediate technical overload that could jeopardize the stability of the core OSDM data layer mandated by month 18. Risk: Delaying accessibility features beyond the initial corridor rollout risks early regulatory challenges regarding equity concerns.

## Question 3 - What precise mechanism and metric will the EU Agency for Railways use to audit and certify compliance with the non-discriminatory commercial terms established for API data access, particularly concerning incumbent carrier IT cost recovery?

**Assumptions:** Assumption: Compliance will be verified annually through audited balance sheets submitted by operators, focusing on IT operational costs directly attributable to OSDM data maintenance. The standard cost-recovery royalty rate is assumed to be capped at 5% of the operating/maintenance expenditure required for the API endpoint.

**Assessments:** Title: Commercial Governance Effectiveness Assessment
Description: Evaluation of the regulatory oversight mechanism ensuring fair financial terms for data access (Decision 2).
Details: Capped, cost-recovery royalties (Decision 2) necessitate robust audit capability. Risk: Operators may inflate indirect IT costs to increase recoverable fees, requiring strong regulatory challenge capabilities. Opportunity: If audits confirm low, fair pricing, it significantly lowers the barrier to entry for independent distributors (Risk 7), supporting the 40% sales target.

## Question 4 - Which specific national operators are designated as primary participants in the first thirty-month compliance audit cycle for the 'Enforcement Posture' concerning the busiest cross-border corridors (Paris-Brussels-etc., Wien-Munich-etc.)?

**Assumptions:** Assumption: The primary participants for the initial 30-month audit cycle are mandated to be SNCF, Deutsche Bahn (DB), and ÖBB due to their central role in the two highest-volume initial corridors. Enforcement actions will be applied first to these entities.

**Assessments:** Title: Regulatory Compliance Risk Management
Description: Gauging the intent and immediacy of applying the enforcement posture (Decision 12) against key infrastructure providers.
Details: Focusing initial high-stakes enforcement (Risk 1) on SNCF, DB, and ÖBB is pragmatic given their corridor centrality. Benefit: Early compliance success here sets a strong operational precedent across the EU. Risk: If these major players resist strongly, enforcement actions could trigger significant political friction undermining coordination.

## Question 5 - How will the public funding component of the €1.5 billion budget be allocated to support capacity building for national operators to meet the OSDM technical integration standards, and what percentage is ring-fenced for the public reference distributor?

**Assumptions:** Assumption: 60% of the €1.5B fund (€900M) is allocated to capacity building (IT grants/testing support), and 10% (€150M) is reserved for the establishment and initial five-year running costs of the public reference distributor (Decision 11).

**Assessments:** Title: Budget Allocation and Sustainable Operations Assessment
Description: Analyzing the budgetary support structure for IT upgrades and the long-term running of the reference platform.
Details: Allocating 60% for grants directly mitigates the resource strain on operators (Risk 4). However, reserving 10% for the reference distributor (Decision 11) creates a fixed cost base that must be managed, potentially conflicting with the goal of minimal long-term drain if usage fees lag.

## Question 6 - What is the operational plan for integrating real-time disruption data between operators required for 'continuity-of-journey rights,' and does this require all carriers to adopt a shared real-time latency benchmark (e.g., maximum 5-minute delay in reporting)?

**Assumptions:** Assumption: A mandatory real-time latency benchmark of T+5 minutes (5 minutes from event occurrence to API availability) will be established as part of the provisional binding standards at month 6 (Decision 4). This is essential for automatically triggering the passenger rights backstop (Decision 13).

**Assessments:** Title: Operational Data Interoperability Assessment
Description: Evaluation of the technical requirements for real-time system interaction needed to support integrated journey protection.
Details: Mandating a T+5 latency benchmark forces high operational standards (Risk 2 mitigation). Benefit: Clear thresholds (Decision 13) enable automated backstop activation, directly supporting the reduction in distributor complaints. Risk: Carriers with older infrastructure may struggle to meet T+5, increasing enforcement pressure (Decision 12).

## Question 7 - Given the need for physical coordination and testing in Brussels and corridor regions, what is the staffing plan for the central governance body (e.g., number of dedicated full-time equivalents) required to manage standards, testing, and stakeholder engagement for the first two years?

**Assumptions:** Assumption: The initial governance body will require 35 FTEs dedicated to standards management (10), conformance testing coordination (15, focused heavily on the physical locations identified), and stakeholder relations (10), spread across the Brussels HQ and corridor liaison offices.

**Assessments:** Title: Resource Deployment and Physical Coordination Assessment
Description: Analyzing the personnel needs required to execute governance and physical testing across multiple EU locations (Physical Locations Rationale).
Details: Deploying 15 FTEs to testing coordination across the identified physical locations (Location 2 & 3) is critical for resolving integration technical risks (Risk 2). However, staffing 35 FTEs requires immediate allocation of operational budget, which must be factored into the €1.5B program management slice, distinct from IT grants.

## Question 8 - How will the governance structure ensure that the necessary adjustments to the liability model (Decision 3) or data access terms (Decision 2) can be rapidly processed if initial corridor tests reveal systemic issues that exceed expected risk tolerances?

**Assumptions:** Assumption: The Governance Structure (Decision 10) will grant an emergency review mandate to the Technical Steering Committee for the first twelve months post-launch, allowing immediate, non-unanimous amendments (requiring only 65% consensus) to be enacted as 'provisional operational directives' before final ratification.

**Assessments:** Title: Governance Agility and Risk Tolerance Assessment
Description: Assessing the procedural flexibility to adapt fundamental rules once implementation starts revealing systemic risk.
Details: Granting emergency override power (Decision 10) mitigates Risk 5 (slow amendments) and allows rapid adaptation if the tiered liability model (Decision 3) proves inadequate or if data access terms (Decision 2) cause distributor pushback. Benefit: This balances stability with necessary agility for a novel, high-pressure program.

# Distill Assumptions

- Initial clearing mechanism float is provisionally set at €200 million.
- Settlement reconciliation delays are assumed manageable within T+3 for 99% of transactions.
- Full harmonization of accessibility and reduction cards is granted a 30-month grace period.
- API access royalties are capped at 5% of attributable IT operating/maintenance expenditure.
- SNCF, Deutsche Bahn (DB), and ÖBB are primary participants in the initial enforcement audit.
- €900M (60% of €1.5B) is allocated for capacity building grants to national operators.
- 10% (€150M) of the €1.5B fund is reserved for the public reference distributor's running costs.
- A mandatory real-time latency benchmark of T+5 minutes will be established at month 6.
- The central governance body requires 35 dedicated FTEs for the first two years.
- Governing structure allows 65% consensus emergency amendments for the first twelve months post-launch.
- Backstop protection activates only for connections cancelled or delayed/missed exceeding 90 minutes.
- Initial operators bear one hundred percent compensation costs unless gross distributor negligence is proven.
- API access fees are capped royalties strictly for cost-recovery, overseen by regulators.
- Technical specifications achieve provisional binding status within six months of project start.
- The required initial capitalization for the clearing mechanism is financed via transactional fee collateral.
- An aggressive enforcement posture uses a 'three strikes' rule leading to suspension of through-ticketing sales.
- Core OSDM data exchange standards mandate formal binding status within eighteen months.
- Tiered liability model holds the segment carrier fully responsible for compensation costs unless negligence is proven.
- The EU backstop limits compensation to connecting failures between the first and last known segment failures.
- Provisional binding status must occur at six months, with finalization at eighteen months.

# Review Assumptions

## Domain of the expert reviewer
Multi-Jurisdictional Project Governance and Infrastructure Integration

## Domain-specific considerations

- Regulatory Harmonization Across Sovereign Entities
- Financial Clearing Mechanism Solvency
- IT Standards Adoption (OSDM) Across Legacy Systems
- Commercial Non-Discrimination and Cost Recovery
- Critical Path Dependencies (Data Layer before Clearing/Ticketing)

## Issue 1 - Unrealistic Grace Period for Ancillary Harmonization (Accessibility/Loyalty)
The assumption grants a 30-month grace period for complex ancillary systems (Accessibility/Reduction Cards) while core ticketing APIs are mandated binding at 18 months. Accessibility (Decision 9) is a non-negotiable regulatory/equity requirement. Delaying harmonization risks early regulatory non-compliance and undermines the modal shift objective by penalizing existing loyal customers. This deferral is a significant tactical omission of risk.

**Recommendation:** Immediately adjust the governance structure (Decision 10) to mandate that full functional conformance testing for Accessibility Reservations (Decision 9) must pass *before* final binding status is granted to core ticketing APIs at month 18. The provisional binding status at month 6 must explicitly require the standardized PRM data schema be finalized, even if backend infrastructure rollout is staggered. This shifts the focus from avoiding an IT load to ensuring compliance meets legal intent.

**Sensitivity:** If full accessibility compliance is delayed beyond Month 24 (baseline 30 months), the project faces regulatory fines estimated at 3-7% of the operational budget annually, potentially reducing overall ROI by 8-12% due to brand damage and legal costs, even if ticketing revenue meets targets.

## Issue 2 - Insufficient Contingency for Clearing Mechanism Float Depletion
The assumption relies on a provisional €200M float financed solely by transactional collateral (Decision 5, Builder Scenario), with settlement targeted at T+3. The inherent risk is that during the initial ramp-up (first 9-12 months), transaction velocity will be low, and the initial collateral may prove insufficient to cover peak settlement risk or temporary liquidity gaps caused by systemic failures before the reserve fund self-capitalizes effectively. This jeopardizes the financial backbone of the entire system.

**Recommendation:** Mandate that 20% of the total €1.5B coordination budget (€300M total) be ring-fenced immediately, not just for the reference distributor, but as a guaranteed, immediately accessible liquidity backstop for the clearing mechanism. This 'Emergency Float Reserve' should only be activated if the T+3 target fails for 48 consecutive hours or the transactional collateral dips below 150% of the baseline peak daily obligation.

**Sensitivity:** If the initial €200M float proves insufficient and requires a public injection of €50M (baseline: fully self-funded), the project's total capital expenditure increases by 3.3% (€50M on €1.5B), potentially reducing final ROI by 2-4 percentage points through increased program overhead.

## Issue 3 - Lack of Assumption on Key Operator Behavioral Response to Enforcement
The success relies heavily on an aggressive Enforcement Posture (Decision 12—'three strikes' leading to suspension) against key players like SNCF, DB, and ÖBB (Assumed Primary Participants). There is no explicit assumption or mitigation planned for the political fallout or coordinated resistance if these majors actively lobby to weaken the governance structure (Decision 10) or delay full compliance past the 18-month core mandate, viewing suspension as an unacceptable commercial threat.

**Recommendation:** Develop a structured 'Political De-escalation' plan prioritized over technical mitigation. This plan must include pre-negotiated, short-term (90-day) technical assistance packages funded by the capacity budget (€900M) earmarked only for the first operator facing the third strike, instead of immediate suspension. This buys time for negotiation while maintaining the implicit threat of commercial exclusion.

**Sensitivity:** If political lobbying forces a 6-month delay in applying the enforcement posture against the top 3 operators (baseline: immediate enforcement), the technical integration risk (Risk 2) rises significantly, likely causing a 4-6 month delay in achieving 40% through-ticket sales, translating to a 15-20% shortfall in projected Year 2 revenue.

## Review conclusion
The current plan exhibits excessive optimism regarding the alignment of complex, mandatory ancillary systems (accessibility/loyalty) and relies too heavily on the self-sufficiency of the initial financial clearing mechanism float. The three most critical missing considerations relate to managing regulatory pushback on enforcement, ensuring the financial stability required for day-one settlement, and addressing the non-negotiable equity issues of accessibility integration without creating early regulatory risk. Immediate action must focus on creating contingency funding for the clearing mechanism and integrating accessibility compliance testing directly into the core standard ratification timeline.

# Governance

# Governance Audit


## Audit - Corruption Risks

- Kickbacks or undue influence from incumbent national operators seeking preferential terms in the standardized, capped royalty structure for API data access (Decision 2), potentially leading to inflated cost-recovery claims.
- Nepotism or conflicts of interest among personnel coordinating capacity building grants (€900M allocated), favoring specific national operator IT modernisation projects in exchange for personal benefits or favors.
- Bribery of regulatory staff or staff in the EU Agency for Railways to receive a favorable ruling during the initial alignment of the Passenger Rights Backstop (Decision 1) or to overlook non-compliance thresholds during the mandated conformance testing phases.
- Misuse of information regarding the financial health or upcoming audit findings of specific national carriers (SNCF, DB, ÖBB) by internal personnel to gain leverage in commercial negotiations or regulatory discussions.
- Trading favors with national regulators to secure leniency on the 'three strikes' enforcement posture (Decision 12) or to delay the final binding adoption of sensitive standards like reduction card harmonization (Decision 8).

## Audit - Misallocation Risks

- Misallocation of the €1.5 billion coordination budget: Directly diverting funds intended for the clearing mechanism float or public reference distributor operation into unauthorized capacity building initiatives based on non-objective stakeholder relations rather than technical need.
- Inflating IT operational expenditure reports by national carriers specifically to maximize cost-recovery royalties for data provision, misusing the regulator-overseen cap (Assumption Q3).
- Inefficient utilization of the 35 dedicated FTEs, with excessive staffing allocated to stakeholder relations instead of core standards management or coordination of physical conformance testing at site locations (Assumption Q7).
- Double spending by national operators claiming public capacity building grants (€900M pool) for IT modernization work that is simultaneously being paid for or guaranteed through other existing national or EU infrastructure investments.
- Misreporting progress on functional compliance for ancillary services (accessibility/PRM reservation data—Decision 9) to meet internal deadlines, thus drawing down capacity funding prematurely while actual integration capability remains unstable.

## Audit - Procedures

- Quarterly detailed audit of the Inter-Carrier Clearing Mechanism float balance, checking collateral provision against the transactional fee model (Decision 5) and triggering an immediate external review if the rolling reserve falls below 150% of the calculated peak daily obligation.
- Annual external audit review of cost-recovery royalty claims submitted by the primary participants (SNCF, DB, ÖBB) to verify IT operational expenditures attributed to OSDM data maintenance against specified cost standards (Assumption Q3).
- Mandatory forensic examination of any operator triggering the 'three strikes' enforcement policy (Decision 12) to confirm that the underlying API failures necessitating suspension were technical and not due to fabricated data or deliberate non-compliance.
- Post-implementation (Month 30) audit of the Passenger Rights Backstop pool to verify the activation criteria (90-minute threshold/inter-segment failure) correlated accurately with actual compensation payouts, assessing 'gross distributor negligence' determinations (Decision 3).
- Periodic (Bi-annual during the first 18 months) audit by the EU Agency for Railways focusing specifically on the integration status of PRM reservation data schemas (Decision 9) to ensure they meet provisional binding status requirements at month 6, regardless of the later service rollout.

## Audit - Transparency Measures

- Publication of monthly utilization and performance dashboards for the shared real-time data layer (OSDM APIs), showing latency benchmarks (T+5 minutes) broken down by operator and route corridor.
- Public disclosure of the standardized, regulator-approved royalty fee structure utilized for API access, immediately following the finalization of Decision 2, ensuring distributors can verify commercial fairness.
- Mandatory publication of minutes from the Technical Steering Committee's emergency review sessions (Decision 10), redacted only for essential security details, showing which provisional operational directives were enacted under the 65% consensus rule.
- Establishment of a secure, independently managed whistleblower channel specifically for reporting suspicious cost-inflation claims related to API cost-recovery reporting or misuse of capacity building grants.
- Public reporting of the capital reserve drawdown schedule and replenishment triggers for the clearing mechanism float, traceable against the initially provisioned €200 million, accessible via the Public Reference Distributor platform (Decision 11).

# Internal Governance Bodies

### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Essential for strategic oversight, high-level decision-making (especially concerning financial thresholds and regulatory alignment), and resolving major risks, ensuring the project remains aligned with the EU Regulation mandate. Its existence clearly separates strategic control from day-to-day execution.

**Responsibilities:**

- Approve annual program strategy, budget allocations deviating more than 10% from the baseline plan, and major scope changes.
- Receive and approve reports on strategic risk status (especially regulatory compliance and enforcement posture).
- Formally sanction operator inclusion/exclusion from the clearing/settlement mechanism.
- Resolve formal disputes escalated from the Operational Management Group regarding policy interpretation or inter-carrier commercial terms.

**Initial Setup Actions:**

- Finalize and approve the Terms of Reference (ToR), defining explicit strategic decision thresholds.
- Appoint the Executive Sponsor (Chair) and establish the conflict resolution mechanism.
- Review and formally approve the initial Capitalization Plan for the Clearing Mechanism.

**Membership:**

- High-level representatives from DG MOVE (Chair)
- Director of the EU Agency for Railways
- Chief Legal Officer (Project Sponsor)
- Designated representative from National Regulators' Forum (Non-voting)
- Chair of the Technical Advisory Group (Invited)

**Decision Rights:** Decisions with financial impact exceeding €5 million, significant changes to the binding timeline (Decision 4), or approval of operator exclusionary actions (Decision 12). Sets the maximum liability cap for the Passenger Rights Backstop (Decision 1).

**Decision Mechanism:** Weighted Majority Vote. DG MOVE representative holds the deciding vote in case of a tie, mandated by the regulatory underpinning. Conflicts between DG MOVE and Member State representatives escalate immediately to the relevant EU Director-General.

**Meeting Cadence:** Quarterly, or on urgent call for critical milestone approvals (e.g., standards ratification milestones).

**Typical Agenda Items:**

- Review of 5-Year Target Progress (40% Through-Ticket Metric).
- Strategic Risk Review (Focus on Regulatory Compliance/Enforcement Viability).
- Approval of major releases/conformance testing outcomes.
- Review of projected utilization vs. clearing mechanism float stability (Risk 3).

**Escalation Path:** Unresolved issues or disputes that cannot reconcile within the PSC due to stakeholder impasse are escalated directly to the relevant DG MOVE Director-General for executive political resolution.
### 2. Operational Management Group (OMG)

**Rationale for Inclusion:** This body is required to manage the day-to-day execution, compliance monitoring, dependency tracking, and resource allocation necessary to deliver the technical integration and operational benchmarks (T+5 latency, 30-month API deadline). It ensures coherence between the standards body and the testing coordination.

**Responsibilities:**

- Manage the 35 dedicated FTEs, coordinating the standards and testing streams.
- Monitor and report on operator performance against API exposure deadlines (Decision 12) and latency benchmarks (T+5).
- Oversee the validation roadmap for the Public Reference Distributor (Decision 11).
- Manage weekly budget burn rate for operational expenditure.
- Coordinate capacity building grant distribution reviews with the relevant technical/auditing bodies.

**Initial Setup Actions:**

- Establish the centralized reporting dashboard linking technical milestones to the timeline (Decision 4/14).
- Finalize the Statement of Work (SOW) for the external auditing firm managing royalty verification (Assumption Q3).
- Develop and distribute weekly progress templates to all primary technical stakeholders (SNCF, DB, etc.).

**Membership:**

- Project Director/Program Manager (Chair)
- Head of Technical Integration (Responsible for OSDM/API)
- Head of Financial Operations (Clearing/Settlement oversight)
- Compliance & Audit Lead
- Stakeholder Relations Manager

**Decision Rights:** Decisions concerning resource shifts within the approved operational budget (<€500k); resolution of day-to-day technical blockers below the threshold requiring PSC intervention; managing the queue for conformance testing slots.

**Decision Mechanism:** Consensus required among all core functional leads. Conflicts are resolved by the Project Director; if irreconcilable within 48 hours, they are escalated to the PSC as an 'Operational Blockade.'

**Meeting Cadence:** Weekly (Operational Stand-up); Bi-weekly (Detailed Review).

**Typical Agenda Items:**

- Review of Critical Path Dependencies (Standards vs. Testing).
- Operator Compliance Report (API Uptime, Latency Checks).
- Clearing Mechanism Liquidity Status (Tracking against €200M float).
- Capacity Grant Utilization Review.

**Escalation Path:** Issues requiring financial approval >€500k, policy reinterpretation, or failure to secure operator cooperation that risks a key deadline (e.g., failure to adhere to the 'three strikes' policy) are escalated to the Project Steering Committee (PSC).
### 3. Technical Assurance & Standards Group (TASG)

**Rationale for Inclusion:** Given the absolute reliance on the novel, complex OSDM standard for real-time data, booking, and clearing, a dedicated body is needed to manage technical development agility, conformance testing, and mandatory governance evolution (Decision 10) without bureaucratic hindrance.

**Responsibilities:**

- Manage the evolution and formal ratification of OSDM V1.0 standards (Decision 4/10).
- Oversee the lifecycle of API functional compliance testing, ensuring T+5 latency is met.
- Provide technical advice to the PSC on all integration risks (Risk 2).
- Govern the immediate operational directives under the emergency review mandate (Assumption Q8).
- Ensure binding conformance testing for Accessibility Reservations (Decision 9) precedes core v1.0 finalization.

**Initial Setup Actions:**

- Establish the technical voting baseline for OSDM amendment consensus (65% agility threshold activated).
- Define the standardized, detailed test cases for T+5 latency validation.
- Appoint an independent Standards Review Board Chair.

**Membership:**

- Head of Technical Integration (Chair)
- Lead Architect (OSDM Focus)
- External Independent Technical Consultants (Ensuring Vendor Neutrality)
- Representative from the EU Agency for Railways (Testing Oversight)
- Two nominated Technical Leads from major Independent Distributors (for API consumer perspective)

**Decision Rights:** Binding approval on technical specifications for all OSDM V1.0 components; issuing of 'Provisional Operational Directives' under the 12-month emergency review mandate; setting technical criteria for operator certification.

**Decision Mechanism:** Dual Approval Threshold: 75% of internal members AND 65% among invited Member State technical representatives (where applicable). Emergency directives (first 12 months) require 65% consensus among core members only.

**Meeting Cadence:** Bi-weekly (during development phases); Monthly (post-ratification stabilization).

**Typical Agenda Items:**

- Review of Amendments/Change Requests to OSDM Specification.
- Conformance Testing Results Analysis (Focus on T+5 latency performance per operator).
- Accessibility Reservation Data Schema Validation Status (Decision 9 check-in).
- Technical Mitigation Plan Review for known integration bugs.

**Escalation Path:** Technical disagreements that threaten the 18-month binding deadline, or specifications that cause unworkable commercial terms (potential conflict with Decision 2), are immediately escalated to the Operational Management Group (OMG) for policy resolution or to the PSC if financial thresholds are impacted.
### 4. Compliance and Liability Assurance Board (CLAB)

**Rationale for Inclusion:** Due to the high regulatory burden, the critical nature of passenger rights (Decision 1/13), and the complexity of non-discriminatory commercial terms (Decision 2), a dedicated assurance body is necessary to enforce accountability, manage compliance audits, and govern the crucial financial liability framework independently of operations.

**Responsibilities:**

- Oversee compliance with the Passenger Rights Backstop activation thresholds (Decision 13).
- Conduct/commission compliance audits against the 'three strikes' enforcement posture (Decision 12), particularly on SNCF, DB, ÖBB.
- Verify national carrier adherence to cost-recovery royalty caps (Assumption Q3) via annual report review.
- Ensure non-discriminatory access to APIs and settlement mechanism liquidity.
- Provide independent assessment on determinations of 'gross distributor negligence' (Decision 3).

**Initial Setup Actions:**

- Formalize the charter for auditing IT cost allocations from national carriers.
- Establish the protocol for triggering the forensic audit upon 'three strikes' enforcement action.
- Develop the compliance reporting matrix linking Decision 2 (Commercial Terms) to Decision 5 (Clearing Mechanism).

**Membership:**

- Chief Compliance Officer (Chair)
- Internal Audit Lead
- External Regulatory Counsel (Independent)
- Risk Manager (Responsible for Clearing Float Stress Testing)
- Representative from National Regulatory Bodies (Non-voting, for local context)

**Decision Rights:** Binding determination on whether an operator has met compliance thresholds for continued participation in the clearing mechanism; recommendations for applying enforcement actions (subject to PSC final approval). Sole authority on validating compensation payout correlation data post-audit.

**Decision Mechanism:** Consensus among the Chair and Independent Counsel. The Risk Manager can raise a procedural objection requiring PSC review if audit findings directly threaten clearing mechanism solvency.

**Meeting Cadence:** Monthly, with immediate emergency session called upon the triggering of a 'three strikes' policy against a primary participant.

**Typical Agenda Items:**

- Review of Audit Findings on Cost Recovery Reporting.
- Assessment of Passenger Rights Backstop Utilization (Correlation with T+90 threshold).
- Status of Enforcement Actions against Primary Participants (SNCF, DB, ÖBB).
- Reviewing impact of TASG decisions on regulatory compliance.

**Escalation Path:** Any determination leading to suspension of clearing access, or any finding indicating potential misuse of the public budget or sustained non-compliance by a primary carrier, is immediately escalated to the Project Steering Committee (PSC) for sanctioning.

# Governance Implementation Plan

### 1. Project Sponsor (DG MOVE/Executive Lead) formally authorizes the establishment of all defined governance bodies based on agreed strategic decisions.

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Formal Project Initiation Mandate
- Charter documents for PSC, OMG, TASG, CLAB circulation

**Dependencies:**

- Strategic Path (Builder Scenario) Confirmed
- Governance Body Definitions Finalized

### 2. Project Manager (via assumed interim coordination role) drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC), incorporating PSC's specific decision thresholds and conflict resolution mechanisms.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1-2

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1

**Dependencies:**

- Formal Project Initiation Mandate

### 3. Project Sponsor formally appoints the Executive Sponsor (Chair of PSC) and proposes the full PSC membership list for circular approval by key stakeholders (DG MOVE, EU Agency for Railways, Regulators Forum).

**Responsible Body/Role:** Project Sponsor (DG MOVE)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PSC Chair Appointment Confirmation
- Nominated PSC Member List

**Dependencies:**

- Draft PSC ToR v0.1

### 4. PSC membership is formally confirmed, and the PSC Chair initiates the charter review/approval process.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Approved PSC ToR
- PSC Kick-off Meeting scheduled

**Dependencies:**

- PSC Membership Confirmed

### 5. Hold the inaugural meeting of the Project Steering Committee (PSC). Primary agenda item: Formal approval of the final structure and appointments for the subordinate bodies (OMG, TASG, CLAB).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved PSC Meeting Minutes
- Endorsement of OMG, TASG, CLAB Charters and Initial Appointments

**Dependencies:**

- Final Approved PSC ToR

### 6. Project Manager proceeds to draft ToRs and finalize nominations for the Operational Management Group (OMG), Technical Assurance & Standards Group (TASG), and Compliance and Liability Assurance Board (CLAB), based on PSC endorsement.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4-5

**Key Outputs/Deliverables:**

- Draft OMG ToR/Membership List
- Draft TASG ToR/Membership List
- Draft CLAB ToR/Membership List

**Dependencies:**

- Endorsement of OMG, TASG, CLAB Charters

### 7. Confirm nomination of Chairs for OMG, TASG, and CLAB. These Chairs, advised by the Project Manager, secure final functional membership confirmations required for their groups to operate.

**Responsible Body/Role:** PSC Chair (via Project Manager)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Confirmed Chairs for OMG, TASG, CLAB
- Final OMG, TASG, CLAB Membership Roster

**Dependencies:**

- Draft OMG/TASG/CLAB ToRs

### 8. Hold the inaugural meetings for the OMG, TASG, and CLAB. Key initial tasks: internal ratification of their respective ToRs and assigning immediate setup actions (e.g., dashboard setup for OMG, testing case definition for TASG, audit protocol drafting for CLAB).

**Responsible Body/Role:** Chairs of OMG, TASG, CLAB

**Suggested Timeframe:** Project Week 7-8

**Key Outputs/Deliverables:**

- Ratified ToRs for OMG, TASG, CLAB
- Initial Action Plan for each group (e.g., Draft SOW for OMG audit firm, TASG Test Cases)

**Dependencies:**

- Confirmed Chairs and Final Membership Roster

### 9. OMG initiates Project Reporting Framework setup: Establish centralized dashboard linking to timelines (Decision 4/14) and schedule initial weekly operational stand-ups.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 8-9

**Key Outputs/Deliverables:**

- Operational Reporting Dashboard v1.0 operational
- First OMG Weekly Stand-up Minutes

**Dependencies:**

- Ratified OMG ToR

### 10. TASG defines the standardized, detailed test cases required for OSDM compliance and the T+5 latency validation benchmark (Assumption Q6). This feeds directly into capacity grant planning.

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Week 9-10

**Key Outputs/Deliverables:**

- Finalized OSDM V1.0 Test Case Matrix
- T+5 Latency Validation Protocol

**Dependencies:**

- Ratified TASG ToR
- Agreement on Provisional Binding Status Timeline (M+6)

### 11. CLAB finalizes the protocol for auditing national carrier IT cost allocations (to enforce Capped Royalty, Decision 2 / Assumption Q3) and establishes the compliance reporting matrix linking commercial terms to clearing mechanism stability.

**Responsible Body/Role:** Compliance and Liability Assurance Board (CLAB)

**Suggested Timeframe:** Project Week 10-12

**Key Outputs/Deliverables:**

- Signed Charter for External Auditing Firm (SOW)
- Compliance Audit Framework v1.0

**Dependencies:**

- Ratified CLAB ToR
- PSC Approval of Initial Budget Allocation (for external audit costs)

### 12. OMG issues initial capacity building grants/technical assistance packages, prioritizing operators identified by CLAB for early audit focus (SNCF, DB, ÖBB) to accelerate OSDM integration.

**Responsible Body/Role:** Operational Management Group (OMG)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Disbursement Record for Initial Capacity Building Grants (€900M fund deployment commences)
- Compliance Roadmap signed by SNCF, DB, ÖBB

**Dependencies:**

- Finalized OSDM V1.0 Test Case Matrix (TASG)
- Operator Compliance Roadmap (CLAB)

### 13. TASG begins work on harmonizing PRM reservation schema (Decision 9), ensuring the data schema validation is locked down before the provisional binding standard deadline (M+6).

**Responsible Body/Role:** Technical Assurance & Standards Group (TASG)

**Suggested Timeframe:** Project Month 2 (Week 9 Ongoing)

**Key Outputs/Deliverables:**

- Draft PRM Data Schema integrated into OSDM Specification Branch

**Dependencies:**

- T+5 Latency Validation Protocol
- Governance mandate to prioritize PRM schema conformance over ancillary grace period

### 14. PSC reviews the governance setup completeness, confirms readiness for standards ratification process, and formally signs off on the financial stabilization strategy for the Clearing Mechanism Float (€200M collateral structure).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Month 3

**Key Outputs/Deliverables:**

- Governance Structure Final Stability Report
- Clearing Mechanism Capitalization Approval (Decision 5)

**Dependencies:**

- OMG budget burn aligned with plan
- CLAB Compliance Framework established

# Decision Escalation Matrix

**Proposed decision to deviate >10% from approved annual budget allocation.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review of strategic necessity/ROI; Weighted Majority Vote with DG MOVE tie-breaker.
Rationale: Exceeds the Project Director's financial decision rights (<€500k) and impacts strategic resource distribution from the overall €1.5B scope.
Negative Consequences: Budget overrun; potential need to delay critical capacity building or testing coordination expenditures.

**Inability of the Operational Management Group (OMG) to reach consensus on resource allocation shifts exceeding €500k or resolving an operational blockade.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Urgent call; review necessity and strategic impact; majority vote overseen by the PSC Chair.
Rationale: The OMG consensus deadlock requires intervention at the next governance level to prevent a failure in hitting critical path technical deadlines (e.g., T+5 latency testing or standards adoption pace).
Negative Consequences: Project timeline slippage; failure to meet mandatory binding standard deadlines (18 or 30 months).

**Technical Assurance & Standards Group (TASG) deadlock requiring amendment to OSDM specification that creates significant commercial detriment or contradicts non-discrimination principles.**
Escalation Level: Operational Management Group (OMG) for policy resolution, then PSC if policy required.
Approval Process: OMG resolves policy conflicts via Consensus; if policy conflict is irreconcilable or impacts financial targets (e.g., justifying cost-recovery royalties), it escalates to PSC for strategic mandate.
Rationale: Technical disagreements impact established commercial terms (Decision 2) or the finality of standards (Decision 4). This requires policy-level judgment on trade-offs between technical perfection and commercial viability.
Negative Consequences: Protracted technical uncertainty; potential conflict between technical agility and carrier cooperation.

**Compliance and Liability Assurance Board (CLAB) determination leading to recommendation for sanctioning SNCF, DB, or ÖBB regarding repeated failure to comply with API exposure deadlines ('Three Strikes' threshold met).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB recommendation, assesses political risk (Risk 1/Issue 3 mitigation), and votes on formal sanction (suspension of clearing access).
Rationale: Sanctioning a primary participant carries severe political and operational risk. It exceeds CLAB's mandate to recommend and requires the PSC for formal executive authorization.
Negative Consequences: Potential legal challenge/political pushback from that Member State; temporary fracturing of the network if service suspension is enacted.

**Determination by CLAB that clearing mechanism collateral structure (float) has dropped below 150% of peak daily obligation, posing a liquidity risk to financial settlement.**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Executive session for immediate review of solvency risk; PSC must decide on accessing the 'Emergency Float Reserve' or mandating increased bank guarantees.
Rationale: Direct threat to the financial backbone of the project (single-payment settlement) requiring immediate executive financial stewardship that surpasses the operational risk monitoring of the OMG.
Negative Consequences: Settlement failure (T+3 breach); high risk of triggering public funding top-up from the coordination budget (Risk 3).

**Major policy interpretation dispute regarding scope of 'gross distributor negligence' in cross-border failure attribution (Decision 3).**
Escalation Level: Project Steering Committee (PSC)
Approval Process: PSC reviews CLAB's assessment against the PSC's established liability cap, providing a binding interpretation that settles the dispute for all future claims.
Rationale: This interpretation defines the burden of financial risk in complex failure scenarios, directly impacting carrier financial risk models and the viability of the backstop. It requires strategic policy setting.
Negative Consequences: Inconsistent handling of passenger rights claims; potential for one stakeholder group (e.g., distributors) to shift undue financial burden post-implementation.

# Monitoring Progress

### 1. Tracking adherence to Phased Standardization Timeline (Binding vs. Provisional)
**Monitoring Tools/Platforms:**

  - TASG OSDM Specification Version Tracker
  - PSC Milestone Report

**Frequency:** Bi-weekly alignment checks; Formal review Monthly

**Responsible Role:** Technical Assurance & Standards Group (TASG)

**Adaptation Process:** If the provisional binding status (M+6) is at risk, TASG immediately recommends prioritizing PRM data schema finalization over other ancillary system integration updates. If final binding status (M+18) is at risk, the matter is escalated to the PSC for potential emergency directive approval via the OMG.

**Adaptation Trigger:** Delay in locking down specification drafts exceeding 2 calibration weeks relative to the M+6 (Provisional) or M+18 (Final Binding) mandates (Decision 4).

### 2. Real-Time API Performance and Latency Monitoring (Critical Technical Risk)
**Monitoring Tools/Platforms:**

  - OMG Centralized Reporting Dashboard
  - T+5 Latency Validation Protocol Logs

**Frequency:** Daily operational checks; Weekly OMG review

**Responsible Role:** Operational Management Group (OMG)

**Adaptation Process:** If an operator breaches the T+5 latency benchmark for two consecutive reporting cycles, OMG issues a formal 'Technical Alert' to the operator, assigns targeted technical assistance from the Capacity Building fund, and flags the operator's status in CLAB's compliance report.

**Adaptation Trigger:** Any primary participant (SNCF, DB, ÖBB) failing the T+5 latency benchmark for 7 consecutive days, indicating Risk 2 (Data Layer Instability).

### 3. Enforcement Posture Compliance Monitoring (Critical Regulatory Success Factor)
**Monitoring Tools/Platforms:**

  - CLAB Compliance Audit Report
  - Operator Service Suspension Register

**Frequency:** Monthly for primary operators; Quarterly for all others

**Responsible Role:** Compliance and Liability Assurance Board (CLAB)

**Adaptation Process:** If an operator meets the 'three strikes' threshold, CLAB compiles a suspension recommendation report, including suggested duration and political risk assessment, and immediately escalates it to the PSC for formal sanctioning according to the escalation matrix.

**Adaptation Trigger:** CLAB formally documents the third validated, un-remediated API failure event against a primary participant (Risk 1 mitigation fulfillment).

### 4. Clearing Mechanism Liquidity and Float Stress Testing (Critical Financial Risk)
**Monitoring Tools/Platforms:**

  - Financial Operations Daily Liquidity Report
  - Emergency Float Reserve Utilization Tracker

**Frequency:** Daily monitoring by Financial Operations; Weekly OMG Review

**Responsible Role:** Head of Financial Operations (via OMG)

**Adaptation Process:** If the rolling reserve fund balance drops below 150% of peak daily obligation, the OMG Chair initiates an immediate executive session with the PSC to secure access to the ring-fenced 'Emergency Float Reserve' (€300M contingency) or mandate increased bank guarantees from non-compliant carriers.

**Adaptation Trigger:** Collateral level drops below the pre-defined solvency threshold (Risk 3 mitigation trigger).

### 5. Commercial Terms Adherence (Cost Recovery Royalty Verification)
**Monitoring Tools/Platforms:**

  - External Auditing Firm Reports (Annual)
  - CLAB Royalty Verification Tracker

**Frequency:** Annual (Audit Cycle); Quarterly (Interim Check)

**Responsible Role:** CLAB (Oversight) / OMG (Coordination)

**Adaptation Process:** If the external audit reveals that carrier-reported IT operational costs used for calculating the 5% royalty cap are inflated, CLAB recommends specific adjustments to the PSC. The PSC can mandate the rejection of inflated costs, potentially leading to temporary withholding of clearing mechanism access until accurate accounting is provided.

**Adaptation Trigger:** Annual audit findings indicating royalties deviating more than 5% from expected transaction volume yields, suggesting cost inflation (Assumption Q3).

### 6. Passenger Rights Backstop Utilization Tracking (Service Level Success Factor)
**Monitoring Tools/Platforms:**

  - Backstop Utilization Ledger (Linked to T+90 threshold implementation)
  - Distributor Complaint Log (Target: -50% reduction)

**Frequency:** Monthly

**Responsible Role:** Compliance and Liability Assurance Board (CLAB)

**Adaptation Process:** If utilization of the backstop (claims paid out) is disproportionately high relative to expected delays (i.e., many successful claims are occurring below the 90-minute threshold in practice), CLAB advises the PSC to review the 'Continuity-of-Journey Failure Thresholds' (Decision 13) for necessary tightening, or investigate potential procedural manipulation.

**Adaptation Trigger:** Utilization spikes by >20% QoQ or if distributor complaints regarding resolution failure do not show a declining trend year-over-year.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All requested core components of the governance framework—Bodies (Stage 2), Implementation Plan (Stage 3), Escalation Matrix (Stage 4), and Monitoring Plan (Stage 5)—appear to be generated and substantially detailed.
2. Internal Consistency Check: The framework demonstrates strong consistency. The OMG monitors T+5 latency, which ties directly to TASG's defined protocol and the need for Decision 13 (Failure Thresholds). The CLAB enforces Decision 12 (Enforcement Posture) against the targeted primary participants identified in the assumptions (SNCF, DB, ÖBB). The PSC's role as the critical arbitrator in the Escalation Matrix is clearly defined across financial, policy, and enforcement domains.
3. Potential Gaps / Areas for Enhancement 1 (Role Clarity): The role and authority of the 'Project Sponsor (DG MOVE)' as Chair of the PSC is noted, but the specific line between the 'Project Director/Program Manager' (who manages daily operations through the OMG) and the 'Executive Sponsor' (PSC Chair) needs explicit demarcation regarding operational accountability vs. strategic oversight authority, especially concerning budget management delegated from the Sponsor.
4. Potential Gaps / Areas for Enhancement 2 (Process Depth - Conflict of Interest): While the Audit Details (provided as context) list corruption risks, the governance bodies lack an explicitly defined, mandatory *proactive* Conflict of Interest (CoI) declaration and management protocol integrated into the membership onboarding (Initial Setup Actions of PSC/OMG/TASG/CLAB).
5. Potential Gaps / Areas for Enhancement 3 (Delegation Specificity): The OMG has authority over budget shifts up to €500k. It is unclear if this delegation extends to authorizing the initial deployment of Capacity Building Grants (part of the €900M fund) before the PSC formally approves the overall grant framework, which is a key risk area identified in the audit assumptions.
6. Potential Gaps / Areas for Enhancement 4 (Integration of Policy Decisions): Strong links exist between implementation and monitoring, but the formal process for integrating the chosen strategic decisions (e.g., Decision 3: Tiered Liability Model) into the operational frameworks (e.g., CLAB's audit criteria post-launch) needs a mandatory checkpoint within the OMG/CLAB charter ratification phase, beyond just initial setup actions.
7. Potential Gaps / Areas for Enhancement 5 (Specificity of Enforcement Appeal): The Escalation Matrix correctly routes CLAB recommendations for sanctioning primary operators to the PSC. However, the mechanism for the sanctioned operator (e.g., SNCF) to appeal this sanction before execution lacks explicit procedural definition within the matrix; it currently jumps straight to PSC vote, potentially bypassing necessary dialogue.

## Tough Questions

1. Given Decision 5 (transactional fee model for capitalization) and the explicit assumption of needing a €300M Emergency Float Reserve, what is the modelled trigger frequency for drawing on this public contingency fund if initial transaction velocity is 50% lower than expected in Q1 post-launch?
2. For the primary operators (SNCF, DB, ÖBB), what specific behavioral indicators (beyond API uptime) will the CLAB use to determine if their cost recovery royalty claims (Assumption Q3) represent 'inflated IT operational expenditure' requiring the PSC to sanction withholding clearing mechanism access?
3. If the TASG is prioritizing PRM data schema finalization (Issue 1) to meet the 18-month binding deadline, what is the pre-approved Plan B for ensuring basic accessibility flagging can still operate functionally on the initial corridors if the complex two-way reservation system falls behind schedule past month 18?
4. Per Decision 13, the backstop activates at 90 minutes. If the monitoring plan consistently shows high utilization correlating with delays just *under* 90 minutes, what is the mandated review mechanism for the PSC to tighten this threshold within the first two years to meet the goal of halving distributor complaints?
5. What is the established contingency plan for the Project Director if the political de-escalation strategy (Issue 3) fails, and a major market participant, facing a 'three strikes' suspension, successfully lobbies DG MOVE leadership to halt the PSC's sanctioning process?
6. How does the OMG plan to reconcile the need for governance agility (Emergency review for 12 months, Assumption Q8) with the need for strict accountability and audit trails when issuing Provisional Operational Directives with only 65% technical consensus?
7. If the T+5 minute latency rule proves technically unsustainable for one major participant (Risk 2), is the Builder scenario policy (Decision 14) firm on maintaining the standardized T+5 requirement or is there a pre-approved, documented variance allowance (e.g., T+8 minutes for 12 months) that the PSC can utilize to prevent operational fragmentation?
8. How often (and at what level of detail) will the PSC formally review the Financial Operations Daily Liquidity Report to ensure the Head of Financial Operations is effectively managing the €200M float, given the high-stakes nature of the clearing mechanism?

## Summary

The project governance framework is robustly structured across four defined bodies (PSC, OMG, TASG, CLAB) designed to manage the intense complexity stemming from regulatory mandates, novel technical standards (OSDM), and critical financial settlement mechanisms. The chosen 'Builder' scenario emphasizes pragmatic harmonization through phased timelines and cost-sharing. Key strengths include the segregation of duties (CLAB for assurance, TASG for technical agility) and a clear escalation path to the PSC. However, success hinges on managing significant foreseen risks, particularly the political resistance to enforcement, ensuring the solvency of the transactional clearing mechanism, and rigorously following through on the challenging ancillary harmonization requirements (accessibility/loyalty) concurrently with core IT integration.

# Related Resources

## Suggestion 1 - European Rail Traffic Management System (ERTMS) / Shift2Rail (now Innovative Rail Joint Undertaking - INNOWAI)

ERTMS is the European rail traffic management system designed to ensure interoperability of railway signaling and control/command systems across the European Union (TEN-T network). Shift2Rail (and its successor, INNOWAI) focused on funding and developing next-generation railway technologies, including digital operations, advanced traffic management, and improved ticketing capabilities, often addressing pan-European integration challenges similar to the planned project. Key achievements include standardized specifications for communication protocols, data exchange, and operational procedures across various national systems.

### Success Metrics

Successful deployment of ERTMS Level 2 and trials of Level 3 across multiple member states.
Development and standardization of core specifications that underpin current digital railway operations.
Securing significant consensus among major national infrastructure managers (like DB Netz, SNCF Réseau) on common technical standards despite initial resistance.

### Risks and Challenges Faced

Stakeholder Resistance to Harmonization: National operators strongly defended legacy proprietary systems, leading to slow adoption rates initially.
Specification Volatility: Continuous changes to the ERTMS specifications meant significant rework for integrators.
Funding Gaps: Ensuring sufficient, sustained cross-border funding across multiple EU budget cycles.

### Where to Find More Information

https://shift2rail.org/ (Current work of INNOWAI, successor to Shift2Rail)
https://era.europa.eu/domain-activities/rail-infrastructure-systems/ertms_en (EU Agency for Railways overview of ERTMS)

### Actionable Steps

Contact the European Union Agency for Railways (ERA) directly. Specifically inquire about the 'ERADIS' (ERA Database Interface System) working groups for insights into enforcing OSDM-like standards across diverse IT landscapes. Look for contacts within their 'Standardisation and Interoperability' department via the official ERA website.
Review Shift2Rail/INNOWAI documentation related to 'Digital Operational Processes' and 'Terminal and Frontier Operations' to understand the established governance model for standard amendments (Decision 10).
Identify IT consultancy firms specializing in cross-border rail system integration (System Integrators) who worked on ERTMS/Shift2Rail deployment contracts, as they will have faced similar technical integration risks (Risk 2).

### Rationale for Suggestion

This is the most relevant established precedent for mandated pan-European IT and operational standard enforcement within the rail sector. It directly parallels the challenge of enforcing OSDM-compatible APIs (Decision 25/14) and managing consensus among technical stakeholders (SNCF, DB, ÖBB) within a demanding regulatory environment. The history of ERTMS adoption offers direct lessons on managing specification volatility (Risk 2) and political resistance (Risk 1).
## Suggestion 2 - EU Cross-Border Payment Regulation (PSD2 Implementation and Scheme Development)

The implementation of the Payment Services Directive 2 (PSD2) and subsequent regulatory work creating the Single Euro Payments Area (SEPA) aimed to harmonize retail payment processing across the Eurozone. This involved creating standardized technical frameworks (APIs for Account Information Service Providers and Payment Initiation Service Providers) and ensuring efficient inter-bank clearing and settlement mechanisms, often requiring centralized scheme management (like the Euro Processing System or national clearing houses collaboration). The goal was to reduce friction and cost for digital payments, mirroring the plan's objective for single-payment settlement in ticketing.

### Success Metrics

Widespread adoption of Strong Customer Authentication (SCA) protocols.
Reduction in intra-zone transfer costs to near zero.
Standardization of API interfaces for payment initiation across European banking sectors.

### Risks and Challenges Faced

Varying National Interpretations: Different national competent authorities interpreted PSD2 scope differently, leading to uneven compliance among banks.
API Usability: Early PSD2 APIs were often poorly documented or unstable, causing high integration friction for FinTechs.
Fraud Liability and Management: Determining liability for unauthorized payment transactions when multiple intermediaries are involved.

### Where to Find More Information

https://www.ecb.europa.eu/paym/retail/sepa/html/index.en.html (European Central Bank guidelines on SEPA and payments harmonization)
Reports from the European Banking Authority (EBA) on PSD2 compliance and RTS standardization.

### Actionable Steps

Consult with European FinTech bodies or regulatory compliance experts specializing in PSD2/SCA adherence for lessons on enforcing technical standards (Decision 12) on regulated entities reluctant to share data.
Investigate the design and capitalization strategy of the EU-level payment clearing/settlement system (similar to the planned clearing mechanism, Decision 5). Look for reports detailing how the float was initially secured and managed.
Contact the European Payments Council (EPC) or similar bodies to understand how they managed the introduction of transactional fees and cost-recovery models (Decision 2 for Data Access) within the payment industry.

### Rationale for Suggestion

The financial clearing and settlement mechanism (Decision 5) is the project's financial backbone. The PSD2/SEPA experience provides the most robust, real-world EU model for successfully integrating FinTech distribution (digital platforms) with incumbent infrastructure (national carriers/banks) via mandated, non-discriminatory APIs and managing cross-border financial risk and settlement speed (T+3 assumption).
## Suggestion 3 - Interoperable Accessibility Requirements for EU Rail Infrastructure (e.g., EU Directive 2019/882 implementation planning)

This umbrella covers the ongoing efforts and pilot programs across member states to transpose the EU Directive on the accessibility requirements for products and services (which includes transport) into national rail operations. While technical procurement/physical infrastructure is slow, preparatory phases involve standardizing the data exchange required for Persons with Reduced Mobility (PRM) booking, assistance coordination, and accessibility information flow across booking channels, mirroring Decision 9.

### Success Metrics

Establishment of unified data structures defining minimum requirements for PRM reservation booking across pilot corridors.
Agreement on coordinated cross-border assistance handovers.
Successfully integrating key disability advocacy groups into the technical working groups (Stakeholder Management, Risk 6).

### Risks and Challenges Faced

Physical Asset Lag: National infrastructure managers could not rapidly update physical carriages/stations to meet the strictest EU mandates, creating a gap between required data and physical reality.
Data Silos for Ancillary Services: Difficulty unifying the booking/notification process for assistance across legacy systems.
Political Sensitivity: Balancing accessibility mandates with the economic burden on smaller operators.

### Where to Find More Information

Official publications from the European Commission's DG MOVE regarding ongoing accessibility consultations in transport.
National reports from large operators (e.g., Deutsche Bahn's accessibility service documentation) detailing their efforts to integrate PRM data into online distribution.

### Actionable Steps

Contact disability and consumer advocacy groups (like BEUC or specific national PRM organizations) who were involved in shaping the requirements for Decision 9 (Harmonizing Accessibility Reservations). They can detail the negotiation tactics used to ensure mandated features were not delayed beyond core ticketing.
Identify officials within the EU Agency for Railways responsible for the Technical Specifications for Interoperability (TSIs) related to accessibility. They can provide insight into how they enforced parallel development schedules (Risk 4 mitigation).
Focus outreach on operators in the Vienna-Munich-Zurich corridor (ÖBB and DB), as they are directly involved in two critical corridors and likely faced early pressure to harmonize accessibility data exchange.

### Rationale for Suggestion

Accessibility integration (Decision 9) is identified as a major hurdle that risks regulatory non-compliance and limits the project's social relevance, despite the delay grace period assumed in the plan. Historical data from mandatory accessibility integration projects provides direct, high-fidelity insight into managing complex, politically sensitive auxiliary services integration alongside core IT rollouts (Risk 4).

## Summary

The proposed project combines large-scale regulated IT infrastructure modernization with complex, multi-sovereign governance and financial mechanism development. To ensure a 'realistic' path forward, the reference projects are drawn from proven EU-level harmonization efforts in rail technology (ERTMS/Shift2Rail) for managing standards enforcement (governance, data layer), in financial regulation (PSD2/SEPA) for building the inter-carrier clearing mechanism, and in mandatory social convergence (Accessibility Directives) for navigating politically sensitive ancillary service integration.

# Data Collection

## 1. Passenger Rights Backstop Capitalization & Liability Model Costs

As the backstop mechanism (Decision 1 & 3) is fundamental to consumer trust and financial stability, understanding the actual cost implications and legal defensibility of the liability split is critical. This directly impacts the required capitalization of the clearing house.

### Data to Collect

- Actuarial cost modeling for pooled backstop under Decision 1, Strategic Choice 2 (Collective Pool)
- Estimated frequency and severity of multi-operator fault claims based on historical data (cross-border rail incidents)
- Legal analysis of the enforceability of Strict Tiered Liability (Decision 3, Choice 1) versus Collective Insurance (Decision 3, Choice 2) under current EU transport law.

### Simulation Steps

- Use commercial actuarial software (e.g., R or Python with specific insurance libraries) to simulate 10,000 journey scenarios spanning the four priority corridors, modeling claim severity based on historical OTP/cancellation records from European Rail Agency archives (if accessible under a confidentiality agreement or public use proxy data).
- Model the float depletion curve for Decision 5 using the Builder scenario's transactional fee model, assuming a T+3 settlement speed, projecting reserve fund balance over the first 48 months.

### Expert Validation Steps

- Consult a Special Counsel for EU Consumer Protection Law to validate the legal robustness of the Strict Tiered Liability (Decision 3, Choice 1) proposal against existing passenger rights regulations.
- Consult the Financial Settlement Specialist (Expert 6) to calibrate the required capital buffer for the €200M operational float under the T+3 assumption.
- Consult the Regulatory Economist (Expert 1) to assess the long-term financial viability and regulatory risk profile of mandated insurance pooling (Decision 1, Choice 1 vs Choice 3).

### Responsible Parties

- Financial Clearing & Settlement Specialist (Expert 6)
- Passenger Rights & Equity Policy Analyst (Expert 5)
- EU Regulatory & Governance Architect (Expert 1)

### Assumptions

- **High:** The T+3 settlement reconciliation duration is achievable for 99% of transactions.
- **High:** The selected Liability model (Strict Tiered Liability, Decision 3/Choice 1 in Builder Scenario) is legally sound and defensible against immediate operator legal challenge.
- **Medium:** Historical cross-border rail incident data provides a statistically significant proxy for projected failure rates under the new unified system.

### SMART Validation Objective

Validate that the projected solvency buffer requirement for the collective insurance pool (Decision 3, Choice 2) falls within 160% of the currently allocated Emergency Float Reserve (€300M) by 2027-03-01, confirmed via financial simulation and external actuarial review.

### Notes

- The Intermodal Logistics Architect explicitly recommended pivoting Decision 3 to Choice 2 (Collective Pool) due to conflict with the 'Builder' scenario's pragmatic pace. This validation must confirm the feasibility of the *revised* liability approach.


## 2. OSDM API Latency and Technical Conformance (T+5 Benchmark)

The unified data layer is the project's technical dependency bedrock. Failure to meet T+5 latency undermines automated passenger rights (Decision 13) and invalidates operational trust. The aggressive Pacing (Decision 4) requires immediate technical proof.

### Data to Collect

- Test results validating T+5 minute latency achievement for real-time disruption data availability across OSDM endpoints on test environments.
- Feasibility assessment mapping mandatory PRM data schema requirements (Decision 9) against T+5 latency constraints against current operator IT capabilities.
- Draft Technical Failure Criteria report defining data quality metrics that trigger the first warning under the 'Three Strikes' enforcement posture (Decision 12).

### Simulation Steps

- Utilize the high-performance isolated testing environment (per Kenji Ito's needs) to run structured load tests simulating peak hourly transactions across the four core corridors.
- Run the T+5 latency monitoring tools rigorously against simulated 'disruption events' fed into the test environment to measure actual data propagation time.

### Expert Validation Steps

- Consult the IT Compliance and Enforcement Strategist (Expert 8) to finalize the technical failure thresholds that constitute a 'strike' under Decision 12.
- Consult the Accessibility Compliance Auditor (Expert 7) to verify that PRM data exchange flows meet regulatory mandates *while* adhering to the T+5 latency benchmark.
- Consult the Intermodal Logistics Architect (Expert 2) on the test result interpretation concerning the technical feasibility of the PRM integration schedule mandated by the expert review.

### Responsible Parties

- Cross-Corridor Conformance Testing Coordinator (Expert 8)
- Interoperability Standards Lead (Expert 2)
- EU Regulatory & Governance Architect (Expert 1)

### Assumptions

- **High:** The T+5 minute real-time latency benchmark is technically achievable using existing national infrastructure (with capacity grant support).
- **Medium:** Conforming SNCF, DB, and ÖBB IT systems can generate necessary OSDM data streams without requiring major architectural overhauls beyond capacity support funding.

### SMART Validation Objective

Achieve verifiable, sustained T+5 minute average latency across 95% of simulated core inventory and disruption endpoints for the initial four corridors in the test environment by 2027-03-14.

### Notes

- This validation must explicitly integrate PRM data structure testing concurrently, as advised by the expert review.


## 3. Commercial Terms Auditability and Cost Recovery Compliance

The mandated cost-recovery for data access (Decision 2) is crucial for balancing operator buy-in against distributor market entry. Its auditability must be proven immediately to prevent regulatory delays or financial disputes post-launch.

### Data to Collect

- Sample audit templates for verifying National Rail Operators' IT operational costs attributable to OSDM data provisioning.
- Initial regulatory guidance drafts detailing the enforcement mechanism for capping royalties at 5% of attributable maintenance expenditure (Decision 2).
- Comparative data on historical third-party distributor access costs vs. the proposed cost-recovery royalty structure.

### Simulation Steps

- Develop a mock financial submission template for a major operator (e.g., DB) based on known industry IT budget benchmarks, applying the 5% royalty cap to determine potential operator revenue loss/gain.
- Simulate distributor integration cost savings realized by the 5% cap versus market prevailing rates observed in the PSD2 implementation (Expert 2 Rationale).

### Expert Validation Steps

- Consult the Regulatory Economist (Expert 1) to sign off on the fairness and compliance (State Aid implications) of the 5% royalty cap model.
- Consult the Digital Distributor & Market Adoption Strategist (Expert 6) to confirm that this cost structure maximizes distributor incentive for adoption (Risk 7 mitigation).
- Consult the Rail Operator Liaison Manager (Expert 4) to anticipate operator resistance/misreporting strategies regarding cost attribution.

### Responsible Parties

- Rail Operator Liaison & Integration Manager (Expert 4)
- EU Regulatory & Governance Architect (Expert 1)

### Assumptions

- **High:** National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance.
- **Medium:** The 5% cap on royalties is sufficient to cover the national carrier's verifiable marginal costs for data provisioning.

### SMART Validation Objective

By 2027-05-01, secure documented agreement from SNCF, DB, and ÖBB representatives (via the Liaison Manager) on the audit methodology used to verify OSDM cost attribution for the first fiscal year calculation.

### Notes

- This validation directly addresses expert concern regarding verification processes for cost recovery.

## Summary

The immediate next steps must focus on reconciling the conflicting demands of the 'Builder' scenario: aggressive technical compliance (T+5 latency, PRM integration) under a pragmatic timeline, while managing political resistance to shared financial risk (Liability Pivot). The most sensitive assumptions relate to operator compliance with technical deadlines and the legal/financial viability of the chosen liability model. Action must prioritize rigorous, simultaneous testing of the core data layer stability and binding accessibility schemas, alongside establishing the auditability proof for commercial terms. The immediate actionable tasks are detailed below, focusing on validation Item 2 (Technical Stability) and Item 1 (Liability Validation) due to their high associated risk scores.

# Documents to Create and Find

# Documents to Create

## Create Document 1: Project Charter (Cross-Border Ticketing Integration)

**ID**: c5da177c-eb6d-4c9b-b213-47bc049843f2

**Description**: The foundational document authorizing the project, defining high-level scope, objectives against the five-year target (40% adoption), initial budget (€1.5B), and success metrics (50% reduction in distributor complaints). Includes alignment with the 'Builder' Scenario.

**Responsible Role Type**: EU Regulatory & Governance Architect

**Primary Template**: PMI Project Charter Template

**Secondary Template**: DG MOVE Program Initiation Template

**Steps to Create**:

- Finalize SMART criteria based on Goal Statement.
- Incorporate key strategic decisions (e.g., phased standardization, Builder scenario choices) as scope baseline.
- Obtain initial internal mandate sign-off from key initiating bodies (implied DG MOVE).
- Establish initial dependency mapping for critical path items (OSDM finalization, Clearing Mechanism capitalization).

**Approval Authorities**: DG MOVE Leadership

**Essential Information**:

- Define the 'vital few' decisions: Pacing Standard Adoption, Data Exposure Terms, Clearing Mechanism Funding, Passenger Rights Liability (Backstop Scope), and Commercial Terms for Operators.
- For each of the 14 identified 'Lever IDs', explicitly document the selected strategic choice based on the 'Builder' Scenario ('Pragmatic Harmonization and Shared Burden').
- For each of the 5 primary strategic decisions selected by the Builder scenario, detail the specific trade-offs (e.g., Speed vs. Robustness, Regulator Control vs. Private Buy-in) that were accepted.
- Integrate justifications for why the selected choices align with the 'realistic' path rather than the 'Pioneer' or 'Consolidator' alternatives, referencing required inputs (e.g., 'Builder' acceptance of phased standardization).
- Document the precise linkages (Synergy/Conflict) between the 5 primary strategic decisions and the 9 secondary decisions that are affected by them.
- Explicitly document the rationale for choosing the Builder scenario, referencing the 'scenarios.md' analysis and the high-level constraints outlined in 'assumptions.md' (e.g., avoiding overly aggressive timelines).

**Risks of Poor Quality**:

- Inconsistency between the documented strategic decisions and the overarching 'Builder' scenario selected, leading to conflicting execution guidance.
- Failure to detail the specific trade-offs accepted results in subsequent decision-makers being unable to resolve inevitable conflicts between levers (e.g., aggressive pacing vs. shared funding).
- Missing explicit connections (Synergy/Conflict) will result in unforeseen negative interactions between critical components like Liability Backstop (Decision 1) and Enforcement Posture (Decision 12).
- If the document only lists the five primary decisions without detailing the justification rooted in the realism constraint, the project might drift back toward the rejected 'Pioneer' scenario.
- Failure to capture all 14 levers, even the secondary ones affected by the primary levers, leads to an incomplete project baseline for governance.

**Worst Case Scenario**: Lack of a unified, clearly justified strategic document results in execution teams reverting to competing internal priorities (e.g., some treating standards as binding immediately while others defer them), causing critical implementation paths to diverge, ultimately leading to non-compliance with the 18-month binding standard deadline and failure to secure necessary cross-border settlement functionality.

**Best Case Scenario**: This document serves as the immutable baseline for all subsequent execution documentation (like the 'project-plan.md' mitigations) and governance meetings, ensuring that all technical requirements, financial models, and enforcement schedules are perfectly aligned with the politically selected 'Pragmatic Harmonization and Shared Burden' strategy, accelerating stakeholder agreement on implementation roadmaps.

**Fallback Alternative Approaches**:

- Conduct an immediate 'Strategy Alignment Workshop' involving the Governance Architect and key DG MOVE/Agency for Railways representatives to ratify the subset of 5 primary decisions, documenting concurrence via annotated minutes.
- If documenting all 14 levers proves too complex initially, create a simplified 'Core Decision Matrix' containing only the 5 chosen levers and their immediate dependencies/conflicts, with a mandatory review slot scheduled within 30 days to incorporate the remaining 9.
- Utilize the final decisions listed in the 'Key Strategic Decisions' section of the Builder Scenario as the mandatory first draft, focusing gap analysis solely on ensuring all conflicts/synergies mentioned in 'strategic_decisions.md' are explicitly resolved or documented.

## Create Document 2: High-Level Infrastructure & Technical Roadmap (OSDM Focus)

**ID**: af5a22aa-682f-4101-867a-066c4c1cda5e

**Description**: A strategic, phased timeline document detailing the relationships between technical milestones: OSDM V0.9 Draft (Month 6), Provisional Binding Status (Month 6), Final Binding Status (Month 18), and Mandatory API Exposure deadline (Month 30). Crucially maps Decision 4/14.

**Responsible Role Type**: Interoperability Standards Lead (OSDM/Technical Governance)

**Primary Template**: Program Milestone Tracking Template

**Secondary Template**: Shift2Rail Technical Implementation Plan Structure

**Steps to Create**:

- Incorporate mandated timelines: Provisional Binding (M6), Final Binding (M18), Exposure Deadline (M30).
- Map dependency chain showing required completion of Accessibility Schema Validation (Decision 9) prerequisite to achieving Final Binding Status (M18).
- Integrate testing phases managed by the Conformance Testing Coordinator across the three physical locations.

**Approval Authorities**: Technical Steering Committee (TSC)

**Essential Information**:

- Detail the exact relationship between Pacing the Binding Standard Adoption Timeline (Decision 4) and Pacing the Mandatory API Exposure Timeline (Decision 14).
- Explicitly define the technical milestone (e.g., what specific API endpoints/transaction types) that must be completed to qualify for 'Provisional Binding Status' at Month 6.
- Specify which Decision points (e.g., Liability Backstop parameters, Commercial Terms structure) must be finalized *before* Final Binding Status (Month 18) can be achieved.
- Map the Dependency Chain, explicitly showing how Accessibility Schema Validation (from Decision 9) prerequisites completion before Final Binding Status (Month 18).
- List the required data exchange standards (OSDM version) relevant to the Mandatory API Exposure Deadline (Month 30).
- Detail the handoff/coordination plan for integrating the results from initial testing phases managed across the three defined physical locations.

**Risks of Poor Quality**:

- Inaccurate timeline mapping will cause major schedule slippage, as mandatory exposure (M30) cannot be met if standards binding (M18) is delayed due to unvalidated dependencies.
- Failure to align technical milestones with financial/liability decisions prevents the Legal/Governance team from securing necessary authorizations for the clearing mechanism float based on technical readiness.
- If the accessibility schema validation dependency is missed or wrongly phased, the project faces regulatory non-compliance despite core ticketing launch (Risk 1/Issue 1).
- Poor dependency mapping leads to incorrect resource allocation for the 35 FTEs dedicated to standards management and testing coordination.

**Worst Case Scenario**: The technical roadmap fails to align standards finalization (M18) with the exposure deadline (M30), resulting in a de facto M30 delay for commercial launch due to dependency failure (especially regarding accessibility integration), thereby missing the 40% adoption target within the five-year limit and leading to significant legislative scrutiny.

**Best Case Scenario**: A perfectly sequenced roadmap enables Provisional Binding (M6) to confirm readiness for the initial two corridors, allowing smooth transition into Final Binding (M18) for core features, thus enabling distributors to integrate confidently and meet the Mandatory API Exposure Deadline (M30), accelerating time-to-market for single through-tickets.

**Fallback Alternative Approaches**:

- If dependency mapping proves intractable, adopt the Phase 1 schedule from the 'Consolidator' scenario—deferring complex dependencies (like Accessibility) entirely past M18, focusing only on the minimum viable ticketing standard required for M30 exposure.
- Request an immediate emergency roadmap review workshop with the TSC and OSDM governance leads to lock down the M6 and M18 boundary definitions, using assumptions (Q2/Q6) as the initial blueprint.
- Develop two parallel roadmap timelines: one adhering strictly to the Builder scenario dependencies, and one optimized for an aggressive, Pioneer-style timeline, to test sensitivity boundaries.

## Create Document 3: Financial Mechanism Design & Capitalization Framework (Builder Scenario)

**ID**: c89a653a-5ae8-42b1-b8d8-88c383dab5d0

**Description**: Framework detailing the transactional fee model (Decision 5) for funding the Clearing Mechanism float, including the formula for the variable transaction fee ('R'), the target €200M operational float, and the operational procedure for accessing the €300M Emergency Float Reserve.

**Responsible Role Type**: Financial Clearing & Settlement Specialist

**Primary Template**: Financial Instrument Design Document

**Secondary Template**: Payment Services Directive (PSD2) Financial Modeling Structure

**Steps to Create**:

- Develop the specific algorithm/formula for the variable transaction fee ('R') based on target cost recovery.
- Define the specific on/off triggers for accessing the €300M Emergency Float Reserve, coordinating with the Risk Manager.
- Draft necessary documentation for engaging third-party guarantor banks for conditional collateral.

**Approval Authorities**: EU Regulatory & Governance Architect; TSC

**Essential Information**:

- Define the specific algorithm/formula for the variable transaction fee ('R') that contributes to the rolling reserve fund, ensuring it aligns with the Builder Scenario's goal of sustainability based on transaction volume.
- Quantify the acceptable minimum reserve level (absolute minimum and trigger point for 150% peak daily obligation) of the rolling reserve fund before accessing the Emergency Float Reserve.
- Detail the exact operational procedure and access criteria for drawing upon the ring-fenced €300 Million Emergency Float Reserve, coordinated with the Risk Manager.
- Draft contractual requirements and procedural workflow for obtaining conditional third-party bank guarantees from participating carriers instead of direct capital injection.
- Model the expected impact of the T+3 settlement reconciliation duration on the required total float (€200M target) under low initial transaction velocity scenarios.

**Risks of Poor Quality**:

- An incorrectly defined transaction fee ('R') results in either market friction (if too high) or failure to self-sustain the clearing mechanism, forcing reliance on public funds unexpectedly (violating Builder Scenario logic).
- Ambiguous triggers for accessing the €300M Emergency Reserve lead to inappropriate fund usage, threatening the solvency of the mechanism during peak operational stress.
- Complex or non-standard documentation for bank guarantees deters carriers from participation or causes significant delays in securing the necessary collateral backing.
- Inaccurate modeling of T+3 impacts could lead to an inadequate target float (€200M or less), causing immediate settlement failures upon system launch.

**Worst Case Scenario**: Delayed initial settlement due to under-capitalization or collateral disputes, forcing the immediate depletion of the €300M Emergency Float Reserve and requiring a politically difficult, high-profile injection of public funds to cover shortfalls, severely undermining trust in the financial backbone of the entire project.

**Best Case Scenario**: A mathematically robust, self-sustaining transactional fee model is implemented, ensuring the €200M float is efficiently capitalized via carrier guarantees, enabling seamless T+3 settlement for 99% of transactions from day one and preserving the public budget for core infrastructure grants.

**Fallback Alternative Approaches**:

- If formula definition stalls, immediately adopt a simpler, fixed percentage fee (e.g., 0.5% per transaction) for a 6-month period, funded entirely by the public budget initially, while the specialized Financial Clearing Specialist develops the precise variable 'R' algorithm.
- If bank guarantee negotiation proves slow, temporarily substitute the required collateral with escrow accounts funded proportionally from the operational budget capacity grants (€900M), with the mandate to replace it with guarantees within 12 months.
- If the specialized modeling proves too complex, revert to the 'Pioneer' scenario's default mechanism—a full public capitalization of the €200M float—and focus this document only on the governance/audit mechanisms for that public fund.

## Create Document 4: Tiered Liability & Passenger Backstop Governance Protocol

**ID**: 23f442a2-8bbb-442a-becc-d3727e3a466e

**Description**: Protocol defining the structure and management of the pooled liability backstop mechanism, based on the chosen 'Collective Insurance Pool' model (revised Decision 3). It must detail the recoupment rules from segment carriers and the scope limit (first/last segment failure).

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Primary Template**: Risk Transfer & Insurance Protocol Template

**Secondary Template**: EU Agency for Railways Financial Backstop Mandate Draft

**Steps to Create**:

- Draft the legal language for the mandatory collective insurance pool structure (Decision 3, Choice 2).
- Define the precise actuarial model used to apportion pool contribution based on journey volume.
- Establish the initial scope limitation (first/last segment failure) for backstop activation.

**Approval Authorities**: Legal Counsel (implied); EU Regulatory & Governance Architect

**Essential Information**:

- Detail the legal language mandating the structure of the collective insurance pool for covering unknown-cause or multi-party failure compensation claims (Based on Decision 3, Choice 2).
- Define the precise, auditable actuarial model used to apportion mandatory pool contribution based on participating carrier's journey volume.
- Explicitly establish the ceiling/limit for liability covered by the EU backstop pool, as defined by the strategic decision: coverage applies only up to the connecting failure between the first and last known segments.
- Outline the complete operational workflow and timeline (e.g., T+X days) for the EU Agency for Railways to recoup covered compensation costs from the segment carrier at fault.
- Specify the trigger conditions and evidence required for a failure scenario to be classified as 'unknown-cause' warranting backstop activation.

**Risks of Poor Quality**:

- Inaccurate assessment of carrier risk exposure leading to inequitable contribution allocations, causing significant political resistance from major operators (SNCF, DB, ÖBB).
- Ambiguous recoupment rules resulting in settlement delays (violating T+3 assumption) and draining the pool's immediate liquidity, jeopardizing consumer trust metrics.
- Unclear scope limitation resulting in invalid claims against the backstop, leading to unexpected financial burden on the public budget (Risk 3).
- A weak protocol undermines the perceived strength of the Passenger Rights framework, failing to incentivize carrier compliance with data requirements (conflicts with Decision 12).

**Worst Case Scenario**: The poorly defined protocol triggers a solvency crisis in the collective insurance pool due to over-payouts on non-covered claims or protracted, complex recoupment disputes with major carriers, forcing an emergency, non-budgeted capital injection (Risk 3 realization) and undermining the core passenger confidence target.

**Best Case Scenario**: A legally robust, transparent protocol enables maximum operational efficiency for the backstop, swiftly compensating passengers within stated recovery parameters, thereby strengthening stakeholder confidence in the shared financial mechanism and supporting the overall consumer trust objective.

**Fallback Alternative Approaches**:

- Adopt the Distributor-Assumes-All-Liability model (Decision 3, Choice 3) temporarily until the complexities of pooling and recoupment can be legally finalized, shifting immediate risk management burden.
- Delegate initial operational scope to the EU Agency for Railways to manage pilot pool liquidity using a simplified, flat-rate carrier contribution derived from the expected cost of the 'Tiered Liability Model' (Decision 3, Choice 1) as a proxy.
- Utilize the 'Risk Transfer & Insurance Protocol Template' entirely, focusing only on defining the maximum acceptable loss threshold and deferring the complex recoupment workflow logic until post-provisional binding standards (Month 6).

## Create Document 5: OSDM Data Exposure Commercial Terms & Cost Recovery Policy

**ID**: f54ce20c-d35d-46a8-b64f-1b81d02a7a02

**Description**: Policy document establishing the non-discriminatory capped royalty structure for API access (Decision 2). It must define the precise methodology for auditing operator IT maintenance costs attributable to OSDM maintenance (5% cap constraint).

**Responsible Role Type**: Digital Distributor & Market Adoption Strategist

**Primary Template**: Commercial Access Policy Framework

**Secondary Template**: Cost Allocation Methodology Report Standard

**Steps to Create**:

- Define the specific cost categories considered 'attributable IT O&M expenditure' for royalty calculation.
- Develop the mandatory annual reporting template for operators to submit these audited costs.
- Establish the review cycle and escalation path (via Rail Operator Liaison) for disputes over cost attribution.

**Approval Authorities**: Regulatory Economist (Implied Review); TSC

**Essential Information**:

- Define the specific cost categories considered 'attributable IT O&M expenditure' for royalty calculation, based on the assumption that royalties are capped at 5% of this expenditure.
- Detail the standardized, non-discriminatory commercial access royalty structure, specifying the exact transaction-volume-based rate or method.
- Develop the mandatory annual reporting template for operators to submit their audited OSDM maintenance costs for regulatory review.
- Establish the precise regulatory review cycle, escalation path, and appeal process for disputes over cost attribution, aligning with TSC oversight.
- Confirm mechanism for regulator oversight ensuring that access fees strictly adhere to 'cost-recovery' principles, avoiding profit generation.
- Integrate language confirming that failure to comply with cost reporting will result in temporary barring from the centralized clearing settlement mechanism (as per Decision 2, Choice 3).

**Risks of Poor Quality**:

- If cost categories are ill-defined, operators may inflate indirect IT costs, leading to unfair/excessive royalties imposed on distributors, increasing market entry barriers.
- Lack of a clear, auditable reporting template prevents verification of the 5% cost-recovery cap, risking regulatory non-compliance and legal challenges to the commercial fairness principle.
- Ambiguous dispute resolution mechanics will slow down commercial agreement finalization, delaying distributor integration and hindering the 40% through-ticket adoption target.
- If the structure isn't non-discriminatory, it undermines the mandate for competitive market structure, concentrating power with incumbents.

**Worst Case Scenario**: The policy is successfully challenged by major national operators claiming unfair cost auditing or discriminatory application, forcing an immediate re-negotiation of the entire API access framework, causing a minimum 6-month delay to distributor onboarding and jeopardizing market uptake goals.

**Best Case Scenario**: The clearly defined, auditable, capped cost-recovery mechanism is swiftly adopted, providing regulatory certainty, maximizing distributor confidence due to low, predictable entry costs, and accelerating market penetration necessary to meet the 40% single through-ticket goal by encouraging rapid integration with OSDM APIs.

**Fallback Alternative Approaches**:

- Adopt Decision 2, Choice 2 initially: Offer API access free for two years using the public budget (€1.5B fund) to maximize penetration, postponing the complex cost-recovery audit requirement until after the initial testing phase.
- Develop a simplified template based only on direct external hosting costs related to OSDM endpoints, deferring complex internal IT cost attribution until the reference distributor (Decision 11) establishes a baseline operational maintenance budget.
- Engage external IT auditing experts immediately to draft a preliminary, legally robust audit methodology draft for immediate review by the TSC and primary stakeholders.

## Create Document 6: Enforcement & Non-Compliance Action Matrix (Three Strikes)

**ID**: 1a111cf9-bbe6-49f5-8529-707fa0dd4d78

**Description**: Detailed matrix defining the operational triggers for the 'Three Strikes' enforcement posture (Decision 12). Specifies the measurable thresholds (T+5 latency breaches, semantic error rates, downtime) that constitute a 'strike' for SNCF, DB, and ÖBB.

**Responsible Role Type**: Program Risk Manager & Contingency Coordinator

**Primary Template**: Regulatory Compliance Sanctioning Matrix

**Secondary Template**: IT Failure Reporting Standard

**Steps to Create**:

- Collaborate with the Interoperability Standards Lead to quantify specific technical failure criteria equivalent to a 'strike'.
- Map the consequences (suspension of through-ticketing sales) to the specific IT failure type/duration (Risk 2 mitigation).
- Formalize the notification procedures delivered by the Rail Operator Liaison.

**Approval Authorities**: EU Regulatory & Governance Architect; EU Agency for Railways

**Essential Information**:

- Define the precise, measurable technical criteria for a 'strike' related to OSDM API failure (e.g., T+5 latency breach count, Semantic Error Rate threshold, total downtime percentage over a quarter).
- Detail the specific consequences (the 'action') associated with Strike 1, Strike 2, and Strike 3, specifically stating which functionalities (e.g., selling new through-tickets, handling refunds) are suspended for the non-compliant operator (SNCF, DB, ÖBB).
- Establish the formal, documented process for notifying the targeted operator (SNCF, DB, ÖBB) upon the issuance of each strike, including response deadlines (e.g., 7-day remediation window).
- Identify the specific responsible entity (from the Program Risk Manager team) for logging, verifying, and reporting the data required to trigger a strike.
- Confirm the necessary legal alignment (referenced from DG MOVE) that validates the right to suspend commercial sales against sovereign rail operators.

**Risks of Poor Quality**:

- Ambiguous strike criteria will lead to challenges from compliant operators claiming unfair targeting, stalling enforcement.
- Lack of clear, documented consequence mapping will result in weak political pressure, allowing major operators to ignore deadlines (Exacerbates Risk 1).
- Ineffective notification procedures will invalidate enforcement actions on legal grounds, rendering Decision 12 moot and failing to compel timely IT integration.
- Inaccurate operational data logging will expose the Program Risk Manager team to high legal risk and expose the project to significant delays if enforcement stalls.

**Worst Case Scenario**: Ambiguous or poorly documented enforcement triggers allow the top three incumbent operators (SNCF, DB, ÖBB) to successfully lobby DG MOVE to halt the 'Three Strikes' suspension mechanism within the first year, leading to a 6-12 month delay in data layer stability and effectively neutralizing the primary behavioral lever required to meet the 30-month API exposure deadline.

**Best Case Scenario**: The clearly defined, legally sound 'Three Strikes' matrix enables decisive action against non-compliant operators (SNCF, DB, ÖBB). This predictability forces rapid investment in OSDM integration, ensuring the stability of the real-time data layer (Risk 2 mitigation) and achieving binding compliance on core corridors by the 18-month deadline, directly enabling the clearing mechanism stability.

**Fallback Alternative Approaches**:

- If technical quantification of strikes proves too slow (i.e., definitive metrics cannot be agreed by Interoperability Lead), adopt a pre-approved 'Compliance Scorecard' based on subjective regulatory audit ratings for the first 12 months, pending technical metric finalization.
- If DG MOVE approval on sales suspension is delayed, immediately substitute the enforcement action with ring-fencing capacity building funds (€900M budget) from the non-compliant operator until satisfactory audit completion.
- Utilize the European Agency for Railways to issue an immediate, non-appealable technical directive requiring alignment with the current OSDM 'Provisional Binding Status' (Month 6) for the targeted carriers, shifting the legal burden to infrastructure adherence rather than commercial suspension.

## Create Document 7: Accessibility Reservation Data Specification Requirements (PRM Integration)

**ID**: b55c7121-fd16-4012-805c-a2d2f1812801

**Description**: The technical requirements document detailing the mandatory OSDM data fields and schemas required for PRM booking and assistance notification, designed to align with the 'most restrictive national requirements' (Decision 9, Choice 1) required for Provisional Binding Status.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Primary Template**: OSDM Data Specification Addendum (Non-Core/Equity)

**Secondary Template**: Accessibility Directive Compliance Checklist

**Steps to Create**:

- Define the mandatory data fields necessary to signal assistance needs and book limited accessibility inventory.
- Map these requirements directly into the OSDM iteration planned for Provisional Binding release (Month 6).
- Develop the validation criteria for conformance testing teams.

**Approval Authorities**: Technical Steering Committee (TSC); Disability Advocacy Group Liaison

**Essential Information**:

- Detail the mandatory OSDM data fields and schemas required for Persons with Reduced Mobility (PRM) booking and assistance notification.
- Explicitly define the data requirements to align with the 'most restrictive national requirements' chosen under Decision 9, Choice 1.
- Specify the interoperability requirements necessary to support 'seamlessness of multi-operator PRM bookings' across the initial four corridors.
- List the validation criteria necessary for conformance testing teams to verify compliance against the established technical standard (to be integrated at Month 6).
- Identify the specific sections or data elements that are intentionally deferred for two-way resource deployment coordination until after the initial binding period finishes at Month 18, referencing Decision 9, Choice 2 constraints.

**Risks of Poor Quality**:

- Failure to capture the most restrictive national requirements will lead to immediate regulatory non-compliance regarding accessibility equity upon launch.
- Inaccurate mapping into the OSDM schema will cause PRM booking failures, leading to operational chaos, customer complaints against distributors, and rapid erosion of passenger trust.
- Vague validation criteria will lead to subjective conformance testing, resulting in an unstable, partially compliant data layer and creating conflict with the 'three strikes' enforcement posture.
- If the requirement for unified data exchange is misunderstood, it will necessitate costly rework post-launch when attempting to integrate fringe modes later (Risk 8 mitigation failure).

**Worst Case Scenario**: The document imposes a flawed or incomplete data standard that fails to meet mandatory EU equity regulations, resulting in immediate legal challenges against the Commission, suspension of the core ticketing system due to regulatory halt on accessibility compliance, and severe reputational damage to the entire regulatory project.

**Best Case Scenario**: The specification clearly dictates the highly restrictive, yet compliant, data schema required at Month 6, enabling the Technical Steering Committee to ratify the standard early, thus satisfying non-negotiable regulatory mandates (Decision 9) and ensuring that core ticketing and accessibility integration proceed in lockstep, mitigating Risk 4.

**Fallback Alternative Approaches**:

- Immediately revert to a simplified signal/flag mechanism (paraphrased from Decision 9, Choice 2) based only on mandatory assistance notification codes, deferring complex inventory booking until V1.1 is approved after the initial 18-month stabilization period.
- Engage the Disability Advocacy Group Liaison and a Subject Matter Expert from the most restrictive national rail operator in an intensive, three-day standards workshop to rapidly define and lock down the necessary schema placeholders for Provisional Binding status.
- If schema definition stalls, publish a 'Minimum Viable Representation' (MVR) document listing required fields only, deferring the detailed schema documentation (mapping/validation) until after the feasibility testing at Month 12.


# Documents to Find

## Find Document 1: Existing EU Legal Text on Digital Booking and Ticketing Services for Rail

**ID**: 9acbebc0-6f87-4e9c-8209-eb6ed94d973d

**Description**: The full text of the proposed or final EU Regulation governing the project scope, essential for defining regulatory constraints, success criteria, and the legal basis for enforcement and standardization.

**Recency Requirement**: Must be the most current official legislative text or draft.

**Responsible Role Type**: EU Regulatory & Governance Architect

**Steps to Find**:

- Search the European Parliament and Council official publication websites (EUR-Lex) for the latest legislative proposal draft.
- Consult DG MOVE documentation archives for internal regulatory summaries.

**Access Difficulty**: Easy

**Essential Information**:

- Identify the precise, mandated definition for 'continuity-of-journey failure' that triggers passenger rights activation (Decision 13).
- Extract the final, ratified text imposing the **binding** adoption timeline for core OSDM data exchange and transaction processing standards (Decision 4).
- Detail the legal language establishing the non-discriminatory, cost-recovery cap for API access fees overseen by regulators (Decision 2).
- List the exact regulatory leverage points permitting the suspension of a carrier's through-ticket sales capability for non-compliance (Decision 12).
- Define the official scope and limits of the EU backstop mechanism concerning which segments of a denied journey it must cover (Decision 1).
- Specify the legal mandate and governance structure defining which stakeholder groups (e.g., incumbents vs. distributors) have voting power on post-launch standard amendments (Decision 10).

**Risks of Poor Quality**:

- Failure to incorporate critical regulatory limitations (e.g., on the EU backstop scope) leads to misallocation of operational budget or over-promising consumer benefits.
- An outdated or incorrect binding standard timeline (Decision 4) results in investment freezes based on obsolete technical pathways, necessitating rework at month 18.
- Misinterpreting the terms for mandated cost-recovery royalties (Decision 2) opens the project to legal challenges from operators regarding fair compensation for data provision.
- Ambiguity in mandatory enforcement severity (Decision 12) leads to weak initial posture, encouraging widespread non-compliance from major carriers (SNCF, DB, ÖBB).

**Worst Case Scenario**: The project proceeds based on outdated or misread legal constraints, leading to immediate regulatory non-compliance on passenger rights equity or technical standards adherence upon mandatory deadline, resulting in the revocation of the €1.5B budget authorization and subsequent project collapse.

**Best Case Scenario**: The project is launched with technical requirements and financial models built precisely upon the ratified legal baseline, leading to immediate, auditable compliance by pilot operators and securing necessary authorization for the centralized financial clearing mechanism.

**Fallback Alternative Approaches**:

- Initiate an emergency legal task force comprising external EU regulatory counsel to conduct a rapid, high-assurance review of the top 5 most interconnected decisions (1, 2, 4, 10, 12).
- Require the DG MOVE Legal Counsel to formally sign off on the interpretation of all enforcement and liability clauses before committing budget beyond the governance setup phase (Decision 10).
- If binding timeline specifications are unclear, prioritize physical implementation (Testing Locations 2 & 3) using the provisional standards (Month 6 target) while delaying commitment for full capitalization of the clearing mechanism (Decision 5).

## Find Document 2: OSDM Technical Specification Documentation (Current Version)

**ID**: 957008dd-8084-40f4-8c5e-cd0ed419a83a

**Description**: The foundational technical documents outlining the current OSDM API structure, data dictionaries, semantic definitions, and any prior technical governance models used for standard amendments.

**Recency Requirement**: Most recent stable release candidate available.

**Responsible Role Type**: Interoperability Standards Lead (OSDM/Technical Governance)

**Steps to Find**:

- Obtain documentation from the European Union Agency for Railways (ERA) or the associated Technical Body.
- Search Shift2Rail/INNOWAI technical repositories for foundational standards related to digital operations.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the precise version number and release date of the current stable OSDM API structure and data dictionaries.
- Detail the complete set of semantic definitions and payloads required for core transaction processing (booking, cancellation, settlement feed).
- Extract the established governance model for technical standard amendments (relevant to Decision 10), specifically identifying the entities responsible for initial draft and final ratification.
- List all pre-existing technical governance protocols or prior models referenced or superseded by the current version that affect Decision 4 (Pacing Timeline).

**Risks of Poor Quality**:

- Using an outdated API specification leads to immediate integration failure when attempting to generate binding OSDM V1.0 compliant feeds, causing critical delay to the 18-month binding standard deadline.
- Inaccurate or incomplete semantic definitions lead to data mismatch errors in the interoperability layer (Risk 2), resulting in unstable real-time data feeds and failed passenger rights activations.
- Misunderstanding the amendment governance structure delays necessary post-launch technical pivots (Risk 5), locking the system into suboptimal configurations.
- Failure to align integration work with the *current* version forces expensive rework across all operator IT landscapes, creating resistance to enforcement (Risk 1).

**Worst Case Scenario**: Adopting a specification that is functionally obsolete or incomplete will result in all national operators building incompatible systems (Risk 2), forcing a complete halt to the binding standardization effort at the 18-month mark and delaying the core cross-border ticketing launch by 12+ months.

**Best Case Scenario**: Access to the definitive, latest standard immediately harmonizes stakeholder understanding of the technical baseline, allowing the Interoperability Standards Lead to finalize implementation plans, secure commitment from the three primary auditors (SNCF, DB, ÖBB), and accurately plan necessary capacity building grants.

**Fallback Alternative Approaches**:

- Initiate immediate, high-priority joint workshop with the EU Agency for Railways and the technical leads from SNCF/DB to cross-validate the three most critical OSDM messages against manual reconciliation results.
- Immediately mandate the 35 FTE Governance Team to produce a formal 'Delta Report' comparing the presumed current standard against the specification documents available internally across the two initial physical testing locations.
- If internal access fails, formally request DG MOVE utilize its regulatory oversight to compel the ERA/Technical Body to deliver the definitive documentation within 7 days, framed as a prerequisite for executing Decision 12 (Enforcement).

## Find Document 3: PSD2 Implementation Guidelines and Payment Cost Benchmarks

**ID**: b645a8e7-3c35-4bf9-8944-c03f2a716554

**Description**: Official specifications, cost recovery models, and settlement speed data related to the European Banking Authority's (EBA) implementation of payment standards (PSD2/SEPA), used to benchmark the clearing mechanism design (Decision 5).

**Recency Requirement**: Documents detailing T+1/T+3 settlement finality and cost recovery mechanics.

**Responsible Role Type**: Financial Clearing & Settlement Specialist

**Steps to Find**:

- Search the European Central Bank (ECB) and European Banking Authority (EBA) portals for detailed technical specifications and RTS documents.
- Review EPC working papers on intra-zone transfer cost structures.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact permissible settlement finality benchmarks (T+1, T+3) specified by EBA/EPC for commercial transfers, as this directly informs the viability of the T+3 assumption for the clearing mechanism.
- List the regulator-approved, non-discriminatory cost recovery benchmarks defined for PSD2/SEPA payment processing, specifically noting any caps or tiered structures for transaction-based fees.
- Detail the documented liquidity and collateral management procedures outlined for capitalizing the reserve/float (€200M assumed) within the clearing structure, referencing corresponding EBA guidelines.
- Provide concrete data on *actual* average intra-bank and inter-bank transfer costs observed under the current SEPA schemes to validate the assumption that a transactional fee model (Decision 5) is sustainable.

**Risks of Poor Quality**:

- Inaccurate cost benchmarking leads to under-capitalization of the project's clearing mechanism float, forcing reliance on the €300M emergency reserve sooner than planned (Risk 3).
- Misunderstanding settlement finality rules (T+3 vs. T+1 mandates) results in the designed clearing mechanism failing to meet the critical T+3 reconciliation goal, eroding carrier trust.
- Unclear cost recovery models result in the project either overcharging distributors (violating Decision 2 Commercial Terms) or under-charging, leading to disputes during the annual audit (Assumption Q3).

**Worst Case Scenario**: Adopting a flawed financial benchmark causes the clearing mechanism to experience a catastrophic capital shortfall during peak operations, leading to immediate suspension of single-payment settlement and triggering a political crisis requiring the EU budget to absorb hundreds of millions in working capital support.

**Best Case Scenario**: The document validates that industry standards allow for the project's proposed transactional fee model to be sustainable and compliant with T+3 settlement, confirming the viability of the Builder Scenario's financial dependency and reducing perceived operational solvency risk.

**Fallback Alternative Approaches**:

- Initiate targeted engagement with the EPC/EBA liaison officers to secure ad-hoc clarification sessions regarding specific operational transaction benchmarks (T+3 fidelity).
- Commission an independent forensic cost analysis comparing existing legacy inter-carrier settlement costs versus projected PSD2 transaction costs to establish a conservative, defensible internal cost floor.
- Prioritize the establishment of the €300M 'Emergency Float Reserve' buffer immediately, assuming the worst-case cost structure until definitive EBA documentation is secured.

## Find Document 4: EU Directive on Accessibility Requirements for Transport Products - National Transposition Status Reports

**ID**: 8ae75179-e77b-4612-9deb-e70ea44f8f7d

**Description**: Official documentation detailing the status of national transposition of EU accessibility laws relevant to booking/assistance services, crucial for defining the 'most restrictive requirement' for PRM data (Decision 9).

**Recency Requirement**: Current status reports or comparative analysis publications from DG MOVE/ERA.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Search DG MOVE public consultations or reports on Directive 2019/882 implementation in rail.
- Contact relevant disability advocacy liaison groups for their assessment of current national booking system gaps.

**Access Difficulty**: Medium

**Essential Information**:

- Identify the exact, legally binding transposition status (Date of Adoption, Scope of Coverage) for EU accessibility laws relevant to booking across all primary participating nations (SNCF, DB, ÖBB, etc.).
- Detail the specific national requirements that represent the 'most restrictive' criteria for Persons with Reduced Mobility (PRM) data points (e.g., required lead time for assistance notification, detailed specifications for accessible seating inventory data).
- Quantify the gap between the current, most restrictive operational requirement and the proposed OSDM V1.0 accessibility schema requirements to determine necessary modification effort.
- List all national requirements that conflict or exceed the proposed OSDM accessibility schema to inform the 'most restrictive' standard adopted per Decision 9.

**Risks of Poor Quality**:

- Inaccurate definition of the 'most restrictive' requirement will lead to the adoption of an OSDM accessibility schema that is non-compliant in certain high-volume jurisdictions (Risk of non-compliance on equity grounds).
- Adopting an overly lenient standard (if transposition status is outdated) will fail to satisfy regulatory mandates, risking fines or legal challenge against the program's core operation.
- Failure to accurately map integration needs will result in the Accessibility Reservations Infrastructure (Decision 9) being built incorrectly, forcing costly, late-stage rework that delays the 18-month binding standard deadline.

**Worst Case Scenario**: The developed unified PRM booking system fails compliance audits in key jurisdictions (e.g., Germany or France) immediately post-launch (Month 18-30), leading to regulatory fines (Risk Issue 1 mitigation failure) and requiring immediate, resource-intensive decoupling or emergency fixes that halt progress on other critical integration streams.

**Best Case Scenario**: Precise documentation enables a seamless integration of the 'most restrictive' PRM requirements into the OSDM schema at the 18-month mark, ensuring 100% regulatory equity compliance from the launch of core ticketing, thus maximizing the value proposition for users with accessibility needs and avoiding remediation costs entirely.

**Fallback Alternative Approaches**:

- Initiate direct bilateral consultations with the National Competent Authorities (NCAs) of SNCF, DB, and ÖBB to obtain the most recent, internal technical manuals regarding PRM service provisioning, bypassing potentially outdated public reports.
- Engage the Passenger Rights Advocacy Stakeholder Group to conduct a rapid gap analysis comparing their observed system limitations against the theoretical scope of the EU Directive.
- If transposition data is unobtainable, default the OSDM requirement to the single highest defined lead-time (e.g., 72 hours) for all assistance requests until official validation confirms a lower, harmonized baseline.

## Find Document 5: National Rail Operator IT Cost Attribution Policies (SNCF, DB, ÖBB)

**ID**: 77bc3d8d-e987-43fb-b466-68658e0dd70d

**Description**: Internal or publicly documented guidelines used by primary incumbent operators (SNCF, DB, ÖBB) for attributing maintenance and operational expenditure (OPEX) related to their internal IT systems, required to verify fair cost-recovery royalties (Decision 2).

**Recency Requirement**: Most recent publicly stated accounting standards or disclosures.

**Responsible Role Type**: Rail Operator Liaison & Integration Manager

**Steps to Find**:

- Search annual financial reports or sustainability/IT strategic documents published by SNCF, DB, and ÖBB.
- Contact the CER for consolidated, non-public datasets detailing typical IT cost allocation methodologies in rail.

**Access Difficulty**: Hard

**Essential Information**:

- Obtain the specific Opex/IT maintenance cost attribution policies used by SNCF, Deutsche Bahn (DB), and ÖBB for systems supporting data provisioning (API endpoints).
- Identify the internal methodology or formula used by each operator to allocate costs (e.g., direct assignment vs. rolling overhead allocation) related to maintaining the OSDM-compatible API infrastructure.
- Determine the documented accounting practice for isolating 'IT operational costs attributable to OSDM data maintenance' to verify the 5% cost-recovery royalty cap (Assumption Q3).
- Verify if the reported metrics align with the most recent publicly stated accounting standards or regulatory disclosures.

**Risks of Poor Quality**:

- Inability to accurately audit compliance with the mandated 5% cost-recovery royalty cap for API access, potentially leading to overcharging commercial distributors (Decision 2).
- If attribution policies are opaque or use inflated indirect costs, the project leadership cannot confidently defend the royalty structure against distributor challenges (Risk 7).
- Failure to establish a baseline cost structure prevents effective negotiation or enforcement against the primary initial audit participants (SNCF, DB, ÖBB) (Assumption Q4).
- Regulatory dispute regarding the fairness of data access billing, potentially eroding regulator oversight of commercial terms.

**Worst Case Scenario**: Carriers successfully inflate IT cost allocations, resulting in excessive royalties charged to distributors; this undermines the commitment to low barriers to entry, directly jeopardizing the 40% single through-ticket adoption target due to unfair commercial terms.

**Best Case Scenario**: Clear, verifiable cost attribution policies are secured for SNCF, DB, and ÖBB, allowing immediate, credible application of the regulated 5% cost-recovery royalty cap, which establishes commercial governance certainty and accelerates distributor confidence in the shared data layer.

**Fallback Alternative Approaches**:

- Initiate a mandatory, regulator-led cost audit procedure (using the EU Agency for Railways technical team) on the three primary operators to establish a standardized, externally benchmarked cost allocation methodology for OSDM maintenance.
- Temporarily implement a standardized, fixed-rate transactional fee for data access (as an alternative to cost-recovery) based on a benchmark derived from publicly available telecom API usage rates, pending receipt of audited operator data.
- Require all three major affected operators to submit their full operational expenditure reports related to IT modernization for centralized analysis by the governance body's dedicated financial team.

## Find Document 6: European Consumer Organization (BEUC) Position Papers on Through-Ticketing Friction

**ID**: 928dfd4f-d2b7-4a87-83ee-5cf8696e14cf

**Description**: Existing analysis from consumer advocacy groups detailing specific points of friction passengers currently face booking cross-border journeys (e.g., refund complexity, accessibility difficulties), essential for validating the 90-minute threshold (Decision 13) and prioritizing enhancements.

**Recency Requirement**: Documents focusing on rail/transport published within the last 3 years.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Search the official BEUC website and publications portal for transport sector reports.
- Cross-reference findings with official reports from national consumer protection bodies.

**Access Difficulty**: Medium

**Essential Information**:

- List specific instances of customer friction documented by BEUC related to cross-border rail refunds/rebooking complexity.
- Quantify the observed difficulty (e.g., average time taken, number of contacts required) for passengers encountering journey failures under current national frameworks.
- Detail specific pain points identified regarding accessibility booking integration (PRM) that must be addressed by Decision 9.
- Identify specific findings that directly inform or challenge the preliminary '90-minute continuity failure threshold' (Decision 13).

**Risks of Poor Quality**:

- Inaccurate characterization of current passenger friction leads to setting the continuity threshold (Decision 13) too high, resulting in consumer mistrust and failure to meet the goal of a 50% reduction in complaints.
- If accessibility issues are underrepresented, the framework may launch with insufficient harmonization on PRM booking (Decision 9), triggering regulatory conflict immediately.
- Failure to incorporate binding evidence from BEUC allows incumbent operators to successfully lobby for weaker liability rules (Decision 3) or less stringent enforcement (Decision 12).

**Worst Case Scenario**: The project launches with a continuity failure threshold (Decision 13) that is too lenient, leading to widespread public backlash, widespread regulatory intervention against the EU Agency for Railways, and jeopardizing the overall goal of achieving consumer trust necessary for the 40% adoption target.

**Best Case Scenario**: Precise quantification of current booking/refund friction allows the team to calibrate Decision 13 (90-minute threshold) optimally for maximum consumer benefit while managing backstop liability costs, leading to immediate positive media coverage and strengthening stakeholder support for the program's equity goals.

**Fallback Alternative Approaches**:

- Initiate targeted, structured interviews with 5-10 independent travel distributors known for high cross-border volume to generate anecdotal evidence on current friction points.
- Commission a rapid, targeted analysis focusing solely on comparing refund/rebooking SLAs between the primary pilot carriers (SNCF, DB, ÖBB) for recent multi-carrier failures.
- Engage Passenger Rights Advocacy stakeholders directly to draft an 'evidence summary statement' enumerating required minimum functionality for Decision 13 and Decision 9 compliance.

## Find Document 7: Benchmark Data on Real-Time Latency for Current Rail Operations (T+5 Data)

**ID**: b23b2f5c-ab17-4d0f-b4b1-5c70e912b10c

**Description**: Existing internal performance data or benchmark studies from major operators (or ERA studies) showing the typical end-to-end latency performance for current disruption notification systems, necessary to assess the feasibility of the mandated T+5 minute benchmark.

**Recency Requirement**: Data capturing performance under peak operational load, last 1-2 years.

**Responsible Role Type**: Cross-Corridor Conformance Testing Coordinator

**Steps to Find**:

- Liaise with the Interoperability team to request operational telemetry data shared previously via Shift2Rail testing programs.
- Engage IT consulting firms who have worked on ERTMS integration for proprietary performance insights.

**Access Difficulty**: Hard

**Essential Information**:

- Quantify the typical end-to-end latency (in minutes) for current disruption notification systems across major operators (SNCF, DB, ÖBB) for events leading to potential passenger rights activation.
- Identify the operational load factor under which the benchmark data was collected (e.g., typical vs. peak holiday traffic).
- List specific studies or internal reports (e.g., Shift2Rail telemetry output) confirming the source and date of the latency figures.
- Detail the gap between the current recorded maximum latency and the mandated T+5 minute benchmark, quantifying the required technical improvement per segment.

**Risks of Poor Quality**:

- Inaccurate benchmark data (e.g., using off-peak figures) leads to an overly optimistic assessment of the T+5 minute target feasibility, masking severe integration challenges (Risk 2).
- Using outdated data (pre-COVID/pre-2022 capacity changes) results in mandating a T+5 requirement that is technically impossible given current infrastructure limits.
- If the data is internal/proprietary and lacks comprehensive coverage (e.g., missing ÖBB), the enforcement posture against non-compliant operators will lack foundational evidence.
- Failure to verify the source leads to reliance on unverified metrics, undermining the credibility of the entire Conformance Testing Coordination effort.

**Worst Case Scenario**: Adopting an overly optimistic benchmark leads to setting the provisional binding standard (Month 6) and mandatory T+5 requirement based on false premises, resulting in mass technical failure during the main API rollout (Month 30), jeopardizing the entire data layer stability and leading to severe enforcement backlash (Risk 1 and Risk 2).

**Best Case Scenario**: High-quality, recent data confirms that the T+5 latency benchmark is achievable through focused technical assistance (Decision 6/Capacity Budget), allowing the Conformance Testing Coordinator to confidently proceed with setting aggressive, but achievable, operational readiness milestones, building initial trust with stakeholders.

**Fallback Alternative Approaches**:

- Initiate immediate, narrowly scoped technical spikes (PoCs) with DB and SNCF focusing *only* on measuring current real-time path latency for a predefined disruption scenario (e.g., signal failure).

- Engage the EU Agency for Railways to commission a rapid, targeted performance audit on the two pilot corridors, focusing specifically on the data chain between disruption detection and current central system notification.
- Temporarily adopt the most conservative (slowest) available performance metric from any primary participant (SNCF, DB, ÖBB) as the assumed baseline to protect the T+5 requirement from being overly optimistic, thereby forcing a safer implementation path, even if it stresses the Governance structure (Decision 10).

## Find Document 8: National Rail Discount/Loyalty Scheme Rule Books (Top 3 Volume Schemes)

**ID**: 32724029-5c61-4e66-9430-279c738aa2e3

**Description**: The complete legal rulebooks for the highest-volume national reduction cards (e.g., BahnCard, Carte Avantage), required to understand the complexity of converting monetary value or functionality for cross-border recognition (Decision 8).

**Recency Requirement**: Current, official rulebooks applicable as of the current year.

**Responsible Role Type**: Passenger Rights & Equity Policy Analyst

**Steps to Find**:

- Visit the official websites of the major operators (SNCF, DB, ÖBB) and navigate their loyalty/discount sections.
- Consult with the Rail Operator Liaison to obtain definitive, consolidated handbooks if public versions are incomplete.

**Access Difficulty**: Medium

**Essential Information**:

- List the exact, specific monetary value or percentage discount applied by Decision 8's chosen strategy (Strategy 1, 2, or 3) on the base, full-fare ticket price for the top three national reduction cards (BahnCard, Carte Avantage, etc.).
- Detail the operational steps required for a distributor to verify if a customer's reduction card eligibility translates into a correctly applied discount via the new clearing mechanism for the first cross-border transaction.
- Quantify the revenue differential (in Euros/Transaction) between recognizing the full national loyalty benefit versus applying the temporary EU 'Cross-Border Discount Voucher' substitute, as this informs the risk analysis for Decision 8.
- Identify the specific data fields within the OSDM standard that must be populated by the carrier to confirm the validity status of the recognized discount card, ensuring compliance with harmonization efforts (Decision 8 synergy).

**Risks of Poor Quality**:

- Implementing the wrong conversion mechanism (e.g., using the substitute voucher instead of direct rule reconciliation) leads to over- or under-compensation, resulting in immediate financial disputes with national operators.
- Inaccurate understanding of complex national scheme rules (e.g., blackout dates, eligibility co-pays) causes the system to reject valid loyalty claims, leading to the high consumer complaint target miss (50% reduction goal failure).
- Failure to secure current rulebooks prevents accurate technical mapping, resulting in the adoption of an outdated schema that is immediately incompatible when national rules change.

**Worst Case Scenario**: If the rulebooks are inaccessible or misunderstood, the project defaults to the most difficult (but rejected) strategy of full, immediate, complex harmonization, leading to a resource drain, a 6-month delay in core ticketing launch to resolve discount conflicts, and alienating loyal customer bases, thereby jeopardizing the 40% adoption target.

**Best Case Scenario**: Precise knowledge of the top three schemes allows the immediate, high-quality implementation of the chosen Builder strategy (likely substitution or simple monetary application), maximizing immediate customer value realization, directly supporting the synergy with data exposure terms, and accelerating initial distributor adoption by maximizing the value proposition for existing loyal customers.

**Fallback Alternative Approaches**:

- Immediately implement the fallback Strategic Choice 2: Temporarily substitute all national discount cards with a single, standardized EU 'Cross-Border Discount Voucher' distributed automatically, while policy analysis continues in the background.
- Engage the National Regulatory Bodies (NRBs) for the top three operators (DB, SNCF, ÖBB) via the mandated National Competent Authorities channel to demand expedited delivery of the specific cross-border conversion logic required for system integration.
- Isolate the accessibility harmonization work (Decision 9) and allocate dedicated integration FTEs to it, ensuring the discount decision (Decision 8) does not block the delivery of mandatory equity compliance.

# SWOT Analysis


## Strengths 👍💪🦾
- EU regulatory backing and alignment with the Digital Booking and Ticketing Services for Rail Regulation
- €1.5 billion public coordination budget for standards, testing, and infrastructure
- Phased implementation approach (18-month standards, 30-month API exposure) reduces risk
- Strong governance framework with technical steering committees and enforcement mechanisms
- Existing precedent from ERTMS and PSD2 for cross-border standardization and financial mechanisms

## Weaknesses 👎😱🪫⚠️
- Lack of a clearly defined, immediately deployable 'killer app' to drive early adoption
- High dependency on national operators' willingness to adopt OSDM standards and share data
- Potential resistance from incumbent distributors and operators to relinquish control over ticketing
- Complexity of harmonizing accessibility, reduction cards, and liability frameworks across 20+ national systems
- Risk of undercapitalization of the clearing mechanism if transactional velocity is low

## Opportunities 🌈🌐
- Growing demand for sustainable travel options (modal shift from air to rail)
- Potential for a unified mobile app or platform as a 'killer app' for seamless cross-border travel
- Leveraging EU Green Deal incentives for digital and transport infrastructure
- Partnerships with third-party distributors (e.g., Trainline, Omio) to accelerate market penetration
- Integration of non-rail modes (buses, ferries) as a value-add feature post-launch

## Threats ☠️🛑🚨☢︎💩☣︎
- Political resistance from national operators prioritizing legacy systems over standardization
- Technical challenges in real-time data integration and latency management (T+5 minute benchmark)
- Financial risks from undercapitalized clearing mechanisms or low transactional velocity
- Regulatory delays or changes in EU policy affecting implementation timelines
- Consumer skepticism about the reliability of through-ticketing compared to existing options

## Recommendations 💡✅
- By 2026-11-14, release the Provisional Binding Specification V0.9 with mandatory PRM data schema integration to establish a foundational 'killer app' for accessibility (Owner: EU Agency for Railways).
- By 2026-12-31, pilot a public reference distributor app with real-time booking and refund capabilities on the Paris-Brussels-Amsterdam corridor to demonstrate the through-ticketing 'killer app' (Owner: DG MOVE).
- By 2027-03-31, negotiate with major operators (SNCF, DB, ÖBB) to incentivize early API compliance via capacity-building grants tied to 90% uptime targets (Owner: CER).
- By 2027-06-30, launch a marketing campaign highlighting the 90-minute continuity-of-journey guarantee as the core value proposition of the through-ticketing system (Owner: BEUC).
- By 2027-09-30, establish a feedback loop with distributors and passengers to refine the 'killer app' features based on early adoption metrics (Owner: EU Agency for Railways).

## Strategic Objectives 🎯🔭⛳🏅
- Achieve 40% cross-border through-ticket adoption within five years by 2031-05-14 (SMART: Specific, Measurable, Time-bound).
- Reduce distributor complaints by 50% through standardized refund processes and liability backstop mechanisms by 2029-05-14 (SMART: Achievable, Relevant).
- Complete OSDM API exposure on 100% of priority corridors by 2028-05-14 (SMART: Time-bound, Specific).
- Secure €200M initial clearing mechanism float with 150% liquidity buffer by 2027-01-31 (SMART: Measurable, Achievable).
- Integrate accessibility reservations into 100% of core corridors by 2028-12-31 (SMART: Relevant, Time-bound).

## Assumptions 🤔🧠🔍
- The €1.5B budget will be allocated as planned, with no significant reallocation due to political pressure.
- National operators will comply with OSDM standards by the 30-month deadline without major rework.
- The T+5 minute real-time data latency benchmark is achievable with existing infrastructure.
- The 'three strikes' enforcement posture will not trigger significant political backlash from major operators.
- Distributors will adopt the new system rapidly once the 'killer app' features (e.g., single payment, unified refunds) are demonstrated.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Detailed adoption rates of similar systems (e.g., ERTMS, PSD2) in other sectors for benchmarking.
- Quantitative data on passenger willingness to switch from air to rail with the proposed through-ticketing system.
- Specific technical challenges expected from legacy systems in implementing OSDM APIs.
- Detailed cost-benefit analysis of the 'killer app' features versus the baseline system.
- Long-term financial projections for the clearing mechanism under varying transactional velocity scenarios.

## Questions 🙋❓💬📌
- How can we ensure the 'killer app' of through-ticketing is perceived as a must-have feature rather than an incremental improvement?
- What specific metrics should we track to validate the success of the 'killer app' in the first year of rollout?
- How might resistance from national operators impact the development and adoption of the 'killer app'?
- What role should third-party distributors play in promoting the 'killer app' to end-users?
- How can we mitigate the risk of the 'killer app' being overshadowed by technical or regulatory delays?

# Team

*Roles Needed & Example People*

# Roles

## 1. EU Regulatory & Governance Architect

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The EU Regulatory & Governance Architect must maintain constant alignment with DG MOVE/Agency for Railways and anchor operational decisions, requiring deep internal commitment and continuous presence, suitable for a full-time role.

**Explanation**:
Responsible for ensuring compliance with the proposed EU Regulation, managing stakeholder reporting to DG MOVE and the EU Agency for Railways, and anchoring the project's operational decisions within the political and legal framework.

**Consequences**:
Risk of misalignment with final legal text, slow approvals on binding standards (Decision 4), and failure to establish functional enforcement posture (Risk 1).

**People Count**:
min 1, max 2, depending on workload for DG MOVE liaisons

**Typical Activities**:
Leading monthly alignment sessions between the Project Steering Committee and DG MOVE; drafting legal instruments making OSDM specifications provisionally and formally binding; establishing the legal basis for cross-border enforcement mechanisms (the 'Three Strikes' policy); managing liaison reporting schedules for the Agency for Railways.

**Background Story**:
Dr. Elara Vancini, hailing from Rome, Italy, brings a formidable background forged through years at the intersection of EU transport law and digital policy implementation; she holds a dual Ph.D. in European Public Law and Information Systems from Leiden and Bologna Universities, enabling her to bridge complex regulatory mandates with technical realities. Her extensive experience includes serving as a senior advisor during the initial drafting phases of several major EU digital service regulations, giving her firsthand knowledge of how mandates translate (or fail to translate) into binding technical standards, and she is intimately familiar with the consensus-building required among Member States. Elara is exceptionally relevant because her expertise ensures that the project’s governance (Decision 4 & 10) and enforcement posture (Decision 12) are legally defensible and politically robust, preventing the kind of stakeholder stalling that plagued earlier infrastructure projects.

**Equipment Needs**:
Access to secure EU network infrastructure for sensitive policy document exchange and DG MOVE/Agency for Railways secure digital reporting portals.

**Facility Needs**:
Dedicated office space with high-security classification in Brussels (Location 1) for continuous governance presence and confidential policy workshops.

## 2. Interoperability Standards Lead (OSDM/Technical Governance)

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Interoperability Standards Lead needs to drive OSDM finalization and manage continuous governance changes. This requires dedicated, long-term organizational commitment to ensure technical stability throughout the five-year lifespan.

**Explanation**:
Drives the definition, finalization, and amendment process for the OSDM-compatible APIs, ensuring the technical specifications meet the T+5 latency benchmark and address ancillary requirements like accessibility data structures.

**Consequences**:
Technical divergence between operators, unstable data layer (Risk 2), failure to meet API exposure deadlines (Decision 14), leading to platform instability.

**People Count**:
3, to cover standards definition, technical drafting, and drafting procedural documentation for governance amendments efficiently.

**Typical Activities**:
Chairing the Technical Working Group for OSDM finalization; overseeing the drafting and release of the Provisional Binding Specification V0.9; designing the data validation protocols ensuring T+5 latency compliance for real-time inventory feeds; analyzing system proposals from rail operators for OSDM-backward compatibility.

**Background Story**:
Kenji Ito, originally from Tokyo but having completed his Master’s in Computer Science at ETH Zurich, specializes in high-throughput, distributed ledger technologies and API standardization, having previously worked on designing transactional messaging systems for global logistics firms coordinating supply chains across Asia. Kenji possesses deep, practical experience with high-velocity data layers, specifically ensuring latency metrics like the T+5 minute benchmark are technically achievable and verifiable under real-world load, making him the perfect lead for OSDM implementation. He is relevant because the entire project hinges on the technical success of the shared real-time data layer; Kenji’s ability to shepherd the OSDM specification through provisional binding status and manage necessary post-launch amendments (Decision 10) is crucial to mitigating technical risk (Risk 2).

**Equipment Needs**:
High-performance, isolated testing environment (sandboxed OSDM V0.9 instance) capable of simulating high-volume, multi-party data exchanges (T+5 latency testing). Access to advanced API monitoring and debugging tools.

**Facility Needs**:
Primary workspace in Brussels (Location 1) and guaranteed functional access to dedicated testing labs at either Location 2 or Location 3 for physical integration checks.

## 3. Financial Clearing & Settlement Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Financial Clearing & Settlement Specialist is responsible for the core financial backbone, including critical infrastructure ($200M float, transactional models). This demands sustained, dedicated oversight and fiduciary responsibility best suited to an FTE.

**Explanation**:
Designs, capitalizes, and manages the ongoing solvency of the inter-carrier clearing mechanism. This role models the transactional fee structure, monitors the Emergency Float Reserve (€300M), and advises on settlement reconciliation (T+3 assumption).

**Consequences**:
Financial instability leading to settlement delays, failure of single-payment settlement objective, and potential depletion of the security float (Risk 3).

**People Count**:
2, due to the critical nature of finance and the need for simultaneous simulation/design during the setup phase.

**Typical Activities**:
Developing the definitive algorithm for the variable transactional fee ('R') applied to ticket sales; modeling liquidity requirements for the €200M operational float under various velocity scenarios; managing due diligence procedures for external bank guarantees; coordinating with the Risk Manager to authorize drawdown protocols for the Emergency Float Reserve.

**Background Story**:
Sofia Rossi, a financial engineer from Milan, Italy, arrived with a reputation for stabilizing complex inter-institutional transactions, having spent a decade at a major European investment bank designing counterparty risk mitigation models for emerging EU-wide financial services legislation. Her expertise lies in creating solvent mechanisms from scratch, a skill honed during the post-crisis mandate to ensure liquidity in cross-border finance; she is highly familiar with capitalization modeling, collateralization, and transaction fee structures, aligning perfectly with Decision 5 and the Builder scenario's transactional fee approach. Sofia is indispensable because the clearing mechanism is the operational heart of the single-payment objective; her role is to ensure its solvency using the transactional fees while monitoring the €300M emergency float reserve against low early velocity (Risk 3).

**Equipment Needs**:
Specialized financial modeling software (e.g., Monte Carlo simulation tools for liquidity stress testing) and access to escrow/guarantor bank portals for monitoring collateral.

**Facility Needs**:
Secure, shielded working environment for managing financial float data; primary base ideally near central European financial hubs, though Brussels (Location 1) suffices for governance alignment.

## 4. Rail Operator Liaison & Integration Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Rail Operator Liaison must manage high-stakes, ongoing relationships with 20+ operators, driving adoption and compliance reporting. This sustained engagement and political navigation require a dedicated, integrated FTE.

**Explanation**:
The primary interface for the 20+ national rail operators (SNCF, DB, ÖBB, etc.). Responsible for driving adoption, verifying commercial cost-recovery reporting, and managing compliance auditing for the primary enforcement targets.

**Consequences**:
Political resistance hardening (Risk 1, Risk 6), failure to enforce data exposure, and inability to track IT operational costs for royalty calculation (Decision 2).

**People Count**:
min 1, max 3, depending on the complexity/number of initial operators engaged.

**Typical Activities**:
Conducting quarterly compliance verification workshops with SNCF and DB representatives, focusing on IT cost attribution for royalty calculations; leading negotiations on the tiered liability model (Decision 3) with national regulatory bodies; serving as the primary contact for implementing the 'Three Strikes' enforcement posture.

**Background Story**:
Mathias Weber, a seasoned manager raised near Frankfurt, Germany, spent twenty years at Deutsche Bahn’s corporate strategy division, specializing in navigating national regulatory hurdles and negotiating integration compromises between domestic mandates and EU-level interoperability goals post-2010. His deep institutional memory of operator hesitations regarding data sharing and his established relationships with IT directors at major lines make him the vital bridge between the centralized project team and the 20+ decentralized national carriers. Mathias is essential because he is tasked with achieving buy-in and ensuring compliance from the very entities most likely to resist external control (SNCF, DB, ÖBB); his success governs the feasibility of both the data exposure deadlines and the layered liability framework (Risk 1 and Risk 6 mitigation).

**Equipment Needs**:
Secure communication channels (encrypted lines primarily) for confidential negotiations with national carrier executives (SNCF, DB, ÖBB). Access to operator IT team contact lists and organizational charts.

**Facility Needs**:
Flexible meeting facilities capable of hosting workshops with operators, potentially requiring travel to host countries (France, Germany, Austria) for targeted engagement sessions.

## 5. Passenger Rights & Equity Policy Analyst

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Passenger Rights & Equity Policy Analyst focuses on complex regulatory interpretation (90-min threshold, accessibility) crucial for success, but this specialized legal/policy expertise is often sourced externally via short-to-medium term contracts for specific policy drafting.

**Explanation**:
Focuses entirely on the consumer-facing elements: setting the 90-minute continuity threshold (Decision 13), designing the structure of the pooled backstop, and ensuring compliance with accessibility harmonization (Decision 9) and reduction card recognition (Decision 8).

**Consequences**:
Failure to meet consumer trust goals, regulatory non-compliance on equity grounds (Risk 4), and potential legal challenges regarding the 90-minute trigger threshold.

**People Count**:
1, as the area requires deep policy knowledge but is distinct from the primary financial/technical integration work.

**Typical Activities**:
Analyzing the actuarial impact of the 90-minute continuity threshold (Decision 13) against disability rights advocacy group submissions; drafting policy guidance for integrating national reduction card value conversion (Decision 8); serving as the primary liaison with BEUC and disability rights bodies to validate the fairness of the pooled backstop structure.

**Background Story**:
Anya Petrova, based out of Warsaw, Poland, transitioned into policy analysis after starting her career lobbying for robust consumer protection in the telecommunications sector, giving her a sharp focus on regulatory fairness and equitable access. She holds advanced degrees in International Consumer Law and is deeply familiar with the political sensitivity surrounding national loyalty programs and accessibility mandates across Eastern and Western European markets. Anya is crucially relevant because the success metrics include halving distributor complaints and improving modal attractiveness, both of which rely heavily on consumer trust derived from fair dealings regarding delays and discounts. She is responsible for translating complex legal requirements for PRM booking (Decision 9) and discount recognition (Decision 8) into practical, enforceable operational thresholds (Decision 13).

**Equipment Needs**:
Access to regulatory drafting software and comparative law databases focused on EU consumer rights directives. Tools for modelling the impact of various delay/refund thresholds on passenger trust metrics.

**Facility Needs**:
Dedicated meeting space for consultations with consumer advocacy groups (BEUC) and disability rights bodies, likely based within the Brussels administrative hub (Location 1) for ease of engagement.

## 6. Digital Distributor & Market Adoption Strategist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Digital Distributor & Market Adoption Strategist focuses on commercial terms and uptake metrics (40% target). This role benefits from external insights from market-facing entities (like FinTech/OTA perspectives) and may be contracted for specific commercial modeling/engagement periods.

**Explanation**:
Represents the needs of platforms (Trainline, Omio) and the public reference distributor. This role drives adoption by ensuring commercial terms (Decision 2) are fair and API usability is maximized, directly tracking progress toward the 40% sales target.

**Consequences**:
Distributors may reject the system due to high integration costs/poor API stability (Risk 7), jeopardizing the 40% sales metric.

**People Count**:
min 1, max 2, depending on the competitive landscape analysis required.

**Typical Activities**:
Validating the proposed capped royalty structure (Decision 2) against market expectations for data access costs; designing incentive frameworks for the Public Reference Distributor's uptake; modeling distributor dependency curves based on API usability and commercial terms; reporting progress against the 40% market penetration target.

**Background Story**:
Chloe Dubois, an independent consultant from Paris, France, specialized in Digital Marketplaces and Platform Economics, having previously advised European OTAs (Online Travel Agencies) on scaling customer acquisition and managing dynamic pricing across complex inventory systems. Chloe brings an external market perspective, understanding that the 40% through-ticket goal relies entirely on distributors finding the new APIs commercially viable and easy to integrate. Her expertise in commercial structuring (Decision 2) and adoption strategies is necessary to counteract platform friction (Risk 7). She is relevant because she ensures the project output is competitive and attractive to the third-party distributors who must sell the final product, balancing their integration costs against the capped royalty structure.

**Equipment Needs**:
Access to distributor API sandbox environments for usability testing; market analysis software for tracking cross-border ticket sales velocity and competitor performance.

**Facility Needs**:
Flexible collaboration space suitable for joint workshops with independent distributors (e.g., in a central European business/tech hub).

## 7. Program Risk Manager & Contingency Coordinator

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Program Risk Manager & Contingency Coordinator owns the integrated risk register and manages immediate contingency activation protocols (like Emergency Float release). This necessary organizational continuity and rapid response capability demands a dedicated, embedded FTE.

**Explanation**:
Owns the integrated risk register, tracks adherence to the five-year deadlines, manages the relationship between the rapid amendment governance (Decision 10) and the emergency float release protocols (Contingency Action), ensuring agility and swift response to critical failures.

**Consequences**:
Critical risks (like clearing float depletion or political enforcement failure) are not escalated or addressed with contingency plans quickly enough, leading to cascading delays (Risk 5).

**People Count**:
1, this is a dedicated oversight function central to the 'Builder' scenario's pragmatic, risk-managed execution.

**Typical Activities**:
Chairing the bi-weekly risk review board; coordinating immediate technical response drills when T+5 latency spikes threaten the continuity threshold; managing the formal governance process for enacting provisional operational directives under the emergency mandate; ensuring all regulatory reporting milestones are flagged in advance for mandatory DG MOVE sign-offs.

**Background Story**:
Dr. Liam O’Connell, based in Dublin, Ireland, has a background in enterprise risk management methodologies, specializing in regulatory compliance monitoring across multinational, multi-year infrastructure programs funded by the EU. Liam’s specialty lies in tracking complex critical path dependencies, particularly the reliance of financial mechanisms on technical milestones, and creating the operational procedures to activate contingency plans swiftly. He is responsible for owning the integrated risk register and ensuring that the governance agility measures (Decision 10) are properly aligned with the financial backstops (the Emergency Float). Liam’s role is central to the 'Builder' scenario, as his focus prevents unforeseen technical or political issues from causing cascading delays or financial insolvency (Risk 5 and Risk 3).

**Equipment Needs**:
Access to the integrated risk register visualization dashboard and automated alerting system linked to contingency triggers (e.g., float depletion, governance deadline breaches).

**Facility Needs**:
A dedicated, secure office location (Brussels preferred) allowing for rapid mobilization of crisis response teams when contingency plans are enacted.

## 8. Cross-Corridor Conformance Testing Coordinator

**Contract Type**: `agency_temp`

**Contract Type Justification**: The Cross-Corridor Conformance Testing Coordinator manages a large team (15 FTEs) conducting intensive, short-to-medium term technical validation across physical hubs. This project-specific, surge capacity requirement is best filled by experienced technical staff supplied via an agency contract.

**Explanation**:
Manages the 15 assigned testing FTEs, coordinating physical testing logistics across the three designated hub locations (Brussels, Corridor 1 Area, Corridor 2 Area) to resolve integration issues (Risk 2) and validate T+5 latency benchmarks.

**Consequences**:
Testing becomes siloed or uncoordinated, leading to prolonged technical instability and failure to certify core APIs by the 18-month deadline.

**People Count**:
2, to provide operational redundancy and cover logistics across multiple physical testing sites simultaneously.

**Typical Activities**:
Designing and executing end-to-end integration test suites across simulated and live environments for the initial corridors; coordinating the physical logistics for testing teams deployed to Location 2 and Location 3; verifying operator compliance with the T+5 minute latency benchmark through dedicated monitoring tools; creating final conformance certification reports for the EU Agency for Railways.

**Background Story**:
Dr. Benjamin Koo, who took his doctorate in Logistics Engineering from Delft in the Netherlands, is an expert in large-scale testing orchestration, having managed the deployment QA for complex European rail signaling projects like ERTMS. He knows precisely how to coordinate technical testing across disparate physical environments, making him ideal for coordinating the 15 dedicated testing FTEs across the Brussels hub and the two initial corridor testing grounds. Benjamin is critical for mitigating major technical risk (Risk 2) by designing test scenarios that force failures in data latency (T+5) and cross-operator fault attribution; his teams validate the feasibility of the hard deadlines mandated for API exposure (Decision 14).

**Equipment Needs**:
Logistics management suite for coordinating the 15 testing FTEs across multiple physical sites (Location 2 and 3). Budget tracking for travel, local access permits, and testing infrastructure deployment.

**Facility Needs**:
Dedicated logistics and coordination office access at Location 2 and/or Location 3 to manage on-the-ground testing operations proximal to core corridor infrastructure.

---

# Omissions

## 1. Missing Dedicated Standards Maintenance/Evolution Team

The team has an Interoperability Standards Lead group (3 FTEs) focused on *finalizing* OSDM V1.0. However, given the binding timeline (18 months) and the need for rapid post-launch amendments (Decision 10 concerns), there is no dedicated resource aligned with Risk 5 (slow governance) specifically tasked with the ongoing maintenance, testing, and iteration/V2.0 planning post-launch.

**Recommendation**:
Add one dedicated Technical Standards Engineer (perhaps agency_temp for high initial burst) whose sole mandate is maintaining the OSDM specification documentation and coordinating the Technical Steering Committee's provisional directives post-launch, ensuring technical agility without burdening the initial design team.

## 2. Lack of Dedicated IT Audit/Compliance Verification Team

The success of Decision 2 (Capped Royalties at 5% IT Cost Recovery) relies on rigorous annual auditing of operator IT maintenance costs. The existing team focuses on *enforcement* (Liaison Manager) and *core design*, but staff dedicated specifically to complex IT cost attestation, against potentially resistant national operators (SNCF, DB, ÖBB), are missing.

**Recommendation**:
Allocate budget to contract specialized IT forensic accountants or IT auditors (perhaps linked to the Conformance Testing Coordinator's external support structure) for a 6-month engagement annually, specifically to scrutinize operator cost submissions against the 5% royalty cap.

## 3. No Dedicated Cross-Corridor Testing Infrastructure/Logistics Support

The Conformance Testing Coordinator manages 15 FTEs spread across three physical locations (Brussels, Corridor 1 Area, Corridor 2 Area). This role risks becoming purely administrative, lacking dedicated logistical support to manage travel, hardware deployment, and localized testing environments specific to national differences outside Brussels.

**Recommendation**:
Assign one administrative/logistics assistant (perhaps Agency_Temp) reporting to the Conformance Testing Coordinator. This individual will focus exclusively on managing facility access, hardware movement between Locations 2 & 3, and travel arrangements for the 15 testing staff, freeing up the Coordinator for technical oversight.

## 4. Undefined Relationship between Public Fund Manager and Clearing Mechanism Operations

While the Financial Specialist drives the design (Decision 5) and the Risk Manager monitors the Emergency Float (€300M), there is no explicit role responsible for the day-to-day operational administration of disbursing public funds for capacity building (€900M) or managing the strict reporting requirements for the Emergency Float access protocols.

**Recommendation**:
Integrate the operational accounting tasks related to the €1.5B budget drawdown and tracking grants against the capacity building plan into the responsibilities of the Financial Clearing & Settlement Specialist, clarifying that this specialist manages both the private-sector clearing float *and* the public-sector contingency/grant execution.

---

# Potential Improvements

## 1. Clarify Timeline Risk Between Core API Binding and Ancillary Harmonization

The plan assumes a 12-month grace period (ending at 30 months) for full accessibility/reduction cards (as per Assumption 2), but Risk 4 notes these must be harmonized earlier to avoid limiting modal shift. The current team structure separates the Policy Analyst (responsible for Decision 8/9) from the Standards Lead, creating a coordination gap.

**Recommendation**:
Mandate a joint working session (chaired by the EU Regulatory & Governance Architect) bi-monthly for the first year, forcing the Interoperability Standards Lead and the Passenger Rights & Equity Policy Analyst to integrate finalized accessibility/discount data schemas directly into the Provisional Binding Specification (V0.9) released at month 6.

## 2. Strengthen Engagement with Key Enforcement Targets (SNCF, DB, ÖBB)

The Rail Operator Liaison is tasked with enforcing compliance and auditing costs against the major players (SNCF, DB, ÖBB), but there is no dedicated mechanism to handle foreseen political resistance or coordinated lobbying (Risk 6).

**Recommendation**:
The Rail Operator Liaison & Integration Manager should formally delegate accountability for managing political de-escalation negotiation support (as recommended in Review Assumption Issue 3) to the EU Regulatory & Governance Architect, leveraging their primary relationship with DG MOVE to counter political friction proactively.

## 3. Formalize the Distributor Feedback Mechanism into Governance

The Digital Distributor Strategist manages adoption and commercial feedback (Risk 7), reporting on the 40% target. This feedback is crucial but sits outside the primary governance loops (TSC/Steering Committee) that manage technical standards and risk.

**Recommendation**:
Ensure the TSC formally reviews the Digital Distributor & Market Adoption Strategist’s adoption metrics and key usability feedback from distributors quarterly, granting the TSC the right to issue provisional directives (under its emergency mandate) specifically addressing API usability issues, ensuring technical focus remains market-relevant.

## 4. Clarify Physical Testing Site Ownership and Cross-Site Coordination

Testing spans Brussels (Location 1) and two remote corridor hubs (Location 2 & 3). Without clear ownership, handover of testing artifacts, hardware deployment, and resolution tracking between the Brussels-based Standards team, the Coordinator, and the remote testing crews risks delays.

**Recommendation**:
Establish a standardized 'Test Wave Handoff Protocol' owned by the Cross-Corridor Conformance Testing Coordinator. This protocol must dictate the exact data package (logs, configuration files, issue tickets) required from Location 2/3 teams before they demobilize, which must be immediately reviewed by the Standards Lead team in Brussels upon receipt.

# Expert Criticism

# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Regulatory Economist (EU Transport Focus)

**Knowledge**: Cost recovery models, non-discrimination mandates, CAPEX/OPEX allocation, EU funding oversight

**Why**: Needed to scrutinize the 'standardized, capped royalty structure' (Decision 2) for true cost recovery vs. profit generation by operators.

**What**: Analyze the proposed capped royalty structure to ensure it meets non-discriminatory principles while covering carrier IT costs fairly.

**Skills**: Financial modeling, regulatory impact assessment, State Aid compliance, economic viability studies

**Search**: EU transport regulatory economist, royalty structure transport APIs, rail data cost recovery EU

## 1.1 Primary Actions

- Establish the Technical Steering Committee (TSC) by 2026-06-14.
- Draft the legally binding framework for conditional third-party bank guarantees by 2026-08-30.
- Mandate the integration of accessibility features into the OSDM standards by 2026-12-31.

## 1.2 Secondary Actions

- Engage with potential guarantor banks to secure financial backing for the clearing mechanism.
- Conduct regular stakeholder meetings to ensure alignment on governance and compliance.
- Implement a public communication strategy to raise awareness of accessibility features and their importance.

## 1.3 Follow Up Consultation

Discuss the progress on establishing the governance structure, the financial framework for the clearing mechanism, and the integration of accessibility features in the next consultation.

## 1.4.A Issue - Insufficient Governance Structure

The project lacks a clearly defined governance structure to oversee the implementation of the OSDM standards and ensure compliance from national operators. Without this, there is a risk of delays and inconsistencies in the adoption of standards.

### 1.4.B Tags

- governance
- compliance
- risk

### 1.4.C Mitigation

Establish a Technical Steering Committee (TSC) by 2026-06-14 with representatives from key stakeholders, including DG MOVE and major operators. This committee should be responsible for monitoring compliance and facilitating communication among stakeholders.

### 1.4.D Consequence

Failure to establish a robust governance structure may lead to fragmented implementation, resulting in delays and increased resistance from national operators.

### 1.4.E Root Cause

Lack of urgency in forming a governance body and unclear accountability for compliance.

## 1.5.A Issue - Under-capitalization of the Clearing Mechanism

The financial model for the inter-carrier clearing mechanism is not adequately defined, risking under-capitalization and liquidity issues, especially if initial transactional velocity is low.

### 1.5.B Tags

- finance
- liquidity
- risk

### 1.5.C Mitigation

Draft the legally binding framework for conditional third-party bank guarantees by 2026-08-30. Additionally, implement a transactional fee model to ensure ongoing capitalization of the clearing mechanism.

### 1.5.D Consequence

If the clearing mechanism is under-capitalized, it could lead to operational failures, impacting the entire ticketing system and eroding consumer trust.

### 1.5.E Root Cause

Inadequate financial planning and lack of immediate engagement with potential guarantor banks.

## 1.6.A Issue - Delayed Accessibility Integration

The integration of accessibility features into the OSDM standards is not prioritized, risking non-compliance with EU regulations and alienating passengers with reduced mobility.

### 1.6.B Tags

- accessibility
- regulatory
- risk

### 1.6.C Mitigation

Mandate that the OSDM data fields related to PRM booking must demonstrate functional mapping against the most restrictive standard by 2026-12-31. Conduct independent audits to ensure compliance with accessibility requirements.

### 1.6.D Consequence

Delaying accessibility integration could lead to regulatory penalties and a negative public perception of the project, undermining its goals.

### 1.6.E Root Cause

Insufficient focus on accessibility during the initial planning phases and lack of stakeholder engagement with disability rights groups.

---

# 2 Expert: Intermodal Logistics Architect

**Knowledge**: API integration for diverse transport modes, multi-modal data mapping, federated inventory systems

**Why**: Crucial for reviewing Decision 7 on integrating buses, ferries, and air, ensuring OSDM hooks are architecturally sound for non-rail modes.

**What**: Map the proposed OSDM API structure's flexibility against the known complexities of bus/ferry reservation data (e.g., luggage capacity).

**Skills**: Systems architecting, multi-modal data standards, API contract design, transport network integration

**Search**: Multi-modal ticketing API standards, OSDM extension, transport integration architect

## 2.1 Primary Actions

- Immediately revise the strategic choice for Decision 3 ('Mechanism for Handling Incomplete Cross-Border Journey Data') from Strict Tiered Liability (Option 1) to Mandatory Collective Insurance Pool (Option 2), to align financial reality with the chosen 'Pragmatic Harmonization' scenario.
- Elevate Decision 9 ('Approach to Harmonizing Accessibility Reservations Infrastructure') to immediate primary focus. Select Strategic Choice 1 (Mandate most restrictive schema immediately) and ensure PRM data mapping validation is fully integrated into the Provisional Binding Specification V0.9 release target of 2026-11-14.
- Revise Decision 10 ('Governance Structure for Binding vs. Non-Binding Standards Amendments'). Immediately implement the 'Fast-Track' subcommittee model (Choice 2) for technical amendments for the first two years post-binding status to ensure necessary operational agility.

## 2.2 Secondary Actions

- Recalibrate the resource allocation for Conformance Testing FTEs: dedicate 20% of initial testing capacity specifically to validating PRM data schema functional mapping concurrently with core inventory testing.
- Initiate immediate commercial/legal consultation to restructure Decision 5 ('Financing the Clearing Mechanism') to account for the shift from carrier collateral guarantees to public budget capitalization of the initial float, as required by the pivot in Decision 3.
- Schedule a mandatory joint workshop between the Liability/Backstop team and the Accessibility team to model the impact of Decision 9's chosen path on the required capitalization of the collective insurance pool (new Decision 3, Option 2).

## 2.3 Follow Up Consultation

The next consultation must focus exclusively on operationalizing the revised liability framework (Decision 3/Option 2) and stress-testing the proposed mandatory PRM integration against the aggressive binding standard timeline. We must confirm the revised capitalization strategy for the clearing mechanism float given the shift in risk pooling and confirm the exact scope and vetting process for the fast-track governance procedures established in the revised Decision 10.

## 2.4.A Issue - Scenario Selection Undermines Core Technical Enforcement

The client selected 'The Builder' scenario (pragmatic harmonization), which defers full financial risk centralization and adopts a phased standardization timeline (provisional binding at 6 months). However, the underlying strategic decisions selected within this scenario (especially Decision 3: Strict Tiered Liability, and Decision 12: Strong 'Three Strikes' Enforcement) are fundamentally contradictory to the 'realistic' pace selected. By choosing a strict, high-liability model (Option 1 in Decision 3) without socializing the risk (unlike The Pioneer), operators will inevitably resist the aggressive enforcement defined in Decision 12, leading to early political deadlock. You are planning maximal enforcement on minimal technical buy-in.

### 2.4.B Tags

- Scenario_Inconsistency
- Liability_Conflict
- Enforcement_Risk

### 2.4.C Mitigation

Consult Decision 3 and immediately pivot the chosen strategic option from 'Strict, Tiered Liability' to 'Option 2: Mandatory Collective Insurance Pool'. This is the correct mitigation for a 'realistic' scenario that still requires high technical compliance (Decision 12). Mitigation requires consulting DG MOVE legal counsel on structuring the pool and revising the initial capitalization strategy (Decision 5) to reflect pooled risk rather than unilateral carrier risk.

### 2.4.D Consequence

The strict tiered liability model, combined with aggressive enforcement (Three Strikes), will cause key operators (DB, SNCF) to contest the resulting liabilities immediately, freezing OSDM integration progress and rendering the 30-month API exposure deadline unreachable due to protracted legal/commercial standoffs.

### 2.4.E Root Cause

Empty

## 2.5.A Issue - Ignoring Critical Dependency: Accessibility Data Schema Integration Pacing

The client's assessment suggests prioritizing core ticketing functionality first, with accessibility integration (Decision 9) being relegated to a secondary concern addressed late in the cycle, even though the 'pre-project assessment' correctly identified mandatory PRM schema validation by 2026-12-31. The selected Builder scenario does not explicitly address how Decision 9 will be paced against Decision 4 (Pacing Binding Standards). If standards become binding (provisional at 6 months, final at 18 months) before accessibility schema is validated internally, the system architecture will be fundamentally broken from an equity standpoint, forcing a costly retrofit or regulatory failure.

### 2.5.B Tags

- Regulatory_NonCompliance
- Equity_Delay
- Technical_Dependency

### 2.5.C Mitigation

Immediately elevate Decision 9 ('Approach to Harmonizing Accessibility Reservations Infrastructure') to Primary status. The client MUST select Strategic Choice 1 ('Mandatory, standardized PRM schema based on most restrictive requirement') for immediate binding adoption. Consult with disability rights bodies (referenced in Stakeholder Analysis) for rapid validation of the requirements definition against the provisional standard released in November 2026. This requires reallocating 20% of the initial testing FTEs (from the 35 total) specifically to PRM data mapping, documented via weekly reports to the TSC.

### 2.5.D Consequence

Failing to integrate accessibility compliance (PRM booking/assistance notification) into the binding standard means the final product violates the legislative intent of the Digital Booking Regulation, inviting immediate regulatory intervention from consumer protection bodies and potentially invalidating the entire passenger rights backstop mechanism designed for *all* passengers.

### 2.5.E Root Cause

Empty

## 2.6.A Issue - Underestimating Governance Agility for Post-Launch Stability

The client selected Decision 10, Choice 1, establishing a dual-approval governance structure (75% carriers + PRD) for binding amendments post-18 months. While this balances power, the initial plan suggests a five-year horizon with a high risk of discovering unforeseen interoperability issues on the complex initial corridors. A 75% threshold for binding changes is too high for effective post-launch correction when early adopters require rapid pivots identified during the first year of live operation. This structure guarantees technical stagnation, conflicting directly with the need for agility implied by the tight timeline.

### 2.6.B Tags

- Governance_Inflexibility
- Technical_Stagnation
- Iteration_Speed

### 2.6.C Mitigation

Immediately revise Decision 10 to implement the 'rotating Fast-Track subcommittee' (Choice 2) for the initial 24 months post-binding status (i.e., until Month 42). This grants necessary agility for minor fixes. Consult the EU Agency for Railways technical leads on defining the scope criteria for amendments assignable to this fast-track group (e.g., only schema clarifications or minor latency fixes). Revert to the 75% dual-approval for any substantive changes to liability, settlement, or commercial terms.

### 2.6.D Consequence

If the initial OSDM implementation reveals critical but minor technical flaws on the Paris-Brussels corridor, the 75% consensus requirement will lead to months of operational instability while the rigid governance structure debates necessary protocol updates. This will immediately trigger distributor complaints and undermine confidence in the T+90 minute guarantee.

### 2.6.E Root Cause

Empty

---

# The following experts did not provide feedback:

# 3 Expert: Public Sector Governance Specialist

**Knowledge**: Large-scale public consortium management, stakeholder coordination protocols, grant management compliance

**Why**: Required to validate the proposed governance structure (Decision 10) for amending binding standards amidst diverse national regulatory bodies and political pressure.

**What**: Develop clear delegation matrix and voting protocols for the Technical Steering Committee amendments post-binding status.

**Skills**: Consensus building, governance framework design, public investment oversight, stakeholder management

**Search**: EU public project governance framework, standards amendment voting protocols, multi-national regulatory steering committee

# 4 Expert: Special Counsel for EU Consumer Protection Law

**Knowledge**: EC Regulation 261/2004 (Air), Rail Passenger Rights (Regulation 1371/2007), liability attribution, redress mechanisms

**Why**: Essential for reviewing the legal robustness of the liability decisions (Decisions 1 & 3) concerning passenger rights backstop and fault attribution.

**What**: Review the tiered liability model against existing EU passenger rights case law to ensure the backstop is legally sound and not easily circumvented.

**Skills**: EU passenger rights directive compliance, liability definition, regulatory risk mapping, compensation framework construction

**Search**: EU rail passenger rights backstop legal review, carrier liability framework EU, Regulation 1371/2007 interpretation

# 5 Expert: Behavioral Scientist (Travel Adoption)

**Knowledge**: Modal choice modeling, friction reduction in booking, consumer inertia, value perception in travel

**Why**: Needed to assess if the proposed features and the definition of continuity thresholds (Decision 13) will genuinely drive the 'attractive than flying' goal (modal shift).

**What**: Quantify the necessary perceived value increase from unified ticketing to overcome existing consumer inertia related to cross-border train travel.

**Skills**: Choice modeling, consumer behavior analysis, UX/UI impact assessment, travel demand forecasting

**Search**: Behavioral science modal shift rail, consumer friction cross-border travel, perceived value single ticket

# 6 Expert: Financial Settlement Specialist (Clearing & Reconciliation)

**Knowledge**: Real-time gross settlement (RTGS), security/collateral requirements, transaction velocity risk management

**Why**: Essential for scrutinizing the complex capitalization and operational mechanism of the clearing fund (Decision 5) under the transactional fee model.

**What**: Design the automated velocity triggers and collateral reporting requirements needed to manage the contingent liability for the clearing mechanism float.

**Skills**: Payment systems engineering, financial reconciliation, collateral management, cross-border settlement

**Search**: Transactional fee clearing mechanism design, railway financial settlement specialist, contingent capital requirement

# 7 Expert: Accessibility Compliance Auditor (EU Transport)

**Knowledge**: Particularly EU Directive 2008/164/EC, PRM accommodation standards, operational vs reservation compliance

**Why**: To verify that Decision 9's proposed unified schema aligns with mandated physical accessibility requirements across national networks under the 'phased' approach.

**What**: Audit the schema mapping requirements against the most restrictive national physical infrastructure readiness levels for high-speed corridors.

**Skills**: Accessibility auditing, disability impact assessment, non-discrimination technical implementation, PRM seating protocols

**Search**: EU rail PRM booking requirement audit, physical accessibility compliance TEN-T network, OSDM accessibility standard

# 8 Expert: IT Compliance and Enforcement Strategist

**Knowledge**: Mandatory API rollout enforcement, conformity assessment procedures, sanctioning procedures for IT non-compliance

**Why**: Required to ensure Decision 12's 'three strikes' policy is practical, legally defensible, and effective against skeptical, powerful incumbent IT monopolies.

**What**: Draft the specific technical failure criteria (uptime, latency, semantic error rate) that immediately trigger the first warning in the enforcement posture.

**Skills**: IT regulatory enforcement, API conformance testing, digital service act compliance, sanctioning frameworks

**Search**: Mandatory IT API enforcement strategy, sanctioning for non-compliant rail operators, technical compliance audit railway

# Work Breakdown Structure

```csv
Level 1,Level 2,Level 3,Level 4,Task ID
Cross-Border Rail Ticketing,,,,66940117-f831-44ca-9ad9-b4df7dd463ce
,Foundational Decision Finalization & Legal Validation,,,55b4b842-d09e-408e-be3e-ccf29fe0302e
,,Validate Strict Tiered Liability Model (Decision 3/Choice 1) Legal Robustness,,41e51df6-6d7c-445e-94b2-5a45f887a210
,,,Review liability model against EU transport law,1c20189f-8a9f-40ee-9db5-3bfe258280cb
,,,Gauge national operator buy-in for liability,ec4b5818-b4a0-42f7-92db-1cc3aebc5e49
,,,Secure DG MOVE opinion on the liability framework,1a2564f7-44b4-4f34-bf04-50afd5f18064
,,Calibrate Required Capital Buffer for Clearing Mechanism Float (Decision 5),,5e198934-c60e-495a-b0d5-da970f815546
,,,Analyze historical cross-border claim data,a8c1bc4e-3124-407a-a601-5a558416cc35
,,,Model float depletion curve under stress,6a7a9690-caa9-48de-b8fa-e1842d4445bd
,,,Validate collective insurance pool solvency,34fc4559-a285-4d17-8f6a-1c4ff3b13b2f
,,,Consult legal expert on liability enforceability,96771f17-52cd-40db-9bce-8d085b2c1232
,,Secure Regulatory Pre-Approval for 'Three Strikes' Enforcement Template (Decision 12),,74bd27e2-8e1b-461f-a102-8f188edd8990
,,,Draft Enforcement Template with Legal Rationale,e03f08f9-3260-4b29-9f50-86c8f5d5362c
,,,Internal Vetting of Strike Criteria with Tech Team,9a59ae31-16d4-4a94-960d-9f7f0ffdda4e
,,,Present Template to DG MOVE for Pre-Approval,712fbba7-756d-45f3-9096-4af248657b39
,,Finalize Provisional Binding Standards Definition (Decision 4/Choice 2),,2c8f21d5-8134-491e-ba2b-c4ffa1d754f7
,,,Resolve binding OSNDM definition conflicts,6f7431aa-a321-40bc-a54e-16dd04a84e86
,,,Empower quorum for interpretative calls,396d841e-1422-45f5-a53b-42a5edaf56a9
,,,Document and socialize provisional standard definitions,78b34655-de81-4669-abc7-566e046f8193
,Technical Architecture & Conformance Testing,,,b0d22079-bfb9-4072-a42c-cb99a2b96e67
,,Establish Isolated High-Performance Test Environment for Load Simulation,,7b8b0750-94b9-4b8a-b52f-148ae326b2f6
,,,Provision scalable cloud infrastructure,4e8158a1-21ca-4c89-9c94-ff979ae82a67
,,,Configure OSDM test systems integration,2ff9025d-59c8-4a82-8d17-08266df5b302
,,,Finalize configuration baselines and documentation,ae283994-2221-440d-ac8f-823dcdf31e6e
,,Execute T+5 Latency Load Tests across Core Inventory & Disruption Endpoints,,d9098247-4a66-417f-af81-d67a7e5eb825
,,,Setup isolated load simulation environment,5a206c45-08b6-4022-bcc8-b3551431c967
,,,Run core inventory latency performance tests,b714800f-baee-412c-82e6-c5f396e39b5d
,,,Integrate and validate PRM data latency,71ea1fd9-f5f3-4338-9e6f-95921db50175
,,,Finalize technical 'Strike' criteria definition,b8ccc68f-d6ea-4777-8ddc-c01fbdfa5e34
,,Validate PRM Data Schema Conformance Against T+5 Latency Benchmark,,bc825d58-5cbe-49e5-be71-9aa3beb726da
,,,Define PRM data validation benchmarks,5f20ee41-7b49-4c20-9732-d87bd73d412a
,,,Integrate PRM testing into load simulations,776795ee-010d-4384-9a72-a771195b8466
,,,Audit PRM schema compliance against mandates,75acf178-2c87-44b8-9c68-56753e08ae48
,,,Formalize PRM integration sign-off criteria,b82aa768-4c06-4fe5-88a0-ebd575177634
,,Finalize Technical Failure Criteria Defining 'Strike' for Enforcement (Decision 12),,337ebc01-ef51-413f-8ebf-7f9814347950
,,,Define technical failure thresholds for 'strikes',26103d20-550e-4fac-8005-aa30a073fa4f
,,,Establish arbitration panel for threshold disputes,4225ed06-86c3-4d5a-bb5f-bad514feb2ca
,,,Document strike consequences and trigger sequencing,1a696884-0e72-4e31-a2ba-8db3697850e5
,Commercial Terms & Financial Auditing Framework,,,24eefa57-560e-474b-b8c3-fba698444535
,,Develop Audit Templates for Operator OSDM Cost Attribution Verification,,f7734d43-e969-4487-ae60-b0c11c59918d
,,,Design OSDM cost attribution audit,c099b98d-93c6-4f04-be4a-74615a4a4a33
,,,Model national accounting reconciliation,46d52350-d39b-45a9-8235-4e183cf767aa
,,,Draft initial audit submission template,33c1caeb-6716-46de-9c39-ab2ff5e6c8dc
,,"Secure Agreement from SNCF, DB, ÖBB on Cost Verification Methodology (Decision 2)",,e8f8ef8a-7bba-4d77-828b-af45d3bc78ba
,,,Bilateral Workshops for Cost Methodology Buy-in,ae444f55-f3a1-42c2-8ee3-6c65a591d4e9
,,,Design Incentive Structure for Cost Data Disclosure,36b74edf-1322-4f1e-b717-9d269998291b
,,,Secure Formal Operator Sign-off on Audit Protocol,508305c1-2d89-44b0-b355-c444a5d5767d
,,Develop Mechanism for Transactional Fee Collection toward Clearing Capitalization,,c293a705-1ae3-4c5d-81d1-adc46c6a3fac
,,,Model transactional fee structure,4c667847-1e08-4194-8184-b25bf9db2427
,,,Simulate distributor impact of fee tiers,0eeb3d3d-20b1-4a94-95d6-b2eac16b06e8
,,,Derive minimum capital requirement table,451a2c3f-d22a-4194-87f4-7f10936c6bce
,,,Finalize and document fee collection agreement,6e3e6aad-b527-41f3-9a89-13f1356f31b2
,,Design Governance Structure for Post-Launch Standard Amendments (Decision 10),,6186fba2-8509-4589-8fb5-358b773b9cee
,,,Define amendment voting thresholds,8cd325e9-9e48-4056-bbc2-131cf12264f1
,,,Draft governance MoU terms,d7b03d53-ce37-4935-987a-c506e42aca46
,,,Circulate and secure governance MoU,53e91f4f-2ee9-46e4-909e-c9b2d683280f
,,,Pilot amendment scenario testing,3f50a2c4-5c8e-4562-a42a-b1f5fe74af29
,Harmonization Strategy Definition (Ancillary Services),,,ae7cfdf4-abdc-4920-98fe-323ac533d4b4
,,Define Scope for Recognition of Top Three National Reduction Cards (Decision 8),,4d41a016-6bb4-49fa-998a-b4d98c32d1db
,,,Define scope for top three card types,bc12d679-978c-4f30-b50b-0e5aad8a8730
,,,Mandate structured input for card validation rules,eb2c5016-5a5c-4525-baf9-15ad14f26ccd
,,,Validate card recognition against V1.0 schema,41438a29-b754-48bb-a7fd-9d18177fa0e9
,,Formalize Continuity-of-Journey Failure Thresholds (Decision 13),,a88438f2-0ea5-45b4-829f-1ba975c1fc50
,,,Define passenger journey continuity thresholds,852eba65-3b17-4859-b501-9e083f6690a7
,,,Gather historical delay/platform data (test data),9f104606-163f-4b73-b6d4-4aa127df1a56
,,,Map data requirements to OSDM continuity schema,cc158e88-e83f-4617-812a-4c610214936d
,,,Validate continuity triggers in test environment,369c62a7-8d13-4b53-b3b3-09da9a1cebee
,,Determine Pilot Strategy for Non-Core Transport Integration Hooks (Decision 7),,a0aa09d1-fb63-4a99-a238-863084039883
,,,Define scope for non-core modes,f7537eff-19a2-49f6-998b-9e0a48b92966
,,,Assess feasibility of non-rail integration,31fc2e8c-7077-46c7-acee-53304ef8871f
,,,Secure agreement on Phase 2 deferral,d82b55c4-2298-4eb7-b8a4-1bbb75e5b237
,,,Draft provisional V1.0 integration hooks,db681575-0598-4535-b4e3-9a16740b98f5
,,Establish Operational Funding Model for Public Reference Distributor (Decision 11),,f8332314-f41b-4fb1-b218-d5d329d08d04
,,,Model PRD operational costs,f62415fc-c523-42aa-b09f-cba1fb006974
,,,Secure initial DG MOVE funding endorsement,91d2b7bd-6809-492d-b494-2b7406d5a899
,,,Design PRD incentive funding structure,01d6721c-cfbc-45b4-8f67-2f48c6fab7a4
,,,Finalize PRD contracting framework,00496ddb-6673-4765-abaf-b05ed2802723
,Incentivization Structure Finalization,,,33cfe410-ef33-4826-ab41-883e1b03d3ab
,,Design Tiered Funding Model for Early API Adopters (Decision 6),,11d8d8d4-49ef-4f8a-b848-1ab657d880d9
,,,Co-design incentive tiers with stakeholders,85383c92-61dc-4cd4-91f8-8af013dd9282
,,,Quantify benefits for Fast-Track carriers,6734154d-1ff7-4ad7-89ba-ecf66c89928a
,,,Finalize modular contract templates,a5347ae8-0c4d-4081-b494-43a5a33875f4
,,Finalize Regulatory Fast-Track Status Conditions for Compliant Carriers,,f32696b8-37c8-4e64-9ad1-a6b65d751c87
,,,Draft F-T conditions for carrier status,0b335c23-722f-4e24-a13a-cec2c49256d0
,,,Pre-vet fast track criteria with DG MOVE,e5877624-0569-4e05-81e9-b032fdaa7592
,,,Incorporate competition compliance feedback,3eafa627-cc65-4329-9c4a-bc8ea54e83c7
,,,Formalize binding fast-track approval process,eaa8097e-9c86-40b9-9c9a-9560f067b37d
,,Map Distributor Contractual Priority Window Requirements to API Compliance Metrics,,5b09dcca-8ade-48af-85c1-9c848706cf86
,,,Develop modular distributor contract template,c895c7b2-9a00-436a-b8dd-be32b3be22bd
,,,Link distributor incentives to API compliance metrics,905edf31-d627-4656-8ddb-f90e8ef8bd2b
,,,Simulate distributor integration cost/benefit,941a6334-34e0-4fa2-9b9e-ed8080f63c09
,,,Secure contractual commitment documentation,361f0dc2-568e-431f-b6cb-2e2f07dc5228
```

# Review Plan

## Review 1: Critical Issues

1. **Scenario Inconsistency Creates Enforcement Deadlock**: The chosen 'Builder' scenario (pragmatic pace) conflicts with the maximal 'Strict Tiered Liability' (Decision 3, Option 1) combined with aggressive 'Three Strikes' enforcement (Decision 12), increasing political resistance risk (Risk 6) by 6-12 months delay if operators contest liability; the actionable recommendation is to immediately pivot Decision 3 to the Mandatory Collective Insurance Pool (Option 2) to align financial risk sharing with the realistic pace, stabilizing operator buy-in.


2. **Delayed Accessibility Integration Undermines Equity and Timelines**: The assumed 30-month grace period for Accessibility Reservations (Decision 9) risks regulatory non-compliance and negates social relevance, as this critical feature must be integrated into the core binding standard set for month 18, therefore the actionable recommendation is to mandate functional PRM schema conformance testing concurrently with core API certification by month 18, leveraging 20% of testing FTEs immediately.


3. **Governance Inflexibility Threatens Post-Launch Stability**: The chosen governance structure (Decision 10, Choice 1) establishes a rigid 75% consensus threshold for post-launch amendments, risking technical stagnation (Risk 5), which conflicts with the need for agile fixes identified during live operation; thus, the actionable recommendation is to revise Decision 10 to implement the 'Fast-Track subcommittee' (Choice 2) for 24 months post-binding status to manage necessary minor technical pivots rapidly.


## Review 2: Implementation Consequences

1. **Rapid Distributor Engagement via Costed Data Access (Positive)**: Implementing the mandated capped royalty structure (Decision 2) immediately reduces market barrier to entry, incentivizing distributors to rapidly build integrated systems, which proactively supports achieving the 40% through-ticket sales goal years ahead of schedule and positively influences the ROI of capacity building grants; however, this necessitates rigorous anti-cost-inflation audits managed by the Liaison Manager to ensure operator compliance with the 5% cap, which should be addressed by securing specialized IT forensic auditing support annually.


2. **Passenger Trust Boost via Unified Liability (Positive/Negative)**: Establishing the pooled Passenger Rights Backstop (Decision 1), even under the Builder scenario's tiered approach, significantly increases consumer confidence regarding multi-operator travel, directly supporting the goal of halving future distributor complaints; conversely, this structural reliance strains the clearing mechanism's float, requiring the immediate operationalization of the €300M Emergency Float Reserve to absorb projected early drawdowns from high-incidence claims.


3. **Accelerated Technical Compliance Drives Early Feature Parity (Positive)**: The aggressive pacing of binding standards (Decision 4) forces operators to commit resources to API alignment sooner, which positively compels early integration of accessibility reservation data (Decision 9) and thus avoids future regulatory non-compliance risks (Risk 4); this accelerated technical focus, however, diverts operator resources from finalizing national reduction card schemes (Decision 8), meaning the team must immediately prioritize the mechanism enabling standardized EU discount substitution to maintain consumer value perception.


## Review 3: Recommended Actions

1. **Implement Emergency Mandate for Governance Agility (Priority: High)**: Immediately applying the Fast-Track subcommittee authority (Decision 10, Choice 2) for the first 24 months post-binding status is expected to reduce the time spent resolving minor operational bugs from an estimated 6-9 months to under 4 weeks, demanding the EU Regulatory Architect formally charter this subcommittee within the first quarter.


2. **Allocate Dedicated Funding for Behavioral Testing (Priority: Medium)**: Dedicating a portion of the €1.5B budget, perhaps 2% (€30 million), to fund quantitative behavioral modeling on rail vs. air choice (as suggested by the missing expert) will provide the necessary data to refine marketing/value proposition claims, which is critical for ensuring the 40% adoption target is met, requiring the Digital Distributor Strategist to commission this external study immediately.


3. **Mandate Parallel PRM Conformance Testing (Priority: Critical)**: By mandating functional testing of the PRM data schema against the T+5 latency benchmark (Assumption 6) concurrently with core API testing, this action reduces the Risk 4 consequence of late accessibility integration, thereby preventing potential regulatory penalties equivalent to 3-7% of the annual operational budget, which must be implemented by embedding PRM validation into the Cross-Corridor Conformance Testing Coordinator's standard checklist starting in Q1.


## Review 4: Showstopper Risks

1. **Risk of Coordinated Incumbent Lobbying Against Liability Framework (Likelihood: Medium)**: If major operators successfully lobby to weaken the tiered liability framework (Decision 3), it could cause a 15-20% revenue shortfall in Year 2 due to distributor/passenger mistrust, directly compounding the operational risk (Risk 2) if data quality is also poor; the initial action is to frame tiered liability as necessary risk pooling supported by data transparency, with the contingency being the EU Regulatory Architect leveraging DG MOVE authority to mandate the liability structure prior to clearing mechanism activation.


2. **Risk of Inflation in Operator IT Costs for Royalty Justification (Likelihood: Medium)**: If national operators overstate IT operational costs needed for OSDM maintenance to maximize cost-recovery royalty revenue (in violation of Decision 2), the resulting royalty increase could raise distributor integration costs by 10-25%, negatively impacting the 40% adoption ROI, which compounds slow governance (Risk 5) if the dispute stalls audit approval; the action is to mandate the Rail Operator Liaison secure formal operator sign-off on the cost verification methodology by Q2, with contingency being the Regulatory Economist imposing an independent cost benchmark based on industry averages.


3. **Risk of Core Objective Displacement by Non-Core Mode Scope Creep (Likelihood: Low)**: If the low-likelihood pilot for non-core integration (Decision 7) consumes disproportionate engineering focus, it could delay core rail API stabilization by 9-12 months, jeopardizing the 18-month binding standard deadline and risking the entire €1.5B budget's justification; the action is to strictly adhere to an official de-scope of non-rail modes from Phase 1, with the contingency being the Program Risk Manager reducing Conformance Testing FTEs dedicated to Decision 7 tasks by 50% if core stability alerts trigger above a predefined threshold.


## Review 5: Critical Assumptions

1. **Assumption: T+3 Settlement Reconciliation is Achievable for 99% of Transactions (Likelihood: High)**: If T+3 fails, escalating settlement delays to T+7 will require the Financial Specialist to increase the required operational float by at least €50 million to maintain system liquidity, potentially eroding the Emergency Float Reserve and compounding the clearing mechanism under-capitalization risk (Risk 3); the validation action is for the Financial Settlement Specialist to run immediate simulation stress tests projecting float depletion curves under T+7 conditions by the end of Q1.


2. **Assumption: National Operators Will Provide Auditable IT Cost Records for Royalties (Likelihood: High)**: Failure of operators to provide reliable, granular IT cost attribution will render the 5% royalty cap ineffective, leading to disputes over Decision 2 commercial terms and potentially stalling distributor adoption (Risk 7) by creating uncertainty over long-term data access costs; the validation action is for the Rail Operator Liaison to secure formal agreement on the audit methodology from SNCF, DB, and ÖBB by Q2 (Validation Objective 3).


3. **Assumption: The €1.5B Budget Allocation Remains Stable (Likelihood: Medium)**: Any political reallocation that reduces the €900M capacity building grant budget by more than 15% (€135M) will directly undermine the incentive program (Decision 6) and delay technical integration support, slowing the achievement of the 90%+ uptime target and compounding the risk of unstable data layers (Risk 2); the validation action is for the EU Regulatory Architect to secure DGMOU confirmation that the capacity budget is ring-fenced against mid-program political redirection immediately.


## Review 6: Key Performance Indicators

1. **KPI 1: Cross-Border Through-Ticket Adoption Rate (Target: >40% by Year 5)**: This KPI directly measures the achievement of the primary goal, and its failure interacts with any breakdown in distributor adoption (Risk 7) or commercial friction (Decision 2); monitoring must be performed monthly by the Digital Distributor Strategist, tracking the share of bookings processed via certified OSDM APIs versus legacy channels, ensuring corrective action kicks in if velocity fails to reach 10% penetration by the end of Year 2.


2. **KPI 2: Inter-Carrier Clearing Mechanism Liquidity Buffer (Target: Maintain 150% of Peak Daily Obligation)**: Maintaining this buffer, which covers the primary financial backbone, directly mitigates the risk of clearing mechanism under-capitalization (Risk 3), and its stability is reliant on validating the T+3 settlement assumption; the Financial Clearing Specialist must generate a **weekly liquidity health dashboard** that triggers the Emergency Float assessment protocol if the buffer drops below 160% for more than two consecutive weeks.


3. **KPI 3: Accessibility Data Functional Compliance Rate (Target: 100% with T+5 Latency by Month 24)**: Achieving this measures success in integrating mandatory equity requirements (Decision 9) and validates the effectiveness of the early accessibility testing mandate, failing which leads to regulatory penalties (Risk 4 implication); the Cross-Corridor Conformance Testing Coordinator must deliver a **formal certification report quarterly** showing successful end-to-end PRM booking transactions across all four corridors meeting the T+5 benchmark.


## Review 7: Report Objectives

1. **Primary Objectives and Audience**: The report's core objective is to critically review the project plan ('Pragmatic Harmonization' scenario) for feasibility, identify existential risks, and derive immediate execution mandates, primarily informing DG MOVE, the Agency for Railways, and National Rail Operators on strategic course correction.


2. **Key Decisions Informed**: This document specifically seeks to validate or adjust critical high-stakes decisions concerning the liability framework (Decision 1/3), the pace of technical standardization (Decision 4/14), the operational governance for amendments (Decision 10), and the financial structure of the clearing mechanism (Decision 5).


3. **V2 Differentiation Strategy**: Version 2 must differ from V1 by embedding corrections based on expert feedback, explicitly confirming the pivot from Strict Tiered Liability to Collective Insurance, integrating the finalized governance charter for the Fast-Track subcommittee, and presenting a validated timeline that explicitly incorporates the accessibility integration schedule parallel to core API finalization.


## Review 8: Data Quality Concerns

1. **Critical Area: Actuarial Cost Modeling for Liability Backstop (Data Criticality: High)**: Accurate historical cross-border failure data is needed to size the required backstop pool (Decision 1/3), and reliance on proxies could result in under-capitalization leading to a €50-200M float shortfall contingency (compounding Risk 3); the validation approach must involve the Passenger Rights Analyst securing and analyzing official European Rail Agency incident archives, or external actuarial firms must certify the model's margin of error by Q3.


2. **Critical Area: Operator IT Cost Attribution Verifiability (Data Criticality: High)**: Complete and accurate operator IT cost data is vital for enforcing the 5% royalty cap (Decision 2), and if data is incomplete or inflated, it undermines the cost-recovery principle, risking distributor market friction (Risk 7) and potentially violating State Aid rules; the validation approach requires the Rail Operator Liaison to secure formal sign-off on the audit methodology templates from SNCF, DB, and ÖBB by Q2, as detailed in Data Collection Item 3.


3. **Critical Area: Feasibility Mapping of PRM Data Schema to T+5 Latency (Data Criticality: High)**: The data quality regarding current national PRM system capabilities versus the T+5 benchmark is uncertain, and inaccurate mapping here invalidates the accessibility compliance strategy (Decision 9) and risks regulatory failure; the validation approach demands the Conformance Testing Coordinator runs immediate, targeted load tests focusing solely on PRM data propagation latency in the isolated test environment to confirm technical feasibility before finalizing the Provisional Binding Specification.


## Review 9: Stakeholder Feedback

1. **Feedback Needed: Legal Robustness of Strict Tiered Liability (Criticality: High)**: The initial plan selected Strict Tiered Liability (Decision 3, Choice 1), which the Intermodal Architect argues conflicts with the 'Builder' scenario's realism, and unresolved legal ambiguity could trigger immediate, protracted operator litigation costing 6-9 months in legal delays; thus, the Passenger Rights Analyst must secure a formal legal opinion from the Special Counsel on the enforceability of this specific liability split against existing EU law before finalizing V2.


2. **Feedback Needed: Distributor Commercial Usability of Capped Royalties (Criticality: High)**: The success of the 40% adoption target hinges on the Digital Distributor Strategist confirming the 5% royalty cap (Decision 2) is attractive enough compared to existing friction costs, and uncertainty here could cause distributors to delay major integration efforts, resulting in a 15-20% ROI reduction in Year 2 sales; the Digital Distributor Strategist must conduct targeted workshops with major distributors to quantify integration savings versus the new cost structure before V2 sign-off.


3. **Feedback Needed: Finalized Scope for PRM Data Schema Integration (Criticality: High)**: The Interoperability Architect stresses elevating PRM integration (Decision 9) within the binding timeline, yet the exact required data fields are not fully locked, meaning any late change causes rework for the Standards Lead, risking delays to the OSDM finalization at month 18; the Standards Lead must confirm final, agreed-upon PRM schema requirements with the Accessibility Compliance Auditor and officially lock this scope into the Provisional Binding Specification documentation by the end of Q1.


## Review 10: Changed Assumptions

1. **Assumption Re-evaluation: Achievability of T+5 Minute Latency Benchmark (Original: High Confidence)**: If independent testing reveals T+5 latency is only achievable at T+10 minutes for 25% of core routes, this failure invalidates core functionality for automated rights (Decision 13) and escalates Technical Risk 2, forcing a choice between sacrificing automation or delaying API exposure by 3-6 months; the review action is for the Conformance Testing Coordinator to formally present the most optimistic achievable latency benchmark based on current test results to the TSC for immediate governance review.


2. **Assumption Re-evaluation: Operator Willingness to Provide Auditable Cost Data (Original: High Confidence)**: If major operators actively resist or provide non-auditable IT cost data for royalty verification (Decision 2), the project cannot confidently enforce the 5% cap, potentially leading to legal challenges on non-discrimination grounds and increasing political friction (Risk 1); the review approach should involve the Regulatory Economist conducting a proactive sensitivity analysis showing the financial impact if the average reported cost recovery rate is forced down by 15% due to non-cooperation.


3. **Assumption Re-evaluation: Public Funding Stability of €1.5B (Original: Medium Confidence)**: If binding EU political shifts reduce the available capacity building budget (€900M) by 10% (€90M), this directly undermines the 'carrot' side of the incentive structure (Decision 6) and strains resources for the Program Risk Manager, potentially weakening enforcement posture (Decision 12); the review process must require the EU Regulatory Architect to obtain a formal statement from DG MOVE regarding the stability of the allocated budget tranche for the next 18 months.


## Review 11: Budget Clarifications

1. **Clarification 1: Finalized Capitalization Requirement for Clearing Mechanism Float (Impact: €50M working capital reserve uncertainty)**: The assumption relies on a €200M float, but the Financial Specialist needs confirmation on the exact size of the Emergency Float Reserve requirement (beyond the €300M contingency pool) under the T+3 settlement assumption to prevent a liquidity crisis (Risk 3); the action is for the Financial Clearing Specialist to finalize the minimum required operational float buffer based on the stress testing simulations and report the final required commitment to the Steering Committee by month's end.


2. **Clarification 2: Exact Cost Allocation for PRM Data Schema Implementation (Impact: Potential 5-10% overrun on capacity building grants)**: The cost associated with forcing the most restrictive PRM schema (Decision 9) onto legacy systems, which was prioritized in remediation, is highly uncertain and threatens to consume a large portion of the €900M capacity grant; the action required is for the Interoperability Standards Lead to produce a cost breakdown estimate for the specialized PRM data mapping required by the Accessibility Auditor, allowing the Regulatory Architect to ring-fence contingency funds within the grants.


3. **Clarification 3: Operator Cost Attribution Verification Burden (Impact: 20% increase in audit/Liaison overhead costs)**: Verifying the 5% cost-recovery royalty (Decision 2) against potentially obfuscated operator IT costs for the first fiscal year requires substantial forensic effort by the Liaison Manager and supporting auditors; the action is to formally budget and secure specialized IT forensic accounting contractors (as suggested in Omissions 2) costing approximately 20% more than initial estimates, ensuring the commercial governance framework is enforceable and the audit process is not delayed.


## Review 12: Role Definitions

1. **Role Clarification: Emergency Directive Authority Under Governance (Essential for Agility)**: The ambiguity of who can *immediately* enact a provisional operational directive under the fast-track governance mechanism (Decision 10) risks delaying critical technical pivots by weeks, directly affecting API stability (Risk 2); the actionable step is for the EU Regulatory & Governance Architect to formally define the specific quorum composition of the Technical Steering Committee granting this immediate enactment power in the governance charter.


2. **Role Clarification: Accountability for Contingency Activation of Emergency Float (Essential for Financial Resilience)**: Unclear authority over drawing down the €300M Emergency Float Reserve could cause regulatory paralysis during a liquidity crisis (Risk 3), potentially delaying settlement reconciliation (T+3 assumption failure) by several days; the actionable step is for the Program Risk Manager to formally document the explicit sign-off chain involving themselves and the Financial Clearing Specialist required for any float drawdown exceeding €20 million.


3. **Role Clarification: Final Sign-off Authority for PRM Schema Compliance (Essential for Regulatory Mandate)**: Without a single accountable role for signing off that the complex PRM data schema meets all mandates before the binding deadline, compliance auditing (Risk 4 implication) becomes fragmented, risking major regulatory challenge post-launch; the actionable step is to designate the Accessibility Compliance Auditor (Expert 7) as the sole, final signatory certifying PRM schema acceptance, pending mandatory review by the Interoperability Standards Lead.


## Review 13: Timeline Dependencies

1. **Sequencing Concern: Provisional Binding Standard Release vs. PRM Schema Validation (Impact: Risk of Retooling/4-6 Month Delay)**: Releasing the Provisional Binding OSDM Specification (Month 6) before mandatory PRM data mapping validation (as recommended by Expert 2) is finalized means the standards risk being architecturally flawed for accessibility, forcing a costly retrofit that compounds technical stability risk (Risk 2); the concrete action is to explicitly link the technical sign-off for the Provisional Standard (Decision 4) to the Accessibility Compliance Auditor's formal acceptance of the PRM schema definition.


2. **Dependency Concern: Operator Audit Agreement vs. API Exposure Mandate (Impact: Enforcement Impasse/Timeline Freeze)**: If the Rail Operator Liaison fails to secure agreement on cost verification methodology (Decision 2 output) by Month 24, and the API exposure mandate (Decision 14) hits at Month 30, operators facing financial investigation are likely to stall technical compliance, freezing enforcement actions against SNCF/DB/ÖBB; the concrete action is to make the Q2 deadline for cost audit agreement (Validation Objective 3) a prerequisite hurdle for granting access/certification to the final production API environment.


3. **Dependency Concern: Clearing Mechanism Capitalization vs. Full Liability Framework (Impact: Financial Instability/Trust Erosion)**: Finalizing the capitalization of the clearing mechanism (Decision 5) must be synchronized with the DG MOVE pre-approval of the tiered liability framework (Decision 3), as the projected capital need depends directly on the agreed-upon risk exposure; the concrete action is for the Financial Clearing Specialist to require DG MOVE formal approval of the finalized liability framework *before* initiating the process for securing third-party bank guarantees for the operational float.


## Review 14: Financial Strategy

1. **Question 1: Long-Term Viability of Transactional Fee Model Post Initial Float Exhaustion (Quantified Impact: Potential 100% ROI loss if float requires public top-up)**: If the initial transactional fees fail to generate sufficient reserve capital growth after the initial €200M float is utilized, the system risks collapse or requiring significant unforeseen public injection, undermining the sustainability assumption; the actionable step is for the Financial Clearing Specialist to present a sensitivity analysis detailing the minimum required transaction velocity (tickets per month) needed to achieve self-sustainability by Month 48.


2. **Question 2: Long-Term Cost of Maintaining the Public Reference Distributor (Quantified Impact: Fixed budget drain increasing by 5% annually without fee structure)**: The plan reserves 10% (€150M) for initial PRD costs, but the long-term funding model (Decision 11) is uncertain; if usage fees fail to materialize, this becomes a perpetual drain on the grant budget, offsetting modal shift goals; the actionable step is for the Regulatory Architect to define a mandatory, hard sunset clause for full public funding of the PRD unless usage fee targets (defined by the Digital Distributor Strategist) are met by Year 3.


3. **Question 3: Financial Impact of Regulatory Mandates for Future OSDM Upgrades (Quantified Impact: Unbudgeted €20-40M CAPEX needed for V2.0)**: The governance structure (Decision 10) allows for amendments, but the financial burden of mandatory V2.0 upgrades (driven by necessary technical evolution or new regulation) is unbudgeted, potentially straining the remaining grant pool; the actionable step is for the Program Risk Manager to mandate that the Interoperability Lead quantify the estimated average CAPEX required per operator for a standard future specification upgrade cycle to establish a formal 'Future Standards Contingency Reserve' within the grant budget.


## Review 15: Motivation Factors

1. **Factor 1: Demonstrable Early Success via Pilot Corridors (Quantified Setback: 15% drop in distributor adoption if pilot fails)**: Operator motivation and distributor buy-in (Risk 7/Decision 6) are highly dependent on visible early wins; motivation falters if the first pilot corridor faces critical integration failures, potentially stalling wider rollout momentum; the actionable recommendation is for the Cross-Corridor Conformance Testing Coordinator to launch a high-visibility 'Pilot Success Dashboard' tracking T+5 latency and initial transaction volume from the first pilot corridor weekly, rewarding rapid early sign-off with public recognition.


2. **Factor 2: Fairness and Transparency in Cost Recovery/Audit (Quantified Setback: 25% increase in operator resistance/non-compliance)**: Operator motivation to comply with complex API exposure and cost reporting (Decision 2/Risk 1) hinges on perceiving the royalty structure as fair cost-recovery rather than a tax; this directly impacts the Rail Operator Liaison's effectiveness in avoiding political pushback; the actionable recommendation is for the Regulatory Economist to publish an annual, simplified report detailing the percentage of operator IT costs verified versus total costs recouped, ensuring perceived fairness drives continued engagement.


3. **Factor 3: Tangible Proof of Concept for Passenger Value (Quantified Setback: 50% failure to meet modal shift target if perceived value is low)**: If technical implementation outpaces perceived passenger benefit (e.g., accessibility recognized but hard to book), consumer trust erodes, undermining the entire project value proposition; this interacts negatively with issues in Decision 13 (threshold setting); the actionable recommendation is for the team to partner with the Digital Distributor Strategist immediately to launch a minimal viable 'killer app' demonstration focusing exclusively on the unified 90-minute refund guarantee at the 18-month mark, regardless of full discount harmonization.


## Review 16: Automation Opportunities

1. **Automation Opportunity: Real-Time API Conformance Monitoring (Potential Savings: 30% reduction in manual testing FTE time)**: Automating the continuous monitoring of key OSDM metrics (T+5 latency, data completeness) against the defined 'strike' thresholds (Decision 12) eliminates the need for constant manual data sampling by the 15 testing FTEs; this directly alleviates the resource constraint on the Conformance Testing Coordinator by shifting focus from detection to resolution management.


2. **Streamlining Opportunity: Provisional Standard Amendment Processing (Potential Savings: Reducing amendment cycle time by 60%)**: Utilizing the proposed Fast-Track subcommittee (Decision 10) for routine specification clarifications can streamline the V1.0 iteration process, avoiding the bottleneck of the 75% dual-approval consensus that slows down technical pivots; the actionable approach is for the Interoperability Standards Lead to automate the workflow for drafting ratification ballots for provisional directives immediately following the subcommittee approval.**


3. **Automation Opportunity: Clearing Mechanism Collateral Triggering (Potential Savings: Reducing liquidity lag by 24-48 hours)**: Automating the trigger mechanism that signals required collateral top-ups or alerts the Emergency Float Reserve (contingency for Risk 3) when transactional velocity falls below projections reduces reliance on manual T+3 reconciliation checks; the actionable approach is for the Financial Clearing Specialist to develop and integrate the automated velocity monitoring tool directly with the Risk Manager's dashboard to ensure real-time, rather than weekly, alerts.

# Questions & Answers

**Q1: What is the significance of defining the Passenger Rights Liability Backstop Scope in the project?**

A1: Defining the Passenger Rights Liability Backstop Scope is crucial as it establishes a mechanism to protect passengers from financial losses due to inter-carrier disputes when journey segments fail. It aims to create a unified EU backstop that ensures immediate compensation for passengers, thereby enhancing consumer trust. This backstop simplifies the process for passengers by clarifying who is responsible for compensation, which is vital when multiple operators are involved in a single ticket journey.

**Q2: How do the commercial terms for data exposure and API access impact distributor participation?**

A2: The commercial terms for data exposure and API access dictate the fees that distributors must pay to access real-time inventory data from national operators. If these terms are too high, they can create barriers for smaller distributors, limiting competition and reducing the diversity of options available to consumers. Conversely, fair and transparent pricing can encourage more distributors to participate, which is essential for achieving the project's goal of increasing cross-border ticket sales.

**Q3: What are the risks associated with the proposed tiered liability model for handling incomplete cross-border journey data?**

A3: The tiered liability model assigns compensation costs to the carrier responsible for a segment failure unless negligence by the distributor is proven. While this encourages compliance among carriers, it may discourage new entrants who fear high liability costs. Additionally, if the model is too punitive, it could lead to fewer carriers participating in the system, ultimately undermining the project's goal of seamless cross-border travel.

**Q4: What ethical considerations are involved in the implementation of the pooled Passenger Rights Backstop?**

A4: The pooled Passenger Rights Backstop raises ethical considerations regarding fairness and accountability among carriers. High-performing carriers may end up subsidizing the failures of less reliable operators, which could create a moral hazard. Ensuring that the backstop is funded equitably and that all carriers contribute fairly is essential to maintain trust and ensure that the system is perceived as just by consumers.

**Q5: How does the project plan to manage the risks associated with political resistance from national operators?**

A5: The project plans to manage political resistance by implementing a strong enforcement posture, including a 'three strikes' policy that suspends through-ticketing rights for non-compliant operators. This approach aims to create a clear incentive for operators to comply with the new standards. Additionally, ongoing engagement and communication with stakeholders will be crucial to address concerns and foster collaboration.

**Q6: What are the potential consequences of under-capitalization of the inter-carrier clearing mechanism?**

A6: Under-capitalization of the inter-carrier clearing mechanism can lead to liquidity issues, causing delays in settlement and disputes among carriers. If the float required for operations is insufficient, it may force the EU budget to cover gaps, potentially amounting to €50-200 million in working capital support. This could undermine the financial stability of the entire ticketing system and erode consumer trust in the process.

**Q7: How does the project address the ethical implications of liability distribution among carriers?**

A7: The project addresses ethical implications by proposing a tiered liability model that aims to balance accountability among carriers while protecting consumer rights. However, it raises concerns about fairness, as high-performing carriers may disproportionately bear the costs of failures caused by less reliable operators. Ensuring that the liability framework is perceived as equitable is crucial for maintaining trust among all stakeholders.

**Q8: What are the risks associated with the aggressive timeline for binding standard adoption?**

A8: The aggressive timeline for binding standard adoption poses risks such as forcing operators to implement potentially unstable specifications quickly, which could lead to costly rework if the standards are found to be inadequate. Additionally, it may create pressure on smaller operators who lack the resources to adapt swiftly, potentially leading to compliance issues and delays in achieving the project's goals.

**Q9: What are the implications of the proposed 'three strikes' enforcement policy for non-compliant operators?**

A9: The 'three strikes' enforcement policy implies that operators who fail to comply with the mandated API exposure will face suspension of their ability to sell through-tickets. While this approach aims to ensure compliance and protect consumer rights, it could also lead to operational chaos if multiple operators are suspended simultaneously, disrupting service availability and passenger trust.

**Q10: How does the project plan to ensure that accessibility features are integrated effectively into the ticketing system?**

A10: The project plans to ensure effective integration of accessibility features by mandating that the PRM (Persons with Reduced Mobility) data schema is finalized and validated against the most restrictive national requirements. This integration is critical for compliance with EU regulations and for ensuring that the ticketing system is equitable and accessible to all passengers, including those with disabilities.

# Premortem

A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A4 | The EU Commission will successfully enforce the 'Three Strikes' suspension policy against major national operators (SNCF, DB, ÖBB) without triggering immediate, paralyzing political intervention from the Council of Ministers. | The EU Regulatory & Governance Architect will present the finalized, legally vetted 'Three Strikes' suspension charter to DG MOVE for official pre-approval, checking for safeguards against Council override mechanisms by 2027-06-01. | DG MOVE indicates that enforcement on any single major operator requires unanimous Council approval rather than simple DG MOVE sanctioning authority. |
| A5 | The €1.5 Billion public coordination budget will remain fully available and unreduced throughout the initial 3-year critical implementation phase for capacity building grants and contingency funds. | The Program Risk Manager will secure a formal financial commitment letter from the European Parliament's budgetary authority confirming zero planned reallocation or reduction of the €1.5B tranche earmarked for the first 36 months of operations by 2027-07-01. | A significant Member State successfully lobbies to ring-fence or reallocate „100 Million from the grants pool for domestic infrastructure projects, reducing the incentive budget. |
| A6 | National operators possess the latent IT capacity (even if currently unbudgeted) to undertake the necessary system modifications to implement the final OSDM V1.0 binding standard within the 18-month deadline, requiring only financial support via available grants. | The Interoperability Standards Lead will conduct a 10-day diagnostic sprint with the IT heads of the 5 largest operators to map OSDM V1.0 technical gaps against current legacy architecture roadmaps, looking for major architectural incompatibility rather than simple coding gaps. | The diagnostic sprint reveals that 3 of the 5 largest operators require a fundamental replacement of their core booking engine (not just API wrapping) to achieve OSDM compliance, rendering the 18-month timeline infeasible regardless of grant funding. |
| A1 | National operators will provide auditable financial records detailing IT operational costs attributable specifically to OSDM API maintenance. | The Rail Operator Liaison & Integration Manager will mandate that SNCF, DB, and ÖBB submit initial mock audit templates demonstrating cost attribution for a recent quarter by 2027-04-30. | Agreement on the audit methodology is not secured from all three major operators, or submitted cost breakdowns lack verifiable internal ledger references. |
| A2 | The 'Strict, Tiered Liability' model (Decision 3, Choice 1) is legally robust and politically tenable across all Member States, minimizing legal challenges. | The EU Regulatory & Governance Architect will secure a formal, written legal opinion from the Special Counsel for EU Consumer Protection Law validating the enforceability of Choice 1 against existing case law by 2027-05-15. | The Special Counsel advises a mandatory pivot to the Collective Insurance Pool (Choice 2) due to high risk of litigation or non-enforceability in key jurisdictions. |
| A3 | The T+5 minute real-time latency benchmark is technically achievable across 95% of core inventory and disruption endpoints using existing national infrastructure, even when exchanging complex PRM data. | The Cross-Corridor Conformance Testing Coordinator must successfully complete the Phase 1 load test confirming verifiable, sustained T+5 average latency across 95% of simulated endpoints by 2027-05-30. | The sustained average latency achieved in testing consistently exceeds T+7 minutes for more than 10% of critical endpoints under peak load conditions. |
| A4 | The EU Commission will successfully enforce the 'Three Strikes' suspension policy against major national operators (SNCF, DB, ÖBB) without triggering immediate, paralyzing political intervention from the Council of Ministers. | The EU Regulatory & Governance Architect will present the finalized, legally vetted 'Three Strikes' suspension charter to DG MOVE for official pre-approval, checking for safeguards against Council override mechanisms by 2027-06-01. | DG MOVE indicates that enforcement on any single major operator requires unanimous Council approval rather than simple DG MOVE sanctioning authority. |
| A5 | The €1.5 Billion public coordination budget will remain fully available and unreduced throughout the initial 3-year critical implementation phase for capacity building grants and contingency funds. | The Program Risk Manager will secure a formal financial commitment letter from the European Parliament's budgetary authority confirming zero planned reallocation or reduction of the €1.5B tranche earmarked for the first 36 months of operations by 2027-07-01. | A significant Member State successfully lobbies to ring-fence or reallocate €100 Million from the grants pool for domestic infrastructure projects, reducing the incentive budget. |
| A6 | National operators possess the latent IT capacity (even if currently unbudgeted) to undertake the necessary system modifications to implement the final OSDM V1.0 binding standard within the 18-month deadline, requiring only financial support via available grants. | The Interoperability Standards Lead will conduct a 10-day diagnostic sprint with the IT heads of the 5 largest operators to map OSDM V1.0 technical gaps against current legacy architecture roadmaps, looking for major architectural incompatibility rather than simple coding gaps. | The diagnostic sprint reveals that 3 of the 5 largest operators require a fundamental replacement of their core booking engine (not just API wrapping) to achieve OSDM compliance, rendering the 18-month timeline infeasible regardless of grant funding. |
| A7 | The general public possesses sufficient awareness and understanding of the complex passenger rights guarantees (especially the 90-minute continuity threshold) to generate reliable, positive feedback leading to modal shift. | The Passenger Rights & Equity Policy Analyst will execute a pre-launch public perception survey measuring awareness of the new 90-minute delay guarantee and willingness to book a multi-leg journey based on this feature alone, targeting 60% recall rate among frequent short-haul air travelers. | The survey shows less than 30% recall of the new 90-minute rule, and respondents primarily rely on existing, fragmented national guarantees rather than the unified system feature. |
| A8 | The governance structure agreed upon (TSC with fast-track subcommittees) will successfully resolve inevitable specification conflicts without fracturing or empowering a single dominant incumbent operator to veto necessary changes. | The EU Regulatory & Governance Architect will run a historical simulation exercise using the records from the ERTMS/Shift2Rail governance board to model adversarial voting patterns on a hypothetical V1.1 feature change, requiring a decision by a 65% fast-track quorum. | The simulation reveals that two major states, acting in concert, can consistently block the required 65% threshold on critical technical pivots five times out of ten attempts, suggesting systemic gridlock even with the fast-track mechanism. |
| A9 | The centralized clearing mechanism float, fully capitalized by transactional fees and backed by bank guarantees, will maintain sufficient liquidity (150% buffer) without requiring drawdowns from the Emergency Float Reserve (€300M) during the first 18 months of operation. | The Financial Clearing & Settlement Specialist will report the rolling 4-week average liquidity buffer status against the 150% threshold, demanding automated alerts if it dips below 165% for two consecutive weeks, rather than the stop-rule 150% trigger. | The rolling average liquidity buffer consistently registers between 130% and 149% for 6 continuous weeks, indicating that transactional velocity is too low to support the T+3 settlement window without tapping the emergency reserve. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM2 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM3 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Market/Human | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |
| FM4 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM5 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM6 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Market/Human | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |
| FM7 | The Liability Deadlock: Legal Contestation Freezes Clearing Activation | Process/Financial | A2 | EU Regulatory & Governance Architect | CRITICAL (20/25) |
| FM8 | The Latency Choke: PRM Data Overloads the T+5 Pipe | Technical/Logistical | A3 | Interoperability Standards Lead | CRITICAL (20/25) |
| FM9 | The Royalty Rebellion: Cost Audit Failure and Distributor Exodus | Process/Financial | A1 | Digital Distributor & Market Adoption Strategist | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM2 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption that T+5 latency was achievable (A3) proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes an urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM3 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20%).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.

---

#### FM4 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM5 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption (A3) that T+5 latency was achievable proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM6 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20% power curve).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.

---

#### FM7 - The Liability Deadlock: Legal Contestation Freezes Clearing Activation

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: EU Regulatory & Governance Architect
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project proceeded with the Builder Scenario's chosen strategy of Strict Tiered Liability (Decision 3, Choice 1), assuming it was legally sound (A2). Following the binding standard adoption at 18 months, SNCF and Deutsche Bahn immediately contest the liability attribution in the European Court of Justice, arguing it violates national sovereignty in carrier fault determination. This legal standoff forces DG MOVE to freeze the final regulatory sign-off necessary for activating the inter-carrier clearing mechanism. Without a legally ratified liability framework, the Financial Clearing & Settlement Specialist cannot secure the required bank guarantees attached to the tiered risk exposure, leaving the €200M operational float uncapitalized and unusable. Consequently, single-payment settlement fails entirely at launch, defaulting back to complex, manual T+30 reconciliation systems that the project was intended to replace.

##### Early Warning Signs
- Legal challenge filing referencing Decision 3/Choice 1 exceeds 90 days post-standard binding.
- The Financial Clearing & Settlement Specialist reports that conditional bank guarantee finalization is pending 'High Court Guidance' for more than 45 days.
- Rail Operator Liaison reports a complete cessation of productive engagement from SNCF/DB IT security teams regarding T+3 auditing processes.

##### Tripwires
- Legal challenge filed by any operator within 60 days of standard finalization (Month 24).
- Clearing mechanism collateral securing falls below 120% of peak daily obligation for 7 consecutive days.

##### Response Playbook
- Contain: Immediately freeze all disbursement of capacity building grants (€900M) pending legal clarification on financial exposure.
- Assess: EU Regulatory Architect convenes emergency triage with Special Counsel to model the financial impact of a mandatory shift to Collective Insurance (Decision 3, Choice 2) under current timelines.
- Respond: Program Director engages DG MOVE leadership to mandate an emergency governance directive forcing provisional activation of the clearing mechanism collateral using the €300M Emergency Float Reserve, insulated from the litigation.


**STOP RULE:** If the legal contestation regarding liability remains unresolved 6 months post-binding standard date, project funds for clearing mechanism operations revert to contingency use, and single-payment settlement target is deferred 3 years.

---

#### FM8 - The Latency Choke: PRM Data Overloads the T+5 Pipe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A3
- **Owner**: Interoperability Standards Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The assumption (A3) that T+5 latency was achievable proved false after initial live testing, particularly when complex PRM data (Decision 9) was introduced to the live inventory feed, exceeding the 95% success threshold. The IT Compliance team activates the 'Three Strikes' policy (Decision 12) against multiple operators simultaneously due to sustained T+7 minute latency. Instead of rapid self-correction, operators claim the combined load of core inventory and PRM data exchange exceeds their realistic capacity given the budget constraints, arguing the T+5 standard was unrealistic for dual-stream exchange. The resulting instability causes the Public Reference Distributor to begin selling inaccurate bookings, leading to mass failed transactions and massive refund processing requirements, burning through the operational budget faster than anticipated.

##### Early Warning Signs
- Automated System Monitoring reports average real-time disruption latency > T+6.0 minutes for 4 consecutive weeks.
- Cross-Corridor Conformance Testing reports less than 80% pass rate for PRM data extraction tests under peak load simulations.
- The Rail Operator Liaison reports three or more operators filing formal notifications contesting the attribution of the first T+5 latency failure 'strike'.

##### Tripwires
- T+5 latency success rate drops below 90% during any 7-day monitoring window post-API Go-Live.
- The Program Risk Manager flags an increase in planned refund volume exceeding 150% of the initial actuarial projection.

##### Response Playbook
- Contain: Immediately throttle all non-essential API traffic originating from the bottom 25% performing operators to preserve stability for the top 75%.
- Assess: Interoperability Standards Lead convenes urgent technical workshop with operator CTOS to negotiate a temporary, data-stream-specific relaxation of the T+5 mandate (e.g., PRM data permitted T+7), requiring Governance sign-off.
- Respond: Program Risk Manager initiates a review of the €900M capacity budget to reallocate €20M for emergency hardware/network upgrades specifically targeting the latency-bound carriers.


**STOP RULE:** If sustained T+5 latency compliance (95% success rate) is not achieved 6 months post-mandated API exposure deadline, the binding standard is reverted to Provisional Status (V0.9) for 9 months to allow architectural redesign.

---

#### FM9 - The Royalty Rebellion: Cost Audit Failure and Distributor Exodus

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Digital Distributor & Market Adoption Strategist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project was founded on the crucial assumption (A1) that national operators would transparently submit auditable IT cost data to verify the 5% royalty cap (Decision 2). When the first annual audit window arrives, incumbent operators, led by ÖBB and SNCF, submit aggregated, non-verifiable IT expenditure reports, citing 'security separation' and 'confidential competitive costs.' The Rail Operator Liaison is unable to break these consolidated figures down using internal negotiation power alone, and external forensic accountants cannot deliver findings within the required 90-day governance window. Because cost recovery cannot be verified, the Digital Distributor Strategist cannot certify that market access is truly non-discriminatory. This uncertainty causes independent distributors to halt integration work, citing unpredictable long-term operating costs, leading to a market vacuum where only incumbent platforms can confidently sell tickets. The 40% through-ticket goal collapses, achieving only 15% adoption by Year 3.

##### Early Warning Signs
- Rail Operator Liaison reports internal pushback on cost audit template finalization past the 2027-05-01 deadline.
- Digital Distributor Strategist reports YoY drop in pipeline commitments for OSDM API integration exceeding 30% during Q1 post-audit season.
- The Regulatory Economist flags an increase in formal complaints submitted by distribution platforms regarding potential State Aid violations.

##### Tripwires
- Annual IT cost verification audit deadline missed by 60 days for more than one primary operator.
- Anticipated Year 2 through-ticket sales velocity falls below 12% cumulative adoption (Target: 20% power curve).

##### Response Playbook
- Contain: Immediately suspend the eligibility of all non-compliant operators for any further capacity building grants (€900M budget) until audit compliance is secured.
- Assess: EU Regulatory Architect initiates formal DG MOVE inquiry into potential anti-competitive behavior regarding data access fees, prioritizing the commercial fairness angle over technical compliance.
- Respond: Digital Distributor Strategist launches a dedicated marketing campaign, temporarily subsidizing distributor integration costs out-of-pocket, contingent on regulatory action against non-compliant operators.


**STOP RULE:** If verifiable through-ticket sales adoption remains below 25% by the end of Year 3 due to commercial uncertainty or distributor hesitation, the project pivots to a highly subsidized, EU-backed single carrier platform model, eliminating the distributed sales objective.


# Self Audit

Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a large-scale regulatory, technical integration, and commercial coordination project among established transport entities, requiring software development, API standardization, and contractual agreements; it does not require violating any known laws of physics or relying on non-physical causal mechanisms for its success. The plan involves creating interoperable software systems and defining commercial/governance processes.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of regulatory enforcement, complex IT standardization (OSDM), and new financial clearing/liability models, demanding unprecedented compliance from established national operators without sufficient validation precedent for the *entire system* in the EU rail domain. This lack of scaled proof justifies the high rating.

**Mitigation**: Technology Lead/Governance Architect: Launch concurrent validation tracks for (1) T+5 latency adherence with PRM data load and (2) Legal vetting outcome of tiered liability vs. collective pool by within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly names strategic concepts ('Pacing Standard Adoption', 'Data Exposure', 'Passenger Rights Liability') but fails to define their business-level mechanism-of-action (inputs→process→customer value), nor assign owners or measurable outcomes *except* for citing the final 40% adoption goal. For instance, Decision 1 details the complexity but lacks a single owner.

**Mitigation**: EU Regulatory & Governance Architect: Produce 5 one-pagers detailing mechanism-of-action, owner, KPIs, and decision hooks for each of the five primary decisions within 45 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly relies on aggressive enforcement ('Three Strikes') against established incumbents (SNCF, DB) while assuming their behavioral compliance regarding liability (Decision 3) and cost auditing (Decision 2) is manageable. Premortems show these regulatory/cost assumptions are the primary critical failure modes (FM1, FM3), indicating second-order political and compliance risks are severely underestimated.

**Mitigation**: EU Regulatory & Governance Architect: Initiate preemptive high-level lobbying engagement to secure DG MOVE commitment regarding the 'Three Strikes' policy insulation from Council override within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project relies on strict timelines for technical standards (18 months binding), but the expert review flagged the concurrency of ancillary harmonization (Accessibility/Loyalty—30-month grace assumed) as conflicting with core binding deadlines, indicating aggressive scheduling without sufficient predecessor mapping.

**Mitigation**: Interoperability Standards Lead: Mandate that the PRM data schema validation must be formally signed off before the core OSDM standard achieves final binding status at month 18.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's reliance on a transactional fee model for capitalization (Decision 5) is directly flagged as a weakness (Risk 3) sensitive to low initial velocity. The plan commits to a €200M float financed via collateral, which the expert review flagged as requiring immediate contingency ($300M Emergency Float Reserve) due to settlement delay assumptions (T+3). The status of this critical contingency funding is not detailed.

**Mitigation**: Program Risk Manager/Financial Clearing Specialist: Formally document the commitment and funding source for the $300M Emergency Float Reserve within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan selects the 'Builder' scenario, which uses a 'transactional fee model' for capitalization (Decision 5, Choice 2). This relies on future transaction velocity, which is an untested assumption that introduces financial risk if velocity is low, as noted in Risk 3, pending a full cost-benefit analysis.

**Mitigation**: Financial Clearing Specialist: Finalize and present the minimum required transaction velocity needed by Month 48 for self-sustainability by within 90 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Builder scenario relies exclusively on single numeric targets for projection, such as '40% of cross-border journeys sold as single through-tickets within five years' (Goal Statement). No sensitivity analysis or worst-case scenario is presented for this critical adoption metric, indicating optimism.

**Mitigation**: Digital Distributor Strategist/Program Risk Manager: Produce a best/base/worst-case scenario for the 40% adoption KPI, using the projected impact of the FM3/FM9 failure mode as the worst-case basis, within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the instruction notes that core components may lack specs, interface contracts, acceptance tests, integration plans, and NFRs. The inputs confirm the dependence on novel standards (OSDM) and complex financial/data integrations (Clearing Mechanism, T+5 latency), but lack specific evidence (e.g., 'OSDM V1.0 Interface Contract v2.1') addressing these critical components.

**Mitigation**: Interoperability Standards Lead/Program Risk Manager: Deliver the complete OSDM V1.0 interface contract, integration map, and acceptance test suite for the core ticketing/disruption endpoints within 120 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because Checklist Item 10 explicitly requires verifiable artifacts for critical claims. Critical claims exist regarding mandatory legal enforcement ('Three Strikes' Policy, Decision 12) and financial backing (Clearing Mechanism capitalization, Decision 5). No verifiable artifact (link/ID) is currently cited for the 'legally vetted 'Three Strikes' suspension charter' (Premortem A4) or the 'formal commitment letter' for the Emergency Float Reserve (Review Q3-2's required action).

**Mitigation**: EU Regulatory & Governance Architect: Secure formal DG MOVE written pre-approval for the 'Three Strikes' charter within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan contains several major milestones and key decisions (e.g., Passenger Rights Backstop, Pacing Binding Standard) that are abstractly defined, lacking specific, quantifiable KPI targets in their descriptions.

**Mitigation**: EU Regulatory & Governance Architect: Define SMART acceptance criteria for Decision 1, including KPI for backstop claim processing time (e.g., 90% processed within T+7 days) within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan explicitly details several features whose costs/benefits are insufficiently justified relative to core goals: 'Offer the first two years of API access entirely free of charge' shifts cost to the public budget, conflicting with sustainability goals, as stated in Decision 2.

**Mitigation**: Digital Distributor & Market Adoption Strategist: Produce a one-page benefit case for free API access justifying inclusion vs. cost-recovery royalty model within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the mission-critical role is the EU Regulatory & Governance Architect, whose failure causes alignment breakdown, stalled standards, and legally indefensible enforcement. This role requires deep, rare expertise spanning EU transport law, digital policy, and multisovereign governance.

**Mitigation**: EU Regulatory & Governance Architect: Commissions an external market analysis validating the availability of candidates matching Dr. Vancini's profile within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the legality of enforcing data sharing and financial mandates on sovereign entities is unclear, and the pre-approval of the 'Three Strikes' enforcement template by DG MOVE is a critical unmapped approval artifact.

**Mitigation**: EU Regulatory & Governance Architect: Secure formal DG MOVE written pre-approval for the 'Three Strikes' charter within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks any explicit documentation regarding ongoing operational costs versus projected revenue/funding post-completion, particularly concerning the long-term funding for the Public Reference Distributor (Decision 11, 10% fixed budget commitment) and ongoing maintenance of the OSDM standards.

**Mitigation**: EU Regulatory & Governance Architect: Define the 5-year operational funding sunset clause for the Public Reference Distributor based on usage fee targets within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions hard constraints (e.g., Regulation compliance, OSDM standards) but lacks explicit, written confirmation or risk assessment for site-specific physical constraints like zoning or local occupancy limits relevant to the proposed testing facilities (Location 2 and 3).

**Mitigation**: Cross-Corridor Conformance Testing Coordinator: Initiate contact with local authorities near testing sites (Location 2/3) to confirm basic operational permits and zoning overlays within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan addresses external resilience by choosing a liability model (Strict Tiered Liability, Decision 3/Choice 1) that the Intermodal Architect argues contradicts the 'realistic' Builder scenario by imposing high unilateral risk on carriers, which is a single point of failure for operator buy-in. No tested failover structure (like the recommended Collective Insurance Pool) is selected for this critical financial risk.

**Mitigation**: EU Regulatory & Governance Architect: Immediately mandate the pivot for Decision 3 to Strategic Choice 2 (Mandatory Collective Insurance Pool) and secure legal sign-off within 45 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Financial Department (incentive: budget adherence) conflicts with R&D/Technical (implicit incentive: robust standards adoption), visible in Decision 2's choice to offer two years of free API access, shifting cost to the public budget.

**Mitigation**: EU Regulatory & Governance Architect: Finalize an OKR linking R&D's API stability certification timeline to the Finance Department's measurable reduction in public subsidy drawdowns within 90 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit definition of KPIs, review cadence, owners, and change control thresholds as required. Although the 'SWOT Recommendations' suggest future KPIs, the core plan lacks documented feedback loops for ongoing monitoring and adjustment.

**Mitigation**: EU Regulatory & Governance Architect: Establish a monthly Governance Review Board charter defining KPIs, owners, and change thresholds (e.g., 10% KPI deviation triggers light-weight review) within 45 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits strong coupling between the technical stability (T+5 latency via Decision 14/Assumptions A3, FM2/FM5), the liability regime (Strict Tiered Liability, Decision 3, FM1/FM4/FM7), and the distributor adoption rate (Decision 2/A1, FM3/FM9). The chosen 'Builder' scenario is highly vulnerable to deadlock if operators contest the liability structure, which will inevitably strain technical compliance efforts.

**Mitigation**: EU Regulatory & Governance Architect: Immediately mandate the pivot for Decision 3 to Collective Insurance and secure legal sign-off within 45 days to de-risk litigation.

# Initial Prompt Vetted

## Initial Prompt

```text
Plan:
Deliver a coordinated European program to make cross-border train travel as easy to search, book, and refund, aligned with the European Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail. Today, travelling by rail across two or more EU member states means stitching together itineraries from disconnected national operators (SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ and roughly twenty more), each with its own fares, booking system, refund policy and disruption handling, while distributors face inconsistent access to real-time inventory and post-sale operations; passengers cannot reliably buy a single through-ticket from Lisbon to Tallinn and lose passenger-rights protection the moment a connection is missed. The objective is to stand up the technical, commercial and governance arrangements that let any compliant distributor — incumbent operator, third-party platform like Trainline or Omio, or a new public European booking service — sell through-tickets across all participating carriers with continuity-of-journey rights, single-payment settlement, harmonised refunds, reduction cards, accessibility for persons with reduced mobility, and bicycle reservations. Scope covers a shared real-time data layer exposed through OSDM-compatible APIs on non-discriminatory commercial terms, an inter-carrier clearing and settlement mechanism, a passenger-rights backstop, and integration hooks for buses, ferries and short-haul air; rollout starts with the busiest cross-border corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin) before extending to the full TEN-T network. Stakeholders are DG MOVE, the EU Agency for Railways, CER and national operators, independent distributors, BEUC, national regulators and disability-rights bodies. Horizon is five years: binding standards within eighteen months, mandatory API exposure within thirty, full corridor through-ticketing within sixty. Public-side coordination budget is €1.5 billion covering standards work, conformance testing, the clearing mechanism, a public reference distributor, member-state capacity building and consumer-side rollout (apps, multilingual support, complaint handling); estimate the larger private carrier IT investment separately. Success means 40% of cross-border journeys sold as single through-tickets within five years, distributor complaints halved, and the train becoming the more attractive option than flying on competitive short-haul routes so that fewer travellers choose the plane. Pick a realistic scenario, not the most aggressive one.

Today's date:
2026-May-14

Project start ASAP
```

## Prompt Screening

**Verdict:** 🟢 USABLE

**Rationale:** This prompt describes a highly concrete, complex, and actionable project: establishing a coordinated European digital infrastructure for cross-border rail ticketing aligned with EU regulation, complete with specific technical, commercial, and governance goals, timelines, budget estimates, and involved stakeholders. The detail level is extremely high, making it ideal for generating a detailed project plan.

## Redline Gate

**Verdict:** 🟢 ALLOW

**Rationale:** This query asks for a high-level planning and coordination strategy for a complex, publicly discussed EU regulatory and technological project that does not involve illegal activities or generating specific operational instructions for harm.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Capability Uplift**     | No |

## Premise Attack

Why this fails.

### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] The premise that binding standards and mandatory API exposure can be reliably mandated and enforced across two dozen heterogeneous national rail operators within 6 to 30 months is fundamentally undermined by disparate national IT maturities and entrenched operational sovereignty.**

**Bottom Line:** REJECT: The premise relies on the false assumption that twenty-plus national rail entities, driven by distinct commercial incentives, will integrate their core, revenue-critical IT infrastructure under new EU standards within an artificially short 30-month window.


#### Reasons for Rejection

- The timeline demands binding standards within 18 months and mandatory API exposure within 30 months across numerous legacy systems belonging to operators like SNCF, DB, and Renfe, which historically resist rapid, externally imposed technical harmonization.
- Establishing a single, non-discriminatory commercial term structure for real-time inventory access requires overcoming the established revenue protection mechanisms currently used by national incumbents to guard their highest-yield direct sales channels.
- The scope includes a public-side coordination budget of €1.5 billion to manage complex technical agreements, governance alignment between DG MOVE, independent regulators, and the European Commission, which is insufficient for securing deep operational buy-in from twenty or more sovereign national entities.
- Guaranteeing continuity-of-journey rights funded by a 'passenger-rights backstop' assumes a unified liability framework that currently does not exist, creating an immediate legal ambiguity regarding which operator/distributor covers the eventual financial fallout of a missed connection.
- The inclusion of mandatory integration hooks for buses, ferries, AND short-haul air within the same initial five-year horizon stretches technical standardization capacity beyond feasible limits, forcing compromises on the core rail integration.

#### Second-Order Effects

- 0–6 months: Deep initial paralysis as national operators leverage existing fragmentation governance structures to bog down the definition of 'non-discriminatory commercial terms' for API access.
- 1–3 years: Mandatory API deployment will result in fragmented 'lowest common denominator' data feeds, where complex services like specific accessibility reservations fail to port correctly across borders, leading to an increase, not a decrease, in distributor complaints.
- 5–10 years: The high cost and slow pace of interoperability will solidify the dominance of incumbent operators who control the core network infrastructure, making the ambitious goal of making rail more attractive than flying unsustainable.

#### Evidence

- Case/Incident — EU Rail Market Opening (Various Years): National incumbents consistently delay or weakly implement EU directives concerning infrastructure access and data sharing, demonstrating organizational inertia against supranational mandates.
- Law/Standard — Digital Services Act (DSA) (2022): Demonstrates the years required for the EU to establish enforcement mechanisms for digital platform governance, which is significantly less granular than forcing real-time technical integration across national rail carriers.
- Case/Incident — Single European Railway Area Initiative Failures (Past Decades): Past attempts at deep harmonization of national ticketing standards consistently failed due to the unyielding difficulty of unifying legacy inventory management systems across diverse technological ages.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — The Premise of Mandatory Coordinated Disruption: The reliance on voluntary, non-discriminatory commercial terms among fierce, nationally entrenched competitors creates an immediate and insurmountable friction point that voids the functional premise of unified service.**

**Bottom Line:** REJECT: This architecture is a sophisticated attempt to mandate market consolidation by fiat, but it fundamentally misunderstands that unwilling competitors will treat standard-setting mechanisms as tools for regulatory capture, not cooperation. The premise collapses beneath the weight of enforced goodwill.


#### Reasons for Rejection

- The premise relies on national incumbent monopolies willingly adopting standardized, non-discriminatory API access terms, which subverts their existing, profitable control over ticketing data and distribution.
- Delegating critical post-sale enforcement, such as 'continuity-of-journey rights' and 'harmonised refunds' across diverse national legal regimes, creates jurisdictional gaps where enforcement against non-compliant members will fail.
- Attempting to force full-service integration (fares, accessibility, bikes) across twenty-plus distinct national legacy IT systems within an aggressive 60-month horizon guarantees systemic data synchronization failure.
- Allocating substantial public funds (€1.5B) to build standards and a 'public reference distributor' merely subsidizes the inevitable private sector resistance to sharing their proprietary commercial logic.

#### Second-Order Effects

- **T+0–18 Months — Competitive Poisoning:** Incumbent carriers will strategically withhold the most valuable real-time disruption data through ambiguous 'commercial terms' compliance, effectively sabotaging third-party distributors while appearing cooperative.
- **T+1–3 Years — Regulatory Deadlock:** National regulators, defending local operator supremacy, will actively challenge the jurisdiction of the central EU Agency for Railways over API access disputes, freezing development in key corridors.
- **T+5–10 Years — Bifurcation of Standards:** A slow, fragmented adoption will occur where only the simplest routes comply, creating a two-tier system: seamless booking for the top 5 corridors and Balkanized complexity everywhere else.
- **T+10+ Years — Public Capital Burn:** The reference distributor will become an expensive middleman competing poorly against streamlined private aggregators, ultimately failing to reach the 40% adoption target while draining public sustainability funds.

#### Evidence

- Case/Report — Failure of the European Rail Traffic Management System (ERTMS) adoption pace demonstrates the difficulty of forcing unified operational standards on sovereign infrastructure managers.
- Law/Standard — Directive 2012/34/EU (Railway Interoperability) still faces persistent non-compliance regarding access rights, foreshadowing the weakness of 'non-discriminatory commercial terms' for distribution.
- Narrative — Front-Page Test: Commuters in the first pilot corridors will experience multiple high-profile, highly visible system crashes during initial through-ticket sales, leading to immediate public erosion of trust in the entire project.
- Law/Standard — EU Regulation 1371/2006 (Passenger Rights) is already difficult to enforce across borders due to varying national interpretation of 'extraordinary circumstances', which this program relies on harmonizing technically.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] The premise relies on the fatal delusion that disparate, fiercely sovereign national rail monopolies will willingly yield operational control for a pan-European customer experience.**

**Bottom Line:** REJECT: This technical veneer masks a fundamental failure to secure the political and commercial consent required to disarm entrenched national transport monopolies.


#### Reasons for Rejection

- The ambitious five-year timeline collapses immediately under the weight of mandating binding standards for nearly thirty fiercely protective national rail operators within eighteen months.
- Expecting non-discriminatory commercial terms for real-time inventory access ignores the carriers' inherent incentive to wall off premium data or impose punitive access fees to protect proprietary sales channels.
- The €1.5 billion public coordination budget is patently inadequate for forcing behavioral and massive IT harmonization across incumbent operators accustomed to legacy silos and self-regulation.
- Creating a unified passenger-rights backstop demands surrendering national legal sovereignty over liability and compensation, a concession political bodies have consistently refused for core infrastructure.
- The goal of harmonizing complex elements like reduction cards, PRM accessibility, and bicycle reservations requires deep legislative action beyond mere technical API layering, exceeding the plan's projected execution scope.

#### Second-Order Effects

- 0–6 months: Immediate internal bureaucratic deadlock as national carriers leverage veto power in harmonization working groups to protect legacy revenue streams, slowing standards adoption.
- 1–3 years: Public funds are consumed creating a compliant, but non-functional, reference API that incumbent operators ignore or spoof, leading to public distributor complaints doubling, not halving.
- 5–10 years: The initiative crystallizes into a fragmented, multi-speed data-sharing system where profitability pathways dictate data sharing tiers, institutionalizing data discrimination on the TEN-T network.

#### Evidence

- Case/Incident — Eurail Group’s Interoperability Evolution (Ongoing): Demonstrates the decades-long friction required merely to standardize ticketing for leisure travel, far simpler than mandated operational ticketing.
- Law/Standard — EU Regulation 1371/2007 (Rail Passenger Rights): Highlights the existing complexity of cross-border rights assignment, requiring supranational enforcement which member states resist.
- Evidence Gap — High-confidence, directly relevant primary sources unavailable; verdict based on prompt’s inherent flaws regarding forcing sovereign national entities into unified commercial settlement.



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**This plan suffers from fundamental strategic hubris by assuming that standardizing complex, nationally siloed legacy infrastructure and achieving mandatory technological convergence across dozens of fiercely competitive and sovereign national operators can be forced within an impossibly compressed regulatory timetable.**

**Bottom Line:** The premise fundamentally misunderstands that rail infrastructure is a political and sovereign domain, not merely a technical one; the assumption that sovereign carriers will willingly subject their core revenue streams and operational data to EU-mandated, non-discriminatory APIs within 30 months reveals profound industrial naiveté. Abandon this plan because technical alignment is impossible without first achieving political unification these operators fiercely resist.


#### Reasons for Rejection

- The 'Sovereignty Mismatch Trap': National rail operators view their booking systems, fare rules, and network data as proprietary assets, not communal utilities; mandatory API exposure conflicts directly with decades of entrenched national competitiveness mechanisms, ensuring glacial, non-compliant technical integration.
- The 'Regulatory Decoupling Delusion': Mandating binding standards within 18 months for a system dependent on harmonizing refund, accessibility, and settlement rules across 27 unique legal frameworks is a fantasy; the political friction required for consensus will consume the entire five-year horizon before basic data standards are even ratified, let alone implemented.
- The 'Legacy Infrastructure Paralysis': The stated goal of exposing real-time inventory via OSDM-compatible APIs presupposes that the underlying 1970s-era, COBOL-dependent national reservation systems can 'speak' modern, high-throughput digital languages on demand, leading to systemic fragility when forced to communicate.
- The 'Interoperability Overreach': Attempting to force 'continuity-of-journey rights' and a 'passenger-rights backstop' across carriers who fundamentally disagree on liability apportionment for delays creates an impenetrable liability shield that no insurer will underwrite, stalling the commercial backbone.

#### Second-Order Effects

- Within 18 months: Implementation of binding standards stalls at the first stage—defining a unified definition of 'disruption' that satisfies German, French, and Polish legal definitions—resulting in a €500 million budget overrun before a single line of operational code is written.
- 1-3 years: Pilot corridors fail spectacularly due to data synchronization errors between national systems, leading to 'ghost bookings' where tickets are sold but capacity has not been reserved, causing immediate, high-profile passenger chaos on the priority routes.
- 3-5 years: The public reference distributor, funded by the €1.5 billion, becomes an expensive, isolated island—a niche platform serving only the simplest, most profitable routes—while the majority of consumer journeys revert to the established, albeit fragmented, legacy methods due to unreliability.
- 5-10 years: The resulting lack of trust in the new unified system forces national operators to quietly build parallel, proprietary extensions, undermining the OSDM layer and creating a fragmented technical environment worse than the pre-project state, as incompatibility is now codified in new standards.

#### Evidence

- The repeated, decades-long failures of pan-European Passenger Information Systems (like the failed attempts to harmonize passenger information dissemination across the TEN-T network), which consistently collapse under the weight of national data ownership disputes.
- The long lead times and political compromise demonstrated in creating the European Union Agency for Railways (ERA) itself, which took years to achieve minimal operational leverage over sovereign national safety bodies.
- The historical fate of any large-scale IT project involving mandatory integration across historically antagonistic utility sectors (e.g., early attempts at harmonizing European air traffic control systems), where technological convergence is always sacrificed to maintain national operational control.



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Premise of Harmonized Sovereign Sovereignty: The plan delusionally assumes that sovereign national rail operators, empowered by centuries of protectionism and burdened by legacy IT, will willingly submit to a centralized, standardized European technical and commercial fiat.**

**Bottom Line:** REJECT: This project is pre-doomed by its reliance on forcing sovereign competitors into a unified technical chassis before political and commercial alignment is achieved, guaranteeing regulatory paralysis amidst operational chaos.


#### Reasons for Rejection

- The inherent conflict between national control over critical infrastructure and the proposed unified governance structure ensures perpetual stalling and non-compliance from member states' entrenched interests.
- Accountability dissipates immediately; when a cross-border journey fails, the blame will fracture across the centralized API layer, the national carrier's backend, and the independent distributor, erasing any meaningful oversight pathway.
- The sheer complexity of achieving a 'single-payment settlement' and 'harmonised refunds' across numerous national GAAP accounting systems and disparate regulatory regimes guarantees systemic financial deadlock.
- The proposed system relies on the hubristic assumption that forcing immediate interoperability negates the commercial incentive for incumbent operators to starve third parties of optimized inventory, leading to functional deceit by omission.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Initial standards meetings devolve into protracted negotiations where national operators refuse to expose critical, real-time capacity data, citing proprietary security concerns, resulting in a sluggish, incomplete 'reference' API.
- T+1–3 years — Copycats Arrive: Frustrated distributors bootstrap proprietary, regional solutions around the official standard, creating new silos based on corporate alliances rather than technical neutrality, accelerating market fragmentation.
- T+5–10 years — Norms Degrade: The promised 'passenger-rights backstop' collapses under the first major disruption (like a system-wide labor strike), as member states invoke 'force majeure' clauses relevant only to their national carriers, rendering passenger protection a fiction.
- T+10+ years — The Reckoning: The €1.5 billion investment stabilizes only the bureaucratic superstructure; actual seamless travel remains elusive, and the mandate to shift passengers from air simply reinforces the entrenched, poorly connected reality, leading to political abandonment of the digital rail project.

#### Evidence

- Case/Report — The historical failures of the EU's various 'Single European Railway Area' legislative packages repeatedly demonstrate that technical mandates buckle before operational sovereignty.
- Principle/Analogue — Public Goods Theory: Attempting to create a cross-border utility by mandating cooperation among competitive, state-protected monopolies inevitably results in the lowest common denominator solution.
- Law/Standard — GDPR Compliance Fragmentation: Despite unified regulation, the enforcement and interpretation regarding cross-border data handling for ticket sales remain wildly inconsistent, previewing the settlement failure.
- Narrative — Front‑Page Test: A front-page story details a tourist stranded in Frankfurt who receives three contradictory refund offers, one from the booking agent, one from the originating German carrier, and none from the final Italian carrier.

# Prompt Adherence

**Overall Adherence: 96%**

```
IMPORTANCE_ADHERENCE_SUM = (5×5 + 4×4 + 5×5 + 5×5 + 5×5 + 3×4 + 4×5 + 4×5 + 4×5 + 3×4 + 4×5 + 5×5 + 5×5 + 4×5 + 4×4 + 4×5) = 326
IMPORTANCE_SUM = 5 + 4 + 5 + 5 + 5 + 3 + 4 + 4 + 4 + 3 + 4 + 5 + 5 + 4 + 4 + 4 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 326 / 340 = 96%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Deliver a coordinated European program for cross-border train travel. | Requirement | 5/5 | 5/5 | Fully honored |
| 2 | Current process requires stitching together national operators (SNCF, DB, etc.). | Stated fact | 4/5 | 4/5 | Partially honored |
| 3 | Align with the European Commission's proposed Regulation on Digital Booking and Ticketing. | Requirement | 5/5 | 5/5 | Fully honored |
| 4 | Enable any compliant distributor to sell through-tickets across all participating carriers. | Requirement | 5/5 | 5/5 | Fully honored |
| 5 | Establish continuity-of-journey rights, single-payment settlement, and harmonised refunds. | Requirement | 5/5 | 5/5 | Fully honored |
| 6 | Scope must include reserved accessibility for PRM and bicycle reservations. | Requirement | 3/5 | 4/5 | Partially honored |
| 7 | Scope covers a shared real-time data layer exposed via OSDM-compatible APIs. | Requirement | 4/5 | 5/5 | Fully honored |
| 8 | API access must be on non-discriminatory commercial terms. | Stated fact | 4/5 | 5/5 | Fully honored |
| 9 | Scope must include an inter-carrier clearing and settlement mechanism. | Requirement | 4/5 | 5/5 | Fully honored |
| 10 | Scope must include integration hooks for buses, ferries and short-haul air. | Requirement | 3/5 | 4/5 | Partially honored |
| 11 | Rollout starts with specific busy cross-border corridors (e.g., Paris–Brussels–Amsterdam–Köln). | Requirement | 4/5 | 5/5 | Fully honored |
| 12 | Horizon is five years for full implementation. | Constraint | 5/5 | 5/5 | Fully honored |
| 13 | Binding standards within eighteen months; mandatory API exposure within thirty months. | Constraint | 5/5 | 5/5 | Fully honored |
| 14 | Public coordination budget is €1.5 billion. | Constraint | 4/5 | 5/5 | Fully honored |
| 15 | Pick a realistic scenario, not the most aggressive one. | Intent | 4/5 | 4/5 | Partially honored |
| 16 | Success metric: 40% of cross-border journeys sold as single through-tickets within five years. | Requirement | 4/5 | 5/5 | Fully honored |

## Issues

### Issue 2 - Current process requires stitching together national operators (SNCF, DB, etc.).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** stitching together itineraries from disconnected national operators (SNCF, Deutsche Bahn, Trenitalia, Renfe, ÖBB, NS, SJ and roughly twenty more)
- **Explanation:** The plan acknowledges the fragmentation by detailing the need to move from this current state, but it doesn't explicitly quote the full list of operators mentioned in the input as context.

### Issue 15 - Pick a realistic scenario, not the most aggressive one.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** The language is direct, policy-aware, and emphasizes decision synthesis, cross-dependencies, risk management, and alignment with the mandated 'Pragmatic Harmonization' strategy ('The Builder' scenario').
- **Explanation:** The plan commits to a 'Pragmatic Harmonization' scenario, which implies choosing a realistic path over the most aggressive one, although it doesn't explicitly state the selection process contrast.

### Issue 6 - Scope must include reserved accessibility for PRM and bicycle reservations.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 3/5
- **Evidence:** Ensure full accessibility mandates (PRM booking) are integrated into the V1.0 standard.
- **Explanation:** Accessibility is included, and the review highlights making its conformance testing concurrent with core standards, but bicycle reservations are not explicitly mentioned in the plan artifacts, softening the completeness.

### Issue 10 - Scope must include integration hooks for buses, ferries and short-haul air.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 3/5
- **Evidence:** Integrate provisional API hooks for buses, ferries, and short-haul air (post five-year target).
- **Explanation:** The plan addresses integration hooks but explicitly de-scopes the full realization until *after* the five-year target, acknowledging the requirement but reducing its immediacy.

