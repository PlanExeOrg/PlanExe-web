## Suggestion 1 - European Rail Traffic Management System (ERTMS) / Shift2Rail (now Innovative Rail Joint Undertaking - INNOWAI)

ERTMS is the European rail traffic management system designed to ensure interoperability of railway signaling and control/command systems across the European Union (TEN-T network). Shift2Rail (and its successor, INNOWAI) focused on funding and developing next-generation railway technologies, including digital operations, advanced traffic management, and improved ticketing capabilities, often addressing pan-European integration challenges similar to the planned project. Key achievements include standardized specifications for communication protocols, data exchange, and operational procedures across various national systems.

### Success Metrics

Successful deployment of ERTMS Level 2 and trials of Level 3 across multiple member states.
Development and standardization of core specifications that underpin current digital railway operations.
Securing significant consensus among major national infrastructure managers (like DB Netz, SNCF Réseau) on common technical standards despite initial resistance.

### Risks and Challenges Faced

Stakeholder Resistance to Harmonization: National operators strongly defended legacy proprietary systems, leading to slow adoption rates initially.
Specification Volatility: Continuous changes to the ERTMS specifications meant significant rework for integrators.
Funding Gaps: Ensuring sufficient, sustained cross-border funding across multiple EU budget cycles.

### Where to Find More Information

https://shift2rail.org/ (Current work of INNOWAI, successor to Shift2Rail)
https://era.europa.eu/domain-activities/rail-infrastructure-systems/ertms_en (EU Agency for Railways overview of ERTMS)

### Actionable Steps

Contact the European Union Agency for Railways (ERA) directly. Specifically inquire about the 'ERADIS' (ERA Database Interface System) working groups for insights into enforcing OSDM-like standards across diverse IT landscapes. Look for contacts within their 'Standardisation and Interoperability' department via the official ERA website.
Review Shift2Rail/INNOWAI documentation related to 'Digital Operational Processes' and 'Terminal and Frontier Operations' to understand the established governance model for standard amendments (Decision 10).
Identify IT consultancy firms specializing in cross-border rail system integration (System Integrators) who worked on ERTMS/Shift2Rail deployment contracts, as they will have faced similar technical integration risks (Risk 2).

### Rationale for Suggestion

This is the most relevant established precedent for mandated pan-European IT and operational standard enforcement within the rail sector. It directly parallels the challenge of enforcing OSDM-compatible APIs (Decision 25/14) and managing consensus among technical stakeholders (SNCF, DB, ÖBB) within a demanding regulatory environment. The history of ERTMS adoption offers direct lessons on managing specification volatility (Risk 2) and political resistance (Risk 1).
## Suggestion 2 - EU Cross-Border Payment Regulation (PSD2 Implementation and Scheme Development)

The implementation of the Payment Services Directive 2 (PSD2) and subsequent regulatory work creating the Single Euro Payments Area (SEPA) aimed to harmonize retail payment processing across the Eurozone. This involved creating standardized technical frameworks (APIs for Account Information Service Providers and Payment Initiation Service Providers) and ensuring efficient inter-bank clearing and settlement mechanisms, often requiring centralized scheme management (like the Euro Processing System or national clearing houses collaboration). The goal was to reduce friction and cost for digital payments, mirroring the plan's objective for single-payment settlement in ticketing.

### Success Metrics

Widespread adoption of Strong Customer Authentication (SCA) protocols.
Reduction in intra-zone transfer costs to near zero.
Standardization of API interfaces for payment initiation across European banking sectors.

### Risks and Challenges Faced

Varying National Interpretations: Different national competent authorities interpreted PSD2 scope differently, leading to uneven compliance among banks.
API Usability: Early PSD2 APIs were often poorly documented or unstable, causing high integration friction for FinTechs.
Fraud Liability and Management: Determining liability for unauthorized payment transactions when multiple intermediaries are involved.

### Where to Find More Information

https://www.ecb.europa.eu/paym/retail/sepa/html/index.en.html (European Central Bank guidelines on SEPA and payments harmonization)
Reports from the European Banking Authority (EBA) on PSD2 compliance and RTS standardization.

### Actionable Steps

Consult with European FinTech bodies or regulatory compliance experts specializing in PSD2/SCA adherence for lessons on enforcing technical standards (Decision 12) on regulated entities reluctant to share data.
Investigate the design and capitalization strategy of the EU-level payment clearing/settlement system (similar to the planned clearing mechanism, Decision 5). Look for reports detailing how the float was initially secured and managed.
Contact the European Payments Council (EPC) or similar bodies to understand how they managed the introduction of transactional fees and cost-recovery models (Decision 2 for Data Access) within the payment industry.

### Rationale for Suggestion

The financial clearing and settlement mechanism (Decision 5) is the project's financial backbone. The PSD2/SEPA experience provides the most robust, real-world EU model for successfully integrating FinTech distribution (digital platforms) with incumbent infrastructure (national carriers/banks) via mandated, non-discriminatory APIs and managing cross-border financial risk and settlement speed (T+3 assumption).
## Suggestion 3 - Interoperable Accessibility Requirements for EU Rail Infrastructure (e.g., EU Directive 2019/882 implementation planning)

This umbrella covers the ongoing efforts and pilot programs across member states to transpose the EU Directive on the accessibility requirements for products and services (which includes transport) into national rail operations. While technical procurement/physical infrastructure is slow, preparatory phases involve standardizing the data exchange required for Persons with Reduced Mobility (PRM) booking, assistance coordination, and accessibility information flow across booking channels, mirroring Decision 9.

### Success Metrics

Establishment of unified data structures defining minimum requirements for PRM reservation booking across pilot corridors.
Agreement on coordinated cross-border assistance handovers.
Successfully integrating key disability advocacy groups into the technical working groups (Stakeholder Management, Risk 6).

### Risks and Challenges Faced

Physical Asset Lag: National infrastructure managers could not rapidly update physical carriages/stations to meet the strictest EU mandates, creating a gap between required data and physical reality.
Data Silos for Ancillary Services: Difficulty unifying the booking/notification process for assistance across legacy systems.
Political Sensitivity: Balancing accessibility mandates with the economic burden on smaller operators.

### Where to Find More Information

Official publications from the European Commission's DG MOVE regarding ongoing accessibility consultations in transport.
National reports from large operators (e.g., Deutsche Bahn's accessibility service documentation) detailing their efforts to integrate PRM data into online distribution.

### Actionable Steps

Contact disability and consumer advocacy groups (like BEUC or specific national PRM organizations) who were involved in shaping the requirements for Decision 9 (Harmonizing Accessibility Reservations). They can detail the negotiation tactics used to ensure mandated features were not delayed beyond core ticketing.
Identify officials within the EU Agency for Railways responsible for the Technical Specifications for Interoperability (TSIs) related to accessibility. They can provide insight into how they enforced parallel development schedules (Risk 4 mitigation).
Focus outreach on operators in the Vienna-Munich-Zurich corridor (ÖBB and DB), as they are directly involved in two critical corridors and likely faced early pressure to harmonize accessibility data exchange.

### Rationale for Suggestion

Accessibility integration (Decision 9) is identified as a major hurdle that risks regulatory non-compliance and limits the project's social relevance, despite the delay grace period assumed in the plan. Historical data from mandatory accessibility integration projects provides direct, high-fidelity insight into managing complex, politically sensitive auxiliary services integration alongside core IT rollouts (Risk 4).

## Summary

The proposed project combines large-scale regulated IT infrastructure modernization with complex, multi-sovereign governance and financial mechanism development. To ensure a 'realistic' path forward, the reference projects are drawn from proven EU-level harmonization efforts in rail technology (ERTMS/Shift2Rail) for managing standards enforcement (governance, data layer), in financial regulation (PSD2/SEPA) for building the inter-carrier clearing mechanism, and in mandatory social convergence (Accessibility Directives) for navigating politically sensitive ancillary service integration.