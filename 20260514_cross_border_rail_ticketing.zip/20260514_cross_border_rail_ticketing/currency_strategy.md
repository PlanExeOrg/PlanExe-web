This plan involves money.

## Currencies

- **EUR:** The project is centered across the European Union, where the Euro is the primary currency for most participating member states.

**Primary currency:** EUR

**Currency strategy:** The primary currency budget will be managed in EUR due to the consolidated European scope. Local operational expenditures in non-Eurozone EU countries (if any are involved in the initial corridors, though none are immediately obvious from the primary routes mentioned) should be reconciled to EUR, utilizing routine foreign exchange procedures without complex hedging due to Eurozone stability.