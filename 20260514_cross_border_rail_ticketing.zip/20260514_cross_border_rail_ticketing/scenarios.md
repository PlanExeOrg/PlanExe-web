# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** High ambition: Creating a coordinated, integrated technical and commercial framework for pan-European cross-border rail travel, mandated by EU regulation, aiming for significant modal shift.

**Risk and Novelty:** High risk/Novelty: Requires complex IT integration (OSDM APIs), new financial clearing mechanisms, and harmonizing divergent national policies across numerous established operators.

**Complexity and Constraints:** Very high complexity: Involves numerous sovereign stakeholders (DG MOVE, regulators, 20+ national operators), stringent timeline (five years total, 18 months for binding standards), a large public budget (€1.5B), and deep technical/legal harmonization requirements.

**Domain and Tone:** Public Policy, Regulatory, and Large-Scale Infrastructure/IT implementation. Tone is urgent, comprehensive, and regulatory-driven.

**Holistic Profile:** A mandated, highly complex, multi-year regulatory effort to overhaul cross-border rail ticketing infrastructure across the EU, involving significant technical integration, governance challenges, and balancing public funding with commercial imperatives. The constraint is explicit: 'Pick a realistic scenario, not the most aggressive one.'

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder: Pragmatic Harmonization and Shared Burden
**Strategic Logic:** This scenario aims for scalable, verifiable progress by balancing public investment with carrier accountability. It enforces high standards through structured timelines and cost-sharing models that promote sustainability without freezing out market players.

**Fit Score:** 10/10

**Why This Path Was Chosen:** This scenario perfectly aligns with the requirement for a 'realistic' approach while matching the plan's required scope. It utilizes phased standardization, capped cost recovery for data, and shared liability, balancing ambition with operational reality across complex, diverse stakeholders.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Limit the EU backstop only to instances where the connecting failure occurs between the first and last known segments, leaving disputes regarding segments managed entirely within existing national compensation frameworks.
- **Governing Commercial Terms for Data Exposure and API Access:** Implement a standardized, capped royalty structure based on transaction volume, ensuring all API access fees are strictly cost-recovery for the national carrier's data provisioning, overseen by the regulators.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Establish a strict, tiered liability model where the carrier whose segment experienced the technical failure bears one hundred percent of compensation costs unless gross distributor negligence is proven.
- **Pacing the Binding Standard Adoption Timeline:** Implement a phased standardization approach where technical specifications achieve provisional binding status at six months, followed by regulatory finalization after the first set of corridors demonstrate operational stability at eighteen months.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Implement a transactional fee model where each ticket sale contributes a small, variable percentage to a rolling reserve fund, requiring carriers to provide conditional third-party bank guarantees instead of direct capital injection.

**The Decisive Factors:**

The plan is highly ambitious, involving massive regulatory overhaul and technical risk, yet explicitly requires a *realistic* path over the 'most aggressive' one. The Builder scenario is the superior fit because it manages this tension.

*   **Alignment with Realism:** It adopts a phased standardization timeline (provisional binding at 6 months, finalization after corridor testing), aligning perfectly with the request to avoid overly aggressive adoption, unlike The Pioneer's 12-month hard mandate.
*   **Shared Burden:** It implements cost-recovery royalties for data access and a tiered liability model, balancing the need for market entry with carrier accountability, which is more sustainable than The Pioneer's complete reliance on the public budget.
*   **Contrast with Other Scenarios:** The Pioneer is too aggressive, demanding immediate freezing of core standards and socializing all financial risk. The Consolidator is too passive, pushing excessive liability onto distributors and deferring critical harmonization elements, jeopardizing the core objective of seamless, equitable travel.

---
## Alternative Paths
### The Pioneer: Maximum Dominance & Risk Absorption
**Strategic Logic:** This path aggressively pursues complete harmonization and passenger trust by centralizing risk and forcing rapid technological adoption. It prioritizes market disruption and regulatory success over short-term cost containment or operational comfort for incumbent carriers.

**Fit Score:** 6/10

**Assessment of this Path:** This scenario matches the high ambition and novelty of the plan but is explicitly rejected by the instruction to avoid the 'most aggressive' approach. It mandates the fastest timelines (12 months binding) and centralizes nearly all risk onto the public budget.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Establish a pooled, mandatory insurance or reserve fund managed operationally by the EU Agency for Railways, which pays the passenger upfront for all validated rights claims, then recoups costs based on fault attribution.
- **Governing Commercial Terms for Data Exposure and API Access:** Offer the first two years of API access entirely free of charge for all certified third-party distributors to maximize market penetration initially, shifting the cost burden entirely onto the €1.5 billion public budget.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Create a mandatory collective insurance pool, pre-funded by all participants proportional to journey volume, to cover all unknown-cause or multi-party failure compensation claims up to a defined ceiling.
- **Pacing the Binding Standard Adoption Timeline:** Mandate that all core OSDM data exchange and transaction processing standards achieve full formal binding status within twelve months, necessitating immediate, high-risk operator system modification.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Capitalize the initial float required for the settlement mechanism entirely through the €1.5 billion public coordination budget, treating it as infrastructure investment to minimize carrier working capital strain.

### The Consolidator: Stability and Cost Control
**Strategic Logic:** This conservative path prioritizes minimizing public financial outlay and avoiding operational surprises by favoring established best practices and delayed adoption of complex elements. It relies heavily on existing regulatory structures and national liability frameworks.

**Fit Score:** 3/10

**Assessment of this Path:** This scenario is too conservative. It shifts excessive liability to distributors, defers harmonization of key features (accessibility), and would likely fail to meet the mandated five-year goal of 40% single ticketing penetration due to operational friction.

**Key Strategic Decisions:**

- **Defining Liability and Passenger Rights Backstop Scope:** Require the initial seller (distributor) to assume 100% of the passenger rights liability for the entire journey, irrespective of fault, forcing them to negotiate complex secondary reinsurance contracts with every carrier separately.
- **Governing Commercial Terms for Data Exposure and API Access:** Empower national regulators to impose maximum commercial fees on inventory access, with any carrier exceeding this threshold being temporarily barred from the centralized clearing settlement mechanism until compliance is confirmed.
- **Mechanism for Handling Incomplete Cross-Border Journey Data:** Insist that the initial distributor (the entity contracting with the passenger) retains full, un-capped liability for the entire journey, regardless of failure point, promoting rigorous downstream vetting.
- **Pacing the Binding Standard Adoption Timeline:** Defer the formal binding adoption of reduction card and accessibility reservation schemas until the full TEN-T network integration phase, allowing initial corridors to operate with nationally negotiated, non-harmonized parameters.
- **Financing the Inter-Carrier Clearing Mechanism Capitalization:** Require that only the initiating carrier posts 100% of the required settlement collateral for a given transaction, with automated subrogation mechanisms to reclaim funds from downstream carriers within seven business days.
