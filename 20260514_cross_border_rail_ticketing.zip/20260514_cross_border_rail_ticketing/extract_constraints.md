## Positive Constraints

- Deliver a coordinated European program to make cross-border train travel as easy to search, book, and refund
- Align with the European Commission's proposed Regulation on Digital Booking and Ticketing Services for Rail
- Stand up technical, commercial and governance arrangements
- Enable any compliant distributor to sell through-tickets across all participating carriers
- Ensure continuity-of-journey rights
- Implement single-payment settlement
- Implement harmonised refunds
- Include reduction cards functionality
- Include accessibility for persons with reduced mobility
- Include bicycle reservations
- Scope covers a shared real-time data layer exposed through OSDM-compatible APIs
- Ensure non-discriminatory commercial terms for API access
- Scope covers an inter-carrier clearing and settlement mechanism
- Scope covers a passenger-rights backstop
- Scope covers integration hooks for buses, ferries and short-haul air
- Rollout starts with the busiest cross-border corridors (Paris–Brussels–Amsterdam–Köln, Wien–München–Zürich, Madrid–Barcelona–Lyon, Copenhagen–Hamburg–Berlin)
- Extend rollout to the full TEN-T network
- Involve stakeholders: DG MOVE, the EU Agency for Railways, CER and national operators, independent distributors, BEUC, national regulators and disability-rights bodies
- Target horizon of five years
- Binding standards within eighteen months
- Mandatory API exposure within thirty months
- Full corridor through-ticketing within sixty months
- Public-side coordination budget of €1.5 billion
- Budget covers standards work, conformance testing, the clearing mechanism, a public reference distributor, member-state capacity building and consumer-side rollout (apps, multilingual support, complaint handling)
- Goal: 40% of cross-border journeys sold as single through-tickets within five years
- Goal: Distributor complaints halved within five years
- Goal: Train becomes the more attractive option than flying on competitive short-haul routes so that fewer travellers choose the plane
- Project start ASAP
- Pick a realistic scenario, not the most aggressive one

## Negative Constraints

- Avoid stitching together itineraries from disconnected national operators
- Avoid national operators each having their own fares, booking system, refund policy and disruption handling
- Avoid distributors facing inconsistent access to real-time inventory and post-sale operations
- Avoid passengers being unable to reliably buy a single through-ticket from Lisbon to Tallinn
- Avoid passengers losing passenger-rights protection the moment a connection is missed
