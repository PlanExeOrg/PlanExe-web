## Domain of the expert reviewer
Aquaculture Infrastructure & Strategic Business Planning

## Domain-specific considerations

- Bio-secure recirculating aquaculture system (RAS) engineering
- Midwest thermal dynamics and energy load balancing
- Saline wastewater mitigation in landlocked jurisdictions
- Biological asset risk management (shrimp-specific)
- Direct-to-consumer (DTC) perishable supply chain logistics

## Issue 1 - Missing Assumption: Feed Conversion Ratio (FCR) and Feed Supply Chain
Feed typically represents 50-60% of aquaculture OPEX. The plan assumes a premium price point but lacks an assumption on the FCR (how many lbs of feed to produce 1 lb of shrimp) or the sourcing of high-quality, biosecure feed in the Midwest. Without a local supplier, shipping costs and 'just-in-time' delivery risks could cripple margins.

**Recommendation:** Explicitly assume a target FCR of 1.2 to 1.5. Identify and vet at least two specialized shrimp feed manufacturers (e.g., Zeigler Bros) and factor in a 3-month buffer of feed storage to mitigate supply chain disruptions.

**Sensitivity:** A 20% increase in feed costs or a poor FCR of 1.8 (baseline: 1.3) would increase the cost-per-pound by $1.50-$2.50, potentially reducing the projected ROI by 12-18%.

## Issue 2 - Under-Explored Assumption: Saline Discharge Legal Precedent
The plan assumes municipal plants will accept 1,000–3,000 gallons of saline water daily with 'pre-treatment.' However, many Midwest POTWs (Publicly Owned Treatment Works) have strict chloride limits to protect freshwater ecosystems. 'Pre-treatment' for salt usually requires expensive Reverse Osmosis (RO) or evaporation, not just basic filtration.

**Recommendation:** Conduct a formal feasibility study on 'Zero-Liquid Discharge' (ZLD) systems. Instead of assuming municipal acceptance, budget for an on-site salt recovery or evaporation system to ensure the project isn't halted by a 'Cease and Desist' from the EPA/DNR.

**Sensitivity:** If municipal discharge is denied, an unbudgeted ZLD system (baseline: $0) could cost $150,000-$250,000, increasing initial CAPEX by 10-15% and delaying the first harvest by 4-6 months.

## Issue 3 - Unrealistic Assumption: 14-Month Timeline from Feb Start
Starting construction in the Midwest in February is high-risk. Ground frost and sub-zero temperatures often delay foundation pouring and utility trenching. Furthermore, the plan allows only 2 months for 'system cycling.' Bio-filters in RAS often take 3-4 months to reach the microbial stability required for high-density stocking.

**Recommendation:** Shift the construction start to April or ensure the facility is a 'brownfield' retrofit with existing utilities. Extend the 'system cycling' phase to 90 days in the project schedule to prevent early-stage mass mortality from 'New Tank Syndrome.'

**Sensitivity:** A 3-month construction delay combined with a crashed bio-filter could push the first revenue-generating harvest back by 6-9 months, requiring an additional $100,000-$150,000 in working capital to cover debt service.

## Review conclusion
The 'Builder's Foundation' strategy is technically sound but contains dangerous gaps regarding operational OPEX (feed) and regulatory 'deal-breakers' (saline waste). The most critical risk is the financial 'valley of death' caused by the optimistic 14-month timeline. If the project fails to account for the slow maturation of bio-filters or the high cost of salt management, the $1.5M capital stack will be exhausted before the second harvest. Prioritizing a Zero-Liquid Discharge strategy and securing feed contracts are the most urgent next steps.