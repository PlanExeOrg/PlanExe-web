**Capital Expenditure Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: The PMO only has authority for operational decisions below $25,000. Any major equipment procurement (e.g., RAS components or backup generators) exceeding $100,000 requires strategic oversight due to the impact on the $1.5M total budget.
Negative Consequences: Budget exhaustion before the first harvest, leading to project insolvency and inability to service SBA loans.

**Municipal Denial of Saline Wastewater Discharge Permit**
Escalation Level: Project Steering Committee
Approval Process: Strategic Review and Budget Re-allocation
Rationale: If local authorities deny discharge permits, the project must pivot to a Zero-Liquid Discharge (ZLD) system. This is a strategic shift that involves unbudgeted CAPEX of $150k-$250k and significantly alters the facility infrastructure.
Negative Consequences: Immediate 'Stop Work' order from the EPA/DNR, resulting in indefinite construction delays and potential loss of the chosen site.

**Critical Technical Dispute on RAS Design Specifications**
Escalation Level: Project Steering Committee
Approval Process: Technical Advisory Group Recommendation followed by Steering Committee Vote
Rationale: If the PMO and Technical Lead cannot agree on critical life-support redundancies (e.g., bio-filter capacity or oxygenation levels), the Technical Advisory Group must provide an expert recommendation to the Steering Committee for a final decision.
Negative Consequences: Systemic biological failure leading to mass shrimp mortality (100% crop loss) and reputational damage with restaurant stakeholders.

**Reported Violation of Environmental Compliance Standards**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Any report of illegal saline dumping or violation of USDA food safety standards requires an independent investigation to ensure transparency and legal protection for the founding partners.
Negative Consequences: Heavy regulatory fines ($5,000/day), permanent revocation of aquaculture licenses, and potential criminal liability for the partners.

**Major Strategic Pivot in Market Integration Model**
Escalation Level: Project Steering Committee
Approval Process: Sponsor Consensus and Steering Committee Approval
Rationale: A decision to move from 'Direct-to-Consumer' to a 'Full-stack Pond-to-Plate' model (including on-site processing) introduces significant USDA/FDA hurdles and logistical complexity that exceed the original project scope.
Negative Consequences: Operational overextension, dilution of management focus, and failure to meet existing Letters of Intent (LOI) from restaurant partners.