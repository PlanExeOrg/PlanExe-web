**Goal Statement:** Establish a commercial indoor shrimp farm in the US Midwest using Recirculating Aquaculture System (RAS) technology to achieve the first harvest by April 2027.

## SMART Criteria

- **Specific:** Construct a purpose-built, climate-controlled steel facility of approximately 10,000 sq ft to house a Recirculating Aquaculture System for premium shrimp production.
- **Measurable:** Success is measured by the completion of the facility, successful bio-filter maturation, and a first harvest yielding shrimp for direct-to-consumer and restaurant sales.
- **Achievable:** The project is achievable by leveraging $1.5M in combined partner capital and SBA loans, utilizing the founders' mechanical expertise, and following the 'Builder's Foundation' strategic path.
- **Relevant:** This goal addresses the demand for fresh, high-quality seafood in the Midwest while mitigating the risks of traditional coastal supply chains through local indoor production.
- **Time-bound:** The project aims for a first harvest within 14 months of the February 2026 start date, specifically targeting April 2027.

## Dependencies

- Secure $500k initial partner capital and $1M in SBA 7(a) loans or equipment leasing
- Acquire a 10,000 sq ft industrial site in Indianapolis, Des Moines, or Columbus with appropriate zoning
- Obtain municipal permits for saline wastewater discharge or Zero-Liquid Discharge (ZLD) systems
- Establish a long-term partnership with a genetic provider for SPF post-larvae
- Contract with high-quality shrimp feed manufacturers

## Resources Required

- Climate-controlled steel facility (10,000 sq ft)
- Recirculating Aquaculture System (RAS) components (mechanical filters, bio-bead reactors)
- R-30 spray foam insulation and Heat Recovery Ventilators (HRV)
- 100kW dual-fuel (propane/diesel) backup generator
- IoT water quality sensors (ammonia, dissolved oxygen, temperature)
- Oxygenated transport tanks for hub-and-spoke logistics
- Specific Pathogen Free (SPF) post-larvae
- High-quality shrimp feed (FCR 1.2-1.5)

## Related Goals

- Expand to a hub-and-spoke model with satellite grow-out tanks
- Achieve 'Pond-to-Plate' premium branding in regional culinary markets
- Implement Zero-Liquid Discharge (ZLD) for environmental sustainability

## Tags

- Aquaculture
- Midwest Business
- RAS Technology
- Shrimp Farming
- Sustainable Food

## Risk Assessment and Mitigation Strategies


### Key Risks

- Mass mortality due to RAS failure or thermal shock during Midwest winters
- Regulatory shutdown due to saline wastewater discharge violations
- Financial insolvency due to high heating OPEX or delayed first harvest

### Diverse Risks

- Biosecurity breaches from contaminated post-larvae or feed
- Shortage of skilled RAS technicians in the Midwest region
- Supply chain disruptions for specialized shrimp feed

### Mitigation Plans

- Install redundant 100kW generators and 24/7 IoT monitoring with mobile alerts
- Implement a Zero-Liquid Discharge (ZLD) system or on-site evaporation to bypass municipal chloride limits
- Utilize R-30 insulation and HRV systems to reduce heating costs by 70%
- Establish 30-day quarantine protocols and maintain a 3-month feed buffer
- Partner with local universities (Purdue/Iowa State) for internship programs to build a talent pipeline

## Stakeholder Analysis


### Primary Stakeholders

- Founding Partners (You, Larry, Bubba)
- On-Site Facility Manager
- SBA Loan Officers

### Secondary Stakeholders

- Regional High-End Restaurant Owners
- State Department of Agriculture (Indiana/Iowa/Ohio)
- Municipal Water Authorities
- Shrimp Genetic Providers
- Feed Suppliers (e.g., Zeigler Bros)

### Engagement Strategies

- Secure Letters of Intent (LOI) from 5-10 high-end restaurants to guarantee 30% of first harvest sales
- Regular progress reporting to SBA lenders to ensure continued funding flow
- Early-stage consultation with municipal water authorities to ensure wastewater compliance
- Collaborative training sessions with genetic providers to optimize growth traits

## Regulatory and Compliance Requirements


### Permits and Licenses

- Aquaculture Producer License
- Industrial Discharge Permit
- Building and Electrical Permits for RAS installation
- Zoning Variance for indoor livestock/aquaculture

### Compliance Standards

- EPA Clean Water Act (saline discharge limits)
- USDA/FDA food safety standards for live seafood
- State-specific biosecurity and transport regulations

### Regulatory Bodies

- Indiana Department of Environmental Management (IDEM)
- Iowa Department of Natural Resources (DNR)
- Ohio Environmental Protection Agency
- Local Municipal Wastewater Departments

### Compliance Actions

- Conduct a chloride limit study for the chosen municipality
- Implement a biosecure feed handling and quarantine protocol
- Schedule a pre-operational inspection with the State Department of Agriculture
- Apply for saline wastewater pre-treatment certification