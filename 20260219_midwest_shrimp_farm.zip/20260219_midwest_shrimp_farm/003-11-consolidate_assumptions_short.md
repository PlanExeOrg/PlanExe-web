# Purpose
# Indoor Shrimp Farm Establishment

## Purpose

- Business entrepreneurship and commercial aquaculture project management


# Plan Type
This plan requires physical locations. Cannot be executed digitally.

Explanation: Indoor shrimp farm needs Midwest site scouting/acquisition, facility construction/retrofitting, aquaculture tanks/filtration installation, live shrimp management, Larry/Bubba in-person collaboration, and regulatory inspections.

# Physical Locations
This plan requires physical locations in US Midwest.

## Requirements for physical locations

- US Midwest region
- Zoning for aquaculture or light industrial use
- High-capacity water and electrical utilities
- Proximity to high-end restaurant hubs
- Climate-controlled or insulated structure
- Saline wastewater discharge compliance

## Location 1
USA  
Indianapolis, Indiana  
Industrial Corridor / Near I-465  

Rationale: Supportive aquaculture regulations. Central hub with logistics for Pond-to-Plate and high-end restaurants.

## Location 2
USA  
Des Moines, Iowa  
Agricultural-Industrial Zones  

Rationale: Strong agricultural infrastructure and partnerships. Growing culinary market with workforce for biological management.

## Location 3
USA  
Columbus, Ohio  
Rickenbacker International Airport Area  

Rationale: Fast-growing city. Logistics hub with industrial space for steel facilities and access to regional markets.

## Location Summary
Targets US Midwest indoor shrimp farm. Indiana, Iowa, Ohio selected for agricultural heritage, RAS utility access, and proximity to high-end restaurant contracts.

# Currency Strategy
## Currencies

- USD: US Midwest project; domestic capex for construction, utilities, labor. Primary currency.

- Currency strategy: Use USD for all transactions (facility acquisition, equipment procurement, payroll). No FX risk; domestic operations/markets.


# Identify Risks
## Risk 1 - Operational & Biological
RAS failure (aeration, bio-filtration, heating) causes mass mortality from ammonia spikes or thermal shock in indoor Midwest.

Impact: 3-4 month harvest loss ($50,000-$150,000 per batch); 4-month revenue delay.

Likelihood: Medium

Severity: High

Action: Redundant power supplies (generators), IoT water sensors with 24/7 alerts, automated oxygen injection.

## Risk 2 - Regulatory & Permitting
Saline wastewater discharge violates Midwest codes for freshwater agriculture.

Impact: Fines $1,000-$5,000/day; shutdown or $50,000-$100,000 treatment plant.

Likelihood: High

Severity: High

Action: Engage water authorities in site selection; use Zero-Exchange or evaporation ponds.

## Risk 3 - Financial & Capital
High OPEX from Midwest winter heating for 80°F+ temperatures.

Impact: $5,000-$12,000 monthly overruns; 20-30% higher cost-per-pound.

Likelihood: High

Severity: Medium

Action: High-R-value insulation, HRVs; geothermal pumps or waste-heat co-location.

## Risk 4 - Supply Chain
Biosecurity/logistics issues with single PL source (disease, delays).

Impact: 4-8 week empty tanks; $20,000-$40,000 revenue loss.

Likelihood: Medium

Severity: Medium

Action: Backup hatchery agreements; 30-day quarantine protocol.

## Risk 5 - Technical & Integration
Hub-and-Spoke scaling risks damage/contamination in shrimp/water transport.

Impact: Lower prices, 10-15% labor increase; 2-4 week spoke delay.

Likelihood: Medium

Severity: Low

Action: Standardize oxygenated tanks; rigorous SOP for biosecurity transfers.

## Risk 6 - Social & Labor
Midwest shortage of RAS technicians risks burnout/error.

Impact: Inefficiencies, failures; $15,000-$30,000 consultant costs.

Likelihood: High

Severity: Medium

Action: University internships (Purdue/Iowa State); automated tech stacks.

## Risk summary
High-Severity from Biological/Regulatory risks: (1) asset loss from climate failures, (2) saline waste hurdles. Success needs over-engineered insulation, pre-capital permits. CAPEX for climate control vs. OPEX stability is key tension.

# Make Assumptions
## Question 1 - What is the total initial capital contribution from the three partners, and what is the maximum debt-to-equity ratio you are willing to accept?

- Assumptions: Founding partners (You, Larry, Bubba) have $500k combined liquid capital, leverage $1M via SBA 7(a) loans or ag equipment leasing for mid-scale indoor RAS in Midwest.
- Assessments:

  - Title: Financial Feasibility Assessment
  - Description: Capital structure vs high upfront costs of steel facilities
  - Details: $1.5M budget for ~10,000 sq ft facility
  - Risk: Below $300k initial capital, $1.2M+ loan debt service exceeds early cash flow from restaurant contracts before third harvest

## Question 2 - What is the specific target date for the first 'seed-to-harvest' cycle to be completed?

- Assumptions: First harvest within 14 months of Feb 2026 start: 6 months construction, 2 months system cycling/bio-filter, 6 months growth per RAS standards.
- Assessments:

  - Title: Timeline & Milestones Assessment
  - Description: ASAP start vs Midwest construction seasons
  - Details: Feb start risks winter delays; enclosure by Nov 2026 avoids 30-50% labor drops
  - Opportunity: First harvest aligns with Spring 2027 high-end dining season for max margins

## Question 3 - Which of the three founders will be the full-time 'On-Site Manager,' and what is their specific experience with water chemistry or mechanical systems?

- Assumptions: One founder full-time operator, others part-time/capital; team lacks aquaculture degrees but has hands-on mechanical/ag experience.
- Assessments:

  - Title: Resources & Personnel Assessment
  - Description: Specialized talent gap risk
  - Details: No 24/7 on-site raises Mass Mortality risk 40%
  - Mitigation: $15k for remote consultant first 6 months to train staff

## Question 4 - Have you identified a specific municipal wastewater plant in Indianapolis, Des Moines, or Columbus that will accept saline discharge?

- Assumptions: Standard RAS with 10% daily exchange, 1,000-3,000 gal saline discharge/day; pre-treatment needed per EPA for inland aquaculture.
- Assessments:

  - Title: Governance & Regulations Assessment
  - Description: Saline waste management feasibility
  - Details: High salinity risks pipe corrosion; non-zero-exchange may need $100k desalination unit
  - Recommendation: Early IDEM/Iowa DNR engagement to avoid Stop Work order

## Question 5 - What is the planned redundancy for the life support systems in the event of a multi-day Midwest power outage?

- Assumptions: Dual-fuel (Propane/Diesel) generator for 100% aeration, 50% heating for 72 hours in storm-prone areas.
- Assessments:

  - Title: Safety & Risk Management Assessment
  - Description: Operational/biological failure risk
  - Details: 4-hour outage in sub-zero without generator causes 90%+ mortality; $45k 100kW generator vs $50k-150k lost harvest (100% ROI on first failure)

## Question 6 - What is the target R-value for the facility insulation, and will you utilize geothermal or waste-heat recovery?

- Assumptions: R-30 spray foam insulation, HRV captures 70% exhaust heat vs Midwest winter OPEX risk; industry benchmark.
- Assessments:

  - Title: Environmental Impact & Energy Assessment
  - Description: Carbon footprint and energy efficiency
  - Details: No R-30+ means 40% margins to heating; waste-heat cuts cost-per-pound $1.20 vs coastal imports

## Question 7 - Which 5-10 high-end restaurants in the chosen city have been contacted for preliminary 'Letters of Intent' (LOI)?

- Assumptions: LOIs for 30% first harvest at $18-22/lb premium via Pond-to-Plate freshness (2x frozen imports).
- Assessments:

  - Title: Stakeholder Involvement Assessment
  - Description: Market integration/revenue stability
  - Details: Restaurant contracts boost margins but add logistics; no LOIs risks $8-10/lb wholesaler sales, threatening loans

## Question 8 - What software or IoT platform will be used to integrate water quality sensors with the 'Hub-and-Spoke' logistics?

- Assumptions: Cloud system (e.g., Aquamanager) for real-time mobile alerts to manage scaling complexity.
- Assessments:

  - Title: Operational Systems Assessment
  - Description: Technical infrastructure for multi-site
  - Details: IoT dashboard monitors remote spokes, cuts on-site labor 25%; digital backbone vs single-point failure

# Distill Assumptions
- Founders provide $500k capital + $1M SBA loans/equipment leasing.
- First harvest within 14 months of Feb 2026 start; construction/retrofitting in 6 months.
- One founder as full-time on-site operator; team uses hands-on mechanical experience (no formal aquaculture degrees).
- RAS disposes 1,000-3,000 gal saline water daily; industrial zoning requires EPA/state pre-treatment.
- Dual-fuel generator provides 72 hrs emergency power for life support.
- Insulation meets R-30 with spray foam + heat recovery ventilators.
- Secure LOIs for 30% first harvest; DTC shrimp priced $18-22/lb.
- Cloud IoT platform for real-time water quality monitoring.
- Purpose-built climate-controlled steel facilities for thermal stability.
- Long-term partnership with single genetic provider.
- Hub-and-spoke scaling: central processing + satellite grow-out tanks.


# Review Assumptions
## Domain of the expert reviewer
Aquaculture Infrastructure & Strategic Business Planning

## Domain-specific considerations

- Bio-secure recirculating aquaculture system (RAS) engineering
- Midwest thermal dynamics and energy load balancing
- Saline wastewater mitigation in landlocked jurisdictions
- Biological asset risk management (shrimp-specific)
- Direct-to-consumer (DTC) perishable supply chain logistics

## Issue 1 - Missing Assumption: Feed Conversion Ratio (FCR) and Feed Supply Chain
Feed is 50-60% of OPEX. Plan assumes premium price but lacks FCR or Midwest biosecure feed sourcing. Shipping and just-in-time risks threaten margins.

Recommendation: Assume FCR 1.2-1.5. Vet two shrimp feed manufacturers (e.g., Zeigler Bros) and include 3-month feed storage buffer.

Sensitivity: 20% feed cost increase or FCR 1.8 (baseline 1.3) raises cost-per-pound $1.50-$2.50, reduces ROI 12-18%.

## Issue 2 - Under-Explored Assumption: Saline Discharge Legal Precedent
Plan assumes municipal acceptance of 1,000-3,000 gallons daily saline water with pre-treatment. Midwest POTWs have strict chloride limits; pre-treatment needs RO or evaporation.

Recommendation: Study Zero-Liquid Discharge (ZLD). Budget on-site salt recovery or evaporation to avoid EPA/DNR halt.

Sensitivity: Denied discharge adds unbudgeted ZLD $150,000-$250,000 (10-15% CAPEX increase), delays first harvest 4-6 months.

## Issue 3 - Unrealistic Assumption: 14-Month Timeline from Feb Start
February Midwest start risks frost delays in construction. RAS bio-filters need 3-4 months cycling, not 2.

Recommendation: Start April or use brownfield retrofit. Extend cycling to 90 days to avoid New Tank Syndrome mortality.

Sensitivity: 3-month delay plus bio-filter crash pushes harvest 6-9 months, needs $100,000-$150,000 extra working capital.

## Review conclusion
Builder's Foundation strategy sound but gaps in OPEX (feed) and regulations (saline waste). Critical risk: 14-month timeline's financial valley of death. $1.5M stack exhausts pre-second harvest without bio-filter or salt fixes. Prioritize ZLD and feed contracts.