# Documents to Create

## Create Document 1: Project Charter: Midwest Indoor Shrimp Farm

**ID**: 92aa6c6e-04c0-4df0-96c4-9539286a9b4c

**Description**: A foundational document defining the project's purpose, high-level objectives (April 2027 first harvest), $1.5M capital structure, and the 'Builder's Foundation' strategic path. It formally authorizes the project and defines the roles of the three founding partners.

**Responsible Role Type**: Project Manager

**Primary Template**: PMI Project Charter Template

**Secondary Template**: None

**Steps to Create**:

- Define project vision and SMART goals based on the 'Builder's Foundation' scenario.
- Outline the $500k equity and $1M debt capital stack.
- Identify high-level risks (biological, thermal, regulatory).
- Obtain signatures from the three founding partners.

**Approval Authorities**: Founding Partners (You, Larry, Bubba)

**Essential Information**:

- Define the specific roles and decision-making authorities of the three founding partners (You, Larry, Bubba), specifically identifying who serves as the full-time 'On-Site Manager' versus capital/strategic partners.
- Detail the $1.5M capital structure: explicitly break down the $500k partner equity and the $1M SBA 7(a) loan/leasing requirements.
- State the primary project objective: Achieving the first 'seed-to-harvest' cycle by April 2027 within a 10,000 sq ft purpose-built steel facility.
- Identify the 'Builder's Foundation' as the chosen strategic path, mandating the use of standard RAS technology and climate-controlled infrastructure.
- List the high-level success criteria: Completion of facility construction by Nov 2026, successful 90-day bio-filter maturation, and securing LOIs for 30% of the first harvest.
- Define the geographic scope: Selection of one primary site from the identified hubs (Indianapolis, Des Moines, or Columbus).
- Specify the high-level mitigation strategy for the 'Critical Risks': Redundant power (100kW generator) and saline waste management (ZLD or pre-treatment).

**Risks of Poor Quality**:

- Ambiguity in founder roles leads to 'single-point-of-failure' risk if the on-site manager is not clearly designated and empowered.
- Inaccurate capital breakdown results in a 'financial valley of death' where funds exhaust before the second harvest due to underestimated OPEX (heating/feed).
- Lack of formal authorization for the ZLD/saline waste strategy leads to mid-project Stop Work orders from municipal authorities.
- Vague success criteria prevent the project from securing the necessary $1M in SBA financing due to perceived lack of operational rigor.

**Worst Case Scenario**: The project suffers a total loss of the first harvest ($150k value) and subsequent bankruptcy because the lack of a formal charter resulted in inadequate emergency power protocols and undefined operational accountability during a Midwest winter power outage.

**Best Case Scenario**: The Charter enables immediate securing of SBA funding and local permits by demonstrating a professional, risk-aware management structure, directly leading to an on-time April 2027 harvest with 40% profit margins.

**Fallback Alternative Approaches**:

- Develop a 'Minimum Viable Charter' focusing exclusively on the capital allocation and the On-Site Manager's authority to prevent immediate delays.
- Utilize a standard PMI Project Charter template but append the 'Assumptions' and 'Strategic Decisions' documents as mandatory technical exhibits.
- Conduct a one-day 'Founder Alignment Workshop' to finalize the Charter's content if disagreements on labor or capital split arise.

## Create Document 2: Facility Infrastructure & Thermal Strategy Framework

**ID**: b9d322ed-b09c-48dc-b1ca-1de87f31cb45

**Description**: A high-level strategy document detailing the requirements for purpose-built climate-controlled steel facilities. It addresses the core tension between CAPEX and Midwest thermal stability, focusing on R-30 insulation and HRV integration.

**Responsible Role Type**: Aquaculture Systems Engineer

**Primary Template**: Industrial Facility Design Strategy

**Secondary Template**: None

**Steps to Create**:

- Define technical specifications for steel facility construction.
- Outline the thermal envelope requirements (R-30 spray foam).
- Specify the Heat Recovery Ventilation (HRV) and backup power (100kW generator) requirements.
- Align infrastructure design with the Hub-and-Spoke scaling model.

**Approval Authorities**: Founding Partners, Technical Lead

**Essential Information**:

- Define the specific structural requirements for the 10,000 sq ft steel facility to support the weight of RAS tanks and equipment.
- Detail the R-30 spray foam insulation application plan, including vapor barrier specifications to prevent moisture damage from high-humidity aquaculture environments.
- Specify the Heat Recovery Ventilation (HRV) system capacity required to maintain 80°F+ internal temperatures while managing air exchange and humidity.
- Quantify the 100kW dual-fuel generator's load distribution: Which specific life-support systems (aeration, heaters, sensors) are prioritized during a 72-hour outage?
- Provide a floor plan layout that optimizes the 'Hub-and-Spoke' model, specifically detailing the central processing area versus grow-out tank zones.
- Identify the geothermal or waste-heat recovery integration points to reduce the projected $5,000-$12,000 monthly heating OPEX.
- List the necessary inputs: Structural engineering load requirements for water tanks, local Midwest climate data (extreme lows), and energy efficiency benchmarks for indoor RAS.

**Risks of Poor Quality**:

- Inadequate insulation (below R-30) leads to 20-30% higher cost-per-pound, making the shrimp uncompetitive against imports.
- Poor thermal envelope design causes condensation and structural corrosion, leading to premature facility degradation and biosecurity breaches.
- Undersized HRV or backup power systems result in mass mortality (Risk 1) during the first Midwest winter storm, causing a $150,000 loss per batch.
- Failure to align infrastructure with scaling needs prevents the transition to a hub-and-spoke model, capping revenue potential.

**Worst Case Scenario**: A catastrophic thermal failure during a sub-zero Midwest winter freeze leads to 100% biological asset loss and structural damage, resulting in total financial insolvency and the inability to service the $1M SBA loan.

**Best Case Scenario**: The facility achieves a 70% reduction in heating costs compared to standard retrofits, enabling a stable 80°F environment that accelerates shrimp growth cycles and secures a 40%+ profit margin on premium 'Pond-to-Plate' sales.

**Fallback Alternative Approaches**:

- If purpose-built steel construction is too slow, pivot to a brownfield retrofit of an existing industrial warehouse using modular 'box-in-box' insulation techniques.
- Utilize a pre-engineered metal building (PEMB) supplier with a specialized aquaculture package to accelerate the design phase.
- Develop a 'Minimum Viable Facility' (MVF) covering 5,000 sq ft initially to prove thermal stability before committing to the full 10,000 sq ft footprint.
- Engage a specialized HVAC consultant to produce a standalone Thermal Load Analysis if the internal team lacks specific thermodynamics expertise.

## Create Document 3: Water Management & Saline Waste Strategy

**ID**: 7c1a80b1-0e5b-46d5-94d9-eddf47591c2d

**Description**: A strategic framework for the Recirculating Aquaculture System (RAS) and waste management. It evaluates the transition from standard discharge to Zero-Liquid Discharge (ZLD) to meet Midwest chloride limits.

**Responsible Role Type**: Environmental Compliance & Wastewater Specialist

**Primary Template**: Industrial Wastewater Management Plan

**Secondary Template**: None

**Steps to Create**:

- Define the RAS mechanical and bio-filtration philosophy.
- Outline the ZLD/evaporation strategy to bypass municipal discharge hurdles.
- Establish water quality monitoring parameters (ammonia, DO, temperature).
- Draft initial compliance pathways for IDEM/DNR/Ohio EPA.

**Approval Authorities**: Environmental Compliance Specialist, Municipal Water Authorities

**Essential Information**:

- What are the specific chloride and TDS (Total Dissolved Solids) limits for the chosen municipal wastewater treatment plant (e.g., Indianapolis, Des Moines, or Columbus)?
- Quantify the daily saline discharge volume (gallons) based on a 10% daily exchange rate for a 10,000 sq ft facility.
- Detail the technical specifications of the Zero-Exchange Biofloc or Zero-Liquid Discharge (ZLD) system, including evaporation pond dimensions or mechanical desalination unit capacity.
- A section comparing the CAPEX and OPEX of 'Standard RAS with Pre-treatment' vs. 'Full ZLD' to enable a final technology selection.
- Identify the specific water quality monitoring parameters and sensor placement (Ammonia, Dissolved Oxygen, Temperature, Salinity, pH) required for 24/7 IoT integration.
- List the concrete steps and documentation required for an Industrial Discharge Permit from the relevant state agency (IDEM, Iowa DNR, or Ohio EPA).
- Necessary inputs: Current municipal code for the specific site, RAS equipment flow-rate specs, and quotes for ZLD/evaporation hardware.

**Risks of Poor Quality**:

- Inaccurate salinity calculations lead to a 'Stop Work' order from municipal authorities during the first production cycle.
- Underestimating the cost of ZLD systems (estimated at $150k-$250k) causes a critical capital shortfall before the first harvest.
- Poorly defined water quality parameters result in 'New Tank Syndrome' or ammonia spikes, causing mass shrimp mortality and 100% loss of a $50k-$150k batch.
- Failure to account for Midwest winter evaporation rates leads to overflow of waste ponds and environmental fines.

**Worst Case Scenario**: The project is permanently shut down by state environmental agencies due to illegal saline discharge into freshwater systems, resulting in total loss of the $1.5M investment and potential legal liability for the founders.

**Best Case Scenario**: Enables a confident 'Go' decision on a ZLD system that bypasses all municipal discharge hurdles, securing a 14-month path to harvest and positioning the farm as a sustainable, zero-waste model for future scaling.

**Fallback Alternative Approaches**:

- Engage a specialized aquaculture engineering firm to conduct a 2-week 'Wastewater Feasibility Study' if internal expertise is insufficient.
- Develop a 'Minimum Viable Waste Plan' focusing on a smaller pilot batch with hauled-away waste while the full ZLD system is being permitted.
- Utilize a pre-approved industrial wastewater template from the local Chamber of Commerce and adapt it specifically for saline aquaculture.
- Schedule a formal pre-consultation meeting with the State DNR to confirm if evaporation ponds are a viable alternative to mechanical desalination.

## Create Document 4: Biological Sourcing & Biosecurity Framework

**ID**: 4f816738-20e6-4d2e-aefc-bef497ab3b1e

**Description**: A high-level plan for securing SPF post-larvae and protecting the facility from pathogens. It addresses the risk of single-provider dependency and the biosecurity challenges of the hub-and-spoke model.

**Responsible Role Type**: Aquatic Biologist / Husbandry Technician

**Primary Template**: Aquaculture Biosecurity Standard Operating Framework

**Secondary Template**: None

**Steps to Create**:

- Identify primary and secondary SPF post-larvae providers.
- Define the 30-day quarantine protocol for new shipments.
- Establish 'All-in/All-out' batch protocols for the hub-and-spoke model.
- Outline the feed supply chain biosecurity requirements.

**Approval Authorities**: Technical Lead, State Department of Agriculture

**Essential Information**:

- Identify the top 3 SPF (Specific Pathogen Free) post-larvae providers and evaluate their reliability, cost, and genetic quality.
- Detail a 30-day quarantine protocol for incoming post-larvae shipments to minimize biosecurity risks.
- Define 'All-in/All-out' batch protocols for the hub-and-spoke model to ensure biosecurity between sites and prevent cross-contamination.
- Outline biosecurity requirements for the feed supply chain, including storage, handling, and transportation of shrimp feed.
- Analyze the risks associated with single-provider dependency for post-larvae and propose mitigation strategies, such as backup agreements or in-house breeding feasibility.
- Provide a risk assessment matrix for potential pathogen introduction pathways within the facility and across the hub-and-spoke network.
- Detail the roles and responsibilities of the aquatic biologist and husbandry technician in implementing and maintaining biosecurity protocols.

**Risks of Poor Quality**:

- Inadequate quarantine protocols may lead to disease outbreaks, resulting in mass mortality and significant financial losses.
- Lack of clear biosecurity requirements for the feed supply chain could introduce pathogens, compromising shrimp health and safety.
- Poorly defined 'All-in/All-out' protocols may cause cross-contamination between sites, undermining the hub-and-spoke model’s effectiveness.
- Insufficient analysis of single-provider dependency risks could lead to supply chain disruptions, delaying production cycles and impacting revenue.

**Worst Case Scenario**: A disease outbreak due to inadequate biosecurity protocols wipes out the entire shrimp population, leading to a complete production failure, loss of investor confidence, and potential bankruptcy of the project.

**Best Case Scenario**: The document enables the implementation of a robust biosecurity framework that safeguards shrimp health, ensures consistent production cycles, and supports the scalability of the hub-and-spoke model, ultimately leading to reliable supply for direct-to-consumer and restaurant channels.

**Fallback Alternative Approaches**:

- Utilize a pre-approved aquaculture biosecurity template from a reputable industry organization and adapt it to the hub-and-spoke model’s requirements.
- Engage an aquatic biosecurity consultant to expedite the development of quarantine and batch protocols.
- Conduct a focused workshop with the aquatic biologist and husbandry technician to collaboratively define and refine biosecurity measures.
- Develop a simplified 'minimum viable document' that prioritizes critical biosecurity elements, such as quarantine and 'All-in/All-out' protocols, and iteratively expand it based on early feedback and implementation experience.

## Create Document 5: Initial High-Level Budget & Funding Framework

**ID**: 27aac2b4-8bac-4cb4-aba2-38347a5783b6

**Description**: A foundational financial model outlining the $1.5M allocation across CAPEX (Facility/RAS/ZLD) and 14 months of OPEX. Includes the 20-40% contingency reserve recommended by experts.

**Responsible Role Type**: Project Finance & Grant Administrator

**Primary Template**: SBA 7(a) Financial Projection Template

**Secondary Template**: None

**Steps to Create**:

- Consolidate equipment quotes for RAS and ZLD systems.
- Model heating OPEX based on R-30 insulation and Midwest utility data.
- Define the draw-down schedule for the $1M loan.
- Establish the 'Zero Revenue' contingency scenario for months 14-18.

**Approval Authorities**: Founding Partners, SBA Loan Officer

**Essential Information**:

- Quantify the total CAPEX breakdown: Facility construction ($1.5M target), RAS components, ZLD system ($150k-$250k estimate), and R-30 insulation/HVAC.
- Detail the 14-month OPEX runway: Calculate monthly heating costs for 80°F+ maintenance in Midwest winters, feed costs (based on FCR 1.2-1.5), and labor.
- Define the funding structure: Specify the $500k partner equity contribution and the $1M SBA 7(a) loan terms (interest rate, amortization, and draw-down schedule).
- Establish a 'Financial Valley of Death' contingency: A specific section modeling a 4-6 month delay in the first harvest (e.g., due to bio-filter maturation or construction delays).
- Identify specific data sources: Use utility rate benchmarks for Indianapolis/Des Moines/Columbus and equipment quotes from vendors like Zeigler Bros or RAS specialists.
- Answer: What is the minimum cash-on-hand required at Month 10 to survive until the first premium sale at $18-22/lb?

**Risks of Poor Quality**:

- Underestimating ZLD or saline treatment costs leads to a 'Stop Work' order from municipal authorities mid-construction.
- Inaccurate heating OPEX projections result in the project running out of working capital during the first winter cycle.
- Failure to include a 20-40% contingency reserve causes loan default if the first harvest is delayed or suffers high mortality.
- Vague financial projections lead to SBA loan rejection or unfavorable terms that strain long-term cash flow.

**Worst Case Scenario**: The project exhausts all $1.5M in capital before the first harvest is ready, leading to total insolvency, personal financial loss for the founders, and the abandonment of a half-finished facility.

**Best Case Scenario**: Secures full SBA funding with favorable terms, enables a 'go' decision on the ZLD investment to ensure regulatory peace of mind, and provides a clear 18-month liquidity map that survives initial operational hiccups.

**Fallback Alternative Approaches**:

- Develop a 'Minimum Viable Facility' budget: Scale down to a 5,000 sq ft pilot to prove the concept with the $500k equity before taking on $1M in debt.
- Utilize a pre-approved SBA financial template and hire a specialized agricultural financial consultant for a 2-day intensive review.
- Shift to a brownfield retrofit model (Decision 7, Option 1) if purpose-built steel facility quotes exceed the $1.5M total budget.


# Documents to Find

## Find Document 1: Municipal Wastewater Chloride & TDS Limit Data

**ID**: cc741284-9bd5-4122-be72-48fd5d5dfd08

**Description**: Official 'Local Limits' and pretreatment regulations for the municipal wastewater departments in Indianapolis, Des Moines, and Columbus. Crucial for determining if ZLD is mandatory.

**Recency Requirement**: Current/Most recent version (2024-2026)

**Responsible Role Type**: Environmental Compliance & Wastewater Specialist

**Steps to Find**:

- Contact the Pretreatment Coordinator at Indianapolis (IDEM), Des Moines (DNR), and Columbus (Ohio EPA).
- Search municipal code portals for 'Industrial User' discharge limits.

**Access Difficulty**: Medium (Requires direct contact with city engineers and specific regulatory requests)

**Essential Information**:

- Identify the exact chloride and Total Dissolved Solids (TDS) limits for municipal wastewater discharge in Indianapolis, Des Moines, and Columbus.
- Detail the pretreatment requirements for saline wastewater as specified by each municipality's wastewater department.
- Quantify the cost implications of compliance with these limits, including any required on-site treatment systems (e.g., Zero-Liquid Discharge or evaporation).
- List the specific regulatory contacts and procedures for obtaining wastewater discharge permits in each city.
- Compare the feasibility of direct discharge versus on-site treatment for the project's planned saline wastewater output (1,000-3,000 gallons daily).

**Risks of Poor Quality**:

- Inaccurate chloride or TDS limits lead to permit violations and potential fines of $1,000-$5,000 per day.
- Misinterpretation of pretreatment requirements results in improper system design, causing operational delays and retrofit costs of $50,000-$100,000.
- Outdated or incorrect data leads to regulatory non-compliance, risking project shutdown or enforced treatment upgrades.

**Worst Case Scenario**: The project is forced to halt operations due to untreated saline discharge violations, resulting in fines, mandated, and unbudgeted upgrades of $150,000-$250,000, and a 4-6 month delay in the first harvest.

**Best Case Scenario**: Securing accurate and current wastewater discharge data enables the design of a compliant and cost-effective treatment system, ensuring smooth regulatory approval and allowing the project to stay on schedule and within budget.

**Fallback Alternative Approaches**:

- Engage a wastewater engineering consultant to perform a detailed chloride and TDS analysis for the chosen sites.
- Research and implement a Zero-Liquid Discharge (ZLD) system to eliminate discharge concerns entirely, despite higher upfront costs.
- Negotiate a variance or special permit with municipal authorities by demonstrating the project's economic benefits and commitment to environmental compliance.
- Explore alternative locations with more lenient saline discharge regulations if compliance proves too costly or unattainable.

## Find Document 2: Midwest Industrial Utility Rate Cards

**ID**: e0bc0db8-c89e-4138-88db-c580be25e794

**Description**: Raw data on industrial electricity and natural gas rates for the specific counties targeted. Needed to model the OPEX for 80°F+ winter heating.

**Recency Requirement**: Current year (2025/2026)

**Responsible Role Type**: Project Finance & Grant Administrator

**Steps to Find**:

- Access utility provider websites (e.g., AES Indiana, MidAmerican Energy).
- Request industrial rate schedules from local economic development corporations.

**Access Difficulty**: Easy (Publicly available on utility websites)

**Essential Information**:

- Identify the exact industrial electricity rate (cents per kWh) for the specific service territories in Indianapolis (AES Indiana), Des Moines (MidAmerican Energy), and Columbus (AEP Ohio).
- Identify the exact natural gas rates (per therm or MCF) for industrial users in the target counties.
- Detail the structure of demand charges (peak vs. off-peak) and how they apply to 24/7 life-support systems (aeration and pumps).
- Quantify any 'Economic Development' or 'Agricultural' riders/discounts available for new indoor farming operations.
- List the fixed monthly service fees and infrastructure connection charges for high-capacity industrial meters.
- Determine the seasonal rate fluctuations (Winter vs. Summer) to model the specific impact of heating an 80°F+ environment during Midwest sub-zero months.

**Risks of Poor Quality**:

- Underestimating heating OPEX leads to a 20-30% higher cost-per-pound, potentially erasing the premium margin expected from restaurant sales.
- Inaccurate demand charge modeling causes unexpected monthly cash flow shortages of $5,000-$12,000.
- Failure to account for peak-hour pricing could lead to inefficient scheduling of energy-intensive tasks (e.g., water heating or heavy filtration cycles).
- Incorrect utility data invalidates the Financial Feasibility Assessment, leading to a 'debt service coverage ratio' (DSCR) that fails SBA loan requirements.

**Worst Case Scenario**: The project faces financial insolvency within the first winter because heating costs exceed the total revenue from early harvests, and the $1.5M capital stack is exhausted before the system reaches biological maturity.

**Best Case Scenario**: Precise utility modeling allows the founders to select the most cost-effective site, secure agricultural energy discounts, and optimize the ROI on R-30 insulation, ensuring a stable $1.20/lb cost advantage over coastal competitors.

**Fallback Alternative Approaches**:

- Engage a local energy consultant to provide a comparative utility cost analysis for the three target cities.
- Contact the Economic Development Corporation (EDC) in each city to request 'pro-forma' utility bills for similar-sized industrial facilities.
- Use state-level industrial average rates from the U.S. Energy Information Administration (EIA) as a temporary proxy while awaiting specific rate cards.

## Find Document 3: State-Specific Aquaculture & Biosecurity Laws

**ID**: ab36726a-0e11-48ca-b65e-abf72a09f2da

**Description**: Official legislative text from Indiana, Iowa, and Ohio regarding the transport of live aquatic species and biosecurity requirements for indoor farms.

**Recency Requirement**: Current regulations essential

**Responsible Role Type**: Legal Counsel

**Steps to Find**:

- Search state legislative databases for 'Aquaculture Producer' statutes.
- Check State Department of Agriculture websites for biosecurity and transport permit requirements.

**Access Difficulty**: Easy (Publicly available on government legislative portals)

**Essential Information**:

- Identify the specific 'Import Permit' requirements for transporting Specific Pathogen Free (SPF) post-larvae across state lines into Indiana, Iowa, and Ohio.
- What are the exact quarantine duration and facility isolation standards required by each state's Department of Agriculture before new stock can be integrated?
- List the 'Reportable Diseases' for shrimp in each jurisdiction and the mandatory reporting timeline (e.g., within 24 or 48 hours of detection).
- Detail the specific vehicle and container disinfection protocols mandated for the 'Hub-and-Spoke' transport of live shrimp between satellite tanks.
- Quantify the minimum distance requirements (if any) between the indoor aquaculture facility and existing livestock operations to prevent cross-contamination.
- Identify the required credentials for the 'On-Site Manager' to be recognized as a certified aquatic animal health inspector or equivalent.

**Risks of Poor Quality**:

- Seizure and destruction of expensive SPF post-larvae at state borders due to missing or incorrect transit permits.
- Mandatory facility-wide depopulation (culling) by state authorities if a reportable disease is discovered and biosecurity protocols are deemed non-compliant.
- Legal injunctions or 'Stop Work' orders during the critical 14-month startup phase due to failure to register as an official Aquaculture Producer.
- Ineligibility for state agricultural grants or SBA loan disbursements if the facility fails to meet baseline biosecurity standards.

**Worst Case Scenario**: A biosecurity breach leads to a mass mortality event, followed by a state-mandated permanent shutdown of the facility without compensation, resulting in a total loss of the $1.5M investment and potential legal liability for spreading pathogens to regional water bodies.

**Best Case Scenario**: The project secures 'Certified Biosecure' status, enabling seamless interstate transport of shrimp, reducing insurance premiums by 20%, and serving as a 'Gold Standard' model that fast-tracks future regulatory approvals for the 'Farm-as-a-Service' expansion.

**Fallback Alternative Approaches**:

- Engage a specialized aquaculture regulatory consultant to provide a summary compliance matrix for the three target states.
- Request a formal 'Pre-Operational Review' from the State Veterinarian's office in the selected location.
- Limit initial operations to a single state (e.g., Indiana only) to simplify the regulatory burden until the first harvest is successful.
- Purchase a 'Regulatory Compliance Package' from the shrimp genetic provider that includes pre-vetted transport templates.

## Find Document 4: SPF Post-Larvae Provider Price & Availability Data

**ID**: cc301eb8-2e33-4354-aa16-98cde793f7d9

**Description**: Raw pricing, seasonal availability schedules, and health certification standards from major coastal shrimp hatcheries (e.g., Florida/Texas).

**Recency Requirement**: Published within last 12 months

**Responsible Role Type**: Supply Chain & Logistics Coordinator

**Steps to Find**:

- Contact sales departments of major SPF hatcheries.
- Request 'Certificate of Health' templates and shipping logistics data.

**Access Difficulty**: Medium (Requires direct business-to-business inquiry and verification of biosecurity status)

**Essential Information**:

- Identify the exact unit price per 1,000 post-larvae (PL) for quantities ranging from 100k to 1M units.
- Detail the specific seasonal availability windows (e.g., monthly hatch counts) to ensure year-round stocking for the Midwest facility.
- List the specific pathogens screened for in the 'Certificate of Health' (e.g., WSSV, TSV, EMS/AHPND) to meet biosecurity standards.
- Quantify the guaranteed survival rate during transit from coastal hatcheries to the Midwest (e.g., '95% survival upon arrival').
- Specify the minimum lead time required for orders and the maximum duration for holding a reserved hatch slot.
- Compare shipping costs and logistics requirements for oxygenated transport from Florida vs. Texas hatcheries.

**Risks of Poor Quality**:

- Inaccurate pricing leads to a 'financial valley of death' where the $1.5M capital stack is exhausted before the second harvest.
- Poor health certification standards introduce pathogens, causing a total crop loss and a 4-month revenue delay.
- Unreliable availability schedules result in empty tanks, increasing the cost-per-pound due to fixed overhead (heating/labor) without production.
- Underestimating shipping stress leads to high initial mortality, skewing Feed Conversion Ratio (FCR) data and profitability metrics.

**Worst Case Scenario**: A biosecurity breach from uncertified larvae causes a mass mortality event that triggers a mandatory state-ordered facility quarantine and total asset liquidation, leading to a $1.5M total loss and loan default.

**Best Case Scenario**: Securing a reliable, high-health genetic partner ensures 95%+ survival rates and consistent 6-month growth cycles, allowing the project to hit the April 2027 harvest target with maximum margins.

**Fallback Alternative Approaches**:

- Engage a specialized aquaculture consultant to broker a deal with a secondary backup hatchery.
- Negotiate a 'Trial Batch' agreement with a smaller boutique provider to test transport resilience before committing to a long-term contract.
- Purchase a comprehensive industry market report on shrimp genetics if direct hatchery data is withheld for competitive reasons.
- Accelerate the 'In-house Hatchery' strategic choice if external supply chain risks are deemed unmanageable.

## Find Document 5: Midwest Regional Climate & Soil Statistical Data

**ID**: ca157047-9099-4f20-a7dc-fdf657b63a05

**Description**: Historical temperature extremes and frost depth data for Indianapolis, Des Moines, and Columbus. Used to validate the 100kW generator sizing and construction timelines.

**Recency Requirement**: Last 10-20 years of historical data

**Responsible Role Type**: Aquaculture Systems Engineer

**Steps to Find**:

- Access National Oceanic and Atmospheric Administration (NOAA) regional databases.
- Search state climatology office records for 'Polar Vortex' frequency.

**Access Difficulty**: Easy (Open data portals)

**Essential Information**:

- Identify the absolute minimum and maximum ambient temperatures recorded in Indianapolis, Des Moines, and Columbus over the last 20 years to calculate peak heating and cooling loads.
- Quantify the average and maximum duration of power outages during Midwest winter storm events to validate if the 72-hour fuel reserve for the 100kW generator is sufficient.
- Detail the local frost depth specifications for each city to determine the required depth for water intake/discharge piping and foundation footings.
- List the historical frequency and duration of 'Polar Vortex' events (temperatures below -10°F) to stress-test the R-30 insulation and HRV system efficiency assumptions.
- Compare monthly humidity averages to assess the risk of condensation and mold within a 80°F+ indoor shrimp environment during sub-zero external temperatures.

**Risks of Poor Quality**:

- Underestimated heating loads lead to thermal shock and mass shrimp mortality during extreme cold snaps.
- Inadequate frost depth planning causes burst pipes, leading to system-wide RAS failure and significant property damage.
- Insufficient generator fuel capacity during prolonged regional outages results in total loss of biological assets.
- Inaccurate construction windows lead to mid-winter concrete pours, increasing CAPEX by 30-50% due to heating and hoarding costs.

**Worst Case Scenario**: A record-breaking Polar Vortex occurs during the first winter; the heating system is undersized for the extreme delta, and the generator runs out of fuel during a 4-day grid failure, resulting in 100% crop mortality and a $150,000 loss that triggers loan default.

**Best Case Scenario**: The facility is engineered with high-precision climate data, allowing it to maintain a steady 82°F during record lows with optimized energy consumption, proving the 'Builder's Foundation' model's resilience and securing lower insurance premiums.

**Fallback Alternative Approaches**:

- Consult with local structural engineers or agricultural extension offices (Purdue/Iowa State) for 'worst-case' design standards used in local livestock barns.
- Purchase a site-specific climate risk report from a commercial meteorological service.
- Over-engineer the heating and backup systems by a 25% safety margin if granular historical data is unavailable.

## Find Document 6: Zoning & Land Use Regulations for Target Counties

**ID**: 5037dd92-4484-418c-a946-b3811b808dcd

**Description**: Official zoning maps and permitted use tables for industrial corridors in the three target cities to identify 'Aquaculture' or 'Light Industrial' compatibility.

**Recency Requirement**: Current regulations essential

**Responsible Role Type**: Project Manager

**Steps to Find**:

- Search municipal GIS portals for Indianapolis, Des Moines, and Columbus.
- Download 'Permitted Use' tables from county planning departments.

**Access Difficulty**: Easy (Publicly available on city/county websites)

**Essential Information**:

- Identify the specific zoning classification for each of the three target sites (e.g., I-1 Light Industrial, AG-Agricultural) and confirm if 'Aquaculture' or 'Indoor Livestock' is a permitted, accessory, or conditional use.
- What are the exact setback requirements and maximum building height restrictions for new steel facility construction in these specific industrial corridors?
- List the specific municipal codes governing 'Saline Wastewater Discharge' or 'Industrial Pre-treatment' for each county.
- Identify any 'Overlay Districts' (e.g., Airport, Environmental, or Logistics) that impose additional design standards or usage restrictions on the Rickenbacker or I-465 sites.
- Detail the step-by-step process, timeline, and fees for obtaining a 'Conditional Use Permit' (CUP) if aquaculture is not a 'Use by Right' in the selected zones.
- Quantify the minimum parking and loading dock requirements for a 10,000 sq ft industrial production facility to ensure hub-and-spoke logistics feasibility.

**Risks of Poor Quality**:

- Selection of a site where aquaculture is prohibited leads to immediate project halt and loss of earnest money/deposits.
- Misinterpretation of 'Light Industrial' vs. 'Heavy Industrial' requirements results in expensive, unplanned fire suppression or structural upgrades.
- Failure to identify restrictive overlay districts causes 3-6 month delays in building permit approvals, pushing the February 2026 start date into high-cost winter construction.
- Inaccurate setback data leads to facility designs that cannot be legally built on the acquired lot, requiring a total redesign.

**Worst Case Scenario**: The project acquires a site and begins retrofitting only to receive a 'Cease and Desist' order from the county because shrimp farming is classified as a prohibited 'Concentrated Animal Feeding Operation' (CAFO) in that specific zone, resulting in total loss of initial CAPEX and potential litigation.

**Best Case Scenario**: The document identifies a 'Use by Right' site in a supportive zone, allowing for an accelerated 6-month construction timeline and securing all building permits without the need for public hearings or zoning variances.

**Fallback Alternative Approaches**:

- Engage a local land-use attorney or zoning consultant in the specific municipality to provide a formal 'Zoning Verification Letter'.
- Request a pre-development meeting with the City Planning Department to present the RAS technology and seek a formal 'Administrative Interpretation' of the use.
- Pivot site selection to 'Unincorporated' county land where agricultural exemptions may bypass restrictive municipal industrial zoning.