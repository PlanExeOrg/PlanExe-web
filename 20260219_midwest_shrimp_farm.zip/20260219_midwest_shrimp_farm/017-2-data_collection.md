## 1. Municipal Saline Discharge Limits & ZLD Requirements

Midwest inland treatment plants have strict chloride limits to prevent pipe corrosion and protect freshwater ecosystems. Failure to validate this leads to immediate 'Cease and Desist' orders.

### Data to Collect

- Local Limits for Chloride and Total Dissolved Solids (TDS) for Indianapolis, Des Moines, and Columbus POTWs.
- Industrial User permit requirements and pretreatment surcharges.
- Technical specifications and CAPEX/OPEX for Zero-Liquid Discharge (ZLD) systems.

### Simulation Steps

- Use EPA's 'Industrial User Permitting' online resources to identify pretreatment standards.
- Model wastewater salinity impact using 'AQUASIM' or similar fluid dynamic software to estimate dilution requirements.
- Utilize 'WAVE' (Water Application Value Engine) software by DuPont to simulate ZLD performance and energy consumption.

### Expert Validation Steps

- Consult with the Pretreatment Coordinator at the Indianapolis Department of Public Works.
- Engage a Professional Engineer (PE) specializing in industrial brine management to review discharge plans.
- Submit preliminary data to the Indiana Department of Environmental Management (IDEM) for a 'Letter of Interpretation'.

### Responsible Parties

- Environmental Compliance & Wastewater Specialist
- Project Finance & Grant Administrator

### Assumptions

- **High:** Municipalities will allow 1,000-3,000 gal/day saline discharge with basic pretreatment.

### SMART Validation Objective

Obtain written confirmation of chloride discharge limits from at least two target municipalities by March 1, 2026.

### Notes

- ZLD systems can add $150k-$250k to CAPEX.
- Estimated validation cost: $5,000 (PE consultation fees).


## 2. Thermal Load & Energy Redundancy Validation

Maintaining 80°F in a Midwest winter is the primary OPEX driver. A 4-hour power failure in sub-zero temps results in 90%+ biological mortality.

### Data to Collect

- Historical hourly temperature data for target cities (10-year polar vortex extremes).
- Utility rate cards for industrial gas and electricity in Marion (IN), Polk (IA), and Franklin (OH) counties.
- Fuel consumption rates for 100kW dual-fuel generators under 100% load.

### Simulation Steps

- Run thermal envelope simulations using 'EnergyPlus' or 'eQUEST' to calculate BTU loss at -20°F.
- Use 'HOMER Pro' to simulate microgrid/backup power reliability and fuel autonomy durations.
- Calculate R-30 insulation performance vs. humidity-induced condensation using 'WUFI' software.

### Expert Validation Steps

- Consult with a regional HVAC engineer experienced in industrial climate control.
- Review backup power strategy with a representative from a generator manufacturer (e.g., Generac or CAT).
- Validate utility rate assumptions with local Economic Development Corporations (EDC).

### Responsible Parties

- Facility Operations & Climate Manager
- Aquaculture Systems Engineer

### Assumptions

- **High:** R-30 insulation and HRV will reduce heating costs by 70% compared to uninsulated barns.

### SMART Validation Objective

Complete a thermal load report and backup fuel strategy that guarantees 72-hour autonomy by April 15, 2026.

### Notes

- Propane prices fluctuate significantly in winter; storage capacity is critical.
- Estimated validation cost: $3,500 (Thermal modeling software/consultant).


## 3. Feed Conversion Ratio (FCR) & Supply Chain Biosecurity

Feed is 50-60% of OPEX. Underestimating FCR or facing supply disruptions directly threatens the 14-month financial runway.

### Data to Collect

- Guaranteed FCR and protein content specs from manufacturers (e.g., Zeigler Bros).
- Lead times and biosecure transport costs for 3-month feed buffers.
- Pathogen screening protocols for incoming feed batches.

### Simulation Steps

- Use 'AquaManager' software to simulate growth cycles and feed demand based on FCR variables (1.2 to 1.8).
- Perform a sensitivity analysis on a spreadsheet to determine the 'break-even' FCR at $18/lb sales price.
- Map supply chain routes using 'AnyLogistix' to identify weather-related bottleneck risks.

### Expert Validation Steps

- Consult with a nutritionist at a major aquaculture feed manufacturer.
- Interview an Aquatic Biologist to verify the feasibility of maintaining a 1.5 FCR in a new RAS.
- Review biosecurity protocols with a USDA APHIS (Animal and Plant Health Inspection Service) officer.

### Responsible Parties

- Aquatic Biologist / Husbandry Technician
- Supply Chain & Logistics Coordinator

### Assumptions

- **Medium:** Feed Conversion Ratio (FCR) will remain at 1.5 or lower across the first three cycles.

### SMART Validation Objective

Secure a signed supply agreement and FCR performance data from a primary feed vendor by May 1, 2026.

### Notes

- FCR of 1.8 instead of 1.5 reduces ROI by 15%.
- Estimated validation cost: $1,000 (Sample testing and logistics mapping).

## Summary

The project's success hinges on three high-sensitivity pillars: environmental compliance (saline waste), thermal resilience (Midwest winters), and biological efficiency (FCR). Immediate action is required to validate municipal discharge limits, as a denial would necessitate a $200k+ ZLD system, potentially invalidating the current $1.5M capital stack. Stakeholders must prioritize the 'Industrial User' permit inquiry and the thermal load simulation before committing to a facility lease. The next 60 days should focus on 'de-risking' the saline waste and energy assumptions to ensure the SBA loan application is grounded in regulatory reality.