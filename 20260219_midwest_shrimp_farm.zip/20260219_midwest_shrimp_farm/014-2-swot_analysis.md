
## Strengths 👍💪🦾
- Founding team possesses strong hands-on mechanical and agricultural expertise, essential for RAS maintenance.
- Strategic 'Builder’s Foundation' approach balances proven RAS technology with manageable innovation.
- High-margin 'Pond-to-Plate' model targets $18-22/lb, significantly outperforming commodity frozen imports.
- Geographic advantage: Proximity to high-end culinary hubs (Indy, Des Moines, Columbus) reduces 'food miles' and ensures peak freshness.
- Planned infrastructure includes high R-value insulation (R-30) and Heat Recovery Ventilators (HRV) to mitigate Midwest climate volatility.

## Weaknesses 👎😱🪫⚠️
- Lack of formal aquaculture or microbiological degrees within the founding team increases risk of 'New Tank Syndrome' or bio-filter failure.
- Significant capital intensity ($1.5M) with a long 'financial valley of death' before the first harvest in Month 14.
- Missing a 'Killer Application' or flagship product that differentiates the brand beyond just 'local' to ensure mainstream retail penetration.
- High dependency on a single genetic provider for SPF post-larvae, creating a single point of failure in the supply chain.
- Operational vulnerability to Midwest power outages and extreme thermal shifts.

## Opportunities 🌈🌐
- Development of a 'Killer Application': A 'Subscription-Based Live-Shrimp Home Kit' or 'Ultra-Fresh 24-Hour Delivery' app that gamifies the farm-to-table experience for retail consumers.
- Expansion into a 'Farm-as-a-Service' (FaaS) model, licensing the Midwest-specific tech stack to other regional farmers.
- Utilization of geothermal heat or waste-heat co-location with nearby industrial plants to further slash OPEX.
- Partnerships with universities (Purdue/Iowa State) to create a proprietary 'Midwest-Hardy' shrimp strain.
- Potential for Zero-Liquid Discharge (ZLD) technology to market the farm as the most sustainable seafood source in the region.

## Threats ☠️🛑🚨☢︎💩☣︎
- Regulatory hurdles regarding saline wastewater discharge; potential for EPA/DNR to halt operations if chloride limits are exceeded.
- Rising energy costs in winter could erode the 20-30% margin buffer despite insulation.
- Biosecurity threats: A single pathogen introduction could result in 100% crop mortality and months of decontamination.
- Market entry of large-scale land-based competitors (e.g., Natural Shrimp) into the Midwest market.
- Labor shortage of specialized RAS technicians in non-coastal regions.

## Recommendations 💡✅
- By June 2026, the Marketing Lead must develop a 'Killer App' prototype—a direct-to-consumer subscription platform that offers 'Harvest Alerts' and QR-code traceability to catalyze mainstream adoption.
- By March 10, 2026, the Project Manager must secure a formal consultation with municipal water authorities to finalize the Saline Discharge vs. ZLD investment decision.
- By April 2026, the Technical Lead must install a dual-fuel 100kW generator and conduct a full-load 'blackout' simulation to verify life-support redundancy.
- By May 2026, establish a formal internship partnership with at least one regional university (e.g., Purdue) to secure a pipeline of RAS-trained labor.
- By September 2026, secure signed Letters of Intent (LOIs) from at least 10 high-end restaurants to de-risk the first harvest revenue.

## Strategic Objectives 🎯🔭⛳🏅
- Complete construction and insulation of a 10,000 sq ft climate-controlled facility by November 2026.
- Achieve a stable Bio-filter maturation with zero ammonia spikes for 60 consecutive days prior to first stocking.
- Secure $1.5M in total funding (equity + debt) with a 20% cash contingency reserve by May 2026.
- Execute the first commercial harvest of at least 5,000 lbs of premium shrimp by April 2027.
- Maintain a Feed Conversion Ratio (FCR) of 1.5 or lower across the first three harvest cycles.

## Assumptions 🤔🧠🔍
- Founding partners can successfully secure $1M in SBA 7(a) loans based on $500k equity.
- The Midwest high-end restaurant market will sustain a $18-22/lb price point for fresh vs. frozen product.
- Municipalities will allow saline discharge or the budget can absorb a $150k-$250k ZLD system upgrade.
- The 'Builder's Foundation' path provides enough thermal stability to survive a -20°F Midwest polar vortex.

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Specific chloride discharge limits for the targeted industrial zones in Indianapolis, Des Moines, and Columbus.
- Confirmed availability and lead times for SPF post-larvae from coastal hatcheries during winter months.
- Detailed utility rate cards for industrial electricity/gas in the specific target counties.
- The specific 'Killer App' features that would most appeal to Midwest suburban consumers (e.g., convenience vs. sustainability).

## Questions 🙋❓💬📌
- If a 'Killer App' for direct delivery is the key to mainstream adoption, do we have the logistical 'last-mile' capability to support it?
- What is our 'Plan B' if the local municipality denies our saline wastewater discharge permit 3 months into construction?
- How will we maintain biosecurity if we move toward a 'Hub-and-Spoke' model with frequent shrimp transfers?
- Is our $1.5M budget sufficient if the FCR is 20% worse than assumed or if feed prices spike?
- Which founder is prepared to be on-site 24/7 during the critical first 90 days of bio-filter maturation?