# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: Aquaculture Engineer

**Knowledge**: RAS technology, thermal stability, water quality management

**Why**: To address technical challenges in RAS implementation and thermal stability for Midwest climate.

**What**: Review and optimize the RAS design and thermal management systems in the strategic plan.

**Skills**: Water engineering, thermal dynamics, aquaculture systems

**Search**: Midwest aquaculture engineer, RAS technology consultant, thermal management in aquaculture

## 1.1 Primary Actions

- Engage aquaculture consultants and establish a partnership with a university to provide technical expertise on RAS and water quality management.
- Install a dual-fuel generator with a minimum 100kW capacity and conduct a full-load 'blackout' simulation to ensure thermal stability.
- Conduct a chloride limit study and budget for a Zero-Liquid Discharge (ZLD) system or on-site salt recovery/evaporation unit.

## 1.2 Secondary Actions

- Develop detailed SOPs for bio-filter management and emergency response protocols.
- Stockpile sufficient fuel for the generator to sustain operations during power outages.
- Explore the feasibility of integrating geothermal or waste-heat co-location with nearby industrial plants.

## 1.3 Follow Up Consultation

Discuss the engagement strategy for aquaculture consultants and the timeline for conducting the chloride limit study. Review the budget for the ZLD system and explore potential partnerships with universities for technical support.

## 1.4.A Issue - Insufficient RAS Expertise

The founding team lacks formal aquaculture or microbiological expertise, which increases the risk of 'New Tank Syndrome' or bio-filter failure. This is a critical gap given the complexity of RAS technology and the sensitivity of shrimp to water quality fluctuations.

### 1.4.B Tags

- RAS
- expertise
- bio-filter failure

### 1.4.C Mitigation

Engage with aquaculture consultants or partner with a university (e.g., Purdue or Iowa State) to provide ongoing technical support. Conduct intensive training sessions for the team on RAS operation and troubleshooting. Develop a detailed Standard Operating Procedure (SOP) for bio-filter management and emergency response protocols.

### 1.4.D Consequence

Without this expertise, the project risks catastrophic failure due to poor water quality management, leading to mass shrimp mortality and financial loss.

### 1.4.E Root Cause

The founders' background is mechanical and agricultural, not specialized in aquaculture microbiology.

## 1.5.A Issue - Underestimated Thermal Stability Challenges

The plan relies on insulation and HRV systems to manage Midwest climate extremes, but it does not account for the potential for extreme cold snaps or power outages that could jeopardize thermal stability and shrimp survival.

### 1.5.B Tags

- thermal stability
- power outages
- climate control

### 1.5.C Mitigation

Install a dual-fuel generator with a minimum 100kW capacity and stockpile sufficient fuel for at least 72 hours of continuous operation. Conduct a full-load 'blackout' simulation to verify system redundancy. Consider integrating geothermal or waste-heat co-location with nearby industrial plants to further enhance thermal stability.

### 1.5.D Consequence

Failure to maintain thermal stability could result in significant shrimp mortality, especially during harsh Midwest winters, leading to financial losses and delays in the harvest timeline.

### 1.5.E Root Cause

The plan assumes that insulation and standard backup systems are sufficient without considering worst-case scenarios.

## 1.6.A Issue - Inadequate Saline Waste Management Strategy

The plan mentions engaging with local water authorities but lacks a detailed plan for managing saline wastewater discharge. The risk of violating EPA/DNR chloride limits is high, and the current proposal for a Zero-Liquid Discharge (ZLD) system is not fully budgeted or confirmed.

### 1.6.B Tags

- saline waste
- regulatory compliance
- ZLD

### 1.6.C Mitigation

Conduct a chloride limit study for the chosen municipality immediately and engage with environmental engineers to design a compliant discharge system. Budget for and install a ZLD system or on-site salt recovery/evaporation unit by June 30, 2026. Develop a contingency plan for alternative disposal methods if ZLD proves unfeasible.

### 1.6.D Consequence

Failure to manage saline waste could result in regulatory shutdowns, fines, and reputational damage, jeopardizing the project's viability.

### 1.6.E Root Cause

The plan underestimates the complexity and cost of complying with environmental regulations for saline wastewater.

---

# 2 Expert: Environmental Compliance Specialist

**Knowledge**: EPA regulations, wastewater treatment, saline discharge permits

**Why**: To ensure compliance with local and federal regulations on saline wastewater discharge.

**What**: Assess the regulatory requirements and potential environmental impacts of the proposed Zero-Liquid Discharge system.

**Skills**: Environmental law, wastewater treatment, regulatory compliance

**Search**: saline wastewater compliance, EPA regulations consultant, Midwest aquaculture permits

## 2.1 Primary Actions

- Obtain the 'Local Limits' for Chloride and TDS from the Indianapolis, Des Moines, and Columbus municipal wastewater departments by March 1, 2026.
- Hire a Professional Engineer (PE) to design a Zero-Liquid Discharge (ZLD) system and provide a firm quote to be integrated into the SBA loan application.
- Draft a formal Biosecurity Manual that includes a 'No-Entry' quarantine protocol for the first 30 days of any new PL shipment.
- Re-verify the $1.5M budget against current 2026 steel and specialized PVC piping prices, which have likely inflated.

## 2.2 Secondary Actions

- Secure a secondary 'Backup' PL supplier contract in a different geographic region (e.g., Texas vs. Florida).
- Identify a local lab capable of performing PCR testing for shrimp pathogens (WSSV, EMS, IHHNV) with a 24-hour turnaround.
- Develop a 'Winter Emergency SOP' specifically for power outages exceeding 72 hours during sub-zero temperatures.

## 2.3 Follow Up Consultation

The next session must focus exclusively on the 'Wastewater Pre-treatment Agreement' and the specific ZLD technology chosen. We will also review the 'Bio-filter Maturation' schedule to ensure the 14-month harvest goal is actually grounded in nitrogen cycle reality.

## 2.4.A Issue - Fatal Regulatory Blind Spot: Saline Discharge vs. POTW Limits

The plan assumes a 'Traditional flow-through' or 'Standard RAS' can simply discharge saline water to local Publicly Owned Treatment Works (POTW). Midwest inland treatment plants are not designed for high-chloride loads. Most municipal codes have strict Total Dissolved Solids (TDS) and chloride limits (often <250 mg/L) to protect freshwater ecosystems and prevent corrosion of city infrastructure. Discharging 15-30 ppt (parts per thousand) saltwater into a freshwater sewer system is a guaranteed 'Cease and Desist' order within the first month of operation.

### 2.4.B Tags

- Regulatory Failure
- Environmental Compliance
- Infrastructure Gap

### 2.4.C Mitigation

Immediately pivot the budget to include a Zero-Liquid Discharge (ZLD) system or a closed-loop evaporation/crystallization unit. Consult with an environmental engineer specializing in industrial brine management. Do not sign a lease until you have the 'Industrial User' permit requirements from the specific municipality's Pretreatment Coordinator.

### 2.4.D Consequence

Immediate shutdown by the EPA or local utility, forfeiture of SBA loan due to non-compliance, and potential environmental litigation for damaging local biological treatment processes.

### 2.4.E Root Cause

Underestimation of the chemical difference between coastal aquaculture (ocean discharge) and inland Midwest wastewater infrastructure.

## 2.5.A Issue - Financial 'Valley of Death' and CAPEX Underestimation

A $1.5M budget for a 10,000 sq ft purpose-built steel facility with RAS, ZLD, and 14 months of OPEX is dangerously thin. High-efficiency RAS components and ZLD systems alone can consume 60-70% of that capital. The plan lacks a 'Bio-filter Maturation' buffer—if the nitrifying bacteria crash (common in new systems), you lose the crop and the revenue, but the $20k/month utility and loan payments continue. You are one 'New Tank Syndrome' event away from insolvency.

### 2.5.B Tags

- Financial Risk
- Under-capitalization
- Operational Fragility

### 2.5.C Mitigation

Increase the contingency fund from 20% to 40%. Secure a line of credit specifically for 'Crop Loss Recovery.' Read 'Recirculating Aquaculture' (Timmons & Ebeling) to understand the true cost of bio-filter failures. Provide a detailed month-by-month cash flow statement that includes a 'Zero Revenue' scenario for months 14-18.

### 2.5.D Consequence

Bankruptcy before the second harvest cycle due to technical delays or biological mortality.

### 2.5.E Root Cause

Optimistic bias regarding biological system stability and equipment lead times/costs.

## 2.6.A Issue - Biosecurity and Genetic Supply Chain Fragility

Relying on a 'single genetic provider' for SPF post-larvae (PL) while operating in the Midwest is a strategic bottleneck. If a hurricane hits the coastal hatchery or a 'White Spot Syndrome Virus' (WSSV) outbreak occurs at their site, your Midwest facility goes dark for a season. Furthermore, the plan to move shrimp between 'Hub and Spoke' facilities is a biosecurity nightmare; every transfer is a vector for pathogen introduction that could wipe out the entire network.

### 2.6.B Tags

- Biosecurity
- Supply Chain Risk
- Biological Failure

### 2.6.C Mitigation

Diversify PL sourcing immediately. Invest in on-site 'Nursery' tanks to hold 2-3 months of stock. For the hub-and-spoke model, implement a 'Strict Batch' (All-in/All-out) protocol with no shared water or equipment between spokes. Consult a crustacean pathologist to review the transfer SOPs.

### 2.6.D Consequence

Total facility depopulation due to introduced pathogens, followed by a 6-month decontamination shutdown.

### 2.6.E Root Cause

Failure to account for the extreme vulnerability of high-density monoculture systems to external biological shocks.

---

# The following experts did not provide feedback:

# 3 Expert: Supply Chain Logistics Expert

**Knowledge**: Feed supply chain, biosecurity protocols, transportation of live seafood

**Why**: To mitigate risks in the feed supply chain and ensure biosecurity during shrimp transportation.

**What**: Evaluate the logistics plan for feed supply and shrimp transport, identifying potential vulnerabilities.

**Skills**: Supply chain management, biosecurity, logistics optimization

**Search**: aquaculture supply chain, biosecurity protocols, live seafood logistics

# 4 Expert: Agricultural Economist

**Knowledge**: Farm economics, cost analysis, market pricing strategies

**Why**: To validate financial assumptions and assess the economic viability of the 'Pond-to-Plate' model.

**What**: Conduct a detailed cost-benefit analysis of the proposed pricing strategy and market integration approach.

**Skills**: Financial modeling, market analysis, agricultural economics

**Search**: agricultural economist, aquaculture financial analysis, shrimp farming economics

# 5 Expert: Biosecurity Specialist

**Knowledge**: Aquaculture biosecurity, disease prevention, pathogen control

**Why**: To mitigate the risk of disease outbreaks and ensure robust biosecurity measures are in place.

**What**: Develop and review biosecurity protocols for post-larvae quarantine and facility access control.

**Skills**: Disease management, biosecurity planning, pathogen detection

**Search**: biosecurity in aquaculture, shrimp disease prevention, pathogen control strategies

# 6 Expert: Renewable Energy Consultant

**Knowledge**: Geothermal energy, waste-heat utilization, sustainable power solutions

**Why**: To explore opportunities for reducing operational costs through renewable energy integration.

**What**: Assess the feasibility of using geothermal or waste-heat sources to power the facility's heating systems.

**Skills**: Renewable energy systems, energy efficiency, sustainable design

**Search**: geothermal energy consultant, waste-heat utilization, sustainable aquaculture power solutions

# 7 Expert: Regulatory Affairs Manager

**Knowledge**: Aquaculture regulations, permitting processes, government liaison

**Why**: To navigate the complex regulatory landscape and expedite permit approvals for the project.

**What**: Lead interactions with state and local agencies to secure necessary permits and ensure compliance.

**Skills**: Regulatory compliance, government relations, permit management

**Search**: aquaculture regulatory manager, permitting process consultant, government liaison for aquaculture

# 8 Expert: Agritourism Development Expert

**Knowledge**: Farm-to-table experiences, agritourism marketing, customer engagement

**Why**: To evaluate the potential of integrating agritourism into the business model and enhance customer engagement.

**What**: Analyze the market potential and operational implications of adding agritourism elements to the shrimp farm.

**Skills**: Tourism development, customer experience design, agritourism marketing

**Search**: agritourism consultant, farm-to-table business model, agritourism marketing strategies