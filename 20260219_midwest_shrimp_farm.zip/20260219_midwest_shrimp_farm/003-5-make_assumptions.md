
## Question 1 - What is the total initial capital contribution from the three partners, and what is the maximum debt-to-equity ratio you are willing to accept?

**Assumptions:** Assumption: The founding partners (You, Larry, and Bubba) have a combined liquid capital of $500,000 and intend to leverage an additional $1,000,000 through SBA 7(a) loans or agricultural equipment leasing. This assumption is based on the typical CAPEX requirements for a mid-scale indoor RAS facility in the Midwest.

**Assessments:** Title: Financial Feasibility Assessment. Description: Evaluation of the capital structure against the high upfront costs of purpose-built steel facilities. Details: A $1.5M total budget allows for the construction of a ~10,000 sq. ft. facility. Risk: If initial capital is below $300k, the debt service on a $1.2M+ loan may exceed early-stage cash flow from restaurant contracts, creating a 'valley of death' before the third harvest cycle.

## Question 2 - What is the specific target date for the first 'seed-to-harvest' cycle to be completed?

**Assumptions:** Assumption: The project aims for a 'first harvest' within 14 months of the Feb 2026 start date. This includes 6 months for facility retrofitting/construction, 2 months for system cycling/bio-filter maturation, and 6 months for the first growth cycle. This follows industry standards for new RAS startups.

**Assessments:** Title: Timeline & Milestones Assessment. Description: Analysis of the 'ASAP' start date relative to Midwest construction seasons. Details: Starting in February means construction begins during peak winter; if the facility isn't enclosed by November 2026, internal system installation will face 30-50% labor efficiency drops due to cold. Opportunity: Aligning the first harvest with the Spring 2027 'high-end' dining season maximizes initial margins.

## Question 3 - Which of the three founders will be the full-time 'On-Site Manager,' and what is their specific experience with water chemistry or mechanical systems?

**Assumptions:** Assumption: One founder will act as the full-time operator while the others provide part-time support or capital. It is assumed the team lacks formal aquaculture degrees but possesses 'hands-on' mechanical or agricultural experience. This is common in entrepreneurial 'Builder' scenarios.

**Assessments:** Title: Resources & Personnel Assessment. Description: Evaluation of the 'Specialized Talent Gap' risk identified in the risk profile. Details: Without a dedicated 24/7 on-site presence, the likelihood of Risk 1 (Mass Mortality) increases by 40%. Mitigation: Budgeting $15k for a remote aquaculture consultant for the first 6 months of operation can bridge the expertise gap while training local staff.

## Question 4 - Have you identified a specific municipal wastewater plant in Indianapolis, Des Moines, or Columbus that will accept saline discharge?

**Assumptions:** Assumption: The project will utilize a 'Standard RAS' with a 10% daily water exchange rate, requiring the disposal of approximately 1,000–3,000 gallons of saline water per day. It is assumed that local industrial zones will require pre-treatment before discharge. This is based on EPA guidelines for inland aquaculture.

**Assessments:** Title: Governance & Regulations Assessment. Description: Review of the legal feasibility of saline waste management. Details: High-salinity discharge can corrode municipal pipes. If a 'Zero-Exchange' system isn't used, the project may face a $100k unbudgeted expense for an on-site desalination/evaporation unit. Early engagement with the Indiana IDEM or Iowa DNR is critical to avoid a 'Stop Work' order.

## Question 5 - What is the planned redundancy for the life support systems in the event of a multi-day Midwest power outage?

**Assumptions:** Assumption: The facility will be equipped with a dual-fuel (Propane/Diesel) industrial generator capable of maintaining 100% of aeration and 50% of heating loads for 72 hours. This is a standard risk mitigation strategy for high-density indoor farming in storm-prone regions.

**Assessments:** Title: Safety & Risk Management Assessment. Description: Analysis of the 'Operational & Biological' risk of system failure. Details: A 4-hour power failure in sub-zero temperatures without a generator results in 90%+ mortality. The cost of a 100kW generator (~$45k) is less than the cost of a single lost harvest ($50k-$150k), representing a 100% ROI upon the first major grid failure.

## Question 6 - What is the target R-value for the facility insulation, and will you utilize geothermal or waste-heat recovery?

**Assumptions:** Assumption: The facility will use R-30 spray foam insulation and a heat recovery ventilator (HRV) to capture 70% of heat from exhausted air. This assumption addresses the 'High OPEX' risk of Midwest winters. This is an industry benchmark for energy-efficient indoor agriculture.

**Assessments:** Title: Environmental Impact & Energy Assessment. Description: Evaluation of the carbon footprint and energy cost-efficiency. Details: Without R-30+ insulation, winter heating costs in Iowa/Indiana can consume 40% of gross margins. Utilizing waste-heat recovery reduces the 'cost-per-pound' of shrimp by an estimated $1.20, significantly increasing competitiveness against coastal imports.

## Question 7 - Which 5-10 high-end restaurants in the chosen city have been contacted for preliminary 'Letters of Intent' (LOI)?

**Assumptions:** Assumption: The business model relies on securing LOIs for at least 30% of the projected first harvest at a premium price of $18-$22/lb. This assumes a 'Pond-to-Plate' marketing strategy where freshness justifies the 2x price over frozen imports.

**Assessments:** Title: Stakeholder Involvement Assessment. Description: Analysis of market integration and revenue stability. Details: Direct-to-consumer and restaurant contracts provide higher margins but require high 'Logistical Complexity.' Failure to secure LOIs before the first stocking window increases the risk of being forced to sell to low-margin wholesalers at $8-$10/lb, threatening loan repayment.

## Question 8 - What software or IoT platform will be used to integrate water quality sensors with the 'Hub-and-Spoke' logistics?

**Assumptions:** Assumption: The project will deploy a cloud-based monitoring system (e.g., Aquamanager or similar) that provides real-time alerts to all three founders' mobile devices. This assumes a 'Tech-Forward' approach to manage the 'Scaling Complexity' risk.

**Assessments:** Title: Operational Systems Assessment. Description: Evaluation of the technical infrastructure for multi-site management. Details: Using a centralized IoT dashboard allows the founders to monitor 'Spoke' tanks remotely, reducing the need for on-site specialized labor by 25%. This system is the 'digital backbone' required to prevent the 'Single-Point-of-Failure' risk identified in the scaling model.