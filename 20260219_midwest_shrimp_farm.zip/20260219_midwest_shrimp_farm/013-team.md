*Roles Needed & Example People*

# Roles

## 1. Aquaculture Systems Engineer

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The design and installation of a specialized RAS require high-level engineering expertise that is typically project-based. Once the system is calibrated and operational, the need for this specific engineering role diminishes.

**Explanation**:
Responsible for the design, installation, and calibration of the Recirculating Aquaculture System (RAS), including mechanical filtration, bio-bead reactors, and aeration redundancies.

**Consequences**:
Improper system integration leading to bio-filter failure, ammonia spikes, and total crop loss (mass mortality).

**People Count**:
1

**Typical Activities**:
Designing and overseeing the installation of mechanical filtration units, bio-bead reactors, and aeration systems; calibrating water flow rates and pressure sensors; and establishing redundant fail-safe protocols for life-support hardware.

**Background Story**:
Marcus Thorne is a Chicago-based mechanical engineer with a Master’s in Biosystems Engineering from Purdue University and over twelve years of experience in industrial fluid dynamics. Having previously designed closed-loop cooling systems for data centers, Marcus transitioned into aquaculture five years ago, mastering the intricacies of Recirculating Aquaculture Systems (RAS) and bio-filtration. He is deeply familiar with the challenges of maintaining precise water chemistry in volatile climates, making him the ideal candidate to ensure the Midwest facility's life-support systems are resilient against the region's extreme temperature swings.

**Equipment Needs**:
Industrial-grade mechanical filtration units, bio-bead reactors, high-capacity aeration systems, and precision water chemistry testing kits (spectrophotometers).

**Facility Needs**:
A dedicated engineering workshop space within the facility for system assembly, calibration, and testing of fluid dynamic components.

## 2. Environmental Compliance & Wastewater Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: Navigating Midwest saline discharge regulations and ZLD implementation is a specialized legal and technical hurdle. A consultant or specialist is ideal for securing permits and setting up the framework during the pre-operational phase.

**Explanation**:
Navigates the complex Midwest regulations regarding saline discharge and manages the implementation of the Zero-Liquid Discharge (ZLD) or evaporation systems.

**Consequences**:
Legal shutdowns, heavy EPA/DNR fines, or the inability to obtain necessary operating permits for saline water management.

**People Count**:
1

**Typical Activities**:
Liaising with municipal water authorities and state environmental agencies; designing on-site salt recovery or evaporation systems; and conducting regular chloride limit studies to ensure total regulatory compliance.

**Background Story**:
Elena Rodriguez, based in Des Moines, Iowa, is an environmental scientist with a decade of experience navigating EPA and state-level DNR regulations for industrial agricultural runoff. With a background in chemical engineering and a specialized certification in wastewater management, she has successfully led three major projects involving Zero-Liquid Discharge (ZLD) systems for manufacturing plants. Her familiarity with the specific chloride limits of Midwest municipal treatment plants is vital for this project, as she provides the legal and technical bridge needed to secure saline discharge permits in landlocked jurisdictions.

**Equipment Needs**:
Zero-Liquid Discharge (ZLD) system hardware, on-site evaporation units, and high-precision chloride and salinity monitoring equipment.

**Facility Needs**:
Access to the facility's water intake and discharge points, and a small on-site laboratory for conducting wastewater compliance testing.

## 3. Facility Operations & Climate Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Maintaining a constant 80°F+ environment in Midwest winters is a 24/7 critical operation. This role requires a dedicated staff member to manage facility uptime, backup systems, and immediate response to climate failures.

**Explanation**:
Oversees the physical plant, focusing on maintaining the 80°F+ internal environment through R-30 insulation maintenance, HRV systems, and backup generator readiness.

**Consequences**:
Thermal shock to the shrimp during Midwest winters and astronomical utility bills due to inefficient climate control.

**People Count**:
1

**Typical Activities**:
Monitoring and maintaining the facility's thermal envelope and HRV systems; performing routine maintenance on dual-fuel backup generators; and responding to 24/7 climate-related alerts to prevent thermal shock to the shrimp.

**Background Story**:
David 'Bubba' Jenkins is a lifelong resident of Indianapolis with twenty years of experience in commercial HVAC and industrial facility maintenance. While he lacks a formal degree in marine biology, his hands-on expertise with high-R-value insulation, heat recovery ventilators (HRV), and heavy-duty backup generators is unmatched in the local agricultural sector. As one of the founding partners, David is intimately familiar with the project's physical requirements and is uniquely qualified to manage the 24/7 operational demands of keeping a steel facility at a constant 80°F during a sub-zero Indiana winter.

**Equipment Needs**:
100kW dual-fuel (propane/diesel) backup generator, Heat Recovery Ventilators (HRV), and industrial HVAC diagnostic tools.

**Facility Needs**:
A climate-controlled 10,000 sq ft steel facility with R-30 spray foam insulation and a secure, ventilated enclosure for the backup power system.

## 4. Aquatic Biologist / Husbandry Technician

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Daily monitoring of biological assets, managing quarantine, and feeding protocols are core operational tasks. Given the high risk of mass mortality, dedicated full-time staff are needed to ensure consistency and biosecurity.

**Explanation**:
Monitors shrimp health, manages the 30-day quarantine protocols for post-larvae, and optimizes Feed Conversion Ratios (FCR) to ensure growth targets are met.

**Consequences**:
Undetected disease outbreaks, poor growth rates, and inefficient feed usage which accounts for 50-60% of operating costs.

**People Count**:
min 2, max 3, depending on the number of active tanks and harvest cycles.

**Typical Activities**:
Managing 30-day quarantine protocols for post-larvae; monitoring shrimp health and growth rates; and adjusting feeding schedules to optimize FCR and minimize waste protein in the water.

**Background Story**:
Sarah Chen is an aquatic biologist located in Columbus, Ohio, holding a degree in Marine Science and extensive experience in crustacean husbandry from her time at coastal hatcheries. She specializes in biosecurity protocols and the optimization of Feed Conversion Ratios (FCR), having managed large-scale shrimp populations in high-density environments. Sarah is highly familiar with the 'Builder's Foundation' approach and is relevant to this project because her biological oversight will prevent the 'New Tank Syndrome' and disease outbreaks that often plague inland startups.

**Equipment Needs**:
Microscopes for health screening, automated feeding systems, and specialized quarantine tanks for post-larvae isolation.

**Facility Needs**:
A biosecure quarantine zone separate from the main grow-out area and a temperature-controlled feed storage room to maintain a 3-month buffer.

## 5. IoT & Automation Systems Integrator

**Contract Type**: `agency_temp`

**Contract Type Justification**: The initial setup of IoT sensors and cloud platforms can be handled by an agency or specialized firm. Ongoing maintenance can be managed via a service level agreement rather than a permanent hire.

**Explanation**:
Sets up and maintains the cloud-based monitoring platform and water quality sensors to provide 24/7 alerts and data for the hub-and-spoke scaling model.

**Consequences**:
Lack of real-time visibility into water chemistry, leading to slow response times during equipment malfunctions.

**People Count**:
1

**Typical Activities**:
Integrating water quality sensors with cloud-based monitoring platforms; configuring real-time mobile alerts for ammonia and oxygen levels; and maintaining the security and uptime of the automation tech stack.

**Background Story**:
Kevin Park is a systems architect based in Minneapolis who specializes in industrial IoT and cloud-based automation for the agricultural sector. With a background in computer science and five years of experience deploying remote sensor networks for smart-farms, Kevin is an expert at integrating disparate hardware into a unified dashboard. He is familiar with the hub-and-spoke model and is relevant here because he will build the digital backbone that allows the founders to monitor water quality across multiple satellite tanks from a single mobile interface.

**Equipment Needs**:
IoT sensor suite (ammonia, DO, temperature), industrial routers, cloud-server subscriptions, and mobile interface hardware.

**Facility Needs**:
A secure server closet or IT hub with high-speed internet connectivity and redundant power to ensure 24/7 monitoring uptime.

## 6. Supply Chain & Logistics Coordinator

**Contract Type**: `part_time_employee`

**Contract Type Justification**: While critical, procurement and logistics for a single 10,000 sq ft facility do not yet require a 40-hour work week. This role can scale to full-time as the hub-and-spoke model expands.

**Explanation**:
Manages the procurement of biosecure feed, coordinates live shrimp transport in oxygenated tanks, and maintains the 3-month feed buffer.

**Consequences**:
Production halts due to feed shortages or high mortality during transport between satellite grow-out tanks.

**People Count**:
1

**Typical Activities**:
Coordinating the procurement of biosecure feed from specialized manufacturers; managing the logistics of live shrimp transport in oxygenated tanks; and maintaining inventory levels for all critical biological inputs.

**Background Story**:
Linda Wu is a logistics professional from Omaha with a background in cold-chain management and agricultural procurement. She has spent eight years coordinating the transport of perishable goods across the Midwest and has developed a deep network of contacts within the regional supply chain. Her familiarity with biosecure transport and just-in-time delivery is essential for maintaining the farm's three-month feed buffer and ensuring that live shrimp reach satellite grow-out tanks without suffering transport-related mortality.

**Equipment Needs**:
Oxygenated transport tanks for live shrimp, specialized transport vehicles, and industrial pallet racking for feed storage.

**Facility Needs**:
A loading dock with biosecurity disinfection stations for incoming feed deliveries and outgoing shrimp transfers.

## 7. Market Relations & Sales Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Securing high-margin restaurant contracts and managing the 'Pond-to-Plate' brand is essential for the project's financial viability. This requires a dedicated person to build relationships and manage the sales pipeline.

**Explanation**:
Secures and manages 'Letters of Intent' (LOI) from high-end restaurants and handles the 'Pond-to-Plate' branding and direct-to-consumer sales channels.

**Consequences**:
Inability to command premium pricing ($18-22/lb), forcing the business to sell at low-margin commodity wholesale prices.

**People Count**:
1

**Typical Activities**:
Securing Letters of Intent (LOI) from high-end restaurants; managing the 'Pond-to-Plate' brand identity; and overseeing direct-to-consumer sales channels and subscription models.

**Background Story**:
Larry Miller, a founding partner based in Indianapolis, is a former regional sales manager for a major food distribution company with fifteen years of experience in the high-end culinary market. Larry possesses an extensive Rolodex of executive chefs and restaurant owners across the Midwest and understands the 'Pond-to-Plate' value proposition better than anyone. His familiarity with the premium seafood market is the key to the project's financial viability, as he is responsible for securing the high-margin contracts that justify the farm's significant CAPEX.

**Equipment Needs**:
Flash-freezing equipment, branded packaging machinery, and a professional CRM (Customer Relationship Management) software suite.

**Facility Needs**:
A clean-room processing area for packaging and a professional office space for conducting sales meetings and managing restaurant contracts.

## 8. Project Finance & Grant Administrator

**Contract Type**: `part_time_employee`

**Contract Type Justification**: Managing the $1.5M capital stack and SBA compliance is a specialized administrative task that can be performed on a part-time basis or by a fractional CFO to preserve capital during the 'financial valley of death'.

**Explanation**:
Manages the $1.5M capital stack, ensures compliance with SBA 7(a) loan requirements, and pursues state agricultural grants for energy efficiency.

**Consequences**:
Cash flow insolvency during the 14-month 'financial valley of death' before the first harvest generates revenue.

**People Count**:
1

**Typical Activities**:
Managing the $1.5M capital stack and SBA 7(a) loan reporting; pursuing state agricultural and energy grants; and performing cash-flow forecasting to ensure operational runway through the first harvest.

**Background Story**:
Rachel Vance is a fractional CFO based in Chicago who specializes in agricultural finance and SBA loan compliance. With an MBA and a background in venture capital, she has helped dozens of startups navigate the 'financial valley of death' by optimizing capital stacks and securing state-level energy efficiency grants. She is highly familiar with the 14-month timeline of this project and is relevant because she will ensure the $1.5M budget is managed with the discipline required to reach the first harvest without insolvency.

**Equipment Needs**:
Enterprise-grade financial accounting software (e.g., QuickBooks Enterprise) and secure digital document storage for SBA compliance.

**Facility Needs**:
A secure administrative office space for managing sensitive financial records and loan documentation.

---

# Omissions

## 1. Feed Supply Chain Strategy

The plan lacks a detailed strategy for sourcing and managing shrimp feed, which is critical for controlling costs and ensuring biosecurity. Feed accounts for a significant portion of operating expenses and is essential for maintaining optimal shrimp growth.

**Recommendation**:
Develop a comprehensive feed supply chain strategy that includes identifying reliable suppliers, negotiating bulk purchase agreements, and establishing a biosecure storage system with a 3-month buffer.

## 2. Saline Waste Management Plan

The plan assumes municipal acceptance of saline wastewater discharge but lacks a detailed contingency for compliance issues or potential regulatory changes. This is critical in landlocked Midwest regions with strict chloride limits.

**Recommendation**:
Incorporate a Zero-Liquid Discharge (ZLD) system or on-site salt recovery/evaporation as a backup to ensure compliance and avoid environmental violations.

## 3. Biosecurity Protocol for Live Transport

The plan does not detail biosecurity measures for transporting live shrimp between the central facility and satellite tanks, which is crucial for preventing disease outbreaks and ensuring shrimp survival.

**Recommendation**:
Develop and implement a robust biosecurity protocol for live transport, including disinfection stations, health checks, and standardized oxygenated tank systems.

## 4. Local Labor Training and Retention Plan

The plan relies on founders' expertise but does not address the need for training local staff or building a talent pipeline for specialized roles, which is essential for long-term operational resilience.

**Recommendation**:
Partner with local universities (e.g., Purdue, Iowa State) to create internship programs and establish a training curriculum for staff to ensure a skilled workforce.

## 5. Contingency Plan for Power Outages

The plan includes a backup generator but lacks a detailed strategy for extended power outages, which could lead to catastrophic shrimp mortality during Midwest winters.

**Recommendation**:
Enhance the contingency plan by stockpiling additional fuel, installing redundant power systems, and exploring alternative energy sources (e.g., solar or wind) for critical systems.

---

# Potential Improvements

## 1. Clarify Roles and Responsibilities

Some roles, such as the IoT & Automation Systems Integrator and Supply Chain & Logistics Coordinator, have overlapping responsibilities, which could lead to confusion and inefficiencies.

**Recommendation**:
Clearly define the scope of each role, establish a hierarchy for decision-making, and ensure that all team members understand their specific duties and how they contribute to the overall project.

## 2. Enhance Communication Protocols

The plan does not specify communication protocols for team members, which is crucial for coordinating activities and responding to emergencies.

**Recommendation**:
Implement a centralized communication platform (e.g., Slack or Microsoft Teams) and establish regular check-ins to ensure all team members are aligned and informed.

## 3. Streamline Decision-Making Process

The plan involves multiple strategic decisions that could benefit from a more structured decision-making framework to avoid delays and ensure alignment with project goals.

**Recommendation**:
Adopt a decision matrix or similar tool to prioritize decisions based on urgency and impact, and assign clear accountability for each decision.

## 4. Incorporate Sustainability Metrics

While the plan emphasizes sustainability, it lacks specific metrics for measuring environmental impact and resource efficiency, which are important for long-term viability and stakeholder engagement.

**Recommendation**:
Define key sustainability metrics (e.g., water usage, energy consumption, waste production) and establish a system for tracking and reporting these metrics regularly.

## 5. Develop a Risk Management Dashboard

The plan identifies several risks but does not provide a centralized system for monitoring and managing them, which could lead to oversight and inadequate response.

**Recommendation**:
Create a risk management dashboard that tracks key risks, assigns responsibility for mitigation, and includes regular reviews to ensure proactive risk management.