**Purpose:** business

**Purpose Detailed:** Entrepreneurship and commercial aquaculture project management

**Topic:** Indoor shrimp farm establishment