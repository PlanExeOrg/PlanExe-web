A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Municipal wastewater treatment plants in the target Midwest cities will accept daily saline discharge of 1,000-3,000 gallons with only basic pre-treatment. | Submit a formal 'Industrial User' inquiry to the Indianapolis and Des Moines Pretreatment Coordinators requesting specific chloride and TDS limits for the selected zones. | A written response stating that chloride limits are <250 mg/L, which would necessitate an unbudgeted $200k+ Zero-Liquid Discharge (ZLD) system. |
| A2 | The R-30 spray foam insulation and Heat Recovery Ventilators (HRV) will maintain an 80°F internal temperature during a -20°F polar vortex without exceeding the $12,000 monthly utility budget. | Run a thermal envelope simulation using EnergyPlus software specifically modeling a 10,000 sq ft steel structure against 10-year historical Midwest winter extremes. | Simulation results showing a required BTU load that translates to >$18,000 in monthly natural gas or electric costs at current industrial rates. |
| A3 | Regional high-end chefs will sign binding purchase agreements at a $18-22/lb price point based solely on the 'never-frozen' value proposition. | Conduct a 'blind taste test' and pricing survey with 10 executive chefs in the Indianapolis culinary corridor using RAS-grown samples. | Fewer than 3 chefs willing to sign Letters of Intent (LOI) at a price point above $14/lb, citing existing high-quality frozen supply chains. |
| A4 | The Specific Pathogen Free (SPF) post-larvae (PL) supply chain from coastal hatcheries remains biologically secure and accessible during peak winter months. | Request a 3-year historical 'winter delivery' log and most recent PCR pathogen screening report from the primary Florida-based hatchery. | Hatchery data showing >15% delivery cancellation rate between Dec-Feb or a 'detected' status for IHHNV/WSSV in the last 12 months. |
| A5 | The nitrifying bacteria in the bio-bead reactors will achieve full maturation and nitrogen-cycle stability within the budgeted 60-day window using local municipal water. | Perform a 'stress-test' inoculation in a 500-gallon pilot tank using the exact local water source and planned bio-bead media. | Ammonia levels failing to drop below 0.05 mg/L after 75 days of cycling, indicating local water chemistry (e.g., heavy metals or chloramines) is inhibiting bacterial growth. |
| A6 | The Feed Conversion Ratio (FCR) will remain at or below 1.5 using a standard high-protein aquaculture pellet sourced from regional grain processors. | Conduct a 30-day controlled feeding trial with a sample population of 1,000 shrimp using the specific Midwest-sourced feed formulation. | A calculated FCR of >= 1.9, which would increase the cost-per-pound by $2.10 and eliminate the projected 25% net profit margin. |
| A7 | The founding team can execute 24/7 facility monitoring and emergency response manually without hiring specialized RAS technicians for the first 12 months. | Conduct a 72-hour 'stress test' where the three founders must manage all water quality logging and system adjustments on a 3-shift rotation while maintaining their other business duties. | More than two missed critical sensor alerts or a >15% deviation in dissolved oxygen levels during the test period due to operator fatigue. |
| A8 | The purpose-built steel facility will meet all local 'Agricultural-Industrial' zoning variances without requiring a full Environmental Impact Study (EIS). | Submit a preliminary site plan to the Indianapolis Department of Metropolitan Development for a 'Staff Comment' on the necessity of an EIS for indoor aquaculture. | A formal requirement for an EIS, which would add $40,000 in unbudgeted consulting fees and a minimum 9-month delay to the construction start. |
| A9 | The 'Hub-and-Spoke' logistics model can transport live shrimp between satellite grow-out tanks with <5% transport-related mortality using standard oxygenated tanks. | Perform a 4-hour 'mock transport' run with 50 lbs of live shrimp in the planned tank configuration, simulating Midwest road vibrations and temperature shifts. | A post-transport mortality rate of >= 10% or a significant 'stress-induced' ammonia spike in the transport water that prevents immediate tank integration. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Saline Standoff | Process/Financial | A1 | Environmental Compliance Specialist | CRITICAL (20/25) |
| FM2 | The Deep Freeze Blackout | Technical/Logistical | A2 | Facility Operations Manager | CRITICAL (15/25) |
| FM3 | The Premium Perception Gap | Market/Human | A3 | Market Relations Director | CRITICAL (16/25) |
| FM4 | The Nitrogen Debt Trap | Process/Financial | A5 | Aquaculture Systems Engineer | CRITICAL (15/25) |
| FM5 | The Biosecure Border Closure | Technical/Logistical | A4 | Aquatic Biologist | CRITICAL (15/25) |
| FM6 | The Metabolic Margin Erosion | Market/Human | A6 | Supply Chain Coordinator | CRITICAL (16/25) |
| FM7 | The Zoning Quagmire | Process/Financial | A8 | Project Finance & Grant Administrator | CRITICAL (15/25) |
| FM8 | The Oxygen Depletion Cascade | Technical/Logistical | A9 | Supply Chain & Logistics Coordinator | CRITICAL (16/25) |
| FM9 | The Founder Burnout Collapse | Market/Human | A7 | Market Relations & Sales Director | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Saline Standoff

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Environmental Compliance Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project fails due to a catastrophic misalignment between operational waste output and municipal regulatory capacity. While construction is 60% complete, the local utility issues a permanent 'Cease and Desist' order after discovering the salinity levels in the test discharge. The budget, already strained by construction overruns, cannot absorb the $250,000 cost of an emergency Zero-Liquid Discharge (ZLD) system. SBA lenders freeze the remaining loan disbursements due to the permit violation, leading to immediate insolvency and the abandonment of the half-finished facility.

##### Early Warning Signs
- Municipal pretreatment coordinator requests additional chemical assays twice in 30 days.
- Local utility board meeting minutes mention 'tightening chloride restrictions' for industrial zones.

##### Tripwires
- Municipal chloride limit confirmed at <= 250 mg/L.
- ZLD system quote exceeds 15% of total remaining CAPEX.

##### Response Playbook
- Contain: Halt all plumbing and drainage installation immediately to prevent non-compliant infrastructure lock-in.
- Assess: Commission a 7-day feasibility study on on-site evaporation ponds vs. mechanical crystallization units.
- Respond: Pivot the capital stack by reallocating the 'Marketing' budget to ZLD procurement and apply for an emergency state environmental grant.


**STOP RULE:** If a discharge permit is denied and ZLD financing is not secured within 45 days, the project is terminated.

---

#### FM2 - The Deep Freeze Blackout

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Facility Operations Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
During a record-breaking February polar vortex, the facility's thermal load exceeds the capacity of the HRV system. Simultaneously, a regional ice storm triggers a 48-hour power outage. While the backup generator kicks in, the fuel consumption rate is 40% higher than estimated due to the extreme cold. The propane delivery truck is delayed by closed highways. The internal temperature drops from 82°F to 55°F in six hours. The thermal shock triggers a 95% mortality rate across all grow-out tanks. The biological cycle is reset, but the 14-month financial runway is exhausted before a second stocking can occur.

##### Early Warning Signs
- Generator fuel consumption exceeds 15 gallons/hour during testing.
- Internal wall sensors show a temperature gradient of >10°F between floor and ceiling.

##### Tripwires
- External temperature remains <= -10°F for > 48 consecutive hours.
- On-site fuel reserves drop to <= 24 hours of autonomy during an active storm.

##### Response Playbook
- Contain: Initiate 'Emergency Recirculation Mode' to concentrate all available heat into the nursery tanks only.
- Assess: Conduct a manual biomass health check every 2 hours to identify the 'point of no return' for harvest salvage.
- Respond: Execute an emergency 'flash harvest' of all marketable-size shrimp to recover at least 20% of asset value before total mortality.


**STOP RULE:** Total biological mortality exceeding 80% in a single event triggers an immediate pivot to a 'dry-lease' of the facility to third-party storage.

---

#### FM3 - The Premium Perception Gap

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Market Relations Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The first harvest is successful, but the 'Pond-to-Plate' model collapses upon market entry. Regional chefs, facing their own margin pressures, refuse to pay the $20/lb premium, opting instead for high-quality 'frozen-at-sea' imports at $11/lb. The founders are forced to sell the perishable inventory to commodity wholesalers at $9/lb to avoid total loss. This 50% revenue shortfall makes it impossible to service the $1M SBA loan. Internal friction peaks as Larry and Bubba blame the marketing strategy, leading to a management breakdown and the eventual foreclosure of the business by the bank.

##### Early Warning Signs
- Fewer than 5 LOIs converted to firm purchase orders 30 days before harvest.
- Target restaurant menus show a shift toward 'Value Seafood' sections.

##### Tripwires
- Average realized sales price per lb is <= $14.00 for two consecutive weeks.
- Customer churn rate of initial LOI signers exceeds 60%.

##### Response Playbook
- Contain: Stop all paid social media advertising and redirect funds to direct sales commissions.
- Assess: Survey non-buying chefs to determine if the barrier is price, size consistency, or delivery frequency.
- Respond: Pivot to a 'Direct-to-Consumer' subscription box model to bypass restaurant gatekeepers and capture retail margins.


**STOP RULE:** If the average sales price remains below the break-even CPP of $12.50 for three consecutive harvest cycles, the business is liquidated.

---

#### FM4 - The Nitrogen Debt Trap

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A5
- **Owner**: Aquaculture Systems Engineer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project enters a financial death spiral when the bio-filters fail to mature on schedule. Despite three separate inoculations, the local water's high mineral content prevents the nitrifying bacteria from colonizing the bio-beads. The 60-day window passes, then 90, then 120. With no shrimp in the tanks, there is zero revenue, but the $15,000 monthly utility bill and SBA loan interest payments continue to drain the $500k partner capital. By the time the water chemistry is finally balanced using expensive reverse-osmosis treatment, the project has exhausted its working capital, leaving no funds for the first larvae purchase or feed.

##### Early Warning Signs
- Ammonia levels remain stagnant at >2.0 mg/L for 3 consecutive weeks post-inoculation.
- Nitrite spike fails to appear by day 45 of the cycling process.

##### Tripwires
- Bio-filter maturation exceeds 90 days.
- Remaining liquid capital drops to <= $50,000 before first stocking.

##### Response Playbook
- Contain: Shut down non-essential heating and aeration in 70% of tanks to preserve cash.
- Assess: Hire a water chemist to perform a full heavy-metal and toxin panel on the municipal source.
- Respond: Install an emergency industrial Reverse Osmosis (RO) system and seek a 3-month loan deferment from the SBA.


**STOP RULE:** If the nitrogen cycle is not stabilized within 150 days, the project is liquidated to prevent total partner equity loss.

---

#### FM5 - The Biosecure Border Closure

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Aquatic Biologist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
A sudden outbreak of Early Mortality Syndrome (EMS) at the primary coastal hatchery, combined with a multi-state 'stop-movement' order on live crustaceans, leaves the Midwest facility with empty tanks for an entire quarter. The 'single genetic provider' strategy backfires as no backup source is available. To save the season, the team attempts to source larvae from an unvetted secondary supplier. This shipment introduces a latent pathogen into the RAS. Within 14 days of stocking, the entire facility suffers a 100% mortality event. The cost of decontaminating the 10,000 sq ft facility and the specialized PVC plumbing exceeds the remaining insurance coverage.

##### Early Warning Signs
- Primary hatchery issues a 'Force Majeure' notice regarding larvae availability.
- State Department of Agriculture announces new emergency inspection requirements for interstate shrimp transport.

##### Tripwires
- Larvae delivery delay exceeds 60 days.
- Pathogen PCR test returns a 'Positive' result for any tank in the facility.

##### Response Playbook
- Contain: Quarantine the affected tank and implement a 'Level 4' biosecurity lockdown (no water sharing).
- Assess: Send tissue samples to a specialized lab for 24-hour PCR confirmation of the specific pathogen.
- Respond: Execute a total facility 'bleach-out' and pivot to a 6-month fallow period while renegotiating supply contracts.


**STOP RULE:** A confirmed outbreak of a 'Reportable Disease' (e.g., WSSV) that requires mandatory USDA depopulation.

---

#### FM6 - The Metabolic Margin Erosion

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Supply Chain Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project successfully reaches harvest, but the financial model collapses due to poor biological efficiency. The regional feed formulation, while cheap, results in an FCR of 2.1 instead of the assumed 1.5. The shrimp grow slower and consume significantly more feed to reach market size. This increases the cost-per-pound to $16.50, leaving almost no margin even at premium restaurant prices. The founders, desperate to cut costs, reduce the aeration and water exchange to save energy, which further stresses the shrimp and leads to a 'muddy' flavor profile. High-end chefs begin returning orders, citing poor quality, and the 'Pond-to-Plate' brand is permanently tarnished in the regional market.

##### Early Warning Signs
- Weekly weight gain per shrimp is <= 0.8 grams for three consecutive weeks.
- Feed inventory depletion rate is 20% faster than the growth-model projection.

##### Tripwires
- Calculated FCR exceeds 1.8 for a full harvest cycle.
- Customer return rate exceeds 15% due to flavor or texture complaints.

##### Response Playbook
- Contain: Immediately switch to a premium, imported feed brand for the remaining 30% of the crop.
- Assess: Conduct a blind taste test with the current crop vs. a competitor's product to identify flavor defects.
- Respond: Implement a 'Purge Cycle' (clean water finishing) for 48 hours prior to harvest to improve flavor profile.


**STOP RULE:** If the FCR cannot be reduced below 1.7 after two corrective feed changes, the facility is converted to a lower-cost species (e.g., Tilapia).

---

#### FM7 - The Zoning Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Project Finance & Grant Administrator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's financial runway is consumed by a regulatory stalemate. Upon submitting the building permits, the county board classifies the 10,000 sq ft facility as a 'High-Impact Industrial' site rather than 'Agricultural,' triggering a mandatory Environmental Impact Study (EIS). The study costs $50,000 and takes 11 months to complete. During this time, the $1M SBA loan commitment expires because construction hasn't commenced. The partners are forced to pay 'holding rent' on the land and legal fees with their initial $500k capital. By the time the variance is granted, the remaining capital is insufficient to break ground, and the project is abandoned before a single steel beam is raised.

##### Early Warning Signs
- City planning office returns the preliminary site plan with >10 'major' environmental queries.
- Local neighborhood association files a formal objection to 'industrial-scale' water usage.

##### Tripwires
- Zoning approval delay exceeds 180 days.
- Pre-construction legal and consulting fees exceed $75,000.

##### Response Playbook
- Contain: Negotiate a 'lease-break' or 'suspension' clause with the landowner to stop rent bleed.
- Assess: Evaluate the cost-benefit of moving the project to a neighboring 'Right-to-Farm' county with fewer restrictions.
- Respond: Pivot to a 'Brownfield' site that already possesses the necessary industrial permits to bypass the EIS requirement.


**STOP RULE:** If a mandatory EIS is triggered and a zoning variance is not granted within 12 months, the project is cancelled.

---

#### FM8 - The Oxygen Depletion Cascade

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Supply Chain & Logistics Coordinator
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The 'Hub-and-Spoke' expansion model fails during its first operational test. A shipment of 5,000 juvenile shrimp is moved from the central nursery to a satellite grow-out tank. During the 3-hour transit, a mechanical failure in the oxygen diffuser goes unnoticed due to a lack of redundant sensors in the transport tank. The shrimp suffer acute hypoxia. While they appear alive upon arrival, their immune systems are compromised. Within 72 hours of integration into the satellite tank, a massive 'die-off' occurs. The satellite tank's bio-filter is overwhelmed by the sudden biomass decay, causing an ammonia spike that kills the remaining healthy stock. The logistical failure results in a total loss of the spoke's production capacity for the season.

##### Early Warning Signs
- Transport tank water shows a pH drop of >0.5 during 1-hour test runs.
- Shrimp exhibit 'lethargic' swimming behavior immediately following tank transfer.

##### Tripwires
- Transport-related mortality exceeds 8% in a single batch.
- Satellite tank ammonia levels exceed 1.0 mg/L within 24 hours of stocking.

##### Response Playbook
- Contain: Immediately isolate the satellite tank's water loop from the rest of the facility to prevent cross-contamination.
- Assess: Perform a necropsy on deceased shrimp to confirm hypoxia vs. pathogen-induced mortality.
- Respond: Retrofit all transport tanks with dual-redundant oxygen sensors and automated 'low-O2' driver alerts.


**STOP RULE:** If three consecutive 'Hub-and-Spoke' transfers result in >10% mortality, the satellite model is abandoned in favor of centralized growth.

---

#### FM9 - The Founder Burnout Collapse

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Market Relations & Sales Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project fails due to human error caused by chronic sleep deprivation. After six months of 24/7 manual monitoring, the three founders are physically and mentally exhausted. During a critical bio-filter maturation phase, Bubba misses a 2:00 AM high-ammonia alert because he silenced his phone to sleep. By the time the team arrives at 7:00 AM, the ammonia levels have reached lethal concentrations, killing the entire nursery stock. The loss of $40,000 in biological assets is compounded by a total breakdown in the founders' working relationship, as Larry blames Bubba for the negligence. The lack of a professional 'On-Site Manager' means there is no objective party to mediate, and the partnership dissolves, leading to a forced liquidation of the facility.

##### Early Warning Signs
- Founders report missing more than 2 routine water checks per week.
- Increase in interpersonal conflict and 'blame-shifting' during weekly partner meetings.

##### Tripwires
- Critical sensor alerts go unacknowledged for > 60 minutes.
- Founder 'on-call' hours exceed 100 hours per week for more than 3 consecutive weeks.

##### Response Playbook
- Contain: Hire a temporary night-shift security/monitoring service to provide immediate relief.
- Assess: Conduct a 'skills gap' audit to determine the exact cost of hiring a full-time RAS technician.
- Respond: Reallocate the founders' equity draw to fund a professional On-Site Facility Manager position immediately.


**STOP RULE:** If a mass mortality event occurs due to a documented 'missed alert' by a founder, the project must hire professional management or close.
