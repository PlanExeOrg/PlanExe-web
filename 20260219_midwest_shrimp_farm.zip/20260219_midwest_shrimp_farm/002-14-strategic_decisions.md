## Primary Decisions
The vital few decisions that have the most impact.


The 'Vital Few' levers (Infrastructure, Water, Market Depth, Genetics, and Scaling) address the core tension between High Upfront CAPEX/Complexity and Long-term Biological/Financial Resilience. By prioritizing these, the founders manage the fundamental risks of Midwest aquaculture: thermal stability, waste compliance, and margin protection. A missing dimension is 'Feed Supply Strategy,' which represents a major recurring cost and biosecurity risk in shrimp farming.

### Decision 1: Facility Infrastructure Strategy
**Lever ID:** `e4f54275-63e8-4fbb-8c09-a97f5b35b4cf`

**The Core Decision:** The Facility Infrastructure Strategy lever determines the physical layout, design, and technological sophistication of the shrimp farm. It directly influences costs, scalability, and operational efficiency. Key success metrics include construction costs, energy efficiency, and biosecurity levels. Options range from retrofitting existing structures to deploying cutting-edge subterranean domes with AI monitoring.

**Why It Matters:** Immediate: Lower upfront CAPEX → Systemic: 30% higher energy loss through poor insulation → Strategic: Long-term operational fragility against Midwest seasonal temperature extremes.

**Strategic Choices:**

1. Retrofit existing agricultural barns with basic insulation and modular plastic tank systems
2. Construct purpose-built climate-controlled steel facilities with integrated heat recovery ventilation
3. Deploy fully automated subterranean bio-secure domes utilizing geothermal heat exchange and AI-monitored life support

**Trade-Off / Risk:** Controls Initial Capital Outlay vs. Operational Thermal Stability. Weakness: The options do not account for the specific zoning challenges of converting livestock barns to aquaculture.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the Water Management Philosophy lever, as advanced infrastructure (e.g., subterranean domes) can better support sophisticated water recycling systems like Zero-Exchange Biofloc. It also complements the Biological Sourcing and Genetics lever by enabling controlled environments for specialized breeding programs.

**Conflict:** This lever may conflict with the Operational Scaling Model lever, as highly sophisticated infrastructure (e.g., subterranean domes) could limit the feasibility of rapid, cost-effective scaling. It may also constrain the Capital Allocation Model lever by requiring higher upfront investments, potentially limiting funds for other critical areas.

**Justification:** *Critical*, Critical because it is the primary physical 'hub' lever. It dictates the CAPEX/OPEX balance and determines the viability of all biological and water management systems in the harsh Midwest climate, directly impacting long-term operational fragility.

### Decision 2: Water Management Philosophy
**Lever ID:** `04962183-0fa8-4342-9ffe-6cfe978f668c`

**The Core Decision:** The Water Management Philosophy lever defines how water is treated, recycled, and discharged within the shrimp farm. It impacts environmental sustainability, operational costs, and regulatory compliance. Success is measured by water usage efficiency, waste discharge levels, and system reliability. Options vary from traditional flow-through to advanced biofloc systems.

**Why It Matters:** Immediate: Simplified plumbing requirements → Systemic: 15% weekly water replacement costs → Strategic: Increased regulatory scrutiny regarding saline wastewater discharge permits.

**Strategic Choices:**

1. Traditional flow-through system with periodic saline discharge to local treatment facilities
2. Standard Recirculating Aquaculture System (RAS) with mechanical filtration and bio-bead reactors
3. Zero-Exchange Biofloc technology utilizing microbial colonies to recycle waste into supplemental protein

**Trade-Off / Risk:** Controls Technical Complexity vs. Environmental Compliance Costs. Weakness: Biofloc requires high-level microbiological expertise that the current team may lack.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Facility Infrastructure Strategy lever, as more advanced water management systems (e.g., Zero-Exchange Biofloc) benefit from purpose-built or automated facilities. It also supports the Biological Sourcing and Genetics lever by maintaining optimal water conditions for specialized shrimp breeds.

**Conflict:** This lever may conflict with the Market Integration Depth lever, as more sophisticated water systems (e.g., Zero-Exchange Biofloc) could complicate scaling for high-volume wholesale operations. It may also constrain the Operational Labor Model lever by requiring specialized expertise for maintenance.

**Justification:** *Critical*, Critical as it controls the core technical risk and environmental compliance. In an indoor Midwest setting, water recycling efficiency and waste discharge permits are the 'make-or-break' factors for regulatory approval and biological yield.

### Decision 3: Market Integration Depth
**Lever ID:** `c984ecab-8105-41e7-a88e-2ad687a2810b`

**The Core Decision:** The Market Integration Depth lever outlines the approach to selling shrimp, from basic wholesaling to full vertical integration. It affects revenue streams, brand control, and customer relationships. Key metrics include profit margins, market reach, and customer acquisition costs. Options range from selling to distributors to a 'Pond-to-Plate' model with direct delivery.

**Why It Matters:** Immediate: Faster time to first sale → Systemic: 40% margin loss to third-party processors → Strategic: Total dependence on external logistics for perishable inventory.

**Strategic Choices:**

1. Wholesale live-shrimp sales to regional seafood distributors and processing plants
2. Direct-to-consumer sales via local farmers markets and high-end regional restaurant contracts
3. Full-stack 'Pond-to-Plate' model including on-site flash-freezing, branded packaging, and subscription delivery

**Trade-Off / Risk:** Controls Revenue Margin vs. Logistical Complexity. Weakness: The radical option ignores the significant USDA/FDA certification hurdles for on-site processing.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Operational Scaling Model lever, as a decentralized franchise model could support regional direct-to-consumer sales. It also complements the Talent Acquisition Approach lever by creating diverse roles for marketing, logistics, and customer service.

**Conflict:** This lever may conflict with the Capital Allocation Model lever, as a full-stack 'Pond-to-Plate' model demands significant investment in logistics, packaging, and marketing. It may also constrain the Biological Sourcing and Genetics lever by requiring rapid, consistent shrimp supply for direct sales.

**Justification:** *High*, High importance because it governs the fundamental revenue model and margin retention. It forces a strategic choice between being a commodity producer or a premium brand, which dictates the necessary scale and logistical complexity.

### Decision 4: Biological Sourcing and Genetics
**Lever ID:** `347e4fd0-6e04-4fbf-8e87-e27b04c60a02`

**The Core Decision:** The Biological Sourcing and Genetics lever focuses on shrimp broodstock and post-larvae sourcing strategies, balancing cost, consistency, and genetic quality. Success is measured by growth rates, disease resistance, and adaptability to local conditions. Options include purchasing SPF larvae, partnering with providers, or developing in-house CRISPR-enhanced breeding programs.

**Why It Matters:** Immediate: Reduced initial broodstock costs → Systemic: 20% higher mortality rates → Strategic: Inability to guarantee year-round supply due to seasonal larvae availability.

**Strategic Choices:**

1. Purchase Specific Pathogen Free (SPF) post-larvae from external coastal hatcheries as needed
2. Establish a long-term partnership with a single genetic provider for consistent growth traits
3. In-house closed-loop hatchery utilizing CRISPR-enhanced broodstock for cold-tolerance and rapid growth

**Trade-Off / Risk:** Controls Supply Chain Reliability vs. R&D Investment. Weakness: It fails to address the biosecurity risks of transporting live larvae across state lines.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Water Management Philosophy lever, as advanced water systems can support specialized genetic lines (e.g., cold-tolerant shrimp). It also complements the Facility Infrastructure Strategy lever by benefiting from controlled environments for breeding and growth.

**Conflict:** This lever may conflict with the Operational Scaling Model lever, as in-house breeding programs could slow rapid expansion due to setup time and complexity. It may also constrain the Market Integration Depth lever by requiring additional resources for maintaining genetic quality during scaling.

**Justification:** *High*, High importance due to its impact on supply chain reliability. For a Midwest farm, the ability to secure or produce larvae year-round is a significant strategic bottleneck that controls mortality rates and production consistency.

### Decision 5: Operational Scaling Model
**Lever ID:** `43b1a316-8d9d-4f00-b776-1aa77312152b`

**The Core Decision:** The Operational Scaling Model lever defines the growth strategy for the shrimp farm, from single-site owner-operator to decentralized franchise models. It influences cost structures, market reach, and management complexity. Key metrics include scalability, operational control, and profitability. Options range from centralized to highly distributed models.

**Why It Matters:** Immediate: Concentrated management focus → Systemic: Single-point-of-failure risk → Strategic: Limited ability to capture regional market share before competitors emerge.

**Strategic Choices:**

1. Single-site owner-operator model managed exclusively by the founding partners
2. Hub-and-spoke expansion utilizing centralized processing with satellite grow-out tanks
3. Decentralized 'Farm-as-a-Service' franchise model providing tech stacks to local Midwest farmers

**Trade-Off / Risk:** Controls Management Control vs. Geographic Reach. Weakness: The franchise model assumes a level of process standardization that is difficult to achieve in live aquaculture.

**Strategic Connections:**

**Synergy:** This lever synergizes with the Market Integration Depth lever, as a decentralized 'Farm-as-a-Service' model could enable regional customization for direct-to-consumer sales. It also complements the Capital Allocation Model lever by spreading investments across multiple sites and stakeholders.

**Conflict:** This lever may conflict with the Facility Infrastructure Strategy lever, as decentralized models could complicate the implementation of advanced, centralized infrastructure. It may also constrain the Biological Sourcing and Genetics lever by making it harder to maintain genetic consistency across multiple sites.

**Justification:** *High*, High importance as it defines the project's ultimate ceiling. It manages the trade-off between tight founder control and the speed required to capture regional market share before competitors enter the indoor aquaculture space.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Operational Labor Model
**Lever ID:** `8f148afa-b5ac-4228-be99-1b1dffa76490`

**The Core Decision:** The Operational Labor Model determines how labor is deployed for daily shrimp farm operations. It ranges from a hands-on approach with minimal overhead by relying on the founders, to hiring local staff for routine tasks, to leveraging AI and automation for efficiency. Success metrics include labor costs, operational efficiency, and scalability of processes.

**Why It Matters:** Immediate: High reliance on founder sweat equity → Systemic: 50% slower scaling due to human bottleneck → Strategic: Limits the business to a single-site lifestyle operation.

**Strategic Choices:**

1. Execute all daily operations manually between the three founders to minimize overhead
2. Hire a dedicated facility manager and local hourly staff for routine maintenance
3. Integrate AI-driven biomass sensors and automated feeding systems to minimize human intervention

**Trade-Off / Risk:** Controls Labor Cost vs. Operational Consistency. Weakness: Does not address the specialized aquaculture expertise required that the founders may lack.

**Strategic Connections:**

**Synergy:** This lever strongly synergizes with the 'Facility Infrastructure Strategy' by enabling scalable automation solutions for labor-intensive tasks. It also aligns with the 'Market Integration Depth' lever by freeing up resources for strategic growth activities.

**Conflict:** Choosing high automation may conflict with the 'Talent Acquisition Approach' if it reduces the need for skilled local hires. It may also complicate the 'Regulatory Engagement Framework' if automated systems face scrutiny or require specialized permits.

**Justification:** *Medium*, Medium importance; while it affects daily efficiency and scaling speed, it is largely a downstream consequence of the chosen Infrastructure and Scaling models rather than a primary driver of the business's existence.

### Decision 7: Location Acquisition Strategy
**Lever ID:** `ae9cd138-24a0-4e86-8c65-7bcc1b260ea0`

**The Core Decision:** The Location Acquisition Strategy focuses on securing a physical space for the shrimp farm. Options include retrofitting an existing warehouse, converting a manufacturing facility through partnerships, or deploying modular farms using AI-driven systems. Key metrics are upfront costs, scalability, and compliance with local zoning and environmental regulations.

**Why It Matters:** Immediate: Secure a site with existing utility infrastructure → Systemic: 30% reduction in construction costs through modular retrofits → Strategic: Enables market entry within 12 months, 20% faster than conventional builds.

**Strategic Choices:**

1. Utilize an existing industrial warehouse in a low‑cost county with minimal retrofits
2. Acquire a former manufacturing facility and retrofit it with modular aquaculture systems under a public‑private partnership
3. Deploy a pop‑up modular farm using shipping containers on leased land, integrating AI‑driven water recycling and edge‑computing monitoring

**Trade-Off / Risk:** Controls Cost Efficiency vs. Speed to Market. Weakness: The options underestimate the impact of local zoning restrictions on site acquisition timelines.

**Strategic Connections:**

**Synergy:** This lever works synergistically with the 'Facility Infrastructure Strategy' by directly influencing the type of systems that can be installed. It also supports the 'Capital Allocation Model' by affecting long-term financial commitments and potential for public funding.

**Conflict:** Selecting a modular farm approach may conflict with the 'Operational Labor Model' if it requires specialized skills for maintenance. It may also complicate the 'Regulatory Engagement Framework' due to the novelty of container-based farming methods.

**Justification:** *Medium*, Medium importance. While essential for the 'ASAP' start, it is a tactical execution of the Facility Infrastructure Strategy. Once a site is secured, its strategic influence diminishes compared to the systems inside it.

### Decision 8: Capital Allocation Model
**Lever ID:** `cfb3708e-6b7b-4e74-b219-7bfc6c684f21`

**The Core Decision:** The Capital Allocation Model outlines how funding is secured and deployed for the shrimp farm. It includes personal savings, blended loans with grants, or tokenized equity for broader investment. Success is measured by the ability to secure adequate funding, manage financial risk, and optimize cost-efficiency.

**Why It Matters:** Immediate: Lock in initial capital through partner contributions → Systemic: 40% lower financing costs via equipment leasing → Strategic: Extends runway for technology scaling while maintaining control.

**Strategic Choices:**

1. Rely on equity financing from personal savings and partner contributions
2. Secure a blended loan using equipment leasing and state agricultural grants
3. Issue tokenized equity on a decentralized platform to attract venture capital and community investors

**Trade-Off / Risk:** Controls Dilution vs. Growth Speed. Weakness: The tokenized equity option lacks clear investor protection mechanisms.

**Strategic Connections:**

**Synergy:** This lever complements the 'Location Acquisition Strategy' by aligning funding sources with the chosen facility approach. It also supports the 'Operational Labor Model' by ensuring funds are available for hiring or automation investments.

**Conflict:** Relying on tokenized equity may conflict with the 'Regulatory Engagement Framework' if it introduces complexity in compliance or governance. It may also challenge the 'Talent Acquisition Approach' if investors demand cost-cutting in labor.

**Justification:** *Medium*, Medium importance. It facilitates the project but doesn't define the operational success of the shrimp farm itself. It is a secondary lever that responds to the requirements set by the Infrastructure and Scaling choices.

### Decision 9: Talent Acquisition Approach
**Lever ID:** `51f7aa37-79f3-46c0-b868-e590a43c1125`

**The Core Decision:** The Talent Acquisition Approach defines the strategy for hiring and training staff for the shrimp farm. It includes hiring local agricultural workers, recruiting specialized engineers, or building a remote AI-managed team. Key metrics are labor quality, cost-effectiveness, and alignment with operational needs.

**Why It Matters:** Immediate: Assemble a core operational crew → Systemic: 25% faster staffing through targeted recruitment → Strategic: Reduces training costs by 35% while maintaining expertise.

**Strategic Choices:**

1. Hire local agricultural workers with on‑the‑job training
2. Recruit aquaculture engineers from coastal regions with relocation incentives
3. Build a remote AI‑managed operations team using offshore talent and immersive VR training

**Trade-Off / Risk:** Controls Skill Depth vs. Operational Autonomy. Weakness: The offshore AI team option may face integration challenges with on‑site equipment.

**Strategic Connections:**

**Synergy:** This lever strengthens the 'Operational Labor Model' by ensuring the right talent is in place for the chosen approach, whether manual, staffed, or automated. It also supports the 'Market Integration Depth' by bringing in expertise for strategic growth.

**Conflict:** Recruiting specialized engineers may conflict with the 'Capital Allocation Model' due to higher costs. It may also complicate the 'Regulatory Engagement Framework' if imported talent faces work permit or local labor law challenges.

**Justification:** *Low*, Low importance because it is redundant with the Operational Labor Model. The choice of 'who' to hire is secondary to the 'how' of the operation (manual vs. automated) defined elsewhere.

### Decision 10: Regulatory Engagement Framework
**Lever ID:** `d6bf0357-3cab-46e5-b6f3-f56921708d5d`

**The Core Decision:** The Regulatory Engagement Framework determines how the farm navigates legal and compliance requirements. It includes standard county processes, forming coalitions for streamlined approvals, or co-developing regulatory pathways with state agencies. Success is measured by the speed and cost of approvals and the ability to influence favorable policies.

**Why It Matters:** Immediate: Submit permit applications → Systemic: 50% faster approval timeline through coalition advocacy → Strategic: Positions the farm as a model for future policy, attracting additional funding.

**Strategic Choices:**

1. Navigate permits through standard county processes with legal counsel
2. Form a coalition with local chambers to streamline approvals
3. Launch a pilot program with the state agriculture department to co‑develop regulatory pathways for indoor farms

**Trade-Off / Risk:** Controls Compliance Timeline vs. Innovation Freedom. Weakness: The pilot program option may require extensive data that the project currently lacks.

**Strategic Connections:**

**Synergy:** This lever enhances the 'Location Acquisition Strategy' by ensuring compliance and reducing regulatory friction for facility choices. It also supports the 'Capital Allocation Model' by opening access to grants and incentives.

**Conflict:** Engaging in pilot programs with state agencies may conflict with the 'Operational Labor Model' if it delays hiring or operational launch. It may also complicate the 'Market Entry Model' by introducing uncertainty in timelines.

**Justification:** *Medium*, Medium importance. While it can accelerate timelines, it is a supporting function to the Water Management and Location levers, which are the actual subjects of the regulation.

### Decision 11: Market Entry Model
**Lever ID:** `eab38166-61f9-4905-8c60-5527e04c683b`

**The Core Decision:** The Market Entry Model defines the primary commercial interface and revenue generation strategy for the shrimp farm. It dictates whether the business focuses on high-volume wholesale to local retailers, high-margin direct-to-consumer digital channels, or a diversified agritourism destination. This lever controls the brand identity, customer relationship management, and logistics requirements. Success is measured by customer acquisition costs, price premiums achieved over commodity markets, and the stability of the sales pipeline relative to the biological production cycles of the facility.

**Why It Matters:** Immediate: Establish initial sales channels → Systemic: Capture 15% market share within two years through diversified channels → Strategic: Generates multiple revenue streams, reducing reliance on single buyer.

**Strategic Choices:**

1. Supply local restaurants and grocery chains directly
2. Integrate with subscription meal kits and direct‑to‑consumer e‑commerce
3. Create a farm‑to‑table agritourism experience with on‑site dining and educational tours

**Trade-Off / Risk:** Controls Revenue Diversification vs. Operational Complexity. Weakness: The agritourism option may strain limited management capacity.

**Strategic Connections:**

**Synergy:** This lever strongly enhances Market Integration Depth by defining the specific touchpoints where the brand adds value. It also works in tandem with the Operational Scaling Model; for instance, a direct-to-consumer model provides the higher margins necessary to fund rapid facility expansion and technological upgrades across the Midwest.

**Conflict:** A significant conflict exists with the Operational Labor Model, as an agritourism approach requires hospitality-trained staff rather than just aquaculture technicians. Furthermore, it constrains the Facility Infrastructure Strategy, as on-site dining or tours necessitate public-facing amenities and safety compliance that differ from a strictly industrial production environment.

**Justification:** *Low*, Low importance as it overlaps significantly with Market Integration Depth. The strategic decision of 'how deep' to go in the value chain is more foundational than the specific 'entry' channel.
