This plan involves money.

## Currencies

- **USD:** The project is located entirely within the United States (Midwest region), involving domestic capital expenditures for construction, utility payments, and local labor.

**Primary currency:** USD

**Currency strategy:** The local currency (USD) will be used for all transactions, including facility acquisition, equipment procurement, and payroll. No international exchange risk management is required as the operations and target markets are domestic.