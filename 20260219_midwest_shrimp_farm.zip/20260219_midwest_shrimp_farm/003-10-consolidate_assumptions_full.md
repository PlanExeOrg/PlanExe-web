# Purpose

**Purpose:** business

**Purpose Detailed:** Entrepreneurship and commercial aquaculture project management

**Topic:** Indoor shrimp farm establishment

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** Opening an indoor shrimp farm is a massive physical undertaking. It requires scouting and acquiring a physical location in the Midwest, constructing or retrofitting a facility, installing specialized aquaculture tanks and filtration systems, and physically managing live biological assets (shrimp). Furthermore, it involves in-person collaboration between the partners (Larry and Bubba) and local regulatory inspections.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Located within the US Midwest region
- Zoning allowance for aquaculture or light industrial use
- Access to high-capacity water and electrical utilities
- Proximity to high-end regional restaurant hubs
- Climate-controlled or insulated structure suitability
- Compliance with saline wastewater discharge regulations

## Location 1
USA

Indianapolis, Indiana

Industrial Corridor / Near I-465

**Rationale**: Indiana has a supportive regulatory environment for aquaculture. Indianapolis provides a central Midwest hub with excellent logistics for 'Pond-to-Plate' distribution and proximity to a large concentration of high-end restaurants.

## Location 2
USA

Des Moines, Iowa

Agricultural-Industrial Zones

**Rationale**: Iowa offers strong agricultural infrastructure and potential for public-private partnerships. Des Moines is a growing culinary market and provides access to a workforce familiar with large-scale biological asset management.

## Location 3
USA

Columbus, Ohio

Rickenbacker International Airport Area

**Rationale**: Columbus is one of the fastest-growing cities in the Midwest. The area near the logistics hub offers the specialized industrial space needed for purpose-built steel facilities and easy access to major regional markets like Cleveland and Cincinnati.

## Location Summary
The plan explicitly targets the US Midwest for an indoor shrimp farm. The suggested locations in Indiana, Iowa, and Ohio were selected based on their robust agricultural heritage, favorable utility access for Recirculating Aquaculture Systems (RAS), and strategic proximity to the high-end restaurant contracts defined in the 'Builder's Foundation' strategic path.

# Currency Strategy

This plan involves money.

## Currencies

- **USD:** The project is located entirely within the United States (Midwest region), involving domestic capital expenditures for construction, utility payments, and local labor.

**Primary currency:** USD

**Currency strategy:** The local currency (USD) will be used for all transactions, including facility acquisition, equipment procurement, and payroll. No international exchange risk management is required as the operations and target markets are domestic.

# Identify Risks


## Risk 1 - Operational & Biological
Mass mortality event due to Recirculating Aquaculture System (RAS) failure. In an indoor Midwest environment, a failure in the life support system (aeration, bio-filtration, or heating) can lead to total crop loss within hours due to ammonia spikes or thermal shock.

**Impact:** Loss of an entire harvest cycle (approx. 3–4 months of growth). Financial impact of $50,000–$150,000 per batch depending on shrimp density and age. Potential 4-month delay in revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** Install redundant power supplies (industrial generators), IoT-based water quality sensors with 24/7 mobile alerts, and automated emergency oxygen injection systems.

## Risk 2 - Regulatory & Permitting
Saline wastewater discharge compliance. Discharging high-salinity water from shrimp tanks into Midwest municipal sewer systems or local water tables often violates local environmental codes designed for freshwater agriculture.

**Impact:** Fines of $1,000–$5,000 per day of non-compliance. Potential project shutdown or a requirement to install a $50,000–$100,000 on-site water treatment/desalination plant.

**Likelihood:** High

**Severity:** High

**Action:** Engage with municipal water authorities during the site selection phase. Prioritize 'Zero-Exchange' technology or evaporation ponds to minimize liquid discharge.

## Risk 3 - Financial & Capital
High Operational Expenditure (OPEX) due to Midwest energy costs. Maintaining tropical temperatures (80°F+) in a steel facility during Indiana/Iowa winters (sub-zero) creates massive heating bills that can erode margins.

**Impact:** Monthly utility overruns of $5,000–$12,000 beyond projections during winter months. Could lead to a 20-30% increase in the cost-per-pound of shrimp produced.

**Likelihood:** High

**Severity:** Medium

**Action:** Invest in high-R-value spray foam insulation and heat recovery ventilators (HRVs). Explore geothermal heat pumps or co-location near industrial waste-heat sources.

## Risk 4 - Supply Chain
Biosecurity and logistics of Post-Larvae (PL) sourcing. Relying on a single genetic provider for live larvae means any disease outbreak at the provider's hatchery or a transport delay (e.g., grounded flights) halts production.

**Impact:** Empty tanks for 4–8 weeks. Loss of 'consistent supply' reputation with high-end restaurant partners. Estimated revenue loss of $20,000–$40,000 per missed stocking window.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish secondary sourcing agreements with a backup hatchery. Implement a strict 30-day quarantine protocol for all incoming larvae to protect the main facility.

## Risk 5 - Technical & Integration
Scaling complexity of the 'Hub-and-Spoke' model. Moving live shrimp or sensitive water between satellite grow-out tanks and a central processing hub increases the risk of physical damage to the product and cross-contamination.

**Impact:** Product degradation leading to lower market prices (wholesale vs. premium). 10-15% increase in labor costs due to complex logistics. Potential 2-4 week delay in establishing the first 'spoke'.

**Likelihood:** Medium

**Severity:** Low

**Action:** Standardize transport equipment (oxygenated hauling tanks) and develop a rigorous SOP for biosecurity transfers between sites.

## Risk 6 - Social & Labor
Specialized talent gap. The Midwest lacks a deep pool of experienced warm-water aquaculture technicians. Relying on Larry, Bubba, and the founder to manage complex RAS chemistry may lead to burnout or human error.

**Impact:** Operational inefficiencies and increased risk of system failure. Hiring specialized consultants from coastal regions could cost an extra $15,000–$30,000 in relocation and salary premiums.

**Likelihood:** High

**Severity:** Medium

**Action:** Partner with local universities (e.g., Purdue or Iowa State) to create an internship pipeline. Invest in simplified, automated 'tech stacks' to reduce the need for PhD-level water chemistry knowledge.

## Risk summary
The project faces a 'High-Severity' profile primarily driven by Biological and Regulatory risks. The most critical threats are (1) the catastrophic loss of live assets due to Midwest climate-induced system failures and (2) the legal hurdles of saline waste management in a freshwater region. While the 'Builder's Foundation' strategy uses proven RAS technology, the team's success depends on over-engineering thermal insulation and securing ironclad discharge permits before capital is deployed. The trade-off between high upfront CAPEX for climate control and long-term OPEX stability is the project's central financial tension.

# Make Assumptions


## Question 1 - What is the total initial capital contribution from the three partners, and what is the maximum debt-to-equity ratio you are willing to accept?

**Assumptions:** Assumption: The founding partners (You, Larry, and Bubba) have a combined liquid capital of $500,000 and intend to leverage an additional $1,000,000 through SBA 7(a) loans or agricultural equipment leasing. This assumption is based on the typical CAPEX requirements for a mid-scale indoor RAS facility in the Midwest.

**Assessments:** Title: Financial Feasibility Assessment. Description: Evaluation of the capital structure against the high upfront costs of purpose-built steel facilities. Details: A $1.5M total budget allows for the construction of a ~10,000 sq. ft. facility. Risk: If initial capital is below $300k, the debt service on a $1.2M+ loan may exceed early-stage cash flow from restaurant contracts, creating a 'valley of death' before the third harvest cycle.

## Question 2 - What is the specific target date for the first 'seed-to-harvest' cycle to be completed?

**Assumptions:** Assumption: The project aims for a 'first harvest' within 14 months of the Feb 2026 start date. This includes 6 months for facility retrofitting/construction, 2 months for system cycling/bio-filter maturation, and 6 months for the first growth cycle. This follows industry standards for new RAS startups.

**Assessments:** Title: Timeline & Milestones Assessment. Description: Analysis of the 'ASAP' start date relative to Midwest construction seasons. Details: Starting in February means construction begins during peak winter; if the facility isn't enclosed by November 2026, internal system installation will face 30-50% labor efficiency drops due to cold. Opportunity: Aligning the first harvest with the Spring 2027 'high-end' dining season maximizes initial margins.

## Question 3 - Which of the three founders will be the full-time 'On-Site Manager,' and what is their specific experience with water chemistry or mechanical systems?

**Assumptions:** Assumption: One founder will act as the full-time operator while the others provide part-time support or capital. It is assumed the team lacks formal aquaculture degrees but possesses 'hands-on' mechanical or agricultural experience. This is common in entrepreneurial 'Builder' scenarios.

**Assessments:** Title: Resources & Personnel Assessment. Description: Evaluation of the 'Specialized Talent Gap' risk identified in the risk profile. Details: Without a dedicated 24/7 on-site presence, the likelihood of Risk 1 (Mass Mortality) increases by 40%. Mitigation: Budgeting $15k for a remote aquaculture consultant for the first 6 months of operation can bridge the expertise gap while training local staff.

## Question 4 - Have you identified a specific municipal wastewater plant in Indianapolis, Des Moines, or Columbus that will accept saline discharge?

**Assumptions:** Assumption: The project will utilize a 'Standard RAS' with a 10% daily water exchange rate, requiring the disposal of approximately 1,000–3,000 gallons of saline water per day. It is assumed that local industrial zones will require pre-treatment before discharge. This is based on EPA guidelines for inland aquaculture.

**Assessments:** Title: Governance & Regulations Assessment. Description: Review of the legal feasibility of saline waste management. Details: High-salinity discharge can corrode municipal pipes. If a 'Zero-Exchange' system isn't used, the project may face a $100k unbudgeted expense for an on-site desalination/evaporation unit. Early engagement with the Indiana IDEM or Iowa DNR is critical to avoid a 'Stop Work' order.

## Question 5 - What is the planned redundancy for the life support systems in the event of a multi-day Midwest power outage?

**Assumptions:** Assumption: The facility will be equipped with a dual-fuel (Propane/Diesel) industrial generator capable of maintaining 100% of aeration and 50% of heating loads for 72 hours. This is a standard risk mitigation strategy for high-density indoor farming in storm-prone regions.

**Assessments:** Title: Safety & Risk Management Assessment. Description: Analysis of the 'Operational & Biological' risk of system failure. Details: A 4-hour power failure in sub-zero temperatures without a generator results in 90%+ mortality. The cost of a 100kW generator (~$45k) is less than the cost of a single lost harvest ($50k-$150k), representing a 100% ROI upon the first major grid failure.

## Question 6 - What is the target R-value for the facility insulation, and will you utilize geothermal or waste-heat recovery?

**Assumptions:** Assumption: The facility will use R-30 spray foam insulation and a heat recovery ventilator (HRV) to capture 70% of heat from exhausted air. This assumption addresses the 'High OPEX' risk of Midwest winters. This is an industry benchmark for energy-efficient indoor agriculture.

**Assessments:** Title: Environmental Impact & Energy Assessment. Description: Evaluation of the carbon footprint and energy cost-efficiency. Details: Without R-30+ insulation, winter heating costs in Iowa/Indiana can consume 40% of gross margins. Utilizing waste-heat recovery reduces the 'cost-per-pound' of shrimp by an estimated $1.20, significantly increasing competitiveness against coastal imports.

## Question 7 - Which 5-10 high-end restaurants in the chosen city have been contacted for preliminary 'Letters of Intent' (LOI)?

**Assumptions:** Assumption: The business model relies on securing LOIs for at least 30% of the projected first harvest at a premium price of $18-$22/lb. This assumes a 'Pond-to-Plate' marketing strategy where freshness justifies the 2x price over frozen imports.

**Assessments:** Title: Stakeholder Involvement Assessment. Description: Analysis of market integration and revenue stability. Details: Direct-to-consumer and restaurant contracts provide higher margins but require high 'Logistical Complexity.' Failure to secure LOIs before the first stocking window increases the risk of being forced to sell to low-margin wholesalers at $8-$10/lb, threatening loan repayment.

## Question 8 - What software or IoT platform will be used to integrate water quality sensors with the 'Hub-and-Spoke' logistics?

**Assumptions:** Assumption: The project will deploy a cloud-based monitoring system (e.g., Aquamanager or similar) that provides real-time alerts to all three founders' mobile devices. This assumes a 'Tech-Forward' approach to manage the 'Scaling Complexity' risk.

**Assessments:** Title: Operational Systems Assessment. Description: Evaluation of the technical infrastructure for multi-site management. Details: Using a centralized IoT dashboard allows the founders to monitor 'Spoke' tanks remotely, reducing the need for on-site specialized labor by 25%. This system is the 'digital backbone' required to prevent the 'Single-Point-of-Failure' risk identified in the scaling model.

# Distill Assumptions

- Founders provide $500,000 capital and leverage $1,000,000 in SBA loans or equipment leasing.
- The project targets a first harvest within 14 months of the February 2026 start.
- Facility construction and retrofitting are allocated a six-month timeline within the overall schedule.
- One founder will serve as the full-time on-site operator for daily farm management.
- The team relies on hands-on mechanical experience rather than formal aquaculture degrees.
- Standard Recirculating Aquaculture Systems will require disposing 1,000–3,000 gallons of saline water daily.
- Industrial zoning will necessitate pre-treatment of saline discharge per EPA and state guidelines.
- A dual-fuel industrial generator will provide 72 hours of emergency power for life support.
- Facility insulation will meet R-30 standards using spray foam and heat recovery ventilators.
- The business model requires securing Letters of Intent for 30% of the first harvest.
- Target pricing for premium direct-to-consumer shrimp is set between $18 and $22 per pound.
- A cloud-based IoT platform will integrate water quality sensors for real-time remote monitoring.
- The infrastructure strategy utilizes purpose-built climate-controlled steel facilities for thermal stability.
- Biological sourcing relies on a long-term partnership with a single consistent genetic provider.
- Scaling follows a hub-and-spoke model with centralized processing and satellite grow-out tanks.

# Review Assumptions

## Domain of the expert reviewer
Aquaculture Infrastructure & Strategic Business Planning

## Domain-specific considerations

- Bio-secure recirculating aquaculture system (RAS) engineering
- Midwest thermal dynamics and energy load balancing
- Saline wastewater mitigation in landlocked jurisdictions
- Biological asset risk management (shrimp-specific)
- Direct-to-consumer (DTC) perishable supply chain logistics

## Issue 1 - Missing Assumption: Feed Conversion Ratio (FCR) and Feed Supply Chain
Feed typically represents 50-60% of aquaculture OPEX. The plan assumes a premium price point but lacks an assumption on the FCR (how many lbs of feed to produce 1 lb of shrimp) or the sourcing of high-quality, biosecure feed in the Midwest. Without a local supplier, shipping costs and 'just-in-time' delivery risks could cripple margins.

**Recommendation:** Explicitly assume a target FCR of 1.2 to 1.5. Identify and vet at least two specialized shrimp feed manufacturers (e.g., Zeigler Bros) and factor in a 3-month buffer of feed storage to mitigate supply chain disruptions.

**Sensitivity:** A 20% increase in feed costs or a poor FCR of 1.8 (baseline: 1.3) would increase the cost-per-pound by $1.50-$2.50, potentially reducing the projected ROI by 12-18%.

## Issue 2 - Under-Explored Assumption: Saline Discharge Legal Precedent
The plan assumes municipal plants will accept 1,000–3,000 gallons of saline water daily with 'pre-treatment.' However, many Midwest POTWs (Publicly Owned Treatment Works) have strict chloride limits to protect freshwater ecosystems. 'Pre-treatment' for salt usually requires expensive Reverse Osmosis (RO) or evaporation, not just basic filtration.

**Recommendation:** Conduct a formal feasibility study on 'Zero-Liquid Discharge' (ZLD) systems. Instead of assuming municipal acceptance, budget for an on-site salt recovery or evaporation system to ensure the project isn't halted by a 'Cease and Desist' from the EPA/DNR.

**Sensitivity:** If municipal discharge is denied, an unbudgeted ZLD system (baseline: $0) could cost $150,000-$250,000, increasing initial CAPEX by 10-15% and delaying the first harvest by 4-6 months.

## Issue 3 - Unrealistic Assumption: 14-Month Timeline from Feb Start
Starting construction in the Midwest in February is high-risk. Ground frost and sub-zero temperatures often delay foundation pouring and utility trenching. Furthermore, the plan allows only 2 months for 'system cycling.' Bio-filters in RAS often take 3-4 months to reach the microbial stability required for high-density stocking.

**Recommendation:** Shift the construction start to April or ensure the facility is a 'brownfield' retrofit with existing utilities. Extend the 'system cycling' phase to 90 days in the project schedule to prevent early-stage mass mortality from 'New Tank Syndrome.'

**Sensitivity:** A 3-month construction delay combined with a crashed bio-filter could push the first revenue-generating harvest back by 6-9 months, requiring an additional $100,000-$150,000 in working capital to cover debt service.

## Review conclusion
The 'Builder's Foundation' strategy is technically sound but contains dangerous gaps regarding operational OPEX (feed) and regulatory 'deal-breakers' (saline waste). The most critical risk is the financial 'valley of death' caused by the optimistic 14-month timeline. If the project fails to account for the slow maturation of bio-filters or the high cost of salt management, the $1.5M capital stack will be exhausted before the second harvest. Prioritizing a Zero-Liquid Discharge strategy and securing feed contracts are the most urgent next steps.