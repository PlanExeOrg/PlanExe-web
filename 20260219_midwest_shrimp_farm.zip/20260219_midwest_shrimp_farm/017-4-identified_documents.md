
## Documents to Create

### 1. Project Charter: Midwest Indoor Shrimp Farm

**ID:** 92aa6c6e-04c0-4df0-96c4-9539286a9b4c

**Description:** A foundational document defining the project's purpose, high-level objectives (April 2027 first harvest), $1.5M capital structure, and the 'Builder's Foundation' strategic path. It formally authorizes the project and defines the roles of the three founding partners.

**Responsible Role Type:** Project Manager

**Primary Template:** PMI Project Charter Template

**Steps:**

- Define project vision and SMART goals based on the 'Builder's Foundation' scenario.
- Outline the $500k equity and $1M debt capital stack.
- Identify high-level risks (biological, thermal, regulatory).
- Obtain signatures from the three founding partners.

**Approval Authorities:** Founding Partners (You, Larry, Bubba)

### 2. Facility Infrastructure & Thermal Strategy Framework

**ID:** b9d322ed-b09c-48dc-b1ca-1de87f31cb45

**Description:** A high-level strategy document detailing the requirements for purpose-built climate-controlled steel facilities. It addresses the core tension between CAPEX and Midwest thermal stability, focusing on R-30 insulation and HRV integration.

**Responsible Role Type:** Aquaculture Systems Engineer

**Primary Template:** Industrial Facility Design Strategy

**Steps:**

- Define technical specifications for steel facility construction.
- Outline the thermal envelope requirements (R-30 spray foam).
- Specify the Heat Recovery Ventilation (HRV) and backup power (100kW generator) requirements.
- Align infrastructure design with the Hub-and-Spoke scaling model.

**Approval Authorities:** Founding Partners, Technical Lead

### 3. Water Management & Saline Waste Strategy

**ID:** 7c1a80b1-0e5b-46d5-94d9-eddf47591c2d

**Description:** A strategic framework for the Recirculating Aquaculture System (RAS) and waste management. It evaluates the transition from standard discharge to Zero-Liquid Discharge (ZLD) to meet Midwest chloride limits.

**Responsible Role Type:** Environmental Compliance & Wastewater Specialist

**Primary Template:** Industrial Wastewater Management Plan

**Steps:**

- Define the RAS mechanical and bio-filtration philosophy.
- Outline the ZLD/evaporation strategy to bypass municipal discharge hurdles.
- Establish water quality monitoring parameters (ammonia, DO, temperature).
- Draft initial compliance pathways for IDEM/DNR/Ohio EPA.

**Approval Authorities:** Environmental Compliance Specialist, Municipal Water Authorities

### 4. Biological Sourcing & Biosecurity Framework

**ID:** 4f816738-20e6-4d2e-aefc-bef497ab3b1e

**Description:** A high-level plan for securing SPF post-larvae and protecting the facility from pathogens. It addresses the risk of single-provider dependency and the biosecurity challenges of the hub-and-spoke model.

**Responsible Role Type:** Aquatic Biologist / Husbandry Technician

**Primary Template:** Aquaculture Biosecurity Standard Operating Framework

**Steps:**

- Identify primary and secondary SPF post-larvae providers.
- Define the 30-day quarantine protocol for new shipments.
- Establish 'All-in/All-out' batch protocols for the hub-and-spoke model.
- Outline the feed supply chain biosecurity requirements.

**Approval Authorities:** Technical Lead, State Department of Agriculture

### 5. Market Integration & 'Pond-to-Plate' Strategy

**ID:** 2f3c58f1-a38d-4ea6-a973-3fc7e79a2e86

**Description:** A strategic plan for capturing premium margins ($18-22/lb) through direct-to-consumer and high-end restaurant channels. It defines the brand identity and the 'Killer App' for harvest alerts.

**Responsible Role Type:** Market Relations & Sales Director

**Primary Template:** Go-To-Market Strategy Framework

**Steps:**

- Define the 'Pond-to-Plate' value proposition.
- Identify target high-end restaurants in Indy, Des Moines, and Columbus.
- Outline the subscription-based retail model and 'Killer App' features.
- Draft the Letter of Intent (LOI) template for restaurant partners.

**Approval Authorities:** Founding Partners, Marketing Lead

### 6. Initial High-Level Budget & Funding Framework

**ID:** 27aac2b4-8bac-4cb4-aba2-38347a5783b6

**Description:** A foundational financial model outlining the $1.5M allocation across CAPEX (Facility/RAS/ZLD) and 14 months of OPEX. Includes the 20-40% contingency reserve recommended by experts.

**Responsible Role Type:** Project Finance & Grant Administrator

**Primary Template:** SBA 7(a) Financial Projection Template

**Steps:**

- Consolidate equipment quotes for RAS and ZLD systems.
- Model heating OPEX based on R-30 insulation and Midwest utility data.
- Define the draw-down schedule for the $1M loan.
- Establish the 'Zero Revenue' contingency scenario for months 14-18.

**Approval Authorities:** Founding Partners, SBA Loan Officer

### 7. Stakeholder Engagement & Communication Plan

**ID:** d0aa9eaf-1181-4010-acc9-92a380a18fe1

**Description:** A plan to manage relationships with primary (SBA, Partners) and secondary (Chefs, Water Authorities, Universities) stakeholders. Focuses on securing LOIs and building the talent pipeline.

**Responsible Role Type:** Communication Specialist

**Primary Template:** Standard Stakeholder Engagement Matrix

**Steps:**

- Map stakeholders by influence and interest.
- Define communication frequency for SBA reporting.
- Outline the outreach strategy for Purdue/Iowa State internship programs.
- Establish the 'Harvest Alert' notification system for restaurant partners.

**Approval Authorities:** Project Manager

## Documents to Find

### 1. Municipal Wastewater Chloride & TDS Limit Data

**ID:** cc741284-9bd5-4122-be72-48fd5d5dfd08

**Description:** Official 'Local Limits' and pretreatment regulations for the municipal wastewater departments in Indianapolis, Des Moines, and Columbus. Crucial for determining if ZLD is mandatory.

**Recency Requirement:** Current/Most recent version (2024-2026)

**Responsible Role Type:** Environmental Compliance & Wastewater Specialist

**Access Difficulty:** Medium (Requires direct contact with city engineers and specific regulatory requests)

**Steps:**

- Contact the Pretreatment Coordinator at Indianapolis (IDEM), Des Moines (DNR), and Columbus (Ohio EPA).
- Search municipal code portals for 'Industrial User' discharge limits.

### 2. Midwest Industrial Utility Rate Cards

**ID:** e0bc0db8-c89e-4138-88db-c580be25e794

**Description:** Raw data on industrial electricity and natural gas rates for the specific counties targeted. Needed to model the OPEX for 80°F+ winter heating.

**Recency Requirement:** Current year (2025/2026)

**Responsible Role Type:** Project Finance & Grant Administrator

**Access Difficulty:** Easy (Publicly available on utility websites)

**Steps:**

- Access utility provider websites (e.g., AES Indiana, MidAmerican Energy).
- Request industrial rate schedules from local economic development corporations.

### 3. State-Specific Aquaculture & Biosecurity Laws

**ID:** ab36726a-0e11-48ca-b65e-abf72a09f2da

**Description:** Official legislative text from Indiana, Iowa, and Ohio regarding the transport of live aquatic species and biosecurity requirements for indoor farms.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Legal Counsel

**Access Difficulty:** Easy (Publicly available on government legislative portals)

**Steps:**

- Search state legislative databases for 'Aquaculture Producer' statutes.
- Check State Department of Agriculture websites for biosecurity and transport permit requirements.

### 4. SPF Post-Larvae Provider Price & Availability Data

**ID:** cc301eb8-2e33-4354-aa16-98cde793f7d9

**Description:** Raw pricing, seasonal availability schedules, and health certification standards from major coastal shrimp hatcheries (e.g., Florida/Texas).

**Recency Requirement:** Published within last 12 months

**Responsible Role Type:** Supply Chain & Logistics Coordinator

**Access Difficulty:** Medium (Requires direct business-to-business inquiry and verification of biosecurity status)

**Steps:**

- Contact sales departments of major SPF hatcheries.
- Request 'Certificate of Health' templates and shipping logistics data.

### 5. Midwest Regional Climate & Soil Statistical Data

**ID:** ca157047-9099-4f20-a7dc-fdf657b63a05

**Description:** Historical temperature extremes and frost depth data for Indianapolis, Des Moines, and Columbus. Used to validate the 100kW generator sizing and construction timelines.

**Recency Requirement:** Last 10-20 years of historical data

**Responsible Role Type:** Aquaculture Systems Engineer

**Access Difficulty:** Easy (Open data portals)

**Steps:**

- Access National Oceanic and Atmospheric Administration (NOAA) regional databases.
- Search state climatology office records for 'Polar Vortex' frequency.

### 6. Zoning & Land Use Regulations for Target Counties

**ID:** 5037dd92-4484-418c-a946-b3811b808dcd

**Description:** Official zoning maps and permitted use tables for industrial corridors in the three target cities to identify 'Aquaculture' or 'Light Industrial' compatibility.

**Recency Requirement:** Current regulations essential

**Responsible Role Type:** Project Manager

**Access Difficulty:** Easy (Publicly available on city/county websites)

**Steps:**

- Search municipal GIS portals for Indianapolis, Des Moines, and Columbus.
- Download 'Permitted Use' tables from county planning departments.