### 1. Project Sponsor (You, Larry, Bubba) drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Project Steering Committee ToR v0.1

**Dependencies:**

- Project goal statement finalized
- Initial project budget and timeline established

### 2. Project Sponsor reviews and refines the Draft Project Steering Committee ToR.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Refined Project Steering Committee ToR v0.2

**Dependencies:**

- Draft Project Steering Committee ToR v0.1 available

### 3. Project Sponsor circulates the refined Project Steering Committee ToR to nominated members for feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary from nominated members

**Dependencies:**

- Refined Project Steering Committee ToR v0.2 available
- Nominated members list available

### 4. Project Sponsor finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized Project Steering Committee ToR

**Dependencies:**

- Feedback Summary from nominated members received

### 5. Project Sponsor formally appoints the Project Steering Committee Chair and assigns initial roles (e.g., Secretary, Risk Officer).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for Steering Committee Chair and roles

**Dependencies:**

- Finalized Project Steering Committee ToR

### 6. Project Sponsor schedules and holds the inaugural Project Steering Committee meeting.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule for Steering Committee

**Dependencies:**

- Project Steering Committee Chair appointed
- Finalized Project Steering Committee ToR

### 7. Project Steering Committee reviews and approves the initial Project Management Office (PMO) setup plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved PMO Setup Plan

**Dependencies:**

- Project Steering Committee formally established

### 8. PMO Lead drafts the initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Steering Committee approves PMO setup plan

### 9. PMO Lead circulates the Draft Technical Advisory Group ToR to Steering Committee for review.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary from Steering Committee

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1 available

### 10. PMO Lead finalizes the Technical Advisory Group ToR based on Steering Committee feedback.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Finalized Technical Advisory Group ToR

**Dependencies:**

- Feedback Summary from Steering Committee received

### 11. PMO Lead recruits external experts for the Technical Advisory Group and appoints the internal Technical Lead.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Finalized Technical Advisory Group ToR

### 12. PMO Lead schedules and holds the inaugural Technical Advisory Group meeting.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule for Technical Advisory Group

**Dependencies:**

- Technical Advisory Group members confirmed

### 13. Project Sponsor appoints the Ethics & Compliance Committee Chair and recruits external compliance experts.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Project Steering Committee approves Ethics & Compliance Committee setup

### 14. Ethics & Compliance Committee Chair drafts the initial Compliance Framework and submits it to the Steering Committee for approval.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Compliance Framework

**Dependencies:**

- Ethics & Compliance Committee members confirmed

### 15. Project Steering Committee reviews and approves the Compliance Framework.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Compliance Framework

**Dependencies:**

- Draft Compliance Framework submitted

### 16. Ethics & Compliance Committee schedules and holds its inaugural meeting to discuss the approved Compliance Framework and next steps.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Implementation Plan for Compliance Framework

**Dependencies:**

- Compliance Framework approved