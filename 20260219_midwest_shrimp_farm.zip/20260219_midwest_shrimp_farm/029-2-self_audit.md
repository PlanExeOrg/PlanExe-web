Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan relies on established Recirculating Aquaculture System (RAS) technology and standard climate-controlled steel structures, which do not require breaking physical laws. The plan explicitly targets "proven technologies" and "standard RAS" components, avoiding high-risk physics-defying concepts like perpetual motion or reactionless drives.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination without independent evidence at comparable scale, as shown by the statement that "The plan's assumption of municipal acceptance for saline wastewater discharge is critically flawed" and the claim that "The 'Builder's Foundation' path balances proven RAS technology with manageable innovation."

**Mitigation**: Market Analysis Team: Conduct a benchmark study of comparable indoor shrimp farms, assess independent evidence of success, and deliver a validation report with findings within 30 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on several undefined or vague strategic concepts like "Market Integration Depth" and "Operational Scaling Model" without providing a business-level mechanism-of-action (inputs→process→customer value). Verbatim, the plan admits a "Strategic blind spot" regarding the "Feed Supply Strategy," which is a critical driver of the business model, and the "Market Entry Model" is noted to have "Low importance" despite being a primary commercial interface.

**Mitigation**: Founding Partners: Produce one-pagers for each primary decision lever (Infrastructure, Water, Market, Genetics, Scaling) defining value hypotheses, success metrics, and decision hooks by March 15, 2026.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a formal risk register mapping cascades, such as the identified "saline discharge → cease and desist → loan default" path. The expert review explicitly warns of a "Fatal Regulatory Blind Spot" where saline discharge violations lead to "immediate shutdown by the EPA" and "forfeiture of SBA loan," yet the primary plan minimizes this as a "Medium" importance supporting function.

**Mitigation**: Environmental Compliance Specialist: Create a second-order risk map linking regulatory, biological, and financial hazards with specific tripwires and a monthly review cadence by April 1, 2026.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix and the 14-month timeline is explicitly flagged as unrealistic by experts. The plan assumes a "Feb 2026 start" with a "6 months construction" window, but the expert review warns this "risks frost delays" and that "RAS bio-filters need 3-4 months cycling, not 2," creating a likely failure mode for the April 2027 harvest goal.

**Mitigation**: Project Manager: Rebuild the critical path using April start dates, 90-day bio-filter maturation, and authoritative municipal permit lead times, including a NO-GO threshold for slip by May 2026.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a committed funding source for the $1M debt portion, stating only that founders will "Apply for $1M SBA 7(a) loans" and that "below $300k initial capital, $1.2M+ loan debt service exceeds early cash flow." No signed term sheets or specific covenants are provided for the $1.5M total stack, and the 14-month runway is described as a "financial valley of death" with a "dangerously thin" budget.

**Mitigation**: Project Finance Administrator: Deliver a signed term sheet or LOI from an SBA-preferred lender including a 14-month interest-only period and a defined draw schedule by May 1, 2026.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the $1.5M budget for a 10,000 sq ft facility ($150/sq ft) is "dangerously thin" and lacks scale-appropriate benchmarks for specialized RAS and ZLD systems. The plan omits a firm quote for the ZLD system, which experts estimate adds "$150,000-$250,000 to CAPEX," and the 20% contingency is insufficient for the "financial valley of death" before the first harvest.

**Mitigation**: Project Finance Administrator: Obtain three vendor quotes for RAS and ZLD systems, normalize costs per square foot against Midwest industrial benchmarks, and adjust the contingency to 40% by June 2026.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single-point targets, such as the "first harvest by April 2027" and "$18-22/lb premium pricing," without providing confidence intervals or a sensitivity analysis for the "financial valley of death." The plan lacks a conservative case for the 14-month timeline, which experts warn is "unrealistic" due to construction and bio-filter maturation variables.

**Mitigation**: Project Finance Administrator: Deliver a sensitivity analysis showing base, best, and worst-case scenarios for revenue and cash flow, specifically modeling a 4-month harvest delay, by May 1, 2026.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks technical specifications, interface contracts, and non-functional requirements for the RAS and ZLD systems. The expert review explicitly identifies a "Fatal Regulatory Blind Spot" and "Insufficient RAS Expertise," noting that the ZLD system is "not fully budgeted or confirmed" and the plan lacks a "Bio-filter Maturation buffer," which are build-critical engineering artifacts.

**Mitigation**: Aquaculture Systems Engineer: Produce a technical design package including RAS P&IDs, ZLD interface definitions, a 90-day bio-filter maturation test plan, and a system integration map by June 30, 2026.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical legal and operational claims lack verifiable artifacts, specifically the claim that "Founding partners... have $500k combined liquid capital" and the assumption that "municipalities will allow 1,000-3,000 gal/day saline discharge." No proof of funds, bank statements, or municipal Letters of Interpretation are provided to support these foundational requirements.

**Mitigation**: Project Finance Administrator: Obtain partner proof-of-funds statements and a written Letter of Interpretation from the target municipal pretreatment coordinator regarding chloride limits by March 1, 2026.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because plan states "first harvest within 14 months of the February 2026 start date, specifically targeting April 2027" but does not specify a quantity, weight, or KPI.

**Mitigation**: Market Relations Team: Define SMART acceptance criteria for the first harvest, including a KPI of 5,000 lbs at $18/lb, within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'fully automated subterranean bio-secure domes utilizing geothermal heat exchange and AI-monitored life support' as a strategic choice, which adds extreme complexity and cost without demonstrably supporting the core goals of 'lower upfront CAPEX' and 'steady growth' defined in the Builder's Foundation path.

**Mitigation**: Project Team: Produce a one-page benefit case for the subterranean dome and AI monitoring features, including a specific KPI, owner, and estimated cost, or move them to the backlog by April 2026.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Aquaculture Systems Engineer' is a mission-critical unicorn role requiring a rare blend of industrial fluid dynamics, bio-filtration, and water chemistry expertise to prevent 'mass mortality' and 'bio-filter failure' in a volatile Midwest climate.

**Mitigation**: Founding Partners: Conduct a formal talent market scan and interview at least two qualified RAS engineering consultants to secure a signed engagement letter or advisory agreement by May 1, 2026.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix and the legality of saline discharge is unmapped, with experts warning of a "Fatal Regulatory Blind Spot" where "discharging 15-30 ppt saltwater into a freshwater sewer system is a guaranteed 'Cease and Desist' order."

**Mitigation**: Environmental Compliance Specialist: Deliver a regulatory matrix including chloride limits from target municipalities and a signed Letter of Interpretation from the local water authority by March 1, 2026.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a sustainable business model for the 14-month "financial valley of death" and omits a "Feed Supply Strategy," which is the primary recurring cost. Experts warn that "$1.5M stack exhausts pre-second harvest without bio-filter or salt fixes," and the plan lacks specialized skills, noting a "lack of formal aquaculture or microbiological degrees" to maintain complex RAS systems.

**Mitigation**: Project Finance Administrator: Develop a 24-month operational sustainability plan including a secured feed supply contract, a 40% cash reserve for crop loss, and a technical training curriculum by June 2026.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success hinges on non-waivable saline discharge limits that are currently unvalidated. The plan admits a "Fatal Regulatory Blind Spot," noting that "discharging 15-30 ppt saltwater into a freshwater sewer system is a guaranteed 'Cease and Desist' order" due to strict Midwest chloride limits (<250 mg/L).

**Mitigation**: Environmental Compliance Specialist: Conduct a fatal-flaw screen with municipal pretreatment coordinators to secure a written Letter of Interpretation on chloride limits and define a ZLD NO-GO threshold by March 1, 2026.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a "single genetic provider for SPF post-larvae," creating a single point of failure for biological stock. Furthermore, the expert review identifies a "strategic bottleneck" where a coastal hatchery disruption or a "stop-movement order" would leave the Midwest facility with "empty tanks for an entire quarter" and no tested fallback path.

**Mitigation**: Aquatic Biologist: Secure a secondary backup post-larvae supplier contract in a different geographic region and document a 30-day on-site quarantine protocol for new stock by May 1, 2026.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Finance Department' (SBA Loan Officers) is incentivized by quarterly debt service and "continued funding flow," while the 'R&D Team' (Aquaculture Systems Engineer) is incentivized by "long-term biological resilience" and "specialized breeding programs," creating a conflict over the $150k-$250k unbudgeted CAPEX for Zero-Liquid Discharge (ZLD) systems required for regulatory compliance.

**Mitigation**: Founding Partners: Create a shared OKR to "Achieve 100% regulatory compliance and 95% bio-filter stability within the $1.5M capital stack by June 2026," signed by both Finance and Engineering leads.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a formal change-control process, review cadence, and specific thresholds for re-planning or stopping. While it mentions 'regular progress reporting to SBA lenders,' it provides no internal KPI dashboard, monthly review structure, or defined owners for a change board to manage the 'financial valley of death' and technical pivots.

**Mitigation**: Project Manager: Establish a monthly 'Strategic Review Board' with a KPI dashboard (FCR, Ammonia, Cash Runway) and a change-control log with defined $50k/30-day thresholds by April 2026.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan exhibits a critical cascade where a single dependency—municipal saline discharge approval—triggers multi-domain failure across regulatory, financial, and biological domains. Specifically, the "Saline Standoff" (FM1) describes a scenario where a discharge denial necessitates an unbudgeted $250k ZLD system, leading to SBA loan forfeiture and immediate insolvency. This is coupled with the "Deep Freeze Blackout" (FM2) and "Nitrogen Debt Trap" (FM4), which are strongly coupled risks that can collectively exhaust the thin $1.5M capital stack before the first harvest.

**Mitigation**: Project Manager: Deliver an interdependency map and bow-tie analysis linking saline compliance, thermal stability, and bio-filter maturation with specific NO-GO thresholds and a 40% cash contingency reserve by May 1, 2026.