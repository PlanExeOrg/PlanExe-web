
## Risk 1 - Operational & Biological
Mass mortality event due to Recirculating Aquaculture System (RAS) failure. In an indoor Midwest environment, a failure in the life support system (aeration, bio-filtration, or heating) can lead to total crop loss within hours due to ammonia spikes or thermal shock.

**Impact:** Loss of an entire harvest cycle (approx. 3–4 months of growth). Financial impact of $50,000–$150,000 per batch depending on shrimp density and age. Potential 4-month delay in revenue.

**Likelihood:** Medium

**Severity:** High

**Action:** Install redundant power supplies (industrial generators), IoT-based water quality sensors with 24/7 mobile alerts, and automated emergency oxygen injection systems.

## Risk 2 - Regulatory & Permitting
Saline wastewater discharge compliance. Discharging high-salinity water from shrimp tanks into Midwest municipal sewer systems or local water tables often violates local environmental codes designed for freshwater agriculture.

**Impact:** Fines of $1,000–$5,000 per day of non-compliance. Potential project shutdown or a requirement to install a $50,000–$100,000 on-site water treatment/desalination plant.

**Likelihood:** High

**Severity:** High

**Action:** Engage with municipal water authorities during the site selection phase. Prioritize 'Zero-Exchange' technology or evaporation ponds to minimize liquid discharge.

## Risk 3 - Financial & Capital
High Operational Expenditure (OPEX) due to Midwest energy costs. Maintaining tropical temperatures (80°F+) in a steel facility during Indiana/Iowa winters (sub-zero) creates massive heating bills that can erode margins.

**Impact:** Monthly utility overruns of $5,000–$12,000 beyond projections during winter months. Could lead to a 20-30% increase in the cost-per-pound of shrimp produced.

**Likelihood:** High

**Severity:** Medium

**Action:** Invest in high-R-value spray foam insulation and heat recovery ventilators (HRVs). Explore geothermal heat pumps or co-location near industrial waste-heat sources.

## Risk 4 - Supply Chain
Biosecurity and logistics of Post-Larvae (PL) sourcing. Relying on a single genetic provider for live larvae means any disease outbreak at the provider's hatchery or a transport delay (e.g., grounded flights) halts production.

**Impact:** Empty tanks for 4–8 weeks. Loss of 'consistent supply' reputation with high-end restaurant partners. Estimated revenue loss of $20,000–$40,000 per missed stocking window.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish secondary sourcing agreements with a backup hatchery. Implement a strict 30-day quarantine protocol for all incoming larvae to protect the main facility.

## Risk 5 - Technical & Integration
Scaling complexity of the 'Hub-and-Spoke' model. Moving live shrimp or sensitive water between satellite grow-out tanks and a central processing hub increases the risk of physical damage to the product and cross-contamination.

**Impact:** Product degradation leading to lower market prices (wholesale vs. premium). 10-15% increase in labor costs due to complex logistics. Potential 2-4 week delay in establishing the first 'spoke'.

**Likelihood:** Medium

**Severity:** Low

**Action:** Standardize transport equipment (oxygenated hauling tanks) and develop a rigorous SOP for biosecurity transfers between sites.

## Risk 6 - Social & Labor
Specialized talent gap. The Midwest lacks a deep pool of experienced warm-water aquaculture technicians. Relying on Larry, Bubba, and the founder to manage complex RAS chemistry may lead to burnout or human error.

**Impact:** Operational inefficiencies and increased risk of system failure. Hiring specialized consultants from coastal regions could cost an extra $15,000–$30,000 in relocation and salary premiums.

**Likelihood:** High

**Severity:** Medium

**Action:** Partner with local universities (e.g., Purdue or Iowa State) to create an internship pipeline. Invest in simplified, automated 'tech stacks' to reduce the need for PhD-level water chemistry knowledge.

## Risk summary
The project faces a 'High-Severity' profile primarily driven by Biological and Regulatory risks. The most critical threats are (1) the catastrophic loss of live assets due to Midwest climate-induced system failures and (2) the legal hurdles of saline waste management in a freshwater region. While the 'Builder's Foundation' strategy uses proven RAS technology, the team's success depends on over-engineering thermal insulation and securing ironclad discharge permits before capital is deployed. The trade-off between high upfront CAPEX for climate control and long-term OPEX stability is the project's central financial tension.