
## Audit - Corruption Risks

- Kickbacks from steel facility contractors or RAS equipment suppliers in exchange for awarding construction contracts for the 10,000 sq ft facility.
- Nepotism in the hiring of the 'On-Site Manager' or facility staff, bypassing the required mechanical or aquaculture expertise needed for system stability.
- Conflicts of interest where a founding partner (Larry or Bubba) holds undisclosed stakes in the selected shrimp genetic provider or feed manufacturer.
- Bribery of municipal water authorities or inspectors to overlook saline wastewater discharge violations or to fast-track zoning variances.
- Misuse of confidential 'Pond-to-Plate' market data or restaurant LOI details to benefit a competitor or personal side-venture.
- Trading favors with local officials in Indianapolis, Des Moines, or Columbus to secure agricultural grants or public-private partnership benefits.

## Audit - Misallocation Risks

- Diversion of SBA 7(a) loan funds intended for R-30 insulation and HRVs toward non-essential facility aesthetics or personal partner expenses.
- Double-spending or inflated invoicing for 'hub-and-spoke' logistics equipment, such as oxygenated transport tanks.
- Inefficient allocation of the $500k partner capital, leading to a 'financial valley of death' before the first harvest in April 2027.
- Unauthorized use of the 100kW backup generator or facility utilities for non-project related activities, increasing OPEX.
- Misreporting of shrimp growth rates or bio-filter maturation progress to SBA lenders to trigger subsequent funding tranches prematurely.
- Poor record-keeping of feed conversion ratios (FCR), leading to untracked waste of the 3-month feed buffer.

## Audit - Procedures

- Quarterly financial audits of SBA loan disbursements against verified construction milestones and equipment receipts.
- Monthly biological asset audits (shrimp count and biomass verification) to reconcile actual stock against reported growth and mortality data.
- Bi-annual compliance reviews of saline discharge logs and ZLD system performance to ensure adherence to IDEM/DNR/EPA standards.
- Ad-hoc technical audits of IoT sensor data and 24/7 alert logs to verify operational redundancy and 'On-Site Manager' responsiveness.
- Post-harvest reconciliation of 'Pond-to-Plate' sales against Letters of Intent (LOI) and bank deposits to ensure revenue integrity.

## Audit - Transparency Measures

- Implementation of a real-time digital dashboard (e.g., Aquamanager) accessible to all partners and lenders showing water quality and system health.
- Publication of monthly 'Project Health Reports' for stakeholders, detailing budget utilization, construction progress, and biosecurity status.
- Formalized and documented vendor selection criteria for major CAPEX items like the steel facility and RAS components.
- Maintenance of a transparent 'Conflict of Interest' register for the three founding partners and key facility management.
- Establishment of a secure internal reporting mechanism (whistleblower line) for staff to report biosecurity breaches or financial irregularities.
- Publicly accessible log of all municipal permits, zoning variances, and environmental compliance certifications obtained for the site.