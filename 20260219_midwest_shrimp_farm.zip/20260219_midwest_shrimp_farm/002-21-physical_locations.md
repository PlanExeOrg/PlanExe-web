This plan implies one or more physical locations.

## Requirements for physical locations

- Located within the US Midwest region
- Zoning allowance for aquaculture or light industrial use
- Access to high-capacity water and electrical utilities
- Proximity to high-end regional restaurant hubs
- Climate-controlled or insulated structure suitability
- Compliance with saline wastewater discharge regulations

## Location 1
USA

Indianapolis, Indiana

Industrial Corridor / Near I-465

**Rationale**: Indiana has a supportive regulatory environment for aquaculture. Indianapolis provides a central Midwest hub with excellent logistics for 'Pond-to-Plate' distribution and proximity to a large concentration of high-end restaurants.

## Location 2
USA

Des Moines, Iowa

Agricultural-Industrial Zones

**Rationale**: Iowa offers strong agricultural infrastructure and potential for public-private partnerships. Des Moines is a growing culinary market and provides access to a workforce familiar with large-scale biological asset management.

## Location 3
USA

Columbus, Ohio

Rickenbacker International Airport Area

**Rationale**: Columbus is one of the fastest-growing cities in the Midwest. The area near the logistics hub offers the specialized industrial space needed for purpose-built steel facilities and easy access to major regional markets like Cleveland and Cincinnati.

## Location Summary
The plan explicitly targets the US Midwest for an indoor shrimp farm. The suggested locations in Indiana, Iowa, and Ohio were selected based on their robust agricultural heritage, favorable utility access for Recirculating Aquaculture Systems (RAS), and strategic proximity to the high-end restaurant contracts defined in the 'Builder's Foundation' strategic path.