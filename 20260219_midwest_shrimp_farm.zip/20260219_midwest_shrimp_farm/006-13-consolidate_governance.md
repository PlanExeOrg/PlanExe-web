# Governance Audit


## Audit - Corruption Risks

- Kickbacks from steel facility contractors or RAS equipment suppliers in exchange for awarding construction contracts for the 10,000 sq ft facility.
- Nepotism in the hiring of the 'On-Site Manager' or facility staff, bypassing the required mechanical or aquaculture expertise needed for system stability.
- Conflicts of interest where a founding partner (Larry or Bubba) holds undisclosed stakes in the selected shrimp genetic provider or feed manufacturer.
- Bribery of municipal water authorities or inspectors to overlook saline wastewater discharge violations or to fast-track zoning variances.
- Misuse of confidential 'Pond-to-Plate' market data or restaurant LOI details to benefit a competitor or personal side-venture.
- Trading favors with local officials in Indianapolis, Des Moines, or Columbus to secure agricultural grants or public-private partnership benefits.

## Audit - Misallocation Risks

- Diversion of SBA 7(a) loan funds intended for R-30 insulation and HRVs toward non-essential facility aesthetics or personal partner expenses.
- Double-spending or inflated invoicing for 'hub-and-spoke' logistics equipment, such as oxygenated transport tanks.
- Inefficient allocation of the $500k partner capital, leading to a 'financial valley of death' before the first harvest in April 2027.
- Unauthorized use of the 100kW backup generator or facility utilities for non-project related activities, increasing OPEX.
- Misreporting of shrimp growth rates or bio-filter maturation progress to SBA lenders to trigger subsequent funding tranches prematurely.
- Poor record-keeping of feed conversion ratios (FCR), leading to untracked waste of the 3-month feed buffer.

## Audit - Procedures

- Quarterly financial audits of SBA loan disbursements against verified construction milestones and equipment receipts.
- Monthly biological asset audits (shrimp count and biomass verification) to reconcile actual stock against reported growth and mortality data.
- Bi-annual compliance reviews of saline discharge logs and ZLD system performance to ensure adherence to IDEM/DNR/EPA standards.
- Ad-hoc technical audits of IoT sensor data and 24/7 alert logs to verify operational redundancy and 'On-Site Manager' responsiveness.
- Post-harvest reconciliation of 'Pond-to-Plate' sales against Letters of Intent (LOI) and bank deposits to ensure revenue integrity.

## Audit - Transparency Measures

- Implementation of a real-time digital dashboard (e.g., Aquamanager) accessible to all partners and lenders showing water quality and system health.
- Publication of monthly 'Project Health Reports' for stakeholders, detailing budget utilization, construction progress, and biosecurity status.
- Formalized and documented vendor selection criteria for major CAPEX items like the steel facility and RAS components.
- Maintenance of a transparent 'Conflict of Interest' register for the three founding partners and key facility management.
- Establishment of a secure internal reporting mechanism (whistleblower line) for staff to report biosecurity breaches or financial irregularities.
- Publicly accessible log of all municipal permits, zoning variances, and environmental compliance certifications obtained for the site.

# Internal Governance Bodies

### 1. Project Steering Committee

**Rationale for Inclusion:** The project involves high capital investment, complex infrastructure decisions, and significant regulatory risks. A strategic oversight body is essential to align the project with its long-term goals and manage high-stakes decisions.

**Responsibilities:**

- Provide strategic direction and approve the overall project vision.
- Approve major financial decisions and budget allocations above $100,000.
- Oversee risk management, including regulatory, financial, and operational risks.
- Review and approve key project milestones and deliverables.
- Facilitate resolution of escalated issues from operational bodies.

**Initial Setup Actions:**

- Finalize the Terms of Reference (ToR) for the committee.
- Elect a chairperson and assign roles (e.g., secretary, risk officer).
- Set a regular meeting schedule and define quorum requirements.

**Membership:**

- You (Project Lead)
- Larry (Financial Lead)
- Bubba (Technical Lead)
- Independent aquaculture expert (external member)
- Legal counsel (external member)

**Decision Rights:** Authority to approve or reject decisions exceeding $100,000 in value and strategic choices affecting long-term project viability.

**Decision Mechanism:** Decisions are made by majority vote; the chairperson holds a tie-breaking vote if necessary.

**Meeting Cadence:** Monthly, with ad-hoc meetings as required for urgent issues.

**Typical Agenda Items:**

- Review of financial performance and budget adherence.
- Assessment of construction progress and RAS system development.
- Evaluation of risk management strategies and mitigation plans.
- Discussion of strategic partnerships (e.g., genetic providers, restaurants).
- Review of compliance and regulatory updates.

**Escalation Path:** Issues unresolved by the committee are escalated to an external advisory panel or legal counsel for mediation.
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Given the project’s complexity and need for coordinated execution, a dedicated operational management body is necessary to oversee day-to-day activities, manage timelines, and ensure alignment with strategic goals.

**Responsibilities:**

- Develop and maintain the project plan and timeline.
- Coordinate between different operational teams (e.g., construction, RAS installation, logistics).
- Monitor progress against milestones and KPIs.
- Manage risk registers and ensure mitigation actions are implemented.
- Facilitate communication between the Steering Committee and core project team.

**Initial Setup Actions:**

- Appoint a PMO Lead and support staff.
- Establish project management tools and dashboards (e.g., Gantt charts, risk registers).
- Set up reporting mechanisms for tracking progress and issues.

**Membership:**

- PMO Lead (internal)
- Construction Manager (internal)
- RAS Systems Engineer (internal)
- Logistics Coordinator (internal)
- Financial Analyst (internal)

**Decision Rights:** Authority to make operational decisions below $25,000 and manage day-to-day activities within the approved budget and timeline.

**Decision Mechanism:** Decisions are made by consensus; the PMO Lead has final say in case of disagreement.

**Meeting Cadence:** Weekly, with daily stand-ups for urgent issues.

**Typical Agenda Items:**

- Progress updates on construction and RAS installation.
- Review of budget vs. actuals and financial forecasts.
- Risk identification and mitigation planning.
- Resource allocation and task prioritization.
- Stakeholder communication and engagement.

**Escalation Path:** Issues requiring strategic input or exceeding the PMO’s decision threshold are escalated to the Project Steering Committee.
### 3. Technical Advisory Group

**Rationale for Inclusion:** The project relies on advanced RAS technology and specialized knowledge in aquaculture. A dedicated advisory body ensures technical decisions are well-informed and aligned with best practices.

**Responsibilities:**

- Provide technical expertise on RAS design, installation, and operation.
- Review and validate technical specifications and system performance metrics.
- Advise on risk mitigation strategies related to biological and technical risks.
- Assess new technologies and innovations relevant to the project.

**Initial Setup Actions:**

- Recruit external aquaculture and RAS experts.
- Define the scope of technical guidance and review processes.
- Establish a feedback loop with the PMO and Steering Committee.

**Membership:**

- Independent RAS technology expert (external)
- Aquaculture biologist (external)
- Technical Lead from the core project team (internal)
- Supplier representatives (invited as needed)

**Decision Rights:** Authority to provide recommendations on technical matters; final decisions remain with the Steering Committee.

**Decision Mechanism:** Decisions are made by consensus; dissenting opinions are documented and reported to the Steering Committee.

**Meeting Cadence:** Bi-weekly, with ad-hoc meetings for urgent technical issues.

**Typical Agenda Items:**

- Review of RAS system performance and technical challenges.
- Evaluation of new technologies or suppliers.
- Discussion of biological risks and mitigation strategies.
- Feedback on project progress and technical milestones.

**Escalation Path:** Technical disputes or unresolved issues are escalated to the Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** The project involves significant regulatory and environmental compliance risks. A dedicated body ensures ethical conduct, transparency, and adherence to legal standards.

**Responsibilities:**

- Oversee compliance with environmental, labor, and financial regulations.
- Monitor ethical conduct and manage conflicts of interest.
- Review and approve compliance policies and procedures.
- Investigate and resolve compliance-related issues or incidents.

**Initial Setup Actions:**

- Appoint an independent chair and members with compliance expertise.
- Develop a compliance framework and reporting mechanisms.
- Establish a whistleblower hotline and protection policies.

**Membership:**

- Independent compliance expert (external)
- Legal counsel (external)
- Ethics officer (internal)
- Representative from the PMO (internal)

**Decision Rights:** Authority to enforce compliance policies and recommend corrective actions; final decisions on major issues are escalated to the Steering Committee.

**Decision Mechanism:** Decisions are made by majority vote; the chair holds a tie-breaking vote.

**Meeting Cadence:** Monthly, with ad-hoc meetings for urgent compliance issues.

**Typical Agenda Items:**

- Review of compliance audits and reports.
- Assessment of regulatory changes and impacts.
- Discussion of ethical concerns or conflicts of interest.
- Review of incident reports and investigations.

**Escalation Path:** Major compliance issues or disputes are escalated to external legal counsel or the Project Steering Committee.

# Governance Implementation Plan

### 1. Project Sponsor (You, Larry, Bubba) drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Project Steering Committee ToR v0.1

**Dependencies:**

- Project goal statement finalized
- Initial project budget and timeline established

### 2. Project Sponsor reviews and refines the Draft Project Steering Committee ToR.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Refined Project Steering Committee ToR v0.2

**Dependencies:**

- Draft Project Steering Committee ToR v0.1 available

### 3. Project Sponsor circulates the refined Project Steering Committee ToR to nominated members for feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary from nominated members

**Dependencies:**

- Refined Project Steering Committee ToR v0.2 available
- Nominated members list available

### 4. Project Sponsor finalizes the Project Steering Committee ToR based on feedback.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Finalized Project Steering Committee ToR

**Dependencies:**

- Feedback Summary from nominated members received

### 5. Project Sponsor formally appoints the Project Steering Committee Chair and assigns initial roles (e.g., Secretary, Risk Officer).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for Steering Committee Chair and roles

**Dependencies:**

- Finalized Project Steering Committee ToR

### 6. Project Sponsor schedules and holds the inaugural Project Steering Committee meeting.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule for Steering Committee

**Dependencies:**

- Project Steering Committee Chair appointed
- Finalized Project Steering Committee ToR

### 7. Project Steering Committee reviews and approves the initial Project Management Office (PMO) setup plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved PMO Setup Plan

**Dependencies:**

- Project Steering Committee formally established

### 8. PMO Lead drafts the initial Terms of Reference (ToR) for the Technical Advisory Group.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Steering Committee approves PMO setup plan

### 9. PMO Lead circulates the Draft Technical Advisory Group ToR to Steering Committee for review.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Feedback Summary from Steering Committee

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1 available

### 10. PMO Lead finalizes the Technical Advisory Group ToR based on Steering Committee feedback.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Finalized Technical Advisory Group ToR

**Dependencies:**

- Feedback Summary from Steering Committee received

### 11. PMO Lead recruits external experts for the Technical Advisory Group and appoints the internal Technical Lead.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Confirmed Technical Advisory Group Membership List

**Dependencies:**

- Finalized Technical Advisory Group ToR

### 12. PMO Lead schedules and holds the inaugural Technical Advisory Group meeting.

**Responsible Body/Role:** PMO Lead

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Meeting Schedule for Technical Advisory Group

**Dependencies:**

- Technical Advisory Group members confirmed

### 13. Project Sponsor appoints the Ethics & Compliance Committee Chair and recruits external compliance experts.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Confirmed Ethics & Compliance Committee Membership List

**Dependencies:**

- Project Steering Committee approves Ethics & Compliance Committee setup

### 14. Ethics & Compliance Committee Chair drafts the initial Compliance Framework and submits it to the Steering Committee for approval.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Draft Compliance Framework

**Dependencies:**

- Ethics & Compliance Committee members confirmed

### 15. Project Steering Committee reviews and approves the Compliance Framework.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Approved Compliance Framework

**Dependencies:**

- Draft Compliance Framework submitted

### 16. Ethics & Compliance Committee schedules and holds its inaugural meeting to discuss the approved Compliance Framework and next steps.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Implementation Plan for Compliance Framework

**Dependencies:**

- Compliance Framework approved

# Decision Escalation Matrix

**Capital Expenditure Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: The PMO only has authority for operational decisions below $25,000. Any major equipment procurement (e.g., RAS components or backup generators) exceeding $100,000 requires strategic oversight due to the impact on the $1.5M total budget.
Negative Consequences: Budget exhaustion before the first harvest, leading to project insolvency and inability to service SBA loans.

**Municipal Denial of Saline Wastewater Discharge Permit**
Escalation Level: Project Steering Committee
Approval Process: Strategic Review and Budget Re-allocation
Rationale: If local authorities deny discharge permits, the project must pivot to a Zero-Liquid Discharge (ZLD) system. This is a strategic shift that involves unbudgeted CAPEX of $150k-$250k and significantly alters the facility infrastructure.
Negative Consequences: Immediate 'Stop Work' order from the EPA/DNR, resulting in indefinite construction delays and potential loss of the chosen site.

**Critical Technical Dispute on RAS Design Specifications**
Escalation Level: Project Steering Committee
Approval Process: Technical Advisory Group Recommendation followed by Steering Committee Vote
Rationale: If the PMO and Technical Lead cannot agree on critical life-support redundancies (e.g., bio-filter capacity or oxygenation levels), the Technical Advisory Group must provide an expert recommendation to the Steering Committee for a final decision.
Negative Consequences: Systemic biological failure leading to mass shrimp mortality (100% crop loss) and reputational damage with restaurant stakeholders.

**Reported Violation of Environmental Compliance Standards**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Any report of illegal saline dumping or violation of USDA food safety standards requires an independent investigation to ensure transparency and legal protection for the founding partners.
Negative Consequences: Heavy regulatory fines ($5,000/day), permanent revocation of aquaculture licenses, and potential criminal liability for the partners.

**Major Strategic Pivot in Market Integration Model**
Escalation Level: Project Steering Committee
Approval Process: Sponsor Consensus and Steering Committee Approval
Rationale: A decision to move from 'Direct-to-Consumer' to a 'Full-stack Pond-to-Plate' model (including on-site processing) introduces significant USDA/FDA hurdles and logistical complexity that exceed the original project scope.
Negative Consequences: Operational overextension, dilution of management focus, and failure to meet existing Letters of Intent (LOI) from restaurant partners.

# Monitoring Progress

### 1. Biological Asset & Life Support System Monitoring
**Monitoring Tools/Platforms:**

  - IoT Water Quality Dashboard (Aquamanager)
  - Real-time Mobile Alert System
  - Daily Manual Water Chemistry Log

**Frequency:** Continuous (Automated) / Daily (Manual)

**Responsible Role:** RAS Systems Engineer

**Adaptation Process:** The RAS Systems Engineer initiates immediate emergency protocols for life support. If a systemic issue is identified, the PMO proposes technical adjustments to the Technical Advisory Group for validation.

**Adaptation Trigger:** Ammonia/Nitrite spikes > 0.25ppm, Dissolved Oxygen < 5mg/L, or power outage exceeding 15 minutes.

### 2. Regulatory & Wastewater Compliance Tracking
**Monitoring Tools/Platforms:**

  - Compliance Checklist
  - Municipal Discharge Metering Logs
  - State DNR Correspondence Folder

**Frequency:** Weekly

**Responsible Role:** Ethics & Compliance Committee

**Adaptation Process:** The Committee recommends corrective actions or facility modifications (e.g., shifting to ZLD) to the Steering Committee for budget approval and strategic pivot.

**Adaptation Trigger:** Chloride levels exceeding municipal limits or receipt of a 'Notice of Violation' from IDEM/DNR/EPA.

### 3. Thermal Stability & Energy OPEX Monitoring
**Monitoring Tools/Platforms:**

  - Utility Billing Tracker
  - Facility Temperature Sensors
  - Energy Efficiency Spreadsheet

**Frequency:** Monthly

**Responsible Role:** Financial Analyst

**Adaptation Process:** The Financial Analyst and Construction Manager review insulation performance and HRV efficiency. If costs are unsustainable, the PMO proposes additional retrofitting or geothermal integration to the Steering Committee.

**Adaptation Trigger:** Heating OPEX exceeds $12,000/month or internal facility temperature drops below 75°F during winter peaks.

### 4. Sponsorship & Market Commitment Monitoring (LOI Tracking)
**Monitoring Tools/Platforms:**

  - Sales Pipeline CRM
  - Restaurant LOI Tracker
  - Market Integration Spreadsheet

**Frequency:** Bi-weekly

**Responsible Role:** Logistics Coordinator

**Adaptation Process:** The Logistics Coordinator adjusts the outreach strategy or pricing model. If targets are missed, the Steering Committee may pivot the market entry model toward wholesale distributors.

**Adaptation Trigger:** Projected sales volume from signed LOIs falls below 30% of the first harvest target by Project Month 10.

### 5. Supply Chain & Biosecurity Risk Review
**Monitoring Tools/Platforms:**

  - Risk Register Document
  - Supplier Performance Scorecard
  - Quarantine Protocol Logs

**Frequency:** Monthly

**Responsible Role:** PMO Lead

**Adaptation Process:** The PMO Lead activates backup supplier agreements or extends quarantine periods. The Technical Advisory Group is consulted if genetic performance (growth rates) deviates from the partnership agreement.

**Adaptation Trigger:** Post-larvae mortality > 20% during quarantine or Feed Conversion Ratio (FCR) exceeds 1.6.

### 6. Capital Runway & Debt Service Monitoring
**Monitoring Tools/Platforms:**

  - Budget vs. Actuals Dashboard
  - SBA Loan Compliance Report
  - Cash Flow Forecast

**Frequency:** Monthly

**Responsible Role:** Larry (Financial Lead)

**Adaptation Process:** The Financial Lead identifies funding gaps and proposes cost-cutting measures or requests additional capital drawdowns to the Steering Committee.

**Adaptation Trigger:** Projected cash reserves fall below 3 months of OPEX or construction cost overruns exceed 15% of the $1.5M budget.

# Governance Extra

## Governance Validation Checks

1. Completeness Confirmation: All core components (Internal Bodies, Implementation Plan, Escalation Matrix, Monitoring Plan, and Audit Procedures) have been generated and reviewed.
2. Internal Consistency Check: The framework is logically aligned. The Escalation Matrix correctly maps to the $25k/$100k thresholds defined in the Internal Bodies, and the Implementation Plan follows a logical sequence from Sponsor setup to Committee activation.
3. Gap 1 - Process Depth (Conflict of Interest): While a 'Conflict of Interest register' is mentioned in transparency measures, there is no defined process for how a founding partner (Larry or Bubba) would be recused from decisions if a conflict is identified, particularly regarding vendor selection for RAS equipment or feed.
4. Gap 2 - Delegation Granularity: The framework lacks specific 'Emergency Decision Rights' for the On-Site Manager. In a biological crisis (e.g., mass mortality event at 2:00 AM), the current matrix requires PMO or Steering Committee involvement, which may be too slow to save the crop.
5. Gap 3 - Integration of Audit and Monitoring: The 'Audit Procedures' (Stage 1) and 'Monitoring Progress' (Stage 5) operate in parallel but lack a formal feedback loop. For example, if a biological audit finds biomass discrepancies, there is no explicit trigger to update the Risk Register or the IoT monitoring thresholds.
6. Gap 4 - Specificity of 'Senior Management' in Escalation: The escalation path for the Steering Committee refers to an 'external advisory panel' or 'legal counsel.' The criteria for selecting this panel and their binding authority over the three founders (who are also the owners) remain undefined.

## Tough Questions

1. What is the current probability-weighted forecast for the first harvest date, and how many weeks of 'financial runway' remain if the bio-filter maturation takes 120 days instead of 60?
2. Can we produce a verified chloride-level report from our current discharge logs that proves we are at least 20% below the municipal limit for Indianapolis/Des Moines/Columbus?
3. What is the specific 'Plan B' if our single genetic provider suffers a biosecurity breach, and have we executed a trial order with our backup hatchery to verify their logistics?
4. Show evidence of the last 48 hours of IoT sensor data: were there any 'silent' alerts where thresholds were breached but no manual intervention was logged by the On-Site Manager?
5. Given the current Midwest utility rates, what is the exact cost-per-pound impact if our HRV (Heat Recovery Ventilation) system operates at 50% efficiency instead of the assumed 70%?
6. How much of the $1M SBA loan has been drawn down against non-fixed assets, and what is the specific trigger point for a 'capital call' from the three partners?
7. In the event of a 72-hour power outage, do we have a signed service contract for emergency fuel delivery for the 100kW generator, or are we relying on local retail availability during a storm?

## Summary

The governance framework for the Midwest Indoor Shrimp Farm is robust, characterized by a clear separation between strategic oversight (Steering Committee) and technical execution (PMO/Technical Advisory Group). Its primary strength lies in the integration of biological risk monitoring with financial accountability, specifically addressing the 'financial valley of death' risk inherent in RAS aquaculture. To reach full maturity, the framework requires more granular 'emergency' delegation for on-site staff and a formalized recusal process for the founding partners to ensure that high-value CAPEX decisions remain objective and transparent to lenders.