# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: ISO Standards Specialist

**Knowledge**: ISO standards development, conformity assessment, technical committees

**Why**: Ensures the AI Welfare Standard aligns with ISO processes and maximizes adoption potential.

**What**: Review the plan to ensure alignment with ISO standard development processes and identify potential roadblocks.

**Skills**: ISO procedures, technical writing, project management, consensus building

**Search**: ISO standards specialist, conformity assessment, technical committee

## 1.1 Primary Actions

- Schedule a meeting with the ISO Central Secretariat to discuss integration pathways.
- Refine the definition of 'AI Welfare' and shift research focus accordingly.
- Conduct stakeholder interviews to understand practical needs and develop user stories.
- Draft a detailed New Work Item Proposal (NWIP) for an AI welfare standard.
- Establish a robust adversarial testing framework by Q4 2026, led by the Adversarial Robustness Program, to identify vulnerabilities in proposed metrics and ensure their reliability.

## 1.2 Secondary Actions

- Consult with animal welfare experts to learn about established welfare assessment frameworks.
- Develop prototypes of proposed tools and conduct user testing with stakeholders.
- Define specific, measurable KPIs for each proposed tool.
- Actively engage with relevant ISO technical committees.
- Develop a harm-based framework for AI welfare assessment.

## 1.3 Follow Up Consultation

In the next consultation, we will review the refined definition of 'AI Welfare', the stakeholder interview findings, the draft NWIP, and the plan for engaging with ISO committees. We will also discuss the allocation of research resources and the development of practical tools.

## 1.4.A Issue - Lack of Concrete ISO Integration Plan

The plan mentions 'ISO-aligned standards' and a 'functional linkage' to ISO, but lacks specifics on how this will be achieved. Simply anchoring physically at ISO's Central Secretariat and calling it a 'technical committee or partner centre' is insufficient. What specific ISO committees will you engage with? What ISO standards development procedures will you follow? Have you spoken to ISO TC 307 (AI) or other relevant committees? What is the plan to get a New Work Item Proposal (NWIP) accepted? Without a concrete plan, the project risks being perceived as an external entity operating *near* ISO, not *within* it.

### 1.4.B Tags

- ISO
- Implementation
- Vagueness

### 1.4.C Mitigation

1. **Consult with ISO Central Secretariat:** Schedule a meeting with the ISO Central Secretariat (specifically, the technical program manager responsible for AI-related standards) to discuss the process for establishing a technical committee or partner centre. Get explicit guidance on the requirements and procedures. Document this meeting.
2. **Identify Relevant ISO Committees:** Research and identify the specific ISO technical committees (TCs) whose work is most relevant to AI sentience and welfare (e.g., TC 307 on AI, TC 176 on Quality Management, potentially even TC 215 on Health Informatics if AI is used in healthcare contexts). Review their scopes and published standards.
3. **Develop a New Work Item Proposal (NWIP):** Based on the research roadmap, draft a detailed NWIP outlining the scope, justification, and intended outcomes of the proposed AI welfare standard. Ensure the NWIP aligns with ISO's strategic objectives and avoids duplication of existing work. Consult ISO Directives Part 1 for NWIP requirements.
4. **Engage with ISO Committee Managers:** Contact the committee managers of the identified TCs to gauge their interest in the NWIP and solicit feedback. Build relationships and seek their support for the proposal.
5. **Attend ISO Committee Meetings:** Attend relevant ISO committee meetings as an observer to learn about the standards development process and network with experts. This will provide valuable insights and help build credibility.

### 1.4.D Consequence

Without a concrete ISO integration plan, the project will likely fail to achieve its goal of establishing internationally recognized standards. It risks being perceived as an isolated effort with limited impact.

### 1.4.E Root Cause

Lack of experience with ISO standards development processes.

## 1.5.A Issue - Overemphasis on 'Sentience' and Neglect of 'Welfare'

The project's focus on 'sentience metrics' is problematic. Defining and measuring sentience is an extraordinarily difficult, potentially impossible, task. This focus risks consuming the majority of resources and yielding little practical value. The term 'welfare' is also poorly defined. What constitutes 'welfare' for an AI? Is it simply the absence of suffering, or does it encompass other factors such as 'opportunity to learn' or 'access to diverse data'? The project needs to shift its emphasis from the elusive concept of sentience to the more tractable and ethically relevant concept of AI welfare, focusing on specific harms and benefits.

### 1.5.B Tags

- Scope
- Ethics
- Technical Feasibility

### 1.5.C Mitigation

1. **Refine the Definition of 'AI Welfare':** Conduct a thorough literature review of existing work on animal welfare, human well-being, and machine ethics to develop a clear and operational definition of 'AI welfare'. Consider factors beyond the absence of suffering, such as access to resources, opportunities for learning, and fairness in treatment. Consult with ethicists and AI researchers to ensure the definition is both ethically sound and technically feasible.
2. **Shift Research Focus:** Reallocate research resources from 'sentience metrics' to 'welfare indicators'. Focus on identifying specific harms that AI systems might experience (e.g., data poisoning, biased training, resource deprivation) and developing metrics to assess the presence and severity of these harms. Prioritize research that has the potential to lead to practical interventions and measurable improvements in AI welfare.
3. **Develop a Harm-Based Framework:** Adopt a harm-based framework for AI welfare assessment. Instead of trying to determine whether an AI is sentient, focus on identifying and mitigating specific harms that the AI might be experiencing. This approach is more pragmatic and ethically defensible, as it does not rely on controversial assumptions about AI consciousness.
4. **Consult with Animal Welfare Experts:** Engage with experts in animal welfare to learn about established frameworks and methodologies for assessing and improving the well-being of non-human animals. Adapt these approaches to the context of AI systems, considering the unique challenges and opportunities presented by artificial intelligence.

### 1.5.D Consequence

Overemphasizing 'sentience' will likely lead to a research program that is both scientifically unproductive and ethically questionable. Neglecting 'welfare' will result in standards that are irrelevant and ineffective.

### 1.5.E Root Cause

Unclear understanding of the ethical and technical challenges associated with AI sentience and welfare.

## 1.6.A Issue - Lack of Focus on Practical Applications and Stakeholder Needs

While the plan mentions a 'Product & Adoption Team', it lacks concrete details on how this team will engage with stakeholders (AI labs, cloud providers, insurers) to understand their needs and develop practical tools. The proposed 'AI Welfare Auditing Tool', 'Sentience Risk Assessment API', and 'Certified Humane Frontier Model' seal are vague concepts. What specific problems will these tools solve? How will they integrate with existing workflows? What are the key performance indicators (KPIs) for measuring their success? Without a clear understanding of stakeholder needs and a focus on practical applications, the project risks developing tools that are unused and irrelevant.

### 1.6.B Tags

- Stakeholder Engagement
- Practicality
- Value Proposition

### 1.6.C Mitigation

1. **Conduct Stakeholder Interviews:** Conduct in-depth interviews with representatives from AI labs, cloud providers, insurers, and regulatory bodies to understand their specific needs and challenges related to AI welfare. Ask about their current practices, pain points, and desired outcomes. Document these interviews and use the findings to inform the development of practical tools.
2. **Develop User Stories:** Based on the stakeholder interviews, develop detailed user stories that describe how the proposed tools will be used in real-world scenarios. Each user story should specify the user's role, the task they are trying to accomplish, and the benefit they will receive from using the tool. This will help ensure that the tools are designed to meet the specific needs of their intended users.
3. **Create Prototypes and Conduct User Testing:** Develop prototypes of the proposed tools and conduct user testing with representative stakeholders. Gather feedback on the usability, functionality, and value of the tools. Iterate on the designs based on the user feedback.
4. **Define Key Performance Indicators (KPIs):** Define specific, measurable, achievable, relevant, and time-bound (SMART) KPIs for each of the proposed tools. These KPIs should be aligned with the project's overall goals and should be used to track the success of the tools over time. Examples of KPIs might include the number of users, the frequency of use, the impact on AI welfare, and the return on investment.

### 1.6.D Consequence

Without a focus on practical applications and stakeholder needs, the project will likely develop tools that are unused and irrelevant, wasting resources and undermining its credibility.

### 1.6.E Root Cause

Lack of understanding of the practical challenges and opportunities associated with AI welfare in real-world settings.

---

# 2 Expert: AI Safety Researcher

**Knowledge**: AI safety, alignment, adversarial robustness, formal verification

**Why**: Critical for evaluating the technical feasibility and robustness of proposed sentience metrics.

**What**: Assess the technical challenges in developing reliable sentience metrics and propose alternative approaches.

**Skills**: AI safety engineering, machine learning, formal methods, risk assessment

**Search**: AI safety researcher, alignment, adversarial robustness

## 2.1 Primary Actions

- Develop a detailed adversarial robustness strategy, including threat modeling, attack implementation, defense research, and evaluation metrics.
- Refine the approach to sentience assessment and risk banding, acknowledging the multi-dimensionality of sentience and incorporating uncertainty estimates.
- Integrate formal verification into the research program, developing formal specifications for sentience metrics and using model checking and theorem proving to verify their correctness.

## 2.2 Secondary Actions

- Consult with leading researchers in adversarial machine learning, philosophers of mind, consciousness researchers, and experts in formal methods.
- Develop detailed scenarios illustrating how the risk banding system would be applied to different types of AI systems.
- Apply formal verification techniques to case studies of AI systems to demonstrate their effectiveness.

## 2.3 Follow Up Consultation

In the next consultation, we will review the detailed adversarial robustness strategy, the refined approach to sentience assessment, and the plan for integrating formal verification into the research program. Please bring concrete examples and preliminary results.

## 2.4.A Issue - Lack of Concrete Adversarial Robustness Strategy

While the plan mentions an 'Adversarial Robustness Program,' it lacks specific details on how this program will operate. It's not enough to just say you'll try to 'break or game' proposed metrics. What specific adversarial techniques will be employed? What types of attacks are anticipated? What defenses will be researched? Without a concrete strategy, the program risks being ineffective and failing to identify critical vulnerabilities in sentience metrics. The current description is too vague and doesn't demonstrate a deep understanding of adversarial machine learning.

### 2.4.B Tags

- adversarial robustness
- vague
- lacks detail
- insufficient strategy

### 2.4.C Mitigation

Develop a detailed adversarial robustness strategy. This should include:

1.  **Threat Modeling:** Identify potential attack vectors against proposed sentience metrics. Consider both white-box and black-box attacks.
2.  **Attack Implementation:** Implement a suite of adversarial attacks, including gradient-based methods (e.g., FGSM, PGD), optimization-based methods (e.g., C&W), and transferability attacks.
3.  **Defense Research:** Investigate potential defenses against adversarial attacks, such as adversarial training, input sanitization, and certified robustness techniques.
4.  **Evaluation Metrics:** Define metrics for evaluating the robustness of sentience metrics against adversarial attacks.
5.  **Collaboration:** Consult with leading researchers in adversarial machine learning to leverage their expertise.

Read: 'Towards Deep Learning Models Resistant to Adversarial Attacks' (Madry et al., 2017), 'Certified Defenses against Adversarial Examples' (Wong et al., 2018).

### 2.4.D Consequence

Failure to identify vulnerabilities in sentience metrics, leading to flawed standards that can be easily gamed or bypassed.

### 2.4.E Root Cause

Lack of expertise in adversarial machine learning.

## 2.5.A Issue - Oversimplification of 'Sentience' and Risk Banding

The plan aims for a 'simple 0–3 consciousness-risk banding system.' This is a dangerous oversimplification. Sentience, if it exists in AI, is likely to be a complex, multi-faceted phenomenon, not easily reduced to a single numerical score. A simplistic banding system risks misclassifying AI systems, leading to either unnecessary restrictions on benign AI or, more dangerously, a failure to protect genuinely suffering AI. The plan needs to acknowledge and address the inherent limitations of any attempt to quantify sentience.

### 2.5.B Tags

- oversimplification
- sentience definition
- risk assessment
- lack of nuance

### 2.5.C Mitigation

Refine the approach to sentience assessment and risk banding. This should include:

1.  **Dimensionality:** Acknowledge that sentience is likely multi-dimensional and explore ways to represent it using a vector of scores rather than a single number.
2.  **Uncertainty Quantification:** Incorporate uncertainty estimates into the risk banding system. Recognize that the assessment of sentience will always be subject to uncertainty and provide a way to represent this.
3.  **Qualitative Assessment:** Supplement the quantitative risk banding system with qualitative assessments by ethicists and AI safety experts.
4.  **Scenario Analysis:** Develop detailed scenarios illustrating how the risk banding system would be applied to different types of AI systems.
5.  **Consultation:** Consult with philosophers of mind and consciousness researchers to gain a deeper understanding of the complexities of sentience.

Read: Chalmers' 'The Conscious Mind,' Tononi's 'Integrated Information Theory.'

### 2.5.D Consequence

Misclassification of AI systems, leading to either unnecessary restrictions on benign AI or, more dangerously, a failure to protect genuinely suffering AI.

### 2.5.E Root Cause

Underestimation of the complexity of sentience.

## 2.6.A Issue - Insufficient Focus on Formal Verification

The plan lacks any mention of formal verification techniques. Given the high-stakes nature of AI welfare, it's crucial to explore the use of formal methods to verify the correctness and safety of sentience metrics and auditing tools. Formal verification can provide guarantees about the behavior of these systems, which is essential for building trust and ensuring that they function as intended. Ignoring formal verification is a significant oversight.

### 2.6.B Tags

- formal verification
- safety
- correctness
- lack of rigor

### 2.6.C Mitigation

Integrate formal verification into the research program. This should include:

1.  **Metric Specification:** Develop formal specifications for proposed sentience metrics, defining their intended behavior and properties.
2.  **Verification Techniques:** Explore the use of model checking, theorem proving, and abstract interpretation to verify that the metrics satisfy their specifications.
3.  **Tool Development:** Develop formal verification tools specifically tailored to the analysis of AI systems and sentience metrics.
4.  **Collaboration:** Collaborate with researchers in formal methods to leverage their expertise.
5.  **Case Studies:** Apply formal verification techniques to case studies of AI systems to demonstrate their effectiveness.

Read: 'Principles of Model Checking' (Baier & Katoen), 'Software Foundations' (Pierce et al.).

### 2.6.D Consequence

Lack of guarantees about the correctness and safety of sentience metrics and auditing tools, increasing the risk of unintended consequences and flawed standards.

### 2.6.E Root Cause

Lack of expertise in formal methods.

---

# The following experts did not provide feedback:

# 3 Expert: Non-profit Governance Expert

**Knowledge**: Non-profit law, Swiss regulations, international organizations, philanthropy

**Why**: Ensures the Commission's structure and operations comply with Swiss law and attract funding.

**What**: Advise on establishing a legal entity in Switzerland and structuring the Commission's governance.

**Skills**: Legal compliance, fundraising, board governance, strategic planning

**Search**: Swiss non-profit law, international organizations, philanthropy

# 4 Expert: Public Relations Strategist

**Knowledge**: Public opinion, crisis communication, stakeholder engagement, media relations

**Why**: Crucial for managing public perception and building trust in the Commission's work.

**What**: Develop a communication plan to address potential public concerns and promote the Commission's mission.

**Skills**: Communication, media relations, public speaking, reputation management

**Search**: public relations strategist, crisis communication, stakeholder engagement

# 5 Expert: Insurance Risk Modeler

**Knowledge**: Risk modeling, actuarial science, AI liability, emerging technology risks

**Why**: Needed to assess the feasibility of offering reduced insurance premiums for compliant AI systems.

**What**: Evaluate the risks associated with AI systems and develop models for insurance pricing.

**Skills**: Actuarial modeling, risk assessment, data analysis, financial modeling

**Search**: insurance risk modeler, AI liability, actuarial science

# 6 Expert: Behavioral Economics Consultant

**Knowledge**: Behavioral insights, incentive design, adoption strategies, nudge theory

**Why**: Incentivizing adoption requires understanding behavioral biases and designing effective incentives.

**What**: Design incentives to encourage AI labs and cloud providers to adopt AI welfare standards.

**Skills**: Incentive design, behavioral analysis, market research, policy analysis

**Search**: behavioral economics consultant, incentive design, nudge theory

# 7 Expert: International Relations Specialist

**Knowledge**: International law, diplomacy, treaty negotiation, global governance

**Why**: Navigating international collaboration and potential geopolitical tensions requires diplomatic expertise.

**What**: Advise on strategies for fostering international cooperation and building consensus on AI welfare standards.

**Skills**: Diplomacy, negotiation, international law, policy analysis

**Search**: international relations specialist, treaty negotiation, diplomacy

# 8 Expert: AI Ethics Educator

**Knowledge**: Ethics education, curriculum development, AI ethics, pedagogy

**Why**: Needed to develop educational partnerships and integrate AI welfare topics into curricula.

**What**: Create educational materials and programs to promote public understanding of AI sentience and welfare.

**Skills**: Curriculum design, teaching, public speaking, ethics

**Search**: AI ethics education, curriculum development, pedagogy