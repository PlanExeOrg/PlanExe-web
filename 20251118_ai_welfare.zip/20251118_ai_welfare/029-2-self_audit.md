Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 17 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 2 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan does not require breaking any physical laws. The project focuses on ethical and welfare standards, not on impossible physics.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (AI welfare standards) + market (global adoption) + tech/process (measuring AI sentience) + policy (ISO alignment) without independent evidence at comparable scale. There is no credible precedent for this specific system combination. Failure would be existential.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Reject domain-mismatched PoCs. Owner: Project Lead / Deliverable: Validation Report / Date: Q4 2025.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on buzzwords like 'AI welfare' and 'sentience' without clear, measurable definitions or mechanisms. The plan states, "A key strategic dimension that could be missing is a more explicit focus on the ethical frameworks guiding the Commission's work."

**Mitigation**: Ethical Framework Architect: Produce one-pagers for 'AI Welfare' and 'Sentience' with value hypotheses, success metrics, and decision hooks by Q2 2025. These must include a business-level mechanism-of-action (inputs→process→customer value).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (reputational risk) is minimized. The plan mentions "public backlash, reduced funding, lack of adoption" but lacks explicit cascade analysis. For example, ethical disagreement → public backlash → funding shortfall → project shutdown.

**Mitigation**: Public Engagement Team: Expand the risk register to include cascade effects (e.g., ethical disagreements leading to reputational damage and funding shortfalls) and add controls with a review cadence by Q3 2025.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a permit/approval matrix. The plan mentions "Permits for operating a research institution in Geneva" and "Licenses for data handling and privacy compliance" but does not map these to a timeline.

**Mitigation**: Legal Team: Create a permit/approval matrix with lead times, dependencies, and NO-GO thresholds by Q2 2025. Include triggers for escalation and alternatives.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets do not cover the required runway. The plan mentions "Funding of $300M per year" but lacks details on funding sources, draw schedule, covenants, and runway length.

**Mitigation**: Funding Team: Create a dated financing plan listing sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates by Q2 2025.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $300M/year lacks substantiation via benchmarks or vendor quotes normalized by area. The plan mentions "Funding of $300M per year" but provides no cost breakdown or justification for this figure.

**Mitigation**: Finance Team: Obtain ≥3 relevant cost benchmarks (capex/opex) for similar international research initiatives, normalize per area (cost per m²/ft²), and adjust the budget or de-scope by Q3 2025.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios. For example, the plan aims to establish standards by "2029-2030" without discussing potential delays or best/worst-case scenarios.

**Mitigation**: Project Manager: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the completion date, including potential delays and their impact, by Q3 2025.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because core components lack engineering artifacts. The plan mentions "AI Welfare Auditing Tool" and "Sentience Risk Assessment API" but lacks technical specifications, interface definitions, test plans, and integration maps.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for the AI Welfare Auditing Tool and Sentience Risk Assessment API by Q4 2025.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks verifiable artifacts for critical claims. For example, it states, "Success is measured by the robustness of the research findings" but does not provide evidence of existing licenses or approvals.

**Mitigation**: Research Team: Obtain verifiable artifacts for all critical claims, including licenses and approvals, and document them by Q2 2025.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "AI Welfare Standard v1.0" lacks SMART acceptance criteria. The plan mentions "release of a versioned AI Welfare Standard v1.0 under the ISO umbrella" without specific, verifiable qualities.

**Mitigation**: Standards Team: Define SMART criteria for AI Welfare Standard v1.0, including a KPI for adoption rate (e.g., 20% adoption by major AI labs within 2 years) by Q3 2025.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Certified Humane Frontier Model' seal adds complexity without clear support for core goals. The plan aims to "research and develop standards for AI sentience and welfare" and "mitigate potential suffering in AI systems."

**Mitigation**: Product & Adoption Manager: Produce a one-page benefit case for the 'Certified Humane Frontier Model' seal, including a KPI, owner, and estimated cost, or move it to the project backlog by Q2 2025.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a rare mix of skills: "ISO Liaison & Standards Coordinator" must navigate ISO, ensure alignment, and facilitate adoption. This role is critical, and finding someone with both ISO expertise and AI knowledge will be difficult.

**Mitigation**: HR: Validate the talent market for an "ISO Liaison & Standards Coordinator" with AI expertise by Q2 2025. If the market is thin, adjust the role or timeline.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping authorities, artifacts, and lead times. The plan mentions "Permits for operating a research institution in Geneva" but lacks specifics.

**Mitigation**: Legal Team: Develop a regulatory matrix identifying all required permits, licenses, and compliance standards, including authorities, artifacts, lead times, and NO-GO criteria by Q2 2025.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "long-term sustainability" and "diversified funding" but lacks a concrete operational sustainability plan. The plan mentions "sustainability plan, diversified funding, clear value proposition" as actions to mitigate Risk 11, but lacks specifics.

**Mitigation**: Finance Team: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms by Q4 2025.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a fatal-flaw screen with authorities. The plan mentions "Permits for operating a research institution in Geneva" but lacks evidence of zoning/land-use, occupancy/egress, fire load, structural limits, noise, and permit viability.

**Mitigation**: Legal Team: Conduct a fatal-flaw screen with Geneva authorities regarding zoning/land-use, occupancy/egress, fire load, structural limits, noise, and permits by Q2 2025.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks redundancy or tested failovers for critical external dependencies. The plan mentions "Secure initial funding commitments of $300M per year" but does not address vendor lock-in or tested alternatives.

**Mitigation**: Finance Team: Secure SLAs with key vendors and add a secondary funding source or path, testing failover procedures by Q4 2025.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states goals for "AI Researchers" (access to research) and "AI developers" (clear guidelines) but does not address their conflicting incentives. Researchers seek publication, while developers prioritize rapid deployment.

**Mitigation**: Project Lead: Define a shared OKR (Objective and Key Results) that aligns both AI Researchers and AI Developers on a common outcome, such as "Increase adoption of standards" by Q3 2025.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board with escalation thresholds (when to re-plan/stop) by Q2 2025.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a cross-impact analysis or FTA. The plan identifies risks (funding, technical, ethical) but does not assess interactions. For example, technical challenges in developing metrics could lead to ethical disagreements, hindering international consensus and causing funding shortfalls.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by Q3 2025.