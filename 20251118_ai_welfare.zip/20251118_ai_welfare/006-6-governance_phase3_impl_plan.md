### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start
- Pre-defined SteerCo responsibilities and membership

### 2. Project Manager drafts initial Terms of Reference for the Core Project Team, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Core Project Team ToR v0.1

**Dependencies:**

- Project Start
- Pre-defined Core Project Team responsibilities and membership

### 3. Project Manager drafts initial Terms of Reference for the Technical Advisory Group, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Technical Advisory Group ToR v0.1

**Dependencies:**

- Project Start
- Pre-defined Technical Advisory Group responsibilities and membership

### 4. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**

- Project Start
- Pre-defined Ethics & Compliance Committee responsibilities and membership

### 5. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group, based on the pre-defined responsibilities and membership.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**

- Project Start
- Pre-defined Stakeholder Engagement Group responsibilities and membership

### 6. Circulate Draft SteerCo ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 7. Circulate Draft Core Project Team ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Core Project Team ToR v0.1
- Nominated Members List Available

### 8. Circulate Draft Technical Advisory Group ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Technical Advisory Group ToR v0.1
- Nominated Members List Available

### 9. Circulate Draft Ethics & Compliance Committee ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 10. Circulate Draft Stakeholder Engagement Group ToR for review by nominated members.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 11. Project Manager finalizes the Project Steering Committee Terms of Reference based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 12. Project Manager finalizes the Core Project Team Terms of Reference based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Core Project Team ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Core Project Team ToR v0.1

### 13. Project Manager finalizes the Technical Advisory Group Terms of Reference based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Technical Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Technical Advisory Group ToR v0.1

### 14. Project Manager finalizes the Ethics & Compliance Committee Terms of Reference based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.1

### 15. Project Manager finalizes the Stakeholder Engagement Group Terms of Reference based on feedback received.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Stakeholder Engagement Group ToR v0.1

### 16. Project Sponsor formally appoints the Steering Committee Chair.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 17. Project Sponsor confirms all Steering Committee members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final SteerCo ToR v1.0
- Nominated Members List Available

### 18. Project Sponsor confirms all Core Project Team members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Core Project Team ToR v1.0
- Nominated Members List Available

### 19. Project Sponsor confirms all Technical Advisory Group members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Nominated Members List Available

### 20. Project Sponsor confirms all Ethics & Compliance Committee members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Nominated Members List Available

### 21. Project Sponsor confirms all Stakeholder Engagement Group members.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Nominated Members List Available

### 22. Project Manager schedules and facilitates the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Final SteerCo ToR v1.0
- Appointment Confirmation Emails

### 23. Project Manager schedules and facilitates the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Final Core Project Team ToR v1.0
- Appointment Confirmation Emails

### 24. Project Manager schedules and facilitates the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Final Technical Advisory Group ToR v1.0
- Appointment Confirmation Emails

### 25. Project Manager schedules and facilitates the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Appointment Confirmation Emails

### 26. Project Manager schedules and facilitates the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Appointment Confirmation Emails

### 27. The Project Steering Committee reviews and approves the initial project plan and budget.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Approved Project Plan
- Approved Project Budget

**Dependencies:**

- Meeting Minutes with Action Items
- Initial Project Plan Draft
- Initial Budget Draft

### 28. The Core Project Team develops and executes detailed project plans.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Detailed Project Plans

**Dependencies:**

- Approved Project Plan
- Approved Project Budget

### 29. The Technical Advisory Group reviews initial research plans and technical specifications.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Technical Assessment Report

**Dependencies:**

- Detailed Project Plans

### 30. The Ethics & Compliance Committee develops a code of ethics for the Commission.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Code of Ethics v1.0

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 31. The Stakeholder Engagement Group develops and implements a stakeholder engagement plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Stakeholder Engagement Plan v1.0

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0