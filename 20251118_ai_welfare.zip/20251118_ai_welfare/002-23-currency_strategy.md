This plan involves money.

## Currencies

- **CHF:** Local currency for operations in Switzerland.
- **USD:** For international budgeting and funding, and to mitigate currency fluctuation risks.
- **EUR:** For transactions within the Geneva metro area and potential collaborations with European entities.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. CHF will be used for local transactions in Switzerland. EUR may be used for transactions within the Geneva metro area.