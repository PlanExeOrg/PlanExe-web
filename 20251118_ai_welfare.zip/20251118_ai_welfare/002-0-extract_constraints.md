## Positive Constraints

- AI Sentience & Welfare Commission
- Functionally linked to the International Organization for Standardization (ISO)
- Anchor physically at ISO's Central Secretariat in the Geneva metro area: Chemin de Blandonnet 8, 1214 Vernier / Geneva, Switzerland
- Target operating budget: about $300M per year
- Run a multi-year research program
- Coordinate and fund foundational work on AI sentience metrics and consciousness-risk assessment
- Publish evolving, versioned outputs
- Create a Sentience Metrics & Theory Program
- Create a dedicated Adversarial Robustness Program funded at ≥15% of the total research budget
- Create a Product & Adoption Team
- Build tangible value-add tools
- Safety & Control Working Group focuses on shutdown/deletion and control standards for human safety
- Welfare track stays focused on preventing suffering to plausible moral patients
- Commission is already operating on a minimal but real footing in Geneva by late 2026
- Legal entity in Switzerland by late 2026
- ISO linkage agreed by late 2026
- Small core team in place at Chemin de Blandonnet 8 by late 2026
- Initial $300M/year funding commitments by late 2026
- First global Research Roadmap on AI Sentience Metrics & Welfare plus initial grant calls by late 2026
- Sentience Metrics White Paper by around 2028
- Draft Principles of AI Welfare by around 2028
- AI Welfare Standard v1.0 under the ISO umbrella by 2029–2030

## Negative Constraints

- Do not use blockchain
- Do not use NFT
- Do not use Metaverse
- Do not use VR
- Do not use AR
- Do not use DAO
