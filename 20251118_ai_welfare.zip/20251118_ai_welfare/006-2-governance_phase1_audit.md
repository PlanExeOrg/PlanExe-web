
## Audit - Corruption Risks

- Bribery of ISO officials to expedite or influence the standards development process.
- Conflicts of interest within the Commission, where members prioritize personal or affiliated lab interests over objective welfare assessments.
- Kickbacks from vendors providing services to the Commission (e.g., IT infrastructure, office space) in exchange for favorable treatment.
- Misuse of confidential information regarding AI system vulnerabilities or sentience assessments for personal gain or competitive advantage.
- Nepotism in hiring practices, leading to unqualified personnel in key roles and compromising the integrity of the Commission's work.

## Audit - Misallocation Risks

- Excessive spending on administrative overhead, diverting funds from core research activities.
- Inefficient allocation of research funds, prioritizing projects based on personal connections rather than scientific merit.
- Duplication of research efforts due to poor coordination between the Sentience Metrics & Theory Program and the Adversarial Robustness Program.
- Unauthorized use of Commission assets (e.g., computing resources, data) for personal projects or commercial ventures.
- Misreporting of research progress or results to secure continued funding or inflate the Commission's perceived impact.

## Audit - Procedures

- Annual independent financial audits to verify the proper use of funds and compliance with accounting standards, conducted by a reputable external auditing firm.
- Periodic internal reviews of research project selection and funding allocation processes to ensure fairness and alignment with the Commission's mandate, led by a designated audit committee.
- Regular compliance checks to ensure adherence to Swiss data protection laws and ISO standards, conducted by a qualified legal counsel.
- Expense report audits to identify and prevent fraudulent or inappropriate spending, with a threshold for mandatory review of expenses exceeding a specified amount (e.g., 5,000 CHF).
- Post-project audits of major initiatives (e.g., development of the AI Welfare Auditing Tool) to assess their effectiveness and identify lessons learned, conducted by an independent evaluation team.

## Audit - Transparency Measures

- Publicly accessible dashboard displaying the Commission's budget, funding sources, and key performance indicators (KPIs) related to research progress and standards adoption.
- Publication of minutes from key meetings of the Commission's governing bodies (e.g., the board of directors, research advisory committee) on the Commission's website.
- Establishment of a confidential whistleblower mechanism for reporting suspected fraud, corruption, or ethical violations, with clear procedures for investigation and resolution.
- Public access to the Commission's policies and procedures, including those related to research ethics, data privacy, and conflict of interest management.
- Documented selection criteria and justification for major decisions, such as the awarding of research grants or the selection of vendors, published on the Commission's website.