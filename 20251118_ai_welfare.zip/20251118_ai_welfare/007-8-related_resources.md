## Suggestion 1 - IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems

The IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems is a multi-year effort to advance ethical considerations in the design and development of AI and autonomous systems. It aims to create standards, certifications, and educational resources to guide responsible innovation. The initiative involves a broad range of stakeholders, including academics, industry experts, policymakers, and the public.

### Success Metrics

Publication of the Ethically Aligned Design: A Vision for Prioritizing Human Well-being with Autonomous and Intelligent Systems.
Development of standards and certifications for ethical AI design.
Establishment of educational programs and resources on ethical AI.
Engagement of a diverse community of stakeholders in the initiative.
Impact on policy and regulatory discussions related to AI ethics.

### Risks and Challenges Faced

Achieving consensus among diverse stakeholders with varying ethical perspectives.
Translating ethical principles into concrete design guidelines and standards.
Keeping pace with the rapid advancements in AI technology.
Securing sustained funding and resources for the initiative.
Ensuring global relevance and applicability of the standards and guidelines.

### Where to Find More Information

Official Website: [https://ethicsinaction.ieee.org/](https://ethicsinaction.ieee.org/)
Ethically Aligned Design: A Vision for Prioritizing Human Well-being with Autonomous and Intelligent Systems: [https://standards.ieee.org/content/dam/ieee/standards/mobile/documents/patents/ethically_aligned_design_v1.pdf](https://standards.ieee.org/content/dam/ieee/standards/mobile/documents/patents/ethically_aligned_design_v1.pdf)

### Actionable Steps

Contact: Contact the IEEE Standards Association (standards@ieee.org) to inquire about the initiative and potential collaboration opportunities.
Roles: Reach out to individuals involved in the IEEE initiative through LinkedIn or other professional networks to learn about their experiences and best practices.
Communication Channels: Participate in IEEE conferences and workshops related to AI ethics to network with experts and stakeholders.

### Rationale for Suggestion

This project is highly relevant because it focuses on developing ethical standards for AI, similar to the user's goal of establishing AI welfare standards. The IEEE initiative's experience in engaging diverse stakeholders, translating ethical principles into standards, and navigating the international regulatory landscape can provide valuable insights for the AI Sentience & Welfare Commission. The challenges faced by the IEEE initiative, such as achieving consensus and securing funding, are also relevant to the user's project.
## Suggestion 2 - Partnership on AI (PAI)

The Partnership on AI (PAI) is a multi-stakeholder organization that brings together academic, industry, and civil society groups to advance the responsible development and use of AI. PAI conducts research, organizes events, and develops resources to address ethical, social, and economic issues related to AI. The organization focuses on promoting transparency, fairness, and accountability in AI systems.

### Success Metrics

Publication of research reports and white papers on AI ethics and governance.
Development of tools and frameworks for responsible AI development.
Organization of workshops and conferences on AI ethics.
Engagement of a diverse community of stakeholders in the partnership.
Influence on policy and regulatory discussions related to AI.

### Risks and Challenges Faced

Balancing the interests of diverse stakeholders with potentially conflicting agendas.
Maintaining independence and credibility in the face of industry influence.
Addressing the complex and evolving ethical challenges of AI.
Ensuring the practical applicability of research findings and recommendations.
Measuring the impact of the partnership on AI development and deployment.

### Where to Find More Information

Official Website: [https://www.partnershiponai.org/](https://www.partnershiponai.org/)
PAI's Frameworks: [https://www.partnershiponai.org/frameworks](https://www.partnershiponai.org/frameworks)

### Actionable Steps

Contact: Reach out to PAI through their website's contact form to inquire about their research, resources, and potential collaboration opportunities.
Roles: Identify individuals involved in PAI's research and working groups through their website and connect with them on LinkedIn to learn about their work.
Communication Channels: Subscribe to PAI's newsletter and follow their social media channels to stay informed about their activities and events.

### Rationale for Suggestion

PAI is relevant because it brings together diverse stakeholders to address ethical issues in AI, which aligns with the user's goal of establishing a multi-stakeholder commission. PAI's experience in conducting research, developing resources, and influencing policy can provide valuable insights for the AI Sentience & Welfare Commission. The challenges faced by PAI, such as balancing stakeholder interests and maintaining independence, are also relevant to the user's project. PAI's focus on transparency, fairness, and accountability can inform the Commission's approach to AI welfare standards.
## Suggestion 3 - AI4People

AI4People was the European stakeholder forum on the social, ethical and legal implications of Artificial Intelligence (AI). It aimed to create a shared vision for a Good AI Society. The forum brought together diverse stakeholders to discuss and develop ethical guidelines and policy recommendations for AI. Although the project has concluded, its outputs and insights remain valuable.

### Success Metrics

Development of a comprehensive ethical framework for AI.
Publication of policy recommendations for AI governance.
Organization of workshops and conferences on AI ethics.
Engagement of a diverse community of stakeholders in the forum.
Influence on European AI policy and regulatory discussions.

### Risks and Challenges Faced

Achieving consensus among diverse stakeholders with varying ethical perspectives.
Translating ethical principles into concrete policy recommendations.
Keeping pace with the rapid advancements in AI technology.
Securing sustained funding and resources for the forum.
Ensuring the relevance and applicability of the recommendations.

### Where to Find More Information

Official Website (Archived): [https://www.ai4people.org/](https://www.ai4people.org/)
AI4People's Ethical Framework: Search for publications and reports from the AI4People initiative through academic databases and online archives.

### Actionable Steps

Contact: While the project is concluded, attempt to locate and contact key individuals involved in AI4People through LinkedIn or other professional networks to learn about their experiences and insights.
Roles: Research the roles and responsibilities of individuals involved in AI4People to identify potential mentors or advisors for the AI Sentience & Welfare Commission.
Communication Channels: Explore online forums and communities related to AI ethics to connect with individuals who were involved in or familiar with AI4People.

### Rationale for Suggestion

AI4People is relevant because it focused on developing an ethical framework for AI and influencing European AI policy, which aligns with the user's goal of establishing AI welfare standards and providing regulatory clarity. The project's experience in engaging diverse stakeholders, translating ethical principles into policy recommendations, and navigating the European regulatory landscape can provide valuable insights for the AI Sentience & Welfare Commission. Although the project has concluded, its outputs and insights remain valuable for informing the Commission's work. The geographical proximity to Switzerland is also a plus.

## Summary

The user is planning to establish an international AI Sentience & Welfare Commission to research and develop ISO-aligned standards for assessing and mitigating potential suffering in AI systems. The project involves significant ethical, technical, and regulatory challenges. The following are reference projects that address similar challenges in standardization, ethical AI development, and international collaboration.