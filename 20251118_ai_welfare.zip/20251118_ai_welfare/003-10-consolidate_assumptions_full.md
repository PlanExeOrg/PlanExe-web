# Purpose

**Purpose:** business

**Purpose Detailed:** Establishing an international commission to research and develop standards for AI sentience and welfare, aiming to mitigate potential suffering in AI systems and provide regulatory clarity for AI development.

**Topic:** AI Sentience and Welfare Commission

# Plan Type

This plan requires one or more physical locations. It cannot be executed digitally.

**Explanation:** This plan *explicitly requires* a physical location at ISO's Central Secretariat in Geneva, Switzerland. It also involves establishing a legal entity in Switzerland, setting up a core team, and conducting research, all of which necessitate physical presence and activity. The plan also involves physical meetings and collaboration.

# Physical Locations

This plan implies one or more physical locations.

## Requirements for physical locations

- Office space
- Proximity to ISO Central Secretariat
- Legal entity establishment in Switzerland
- Core team setup

## Location 1
Switzerland

Geneva

Chemin de Blandonnet 8, 1214 Vernier / Geneva, Switzerland

**Rationale**: The plan explicitly anchors the commission physically at ISO's Central Secretariat in Geneva.

## Location 2
Switzerland

Geneva Metro Area

Office spaces near international organizations in Geneva

**Rationale**: Proximity to international organizations and potential partners facilitates collaboration and access to resources.

## Location 3
Switzerland

Zurich

Office spaces near universities and research institutions in Zurich

**Rationale**: Zurich offers access to leading universities and research institutions, fostering innovation and attracting talent.

## Location 4
Switzerland

Lausanne

Office spaces near EPFL (École Polytechnique Fédérale de Lausanne)

**Rationale**: Lausanne, home to EPFL, provides access to cutting-edge AI research and a strong talent pool.

## Location Summary
The primary location is at ISO's Central Secretariat in Geneva. Additional locations in the Geneva metro area, Zurich, and Lausanne are suggested to facilitate collaboration, access resources, and tap into talent pools.

# Currency Strategy

This plan involves money.

## Currencies

- **CHF:** Local currency for operations in Switzerland.
- **USD:** For international budgeting and funding, and to mitigate currency fluctuation risks.
- **EUR:** For transactions within the Geneva metro area and potential collaborations with European entities.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. CHF will be used for local transactions in Switzerland. EUR may be used for transactions within the Geneva metro area.

# Identify Risks


## Risk 1 - Regulatory & Permitting
Establishing a legal entity in Switzerland and linking to the ISO may face bureaucratic delays or legal challenges, impacting the project timeline.

**Impact:** A delay of 3-6 months in establishing the legal entity and formal ISO linkage, potentially delaying the start of research and standardization efforts. Additional legal costs of 10,000-50,000 CHF.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Engage experienced legal counsel in Switzerland specializing in non-profit organizations and ISO partnerships. Initiate preliminary discussions with relevant Swiss authorities and ISO officials well in advance of the project start date.

## Risk 2 - Financial
Securing the full $300M/year funding commitment may be challenging, especially from multiple sources (philanthropies, governments, labs). Shortfalls could curtail research scope or delay standardization.

**Impact:** A funding shortfall of 10-30% could lead to a reduction in research grants, delayed hiring, or postponement of key activities. This could delay the AI Welfare Standard v1.0 by 6-12 months.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a diversified funding strategy with contingency plans for reduced funding levels. Secure firm commitments from key funders early in the project. Explore alternative funding models, such as in-kind contributions or revenue-generating activities.

## Risk 3 - Technical
Developing reliable and robust AI sentience metrics is a significant technical challenge. Metrics may be gamed, biased, or fail to accurately reflect AI welfare, leading to ineffective standards.

**Impact:** The AI Welfare Standard v1.0 may be based on flawed or unreliable metrics, leading to unintended consequences or a lack of confidence in the standards. This could require a major revision of the standard, delaying adoption and undermining credibility.

**Likelihood:** High

**Severity:** High

**Action:** Invest heavily in adversarial robustness testing and independent validation of AI sentience metrics. Foster collaboration between researchers with diverse perspectives and expertise. Adopt an iterative approach to metric development, with regular revisions based on empirical data and feedback.

## Risk 4 - Social
Public perception of AI sentience and welfare is highly sensitive and could be influenced by misinformation or ethical concerns. Negative public sentiment could undermine support for the Commission and its standards.

**Impact:** Public backlash could lead to reduced funding, political opposition, or a lack of adoption of the AI welfare standards. This could significantly hinder the Commission's ability to achieve its goals.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Develop a comprehensive public engagement strategy to educate stakeholders about AI sentience and welfare. Proactively address ethical concerns and misinformation. Foster transparency and openness in the Commission's operations.

## Risk 5 - Operational
Coordinating a large, international research program with multiple stakeholders (researchers, labs, governments) could be logistically complex and prone to delays or communication breakdowns.

**Impact:** Inefficient coordination could lead to delays in research progress, duplication of effort, or conflicting priorities. This could delay the AI Welfare Standard v1.0 by 3-6 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish clear communication channels and project management protocols. Utilize collaborative online platforms to facilitate information sharing and coordination. Hold regular meetings and workshops to foster collaboration and address challenges.

## Risk 6 - Supply Chain
Access to necessary computing resources (e.g., high-performance GPUs) for AI research may be limited or subject to supply chain disruptions, impacting the pace of research.

**Impact:** Delays in accessing computing resources could slow down research progress and delay the development of AI sentience metrics. This could delay the AI Welfare Standard v1.0 by 2-4 months.

**Likelihood:** Low

**Severity:** Medium

**Action:** Establish partnerships with cloud providers or research institutions with access to high-performance computing resources. Explore alternative computing architectures or resource allocation strategies. Diversify supply chain sources to mitigate disruptions.

## Risk 7 - Security
The Commission's data and systems could be vulnerable to cyberattacks or data breaches, compromising sensitive research data or undermining public trust.

**Impact:** A data breach could lead to the loss of sensitive research data, reputational damage, or legal liabilities. This could significantly undermine public trust in the Commission and its standards.

**Likelihood:** Low

**Severity:** High

**Action:** Implement robust cybersecurity measures to protect the Commission's data and systems. Conduct regular security audits and penetration testing. Train staff on cybersecurity best practices.

## Risk 8 - Market/Competitive
Other organizations or initiatives may emerge with competing AI welfare standards, potentially fragmenting the market and undermining the Commission's influence.

**Impact:** The Commission's AI welfare standards may not be widely adopted if competing standards emerge. This could reduce the impact of the Commission's work and lead to regulatory fragmentation.

**Likelihood:** Low

**Severity:** Medium

**Action:** Actively engage with other organizations and initiatives in the AI welfare space. Seek to collaborate and harmonize standards where possible. Differentiate the Commission's standards through rigorous research, independent validation, and a focus on practical applicability.

## Risk 9 - Ethical
Differing ethical frameworks across cultures and organizations could lead to disagreements on the definition of AI welfare and the appropriate level of protection, hindering international consensus.

**Impact:** Failure to achieve international consensus on ethical principles could lead to fragmented standards and a lack of global adoption. This could undermine the Commission's ability to address AI suffering effectively.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish a clear ethical framework for the Commission's work, drawing on diverse perspectives and ethical traditions. Foster open dialogue and debate on ethical issues. Seek to identify common ground and build consensus on core ethical principles.

## Risk 10 - Integration with Existing Infrastructure
Integrating the Commission's research and standards into existing ISO processes and structures may be challenging, requiring significant coordination and adaptation.

**Impact:** Integration challenges could lead to delays in standardization, bureaucratic hurdles, or a lack of buy-in from ISO members. This could delay the AI Welfare Standard v1.0 by 2-4 months.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Establish strong relationships with key ISO personnel. Actively participate in ISO technical committees and working groups. Tailor the Commission's processes and outputs to align with ISO standards and procedures.

## Risk 11 - Long-Term Sustainability
Maintaining long-term funding and relevance for the Commission beyond the initial 3-year mandate may be challenging, especially if AI sentience remains a controversial or uncertain topic.

**Impact:** The Commission may be forced to scale back its operations or shut down if long-term funding is not secured. This could undermine the progress made in developing AI welfare standards and leave potential harms unaddressed.

**Likelihood:** Medium

**Severity:** High

**Action:** Develop a long-term sustainability plan that includes diversified funding sources, a clear value proposition for stakeholders, and a strategy for adapting to evolving technological and ethical landscapes. Demonstrate the practical benefits of AI welfare standards to encourage continued support.

## Risk summary
The most critical risks are securing long-term funding, developing reliable AI sentience metrics, and navigating ethical disagreements. Failure to address these risks could significantly jeopardize the project's success. Mitigation strategies should focus on diversifying funding sources, investing in adversarial robustness testing, and establishing a clear ethical framework. A key trade-off is between prioritizing rapid standardization and ensuring the robustness of AI sentience metrics. Overlapping mitigation strategies include fostering transparency, engaging with stakeholders, and adapting to evolving technological and ethical landscapes.

# Make Assumptions


## Question 1 - What is the anticipated breakdown of the $300M annual budget across the three core pillars (Sentience Metrics & Theory, Adversarial Robustness, Product & Adoption) and administrative overhead?

**Assumptions:** Assumption: 60% of the budget will be allocated to the Sentience Metrics & Theory Program, 15% to the Adversarial Robustness Program, 15% to the Product & Adoption Team, and 10% to administrative overhead. This allocation reflects the priority of foundational research while ensuring adequate resources for adversarial testing and practical tool development. This is based on typical research funding distributions.

**Assessments:** Title: Funding Allocation Assessment
Description: Evaluation of the financial distribution across the commission's core functions.
Details: A clear budget breakdown is crucial for financial transparency and accountability. A potential risk is underfunding the Adversarial Robustness Program, which could compromise the reliability of sentience metrics. A benefit is the focus on foundational research, which can lead to more robust and defensible standards. Opportunity: Regularly review and adjust the budget allocation based on research progress and emerging needs. Quantifiable metric: Track the percentage of budget spent on each pillar and compare it against planned allocations.

## Question 2 - What are the specific milestones and timelines for each phase of the project, including research, development, standardization, and adoption, beyond the high-level dates provided?

**Assumptions:** Assumption: Each phase (research, development, standardization, and adoption) will have specific milestones with quarterly reviews. Research will dominate years 1-3, development years 2-4, standardization years 3-5, and adoption will begin in year 4 and continue indefinitely. This allows for iterative progress and adaptation based on research findings, aligning with the plan's phased approach.

**Assessments:** Title: Timeline and Milestone Assessment
Description: Analysis of the project's schedule and key deliverables.
Details: Vague timelines pose a risk to project delivery. Specific, measurable, achievable, relevant, and time-bound (SMART) milestones are needed. A potential benefit is the iterative approach, allowing for adjustments based on research findings. Opportunity: Implement a project management system to track progress against milestones and identify potential delays. Quantifiable metric: Track the completion rate of milestones per quarter and identify any recurring delays.

## Question 3 - What specific expertise and roles are required for each of the three core pillars and the Safety & Control Working Group, and how will these personnel be recruited and managed?

**Assumptions:** Assumption: Each pillar will require a mix of AI researchers, ethicists, software engineers, and project managers. Recruitment will focus on attracting top talent through competitive salaries and research opportunities. A dedicated HR team will manage personnel and ensure effective collaboration. This is based on the typical staffing needs of research-intensive organizations.

**Assessments:** Title: Resource and Personnel Assessment
Description: Evaluation of the human capital required for the project.
Details: Lack of skilled personnel is a significant risk. A clear definition of required expertise and a robust recruitment strategy are essential. A potential benefit is attracting top talent, which can drive innovation and improve the quality of research. Opportunity: Develop a talent pipeline through partnerships with universities and research institutions. Quantifiable metric: Track the number of qualified applicants per open position and the retention rate of key personnel.

## Question 4 - What specific legal structure will the Commission adopt in Switzerland, and how will it ensure compliance with Swiss regulations and ISO standards?

**Assumptions:** Assumption: The Commission will be established as a non-profit association under Swiss law, ensuring compliance with relevant regulations. Legal counsel will be retained to advise on all governance matters and ensure adherence to ISO standards. This is a common legal structure for international organizations in Switzerland.

**Assessments:** Title: Governance and Regulatory Assessment
Description: Analysis of the legal and regulatory framework governing the commission.
Details: Non-compliance with Swiss regulations or ISO standards is a major risk. A clear legal structure and robust compliance program are essential. A potential benefit is establishing a credible and trustworthy organization. Opportunity: Conduct regular legal audits to ensure ongoing compliance. Quantifiable metric: Track the number of regulatory violations or non-compliance incidents per year.

## Question 5 - What specific safety protocols and risk mitigation strategies will be implemented to address potential risks associated with AI research and development, particularly concerning data security and unintended consequences?

**Assumptions:** Assumption: The Commission will adopt industry-standard safety protocols for data security and AI research, including data encryption, access controls, and ethical review boards. Regular risk assessments will be conducted to identify and mitigate potential unintended consequences. This is based on best practices in AI safety and security.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Evaluation of the measures to ensure safety and mitigate risks.
Details: Inadequate safety protocols pose a significant risk to the project and public trust. A comprehensive risk management plan is essential. A potential benefit is minimizing the likelihood of accidents or unintended consequences. Opportunity: Implement a formal incident reporting and investigation process. Quantifiable metric: Track the number of safety incidents or data breaches per year.

## Question 6 - What measures will be taken to assess and minimize the environmental impact of the Commission's operations, including energy consumption, waste management, and carbon footprint?

**Assumptions:** Assumption: The Commission will adopt sustainable practices to minimize its environmental impact, including using renewable energy sources, reducing waste, and offsetting its carbon footprint. An environmental impact assessment will be conducted to identify areas for improvement. This is based on growing awareness of environmental sustainability.

**Assessments:** Title: Environmental Impact Assessment
Description: Analysis of the project's environmental footprint and mitigation strategies.
Details: Ignoring environmental impact can damage the Commission's reputation and undermine its ethical goals. A proactive approach to sustainability is essential. A potential benefit is reducing operating costs and promoting a positive image. Opportunity: Implement a carbon offsetting program. Quantifiable metric: Track the Commission's carbon footprint and waste generation per year.

## Question 7 - How will the Commission engage with diverse stakeholders, including AI developers, ethicists, policymakers, and the public, to ensure their perspectives are considered in the development of AI welfare standards?

**Assumptions:** Assumption: The Commission will establish a stakeholder advisory board representing diverse perspectives. Regular public consultations and workshops will be held to gather feedback and ensure transparency. This is based on best practices in stakeholder engagement.

**Assessments:** Title: Stakeholder Involvement Assessment
Description: Evaluation of the strategies for engaging with relevant stakeholders.
Details: Failure to engage stakeholders can lead to resistance and a lack of adoption of the standards. A comprehensive stakeholder engagement plan is essential. A potential benefit is building trust and ensuring the standards are relevant and practical. Opportunity: Create an online forum for stakeholders to share their views and provide feedback. Quantifiable metric: Track the number of stakeholder engagements and the level of participation in public consultations.

## Question 8 - What specific operational systems and technologies will be implemented to support the Commission's research, collaboration, and standardization efforts, including data management, communication, and project management tools?

**Assumptions:** Assumption: The Commission will implement a cloud-based collaboration platform with secure data management, project management tools, and communication channels. This will facilitate efficient collaboration and knowledge sharing among researchers and stakeholders. This is based on common practices in modern research organizations.

**Assessments:** Title: Operational Systems Assessment
Description: Analysis of the technological infrastructure supporting the project.
Details: Inefficient operational systems can hinder research progress and collaboration. A robust and scalable technology infrastructure is essential. A potential benefit is improving efficiency and reducing administrative overhead. Opportunity: Implement a knowledge management system to capture and share research findings. Quantifiable metric: Track the usage of operational systems and the efficiency of research workflows.

# Distill Assumptions

- 60% of budget to Sentience Metrics, 15% to Adversarial Robustness, 15% to Adoption.
- Each project phase will have specific milestones with quarterly reviews.
- Each pillar needs AI researchers, ethicists, engineers; HR manages personnel.
- Commission will be a Swiss non-profit, ensuring compliance with regulations/ISO.
- Adopt industry-standard safety protocols for data security and AI research.
- Commission will use renewable energy, reduce waste, and offset its carbon footprint.
- Establish a stakeholder advisory board; hold regular public consultations/workshops.
- Implement cloud-based platform with secure data management and project tools.

# Review Assumptions

## Domain of the expert reviewer
Project Management and Risk Assessment for International Scientific and Regulatory Initiatives

## Domain-specific considerations

- International regulatory landscape for AI
- Scientific validity and acceptance of AI sentience metrics
- Stakeholder management across diverse cultural and ethical perspectives
- Long-term funding sustainability for a novel research area
- Data security and ethical considerations in AI research

## Issue 1 - Uncertainty in AI Sentience Metrics Development
The plan assumes the feasibility of developing reliable and robust AI sentience metrics within the project timeline and budget. However, AI sentience is a highly complex and debated topic, and there's no guarantee that accurate and universally accepted metrics can be developed. This uncertainty poses a significant risk to the project's success, as the entire initiative hinges on the ability to measure and assess AI welfare.

**Recommendation:** 1. Conduct a thorough literature review and expert consultation to assess the current state of AI sentience research and identify potential challenges in metric development.
2. Develop a flexible research plan that allows for exploration of multiple metric approaches and adaptation based on research findings.
3. Establish clear criteria for evaluating the validity and reliability of AI sentience metrics, including adversarial robustness testing and independent validation.
4. Allocate a contingency budget specifically for addressing unforeseen challenges in metric development.

**Sensitivity:** If the development of reliable AI sentience metrics is delayed by 12-18 months (baseline: 36 months), the project's ROI could be reduced by 15-25% due to delayed standardization and adoption. The total project cost could increase by $30-50 million due to additional research and development efforts.

## Issue 2 - Funding Sustainability Beyond Initial Mandate
The plan assumes continued funding beyond the initial 3-year mandate, but securing long-term financial support for a novel and potentially controversial research area is not guaranteed. Changes in political priorities, economic downturns, or a lack of demonstrable progress could jeopardize future funding, undermining the project's long-term impact.

**Recommendation:** 1. Develop a diversified funding strategy that includes government grants, philanthropic donations, industry partnerships, and potential revenue-generating activities (e.g., certification programs).
2. Establish a clear value proposition for stakeholders, demonstrating the practical benefits of AI welfare standards for AI developers, policymakers, and the public.
3. Build strong relationships with key funders and communicate progress regularly to maintain their support.
4. Explore the possibility of establishing an endowment fund to provide a stable source of long-term funding.

**Sensitivity:** If long-term funding is not secured after the initial 3-year mandate, the project's ROI could be reduced by 50-70% due to the inability to sustain research and standardization efforts. The project may be forced to scale back its operations or shut down entirely, resulting in a loss of investment.

## Issue 3 - Ethical Disagreements and International Consensus
The plan assumes that international consensus can be reached on the definition of AI welfare and the appropriate level of protection, despite differing ethical frameworks across cultures and organizations. However, ethical disagreements could hinder the development of universally accepted standards, leading to fragmented regulations and a lack of global adoption.

**Recommendation:** 1. Establish a clear ethical framework for the Commission's work, drawing on diverse perspectives and ethical traditions.
2. Foster open dialogue and debate on ethical issues through workshops, conferences, and online forums.
3. Seek to identify common ground and build consensus on core ethical principles, focusing on areas of agreement rather than disagreement.
4. Develop flexible standards that can be adapted to different cultural and ethical contexts while maintaining a core set of principles.

**Sensitivity:** If ethical disagreements prevent the development of universally accepted standards, the project's ROI could be reduced by 20-30% due to limited international adoption. The impact of the standards may be confined to specific regions or countries, undermining the goal of global AI welfare protection.

## Review conclusion
The plan presents a globally ambitious and ethically driven initiative to establish AI sentience and welfare standards. However, the success of the project hinges on addressing key challenges related to AI sentience metrics development, funding sustainability, and ethical disagreements. By implementing the recommendations outlined above, the Commission can mitigate these risks and increase the likelihood of achieving its goals.