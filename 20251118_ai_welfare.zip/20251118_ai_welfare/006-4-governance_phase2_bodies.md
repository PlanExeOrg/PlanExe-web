### 1. Project Steering Committee

**Rationale for Inclusion:** Provides high-level strategic direction and oversight for the AI Sentience & Welfare Commission, given the project's international scope, ethical considerations, and significant funding.

**Responsibilities:**

- Approve the overall project strategy and roadmap.
- Approve annual budgets exceeding $10 million.
- Monitor project progress against strategic goals.
- Oversee strategic risk management and mitigation.
- Approve major changes to project scope or direction.
- Ensure alignment with ISO standards and ethical guidelines.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Committee Chair.
- Establish meeting schedule and communication protocols.
- Review and approve initial project plan and budget.

**Membership:**

- Executive Director of the AI Sentience & Welfare Commission
- Representative from ISO Central Secretariat
- Representative from a major funding philanthropy
- Representative from a participating government (e.g., Switzerland)
- Independent Ethics Expert
- Independent AI Safety Expert

**Decision Rights:** Strategic decisions related to project scope, budget (above $10 million), and direction. Approval of major milestones and risk mitigation strategies.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Committee Chair has the deciding vote. Dissenting opinions are formally recorded in meeting minutes.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review of project progress against strategic goals.
- Discussion of strategic risks and mitigation plans.
- Approval of budget requests exceeding $10 million.
- Review of stakeholder engagement activities.
- Updates from the Executive Director.

**Escalation Path:** Unresolved issues are escalated to the ISO Secretary-General and the board of the funding philanthropy.
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient operation and adherence to the strategic direction set by the Steering Committee.

**Responsibilities:**

- Develop and execute detailed project plans.
- Manage project budget within approved limits (below $10 million).
- Track project progress and report to the Steering Committee.
- Identify and manage operational risks.
- Coordinate activities of research teams and working groups.
- Ensure compliance with relevant regulations and standards.

**Initial Setup Actions:**

- Define roles and responsibilities of team members.
- Establish project management processes and tools.
- Develop a communication plan.
- Set up regular team meetings.

**Membership:**

- Project Manager
- Lead AI Researcher (Sentience Metrics & Theory Program)
- Lead Adversarial Robustness Researcher
- Product & Adoption Team Lead
- Compliance Officer
- Finance Officer

**Decision Rights:** Operational decisions related to project execution, budget management (below $10 million), and resource allocation within approved plans.

**Decision Mechanism:** Decisions made by the Project Manager in consultation with relevant team members. Conflicts are resolved through team discussion and, if necessary, escalated to the Executive Director.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of operational risks and mitigation plans.
- Budget tracking and variance analysis.
- Coordination of team activities.
- Action item review.

**Escalation Path:** Issues exceeding the Project Manager's authority are escalated to the Executive Director.
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on AI sentience metrics, adversarial robustness, and related technical aspects of the project.

**Responsibilities:**

- Review and provide feedback on research proposals and findings.
- Advise on the development of AI sentience metrics and auditing tools.
- Assess the robustness of proposed metrics and identify potential vulnerabilities.
- Provide guidance on technical challenges and emerging technologies.
- Ensure the technical soundness of the project's outputs.

**Initial Setup Actions:**

- Identify and recruit leading AI researchers and technical experts.
- Define the scope of the group's advisory role.
- Establish communication protocols and meeting schedule.
- Review initial research plans and technical specifications.

**Membership:**

- Leading AI Researcher (independent, not directly involved in the Commission's research)
- Expert in Adversarial Machine Learning
- Expert in AI Ethics and Safety
- Software Engineer with experience in AI auditing tools
- Representative from a major AI lab

**Decision Rights:** Provides technical recommendations and assessments. Does not have decision-making authority but its advice strongly informs the Core Project Team and Steering Committee.

**Decision Mechanism:** Recommendations are developed through consensus. Dissenting opinions are documented and presented to the Core Project Team and Steering Committee.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research progress and findings.
- Discussion of technical challenges and potential solutions.
- Assessment of proposed AI sentience metrics.
- Evaluation of adversarial robustness testing results.
- Feedback on the development of AI auditing tools.

**Escalation Path:** Technical disagreements or concerns are escalated to the Steering Committee for resolution.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures the project adheres to the highest ethical standards and complies with all relevant regulations, including GDPR, Swiss data protection laws, and ISO standards.

**Responsibilities:**

- Develop and maintain an ethical framework for the project.
- Review research proposals and activities for ethical concerns.
- Ensure compliance with GDPR and other data protection regulations.
- Monitor adherence to ISO standards and guidelines.
- Investigate and address ethical violations or compliance breaches.
- Provide training and guidance on ethical and compliance matters.

**Initial Setup Actions:**

- Develop a code of ethics for the Commission.
- Establish a data protection compliance plan.
- Define procedures for reporting and investigating ethical violations.
- Recruit members with expertise in ethics, law, and compliance.

**Membership:**

- Independent Ethics Expert (Chair)
- Legal Counsel specializing in data protection and international law
- Compliance Officer
- Representative from the ISO Central Secretariat (Compliance Division)
- Representative from a participating government's regulatory body

**Decision Rights:** Authority to review and approve research proposals from an ethical and compliance perspective. Authority to halt research activities that violate ethical guidelines or compliance regulations. Authority to mandate corrective actions for compliance breaches.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Committee Chair has the deciding vote. Dissenting opinions are formally recorded in meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of research proposals for ethical concerns.
- Discussion of compliance issues and updates.
- Investigation of reported ethical violations.
- Development and review of ethical guidelines and policies.
- Training and education on ethical and compliance matters.

**Escalation Path:** Serious ethical violations or compliance breaches are escalated to the Steering Committee and the ISO Secretary-General.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Facilitates effective communication and engagement with key stakeholders, including AI researchers, ethicists, AI labs, cloud providers, insurers, and the public, to ensure broad support for the project and its outputs.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Organize public consultations and forums.
- Communicate project progress and findings to stakeholders.
- Solicit feedback from stakeholders on research and standards development.
- Address stakeholder concerns and build consensus.
- Manage relationships with key stakeholders.

**Initial Setup Actions:**

- Identify key stakeholders and their interests.
- Develop a communication strategy.
- Establish channels for stakeholder feedback.
- Recruit members with expertise in communication, public relations, and stakeholder management.

**Membership:**

- Communication Officer (Chair)
- Public Relations Specialist
- Stakeholder Management Specialist
- Representative from a major AI lab
- Representative from a participating government's public relations department
- Independent Public Advocate

**Decision Rights:** Advisory role on stakeholder engagement strategies and communication plans. Responsible for executing the stakeholder engagement plan and providing feedback to the Core Project Team and Steering Committee.

**Decision Mechanism:** Recommendations are developed through consensus. Dissenting opinions are documented and presented to the Core Project Team and Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder engagement activities.
- Discussion of stakeholder feedback and concerns.
- Development of communication materials.
- Planning for public consultations and forums.
- Management of relationships with key stakeholders.

**Escalation Path:** Stakeholder concerns that cannot be resolved by the Stakeholder Engagement Group are escalated to the Steering Committee.