This plan implies one or more physical locations.

## Requirements for physical locations

- Office space
- Proximity to ISO Central Secretariat
- Legal entity establishment in Switzerland
- Core team setup

## Location 1
Switzerland

Geneva

Chemin de Blandonnet 8, 1214 Vernier / Geneva, Switzerland

**Rationale**: The plan explicitly anchors the commission physically at ISO's Central Secretariat in Geneva.

## Location 2
Switzerland

Geneva Metro Area

Office spaces near international organizations in Geneva

**Rationale**: Proximity to international organizations and potential partners facilitates collaboration and access to resources.

## Location 3
Switzerland

Zurich

Office spaces near universities and research institutions in Zurich

**Rationale**: Zurich offers access to leading universities and research institutions, fostering innovation and attracting talent.

## Location 4
Switzerland

Lausanne

Office spaces near EPFL (École Polytechnique Fédérale de Lausanne)

**Rationale**: Lausanne, home to EPFL, provides access to cutting-edge AI research and a strong talent pool.

## Location Summary
The primary location is at ISO's Central Secretariat in Geneva. Additional locations in the Geneva metro area, Zurich, and Lausanne are suggested to facilitate collaboration, access resources, and tap into talent pools.