### 1. Project Director drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Project Director drafts initial Terms of Reference (ToR) for the Security Advisory Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Security Advisory Group ToR v0.1

**Dependencies:**


### 3. Project Director drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 4. Project Director drafts initial Terms of Reference (ToR) for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Stakeholder Engagement Group ToR v0.1

**Dependencies:**


### 5. Project Director circulates Draft SteerCo ToR for review by nominated members (Secretary of State, Governor of Vatican City, Chief of Vatican Security, Representative of the Private Benefactor).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 6. Project Director circulates Draft Security Advisory Group ToR for review by nominated members (Chief of Vatican Security, Representative from Italian Police, Independent Security Expert, Cybersecurity Expert, Intelligence Analyst).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Feedback Summary

**Dependencies:**

- Draft Security Advisory Group ToR v0.1
- Nominated Members List Available

### 7. Project Director circulates Draft Ethics & Compliance Committee ToR for review by nominated members (Vatican Legal Counsel, Data Protection Officer, Independent Ethics Advisor, Representative from the Vatican Finance Office).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Feedback Summary

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1
- Nominated Members List Available

### 8. Project Director circulates Draft Stakeholder Engagement Group ToR for review by nominated members (Communications Lead, Media Relations Officer, Community Liaison Officer, Representative from the Vatican Press Office, VIP Liaison Lead).

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Circulation Email
- Feedback Summary

**Dependencies:**

- Draft Stakeholder Engagement Group ToR v0.1
- Nominated Members List Available

### 9. Project Director finalizes the Project Steering Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft SteerCo ToR v0.1

### 10. Project Director finalizes the Security Advisory Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Security Advisory Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Security Advisory Group ToR v0.1

### 11. Project Director finalizes the Ethics & Compliance Committee Terms of Reference based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Ethics & Compliance Committee ToR v0.1

### 12. Project Director finalizes the Stakeholder Engagement Group Terms of Reference based on feedback.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Final Stakeholder Engagement Group ToR v1.0

**Dependencies:**

- Feedback Summary
- Draft Stakeholder Engagement Group ToR v0.1

### 13. Secretary of State (Vatican) formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Secretary of State (Vatican)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 14. Project Director schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Appointment Confirmation Email
- Final SteerCo ToR v1.0

### 15. Hold the initial Project Steering Committee kick-off meeting to review ToR, project goals, and initial plans.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 16. Project Steering Committee formally approves the Security Advisory Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Security Advisory Group ToR

**Dependencies:**

- Final Security Advisory Group ToR v1.0
- Meeting Minutes with Action Items

### 17. Project Steering Committee formally approves the Ethics & Compliance Committee Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Ethics & Compliance Committee ToR

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0
- Meeting Minutes with Action Items

### 18. Project Steering Committee formally approves the Stakeholder Engagement Group Terms of Reference.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved Stakeholder Engagement Group ToR

**Dependencies:**

- Final Stakeholder Engagement Group ToR v1.0
- Meeting Minutes with Action Items

### 19. Chief of Vatican Security (Chair) schedules the initial Security Advisory Group kick-off meeting.

**Responsible Body/Role:** Chief of Vatican Security

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Approved Security Advisory Group ToR

### 20. Vatican Legal Counsel (Chair) schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Vatican Legal Counsel

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Approved Ethics & Compliance Committee ToR

### 21. Communications Lead (Chair) schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Communications Lead

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Approved Stakeholder Engagement Group ToR

### 22. Hold the initial Security Advisory Group kick-off meeting to review ToR and initial security plans.

**Responsible Body/Role:** Security Advisory Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Approved Security Advisory Group ToR

### 23. Hold the initial Ethics & Compliance Committee kick-off meeting to review ToR and relevant regulations.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Approved Ethics & Compliance Committee ToR

### 24. Hold the initial Stakeholder Engagement Group kick-off meeting to review ToR and communication plan.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Approved Stakeholder Engagement Group ToR

### 25. Establish Project Management Office (PMO) and define roles and responsibilities within the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- PMO Setup
- Roles and Responsibilities Matrix

**Dependencies:**


### 26. Set up communication channels for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Communication Channels Established

**Dependencies:**


### 27. Develop initial project schedule for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Initial Project Schedule

**Dependencies:**


### 28. Establish initial risk register for the Core Project Team.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Initial Risk Register

**Dependencies:**


### 29. Hold initial Core Project Team meeting to review project schedule and risk register.

**Responsible Body/Role:** Project Director

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Initial Project Schedule
- Initial Risk Register