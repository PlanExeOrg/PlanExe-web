
## Audit - Corruption Risks

- Bribery of Vatican officials or Italian authorities to expedite permits or overlook security lapses.
- Kickbacks from catering companies or hotel chains in exchange for exclusive contracts.
- Conflicts of interest involving project team members with personal connections to vendors or suppliers.
- Nepotism in hiring security personnel or VIP liaisons, potentially compromising competence.
- Misuse of privileged information regarding VIP movements or security protocols for personal gain or to leak to media outlets.

## Audit - Misallocation Risks

- Inflated invoices from vendors or contractors, with the excess funds diverted for personal use.
- Double-billing for security services or equipment, with the same expenses claimed multiple times.
- Inefficient allocation of security personnel, leading to overstaffing in some areas and understaffing in others.
- Unauthorized use of project funds for personal travel or entertainment.
- Misreporting of progress or results to conceal delays or cost overruns, potentially impacting security preparations.

## Audit - Procedures

- Conduct periodic internal reviews of all financial transactions, with a focus on high-value contracts and expenses, at least monthly.
- Implement a robust expense approval workflow, requiring multiple levels of authorization for all expenditures above a defined threshold (€5,000).
- Perform regular compliance checks to ensure adherence to Italian security regulations and Vatican security protocols, at least quarterly.
- Engage an external auditor to conduct a post-project audit of all financial activities and compliance measures.
- Review all contracts with vendors and suppliers to ensure fair pricing and prevent conflicts of interest, with a threshold of €100,000 for external legal review.

## Audit - Transparency Measures

- Establish a public dashboard displaying key project metrics, including budget allocation, security personnel deployment, and crowd management statistics.
- Publish minutes of key project meetings, including security briefings and logistical planning sessions, on a secure website accessible to stakeholders.
- Implement a whistleblower mechanism allowing individuals to report suspected fraud or corruption anonymously.
- Make relevant project policies and reports, such as the security plan and crowd management plan, publicly available on the Vatican website.
- Document and publish the selection criteria for all major decisions, including vendor selection and security protocol implementation.