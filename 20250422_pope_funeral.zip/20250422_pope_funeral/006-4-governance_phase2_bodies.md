### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for this high-profile, politically sensitive, and logistically complex event.  Ensures alignment with Vatican objectives and manages key strategic risks.

**Responsibilities:**

- Approve overall project strategy and key milestones.
- Oversee budget and resource allocation.
- Monitor and manage strategic risks.
- Resolve high-level conflicts and escalate issues as needed.
- Ensure alignment with Vatican strategic objectives.
- Approve significant changes to project scope or budget (above €500,000).

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- Secretary of State (Vatican)
- Governor of Vatican City
- Chief of Vatican Security
- Representative of the Private Benefactor (Independent)
- Project Director

**Decision Rights:** Strategic decisions related to project scope, budget (above €500,000), key milestones, and risk management.

**Decision Mechanism:** Majority vote, with the Secretary of State holding the tie-breaking vote.

**Meeting Cadence:** Monthly, increasing to bi-weekly in the final two months leading up to the funeral.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion and approval of budget revisions.
- Review of strategic risks and mitigation plans.
- Escalation of unresolved issues.
- Stakeholder updates.

**Escalation Path:** Pope (via Secretary of State).
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring efficient coordination and implementation of the strategic plan.

**Responsibilities:**

- Develop and maintain detailed project plans.
- Manage project budget and resources.
- Coordinate activities across different work streams.
- Monitor project progress and identify potential issues.
- Implement risk mitigation plans.
- Report project status to the Project Steering Committee.
- Make operational decisions within defined thresholds (below €500,000).

**Initial Setup Actions:**

- Establish project management office (PMO).
- Define roles and responsibilities.
- Set up communication channels.
- Develop project schedule.
- Establish risk register.

**Membership:**

- Project Director
- Security Lead
- Logistics Lead
- Communications Lead
- VIP Liaison Lead
- Finance Manager

**Decision Rights:** Operational decisions related to project execution, resource allocation (below €500,000), and risk mitigation within the approved project plan.

**Decision Mechanism:** Consensus-based decision-making, with the Project Director having the final decision-making authority.

**Meeting Cadence:** Weekly, with daily stand-up meetings for specific work streams.

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current issues and risks.
- Coordination of activities across work streams.
- Budget tracking and variance analysis.
- Action item review.

**Escalation Path:** Project Steering Committee.
### 3. Security Advisory Group

**Rationale for Inclusion:** Provides specialized expertise and assurance on all security-related aspects of the project, given the high security risks associated with the event and the presence of high-profile attendees.

**Responsibilities:**

- Review and approve the security plan.
- Provide expert advice on security threats and vulnerabilities.
- Monitor the implementation of security measures.
- Conduct security audits and risk assessments.
- Liaise with international security agencies.
- Advise on dignitary protection protocols.
- Oversee intelligence gathering and analysis.

**Initial Setup Actions:**

- Define scope of security oversight.
- Establish communication protocols.
- Review existing security plans.
- Identify key security risks.

**Membership:**

- Chief of Vatican Security (Chair)
- Representative from Italian Police
- Independent Security Expert (External)
- Cybersecurity Expert
- Intelligence Analyst

**Decision Rights:** Approval of the security plan and recommendations on security-related decisions.

**Decision Mechanism:** Consensus-based decision-making, with the Chief of Vatican Security having the final decision-making authority on operational security matters.

**Meeting Cadence:** Bi-weekly, increasing to weekly in the final month leading up to the funeral.

**Typical Agenda Items:**

- Review of threat assessments.
- Discussion of security vulnerabilities.
- Approval of security protocols.
- Review of security incident reports.
- Updates from international security agencies.

**Escalation Path:** Project Steering Committee.
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical conduct and compliance with all relevant regulations, including GDPR, Italian law, and Vatican policies, given the high level of scrutiny and potential for ethical breaches in a project of this scale.

**Responsibilities:**

- Oversee compliance with GDPR and other data protection regulations.
- Ensure adherence to ethical standards and Vatican policies.
- Review contracts and agreements for compliance.
- Investigate allegations of fraud, corruption, or ethical misconduct.
- Provide training on ethics and compliance to project staff.
- Ensure compliance with Italian law regarding event permits and security regulations.

**Initial Setup Actions:**

- Develop a code of conduct.
- Establish reporting mechanisms.
- Review relevant regulations.
- Define investigation procedures.

**Membership:**

- Vatican Legal Counsel (Chair)
- Data Protection Officer
- Independent Ethics Advisor (External)
- Representative from the Vatican Finance Office

**Decision Rights:** Authority to investigate ethical breaches and recommend corrective actions.  Authority to halt project activities if non-compliance is detected.

**Decision Mechanism:** Majority vote, with the Vatican Legal Counsel holding the tie-breaking vote.

**Meeting Cadence:** Monthly, or as needed to address specific compliance issues.

**Typical Agenda Items:**

- Review of compliance reports.
- Discussion of ethical concerns.
- Investigation of alleged misconduct.
- Updates on relevant regulations.
- Training on ethics and compliance.

**Escalation Path:** Project Steering Committee, Pope (via Secretary of State) for serious ethical breaches.
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including attendees, media, local residents, and protest organizers, to ensure transparency, address concerns, and mitigate potential conflicts.

**Responsibilities:**

- Develop and implement a communication plan.
- Manage relationships with key stakeholders.
- Address stakeholder concerns and feedback.
- Coordinate media relations.
- Engage with protest organizers.
- Provide regular updates to local residents.
- Manage public perception of the event.

**Initial Setup Actions:**

- Identify key stakeholders.
- Establish communication channels.
- Develop messaging guidelines.
- Create a stakeholder database.

**Membership:**

- Communications Lead (Chair)
- Media Relations Officer
- Community Liaison Officer
- Representative from the Vatican Press Office
- VIP Liaison Lead

**Decision Rights:** Decisions related to communication strategy, stakeholder engagement, and media relations.

**Decision Mechanism:** Consensus-based decision-making, with the Communications Lead having the final decision-making authority.

**Meeting Cadence:** Weekly, increasing to daily in the final week leading up to the funeral.

**Typical Agenda Items:**

- Review of communication plan.
- Discussion of stakeholder feedback.
- Coordination of media relations activities.
- Updates on engagement with protest organizers.
- Review of public perception.

**Escalation Path:** Project Steering Committee.