This plan involves money.

## Currencies

- **EUR:** The project budget is specified in Euros, and the primary location is within the Eurozone.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting. Local transactions will also be in EUR, as the project is primarily based in Vatican City and Rome, Italy.