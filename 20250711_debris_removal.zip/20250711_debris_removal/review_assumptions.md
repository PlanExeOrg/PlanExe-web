## Domain of the expert reviewer
International Space Infrastructure & Geopolitical Risk

## Domain-specific considerations

- Regulatory Compliance
- Human Capital Longevity
- Currency Hedging
- Legal Liability

## Issue 1 - Legal Validity of Existing Treaty Interpretations
Assuming existing Outer Space Treaty interpretations suffice for active debris removal is high-risk given the exclusion of major powers like Russia and China. This could lead to legal injunctions halting missions.

**Recommendation:** Develop a parallel diplomatic track to secure bilateral agreements with key non-participants before deployment. Budget explicitly for international legal defense costs separate from operational funds.

**Sensitivity:** Legal disputes could delay missions by 6-12 months each, increasing operational costs by $100M-$200M per delay. A full injunction could reduce total project ROI by 15-20% over the 15-year timeline.

## Issue 2 - Human Capital Sustainability Over 15 Years
Assuming 10% of national agency staff remain committed for 15 years ignores typical turnover rates and political shifts. Knowledge loss could cripple complex hybrid fleet operations.

**Recommendation:** Create a dedicated independent workforce funded directly by the consortium rather than relying solely on seconded national staff. Implement long-term retention bonuses and knowledge transfer protocols.

**Sensitivity:** If staff attrition exceeds 20%, recruitment and specialized training costs could rise by $150M-$250M. Operational delays from critical skill shortages could add 3-6 months to the overall project timeline.

## Issue 3 - Currency and Inflation Contingency Adequacy
A 5% contingency buffer may be insufficient for 15-year currency volatility against USD, especially for long-haul procurement in multiple regions. Inflation could erode purchasing power significantly.

**Recommendation:** Increase financial contingency to 10% and lock in multi-year supplier contracts in local currencies where possible. Diversify reserve holdings beyond USD.

**Sensitivity:** A 10% appreciation in USD against EUR, JPY, or INR could increase international procurement costs by 8-12%, adding $400M-$600M to the budget. Persistent inflation above 3% annually could erode total purchasing power by 5%.

## Review conclusion
The plan relies heavily on optimistic legal and human resource assumptions. Strengthening legal diplomacy, establishing independent staffing, and increasing financial buffers is critical to prevent budget overruns and operational paralysis over the 15-year initiative.