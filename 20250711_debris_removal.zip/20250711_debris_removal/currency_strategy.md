This plan involves money.

## Currencies

- **USD:** Primary currency for NASA consortium member and international reporting.
- **EUR:** Used by ESA partners and operations in French Guiana.
- **JPY:** Relevant for JAXA contributions and procurement in Japan.
- **INR:** Relevant for ISRO contributions and procurement in India.

**Primary currency:** USD

**Currency strategy:** Maintain USD as the primary budgeting currency for consolidated financial reporting. Implement hedging strategies or use financial instruments to manage exchange rate risks for transactions occurring in EUR, JPY, and INR.