
## Question 1 - How will the $20 billion budget be allocated across the 15 years, and what mechanisms are in place to handle currency fluctuations (USD, EUR, JPY, INR)?

**Assumptions:** Assumption: The $20B is secured with a 5% contingency buffer for currency hedging as per currency strategy.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates budget allocation and currency risk management.
Details: Multi-currency exposure introduces volatility risks; hedging strategies can mitigate 5-15% cost increases over the project lifetime, ensuring funding stability for milestone-dependent operations.

## Question 2 - What are the specific milestone triggers for funding releases, and how will the consortium handle potential delays in verification that could impact the launch cadence?

**Assumptions:** Assumption: Verification processes are automated to reduce administrative lag to under 2 weeks per milestone.

**Assessments:** Title: Schedule Feasibility Assessment
Description: Analyzes milestone impact on operational timelines.
Details: Automated metrics reduce delay risks; however, delays could still cost $100-200M per mission due to storage and re-scheduling, necessitating contingency reserves.

## Question 3 - What is the staffing plan for the independent rotating council, and how will technical expertise be sourced for the hybrid fleet manufacturing over the 15-year period?

**Assumptions:** Assumption: Consortium members commit 10% of their relevant space agency staff to the council and operational roles.

**Assessments:** Title: Resource Allocation Assessment
Description: Evaluates human resource availability and expertise.
Details: Staffing levels align with agency capacity for major partners; long-term talent retention risks require competitive engagement strategies to prevent knowledge loss over 15 years.

## Question 4 - How will the consortium navigate legal disputes if non-participating nations contest target selection under existing Outer Space Treaty interpretations?

**Assumptions:** Assumption: Operating under existing treaty interpretations will suffice for initial phases without immediate new treaty ratification.

**Assessments:** Title: Regulatory Compliance Assessment
Description: Assesses legal dispute risks and legitimacy.
Details: Existing treaty use accelerates launch; potential for diplomatic disputes requires a robust liability framework and observer engagement to avoid injunctions or sanctions.

## Question 5 - What specific thresholds will trigger a mission abort to prevent secondary debris generation, and how will these be validated independently?

**Assumptions:** Assumption: Mission abort criteria will be set at >90% collision probability to maximize completion while limiting risk.

**Assessments:** Title: Operational Safety Assessment
Description: Reviews abort criteria effectiveness and verification.
Details: High thresholds protect assets from secondary debris but require strict validation to ensure mission integrity; independent audits must validate these thresholds.

## Question 6 - What measures are planned to ensure the debris removal activities themselves do not create new hazards in the Low Earth Orbit environment?

**Assumptions:** Assumption: Secondary debris generation risk will be kept below 1% per mission through strict abort criteria and verification.

**Assessments:** Title: Orbital Environment Safety Assessment
Description: Focuses on Long-term orbital health and sustainability.
Details: Secondary debris mitigation is critical to preventing Kessler syndrome; strict abort criteria ensures net safety gains per mission.

## Question 7 - How will the consortium engage commercial satellite operators to share telemetry data without compromising national sovereignty or proprietary information?

**Assumptions:** Assumption: Commercial operators will accept anonymized data sharing protocols.

**Assessments:** Title: Stakeholder Cooperation Assessment
Description: Evaluates data sharing feasibility and operator trust.
Details: Anonymized protocols mitigate sovereignty concerns; operator resistance could increase collision risks during removal if traffic coordination fails.

## Question 8 - What redundancy plans exist for ground station communication if a primary site (e.g., Kourou or Canberra) becomes unavailable during critical operations?

**Assumptions:** Assumption: Ground stations have redundant links via commercial leasing if member facilities fail.

**Assessments:** Title: System Redundancy Assessment
Description: Reviews ground station reliability and continuity.
Details: Commercial leasing ensures global coverage; redundancy prevents telemetry loss during critical maneuvers which could lead to aborted missions or debris generation.