### 1. Project Manager drafts initial Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start

### 2. Circulate Draft SteerCo ToR for review by nominated members (Senior representatives from NASA, ESA, JAXA, ISRO, Representative from commercial stakeholder group, Independent expert in space law and policy).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Senior Sponsor formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Senior Sponsor formally appoints the Vice-Chair of the Project Steering Committee.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 6. Senior Sponsor formally confirms all members of the Project Steering Committee.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final SteerCo ToR v1.0

### 7. Project Steering Committee Chair schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee Chair

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 8. Hold initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 9. Project Manager drafts initial Terms of Reference for the Project Management Office (PMO).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PMO ToR v0.1

**Dependencies:**

- Project Start

### 10. Circulate Draft PMO ToR for review by nominated members (Project Manager, Deputy Project Manager, Representatives from each participating space agency (technical leads), Financial Controller, Risk Manager, Communications Manager).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft PMO ToR v0.1
- Nominated Members List Available

### 11. Project Manager finalizes the Terms of Reference for the Project Management Office (PMO) based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final PMO ToR v1.0

**Dependencies:**

- Feedback Summary

### 12. Senior Sponsor formally confirms all members of the Project Management Office (PMO).

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final PMO ToR v1.0

### 13. Project Manager schedules the initial Project Management Office (PMO) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 14. Hold initial Project Management Office (PMO) kick-off meeting & assign initial tasks.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 15. Project Manager drafts initial Terms of Reference for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG ToR v0.1

**Dependencies:**

- Project Start

### 16. Circulate Draft TAG ToR for review by nominated members (Independent experts in robotics, laser technology, space debris tracking, orbital mechanics, Representatives from each participating space agency (technical experts), Independent expert in environmental impact assessment).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft TAG ToR v0.1
- Nominated Members List Available

### 17. Project Manager finalizes the Terms of Reference for the Technical Advisory Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Final TAG ToR v1.0

**Dependencies:**

- Feedback Summary

### 18. Senior Sponsor formally appoints the Chair of the Technical Advisory Group.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final TAG ToR v1.0

### 19. Senior Sponsor formally confirms all members of the Technical Advisory Group.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final TAG ToR v1.0

### 20. Technical Advisory Group Chair schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 21. Hold initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 22. Project Manager drafts initial Terms of Reference for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft ECC ToR v0.1

**Dependencies:**

- Project Start

### 23. Circulate Draft ECC ToR for review by nominated members (Independent legal expert specializing in international law, Independent ethics expert, Representative from each participating space agency (legal counsel), Data Protection Officer, Representative from commercial stakeholder group (compliance officer), Independent expert in international relations).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft ECC ToR v0.1
- Nominated Members List Available

### 24. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Final ECC ToR v1.0

**Dependencies:**

- Feedback Summary

### 25. Senior Sponsor formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final ECC ToR v1.0

### 26. Senior Sponsor formally confirms all members of the Ethics & Compliance Committee.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final ECC ToR v1.0

### 27. Ethics & Compliance Committee Chair schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 28. Hold initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda

### 29. Project Manager drafts initial Terms of Reference for the Stakeholder Engagement Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Draft SEG ToR v0.1

**Dependencies:**

- Project Start

### 30. Circulate Draft SEG ToR for review by nominated members (Communications Manager, Public Relations Officer, Representatives from each participating space agency (stakeholder engagement leads), Representative from commercial stakeholder group (public affairs), Independent expert in international relations, Independent expert in public opinion research).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary

**Dependencies:**

- Draft SEG ToR v0.1
- Nominated Members List Available

### 31. Project Manager finalizes the Terms of Reference for the Stakeholder Engagement Group based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final SEG ToR v1.0

**Dependencies:**

- Feedback Summary

### 32. Senior Sponsor formally appoints the Chair of the Stakeholder Engagement Group.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SEG ToR v1.0

### 33. Senior Sponsor formally confirms all members of the Stakeholder Engagement Group.

**Responsible Body/Role:** Senior Sponsor

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Membership Confirmation List

**Dependencies:**

- Final SEG ToR v1.0

### 34. Stakeholder Engagement Group Chair schedules the initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group Chair

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- Membership Confirmation List

### 35. Hold initial Stakeholder Engagement Group kick-off meeting.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation
- Agenda