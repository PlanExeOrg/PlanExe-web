A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Operating under existing Outer Space Treaty interpretations will suffice for target selection without new treaty ratification. | Obtain written legal clearance opinions from General Counsel regarding existing treaty interpretations. | General Counsel confirms legal risk of injunctions exceeding 50% from non-participating nations. |
| A2 | 10kW ground-based lasers are effective regardless of atmospheric conditions. | Complete independent physics review of laser capabilities. | Physics review shows effectiveness below 70% under standard atmospheric turbulence. |
| A3 | A $500M reserve fund is sufficient to cover state-to-state liability limits. | Stress test fund against catastrophic state-to-state claims. | Stress test shows reserves cover only 50% of catastrophic scenarios. |
| A4 | Specialized suppliers for robotic arms and laser optics will maintain capacity and pricing over 15 years without obsolescence issues. | Secure long-term contracts for critical components with obsolescence clauses. | Suppliers confirm production capacity limits or price hikes exceeding 15% within 2 years. |
| A5 | Commercial satellite operators will consistently share anonymized telemetry data for traffic management without sovereignty concerns. | Negotiate binding data sharing contracts with three major operators. | Operators reject data sharing protocols citing proprietary or sovereign rights. |
| A6 | Consortium members will commit staff to operational roles without significant attrition or political shifts over the 15-year timeline. | Audit staff retention rates of seconded personnel annually. | Attrition rates exceed 20% annually in key engineering or legal roles. |
| A7 | Ground station power grids at primary launch sites maintain 99.9% uptime during critical operations. | Audit historical power grid reliability data for Kourou and Canberra sites. | Historical data shows power outages exceeding 1 hour within critical launch windows. |
| A8 | Independent third-party audit firms have sufficient global capacity to verify all 500 removal milestones within the planned fiscal timeline. | Request capacity letters from top 5 global space verification agencies. | Verified agencies confirm capacity limits preventing concurrent 500-object verification. |
| A9 | Political leadership in key consortium nations remains supportive across 3-4 election cycles without significant funding shifts. | Analyze current fiscal year budget commitments for partner space agencies. | Partner budgets show reduction greater than 20% for the next fiscal cycle. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Liability Liquidity Event | Process/Financial | A3 | Financial Controller | CRITICAL (20/25) |
| FM2 | The Atmospheric Failure Cascade | Technical/Logistical | A2 | Space Systems Architect | CRITICAL (15/25) |
| FM3 | The Legal and Coalition Fracture | Market/Human | A1 | Geopolitical Strategy Lead | CRITICAL (20/25) |
| FM4 | The Obsolescence Trap | Technical/Logistical | A4 | Supply Chain Director | CRITICAL (15/25) |
| FM5 | The Data Silo Crisis | Market/Human | A5 | Stakeholder Engagement Manager | CRITICAL (20/25) |
| FM6 | The Knowledge Drain | Process/Financial | A6 | Consortium Program Director | CRITICAL (16/25) |
| FM7 | The Power Grid Blackout | Technical/Logistical | A7 | IT Director | CRITICAL (15/25) |
| FM8 | The Verification Bottleneck | Process/Financial | A8 | Financial Controller | CRITICAL (20/25) |
| FM9 | The Political Cycle Cliff | Market/Human | A9 | Consortium Program Director | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Liability Liquidity Event

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
A catastrophic mission failure damages a commercially owned satellite belonging to a non-participating state. Under the 1972 Liability Convention, the consortium faces state-to-state claims far exceeding the $500M reserve. Legal defense costs spike, budget reserves are drained, and subsequent funding approvals are stalled as members resist uncapped liability exposure.

##### Early Warning Signs
- Liability claims exceed $250M reserve by Year 3
- Insurance premiums increase by 30% without intervention

##### Tripwires
- Reserve fund drawdown >= 50% before end of Year 3
- Total confirmed claims exceed $500M reserve

##### Response Playbook
- Contain: Freeze all non-essential payments and cap reserve disbursements.
- Assess: Conduct rapid audit of exposure and potential state liability.
- Respond: Secure emergency sovereign guarantees from consortium members.


**STOP RULE:** Liability claims exceed 2x total reserve fund and sovereign guarantees are not secured within 30 days.

---

#### FM2 - The Atmospheric Failure Cascade

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Space Systems Architect
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Ground-based laser systems fail to generate sufficient momentum transfer on debris due to unaccounted atmospheric turbulence. Operational efficiency drops below viable thresholds. The hybrid fleet is deemed ineffective for large debris targets. Budget is wasted on hardware, delivery schedules slip, and technical targets are not met.

##### Early Warning Signs
- Laser mission success rate drops below 60% in first 10 operations
- Hardware delivery delays exceed 18 months

##### Tripwires
- Laser effectiveness rate < 60% over first 10 missions
- Hardware deployment delay >= 12 months

##### Response Playbook
- Contain: Pause all laser operations and switch to backup capture systems.
- Assess: Commission independent physics review and atmospheric data analysis.
- Respond: Reallocate funds toward space-based laser node prototypes.


**STOP RULE:** Laser effectiveness rate remains < 50% after 20 operational attempts.

---

#### FM3 - The Legal and Coalition Fracture

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Geopolitical Strategy Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Non-participating nations contest removal of debris linked to their historic registration. International legal injunctions halt operations for extended periods. Trust in the rotating council erodes as transparency is questioned. Key members withdraw, causing political stalemate and funding collapse across the coalition.

##### Early Warning Signs
- Number of formal legal challenges reaches 2 within 24 months
- Key member nations suspend financial contributions

##### Tripwires
- Legal injunctions >= 2 within first 24 months
- Consortium membership drops below 4 major agencies

##### Response Playbook
- Contain: Halt targeted removal missions pending diplomatic review.
- Assess: Evaluate political risk and treaty interpretation validity.
- Respond: Initiate emergency bilateral negotiations for observer status.


**STOP RULE:** Three or more consortium nations formally withdraw from the initiative.

---

#### FM4 - The Obsolescence Trap

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Supply Chain Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Hardware components face rapid obsolescence or supplier capacity shrinkage. Redesigns become necessary mid-cycle, delaying launches and inflating costs. This breaks the launch cadence schedule and consumes contingency reserves.

##### Early Warning Signs
- Hardware delivery delayed >= 6 months beyond contract dates
- Redesign costs exceed $200M per mission

##### Tripwires
- Hardware delivery delay >= 6 months
- Component redesign cost > $200M

##### Response Playbook
- Contain: Halt procurement of affected components immediately.
- Assess: Audit supplier contracts and identify alternative sources.
- Respond: Pivot to backup suppliers or redesign mission hardware profile.


**STOP RULE:** Total redesign costs exceed 10% of remaining operational budget.

---

#### FM5 - The Data Silo Crisis

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Stakeholder Engagement Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Operators resist telemetry sharing due to sovereignty or proprietary concerns. Traffic coordination fails, increasing collision risk during missions. Non-cooperators damage debris removal assets and blame the consortium.

##### Early Warning Signs
- Telemetry data sharing rate < 50% of target
- Collision near-miss count > 50 within 24 months

##### Tripwires
- Telemetry share rate < 50%
- Collision near-miss count >= 50

##### Response Playbook
- Contain: Escalate concerns to consortium legal and geopolitical leads.
- Assess: Quantify liability risks of missing operator data.
- Respond: Negotiate compensation mechanisms or deploy autonomous avoidance.


**STOP RULE:** Data coverage drops below 40% for critical LEO orbits.

---

#### FM6 - The Knowledge Drain

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Consortium Program Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
Staff attrition or political shifts reduce commitment to consortium roles. Institutional memory is lost, leading to decision errors and rework. Hiring costs skyrocket as specialized expertise is replaced.

##### Early Warning Signs
- Key role vacancy rate > 20% in operational teams
- Training cost overrun exceeds 15% annually

##### Tripwires
- Key role vacancy rate > 20%
- Training cost overrun > 15%

##### Response Playbook
- Contain: Freeze non-essential hiring and reassign critical tasks.
- Assess: Audit retention drivers and skill gap risks.
- Respond: Launch retention bonuses and external consultancy support.


**STOP RULE:** Core staff attrition exceeds 30% within a single fiscal year.

---

#### FM7 - The Power Grid Blackout

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: IT Director
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Critical ground station infrastructure suffers power outages during active laser or telemetry operations. Signal loss prevents capture commands, risking mission abort or secondary debris generation. Redundant systems fail to activate quickly enough to preserve orbital safety protocols.

##### Early Warning Signs
- Power uptime drops below 98% during non-critical operations
- Unplanned backup generator tests fail

##### Tripwires
- Power outage >= 1 hour during active capture window
- Redundant power switch time > 30 minutes

##### Response Playbook
- Contain: Switch to mobile backup power generators immediately.
- Assess: Diagnose root cause of grid instability.
- Respond: Implement hardening upgrades for critical ground sites.


**STOP RULE:** Multiple ground stations fail power requirements during active missions and backup systems are unavailable.

---

#### FM8 - The Verification Bottleneck

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Financial Controller
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Third-party auditors lack capacity to process removal proofs at the required cadence. Milestone verification stalls, delaying budget releases. Manufacturing partners halt production due to lack of funds, breaking the launch schedule and creating operational gaps.

##### Early Warning Signs
- Audit cycle time exceeds 30 days per mission
- Consortium budget reserves drop below 15%

##### Tripwires
- Milestone verification delay > 30 days
- Budget release paused > 45 days

##### Response Playbook
- Contain: Halt non-essential spending to conserve remaining cash.
- Assess: Identify alternative rapid verification vendors.
- Respond: Secure emergency interim funding from consortium members.


**STOP RULE:** Funding delays exceed 90 days consecutively causing manufacturing shutdown.

---

#### FM9 - The Political Cycle Cliff

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Consortium Program Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Change in government priorities in key member states reduces funding commitments. Withdrawal triggers budget shortfalls and erodes coalition trust. Remaining partners face increased costs, causing further attrition and stalling the initiative mid-timeline.

##### Early Warning Signs
- Partner space agency budget proposals reduced by >15%
- Political opposition statements against space spending emerge

##### Tripwires
- Budget contribution reduced > 20% in one cycle
- Number of funding partners drops below 3

##### Response Playbook
- Contain: Suspend new mission planning pending funding review.
- Assess: Recalculate financial viability without withdrawn funding.
- Respond: Secure alternative funding from commercial partners.


**STOP RULE:** Two or more key nations withdraw funding simultaneously.
