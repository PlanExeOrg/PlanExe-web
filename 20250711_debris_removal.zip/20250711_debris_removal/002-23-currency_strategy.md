This plan involves money.

## Currencies

- **USD:** Primary currency for the overall project budget and international transactions.
- **EUR:** Relevant for ESA contributions and operations in French Guiana.
- **JPY:** Relevant for JAXA contributions and operations in Japan.
- **INR:** Relevant for ISRO contributions and operations in India.

**Primary currency:** USD

**Currency strategy:** USD will be used for the overall project budget and reporting. Exchange rates should be monitored, and hedging strategies considered to mitigate currency fluctuations. EUR, JPY, and INR will be used for local transactions within Europe, Japan, and India, respectively.