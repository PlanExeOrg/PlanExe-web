**Purpose:** business

**Purpose Detailed:** Large-scale societal initiative focused on space debris removal, satellite infrastructure protection, and international space governance.

**Topic:** Space debris removal initiative