## Primary Decisions
The vital few decisions that have the most impact.


The prioritization centers on governance, capital, and target selection to address the core tension between speed and coalition trust. Critical levers prioritize independent oversight and precise prioritization to mitigate geopolitical risks while ensuring fiscal discipline sustains the fifteen-year initiative despite technical constraints.

### Decision 1: Target Prioritization Logic
**Lever ID:** `8d43a031-a9ad-4da9-aeb7-a7e238c093e6`

**The Core Decision:** This lever defines the criteria for selecting debris objects, balancing immediate collision probability against long-term kinetic energy risks. Success is measured by risk reduction per dollar spent and the avoidance of catastrophic chain reactions. It ensures resources target the most dangerous threats first while maintaining orbital safety sustainability.

**Why It Matters:** Focusing on highest collision probability objects maximizes immediate risk reduction per dollar spent, but ignoring larger debris with lower collision rates leaves long-term kinetic energy risks unresolved. This trade-off determines whether the mission achieves quick wins or sustainable orbital safety.

**Strategic Choices:**

1. Prioritize objects with the highest calculated collision probability regardless of mass or kinetic energy potential
2. Select targets based on a combination of collision probability and total kinetic energy to address worst-case scenarios
3. Focus exclusively on debris threatening active satellite constellations to demonstrate immediate tangible value to stakeholders

**Trade-Off / Risk:** Prioritizing collision probability over kinetic energy accelerates early risk reduction metrics but leaves massive objects capable of catastrophic chain reactions untouched until later phases.

**Strategic Connections:**

**Synergy:** Amplifies Mission Success Metrics by aligning targets with verifiable risk reduction goals. It also supports Capital Allocation Model by justifying spending on high-probability threats early.

**Conflict:** Constrains Traffic Management Protocol if high-priority targets require complex coordination with active satellites. It may also conflict with Removal Technology Mix if chosen targets demand specific capture methods.

**Justification:** *Critical*, Defines core strategy balancing immediate risk vs long-term stability. Its synergy with Metrics and Capital ensures funding aligns with highest-impact targets, central to mission viability.

### Decision 2: Removal Technology Mix
**Lever ID:** `788a1e57-ba6c-4418-a079-deb25e86b92f`

**The Core Decision:** This lever selects the combination of robotic capture and laser mitigation technologies to execute debris removal. Key metrics include mission duration per object, regulatory compliance, and engagement speed. It determines operational efficiency and influences dual-use scrutiny levels across participating nations.

**Why It Matters:** Deploying robotic capture systems allows for precise debris disposal but requires complex rendezvous and capture maneuvers that increase mission duration per object. Laser mitigation offers faster engagement times but faces stricter dual-use scrutiny and atmospheric interference limitations.

**Strategic Choices:**

1. Invest primarily in robotic capture systems to ensure precise debris disposal and minimize regulatory scrutiny regarding weaponization concerns
2. Allocate significant resources to precision laser ground stations for rapid engagement despite increased dual-use policy and atmospheric interference challenges
3. Develop a hybrid fleet combining both robotic spacecraft and ground lasers to balance precision with engagement speed across different debris types

**Trade-Off / Risk:** Relying heavily on ground lasers reduces spacecraft complexity but introduces atmospheric interference and dual-use regulatory hurdles that could delay deployment in certain national jurisdictions.

**Strategic Connections:**

**Synergy:** Enables Ground Station Access Policy by requiring infrastructure for laser systems. It also supports Dual-Use Safeguard Implementation by choosing less controversial robotic options over weapons-like lasers.

**Conflict:** Conflicts with Capital Allocation Model due to high upfront costs for hybrid fleets. It may also clash with Oversight Framework Design if laser choices raise independent risk assessment concerns.

**Justification:** *High*, Controls dual-use scrutiny and operational speed. Conflicts with Capital Allocation highlight budget trade-offs, while synergy with Safeguards ensures compliance with international disarmament laws essential for coalition stability.

### Decision 3: Oversight Framework Design
**Lever ID:** `6cb59885-4db4-4a05-9b04-214f9d1e7ac7`

**The Core Decision:** This lever establishes how target selection and risk assessment are monitored to ensure transparency and trust. Success depends on balancing administrative speed with credibility among non-participating states. It prevents bias in targeting and maintains coalition integrity throughout the fifteen-year initiative.

**Why It Matters:** Establishing a fully independent risk model enhances credibility among non-participating states but introduces administrative overhead that slows target selection decisions. Embedding oversight within member agencies speeds up decisions but raises concerns about bias in target selection for national assets.

**Strategic Choices:**

1. Establish a fully independent third-party risk assessment body to maximize transparency and credibility among non-participating states
2. Embed oversight functions within existing member agency structures to accelerate target selection decisions and reduce administrative overhead costs
3. Create a rotating council of independent experts from non-aligned nations to verify target selection without slowing down operational decision-making processes

**Trade-Off / Risk:** A fully independent body maximizes trust but adds administrative layers that can slow target selection decisions compared to embedding oversight within existing member agency structures.

**Strategic Connections:**

**Synergy:** Strengthens Legal Precedent Establishment Path by demonstrating fair governance. It also supports Verification and Validation Standards by providing independent checks on mission outcomes.

**Conflict:** Constrains Launch Cadence Scheduling if independent reviews slow decision-making. It may also conflict with Capital Allocation Model if oversight costs consume funds meant for operations.

**Justification:** *Critical*, Governs coalition trust among nations without mutual trust. Independent review slows decisions but prevents bias conflicts, ensuring long-term legitimacy critical for sustained international cooperation over fifteen years.

### Decision 4: Capital Allocation Model
**Lever ID:** `51d3cca1-ac0a-4564-b371-c763a6b65360`

**The Core Decision:** This lever determines how funds are distributed over time to balance early momentum with long-term sustainability. Success is measured by milestone achievement and budget longevity. It ensures financial discipline while allowing flexibility for unexpected debris emergence or technological shifts.

**Why It Matters:** Front-loading capital for early missions builds momentum but risks budget exhaustion before long-term debris reduction goals are met. Phased funding tied to milestone verification ensures fiscal discipline but may slow initial spacecraft manufacturing and launch cadence.

**Strategic Choices:**

1. Front-load capital expenditure for initial missions to build operational momentum and demonstrate early success to coalition stakeholders
2. Tie funding releases to verified removal milestones to ensure fiscal discipline across the full fifteen-year initiative timeline
3. Allocate reserves for unexpected debris emergence events to maintain operational flexibility without requiring constant coalition budget renegotiation

**Trade-Off / Risk:** Front-loading capital accelerates early momentum but risks depleting the budget before long-term debris reduction targets are achieved if initial mission costs overrun.

**Strategic Connections:**

**Synergy:** Supports Mission Success Metrics by funding verified removal milestones. It also enables Launch Cadence Scheduling by providing timely resources for manufacturing and deployment.

**Conflict:** Conflicts with Removal Technology Mix if hybrid fleets exceed budget limits. It may also clash with Oversight Framework Design if funding ties slow administrative processes.

**Justification:** *High*, Balances early momentum with fiscal discipline across timeline. Conflicts with Tech Mix limit fleet scope, while synergy with Metrics validates spending to maintain investor confidence during critical fifteen-year initiative phases.

### Decision 5: Mission Success Metrics
**Lever ID:** `a8d034ec-6711-469c-a5fe-57dfb97e4b9a`

**The Core Decision:** Defines how the initiative measures achievement, balancing tangible object removal with overall risk reduction. It ensures political accountability while maintaining operational flexibility. Success criteria must align with safety goals and stakeholder expectations to validate the program's effectiveness and justify continued investment over the fifteen-year timeline.

**Why It Matters:** Defining success as the removal of 500 specific objects provides clear targets but ignores newly generated debris from explosions or collisions during the mission. Defining success as risk reduction below a threshold allows flexibility but lacks the tangible milestones needed for political accountability.

**Strategic Choices:**

1. Define success strictly as the physical removal of the 500 pre-identified critical debris threats to ensure clear accountability
2. Define success as reducing overall collision risk below a specific threshold regardless of which specific objects are removed or neutralized
3. Adopt a dual metric approach requiring both specific object removal and risk reduction targets to satisfy political and safety stakeholders

**Trade-Off / Risk:** Defining success strictly by object count ignores new risks generated during operations while risk reduction thresholds lack the tangible milestones needed for political accountability.

**Strategic Connections:**

**Synergy:** Amplifies Target Prioritization Logic by ensuring selected objects directly contribute to defined risk thresholds. It also supports Verification and Validation Standards by providing clear benchmarks for third-party audit and proof of mission completion.

**Conflict:** Conflicts with Launch Cadence Scheduling if rapid deployment pressures lead to cutting corners on verification. It may also strain Oversight Framework Design if metrics become too complex for independent monitoring bodies to track effectively.

**Justification:** *High*, Sets accountability standards for removal versus risk reduction. Conflicts with Launch Cadence if verification is too strict, but synergy with Prioritization ensures goals match tangible outcomes required for political survival.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Traffic Management Protocol
**Lever ID:** `a6ca7274-5556-4ce1-9767-5a25e7587940`

**The Core Decision:** This lever coordinates satellite movements during removal operations to prevent new debris generation. Key metrics include collision avoidance rates and data sharing compliance. It balances operational safety with national sovereignty concerns regarding sensitive orbital telemetry exchange.

**Why It Matters:** Centralizing traffic coordination prevents unintended collisions during removal but requires all operators to share sensitive orbital data which may face resistance. Distributed coordination respects sovereignty but increases the risk of uncoordinated maneuvers leading to new debris generation.

**Strategic Choices:**

1. Centralize traffic coordination authority within the consortium to prevent unintended collisions during removal operations despite data sharing resistance
2. Implement distributed coordination protocols that respect national sovereignty while requiring minimal data exchange to reduce collision risks
3. Mandate real-time telemetry sharing from all participating satellite operators to enable proactive avoidance maneuvers during active debris removal missions

**Trade-Off / Risk:** Centralizing coordination prevents collisions effectively but requires sensitive data sharing that may face resistance from operators protecting proprietary orbital maneuver information.

**Strategic Connections:**

**Synergy:** Enhances Asset Protection Liability Framework by reducing collision risks during operations. It also supports Mission Abort Criteria by providing real-time collision warnings.

**Conflict:** Conflicts with Ground Station Access Policy if data sharing restrictions limit coordination. It may also clash with Target Prioritization Logic if high-priority targets lack operator cooperation.

**Justification:** *Medium*, Coordinates active satellites but requires data sharing. Conflicts with Ground Station Policy if restrictions apply, yet essential for operational safety during removal without creating new collision risks temporarily.

### Decision 7: Launch Cadence Scheduling
**Lever ID:** `0643c152-e6d7-4374-be52-8d25b17af139`

**The Core Decision:** Determines the timing and frequency of spacecraft deployments to balance speed against resource constraints. This lever optimizes manufacturing throughput and budget utilization while minimizing orbital decay risks. Effective scheduling ensures continuous coverage without overwhelming supply chains or causing logistical bottlenecks during critical mission phases.

**Why It Matters:** Rapid deployment reduces orbital congestion quickly but strains manufacturing capacity and increases launch costs. Staggered launches ease financial pressure but allow debris to drift into higher-risk orbits.

**Strategic Choices:**

1. Deploy all spacecraft in rapid succession to minimize orbital decay risks and ensure early safety gains.
2. Stagger launches across five-year intervals to align with budget cycles and reduce manufacturing pressure on suppliers.
3. Prioritize early missions for high-value targets to demonstrate immediate value and secure critical asset protection.

**Trade-Off / Risk:** Rapid deployment reduces orbital congestion quickly but strains manufacturing capacity and increases launch costs, while staggered launches ease financial pressure but allow debris to drift into higher-risk orbits.

**Strategic Connections:**

**Synergy:** Enables Removal Technology Mix by aligning hardware availability with launch windows. It also supports Capital Allocation Model by smoothing out expenditure peaks and aligning costs with fiscal cycles for better financial planning.

**Conflict:** Conflicts with Target Prioritization Logic if urgent launches force suboptimal target selection. It may also contradict Post-Mission Disposal Mandate if rushed schedules neglect proper end-of-life planning for launched assets.

**Justification:** *Medium*, Optimizes deployment speed against capacity limits. Conflicts with Tech Mix on costs, but synergy with Capital Model smooths expenditure peaks to manage manufacturing pressure effectively over the long-term.

### Decision 8: Dual-Use Safeguard Implementation
**Lever ID:** `28d00577-3681-431d-a968-ce83a877af07`

**The Core Decision:** Establishes controls to prevent space debris removal assets from being repurposed as weapons. This lever balances security needs with operational efficiency, ensuring compliance with international laws. Effective safeguards maintain trust among coalition members and prevent escalation, protecting the initiative's legitimacy and long-term sustainability against geopolitical suspicion.

**Why It Matters:** Physical locks prevent unauthorized hardware use but add weight and complexity to spacecraft. Software kill-switches allow rapid deactivation but depend on secure communication links.

**Strategic Choices:**

1. Install physical locks on all laser targeting systems to prevent weaponization of the debris removal assets.
2. Implement software kill-switches that disable offensive capabilities remotely to ensure compliance with international disarmament laws.
3. Mandate independent third-party audits of all guidance software code to verify safety protocols before launch.

**Trade-Off / Risk:** Physical locks prevent unauthorized hardware use but add weight and complexity to spacecraft, while software kill-switches allow rapid deactivation but depend on secure communication links.

**Strategic Connections:**

**Synergy:** Supports Legal Precedent Establishment Path by demonstrating compliance with disarmament norms. It also reinforces Oversight Framework Design by providing clear mechanisms for independent verification of non-offensive capabilities.

**Conflict:** Conflicts with Removal Technology Mix if safeguards add excessive weight or complexity to hardware. It may also hinder Launch Cadence Scheduling if additional testing and audit requirements delay deployment timelines.

**Justification:** *High*, Addresses geopolitical trust explicitly by preventing weaponization. Conflicts with Tech Mix on hardware complexity, but synergy with Legal Precedent ensures compliance necessary for coalition cohesion and international legal safety.

### Decision 9: Asset Protection Liability Framework
**Lever ID:** `191f268a-1f4c-4228-a59a-74b4fedb2011`

**The Core Decision:** Defines how financial risks associated with satellite damage are distributed among consortium members and commercial operators. This lever protects public budgets while ensuring victims receive compensation. Clear liability terms encourage participation and reduce legal friction, enabling smoother operations and fostering trust between government agencies and private satellite owners.

**Why It Matters:** Collective underwriting spreads risk across agencies but requires complex inter-agency financial agreements. A dedicated fund reduces agency burden but relies on commercial participation willingness.

**Strategic Choices:**

1. Require consortium members to underwrite all satellite damage claims collectively to ensure equitable risk distribution among partners.
2. Establish a dedicated insurance fund funded by commercial satellite operators to externalize liability costs from public budgets.
3. Limit liability to direct collision damages only, excluding indirect operational losses to reduce legal exposure for agencies.

**Trade-Off / Risk:** Collective underwriting spreads risk across agencies but requires complex inter-agency financial agreements, while a dedicated fund reduces agency burden but relies on commercial participation willingness.

**Strategic Connections:**

**Synergy:** Supports Capital Allocation Model by clarifying risk exposure and funding requirements. It also reinforces Oversight Framework Design by establishing clear accountability lines for financial disputes during operations.

**Conflict:** Conflicts with Legal Precedent Establishment Path if new treaties override existing liability assumptions. It may also strain Ground Station Access Policy if legal uncertainties prevent shared infrastructure usage between partners and international stakeholders.

**Justification:** *Medium*, Manages financial risk for damage claims. Conflicts with Legal Precedent if treaties override assumptions, but supports Capital Model by clarifying exposure to stabilize commercial participation incentives.

### Decision 10: Legal Precedent Establishment Path
**Lever ID:** `188fb058-0b50-464a-8de2-b07891cfe405`

**The Core Decision:** Determines the legal basis for operations, balancing new treaties against existing interpretations. This lever ensures international legitimacy while allowing timely deployment. Choosing the right path minimizes legal disputes and fosters cooperation, securing the initiative's right to operate in shared orbital environments without triggering diplomatic conflicts or regulatory delays.

**Why It Matters:** New treaties create clear rules but take decades to ratify and may stall immediate action. Operating under existing treaties allows faster launches but invites legal disputes over interpretation.

**Strategic Choices:**

1. Draft new treaties specifically governing active debris removal operations to establish clear international norms for future missions.
2. Operate under existing Outer Space Treaty interpretations with formal notifications to accelerate deployment without waiting for ratification.
3. Seek bilateral agreements with key affected nations for each mission to ensure specific consent from satellite owners.

**Trade-Off / Risk:** New treaties create clear rules but take decades to ratify and may stall immediate action, while operating under existing treaties allows faster launches but invites legal disputes over interpretation.

**Strategic Connections:**

**Synergy:** Supports Dual-Use Safeguard Implementation by providing a legal framework for non-proliferation norms. It also reinforces Traffic Management Protocol by establishing clear rules for interaction with other space assets.

**Conflict:** Conflicts with Launch Cadence Scheduling if treaty negotiations delay deployment. It may also hinder Mission Success Metrics if legal ambiguities prevent clear definition of acceptable operational outcomes.

**Justification:** *High*, Determines legitimacy under existing or new treaties. Conflicts with Cadence if negotiations stall, but supports Traffic Protocol by establishing interaction rules essential for shared orbital environment access globally.

### Decision 11: Ground Station Access Policy
**Lever ID:** `250151f1-0a68-4adb-b3f0-e4ad460ccdfc`

**The Core Decision:** This lever defines communication infrastructure strategies, balancing security against geographic coverage. It dictates whether member nations control stations or commercial leases are used. Success depends on maintaining reliable telemetry during critical maneuvers while minimizing third-party dependencies that could compromise operational security or introduce bottlenecks during high-stakes debris capture operations.

**Why It Matters:** Restricting to member facilities ensures security but limits geographic coverage during critical maneuvers. Leasing commercial stations expands reach quickly but introduces third-party dependency risks during high-stakes operations. Relying on partner networks leverages existing assets but creates bottlenecks if agency priorities shift.

**Strategic Choices:**

1. Restrict ground station control to facilities owned by member nations to ensure data security.
2. Lease commercial ground stations globally to expand geographic reach during critical maneuver windows.
3. Rely solely on existing partner agency networks to leverage established communication infrastructure.

**Trade-Off / Risk:** Leasing commercial ground stations expands geographic reach rapidly but introduces third-party dependency risks during high-stakes debris capture maneuvers.

**Strategic Connections:**

**Synergy:** Enables Launch Cadence Scheduling by ensuring reliable communication windows for precise timing, and supports Mission Abort Criteria by guaranteeing telemetry integrity during critical capture operations.

**Conflict:** Constrains Dual-Use Safeguard Implementation because broader access increases security risks, potentially conflicting with strict data protection requirements for sensitive satellite maneuvers.

**Justification:** *Low*, Defines communication infrastructure choices. Conflicts with Safeguard Implementation due to security risks, but remains tactical compared to governance or budget levers governing the project’s core strategic direction.

### Decision 12: Verification and Validation Standards
**Lever ID:** `e7582a9b-f342-459d-a745-9504a9add8c7`

**The Core Decision:** This lever establishes protocols for proving mission reliability and system performance before deployment. It balances the need for external credibility against operational agility. Success is measured by the ability to validate removal systems quickly without compromising safety or inviting legal disputes over unexpected system failures during critical space operations.

**Why It Matters:** Independent audits provide high credibility but add significant time and cost to the launch schedule. Internal peer reviews maintain agility but may lack external legitimacy with non-participating nations. Accepting vendor certification speeds deployment but increases liability if removal systems fail unexpectedly.

**Strategic Choices:**

1. Require independent third-party audit before every mission to ensure removal success credibility.
2. Conduct internal peer reviews within the consortium to maintain agility during critical operations.
3. Accept vendor certification as sufficient proof to accelerate deployment timelines for urgent threats.

**Trade-Off / Risk:** Independent third-party audits provide high credibility for removal success but add significant time and cost to the tight launch schedule.

**Strategic Connections:**

**Synergy:** Supports Mission Success Metrics by defining acceptable proof of removal, and strengthens Asset Protection Liability Framework by clarifying responsibility when systems fail unexpectedly.

**Conflict:** Conflicts with Launch Cadence Scheduling because independent audits add significant time and cost, potentially delaying urgent threat responses against tight launch windows.

**Justification:** *High*, Ensures credibility through audits versus agility. Conflicts with Cadence due to time costs, but synergy with Success Metrics provides proof essential for independent oversight and liability protection across consortium members.

### Decision 13: Mission Abort Criteria
**Lever ID:** `3f499b8c-bc85-4880-86bd-16720f7a4a79`

**The Core Decision:** This lever sets thresholds for halting operations to prevent unintended consequences during debris capture. It balances mission completion rates against risks like data loss or secondary debris generation. Success involves defining precise triggers that protect assets without unnecessarily aborting high-value missions due to minor signal fluctuations or false positive detections.

**Why It Matters:** High collision probability thresholds maximize mission completion but increase risk of unintended debris generation. Telemetry integrity checks prevent data loss but may halt operations during minor signal drops. Unauthorized object detection aborts protect against interference but risk unnecessary mission stops due to false positives.

**Strategic Choices:**

1. Abort only if collision probability exceeds ninety percent to maximize mission completion rates.
2. Abort if telemetry integrity is compromised to prevent data loss during critical capture operations.
3. Abort if unauthorized object detection occurs to protect against external interference during maneuvers.

**Trade-Off / Risk:** High collision probability thresholds maximize mission completion rates but increase the risk of unintended debris generation during capture attempts.

**Strategic Connections:**

**Synergy:** Aligns with Mission Success Metrics by defining safety limits for completion, and supports Traffic Management Protocol by preventing collisions during maneuvers.

**Conflict:** Trades off against Mission Success Metrics because strict abort thresholds may lower overall completion rates, conflicting with goals to maximize active removal mission success.

**Justification:** *Medium*, Sets safety thresholds during capture. Conflicts with Success Metrics if too strict, but supports Traffic Protocol by preventing unintended collisions during maneuvers balancing completion rates against operational safety effectively.

### Decision 14: Post-Mission Disposal Mandate
**Lever ID:** `5255589e-8692-4b20-8866-9dcd3bd3e413`

**The Core Decision:** This lever mandates end-of-life protocols for spacecraft used in debris removal. It requires balancing long-term orbital safety against operational fuel constraints. Success is achieved by reducing future debris accumulation without compromising primary removal capabilities or requiring excessive fuel reserves that limit mission scope and frequency in crowded orbital environments.

**Why It Matters:** Mandatory deorbit reduces long-term debris but consumes fuel needed for primary removal tasks. Graveyard storage preserves fuel for removal but adds to the debris population in higher orbits. Hardware recycling reduces manufacturing needs but requires complex refurbishment protocols in space.

**Strategic Choices:**

1. Require all spacecraft to deorbit within five years to reduce long-term debris population.
2. Allow indefinite storage in graveyard orbits to preserve fuel needed for removal tasks.
3. Recycle hardware for future missions to reduce manufacturing needs for subsequent fleet deployment.

**Trade-Off / Risk:** Mandatory deorbit reduces long-term debris accumulation but consumes fuel needed for primary removal tasks on the same spacecraft.

**Strategic Connections:**

**Synergy:** Supports Removal Technology Mix by informing fuel budgeting, and reinforces Target Prioritization Logic by ensuring missions reduce long-term orbital hazards.

**Conflict:** Constrains Removal Technology Mix because strict deorbit requirements consume fuel needed for primary tasks, limiting the design of agile capture systems.

**Justification:** *Medium*, Mandates end-of-life protocols. Conflicts with Tech Mix fuel constraints, but supports Prioritization by ensuring missions reduce long-term hazards without compromising primary removal capabilities or fuel availability limits.
