### 1. Consortium Steering Committee

**Rationale for Inclusion:** High strategic complexity and multi-agency funding ($20B) require executive-level alignment on budget, targets, and geopolitical risk to maintain coalition stability.

**Responsibilities:**

- Approve annual budget allocations and major capital expenditures above $100M
- Authorize final target list selection and strategic risk acceptance
- Resolve escalated operational disputes and validate mission success metrics
- Oversee compliance with international treaties and dual-use safeguards

**Initial Setup Actions:**

- Constitute members from NASA, ESA, JAXA, and ISRO leadership
- Define financial thresholds and escalation protocols
- Establish quarterly meeting schedule and secretariat

**Membership:**

- NASA Associate Administrator
- ESA Directorate Head
- JAXA President Representative
- ISRO Chair Representative
- Independent External Finance Lead

**Decision Rights:** Strategic budget approval, target list finalization, policy changes exceeding $100M impact.

**Decision Mechanism:** Supermajority vote (75%); Chair holds casting vote in deadlock.

**Meeting Cadence:** Quarterly

**Typical Agenda Items:**

- Review verified removal milestones and funding releases
- Assess geopolitical risk landscape and coalition integrity
- Approve changes to technology mix or operational scope

**Escalation Path:** Consortium Member Nation Heads of Space Agencies
### 2. Program Management Office (PMO)

**Rationale for Inclusion:** Day-to-day execution of a 15-year technical program requires centralized coordination of hybrid fleet deployment, schedule, and operational risks.

**Responsibilities:**

- Manage daily project schedule, procurement, and resource allocation
- Monitor operational risks and enforce safety protocols
- Prepare reports for Steering Committee and Independent Council
- Coordinate technical teams and ground station logistics

**Initial Setup Actions:**

- Appoint Program Director and core technical leads
- Establish project management tools and communication channels
- Define standard operating procedures for mission execution

**Membership:**

- Program Director
- Technical Lead (Robotics)
- Technical Lead (Lasers)
- Finance Operations Manager
- Risk & Safety Officer

**Decision Rights:** Operational budget decisions under $100M, technical implementation choices, vendor contracts below threshold.

**Decision Mechanism:** Program Director decision with majority input from technical leads.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Track manufacturing and launch schedule progress
- Review operational risk register and mitigation status
- Coordinate ground station access and telemetry data

**Escalation Path:** Consortium Steering Committee
### 3. Independent Oversight & Compliance Council

**Rationale for Inclusion:** Critical need for impartial verification of target selection, dual-use safety, and compliance to maintain trust among non-participating nations and stakeholders.

**Responsibilities:**

- Verify debris removal claims against independent sensor data
- Audit guidance software and laser systems for dual-use capabilities
- Assess compliance with Outer Space Treaty interpretations
- Review liability framework claims and insurance reserves

**Initial Setup Actions:**

- Recruit independent experts from non-aligned nations
- Define verification protocols and audit standards
- Secure secure data channels for sensitive telemetry review

**Membership:**

- International Space Law Expert (Non-aligned)
- Ethics & Compliance Specialist (Non-aligned)
- Technical Auditor (Independent Third Party)
- Liability & Insurance Advisor
- Observer Representative from Non-Participating Nations

**Decision Rights:** Veto authority on target selection, compliance certification for launch, audit findings.

**Decision Mechanism:** Unanimous vote for critical compliance findings; majority for routine audits.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review independent sensor data for confirmed removals
- Evaluate software audit reports for weaponization risks
- Assess legal exposure and treaty interpretation updates

**Escalation Path:** Consortium Steering Committee