## Positive Constraints

- 15-year duration
- $20 billion budget
- Led by consortium of space agencies (NASA, ESA, JAXA, ISRO) and commercial stakeholders
- Funded by coalition members
- Secure future of low Earth orbit
- Remove 500 most critical debris threats
- Deploy proven technologies (robotic capture, precision laser mitigation)
- Transparent framework addressing dual-use concerns
- Adhere strictly to applicable international laws
- Independent risk-assessment model overseen by consortium
- Target selection based on collision probability
- Verifiably reduce risk
- Protect vital satellite infrastructure
- Establish new paradigm for cooperative space governance
- Project start ASAP

## Negative Constraints

- Do not include Russia's Roscosmos
- Do not include China's CNSA
