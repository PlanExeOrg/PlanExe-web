**Budget Request Exceeding PMO Authority ($100M+)**
Escalation Level: Consortium Steering Committee
Approval Process: Supermajority vote (75%) with Chair casting vote if needed
Rationale: Exceeds operational financial delegation limit; requires strategic capital allocation and coalition resource balancing.
Negative Consequences: Unauthorized spending risk; budget overrun; coalition funding instability.

**Independent Council Veto on Target Selection**
Escalation Level: Consortium Steering Committee
Approval Process: Strategic risk review and vote
Rationale: Resolution of operational efficiency versus compliance trust conflict; essential for coalition integrity.
Negative Consequences: Loss of credibility; political backlash from non-participating nations; mission halt.

**Critical Dual-Use Safeguard Failure**
Escalation Level: Consortium Steering Committee
Approval Process: Compliance certification and policy override vote
Rationale: National security and treaty compliance implications exceed operational authority and risk external sanctions.
Negative Consequences: Legal sanctions; treaty violations; geopolitical conflict escalation.

**Proposed Major Scope Change to Technology Mix**
Escalation Level: Consortium Steering Committee
Approval Process: Strategic alignment review and formal approval
Rationale: Impacts long-term timeline, overall budget, and core risk reduction goals requiring executive oversight.
Negative Consequences: Project delay; reduced risk reduction effectiveness; stakeholder distrust.

**Milestone Verification Failure Impacting Funding Releases**
Escalation Level: Consortium Steering Committee
Approval Process: Funding release decision and milestone definition adjustment
Rationale: Direct impact on cash flow and financial discipline framework; requires policy exception.
Negative Consequences: Cash flow interruption; manufacturing stalls; supply chain breakdown.