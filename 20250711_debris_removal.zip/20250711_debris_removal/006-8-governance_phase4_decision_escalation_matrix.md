**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote
Rationale: Exceeds the PMO's delegated financial authority and requires strategic review.
Negative Consequences: Potential for budget overruns and project delays.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Approval of Revised Mitigation Plan
Rationale: The PMO lacks the authority or resources to handle the materialized risk effectively.
Negative Consequences: Project failure, significant delays, or increased costs.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Options and Final Decision
Rationale: The PMO cannot reach a consensus on a critical vendor, requiring higher-level intervention.
Negative Consequences: Delays in procurement, potential for suboptimal vendor selection.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review and Vote on Scope Change Request
Rationale: Significantly alters the project's objectives or deliverables, requiring strategic alignment.
Negative Consequences: Scope creep, budget overruns, and misalignment with strategic goals.

**Reported Ethical Concern**
Escalation Level: Ethics & Compliance Committee
Approval Process: Ethics Committee Investigation & Recommendation to Steering Committee
Rationale: Requires independent review and assessment to ensure ethical conduct and compliance.
Negative Consequences: Legal penalties, reputational damage, and loss of stakeholder trust.

**Technical Impasse on Debris Removal Technology**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Review of Technical Advisory Group Recommendation and Final Decision
Rationale: The Technical Advisory Group cannot agree on the optimal technology, requiring strategic direction.
Negative Consequences: Delays in technology development, potential for suboptimal technology selection.