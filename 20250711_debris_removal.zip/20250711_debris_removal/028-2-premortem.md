A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The project will maintain consistent funding throughout its 15-year duration. | Review historical funding patterns for similar long-term international projects. | Historical data shows funding reductions or cancellations in >25% of comparable projects. |
| A2 | The selected debris removal technologies will achieve their projected removal rates in the operational space environment. | Conduct on-orbit testing of key technology components in a simulated debris environment. | On-orbit testing demonstrates removal rates are <=70% of projected rates. |
| A3 | The international legal framework for debris ownership will be clarified and agreed upon within the next 3 years. | Track progress of UN COPUOS discussions on space debris legal issues. | UN COPUOS fails to reach consensus on key debris ownership principles after 3 years. |
| A4 | There will be sufficient commercial interest in utilizing standardized docking interfaces on satellites to facilitate debris removal. | Survey major satellite operators to gauge their willingness to adopt standardized docking interfaces on future satellites. | Survey results indicate that less than 40% of satellite operators plan to adopt standardized docking interfaces within the next 5 years. |
| A5 | The project's risk assessment model will accurately predict collision probabilities and effectively prioritize debris removal targets. | Compare the model's predictions with actual collision events and expert assessments of debris risk. | Model predictions deviate from actual collision events or expert assessments by >=30%. |
| A6 | The project will be able to attract and retain highly skilled personnel throughout its 15-year duration. | Monitor employee turnover rates and conduct exit interviews to identify reasons for leaving. | Employee turnover rate exceeds 15% annually, and exit interviews reveal dissatisfaction with project management or career opportunities. |
| A7 | The public will maintain a positive perception of the project throughout its 15-year duration, supporting continued funding and international cooperation. | Conduct regular public opinion surveys to gauge public sentiment towards the project. | Public opinion surveys reveal a significant decline in support for the project due to concerns about cost, safety, or ethical issues. |
| A8 | The project's supply chain will remain stable and reliable, ensuring timely delivery of critical components and materials. | Conduct a thorough risk assessment of the project's supply chain, identifying potential vulnerabilities and disruptions. | The risk assessment identifies significant vulnerabilities in the supply chain, such as reliance on single suppliers or geopolitical instability in key regions. |
| A9 | The project's mission verification protocols will be effective in ensuring accountability and building public trust. | Conduct a pilot audit of the mission verification protocols, assessing their ability to detect and prevent fraud or misrepresentation. | The pilot audit reveals significant weaknesses in the mission verification protocols, such as a lack of independent oversight or inadequate data collection procedures. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Austerity Asteroid | Process/Financial | A1 | Coalition Resource Allocation Lead | CRITICAL (20/25) |
| FM2 | The Grapple Glitch | Technical/Logistical | A2 | Technology Integration Lead | CRITICAL (15/25) |
| FM3 | The Legal Labyrinth | Market/Human | A3 | International Relations Specialist | CRITICAL (15/25) |
| FM4 | The Interface Impasse | Market/Human | A4 | Commercial Stakeholder Engagement Lead | CRITICAL (20/25) |
| FM5 | The Miscalculation Catastrophe | Technical/Logistical | A5 | Risk Management Coordinator | CRITICAL (15/25) |
| FM6 | The Brain Drain Debacle | Process/Financial | A6 | Human Resources Manager | CRITICAL (15/25) |
| FM7 | The PR Black Hole | Market/Human | A7 | Public Relations and Communications Manager | CRITICAL (15/25) |
| FM8 | The Supply Chain Snarl | Technical/Logistical | A8 | Supply Chain Risk Manager | CRITICAL (15/25) |
| FM9 | The Verification Void | Process/Financial | A9 | Legal and Regulatory Compliance Officer | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Austerity Asteroid

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Coalition Resource Allocation Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's funding is cut by 40% due to a global recession and shifting political priorities. Key partner nations reduce their contributions, leading to a budget shortfall of $8 billion. This forces the project to drastically scale back its operations, delaying technology development and reducing the number of planned debris removal missions. The project is forced to mothball key initiatives, such as the development of standardized docking interfaces, and focus solely on the lowest-cost, highest-risk removal methods. This leads to a decline in stakeholder confidence and further jeopardizes long-term funding prospects. The project becomes a shadow of its former self, removing only a fraction of the targeted debris and failing to achieve its long-term sustainability goals. The lack of funding also impacts the ability to properly dispose of the removed debris, leading to potential environmental consequences and further reputational damage. The project limps along for a few more years before being quietly cancelled.

##### Early Warning Signs
- Key partner nations announce significant budget cuts affecting space programs.
- Global economic indicators signal a recession or financial crisis.
- Political shifts in key partner nations prioritize domestic spending over international collaborations.

##### Tripwires
- Total project funding falls below 60% of initial projections.
- More than 2 key partner nations reduce funding contributions by >=20%.
- Annual budget allocation is cut by >=30% in any single year.

##### Response Playbook
- Contain: Immediately freeze all non-essential spending and renegotiate contracts.
- Assess: Conduct a comprehensive review of project priorities and identify areas for cost reduction.
- Respond: Develop a revised project plan with reduced scope and seek alternative funding sources.


**STOP RULE:** Total project funding falls below 40% of initial projections, rendering core mission objectives unattainable.

---

#### FM2 - The Grapple Glitch

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Technology Integration Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The robotic capture technology, hailed as a cornerstone of the project, fails to perform as expected in the harsh space environment. The grappling mechanism proves unreliable, struggling to secure a firm grip on tumbling debris objects. Repeated attempts to capture debris result in missed targets and increased fuel consumption. The laser ablation technology also underperforms, proving ineffective at mitigating larger debris fragments. This leads to a significant slowdown in the debris removal rate, falling far short of the project's targets. The project is forced to rely on less efficient and more costly methods, such as drag augmentation devices, which take significantly longer to deorbit debris. The technical failures also raise concerns about the safety of the debris removal operations, increasing the risk of collisions and further debris creation. The project loses credibility and struggles to attract new partners or secure additional funding. The mission becomes a laughingstock, a symbol of technological hubris and failed ambition.

##### Early Warning Signs
- On-orbit testing of robotic capture technology reveals significant performance limitations.
- Laser ablation tests show lower-than-expected mitigation rates for larger debris fragments.
- Fuel consumption rates for debris removal missions exceed projected levels by >=20%.

##### Tripwires
- Robotic capture success rate falls below 50% after 2 years of operations.
- Laser ablation mitigation rate is <=60% of projected levels for debris >10cm.
- More than 3 consecutive debris removal missions fail due to technical malfunctions.

##### Response Playbook
- Contain: Suspend all debris removal missions and conduct a thorough technical review.
- Assess: Identify the root causes of the technology failures and evaluate alternative solutions.
- Respond: Redesign the robotic capture mechanism and laser ablation system, or switch to alternative debris removal technologies.


**STOP RULE:** Core debris removal technologies prove fundamentally unviable after 3 years of intensive development and testing, rendering the project's primary objectives unattainable.

---

#### FM3 - The Legal Labyrinth

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: International Relations Specialist
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The international legal framework for debris ownership remains ambiguous, leading to protracted disputes and legal challenges. Several nations claim ownership of key debris objects, hindering the project's ability to remove them. Legal battles drag on for years, consuming valuable resources and delaying debris removal missions. The project faces accusations of violating international law and infringing on sovereign rights. The lack of legal clarity also creates uncertainty for commercial stakeholders, discouraging their participation and investment. The project becomes entangled in a web of legal complexities, unable to effectively address the growing space debris problem. The project is paralyzed by legal challenges, unable to remove critical debris and protect vital satellite infrastructure. The project is eventually abandoned, a victim of legal gridlock and international discord.

##### Early Warning Signs
- UN COPUOS discussions on space debris legal issues stall or fail to reach consensus.
- Several nations file legal claims asserting ownership of key debris objects.
- Commercial stakeholders express concerns about legal uncertainty and potential liability.

##### Tripwires
- UN COPUOS fails to establish clear debris ownership protocols after 3 years.
- More than 3 legal claims are filed against the project by different nations.
- Commercial stakeholder investment falls below 50% of projected levels due to legal uncertainty.

##### Response Playbook
- Contain: Suspend all debris removal missions involving disputed debris objects.
- Assess: Conduct a comprehensive legal review and explore alternative legal strategies.
- Respond: Engage in diplomatic negotiations with claimant nations to resolve ownership disputes or seek a binding international arbitration.


**STOP RULE:** Fundamental legal disputes over debris ownership remain unresolved after 5 years, preventing the removal of critical debris and rendering the project legally unviable.

---

#### FM4 - The Interface Impasse

- **Archetype**: Market/Human
- **Root Cause**: Assumption A4
- **Owner**: Commercial Stakeholder Engagement Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Satellite operators, driven by proprietary technology and cost concerns, resist adopting standardized docking interfaces. This severely limits the project's ability to efficiently capture and remove debris, as many satellites remain inaccessible to the project's robotic capture systems. The project is forced to rely on more complex and expensive methods, such as net capture or laser ablation, which are less effective and more prone to failure. The lack of standardized interfaces also hinders the development of a commercial market for on-orbit servicing and debris removal, as companies are unable to easily access and service satellites. The project becomes increasingly reliant on government funding, which is subject to political pressures and budget cuts. The project struggles to achieve its debris removal targets and fails to create a sustainable ecosystem for space debris management. The project is ultimately deemed a failure, a victim of market resistance and technological fragmentation.

##### Early Warning Signs
- Satellite operators express reluctance to adopt standardized docking interfaces due to cost or proprietary concerns.
- The development of standardized docking interfaces is delayed due to technical challenges or lack of industry consensus.
- The number of satellites equipped with standardized docking interfaces remains low despite project incentives.

##### Tripwires
- Adoption rate of standardized docking interfaces is <=30% after 5 years.
- The number of satellites equipped with standardized docking interfaces is <50% of projected levels.
- Commercial investment in on-orbit servicing and debris removal remains low despite project incentives.

##### Response Playbook
- Contain: Increase incentives for satellite operators to adopt standardized docking interfaces.
- Assess: Conduct a market analysis to identify the barriers to adoption and develop strategies to overcome them.
- Respond: Develop alternative capture methods that do not rely on standardized docking interfaces, or lobby for regulations mandating their use.


**STOP RULE:** Adoption of standardized docking interfaces remains below 20% after 7 years, rendering the project's primary capture strategy unviable.

---

#### FM5 - The Miscalculation Catastrophe

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Risk Management Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's risk assessment model proves inaccurate, leading to misprioritization of debris removal targets. The model underestimates the collision risk posed by certain debris objects, while overestimating the risk posed by others. This results in the project focusing on removing less critical debris, while more dangerous objects remain in orbit. A major collision occurs between a previously underestimated debris object and a critical satellite, causing widespread disruption to communications and navigation systems. The project is blamed for failing to prevent the collision, and its credibility is severely damaged. Stakeholder confidence plummets, and funding is cut. The project is forced to revise its risk assessment model, but the damage is already done. The project struggles to regain its footing and ultimately fails to achieve its collision probability reduction goals. The project becomes a cautionary tale, a symbol of the dangers of relying on flawed models and inaccurate data.

##### Early Warning Signs
- The risk assessment model's predictions deviate significantly from actual collision events or expert assessments.
- The model fails to accurately predict the trajectory of certain debris objects.
- The project's collision probability reduction rate falls short of projected levels.

##### Tripwires
- Model predictions deviate from actual collision events or expert assessments by >=40%.
- The project's collision probability reduction rate is <=70% of projected levels after 3 years.
- A major collision occurs between a previously underestimated debris object and a critical satellite.

##### Response Playbook
- Contain: Immediately suspend all debris removal missions and conduct a thorough review of the risk assessment model.
- Assess: Identify the sources of error in the model and develop strategies to improve its accuracy.
- Respond: Revise the risk assessment model and reprioritize debris removal targets based on the updated model.


**STOP RULE:** A major collision occurs due to a failure of the risk assessment model, and the model cannot be reliably improved after 2 years of intensive effort.

---

#### FM6 - The Brain Drain Debacle

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Human Resources Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project experiences a significant brain drain, losing key personnel to competing space programs and commercial ventures. The project's rigid management structure, limited career opportunities, and lack of competitive salaries contribute to high employee turnover. The loss of experienced engineers, scientists, and project managers severely hampers the project's ability to develop and deploy debris removal technologies. The project is forced to rely on less qualified personnel, leading to technical errors, project delays, and increased costs. The project struggles to attract new talent, as its reputation suffers from the high turnover rate and lack of career advancement opportunities. The project becomes a revolving door, unable to retain the expertise needed to achieve its ambitious goals. The project is ultimately cancelled, a victim of its own internal mismanagement and inability to attract and retain skilled personnel.

##### Early Warning Signs
- Employee turnover rate exceeds 10% annually.
- Exit interviews reveal dissatisfaction with project management, career opportunities, or compensation.
- The project struggles to fill key positions with qualified candidates.

##### Tripwires
- Employee turnover rate exceeds 20% annually.
- The project is unable to fill more than 3 key positions for >=6 months.
- Employee satisfaction surveys reveal widespread dissatisfaction with project management or career opportunities.

##### Response Playbook
- Contain: Immediately implement measures to improve employee morale and retention, such as increasing salaries, offering better benefits, and providing more career advancement opportunities.
- Assess: Conduct an employee satisfaction survey and exit interviews to identify the root causes of the high turnover rate.
- Respond: Revise the project's management structure, improve communication, and create a more supportive and rewarding work environment.


**STOP RULE:** The project is unable to reduce employee turnover to below 10% annually after 2 years of intensive effort, and the loss of key personnel severely compromises its ability to achieve its technical goals.

---

#### FM7 - The PR Black Hole

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Public Relations and Communications Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
A series of unforeseen events, including a minor collision during a debris removal mission and accusations of favoritism in target selection, trigger a wave of negative publicity. Public opinion turns sharply against the project, with concerns about safety, cost overruns, and ethical issues dominating the media narrative. Activist groups launch campaigns to defund the project, and political support erodes. Key partner nations face pressure to withdraw from the initiative. The project struggles to regain public trust, as its communication efforts are overshadowed by the negative publicity. The project becomes a political liability, and funding is slashed. The project is ultimately cancelled, a victim of its own PR failures and inability to manage public perception. The dream of a clean and safe space environment fades, replaced by cynicism and distrust.

##### Early Warning Signs
- Public opinion surveys reveal a significant decline in support for the project.
- Negative media coverage increases, focusing on safety concerns, cost overruns, or ethical issues.
- Activist groups launch campaigns to defund the project or protest against its activities.

##### Tripwires
- Public approval rating falls below 40%.
- Negative media mentions exceed positive mentions by >=2:1 for 3 consecutive months.
- More than 2 key political figures publicly criticize the project.

##### Response Playbook
- Contain: Immediately launch a crisis communication plan, addressing public concerns and providing accurate information.
- Assess: Conduct a thorough review of the project's communication strategy and identify areas for improvement.
- Respond: Revise the communication strategy, focusing on transparency, accountability, and public engagement.


**STOP RULE:** Public support remains below 30% for more than 6 months, rendering the project politically unviable.

---

#### FM8 - The Supply Chain Snarl

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Supply Chain Risk Manager
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Geopolitical tensions and trade wars disrupt the project's supply chain, leading to critical shortages of key components and materials. The project relies on specialized sensors from a single supplier in a politically unstable region, and production is halted due to civil unrest. The delivery of critical components for the robotic capture systems is delayed due to trade tariffs and export restrictions. The project is forced to scramble for alternative suppliers, but the replacements are more expensive and less reliable. The delays and cost overruns severely impact the project's timeline and budget. The project is unable to launch debris removal missions on schedule, and the debris field continues to grow. The project loses credibility and struggles to attract new partners or secure additional funding. The mission grinds to a halt, a victim of its own supply chain vulnerabilities and inability to adapt to unforeseen disruptions.

##### Early Warning Signs
- Geopolitical tensions escalate in key regions where the project's suppliers are located.
- Trade wars and export restrictions disrupt the flow of critical components and materials.
- The project experiences delays in receiving key components or materials from its suppliers.

##### Tripwires
- Delivery of critical components is delayed by >=6 months.
- The cost of key components increases by >=30% due to supply chain disruptions.
- The project is unable to secure alternative suppliers for critical components within 3 months.

##### Response Playbook
- Contain: Immediately activate contingency plans, seeking alternative suppliers and exploring options for stockpiling critical components.
- Assess: Conduct a thorough review of the project's supply chain and identify vulnerabilities.
- Respond: Diversify the supply chain, establish partnerships with multiple suppliers, and develop strategies to mitigate geopolitical risks.


**STOP RULE:** The project is unable to secure a reliable supply chain for critical components after 1 year of intensive effort, rendering its primary debris removal technologies unviable.

---

#### FM9 - The Verification Void

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Legal and Regulatory Compliance Officer
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's mission verification protocols prove ineffective, failing to detect fraudulent reporting and misrepresentation of debris removal progress. The independent verification agency lacks sufficient resources and expertise to conduct thorough audits. Mission operators inflate the number of debris objects removed, claiming credit for objects that were already deorbited or misrepresenting the size and mass of the debris. The public and stakeholders lose trust in the project, as it becomes clear that the reported progress is not accurate. Funding is cut, and the project is subjected to intense scrutiny. The project is forced to implement more stringent verification protocols, but the damage is already done. The project struggles to regain credibility and ultimately fails to achieve its long-term sustainability goals. The project becomes a symbol of government waste and mismanagement, a cautionary tale about the importance of accountability and transparency.

##### Early Warning Signs
- The independent verification agency lacks sufficient resources or expertise to conduct thorough audits.
- Mission operators resist providing data or access to their operations for verification purposes.
- The reported debris removal progress deviates significantly from independent estimates.

##### Tripwires
- The independent verification agency reports significant discrepancies between reported and actual debris removal progress.
- Stakeholder satisfaction with the mission verification process falls below 50%.
- The project is unable to provide verifiable evidence of debris removal for more than 20% of its reported targets.

##### Response Playbook
- Contain: Immediately suspend all debris removal missions and conduct a thorough review of the mission verification protocols.
- Assess: Identify the weaknesses in the verification protocols and develop strategies to improve their effectiveness.
- Respond: Strengthen the independent verification agency, implement more stringent data collection and analysis procedures, and establish penalties for fraudulent reporting.


**STOP RULE:** The mission verification protocols prove fundamentally ineffective after 2 years of intensive effort, and the project is unable to regain public trust.
