This plan **does not** imply any physical location.

## Requirements for physical locations

- secure launch site
- global telemetry coverage
- neutral oversight headquarters

## Location 1
USA

Florida

Kennedy Space Center, Merritt Island

**Rationale**: Primary hub for NASA consortium members, offering established launch infrastructure for robotic spacecraft missions.

## Location 2
French Guiana

Kourou

Guiana Space Centre, Kourou

**Rationale**: Optimal equatorial launch site for ESA partners, providing energy-efficient access to low Earth orbit for debris missions.

## Location 3
Australia

Canberra

Canberra Deep Space Communication Complex

**Rationale**: Provides essential ground station coverage for telemetry and laser coordination, ensuring 24-hour orbital tracking capability.

## Location Summary
These sites ensure launch efficiency, continuous monitoring, and neutral oversight, satisfying coalition requirements for speed, transparency, and security.