Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 10 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 6 | Material risk with plausible path. |
| ✅ Low | 4 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a space engineering and policy initiative focused on orbital debris removal using established mechanical and optical methods. It operates within known physical laws regarding momentum transfer and energy conservation without requiring impossible technologies.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of hybrid technology and independent governance at global scale without independent evidence at comparable scale. The plan states "Global-scale, $20B, 15-year consortium initiative" using a "hybrid fleet combining both robotic spacecraft and ground lasers" but lacks prior full-scale validation of this specific governance and tech mix.

**Mitigation**: Consortium Program Director: Run parallel validation tracks for legal, technical, and geopolitical subdomains producing authoritative sources or supervised pilots within 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan defines strategic decisions like "Target Prioritization Logic" with owners and measurable outcomes such as "500 confirmed debris removals."

**Mitigation**: Strategic Lead: Document value hypotheses and decision hooks for each lever within 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ✅ Low

**Justification**: Rated LOW because the register covers hazards with owners like "Financial Controller" for liability risks and outlines specific controls such as "sovereign guarantees."

**Mitigation**: Risk Manager: Update liability reserve adequacy models annually to validate against inflation assumptions and sovereign guarantee requirements within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because permit/approval matrix is absent. Experts note "Current plan schedules hardware delivery by 2027 without accounting for multi-year licensing" risking 12–24 month delays.

**Mitigation**: Program Director: Construct a permit/approval matrix mapping ITU and export control lead times to procurement milestones within 60 days to prevent critical path slippage.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states '$20B secured with 5% contingency buffer' but omits named funding sources with status, detailed draw schedules, or defined covenants for milestone releases.

**Mitigation**: Finance Controller: Draft a dated financing plan listing committed sources, draw schedule, covenants, and NO-GO gates within 60 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan states "$20 billion consortium budget" but omits vendor quotes, cost-per-object benchmarks, and required per-area math to substantiate adequacy.

**Mitigation**: Financial Controller: Benchmark ≥3 removal projects, obtain vendor quotes, and normalize cost-per-object with 10% contingency adjustment within 60 days.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because projections are single numbers without ranges or scenarios. "Execute a 15-year, $20 billion initiative to remove 500 critical space debris threats" lacks sensitivity analysis.

**Mitigation**: Financial Controller: Perform sensitivity analysis modeling best/worst/base-case scenarios for budget and timeline projections within 60 days to validate the critical assumptions.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan outlines testing tasks like "Test hybrid robotic and laser systems" but omits detailed specs, interface contracts, or defined acceptance criteria for the hybrid fleet.

**Mitigation**: Engineering Lead: Produce technical specs, interface definitions, and acceptance test plans for the hybrid fleet with owners and dates within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan asserts "Secure legal clearance under existing Outer Space Treaty interpretations" without a written opinion artifact and claims "$20B secured" absent signed funding agreements or sovereign guarantees.

**Mitigation**: Legal Counsel: Secure written treaty clearance opinions and draft binding sovereign indemnity agreements from participating nations within 60 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan states "remove the 500 most critical space debris threats" without defining verifiable mass or energy thresholds for "critical" or confirming deorbit standards.

**Mitigation**: Engineering Lead: Define SMART acceptance criteria for debris removal including a KPI for confirmed deorbit altitude verification within 60 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan ties all major components to stated objectives, including "Deploy hybrid capture technologies to eliminate 500 high-risk debris objects and establish independent governance for space sustainability" without listing non-essential features.

**Mitigation**: Program Director: Document scope alignment for each strategic lever against primary objectives within 30 days to prevent scope creep.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan omits dedicated supply chain leadership for the hybrid fleet. "Omissions: Supply Chain and Procurement Leadership... require dedicated oversight beyond general program management."

**Mitigation**: HR Team: Conduct market analysis for specialized space hardware supply leads and draft recruitment benchmarks within 60 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because "Current plan schedules hardware delivery by 2027 without accounting for multi-year licensing" creates showstopper risks despite goals to "Secure written legal clearance before initial launches".

**Mitigation**: Legal Counsel: Construct a regulatory matrix mapping ITU export control lead times to milestones and file notices with UNOOSA and regulators within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan assumes "$20B secured with 5% contingency" and "members commit 10% of their relevant agency staff" without validating retention or inflation over 15 years.

**Mitigation**: Financial Controller: Develop a 15-year operational sustainability plan covering hedging, staff retention, and technology refresh roadmap within 60 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because success hinges on non-waivable permits yet experts state 'Current plan schedules hardware delivery by 2027 without accounting for multi-year licensing' risking 12–24 month delays.

**Mitigation**: Program Director: Map all regulatory permit lead times including ITU and export controls to procurement milestones and validate dates within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because plan states "redundant links" but Premortem FM7 warns systems may fail quickly without tested fallbacks.

**Mitigation**: Director: Secure secondary contracts and test failover for networks within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because Consortium Members prioritize safety via data sharing while Commercial Operators prioritize proprietary protection, risking collaboration without explicit incentive alignment.

**Mitigation**: Stakeholder Engagement Manager: Create shared OKR on collision risk reduction with anonymized data metrics within 60 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks explicit change-control process with owners and thresholds beyond quarterly verification; Review 6 mandates quarterly but not change control.

**Mitigation**: Program Director: Establish monthly KPI review and lightweight change board with defined thresholds within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lists risks like "Legal Treaty Interpretation Validity" but lacks formal "cross-impact, bow-tie, or FTA" analysis to surface cascades where legal injunctions trigger capital delays.

**Mitigation**: Risk Team: Create an interdependency map with bow-tie analysis and combined heatmap including NO-GO thresholds within 60 days.