### 1. Senior leadership from NASA, ESA, JAXA, and ISRO formally define the high-level mandate and authorize the formation of all three governance bodies.

**Responsible Body/Role:** Consortium Senior Management / Space Agency Heads

**Suggested Timeframe:** Week 1

**Key Outputs/Deliverables:**

- Consortium Mandate Letter
- Approval Confirmation for Governance Framework

**Dependencies:**

- Project Sponsor Identified

### 2. Draft the Terms of Reference (ToR) for the Consortium Steering Committee including decision rights and escalation paths.

**Responsible Body/Role:** Legal Counsel / Secretariat Support

**Suggested Timeframe:** Week 2

**Key Outputs/Deliverables:**

- Draft Steering Committee ToR v0.1
- Draft Governance Decision Matrix

**Dependencies:**

- Consortium Mandate Letter Approved

### 3. Review and finalize the Steering Committee ToR with nominated agency heads.

**Responsible Body/Role:** Nominated Steering Committee Representatives

**Suggested Timeframe:** Week 3

**Key Outputs/Deliverables:**

- Approved Steering Committee ToR v1.0
- Membership Roster Signatures

**Dependencies:**

- Draft Steering Committee ToR v0.1

### 4. Formally appoint Steering Committee Chair and confirm member representatives.

**Responsible Body/Role:** Consortium Senior Management / Space Agency Heads

**Suggested Timeframe:** Week 3

**Key Outputs/Deliverables:**

- Chair Appointment Letter
- Official Membership Roster

**Dependencies:**

- Approved Steering Committee ToR v1.0

### 5. Hold Inaugural Steering Committee Meeting to ratify ToR and approve next-phase setup.

**Responsible Body/Role:** Consortium Steering Committee

**Suggested Timeframe:** Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Formal Ratification
- Approved Work Plan for PMO and Council Setup

**Dependencies:**

- Official Membership Roster

### 6. Draft Program Management Office (PMO) Charter defining scope, authority limits, and deliverables.

**Responsible Body/Role:** Steering Committee / Secretariat

**Suggested Timeframe:** Week 5

**Key Outputs/Deliverables:**

- Draft PMO Charter
- Operational Authority Thresholds

**Dependencies:**

- Steering Committee Inaugural Meeting

### 7. Recruit and appoint Program Director and key PMO technical leads.

**Responsible Body/Role:** Steering Committee (Executive Review)

**Suggested Timeframe:** Week 6

**Key Outputs/Deliverables:**

- Appointed Program Director
- Core PMO Team Contracting

**Dependencies:**

- Approved PMO Charter

### 8. Launch recruitment process for Independent Oversight & Compliance Council members (non-aligned experts).

**Responsible Body/Role:** Steering Committee / External Search Firm

**Suggested Timeframe:** Week 5 - Week 8

**Key Outputs/Deliverables:**

- Candidate Pool for Independent Experts
- Independence Verification Documents

**Dependencies:**

- Steering Committee Inaugural Meeting

### 9. Formally invite and onboard appointed members to the Independent Oversight & Compliance Council.

**Responsible Body/Role:** Steering Committee

**Suggested Timeframe:** Week 9

**Key Outputs/Deliverables:**

- Oversight Council Member Confirmations
- Council Terms Signed

**Dependencies:**

- Independence Verification Documents

### 10. Conduct first Joint Governance Alignment Meeting (Steering Committee and PMO).

**Responsible Body/Role:** Program Director (PMO)

**Suggested Timeframe:** Week 10

**Key Outputs/Deliverables:**

- Operational Reporting Cadence Defined
- Risk Management Workflow Signed-off

**Dependencies:**

- Appointed Program Director
- Steering Committee Inaugural Meeting

### 11. Hold first Independent Oversight Council Meeting to establish verification protocols and data access rights.

**Responsible Body/Role:** Independent Oversight & Compliance Council

**Suggested Timeframe:** Week 10

**Key Outputs/Deliverables:**

- Verification Protocol Draft
- Data Access Agreement (Non-Participating Nations)

**Dependencies:**

- Oversight Council Member Confirmations

### 12. Finalize and publish integrated governance documentation including escalation paths.

**Responsible Body/Role:** Consortium Steering Committee Secretariat

**Suggested Timeframe:** Week 12

**Key Outputs/Deliverables:**

- Master Governance Handbook
- Public Governance Transparency Statement

**Dependencies:**

- All Governance Bodies Operational