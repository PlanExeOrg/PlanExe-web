Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 16 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 3 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on engineering and governance challenges rather than fundamental physics limitations. The project aims to remove existing space debris using known technologies, not to violate any physical laws. The success of the project depends on engineering and political factors, not on overcoming any known physics limitations.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan combines novel elements (international cooperation, commercial involvement, new tech) without evidence of comparable success at this scale. The plan lacks independent validation of the entire system's viability. "The plan is highly ambitious, involving a 15-year, $20 billion initiative..."

**Mitigation**: Project Team: Run parallel validation tracks for Market/Demand, Legal/Regulatory, Technical/Safety, and Ethics/Societal. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Lead / Deliverable: Validation Report / Date: 2027-Q1


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks one-pagers defining the business-level mechanism-of-action, owner, and measurable outcomes for key strategic concepts. For example, "International Cooperation Framework" is a strategic concept, but the plan doesn't detail its inputs→process→customer value.

**Mitigation**: Project Team: Create one-pagers for each strategic concept (e.g., International Cooperation Framework) defining its mechanism-of-action, owner, value hypotheses, success metrics, and decision hooks. Owner: Project Lead / Deliverable: One-pagers / Date: 2027-Q1


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan minimizes major hazard classes. The plan mentions "Key Risks" and "Diverse Risks", but lacks a comprehensive hazard register with owners/controls. The plan does not analyze cascades explicitly. "Key Risks:
Technological failures...Geopolitical tensions".

**Mitigation**: Project Team: Expand the risk register, map cascades, and add controls with owners and a dated review cadence. Owner: Risk Management Coordinator / Deliverable: Updated Risk Register / Date: 2027-Q1


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions "Launch Permits", "Orbital Debris Removal License", and "Technology Export Licenses" but does not include a matrix mapping required permits to responsible parties and timelines.

**Mitigation**: Legal Team: Create a permit/approval matrix with dated predecessors, authoritative lead times, and a NO-GO threshold on slip. Owner: Legal and Regulatory Compliance Officer / Deliverable: Permit Matrix / Date: 2027-Q1


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a dated financing plan listing sources/status, draw schedule, and covenants. The plan mentions "Funding of $20 billion" and "Secure funding from coalition members" but does not specify the sources, status, or draw schedule.

**Mitigation**: Finance Team: Create a dated financing plan listing funding sources, status (e.g., LOI, term sheet, closed), draw schedule, and covenants. Owner: CFO / Deliverable: Financing Plan / Date: 2027-Q1


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget ($20B) lacks substantiation via vendor quotes or scale-appropriate benchmarks normalized by area. The plan does not provide cost per m²/ft² or comparable project data. "Funding of $20 billion"

**Mitigation**: Finance Team: Benchmark (≥3), obtain quotes, normalize per-area, and adjust budget or de-scope by 2027-Q1. Owner: CFO / Deliverable: Costed and Justified Budget / Date: 2027-Q1


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios. The absence of contingency planning indicates optimism. The lack of sensitivity analysis is concerning.

**Mitigation**: Project Team: Conduct a sensitivity analysis for key projections, including best/worst/base-case scenarios for revenue and user adoption. Owner: Project Lead / Deliverable: Sensitivity Analysis Report / Date: 2027-Q1.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan mentions technologies (robotic capture, laser mitigation) but lacks specs, interface contracts, acceptance tests, integration plan, and non-functional requirements.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components. Owner: Engineering Lead / Deliverable: Engineering Artifacts / Date: 2027-Q2


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes critical claims without verifiable artifacts. For example, it states the goal is to "remove the 500 most critical debris threats" but lacks a verifiable list or database of these specific objects.

**Mitigation**: Project Team: Compile a verifiable list of the 500 most critical debris threats, including their IDs, locations, and risk assessments, by 2027-Q1. Owner: Project Lead / Deliverable: Debris List / Date: 2027-Q1


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions "remove the 500 most critical debris threats" without specific, verifiable qualities. The plan lacks SMART acceptance criteria for this deliverable. The plan does not define what constitutes a 'critical' debris threat.

**Mitigation**: Risk Management Coordinator: Define SMART criteria for 'critical debris threats,' including a KPI for collision probability reduction (e.g., 90% reduction in collision risk). Owner: Risk Management Coordinator / Deliverable: SMART Criteria / Date: 2027-Q1


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes "Establish a technology control regime" without demonstrating how this supports the core goals of removing debris or protecting infrastructure. It does not directly contribute to these goals. "Goal Statement: Secure the future of low Earth orbit..."

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the technology control regime, complete with a KPI, owner, and estimated cost. Owner: Project Lead / Deliverable: Benefit Case / Date: 2027-Q1


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Data Security Architect" with "unparalleled skills" who was born in Moscow, Russia. This role is mission-critical, highly specialized, and likely difficult to fill given geopolitical tensions. "Sergei Volkov, born in Moscow, Russia..."

**Mitigation**: HR Team: Validate the talent market for a Data Security Architect with the required skills and security clearances, considering geopolitical constraints. Owner: HR Lead / Deliverable: Talent Market Report / Date: 2027-Q1


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a regulatory matrix mapping required approvals to authority, artifact, lead time, and predecessors. The plan mentions "Launch Permits" and "Orbital Debris Removal License" but does not map these.

**Mitigation**: Legal Team: Create a regulatory matrix mapping required approvals to authority, artifact, lead time, and predecessors. Flag NO-GO conditions. Owner: Legal and Regulatory Compliance Officer / Deliverable: Regulatory Matrix / Date: 2027-Q1


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a comprehensive operational sustainability plan. While it mentions "Long-Term Sustainability" as a risk and includes "Long-Term Sustainability Planning" as a task, it does not detail funding/resource strategy, maintenance, succession, tech roadmap, or adaptation.

**Mitigation**: Project Team: Develop an operational sustainability plan including funding/resource strategy, maintenance schedule, succession planning, technology roadmap, and adaptation mechanisms. Owner: Project Lead / Deliverable: Sustainability Plan / Date: 2027-Q2


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions proximity to launch facilities and access to international collaboration, but lacks specifics on zoning/land-use, occupancy/egress, fire load, structural limits, noise, and permit requirements for the chosen locations.

**Mitigation**: Facilities Team: Perform a fatal-flaw screen with authorities/experts for each location, seeking written confirmation where feasible. Define fallback designs/sites and dated NO-GO thresholds. Owner: Facilities Manager / Deliverable: Fatal-Flaw Screen Report / Date: 2027-Q1


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Secure funding from coalition members" and "Prioritize international collaboration" but lacks evidence of contracts, SLAs, or tested failovers for critical vendors, data, or facilities. The plan does not describe redundancy or continuity measures.

**Mitigation**: Project Team: Secure SLAs with key vendors, add a secondary supplier/path for critical dependencies, and test failover procedures by 2027-Q2. Owner: Project Lead / Deliverable: Redundancy and Failover Plan / Date: 2027-Q2


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'Finance Department' is incentivized by budget adherence, while the 'Technology Development' team is incentivized by innovation, creating a conflict over experimental spending. The plan does not address this conflict.

**Mitigation**: Project Lead: Create a shared OKR that aligns Finance and Technology Development on a common outcome, such as 'Increase ROI by X%' by 2027-Q2. Owner: Project Lead / Deliverable: Shared OKR / Date: 2027-Q2


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Lead: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Lead / Deliverable: Review Cadence / Date: 2027-Q1


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan has multiple critical risks (e.g., geopolitical tensions, technology failures, financial constraints) that are strongly coupled. Failure in "International Cooperation Framework" could trigger "Technology Investment Strategy" failure and "Risk Assessment Model Governance" failure.

**Mitigation**: Project Team: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds. Owner: Risk Management Coordinator / Deliverable: Risk Map / Date: 2027-Q2