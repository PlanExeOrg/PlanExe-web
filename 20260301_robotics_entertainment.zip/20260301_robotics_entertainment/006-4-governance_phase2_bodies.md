### 1. Project Steering Committee

**Rationale for Inclusion:** Provides strategic oversight and guidance for this complex, high-risk, and novel project. Ensures alignment with overall organizational goals and manages strategic risks.

**Responsibilities:**

- Approve project scope, budget, and timeline.
- Provide strategic direction and guidance.
- Monitor project progress against strategic objectives.
- Approve major changes to scope, budget, or timeline (>$5M USD or 10% of total budget).
- Oversee strategic risk management and mitigation.
- Resolve high-level conflicts and escalate issues as needed.
- Approve key vendor selections (>$1M USD).

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Define escalation paths.
- Approve initial project plan.

**Membership:**

- Chief Technology Officer
- Chief Financial Officer
- Chief Marketing Officer
- External Advisor (Robotics Ethics)
- Project Manager

**Decision Rights:** Strategic decisions related to project scope, budget, timeline, and key risks. Approval of budget changes exceeding $5M USD or 10% of the total budget. Approval of key vendor selections exceeding $1M USD.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chief Technology Officer has the tie-breaking vote. Dissenting opinions are documented in the meeting minutes.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Review of budget and expenditures.
- Approval of change requests.
- Strategic alignment with organizational goals.
- Review of key performance indicators (KPIs).

**Escalation Path:** CEO
### 2. Core Project Team

**Rationale for Inclusion:** Manages the day-to-day execution of the project, ensuring tasks are completed on time and within budget. Provides operational risk management and makes decisions below strategic thresholds.

**Responsibilities:**

- Develop and maintain project plans.
- Manage project budget and schedule.
- Coordinate project activities across different teams.
- Identify and manage operational risks.
- Track project progress and report to the Project Steering Committee.
- Make decisions related to day-to-day project execution (<$500k USD).
- Manage vendor relationships (contracts <$500k USD).

**Initial Setup Actions:**

- Define team roles and responsibilities.
- Establish communication protocols.
- Set up project management tools.
- Develop initial project schedule.

**Membership:**

- Project Manager
- Robotics Engineering Lead
- AI/ML Lead
- Construction and Theming Lead
- Hospitality and Guest Experience Lead
- Regulatory Compliance Officer

**Decision Rights:** Operational decisions related to project execution, budget management (<$500k USD), and vendor management (contracts <$500k USD).

**Decision Mechanism:** Decisions made by the Project Manager in consultation with relevant team members. Unresolved disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Weekly

**Typical Agenda Items:**

- Review of project progress against schedule.
- Discussion of current issues and risks.
- Coordination of team activities.
- Review of budget and expenditures.
- Action item tracking.

**Escalation Path:** Project Steering Committee
### 3. Technical Advisory Group

**Rationale for Inclusion:** Provides specialized technical expertise and guidance on robotics, AI, and integration challenges. Ensures technical feasibility and innovation.

**Responsibilities:**

- Review and approve technical designs.
- Provide guidance on robot platform selection and customization.
- Advise on AI narrative engine development and integration.
- Identify and mitigate technical risks.
- Evaluate new technologies and innovations.
- Ensure technical compliance with relevant standards.

**Initial Setup Actions:**

- Define scope of technical expertise.
- Establish communication channels.
- Review project technical requirements.

**Membership:**

- Senior Robotics Engineer
- Senior AI/ML Developer
- External Robotics Consultant
- External AI/ML Consultant
- Project Manager

**Decision Rights:** Technical decisions related to robot selection, AI development, and system integration. Recommendations on technical feasibility and risk mitigation.

**Decision Mechanism:** Decisions made by consensus among technical experts. In case of disagreement, the Senior Robotics Engineer and Senior AI/ML Developer have the final say in their respective areas of expertise.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of technical designs and specifications.
- Discussion of technical challenges and solutions.
- Evaluation of new technologies.
- Review of technical risks and mitigation strategies.
- Progress updates on technical development.

**Escalation Path:** Project Steering Committee
### 4. Ethics & Compliance Committee

**Rationale for Inclusion:** Ensures ethical considerations and regulatory compliance are integrated into all aspects of the project. Addresses potential ethical concerns related to AI, robotics, and data privacy. Oversees compliance with Japanese regulations and international standards.

**Responsibilities:**

- Develop and maintain an ethical framework for robot deployment.
- Review and approve data privacy policies.
- Oversee compliance with Japanese regulations and international standards (ISO 13482, ISO 10218, GDPR).
- Conduct regular audits to ensure compliance.
- Address ethical concerns raised by stakeholders.
- Monitor public perception of humanoid robots and address negative feedback.
- Ensure compliance with Electrical Appliance Law, Radio Law, and local ordinances.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule.
- Develop ethical framework.
- Define compliance procedures.

**Membership:**

- Regulatory Compliance Officer
- Legal Counsel
- External Ethics Consultant
- Community Representative
- Project Manager

**Decision Rights:** Decisions related to ethical considerations, regulatory compliance, and data privacy. Approval of ethical framework, data privacy policies, and compliance plans.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the External Ethics Consultant has the tie-breaking vote.

**Meeting Cadence:** Monthly

**Typical Agenda Items:**

- Review of ethical concerns and potential risks.
- Review of regulatory compliance status.
- Discussion of data privacy issues.
- Review of public perception of humanoid robots.
- Approval of compliance plans and policies.
- Audit findings review.

**Escalation Path:** Project Steering Committee
### 5. Stakeholder Engagement Group

**Rationale for Inclusion:** Manages communication and engagement with key stakeholders, including the local community, regulatory bodies, and investors. Ensures stakeholder concerns are addressed and project benefits are communicated effectively.

**Responsibilities:**

- Develop and implement a stakeholder engagement plan.
- Conduct public forums and meetings to address community concerns.
- Maintain open communication with regulatory bodies.
- Provide regular updates to investors.
- Address stakeholder inquiries and feedback.
- Manage media relations and public relations.
- Monitor stakeholder satisfaction and address any issues.

**Initial Setup Actions:**

- Identify key stakeholders.
- Develop communication plan.
- Establish communication channels.
- Schedule initial stakeholder meetings.

**Membership:**

- Marketing Manager
- Community Representative
- Investor Relations Manager
- Regulatory Compliance Officer
- Project Manager

**Decision Rights:** Decisions related to stakeholder communication, engagement strategies, and public relations. Approval of communication plans and stakeholder engagement activities.

**Decision Mechanism:** Decisions made by the Marketing Manager in consultation with relevant team members. Unresolved disagreements are escalated to the Project Steering Committee.

**Meeting Cadence:** Bi-weekly

**Typical Agenda Items:**

- Review of stakeholder feedback and concerns.
- Discussion of communication strategies.
- Planning of stakeholder engagement activities.
- Review of media coverage and public relations.
- Progress updates on stakeholder engagement.

**Escalation Path:** Project Steering Committee