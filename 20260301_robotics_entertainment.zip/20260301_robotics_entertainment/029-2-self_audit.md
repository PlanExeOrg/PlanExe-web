Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 14 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 5 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan focuses on economics/crypto/tokenization/governance/AI/regulation/engineering-scale, which are out of scope. The project aims to create an entertainment experience using advanced robotics and AI in Japan, which does not inherently require breaking any physical laws.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (theme park), market (Japan), tech/process (humanoid robots + AI), and policy (Japanese regulations) without independent evidence at comparable scale. There is no credible precedent for this entire system. Failure would be existential.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Project Manager / Validation Reports / 90 days.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business‑level mechanism‑of‑action (inputs→process→customer value) is defined for the strategic concepts driving the plan. The plan mentions strategic choices but lacks measurable outcomes or owners. For example, the Robot Sourcing Strategy lacks a defined owner.

**Mitigation**: Project Manager: Assign owners to each strategic concept (e.g., Robot Sourcing Strategy) to produce one-pagers with value hypotheses, success metrics, and decision hooks by EOM.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies several risks (regulatory, technical, financial, operational, social, security, environmental, supply chain, market) and includes mitigation strategies. However, it lacks explicit analysis of risk cascades or second-order effects. For example, "Regulatory & Permitting" risk mentions delays and increased costs, but doesn't map the cascade to financial impacts.

**Mitigation**: Risk and Safety Manager: Expand the risk register to explicitly map risk cascades and second-order effects, adding controls and a dated review cadence within 60 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the permit/approval matrix is absent. The plan mentions various permits and licenses (Building Permit, Fire Safety Certification, Robot Safety Certification (ISO 13482)), but lacks a comprehensive matrix mapping these to specific tasks, timelines, and responsible parties.

**Mitigation**: Regulatory Compliance Specialist: Create a permit/approval matrix with tasks, timelines, dependencies, responsible parties, and authoritative lead times within 60 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions securing funding but lacks specifics: "Secure funding for all project phases" and "Diversification of funding sources." The plan does not name funding sources, their status (LOI/term sheet/closed), the draw schedule, or runway length.

**Mitigation**: CFO: Create a dated financing plan listing funding sources/status, draw schedule, covenants, and a NO‑GO on missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget of $30M conflicts with the scale of the project (theme park prototype with humanoid robots). There are no benchmarks or per-area cost normalizations provided. The plan lacks vendor quotes or scale-appropriate benchmarks.

**Mitigation**: CFO: Benchmark (≥3), obtain quotes, normalize per-area (m²/ft²), and adjust budget or de-scope by EOM. Owner: CFO, Deliverable: Revised budget, Date: EOM.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (budget, timeline, team size) as single numbers without ranges or alternative scenarios. For example, "R&D: $5M" is presented without any sensitivity analysis. This indicates optimism and a lack of contingency planning.

**Mitigation**: CFO: Conduct a sensitivity analysis or a best/worst/base-case scenario analysis for the budget, timeline, and team size projections within 60 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and integration plans for critical components. Their absence creates a likely failure mode.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because any critical legal/contract/operational claim lacks a verifiable artifact. The plan states, "Secure funding for all project phases," but provides no evidence of funding commitments or agreements.

**Mitigation**: CFO: Provide verifiable evidence of funding commitments (e.g., signed term sheets, bank statements) or adjust the project scope within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major deliverable, 'a commercially viable and safe guest experience,' is mentioned without specific, verifiable qualities. The plan lacks SMART criteria for 'guest experience'.

**Mitigation**: Guest Experience Director: Define SMART criteria for 'guest experience,' including a KPI for guest return rate (e.g., 20% return within 12 months) by EOM.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan includes 'Thematic Authenticity Approach' as a secondary decision, which involves cultural accuracy and sensitivity. While important, it adds complexity without directly supporting core goals like demonstrating commercial viability or ensuring safety.

**Mitigation**: Project Team: Produce a one-page benefit case for the Thematic Authenticity Approach, including a KPI, owner, and estimated cost, or move it to the project backlog by EOM.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the 'AI Narrative Architect' as a key role, but the talent market for AI specialists with narrative design skills is highly competitive and difficult to fill. The plan does not address this challenge.

**Mitigation**: HR: Conduct a talent market analysis for AI Narrative Architects, assessing availability, compensation expectations, and recruitment strategies within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan mentions various permits and licenses (Building Permit, Fire Safety Certification, Robot Safety Certification (ISO 13482)), but lacks a comprehensive matrix mapping these to specific tasks, timelines, and responsible parties.

**Mitigation**: Regulatory Compliance Specialist: Create a permit/approval matrix with tasks, timelines, dependencies, responsible parties, and authoritative lead times within 60 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a detailed strategy for long-term maintenance, repair, and replacement of robots. The plan mentions robot maintenance but lacks a detailed strategy for long-term maintenance, repair, and replacement.

**Mitigation**: Robotics Integration Lead: Develop a robot maintenance and obsolescence plan including a maintenance schedule, spare parts availability, and a robot replacement strategy within 90 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Japanese building code compliance" and "Fire safety certification" but lacks specifics on occupancy/egress, fire load, noise, or structural limits. The plan does not include a fatal-flaw screen with authorities.

**Mitigation**: Permitting Lead: Conduct a fatal-flaw screen with local authorities regarding zoning, occupancy, fire load, structural limits, and noise within 60 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan mentions "Diversify suppliers, buffer stocks, contingency plans, monitor conditions" for supply chain risk, but lacks specifics on supplier concentration, geographic distribution, or SLAs. There is no evidence of tested failover plans.

**Mitigation**: Procurement Manager: Secure SLAs with key suppliers, add a secondary supplier for critical components, and test failover procedures by EOM + 90 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the 'Robotics Engineering Team' is incentivized to innovate and push the boundaries of robotics, while 'Investor Relations' is incentivized to minimize costs and maximize ROI. This creates a conflict over resource allocation.

**Mitigation**: Project Manager: Establish a shared OKR focused on achieving a specific ROI within a defined timeframe, aligning both teams on a common financial outcome by EOM.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop). Vague ‘we will monitor’ is insufficient.

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board. Owner: Project Manager, Deliverable: Review process, Date: EOM.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies several high risks (Regulatory, Financial, Security) that are strongly coupled. For example, failure to obtain regulatory approvals (Risk 1) can lead to cost overruns (Risk 3) and potential legal liabilities (Risk 6), creating a multi-domain failure.

**Mitigation**: Project Manager: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by EOM + 60 days.