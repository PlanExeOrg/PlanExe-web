**Purpose:** business

**Purpose Detailed:** Commercial pilot and technology demonstrator for humanoid robotics and AI in entertainment, targeting profit and expansion.

**Topic:** Immersive Entertainment Theme Park Prototype in Japan