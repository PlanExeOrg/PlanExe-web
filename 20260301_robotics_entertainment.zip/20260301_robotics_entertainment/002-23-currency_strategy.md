This plan involves money.

## Currencies

- **JPY:** Local currency for construction, staffing, robot acquisition, and operational expenses in Japan.
- **USD:** Used for budgeting and reporting given the project's international scope and the need for a stable reference currency.

**Primary currency:** USD

**Currency strategy:** USD is recommended for budgeting and reporting to mitigate risks from currency fluctuations. JPY will be used for local transactions. Hedging strategies may be considered to manage exchange rate risks between USD and JPY.