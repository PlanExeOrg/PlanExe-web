### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**


### 2. Circulate Draft SteerCo ToR for review by the Chief Technology Officer, Chief Financial Officer, Chief Marketing Officer, and External Advisor (Robotics Ethics).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised SteerCo ToR v0.2

**Dependencies:**

- Draft SteerCo ToR v0.1

### 3. Project Manager finalizes the Terms of Reference for the Project Steering Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final SteerCo ToR v1.0

**Dependencies:**

- Feedback Summary

### 4. Chief Technology Officer formally appoints the Chair of the Project Steering Committee.

**Responsible Body/Role:** Chief Technology Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final SteerCo ToR v1.0

### 5. Project Manager, in consultation with the SteerCo Chair, schedules the initial Project Steering Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 6. Hold the initial Project Steering Committee kick-off meeting to review the project plan, finalize the meeting schedule, define escalation paths, and approve the initial project plan.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Project Plan

**Dependencies:**

- Meeting Invitation
- Final SteerCo ToR v1.0

### 7. Project Manager defines team roles and responsibilities for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Core Project Team Roles and Responsibilities Document

**Dependencies:**


### 8. Project Manager establishes communication protocols for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Core Project Team Communication Protocols Document

**Dependencies:**

- Core Project Team Roles and Responsibilities Document

### 9. Project Manager sets up project management tools for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Project Management Tool Configuration

**Dependencies:**


### 10. Project Manager develops the initial project schedule for the Core Project Team.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Initial Project Schedule

**Dependencies:**


### 11. Project Manager schedules the initial Core Project Team kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Core Project Team Roles and Responsibilities Document
- Core Project Team Communication Protocols Document
- Project Management Tool Configuration
- Initial Project Schedule

### 12. Hold the initial Core Project Team kick-off meeting to review the project plan, communication protocols, and project schedule.

**Responsible Body/Role:** Core Project Team

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 13. Project Manager defines the scope of technical expertise required for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Technical Advisory Group Scope of Expertise Document

**Dependencies:**


### 14. Project Manager establishes communication channels for the Technical Advisory Group.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Technical Advisory Group Communication Channels Document

**Dependencies:**

- Technical Advisory Group Scope of Expertise Document

### 15. Project Manager reviews project technical requirements with the Senior Robotics Engineer and Senior AI/ML Developer.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Project Technical Requirements Document

**Dependencies:**


### 16. Project Manager schedules the initial Technical Advisory Group kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Technical Advisory Group Scope of Expertise Document
- Technical Advisory Group Communication Channels Document
- Project Technical Requirements Document

### 17. Hold the initial Technical Advisory Group kick-off meeting to review technical designs, discuss technical challenges, and evaluate new technologies.

**Responsible Body/Role:** Technical Advisory Group

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitation

### 18. Project Manager drafts initial Terms of Reference (ToR) for the Ethics & Compliance Committee.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft Ethics & Compliance Committee ToR v0.1

**Dependencies:**


### 19. Circulate Draft Ethics & Compliance Committee ToR for review by the Regulatory Compliance Officer, Legal Counsel, and External Ethics Consultant.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Feedback Summary
- Revised Ethics & Compliance Committee ToR v0.2

**Dependencies:**

- Draft Ethics & Compliance Committee ToR v0.1

### 20. Project Manager finalizes the Terms of Reference for the Ethics & Compliance Committee based on feedback.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Final Ethics & Compliance Committee ToR v1.0

**Dependencies:**

- Feedback Summary

### 21. Regulatory Compliance Officer formally appoints the Chair of the Ethics & Compliance Committee.

**Responsible Body/Role:** Regulatory Compliance Officer

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Final Ethics & Compliance Committee ToR v1.0

### 22. Project Manager, in consultation with the Ethics & Compliance Committee Chair, schedules the initial Ethics & Compliance Committee kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitation
- Meeting Agenda

**Dependencies:**

- Appointment Confirmation Email

### 23. Hold the initial Ethics & Compliance Committee kick-off meeting to review the ethical framework, define compliance procedures, and finalize the meeting schedule.

**Responsible Body/Role:** Ethics & Compliance Committee

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items
- Approved Ethical Framework
- Defined Compliance Procedures

**Dependencies:**

- Meeting Invitation
- Final Ethics & Compliance Committee ToR v1.0

### 24. Marketing Manager identifies key stakeholders for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- List of Key Stakeholders

**Dependencies:**


### 25. Marketing Manager develops a communication plan for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Stakeholder Communication Plan

**Dependencies:**

- List of Key Stakeholders

### 26. Marketing Manager establishes communication channels for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Stakeholder Communication Channels Document

**Dependencies:**

- Stakeholder Communication Plan

### 27. Marketing Manager schedules initial stakeholder meetings for the Stakeholder Engagement Group.

**Responsible Body/Role:** Marketing Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Meeting Invitations
- Meeting Agendas

**Dependencies:**

- Stakeholder Communication Channels Document

### 28. Hold initial stakeholder meetings for the Stakeholder Engagement Group to address community concerns and provide project updates.

**Responsible Body/Role:** Stakeholder Engagement Group

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Meeting Invitations