This plan implies one or more physical locations.

## Requirements for physical locations

- Suburban or semi-rural area
- Land cost balance
- Transport access
- Proximity to robotics supplier ecosystems
- Japanese building code compliance
- Fire safety certification for mixed human-robot occupancy
- Alignment with Japan's Robot Safety regulatory framework including ISO 13482 for personal care robots and any applicable METI guidelines for entertainment robotics
- All robot-guest physical interactions must pass risk assessment under ISO 10218 collaborative robot safety standards
- Appropriate liability insurance

## Location 1
Japan

Outskirts of Osaka

A suburban or semi-rural area with good transport links

**Rationale**: Osaka offers a balance of land cost, transport access, and proximity to robotics supplier ecosystems, aligning with the project's requirements.

## Location 2
Japan

Northern Kyushu

A suburban or semi-rural area with good transport links

**Rationale**: Northern Kyushu provides a similar balance of factors to Osaka, with potentially lower land costs and access to a different set of suppliers.

## Location 3
Japan

Chiba corridor near Tokyo

A suburban or semi-rural area with good transport links

**Rationale**: The Chiba corridor near Tokyo offers proximity to a major metropolitan area and robotics expertise, although land costs may be higher.

## Location Summary
The plan requires a physical location in Japan. The outskirts of Osaka, Northern Kyushu, and the Chiba corridor near Tokyo are suggested due to their balance of land cost, transport access, and proximity to robotics supplier ecosystems.