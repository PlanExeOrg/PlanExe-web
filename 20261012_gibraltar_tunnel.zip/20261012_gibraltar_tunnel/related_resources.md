## Suggestion 1 - Fehmarnbelt Fixed Link (Femern A/S), Denmark–Germany

Binational immersed-tube road and rail tunnel of about 18 km across the Fehmarnbelt, built by the state-owned company Femern A/S under a 2008 Denmark–Germany treaty. It uses large prefabricated concrete elements cast in a purpose-built factory at Rødbyhavn and immersed in a busy shipping area. Construction began around 2020–2021; opening has slipped to the mid-2030s (not verified).

### Success Metrics

Treaty-based binational delivery vehicle established and operating
Element factory and immersion campaign running at industrial scale
Planned opening date moved later than first announced (schedule lesson)

### Risks and Challenges Faced

Treaty and permitting delays: addressed by a state-owned single project company and a bilateral treaty
German court challenges to approval: mitigated by lengthy consent process and legal clarification
Cost and schedule growth: managed with state guarantees and revised timeline

### Where to Find More Information

https://femern.com
Danish Transport Ministry and Femern A/S annual reports
Denmark–Germany Fehmarnbelt Treaty text (2008)

### Actionable Steps

Contact Femern A/S corporate communications and request a technical briefing on element-factory operations
Approach the Danish Ministry of Transport treaty office about governance lessons
Reach project directors via LinkedIn through Femern A/S company page

### Rationale for Suggestion

Closest analogue for a binational treaty-backed owner with its own legal personality and for a large precedent-scale immersion campaign with dedicated casting yards. Not Mediterranean, but the governance and logistics lessons map directly to the delivery vehicle and fabrication decisions.
## Suggestion 2 - Hong Kong–Zhuhai–Macao Bridge Immersed Tunnel (HZMB)

About 5.7 km immersed-tube tunnel segment of the HZMB link, with 33 elements of roughly 180 m each, immersed in deep soft seabed and busy shipping lanes. Construction ran roughly 2011–2018; the link opened in October 2018. Elements were cast in a dedicated factory and installed with a floating immersion system.

### Success Metrics

Tunnel completed and opened in 2018
Final joint closed with high dimensional accuracy (documented in technical papers)
Schedule delays and cost growth occurred, but the link opened

### Risks and Challenges Faced

Deep burial and soft clay: mitigated with a gravel/stone foundation and element-by-element monitoring
Strong tidal currents and shipping traffic: managed with weather windows and marine traffic control
Final joint installation difficulty: solved with a purpose-designed closing method

### Where to Find More Information

HZMB Authority publications
ICE/Tunnelling and Underground Space Technology papers on the HZMB immersed tunnel
International Tunnelling and Underground Space Association (ITA) case materials

### Actionable Steps

Contact the HZMB Authority via its official site for technical papers
Approach the immersion contractor consortium's engineering leads via professional networks
Request design-office contacts from ITA's immersed-tunnel working group

### Rationale for Suggestion

Demonstrates a deep, multi-year immersion campaign in strong currents and a busy lane, directly informing fabrication, tolerance control and weather-window planning. Geographically distant; included because few comparable immersion programmes exist in the Mediterranean region.
## Suggestion 3 - Rogfast / Norwegian Coastal Highway E39 Submerged Floating Tunnel Studies (Statens vegvesen)

Norwegian Public Roads Administration programme on the E39 coastal route studying submerged floating tunnels for fjord crossings (e.g. Sognefjord, Bjørnafjord). It includes concept design, hydrodynamic model tests, and independent external verification of tether and pontoon concepts. The programme reached concept-selection studies but no floating tunnel has been built (not verified for latest status).

### Success Metrics

Multiple concept studies completed with external verification
Model testing and design-basis reports published
No construction commitment yet; used as proof-stage evidence

### Risks and Challenges Faced

No design code: addressed with project-specific design basis and external review
Dynamic response to waves, currents and seismic loads: studied by model tests and numerical analysis
Ship collision and accidental loads: handled as explicit design cases

### Where to Find More Information

https://www.vegvesen.no (E39 Coastal Highway Route, Statens vegvesen)
Published reports on Bjørnafjord submerged floating tube bridge
ITA/COWI/Norconsult technical papers

### Actionable Steps

Contact Statens vegvesen E39 programme office for design-basis reports
Approach Norwegian engineering consultancies involved in concept studies
Seek introductions via the ITA or Norwegian tunnelling society

### Rationale for Suggestion

The most direct technical reference for tether and pontoon support concepts, design-basis development and independent verification in the absence of a code. It supports the stage-gate and certification decisions rather than delivery logistics.
## Suggestion 4 - Strait of Gibraltar Fixed Link Studies (SECEGSA / SNED)

Secondary suggestion. Joint Spanish–Moroccan feasibility work on a fixed link across the Strait, run by Spain's SECEGSA and Morocco's SNED since the late 1970s. Studies covered geology, bathymetry, seismicity and alternative crossings including a bored rail tunnel and bridge concepts. No construction has been launched.

### Success Metrics

Decades of corridor geotechnical and bathymetric data
Reference alignments studied (e.g. Camarinal Sill)
No construction decision reached

### Risks and Challenges Faced

Deep water and seismicity: reflected in study scope
Political continuity: bilateral commissions kept studies alive
Funding and commitment gaps: studies remained unfunded for construction

### Where to Find More Information

SECEGSA (Sociedad Española de Estudios para la Comunicación Fija a través del Estrecho de Gibraltar) public information
Spanish Ministry of Transport records
Academic papers on Strait of Gibraltar fixed link

### Actionable Steps

Contact SECEGSA via the Spanish Ministry of Transport to request archived survey data
Approach SNED through the Moroccan Ministry of Equipment and Transport
Ask both bodies for the joint-commission records

### Rationale for Suggestion

Same location and the existing study entities named in the plan. It is the closest geographic and institutional reference, and its data underpin the seabed campaign. Secondary because no structure has been built.

## Summary

No submerged floating tunnel has been built, so references are drawn from adjacent real projects: immersed-tube tunnels in strong currents, a binational fixed link with a concession model, and a floating-tunnel proof programme. Geographically close precedents are limited. The Strait of Gibraltar study history (SECEGSA/SNED) is the nearest context, and the rest are distant but technically analogous. Priority lessons: staged proving, a binational delivery vehicle, and first-of-kind immersion logistics. Figures not verified are marked (estimate); contacts are given as organisations or roles to approach.