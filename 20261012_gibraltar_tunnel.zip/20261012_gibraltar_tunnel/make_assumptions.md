
## Question 1 - How should the €40 billion envelope be split between the two states, EU/multilateral lenders and private capital, and what contingency reserve and tranche-release rules apply?

**Assumptions:** Assumption: Funding is released in tranches tied to stage gates, with a contingency reserve of about 18% of the envelope (~€7.2 billion, proposed) held at gate level. Civil works stay on public balance sheets; private capital covers rail systems and operations through availability payments. This follows megaproject practice, where first-of-kind overruns of 20-40% are common.

**Assessments:** Title: Financial Feasibility Assessment
Description: Evaluates whether the €40 billion (user constraint) can absorb first-of-kind cost uncertainty.
Details: Support-concept variance is estimated at €4-8 billion; cumulative overruns of €10-18 billion are plausible. Mitigation: gated tranches (opening tranche limited to investigation and pilot, ~€0.5 billion estimate), an independent cost authority escalating variances above 5%, and indexed contingency. Opportunity: EU and multilateral co-financing locks in political commitment. Open risk: no overrun backstop makes private participation hard to price, so costs may shift to taxpayers.

## Question 2 - What are the critical-path durations and stage-gate dates from treaty ratification through seabed survey, certification, casting-yard build and immersion to opening within the 20-year horizon?

**Assumptions:** Assumption: Treaty ratified by Months 12-15 (2027-10-12 to 2028-01-12); seabed campaign Months 0-18 (2026-10-12 to 2028-04-12); design freeze Month 24 (2028-10-12); pilot segment immersed by Month 36 (2029-10-12); main fabrication and immersion Months 36-120 (2029-10-12 to 2036-10-12); commissioning thereafter. Gates at Months 9, 15, 24, 36 and 48 (2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12), plus a 6-month floating reserve (all proposed). Durations follow typical megaproject permitting and survey benchmarks.

**Assessments:** Title: Schedule Feasibility Assessment
Description: Tests whether the 20-year horizon (user constraint) survives sequential dependencies.
Details: Treaty or permitting slips of 12-24 months compress casting and immersion. Weather windows of 60-90 usable days per year (estimate) may make ~14 km of immersion take longer than the available period, so a bottom-up CPM schedule at P50/P80 is needed by Month 1 (2026-11-12). Mitigation: run treaty, ecological baseline and seabed work in parallel from Month 0 (2026-10-12); test the immersion rate against weather windows before committing. Fallback: phased opening or reduced scope if the model shows the horizon is unachievable.

## Question 3 - What workforce, specialist contractors and technical capacity are needed on both coasts, and how will scarce marine-engineering and immersion skills be secured?

**Assumptions:** Assumption: A joint delivery organisation of several hundred core staff (estimate) is staffed from both states plus international marine-tunnel and offshore specialists. Paired yards at Algeciras and Tanger Med each employ thousands at peak (estimate). Only a few global contractors can immerse long concrete elements, so long-term framework agreements are needed.

**Assessments:** Title: Resource and Personnel Assessment
Description: Assesses availability of skills and contractors for a first-of-kind marine programme.
Details: Main risks are competition from offshore wind and LNG projects, which can raise day-rates by an estimated 30-50%, and local shortages of concrete finishers and divers that slow yard ramp-up by 10-20% (estimate). Mitigation: early supply-chain mapping (Months 1-3 = 2026-11-12 to 2027-01-12), training academies at both yards, framework agreements with escalation caps, and dual sourcing for custom items such as tethers and joints. Opportunity: regional employment and skills legacy supports political parity.

## Question 4 - Which legal vehicle, treaty terms, procurement rules and certification authority will govern design, safety, tolling and dispute resolution across both jurisdictions?

**Assumptions:** Assumption: A treaty-backed coordinating framework is established by Month 12-15 (2027-10-12 to 2028-01-12), with a long-term concession to a public-private joint venture under each state's law. SECEGSA and SNED are subordinated to it. A single lead certifier works from a project-specific design code adapted from offshore, immersed-tunnel and railway standards. Tie-break and escalation rules are written in from the start.

**Assessments:** Title: Governance and Regulatory Assessment
Description: Evaluates legal clarity, decision speed and regulatory acceptance.
Details: Consensus cycles of 3-6 months (estimate) across 10-15 gates could consume 30-45 months. Mitigation: delegated approval thresholds (CEO under 2% cost variance, Board 2-5%, political review above 5%, proposed), harmonised procurement and one technical regulator. Risk: concession model leaves interface and standards-harmonisation weaknesses at mid-Strait. Lenders and insurers will want legal personality and certification clarity before committing. A treaty withdrawal-notice clause protects continuity across election cycles.

## Question 5 - What are the principal safety hazards (seismic, structural failure, fire, flooding, vessel strike, sabotage) and what egress, monitoring and incident-response concept will meet operating-licence requirements?

**Assumptions:** Assumption: The design basis uses probabilistic seismic hazard analysis with 475- and 2475-year return periods (proposed). Egress combines cross-passages to a service bore or refuges with shaft or platform access. Rescue assets are based at Tarifa and Tangier. A no-anchoring corridor with sonar and radar monitoring is enforced. Safety case acceptance gates insurance and licences.

**Assessments:** Title: Safety and Risk Management Assessment
Description: Reviews low-probability, high-consequence hazards in a seismic, busy-strait setting.
Details: Egress adds an estimated €0.5-2 billion and adds mass to a buoyancy-sensitive tube. Passive hardening could add €1-3 billion (estimate). Mitigation: fix the egress and impact design cases at concept stage, run prototype tether and joint tests before production, and install permanent structural and seismic monitoring. Treat seismic design as a baseline cost, not contingency. Open item: the 100 m depth assumption conflicts with published Strait depths of several hundred metres and must be resolved first.

## Question 6 - What baseline ecological studies, mitigation measures and consent pathway are needed for marine megafauna and protected areas, and what construction timing restrictions are likely?

**Assumptions:** Assumption: A joint multi-year ecological baseline starts at Month 0 (2026-10-12), with parallel national assessments reconciled by a coordinating committee to a harmonised consent by Months 18-24 (2028-04-12 to 2028-10-12). Seasonal restrictions leave 60-90 usable immersion days per year (estimate). Mitigation of €250-400 million (estimate) is a separate budget line.

**Assessments:** Title: Environmental Impact Assessment
Description: Assesses consent durability and ecological effects of marine works in a migration corridor.
Details: Sequential consents could delay permits 24-36 months; divergent parallel consents risk 12-18 months of reconciliation or injunctions of 3-6 months each (estimates). Impacts to model: acoustic disturbance, current alteration, sediment plumes and tether hydrodynamics. Mitigation: embed ecological windows in the CPM schedule, commit mitigation up front, appoint a joint construction environmental manager with halt authority. Opportunity: artificial reef features and research partnerships strengthen consent defensibility and public support.

## Question 7 - Which stakeholders (governments, regulators, rail operators, IMO and maritime authorities, lenders, insurers, NGOs, local communities) must be engaged, and how will they be involved?

**Assumptions:** Assumption: A ministerial-level binational steering committee meets quarterly. Rail operators sign anchor-tenant agreements by Month 24 (2028-10-12). NGOs, fishing and port communities are consulted from Months 0-3 (2026-10-12 to 2027-01-12). Maritime authorities, including the IMO, are engaged by Month 3 (2027-01-12) on exclusion corridors, and lenders and insurers are engaged before design freeze.

**Assessments:** Title: Stakeholder Engagement Assessment
Description: Maps influence over consent, financing and demand across a multi-party programme.
Details: Political turnover across a 20-year span is the main threat; mitigations are parliamentary supermajority ratification, EU co-financing and board tenure independent of electoral cycles. NGO legal standing makes early co-design of consent conditions cost-effective. IMO consent for exclusion zones may take 2-4 years (estimate), so engagement is needed early. Rail operator commitments underpin ridership and lender confidence. A stakeholder register with an owner and a quarterly review is recommended.

## Question 8 - What rail, signalling, traction power, ventilation, monitoring and maintenance systems will operate the link, and what operating concept and landside integration apply at opening?

**Assumptions:** Assumption: Standard European high-speed gauge and signalling are used in the tunnel, with gauge-change facilities on land. Opening is a passenger service with a freight or vehicle-shuttle option. Opening ridership is planned at about 4 million per year (proposed planning case). Maintenance is condition-based with a continuous structural monitoring network and a dedicated O&M reserve.

**Assessments:** Title: Operational Systems Assessment
Description: Evaluates whether the operating concept is deliverable, certifiable and financially sustainable.
Details: Cross-section, ventilation load and rolling-stock envelope must be frozen early, since they drive buoyancy margins. Operating costs may run 20-40% above land tunnels (estimate). Demand 20-50% below forecast would strain debt service, so the model should break even at conservative volumes. Mitigation: design the O&M regime early, set a 10-year independent inspection cycle, fund an O&M reserve (€200-400 million, estimate) and fix commissioning time for testing and training. Opportunity: through-running maximises network value if regulators align.