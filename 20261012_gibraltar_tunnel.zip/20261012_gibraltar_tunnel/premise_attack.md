### Premise Attack 1 — Integrity
_Forensic audit of foundational soundness across axes._

**[STRATEGIC] A 20-year, €40 billion crossing that depends on a technology with no operating precedent anywhere (a submerged floating tunnel) and parks it at 100 m, deeper than any such design has been built and far deeper than needed, in a strait with 300–900 m seabed, strong currents and seismic uncertainty, is a bet on unproven physics and not a defensible infrastructure program.**

**Bottom Line:** REJECT: Do not start a €40 billion, 20-year Spain–Morocco program on a structure whose load path is undefined and whose technology type has never carried a train anywhere.


#### Reasons for Rejection

- The plan describes the structure as both 'buoyant' and 'pillar-supported' and 'anchored', which are three incompatible load paths; the premise has not settled how the thing carries weight, so the €40 billion (user constraint) is attached to an undefined object.
- 'Transoceanic' is wrong for a Spain–Morocco link that spans a strait of roughly 14 km at its narrowest; the framing signals the scope was set from an image, not from the site's bathymetry, where the studied route reaches about 300 m depth and the alternative about 900 m.
- Fixing the tunnel at 100 m below sea level over a seabed of up to ~300 m implies pillars or tethers of ~200 m (estimate) in the Strait's strong Atlantic–Mediterranean exchange flow and internal waves, so the depth that was chosen for control is also the depth that maximises both pressure load and structural length.
- High-speed rail at 100 m depth means roughly 11 bar of external pressure (recomputed from seawater head) and no way to evacuate passengers upward in an emergency, which places the worst-case rescue scenario inside a structure with no built precedent for trains.
- A 20-year, €40 billion (user constraint) envelope with 'start ASAP' collides with the fact that the Spain–Morocco fixed link has been in the study stage for decades and seismic monitoring of the route is still being gathered; committing a start before seismic and geotechnical baselines exist converts unknowns into sunk capital.

#### Second-Order Effects

- 0–6 months: Announcing a €40 billion Spain–Morocco commitment diverts attention and political capital from the existing seismic and geotechnical studies, and the 'start ASAP' framing forces contractors to bid on an undefined structural concept.
- 1–3 years: Design basis disputes between the 'buoyant', 'pillar-supported' and 'anchored' concepts surface in tender documents, producing re-scoping, claims, and a budget re-baseline well above €40 billion (estimate).
- 5–10 years: A half-funded 20-year program leaves Spain and Morocco with stranded seabed foundations, no revenue, and a decade of debt service, while conventional bored-tunnel or ferry alternatives have been foreclosed politically by the sunk investment.

#### Evidence

- Case/Incident — Spain–Morocco Strait of Gibraltar fixed-link studies by SECEGSA (ongoing since the 1980s): the Punta Paloma–Cape Malabata route was chosen over an alternative with about 900 m depth, with maximum depth of about 300 m on the chosen route, and seismometers were being installed on it in 2024.
- Case/Incident — Norway E39 Hordfast / Bjørnafjord crossing (2020s): Norway, the leading proponent of submerged floating tunnels, chose a floating bridge for the Bjørnafjord and the Hordfast project was postponed in the 2025–2036 national transport plan, so no such tunnel has been built even there.
- Case/Incident — Channel Tunnel (1994): final construction cost was roughly 80% above the original estimate even though it was a conventional bored tunnel in stable chalk.



### Premise Attack 2 — Accountability
_Rights, oversight, jurisdiction-shopping, enforceability._

**[STRATEGIC] — Pillars-In-The-Abyss Paradox: the plan welds two incompatible ideas, pillars standing on a seabed that lies 300 to 900 metres down and buoyant tubes tethered at 100 metres (user constraint), into a first-of-its-kind structure across a tectonic plate boundary, and attaches a €40 billion, 20-year budget (user constraint) to a design that has no proven form anywhere on Earth.**

**Bottom Line:** REJECT: The Pillars-In-The-Abyss Paradox means the plan cannot even name what holds the tunnel up, and a €40 billion commitment to an unbuildable hybrid is not an infrastructure project but a promise with concrete poured around it.


#### Reasons for Rejection

- Rail passengers and the coastal communities of both countries would be committed, without any real ability to consent, to a never-tested concrete tube hung in the water column of a seismically active strait, where the only escape from a failure is a rescue nobody has ever rehearsed.
- Two sovereign states, one disputed neighbouring enclave and a strait governed by international transit rights leave no single body that can be held answerable when a tube, pillar or anchor fails, and the project relies on diplomatic goodwill surviving 20 years of political turnover on both shores.
- A buoyant tube that floods or breaks loose at 100 metres in one of the world's busiest shipping lanes cannot be recovered, and a first-ever success or failure would be copied at other straits as proof, spreading the same unproven design.
- The plan states an exact budget and depth for a structure whose support concept is internally contradictory (pillars and buoyancy anchors at once), so the €40 billion buys confidence theatre in place of an engineered solution, and money is steered away from the bored-tunnel concept that has actually been studied.

#### Second-Order Effects

- **Months 0–12 (2026-10-12 to 2027-10-12) — The Cracks Appear:** The first geotechnical and seabed surveys show that no continuous seabed within reach supports pillars at the required spacing, and the design is quietly re-labelled rather than abandoned, with sunk consulting fees becoming the project's main output.
- **Months 12–60 (2027-10-12 to 2031-10-12) — Copycats Arrive:** Promoters of floating-tunnel schemes in other deep straits and fjords cite the Spain–Morocco programme as validation, drawing public money toward a concept with no operating precedent.
- **Months 60–144 (2031-10-12 to 2038-10-12) — Norms Degrade:** Cost overruns on a binational megaproject are absorbed by taxpayers on both sides, teaching governments that a headline budget figure for an unbuilt design is a political announcement, not a commitment.
- **Months 144–240 (2038-10-12 to 2046-10-12) — The Reckoning:** A half-built, politically untouchable structure sits in a strait that is critical for shipping and naval movement, with navigation hazards, maintenance liabilities and no agreed owner willing to finish or remove it.

#### Evidence

- Case/Report — SECEGSA (Spain's state body for the fixed link) commissioned Herrenknecht to study a bored rail tunnel under the Camarinal Sill, roughly 28 km long at depths of about 175 to 475 m below sea level; the study concluded that a bored tunnel is technically viable but warned of enormous logistical and economic challenges, and it did not examine a floating or pillar-supported concept.
- Case/Report — Norway's proposed submerged floating tunnel for the E39 Sognefjord crossing has been discussed for years with a reported cost around US$25 billion (not verified as current), and reporting states that no such tunnel has ever been built; a Spain–Morocco version would have no operating precedent at all.
- Law/Standard — UN Convention on the Law of the Sea (UNCLOS) Part III, Art. 38 and Art. 44 (right of transit passage through international straits; bordering states must not hamper it) would constrain any permanent structure placed across the Strait of Gibraltar.
- Narrative — Front-Page Test: a headline reading that a concrete rail tube worth tens of billions of euros has broken from its anchors in the Strait of Gibraltar, and that Spain and Morocco disagree over who must raise it, is the only honest preview of this premise.



### Premise Attack 3 — Spectrum
_Enforced breadth: distinct reasons across ethical/feasibility/governance/societal axes._

**[STRATEGIC] Suspending a rail tube 100 m beneath the surface over a strait plunging to about 900 m stakes €40 billion on a structure type no one has ever built.**

**Bottom Line:** REJECT: A €40 billion rail tube hung 100 m under a 900 m-deep, seismically active strait on a never-built technology is a guaranteed write-off, and it must not be started.


#### Reasons for Rejection

- The premise contradicts itself physically: a tube held at 100 m depth over a seabed reported at up to about 900 m leaves roughly 800 m (recomputed) of open water to bridge, so 'pillar-supported' and 'buoyant and anchored' cannot both be the load path across the deep channel.
- Submerged floating tunnels have never been built anywhere in the world, and Norway is still only studying fjord crossings, so a €40 billion commitment to a high-speed rail tube in an ocean strait skips every intermediate proof of concept.
- A fixed €40 billion over 20 years (user constraint) ignores the record of megaprojects, where the Channel Tunnel finished about 80% over forecast, meaning a first-of-kind tube across a 14 km (approximate) strait would almost certainly outrun any number set at Month 0 (2026-10-12).
- 'Project start ASAP' demands construction commitment while Spain is still deploying only four ocean-bottom seismometers and funding studies at the €1.73 million scale (March 2026), on a boundary between the African and Eurasian plates whose hazard is not yet characterised.
- The tube would cross one of the busiest shipping lanes on Earth and sit athwart the Atlantic–Mediterranean water exchange, exposing it to ship strikes, dropped anchors, sinking vessels, deliberate sabotage with no practical way to inspect or guard 100 m of water, and permanent disruption of the currents and marine life of the strait.

#### Second-Order Effects

- 0–6 months: Months 0-6 (2026-10-12 to 2027-04-12) pour money into design contracts and treaty negotiations before seismic and current data exist, locking two governments into a start date that precedes the engineering answer.
- 1–3 years: Months 12-36 (2027-10-12 to 2029-10-12) expose that pillars cannot reach the deep channel and tethers must carry loads nobody has tested at this scale, forcing redesign, cost revision above €40 billion (estimate), and disputes between Madrid and Rabat over who absorbs overruns.
- 5–10 years: Months 60-120 (2031-10-12 to 2036-10-12) leave stranded approach works, a large public-debt burden and no operating rail link, while the Strait remains uncrossed and the political appetite for any fixed link is poisoned for a generation.

#### Evidence

- Case/Incident — Channel Tunnel (1994): construction cost ended roughly 80% above forecast per Flyvbjerg, Bruzelius and Rothengatter, Megaprojects and Risk (2003), showing how a fixed budget for a first-of-kind undersea link collapses.
- Report/Guidance — SECEGSA Strait of Gibraltar fixed-link studies (2024-2026): the Spanish state company running studies since 1981 reports strait depths up to about 900 m, installed four ocean-bottom seismometers, and received a €1.73 million transfer in March 2026 for technical studies, confirming the hazard and route data are still incomplete (secondary press reports, not verified against primary documents).
- Case/Incident — Norway E39 coastal highway submerged floating tunnel studies (2020s): fjord crossings are still being evaluated and no submerged floating tunnel has been built anywhere, so the proposed technology has no operating precedent (secondary sources, not verified against primary documents).



### Premise Attack 4 — Cascade
_Tracks second/third-order effects and copycat propagation._

**The plan fuses three mutually incompatible engineering concepts (a pillar-supported tunnel, a buoyant tunnel and a cable-anchored tunnel) at a fixed 100 m depth in a strait that is 300-900 m deep, crossing an active plate boundary, with an unbuilt technology class and a €40 billion (user constraint) budget it has no way to defend. This is a strategic flaw: the premise assumes that a technology which has never been built at any scale can be deployed at record depth, in record-hostile conditions, on a schedule that starts "ASAP" before the site has been surveyed.**

**Bottom Line:** Abandon this premise: it specifies a structure that contradicts itself, at a depth the Strait does not support, using a technology that has never been built, so no implementation can rescue it. If a Spain-Morocco link is ever built, it will be on a fundamentally different concept, which is why committing €40 billion and 'ASAP' mobilisation to this one is a guaranteed waste.


#### Reasons for Rejection

- The Three-Masters Paradox: the brief asks for a tunnel that is simultaneously pillar-supported (a rigid, compression-loaded structure), buoyant (a tension-loaded structure that wants to rise) and anchored (a structure held down by tethers). These are different structural systems with different load paths, failure modes, fatigue regimes and maintenance regimes. Combining them without a stated governing concept is not a design; it is a list of buzzwords.
- The Hundred-Metre Fiction: a single fixed 100 m depth is imposed on a seabed that is reported to reach about 900 m on the shortest route and about 300 m on the shallower Camarinal Sill route. Holding a tube at 100 m therefore implies pillars or tethers roughly 200-800 m long (recomputed from reported depths), far beyond anything built or specified for a submerged floating tunnel. At that depth the hydrostatic load is roughly 11 bar (estimate), and the structure is inaccessible to ordinary diving and rescue.
- The Plate-Boundary Gamble: the Strait sits on the Africa-Eurasia plate boundary with strong, variable currents and unstable terrain at Camarinal Sill. A long, flexible, tethered structure with thousands of anchor points is exposed to seismic shaking, internal waves, tidal flow and fatigue along its entire length. A bored tunnel under the seabed is protected from most of this; a water-column tunnel is exposed to all of it.
- The Zero-Precedent Cliff: no full-scale submerged floating tunnel exists anywhere in the world (widely reported; not verified here). Norway's E39 fjord crossings, the closest candidates, are still in study phases. This plan skips the pilot, jumps straight to a 28 km class crossing (reported length of the Umbral route) and attempts it as an international rail link carrying high-speed trains.
- The Study-Budget Mismatch: the people investigating the crossing have been spending single-digit millions of euros (reported: about €2.7 million in 2024, plus €2 million EU funds) on geology and drilling studies. The plan commits €40 billion (user constraint) and a 20-year clock (user constraint) with 'ASAP' mobilisation, before any survey that could determine whether a tunnel at that depth is buildable. The budget is also larger than the reported €7.5-15 billion bored-tunnel estimates, which means it already prices in failure.

#### Second-Order Effects

- Within Months 0-12 (2026-10-12 to 2027-10-12): contractors and consultants enter at the 'ASAP' start and quickly discover that no design basis, code or certification path exists for a 100 m deep submerged tunnel carrying high-speed rail. Resources go to concept studies, not construction, and the 20-year schedule starts to burn with nothing on site.
- Months 12-48 (2027-10-12 to 2030-10-12): geotechnical and metocean surveys of the Strait report seabed, current and seismic conditions that make the pillar, buoyancy and anchor concepts contradict each other. The project is forced either to redesign the core concept (restarting the programme) or to retreat to a conventional bored tunnel under the seabed, with the €40 billion envelope already partly spent on a design that cannot be built.
- Years 4-8 (Months 48-96 = 2030-10-12 to 2034-10-12): scope, schedule and cost growth trigger renegotiation between Spain, Morocco and funders. Cost overruns of the order seen on far simpler mega-projects (the Channel Tunnel overran by roughly 80%, widely reported, not verified) would move the figure well beyond €40 billion (user constraint). Political support in both countries is exposed to election cycles, budget crises and shifting Spain-Morocco relations.
- Years 8-15 (Months 96-180 = 2034-10-12 to 2041-10-12): if any section is installed, anchor fatigue, corrosion, biofouling and inspection at 100 m depth drive a maintenance burden that no operator priced. Rail operations are held hostage to a safety case for fire, flooding and evacuation that regulators cannot approve without precedent.
- Years 15-20 (Months 180-240 = 2041-10-12 to 2046-10-12): the programme ends as a stranded asset or a cancelled one, having consumed a generation of political capital and public money. It also discredits the legitimately feasible alternative (a bored tunnel) by association, delaying the Spain-Morocco fixed link for decades.

#### Evidence

- The Strait of Gibraltar is reported to be up to ~900 m deep on the shortest route and ~300 m on the Camarinal Sill; the Umbral route is ~28 km and ~300 m deep. SECEGSA, the Spanish state body for the crossing, has focused on a bored rail tunnel, not a submerged one, and describes Camarinal Sill as a complex zone with strong currents and unstable terrain (https://en.wikipedia.org/wiki/Strait_of_Gibraltar_Tunnel; https://www.railjournal.com/infrastructure/spain-morocco-tunnel-project-revival/).
- Norway's E39 'coastal highway' programme has studied submerged floating tunnels for fjords such as Sognefjord, Hulsafjord and Sulafjord, but they remain in planning and design, not construction, even on narrow, sheltered, non-seismic fjords with much shorter spans than the Strait (https://livescience.com/55583-floating-underwater-tunnels-planned-for-norway.html).
- The Spain-Morocco fixed-link idea has been studied since the late 1970s through bilateral commissions and SECEGSA (founded 1979; not verified in this check) without a single metre of the crossing built. The most recent revival, with Herrenknecht and Tekpam studies of drilling and seismicity, is still in the survey stage (https://www.railjournal.com/news/spain-morocco-tunnel-project-revival/).
- The Channel Tunnel, a bored tunnel through stable chalk marl in a shallow strait, was delivered with large cost overruns (reported ~80%) and a financial restructuring, as a reference for what a far simpler crossing did to its budget (not verified in this check).



### Premise Attack 5 — Escalation
_Narrative of worsening failure from cracks → amplification → reckoning._

**[STRATEGIC] — The Pillared Float Paradox: the plan fuses two mutually exclusive structural concepts (rigid pillars and tethered buoyancy) across a seismically active, up-to-900 m-deep international strait, so it is a €40 billion (user constraint) promise to build something that has never been built anywhere, in the one place where it is hardest.**

**Bottom Line:** REJECT: This is a promise to anchor a rail tunnel to nothing, in the deepest and most contested water between two continents, at four times the price of the alternative that has actually been studied, and it deserves to exist only as a cautionary slide. The gate is closed.


#### Reasons for Rejection

- The premise strips affected people of any voice: coastal communities, fishers and the populations of Andalusia and northern Morocco would carry a 20-year (user constraint) construction footprint, a permanent hazard to the marine ecosystem of a migration corridor, and the risk of a catastrophic tunnel failure, all without having consented to a concept that no regulator has ever certified.
- Accountability dissolves by design: a pillar-supported, buoyant, anchored tube spanning two sovereign states, an international shipping lane and a continental plate boundary has no single owner of its failure modes, so every flooding, mooring failure or collision would be litigated between two governments, a contractor consortium and insurers who cannot price a risk with zero precedent.
- The systemic risk scales with every kilometre: a rigid, continuous high-speed rail tube spanning a boundary where Africa and Eurasia converge turns one seismic, current-driven or ship-strike event into a total loss of structure, rail traffic and passengers, with no redundancy, no evacuation path of credible length and no way to inspect tethers or pillars at depth.
- The value proposition rots at its root: 'pillars' cannot be founded across a strait that reaches about 900 m deep (reported), 'buoyant' contradicts 'pillar-supported', and a fixed '100 m' depth is asserted as a control the ocean does not grant, which is hubris dressed as a specification, while the bored-tunnel alternative has been studied at only roughly €7.5-10 billion (reported estimate), making the €40 billion figure a fourfold premium for unproven novelty.

#### Second-Order Effects

- T+0–6 months — The Cracks Appear: Contradictions surface at the first design review (pillars versus buoyancy, 100 m target versus 300-900 m bathymetry), geological studies of the Camarinal Sill expose unresolved ground and current conditions, and the Spanish and Moroccan sides begin disputing who funds the studies and who owns the risk.
- T+1–3 years — Copycats Arrive: Cost overruns are absorbed by redefining scope, the concept is marketed as a template for other straits and fjord crossings, and suppliers, consultants and financiers lock in fees on a design that has never been validated, rewarding the pitch rather than the physics.
- T+5–10 years — Norms Degrade: Safety margins are renegotiated downward to protect the schedule, unproven mooring and fatigue assumptions are reclassified as 'accepted risk', and public money already sunk makes cancellation politically unthinkable, so oversight bodies are pressed to sign off.
- T+10+ years — The Reckoning: Either the project is quietly abandoned as a stranded multi-billion-euro (not verified in scale) hole in two national budgets, or a partially completed link enters service with a latent fatigue or mooring failure, and a single event turns a rail corridor into a mass-casualty disaster and a generational collapse of trust in megaprojects.

#### Evidence

- Case/Report — SECEGSA and Herrenknecht Gibraltar studies: the Spanish state company SECEGSA's long-studied concept is a bored rail tunnel about 100 m beneath the seabed on a route around the Camarinal Sill (about 38.7 km total, 27.7 km subsea), with cost estimates reported at roughly €7.5-10 billion, which is a different, buried concept rather than a tethered tube in the water column.
- Case/Report — Norway's Sognefjord submerged floating tunnel proposal: the Norwegian Public Roads Administration has proposed this design for fjord crossings, but reporting confirms that no submerged floating tunnel has ever been built anywhere, and a fjord is a sheltered, narrower water body than an open strait with Atlantic-Mediterranean exchange flows.
- Law/Standard — UN Convention on the Law of the Sea (UNCLOS 1982), Part III, Articles 38 and 44: ships and aircraft enjoy the right of transit passage through straits used for international navigation, and states bordering a strait must not hamper it, which makes a permanent structure in the water column of Gibraltar a legal flashpoint, not only an engineering one.
- Principle/Analogue — Offshore engineering (tension-leg and moored structures): slender tethered bodies in strong, variable currents are governed by cyclic fatigue and resonance, and failure of tethers tends to be progressive and hidden until sudden, which is why such systems demand redundancy and inspection access that a 100 m-deep, multi-kilometre rail tube cannot easily provide.