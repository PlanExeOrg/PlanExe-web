Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 6 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 12 | Material risk with plausible path. |
| ✅ Low | 2 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: This is a subsea civil-infrastructure R&D and delivery programme combining founded pillars and tethered-buoyancy modules—both consistent with established ocean-engineering physics. Hydrostatic buoyancy, foundation bearing capacity, and tension anchorage are observable phenomena deployed in existing deep-water infrastructure. The plan's uncertainties (seabed geometry, geotechnical properties, hydrodynamic loads, construction at scale) are empirical and engineering-design questions, not violations of physical laws. No mechanism asserts creation or destruction of energy, momentum, or mass, nor non-physical causation.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan's core concept—buoyant concrete tube anchored by pillars and/or tension tethers—uses established physics (Archimedes' principle, statics/dynamics, seabed anchorage). Risks are empirical (unverified 100 m depth assumption), engineering (first-of-kind durability, novel design code) and execution (fabrication, immersion in strong currents), not violations of physical law.

**Mitigation**: Delivery Authority: Validate seabed bathymetry and geotechnical conditions via front-loaded campaign (geophysics Month 6 = 2027-04-12 2027, borings Month 12 = 2027-10-12 2027, independent review Month 18 = 2028-04-12 2028); prototype test full-scale tether and transition joint by Month 48 (2030-10-12) 2030 to confirm load paths and material performance under design-basis conditions.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because strategic levers are named and mechanisms outlined (stage gates at Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12; independent cost authority by Month 2 = 2026-12-12; treaty target Month 12 = 2027-10-12), but critical success criteria are conditional on unresolved empirical unknowns: seabed depth (100 m assumption vs. 300–900 m published), seasonal construction windows (May–September constraint unvalidated), opening-demand forecast (4.0 million passengers/year unvetted), and cost-overrun funding path (EUR 2.8–10.8 billion gap unfunded). No binding tie-break rule exists yet (treaty not signed). Customer value (30-minute crossing, EUR 60 fare, modal shift benefit) is stated but not quantified against lever outcomes or demand sensitivity.

**Mitigation**: Delivery Authority: By Month 9 (2027-07-12), assign named owners to produce binding one-pagers for each of the 5 Critical levers (Pillar/Tether, Treaty, Cost Control, Stage Gates, Ecological Permit) specifying: (a) value hypothesis (e.g., "hybrid support concept reduces cost variance from ±EUR 4–8 billion to ±EUR 2–3 billion, freeing EUR 2–5 billion contingency for other risks"), (b) quantified success metrics (e.g., "concept freeze Month 24 = 2028-10-12 if seabed bearing capacity >250 kPa and water depth <900 m confirmed"), (c) decision hooks (e.g., "if seabed depth >400 m across >50% of alignment, trigger funded tether-only fallback cost evaluation within 2 weeks"). Require signed owner commitment and Board approval by Month 12 (2027-10-12).


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies 18+ individual risks with named owners and mitigation actions, but second-order cascades—where depth-redesign compounds with supply-chain inflation and contractor scarcity to exceed the EUR 7.2 billion reserve—are not systematically quantified, modeled in the cost-risk Monte Carlo, or gated with pre-authorized decisions. Cascade scenarios (e.g., pillar fallback + inflation = EUR 9–17 billion overrun) could exhaust contingency by Month 48 (2030-10-12), forcing mid-programme scope cuts or political escalation without a codified decision path.

**Mitigation**: Risk Management & Independent Assurance Lead: Develop a Risk Interdependency Matrix by Month 3 (2027-01-12) linking depth-assumption, inflation, contractor-availability and demand-shortfall risks; quantify joint-probability distributions for 3–4 cascade paths; embed cascade monitoring into monthly cost/schedule reviews from Month 12 (2027-10-12) onwards; pre-authorize scope-reduction or funding-decision triggers for each cascade threshold by Month 6 (2027-04-12).


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan contains explicit gates (Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12) and has identified immersion weather-window constraints (60-90 usable days/year, 8.75-14 year duration for 14 km), but the immersion-feasibility model is not yet validated against Strait-specific climatology (due Month 6 = 2027-04-12), and treaty ratification slip (plausible beyond Month 15 = 2028-01-12) directly compresses casting-yard ramp-up and immersion scheduling. A 6-month slip in any predecessor (treaty, seabed investigation, design freeze) consumes the entire 6-month floating reserve and threatens the Month 132 (2037-10-12) opening baseline. No fallback phased-opening scope has been sized or pre-funded.

**Mitigation**: Programme Schedule & Critical Path Lead: Deliver validated hydrographic/meteorological immersion-feasibility model by Month 6 (2027-04-12) confirming 60-90 usable days/year assumption; if P50 immersion duration exceeds 11 years or seasonal windows <60 days/year confirmed, immediately escalate scope-reduction and timeline-extension options to binational leadership by Month 9 (2027-07-12) for political decision-making before Month 24 (2028-10-12) casting-yard commitment.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names funding sources (Spain, Morocco, EU, multilateral lenders, private debt for EUR 4.4 billion rail systems) and proposes tranched release tied to gates (EUR 0.5B Months 0–12 = 2026-10-12 to 2027-10-12, EUR 2.0B Months 12–36 = 2027-10-12 to 2029-10-12, EUR 1.5B Months 24–48 = 2028-10-12 to 2030-10-12, EUR 20B main construction, EUR 8.8B systems). However, no signed term sheets or binding commitments exist; availability-payment covenants (EUR 230–284 million/year, 30-year duration, critical to close the 0.85x DSCR gap) lack parliamentary budget-law backing (target Month 15 = 2028-01-12); contingency reserve (EUR 7.2 billion) falls EUR 2.8–10.8 billion short of plausible overrun exposure (EUR 10–18 billion, 25–45% of envelope); and no pre-authorized funding-gap decision path exists for overruns >EUR 7.2 billion. Stop rules are proposed (Month 24 = 2028-10-12 treaty gate), but the principal gap—who funds and when—remains open.

**Mitigation**: Finance Ministries of Spain and Morocco + EU DG Move + Multilateral Lenders' Working Group: Execute binding availability-payment covenants (EUR 230–284 million/year, 30-year indexed duration, hard obligation) and deposit in parliamentary budget law by Month 15 (2028-01-12); obtain signed indicative term sheets from ≥2 lead lenders (coupon range 4.0–5.5%, maturity 25–30 years) confirming private debt syndication of EUR 4.4 billion will proceed upon covenant deposit; pre-authorize overrun funding response paths (EUR 2–5B, EUR 5–8B, >EUR 8B scenarios) by Month 6 (2027-04-12).


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the EUR 1.71 billion/km civil baseline is partially substantiated by Fehmarnbelt (EUR 1.1–1.3 billion/km) and HZMB (EUR 600–800 million/km) precedents, adjusted for first-of-kind seismic marine risk (+20–40%). However, no ≥3 vendor quotes exist for fabrication, immersion or tether supply; contingency reserve of EUR 7.2 billion (18%) is demonstrably insufficient against plausible EUR 10–18 billion (25–45%) overrun exposure; and a EUR 2.8–10.8 billion unfunded gap above the reserve remains unresolved pending cost-risk Monte Carlo completion (due Month 9 = 2027-07-12) and a new funding decision (target Month 6 = 2027-04-12).

**Mitigation**: Cost Control Authority: Obtain ≥3 competitive quotes for segment fabrication, tether systems and immersion logistics by Month 3 (2027-01-12); complete Monte Carlo cost-risk model by Month 9 (2027-07-12); take a political funding decision on the EUR 2.8–10.8 billion gap (additional contingency, scope reduction or timeline extension) by Month 6 (2027-04-12) before main construction commitment.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single point estimates without confidence intervals: opening demand 4.0 million passengers/year (no downside scenario documented in baseline); immersion timeline 8.75–14 years range, but critical path targets Month 132 (2037-10-12) without P50/P80 completion distributions; cost baseline EUR 40 billion without published Monte Carlo P50/P80; opening fares EUR 60/trip with no elasticity sensitivity. Downside scenarios (demand 2.5–3.0 million, immersion >18 years, cost EUR 44–46 billion+) exist in the premortem but are not integrated into the formal baseline projections. Lack of explicit contingency planning for these scenarios (e.g., phased-opening cost/scope triggers) indicates optimism bias in the presented baseline.

**Mitigation**: Cost Control Authority: Commission a sensitivity analysis and Monte Carlo cost-risk model by Month 9 (2027-07-12) producing P50/P80/P95 cost distributions and documenting baseline assumptions (EUR 40 billion envelope = P50 or P80?); Demand Forecasting Lead: Deliver independent demand study with upside/downside scenarios by Month 3 (2027-01-12) and model DSCR at 2.5, 4.0 and 6.0 million passengers/year; Programme Schedule Lead: Publish P50/P80 completion-date distributions from the CPM and immersion-feasibility model (both due Month 6 = 2027-04-12).


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because core engineering artifacts exist but with critical gaps that block design maturity and cost certainty. The plan specifies a hybrid support concept (pillars <400 m, tethers >400 m) with interface contracts stated in principle; acceptance tests are sketched (full-scale prototype segment immersion by Month 36 = 2029-10-12, tether pull-test and transition-joint mock-up by Month 48 = 2030-10-12); and integration plan is named (seabed-informed design, staged gates Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12). However, the unverified 100 m anchoring depth assumption directly conflicts with published Strait bathymetry (300–900 m), meaning the support-concept specs and interface definitions cannot be finalized until Month 18–24 (2028-04-12 to 2028-10-12) seabed data are available. Non-functional requirements (fatigue life, dynamic response under seismic loads, concrete durability at 100 m depth) are identified but unquantified; no design code exists for this structure type, so load cases and safety factors remain undefined. Absence of locked interface specs and acceptance criteria before Month 24 (2028-10-12) gates blocks detailed fabrication specs and quality-control protocol sign-off, creating a material gap between concept and production-ready engineering.

**Mitigation**: Chief Technical Officer: Freeze the support-concept interface contracts and acceptance-test plan by Month 18 (2028-04-12) using seabed-campaign findings; produce a unified Segment Fabrication and Quality Control Specification (concrete strength C50 minimum, reinforcement tolerance ±5 mm, ballast ±10 mm, dimensional tolerance ±50 mm) and Integration Map with owners/dates (casting yards, Quality Lab, immersion contractors) by Month 24 (2028-10-12 gate).


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan's critical claims—hybrid support concept viability, treaty ratification by Month 12 (2027-10-12), harmonised environmental consent by Month 24 (2028-10-12), EUR 7.2 billion contingency adequacy, and 60–90 usable immersion days/year—all lack verifiable evidence at Month 0 (2026-10-12). The foundational claim that "100 m anchoring depth is viable" directly conflicts with published Strait bathymetry of 300–900 m and depends entirely on seabed borings due Month 18 (2028-04-12). No independent cost-risk model, treaty legal analysis, ecological baseline, or immersion-feasibility model exists. These are not minor gaps; they gate the €4 billion casting-yard advance (Month 24 = 2028-10-12) and the €20 billion main-construction tranche (Month 36–48 = 2029-10-12 to 2030-10-12).

**Mitigation**: Delivery Authority: Deliver and independently review (by Month 18 = 2028-04-12): (1) seabed geotechnical report with bearing-capacity analysis and support-concept feasibility assessment; (2) independent Monte Carlo cost-risk model (Month 9 = 2027-07-12) with P50/P80 distributions; (3) draft treaty with legal-compatibility review from both states' advisers (Month 6 = 2027-04-12); (4) immersion-feasibility model validating 60–90 usable days/year (Month 6 = 2027-04-12); (5) completed 12-month ecological baseline confirming seasonal construction windows (Month 12 = 2027-10-12). Gate casting-yard advance and main-construction release on evidence completion, not on schedule.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because critical deliverables (support concept frozen, treaty ratified, environmental consent harmonised, cost authority independent, immersion feasibility validated) lack specific, verifiable acceptance criteria with quantifiable KPIs. For example, "support concept freeze" is conditional on "no show-stoppers" from seabed data (Month 18 = 2028-04-12 gate), but "show-stopper" is undefined; "harmonised consent" lacks a numerical benchmark (e.g., "both environment ministries sign one permit, zero open conditions"); "immersion feasibility" uses a vague P50 threshold without documented climate data or wave-height definition.

**Mitigation**: Delivery Authority: Define SMART acceptance criteria for each of 8 gates (Months 9, 15, 24, 36, 48, 60, 108, 120 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2035-10-12, 2036-10-12) by Month 6 (2027-04-12), specifying for each: (1) objective pass/fail criteria (e.g., "support concept: bearing capacity >250 kPa at >=5 of 8 borings AND <50% of alignment deeper than 400 m" OR "treaty: ratified in both parliaments, Board operationalized, CEO authority codified"); (2) one quantifiable KPI per deliverable (e.g., "immersion feasibility: P50 duration ≤11 years AND ≥60 usable days/year confirmed by 30-year Strait climatology"). Gate slip >3 months triggers escalation.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the dual-yard feature adds significant cost (EUR 500 million–2 billion premium, estimate) and complexity (parallel workforce training, divergent quality cultures, coordination overhead) without directly supporting the core objectives of delivering a 14 km functional crossing within the €40 billion budget. The feature is justified on political grounds ("industrial and employment benefits") rather than technical necessity; the plan acknowledges that quality variance between yards creates "a durability and watertightness risk at joints" (Decision 5, SWOT). A single consolidated yard with a secondary finishing facility in Morocco would preserve political visibility while eliminating the cost and quality-variance exposure, making the dual full-scale production model a candidate for value-engineering reduction or backlog deferral.

**Mitigation**: Delivery Authority / Binational Programme Director: Produce a one-page Benefit Case for the dual casting-yard model by Month 9 (2027-07-12) quantifying: (1) KPI—political acceptance likelihood (parliamentary ratification probability with vs. without dual yards); (2) Owner—Binational Board; (3) Cost—EUR 500 million–2 billion cost premium (dual vs. single consolidated yard). If benefit case cannot defend the premium cost against available contingency or if alternatives (single primary + secondary finishing) satisfy political requirements at lower cost, move secondary full-scale yard to project backlog and consolidate primary production at Algeciras, releasing contingency for core-objective delivery.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the Submerged Floating Tunnel Engineering Lead (Chief Technical Officer) is mission-critical to resolving the unverified 100 m depth assumption (versus published Strait depths of 300–900 m), which gates the hybrid support-concept freeze at Month 24 (2028-10-12). This role requires extremely rare expertise: submerged-tunnel design (zero built precedents), deep-water geotechnical foundations, tether-and-buoyancy hybrid systems, and seismic dynamic response at 100 m depth. Global talent for this exact combination is estimated at fewer than 10 individuals. A hiring gap or poor appointment delays seabed-investigation review by 3+ months, consuming the entire 6-month schedule reserve and threatening the Month 132 (2037-10-12) opening. Expertise is both critical and rare.

**Mitigation**: Delivery Authority: Identify and secure the Chief Technical Officer with proven deep-water floating-structure or immersed-tunnel expertise (e.g., Fehmarnbelt, HZMB, or offshore platform background) and submerged-tunnel seismic-design knowledge by Month 1 (2026-11-12). Validate market availability (contact 5+ international marine-engineering firms and 3+ classification societies for candidate lists) within 2 weeks. Offer a 5-year fixed contract with a 3-month probation, backfilled by a deputy. Target recruitment close within 4 weeks.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan's legal and regulatory framework is partially developed but critically incomplete. The binational treaty is targeted for ratification by Month 15 (2028-01-12), which is aggressive for two parliaments and a maritime-boundary regime. The plan identifies environmental permitting across Spanish, Moroccan and EU authorities, but has not codified a single unified consent pathway—parallel national assessments with a coordination committee risk 6–12 month delays or divergent conditions mid-construction. A single Lead Certifier is proposed by Month 6 (2027-04-12), but no international design code exists for this structure type; the certifier's authority to bind both states and the procedure for resolving disputes with national regulators remain undefined. Seasonal ecological constraints (May–September work window estimated at 150 days/year, potentially 60–90 days/year net) are acknowledged but not validated, and if enforced, could extend immersion from 8.75–14 years to 18–25 years, threatening the Month 240 (2046-10-12) hard deadline. The mitigation pathway (secure binding unified consent and codify the Lead Certifier's authority by Month 12 = 2027-10-12) is plausible but depends on political will and treaty clarity that do not yet exist.

**Mitigation**: Binational Programme Director + Environmental Permitting Lead: By Month 9 (2027-07-12), establish a Joint Environmental Harmonisation Committee and secure written commitment from both environment ministries to issue a single unified permit (not parallel national permits) by Month 24 (2028-10-12), latest Month 30 (2029-04-12), with binding seasonal construction windows and mitigation obligations enforceable across both states. By Month 6 (2027-04-12), appoint the Lead Certifier and codify explicit authority to issue conditional design approvals, remediation timelines (30 days max for Board response), and escalation rules (unresolved findings trigger political review within 30 days). Embed both commitments in the treaty by Month 12 (2027-10-12).


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan provides no documented strategy for sustaining tunnel operations beyond Month 132 (2037-10-12) service opening across the 50-100 year asset life. Concrete durability at 100 m depth under seismic and fatigue cycling is unproven; tether longevity under continuous marine loads remains unquantified; annual maintenance cost estimates (EUR 200 million baseline) lack 50-year escalation modeling; personnel succession planning and specialized-maintenance skill availability are not addressed; technology obsolescence risks (ventilation, signalling, monitoring systems) lack a refresh roadmap. The debt-service model (private EUR 4.4 billion at 4.5%, EUR 270 million/year) assumes stable EUR 240 million/year passenger revenue indefinitely, but demand risk (plausible 20-40% shortfall) directly threatens operational solvency. No O&M reserve fund governance or catastrophic-failure liability framework exists. Absence of a credible, funded 50-year operational sustainability plan blocks proof-of-insurability (due Month 108 = 2035-10-12) and creates existential risk if concrete deterioration, tether fatigue or catastrophic failure emerges post-opening.

**Mitigation**: Chief Technical Officer and Long-Term Operations & Sustainability Lead (appointed Month 6 = 2027-04-12): Develop a 50-year O&M Manual and Condition-Based Maintenance Plan by Month 108 (2035-10-12), embedding durability requirements into design by Month 24 (2028-10-12); establish an O&M Reserve Fund (EUR 200-400 million, inflation-indexed) funded from fare revenue; lock insurance coverage terms for operational liability and infrastructure-failure scenarios by Month 12 (2027-10-12); conduct independent structural assessment every 10 years post-opening.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies critical hard constraints (seabed depth, zoning/permits, environmental consent, shipping corridor, egress design) but fails to lock definitive approvals before major capital commitment. The core depth assumption—100 m anchoring—conflicts with published Strait bathymetry of 300–900 m and remains unverified until Month 18 (2028-04-12) seabed investigation completes. No written confirmation from environmental authorities, maritime authorities or zoning regulators exists at Month 0 (2026-10-12). The casting-yard advance (EUR 2–5 billion) is released at Month 24 (2028-10-12) gate, contingent on seabed data, treaty ratification, and environmental consent—three critical dependencies that individually carry 12–24 month slip risk. A fatal-flaw screen (validation of all constraints against actual authorities and data) is not scheduled before Month 24 (2028-10-12), by which time early spending is sunk.

**Mitigation**: Delivery Authority: Execute a fatal-flaw constraint screen with Spanish and Moroccan zoning/transport authorities, maritime authorities (IMO), environment regulators and classification societies by Month 9 (2027-07-12)—before casting-yard commitment. Obtain: (1) written confirmation that a no-anchoring corridor ±500–1000 m is acceptable to IMO and multi-flag shipping (Month 12 = 2027-10-12); (2) signed environmental-ministry position on unified consent viability and seasonal windows (Month 12 = 2027-10-12); (3) zoning and land-use sign-off from both states (Month 12 = 2027-10-12). Define dated NO-GO thresholds: if seabed depth >400 m across >50% of alignment, trigger fallback cost/schedule decision by Month 24 (2028-10-12) gate; if environmental consent timeline exceeds Month 30 (2029-04-12), halt fabrication start.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies and documents 8 major external dependencies (seabed, contractors, supply-chain, weather windows, environmental permits, governance, shipping, ecology) and proposes controls (SLAs, framework agreements, independent cost authority, design-change control, coordinating committees, hard stop rules). Tested fallbacks exist for governance deadlock (single lead certifier), seabed uncertainty (three support-concept options pre-sized by Month 9 = 2027-07-12), and casting-yard labor (dual yards with parallel production). However, critical resilience gaps remain: immersion weather-window resilience is unproven (validation due Month 6 = 2027-04-12); seabed fallback cost (EUR 4–8 billion pillar redesign) exceeds available contingency (EUR 6.8–6.95 billion) by EUR 0.8–1.2 billion; contractor scarcity is unmitigated by binding capacity commitments; environmental-permit divergence lacks binding tie-break authority; and schedule margin (6 months floating reserve) is entirely consumed by a single 6-month slip in any predecessor. No phased-opening or reduced-scope fallback has been pre-sized or pre-funded, so contingency-plan activation requires mid-programme political decisions and new funding tranches with no pre-authorized pathway.

**Mitigation**: Delivery Authority: By Month 9 (2027-07-12), deliver validated immersion-feasibility model confirming 60–90 usable days/year assumption against 30-year Strait climatology; if P50 immersion duration exceeds 11 years or usable days <60/year, immediately escalate phased-opening cost-benefit and reduced-scope options to binational leadership. By Month 6 (2027-04-12), secure binding framework agreements with ≥2 tier-1 suppliers per critical item (tethers, buoyancy modules, joints, immersion cranes) with guaranteed availability windows and escalation caps (inflation +2%, capped 5% per tranche). By Month 3 (2027-01-12), obtain written confirmation from environmental ministries that unified environmental permit is feasible by Month 24 (2028-10-12), and codify tie-break escalation rule (unresolved divergence triggers political review within 30 days). By Month 6 (2027-04-12), pre-size phased-opening (7–10 km at Year 1, balance by Year 5) and reduced-scope (single-tube vs twin) cost-benefit analyses; pre-authorize political decision trigger if seabed fallback exceeds available contingency.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because both stakeholders state support for the tunnel, but their underlying incentives diverge sharply on the timing and bindingness of the EUR 230–284 million/year availability-payment commitment. Public finance authorities (Spain, Morocco, EU) are incentivized to defer availability payments until opening-year demand validates the need, minimizing upfront public liability. Private rail operators and debt investors are incentivized to lock binding availability payments by Month 15 (2028-01-12), backed by parliamentary budget law, to enable early debt syndication at baseline coupon (~4.5%) and protect equity returns. This conflict is unresolved: the plan identifies availability payments as essential to close the 0.15x DSCR gap, yet no covenant exists and decision is unscheduled before the Month 24 (2028-10-12) main-construction gate, risking a mid-programme financing crisis and 6–12 month covenant renegotiation.

**Mitigation**: Finance Ministries of Spain and Morocco + EU DG Move + Multilateral Lenders: Execute binding availability-payment covenants (EUR 230–284 million/year, 30-year indexed duration, hard obligation backed by parliamentary budget law) and deposit by Month 15 (2028-01-12); obtain signed indicative term sheets from ≥2 lead lenders confirming private debt syndication of EUR 4.4 billion at baseline coupon will proceed upon covenant deposit, by Month 12 (2027-10-12).


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan names decision gates (Months 9, 15, 24, 36, 48, 60, 108, 120 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2035-10-12, 2036-10-12), proposes delegated approval thresholds (CEO <2%, Board 2–5%, >5% escalates) and mentions monthly cost tracking and quarterly reviews. However, a binding Programme Control Charter with monthly KPI dashboard, quantified variance thresholds, named escalation owners, and decision deadlines does not yet exist; the Project Cost Authority (due Month 2–3 = 2026-12-12 to 2027-01-12) is unnamed and has no published authority limits. Vague references to 'monitor' and 'review' lack sufficient operational detail.

**Mitigation**: Delivery Authority: Publish a Programme Control and Governance Charter by Month 6 (2027-04-12) specifying monthly dashboard KPIs, cost-variance thresholds with escalation owners and decision deadlines (>5% variance flagged within 1 week), quarterly review schedule, Project Cost Authority authority limits, and change-control approval timelines. Operationalise the first monthly dashboard by Month 12 (2027-10-12) visible to Board, lenders and insurers.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan identifies 18+ individual risks with named owners and mitigation actions, and the premortem documents 9 failure modes (FM1–FM9) linking root causes to cascades (e.g., "treaty slip → design cycles extend → immersion window compresses"). However, no formal cross-impact matrix, bow-tie diagram, or FTA exists to systematically surface multi-node cascades. Critical cascade scenarios—such as pillar-fallback redesign (EUR 4–8 billion) compounding with supply-chain inflation and casting-yard delays to exceed the EUR 7.2 billion reserve by Month 48 (2030-10-12)—lack quantified joint-probability modeling or pre-authorized no-go thresholds. The Monte Carlo cost-risk model is not yet completed (due Month 9 = 2027-07-12); without it, cascade exposure (e.g., seabed redesign + demand shortfall + DSCR covenant breach) remains unquantified. Mitigation exists as scenario planning, but not as operationalized cross-impact governance tied to monthly decision triggers.

**Mitigation**: Risk Management Lead: Develop a formal Risk Interdependency Matrix and Bow-Tie diagram by Month 6 (2027-04-12) mapping the 18+ risks, identifying ≥3 cascades with cumulative exposure ≥EUR 3 billion or ≥6 months critical-path slip; embed cascade-monitoring into the monthly cost/schedule reviews from Month 12 (2027-10-12) onwards; pre-authorize no-go thresholds (e.g., if pillar redesign + inflation exceeds EUR 10 billion cumulative, trigger phased-opening decision) by Month 6 (2027-04-12).