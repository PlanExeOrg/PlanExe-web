Persuasive elevator pitch.

# Strait of Gibraltar Submerged Floating Tunnel

## Project Overview

Imagine a permanent high-speed rail link connecting Europe and Africa—no ferries, no delays, no dependency on weather or shipping routes. The **Strait of Gibraltar Submerged Floating Tunnel** will deliver exactly that: a 14 km engineering marvel planned at an assumed 100 m anchoring depth (unverified planning assumption, to be confirmed by the seabed campaign before the Month 24 (2028-10-12) concept freeze), carrying passengers between Spain and Morocco in 30 minutes flat. At EUR 40 billion and 20 years, it is the planet's first **submerged floating tunnel for rail**, and it will unlock **transformative trade, migration and economic integration** across two continents.

This is not a mere concept—it is a pragmatic **hybrid design**, a working design to be confirmed by the seabed campaign and independent review, backed by staged gates, independent certification and paired delivery yards that share engineering leadership and industrial benefit between two nations. The crossing runs from Punta Paloma/Tarifa (Spain) to Punta Malabata/Tangier (Morocco) via the Camarinal Sill corridor. The hybrid support concept pairs founded pillars on shallow shelves and sills (water depth <400 m) with tether groups or buoyancy modules across deep channels (>400 m). Success rests on **proven geotechnical data, unified governance, and disciplined cost control**—but it can succeed, and when it does, it rewrites what is possible in cross-border infrastructure.

## Target Audience

**Primary audiences** are finance ministers, transport ministers, EU institutional leaders, and multilateral development banks (World Bank, EBRD, EIB) who control the EUR 40 billion envelope and treaty ratification.

**Secondary audiences** include project-finance lenders, insurance underwriters, infrastructure investors and pension funds evaluating a first-of-kind concession structure.

**Tertiary audiences** comprise Spanish and Moroccan rail operators and regional port authorities seeking continental connectivity and competitive advantage.

All audiences share an appetite for transformational infrastructure and a need for defensible **risk allocation** and clear governance.

## Risks and Mitigation Strategies

- **Depth assumption uncertainty:** The plan's 100 m anchoring depth is unverified against published Strait depths of several hundred metres to ~900 m. A pillar-only redesign would add EUR 4–8 billion and 12–36 months, consuming 56–111% of the EUR 7.2 billion contingency reserve. *Mitigation:* Front-load the seabed campaign (Months 0–18 = 2026-10-12 to 2028-04-12) and freeze the hybrid support concept only after independent geotechnical review; parallel exploratory gallery supplies evidence for either concept.

- **Treaty ratification delays or sovereignty disputes:** These could stall the entire programme. *Mitigation:* Establish negotiation team by Month 1 (2026-11-12) and set a hard stop rule—no release of the EUR 20 billion main-construction tranche if treaty is not ratified by Month 24 (2028-10-12).

- **Cost overruns:** Plausible cumulative overruns of EUR 10–18 billion (25–45%) exceed the EUR 7.2 billion reserve. *Mitigation:* Independent Project Cost Authority by Month 2 (2026-12-12), tranched release tied to gate evidence, and a distinct EUR 1–2 billion Design Change Reserve for geotechnical surprises.

- **Schedule compression from weather windows:** Only 60–90 usable immersion days per year could stretch 14 km of tube across 8.75–14 years. *Mitigation:* Build the CPM schedule and weather-window model by Month 6 (2027-04-12), hold a 6-month floating reserve, and escalate if the Month 240 (2046-10-12) horizon becomes unachievable.

## Metrics for Success

- **Service opening:** Trains carrying certified passengers through the tunnel before Month 132 (2037-10-12) (baseline); latest acceptable completion Month 240 (2046-10-12).

- **Capital discipline:** Spending remains within the EUR 40 billion envelope; contingency reserve is spent by Board decision only, not eroded by scope creep.

- **Stage gates (all passed):**

  - Seabed concept validation by Month 18 (2028-04-12)
  - Support-concept freeze by Month 24 (2028-10-12)
  - Pilot-segment immersion by Month 36 (2029-10-12)
  - Production maturity by Month 48 (2030-10-12)
  - Immersion completion by Month 120 (2036-10-12)

- **Independent certification:** Lead Certifier issues final certification for operations before opening; no open major findings remain.

- **Treaty and governance:** Ratified by Month 15 (2028-01-12) at latest; binational coordinating commission legally active and making decisions within prescribed timescales.

- **Ridership and revenue:** Planning case of 4.0 million passengers/year at opening (EUR 240 million annual passenger revenue) reached within 2 years of opening; private debt service covered by availability payments (EUR 230 million/year funded by states/EU).

- **Environmental durability:** Mitigation measures delivered and legally durable; no injunctions or stop-work orders occur post-Month 24 (2028-10-12).

- **Operational safety:** No submerged incident (anchor strike, collision, sabotage) breaches the passive-hardening design case.

## Stakeholder Benefits

- **Governments of Spain and Morocco:** Permanent continental link, joint economic zone, shared engineering capability built on both coasts, and political legacy of binational cooperation.

- **EU and Multilateral Lenders:** Proof of first-of-kind infrastructure financing; demonstration that staged gates and independent certification can unlock private participation in unprecedented projects; support for transport connectivity and modal shift targets.

- **Private Investors and Lenders:** EUR 8.8 billion rail systems and operations financed under availability-payment concession, with public civil works (EUR 24 billion) providing a bankable counterparty; tailored **risk allocation** with private carrying operations risk and public carrying construction risk on a first-of-kind concept.

- **Rail Operators:** Seamless through-running to the opposite coast, elimination of ferry delays and dependencies, access to a new passenger and freight market, and capacity for 5–6 million annual passengers by Year 10.

- **Port and Logistics Communities:** Enhanced hinterland connectivity, competitive advantage in container and vehicle throughput, and integration into a pan-European transport corridor.

- **Engineering and Industrial Sectors:** Thousands of skilled jobs at paired casting yards (Algeciras, Tanger Med), international reputation for deep marine and tunnel expertise, and transfer of **know-how** across two nations.

- **Insurers:** Clear safety case (self-rescue egress design), independent certification regime, and passive hardening against shipping and sabotage hazards reduce unquantified risk.

## Ethical Considerations

The project treats **environmental and social risk** with formal rigour. A joint ecological baseline from Month 0 (2026-10-12), with multi-year cetacean-migration and habitat monitoring, ensures that mitigation is evidence-based and legally durable, not post-hoc. Co-design of mitigation measures with environmental NGOs and coastal communities by Month 3 (2027-01-12) builds legitimacy and reduces later injunctions.

**Paired casting yards** at Algeciras and Tanger Med deliberately spread industrial employment and skills benefit across both nations, rejecting a single-coast monopoly that would concentrate wealth and political power. The governance model—a coordinated concession with a binational commission holding tie-break authority—ensures neither state can unilaterally change safety, environmental or operational rules, protecting both the local environment and the other nation's interest.

**Transparency** is hardwired into the delivery: all stage gates are assessed by an independent Lead Certifier and technical panel, whose findings are public; design changes >5% trigger treaty-level political review. A 6-month floating schedule reserve is held outside the critical path and released by binational decision, preventing corner-cutting under time pressure that would expose workers or the environment to uncontrolled risk.

The project explicitly rejects a profit-maximisation model; the planning case assumes EUR 60 per one-way trip and anchors on **public accessibility**, ensuring that the crossing remains affordable and broadly usable across income levels.

## Collaboration Opportunities

- **Academic and Research Institutions:** Joint research consortia with Spanish and Moroccan universities and the Norwegian E39 Rogfast programme on tether dynamics, seismic design and emergency egress accelerate certification and reduce design iteration.

- **Classification Societies and Independent Certifiers:** A single Lead Certifier appointment by Month 6 (2027-04-12), coupled with an independent technical panel, convenes multiple global expertise centres to co-produce the project-specific design code, distributing liability and building international consensus.

- **Adjacent Governments and Regional Organisations:** Portugal, France and the European Commission participate in IMO discussions on the no-anchoring corridor (Month 12 = 2027-10-12 gate) and shipping-security protocols, embedding the crossing into the broader Mediterranean transport strategy.

- **NGO and Community Co-Design:** Environmental NGOs, fishing cooperatives and coastal municipalities jointly define mitigation measures (Months 0–24 = 2026-10-12 to 2028-10-12), converting potential opposition into ownership and reducing permitting risk.

- **Existing Study Entities:** SECEGSA and SNED (the Spanish and Moroccan study bodies) transition from advisory to subordinate delivery roles under the new binational authority, preserving institutional memory and local relationships while consolidating decision power.

- **Immersion Contractors and Marine Specialists:** International towing, heavy-lift and positioning consortia provide technical peer review and bring global floating-tunnel and immersed-tube precedent into design gates, reducing first-of-kind blind spots.

## Long-term Vision

The Strait of Gibraltar Submerged Floating Tunnel is a 50-year-plus asset, opening a permanent continental pathway for 100 million+ journeys and billions of euros in trade. Beyond opening, the project establishes a **new class of deep-water infrastructure and binational delivery governance** that will be replicated in other straits (Cook Strait, New Zealand; Korea Strait; others).

**Engineering advances** in tether design, dynamic response under seismic loading, and emergency egress at depth become global public knowledge, accelerating adoption of submerged floating tunnels for climate-resilient transport in fjords, straits and deep channels worldwide. On both coasts, the paired casting yards—Algeciras and Tanger Med—evolve into permanent **centres of marine-engineering excellence**, attracting follow-on megaprojects in subsea cables, offshore wind and deep-water mining infrastructure.

The 20-year delivery programme trains thousands of Spanish and Moroccan engineers, tunnel workers and offshore specialists, creating a **skilled labour pool** that sustains regional competitiveness for decades. Operationally, the crossing is an availability-payment concession, so its long-term sustainability depends on evidence-based ridership (EUR 240 million/year passenger revenue at opening, growing to EUR 360–450 million/year by Year 10) and cost discipline; any shortfall triggers a political decision to subsidise or renegotiate terms, embedding the link into the **social contract** of both nations.

The project's 50-year maintenance and monitoring regime—seabed sensors, tether inspections, joint watertightness surveys—becomes a continuous feedback loop that informs design of the next generation of submerged tunnels and shapes seismic, current and collision-impact standards across the maritime industry.

## Call to Action

- **Ratify the binational treaty by Month 12 (2027-10-12)** (target) and Month 15 (2028-01-12) (latest acceptable) and appoint the lead certifier and binational coordinating commission by Month 6 (2027-04-12).

- **Begin the seabed investigation and ecological baseline immediately** (Month 0 = 2026-10-12) to retire the depth-assumption uncertainty before the concept freeze (Month 24 = 2028-10-12). Seabed campaign includes geophysics of full corridor by Month 6, 5–8 borings and in-situ tests by Month 12 (2027-10-12), and seismometer array by Month 9 (2027-07-12).

- **Fund the first tranche** (EUR 0.5 billion) to unlock seabed and permitting work, and establish the **Project Cost Authority by Month 2 (2026-12-12)** to enforce discipline on the EUR 40 billion envelope.

- **Establish negotiation team and ministerial steering committee by Month 1 (2026-11-12)** to advance treaty ratification and set a hard stop rule: no release of the EUR 20 billion main-construction tranche if treaty is not ratified by Month 24 (2028-10-12).

- **Build CPM schedule and weather-window model by Month 6 (2027-04-12)** to validate immersion feasibility and schedule risk within the Month 240 (2046-10-12) latest-completion horizon.

The path is clear; execution decides whether this becomes a landmark or a cautionary tale.