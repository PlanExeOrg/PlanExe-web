
## Strengths 👍💪🦾
- Hybrid support concept (founded pillars on shallow sills, tethers or buoyancy modules in channels deeper than 400 m, proposed threshold) matches seabed rather than the unverified 100 m assumption.
- Stage-gated funding: EUR 4.0 billion (10% of envelope) pre-construction tranches before the EUR 20 billion main-construction release, plus a stop rule if the treaty is not ratified by Month 24 (2028-10-12).
- Explicit EUR 7.2 billion contingency (18%, proposed threshold) and an independent Project Cost Authority by Month 2 (2026-12-12), escalating variance above 5%.
- Governance design: treaty-backed commission with Board tie-break, single lead certifier and delegated approval thresholds.
- Existing Camarinal Sill data from SECEGSA and SNED, and paired industrial ports (Algeciras, Tanger Med) with short tows.
- Close precedents for governance and immersion logistics (Fehmarnbelt, HZMB) and floating-tunnel design-basis work (E39 Norway).

## Weaknesses 👎😱🪫⚠️
- Core depth assumption (100 m) conflicts with published depths of several hundred m up to ~900 m; costs are unreliable until the seabed campaign reports.
- Contingency of EUR 7.2 billion is below plausible overruns of EUR 10-18 billion (estimate); unfunded gap EUR 2.8-10.8 billion needs a new funding decision.
- Immersion capacity: 60-90 usable days/year gives 8.75-14 years for 14 km (estimate), leaving little slack against Month 120 (2036-10-12) baseline.
- Revenue cannot service debt: operating surplus EUR 40 million/year vs debt service ~EUR 270 million/year (DSCR ~0.15x, estimate); depends on availability payments.
- Feeder-line financing is an open decision and sits outside the envelope.
- Two-yard model risks divergent quality cultures at joints; labour shortages may slow ramp-up 10-20% (estimate).
- No design code exists; egress (EUR 0.5-2 billion) and hardening add mass to buoyancy-sensitive tubes.

## Opportunities 🌈🌐
- Seabed campaign (EUR 80-150 million) can retire the largest uncertainty early and anchor lender confidence.
- EU and multilateral co-financing and availability-payment structures can give political cover and lower cost of capital.
- Joint ecological baseline plus up-front mitigation (artificial reefs, research) can make consents defensible and build public support.
- Prototype, pilot segment and tether tests create reusable know-how and a design code others could adopt.
- Through-running with standard European gauge could integrate the Iberian and Moroccan networks; anchor-tenant agreements with operators build demand.
- Regional skills legacy and training academies strengthen political parity and local support.
- Pilot results could allow phased opening or scope options if the horizon proves tight.

## Threats ☠️🛑🚨☢︎💩☣︎
- Treaty ratification slips beyond Month 15 (2028-01-12) or political turnover over 20 years stalls tranches.
- Seismic hazard on a plate boundary with no precedent design code; certification disputes can add 6-12 months each.
- Environmental injunctions or divergent national consents in a protected migration corridor.
- Contractor scarcity and day-rate rises of 30-50% (estimate) from competing offshore wind and LNG work; 20-year inflation.
- Ship strikes, anchor drag, sabotage in a busy strait; IMO consent for exclusion corridor may take 2-4 years.
- Demand 20-50% below forecast and insurer reluctance to price first-of-kind fatigue and durability risk.
- Pillar-only redesign (+EUR 4-8 billion, +12-36 months) could exceed the available reserve.

## Recommendations 💡✅
- Launch the seabed and geohazard campaign immediately: geophysics by Month 6 (2027-04-12), borings by Month 12 (2027-10-12), independent review by Month 18 (2028-04-12); owner: delivery authority technical director. Freeze the concept only at Month 24 (2028-10-12).
- Establish the negotiation team and ministerial steering committee by Month 1 (2026-11-12); draft the procurement framework by Month 6 (2027-04-12); target ratification Month 12 (2027-10-12), with the Month 24 (2028-10-12) stop rule applied; owner: both transport ministries.
- Stand up the Project Cost Authority by Month 2 (2026-12-12); hold the EUR 7.2 billion at gate level; take a funding decision on the EUR 2.8-10.8 billion gap before the Month 24 (2028-10-12) gate; owner: finance ministries and EU/multilateral lenders.
- Deliver the CPM schedule at P50/P80 by Month 1 (2026-11-12) and the weather-window immersion model by Month 6 (2027-04-12); if the horizon fails, escalate scope options (phased opening) at Month 9 (2027-07-12); owner: programme director.
- Appoint the lead certifier by Month 6 (2027-04-12) and issue the design code by Month 9 (2027-07-12); fund tether and joint tests (EUR 50-100 million) by Month 48 (2030-10-12); owner: binational technical panel.
- Secure anchor-tenant agreements with rail operators by Month 24 (2028-10-12) and size availability payments to close the debt-service gap; decide feeder-line financing by Month 12 (2027-10-12); owner: rail operators and treasuries.

## Strategic Objectives 🎯🔭⛳🏅
- Complete the full-corridor seabed campaign and independent review by Month 18 (2028-04-12) within EUR 80-150 million (estimate), with the support concept frozen by Month 24 (2028-10-12).
- Ratify the binational treaty with legal personality, Board tie-break and single lead certifier by Month 12 (2027-10-12), no later than Month 15 (2028-01-12).
- Immerse a pilot segment of at least 500 m in sheltered water by Month 36 (2029-10-12) for EUR 100-150 million (estimate), with critical-path slip at or below 6 months.
- Obtain harmonised environmental consents from both states by Month 24 (2028-10-12), no later than Month 30 (2029-04-12), with EUR 250-400 million mitigation committed.
- Hold variance within 5% of each tranche and secure a funded plan for the EUR 2.8-10.8 billion gap by Month 24 (2028-10-12), tracking cost per km of tube delivered.

## Assumptions 🤔🧠🔍
- Hybrid concept remains feasible once seabed data are available.
- Both states ratify a treaty with tie-break rules by Month 15 (2028-01-12).
- 60-90 immersion days/year and 500-800 m per yard per year (estimate).
- Civil works (EUR 24.0 billion) stay on public balance sheets; rail systems are privately financed via availability payments.
- Feeder-line upgrades are outside the EUR 40 billion envelope.
- Opening demand is 4.0 million passengers/year at EUR 60 fare (estimate).

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Actual bathymetry, geology and fault data along the alignment.
- Share of civil funding by each state, EU and multilateral lenders.
- Cost estimates for deep-section bored fallback and phased opening.
- Single- vs twin-tube configuration and cross-section.
- Independent demand forecast and freight volumes.
- Insurer appetite and premium terms for fatigue and security risks.
- Contractor market capacity and availability for immersion.
- Political commitment of both governments across election cycles.

## Questions 🙋❓💬📌
- What seabed finding at Month 6-12 (2027-04-12 to 2027-10-12) would make you abandon the hybrid concept, and what is the funded response?
- Who funds the EUR 2.8-10.8 billion gap between reserve and plausible overrun, and when is that decided?
- Would both governments accept binding tie-break and a single regulator, and what happens if not by Month 24 (2028-10-12)?
- If immersion needs the upper 14 years, which scope reductions or phased opening are acceptable?
- Which public funders will commit to availability payments covering the ~EUR 230 million/year debt-service gap?