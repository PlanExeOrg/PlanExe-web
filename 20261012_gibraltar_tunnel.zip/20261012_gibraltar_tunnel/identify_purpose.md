**Purpose:** business

**Purpose Detailed:** Large-scale transnational infrastructure project: design and construction of a pillar-supported, submerged buoyant concrete tunnel system anchored about 100 m below sea level, carrying high-speed rail between Spain and Morocco. It is a public-scale, cross-border infrastructure initiative aimed at transport connectivity and economic integration, most plausibly delivered as a government or bi-national programme (possibly with private participation).

**Topic:** 20-year, €40 billion Spain–Morocco submerged floating tunnel for high-speed rail across the Strait of Gibraltar