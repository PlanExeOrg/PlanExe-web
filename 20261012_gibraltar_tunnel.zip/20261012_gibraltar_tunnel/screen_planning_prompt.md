**Verdict:** 🟢 USABLE

**Rationale:** The prompt describes a concrete infrastructure project: a Spain–Morocco submerged floating tunnel for high-speed rail, with a €40 billion budget, 20-year timeline, and 100 m anchoring depth. The appended notes on number provenance and document voice are style guidance, not injection attempts.