## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Have both governments signed heads-of-state letters of intent and a written negotiation mandate, with legal review finding no more than one incompatibility that needs national legislation? | Signed letters and written mandate by Month 3 (2027-01-12); legal review lists fewer than 2 incompatibilities needing national legislative change (A2 failure trigger); negotiation team and steering committee in place by Month 1 (2026-11-12). | Signed letters, mandate document and both legal advisers' incompatibility lists, due Month 3 (2027-01-12). Draft treaty text circulated to both legal advisers by Month 6 (2027-04-12). | Delay: keep spending to tranche 1 (EUR 0.5 billion) seabed and ecological work only, escalate to heads of state within 2 weeks, and issue no vessel or yard commitments. Two consecutive negotiation rounds rejecting the Board tie-break clause is a treaty-failure warning that feeds the Month 24 (2028-10-12) stop rule. |
| 2 | Does the validated immersion-feasibility model show at least 60 usable immersion days per year and a P50 immersion duration inside the limit the programme can absorb? | At least 60 usable days/year (wave height <1.5 m and cross-current <0.5 m/s together) and P50 immersion duration <11 years (documented gate). This is only compatible with the Month 240 (2046-10-12) limit, not the Month 132 (2037-10-12) baseline, which needs about 7 years (see contradiction 1). Latest immersion end is Month 240 (2046-10-12) minus 12 months commissioning. | 30-year hydrographic and meteorological model delivered Month 6 (2027-04-12), tested with a marine contractor; go/no-go at Month 9 (2027-07-12) together with a phased-opening cost-benefit. | Downsize or split: take a binational scope-or-timeline decision at Month 9 (2027-07-12) (phased opening, reduced scope, or a new baseline opening date) and defer yard expansion and long-lead procurement beyond the pilot. If P50 completes later than Month 240 (2046-10-12) minus 12 months with no funded phased option, cancel or re-scope. |
| 3 | Have the two treasuries and lenders put in writing, and then bound in budget law, availability payments of about EUR 230-284 million/year plus a named source for the overrun gap? | Written indicative treasury and lender positions by Month 9 (2027-07-12); binding covenant (EUR 230 million/year to reach 1.0x DSCR, EUR 284 million to reach 1.2x) deposited by Month 15 (2028-01-12); named funding source for the EUR 2.8-10.8 billion gap above the EUR 7.2 billion reserve; independent demand study at or above 3.0 million passengers/year at EUR 60. | Lender working-group minutes and treasury letters at Month 9 (2027-07-12); deposited covenant or budget law at Month 15 (2028-01-12); Monte Carlo cost-risk model and independent demand study by Month 9 (2027-07-12). | Delay, then pivot: hold tranche 5 and rail procurement. If no binding availability-payment or overrun-backstop commitment exists by Month 24 (2028-10-12), release none of the EUR 20 billion main-construction tranche and pivot to a reduced public-funded scope. |
| 4 | Is the treaty ratified, with the binational authority legally active, a Board tie-break and a single lead certifier? | Ratified by Month 15 (2028-01-12) (target Month 12 = 2027-10-12); authority legally active; design-basis code drafted (Month 15 = 2028-01-12 gate). Hard stop at Month 24 (2028-10-12). | Ratification instruments from both parliaments and the authority's registration, at the Month 15 (2028-01-12) gate; lead certifier appointed by Month 6 (2027-04-12). | Delay with escalation: freeze casting-yard commitments and tranche releases beyond tranche 2 and escalate to political level within 2 weeks. If still not ratified at Month 24 (2028-10-12), release no main-construction funds (including the yard advance) and cancel or pivot to reduced scope. |
| 5 | Does the independent geotechnical review support freezing the hybrid pillar/tether concept at a cost the reserve can absorb? | Bearing capacity of at least 250 kPa at no fewer than 3 of the 5-8 boring sites (tripwire is <250 kPa at 3 or more); no more than 50% of the alignment deeper than 400 m; forecast redesign cost below EUR 4 billion; concept freeze not later than Month 24 (2028-10-12); any fallback fits the EUR 6.8-6.95 billion available reserve. | Geophysics complete by Month 6 (2027-04-12), borings and PSHA by Month 12 (2027-10-12), independent review and report by Month 18 (2028-04-12), freeze decision at the Month 24 (2028-10-12) gate. | Split or downsize: tether-only fallback (+EUR 2-4 billion, +6-12 months) or pillar-only (+EUR 4-8 billion, +12-36 months) needs a new funding decision before any yard commitment. If no concept fits EUR 7.2 billion plus an approved top-up and Month 240 (2046-10-12), cancel or pivot to a bored or phased scope. |
| 6 | Are the environmental consents and rail-operator anchor-tenant agreements in place so the Month 24 (2028-10-12) yard advance and tranche 3 can be released? | Harmonised consent from both environment ministries by Month 24 (2028-10-12) (latest Month 30 = 2029-04-12), with no NGO challenge filed; at least 2 anchor-tenant agreements signed by Month 24 (2028-10-12); prototype joint test complete; casting-yard site prepared. | Issued consents and written ministry positions (scoping by Month 3 = 2027-01-12); signed operator agreements; Month 24 (2028-10-12) gate review with independent certifier sign-off. | Delay up to Month 30 (2029-04-12) with the casting-yard advance (EUR 2-5 billion) withheld. If no legally durable consent exists at Month 30 (2029-04-12), release no main-construction funds and pivot to a revised alignment or scope; with fewer than 2 anchor tenants, pivot to a phased or shuttle scope. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: service_opening_target / immersion_rate_weather_windows = Immersion complete Month 120 (2036-10-12) and opening Month 132 (2037-10-12); immersion 8.75-14 years for 14 km
    observed:  Immersion Months 36-120 (2029-10-12 to 2036-10-12) (7 years) vs 8.75-14 years; gate P50 <11 years; KPI 2 <=12 years
HIGH CF-002  document: review_plan / executive summary
    canonical: overrun_exposure_vs_reserve = Unfunded gap EUR 2.8-10.8 billion above the cap, requiring a new funding decision
    observed:  Decision by Month 3 (2027-01-12) (executive summary) vs Month 6 (2027-04-12) (review, self-audit); Monte Carlo due Month 9 (2027-07-12); EUR 44 billion trigger at Month 12 (2027-10-12) vs Month 24 (2028-10-12)
HIGH CF-003  document: pitch
    canonical: landside_feeder_financing = OPEN decision; outside the EUR 40 billion envelope unless decided otherwise
    observed:  Through-running and 5-6 million passengers presented as delivered benefits; protocol Month 12 (2027-10-12) vs Month 9 (2027-07-12) vs Month 108 (2035-10-12)
HIGH CF-004  document: review_plan
    canonical: debt_service_coverage_gap = Operating surplus EUR 40 million/year; DSCR ~0.15x; gap EUR 230 million/year to 1.0x
    observed:  DSCR 0.10-0.12x and gap EUR 318-390 million at 2.5-3.2 million passengers; 0.95x from 240+40 vs 270
MEDIUM CF-005  document: review_plan
    canonical: private_debt_and_service_eur = Private debt EUR 4.4 billion (50% of EUR 8.8 billion); debt service ~EUR 270 million/year
    observed:  25-35% equity cushion = EUR 5.5-6.0 billion equity, EUR 2.8-3.3 billion debt
MEDIUM CF-006  document: canonical_facts
    canonical: gate_month_24 / ecological_consent_pathway = Gate at Month 24 (2028-10-12) needs consents issued; consent by Month 24 (2028-10-12), latest Month 30 (2029-04-12)
    observed:  Consent allowed to Month 30 (2029-04-12) while the Month 24 (2028-10-12) gate and yard advance require it
MEDIUM CF-007  document: review_plan (Review 7), self_audit, executive summary
    canonical: gate_month_24 = Support concept frozen at the Month 24 (2028-10-12) gate after independent review at Month 18 (2028-04-12)
    observed:  Gates 9, 15, 24, 36, 48, 60, 108, 120 / 9, 18, 24, 36, 48, 60, 84, 108, 132; freeze by Month 18 (2028-04-12)
MEDIUM CF-008  document: review_plan
    canonical: gate_month_24 = Rail-operator anchor-tenant agreements signed at the Month 24 (2028-10-12) gate
    observed:  Anchor-tenant and availability commitments by Month 3 (2027-01-12)
MEDIUM CF-009  document: review_plan
    canonical: gate_month_36 = Paired yards built at the Month 36 (2029-10-12) gate; balance of the EUR 20 billion first released after Month 36 (2029-10-12)
    observed:  Casting-yard construction start at Month 36 (2029-10-12), slipping to Month 42-48 (2030-04-12 to 2030-10-12)
MEDIUM CF-010  document: pitch
    canonical: depth_assumption_conflict = 100 m anchoring depth unverified; resolved by seabed campaign before the Month 24 (2028-10-12) concept freeze
    observed:  'anchored 100 m below the surface'; 'matched to real seabed conditions'
MEDIUM CF-011  document: executive summary / review_plan
    canonical: immersion_rate_weather_windows = 60-90 usable immersion days/year; 8.75-14 years for 14 km
    observed:  Seasonal constraint (net 60-90 days) leading to 18-25 years
```

### 1. Immersion duration vs the Month 36-120 (2029-10-12 to 2036-10-12) baseline window and the P50 gate (🔴 High) — needs a project decision

- **Executive summary (Key Deliverables, Timeline); project plan (Time-bound); canonical service_opening_target:** Immersion runs Months 36-120 (2029-10-12 to 2036-10-12) (about 7 years) and completes at Month 120 (2036-10-12), opening at Month 132 (2037-10-12); KPI 2 also keeps forecast immersion end within Month 120 (2036-10-12).
- **Canonical immersion_rate_weather_windows; executive summary (Risk 3, success criterion 3); review_plan Review 6 KPI 2; premortem A3:** Immersion takes 8.75-14 years for 14 km at two yards (1.0-1.6 km/year); the feasibility gate passes at P50 <11 years; KPI 2 allows total immersion duration of 12 years.
- **Why it conflicts:** Starting at Month 36 (2029-10-12), even the best case (8.75 years) ends at about Month 141 (2038-07-12) and the 11-year P50 gate ends at about Month 168 (2040-10-12); neither fits immersion completion at Month 120 (2036-10-12). Review 1 also calls Months 36-120 (2029-10-12 to 2036-10-12) an '8-10 year window', which is 7 years (84 months). Passing the gate does not protect the Month 132 (2037-10-12) baseline; it only protects Month 240 (2046-10-12).
- **Suggested resolution:** Decide which target is binding. Options: (a) rebaseline opening to match the modelled P50 (for example about Month 153 = 2039-07-12 if 8.75 years is achieved); (b) add throughput (third yard or higher rate) so that about 2 km/year is reachable; (c) plan a phased opening. Until then, state the gate as 'P50 completion no later than Month 240 (2046-10-12) minus 12 months commissioning' and record the Month 132 (2037-10-12) baseline as conditional, not as a promise.

### 2. Timing and ownership of the new funding decision for the overrun gap (🔴 High) — needs a project decision

- **Executive summary (Success criterion 4, Overall Takeaway):** A funding decision (named source for the EUR 2.8-10.8 billion gap) is due by Month 3 (2027-01-12) 'before design locks in'.
- **Review_plan (Review 3.1, KPI 3, Review 12.2); self_audit (Money Issues, Budget Too Low):** The new funding decision is due by Month 6 (2027-04-12); the Monte Carlo that sizes the gap is due Month 9 (2027-07-12); the EUR 44 billion trigger is tested at Month 12 (2027-10-12) in one place and at Month 24 (2028-10-12) in another, yet 'trigger new funding decision by Month 6 (2027-04-12)'.
- **Why it conflicts:** The decision date varies (Month 3 = 2027-01-12 vs 6), precedes the model that sizes the gap (Month 9 = 2027-07-12), and a Month 6 (2027-04-12) deadline cannot be triggered by a Month 12 (2027-10-12) or Month 24 (2028-10-12) forecast. No document says which states, EU or lenders carry the gap; funding shares are 'not set'.
- **Suggested resolution:** Pick one date after the Monte Carlo (no earlier than the Month 9 = 2027-07-12 gate) and align the Month 12 (2027-10-12) / Month 24 (2028-10-12) trigger tests. The missing project decision is who finances amounts above EUR 7.2 billion. Options: additional EU/multilateral tranche, pre-agreed state shares, scope reduction (phased opening), or timeline extension. None is established in the documents.

### 3. Feeder-line financing open, yet ridership and DSCR treat feeders as ready (🔴 High) — needs a project decision

- **Canonical landside_feeder_financing; executive summary feedback item 4:** Feeder-line financing and schedule is an OPEN decision, counted outside the EUR 40 billion envelope unless decided otherwise.
- **Pitch (Stakeholder Benefits); premortem A9/FM9; review_plan Reviews 9, 11, 14:** Pitch promises 'seamless through-running' and capacity for 5-6 million passengers; planning case 4.0 million assumes feeders ready; the protocol is due Month 12 (2027-10-12) in Review 9 but Month 9 (2027-07-12) in Reviews 11 and 14; premortem tripwire is Month 108 (2035-10-12).
- **Why it conflicts:** Revenue, DSCR and opening-demand claims depend on an unfunded, unscheduled item; the plan's own estimate (EUR 3-8 billion, estimate) is not in the envelope or reserve. Deadlines for resolving it differ by 3 to 96 months.
- **Suggested resolution:** Treat feeder lines as an explicit decision: who funds (Spain %, Morocco %, EU %), whether inside or outside the EUR 40 billion, and the completion date. Until decided, state the 4.0 million planning case as conditional on feeders. Set a single date for the protocol (no later than the Month 9-12 = 2027-07-12 to 2027-10-12 gate).

### 4. Downside DSCR and availability-payment arithmetic (🔴 High)

- **Canonical annual_revenue_opening_eur, annual_opex_eur, debt_service_coverage_gap:** Planning case: EUR 240 million revenue less EUR 200 million opex = EUR 40 million surplus; DSCR ~0.15x; gap EUR 230 million/year to 1.0x.
- **Review_plan Reviews 4.3, 5.3, 6 (KPI 1), 8.3, 10.1:** At 2.5-3.2 million passengers 'DSCR drops to 0.10-0.12x' and the gap widens to EUR 318-390 million (38-50% deeper); KPI 1 gets opening DSCR >=0.95x from 'EUR 240 million revenue + EUR 40 million surplus vs EUR 270 million'.
- **Why it conflicts:** Recomputed: at 2.5-3.2 million, revenue is EUR 150-192 million, below EUR 200 million opex, so surplus is -EUR 50 to -8 million, DSCR is zero or negative, and the gap to 1.0x is about EUR 278-320 million/year (not 318-390; and 318-390 is +38% to +70%, not 38-50%). KPI 1 double counts revenue (the surplus already nets revenue), and the 0.95x/1.15x targets only hold if availability payments are included.
- **Suggested resolution:** Keep the canonical figures and correct the downside: DSCR <=0 and gap about EUR 278-320 million/year at 2.5-3.2 million passengers. Restate KPI 1 as DSCR including availability payments, and show that the EUR 230-284 million/year covenant range does not cover the demand downside.

### 5. Equity cushion percentage vs euro amounts and current structure (🟡 Medium)

- **Canonical private_debt_and_service_eur; review_plan Review 14.3:** Private debt is EUR 4.4 billion, 50% of the EUR 8.8 billion systems tranche; equity is therefore EUR 4.4 billion (50%).
- **Review_plan Reviews 4.3, 8.3, 10.1, 14.3:** '25-35% equity cushion (increase private equity to EUR 5.5-6.0 billion, reduce debt to EUR 2.8-3.3 billion)', and 50% equity is called 'insufficient' against a 25-35% standard.
- **Why it conflicts:** EUR 5.5-6.0 billion is 62-68% of EUR 8.8 billion, not 25-35%; 50% equity already exceeds 25-35%, so it cannot be 'insufficient' against that standard. The proposed change would also alter debt service, which no document recomputes.
- **Suggested resolution:** Keep canonical EUR 4.4 billion debt and ~EUR 270 million service for the baseline. If more equity is wanted, state it as about 62-68% equity (EUR 5.5-6.0 billion) with recomputed debt service for EUR 2.8-3.3 billion debt; drop the '25-35%' label or define what it measures.

### 6. Month 24 (2028-10-12) gate requires consents, but consent is allowed until Month 30 (2029-04-12) (🟡 Medium) — needs a project decision

- **Canonical gate_month_24; executive summary (Deliverables):** Month 24 (2028-10-12) gate requires environmental consents issued by both states; the gate releases tranche 3 and the EUR 2-5 billion yard advance.
- **Canonical ecological_consent_pathway; project plan (Dependencies); premortem FM6:** Harmonised consent by Month 24 (2028-10-12), 'latest Month 30 (2029-04-12)'; stop rule for lack of durable consent applies at Month 30 (2029-04-12).
- **Why it conflicts:** If consent may legitimately arrive up to Month 30 (2029-04-12), the Month 24 (2028-10-12) gate cannot be passed as written, and the documents do not say whether the yard advance is released, withheld or the gate re-held in Months 24-30 (2028-10-12 to 2029-04-12).
- **Suggested resolution:** Decide the interim rule: for example, withhold the yard advance and tranche 3 until consents are issued, re-hold the gate at the consent date, and apply the stop rule at Month 30 (2029-04-12). Alternatively, release a smaller advance conditional on consent. This needs an explicit project decision.

### 7. Different gate sets and concept-freeze month (🟡 Medium)

- **Canonical gates and certification_regime; project plan; pitch:** Gates at Months 9, 15, 24, 36, 48 (2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12) (certification gates at 9, 18, 30, 42); concept freeze at Month 24 (2028-10-12) after independent review at Month 18 (2028-04-12).
- **Review_plan Review 7 and self_audit items 11 and 19; executive summary (Timeline); assumptions Risk 19:** 8 gates at Months 9, 15, 24, 36, 48, 60, 108, 120 (2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2035-10-12, 2036-10-12); or Months 9, 18, 24, 36, 48, 60, 84, 108, 132 (2027-07-12, 2028-04-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2033-10-12, 2035-10-12, 2037-10-12); or Months 9...48, 120, 132; and 'seabed concept freeze by Month 18 (2028-04-12)'.
- **Why it conflicts:** The same governance gates carry three different month lists, and Review 7 places concept freeze at Month 18 (2028-04-12), conflicting with the Month 24 (2028-10-12) freeze (Month 18 = 2028-04-12 is review and reporting only).
- **Suggested resolution:** Use the canonical gate set (9, 15, 24, 36, 48) plus certification gates (9, 18, 30, 42), and label Months 60, 108, 120, 132 (2031-10-12, 2035-10-12, 2036-10-12, 2037-10-12) as milestones or stop-rule checkpoints. Correct Review 7 to concept freeze at Month 24 (2028-10-12).

### 8. Proof-of-insurability timing and 'six months pre-opening' arithmetic (🟡 Medium)

- **Review_plan Review 2.1:** Proof-of-insurability certification by Month 24 (2028-10-12), 'six months earlier than under ambiguous governance'.
- **Review_plan Reviews 2.3, 4.2, 9.2, 14.1; self_audit item 15; premortem FM8:** Proof-of-insurability due Month 108 (2035-10-12) (or deferred from Months 96-108 = 2034-10-12 to 2035-10-12 to Month 120+), described as 'six months pre-opening'; preliminary terms with three underwriters by Month 48 (2030-10-12); stop rule Month 60 (2031-10-12).
- **Why it conflicts:** The same milestone is placed at Month 24, 48, 60 and 108 (2028-10-12, 2030-10-12, 2031-10-12, 2035-10-12) without distinguishing preliminary terms from proof. Month 108 (2035-10-12) and Month 120 (2036-10-12) are 24 and 12 months before the Month 132 (2037-10-12) opening, not six.
- **Suggested resolution:** Define the stages: indicative cover terms (Month 9 = 2027-07-12 per premortem), preliminary terms with 3 underwriters (Month 48 = 2030-10-12), insurance-cover stop rule (Month 60 = 2031-10-12), proof-of-insurability (Month 108 = 2035-10-12, which is 24 months pre-opening). Fix the 'six months' wording.

### 9. Anchor-tenant and availability-payment commitments pulled forward to Month 3 (2027-01-12) (🟡 Medium)

- **Canonical gate_month_24; project plan; executive summary; review_plan Review 3.3:** Anchor-tenant agreements signed by Month 24 (2028-10-12) (a Month 24 = 2028-10-12 gate criterion); availability-payment covenant by Month 12-15 (2027-10-12 to 2028-01-12).
- **Review_plan Reviews 2.3, 4.3, 10.1; self_audit (Overly Optimistic):** Binding demand mitigation through anchor-tenant agreements 'by Month 3 (2027-01-12)'; availability commitment 'closed by Month 3 (2027-01-12) and locked into budget law'; independent demand study 'by Month 3 (2027-01-12)'.
- **Why it conflicts:** Month 3 (2027-01-12) precedes the demand study, the lender working group (Month 9 = 2027-07-12) and the treaty (Month 12-15 = 2027-10-12 to 2028-01-12) that those commitments rely on. The premortem puts the demand study at Month 9 (2027-07-12).
- **Suggested resolution:** Keep Month 9 (2027-07-12) for written positions and demand study, Month 12-15 (2027-10-12 to 2028-01-12) for the covenant, Month 24 (2028-10-12) for anchor tenants. Month 3 (2027-01-12) is the latest date to commission (not deliver) the demand study.

### 10. Casting-yard 'construction start' at Month 36 (2029-10-12) vs yards built by Month 36 (2029-10-12) (🟡 Medium)

- **Canonical gates 24, 36, 48; assumptions Risk 19 (yard build Months 12-36 = 2027-10-12 to 2029-10-12):** Yard advance released at Month 24 (2028-10-12); paired yards built by the Month 36 (2029-10-12) gate; production ramp-up Months 36-48 (2029-10-12 to 2030-10-12).
- **Review_plan Reviews 2.2, 5.2, 12.1, 13.1, 13.2:** Seabed slip 'pushes casting-yard construction start from Month 36 (2029-10-12) to Month 42-48 (2030-04-12 to 2030-10-12)'; treaty slip makes 'casting-yard start' Month 30-36 (2029-04-12 to 2029-10-12).
- **Why it conflicts:** Month 36 (2029-10-12) is the end of yard construction and start of production, not the start of construction (Month 24 = 2028-10-12 advance). The knock-on delays are measured from the wrong event, so the slip arithmetic is unreliable.
- **Suggested resolution:** State yard construction start at the Month 24 (2028-10-12) advance and production start at Month 36 (2029-10-12); restate slips as production start moving from Month 36 (2029-10-12) to Month 42-48 (2030-04-12 to 2030-10-12).

### 11. Pitch presents the 100 m depth and seabed match as fact (🟡 Medium)

- **Canonical depth_assumption_conflict; pitch (Risks); executive summary:** Plan's 100 m anchoring depth is unverified against Strait depths of several hundred m up to ~900 m; to be resolved by the seabed campaign.
- **Pitch (Project Overview):** A tunnel 'anchored 100 m below the surface'; 'not a concept... a hybrid design matched to real seabed conditions'; success rests on 'proven geotechnical data'.
- **Why it conflicts:** The opening presents as established what the same document lists as unverified; no seabed data exist before Month 6-18 (2027-04-12 to 2028-04-12).
- **Suggested resolution:** Reword the pitch: 100 m is an unverified planning assumption; the hybrid concept is a working design to be confirmed by the seabed campaign and independent review.

### 12. Seasonal ecological window counted as a downside beyond a baseline that already includes it (🟡 Medium)

- **Assumptions (Environmental); canonical immersion_rate_weather_windows:** Seasonal restrictions already leave 60-90 usable immersion days/year, which gives the 8.75-14 year baseline.
- **Executive summary Risk 3; review_plan Reviews 1.3, 5.1, 8.1; premortem FM3/FM6:** 'Seasonal ecological constraint (May-September, 150 days/year, net 60-90) extends immersion from 8.75-14 to 18-25 years, pushing completion past Month 240 (2046-10-12)'.
- **Why it conflicts:** If net 60-90 days already reflects the seasonal window, enforcing it cannot take the schedule to 18-25 years; that would require well under 60 days (about 30-45). The seasonal constraint is simultaneously baseline and downside.
- **Suggested resolution:** Treat 60-90 days as the post-seasonal baseline and define the downside as <60 days after storm and consent exclusions, with the 18-25 year range tied to a stated day count. Check consent conditions against the 60-day pass threshold.

## Summary

The plan is broadly aligned on its core architecture: canonical budget, tranches, contingency, gates, treaty target and stop rules are mostly repeated correctly in the exec summary, project plan, pitch and premortem. The main inconsistencies are in the schedule arithmetic (an 8.75-14 year immersion estimate against a 7-year Month 36-120 = 2029-10-12 to 2036-10-12 window), in who funds the EUR 2.8-10.8 billion gap and the feeder lines, and in the downstream review documents, whose DSCR, equity, insurance and gate figures are inconsistent or mis-computed. Later documents also drift on milestone dates (Month 3 = 2027-01-12 vs 6 vs 9 vs 12-15 vs 24), so the Month 9, 15 and 24 (2027-07-12, 2028-01-12, 2028-10-12) gates and the stop rules should be re-anchored to the canonical set before the plan is used for decisions.