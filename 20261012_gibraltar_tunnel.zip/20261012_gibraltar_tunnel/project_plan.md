**Goal Statement:** Deliver a full-crossing submerged floating tunnel for high-speed rail between Spain and Morocco (Camarinal Sill corridor, ~14 km) within the EUR 40 billion envelope, using a hybrid support concept, with service opening at Month 132 (2037-10-12) and no later than Month 240 (2046-10-12).

## SMART Criteria

- **Specific:** Design, permit, build and commission a ~14 km submerged floating tunnel for high-speed rail across the Strait of Gibraltar, from Tarifa area to Tangier area. Founded pillars on shallow shelves and tethers or buoyancy modules in deep channels; the 100 m anchoring depth assumption is to be verified.
- **Measurable:** Success is trains carrying passengers through a certified, insured tunnel; capital spend within the EUR 40 billion envelope (user constraint); all gate criteria passed and a lead certifier's final certification issued.
- **Achievable:** Achievable only if the unverified 100 m depth assumption is resolved by seabed work, treaty authority is ratified and contingency (EUR 7.2 billion, proposed threshold) is held. No built precedent exists; the plan relies on staged gates, pilot segment and paired yards. Overrun exposure of EUR 10-18 billion (estimate) exceeds reserve.
- **Relevant:** Creates a permanent high-speed rail link between Europe and Africa, supporting transport connectivity and economic integration between Spain and Morocco, and builds shared engineering and industrial capability on both coasts.
- **Time-bound:** Start Month 0 (2026-10-12), ASAP. Concept freeze Month 24 (2028-10-12); main construction Months 36-120 (2029-10-12 to 2036-10-12); commissioning to Month 132 (2037-10-12) opening baseline; latest acceptable completion Month 240 (2046-10-12).

## Dependencies

- Ratify a binational treaty and delivery vehicle with legal personality, tie-break rules and a single lead certifier (Month 12-15 = 2027-10-12 to 2028-01-12)
- Complete seabed and geohazard campaign and resolve the depth conflict before support-concept freeze (Month 18-24 = 2028-04-12 to 2028-10-12)
- Obtain harmonised Spanish, Moroccan and EU environmental consents from a joint ecological baseline (Month 24 = 2028-10-12, latest Month 30 = 2029-04-12)
- Establish stage-gated funding with contingency reserve and independent cost authority (Month 2-3 = 2026-12-12 to 2027-01-12)
- Build paired casting yards and immerse a pilot segment in sheltered water before main production (Month 36 = 2029-10-12)

## Resources Required

- EUR 40 billion capital envelope in gated tranches (user constraint)
- Marine geophysical and geotechnical survey vessels and drilling capability
- Paired casting and outfitting yards at Algeciras and Tanger Med
- Concrete, reinforcement, tether and joint hardware supply agreements
- Immersion, towing and heavy-lift marine contractors

## Related Goals

- Connect Spanish and Moroccan high-speed rail networks
- Establish a binational delivery authority and unified design code
- Build ridership and landside feeder-line integration
- Develop long-term operations, monitoring and maintenance regime
- Deliver ecological mitigation and regional skills legacy

## Tags

- submerged floating tunnel
- Strait of Gibraltar
- high-speed rail
- megaproject
- binational treaty

## Risk Assessment and Mitigation Strategies


### Key Risks

- Depth conflict and unresolved support concept: pillar-only redesign could add EUR 4-8 billion and 12-36 months (estimate)
- Treaty ratification and governance delays stall the programme; stop rule applies if not ratified by Month 24 (2028-10-12)
- Cost overruns of EUR 10-18 billion (estimate) exceed the EUR 7.2 billion reserve, leaving an unfunded gap
- Schedule compression: 60-90 usable immersion days per year may make 14 km immersion take 8.75-14 years (estimate)
- Revenue shortfall: planning-case operating surplus (EUR 40 million/year) cannot cover debt service (EUR 270 million/year, estimate) without availability payments

### Diverse Risks

- Environmental consent divergence or injunctions in a migration corridor
- Seismic hazard and absence of an international design code for this structure type
- Supply-chain and contractor scarcity, with day-rates possibly rising 30-50% (estimate)
- Shipping collision, anchor strike and sabotage in a busy strait
- Political turnover across a 20-year span and emergency egress at depth

### Mitigation Plans

- Run front-loaded seabed campaign (Months 0-18 = 2026-10-12 to 2028-04-12), freeze concept only after independent review, and build a pilot segment before production
- Form negotiation team by Month 1 (2026-11-12), target ratification Month 12 (2027-10-12), withhold main-construction tranche if not ratified by Month 24 (2028-10-12)
- Hold EUR 7.2 billion contingency at gate level, set up independent cost authority by Month 2 (2026-12-12), and take a new funding decision for any gap
- Build CPM schedule by Month 1 (2026-11-12) and weather-window model by Month 6 (2027-04-12); keep a 6-month floating reserve and escalate if the horizon is unachievable
- Use a single lead certifier, joint ecological baseline from Month 0 (2026-10-12), no-anchoring corridor, egress design basis by Month 9 (2027-07-12), and treaty continuation clauses

## Stakeholder Analysis


### Primary Stakeholders

- Binational coordinating commission and concession joint venture
- Governments of Spain and Morocco
- Lead certifier and independent technical panel
- Casting-yard and immersion contractors
- Funders: EU, multilateral lenders and private rail financiers

### Secondary Stakeholders

- Maritime authorities and IMO
- Environmental NGOs, fishing and port communities
- Spanish and Moroccan rail operators
- Insurers
- SECEGSA and SNED study entities

### Engagement Strategies

- Quarterly ministerial steering committee and monthly gate-progress reports to the commission
- Early NGO and community consultation (Months 0-3 = 2026-10-12 to 2027-01-12) and co-design of consent conditions
- Anchor-tenant agreements with rail operators by Month 24 (2028-10-12)
- Early engagement of IMO and maritime authorities on exclusion corridors by Month 3 (2027-01-12)
- Lender and insurer briefings before design freeze, tied to gate evidence

## Regulatory and Compliance Requirements


### Permits and Licenses

- Binational treaty ratification in both parliaments
- Spanish, Moroccan and EU environmental consents
- Maritime authority and IMO approvals for exclusion corridor
- Construction and yard permits at Algeciras and Tanger Med
- Operating licence based on accepted safety case

### Compliance Standards

- Project-specific design code adapted from offshore, immersed-tunnel and railway standards
- Eurocode 8 and Moroccan seismic standards, with PSHA at 475- and 2475-year return periods
- Railway safety and signalling interoperability standards
- EU public-procurement and harmonised treaty procurement rules
- Marine environmental protection and protected-area rules

### Regulatory Bodies

- Spanish and Moroccan transport and environment authorities
- European Union institutions
- International Maritime Organization
- Lead certifier (classification society)
- Spanish and Moroccan maritime and coast-guard authorities

### Compliance Actions

- Draft design code and certification gate criteria by Month 9 (2027-07-12)
- Appoint lead certifier by Month 6 (2027-04-12) and hold certification gates at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12)
- Run parallel national assessments with coordinating committee to harmonised consent by Month 24 (2028-10-12)
- Agree no-anchoring corridor with IMO and maritime authorities by Month 12 (2027-10-12)
- Complete safety case, egress drills (Month 108 = 2035-10-12) and insurance terms before opening