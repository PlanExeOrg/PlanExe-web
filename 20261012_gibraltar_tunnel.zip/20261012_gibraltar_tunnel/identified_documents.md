
## Documents to Create

### 1. Binational Treaty and Delivery Vehicle Charter

**ID:** 951d99cf-95fc-4596-af58-f5931369ff25

**Description:** Comprehensive legal instrument establishing the binational authority's legal personality, Board structure with explicit tie-break mechanism, delegated approval thresholds (CEO <2%, Board 2–5%, >5% escalation), unified procurement framework harmonising Spanish, Moroccan and EU law, single Lead Certifier authority, dispute-resolution protocols, and withdrawal-notice requirements (12-month minimum). Audience: Spanish and Moroccan governments, EU institutions, lenders and insurers. Approval required before Month 15 (2028-01-12); governs all subsequent decisions.

**Responsible Role Type:** Legal Counsel and Treaty Negotiator (binational team)

**Primary Template:** International cross-border infrastructure treaty (precedent: Fehmarnbelt Agreement 2008, HZMB Treaty framework)

**Secondary Template:** EU public-private partnership concession agreement template

**Steps:**

- Month 1 (2026-11-12): Establish joint Spanish–Moroccan treaty negotiation team with named lead negotiator and ministerial steering committee; define negotiation roadmap with milestone dates.
- Months 1–3 (2026-11-12 to 2027-01-12): Identify political and legal bottlenecks (sovereignty issues, procurement-law divergence, dispute-resolution jurisdiction); draft heads-of-state letter of intent.
- Months 3–6 (2027-01-12 to 2027-04-12): Draft complete treaty text covering legal personality, Board composition and tie-break, delegated approval thresholds, procurement framework, certification authority, dispute resolution and withdrawal rules.
- Months 6–12 (2027-04-12 to 2027-10-12): Secure ministerial and parliamentary approvals; coordinate with EU (if EU co-financing requires EU Council consent); target signatures by Month 12 (2027-10-12).
- Month 12–15 (2027-10-12 to 2028-01-12): Ratification in both parliaments; establish binational authority legal entity, Board, and operating procedures.

**Approval Authorities:** Spanish and Moroccan transport and finance ministries; both parliaments (supermajority ratification recommended); EU institutions (if EU co-financing triggers Council involvement)

### 2. Project Charter and Governance Framework

**ID:** 4cc3c706-95a3-4448-aa76-6cbb21a22cbc

**Description:** High-level charter establishing the binational delivery authority's mission, organisational structure, roles (Programme Director, Chief Technical Officer, Cost Authority, Schedule Lead, Environmental Lead, Marine Operations Lead), decision-authority boundaries, monthly gate discipline, Design Change Control Board terms of reference, escalation protocols (variance >5%, schedule slip >6 months, cost forecast >10% envelope), and consequences of non-compliance. Audience: delivery authority leadership, binational Board, lenders, insurers. Approval: binational Board and both finance ministries.

**Responsible Role Type:** Binational Programme Director and Governance Architect

**Primary Template:** PMI Project Charter template adapted for binational megaproject

**Secondary Template:** APMG Programme Management standard

**Steps:**

- Month 2 (2026-12-12): Draft charter outline defining authority boundaries, roles, decision thresholds, escalation rules and monthly cadence.
- Months 2–6 (2026-12-12 to 2027-04-12): Detail Design Change Control Board procedures (2-week turnaround for routine, 4–8 weeks for major changes), cost/schedule variance triggers and escalation timelines, gate sign-off criteria.
- Month 6 (2027-04-12): Consult with binational Board, finance ministries and lenders; incorporate feedback.
- Month 9 (2027-07-12): Issue final charter; publish to all stakeholders; establish monthly governance office rhythm (Programme Board, Design Change Board, cost-control reviews).

**Approval Authorities:** Binational Board; Spanish and Moroccan finance ministries; concession agreement signatories (if private partners are named)

### 3. Independent Project Cost Authority Mandate and Operating Procedures

**ID:** b8d2c18b-e230-478c-804a-f9184ce9c5b1

**Description:** Establishes the independent cost-tracking and escalation authority reporting to the binational Board and both finance ministries. Covers monthly variance analysis, quarterly forecasting (cost-to-complete, earned-value), escalation thresholds (variance >5% = Board decision within 1 week; >10% = political review within 2 weeks), design-change cost-impact assessment (2-week turnaround), quarterly supply-chain risk review, and transparency requirements (monthly reports to lenders/insurers). Specifies contingency reserve administration (allocation by gate, release authority, Design Change Reserve access). Audience: Project Cost Authority director, binational Board, finance ministries, lenders.

**Responsible Role Type:** Cost Control Authority Lead (external accountant or multilateral representative)

**Primary Template:** Megaproject cost-control authority charter (precedent: Crossrail, Fehmarnbelt cost-control frameworks)

**Secondary Template:** PMI Cost Management Plan

**Steps:**

- Month 2 (2026-12-12): Define authority scope, staffing (2–4 cost analysts), reporting lines and decision powers.
- Months 2–3 (2026-12-12 to 2027-01-12): Commission independent cost estimate (Class C, ±25% confidence) for all major packages; conduct Monte Carlo cost-risk simulation to quantify P50/P80/P95 cost distributions.
- Month 3 (2027-01-12): Establish contingency allocation framework (Design Change Reserve EUR 1–2 billion; Overrun Reserve EUR 4–5 billion; Tail-Risk Reserve EUR 2–3 billion); document cost-overrun response thresholds (EUR 44 billion = 10% trigger; EUR 46 billion = 15% trigger).
- Month 3 (2027-01-12): Secure pre-commitments from all funding sources (Spain, Morocco, EU, multilateral lenders) specifying responsibility for overruns above contingency or decision authority to invoke scope reduction.
- Month 6 (2027-04-12) onwards: Monthly variance tracking, quarterly forecasts, escalation to Board and finance ministries per protocol.

**Approval Authorities:** Binational Board; Spanish and Moroccan finance ministries; multilateral lenders (if co-financing includes development-bank conditions)

### 4. Critical Path Method Schedule (P50/P80 Confidence) and Weather-Window Immersion Model

**ID:** ac9350b7-6019-4952-a065-4075837b38e5

**Description:** Detailed schedule showing all major work packages (seabed investigation, design, permitting, casting-yard construction, fabrication, immersion, commissioning) with explicit task durations, resource constraints, dependencies, confidence levels (P50, P80, P95), and risk buffers. Includes immersion weather-window model (60–90 usable days/year assumption, validated against Strait climatology) calculating feasibility of 14 km immersion within available time windows. Back-calculated to confirm latest immersion start date against Month 240 (2046-10-12) horizon and Month 132 (2037-10-12) baseline opening. Identifies critical path and floating reserve (6 months, outside critical path). Audience: delivery programme director, binational Board, lenders, Schedule Lead.

**Responsible Role Type:** Programme Schedule Lead and Marine Logistics Specialist

**Primary Template:** Primavera P6 or Microsoft Project CPM schedule template

**Secondary Template:** British tunnelling standards (FAGG) schedule precedent for megaproject

**Steps:**

- Month 1 (2026-11-12): Convene bottom-up scheduling workshop with Spanish, Moroccan, contractor and independent-scheduler teams; define task durations (P50, P80, P95 confidence) for all major work packages.
- Months 1–3 (2026-11-12 to 2027-01-12): Build Primavera P6 or equivalent CPM model; colour-code by risk; establish critical path and identify schedule-critical activities (treaty ratification, seabed investigation, certification gates, casting-yard ramp-up, immersion weather windows).
- Months 3–6 (2027-01-12 to 2027-04-12): Commission hydrographic and meteorological model of Strait weather patterns; calculate realistic immersion weather-window availability (assume 40–60 usable days/year conservative estimate); model immersion production sequence and total duration for 14 km.
- Month 6 (2027-04-12): Deliver CPM schedule and weather-window model; back-calculate latest immersion-start month from Month 132 (2037-10-12) opening baseline; if result is later than Month 48 (2030-10-12), escalate schedule infeasibility to binational leadership.
- Month 9 (2027-07-12): Establish 6-month floating reserve (outside critical path); codify decision rules for reserve release; publish schedule to lenders and insurers for confidence-building.

**Approval Authorities:** Binational Board; multilateral lenders; Schedule Lead with independent schedule review

### 5. Seabed Investigation and Geotechnical Design Basis Report

**ID:** bf3d42d3-0a29-4965-92a7-f11ee470ae8b

**Description:** Comprehensive report documenting full-corridor geophysical survey (bathymetry, sediment profiling, seismic characterization), 5–8 targeted core borings (with cone-penetrometry and in-situ shear testing), seismic hazard assessment (PSHA, 475-year and 2475-year return periods), and foundation/anchor design parameters (bearing capacity, settlement tolerances, seismic design loads). Confirms actual depth profile against the plan's 100 m assumption and resolves support-concept viability (pillars <400 m depth, tethers >400 m). Independent peer review by international geotechnical specialists. Freezes the support concept upon binational Board and Lead Certifier approval. Audience: Chief Technical Officer, Lead Certifier, lenders, design team.

**Responsible Role Type:** Marine Geotechnical and Seabed Investigation Programme Manager

**Primary Template:** ISO/IEC 80000 seismic survey reporting standard; NGI (Norwegian Geotechnical Institute) soil-investigation protocol

**Secondary Template:** Fehmarnbelt geotechnical investigation reports (precedent)

**Steps:**

- Months 0–3 (2026-10-12 to 2027-01-12): Commission geophysical survey vessel; define boring and in-situ-test locations (5–8 sites covering pillar/anchor candidate areas); engage third-party independent geotechnical reviewer by Month 3 (2027-01-12).
- Months 3–6 (2027-01-12 to 2027-04-12): Execute full-corridor geophysical survey (multibeam bathymetry, 3D seismic reflection, gravity/magnetic); deliver geophysics report by Month 6 (2027-04-12).
- Months 6–12 (2027-04-12 to 2027-10-12): Execute targeted core borings and in-situ testing at 5–8 locations; cone-penetrometry to 20–50 m below seabed; laboratory analysis of cores (consolidation, triaxial, durability).
- Months 12–18 (2027-10-12 to 2028-04-12): Analyse all data; prepare geotechnical design basis (bearing capacity, settlement, seismic hazard PSHA); conduct independent peer review; deliver final report with support-concept recommendations by Month 18 (2028-04-12).
- Month 24 (2028-10-12): Freeze support concept (pillars, tethers, or hybrid) based on seabed data; sign off by binational Board and Lead Certifier; release casting-yard construction advance.

**Approval Authorities:** Chief Technical Officer; Lead Certifier; independent geotechnical reviewer; binational Board (for concept freeze at Month 24 = 2028-10-12 gate)

### 6. Unified Design Code and Project-Specific Safety Standards

**ID:** 45565066-8b57-4d6a-98c4-c5385201e05a

**Description:** Single, binding design code combining ISO 23600 (immersed tubes), ISO 61508 (functional safety), EN 1993-1-11 (cable structures), EN 1992-1-1 (concrete) and project-bespoke seismic/hydrodynamic load cases. Codifies design-basis loads (wave, current, seismic acceleration from PSHA analysis), safety factors for first-of-kind structure, joint-design standards, tether-fatigue assessment methodology, and certification pass/fail criteria for all four design gates (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12). Harmonises Spanish, Moroccan and EU regulatory requirements. Single Lead Certifier endorses and enforces. Audience: design team, contractors, Lead Certifier, both national regulators.

**Responsible Role Type:** Lead Certifier and Chief Technical Officer (joint drafting)

**Primary Template:** ISO/IEC 80000 standards; EN 1998 (Eurocode 8) seismic design

**Secondary Template:** HZMB immersed-tunnel design code (precedent); Rogfast floating-tunnel design-basis report (precedent)

**Steps:**

- Month 3 (2027-01-12): Form Joint Technical Panel (Spanish, Moroccan, EU, and independent experts from academia and classification societies); define code-drafting scope and schedule.
- Months 3–6 (2027-01-12 to 2027-04-12): Draft code sections covering structural design (load cases, safety factors), geotechnical foundations (bearing, settlement), seismic design (PSHA, dynamic response), fatigue (tethers and joints under cyclic loading), and emergency egress.
- Months 6–9 (2027-04-12 to 2027-07-12): Integrate seabed investigation findings; conduct seismic hazard assessment (PSHA 475- and 2475-year return periods) and codify earthquake-design spectrum; define gate criteria (pass/fail tests for each design phase).
- Month 9 (2027-07-12): Issue final code; Lead Certifier endorsement; publish gate criteria; communicate to design team and regulators.
- Months 12–18 (2027-10-12 to 2028-04-12): Develop seismic design details and finalize load case methodology; complete PSHA analysis by Month 12 (2027-10-12).

**Approval Authorities:** Lead Certifier (single authority); Spanish and Moroccan transport/environment authorities (liaison, not veto); binational Board

### 7. Design Certification Framework and Gate Criteria

**ID:** 95331016-366f-4244-92bf-5408616f01b5

**Description:** Specifies pre-agreed, objective pass/fail criteria for four design-certification gates (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12). Gate 1 (Month 9 = 2027-07-12): concept design complete, design code finalized, gate criteria codified. Gate 2 (Month 18 = 2028-04-12): 30% design complete, load cases validated, preliminary safety case. Gate 3 (Month 30 = 2029-04-12): 60% design complete, seismic response analysis finished, egress design basis agreed. Gate 4 (Month 42 = 2030-04-12): detailed design complete, all prototype tests (tether pull-test, joint mock-up) complete by Month 48 (2030-10-12), final certification issued. No design changes allowed after Month 48 (2030-10-12) except minor documentation. Lead Certifier reports findings to binational Board and both national regulators. Audience: Lead Certifier, design team, binational Board, regulators.

**Responsible Role Type:** Lead Certifier

**Primary Template:** Gate-review framework (precedent: APMG, PMI governance standards)

**Secondary Template:** Fehmarnbelt design-certification milestones (precedent)

**Steps:**

- Month 6 (2027-04-12): Lead Certifier appointment; define gate scope and criteria in consultation with design team and regulators.
- Month 9 (2027-07-12): Codify all four gate criteria and publish to design team; conduct Gate 1 review (design-code and gate-criteria approval).
- Months 9–18 (2027-07-12 to 2028-04-12): Support design team progression toward Gate 2; conduct interim technical reviews; issue conditional approvals if minor remediation is needed.
- Month 18 (2028-04-12): Gate 2 review (30% design); issue conditional approval or flag major findings requiring redesign.
- Months 18–42 (2028-04-12 to 2030-04-12): Continue gate reviews at Months 30 and 42 (2029-04-12, 2030-04-12); oversee prototype testing (tether pull-test, joint mock-up, hydrostatic testing) completion by Month 48 (2030-10-12).
- Month 48 (2030-10-12): Issue final design certification; forbid material changes to design after this date (production ramp-up under certified design).

**Approval Authorities:** Lead Certifier (final authority); binational Board (escalation if design changes exceed thresholds); both national regulators (liaison, design-basis acceptance)

### 8. Environmental Impact Assessment and Joint Consent Framework

**ID:** 66338f99-c419-4b3e-822e-4cc9653087c6

**Description:** Single harmonised Environmental Impact Assessment (not separate national assessments) covering baseline ecology (cetacean, seabird, sea-turtle migration), habitat impact modelling, seasonal construction-window constraints, mitigation design (artificial reefs, research partnerships, monitoring protocols) and legal defensibility against injunctions. Binding commitment from both Spain and Morocco to a unified environmental consent with aligned conditions (no divergence). Seasonal construction windows (e.g., May–September if migration seasons overlap; estimate 60–90 usable days/year) embedded in Critical Path schedule. Mitigation cost (EUR 250–400 million) allocated as distinct line item in contingency reserve. Audience: environmental authorities (Spain, Morocco, EU), ecological NGOs, Design Change Control Board, Schedule Lead.

**Responsible Role Type:** Environmental Permitting and Ecological Compliance Lead

**Primary Template:** EU Environmental Impact Assessment Directive 2014/52/EU template

**Secondary Template:** Fehmarnbelt Environmental Impact Assessment (precedent); HZMB environmental-consent framework

**Steps:**

- Month 0 (2026-10-12): Establish Joint Ecological Steering Group (Spanish, Moroccan and EU representatives, independent chair); define baseline-survey scope.
- Months 0–9 (2026-10-12 to 2027-07-12): Commission and execute baseline acoustic monitoring (cetacean presence/absence), visual surveys (seabirds, sea turtles), and hydrodynamic-impact modelling; first results deliverable Month 9 (2027-07-12).
- Months 3–9 (2027-01-12 to 2027-07-12): Draft single harmonised Environmental Impact Assessment incorporating baseline findings, impact predictions (noise, current disruption, habitat), and mitigation measures; establish parallel national assessment process with Harmonisation Committee reconciling divergences.
- Months 9–24 (2027-07-12 to 2028-10-12): Coordinate with both environment ministries; codify seasonal construction windows in Critical Path schedule; embed into Design Basis and gate criteria.
- Month 24 (2028-10-12): Issue harmonised environmental consent signed by both states; lock in mitigation commitments (cost, schedule, monitoring obligations); establish Construction Environmental Manager role (joint team) for compliance oversight during fabrication (Months 36 onwards = 2029-10-12 onwards).

**Approval Authorities:** Spanish and Moroccan environment authorities (joint signatory); EU institutions (if Natura 2000 or maritime directives apply); binational Board (liaison)

### 9. Emergency Egress and Incident Response Design Basis

**ID:** 0e320dac-a514-402d-bb8b-ffd0c5fb6f4f

**Description:** Specifies design standards for passenger safety in the event of fire, flooding, derailment or other emergency at 100 m depth. Covers time-to-safety (all passengers reach pressurised refuge or escape bore within 20 minutes estimate), refuge air/smoke-control design (6–12 hour self-rescue endurance minimum), cross-passage spacing (500–1000 m intervals to parallel service bore or vertical shafts), rescue asset basing (tugs, hyperbaric chambers at Tarifa and Tangier, staffed 24/7 by Month 100 = 2035-02-12), emergency command authority (joint Spanish–Moroccan protocol), and training/drill requirements (full-scale simulation by Month 108 = 2035-10-12). Cost cap EUR 0.5–2 billion absorbed in design. If egress infrastructure exceeds cost cap or reduces buoyancy margin below 5–10% threshold, escalate to binational Board. Audience: Design Change Control Board, Lead Certifier, emergency-services authorities, insurers.

**Responsible Role Type:** Chief Technical Officer and Emergency Response Regime Lead

**Primary Template:** UK rail-safety design standards (TSI Emergency Management); offshore emergency-egress design (ISO 23600)

**Secondary Template:** Fehmarnbelt emergency-egress concept (precedent)

**Steps:**

- Month 3 (2027-01-12): Define emergency scenarios (fire, flooding, derailment) and time-to-safety targets; establish baseline egress concept (service bore + cross-passages vs. vertical shafts).
- Months 3–9 (2027-01-12 to 2027-07-12): Conduct refuge-capacity analysis (10% of train length minimum); design air-supply and smoke-control systems; cost estimate for both options.
- Month 9 (2027-07-12): Freeze egress design basis; submit to Lead Certifier for safety-case review; confirm cost impact on buoyancy margin.
- Months 12–36 (2027-10-12 to 2029-10-12): Coordinate with Spanish and Moroccan emergency-services authorities; establish Joint Coast Guard and Naval Coordination Protocol (Month 12 = 2027-10-12); pre-position rescue assets (Months 100 onwards = 2035-02-12 onwards).
- Month 108 (2035-10-12): Conduct full-scale rescue drill (simulated train fire, passenger evacuation, rescue-asset response) to validate procedures and asset readiness.

**Approval Authorities:** Lead Certifier (safety-case acceptance); Spanish and Moroccan transport and emergency-management authorities; binational Board (cost and scope approval)

### 10. Shipping Interaction and Maritime Security Perimeter Design

**ID:** 44af8df5-2c10-4b44-b43f-5768a0235d0d

**Description:** Defines protection measures against anchor damage, vessel sinking, dropped cargo and deliberate attack in the busy Strait of Gibraltar. Establishes no-anchoring exclusion corridor (±500–1000 m, agreed with International Maritime Organization and Spanish/Moroccan maritime authorities by Month 12 = 2027-10-12); passive hardening design (protective sleeves on tethers and upper tube sections, EUR 0.5–1 billion estimate, testing by Month 42 = 2030-04-12); sonar and radar detection network (deployed by Month 48 = 2030-10-12) with alert thresholds for vessel incursion; and Joint Coast Guard/Naval Coordination Protocol (established by Month 12 = 2027-10-12) for rapid response to emergencies. Design impact load cases (sinking-ship, anchor strike) into the structural design basis; cost EUR 0.5–3 billion (contingency-draw if exceeds EUR 1 billion). Audience: binational Board, maritime authorities, shipping industry liaison, insurers, Design Change Control Board.

**Responsible Role Type:** Chief Technical Officer and Shipping/Security Specialist

**Primary Template:** ISO 23600 (immersed-tunnel impact design); international maritime-security protocols

**Secondary Template:** International Maritime Organization (IMO) exclusion-corridor standard (precedent)

**Steps:**

- Month 3 (2027-01-12): Establish Shipping Interaction and Maritime Security Programme; engage IMO, Spanish and Moroccan maritime authorities; define traffic density, vessel types, risk scenarios.
- Months 3–12 (2027-01-12 to 2027-10-12): Coordinate with IMO to codify no-anchoring corridor; propose Vessel Traffic Service (VTS) amendments; negotiate with shipping industry.
- Months 6–12 (2027-04-12 to 2027-10-12): Design passive hardening (protective sleeves, impact-resistant zones) for tethers and upper tube; cost estimate EUR 0.5–1 billion.
- Months 12–48 (2027-10-12 to 2030-10-12): Procure and deploy sonar/radar network (EUR 50–100 million estimate) with alert system; coordinate with VTS operations.
- Month 12 (2027-10-12): Establish Joint Coast Guard and Naval Coordination Protocol; pre-position rescue assets and emergency-response procedures.
- Month 42 (2030-04-12): Complete passive-hardening testing; integrate into fabrication specifications.

**Approval Authorities:** International Maritime Organization (corridor approval); Spanish and Moroccan maritime authorities; binational Board (design and cost); EU maritime directorate (if EU shipping-safety law applies)

### 11. Paired Casting Yards Quality and Production Specification

**ID:** f42089cc-fb57-40f9-a672-9fc00f523bb4

**Description:** Unified technical specification governing segment casting at Algeciras (Spain) and Tanger Med (Morocco). Codifies concrete strength (C50 minimum), reinforcement placement tolerance (±5 mm), ballast-pocket location (±10 mm), dimensional tolerance (±50 mm over 500 m segment), joint-preparation standards, hydrostatic testing procedures (1.5× design pressure), and quality-assurance protocol (independent third-party inspection monthly at each yard). Establishes a central Joint Manufacturing and Quality Control Laboratory (Spanish or neutral EU location) with authority to certify every joint and ballast configuration before immersion. Cost penalties (EUR 0.5–1 million per audit variance >5% between yards) and schedule rewards (2-week acceleration credit per three variance-free audits) incentivize quality parity across both yards. Audience: yard contractors, Quality Lead, Design Change Control Board, fabrication teams.

**Responsible Role Type:** Marine Fabrication and Immersion Programme Manager and Lead Quality Officer

**Primary Template:** ACI concrete-construction standards; ISO 13849 quality-management protocol

**Secondary Template:** Fehmarnbelt element-factory quality specification (precedent)

**Steps:**

- Month 6 (2027-04-12): Award casting-basin civil-works contracts (Algeciras and Tanger Med); define yard construction schedule and ramp-up timeline.
- Month 9 (2027-07-12): Codify unified segment-design standards (concrete, reinforcement, ballast) in binding Technical Specification Document; obtain contractor acceptance.
- Months 12–18 (2027-10-12 to 2028-04-12): Establish central Joint Manufacturing and Quality Control Laboratory; appoint Lead Quality Officer; define monthly audit and certification protocols.
- Months 24–36 (2028-10-12 to 2029-10-12): Complete casting-basin construction; recruit and train casting crews; conduct mock-ups and trial casts.
- Months 36–120 (2029-10-12 to 2036-10-12): Execute production casting under unified standards; run monthly independent audits; enforce cost penalties and schedule rewards.

**Approval Authorities:** Lead Quality Officer (segment certification authority); binational Board (standards approval); casting-yard contractors (acceptance of specifications)

### 12. Full-Scale Prototype Segment Design, Fabrication and Immersion Plan

**ID:** 0a9d30c5-a3cf-4123-9168-6e52326bd3ac

**Description:** Detailed plan for designing, casting, testing and immersing a full-scale prototype tube segment (minimum 500 m length, ~10 m diameter estimate) at Algeciras by Month 36 (2029-10-12). Validates ballast calculations, towing procedures under Strait currents, joint watertightness under hydrostatic pressure (1.5× design pressure), production-quality methods, and immersion weather-window feasibility. Budget EUR 100–150 million (estimate). Critical-path slip tolerance ≤6 months. Prototype immersion success is a gate-pass criterion at Month 36 (2029-10-12); failure triggers immediate design-change decision and schedule review. Audience: fabrication team, Chief Technical Officer, Lead Certifier, marine operations contractor.

**Responsible Role Type:** Marine Fabrication and Immersion Programme Manager and Marine Operations Lead

**Primary Template:** Engineering prototype-testing protocol (precedent: Fehmarnbelt prototype element)

**Secondary Template:** HZMB pilot-immersion procedures

**Steps:**

- Months 18–24 (2028-04-12 to 2028-10-12): Design prototype segment (500 m, representative diameter and joint configuration); finalize towing and immersion procedures; obtain Lead Certifier approval of design.
- Months 24–36 (2028-10-12 to 2029-10-12): Cast prototype at Spanish yard under unified quality standards; conduct hydrostatic testing (1.5× design pressure) and ballast verification; prepare for tow-out.
- Month 30–36 (2029-04-12 to 2029-10-12): Tow prototype from Algeciras to Bay of Algeciras; execute immersion under live-sea conditions; monitor joint watertightness, ballast performance and structural response.
- Month 36 (2029-10-12): Complete immersion and initial operation; document lessons learned; brief design and fabrication teams.
- Months 36–48 (2029-10-12 to 2030-10-12): Incorporate prototype findings into production design and fabrication procedures; validate changes via Lead Certifier before full-rate production authorization at Month 48 (2030-10-12).

**Approval Authorities:** Lead Certifier (design and immersion approval); Chief Technical Officer (success criteria); binational Board (gate decision at Month 36 = 2029-10-12)

### 13. Demand Forecast and Rail-Systems Financial Structure

**ID:** dce7392a-4dcd-4cf1-bb88-69280adc754d

**Description:** Independent demand study covering passenger demand sensitivity (elasticity, price competition from flights/ferries), through-running adoption by Spanish and Moroccan national networks, freight potential (agricultural, logistics), and three scenarios: planning case (4.0 million passengers + EUR 100 million freight/year), downside (2.5 million passengers + EUR 40 million freight), upside (6.0 million passengers + EUR 150 million freight). Models Debt Service Coverage Ratio (DSCR) for each scenario under the EUR 4.4 billion private-debt structure and EUR 8.8 billion rail-systems tranche. If downside DSCR <0.8x, triggers binding availability-payment commitment (EUR 270–284 million/year for 15 years minimum) from Spain, Morocco and/or EU, or rebalances private debt downward and public equity upward. Anchor-tenant agreements with Spanish and Moroccan rail operators (signed by Month 24 = 2028-10-12) operationalize demand commitments. Audience: lenders, finance ministries, rail operators, binational Board.

**Responsible Role Type:** Railway Systems Integration and Demand Forecasting Lead

**Primary Template:** Transport-modelling demand-study precedent (Steer Davies Gleave, Arup methodologies)

**Secondary Template:** European high-speed-rail demand models (e.g., Gotthard, SNCF precedents)

**Steps:**

- Months 0–3 (2026-10-12 to 2027-01-12): Commission independent transport-modelling firm; define scope (baseline, downside, upside scenarios); brief with Strait market context, competitor routes (flights, ferries, road).
- Months 3–9 (2027-01-12 to 2027-07-12): Conduct demand modelling; extract opening-day and Year 5–10 demand curves; run DSCR stress tests under three scenarios.
- Month 9 (2027-07-12): Present findings to finance ministries and lenders; flag DSCR shortfall if downside scenario yields <0.8x coverage.
- Months 9–24 (2027-07-12 to 2028-10-12): Negotiate availability-payment covenants with Spain, Morocco and EU (if downside DSCR <1.0x); finalize rail-operator anchor-tenant agreements committing to minimum throughput.
- Month 24 (2028-10-12): Document final demand assumptions and availability-payment structure in concession agreement; obtain lender approval for debt syndication.

**Approval Authorities:** Spanish and Moroccan finance ministries (funding decision); multilateral lenders (debt syndication approval); rail operators (anchor-tenant signatures)

### 14. Cost-Overrun Response Plan and Funding Gap Decision

**ID:** d13524c2-a33e-43aa-aade-9d48bdafaf9f

**Description:** Framework addressing the EUR 2.8–10.8 billion gap between plausible cost overrun (EUR 10–18 billion) and allocated contingency (EUR 7.2 billion). Specifies funding sources for three overrun scenarios: EUR 0–3 billion (contingency draw + Design Change Reserve), EUR 3–7 billion (additional EU/multilateral tranches + scope phasing options), EUR 7–18 billion (sovereign guarantee escalation + scope reduction). Establishes cost-escalation triggers (EUR 44 billion = 10% overage, EUR 46 billion = 15% overage) and decision timelines (Month 6 = 2027-04-12 initial; Months 24, 48, 72 = 2028-10-12, 2030-10-12, 2032-10-12 gates). Documents pre-approved scope-reduction scenarios (reduced tube diameter, phased opening, deferred feeder-line integration) with cost and revenue impacts. Secures binding political commitment from both treasuries to the gap-closure mechanism by Month 3 (2027-01-12). Audience: Spanish and Moroccan finance ministries, EU, multilateral lenders, binational Board.

**Responsible Role Type:** Cost Control Authority Lead and Finance Ministries

**Primary Template:** Megaproject contingency-management and rebaselining protocol

**Secondary Template:** EU guidelines on contingency reserve for large-scale infrastructure projects

**Steps:**

- Months 2–3 (2026-12-12 to 2027-01-12): Commission Monte Carlo cost-risk model quantifying P50/P80/P95 cost distributions; identify overrun exposure quantitatively.
- Month 3 (2027-01-12): Present gap analysis to Spain, Morocco, EU and multilateral lenders; propose three funding scenarios (contingency draw, additional tranches, scope reduction).
- Month 3 (2027-01-12): Secure written commitment from all funding sources specifying responsibility for overruns (e.g., Spain absorbs 30% of overrun, Morocco 15%, EU 30%, multilaterals 25%, or named trigger for scope reduction).
- Months 3–6 (2027-01-12 to 2027-04-12): Model scope-reduction options (cost and schedule impact, revenue loss); cost out at Month 6 (2027-04-12) for decision readiness at Month 24 (2028-10-12) gate if needed.
- Months 6–240 (2027-04-12 to 2046-10-12): Quarterly review of cost forecast vs. baseline; escalate per protocol if EUR 44 billion (10%) or EUR 46 billion (15%) thresholds are exceeded; invoke pre-approved scope reductions or additional funding tranches without requiring new treaty negotiation.

**Approval Authorities:** Spanish and Moroccan finance ministries (written commitment); EU and multilateral lenders (tranche-availability confirmation); binational Board (scope-reduction decision authority)

### 15. Tranched Funding Release and Gate-Passage Criteria

**ID:** 0c45ad2a-6814-43b2-ab24-d9087ca59389

**Description:** Defines EUR 40 billion funding release across five tranches tied to objective, pre-agreed gate criteria: Tranche 1 (EUR 0.5 billion, Months 0–12 = 2026-10-12 to 2027-10-12, seabed/concept validation); Tranche 2 (EUR 2.0 billion, Months 12–36 = 2027-10-12 to 2029-10-12, design and permitting); Tranche 3 (EUR 1.5 billion, Months 24–48 = 2028-10-12 to 2030-10-12, prototype/pilot); Main Construction (EUR 20 billion, Months 36–96 = 2029-10-12 to 2034-10-12, casting yards and immersion); Systems/Commissioning (EUR 8.8 billion, Months 60–120 = 2031-10-12 to 2036-10-12). Gate pass/fail criteria: Month 9 (2027-07-12) = geophysics >80%, no show-stoppers; Month 15 (2028-01-12) = treaty ratified, design code drafted; Month 24 (2028-10-12) = support concept frozen, consents issued, prototype joint test complete; Month 36 (2029-10-12) = pilot segment immersed successfully; Month 48 (2030-10-12) = yards at 80% capacity. Gate failures trigger scope review or schedule adjustment. Audience: Spanish and Moroccan finance ministries, EU, multilateral lenders, binational Board.

**Responsible Role Type:** Cost Control Authority Lead and Finance Ministries

**Primary Template:** EU guidelines on tranched financing for infrastructure projects; World Bank disbursement protocols

**Secondary Template:** PPP concession financing framework

**Steps:**

- Month 2 (2026-12-12): Define tranche structure and gate criteria; publish to all funding sources.
- Months 2–3 (2026-12-12 to 2027-01-12): Codify gate pass/fail criteria and consequences (pass = next tranche released within 2 weeks; fail = scope review within 4 weeks).
- Month 3 (2027-01-12): Secure written commitment from Spain, Morocco, EU and multilateral lenders confirming tranche-release authority and timelines.
- Months 6–240 (2027-04-12 to 2046-10-12): Execute tranches per schedule; Cost Authority reports gate progress monthly; release/hold tranches per Board decision based on gate criteria.

**Approval Authorities:** Spanish and Moroccan finance ministries (tranche release authority); EU and multilateral lenders (co-financing tranche approval); binational Board (gate decision authority)

### 16. High-Level Operational Plan and Long-Term Sustainability Framework

**ID:** c750a758-9b5d-4c46-a513-4c4dd9ee4790

**Description:** Strategy for 50–100 year service life covering concrete durability in deep marine environment (corrosion protection, ASR/alkali-silica reaction risk at 100 m), tether fatigue under cyclic seismic/tidal loading, predictive maintenance regime (condition-based monitoring using structural sensors embedded during construction), 10-year independent structural assessments, long-term operations and maintenance reserve fund (EUR 200–400 million indexed to inflation), and decommissioning reserve fund (EUR 2–5 billion over 50-year life, funded from fare revenue). Embeds operational requirements into design (inspection access for ROVs, modular maintenance sections, sensor placement) by Month 24 (2028-10-12). Develops O&M manual and condition-based maintenance plan by Month 108 (2035-10-12) pre-opening. Establishes Operations Authority and permanent O&M staffing by Month 120 (2036-10-12) handover. Audience: design team, Long-Term Operations and Sustainability Lead, Operations Authority (post-opening).

**Responsible Role Type:** Long-Term Operations and Sustainability Lead (full-time Month 6–240 = 2027-04-12 to 2046-10-12)

**Primary Template:** Infrastructure asset-management lifecycle plan; ISO 55000 asset-management standards

**Secondary Template:** Fehmarnbelt long-term durability and O&M strategy (precedent)

**Steps:**

- Months 6–12 (2027-04-12 to 2027-10-12): Commission concrete-durability studies in deep-marine environments; assess tether fatigue risk under 50-year load cycles.
- Months 12–24 (2027-10-12 to 2028-10-12): Embed operational requirements into design (inspection shafts, modular sections, sensor locations); define instrumentation suite (acoustic, strain, current, seismic sensors).
- Months 24–108 (2028-10-12 to 2035-10-12): Design predictive-maintenance algorithms using long-term monitoring data; develop condition-based triggering rules for inspections and repairs.
- Month 108 (2035-10-12): Issue final O&M manual and condition-based maintenance plan; appoint Operations Authority; recruit and train permanent staff.
- Months 108–240 (2035-10-12 to 2046-10-12): Establish O&M reserve fund (EUR 200–400 million) and decommissioning reserve (EUR 2–5 billion); conduct 10-year structural assessments beginning Year 10 post-opening.

**Approval Authorities:** Chief Technical Officer (operational design embedding); Operations Authority (O&M plan acceptance); Spanish and Moroccan transport authorities (long-term sustainability oversight)

### 17. Risk Register and Interdependency Analysis

**ID:** c6fafca2-8f2e-4717-a58f-03de7c6980ef

**Description:** Comprehensive Risk Register documenting 18+ principal risks (technical feasibility, regulatory delay, cost overrun, schedule compression, environmental, marine construction, governance, supply-chain, certification, operations/durability, demand/revenue, shipping/security, seabed/geohazard, geotechnical, seismic, emergency response, political/diplomatic, cost control) with likelihood (1–5 scale), severity (1–5 scale), mitigation owner, and escalation thresholds. Includes Risk Dependency Matrix showing how risks interact and compound (e.g., treaty delay + seabed delay both compress fabrication schedule). Defines three risk scenarios (Optimistic: all milestones on time, cost within EUR 7.2 billion reserve; Central: one 6–12 month slip, cost EUR 10–12 billion; Pessimistic: two concurrent slips, cost EUR 14–18 billion). Quarterly scenario-review meetings stress-test programme decisions against risk compounding. Audience: binational Board, lenders, insurers, risk manager.

**Responsible Role Type:** Risk Management and Independent Assurance Lead

**Primary Template:** PMI Risk Management Plan; APMG risk-register template

**Secondary Template:** Megaproject risk-interdependency analysis (precedent: Fehmarnbelt)

**Steps:**

- Month 1 (2026-11-12): Establish risk-identification workshop across all workstreams (treaty, seabed, design, fabrication, environment, finance, operations); document 18+ principal risks with owners.
- Months 1–3 (2026-11-12 to 2027-01-12): Develop Risk Dependency Matrix showing risk interactions (e.g., treaty slip cascades to fabrication compression).
- Months 3–6 (2027-01-12 to 2027-04-12): Model three scenario outcomes (Optimistic, Central, Pessimistic); quantify schedule and cost impact of each risk combination.
- Months 6–240 (2027-04-12 to 2046-10-12): Maintain and update Risk Register quarterly; conduct monthly escalation reviews for risks >3/5 likelihood and >3/5 impact; scenario-review meetings every 6 months to assess compounding-risk probability.

**Approval Authorities:** Risk Management Lead (Register ownership); binational Board (escalation decisions); finance ministries (political-risk oversight)

### 18. Monthly Programme Governance Office and Gate Reporting Dashboard

**ID:** 294836a1-a39c-4fe9-a102-9ddcae7c5378

**Description:** Operational governance structure ensuring disciplined monthly reporting and decision-making. Covers Programme Board monthly meetings (attendance: Programme Director, technical leads, cost authority, schedule lead, finance representatives; agenda: cost variance >5%, schedule slip >6 months, design-change decisions, risk escalations); Design Change Control Board weekly teleconference with 2-week routine turnaround; monthly cost-control variance tracking (actual vs. forecast, escalation if >5% per tranche); quarterly risk reviews; monthly stakeholder briefings (lenders, insurers, operators). Dashboard reports: cost-per-km tracking, earned-value % completion, schedule baseline vs. current, variance forecast at completion, weather-window immersion status, supply-chain risk score. Gate-decision tracker (colour-coded: green = operational decision complete, yellow = Board-level decision pending, red = political escalation required). Audience: binational Board, delivery authority, lenders, insurers, both finance ministries.

**Responsible Role Type:** Binational Programme Director and Governance Office Manager

**Primary Template:** Project management office (PMO) standard operating procedures; APMG governance framework

**Secondary Template:** Megaproject monthly reporting protocol (precedent: Crossrail)

**Steps:**

- Month 2 (2026-12-12): Establish Programme Governance Office (2–3 staff); define monthly and weekly meeting cadence, attendees, decision authorities.
- Months 2–6 (2026-12-12 to 2027-04-12): Design monthly reporting dashboard (cost, schedule, risk, variance tracking); select business intelligence tool (e.g., Tableau, Power BI).
- Month 6 (2027-04-12): Begin monthly Programme Board meetings; weekly Design Change Board teleconferences.
- Months 6–240 (2027-04-12 to 2046-10-12): Execute monthly governance rhythm; publish variance reports and decision logs; escalate per protocol; maintain gate-decision tracker.

**Approval Authorities:** Binational Programme Director (governance office authority); binational Board (meeting oversight and decision authority)

### 19. Casting-Yard Site Selection and Construction Business Case

**ID:** 373488cf-0c3a-423a-bbf3-72ee2a4fbafd

**Description:** Justification for paired casting yards at Algeciras (Spain) and Tanger Med (Morocco), including site-selection criteria (deep-water access, industrial-zone availability, labour supply, proximity to crossing, domestic political balance), infrastructure requirements (concrete-batching plant, curing sheds, launching basins, storage area), construction schedule and cost estimate (EUR 1–2 billion for both yards combined estimate), ramp-up timeline (Months 24–36 = 2028-10-12 to 2029-10-12 site construction; Months 36–48 = 2029-10-12 to 2030-10-12 production ramp), and economic-impact justification (regional employment, skills legacy). Audience: Spanish and Moroccan transport and economic development authorities, binational Board, lenders.

**Responsible Role Type:** Marine Fabrication and Immersion Programme Manager

**Primary Template:** Infrastructure site-selection and construction business-case template

**Secondary Template:** Fehmarnbelt element-factory business case (precedent)

**Steps:**

- Month 6 (2027-04-12): Conduct site-selection study for both Algeciras and Tanger Med; evaluate port capacity, industrial zone availability, labour supply.
- Months 6–12 (2027-04-12 to 2027-10-12): Prepare detailed design for casting basins, batching plants, curing sheds, storage and launching facilities; cost-estimate construction.
- Month 12 (2027-10-12): Prepare business case justifying paired-yard approach (cost savings from shorter tows, political parity, labour distribution) vs. single-yard alternative; obtain government approval.
- Months 12–24 (2027-10-12 to 2028-10-12): Award site-preparation and civil-works contracts; begin site development.
- Months 24–36 (2028-10-12 to 2029-10-12): Complete casting-yard construction; mobilise equipment (batching plants, cranes); recruit and train casting crews.

**Approval Authorities:** Spanish and Moroccan economic development authorities; binational Board; lenders (site and cost approval)

### 20. Ridership Ramp and Landside Network Integration Programme Charter

**ID:** 0819b34b-7ac2-4899-b7f6-e7b535f5af08

**Description:** Strategy document specifying how passenger and freight demand will be built and connected to the tunnel opening to avoid stranded crossing capacity. Scope includes feeder-line upgrades in Spain (high-speed rail connections to Algeciras/Tarifa area) and Morocco (rail links to Tangier and hinterland), service patterns at opening (frequency, fares, through-running vs. shuttle), and any freight or vehicle-shuttle role. Success metrics: utilisation against design capacity at opening, landside-line readiness synchronised with tunnel commissioning, and revenue adequacy to support debt service (EUR 270+ million/year needed). Clarifies whether feeder-line financing sits inside or outside the EUR 40 billion envelope (currently an open decision). Audience: Spanish and Moroccan rail operators, transport ministries, finance ministries, lenders.

**Responsible Role Type:** Railway Systems Integration and Demand Forecasting Lead

**Primary Template:** Transport infrastructure integration and network-development business case

**Secondary Template:** European high-speed-rail network integration framework (precedent: Gotthard–Neat, Fehmarnbelt rail integration)

**Steps:**

- Month 6 (2027-04-12): Map existing Spanish and Moroccan rail networks and identify necessary feeder-line upgrades (capacity, frequency, gauge/signalling compatibility with tunnel).
- Months 6–12 (2027-04-12 to 2027-10-12): Conduct transport-demand study validating opening-day demand (planning case: 4.0 million passengers) and landside-capacity requirements.
- Month 12 (2027-10-12): Decide whether feeder-line financing is inside (EUR 40 billion) or outside (separate transport-ministry budgets) the envelope; obtain agreement from both transport ministries.
- Months 12–24 (2027-10-12 to 2028-10-12): Define service patterns at opening (frequency, fares, through-running agreements); negotiate anchor-tenant agreements with Spanish (Renfe) and Moroccan (ONCF) rail operators.
- Months 24–120 (2028-10-12 to 2036-10-12): Synchronise feeder-line upgrade schedule with tunnel construction; ensure both are ready for service opening Month 132 (2037-10-12).

**Approval Authorities:** Spanish and Moroccan transport and finance ministries; rail operators (service-pattern sign-off); binational Board (integration approval)

### 21. Immersion Operations and Weather-Window Contingency Plan

**ID:** dff07730-298e-4846-8c89-840008d3e59a

**Description:** Detailed operational plan for immersion execution, including segment sequence, weather-forecast decision protocols, towing routes and current-force thresholds, segment-joining procedures (on-site), ballast-system operation, and contingency responses to weather delays, towing accidents or joint failures. Establishes go/no-go immersion criteria (5-day forecast <1.5 m significant wave height AND <0.5 m/s cross-current velocity); defers segments to next usable window if conditions worsen mid-tow. Includes 10–15% spare-segment pool (1.4–2.1 km of tube estimate) to absorb rework or segment loss. Contingency plan for towing accidents (segment sinking, line breakage) with salvage procedures, cost/schedule impact assessment, and alternative segment sourcing. Audience: marine operations contractor, immersion crews, Schedule Lead, binational Board.

**Responsible Role Type:** Marine Construction and Immersion Operations Director

**Primary Template:** Marine construction operations and weather-contingency plan (precedent: HZMB immersion operations)

**Secondary Template:** Hydrographic and met-ocean forecasting procedure

**Steps:**

- Months 12–24 (2027-10-12 to 2028-10-12): Develop detailed immersion master schedule; define segment sequence and landing sequence for optimal joint continuity.
- Month 24 (2028-10-12): Complete weather-forecast protocol and go/no-go decision criteria; establish real-time weather-monitoring system (5-day forecasting).
- Months 24–36 (2028-10-12 to 2029-10-12): Procure towing vessels and immersion equipment; conduct prototype-segment towing trial; validate current-force predictions and towing-procedure safety margins.
- Month 36 (2029-10-12) onwards: Execute immersion campaigns per schedule; monitor weather windows continuously; defer segments as needed (maintain schedule slack via floating reserve).

**Approval Authorities:** Marine Operations Lead; binational Board (go/no-go decisions at weather-delay thresholds); health-and-safety regulators (towing and immersion safety oversight)

### 22. Tether Design, Testing and Fatigue Qualification Programme

**ID:** 9c46b952-e3e9-4cd7-bdc2-196c224f854e

**Description:** Detailed engineering programme for tether-cable systems (tension members for buoyancy support in deep channels >400 m depth). Scope includes: tether-material selection (high-strength steel wire rope or synthetic composite, balancing cost, durability, installation logistics), fatigue analysis under 50-year service life (cyclic loading from tides, currents, seismic motion, waves), anchor-design and installation procedures, prototype pull-test programme (full-scale tether test under 50+ MN load and cyclic fatigue), and qualification criteria for production tethers. Budget EUR 50–100 million for R&D and testing (Months 6–48 = 2027-04-12 to 2030-10-12). Parallel dual-supplier development strategy to avoid single-source lock-in. Audience: Chief Technical Officer, Lead Certifier, design team, tether manufacturers.

**Responsible Role Type:** Chief Technical Officer and Tether/Anchor Systems Engineer

**Primary Template:** Offshore-cable-system design and qualification standard (ISO 13628, API standards)

**Secondary Template:** Fehmarnbelt tether-design report (if comparable); floating-platform tether-qualification precedents

**Steps:**

- Months 6–12 (2027-04-12 to 2027-10-12): Define tether design basis (loads from seismic, tidal, wave, current analysis); select material and cable type; prepare preliminary design.
- Months 12–24 (2027-10-12 to 2028-10-12): Commission dual-supplier R&D (two manufacturers parallel development); conduct material-property testing and initial fatigue analysis.
- Months 24–36 (2028-10-12 to 2029-10-12): Complete prototype tether design; procure full-scale test specimen.
- Months 36–48 (2029-10-12 to 2030-10-12): Execute full-scale tether pull-test (50+ MN) and cyclic-fatigue testing (50-year load spectrum); document results and produce Lead Certifier-approved qualification report.
- Month 48 (2030-10-12): Approve production tethers; authorize long-term supplier contracts (with escalation caps and guaranteed availability).

**Approval Authorities:** Lead Certifier (qualification sign-off); Chief Technical Officer (design approval); binational Board (cost and schedule approval)

### 23. Transition Joint (Pillar-to-Tether) Design and Hydrostatic Testing Protocol

**ID:** 705168fc-9d59-4e3b-98e8-b8941a2de45e

**Description:** Specialized engineering programme for the transition joint connecting pillar-supported tube sections (<400 m depth) to tether-supported sections (>400 m depth). The joint must be structurally continuous (load path integrity), watertight (no seepage), and tolerant of differential movement under seismic loading. Scope includes: joint-geometry optimisation, reinforcement design, grout composition (corrosion resistance at 100 m depth), on-site installation procedures (in strong currents, 100 m underwater), and full-scale mock-up testing (assembly in controlled conditions, hydrostatic pressure to 1.5× design pressure, thermal cycling). Budget EUR 30–50 million for design and testing. Testing complete by Month 48 (2030-10-12) before full fabrication ramps. Audience: Chief Technical Officer, design team, Lead Certifier, Quality Lead, fabrication contractors.

**Responsible Role Type:** Chief Technical Officer and Hybrid-Concept Transition Joint Design Lead

**Primary Template:** Immersed-tube joint design and testing standard (ISO 23600)

**Secondary Template:** HZMB transition-joint testing report (precedent, if available)

**Steps:**

- Months 9–18 (2027-07-12 to 2028-04-12): Design transition joint with structural, waterproofing and seismic analysis; finalize reinforcement and grouting specifications.
- Months 18–24 (2028-04-12 to 2028-10-12): Prepare full-scale mock-up design; procure materials and tooling for mock-up assembly.
- Months 24–36 (2028-10-12 to 2029-10-12): Fabricate transition-joint mock-up (representative section, ~50 m length estimate); assemble with production procedures.
- Months 36–42 (2029-10-12 to 2030-04-12): Conduct hydrostatic testing (1.5× design pressure), thermal-cycle testing, and seismic-response testing; document results.
- Month 42 (2030-04-12): Lead Certifier approval of joint design and testing findings; authorization to proceed with production.

**Approval Authorities:** Lead Certifier (testing approval); Chief Technical Officer (design sign-off); Quality Lead (procedure approval); binational Board (cost and schedule)

### 24. Supply-Chain Framework Agreements and Long-Term Supplier Commitment Tracker

**ID:** 8f5ac3aa-185b-40b4-86bf-50540c5ef73e

**Description:** Set of binding long-term supply agreements with tier-1 suppliers for concrete admixtures, reinforcing steel (10,000+ tonnes/year over 8–10 years), anchor hardware, tether cables (custom, first-of-kind), buoyancy modules, and floating-crane rental. Each agreement specifies: fixed pricing with escalation caps (inflation +2%, capped at 5% per tranche), guaranteed availability and minimum lead-time notice (3–4 years advance for custom items), quality standards, delivery schedules aligned with fabrication ramp-up, and penalty clauses for non-performance. Tracking dashboard reports supplier status monthly, flagging any bottlenecks or cost/schedule risks. Agreements signed by Month 9 (2027-07-12) for material suppliers, Month 12 (2027-10-12) for custom-development and equipment suppliers. Audience: Supply-Chain Lead, Cost Control Authority, binational Board.

**Responsible Role Type:** Supply-Chain and Procurement Lead

**Primary Template:** Framework supply agreement (precedent: major construction projects, e.g., Crossrail)

**Secondary Template:** Long-lead-procurement management standard

**Steps:**

- Months 3–6 (2027-01-12 to 2027-04-12): Map supply chain; identify single-source and dual-source risks; assess market capacity and vendor capability.
- Months 6–9 (2027-04-12 to 2027-07-12): Negotiate framework agreements with tier-1 suppliers (concrete, reinforcement, hardware); lock in pricing and escalation caps; secure letters of commitment.
- Months 9–12 (2027-07-12 to 2027-10-12): Finalize custom-development and equipment-supplier agreements (tether cables, buoyancy modules, floating cranes); schedule R&D activities.
- Month 12 (2027-10-12) onwards: Establish quarterly supply-chain risk review; track supplier performance against commitments; escalate bottlenecks to Cost Authority and binational Board.

**Approval Authorities:** Binational Board (framework-agreement approval); Finance Lead (cost commitment approval); Supply-Chain Lead (vendor selection and performance oversight)

### 25. Availability-Payment Covenant and Demand-Risk Mitigation Structure

**ID:** 51cac4e4-c59b-4b7c-ba5f-47cad0898809

**Description:** Legal and financial framework committing Spain, Morocco and the EU to cover the annual Debt Service Coverage shortfall (EUR 230–284 million/year estimate) if rail operating revenue falls short of debt-service requirements (private debt EUR 4.4 billion at 4.5%, ~EUR 270 million/year service). Specifies: total annual availability-payment amount (EUR 270–284 million/year, escalated annually at inflation), commitment duration (minimum 15–30 years, aligned with private-debt maturity), triggering mechanism (automatic payment if revenue <EUR 270 million/year), and parliamentary/budget backing (binding statute or law, not discretionary). Includes demand-risk hedges: rail-operator anchor-tenant agreements (minimum throughput commitments), revenue-insurance or performance-bond options, and contingency clauses if demand falls >30% below forecast. Financial structure allows private debt syndication and lender confidence. Audience: Spanish and Moroccan finance ministries, EU, multilateral lenders, private-debt consortium.

**Responsible Role Type:** Railway Systems Integration Lead and Finance Ministry

**Primary Template:** Availability-payment concession agreement (precedent: European PPP projects)

**Secondary Template:** Demand-risk insurance and hedging structure

**Steps:**

- Months 3–6 (2027-01-12 to 2027-04-12): Commission independent demand study; confirm DSCR shortfall (EUR 230+ million/year) and financing structure implications.
- Months 6–12 (2027-04-12 to 2027-10-12): Draft availability-payment covenant terms; secure in-principle agreement from Spain, Morocco and EU finance ministries.
- Months 12–18 (2027-10-12 to 2028-04-12): Finalize covenant language; embed in concession agreement; obtain parliamentary approvals or budget-law amendments.
- Month 24 (2028-10-12): Execute binding availability-payment agreements; confirm in debt-syndication documents.

**Approval Authorities:** Spanish and Moroccan finance ministries (commitment authority); EU (if EU funds are part of availability payment); both parliaments (if statutory/budget-law amendment required); private lenders (debt syndication authority)

## Documents to Find

### 1. Strait of Gibraltar Bathymetric and Seismic Survey Data

**ID:** 52f0fb20-2418-4a0c-9eef-0b15894e8ed6

**Description:** Official hydrographic surveys and bathymetric maps of the Strait of Gibraltar, particularly the Camarinal Sill corridor (Tarifa to Tangier), documenting water depth, seabed geology, sediment distribution and seismic characterization. Raw data from Spanish Instituto Hidrográfico de la Marina, Moroccan hydrographic authority and international surveys (e.g., GEBCO global bathymetry). Source material for validating the plan's 100 m anchoring-depth assumption against actual Strait depths of several hundred metres to ~900 m.

**Recency Requirement:** Most recent available surveys (ideal: data within last 10 years; older bathymetry acceptable if no recent surveys exist). Seismic surveys preferred from last 20 years.

**Responsible Role Type:** Marine Geotechnical and Seabed Investigation Programme Manager

**Access Difficulty:** Medium. Spanish and Moroccan hydrographic data may be held by government maritime agencies and require formal data-access requests (2–4 week turnaround estimated). GEBCO and EMODnet data are open-access via online portals. SECEGSA/SNED archives may be partially available through Spanish/Moroccan infrastructure ministries, with classification or sensitivity review required (4–12 week turnaround estimated).

**Steps:**

- Contact Spanish Instituto Hidrográfico de la Marina (Madrid) for official Strait bathymetric charts and seismic survey data.
- Contact Moroccan Ministry of Merchant Marine and Fisheries for hydrographic data and seabed characterization studies.
- Access GEBCO (General Bathymetric Chart of the Oceans) global database and EMODnet (European Marine Observation and Data Network) for Strait data.
- Request SECEGSA and SNED archives (existing study entities) for pre-existing bathymetric and geological surveys commissioned since late 1970s.
- Contact international agencies: International Hydrographic Organization (IHO), NOAA/NCEI (National Centers for Environmental Information) for supplementary Strait bathymetry.

### 2. Spanish and Moroccan Environmental Law and Protected-Area Regulations

**ID:** 34e43880-4304-491c-b803-63279a52f4c6

**Description:** Current laws and directives governing environmental impact assessment (Spanish Law 21/2013 on Environmental Assessment; Moroccan Law 12/2003; EU Habitats Directive 92/43/EEC; EU Marine Strategy Framework Directive 2008/56/EC) and protected-area designations (Spanish marine protected areas, Moroccan protected zones, EU Natura 2000 listings in the Strait region). Source material for defining ecological consent pathways, regulator expectations, and seasonal construction-window constraints driven by species migration.

**Recency Requirement:** Current applicable laws (as of 2026-10-12, Month 0 = 2026-10-12); amendments or regulatory updates within the last 5 years preferred.

**Responsible Role Type:** Environmental Permitting and Ecological Compliance Lead

**Access Difficulty:** Easy. Spanish, Moroccan and EU environmental laws are published online by government agencies and EU legal databases (EUR-Lex). Protected-area designations are publicly accessible via UNEP-WCMC and national agency websites. 1–2 week turnaround to assemble applicable regulations.

**Steps:**

- Spanish Ministry of Ecological Transition and Demographic Challenge (Ministerio para la Transición Ecológica y el Reto Demográfico) website for Spanish law 21/2013 and current protected-area designations.
- Moroccan Ministry of Environment (Ministère de l'Environnement) website for Moroccan environmental law and protected-area listings.
- EUR-Lex (official EU legal database) for EU Habitats Directive 92/43/EEC and Marine Strategy Framework Directive 2008/56/EC texts.
- UNEP-WCMC (World Conservation Monitoring Centre) Natura 2000 viewer and MPA Atlas for Strait protected-area boundaries and designations.
- EU maritime-authorities network for current EU maritime spatial-planning directives and shipping-lane regulations in the Strait.

### 3. Strait of Gibraltar Ecological and Species Migration Data

**ID:** dc586dd2-bb56-4f01-ae51-dbb07c11291b

**Description:** Scientific data on cetacean (dolphins, whales), seabird and sea-turtle migration patterns through the Strait, including peak migration seasons, population density estimates, acoustic signatures and habitat-use patterns. Source: peer-reviewed biodiversity surveys, long-term monitoring programmes (e.g., by conservation NGOs, research institutions), and ecological baseline reports from comparable Mediterranean projects.

**Recency Requirement:** Recent ecological data preferred (studies within last 10 years); historical baseline studies acceptable if no current data exist. Migration-pattern data should reflect recent climate/ocean changes if available.

**Responsible Role Type:** Environmental Permitting and Ecological Compliance Lead

**Access Difficulty:** Medium. Scientific literature is accessible via academic databases (Web of Science, Scopus) with institutional subscription or interlibrary loan (1–2 weeks). NGO and government research-institution reports may require direct contact and data-sharing requests (2–4 weeks). Acoustic and long-term monitoring data may be held by research organizations with restricted access and require formal data-access agreements (4–8 weeks).

**Steps:**

- Contact marine-biology research institutions in Spain (Instituto Español de Oceanografía, CSIC) and Morocco (Institut National de Recherche Halieutique) for Strait ecological surveys.
- Search scientific literature (Web of Science, Scopus) for peer-reviewed papers on Strait cetacean migration (keywords: 'Strait of Gibraltar cetacean migration', 'cetacean bottleneck').
- Access NGO reports: WWF Mediterranean, Fundación Biodiversidad (Spain), IUCN Red List data for Strait species.
- Contact acoustic-monitoring initiatives (e.g., SOCIB—Balearic Islands Coastal Observing and Forecasting System) for cetacean presence-absence data.
- Request baseline-study data from comparable Mediterranean projects (e.g., Fehmarnbelt ecological baseline, HZMB environmental baseline) as methodological precedent.

### 4. Strait of Gibraltar Tidal Current and Wave Climate Data

**ID:** e89a09f8-346a-4de8-9ea0-4d24d71afff9

**Description:** Historical and current measurements of tidal currents (velocity, direction, seasonal variation), significant wave-height distribution (percentiles, storm recurrence), wind climate and sea-state frequency from hydrographic and oceanographic sources. Source material for weather-window and immersion-feasibility modelling. Data from Spanish and Moroccan hydrographic services, NOAA, European Centre for Medium-Range Weather Forecasts (ECMWF), and long-term mooring records if available.

**Recency Requirement:** Historical data from at least the last 20 years (preferably 30+ years for climate-change context); most recent data essential (within last 2–3 years) for current conditions.

**Responsible Role Type:** Marine Logistics and Immersion Operations Lead

**Access Difficulty:** Easy to Medium. NOAA and ECMWF data are freely available via online portals (1–2 weeks download and processing). Spanish/Moroccan hydrographic data may require formal data-request procedures (2–4 weeks). Long-term mooring data held by research institutions may have restricted access (4–8 weeks negotiation).

**Steps:**

- Contact Spanish Instituto Hidrográfico de la Marina and Moroccan hydrographic authority for Strait tidal and current measurements.
- Access NOAA/NCEI historical ocean-data archives (global tidal and wave databases) at https://www.ncei.noaa.gov/.
- Request ECMWF reanalysis data (ERA5) covering the Strait region for wind and wave climate (open-access download).
- Search for long-term buoy or mooring records deployed in the Strait by oceanographic research institutions (contact Instituto Español de Oceanografía, CSIC).
- Obtain published studies on Strait oceanography from peer-reviewed literature (Mediterranean oceanography journals).

### 5. Strait of Gibraltar Seismic Hazard and Earthquake Data

**ID:** 04368845-9a4c-46fc-b05f-a87e4279d237

**Description:** Instrumental seismicity records, earthquake catalogues, fault-zone mapping and probabilistic seismic-hazard assessment (PSHA) parameters for the Eurasia–Africa plate boundary in the Strait region. Source: Spanish and Moroccan geological surveys, USGS Earthquake Hazards Program, and published PSHA models for the Strait and Western Mediterranean.

**Recency Requirement:** Earthquake catalogues should be current (within last 5 years update minimum); PSHA models from last 15 years acceptable; recent studies preferred.

**Responsible Role Type:** Chief Technical Officer and Seismic Design Specialist

**Access Difficulty:** Easy to Medium. USGS Earthquake Hazards Program data are freely available online. Spanish and Moroccan geological surveys maintain public catalogues accessible via web portals (1–2 weeks). PSHA models from research institutions may require contact and data-sharing agreements (2–4 weeks).

**Steps:**

- Contact Spanish Instituto Geográfico Nacional (National Geographic Institute) for seismic hazard data and earthquake catalogue.
- Contact Moroccan geological survey (Direction de la Géologie) for regional seismicity data.
- Access USGS Earthquake Hazards Program (https://www.usgs.gov/programs/vhp) for Western Mediterranean seismic data and PSHA models.
- Search peer-reviewed literature (Tectonophysics, Journal of Geophysical Research) for Strait seismic-hazard studies.
- Request detailed PSHA calculations from geological institutions if published models are insufficient (e.g., from Spanish/Moroccan geological surveys or European seismic networks).

### 6. Spanish High-Speed Rail Network Standards and Gauge Specifications

**ID:** a1845124-bbde-43e6-b609-4b17ce60bc4f

**Description:** Technical standards for Spanish high-speed rail infrastructure: track gauge (typically 1,668 mm or 1,435 mm), signalling systems (ASFA, ERTMS/ETCS), traction power (AC 25 kV or DC 3 kV), train operating procedures, and compatibility requirements for rail systems entering/exiting the tunnel. Source: Spanish Ministry of Transport (Ministerio de Transportes, Movilidad y Agenda Urbana) and Renfe (Spanish rail operator) technical documentation.

**Recency Requirement:** Current standards (as of 2026-10-12); updates within last 3–5 years preferred. Standards should reflect any ongoing modernization (e.g., ERTMS rollout).

**Responsible Role Type:** Railway Systems Integration and Operating Concept Lead

**Access Difficulty:** Medium. Spanish Ministry of Transport and Renfe maintain technical standards, which may be proprietary or restricted to licensed operators. Public-domain portions accessible via ministry website (1–2 weeks). Full technical specifications may require formal request and confidentiality agreement with rail operators (2–6 weeks).

**Steps:**

- Contact Spanish Ministry of Transport for official rail-network standards and gauge specifications.
- Request Renfe technical department documentation on signalling, traction-power systems and train specifications for high-speed services.
- Access ADIF (Spanish railway-infrastructure administrator, Administrador de Infraestructuras Ferroviarias) technical standards (public-domain portions).
- Search UNIFE (European Railways and Infrastructure Employers) database for Spanish rail standards harmonised with EU requirements.
- Contact Iberian Rail Gauge project (if active) for 1,668 mm vs 1,435 mm compatibility documentation.

### 7. Moroccan High-Speed Rail Network Standards and Gauge Specifications

**ID:** e9eb4fdf-6428-4b35-ab84-c3360eb756c2

**Description:** Technical standards for Moroccan high-speed rail infrastructure: track gauge, signalling systems, traction power, train specifications and compatibility requirements for connection to the tunnel. Source: Moroccan Ministry of Equipment and Transport (Ministère de l'Équipement et du Transport) and ONCF (National Railways Company of Morocco, Société Nationale des Chemins de Fer du Maroc).

**Recency Requirement:** Current standards (as of 2026-10-12); recent updates essential as Morocco's high-speed rail network (Tangier–Kenitra) is relatively new (opened 2018).

**Responsible Role Type:** Railway Systems Integration and Operating Concept Lead

**Access Difficulty:** Medium to Hard. Moroccan rail standards may be less widely published than Spanish standards. ONCF and Ministry of Transport may restrict technical documentation to licensed parties. Public-domain portions accessible via ministry website (1–2 weeks). Full specifications may require formal request and confidentiality agreement (3–8 weeks). International lender reports (World Bank, AfDB) may contain project-specific technical data in public-disclosure platforms (1–2 weeks access).

**Steps:**

- Contact Moroccan Ministry of Equipment and Transport for official rail standards and specifications.
- Request ONCF technical department documentation on signalling, traction power and train specifications for the Tangier–Kenitra high-speed line.
- Access ONCF published technical reports and safety standards (partially public-domain).
- Search for Tangier–Kenitra project documentation (EPC contracts, design reports, international lender due-diligence reports) which may disclose technical standards.
- Contact Moroccan railway regulator (Agence Nationale de Régulation du Transport Terrestre) for standardization requirements.

### 8. EU Public-Procurement Law and Harmonised Procurement Framework Precedents

**ID:** 939a2262-2fd2-4d05-8b08-f011ab173654

**Description:** Current EU public-procurement directives (2014/24/EU on public procurement, 2014/25/EU on utilities procurement) and templates for harmonised cross-border procurement frameworks used in comparable binational infrastructure projects. Source material for drafting unified procurement rules acceptable to both Spain (EU member) and Morocco (non-EU third country).

**Recency Requirement:** Current EU directives and regulations (as of 2026-10-12); any recent amendments within last 2–3 years.

**Responsible Role Type:** Legal Counsel and Procurement Framework Lead

**Access Difficulty:** Easy. EU legal texts are freely available via EUR-Lex. EBRD and World Bank templates may require direct contact or registration (1–2 weeks). Fehmarnbelt and other project documentation may be proprietary or archived (2–4 weeks access via project authorities or lenders).

**Steps:**

- Access EUR-Lex (https://eur-lex.europa.eu) for EU public-procurement directives 2014/24/EU and 2014/25/EU.
- Request templates and guidance from European Commission (Directorate-General for Internal Market).
- Contact Fehmarnbelt (Denmark–Germany) and other binational infrastructure projects for copies of their harmonised procurement frameworks.
- Request guidance from OECD, World Bank or European Bank for Reconstruction and Development (EBRD) on cross-border procurement harmonisation.

### 9. Moroccan Administrative and Procurement Law

**ID:** 73446903-2b03-409a-bcb3-0dc2a0b17b6c

**Description:** Current Moroccan laws governing public procurement, infrastructure concessions and binational agreements. Source: Moroccan legislation on public-private partnerships (Dahir or statute-level law), Ministry of Equipment and Transport procurement regulations, and comparative legal analysis with EU procurement law to identify areas requiring harmonisation.

**Recency Requirement:** Current applicable laws (as of 2026-10-12); recent updates within last 5 years essential.

**Responsible Role Type:** Legal Counsel (Morocco jurisdiction specialist)

**Access Difficulty:** Medium to Hard. Moroccan procurement law is primarily in French and may not be widely available in English. Official government sources may have restricted online access. Legal translations and expert guidance may require engagement with Moroccan or international law firms (2–6 weeks for comprehensive analysis).

**Steps:**

- Contact Moroccan Ministry of Equipment and Transport and Ministry of Finance for official procurement and concession-law documentation.
- Access Moroccan government legal portal (portail de la justice or similar) for current Dahirs and decrees on procurement.
- Consult Moroccan law firms specialising in infrastructure and concessions (e.g., firms with EBRD or World Bank experience).
- Request comparative legal analysis from international law firms with Moroccan practice (e.g., Dentons, Clifford Chance regional offices).

### 10. International Maritime Organization (IMO) Shipping-Lane Regulations and Strait of Gibraltar Traffic Data

**ID:** ffcc19f2-f679-4c69-9cfa-f6ff4919a493

**Description:** Official IMO maritime-traffic routing recommendations and regulations for the Strait of Gibraltar, including vessel-traffic-service (VTS) procedures, routing schemes, traffic density and accident/incident data. Source material for defining no-anchoring exclusion corridors and estimating collision/anchor-damage risk.

**Recency Requirement:** Current IMO regulations (as of 2026-10-12); traffic data from last 5 years; incident statistics from last 10 years preferred.

**Responsible Role Type:** Shipping Interaction and Maritime Security Lead

**Access Difficulty:** Easy to Medium. IMO regulations and recommendations are publicly available via IMO website (1–2 weeks download). VTS and traffic data from Spanish and Moroccan maritime authorities may require formal request (2–4 weeks). Incident statistics from EU maritime agencies are partially public-domain (1–2 weeks).

**Steps:**

- Contact International Maritime Organization (IMO) directly for Strait of Gibraltar routing recommendations and traffic data.
- Access IMO's Maritime Safety Committee (MSC) and Maritime Pollution Prevention Committee (MEPC) resolutions and circulars on Strait traffic management (publicly available via IMO website https://www.imo.org).
- Request Spanish Ports Authority (Puertos del Estado) and Moroccan maritime authority for VTS data and traffic statistics in the Strait.
- Contact EU maritime authorities (EU Member State maritime safety coordination) for Strait incident reports and traffic monitoring data.

### 11. European Development Bank and Multilateral Lender Co-Financing Terms and Precedent Projects

**ID:** 4ed18c5c-1ebb-488d-9136-72a484fdbf2d

**Description:** Published financing frameworks and lending terms from European Investment Bank (EIB), World Bank, European Bank for Reconstruction and Development (EBRD), and Agence Française de Développement (AFD) for large cross-border infrastructure projects. Source: precedent projects (Fehmarnbelt, HZMB, Channel Tunnel), due-diligence requirements, governance and risk-management expectations, availability-payment structures, and contingency reserve standards.

**Recency Requirement:** Current lending policies (as of 2026-10-12); precedent project documents from last 10–15 years; any recent policy updates within last 2–3 years.

**Responsible Role Type:** Cost Control Authority Lead and Finance Ministries

**Access Difficulty:** Easy. Multilateral development banks publish lending policies, guidelines and precedent project documents via open-access portals. 1–2 weeks to assemble applicable documents.

**Steps:**

- Access EIB, World Bank, EBRD and AFD public websites for project disclosure, lending policies and guidance.
- Request public-disclosure documents from precedent projects: Fehmarnbelt (financed by EIB and national budgets), HZMB (World Bank and Asian Development Bank), Channel Tunnel (EIB and private financing).
- Contact multilateral development banks directly (EIB, World Bank) for financing-term templates and contingency-reserve guidance.
- Search for published case studies and evaluations of megaproject financing in development-bank libraries.

### 12. Precedent Binational Infrastructure Treaty Texts (Fehmarnbelt, Channel Tunnel, HZMB)

**ID:** 2a7a8e8b-1570-4631-919c-1661e39d845b

**Description:** Complete or redacted treaty texts, concession agreements and governance frameworks from comparable binational/multinational infrastructure projects. Source material for drafting the Spain–Morocco Strait tunnel treaty, particularly sections on legal personality, Board governance, decision authority, dispute resolution and withdrawal clauses.

**Recency Requirement:** Treaties and agreements from completed or operational projects (Fehmarnbelt 2008, Channel Tunnel 1987, HZMB ongoing); current versions with any amendments.

**Responsible Role Type:** Legal Counsel and Treaty Negotiator

**Access Difficulty:** Medium to Hard. Treaty texts vary in public availability: Fehmarnbelt text is largely public (via Danish/German sources, 1–2 weeks); Channel Tunnel treaty is public record (readily available, 1 week); HZMB texts may be restricted or in Chinese (3–6 weeks to obtain and translate). International law firms and development banks may hold redacted versions or executive summaries (2–4 weeks access).

**Steps:**

- Request Fehmarnbelt treaty and governance documents from Danish Ministry of Transport and German Federal Ministry of Transport.
- Request Channel Tunnel Treaty texts (Treaty of Canterbury 1987) and amended governance documents from UK and French transport ministries.
- Request HZMB treaty texts and governance frameworks from Chinese, Hong Kong and Macau governments (via HZMB Authority or development bank disclosure platforms).
- Search international law databases and treaty repositories (UN Treaty Collection, ICSID, etc.) for public or semi-public treaty texts.

### 13. Fehmarnbelt and HZMB Project Documentation (Governance, Cost Control, Risk Management)

**ID:** 43a83964-b491-4fca-bd1c-5f9a30f8f843

**Description:** Published or accessible project documents from the Fehmarnbelt immersed-tunnel and HZMB immersed-tunnel projects covering governance structures, Board decision-making, Design Change Control procedures, cost-management frameworks, contingency reserve allocation, schedule management and risk-register methodologies. Source material for designing comparable governance and operational procedures for the Strait tunnel.

**Recency Requirement:** Project documents from active construction or recent completion (Fehmarnbelt ongoing ~2024+, HZMB completed 2018); most recent updates preferred.

**Responsible Role Type:** Binational Programme Director and Governance Architect

**Access Difficulty:** Medium. Fehmarnbelt is a publicly funded project with significant public disclosure; project reports and governance documents accessible via Femern A/S website and Danish/German government portals (1–2 weeks). HZMB project documents are partially available via development bank disclosure platforms (World Bank, ADB) and HZMB Authority (2–4 weeks); some documents may be restricted or in Chinese (4–8 weeks with translation). International firms may have archived project documentation but with confidentiality restrictions (2–6 weeks negotiation).

**Steps:**

- Request Fehmarnbelt project documents from Femern A/S (state-owned project company) website and annual reports.
- Contact Fehmarnbelt project authority (Danish/German) for governance documentation and case-study materials.
- Request HZMB project documentation from HZMB Authority (China, Hong Kong, Macau joint authority) and development bank disclosure platforms (World Bank, ADB).
- Search academic publications and conference proceedings for Fehmarnbelt and HZMB governance case studies.
- Contact international engineering and programme management firms (Arup, Bechtel, COWI) that managed these projects for archived governance documentation.

### 14. Historical Cost Growth and Schedule Overrun Data from Comparable Megaprojects

**ID:** 63ebaada-7f12-4540-9a51-1a2cc4510a19

**Description:** Documented cost and schedule performance from precedent megaprojects (Fehmarnbelt, HZMB, Channel Tunnel, Gotthard, Hindås, Hallandsås, Crossrail, major immersed tubes and floating structures) showing baseline-to-completion cost growth percentages and schedule slippage. Source material for validating cost-overrun exposure (plausible 25–45% overrun) and informing contingency-reserve adequacy analysis.

**Recency Requirement:** Cost and schedule data from projects completed within last 20 years; most recent large megaprojects (2010 onwards) preferred for relevance.

**Responsible Role Type:** Cost Control Authority Lead

**Access Difficulty:** Easy to Medium. Published final reports from major completed projects are increasingly open-access (1–2 weeks download). Academic literature is accessible via institutional subscriptions or interlibrary loan (1–2 weeks). Bent Flyvbjerg's dataset is publicly available (https://www.megaproject.ox.ac.uk, immediate access). Development bank final audits and evaluations may require formal access requests (2–4 weeks).

**Steps:**

- Access published project evaluations and final audit reports from comparable infrastructure projects (via project authorities, development banks, EU institutions).
- Search academic literature (International Journal of Project Management, Project Management Journal) for megaproject cost-overrun case studies.
- Request final project reports from Fehmarnbelt, HZMB, Gotthard, Crossrail and other European megaprojects via government transparency portals or freedom-of-information requests.
- Contact International Project Management Association (IPMA) and Project Management Institute (PMI) for historical cost-growth databases and case-study archives.
- Consult industry benchmarking databases (e.g., Bent Flyvbjerg's Megaproject Cost Overrun dataset at University of Oxford).

### 15. Insurance Precedent: First-of-Kind Structure Marine Risk Pricing and Insurable Limits

**ID:** 43ae41cd-ce90-490a-9f3d-74bc2559d1b0

**Description:** Published or accessible information from insurance underwriters and risk-assessment firms on pricing first-of-kind marine structures (immersed tunnels, floating platforms, deep-water anchored systems), fatigue risk, sabotage and political-risk insurance. Source material for validating that insurance coverage exists and is available at acceptable terms, and for understanding insurers' contingency-reserve and risk-management expectations.

**Recency Requirement:** Current insurance-market guidance and precedent cases (last 5–10 years); recent pricing information from active projects (Fehmarnbelt, offshore wind) essential.

**Responsible Role Type:** Insurance, Lender Due Diligence and Risk Quantification Specialist

**Access Difficulty:** Hard. Insurance underwriting is proprietary and confidential; precedent project insurance documentation is typically confidential between lenders, project sponsors and insurers. Specific pricing and coverage information may not be publicly available. General guidance on megaproject insurance and first-of-kind risk assessment is available through insurance brokers and industry associations (2–6 weeks consultation). Classification society risk-assessment guidance is semi-public (1–2 weeks access).

**Steps:**

- Contact major marine insurance brokers and underwriters (e.g., Lloyds, AIG, Allianz, Munich Re) with experience in infrastructure megaprojects.
- Request 'Insurance Placement Strategy' or 'Insurability Risk Assessment' documentation from comparable megaprojects (Fehmarnbelt, HZMB, comparable deep-water structures).
- Access published insurance industry reports (International Association of Insurance Supervisors, Geneva Association) on megaproject and first-of-kind risk pricing.
- Contact classification societies (DNV, ABS, LR) for guidance on structural risk assessment and insurance implications.

### 16. Recent Demand Forecasting Studies for Cross-Border Rail and Bridge/Tunnel Infrastructure

**ID:** b81db42c-2cf0-4fc6-bc7f-392549742e7d

**Description:** Independent transport-modelling studies and demand forecasts for comparable cross-border rail links, tunnels or bridges (e.g., Gotthard Base Tunnel, Fehmarnbelt, Øresund Bridge, recent EU cross-border rail projects). Source material for benchmarking passenger-demand assumptions (4.0 million passengers/year planning case) and validating Debt Service Coverage Ratio assumptions.

**Recency Requirement:** Demand studies from projects opened within last 20 years; pre-opening forecasts and actual opening-year and Year 5+ performance data preferred.

**Responsible Role Type:** Railway Systems Integration and Demand Forecasting Lead

**Access Difficulty:** Easy to Medium. Published operational reports from major open projects are readily accessible (1–2 weeks). Academic case studies are available via academic databases (1–2 weeks). Pre-opening forecasts and demand-methodology documentation from development-bank projects are accessible via public-disclosure portals (1–2 weeks). Proprietary demand-modelling tools and detailed traffic forecasts may have restricted access (2–4 weeks negotiation with project authorities).

**Steps:**

- Request published or non-confidential demand studies from comparable project authorities (Gotthard, Fehmarnbelt, Øresund Bridge, etc.).
- Access published operational reports and traffic-data reviews from opened projects (e.g., Gotthard annual reports, Øresund Bridge traffic statistics).
- Search for academic papers and case studies on cross-border rail demand (Transport Research Board, European Commission).
- Contact transport-modelling firms (Steer Davies Gleave, Arup, IVT Institute for Transport Planning) for precedent study methodologies and findings.
- Request final evaluation reports from development banks (EIB, World Bank, EBRD) for financed projects, which typically include demand-forecast vs. actual comparisons.

### 17. Existing SECEGSA and SNED Study Archives and Feasibility Reports

**ID:** 58032e88-0a20-4022-9c20-a771faeb2b9d

**Description:** Historical reports, studies and technical analyses from Spain's SECEGSA (Sociedad Española de Estudios para la Comunicación Fija a través del Estrecho de Gibraltar) and Morocco's SNED (Société Nationale d'Études et de Développement) covering Strait crossing alternatives, geological surveys, bathymetry, feasibility assessments, and bored vs. immersed-tube vs. bridge concepts. These entities have conducted studies since the late 1970s. Source material for seabed data, baseline assumptions, and precedent engineering analysis.

**Recency Requirement:** Most recent SECEGSA/SNED reports preferred (within last 10–15 years); earlier studies acceptable for historical context and geological baseline.

**Responsible Role Type:** Chief Technical Officer and Seabed Investigation Programme Manager

**Access Difficulty:** Medium to Hard. SECEGSA and SNED archives may be dispersed across government agencies or project offices and may be incomplete. Some older studies (1980s–1990s) may only exist in paper form or have restricted access. Recent reports (2010+) may be more readily available via government transparency portals. Direct contact with the study organizations and ministries required; expect 3–8 week turnaround for document retrieval and access.

**Steps:**

- Contact Spanish Ministry of Transport and SECEGSA office (if still active) for archived study reports and technical documentation.
- Contact Moroccan Ministry of Equipment and Transport and SNED office for feasibility studies and geological surveys.
- Request digitized copies of reports from both entities; clarify document-access procedures and any confidentiality restrictions.
- Search government archives or library repositories (e.g., Spanish Biblioteca del Congreso) for published SECEGSA/SNED feasibility studies.
- Contact international consulting firms (if they were involved in SECEGSA/SNED studies) for archival documentation.

### 18. Spanish and Moroccan Budget and Parliamentary Records: Transport Infrastructure Spending and Political Priorities

**ID:** 0ed6e118-7241-4c4e-8003-0a2d13783d04

**Description:** Official government budget documents, parliamentary records and spending statements showing historical transport-infrastructure investment priorities and budget allocations in Spain and Morocco, particularly for rail, port and cross-border connectivity projects. Source material for assessing political and fiscal commitment to the Strait tunnel, likelihood of sustained funding across multiple government administrations, and competing budget priorities that might strain availability payments.

**Recency Requirement:** Current and recent (last 5 years) budget documents; parliamentary records from last 5–10 years showing transport priorities and debate.

**Responsible Role Type:** Finance Ministries and Political Risk Manager

**Access Difficulty:** Easy to Medium. Official budget documents are publicly available via government portals (1–2 weeks access). Parliamentary records are publicly available through legislative websites (1–2 weeks). Fiscal-impact analysis and trend data may require compilation from multiple sources (2–4 weeks research).

**Steps:**

- Access Spanish government budget portal (Portal de Presupuestos, Ministerio de Hacienda) for annual budget documents and transport-sector allocations.
- Access Moroccan government budget portal (Budget Ministry) for parallel Moroccan budget data.
- Search Spanish parliamentary records (Congreso de los Diputados) for transport-policy debates and funding decisions.
- Search Moroccan parliamentary records (House of Councillors) for transport priorities and budget discussions.
- Request comparative fiscal analysis from economic research institutions (e.g., Spanish Instituto de Estudios Fiscales, Moroccan Economic Observatory).

### 19. Recent Economic and Trade Data: Spain–Morocco Cross-Border Commerce and Logistics

**ID:** b9ac767b-e29a-40b7-90b4-eb23cb1fb7b9

**Description:** Statistical data on trade flows, freight volumes, and logistics activity between Spain and Morocco: rail and road cargo tonnage, port-hinterland traffic, truck traffic across the Strait (via ferries), and sectoral profiles (agricultural exports from Morocco, manufacturing imports to Spain, automotive, chemicals). Source material for validating freight-demand assumptions for the tunnel and assessing potential for vehicle-shuttle or rail-freight services.

**Recency Requirement:** Most recent annual data (last 2–3 years); historical data from last 10 years for trend analysis.

**Responsible Role Type:** Railway Systems Integration and Demand Forecasting Lead

**Access Difficulty:** Easy. Statistical data from national statistical offices and the UN Comtrade database are publicly available (1–2 weeks download). Port-authority data is accessible via government websites or formal data requests (1–2 weeks). Trade data from official sources are standardized and readily obtainable.

**Steps:**

- Contact Spanish Statistical Office (INE, Instituto Nacional de Estadística) for trade and logistics data.
- Contact Moroccan Statistical Office (HCP, Haut-Commissariat au Plan) for trade and freight statistics.
- Request data from Spanish Port Authority (Puertos del Estado) on Spain–Morocco trade volumes and port traffic.
- Contact Moroccan Ministry of Equipment and Transport for freight and logistics statistics.
- Search UN Comtrade database (https://comtrade.un.org) for bilateral trade data between Spain and Morocco.
- Access EU Eurostat (for Spain) for detailed trade and transport statistics.

### 20. Climate Change and Sea-Level Rise Projections for the Mediterranean and Strait Region

**ID:** df49b1f1-405f-421d-8fb8-ed5ef7644ddd

**Description:** Climate-scenario data from IPCC (Intergovernmental Panel on Climate Change) and European climate-research institutions covering sea-level rise, storm-surge intensity, ocean-temperature trends and salinity changes projected for the Strait region over the 50–100 year service life of the tunnel. Source material for long-term durability planning (concrete degradation, corrosion risk, tether performance in warming oceans), flood-risk assessment, and insurance/financing implications of climate change.

**Recency Requirement:** IPCC AR6 (6th Assessment Report, 2021+) and recent regional climate models (last 5 years); projections to 2100 minimum.

**Responsible Role Type:** Long-Term Operations and Sustainability Lead

**Access Difficulty:** Easy. IPCC reports and Copernicus data are freely available online (1–2 weeks download and review). Mediterranean regional climate studies are published in peer-reviewed journals and via research institutions (1–2 weeks search and access).

**Steps:**

- Access IPCC AR6 reports directly via https://www.ipcc.ch; download Mediterranean and Western Mediterranean regional projections.
- Contact European Centre for Medium-Range Weather Forecasts (ECMWF) Copernicus Climate Change Service for regional sea-level-rise and storm projections.
- Access Mediterranean climate-research institutions (e.g., University of Barcelona, IMEDEA Mediterranean Institute) for detailed regional models.
- Contact insurance industry (e.g., Munich Re, Swiss Re) for climate-change risk assessments relevant to long-duration marine infrastructure.

### 21. Railway Operating Statistics: Spanish and Moroccan High-Speed Rail Networks (Demand, Revenue, Cost Performance)

**ID:** 7f2c84c2-098b-48fc-b029-601bafc6a9de

**Description:** Published operating data from Renfe (Spanish state railways) and ONCF (Moroccan railways) for high-speed services, including passenger volumes, revenue, operating costs, utilisation rates and any published financial performance or deficit/subsidy data. Source material for validating demand forecasts for the Strait tunnel and understanding whether rail operations require public subsidy (informing feasibility of private financing).

**Recency Requirement:** Most recent annual operating reports (last 3 years); historical data from last 10 years for trend analysis.

**Responsible Role Type:** Railway Systems Integration and Demand Forecasting Lead

**Access Difficulty:** Easy to Medium. Renfe and ONCF annual reports are typically public (1–2 weeks access via company websites). EU Eurostat data is publicly available (immediate access). Private rail-industry research may require subscription or purchase (2–4 weeks).

**Steps:**

- Request Renfe annual reports and financial statements (publicly available via company website or Spanish stock-exchange filings if Renfe is partially listed).
- Request ONCF annual reports and financial statements from ONCF or Moroccan Ministry of Transport.
- Access EU transport statistics databases (Eurostat) for Spanish rail-network operating data.
- Search for ONCF and Renfe investor presentations or quarterly earnings reports (if available).
- Contact rail-industry analysts and research firms (e.g., Steer Davies Gleave, Arup) for comparative rail-network performance data.