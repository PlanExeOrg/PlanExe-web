This plan involves money.

## Currencies

- **EUR:** Primary currency for the €40 billion budget envelope and consolidated reporting across Spain and Morocco. Both countries operate within the eurozone or linked economies. EUR is specified in the project constraint and is the standard for EU-level infrastructure financing and multinational project reporting.
- **USD:** Secondary currency for international finance structuring, multilateral lender reporting (World Bank, EBRD, IFC), private equity and debt participation, and currency-risk hedging. Major equipment procurements and international contractors often price in USD.
- **MAD:** Moroccan dirham for local labour, materials and subcontractor costs in Morocco. Required for budgeting paired casting yards, landfall works and domestic supply chain on the Moroccan coast and feeder rail integration.

**Primary currency:** EUR

**Currency strategy:** EUR is the primary consolidation currency for the €40 billion envelope, all master-level budgeting and treaty-level reporting. Local costs in Spain (EUR) and Morocco (MAD) are tracked separately to manage domestic procurement and labour, then converted to EUR monthly at agreed exchange rates to avoid bid price volatility. USD serves as the secondary currency for multilateral lender reporting and international contractor pricing; a currency-hedging policy should be agreed with lenders and private participants to cap exposure to EUR/USD and EUR/MAD fluctuations beyond agreed quarterly resets. Tranches released by the binational delivery vehicle are denominated in EUR, but private equity and debt may require USD or EUR tranches with periodic rebalancing. The Funding Architecture lever must confirm hedge instruments and reset frequency to manage cost certainty within the 20-year horizon.