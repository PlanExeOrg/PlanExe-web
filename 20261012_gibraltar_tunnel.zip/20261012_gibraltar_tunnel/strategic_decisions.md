## Primary Decisions
The vital few decisions that have the most impact.


The Critical levers (support concept, stage-gate proving, treaty vehicle, funding architecture) address the project's central tensions: structural ambition versus proof of feasibility, speed versus the 20-year horizon, and sovereign autonomy versus unified authority and bankable risk allocation. The High levers (certification, seabed investigation, ecological permitting, fabrication, rail concept) govern evidence and schedule. No dedicated lever covers cost-control, workforce or supply-chain capacity, and long-term operations and maintenance.

### Decision 1: Pillar, Tether and Pontoon Support Concept
**Lever ID:** `bec517cc-9c6f-47be-9055-fbeca5ae6acf`

**The Core Decision:** Defines the load path and structural form of the tube across the Strait: founded pillars, tension tethers, pontoons or a hybrid. Scope covers hydrodynamic and seismic response, fatigue life of anchors, corrosion protection and installation method. Success metrics are a qualified dynamic response under design-basis wave, current and earthquake loads, bounded tether lengths, and a credible cost per kilometre before seabed works begin.

**Why It Matters:** The plan combines 'pillar-supported' with 'buoyant and anchored' at 100 m, but published sources put Strait depths at several hundred metres and up to about 900 m. The support concept determines whether the tube is held by seabed pillars, long tension tethers, surface pontoons, or a mix, and so sets the cost, seismic response and installation method for every other work package. No submerged floating tunnel has been built anywhere, so each choice extends beyond precedent.

**Strategic Choices:**

1. Adopt tension-leg tethers anchored to the seabed along the whole alignment, accepting very long tether lengths in the deepest sections and relying on dynamic-response testing to qualify them.
2. Adopt a hybrid concept that uses founded pillars on shallow shelves and sills, and tether groups or buoyancy modules across deeper channels where pillars become impractical.
3. Adopt a bored or immersed-tube fallback for the deepest central section, and reserve the buoyant concept for shallow approach reaches where a floating tube can be proven first.

**Trade-Off / Risk:** Pillar-supported and tethered concepts are physically different structures; leaving the choice open until late design hides the largest cost and feasibility uncertainty, and a wrong early commitment cannot be reversed once seabed works begin.

**Strategic Connections:**

**Synergy:** Amplifies the Seabed Investigation and Geohazard Characterisation Campaign, whose data fixes where pillars or anchors can be founded, and sets element length, ballast and joint demands that drive Segment Fabrication and Immersion Logistics.

**Conflict:** Early commitment conflicts with Technology Proving and Stage-Gate Sequence, which wants the concept kept open until evidence exists, and tether-heavy options inflate cost uncertainty that strains Funding Architecture and Risk Allocation.

**Justification:** *Critical*, Central structural hub: sets load path, cost, seismic response and installation method for every work package. Links to seabed data, fabrication, egress mass, shipping hardening and funding. Controls the largest feasibility and cost uncertainty, and is irreversible once seabed works begin.

### Decision 2: Technology Proving and Stage-Gate Sequence
**Lever ID:** `f62ff8af-6245-46b0-8058-4dc21a8bed9c`

**The Core Decision:** Sets the evidence thresholds, decision gates and spending release points that stand between concept and full construction. Scope includes scaled prototype and pilot segments, exit criteria, independent assessor authority and the share of budget spent before commitment. Success metrics are gate criteria agreed in advance, no irreversible seabed works before sign-off, and a proving phase that fits within the 20-year horizon.

**Why It Matters:** Because the concept has no built full-scale precedent, the programme must decide how much proof is gathered before the bulk of the budget is committed. A long validation phase delays rail service and uncertain-benefit spending, while a fast start risks locking in a design that fails at scale. The sequence also determines when the project can credibly be presented to lenders and treaty partners.

**Strategic Choices:**

1. Commit to a gated programme that funds seabed investigation, a scaled prototype segment and a full-scale pilot in sheltered waters, releasing main construction funds only after independent assessment.
2. Run the design for the full crossing in parallel with an exploratory gallery or survey tunnel, so that geotechnical data and a possible service bore benefit either tunnel concept.
3. Procure the whole crossing as a single design-build package with performance guarantees, shifting technology risk to a contractor consortium at a substantial risk premium.

**Trade-Off / Risk:** Staging proof protects the budget but extends the timeline against a fixed 20-year horizon, while a single-package approach assumes contractors will underwrite risk that no market participant has priced before.

**Strategic Connections:**

**Synergy:** Gate criteria feed directly into Design Basis and Independent Certification Regime, and milestone evidence unlocks tranches under Funding Architecture and Risk Allocation, giving lenders and treaty partners a credible basis for staged commitment.

**Conflict:** Extended proving delays rail service and the Ridership Ramp and Landside Network Integration Programme, and holds back casting-yard investment in Segment Fabrication and Immersion Logistics, squeezing the fixed 20-year schedule.

**Justification:** *Critical*, Governs the core speed-versus-proof trade-off for a no-precedent concept within a fixed 20-year horizon. Gates feed certification and funding tranches, while delays hit ridership, fabrication investment and schedule. Determines when lenders and treaty partners can credibly commit.

### Decision 3: Binational Treaty and Delivery Vehicle
**Lever ID:** `d56f1145-3d87-441c-a4c3-5167a491de9d`

**The Core Decision:** Establishes the legal basis, owner entity and decision rules for a project that straddles two states and a maritime boundary. Scope covers legal personality, procurement authority, safety regulation, tolling, dispute resolution and handling of the existing SECEGSA and SNED legacy. Success metrics are treaty ratification speed, clarity of design-change approval authority, and acceptability to insurers and lenders.

**Why It Matters:** Spain, Morocco and the maritime boundary under the Strait require a treaty-based legal basis, an owner entity and a decision rule for disputes, safety regulation and tolling. The chosen vehicle controls who can approve design changes and how quickly, and it shapes which investors and insurers will participate. A weak or ambiguous governance structure can stall a 20-year programme more reliably than any engineering problem.

**Strategic Choices:**

1. Create a treaty-backed binational authority with its own legal personality, procurement powers and technical regulator, building on the existing SECEGSA and SNED study companies.
2. Grant a long-term concession to a private-public joint venture under each state's law, with a coordinating commission to harmonise standards and resolve boundary issues.
3. Run two national delivery agencies that each build the section in their own waters to a shared technical code, joined at a defined interface point in mid-Strait.

**Trade-Off / Risk:** A single authority speeds decisions but demands sovereignty concessions that either government may resist, whereas parallel national agencies preserve autonomy at the expense of interface risk at the exact point where the two halves must meet.

**Strategic Connections:**

**Synergy:** Gives Funding Architecture and Risk Allocation an entity able to borrow, contract and hold guarantees, and provides the regulatory standing needed by Design Basis and Independent Certification Regime to bind both countries.

**Conflict:** Sovereignty concessions required for a single authority clash with national control over waters in Shipping Interaction and Maritime Security Perimeter, and parallel national agencies would multiply interface risk for Segment Fabrication and Immersion Logistics.

**Justification:** *Critical*, Foundational governance pillar: provides the counterparty that can borrow, contract and regulate. Connects funding, certification, fabrication, shipping and ecological permitting. Sovereignty and decision-rule choices can stall the programme more reliably than engineering problems.

### Decision 4: Funding Architecture and Risk Allocation
**Lever ID:** `5b1f30d7-d409-4a1d-95f5-9fde37c87a83`

**The Core Decision:** Allocates the €40 billion envelope across the two states, EU and multilateral lenders and private capital, and assigns who bears overrun and demand risk. Scope includes contingency reserves, guarantees, availability payments and tranche release rules. Success metrics are a funded plan without open-ended sovereign guarantees, contingency sized to first-of-kind uncertainty, and lender appetite at each stage.

**Why It Matters:** The €40 billion envelope and 20-year horizon require a split between the two states, EU and multilateral lenders, and private capital, along with a view on who carries cost overrun and demand risk. Megaprojects of this kind commonly exceed initial estimates, and a first-of-kind concept compounds that exposure. The structure chosen will decide whether the project can proceed at all without open-ended sovereign guarantees.

**Strategic Choices:**

1. Fund primarily through state budgets and multilateral development lending, with explicit contingency reserves and sovereign backing, and treat rail fares as a partial offset to cost.
2. Structure availability-payment concessions with private equity and debt for the rail systems and operations, keeping civil works on public balance sheets to limit private exposure to construction risk.
3. Release capital in tranches linked to technical milestones, with the opening tranche limited to investigation and pilot work, so that later commitments depend on demonstrated feasibility.

**Trade-Off / Risk:** Private participation only works if someone can price first-of-kind construction risk; without a credible overrun backstop, the financing structure may shift cost to taxpayers while appearing to share it.

**Strategic Connections:**

**Synergy:** Tranched release works hand in hand with Technology Proving and Stage-Gate Sequence, tying money to demonstrated feasibility, and relies on the Binational Treaty and Delivery Vehicle to provide a creditworthy counterparty.

**Conflict:** Fixed budget ceilings clash with the cost uncertainty of the Pillar, Tether and Pontoon Support Concept, and dependence on fare revenue is exposed to the pace of the Ridership Ramp and Landside Network Integration Programme.

**Justification:** *Critical*, Decides whether the €40 billion first-of-kind project can proceed without open-ended sovereign guarantees. Hub linking tranche release to stage gates, the treaty vehicle, support-concept cost uncertainty, safety capital cost and ridership revenue. Controls the cost-versus-risk trade-off.

### Decision 5: Segment Fabrication and Immersion Logistics
**Lever ID:** `8a04b318-95ea-4e91-a169-20994a0d5947`

**The Core Decision:** Governs how large concrete tube segments are cast, outfitted, floated, towed, joined and immersed in strong currents. Scope includes yard siting, joint design, weather-window planning and quality control across a multi-year production campaign. Success metrics are segment output rate, joint watertightness and dimensional tolerance, immersion success rate per weather window, and consistent quality across any multiple yards.

**Why It Matters:** Concrete tube segments of large size must be cast, floated, towed and joined in strong currents and a very busy shipping lane. The choice of casting yards, joint type and installation weather windows determines production rate and quality control across a multi-year campaign. Siting yards on both coasts spreads industrial benefits between the two countries but duplicates plant, equipment and skills.

**Strategic Choices:**

1. Build one large purpose-built casting basin and outfitting yard on a single coast, and tow finished segments to the crossing to maximise repetition and quality control.
2. Establish paired casting yards on the Spanish and Moroccan coasts, each supplying its own half, with common specifications and shared supervision to balance industrial and employment benefits.
3. Produce shorter modular elements in existing shipyards and industrial ports across the region and assemble them in sheltered water into long strings before immersion.

**Trade-Off / Risk:** Dual yards deliver political balance and shorter tow distances, but divide scarce expertise and can produce two slightly different quality cultures, which becomes a durability and watertightness risk at the joints.

**Strategic Connections:**

**Synergy:** Production design is shaped by the Pillar, Tether and Pontoon Support Concept, and its tow-out and landing methods must match the Landfall Portal and Deep Transition Interface Concept, so early joint planning cuts rework at interfaces.

**Conflict:** Towing and immersion operations compete with traffic in Shipping Interaction and Maritime Security Perimeter, and paired yards require harmonised supervision under the Binational Treaty and Delivery Vehicle, while duplicating plant cost.

**Justification:** *High*, Execution-phase driver of production rate, joint quality and schedule. Interfaces with support concept, landfalls, shipping traffic and binational supervision, and sets industrial balance between countries. Important, but largely downstream of concept and governance choices.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Rail Gauge, Signalling and Operating Concept
**Lever ID:** `a3067f81-5532-41ff-991d-64f82191794f`

**The Core Decision:** Defines the operating DNA of the link: track gauge, signalling and train-control standard, traction power, train types and service pattern. Success is measured by through-running share of passengers and freight, journey time, achievable headway, and avoided transfer friction. Because it sets tube cross-section, ventilation load and rolling-stock envelope, it must be frozen early enough to avoid redesigning a tethered structure with tight buoyancy margins.

**Why It Matters:** Fixing the track gauge, signalling standard, traction power system and service pattern early determines tube cross-section, ventilation load and the rolling stock that can use the link. A concept that suits only one network's standards forces transfer or conversion at a coast, which lowers the connectivity benefit. A more flexible concept raises systems-integration cost and certification effort on both sides.

**Strategic Choices:**

1. Adopt the standard European high-speed gauge and signalling suite throughout, and place any gauge-change or interface facilities on land at the Iberian approach rather than inside the tunnel.
2. Specify a dual-standard tunnel with variable-gauge or dual-certified rolling stock so that trains from both national networks run through without transfer, accepting higher vehicle and approval costs.
3. Operate the crossing as a closed shuttle system with dedicated trains and terminal stations at each coast, decoupling tunnel design from both national networks and enabling a smaller, optimised tube.

**Trade-Off / Risk:** A shuttle concept simplifies the tube design but pushes interchange friction onto passengers and freight, while through-running maximises network value only if two national regulators agree on a single certification regime.

**Strategic Connections:**

**Synergy:** Amplifies Ridership Ramp and Landside Network Integration Programme, since a through-running concept lets both national networks feed the tunnel directly. Also enables a leaner Landfall Portal and Deep Transition Interface Concept when gauge-change facilities sit on land.

**Conflict:** Trades off against Emergency Egress and Incident Response Regime, because larger or dual-standard cross-sections and heavier trains add mass, ventilation load and refuge demands. Dual certification also strains Binational Treaty and Delivery Vehicle by requiring two regulators to align.

**Justification:** *High*, Fixes tube cross-section, ventilation load and rolling-stock envelope, and determines through-running connectivity value. Trades off against egress mass and requires regulator alignment under the treaty. Strongly shapes ridership and landfall design, but is less pivotal than the structural, governance and funding hubs.

### Decision 7: Emergency Egress and Incident Response Regime
**Lever ID:** `77590149-5176-4655-bfce-19612cddfac5`

**The Core Decision:** Sets how passengers survive and are rescued from a train inside a tube at about 100 m depth, where land-tunnel evacuation logic does not apply. It covers refuge provisions, cross-passage spacing, ventilation and smoke control, rescue asset basing and cross-border command authority. Key metrics are time to reach safety, self-rescue endurance, and regulator acceptance of the safety case, which also gates insurability and operating licences.

**Why It Matters:** A tube anchored about 100 m below the surface cannot rely on conventional land-tunnel evacuation, so the egress concept shapes cross-section, cross-passage spacing, refuge provisions and ventilation. It also drives who must be on call and where rescue assets are based. A stricter regime adds structural and equipment mass to tethered, buoyancy-sensitive tubes, which feeds back into the support design.

**Strategic Choices:**

1. Design each tube as a self-rescue system with a separate service and escape bore, frequent cross-passages and pressurised refuge zones, so passengers can survive without external help for a defined period.
2. Provide vertical evacuation shafts from the tube to surface-piercing platforms or pillar-mounted stations at intervals, so that rescue craft can reach trains directly from the water.
3. Rely on train-based safety, with fire-resistant rolling stock designed to continue running to the nearest coast, and keep the infrastructure lean with minimal in-tube refuge provisions.

**Trade-Off / Risk:** Train-based safety reduces tube cost but depends on rolling stock behaving as designed during a fire or flooding event, while full self-rescue provisions add mass and complexity to a structure whose buoyancy margin is tightly managed.

**Strategic Connections:**

**Synergy:** Reinforces Design Basis and Independent Certification Regime, because a defined egress concept provides the safety case that certifiers need. Works with Rail Gauge, Signalling and Operating Concept, where train-based safety features can reduce in-tube infrastructure.

**Conflict:** Conflicts with Pillar, Tether and Pontoon Support Concept, since extra escape bores, refuges and equipment add mass to a buoyancy-sensitive structure. Also competes with Funding Architecture and Risk Allocation, as fuller self-rescue provisions raise capital cost.

**Justification:** *Medium*, Safety concept gating insurability and operating licences; adds mass to buoyancy-sensitive tubes and capital cost. Meaningful interactions with support concept and certification, but it acts mainly as a constraint within the structural and certification levers rather than a primary driver.

### Decision 8: Shipping Interaction and Maritime Security Perimeter
**Lever ID:** `e28e33c3-c5d5-4598-ae05-9d7b7c6c22e2`

**The Core Decision:** Determines how the tunnel is protected from anchors, sinking vessels, dropped cargo and deliberate attack in one of the world's busiest straits. It spans routing rules, exclusion corridors, surveillance, passive hardening and military oversight. Success is measured by reduced incident likelihood, compliance by multi-flag traffic, insurer acceptance and minimal disruption to commercial shipping, with approvals needed from maritime authorities beyond the two treaty partners.

**Why It Matters:** The Strait carries dense merchant, ferry and naval traffic, so anchors, sinking vessels, dropped cargo and deliberate attack become design cases for a tube at 100 m depth. The protection concept determines routing rules, exclusion zones, surveillance and insurance terms. Stronger controls reduce the likelihood of a damaging event but constrain shipping and require agreement from maritime authorities beyond the two treaty partners.

**Strategic Choices:**

1. Establish a no-anchoring corridor along the alignment, enforced through vessel traffic service amendments, with sonar and radar monitoring that detects vessels dragging anchors or sinking near the tunnel.
2. Harden the tubes and tethers passively with protective sacrificial covers and robust design margins for sinking-ship impact, avoiding operating restrictions on commercial traffic.
3. Integrate the tunnel into a joint naval and coast-guard security system, with permanent seabed sensor arrays and rapid-response vessels, treating the link as critical infrastructure under shared military oversight.

**Trade-Off / Risk:** Operational exclusion zones are cheap to build but depend on enforcement against vessels from many flag states, whereas passive hardening works without compliance yet adds mass and cost to every metre of tube.

**Strategic Connections:**

**Synergy:** Complements Design Basis and Independent Certification Regime, because defined impact and sabotage design cases can be codified and certified. Sensor arrays also support Seabed Investigation and Geohazard Characterisation Campaign by supplying long-term monitoring data.

**Conflict:** Trades off against Pillar, Tether and Pontoon Support Concept when passive hardening adds weight to tubes and tethers. Strict exclusion zones also constrain shipping flows and need consent beyond Binational Treaty and Delivery Vehicle.

**Justification:** *Medium*, Defines impact and sabotage design cases and exclusion-zone approach in a busy strait, trading operational restrictions against hardening mass. Needs consent beyond the treaty partners. Important for insurer acceptance, but more of a design-case input than a project-wide hub.

### Decision 9: Ecological Permitting and Habitat Mitigation Pathway
**Lever ID:** `8f1875f5-37f6-4da4-96d5-223a4599c909`

**The Core Decision:** Structures how baseline surveys, impact assessment, mitigation and consultation are organised across Spanish, Moroccan and EU-linked regimes for a migration route with protected-area settings. It is often the critical path, since consents must be legally durable against challenge. Key metrics are time to first consent, consent robustness against injunctions, and the share of mitigation commitments that are binding and monitorable.

**Why It Matters:** The Strait is a migration route and a marine protected area setting, so permitting under Spanish, Moroccan and EU-linked rules can set the critical path before any structure goes in the water. The way baseline studies, mitigation and consultation are organised affects approval timing and the legal durability of consents. Early, conservative commitments can slow construction starts but reduce the risk of later injunctions or stop-work orders.

**Strategic Choices:**

1. Commission a joint, multi-year baseline ecological programme before final design, and set construction methods and timing windows around its findings to secure a single harmonised consent.
2. Pursue separate national environmental consents in parallel, with a binational coordination committee reconciling conditions, to start works on each coast without waiting for the slower regime.
3. Treat the project as an ecological enhancement scheme by funding artificial reef structures on pillars and tethers, long-term marine research and transport modal-shift credits as part of the consent package.

**Trade-Off / Risk:** Parallel national consents save time on paper but risk conflicting conditions mid-construction, while a joint baseline study is more defensible yet may delay the first physical work by several years.

**Strategic Connections:**

**Synergy:** Enables Technology Proving and Stage-Gate Sequence by supplying gate-ready environmental evidence, and shares survey vessel time and data with Seabed Investigation and Geohazard Characterisation Campaign, reducing duplicate offshore effort.

**Conflict:** Conflicts with the schedule goals of Segment Fabrication and Immersion Logistics, because seasonal timing windows and a multi-year baseline can delay installation. Also pulls against Binational Treaty and Delivery Vehicle if parallel national consents diverge.

**Justification:** *High*, Often the critical path before any structure enters the water. Controls the schedule-versus-legal-durability trade-off across three regulatory regimes, enables gate evidence, and conflicts with fabrication timing and treaty harmonisation. Failure risks injunctions and stop-work orders.

### Decision 10: Seabed Investigation and Geohazard Characterisation Campaign
**Lever ID:** `c1f7ae9a-28e5-4b0c-ad20-1859dc7a1ecf`

**The Core Decision:** Controls how much seabed, fault-zone, sediment-stability and current data is acquired before foundations and anchors are fixed in a deep, tectonically active strait. It shapes cost certainty, contractor claims exposure and the credibility of the design basis. Success is measured by reduction in residual ground uncertainty per euro and month spent, and by the absence of late foundation redesign.

**Why It Matters:** Determines how much of the Strait's seabed, fault-zone and sediment-stability data is acquired before the pillar, tether and anchor design is frozen. A deeper early campaign narrows design uncertainty and reduces later foundation redesign, but it consumes schedule and vessel time before any visible construction progress. A thinner campaign accelerates the start but pushes ground risk into the construction contracts, where it becomes a claims exposure.

**Strategic Choices:**

1. Commission a single front-loaded, full-alignment geophysical and geotechnical campaign with deep borings at every candidate pillar and anchor location before any design freeze is allowed.
2. Run a staged investigation that characterises the full corridor with geophysics first, then drills only at locations that survive design screening, and reserves additional drilling for later gates.
3. Deploy an observational approach that installs seabed seismometers, current meters and instrumented test anchors at 100 m depth as a multi-year baseline, using their data to calibrate design loads progressively.

**Trade-Off / Risk:** Front-loading investigation lowers ground-risk uncertainty, but a Strait with deep water, strong currents and active tectonics makes drilling slow and costly, and no campaign eliminates the residual risk it was meant to retire.

**Strategic Connections:**

**Synergy:** Feeds Pillar, Tether and Pontoon Support Concept with ground and load data, and strengthens Design Basis and Independent Certification Regime by giving certifiers evidence-based seismic and geotechnical inputs.

**Conflict:** Competes with Technology Proving and Stage-Gate Sequence and Funding Architecture and Risk Allocation for early time and money, since a deep front-loaded campaign delays visible progress and cannot fully eliminate residual risk.

**Justification:** *High*, Supplies ground and seismic data that fix support design and certification inputs, and sets contractor claims exposure. Competes with stage-gate and funding for early time and money. Shares survey effort with ecological work, making it a key early-risk-retirement lever.

### Decision 11: Design Basis and Independent Certification Regime
**Lever ID:** `e7603322-8ed8-489c-836d-446a1257d66f`

**The Core Decision:** Establishes the normative and assurance framework for a structure type with no international design code, covering load cases, safety targets, verifier independence and the evidence needed for operating permits. Success metrics: acceptance by both national authorities, insurer and lender sign-off, number of unresolved certification findings at each construction gate, and design-iteration cycle time kept compatible with the programme schedule.

**Why It Matters:** Sets which codes, standards and assurance bodies define what counts as safe for a structure type that has no established international design code. The choice affects design cost, regulatory acceptance by both states and insurer confidence. A rigorous independent regime slows design iteration but supplies a defensible basis for financing and operating permits.

**Strategic Choices:**

1. Adopt an adapted combination of existing offshore, immersed-tunnel and railway tunnel standards, and have a single international classification body certify the resulting project-specific design basis.
2. Develop a bespoke project design code jointly with both national authorities and academic institutions, and submit it to a standing panel of independent experts for periodic review and revision.
3. Require two competing independent design verifiers to separately re-derive critical load cases from first principles, and reconcile their differences in a public technical report before each construction gate.

**Trade-Off / Risk:** Independent certification builds financier and regulator confidence, but adapting codes for a structure with no precedent leaves gaps that certifiers must fill with judgement, and parallel verifiers may create disputes rather than consensus.

**Strategic Connections:**

**Synergy:** Supplies the defensible basis that Funding Architecture and Risk Allocation needs for lender and insurer confidence, and gives Technology Proving and Stage-Gate Sequence objective pass/fail criteria for each gate decision.

**Conflict:** Rigorous independent verification slows design iteration, pressuring Pillar, Tether and Pontoon Support Concept and Technology Proving and Stage-Gate Sequence timelines, and risks jurisdictional disputes with the Binational Treaty and Delivery Vehicle over whose standards prevail.

**Justification:** *High*, Provides the defensible safety basis for a structure with no design code, giving lenders, insurers and both regulators confidence. Supplies pass/fail criteria for gates and links to funding, egress, shipping and seabed data. Slows iteration and may spark jurisdictional disputes.

### Decision 12: Landfall Portal and Deep Transition Interface Concept
**Lever ID:** `eda5f5e4-5e3d-4afd-aa1d-63e9e16e428b`

**The Core Decision:** Fixes the geometry and construction method where the roughly 100 m deep floating tube meets fixed rock and the surface rail network at both coasts. It sets maximum rail gradient, achievable line speed, construction footprint, shaft and access provisions, and differential-movement tolerance of the first fixed-to-floating joint. Success metrics: gradient and speed compliance, joint movement margins under seismic loading, and landfall land-use and permitting impact.

**Why It Matters:** Defines how the 100 m deep floating tube meets the surface rail network at the Spanish and Moroccan coasts, including approach tunnels, shafts, ramps and the first fixed-to-floating joint. The interface concentrates geotechnical, seismic and construction complexity in a small footprint, and it governs both gradient limits for rail and land-use impact at each landfall. Poor resolution here can cap train speed or force long approach structures.

**Strategic Choices:**

1. Build long bored approach tunnels at each coast that descend gradually from the surface to the floating tube level, minimising visible surface works but extending the heavily constrained tunnelling section.
2. Use steep-gradient drilled-and-blasted or immersed ramp sections combined with deep shaft stations at each shore, shortening the approach but accepting tighter rail geometry and larger deep excavations.
3. Locate the transition inside an artificial offshore island or caisson structure near each coast, which provides a dry construction base and emergency access point but introduces a new marine obstruction and permitting burden.

**Trade-Off / Risk:** The shore interface is where fixed ground meets a moving floating structure, so differential movement and seismic motion concentrate there; each option relocates that risk rather than removing it, at large cost.

**Strategic Connections:**

**Synergy:** Provides the access shafts and dry bases that Emergency Egress and Incident Response Regime relies on, and its findings feed Seabed Investigation and Geohazard Characterisation Campaign targeting of landfall geotechnical surveys.

**Conflict:** Gradient limits and approach length constrain Rail Gauge, Signalling and Operating Concept speed and capacity targets, while offshore island options add marine obstructions that conflict with Ecological Permitting and Habitat Mitigation Pathway and Shipping Interaction and Maritime Security Perimeter.

**Justification:** *Medium*, Concentrates geotechnical and seismic complexity at the fixed-to-floating joint and sets gradient and speed limits. Interacts with egress, fabrication, permitting and rail concept, but is a localized interface problem whose scope is largely set by upstream concept choices.

### Decision 13: Ridership Ramp and Landside Network Integration Programme
**Lever ID:** `bdd586f7-3853-4153-bcaa-2f657a971979`

**The Core Decision:** Governs how passenger and freight demand is created and connected so the crossing's capacity earns revenue from opening rather than depending on forecasts. Scope includes feeder line upgrades in Spain and Morocco, service pattern at opening, and any freight or vehicle-shuttle role. Success metrics: utilisation against design capacity, landside line readiness at opening, and revenue share from non-passenger demand.

**Why It Matters:** Decides how rail demand is built and connected so that the tunnel's capacity is used once opened, rather than relying on forecasts. Funding the landside connections in Spain and Morocco in step with the crossing improves utilisation and revenue, but it adds to cost and coordination with national rail operators. Delayed integration risks an expensive crossing that links to underused lines on both ends.

**Strategic Choices:**

1. Synchronise high-speed feeder line upgrades on both sides with tunnel milestones, financed as one programme so that completed crossing capacity always has matching approach capacity.
2. Open the crossing with a limited passenger shuttle service tied to existing lines and grow network connections as measured demand justifies each extension, deferring landside investment.
3. Design the service as a combined passenger and vehicle-carrying freight shuttle from the outset, using logistics and port-hinterland demand to underwrite the crossing alongside passenger traffic.

**Trade-Off / Risk:** Matching landside investment to the crossing improves utilisation, but it binds two national rail programmes to the tunnel's schedule, so a delay at either end strands expensive capacity that earns nothing.

**Strategic Connections:**

**Synergy:** Strengthens Funding Architecture and Risk Allocation by giving lenders demonstrable demand and revenue, and shapes Rail Gauge, Signalling and Operating Concept choices such as gauge compatibility and freight or shuttle operating modes.

**Conflict:** Synchronised landside investment adds cost and binds national rail programmes to the tunnel schedule, straining Funding Architecture and Risk Allocation and the Binational Treaty and Delivery Vehicle, while a deferred approach risks underused capacity.

**Justification:** *Medium*, Drives revenue realisation and lender confidence, but acts late in the lifecycle and relies on national rail programmes outside the core project. Straining funding and treaty coordination, it is an optimisation of value capture rather than a foundational pillar.
