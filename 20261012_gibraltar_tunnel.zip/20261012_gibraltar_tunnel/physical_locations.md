This plan implies one or more physical locations.

## Requirements for physical locations

- Alignment across the Strait of Gibraltar linking southern Spain and northern Morocco
- Seabed and geohazard conditions suitable for pillar foundations and anchors in a seismically active strait
- Deep-water, sheltered access for casting yards, outfitting and tow-out of large concrete segments
- Large port, heavy-industry and skilled-labour access on both coasts
- Connection to the Spanish and Moroccan high-speed rail networks
- Landfall sites compatible with environmental protection regimes and shipping lanes
- Paired yards on each coast for political parity and shorter tows

## Location 1
Strait of Gibraltar (Spain–Morocco)

Punta Paloma / Tarifa area, Spain, to Punta Malabata / Tangier area, Morocco (Camarinal Sill corridor)

Camarinal Sill alignment, roughly 14 km crossing, shallowest corridor of the Strait (depths on the sill are several hundred metres, not 100 m)

**Rationale**: Shallowest and best-studied corridor, historically examined by SECEGSA and SNED. It suits the hybrid concept of founded pillars on the sill with tethers or buoyancy modules in deeper channels.

## Location 2
Spain

Bay of Algeciras, Andalusia (Port of Algeciras / San Roque industrial area)

Industrial port zone around Algeciras for the Spanish casting basin and outfitting yard

**Rationale**: Major deep-water port with heavy-industry, marine contractors, skilled labour and rail access. It is close to the crossing for short tows and has existing offshore logistics.

## Location 3
Morocco

Tangier-Med port complex and Tangier region, Tanger-Tétouan-Al Hoceïma

Tanger Med port and industrial zone, near the Moroccan landfall at Malabata

**Rationale**: Large modern deep-water port with free-zone industry and heavy-lift capability. It is suitable as the paired Moroccan casting yard and offers connection to the Tangier–Kenitra high-speed line.

## Location Summary
The plan is tied to the Strait of Gibraltar between Spain and Morocco. The recommended crossing is the Camarinal Sill corridor (Tarifa to Tangier), with paired casting and outfitting yards at Algeciras in Spain and Tanger Med in Morocco. These sites give shortest tows, port and industrial capacity, and rail connections on both coasts. The 100 m anchoring depth assumption conflicts with Strait bathymetry and requires verification.