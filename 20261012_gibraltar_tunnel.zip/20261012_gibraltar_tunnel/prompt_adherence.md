**Overall Adherence: 80%**

```
IMPORTANCE_ADHERENCE_SUM = (5×4 + 5×4 + 5×5 + 5×4 + 5×5 + 5×4 + 5×4 + 4×4 + 4×4 + 4×4 + 4×3 + 4×4 + 4×4 + 4×4 + 5×3) = 273
IMPORTANCE_SUM = 5 + 5 + 5 + 5 + 5 + 5 + 5 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 5 = 68
OVERALL_ADHERENCE = IMPORTANCE_ADHERENCE_SUM / (IMPORTANCE_SUM × 5) = 273 / 340 = 80%
```

## Summary

| ID | Directive | Type | Importance | Adherence | Category |
|----|-----------|------|------------|-----------|----------|
| 1 | Total budget envelope: EUR 40 billion (all sources, incl. privately financed rail systems). | Constraint | 5/5 | 4/5 | Partially honored |
| 2 | Programme horizon: 20 years; latest acceptable service opening Month 240 (2046-10-12). | Constraint | 5/5 | 4/5 | Partially honored |
| 3 | Project start: Month 0 (2026-10-12); seabed and ecological work begin immediately. | Constraint | 5/5 | 5/5 | Fully honored |
| 4 | Construct submerged, buoyant concrete tunnel system engineered for high-speed rail traffic, anchored at 100 metres below sea level in hybrid support configuration (pillars on shallows, tethers/buoyancy in deep channels). | Requirement | 5/5 | 4/5 | Partially honored |
| 5 | Alignment: Camarinal Sill corridor, Punta Paloma/Tarifa (Spain) to Punta Malabata/Tangier (Morocco), approximately 14 km crossing. | Stated fact | 5/5 | 5/5 | Fully honored |
| 6 | Establish treaty-backed binational coordinating commission with legal personality and Board (tie-break authority), single technical regulator, single lead certifier; structure in place by Month 12–15 (2027-10-12 to 2028-01-12). | Requirement | 5/5 | 4/5 | Partially honored |
| 7 | Treaty ratification target: Month 12 (2027-10-12); latest acceptable gate Month 15 (2028-01-12). No release of EUR 20 billion main-construction tranche if treaty not ratified by Month 24 (2028-10-12). | Constraint | 5/5 | 4/5 | Partially honored |
| 8 | Conduct seabed campaign Months 0–18 (2026-10-12 to 2028-04-12) (EUR 80–150 million): full-corridor geophysics by Month 6 (2027-04-12); borings and in-situ tests by Month 12 (2027-10-12); seismometer array by Month 9 (2027-07-12); independent review report Month 18 (2028-04-12). | Requirement | 4/5 | 4/5 | Partially honored |
| 9 | Design and immerse full-scale pilot segment (≥500 m) in sheltered water (Bay of Algeciras) by Month 36 (2029-10-12); EUR 100–150 million estimated cost. | Requirement | 4/5 | 4/5 | Partially honored |
| 10 | Support concept must be frozen after independent geotechnical review by Month 24 (2028-10-12) gate, with environmental consents issued by both states and rail-operator anchor-tenant agreements signed. | Requirement | 4/5 | 4/5 | Partially honored |
| 11 | Immersion rate estimate: 500–800 m/yard/year; two yards = 1.0–1.6 km/year, requiring 8.75–14 years for 14 km. Baseline service opening Month 132 (2037-10-12); 6-month floating reserve to Month 138 (2038-04-12). | Constraint | 4/5 | 3/5 | Softened |
| 12 | Establish single lead certifier by Month 6 (2027-04-12); project design code by Month 9 (2027-07-12); certification gates at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12); seismic code and tether/joint testing complete by Month 48 (2030-10-12). | Requirement | 4/5 | 4/5 | Partially honored |
| 13 | Contingency reserve: EUR 7.2 billion (18% of envelope) held inside EUR 40 billion, released by Board decision only; ecological mitigation EUR 250–400 million as distinct line item; Design Change Reserve EUR 1–2 billion for foundation/geotechnical surprises. | Constraint | 4/5 | 4/5 | Partially honored |
| 14 | Develop self-rescue egress regime: service bore with cross-passages every 500–1000 m or shafts every 2–3 km; 6–12 hour refuge air/smoke control (minimum 6); rescue staff at Tarifa and Tangier operational by Month 100 (2035-02-12); full-scale drills by Month 108 (2035-10-12). | Requirement | 4/5 | 4/5 | Partially honored |
| 15 | Project is being executed, not studied. Parallel work (treaty negotiation, seabed survey, environmental baseline) begins immediately at Month 0 (2026-10-12); gate reviews are go/no-go decisions with financial and schedule consequences, not exploratory. | Intent | 5/5 | 3/5 | Softened |

## Issues

### Issue 15 - Project is being executed, not studied. Parallel work (treaty negotiation, seabed survey, environmental baseline) begins immediately at Month 0 (2026-10-12); gate reviews are go/no-go decisions with financial and schedule consequences, not exploratory.

- **Category:** Softened
- **Adherence:** 3/5
- **Importance:** 5/5
- **Evidence:** Gate reviews are go/no-go decisions with financial and schedule consequences, not exploratory. Immediate: Establish treaty negotiation team and ministerial steering committee (Month 1 = 2026-11-12); gate-progress reports to the commission.
- **Explanation:** The plan states that gates are 'go/no-go decisions with financial and schedule consequences' and that 'parallel work (treaty negotiation, seabed survey, environmental baseline) begins immediately at Month 0 (2026-10-12).' However, it softens the user's intent by treating gates as decision points whose outcomes are contingent on prior work: 'Month 24 (2028-10-12) gate releases tranche 3 only if seabed survey is complete and concept is frozen.' The plan also introduces conditional language ('if treaty ratified by Month 24 = 2028-10-12...') that weakens the 'execution, not study' framing. Score reflects that the user's intent is acknowledged but hedged with feasibility and conditional language.

### Issue 11 - Immersion rate estimate: 500–800 m/yard/year; two yards = 1.0–1.6 km/year, requiring 8.75–14 years for 14 km. Baseline service opening Month 132 (2037-10-12); 6-month floating reserve to Month 138 (2038-04-12).

- **Category:** Softened
- **Adherence:** 3/5
- **Importance:** 4/5
- **Evidence:** Immersion rate estimate: 500–800 m/yard/year; two yards = 1.0–1.6 km/year, requiring 8.75–14 years for 14 km. Baseline service opening Month 132 (2037-10-12); 6-month floating reserve to Month 138 (2038-04-12).
- **Explanation:** The plan states the immersion-rate ranges and baseline schedule. However, it softens the user's directive by adding uncertainty: 'Weather windows of 60–90 usable immersion days per year (estimate); CPM schedule at P50/P80 by Month 1 (2026-11-12).' This introduces contingency margins not explicitly committed. The baseline of Month 132 (2037-10-12) is stated, but the plan warns that 'compressed schedule' due to delays could force opening past Month 240 (2046-10-12). The immersion rate is treated as a planning estimate, not a binding target. Score reflects that the user's target is stated but hedged with feasibility caveats.

### Issue 1 - Total budget envelope: EUR 40 billion (all sources, incl. privately financed rail systems).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Budget: EUR 40 billion total (civil EUR 24.0 billion public; rail systems EUR 8.8 billion private-financed; contingency EUR 7.2 billion inside the cap).
- **Explanation:** The plan acknowledges the €40 billion envelope and allocates it across civil, rail and contingency. However, the final summary notes 'plausible cumulative overruns of EUR 10-18 billion (25-45%)' and an 'unfunded gap of EUR 2.8-10.8 billion' if risks materialize. The plan does not fully guarantee budget adherence; it identifies the constraint but highlights that the reserve may be insufficient. Score reflects that the envelope is stated but not confidently deliverable within it.

### Issue 2 - Programme horizon: 20 years; latest acceptable service opening Month 240 (2046-10-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Baseline service opening Month 132 (2037-10-12); 6-month floating reserve to Month 138 (2038-04-12). Latest acceptable completion Month 240 (2046-10-12).
- **Explanation:** The plan targets Month 132 (2037-10-12) opening with a 6-month reserve, well within the Month 240 (2046-10-12) hard limit. However, the Risks section warns that schedule compression (treaty delays, permitting slips, weather windows) could push opening to 2041-10-12 or later. The plan does not guarantee the 20-year horizon will be met; it assumes optimistic critical-path durations. Score reflects that the constraint is nominally addressed but not de-risked.

### Issue 4 - Construct submerged, buoyant concrete tunnel system engineered for high-speed rail traffic, anchored at 100 metres below sea level in hybrid support configuration (pillars on shallows, tethers/buoyancy in deep channels).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Construct submerged, buoyant concrete tunnel system engineered for high-speed rail traffic, anchored at 100 metres below sea level in hybrid support configuration (pillars on shallows, tethers/buoyancy in deep channels).
- **Explanation:** The plan describes the hybrid concept (pillars and tethers). However, it flags a critical unresolved conflict: the 100 m anchoring depth is 'unverified against Strait bathymetry (several hundred to ~900 m)' and must be verified by Month 18–24 (2028-04-12 to 2028-10-12). The plan does not commit to 100 m as feasible; it defers resolution. Score reflects that the engineering requirement is stated but its feasibility remains in question pending seabed data.

### Issue 6 - Establish treaty-backed binational coordinating commission with legal personality and Board (tie-break authority), single technical regulator, single lead certifier; structure in place by Month 12–15 (2027-10-12 to 2028-01-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Establish treaty-backed binational coordinating commission with legal personality and Board (tie-break authority), single technical regulator, single lead certifier; structure in place by Month 12–15 (2027-10-12 to 2028-01-12).
- **Explanation:** The plan commits to a treaty, Board with tie-break, single lead certifier by Month 6 (2027-04-12), and binational authority by Month 12–15 (2027-10-12 to 2028-01-12). However, the governance architecture has not yet been negotiated; the plan proposes a structure but does not confirm it is achievable by those dates. The user's directive is honored as a plan commitment, but delivery is contingent on treaty ratification success.

### Issue 7 - Treaty ratification target: Month 12 (2027-10-12); latest acceptable gate Month 15 (2028-01-12). No release of EUR 20 billion main-construction tranche if treaty not ratified by Month 24 (2028-10-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 5/5
- **Evidence:** Treaty ratification target: Month 12 (2027-10-12); latest acceptable gate Month 15 (2028-01-12). No release of EUR 20 billion main-construction tranche if treaty not ratified by Month 24 (2028-10-12).
- **Explanation:** The plan states the treaty target and the Month 24 (2028-10-12) stop rule correctly. However, it acknowledges that 'treaty ratification delay' is a 'High' likelihood risk that could slip by 12–24 months. The plan flags the risk but does not guarantee compliance; it relies on mitigation (negotiation team by Month 1 = 2026-11-12, political commitment). Score reflects that the constraint is codified but not de-risked.

### Issue 8 - Conduct seabed campaign Months 0–18 (2026-10-12 to 2028-04-12) (EUR 80–150 million): full-corridor geophysics by Month 6 (2027-04-12); borings and in-situ tests by Month 12 (2027-10-12); seismometer array by Month 9 (2027-07-12); independent review report Month 18 (2028-04-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Seabed campaign Months 0–18 (2026-10-12 to 2028-04-12) (EUR 80–150 million): full-corridor geophysics by Month 6 (2027-04-12); borings and in-situ tests by Month 12 (2027-10-12); seismometer array by Month 9 (2027-07-12); independent review report Month 18 (2028-04-12).
- **Explanation:** The plan commits to the exact seabed campaign durations and budget. However, it notes that geophysical coverage 'by Month 6 (2027-04-12)' means the corridor survey should be complete by Month 6 (2027-04-12), not begun; the plan's language is consistent with the user's intent. All milestones are addressed. Confidence is high that this is planned, but execution risk is real (vessel availability, weather delays).

### Issue 9 - Design and immerse full-scale pilot segment (≥500 m) in sheltered water (Bay of Algeciras) by Month 36 (2029-10-12); EUR 100–150 million estimated cost.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Design and immerse full-scale pilot segment (≥500 m) in sheltered water (Bay of Algeciras) by Month 36 (2029-10-12); EUR 100–150 million estimated cost.
- **Explanation:** The plan explicitly allocates the pilot segment (≥500 m) in Bay of Algeciras by Month 36 (2029-10-12) with a matching cost estimate. However, success depends on casting-yard completion and prototype design by Month 36 (2029-10-12); delays in casting-yard build or tether/joint design could slip the pilot. The plan treats this as a critical gate. Score reflects full planning but execution contingency.

### Issue 10 - Support concept must be frozen after independent geotechnical review by Month 24 (2028-10-12) gate, with environmental consents issued by both states and rail-operator anchor-tenant agreements signed.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Support concept must be frozen after independent geotechnical review by Month 24 (2028-10-12) gate, with environmental consents issued by both states and rail-operator anchor-tenant agreements signed.
- **Explanation:** The plan commits to this gate (Month 24 = 2028-10-12) as a critical milestone, explicitly requiring independent review, consents and anchor-tenant agreements. However, the plan flags that 'if seabed conditions prove unsuitable for pillars, pillar design must deepen or strengthen significantly, adding €500 million–2 billion and 6–12 months.' The concept freeze is achievable only if the seabed campaign delivers clear guidance. Score reflects that the gate is defined but not guaranteed to be met on schedule.

### Issue 12 - Establish single lead certifier by Month 6 (2027-04-12); project design code by Month 9 (2027-07-12); certification gates at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12); seismic code and tether/joint testing complete by Month 48 (2030-10-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Establish single lead certifier by Month 6 (2027-04-12); project design code by Month 9 (2027-07-12); certification gates at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12); seismic code and tether/joint testing complete by Month 48 (2030-10-12).
- **Explanation:** The plan commits to all the certification milestones with matching dates and deliverables. However, it acknowledges that 'certification may take 12–24 months and require expensive iterations.' The plan flags a certification risk: if design basis is disputed by Spanish and Moroccan standards, resolution could slip certification by 6–12 months. The user's directive is planned but not de-risked.

### Issue 13 - Contingency reserve: EUR 7.2 billion (18% of envelope) held inside EUR 40 billion, released by Board decision only; ecological mitigation EUR 250–400 million as distinct line item; Design Change Reserve EUR 1–2 billion for foundation/geotechnical surprises.

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Contingency reserve: EUR 7.2 billion (18% of envelope) held inside EUR 40 billion, released by Board decision only; ecological mitigation EUR 250–400 million as distinct line item; Design Change Reserve EUR 1–2 billion for foundation/geotechnical surprises.
- **Explanation:** The plan allocates the exact contingency structure requested. However, it flags a critical issue: 'plausible cumulative overruns of EUR 10-18 billion exceed the EUR 7.2 billion reserve, leaving an unfunded gap.' The ecological mitigation line item is confirmed as separate (€250–400 million). The Design Change Reserve is allocated. However, the plan's own risk analysis shows the contingency is insufficient for plausible overrun scenarios. Score reflects that the structure is in place but undersized for the risk profile.

### Issue 14 - Develop self-rescue egress regime: service bore with cross-passages every 500–1000 m or shafts every 2–3 km; 6–12 hour refuge air/smoke control (minimum 6); rescue staff at Tarifa and Tangier operational by Month 100 (2035-02-12); full-scale drills by Month 108 (2035-10-12).

- **Category:** Partially honored
- **Adherence:** 4/5
- **Importance:** 4/5
- **Evidence:** Develop self-rescue egress regime: service bore with cross-passages every 500–1000 m or shafts every 2–3 km; 6–12 hour refuge air/smoke control (minimum 6); rescue staff at Tarifa and Tangier operational by Month 100 (2035-02-12); full-scale drills by Month 108 (2035-10-12).
- **Explanation:** The plan commits to the egress architecture (cross-passages, refuges, shafts) and the rescue-asset basing (Tarifa and Tangier by Month 100 = 2035-02-12). Full-scale drills are planned for Month 108 (2035-10-12). However, the plan flags that egress design cost is estimated at EUR 0.5–2 billion, which may draw on the contingency reserve. The user's requirement is stated, but cost and feasibility are noted as uncertain pending detailed design. Score reflects that the requirement is addressed in the plan but not yet financially or technically confirmed.
