35 explicit calculations found in the documents re-computed without an LLM; 2 do not match their stated result.

| Section | Statement | Stated | Computed |
|---|---|---|---|
| Canonical Facts | equivalent to 25%/18%/11% of the net category baselines (22.4/6.8/3.6 = 32.8 | 32.8 | 0.9154 |
| Data Collection | total immersion time for 14 km is 8.75–14 years (28 segments ÷ (60–90 days/year ÷ 3–7 days/segment) = 28 ÷ (8.5–30 segments/year) = 0.93–3.3 years single yard | 28 | 1.4–2.178 |
