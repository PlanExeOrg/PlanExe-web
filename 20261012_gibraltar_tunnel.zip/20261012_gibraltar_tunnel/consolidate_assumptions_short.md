# Purpose
# Spain–Morocco Submerged Floating Tunnel for High-Speed Rail

## Project Overview

Large-scale transnational infrastructure project: design and construction of a pillar-supported, submerged buoyant concrete tunnel system anchored approximately 100 m below sea level, carrying high-speed rail between Spain and Morocco across the Strait of Gibraltar. Public-scale, cross-border infrastructure initiative aimed at transport connectivity and economic integration, most plausibly delivered as a government or bi-national programme with possible private participation.

Duration: 20 years
Budget: €40 billion (user constraint)

# Domain
# Primary Domain
Submerged Floating Tunnel Engineering

## Rationale
Submerged Floating Tunnel Engineering is the only outcome-role candidate and names the core mechanism: buoyant anchored concrete tunnel tubes at 100 m depth. Finance, law, geotechnics, railway systems, and megaproject management are subordinate constraints or methods.

# Secondary Domains

- Marine Geotechnical Engineering
- Transport Infrastructure Finance
- High-Speed Railway Systems

# Disciplines

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Submerged Floating Tunnel Engineering | 5 | 5 | outcome | Core mechanism: buoyant, anchored submerged concrete tunnel tubes at 100 m depth. |
| International Infrastructure Law | 5 | 4 | constraint | Bi-national treaty, jurisdiction, maritime boundaries, and concession arrangements between Spain and Morocco govern delivery. |
| Marine Geotechnical Engineering | 4 | 4 | method | Seabed foundations, pillars, and anchoring in the seismically active Strait of Gibraltar. |
| High-Speed Railway Systems | 4 | 4 | method | Tunnel must carry high-speed rail, requiring track, signalling, traction power, and ventilation integration. |
| Marine Environmental Assessment | 4 | 4 | constraint | Strait of Gibraltar ecosystems, shipping, and seismic setting require environmental impact permitting. |
| Offshore Hydrodynamics | 4 | 4 | method | Strait currents, waves and internal tides drive tunnel and mooring loads. |
| Earthquake Engineering | 4 | 4 | constraint | The Eurasia-Africa plate boundary imposes seismic design demands on the tunnel and anchors. |
| Transport Infrastructure Finance | 4 | 3 | constraint | €40 billion binational funding, procurement, and public-private structuring over 20 years. |
| Megaproject Management | 4 | 3 | method | A 20-year, €40 billion bi-national programme needs integrated governance and delivery control. |

# Plan Type
and

# Physical Locations
# Requirements for physical locations

- Alignment across the Strait of Gibraltar linking southern Spain and northern Morocco
- Seabed and geohazard conditions suitable for pillar foundations and anchors in a seismically active strait
- Deep-water, sheltered access for casting yards, outfitting and tow-out of large concrete segments
- Large port, heavy-industry and skilled-labour access on both coasts
- Connection to the Spanish and Moroccan high-speed rail networks
- Landfall sites compatible with environmental protection regimes and shipping lanes
- Paired yards on each coast for political parity and shorter tows

## Strait of Gibraltar (Spain–Morocco)

Punta Paloma / Tarifa area, Spain, to Punta Malabata / Tangier area, Morocco (Camarinal Sill corridor). Camarinal Sill alignment, roughly 14 km crossing, shallowest corridor of the Strait (depths on the sill are several hundred metres, not 100 m).

## Rationale

Shallowest and best-studied corridor, historically examined by SECEGSA and SNED. It suits the hybrid concept of founded pillars on the sill with tethers or buoyancy modules in deeper channels.

## Spain

Bay of Algeciras, Andalusia (Port of Algeciras / San Roque industrial area). Industrial port zone around Algeciras for the Spanish casting basin and outfitting yard.

## Rationale

Major deep-water port with heavy-industry, marine contractors, skilled labour and rail access. Close to the crossing for short tows and has existing offshore logistics.

## Morocco

Tangier-Med port complex and Tangier region, Tanger-Tétouan-Al Hoceïma. Tanger Med port and industrial zone, near the Moroccan landfall at Malabata.

## Rationale

Large modern deep-water port with free-zone industry and heavy-lift capability. Suitable as the paired Moroccan casting yard and offers connection to the Tangier–Kenitra high-speed line.

## Location Summary

The plan is tied to the Strait of Gibraltar between Spain and Morocco. The recommended crossing is the Camarinal Sill corridor (Tarifa to Tangier), with paired casting and outfitting yards at Algeciras in Spain and Tanger Med in Morocco. These sites give shortest tows, port and industrial capacity, and rail connections on both coasts. The 100 m anchoring depth assumption conflicts with Strait bathymetry and requires verification.

# Currency Strategy
# Currencies

- EUR: Primary currency for the €40 billion budget envelope and consolidated reporting across Spain and Morocco.
- USD: Secondary currency for international finance structuring, multilateral lender reporting, private equity and debt participation, and currency-risk hedging.
- MAD: Moroccan dirham for local labour, materials and subcontractor costs in Morocco.

## Currency Strategy

EUR is the primary consolidation currency for the €40 billion envelope and master-level budgeting. Local costs in Spain (EUR) and Morocco (MAD) are tracked separately and converted to EUR monthly at agreed exchange rates. USD serves for multilateral lender reporting and international contractor pricing. A currency-hedging policy should cap exposure to EUR/USD and EUR/MAD fluctuations beyond agreed quarterly resets. Tranches released by the binational delivery vehicle are denominated in EUR, but private equity and debt may require USD or EUR tranches with periodic rebalancing. The Funding Architecture lever must confirm hedge instruments and reset frequency.

# Identify Risks
# Risk 1 - Technical & Feasibility

The plan states a pillar-supported concept at 100 m depth, but published Strait bathymetry shows depths of several hundred metres, up to 900 m. The discrepancy is fundamental: shallow pillars are not viable in deep water, and three candidate support concepts (pure pillars, tension tethers, hybrid) are structurally and cost-wise incompatible. No submerged floating tunnel has been built anywhere, so no precedent exists for design, fabrication, immersion or long-term durability at 100 m in seismic, high-current marine conditions. Early commitment to a single concept without seabed data means a wrong choice cannot be reversed once excavation or anchor installation begins.

## Impact

Design and cost estimates are unreliable until seabed survey confirms actual depth profile. A pillar-only concept may prove infeasible at depths above 300 m, forcing mid-programme redesign and 12–36 month delays, plus 10–20% cost inflation (€4–8 billion). A tether-only concept inflates anchor cost and dynamic-response testing timelines. A hybrid concept requires interface design between pillar and tether sections, adding complexity and joint risk. Failure to resolve this before major capital commitment undermines all downstream cost and schedule estimates.

## Likelihood

High

## Severity

High

## Action

Immediately commission a detailed seabed geophysical and geotechnical survey (3–6 months, €50–100 million estimate) along the Camarinal Sill corridor to confirm actual depth profile, geology and seismic hazard. Freeze the support concept only after survey completion. Adopt the Pragmatic Foundation strategy: hybrid pillar/tether concept matched to actual seabed conditions, with a parallel exploratory gallery to generate shared geotechnical data. Include early prototype testing (full-scale joint or segment mock-up in controlled conditions) before full design freeze, costing 3–6 months and €100–150 million. Gate main construction funding only after independent certification of the chosen support concept against actual seabed conditions.

# Risk 2 - Regulatory & Permitting

The project requires treaty-level agreement between Spain and Morocco on governance, safety standards, tolling and dispute resolution. It also requires dual-national environmental consents (Spanish national plus EU ecological rules; Moroccan national plus bilateral agreements), maritime-authority approvals beyond the two treaty partners (International Maritime Organization, EU maritime directives), and independent certification of a structure type with no international design code. Slow or conflicting regulator responses, sovereignty disputes over decision authority, or legal challenges to consent robustness can stall the programme more reliably than engineering problems.

## Impact

Treaty negotiation and ratification: 12–24 months delay (estimate). Environmental consent: if pursued in parallel (faster) but diverge, expect 6–12 months reconciliation or legal challenge; if pursued sequentially (safer), expect 18–36 months delay. Certification disputes between national authorities over safety standards or load cases: 6–12 months per dispute, potentially recurring at design gates. Delay in just the treaty and permitting path, independent of construction, could consume 24–48 months (Months 12–36 = 2027-10-12 to 2029-10-12 to Months 24–48 = 2028-10-12 to 2030-10-12 of the 20-year schedule), compressing fabrication and immersion to an infeasible pace.

## Likelihood

High

## Severity

High

## Action

Establish a binational treaty and delivery-vehicle negotiation team by Month 1 (2026-11-12), with legal and technical representatives from both states, EU, and independent mediators. Set a treaty-ratification target of Month 12–15 (2027-10-12 to 2028-01-12), with political commitment at the highest levels. Define the binational authority's legal personality, procurement authority, and dispute-resolution mechanism early (Months 1–6 = 2026-11-12 to 2027-04-12), building on SECEGSA and SNED precedent. Agree a joint Design Basis and Independent Certification Regime (Months 3–9 = 2027-01-12 to 2027-07-12) that combines Spanish, Moroccan and EU standards, overseen by a single international technical panel rather than parallel national reviewers. Parallel ecological permitting with a coordinating committee by Month 2 (2026-12-12) to avoid consent divergence. Establish a dispute-escalation protocol that binds both states to timely resolution.

# Risk 3 - Financial & Budget

The plan allocates €40 billion with a fixed 20-year horizon and 'start ASAP', but contains no visible contingency reserve or cost-control mechanism. Megaprojects routinely exceed budgets by 20–40%; first-of-kind concepts are even more exposed. Cost drivers include: support-concept uncertainty (€4–8 billion variance), seabed and seismic surprises during excavation/anchoring (contractor claims, redesign), dual-yard coordination and quality variance (€500 million–2 billion range), oversize contingency for deep-water marine construction in a busy strait (20–30% of civil cost is typical for offshore, vs. 10–15% for land), contractor risk premiums for unpriced first-of-kind technology, supply-chain inflation over 20 years, and demand/revenue shortfall against optimistic forecasts (typical 30–50% lower initial ridership than forecast, straining repayment of private debt). No explicit mechanism exists to absorb or defer costs within the envelope.

## Impact

If support-concept uncertainty alone generates €4–8 billion variance, and contingency and overrun-management costs consume another 15–25% of the budget envelope (€6–10 billion), the project may face cumulative overruns of €10–18 billion (25–45% of envelope) by Month 36–48 (2029-10-12 to 2030-10-12), forcing tranche delays, scope reductions, or sovereign guarantee increases. Demand shortfall (e.g., 40% lower ridership than forecast) reduces operating revenue by €800 million–2 billion over 20 years, destabilising any private debt or availability-payment structure tied to fare revenue. Cost overruns are also irreversible once seabed works begin; corrective action then means abandoning sunk costs and abandoning the entire crossing.

## Likelihood

High

## Severity

High

## Action

Establish a rigorous cost-control and contingency architecture by Month 2 (2026-12-12): (1) allocate explicit contingency reserves of 20% for civil works (€5.6 billion), 15% for rail systems (€1.2 billion), and 10% for operations/commissioning (€400 million), totalling €7.2 billion within the €40 billion envelope; (2) introduce a stage-gated funding release mechanism: seabed investigation and concept validation Months 0–12 (2026-10-12 to 2027-10-12) (€500 million); design and permitting Months 12–36 (2027-10-12 to 2029-10-12) (€2 billion); pilot/prototype Months 24–48 (2028-10-12 to 2030-10-12) (€1.5 billion); main construction fabrication/immersion Months 36–96 (2029-10-12 to 2034-10-12) (€20 billion); track/systems/commissioning Months 60–120 (2031-10-12 to 2036-10-12) (€8.8 billion); (3) establish an independent Project Cost Authority to track cost-to-complete at each gate, with authority to flag and escalate overruns above 5% of current tranche; (4) build demand-risk mitigation into the Ridership Ramp programme: guarantee minimum passenger levels via anchor tenant agreements with national rail operators by Month 24 (2028-10-12), and structure private debt to accept 30–40% lower opening ridership than forecast; (5) negotiate cost-sharing with contractors for first-of-kind risk: contractor retains 20% of concept risk, but joint venture structure allows state funding to absorb 80% of unforeseeable geotechnical or marine surprises.

# Risk 4 - Schedule & Critical Path

The plan mandates a 20-year horizon and 'start ASAP' without explicit stage gates, formal proving phases or schedule buffers. The critical path is currently opaque: treaty negotiation (est. 12–24 months), seabed investigation (9–18 months), design-basis certification (12–24 months), environmental consents (18–36 months if sequential, or 12–24 months if parallel with coordination risk), prototype testing (6–12 months), casting-yard construction and ramp-up (12–24 months), then 10–15 years of fabrication and immersion (depending on segment size and weather windows). Any gate delay of 6–12 months cascades: casting-yard ramp-up cannot accelerate to absorb treaty delays, so immersion schedule compresses into fewer, higher-risk weather windows. No formal contingency buffer exists for long-duration activities.

## Impact

Treaty or permitting delays of 12–24 months push casting-yard startup to Month 36–48 (2029-10-12 to 2030-10-12), giving only 4–6 years for full production ramp-up before immersion must begin to meet Month 240 (2046-10-12) service target. Immersion weather windows in the Strait are constrained (est. 100–150 days/year with <1 m significant wave height; more commonly 60–90 days/year). If only 60–90 days/year are usable and a single yard can produce and immerse ~500–800 m of tunnel per year (estimate), the full ~14 km crossing requires 18–28 years of continuous immersion. Compressed schedule forces dual yards to ramp in parallel (political pressure for parity), increasing quality-control and joint-watertightness risk. Delays in any phase directly shorten the next phase, squeezing safety margins and quality control.

## Likelihood

High

## Severity

High

## Action

Develop a detailed Critical Path Method (CPM) schedule by Month 1 (2026-11-12), with explicit task durations, predecessors and resource constraints, colour-coded by risk. Establish formal stage gates at Months 9, 15, 24, 36, 48 (2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12) with go/no-go decision authority vested in the binational delivery vehicle. Gate criteria must be objective and pre-agreed: Month 9 (2027-07-12) gate = seabed survey >80% complete, no show-stoppers identified; Month 15 (2028-01-12) gate = treaty ratified, binational authority legally active, design-basis code drafted; Month 24 (2028-10-12) gate = environmental consents issued (both states), prototype joint test complete, casting-yard site prepared; Month 36 (2029-10-12) gate = pilot segment successfully immersed in sheltered water, no major schedule variance; Month 48 (2030-10-12) gate = casting-yard production at 80% capacity, immersion crew trained and equipped. Insert a 6-month schedule contingency reserve (floating, not assigned to any task) outside the critical path, released only by binational decision if a gate slips. Parallel ecological and treaty permitting from Month 0 (2026-10-12) to avoid sequential delays. Use a weather-window model to back-calculate the latest month immersion can begin and still meet Month 240 (2046-10-12) service target; if that month is earlier than casting-yard ramp-up naturally allows, escalate to binational leadership as a trade-off requiring scope or schedule adjustment.

# Risk 5 - Environmental & Ecological

The Strait of Gibraltar is a major migration corridor for marine megafauna (cetaceans, seabirds, sea turtles) and includes protected-area designations under Spanish, Moroccan and EU regimes. Environmental consent in this context is commonly the longest permitting path, requiring multi-year baseline surveys before design is finalised, seasonal timing restrictions on construction, and ongoing monitoring and mitigation obligations. Parallel national environmental consents risk regulatory divergence (e.g., Spain requires year-round seasonal buffers, Morocco allows wider windows) that must be reconciled mid-construction or trigger injunctions. Ecological groups have legal standing to challenge consent robustness, risking stop-work orders. The project's hydrodynamic footprint (tethers, pillars, tube), current disruption and acoustic impact on marine megafauna are not yet modelled.

## Impact

Sequential environmental consent (one state at a time): 24–36 months delay before any construction permit is issued. Parallel consents with divergent conditions: 12–18 months reconciliation or legal challenge, delaying site works by similar duration. Baseline survey requirements (acoustic and visual monitoring for 2–3 years pre-construction): if mandated, blocks fabrication permitting until Month 36–48 (2029-10-12 to 2030-10-12), compressing the immersion schedule to <5 years, which is infeasible for ~14 km. Seasonal construction windows (e.g., May–September only, total 150 days/year) reduce effective immersion days to <60/year at productivity, cutting annual immersion rate by 50% or more. Injunctions or stop-work orders from legal challenges: estimated 3–6 month delays per challenge, potentially recurring at multiple construction phases. Mitigation cost (artificial reef structures on pillars, long-term marine research programmes, ferry emissions offsets): €200–500 million estimate, not clearly budgeted in the €40 billion envelope.

## Likelihood

High

## Severity

Medium

## Action

Commission a joint ecological baseline study (Months 0–9 = 2026-10-12 to 2027-07-12) with Spanish, Moroccan and EU technical teams, scoped to answer the most critical design questions (seasonal sensitivity of key species, acceptable hydrodynamic impact thresholds, acoustic limits). Parallel national environmental assessments with a coordinating committee (Months 6–18 = 2027-04-12 to 2028-04-12) that reconciles findings and commits both states to a single harmonised consent by Month 18–24 (2028-04-12 to 2028-10-12) at the latest. Embed ecological findings into the design basis: if seasonal windows are constrained, build immersion scheduling assumptions into the CPM schedule from Month 1 (2026-11-12) (i.e., assume 60–90 days/year immersion availability and model whether this fits the 20-year horizon). Include mitigation commitments (artificial reef structure, long-term research partnership, monitoring obligations) as part of the initial consent, not deferred to construction. Cost ecological mitigation (€250–400 million estimate) as a distinct line item in the budget contingency. Establish a Construction Environmental Manager role (joint Spanish–Moroccan team) with authority to halt work if seasonal or mitigation conditions are breached. Engage NGO stakeholders early (Months 0–3 = 2026-10-12 to 2027-01-12) to understand legal challenge risk and co-design consent conditions that are defensible against future injunctions.

# Risk 6 - Technical & Marine Construction

Fabricating and immersing large buoyant concrete segments in the Strait of Gibraltar, where tidal currents exceed 1 m/s, significant wave heights range from 1–3 m (median), and swell from Atlantic storms is common, presents fabrication-quality, logistics and immersion-sequencing risks. Large floating tube segments must be cast with tight tolerances (±50 mm), outfitted with ballast and connections, floated, towed 10–50 km, positioned at depth with anchors, and joined to adjacent segments with watertight joints—all in a constrained weather window and in one of the world's busiest shipping lanes. A single joint failure (leakage, structural separation) can flood a 500 m segment, requiring salvage or abandonment. Casting-yard quality and coordination between Spanish and Moroccan yards, if both are used, introduces dual-culture risk. Towing in strong currents risks line breakage, current-induced oscillation and sinking if ballast calculation is wrong.

## Impact

Casting defects (cold joints, reinforcement misplacement, concrete segregation) in 2–5% of segments: €200–500 million rework cost, 3–6 month schedule delay. Joint watertightness failures during immersion or early service: €100–300 million per failure (segment isolation, repairs, testing restart), potential service outage lasting weeks. Towing accidents (line breakage, segment sinking): €200–500 million segment loss, 4–8 month schedule slip if critical path. Weather delays: if immersion window shrinks due to climate variability or tide/current misforecasting, production backlogs accumulate, forcing higher-risk towing windows (larger seas) or cascade delays. Dual-yard quality divergence: if Spanish and Moroccan yards operate independently, joint compatibility issues may emerge after installation (e.g., 50–100 mm dimensional drift, coating or ballast differences), requiring joint redesign or time-consuming quality reconciliation on-site, consuming 3–12 months.

## Likelihood

High

## Severity

High

## Action

Establish a Joint Manufacturing and Logistics Authority (Months 0–3 = 2026-10-12 to 2027-01-12) with technical teams from Spain and Morocco, plus independent quality auditors. Codify segment design, casting procedures, tolerances and outfitting standards in a single approved specification (Months 3–9 = 2027-01-12 to 2027-07-12), inspected by independent third-party verifiers at both yards. Include a full-scale prototype segment (500 m minimum length) cast at the Spanish yard and successfully immersed in sheltered water (e.g., Bay of Algeciras) by Month 36 (2029-10-12), before full-scale production ramps up; use this pilot to validate towing procedures, ballast calculations and joint mock-up. Establish a central Quality Control and Joint Testing Laboratory (Spanish or neutral location, Month 3–12 = 2027-01-12 to 2027-10-12) that certifies all joint assemblies and ballast calculations before immersion, with authority to halt immersion of non-compliant segments. Model towing currents, forces and safety margins using computational fluid dynamics (CFD) with expert review by Month 15 (2028-01-12), and establish trigger criteria for go/no-go immersion decisions based on forecast sea state 5 days ahead. Dual-yard coordination: enforce weekly technical meetings, monthly site audits by the Joint Authority, and a penalty/incentive structure (cost-share or schedule rewards) for matching segment quality metrics. Include a contingency pool of 10–15% extra segments (1.4–2.1 km of extra tube, estimate) to absorb rework and casting losses without jeopardizing the immersion schedule.

# Risk 7 - Governance & Institutional

A multinational, treaty-level project requires a single entity (binational authority or concession holder) that can borrow, contract, regulate and make timely decisions without being stalled by national veto or competing procurement rules. The plan mentions SECEGSA and SNED (existing study bodies), but does not clarify whether they will be dissolved into a new binational authority or whether decision-making will run through a consensus committee. Slow consensus-based decision-making (e.g., 3–6 months per design change or gate decision due to dual-review cycles) can kill a 20-year schedule. Procurement rules that differ between Spain and Morocco (EU public-procurement law vs. Moroccan national law) can invalidate contracts, delay awards or force competitive re-tendering if legal standing is challenged. Weak dispute resolution (e.g., consensus committee with no tie-breaker) risks gridlock on critical design or operational decisions.

## Impact

Slow decision-making: if each major design change or gate decision requires review by two national authorities, a 3-month consensus cycle per decision, applied to ~10–15 major gates, consumes 30–45 months just on decision cycles, compressing the construction schedule. Procurement disputes: if a contract award is challenged as non-compliant with national law, re-tendering can consume 6–12 months and inflate cost (e.g., second bidder bids higher to recoup tendering costs). Governance ambiguity: if the binational authority's legal personality or decision authority is unclear, lenders and insurers may withhold financing until clarified, delaying capital release by 6–12 months. Regulatory misalignment: if Spanish and Moroccan safety or environmental authorities interpret design-basis requirements differently, a design may need dual certification paths or costly redesign, adding 6–12 months to approval cycles.

## Likelihood

Medium

## Severity

High

## Action

Negotiate and ratify a comprehensive treaty by Month 12 (2027-10-12) that establishes a binational authority with explicit legal personality, decision-making structure and dispute-resolution mechanism. The authority must have: (1) a Board of Directors (one chair, one Spanish director, one Moroccan director, one independent technical director) with a tie-breaking mechanism (e.g., chair holds tie-breaker vote, or matters escalate to political level); (2) a Chief Executive Officer with delegated authority to approve design changes up to 5% cost variance without Board approval, and 5–10% with Board approval; (3) a single unified procurement rule (harmonised EU–Morocco framework) drafted by Month 6 (2027-04-12) and ratified by both states by Month 12 (2027-10-12), with dispute resolution routed to the Board; (4) a single technical regulator (Design Basis and Certification Regime) reporting to the Board, not to dual national authorities. SECEGSA and SNED should be dissolved or subordinated to the binational authority by Month 12 (2027-10-12). Establish a Design Change Control Board (monthly meetings, decisions within 2 weeks) to manage scope and cost changes. Define escalation: changes <2% cost variance = CEO approval; 2–5% = Board approval; >5% = triggers treaty-level political review. This structure reduces decision-cycle time from 3–6 months to 2–4 weeks for routine changes and 4–8 weeks for major changes.

# Risk 8 - Supply Chain & Procurement

A 20-year, multinational megaproject depends on a supply chain for specialised materials (high-strength concrete, reinforcing steel, floating sensors, rail systems, signalling equipment) and on contractor availability (marine dredging and anchoring, segment immersion, rail installation). Global supply-chain constraints (inflation, material shortages, labour availability) affect cost and schedule. Procurement for a first-of-kind concept (e.g., tether systems, buoyancy modules, underwater joint hardware) may not exist off-the-shelf, requiring custom development, longer lead times and cost uncertainty. Dual-source procurement (Spain and Morocco) increases complexity and reduces economies of scale. A 20-year production run exposes the project to sustained inflation, wage escalation and material-cost volatility, with limited hedging mechanisms.

## Impact

Material shortages (high-strength concrete admixtures, specialised reinforcement): 3–6 month delays and 5–15% cost inflation per shortage, potentially €2–6 billion cumulative over 20 years. Custom development delays (e.g., tether systems with no precedent require 12–24 months R&D): delays critical-path activities by similar duration. Contractor unavailability: marine dredging and immersion contractors are a limited global resource; if two or more major projects compete for the same resources in 2028–2035, day-rates can spike 30–50%, inflating immersion cost by €1–3 billion. Labour availability: specialised concrete-finishers, divers, and rail-installation crews in Southern Spain and Northern Morocco are limited; persistent labour shortage can slow casting-yard ramp-up by 10–20%, compressing the immersion schedule. Currency and inflation exposure: over 20 years, 2–3% annual inflation inflates budget by 40–80% in nominal terms; if contingency reserves are not indexed to inflation or locked into contracts with escalation caps, budget overruns are likely.

## Likelihood

Medium

## Severity

Medium

## Action

Conduct supply-chain mapping and risk assessment (Months 1–3 = 2026-11-12 to 2027-01-12) for all critical materials and contractor services. Identify single-source or dual-source risks. Establish Strategic Material and Contractor Partnerships (Months 3–9 = 2027-01-12 to 2027-07-12): long-term supply agreements with tier-1 concrete, steel and equipment suppliers, with price-escalation caps (e.g., inflation +2% annually, capped at 5% per tranche). Include 'guaranteed availability' commitments for critical contractors by committing to 3–4 year advance notice of major procurement packages. For custom-development items (tethers, buoyancy modules, specialized joints): begin R&D and prototype development by Month 6 (2027-04-12), allocate €100–200 million estimate, and establish dual suppliers or design redundancy to avoid single-source lock-in. Index contingency reserves to inflation (e.g., €7.2 billion base + 2% annual inflation adjustment). Include a quarterly cost and schedule risk review (Months 12 onwards) that tracks material and labour inflation, contractor-day-rate trends and supply-chain bottlenecks, with authority to flag and escalate if inflation exceeds assumptions by >2 percentage points.

# Risk 9 - Technical & Certification

A submerged floating tunnel at 100 m depth has no international design code or precedent, so certification must be built from first principles by adapting offshore, immersed-tunnel and railway standards. The design basis must be agreed by Spanish, Moroccan and EU authorities, plus independent third parties (likely a classification society such as DNV or ABS). Different standards interpret seismic loads, wave impact, tether fatigue and failure modes differently. Reaching consensus on load cases and safety factors can take 12–24 months and may require expensive iterations or studies to justify design margins. Independent certification by multiple verifiers can be inefficient and create conflicting findings. Certification risk is both a gate-closing issue and a schedule-compression risk.

## Impact

Design-basis disagreement (e.g., seismic acceleration spectrum differs between Spanish and Moroccan standards): 6–12 month study and consensus cycle, delaying design freeze by equivalent time. Certification rejection of a major design element (e.g., tether design deemed unsafe by a verifier): forces major redesign, consuming 6–12 months. Multiple independent verifiers with conflicting findings: deadlock on certification, requiring escalation to political level or binding arbitration, consuming 3–6 months per dispute. Certification conditions (e.g., requirement for prototype tether pull-test or full-scale joint mock-up): adds 6–12 months and €50–200 million to schedule and cost if not anticipated. Late-stage certification findings (e.g., discovered at Month 60 = 2031-10-12 during detailed design): force design changes mid-fabrication, generating rework, cost overruns and schedule slips.

## Likelihood

Medium

## Severity

High

## Action

Establish a unified Design Basis and Independent Certification Regime by Month 3–9 (2027-01-12 to 2027-07-12), before detailed design begins: (1) form a joint technical panel with representatives from Spanish, Moroccan and EU authorities, plus independent experts from classification societies and academia; (2) define a project-specific design code by Month 9 (2027-07-12), combining ISO 23600 (immersed tubes), ISO 61508 (functional safety), EN 1993-1-11 (cable structures), EN 1992-1-1 (concrete) and project-bespoke seismic and hydrodynamic load cases justified by first-principles analysis; (3) appoint a single Lead Certifier (classification society or independent body) by Month 6 (2027-04-12), with authority to issue interim and final certifications, not competing parallel verifiers; (4) establish Design Certification Gates at Months 9 (concept design), 18 (30% design), 30 (60% design) and 42 (detailed design), with pre-agreed pass/fail criteria codified by Month 9 (2027-07-12); (5) allocate €50–100 million and 12–18 months for prototype testing (full-scale tether pull-test, joint assembly mock-up, segment hydrostatic test) to be completed by Month 48 (2030-10-12), before full production ramps up. Any certification finding identified after Month 48 (2030-10-12) must be minor (documentation, inspection procedure only) or absorb cost/schedule within project contingency. This structure locks certification methodology early and avoids late-stage discovery.

# Risk 10 - Operational & Long-Term Sustainability

A submerged floating tunnel is a novel structure with unknown long-term durability. Concrete deterioration in a deep marine environment with corrosive saltwater, extreme pressures and seismic cycling is not fully understood at 100 m depth over a 50–100 year service life. Maintenance access is difficult: divers or ROVs are needed for external inspection; internal repairs require train service outages. Tether systems (if used) have no long-term fatigue data, and cyclic loading from tides, currents, waves and earthquakes could cause surprise failures. A catastrophic failure (e.g., sudden tether rupture, tube flooding, train derailment) would destroy the asset and create an environmental disaster (concrete collapse, fuel spill if a train is inside). Operating costs are unknown: power for traction, ventilation and pumping in a deep tube are likely 20–40% higher than land tunnels due to pressure and isolation. A 50-year service life with unknown maintenance cost is a financing risk if private debt assumes low operating cost.

## Impact

Concrete durability issues emerging at Year 15–25: require major rehabilitation, costing €500 million–2 billion and requiring service outage for 1–3 years. Tether fatigue failures (even non-critical ones): trigger full system inspection and possible strengthening, consuming 6–12 months and €200–500 million. A major structural failure (e.g., tube flooding): catastrophic loss of asset (€10–20 billion sunk cost), service closure for years, environmental liability and potential loss of life. Operating-cost overruns: if actual power and maintenance costs are 30–40% higher than forecast, annual operating deficits of €200–400 million accumulate, straining repayment of public or private debt. Insurability: if underwriters assess fatigue or environmental risk as unquantifiable, insurance premiums spike (potentially €100–300 million/year) or coverage is withheld, increasing public liability.

## Likelihood

Medium

## Severity

High

## Action

Establish a 50-year Durability and Long-Term Operations Programme by Month 6 (2027-04-12): (1) commission long-term concrete durability studies in deep-marine environments, including accelerated-aging tests and field monitoring of existing offshore structures, by Month 9 (2027-07-12); (2) design tether and structural systems with 100-year fatigue life under realistic tide/current/seismic loads, with proof-load testing on prototype tethers by Month 48 (2030-10-12); (3) build a comprehensive long-term monitoring system into the tube infrastructure (acoustic sensors, strain gauges, tether tension monitors, current/seismic sensors) from construction, with continuous data collection feeding a predictive maintenance model; (4) allocate a dedicated O&M Reserve Fund (€200–400 million, indexed to inflation) to cover unexpected durability issues, funded by a portion of annual fare revenue or bond issuance; (5) require independent structural assessments every 10 years, with condition-based maintenance triggers that prevent drift into deterioration; (6) negotiate insurance coverage and conditions early (Months 12–24 = 2027-10-12 to 2028-10-12), locking in premiums and coverage scope before construction starts, avoiding post-opening premium shocks; (7) establish a Decommissioning Reserve Fund (€2–5 billion estimate) over the 50-year life, in case the tunnel must be closed and cleared; (8) model operating cost sensitivities (power, labour, parts cost inflation) and hedge against inflation via indexed maintenance contracts or availability payments.

# Risk 11 - Demand & Revenue

The project assumes revenue from rail passenger and possibly freight use, but actual demand may be 20–50% lower than forecast due to competition from airlines (short-haul flight cost has fallen), road logistics alternatives, economic downturns, or unexpected mode shifts. Rail demand in Europe has grown slower than forecast in many cases due to modal competition. The project opens in Month 120 (2036-10-12) (Year 10), so demand-building depends on landside network investments and service patterns that are outside the tunnel's direct control. Revenue risk is amplified if private debt or availability-payment concessions are underwritten by optimistic forecasts; a 30–40% shortfall can make debt service unsustainable, straining public budgets or forcing commercial restructuring mid-service life.

## Impact

If opening-year passenger demand is 30–40% below forecast (e.g., 4 million/year instead of 6–7 million), annual fare revenue shortfall is €100–200 million, accumulating to €1–2 billion over 10 years. If private debt assumes 6–7 million passengers and demand comes in at 4 million, debt-service ratios deteriorate, triggering covenant breach and potential restructuring or default. Freight demand is even more uncertain; if assumed to contribute €100–150 million/year and actual freight volume is 50% lower due to port-hinterland logistics changes, the revenue gap widens. Service adjustments (reduced train frequency, lower fares to boost ridership) reduce operating margin, amplifying budget pressure. A sustained revenue shortfall requires public subsidy or long-term price increases that reduce competitiveness further.

## Likelihood

Medium

## Severity

Medium

## Action

Build demand-risk management into the Ridership Ramp and Landside Network Integration Programme: (1) commission independent demand forecasting studies (Months 6–12 = 2027-04-12 to 2027-10-12) with conservative demand assumptions (20–30% below optimistic forecasts), sensitivity analysis across opening-year demand ranges (3–7 million/year), and scenario modelling of competitive threats (flight cost, road logistics innovation); (2) structure private debt and availability payments to assume lower demand than central forecast, with flexibility for revenue to surprise upward (e.g., 4 million opening-year passengers, 5–6 million by Year 5–10); (3) negotiate anchor-tenant commitments with Spanish and Moroccan rail operators by Month 24 (2028-10-12) (e.g., guaranteed minimum volume of passengers or freight, minimum annual revenue commitment); (4) include demand-shortfall insurance or revenue-protection hedging (e.g., lenders or EU development bank assumes first 20–30% revenue shortfall, protecting equity and subordinated debt); (5) design the operating model to be profitable even at 4–5 million passengers/year, with break-even fares and minimum subsidy; (6) include a market-review trigger: at Month 108–120 (2035-10-12 to 2036-10-12) (opening), if demand forecast has slipped >15% from Month 30 (2029-04-12) forecast, trigger a full demand and service-pattern review to adjust operations or public support levels. This structure manages downside risk without abandoning upside opportunity.

# Risk 12 - Shipping Interaction & Maritime Security

The Strait of Gibraltar carries ~14,000 vessel transits annually, including tankers, container ships, ferries and naval vessels. A submerged tube at 100 m depth is protected from surface collision but exposed to anchor damage, sinking vessels, dropped cargo, and deliberate attack (sabotage, military action in case of regional conflict). The tube and tethers must be passively hardened or protected by operational exclusion zones and surveillance. Passive hardening (protective covers, design margins for sinking-ship impact) adds mass and cost to buoyancy-sensitive structures. Operational exclusion zones require international maritime authority coordination and compliance from multi-flag traffic, which is difficult to enforce. Sonar and radar monitoring require permanent infrastructure and staffing. Security in a geopolitically sensitive region (Spain–Morocco maritime boundary) invites military or strategic risk.

## Impact

Anchor drag or sinking-vessel impact: if a vessel anchor or hull strikes a tether or the tube at 100 m, damage may be repairable but triggers emergency surface response, divers, inspections and potential service outage (days to weeks). A catastrophic strike (e.g., bulk carrier sinking directly onto the tube) could rupture the concrete and flood a segment, requiring emergency salvage and extended closure. Costs: €50–200 million per major incident, plus 1–3 months service outage. Passive hardening to resist impact adds €1–3 billion to capital cost (protective sleeves, reinforced zones, design margins). Exclusion zones that restrict shipping lanes cost economic efficiency in the Strait (re-routing adds fuel cost and time to shipping) and require IMO rule changes and international consensus, a process consuming 2–4 years. Terrorist attack risk (e.g., deliberate bombing of portal or landfall) adds security infrastructure cost (€100–300 million estimate) and raises public and political concern about vulnerability.

## Likelihood

Low

## Severity

High

## Action

Establish a Shipping Interaction and Maritime Security Programme by Month 3 (2027-01-12): (1) coordinate with International Maritime Organization (IMO), Spanish and Moroccan maritime authorities to define a no-anchoring exclusion corridor (±500–1000 m) along the tunnel alignment by Month 12 (2027-10-12); (2) deploy a permanent Vessel Traffic Service (VTS) upgrade for the Strait, integrating automatic identification system (AIS) data, X-band radar, and underwater sonar monitoring of tether approach, with alert thresholds for vessels entering exclusion zones; (3) design passive hardening (protective covers, impact-resistant zones) for tethers and tube sections in the busiest traffic lanes (upper 50 m, if tethers extend to surface), budgeting €500 million–1 billion; (4) establish a Joint Coast Guard and Naval Coordination Protocol with Spain and Morocco for rapid response to vessel emergencies near the tunnel (e.g., sinking ship, fire at sea), with pre-positioned rescue assets at Tarifa and Tangier; (5) conduct security risk assessment (Months 6–12 = 2027-04-12 to 2027-10-12) covering sabotage and military scenarios, with physical and procedural countermeasures; (6) negotiate maritime insurance coverage for impact and security risks by Month 18 (2028-04-12), locking in premiums and exclusions early. Exclude deliberately-hostile military action from insurable risk (sovereign act); treat as political risk to be managed by treaty and diplomatic channels between Spain and Morocco.

# Risk 13 - Seabed Investigation & Geohazard

The Strait of Gibraltar is seismically active (North African and Iberian plate margin), with a complex seabed including the Camarinal Sill and deeper channels. Seismic hazard assessment is critical for tether and anchor design, but earthquake-induced ground motion and seafloor failure (liquefaction, slope instability) are difficult to characterise in deep water without extensive drilling and monitoring. A thin early geotechnical investigation (e.g., few core borings, mostly geophysics) leaves ground risk for contractors to price at construction, inflating claims and schedule delays. A deep investigation (many borings, long-term seismic monitoring) delays the design freeze and consumes time and vessel resources before any visible construction progress, compressing the 20-year horizon.

## Impact

If seabed investigation is thin and deferred surprises emerge (e.g., weak layers requiring anchor redesign), mid-construction changes cost €500 million–2 billion and delay immersion by 6–12 months. If investigation is deep but slow (2–3 year campaign with limited vessel availability), design freeze slips by equivalent time, compressing fabrication and immersion phases. Earthquake-induced failures (tether rupture, anchor pull-out) during service life: even if rare, have catastrophic consequences (tube flooding, service loss). Insufficient seismic characterization leaves insurance and lender confidence gaps.

## Likelihood

Medium

## Severity

Medium

## Action

Commission a front-loaded, 12–18 month seabed investigation and geohazard characterisation campaign (Months 0–18 = 2026-10-12 to 2028-04-12, €80–150 million estimate): (1) geophysical survey (high-resolution bathymetry, 3D seismic reflection, shallow cores) covering the full Camarinal Sill corridor by Month 6 (2027-04-12), to establish baseline geology and shallow ground conditions; (2) targeted geotechnical drilling at 5–8 candidate pillar-foundation and anchor locations, with in-situ testing (cone penetrometry, vane shear, piezocone) by Month 12 (2027-10-12); (3) seismic hazard assessment combining instrumental seismicity data, paleoseismic evidence and probabilistic seismic hazard analysis (PSHA) to define design earthquake motions by Month 12 (2027-10-12); (4) deploy long-term seabed seismometer array (6–8 stations) and current-meter moorings by Month 9 (2027-07-12), to provide baseline monitoring and validate design-load assumptions; (5) complete all investigation reporting and design-basis recommendations by Month 18 (2028-04-12), with sign-off by independent reviewers before design freeze at Month 24 (2028-10-12). This schedule balances risk retirement (moving surprises forward) against schedule compression; it is intensive and resource-constrained but non-negotiable for a first-of-kind submerged tunnel.

# Risk 14 - Technical & Geotechnical

The plan assumes pillar-supported at 100 m depth, but the Camarinal Sill is several hundred metres deep in sections, and the deepest Strait reaches ~900 m. Shallow pillars require foundation depths of 20–50 m (typical for land tunnels), but in deep water, seabed conditions (soft sediment, weak rock, active faults) may not support large pillar bases without unacceptable settlement or instability. Tension-leg tethers anchored at 100 m in strong currents (up to 1 m/s) experience large dynamic loads and require large anchor blocks or rock anchors, both cost and design-intensive. A hybrid concept (pillars on shallow sills, tethers in deep channels) requires a transition joint that is both structurally efficient and watertight, a challenge never solved at scale.

## Impact

If seabed conditions prove unsuitable for pillars at the foundation depth assumed, pillar design must deepen or strengthen significantly, adding €500 million–2 billion to cost and 6–12 months to design. If tether anchors require large rock-anchor arrays (e.g., 20–30 m deep drilled anchors with grouted cable bundles), drilling and grouting time extends immersion schedule by 6–12 months and inflates cost by €1–3 billion. Hybrid pillar/tether transition joint: if joints fail during immersion or early operation, segment salvage and repair consume €200–500 million and 2–6 months.

## Likelihood

High

## Severity

High

## Action

Resolve the support concept before detailed design (by Month 24 = 2028-10-12): (1) integrate seabed investigation findings (Month 18 = 2028-04-12) into a geotechnical design basis that explicitly addresses pillar foundation depth, bearing capacity, settlement and fault-crossing; (2) commission independent geotechnical engineering review (Month 15–18 = 2028-01-12 to 2028-04-12) of candidate support concepts (pure pillar, pure tether, hybrid) against actual seabed conditions, with cost and schedule impact assessment for each option; (3) adopt the hybrid concept as default: founded pillars on the Camarinal Sill and adjacent shallow areas (depths <400 m), with tension-leg tethers in channels deeper than 400 m; (4) design the pillar/tether transition joint with a full-scale mock-up test by Month 48 (2030-10-12) (before production ramps), validating watertightness, structural continuity and installation procedure; (5) procure anchor drilling and grouting contractors early (Month 12 = 2027-10-12) and negotiate fixed-price, performance-based contracts for tether anchor installation to lock in cost and schedule; (6) include a Design Change Reserve (€1–2 billion, 2.5–5% of civil cost) specifically for foundation and geotechnical surprises, accessible at gate reviews if investigation reveals unexpected conditions.

# Risk 15 - Technical & Seismic

The Strait of Gibraltar sits on a major plate boundary, and earthquakes of magnitude 6–7 are possible on a multi-decadal timescale. The project design must accommodate ground motion (acceleration, displacement), tsunami risk (less likely but catastrophic), and earthquake-induced changes to seabed conditions (liquefaction, fault rupture offset). A submerged floating tube will oscillate in response to seismic shaking, with dynamic loads concentrated at anchor and joint locations. Tethers and anchors must be designed for cyclic loading, with fatigue analysis covering thousands of earthquake cycles over a 50-year service life. The design basis for seismic load cases is not yet defined (Moroccan vs. Spanish standards differ), and there is no precedent for submerged-tunnel seismic design.

## Impact

If seismic design is underestimated and a magnitude 6.5 earthquake occurs at Year 10–20, tether rupture or anchor pull-out could collapse a section of the tube or trap passengers. Cost of emergency repair: €1–5 billion; service outage: months to years. If seismic load cases are overly conservative, design cost inflates by 10–20% (€2–4 billion), and tether/anchor cost dominates the budget. Seismic uncertainty undermines lender and insurer confidence, delaying financing by 6–12 months.

## Likelihood

Low

## Severity

High

## Action

Establish a Seismic Design and Safety Programme by Month 3 (2027-01-12): (1) commission a joint Spanish–Moroccan seismic hazard assessment (PSHA) by Month 12 (2027-10-12), defining design earthquake motions (peak ground acceleration, spectral accelerations, duration) with 475-year and 2475-year return periods; (2) develop a project-specific seismic design code by Month 18 (2028-04-12), combining EN 1998 (Eurocode 8) and Moroccan standards, with guidance on seismic loads for floating structures and tethered systems from offshore and cable-stayed bridge standards; (3) conduct dynamic response analysis of the tube, tethers and anchors under design earthquake motions by Month 30 (2029-04-12), including non-linear effects (large displacement, plastic hinge formation, cable slack and re-tensioning); (4) include seismic monitoring (seabed seismometers, accelerometers on tube and tethers) in the long-term instrumentation network (Month 9 = 2027-07-12), with real-time data feeding a seismic early-warning system that triggers emergency protocols if a major earthquake occurs; (5) design all tethers and anchors for fatigue under cyclic seismic and tidal loading, with proof-loading tests on prototype tethers by Month 48 (2030-10-12); (6) establish a Seismic Emergency Response Plan (Month 36 = 2029-10-12) covering immediate post-earthquake inspection, service suspension criteria, and repair protocols. Seismic risk is irreducible but manageable through rigorous design and monitoring; treat as a design-basis cost, not a contingency.

# Risk 16 - Operations & Emergency Response

A train inside a submerged tube at 100 m depth cannot evacuate via conventional ramps; passengers must reach a refuge or exit structure designed for underwater rescue. The concept is novel and complex: refuges require pressurised compartments, cross-passages to parallel tubes or escape bores, or vertical shafts to rescue vessels on the surface. Each option adds mass and structural cost to a buoyancy-sensitive tube. Rescue asset basing (lifeboats, submarines, hyperbaric chambers) must be pre-positioned at Tarifa and Tangier, requiring infrastructure, staffing and international protocols. An incident involving train failure or flooding at 100 m depth, with dozens or hundreds of passengers requiring urgent rescue, is a low-probability but high-consequence scenario.

## Impact

If emergency egress is inadequate and a train floods or derails in the tunnel, rescue is delayed and lives are lost; public and political consequences are catastrophic, potentially triggering permanent closure of the tunnel and loss of the €40 billion asset. Design of a robust egress system adds €500 million–2 billion to capital cost and increases tube cross-section and associated material, cost and buoyancy demands. Rescue-asset infrastructure (stations, hyperbaric chambers, rescue vessels) costs €200–500 million and requires bi-national staffing and protocols. An incident (even non-fatal) during service startup could trigger public backlash, regulatory investigation and operating closure lasting months to years.

## Likelihood

Low

## Severity

High

## Action

Establish a comprehensive Emergency Egress and Incident Response Regime by Month 9 (2027-07-12): (1) define the design basis for passenger safety during train incidents (fire, flooding, collision, power loss, derailment), covering time-to-safety, refuge capacity, self-rescue endurance and external rescue timelines; (2) design the tube with escape provisions matched to the design basis: e.g., cross-passages every 500–1000 m to a parallel service bore or adjacent pressurised refuge, or vertical escape shafts every 2–3 km to surface rescue platforms/caissons; (3) include ventilation and smoke-control systems designed to maintain breathable air in refuge areas for at least 6–12 hours during a worst-case fire; (4) establish Rescue Asset Basing: pre-positioned fast rescue vessels (rescue tug or fast response craft) at Tarifa and Tangier, with hyperbaric-rescue capabilities, staffed 24/7 by Month 100 (2035-02-12) (pre-opening); (5) define a Binational Incident Response Protocol (Month 24 = 2028-10-12) covering emergency command authority, evacuation procedures, medical response and communication; (6) conduct full-scale rescue drills (e.g., simulated train fire and passenger evacuation) by Month 108 (2035-10-12) (pre-opening) to validate egress procedures and asset response; (7) establish an Emergency Response Authority (joint Spanish–Moroccan team) with legal authority and funding to pre-position, train and exercise rescue assets independently of tunnel operations. Egress cost is non-negotiable; it is a gate-closing criterion for operating permits.

# Risk 17 - Political & Diplomatic

A treaty-level megaproject is vulnerable to political instability, shifts in government, or changes in diplomatic relations between Spain and Morocco. Elections, leadership changes, or regional tensions could de-prioritise the project, slow treaty negotiations, or even halt construction. The project's 20-year timeline spans multiple election cycles in both countries, so sustained political commitment across administrations is essential but uncertain. Geopolitical tensions (e.g., disputes over maritime boundaries, Western Sahara, migration) can be magnified by the project's high visibility.

## Impact

If either government deprioritizes the project due to political change, funding tranches can be delayed or suspended, halting construction (months to years of idle infrastructure and contractor layoffs). Treaty ratification can stall if governments diverge on sovereignty or fiscal burden-sharing; a 12–24 month delay in ratification pushes program start from Month 0–3 (2026-10-12 to 2027-01-12) to Month 12–27 (2027-10-12 to 2029-01-12), compressing the schedule. Public opposition or protest (environmental, nationalism) can derail permitting or trigger injunctions, costing months and millions. A breakdown in diplomatic relations could lead to project abandonment, stranding sunk costs.

## Likelihood

Medium

## Severity

High

## Action

Establish political and diplomatic risk management: (1) secure signed political commitments from both governments at the highest level (Month 0–2 = 2026-10-12 to 2026-12-12), with public declarations of support and multi-year funding allocations (Months 0–3 = 2026-10-12 to 2027-01-12 budgets ring-fenced in national plans); (2) negotiate the treaty with supermajority ratification requirements in both parliaments, making repudiation difficult without consensus; (3) establish a Binational Steering Committee at the ministerial level (Months 0–3 = 2026-10-12 to 2027-01-12) with quarterly meetings to maintain political oversight and resolve disputes above the technical level; (4) include project-continuation clauses in the treaty that require 12-month notice and good-faith negotiation before either state can withdraw, protecting contractors and lenders; (5) engage civil society, environmental groups and regional stakeholders early (Months 0–6 = 2026-10-12 to 2027-04-12) to build public support and defuse opposition; (6) structure EU or multilateral-bank co-financing to lock in international commitment and provide political cover for both governments; (7) design the governance structure to be resilient to government transitions (e.g., binational authority has multi-year Board tenure and contractual independence, not subject to each government's electoral cycle). Political risk is persistent but manageable through institutional design and international partnership.

# Risk 18 - Financial & Cost Control

The €40 billion budget is fixed, and no contingency reserve or cost-management mechanism is explicitly described in the plan. Megaprojects commonly overrun budgets by 20–40% due to design changes, scope creep, inflation, contractor claims and unforeseen conditions. A first-of-kind concept with no precedent inflates this risk. Common cost drivers: (1) support-concept uncertainty (€4–8 billion variance between pillar and tether concepts); (2) seabed surprises requiring foundation redesign (€500 million–2 billion); (3) contingency for marine construction (20–30% of civil cost, vs. 10–15% for land); (4) dual-yard coordination and quality rework (€500 million–1.5 billion); (5) supply-chain inflation over 20 years (2–3% annually = 40–80% cumulative); (6) contractor claims for first-of-kind risk (€1–3 billion); (7) changes in regulatory requirements mid-project (€200–500 million per major change). No mechanism exists to absorb overruns within the envelope.

## Impact

Cost overruns of €5–15 billion (12.5–37.5% of envelope) by Month 48–60 (2030-10-12 to 2031-10-12) are plausible based on megaproject history. This forces: (a) scope reduction (shortened crossing, reduced capacity, deferred systems), losing project value; (b) schedule extension (compressing a fixed programme by extending past Month 240 = 2046-10-12), straining politics and cost; (c) public-budget cuts in other sectors; or (d) demand for additional sovereign guarantees or private equity investment at unfavourable terms. No cost-control mechanism means the overruns are discovered late (Month 48–60 = 2030-10-12 to 2031-10-12) rather than proactively managed, limiting mitigation options.

## Likelihood

High

## Severity

High

## Action

Implement a rigorous Cost Management and Contingency Framework (Months 0–3 = 2026-10-12 to 2027-01-12): (1) establish a Cost Baseline and Budget Reserve: support concept, site investigation, design, permitting cost = €2.5–3 billion; construction cost (fabrication, immersion, systems, contingency) = €32–35 billion; commissioning = €2–3 billion; operations (5-year ramp-up) = €1–2 billion. Allocate explicit contingency: 20% for civil/marine works (€5.6 billion), 15% for rail/systems (€1.2 billion), 10% for O&M and contingencies (€400 million), totalling €7.2 billion reserve (18% of envelope), with authority to use reserves only at gate decisions. (2) establish an independent Project Controls Authority, reporting to the Binational Board, with monthly cost and schedule tracking, quarterly forecasting (cost-to-complete, earned-value analysis), and authority to escalate variances >5% to the Board. (3) implement design-change control: no changes above 2% cost variance without CEO approval; no changes above 5% without Board approval; all changes require independent cost impact assessment within 2 weeks. (4) lock in major contractor costs via fixed-price contracts with escalation caps (inflation + 2%, capped at 5% annually). (5) negotiate cost-sharing mechanisms with contractors: contractor absorbs 20% of concept/technical risk, public authority absorbs 80% of geotechnical/marine/seismic risk, with claims procedure and dispute resolution. (6) conduct quarterly risk reviews (Months 12+) covering supply-chain, labour, material cost trends, with authority to increase contingency if inflation significantly exceeds assumptions.

# Risk 19 - Schedule & Compression

The plan mandates 20-year delivery with 'start ASAP', but the underlying schedule is opaque. The critical path is likely: Treaty + Permitting (Months 0–24 = 2026-10-12 to 2028-10-12 = estimate), Seabed Investigation (Months 0–18 = 2026-10-12 to 2028-04-12 = overlapping), Design + Certification (Months 12–48 = 2027-10-12 to 2030-10-12 = estimate), Casting-Yard Build (Months 12–36 = 2027-10-12 to 2029-10-12 = estimate), then Fabrication + Immersion (Months 36–120 = 2029-10-12 to 2036-10-12 = estimate), then Commissioning + Service Opening (Months 120–132 = 2036-10-12 to 2037-10-12 = estimate). If any major milestone slips (treaty delayed to Month 24 = 2028-10-12, permitting delayed to Month 36 = 2029-10-12, design stretched to Month 60 = 2031-10-12), immersion schedule compresses to <80 months for ~14 km of tunnel, requiring extreme production rates and high weather-window utilisation that is unrealistic. No formal contingency buffer or schedule margin is built into the plan.

## Impact

Treaty or permitting slip of 6–12 months (to Months 18–24 = 2028-04-12 to 2028-10-12 instead of Months 12–15 = 2027-10-12 to 2028-01-12) reduces immersion time from ~100 months to 80–90 months, requiring segment production and immersion rates of 175–175 m/month (vs. ~140 m/month assumed), a 25–50% productivity increase with no evidence it is achievable. Production overages (e.g., casting delays, quality rework, weather) then compress immersion further, forcing towing in larger seas and higher accident risk. Compressed commissioning (Months 120–132 = 2036-10-12 to 2037-10-12) leaves minimal time for testing, staff training or system shakedown, increasing operational risk at service opening.

## Likelihood

High

## Severity

High

## Action

Develop a detailed Critical Path Method (CPM) schedule with explicit task durations, resource constraints and risk buffers (Months 0–3 = 2026-10-12 to 2027-01-12): (1) conduct a bottom-up scheduling workshop with Spanish and Moroccan teams, contractors and independent schedulers, defining each major work package with duration estimates and confidence levels (P50, P80, P95); (2) identify the critical path: estimated path = Treaty (Months 0–15 = 2026-10-12 to 2028-01-12) → Seabed Survey (concurrent, Months 0–18 = 2026-10-12 to 2028-04-12) → Design (Months 12–48 = 2027-10-12 to 2030-10-12, gates at Months 15, 24, 36 = 2028-01-12, 2028-10-12, 2029-10-12) → Permitting (Months 6–30 = 2027-04-12 to 2029-04-12, parallel) → Casting-Yard Build (Months 12–36 = 2027-10-12 to 2029-10-12) → Fabrication (Months 36–120 = 2029-10-12 to 2036-10-12, ramp-up Months 36–48 = 2029-10-12 to 2030-10-12, plateau Months 48–110 = 2030-10-12 to 2035-12-12, ramp-down Months 110–120 = 2035-12-12 to 2036-10-12) → Immersion (Months 36–120 = 2029-10-12 to 2036-10-12, phased) → Commissioning (Months 120–132 = 2036-10-12 to 2037-10-12) → Service Opening (Months 132–144 = 2037-10-12 to 2038-10-12). (3) establish a 6–12 month schedule contingency reserve (allocated outside the critical path, not baseline) that can be deployed at gate reviews if major milestones slip. (4) set formal go/no-go decision gates every 6–12 months (Months 9, 18, 24, 36, 48, 60, 84, 108, 132 = 2027-07-12, 2028-04-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12, 2033-10-12, 2035-10-12, 2037-10-12) with objective pass/fail criteria. (5) model the immersion schedule in detail: assume 60–90 days/year actual weather windows, 500–700 m/segment production rate, and a 100–150 day immersion campaign per 10 km of tunnel; this implies a 14 km crossing requires 140–210 days of immersion across 18–35 years at one yard, or 9–18 years with two yards running in parallel. If this duration exceeds Month 120–130 (2036-10-12 to 2037-08-12), escalate to political level: the 20-year horizon is unachievable without major scope reduction (e.g., shorter crossing, phased opening, deferred systems).

# Summary

This 20-year, €40 billion first-of-kind submerged floating tunnel project faces profound risks across technical feasibility, governance, financial exposure, and schedule. The three most critical risks are: (1) the unresolved support concept (pillar vs. tether vs. hybrid) and conflicting depth assumptions (plan states 100 m anchoring, but Strait depths reach 900 m), which makes cost and feasibility estimates unreliable and early design choices irreversible once seabed works begin; (2) the binational governance, treaty ratification and dual-regulator certification framework, where sovereignty disputes, regulatory misalignment or slow treaty processes can delay or derail the entire programme; and (3) the €40 billion fixed budget against compounding cost-overrun risk (first-of-kind construction, seismic/marine exposure, dual-yard coordination, dual-regulator approval cycles), with no evident contingency reserve or mechanism to absorb contractor claims common in megaprojects. Schedule compression (20-year horizon, "start ASAP" with no formal stage gates) amplifies all three. Secondary risks include ecological permitting delays in a migration-route setting, shipping-interaction hardening costs, fabrication and immersion logistics in strong currents, and long-term demand/revenue uncertainty. The project's success depends critically on resolving the support concept and seabed conditions early (via a credible geotechnical campaign), securing treaty-level political commitment before seabed works, and building a contingency and cost-control architecture that is currently absent from the plan.

# Make Assumptions
# Financial Envelope and Tranching

## Funding Split

- €40 billion total envelope (user constraint)
- Civil works on public balance sheets; private capital covers rail systems and operations via availability payments
- Funding released in tranches tied to stage gates
- Contingency reserve: ~18% of envelope (~€7.2 billion, proposed) held at gate level

## Cost Uncertainty and Mitigation

- Support-concept variance: €4–8 billion (estimate)
- Cumulative overruns plausible at €10–18 billion (estimate); first-of-kind overruns of 20–40% common in megaproject practice
- Mitigations: gated tranches (opening tranche ~€0.5 billion for investigation and pilot), independent cost authority escalating variances above 5%, indexed contingency
- Open risk: no overrun backstop makes private participation hard to price; costs may shift to taxpayers

# Schedule and Critical Path

## Milestones and Gate Dates

- Treaty ratification: Months 12–15 (2027-10-12 to 2028-01-12)
- Seabed campaign: Months 0–18 (2026-10-12 to 2028-04-12)
- Design freeze: Month 24 (2028-10-12)
- Pilot segment immersion: Month 36 (2029-10-12)
- Main fabrication and immersion: Months 36–120 (2029-10-12 to 2036-10-12)
- Gates at Months 9, 15, 24, 36, 48 (2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12), plus 6-month floating reserve (all proposed)

## Schedule Feasibility

- 20-year horizon (user constraint) survives sequential dependencies if treaty and permitting stay on track
- Treaty or permitting slips of 12–24 months compress casting and immersion phases
- Weather windows: 60–90 usable immersion days per year (estimate); ~14 km immersion may exceed available period
- Bottom-up critical-path-method schedule at P50/P80 confidence needed by Month 1 (2026-11-12)
- Mitigations: run treaty, ecological baseline and seabed work in parallel from Month 0 (2026-10-12); test immersion rate against weather windows before committing
- Fallback: phased opening or reduced scope if model shows horizon unachievable

# Workforce and Technical Capacity

## Staffing and Contractors

- Joint delivery organisation: several hundred core staff (estimate) from both states plus international marine-tunnel and offshore specialists
- Paired yards at Algeciras and Tanger Med: thousands at peak (estimate)
- Only a few global contractors can immerse long concrete elements; long-term framework agreements required

## Risk Mitigation

- Competition from offshore wind and LNG projects may raise day-rates 30–50% (estimate)
- Local shortages of concrete finishers and divers may slow yard ramp-up 10–20% (estimate)
- Early supply-chain mapping: Months 1–3 (2026-11-12 to 2027-01-12)
- Training academies at both yards
- Framework agreements with escalation caps
- Dual sourcing for custom items (tethers, joints)
- Opportunity: regional employment and skills legacy support political parity

# Governance, Legal Framework and Certification

## Legal Structure

- Treaty-backed coordinating framework by Months 12–15 (2027-10-12 to 2028-01-12)
- Long-term concession to public-private joint venture under each state's law
- SECEGSA and SNED subordinated to coordinating framework
- Single lead certifier working from project-specific design code adapted from offshore, immersed-tunnel and railway standards
- Tie-break and escalation rules written in from the start

## Decision and Approval Framework

- Consensus cycles: 3–6 months (estimate) across 10–15 gates could consume 30–45 months
- Delegated approval thresholds proposed: CEO under 2% cost variance, Board 2–5%, political review above 5%
- Harmonised procurement and one technical regulator
- Risk: concession model leaves interface and standards-harmonisation weaknesses at mid-Strait
- Lenders and insurers require legal personality and certification clarity before committing
- Treaty withdrawal-notice clause protects continuity across election cycles

# Safety and Risk Management

## Design Basis and Hazards

- Probabilistic seismic hazard analysis with 475- and 2475-year return periods (proposed)
- Principal hazards: seismic, structural failure, fire, flooding, vessel strike, sabotage
- Egress combines cross-passages to service bore or refuges with shaft or platform access
- Rescue assets based at Tarifa and Tangier
- No-anchoring corridor with sonar and radar monitoring enforced

## Cost and Mitigation

- Egress adds €0.5–2 billion (estimate) and adds mass to buoyancy-sensitive tube
- Passive hardening could add €1–3 billion (estimate)
- Mitigations: fix egress and impact design cases at concept stage, run prototype tether and joint tests before production, install permanent structural and seismic monitoring
- Treat seismic design as baseline cost, not contingency
- Open item: 100 m depth assumption conflicts with published Strait depths of several hundred metres; must be resolved first
- Safety case acceptance gates insurance and licences

# Environmental Impact and Ecological Mitigation

## Baseline and Consent Pathway

- Joint multi-year ecological baseline starts Month 0 (2026-10-12), with parallel national assessments reconciled by Months 18–24 (2028-04-12 to 2028-10-12)
- Harmonised consent target: Months 18–24 (2028-04-12 to 2028-10-12)
- Seasonal restrictions leave 60–90 usable immersion days per year (estimate)
- Mitigation budget: €250–400 million (estimate), separate line item

## Consent Risk and Mitigation

- Sequential consents could delay permits 24–36 months
- Divergent parallel consents risk 12–18 months of reconciliation or injunctions of 3–6 months each (estimates)
- Impacts to model: acoustic disturbance, current alteration, sediment plumes, tether hydrodynamics
- Mitigations: embed ecological windows in critical-path-method schedule, commit mitigation up front, appoint joint construction environmental manager with halt authority
- Opportunity: artificial reef features and research partnerships strengthen consent defensibility and public support

# Stakeholder Engagement

## Engagement Plan

- Ministerial-level binational steering committee: quarterly meetings
- Rail operators: anchor-tenant agreements by Month 24 (2028-10-12)
- NGOs, fishing and port communities: consulted Months 0–3 (2026-10-12 to 2027-01-12)
- Maritime authorities and IMO: engaged by Month 3 (2027-01-12) on exclusion corridors
- Lenders and insurers: engaged before design freeze

## Political and Stakeholder Risk

- Political turnover across 20-year span is main threat
- Mitigations: parliamentary supermajority ratification, EU co-financing, board tenure independent of electoral cycles
- NGO legal standing makes early co-design of consent conditions cost-effective
- IMO consent for exclusion zones may take 2–4 years (estimate); engagement needed early
- Rail operator commitments underpin ridership and lender confidence
- Stakeholder register with owner and quarterly review recommended

# Operating Systems and Integration

## Rail and Operating Concept

- Standard European high-speed gauge and signalling in tunnel
- Gauge-change facilities on land
- Opening service: passenger with freight or vehicle-shuttle option
- Opening ridership plan: ~4 million per year (proposed planning case)
- Maintenance: condition-based with continuous structural monitoring network and dedicated O&M reserve

## Operational Feasibility

- Cross-section, ventilation load and rolling-stock envelope must be frozen early; they drive buoyancy margins
- Operating costs may run 20–40% above land tunnels (estimate)
- Demand 20–50% below forecast would strain debt service; model should break even at conservative volumes
- Mitigations: design O&M regime early, set 10-year independent inspection cycle, fund O&M reserve (€200–400 million, estimate), fix commissioning time for testing and training
- Opportunity: through-running maximises network value if regulators align


# Distill Assumptions
and

# Review Assumptions
# Domain of the Expert Reviewer
Megaproject Infrastructure Planning and Risk Management, with specialization in first-of-kind marine-civil engineering, multinational governance frameworks, and cost control in complex public-sector delivery

## Domain-specific Considerations

- Foundational structural concept and seabed bathymetry alignment—stated '100 m anchoring depth' versus published Strait depths of several hundred to 900 metres is critical feasibility assumption requiring resolution before irreversible seabed works
- Multinational treaty, governance and decision-authority architecture—delays in ratification, regulatory misalignment or consensus-based veto can stall programme more reliably than engineering problems
- Cost uncertainty and contingency sizing for first-of-kind concept with no built precedent in seismic, high-current marine environment
- Schedule compression risk under fixed 20-year horizon and 'start ASAP' mandate, with no formal stage gates or documented critical-path logic
- Environmental permitting across three regulatory regimes (Spanish, Moroccan, EU) in marine-megafauna migration corridor where consent robustness against legal challenge is critical
- Supply-chain capacity and dual-yard coordination for casting and immersion logistics in strong currents with constrained annual weather windows

# Issue 1 – Unresolved Support Concept and Bathymetry Conflict

Published Strait bathymetry shows depths of several hundred metres to ~900 m, but plan states 'pillar-supported' anchoring at 100 m depth. Choice between pure pillars, tension tethers, or hybrid concept is fundamental to cost, feasibility and schedule, yet remains unresolved. Once seabed works begin, a wrong early concept cannot be reversed. No submerged floating tunnel has been built anywhere, making any single-concept commitment irreversible and high-risk.

## Recommendation

Immediately commission 12–18 month front-loaded seabed investigation campaign (Months 0–18 = 2026-10-12 to 2028-04-12, estimated cost €80–150 million) covering geophysical survey, targeted core drilling at 5–8 candidate pillar and anchor locations, and seismic hazard assessment. Freeze support concept only after survey complete (by Month 18–24 = 2028-04-12 to 2028-10-12). Adopt hybrid concept by default: founded pillars on Camarinal Sill and shallow areas (<400 m depth), with tension-leg tethers in deeper channels. Commission full-scale prototype segment (500 m minimum, ~€100–150 million) and immerse it in sheltered water by Month 36 (2029-10-12) before ramping production, to validate towing, ballast and joint procedures.

## Sensitivity

- Pillar-only concept may prove infeasible at depths >300 m, forcing mid-programme redesign: 12–36 month delay, €4–8 billion cost inflation (10–20% of envelope)
- Pure tether concept inflates anchor cost by €2–4 billion and extends dynamic-response testing by 6–12 months
- Hybrid transition joint, if poorly designed, risks 3–12 month quality-reconciliation delays on-site
- Without early resolution, cost estimates unreliable and schedule visibility lost: baseline design estimate (€40 billion) could rise to €48–58 billion (20–45% overrun) by Month 36–48 (2029-10-12 to 2030-10-12)

# Issue 2 – Binational Treaty Ratification and Governance Authority Delays

Project requires treaty-level agreement on governance, procurement authority, safety standards, tolling and dispute resolution. No single decision authority established; plan references SECEGSA and SNED (existing study entities) but does not clarify whether they will be dissolved into binational authority or governance will run through consensus committee. Slow consensus-based decision-making (estimated 3–6 months per design change or gate decision) can consume 30–45 months across 10–15 major gates, compressing construction schedules below feasibility. Without clear tie-breaking and delegation rules, lenders and insurers may withhold financing until governance clarity proven.

## Recommendation

Negotiate and ratify comprehensive binational treaty by Month 12–15 (2027-10-12 to 2028-01-12). Establish treaty-backed authority with explicit legal personality, Board with tie-breaking mechanism (e.g., independent technical director or political escalation rule), Chief Executive Officer with delegated authority for changes up to 5% cost variance without Board approval, and single Lead Certifier (classification society or independent body) reporting to Board rather than dual national regulators. Codify unified procurement framework (harmonising EU and Moroccan law) by Month 12 (2027-10-12). Dissolve SECEGSA and SNED into binational authority or subordinate them explicitly. Establish Design Change Control Board meeting monthly, with decisions issued within 2 weeks for routine changes and 4–8 weeks for major changes (versus estimated 3–6 month consensus cycles). Include treaty withdrawal-notice clauses requiring 12-month notice and good-faith negotiation to protect contractors and lenders across political transitions.

## Sensitivity

- Treaty ratification delayed by 12–24 months (to Months 24–36 = 2028-10-12 to 2029-10-12 instead of 12–15) compresses immersion schedule from ~100 months to 80–90 months, forcing segment production rates 25–50% above baseline (from ~140 m/month to 175+ m/month), a productivity increase not demonstrated
- Governance gridlock on design changes (3–6 month consensus cycles) applied to 10–15 major gates consumes 30–45 months in decision cycles alone, pushing immersion start from Month 36–48 (2029-10-12 to 2030-10-12) to Month 60+, leaving <80 months for 14 km of tunnel—infeasible at weather-window constraints
- Regulatory misalignment (e.g., seismic standards differ) could add 6–12 months per design iteration
- Lender and insurer confidence delays if governance authority or procurement rules remain ambiguous: estimated 6–12 month financing-release delay

# Issue 3 – Fixed €40 Billion Budget Without Contingency Reserve or Cost-Control Architecture

Plan allocates €40 billion (user constraint) with fixed 20-year horizon and 'start ASAP', but contains no visible contingency reserve or cost-management mechanism. Megaprojects routinely exceed budgets by 20–40%; first-of-kind concepts inflate this risk further. Major cost drivers: support-concept uncertainty (€4–8 billion variance), seabed surprises requiring foundation redesign (€500 million–2 billion), dual-yard coordination rework (€500 million–1.5 billion), contractor claims for first-of-kind technology (€1–3 billion), and 20-year sustained inflation at 2–3% annually (40–80% cumulative). No mechanism exists to absorb overruns or defer costs within envelope; cost overruns discovered late (Month 48–60 = 2030-10-12 to 2031-10-12) force scope cuts, schedule extension or demand for additional sovereign guarantees.

## Recommendation

Establish rigorous Cost Management and Contingency Framework by Month 2–3 (2026-12-12 to 2027-01-12): (1) Allocate explicit contingency reserves of 20% for civil/marine works (~€5.6 billion), 15% for rail/systems (~€1.2 billion), and 10% for operations/commissioning (~€400 million), totalling ~€7.2 billion (18% of envelope), held at gate level and releasable only by binational Board decision. (2) Establish independent Project Cost Authority, reporting to Board, with monthly cost and schedule tracking, quarterly forecasting (cost-to-complete, earned-value analysis) and authority to escalate variances above 5% to Board within 2 weeks. (3) Implement design-change control: Chief Executive Officer approval for <2% cost variance; Board approval for 2–5%; political review for >5%. All changes require independent cost impact assessment within 2 weeks. (4) Lock in major contractor costs via fixed-price contracts with escalation caps (inflation + 2%, capped at 5% annually). (5) Negotiate cost-sharing: contractor absorbs 20% of concept/technical risk, public authority absorbs 80% of geotechnical/marine/seismic risk. (6) Index contingency reserves to inflation (baseline €7.2 billion plus 2% annual adjustment). (7) Conduct quarterly risk reviews tracking supply-chain, labour and material-cost trends; authority to increase contingency if inflation exceeds assumptions by >2 percentage points.

## Sensitivity

- Support-concept variance alone (€4–8 billion) represents 10–20% of envelope
- If contingency and overrun costs consume 15–25% of envelope (€6–10 billion estimate), cumulative overruns reach €10–18 billion (25–45% of baseline) by Month 36–48 (2029-10-12 to 2030-10-12)
- Cost overruns become irreversible once seabed works begin; corrective action means abandoning sunk costs
- Demand shortfall (40% lower ridership than forecast) reduces operating revenue by €800 million–2 billion over 20 years, destabilising private debt or availability-payment structures
- Without contingency architecture in place, project faces cumulative overruns of €10–18 billion (25–45% of envelope), forcing scope cuts (shortened crossing, reduced capacity, deferred systems), schedule extension past Month 240 (2046-10-12), or demand for additional sovereign guarantees at unfavourable terms

# Review Conclusion

This 20-year, €40 billion first-of-kind submerged floating tunnel faces three critical, interconnected risks: (1) stated 100 m anchoring depth conflicts with Strait bathymetry of several hundred to 900 metres, making support concept (pillars vs. tethers vs. hybrid) unresolved and design cost estimates unreliable until seabed survey complete; (2) binational treaty, governance and regulatory-alignment processes lack clear decision authority, documented critical-path timelines and cost-control mechanisms, so consensus cycles and disputes can stall programme more reliably than engineering problems; (3) fixed €40 billion budget has no explicit contingency reserve or cost-management architecture, yet first-of-kind marine-construction cost overruns of 25–45% are plausible, forcing scope cuts or budget escalation if not managed early.

## Mitigation Priorities

- Complete seabed investigation and support-concept resolution by Month 18–24 (2028-04-12 to 2028-10-12) before major capital commitment
- Secure treaty ratification and establish single decision authority with tie-breaking rules by Month 12–15 (2027-10-12 to 2028-01-12)
- Allocate €7.2 billion contingency reserve (18% of envelope) at gate level, establish independent cost authority with monthly tracking and quarterly forecasting, and implement staged funding release tied to objective gate criteria by Month 2–3 (2026-12-12 to 2027-01-12)

A detailed Critical Path Method schedule at P50/P80 confidence must be completed by Month 1 (2026-11-12); if model shows 20-year horizon unachievable given weather-window constraints and contractor productivity, escalate immediately to political level for scope or schedule adjustment decisions.