_Consistency: first pass found 1 high / 7 medium / 0 low contradictions. Repair: round 1: 41 edits → 0 high / 7 medium. Shown below: the final check of the repaired documents (0 high / 7 medium / 0 low)._

## Decision Kernel

Any NO means delay, split, downsize or stop, as described.

| # | Question | Threshold | Evidence | If NO |
|---|---|---|---|---|
| 1 | Does the Month 3 desk screen of archive bathymetry, boring and seismic records show that founded pillars are workable on the corridor, so the hybrid concept can go to the seabed campaign without a redesign trigger? | Pass only if no more than 50% of the alignment is deeper than 400 m AND typical strata bearing capacity is at least 250 kPa (premortem A1). Pillar-only is judged infeasible beyond ~300 m (proposed threshold). | Month 3: desk screen of SECEGSA/SNED archives and GEBCO data plus a parametric pillar bearing-capacity check, before vessel mobilisation. Confirmed by geophysics of the full corridor by Month 6 and 5-8 borings by Month 12. | Do not treat the hybrid split as the working concept. Pre-size tether-only (+EUR 2-4 billion, +6-12 months) and pillar-only (+EUR 4-8 billion, +12-36 months) fallbacks and a bored/phased option. Take the funding and scope decision before any casting-yard site works. The campaign itself continues (EUR 80-150 million), because it is the evidence source. |
| 2 | Is 14 km of tube immersible against validated Strait weather windows, with enough margin to protect the Month 240 limit, and is the baseline opening still credible? | Hydrographic/meteorological model (wave height <1.5 m and cross-current <0.5 m/s simultaneously) shows at least 60 usable days/year and P50 immersion duration below 11 years (premortem A3, exec summary). Note that 11 years protects only Month 240; the Month 132 baseline needs far less (see contradictions). | Month 6: model delivered, using 30+ years of climatology and a marine-contractor check. Month 9: go/no-go gate, together with the phased-opening cost-benefit pre-sized for the Month 24 scope decision. | Re-baseline the opening month or reduce scope (phased 7-10 km opening, reduced capacity, more yards or rate) by political decision before the Month 24 casting-yard advance. Defer yard expansion and long-lead procurement beyond the pilot. If validated P50 completion falls later than Month 240 minus 12 months of commissioning with no funded phased option, re-scope or cancel (FM3 stop rule). |
| 3 | Is the treaty ratified, with the delivery authority legally active, a binding Board tie-break and a single lead certifier? | Ratified by both parliaments by Month 12 (target) and no later than Month 15 (gate). Early signal: heads-of-state letter and written negotiation mandate by Month 3. Hard stop: not ratified by Month 24. | Month 3: signed letter and legal-adviser incompatibility list. Month 6: draft treaty and procurement framework circulated. Month 12-15: ratification instruments and legal-personality confirmation at the Month 15 gate. | Escalate to heads of state within 2 weeks and freeze casting-yard commitments and tranche releases beyond tranche 2. At Month 24 no part of the EUR 20 billion main-construction tranche (including the yard advance) is released, and the programme is escalated to political level to reduce scope or stop. |
| 4 | Are binding availability payments committed and a named funding source assigned for the overrun gap, with feeder-line financing resolved? | Availability-payment covenant of EUR 230-284 million/year (estimate) deposited in budget law or escrow by Month 15; lender coupon below 5.5% and maturity of at least 20 years (proposed threshold); a named source for the EUR 2.8-10.8 billion gap above the EUR 7.2 billion reserve (estimate); forecast cost-to-complete below EUR 44 billion at each gate. | Month 9: written treasury positions and lender working-group terms. Month 12-15: signed covenants and lender commitment letters. A Monte Carlo cost-risk model (due Month 9) sizes the gap. Feeder-line financing protocol (date must be fixed; see contradictions). | Release no part of the EUR 20 billion tranche. Rebalance toward public capital or a reduced public-funded scope by Board decision. The EUR 8.8 billion rail-systems tranche stays on hold until terms are signed (FM4 stop rule at Month 24). |
| 5 | Does the independent geotechnical review (Month 18) confirm a support concept that can be frozen at Month 24 within the available reserve? | Bearing capacity of at least 250 kPa at no fewer than 3 of the 5-8 boring sites fails the tripwire only when below it at 3 or more sites; forecast redesign cost below EUR 4 billion; freeze forecast no later than Month 24 plus 3 months; EUR 1-2 billion Design Change Reserve not exhausted. | Month 12: borings and in-situ tests, PSHA, seismometer array by Month 9. Month 18: reporting and independent review. Month 24: concept-freeze gate with pre-sized fallback cost/schedule (Month 9). | Withhold the casting-yard advance. Select tether-only (+EUR 2-4 billion), pillar-only (+EUR 4-8 billion; up to 118% of the available EUR 6.8-6.95 billion) or a bored/phased scope by Board decision. Any option beyond the reserve needs a new funding decision first. If no concept fits the reserve plus approved top-up and Month 240, cancel or pivot (FM2 stop rule). |
| 6 | At the Month 24 gate, are harmonised environmental consents issued by both states and anchor-tenant agreements signed, so the casting-yard advance (EUR 2-5 billion) and tranche 3 (EUR 1.5 billion) can be released? | Single harmonised consent issued by Month 24 (latest Month 30) with no pending NGO injunction; at least 2 anchor-tenant agreements signed by Month 24; prototype joint test complete; opening-demand evidence at or above the break-even level (see contradictions). | Month 12: 12 months of continuous ecological baseline data. Month 24: consent documents and signed operator agreements. The independent demand study (Month 9) is the demand evidence. | Hold the gate: the yard advance stays withheld while the gate is re-held between Month 24 and Month 30. If no legally durable consent exists by Month 30, release no main-construction funds and pivot to a revised alignment or scope (FM6 stop rule). If anchor tenants fail, re-scope to phased or shuttle service. |

## Consistency Check

Diagnostics (document vs canonical fact):

```text
HIGH CF-001  document: canonical_facts
    canonical: service_opening_target = Baseline: immersion complete Month 120, commissioning Months 120-132, service opening Month 132; latest acceptable Month 240
    observed:  Immersion of 8.75-14 years starting Month 36 (completes Month 141-204); KPI 2 'start by Month 48, total 12 years or less'
HIGH CF-002  document: executive summary; self-audit; review KPI 3
    canonical: overrun_exposure_vs_reserve = Unfunded gap EUR 2.8-10.8 billion above the cap, requiring a new funding decision (estimate)
    observed:  New funding decision / named source by Month 3 (exec summary) vs Month 6 (self-audit, KPI 3) vs Month 9 (Review 1) vs no date by Month 24 (FM4)
HIGH CF-003  document: pitch; premortem FM9; review KPI 1
    canonical: landside_feeder_financing = OPEN decision; counted outside the EUR 40 billion envelope unless the programme decides otherwise
    observed:  Feeders assumed ready for 4.0 million passengers at opening; resolution Month 9 / Month 12 / Month 108
MEDIUM CF-004  document: Review 5, 8, 10 and 13
    canonical: immersion_rate_weather_windows = 60-90 usable immersion days/year; 8.75-14 years for 14 km (estimate)
    observed:  Completion 'Month 180-240'; seasonal window 'extends immersion by 4-6 years'
MEDIUM CF-005  document: self-audit item 12
    canonical: immersion_rate_weather_windows = 500-800 m per yard per year; two yards = 1.0-1.6 km/year
    observed:  Single consolidated yard recommended as value engineering
MEDIUM CF-006  document: review 4; premortem A9/FM9
    canonical: opening_demand_planning_case = 4.0 million passengers/year at opening; operating model must break even at 4-5 million (proposed threshold)
    observed:  3.0 million floor; 30% miss absorbed by 62-68% equity
MEDIUM CF-007  document: project plan; premortem A5/FM6
    canonical: gate_month_24 = Gate requires environmental consents issued by both states; releases tranche 3 and a casting-yard advance
    observed:  Consent 'Month 24, latest Month 30'
MEDIUM CF-008  document: canonical_facts
    canonical: contingency_reserve_total_eur = EUR 7.2 billion: civil 5.6 (20% of 28.0 gross), rail systems 1.2 (15% of 8.0), operations/commissioning 0.4 (10% of 4.0)
    observed:  Civil EUR 24.0 billion and rail systems EUR 8.8 billion as line items
MEDIUM CF-009  document: pitch
    canonical: opening_demand_planning_case = 4.0 million passengers/year at opening, 5-6 million by Years 5-10
    observed:  EUR 360-450 million/year by Year 10; 4.0 million reached within 2 years of opening
MEDIUM CF-010  document: review 13 item 2
    canonical: gate_month_36 = Month 36 gate: paired yards built; pilot segment immersed; first release of the balance of the EUR 20 billion tranche
    observed:  'casting-yard start slips to Month 30-36'
```

### 1. Immersion duration cannot fit the Month 36-120 baseline window or the P50 gate (🔴 High) — needs a project decision

- **Executive summary (Key Deliverables, Risk 3, Purpose criterion 3); canonical service_opening_target and immersion_rate_weather_windows:** Immersion complete by Month 120, main construction Months 36-120; immersion at 60-90 usable days/year takes 8.75-14 years for 14 km; P50 gate set at below 11 years.
- **Review 3 (item 3), Review 6 (KPI 2), premortem A3 and FM3:** Starting at Month 36, 8.75 years ends at about Month 141 and 14 years at about Month 204; an 11-year P50 ends at about Month 168. Review 3 calls Months 36-120 an '8-10 year window' (it is 7 years). KPI 2 requires 'immersion start by Month 48 at latest' with completion Month 120 (6 years) and also 'total duration of 12 years or less' (KPI target) while the gate says below 11 years and the baseline 'P50 ~11 years' already sits at the gate.
- **Why it conflicts:** Even the best-case rate (1.6 km/year) needs about 105 months, which does not fit the 84 months from Month 36 to Month 120. Passing the 11-year gate protects only the Month 240 limit, not the Month 132 baseline. The gate threshold also differs between documents (11 vs 12 years).
- **Suggested resolution:** The baseline opening and the immersion rate are both canonical yet incompatible, so a project decision is needed. Options: (a) re-baseline immersion completion and opening to the validated model P50 while keeping Month 240; (b) raise the production/immersion rate (more yards or rate); (c) start immersion earlier than Month 36 where sequencing allows; (d) a phased opening of a shorter first section. Use one gate threshold (below 11 years at P50) everywhere and fix the '8-10 year window' wording.

### 2. Timing and ownership of the funding decision for the overrun gap (🔴 High) — needs a project decision

- **Executive summary (Purpose criterion 4, Overall Takeaway):** Exposure to be closed via a new funding decision, and the EUR 2.8-10.8 billion gap assigned to a named source, by Month 3 before design locks in.
- **Self-audit items 6-7; Review 1, Review 3, Review 6 KPI 3; premortem A6/FM4; canonical funding_split:** Self-audit: political funding decision by Month 6, with the Monte Carlo that sizes the gap due Month 9. Review 1: backstop or pre-authorised scope options by Month 9. KPI 3: 'if forecast reaches EUR 44 billion by Month 24, trigger new funding decision by Month 6'. Premortem FM4: backstop 'not scheduled by Month 24'; funding shares not set.
- **Why it conflicts:** The same decision carries deadlines of Month 3, 6, 9 and 24, falls before the model that sizes the gap, and a Month 6 deadline cannot be triggered by a Month 24 forecast. No document says which states, EU or lenders carry the gap.
- **Suggested resolution:** Decision needed on who finances overruns above the EUR 7.2 billion reserve (Spain, Morocco, EU, multilateral lenders, or scope/timeline reduction instead), and in what shares. Sequence it after the Monte Carlo (Month 9) and before the Month 24 gate. Set one date, state the trigger as a forecast at a gate, and make the earlier items 'scope the options' rather than 'decide'.

### 3. Feeder-line financing is open, yet ridership, DSCR and pitch treat feeders as ready (🔴 High) — needs a project decision

- **Canonical landside_feeder_financing; Executive summary Feedback item 4; Review 11 item 1:** Feeder-line financing and schedule are an OPEN decision and counted outside the EUR 40 billion envelope unless decided otherwise; estimated EUR 3-8 billion (estimate).
- **Pitch (Stakeholder Benefits, Metrics); premortem A9/FM9; Review 6 KPI 1; Review 9, 11, 14:** Planning case of 4.0 million passengers at opening and 5-6 million by Years 5-10, 'seamless through-running', and DSCR/availability-payment sizing all assume feeders complete. Resolution deadlines differ: Month 9 (Review 11, Review 14), Month 12 (Review 9, FM9 warning), Month 108 (FM9 tripwire). Review 14 says that if feeders are inside the envelope the EUR 3-8 billion would be carved from contingency.
- **Why it conflicts:** Revenue, DSCR and demand claims depend on an unfunded, unscheduled item that is neither in the envelope nor in the reserve. Deadlines span Month 9 to Month 108, and the plan's own downside (2.5-3.0 million if feeders are late) is not applied to the baseline.
- **Suggested resolution:** A project decision is needed: who funds and owns the feeder upgrades (Spain, Morocco, EU shares) and whether they stay outside the envelope. Fix one resolution date (Month 9, before the lender working group and demand study) and one completion gate tied to Month 132. Until then mark the 4.0 million case as conditional on feeders.

### 4. Below-60-days scenario: completion month and seasonal window counted twice (🟡 Medium)

- **Executive summary Risk 3; Review 1 item 3:** The 60-90 days/year baseline already includes the May-September ecological window; fewer than 60 days/year extends immersion to 18-25 years and pushes completion past Month 240 (about 34-47 days/year by arithmetic).
- **Review 5 (items 1-2), Review 8 (item 1), Review 10 (item 2), Review 13 (item 3):** Review 5/8/10: usable days <60 'pushing completion to Month 180-240' and 'slip of 12-48 months'; the May-September window is also an additional constraint that 'extends immersion by 4-6 years'; storm exclusions reduce the window 'from 150 to 90-100 days/year' (not below 60). Review 5 item 2 puts immersion in Q4/Q1, outside May-September.
- **Why it conflicts:** 18-25 years from Month 36 ends at about Month 252-336, past the hard limit, not Month 180-240. 90-100 days/year is above the 60-day floor, so it cannot produce 18-25 years. The seasonal window is again both baseline and extra downside.
- **Suggested resolution:** Keep the exec-summary logic: seasonal window is inside the 60-90 baseline; the downside is storm/consent exclusions that take net days to about 34-47 (recomputed), giving Month 252-336 completion, which breaches Month 240. Remove 'Month 180-240', '4-6 years extra', and the Q4/Q1 wording from the reviews.

### 5. Self-audit proposes a single yard, which breaks the plan's own schedule arithmetic (🟡 Medium) — needs a project decision

- **Self-audit item 12 (Gold Plating):** Consolidate production at Algeciras and move the second full-scale yard to backlog; the premium is gold plating (EUR 500 million-2 billion).
- **Canonical immersion_rate_weather_windows; Project plan Resources Required; Pitch (Ethical Considerations):** 500-800 m of tube per yard per year; two yards = 1.0-1.6 km/year = 8.75-14 years. One yard gives 0.5-0.8 km/year, i.e. 17.5-28 years, completing at Month 246-372 from Month 36, past Month 240. Paired yards are the decided delivery model and the basis of political parity.
- **Why it conflicts:** The value-engineering option removes half the production rate on which the 8.75-14 year estimate depends, so it cannot meet the Month 240 limit.
- **Suggested resolution:** A project decision is needed. Options: keep paired yards (canonical); keep a single casting basin with a higher rate only if validated; or a single yard with phased scope and a later opening. The benefit case due at Month 9 must be re-run with recomputed durations before any option is considered.

### 6. Downside demand mitigations do not clear opex break-even (🟡 Medium)

- **Review 4 (item 3); premortem A9/FM9; Review 10 (item 1):** Anchor-tenant guarantee of at least 3.0 million passengers/year (and a failure trigger below 3.0 million); 62-68% equity (EUR 5.5-6.0 billion) 'to absorb 30% demand miss without covenant breach'.
- **Canonical opening_demand_planning_case, annual_opex_eur; Review 4 and Review 6 KPI 1:** At EUR 60 and EUR 200 million opex, operating break-even is about 3.33 million passengers (recomputed). At 3.0 million revenue is EUR 180 million; a 30% miss (2.8 million) gives EUR 168 million, a surplus of about -EUR 32 million. Lowering debt cannot fix a negative surplus; the same reviews say DSCR is zero or negative at 2.5-3.2 million. Canonical requires break-even at 4-5 million.
- **Why it conflicts:** A 3.0 million floor sits below operating break-even, and changing the debt/equity split cannot restore covenants when operating surplus is negative; availability payments would still be needed and debt service is not actually recomputed.
- **Suggested resolution:** Set the demand floor at or above opex break-even (about 3.3 million, recomputed) or state that below it only availability payments cover costs. Remove 'without covenant breach' from the equity option, or show the recomputed debt service and the remaining availability-payment need.

### 7. Month 24 gate requires consents, but consent may arrive up to Month 30 (🟡 Medium)

- **Canonical gate_month_24; Executive summary (Key Deliverables, Action Orientation):** The Month 24 gate requires environmental consents issued by both states and releases tranche 3 and the casting-yard advance; Month 24 gates are 'non-negotiable'.
- **Project plan Dependencies; premortem A5/FM6; Review 13 item 2; Self-audit item 16:** Harmonised consent 'Month 24, latest Month 30'; stop rule triggers at Month 30; Review 13 calls it a 'Month 24-30 gate'.
- **Why it conflicts:** If consent can legitimately arrive in Months 24-30, the Month 24 gate cannot be passed as written, and no document says whether the yard advance is released, withheld or the gate re-held.
- **Suggested resolution:** State that the Month 24 gate cannot release the yard advance without consent; Months 24-30 are a re-hold window with the advance withheld, and Month 30 is the stop rule. Keep Month 24 as target and Month 30 as the limit consistently in all documents.

### 8. Contingency percentages use bases that do not match the tranche line items (🟡 Medium) — needs a project decision

- **Executive summary Timeline and Budget; Review 11 item 2; canonical funding_split:** Civil EUR 24.0 billion public and rail systems EUR 8.8 billion (tranches 4.0 + 20 + 8.8 = 32.8, plus EUR 7.2 billion contingency = EUR 40 billion).
- **Canonical contingency_reserve_total_eur; Review 11 item 2 (same sentence):** Contingency: civil 5.6 (20% of 28.0 gross), rail 1.2 (15% of 8.0), operations/commissioning 0.4 (10% of 4.0). 20% of 24.0 is 4.8 and 15% of 8.8 is 1.32; no separate EUR 4.0 billion operations line exists in the tranches.
- **Why it conflicts:** The category bases (28.0 / 8.0 / 4.0) do not reconcile with the category line items (24.0 / 8.8), so it is unclear which tranche each contingency share belongs to; this matters for cross-tranche rebalancing rules.
- **Suggested resolution:** Decide the base: either recompute contingency on the tranche line items (4.8 and 1.32, total differs from EUR 7.2 billion) or restate the line items to the 28.0/8.0/4.0 gross split with a reconciliation to the tranches. The Cost Breakdown Structure due Month 6 must settle this.

### 9. Pitch ridership revenue exceeds the reconciled demand case and contradicts itself (🟡 Medium)

- **Canonical opening_demand_planning_case and fare_per_passenger_eur; Pitch (Stakeholder Benefits):** Planning case 4.0 million at opening, 5-6 million by Years 5-10 at EUR 60 = EUR 300-360 million/year; pitch Rail Operators bullet says 5-6 million by Year 10.
- **Pitch (Long-term Vision, Metrics for Success):** Pitch Long-term Vision: revenue 'growing to EUR 360-450 million/year by Year 10' (6.0-7.5 million passengers at EUR 60). Metrics: 4.0 million 'reached within 2 years of opening' vs 4.0 million at opening.
- **Why it conflicts:** EUR 360-450 million implies 6.0-7.5 million passengers, above the 5-6 million used elsewhere, and it overstates revenue the lenders would see; the 'within 2 years' wording shifts the opening-year anchor.
- **Suggested resolution:** Use EUR 300-360 million/year by Years 5-10 (estimate) and keep 4.0 million as the opening-year planning case.

### 10. 'Casting-yard start' used for two different events (🟡 Medium)

- **Review 2 item 2; Review 12 item 1; Review 13 item 1:** Casting-yard production start slips from Month 36 to Month 42-48 if concept freeze slips.
- **Review 13 item 2:** If treaty slips to Month 18-24, 'casting-yard start slips to Month 30-36' (earlier than or equal to the Month 36 baseline production start).
- **Why it conflicts:** Yard construction starts with the Month 24 advance and production starts at Month 36; the documents label both 'start', so slips are measured from different events and one result is not a slip at all.
- **Suggested resolution:** Use 'yard construction commitment (Month 24)' and 'production start (Month 36)' as separate events and recompute slips from the correct one (a treaty slip moves construction commitment, not production start, to Month 30-36).

### 11. Insurance milestone ordering (🟡 Medium)

- **Self-audit item 15 mitigation:** Lock insurance coverage terms by Month 12.
- **Review 4 item 2; premortem A8/FM8; Review 9 item 2:** Insurers refuse to quote until prototype/full-scale testing proves durability (tests complete Month 48); preliminary terms with three underwriters by Month 48; indicative quotes by Month 9; stop rule if no cover by Month 60; proof of insurability by Month 108.
- **Why it conflicts:** A 'lock' at Month 12 precedes the 'preliminary terms' at Month 48 and the test evidence insurers are said to require; the same milestone is staged as indicative, preliminary, cover and proof without a single definition.
- **Suggested resolution:** Use a staged sequence: indicative terms Month 9, preliminary terms Month 48 after the tether and joint tests, cover or stop rule Month 60, proof of insurability Month 108 (24 months before opening). Replace 'lock by Month 12' with 'approach and indicative terms'.

### 12. 'No Real-World Proof' rated Low while the plan states there is no built precedent (🟡 Medium)

- **Self-audit item 2:** Level Low: concept 'uses established physics' and risks are 'empirical, engineering and execution'.
- **Project plan (Achievable); self-audit items 9 and 13; premortem FM7; Pitch:** 'No built precedent exists' (Project plan); 'zero built precedents' (self-audit items 9 and 13); 'no design code exists for this structure type' (premortem FM7); planet's first submerged floating tunnel for rail (pitch).
- **Why it conflicts:** The checklist question asks about proof in real projects at scale, not physical law; the plan concedes none exists. A Low rating understates a gating risk and conflicts with the 'fix before go' verdict.
- **Suggested resolution:** Re-rate to High (or at least Medium) with the mitigation unchanged: seabed campaign, pilot segment and the tether/joint tests by Month 48 as the proof route.

## Summary

The plan is broadly aligned on the main gates, the EUR 40 billion envelope, the EUR 7.2 billion reserve and the stop rules, and most earlier arithmetic errors (DSCR gaps, equity percentages, reserve percentages) are now corrected. The structural problem that remains is that the baseline schedule cannot be reached at the stated immersion rate: 8.75-14 years of immersion does not fit Months 36-120, and the P50 gate only protects the Month 240 limit. Three decisions are still missing and cause date conflicts: who funds the EUR 2.8-10.8 billion gap, who funds the feeder lines, and whether paired yards are required. The remaining items are mostly repairable wording and threshold alignment, mainly in the reviews, self-audit and pitch.