# Governance Audit


## Audit - Corruption Risks

- Kickbacks and bribery to officials overseeing binational procurement decisions, design-change approvals, and environmental/maritime permitting in two sovereignties with different governance standards and compliance cultures.
- Nepotism and favouritism in contractor selection and casting-yard subcontracting, particularly in paired yards at Algeciras and Tanger Med where dual-sourcing and local employment pressures may incentivize non-competitive awards.
- Conflicts of interest involving the binational delivery vehicle Board, design certifiers, and independent cost authority, where technical reviewers may have financial stakes in contractors or cast-yard operators, or rotate between regulatory and private roles without cooling-off periods.
- Embezzlement or misappropriation of contingency reserves (EUR 7.2 billion held at gate level) or tranches released at stage gates, particularly during periods of weak financial oversight or during political transitions when accountability chains loosen.
- Trading of favours and information misuse: binational authority staff or national regulators trading survey data, geotechnical findings, or environmental baseline results to contractors before formal release, giving advance knowledge of cost/schedule surprises or permitting bottlenecks.
- Manipulation of gate criteria or certification findings by lead certifier, independent cost authority, or national technical panels to unlock tranches prematurely or accelerate approvals, driven by political pressure to meet the Month 132 (2037-10-12) service-opening target or national interests favouring one coast over the other.

## Audit - Misallocation Risks

- Budget misuse in the seabed investigation campaign (Months 0–18 = 2026-10-12 to 2028-04-12, EUR 80–150 million estimate): overpricing of geophysical surveys and drilling, inflated mobilization costs, or duplicate efforts by Spanish and Moroccan teams without coordination, consuming contingency without delivering timely concept-definition data.
- Double spending and scope creep in design and certification: design-change control board approvals allowing multiple versions of key elements (support concept, egress, tether design) to proceed in parallel before convergence, inflating design costs and consultant fees without visible output.
- Inefficient allocation of the EUR 7.2 billion contingency reserve: earmarked commitments (ecological mitigation EUR 250–400 million, design-change reserve EUR 1–2 billion) leaving EUR 4.8–5.95 billion unallocated but untargeted, so discretionary spending proposals (e.g., extra prototype tests, redundant inspections, early equipment orders) consume reserve without rigorous prioritization.
- Misreporting of progress and cost status at gate reviews: underreported actual spend or schedule slip to secure tranche release, or underreported contractor claims and change orders to maintain appearance of cost control, discovered only after commitment of next tranche (e.g., Month 36 or 48 = 2029-10-12, 2030-10-12 gate reveals Month 24 = 2028-10-12 cost is 15% over plan).
- Unauthorized use of advance tranches: casting-yard construction advance (EUR 2–5 billion drawn from EUR 20 billion main tranche at Month 24 = 2028-10-12 gate) used for unplanned equipment, land acquisition, or labour costs at one yard, leaving the other yard underfunded and creating asymmetry and quality-control divergence.
- Inefficient dual-yard coordination and fragmented procurement: separate material contracts, labour agreements and quality standards at Algeciras and Tanger Med yards, with no consolidated purchasing power, leading to 10–20% cost inflation per yard and rework costs from dimensional or coating mismatches at joint locations (estimated EUR 500 million–1.5 billion in risks).

## Audit - Procedures

- Quarterly independent cost and schedule tracking by the Project Cost Authority (established Month 2–3 = 2026-12-12 to 2027-01-12): earned-value analysis, cost-to-complete forecasting, contractor invoice audit, change-order log review, and variance escalation >5% to the Board within 2 weeks; monthly reporting to the Binational Steering Committee.
- Semi-annual seabed investigation and geotechnical data audit (Months 0–18 = 2026-10-12 to 2028-04-12): independent review of core logging, in-situ test procedures, data quality and chain of custody; verification that survey findings are applied to support-concept and foundation-design decisions without delay or manipulation before Month 24 (2028-10-12) gate.
- Annual third-party quality audits of casting yards (Algeciras and Tanger Med) from Month 12 (2027-10-12) onwards: inspection of segment casting procedures, reinforcement placement, tolerance compliance, joint mock-up assembly and performance testing; comparison of defect rates and rework costs between yards to detect divergence.
- Post-gate financial reconciliation (after Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12): binational finance teams conduct full tranche-spend audits, confirm that released funds were used for approved purposes only, verify contingency drawdowns against approved change orders, and certify cost status before next tranche release.
- Biennial external audit by international accounting firms (every 24 months, first at Month 24 = 2028-10-12): full compliance audit of procurement (contract awards, competitive bidding compliance, conflicts of interest in vendor selection), financial controls, segregation of duties, and fraud-risk indicators across both states and the binational authority.
- Continuous monitoring of design-change approvals (monthly Design Change Control Board reviews): log all design changes, cost impacts, approval chain and justification; quarterly independent review of change orders to verify that cumulative variance across all changes does not exceed 5% of tranche and that changes support gate-freeze decisions rather than undermine them.

## Audit - Transparency Measures

- Quarterly binational progress dashboard published to the Spanish and Moroccan governments and EU funding partners (Months 0, 3, 6, 12, 24, 36 onwards = 2026-10-12, 2027-01-12, 2027-04-12, 2027-10-12, 2028-10-12, 2029-10-12 and thereafter): summary of schedule variance (days slip/gain), cost status (EUR spent vs. budgeted by tranche), gate-readiness status (objectives met/pending), and top 5 risks/mitigations; published within 30 days of quarter-end.
- Public dashboard for the 14 km crossing (environmental, engineering, traffic): monthly updates on seabed survey completion, environmental baseline findings (protected-species sightings, current profiles), design-certification status (load cases agreed, outstanding items), immersion progress (segment count completed, immersion days used vs. annual budget) once main construction begins (Month 36 = 2029-10-12 onwards).
- Published design-basis code and certification criteria (by Month 9 = 2027-07-12): binational authority releases the project-specific design code (adapted from offshore/immersed-tunnel/railway standards), gate-certification criteria, and safety-case framework in summary form; enables independent expert review and reduces claims of hidden requirements during design review.
- Disclosed gate-decision documents (within 30 days of each gate: Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12): published evidence that gate criteria were met (geotechnical findings, cost status, schedule variance, certification sign-off, environmental consent status); redactions only for commercial contract terms and national-security information (shipping exclusion details).
- Procurement transparency register: binational authority publishes all contract awards above EUR 10 million (estimate threshold) within 60 days of signature, including contract scope, awarded contractor name, bid amount(s) and evaluation rationale; enables spotting of non-competitive awards, cost overages and conflicts of interest.
- Whistleblower mechanism and grievance log: binational authority establishes an independent hotline (Month 0–3 = 2026-10-12 to 2027-01-12) for employees, contractors and public to report fraud, conflicts of interest, and misallocation; publishes a quarterly summary (anonymized) of reports received, investigations opened and outcomes; protects reporters from retaliation per international standards.

# Internal Governance Bodies

### 1. Binational Project Board

**Rationale for Inclusion:** Strategic oversight body for a treaty-level megaproject requiring high-level political and financial commitment across two states, EU partners and multilateral lenders. The Board provides direction on budget allocation above strategic thresholds (>5% cost variance), approves major design decisions (support concept, concept freeze), ratifies stage gates and tranche releases, and resolves disputes between Spanish and Moroccan authorities that exceed operational authority. Essential for maintaining sustained political will across a 20-year horizon and multiple election cycles.

**Responsibilities:**

- Approve the project's strategic direction, including the choice between competing support concepts (hybrid pillar/tether vs. alternatives) at the Month 24 (2028-10-12) gate.
- Ratify tranche releases (Months 12, 24, 36, 48, 60 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12 and beyond) based on independent gate-readiness evidence; withhold tranches if gate criteria are not met.
- Resolve design-change requests exceeding 5% cost variance or 3-month schedule impact, with authority to escalate to ministerial level if consensus cannot be reached.
- Approve the annual operational and capital budget, including contingency deployment and reserve drawdowns.
- Review and approve binational agreements, procurement policy alignment, and dispute-resolution outcomes affecting both states.
- Monitor top-level schedule variance, cost status and risk trends quarterly; escalate critical risks to participating governments.

**Initial Setup Actions:**

- Establish Board composition: one Spanish director, one Moroccan director, one independent technical director (Chair with tie-breaking authority), and one EU/multilateral-lender observer (non-voting)
- Codify Board decision rules: unanimous consent preferred; if tie between Spanish and Moroccan directors, Chair casts tie-breaker; decisions below 2% variance may be delegated to Chief Executive Officer
- Establish quarterly Board meeting cadence starting Month 1 (2026-11-12) and monthly during critical gates (Month 6–12 = 2027-04-12 to 2027-10-12, Month 24 = 2028-10-12, Month 36–48 = 2029-10-12 to 2030-10-12).
- Define escalation criteria: issues unresolvable by consensus escalate to ministerial steering committee within 15 days; ministerial decision binding on project.
- Approve the independent Cost Authority charter (Month 2–3 = 2026-12-12 to 2027-01-12) and Lead Certifier appointment (Month 6 = 2027-04-12) before detailed design begins.

**Membership:**

- Spanish Government Director (transport/infrastructure ministry or concession-holder appointee)
- Moroccan Government Director (transport/infrastructure ministry or concession-holder appointee)
- Independent Technical Chair (international maritime/tunnel engineering expert, no national affiliation, appointed jointly by both governments; term 4 years, renewable once)
- EU / Multilateral Lender Observer (optional non-voting member from European Commission or development bank co-financing the project; provides lender perspective on tranches and risk appetite)

**Decision Rights:** Strategic decisions with threshold authority: (1) Tranche release >EUR 0.5 billion requires Board approval via formal vote; (2) Design changes >5% cost variance or >3 months schedule impact require Board approval; (3) Gate go/no-go decisions (Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12) are Board decisions based on independent evidence from the Project Cost Authority and Lead Certifier; (4) Major governance or procurement-framework changes require Board decision plus treaty-level ratification; (5) Contingency reserve deployment above EUR 500 million per decision requires Board approval.

**Decision Mechanism:** Majority vote of the three voting members (Spanish, Moroccan, Chair). In case of tie (one director votes yes, one votes no), the Chair casts the tie-breaking vote. Consensus strongly preferred; if consensus cannot be reached after 2 weeks of discussion, matter escalates to the Ministerial Steering Committee (see escalation_path) within 3 days for binding political decision. Board decisions documented in writing with rationale within 5 days of vote; rationale made public (within 30 days, redacting commercial or security details).

**Meeting Cadence:** Monthly during Months 0–12 (2026-10-12 to 2027-10-12) and critical gates (Months 24, 36, 48 = 2028-10-12, 2029-10-12, 2030-10-12); quarterly thereafter (Months 12–60 = 2027-10-12 to 2031-10-12) unless additional meetings called by 2 directors or the Chair. Emergency sessions convened within 48 hours if a risk event requires decision.

**Typical Agenda Items:**

- Gate readiness review: independent evidence from Cost Authority, Certifier and operational teams on go/no-go status; decision to release or hold tranches.
- Cost and schedule status: variance analysis by tranche, top 10 risks, mitigation actions, confidence in forecast cost-to-complete.
- Major design decisions: concept freeze (Month 24 = 2028-10-12), load cases, egress regime, support-concept commitment, certification finding resolution.
- Governance and treaty issues: procurement dispute resolution, national regulatory misalignment, dispute-escalation status, treaty-amendment proposals.
- Stakeholder and political updates: government priorities, lender and insurer feedback, environmental-consent progress, shipping and security coordination.

**Escalation Path:** Issues unresolvable by Board consensus (after 2 weeks of discussion) escalate to a Ministerial Steering Committee comprising the Spanish and Moroccan ministers responsible for transport and a representative from the EU (if EU funding >20%). Ministerial decision is binding on the project within 10 days. If ministerial consensus fails, the matter is escalated to the two governments' prime ministers or equivalent; decision must be issued within 30 days. For decisions involving a tie-break by the independent Chair, the relevant director may escalate to the Ministerial Steering Committee within 5 days for review; ministerial decision overrides Board decision but must be documented and explained.
### 2. Project Management Office and Core Delivery Team

**Rationale for Inclusion:** Operational management body responsible for day-to-day execution, cost control, schedule management, and risk mitigation within approved budgets and thresholds. The PMO translates Board-level strategic decisions into detailed work plans, tracks progress against milestones, manages contractor interfaces, coordinates work across two coasts, and escalates issues that exceed operational authority to the Board. Essential for delivering a 20-year programme with hundreds of staff, multiple contractors and partners, and tight quality and safety requirements.

**Responsibilities:**

- Develop and maintain a detailed Critical Path Method (CPM) schedule at P50/P80 confidence; manage schedule variance and weather-window utilisation.
- Manage the project cost baseline and contingency reserve (EUR 7.2 billion); approve design changes up to 2% cost variance without Board approval; track contractor invoices and change orders.
- Coordinate seabed investigation campaign (Months 0–18 = 2026-10-12 to 2028-04-12) with independent reviewers; prepare Month 24 (2028-10-12) gate evidence on support-concept resolution.
- Oversee design development and interface with the Lead Certifier; manage gate criteria compliance and certification findings tracking.
- Manage casting-yard construction and ramp-up at Algeciras and Tanger Med; coordinate material procurement and quality control across dual yards.
- Plan and execute fabrication and immersion logistics; manage immersion schedules, weather windows, and towing/landing procedures.
- Coordinate with environmental, maritime and rail-integration programmes; ensure schedule integration and mitigation compliance.
- Prepare quarterly progress reports for the Board and binational governments; conduct risk and change reviews; manage stakeholder communication.

**Initial Setup Actions:**

- Appoint a Chief Executive Officer (Month 0 = 2026-10-12) and establish a Core Delivery Team (project controls, engineering, contracts, finance, risk, environmental, rail integration) by Month 1 (2026-11-12).
- Develop a detailed CPM schedule at P50/P80 by Month 1 (2026-11-12); identify critical path and schedule reserve allocation.
- Establish a Design Change Control Board (DCCB), meeting monthly from Month 3 (2027-01-12) onwards, with authority to approve changes <2% variance and escalate others to CEO or Board.
- Create a Project Cost Authority within the PMO by Month 2–3 (2026-12-12 to 2027-01-12) with independent audit authority; establish monthly earned-value tracking and quarterly cost-to-complete forecasting.
- Set up a Risk Management Register by Month 1 (2026-11-12), tracking all 19 risks identified in the assumptions document and any project-specific risks; conduct monthly reviews and quarterly risk-governance updates to the Board.

**Membership:**

- Chief Executive Officer (reports to the Board; appointed by the Board; typically an experienced megaproject delivery leader with multinational experience)
- Director of Project Controls and Finance (managing cost, schedule, earned-value, contingency tracking and budget forecasting)
- Director of Engineering and Design (managing seabed investigation, design development, coordination with the Lead Certifier, and technical working groups)
- Director of Contracts and Procurement (managing competitive bidding, contract award, contractor performance, and supply-chain partnerships)
- Director of Environmental and Ecological Compliance (managing the joint ecological baseline, environmental-consent coordination, and mitigation delivery)
- Director of Rail Integration and Operations Planning (managing landside network coordination, rail-operator agreements, signalling standards and commissioning planning)
- Head of Risk and Assurance (managing the Risk Register, risk reviews, independent audits, and escalations to the Board)

**Decision Rights:** Operational decisions and delegated authority: (1) Design changes <2% cost variance may be approved by the CEO without Board escalation; (2) Changes 2–5% variance require DCCB recommendation and CEO sign-off, with notification to the Board within 5 days; (3) Changes >5% or >3-month schedule impact escalate to the Board; (4) Contingency drawdowns <EUR 500 million per decision may be approved by the CEO with Finance Director sign-off and Risk Authority audit; (5) Contractor performance issues, schedule variance and cost variance >5% of current tranche escalate to the Board; (6) Monthly progress reports and quarterly risk updates are issued to the Board and both governments.

**Decision Mechanism:** CEO decision authority for changes <2% cost variance, made in consultation with affected Directors and DCCB (monthly forum). Changes 2–5% are recommended by DCCB (consensus preferred, simple majority acceptable if DCCB cannot reach consensus) and approved by CEO with Finance and Risk Director sign-off. Major cost or schedule decisions requiring Board escalation are documented with independent analysis (Finance, Risk, Controls) and presented to the Board within 2 weeks of discovery. Risk decisions are made by the Risk Authority (Head of Risk and Assurance) in consultation with operational leaders; high-severity risks (impact >EUR 500 million or >6-month schedule) escalate to the Board within 1 week.

**Meeting Cadence:** Weekly Core Delivery Team standup (30–60 minutes) for schedule and cost status; monthly Design Change Control Board (2–4 hours) for design-change review; monthly Risk and Assurance review (1–2 hours) for risk trends and mitigation effectiveness; monthly Project Control review (2–3 hours) for earned-value analysis, cost-to-complete and contingency status. Quarterly Board-readiness meetings (1 day) prior to scheduled Board meetings, consolidating all updates and preparing gate evidence.

**Typical Agenda Items:**

- Weekly: schedule variance (days slip/gain by work package), critical-path updates, imminent risk triggers, contractor performance issues, environmental or permitting blockers.
- Monthly DCCB: design-change log (all changes >0.1% cost variance, cumulative tracking), change impact analysis (cost, schedule, risk), recommendation for Board or CEO approval.
- Monthly Risk: top 10 risks by severity, mitigation status, emerging risks, risk-driven cost and schedule variance, escalation decisions.
- Monthly Cost/Control: earned-value by tranche, invoice audit findings, contractor claims status, contingency deployment log, forecast cost-to-complete at P50 and P80, variance analysis >5% per tranche.
- Quarterly Board prep: consolidated gate-readiness evidence, cost and schedule confidence level, top risks and mitigation, stakeholder updates, lender/insurer feedback.

**Escalation Path:** Design changes >5% cost variance or >3-month schedule impact, and cost/schedule variance >5% of current tranche, escalate from CEO to the Project Board within 2 weeks, with independent Finance and Risk analysis. Risk events with potential impact >EUR 500 million or >6-month schedule slip escalate from the Risk Authority to the Board within 1 week. Unresolved contractor disputes or contractual claims >EUR 50 million escalate from the Contracts Director to the CEO and Board within 15 days. Permitting or environmental compliance issues that could delay a gate or tranche release escalate from the Environmental Director to the CEO and Board within 5 days. Any issue presenting a material threat to the project's feasibility (e.g., support concept redesign, treaty delay, lender withdrawal) escalates immediately to the Board, with escalation authority vested in any two of the Core Team Directors or the CEO.
### 3. Independent Cost Authority

**Rationale for Inclusion:** Specialized assurance body responsible for objective, independent tracking of project cost and schedule performance against the EUR 40 billion envelope. First-of-kind megaprojects commonly experience cost overruns of 20–40%; the project plan identifies a plausible cumulative overrun of EUR 10–18 billion (25–45% of envelope) versus a EUR 7.2 billion contingency reserve. An independent cost authority, staffed by external auditors and financial specialists with no affiliation to either state or the delivery team, provides the objectivity needed for lenders, governments and the Board to make informed funding decisions. The authority has explicit escalation authority to flag cost and schedule variances above 5% and demand corrective action within defined timelines.

**Responsibilities:**

- Conduct monthly earned-value analysis (schedule performance index, cost performance index) and variance reporting at the tranche level and aggregate programme level.
- Prepare quarterly cost-to-complete forecasts at P50 (50th percentile) and P80 (80th percentile) confidence; track confidence trends month-to-month.
- Audit all contractor invoices, change orders and cost claims; verify that costs charged align with contractual terms and approved scope changes.
- Review all design-change cost impacts independently before DCCB or CEO approval; flag cost inflation risk and cumulative change-order trends.
- Conduct quarterly risk-cost sensitivity analysis: model the top 10 risks and their cost/schedule impacts; update the contingency-reserve adequacy assessment.
- Escalate cost and schedule variance >5% of the current tranche to the Board and both governments within 5 business days; recommend corrective-action options.
- Provide independent certification that each tranche release is justified by actual spend, committed expenditure, and cost-to-complete forecasts aligned with the approved budget.

**Initial Setup Actions:**

- Establish the Cost Authority as an independent entity, chartered by the Project Board, reporting directly to the Board (not to the PMO CEO) by Month 2–3 (2026-12-12 to 2027-01-12).
- Appoint a Chief Financial Officer and Controller with multinational audit/megaproject experience; staff the Authority with a Finance Manager, Cost Engineer, Schedule Analyst and Audit Specialist by Month 3 (2027-01-12).
- Define the cost baseline for each tranche: establish P50 and P80 cost-at-completion forecasts and confidence levels by Month 3 (2027-01-12); document approved scope and change-control thresholds.
- Establish earned-value-tracking systems, contractor-invoice audit workflows, and change-order logging within the project's financial systems by Month 3 (2027-01-12).
- Publish the quarterly cost and schedule reporting format and cadence: monthly variance reports, quarterly gate-readiness cost certification, annual cost-confidence statement.

**Membership:**

- Chief Financial Officer (head of the Authority; independent financial specialist, no affiliation to Spanish or Moroccan government or delivery contractor; reports directly to the Board)
- Controller (responsible for cost baseline, earned-value tracking, and contingency reserve management)
- Finance Manager (day-to-day contractor-invoice audit and change-order cost verification)
- Cost Engineer (independent cost estimates for design changes, risk sensitivity analysis, and cost-to-complete forecasting)
- Schedule Analyst (earned-value schedule tracking, critical-path variance analysis, and weather-window utilisation modelling)

**Decision Rights:** The Cost Authority has authority to: (1) Audit and certify or reject contractor invoices and cost claims if they do not align with approved contracts or scope; (2) Recommend cost-control actions to the Board and PMO CEO if variance exceeds 5% or contingency deployment trends suggest reserve inadequacy; (3) Certify that each tranche release is justified by financial performance and cost-to-complete forecasts; (4) Halt or delay contractor payments if invoice documentation is incomplete or inconsistent with earned-value records, pending PMO CEO and Finance Director resolution; (5) Propose contingency-reallocation or cost-mitigation actions to the Board if risk sensitivity analysis identifies inadequate reserves for a particular work phase.

**Decision Mechanism:** Monthly cost and schedule variance is reported by the Controller without Board vote (administrative reporting). If variance >5% of the current tranche, the Chief Financial Officer escalates to the Board in writing within 5 business days, with independent cost-to-complete analysis and recommended corrective actions. The Board must respond within 10 days with either: (a) acceptance of the variance and reforecast, (b) direction to the PMO to implement corrective actions within a defined timeline, or (c) decision to reallocate contingency reserves or request additional funding. Contractor-invoice disputes are resolved through a three-step process: (1) Finance Manager and Contracts Director attempt resolution within 10 days; (2) if unresolved, PMO CEO makes final project decision within 15 days, documented in writing; (3) if Authority disagrees with CEO decision, matter escalates to the Board within 5 days for binding resolution.

**Meeting Cadence:** Monthly earned-value review (1–2 hours) internal to the Cost Authority; monthly summary variance report issued to the Board and PMO by the 5th working day of each month. Quarterly cost-to-complete forecasting and gate-readiness certification (1 full day) conducted one week before each scheduled Board meeting (Months 8, 14, 23, 35, 47, 59 = 2027-06-12, 2027-12-12, 2028-09-12, 2029-09-12, 2030-08-12, 2031-08-12 and quarterly thereafter). Annual independent audit of Cost Authority processes and cost-data accuracy by an external accounting firm (Month 24, 48, 72 onwards = 2028-10-12, 2030-10-12, 2032-10-12 and every 24 months).

**Typical Agenda Items:**

- Monthly: earned-value summary (BCWS, BCWP, ACWP by tranche), schedule and cost indices, variance analysis vs. Plan and variance trend, contingency-reserve drawdown log, top 5 cost-variance drivers, escalation decisions.
- Quarterly: cost-to-complete forecast (P50, P80) and confidence trend analysis, risk-cost sensitivity (top 10 risks and impact ranges), contingency-reserve adequacy assessment, tranche-readiness certification, corrective-action tracking from previous variance escalations.
- Annual: full audit of project cost baseline and approved-change log, cost-data quality and systems review, historical cost-forecasting accuracy (actuals vs. quarterly P50/P80 forecasts), contractor-claim patterns and dispute resolution effectiveness, external audit findings and corrective actions.

**Escalation Path:** Monthly variance >5% of the current tranche escalates from the Controller to the Chief Financial Officer, who reports to the Board within 5 business days. If the Board does not respond with corrective action or contingency allocation within 10 days, the matter escalates to the Ministerial Steering Committee (Spanish and Moroccan transport ministers plus EU observer). Contractor-invoice disputes that the PMO CEO cannot resolve within 15 days escalate to the Project Board for binding decision within 5 days. If the Cost Authority identifies a pattern of cost overruns or contingency depletion that threatens the programme's financial feasibility (e.g., cumulative variance >EUR 2 billion by a gate, or >5% variance in consecutive quarters), the Chief Financial Officer may issue a formal Feasibility Alert to the Board and both governments, recommending trigger points for scope or schedule adjustment decisions.
### 4. Design Basis and Independent Certification Panel

**Rationale for Inclusion:** Specialized technical assurance body responsible for establishing the design code, safety standards and certification criteria for a structure type with no international design precedent. The project faces seismic, hydrodynamic, marine-construction and long-term durability unknowns that must be codified into a defensible design basis before detailed design begins. An independent panel, comprising international experts in offshore engineering, immersed tunnels, seismic design and railway safety, working under a single Lead Certifier appointed by the Board, ensures that both Spanish and Moroccan regulators and international lenders/insurers accept the design basis. The panel also sets gate criteria, reviews certification findings at design milestones, and issues the final operating permit. Without a robust certification regime, the project cannot be financed or insured.

**Responsibilities:**

- Develop a project-specific design code by Month 9 (2027-07-12), adapting ISO 23600 (immersed tubes), EN 1993-1-11 (cable structures), EN 1992-1-1 (concrete), EN 1998 (seismic design) and Moroccan standards; codify seismic load cases, hydrodynamic loads, tether fatigue criteria, safety factors and inspection protocols.
- Establish design certification gates at Months 9, 18, 30 and 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) (concept, 30% design, 60% design, detailed design); define pass/fail criteria for each gate in advance.
- Review and approve the seismic hazard assessment (probabilistic seismic hazard analysis at 475- and 2475-year return periods) by Month 12 (2027-10-12); confirm design earthquake motions for load-case definition.
- Oversee prototype testing: full-scale tether pull-test, transition-joint mock-up assembly and performance testing, and segment hydrostatic test; certify results by Month 48 (2030-10-12).
- Conduct regular design-review audits (quarterly during design phases Months 12–48 = 2027-10-12 to 2030-10-12) to identify outstanding certification findings and verify closure rate; escalate non-closures to the Board.
- Prepare the final Safety Case for each gate, documenting that design meets code requirements and provides defensible evidence for insurers and regulators; issue final operating permit by Month 130 (2037-08-12).
- Provide independent expert testimony in regulatory disputes if Spanish or Moroccan authorities diverge on code interpretation or load-case requirements.

**Initial Setup Actions:**

- Appoint a Lead Certifier (classification society such as DNV-GL, ABS or equivalent, or a consortium of independent technical experts) by Month 6 (2027-04-12); establish Lead Certifier authority and scope in the contract (2-year initial term, renewable).
- Form a Technical Advisory Panel comprising: international experts in submerged tunnels/offshore structures, seismic and geotechnical engineering, railway safety and emergency response; Spanish and Moroccan technical authorities as observers (non-voting); panel size 5–7 members.
- Draft a project design code incorporating existing standards and project-specific requirements by Month 6 (2027-04-12); publish a draft for stakeholder and regulator review by Month 9 (2027-07-12); finalize and Board-approve by Month 9 (2027-07-12).
- Define the certification gate criteria (pass/fail checklist) for each gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) by Month 9 (2027-07-12); communicate criteria to design teams so gate readiness is clear.
- Establish a Design Review Schedule aligning with CPM schedule: monthly during design phases, with quarterly Lead Certifier audits to track open findings and closure rate.

**Membership:**

- Lead Certifier (independent classification society or consortium; reports to the Project Board, not the PMO; typically one firm with contract authority and lead signature)
- Chair, Technical Advisory Panel (international expert in submerged tunnels or offshore structures; no affiliation to Spanish or Moroccan authorities; appointed by the Lead Certifier in consultation with the Board)
- Technical Panel Members (typically 4–6): experts in seismic/earthquake engineering, marine geotechnics, tunnel/immersed-tube design, railway safety, emergency egress and operations (at least one from EU/OECD country to ensure international standard alignment)
- Spanish National Technical Authority Representative (observer, non-voting; typically from the transport ministry or national rail authority; provides input on Spanish code expectations and regulator acceptance)
- Moroccan National Technical Authority Representative (observer, non-voting; typically from the transport ministry; provides input on Moroccan code expectations and regulator acceptance)

**Decision Rights:** The Lead Certifier has authority to: (1) Approve or reject design submissions against the agreed design code at each gate; (2) Issue interim certification letters at each gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) confirming that design meets code or identifying outstanding findings; (3) Require additional testing or analysis if code compliance is not demonstrated (e.g., prototype tether pull-test, full-scale joint mock-up); (4) Issue the final Safety Case and operating permit by Month 130 (2037-08-12), conditioned on satisfactory testing, construction quality and operational readiness; (5) Recommend rejection of a gate if outstanding findings are non-minor (material impact on safety, cost or schedule); (6) Provide expert judgment on code interpretation if Spanish and Moroccan authorities disagree on load cases or safety factors.

**Decision Mechanism:** Gate certification is a formal process: (1) Design team submits design package to the Lead Certifier 6 weeks before the gate date; (2) Lead Certifier conducts technical review with panel support, typically over 4–6 weeks; (3) Lead Certifier issues either a Certification Letter (design approved) or a Finding Letter (identifies outstanding items requiring resolution); (4) If findings are identified, design team has 2 weeks to respond with corrective actions or justification; (5) Lead Certifier re-reviews and issues either approval or recommendation for Board escalation; (6) Board makes the go/no-go gate decision based on Lead Certifier recommendation; (7) gate decisions are documented in writing with technical rationale, accessible to stakeholders (redacting only commercial/security details). Design code interpretation disputes between Spanish and Moroccan authorities are resolved through the Technical Panel: if consensus cannot be reached, the Panel Chair issues a binding interpretation (30 days to resolve).

**Meeting Cadence:** Monthly design-review meetings (2–4 hours) between the design team and the Lead Certifier, starting Month 12 (2027-10-12); quarterly technical panel meetings (1 day) during design phases (Months 12–48 = 2027-10-12 to 2030-10-12) for design audit and open-findings review. Quarterly interim certifications (Months 18, 30, 42 = 2028-04-12, 2029-04-12, 2030-04-12) issued by the Lead Certifier. Gate certification submittals at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) with go/no-go decisions within 2 weeks of submission.

**Typical Agenda Items:**

- Monthly design review: design update by package (load cases, structural design, geotechnical foundation, tether and anchor design, egress provisions, rail integration), compliance vs. design code, outstanding findings, schedule for resolution.
- Quarterly panel meeting: open-findings summary, closure rate, design risks identified in review, testing plan and timeline, resource adequacy, escalation decisions.
- Gate certification: formal submission package review, compliance checklist against gate criteria, interim or final certification decision, conditions for next gate.

**Escalation Path:** Non-minor certification findings (material impact on safety, cost >EUR 500 million, or schedule >6 months) escalate from the Lead Certifier to the Board within 2 weeks of gate submission, with a recommendation to approve, approve-with-conditions, or reject the gate. The Board has 10 days to decide; if the Board approves the gate despite a non-minor finding, that decision is documented with Board rationale and reported to both Spanish and Moroccan authorities. Design-code interpretation disputes between national authorities escalate from the Technical Panel Chair to the Board within 30 days; the Board may appoint an independent international arbitrator if political solution is preferred. If a finding remains unresolved at a gate, the Lead Certifier may recommend that the gate remain open (no go) until finding is closed; only a unanimous Board vote (Spanish, Moroccan and Chair, all three voting yes) can override the Lead Certifier and approve a gate with open non-minor findings.
### 5. Risk and Assurance Authority

**Rationale for Inclusion:** Specialized assurance body responsible for comprehensive risk management, compliance oversight and mitigation effectiveness across all 19 identified risks (support-concept uncertainty, treaty delays, cost overruns, schedule compression, environmental permitting, marine construction, governance disputes, supply-chain constraints, certification complexity, operational durability, demand shortfall, shipping security, seabed hazards, geotechnical unknowns, seismic design, emergency response, political transitions and cost control). The project faces multiple interconnected risks, any one of which could delay or derail the 20-year programme; a dedicated, independent Risk Authority with authority to escalate risk events and trigger governance responses is essential. The Authority also oversees GDPR, ethical compliance, corruption prevention and supply-chain due diligence, given the multinational public-procurement and binational authority context.

**Responsibilities:**

- Establish and maintain a comprehensive Risk Register (Months 0–240 = 2026-10-12 to 2046-10-12) covering all project risks identified in the assumptions document and emergent risks; conduct monthly risk-review meetings with the Core Delivery Team.
- Assess the probability, impact and timing of each risk; update risk scores monthly and conduct quarterly sensitivity analysis to identify risks with highest expected value.
- Develop and track mitigation strategies for the top 10 risks; monitor mitigation effectiveness and recommend escalation if a risk emerges or mitigation fails (e.g., seabed investigation discovers unexpected geology).
- Track cost and schedule exposure from all 19 risks; ensure that the contingency reserve (EUR 7.2 billion) is adequate for the top-risk scenarios; escalate if reserve depletion trends suggest inadequacy.
- Oversee GDPR and data-privacy compliance for personal data processed by the binational authority (payroll, contractor records, maritime traffic data); establish data-governance policies by Month 6 (2027-04-12).
- Oversee ethical and compliance standards: corruption prevention, conflicts of interest, procurement transparency; establish a whistleblower hotline and grievance log by Month 3 (2027-01-12); conduct annual third-party compliance audits.
- Manage supply-chain due diligence: vet all tier-1 contractors for sanctions compliance, labour standards, environmental practices, and conflicts of interest; establish a modern slavery statement and third-party assurance by Month 12 (2027-10-12).
- Prepare quarterly risk-governance reports for the Board and governments; escalate high-severity risks (impact >EUR 500 million, >6-month schedule, or threat to feasibility) within 1 week of detection.

**Initial Setup Actions:**

- Establish the Risk Authority as an independent function, reporting to the Project Board (not the PMO CEO), by Month 1 (2026-11-12); appoint a Head of Risk and Assurance with multinational megaproject and governance experience.
- Develop a Risk Register template and risk-assessment methodology (qualitative and quantitative) by Month 1 (2026-11-12); populate the Register with 19 baseline risks from the assumptions document by Month 1 (2026-11-12).
- Define risk-escalation thresholds: events with >EUR 500 million cost impact, >6-month schedule impact, or threat to programme feasibility escalate within 1 week; escalate to Board within 2 weeks; top 10 risks monitored monthly, full Register reviewed quarterly.
- Establish a Whistleblower Hotline (Month 1–2 = 2026-11-12 to 2026-12-12), governance policies for handling reports, and quarterly summary reporting (anonymized) to the Board.
- Draft a Compliance and Ethics Policy by Month 3 (2027-01-12), covering procurement transparency, conflict-of-interest declaration, supply-chain due diligence and GDPR; Board approval by Month 6 (2027-04-12).

**Membership:**

- Head of Risk and Assurance (senior risk and governance specialist; reports directly to the Board; independently staffed, not reporting to the PMO CEO)
- Risk Manager (day-to-day risk tracking, mitigation monitoring, escalation decisions)
- Compliance and Ethics Officer (GDPR, corruption prevention, whistleblower hotline management, annual compliance audits)
- Supply-Chain Assurance Specialist (vendor due diligence, sanctions compliance, labour and environmental standards verification)

**Decision Rights:** The Risk Authority has authority to: (1) Escalate any risk event with potential impact >EUR 500 million or >6-month schedule to the Board within 1 week of detection; (2) Recommend risk-mitigation actions and corrective-action timelines to the PMO and Board; (3) Request additional contingency reserve allocation if risk sensitivity analysis indicates reserve inadequacy; (4) Halt or delay contractor engagement if due-diligence findings reveal sanctions risk, unresolved legal disputes, or labour-practice concerns; (5) Recommend rejection of a contractor proposal if compliance or ethical concerns are material; (6) Issue a Feasibility Alert if cumulative risk exposure exceeds the programme's ability to deliver within the EUR 40 billion envelope and 20-year horizon (Month 240 = 2046-10-12); (7) Conduct investigations into suspected corruption, conflicts of interest or fraud allegations and report findings to the Board and governments within 30 days.

**Decision Mechanism:** Monthly risk-register update (administered by Risk Manager, no formal vote required; changes documented and reported to the Board). Risk-escalation decisions made by the Head of Risk and Assurance when impact thresholds are exceeded (EUR 500 million, 6-month schedule, or feasibility threat); escalation is automatic within 1 week of risk event or emerging evidence. Whistleblower and compliance reports are reviewed by the Compliance Officer and escalated to the Head of Risk and Assurance; allegations of material misconduct (potential EUR 10 million impact or greater) are escalated to the Board within 5 business days. Contractor due-diligence decisions are made by the Supply-Chain Assurance Specialist in consultation with the Contracts Director; if no resolution within 15 days, matter escalates to the PMO CEO; if unresolved within another 10 days, escalates to the Board.

**Meeting Cadence:** Monthly risk-register review (1–2 hours) internal to the Risk Authority; monthly risk-governance summary (max. 2 pages) issued to the Board by the 10th working day of each month. Quarterly risk-sensitivity analysis and top-10-risks deep dive (1 day) one week before each Board meeting. Annual compliance and ethics audit by an external firm (Month 24, 48, 72 onwards = 2028-10-12, 2030-10-12, 2032-10-12). Quarterly whistleblower report summary (anonymized, 30 minutes) to the Board.

**Typical Agenda Items:**

- Monthly: Risk Register update summary (new risks added, retired risks, probability/impact changes), top-10 risks by expected value, mitigation status, escalation decisions, emerging-risk indicators.
- Quarterly: sensitivity analysis (expected cost/schedule impact of top 10 risks at P50 and P80), contingency reserve adequacy assessment, portfolio-level risk aggregation, Feasibility Alert triggers, top-5 mitigation actions tracking.
- Annual: compliance audit findings and corrective-action status, whistleblower report themes and trends, supply-chain due-diligence effectiveness, contractor-performance and dispute patterns, anti-corruption control effectiveness.

**Escalation Path:** Risk events with impact >EUR 500 million or >6-month schedule automatically escalate from the Risk Manager to the Head of Risk and Assurance, who reports to the Board within 1 week. The Board must respond within 10 days with mitigation direction or contingency allocation. If a risk materializes (e.g., seabed investigation discovers unexpected geology) and the materialized cost or schedule impact exceeds EUR 500 million or 6 months, the event is classified as a Risk Trigger Event and escalates to the Board within 2 working days, with a request for emergency Board session within 5 days if necessary. Feasibility Alert (cumulative risk or cost exposure suggesting programme cannot deliver within EUR 40 billion and Month 240 = 2046-10-12 horizon) escalates to the Board and Ministerial Steering Committee within 2 weeks, with explicit recommendation for scope or schedule adjustment decisions. Whistleblower allegations involving potential fraud or corruption >EUR 10 million escalate to the Board, relevant governments and possibly law enforcement within 5 business days.
### 6. Binational Ecological and Environmental Compliance Committee

**Rationale for Inclusion:** Specialized assurance body responsible for ecological permitting, environmental-baseline compliance, and habitat-mitigation delivery in a marine-megafauna migration corridor protected under Spanish, Moroccan and EU regimes. Environmental consent is often the critical path in infrastructure projects; a multi-year baseline and seasonal timing restrictions can delay construction permitting 18–36 months. Parallel national environmental consents risk regulatory divergence (e.g., Spain requires year-round seasonal buffers, Morocco allows wider windows) that must be reconciled mid-construction, triggering injunctions and stop-work orders. A unified committee, with joint technical teams and a coordinating commission, harmonises consent conditions, manages baseline monitoring, enforces mitigation delivery and schedules construction work to comply with seasonal windows. The committee also coordinates with maritime authorities on shipping-exclusion zones and with the Ecological Permitting lever to ensure gate-readiness evidence.

**Responsibilities:**

- Conduct a joint multi-year ecological baseline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum, with ongoing monitoring through Month 132 = 2037-10-12 opening) covering acoustic signatures, protected-species sightings, current profiles and sediment conditions in the crossing zone.
- Harmonise Spanish and Moroccan environmental assessments (Months 6–30 = 2027-04-12 to 2029-04-12) to identify conflicting mitigation requirements; resolve conflicts through the coordinating commission and escalate to both governments' environmental ministers if consensus fails.
- Prepare a joint environmental consent application (Months 6–24 = 2027-04-12 to 2028-10-12) that satisfies both Spanish and Moroccan regulators; secure harmonised consent by Month 24 (2028-10-12), latest Month 30 (2029-04-12).
- Design and cost ecological mitigation (artificial reef structures on pillars/tethers, long-term marine research partnerships, ferry-emissions offsets); budget EUR 250–400 million; embed mitigation as a binding condition in the consent.
- Schedule immersion and construction activities to respect seasonal windows for protected species (e.g., if migration season is May–September with 150 days/year usable, encode this into the CPM schedule); enforce compliance via a Construction Environmental Manager.
- Coordinate with maritime authorities (IMO, Spanish and Moroccan coast guards) on shipping-exclusion zones and sonar/radar monitoring for the no-anchoring corridor; update IMO vessel-traffic procedures by Month 12 (2027-10-12).
- Monitor construction environmental performance quarterly; track acoustic levels, sediment plumes, and incidental marine-mammal sightings; ensure mitigation delivery on schedule and budget; report to the Board and governments quarterly.

**Initial Setup Actions:**

- Appoint a Binational Ecological Committee lead (international environmental scientist, no national affiliation) and establish a joint technical team (marine biologists, hydrodynamicists, environmental assessment specialists from Spain and Morocco) by Month 1 (2026-11-12).
- Initiate the baseline ecological study (acoustic monitoring, visual surveys, oceanographic data collection) by Month 0 (2026-10-12); deploy seabed seismometers and current meters by Month 9 (2027-07-12); compile first-year data by Month 12 (2027-10-12).
- Draft the joint environmental impact assessment (EIA) based on baseline findings by Month 9 (2027-07-12); conduct stakeholder consultation (fishing communities, NGOs, local governments) by Month 12 (2027-10-12); finalize EIA by Month 18 (2028-04-12).
- Establish a Construction Environmental Manager role (joint Spanish–Moroccan team) by Month 24 (2028-10-12); this manager has authority to halt immersion work if seasonal windows are breached or mitigation conditions are violated.
- Negotiate mitigation partnerships (artificial reef design, research institutions) by Month 18 (2028-04-12); finalize mitigation scope and budget by Month 24 (2028-10-12); begin design of artificial reef structures by Month 30 (2029-04-12).

**Membership:**

- Binational Ecological Committee Lead (international environmental expert, independent, appointed jointly by Spanish and Moroccan environment ministries; reports to the Committee and the Board)
- Spanish Environmental Authority Representative (Spanish Ministry of Environment or equivalent; leads Spanish national EIA process and consent)
- Moroccan Environmental Authority Representative (Moroccan Ministry of Environment or equivalent; leads Moroccan national EIA process and consent)
- Marine Biologist and Hydrodynamicist (technical experts conducting baseline monitoring and impact assessment)
- NGO and Stakeholder Representative (liaison to environmental groups, fishing and port communities, ensuring transparency and co-design of consent conditions; non-voting member)
- Construction Environmental Manager (appointed Month 24 = 2028-10-12; enforces seasonal windows and mitigation compliance during construction)

**Decision Rights:** The Ecological Committee has authority to: (1) Determine acceptable seasonal windows for construction (e.g., May–September only, 150 days/year) based on baseline findings; encode these windows into the CPM schedule; (2) Design mitigation measures and cost estimates; recommend to the Board for approval and budget allocation within the EUR 7.2 billion contingency; (3) Recommend rejection of a permit application if baseline findings show unacceptable risk to protected species; escalate to the Board for override decision; (4) Require additional baseline data collection if findings are inconclusive; extend baseline timeline and gate dates if necessary (with Board approval); (5) Halt construction work if seasonal windows are breached or mitigation conditions are violated; the halt order stands for up to 30 days, during which the PMO must respond with corrective actions or Board escalation.

**Decision Mechanism:** Monthly baseline-data reviews and quarterly environmental-compliance audits (internal to the Committee, no formal vote). Environmental consent decisions made jointly by the Spanish and Moroccan environmental authority representatives; if they cannot reach consensus on permit conditions, the Ecological Committee Lead issues a recommendation to both governments' environment ministers within 15 days; the ministers have 10 days to decide; if they diverge, the matter escalates to the Binational Project Board for political resolution. Mitigation design and cost approval follow PMO change-control processes: changes <EUR 50 million can be approved by the Committee Lead with Board notification; changes >EUR 50 million require Board approval. Construction Environmental Manager halt orders are issued verbally within 24 hours of detection of a violation, with written justification within 48 hours; the halt stands until the PMO takes corrective action or escalates to the Board for risk acceptance.

**Meeting Cadence:** Monthly baseline-data and environmental-monitoring review (1–2 hours) during Months 0–12 (2026-10-12 to 2027-10-12); quarterly environmental-compliance audit (1 day) during construction phases (Months 36–132 = 2029-10-12 to 2037-10-12). Coordinated national EIA process meetings (monthly, Months 6–24 = 2027-04-12 to 2028-10-12). Harmonisation committee (every 2 weeks, Months 6–30 = 2027-04-12 to 2029-04-12) if Spanish and Moroccan consent conditions diverge.

**Typical Agenda Items:**

- Monthly baseline review: acoustic data quality, protected-species sightings (by species, date, location), hydrodynamic measurements, data-quality issues, sampling adjustments.
- Quarterly construction audit: immersion activity log (dates, locations, duration), seasonal-window usage (days spent vs. annual budget), mitigation delivery (artificial reef progress, research partnerships, acoustic monitoring), permit-condition compliance, incident reports.
- EIA development: baseline-findings summary, impact assessment methodology, draft permit conditions, mitigation design, stakeholder-consultation feedback.

**Escalation Path:** Environmental permit-condition disagreement between Spanish and Moroccan authorities escalates from the Ecological Committee to both environment ministries within 15 days; ministerial decision within 10 days; if ministers diverge, matter escalates to the Binational Project Board within 5 days for binding decision. Construction Environmental Manager halt orders (environmental violation detected) escalate to the PMO CEO within 24 hours; the halt stands until corrective action is taken or the Board accepts the risk (within 15 days). A halt order that exceeds 15 days or affects more than one immersion campaign escalates to the Board within 1 week, with a request for emergency Board session if the halt threatens the schedule. Baseline findings that show material change in environmental conditions (e.g., new protected-species congregation, shift in migration timing) escalate to the Ecological Committee Lead within 5 days of detection; escalate to the Board within 10 days if the finding materially changes permit conditions or mitigation scope.

# Governance Implementation Plan

### 1. Project Sponsor establishes a Governance Setup Team (Spanish and Moroccan government representatives, legal counsel, international advisor) to draft governance charters, ToRs and appointment protocols for the five internal governance bodies. This team will prepare all foundational governance documents for Board and government approval.

**Responsible Body/Role:** Project Sponsor (Spanish and Moroccan governments, represented by Transport Ministry delegates and Chief Legal Advisors)

**Suggested Timeframe:** Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Governance Setup Team roster and appointment letter
- High-level governance-implementation timeline and dependencies map
- Draft charter template for each of the five governance bodies

**Dependencies:**

- Project start authorization from both governments (Month 0 = 2026-10-12)

### 2. Governance Setup Team drafts Terms of Reference (ToR) and Charter for the Binational Project Board, including Board composition (Spanish director, Moroccan director, independent Chair), decision rules (majority vote, tie-breaker authority), meeting cadence (monthly, escalating to quarterly), and delegation thresholds (CEO approval <2% variance, Board 2–5%, >5% political escalation). Includes risk acceptance and cost authority limits.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Binational Project Board Charter v0.1
- Draft Binational Project Board ToR (roles, responsibilities, decision matrix, escalation rules)
- Proposed Board composition and appointment criteria

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 3. Governance Setup Team drafts Terms of Reference and Charter for the Project Management Office (PMO) and Core Delivery Team, covering the Chief Executive Officer role, Core Team composition (Directors of Controls, Engineering, Contracts, Environmental, Rail Integration, Risk), delegation authority, design-change-control procedures, and reporting lines to the Project Board.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor and senior delivery advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft PMO and Core Delivery Team Charter v0.1
- Draft PMO ToR (roles, responsibilities, delegation thresholds, reporting)
- Draft Design Change Control Board (DCCB) charter and monthly agenda template

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 4. Governance Setup Team drafts Terms of Reference and Charter for the Independent Cost Authority, covering reporting directly to the Project Board (not the PMO), earned-value tracking, contingency-reserve management, cost-to-complete forecasting (P50/P80), variance escalation thresholds (>5% of tranche), and contractor-invoice audit authority. Emphasizes independence from operational management.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Financial Officer or independent finance advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Independent Cost Authority Charter v0.1
- Draft Cost Authority ToR (scope, reporting, decision authority, escalation rules)
- Cost-baseline and contingency-reserve definition (EUR 7.2 billion; civil 20%, rail systems 15%, operations 10%)

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)
- Budget envelope (EUR 40 billion) confirmed (user constraint)

### 5. Governance Setup Team drafts Terms of Reference and Charter for the Design Basis and Independent Certification Panel, covering the Lead Certifier role, Technical Advisory Panel composition, gate-certification processes (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12), design-code development, and certification decision authority. Clarifies that the Lead Certifier reports to the Project Board, not to national authorities.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's senior technical advisor or international engineering consultant)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Design Basis and Certification Panel Charter v0.1
- Draft Lead Certifier role description and appointment criteria
- Draft Technical Advisory Panel charter and expertise matrix
- Preliminary gate-certification process flow and criteria template

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 6. Governance Setup Team drafts Terms of Reference and Charter for the Risk and Assurance Authority, covering the Head of Risk and Assurance role, risk-register management, escalation thresholds (>EUR 500 million impact or >6-month schedule), compliance and ethics oversight, supply-chain due diligence, GDPR, and whistleblower hotline. Emphasizes direct Board reporting and independence.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Risk Officer or independent governance advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Risk and Assurance Authority Charter v0.1
- Draft Risk Authority ToR (scope, decision authority, escalation rules, compliance mandate)
- Draft Risk Register template and assessment methodology (qualitative and quantitative)
- Draft Compliance and Ethics Policy (conflicts of interest, procurement transparency, whistleblower process)

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 7. Governance Setup Team drafts Terms of Reference and Charter for the Binational Ecological and Environmental Compliance Committee, covering the Committee Lead role, joint Spanish–Moroccan technical teams, baseline monitoring coordination, environmental-consent harmonization process, seasonal-window enforcement, and Construction Environmental Manager role. Defines escalation to environmental ministers and the Project Board.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's environmental advisor or Spanish/Moroccan environment ministry delegate)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Ecological Committee Charter v0.1
- Draft Ecological Committee ToR (baseline, consent harmonization, mitigation, seasonal enforcement)
- Draft baseline-study scope and timeline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum continuous monitoring through Month 132 = 2037-10-12)
- Draft harmonization protocol for Spanish and Moroccan environmental assessments

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 8. Project Sponsor (and Governance Setup Team) circulates all five draft governance charters and ToRs for review by nominated government representatives, legal counsel, lenders and international partners. Collect and consolidate feedback within 3 weeks.

**Responsible Body/Role:** Project Sponsor (represented by Governance Setup Team)

**Suggested Timeframe:** Week 1–3 of Month 1 (2026-11-12 to 2026-11-26)

**Key Outputs/Deliverables:**

- Feedback summary report (consolidated from all stakeholders)
- Revision log identifying substantive comments and proposed changes to charters

**Dependencies:**

- All five draft charters completed (Month 0–1 = 2026-10-12 to 2026-11-12)

### 9. Governance Setup Team incorporates feedback into revised governance charters and ToRs. Finalizes all five charters for Project Sponsor approval and Board adoption.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor)

**Suggested Timeframe:** Week 4 of Month 1 (2026-11-12) through Month 1 (2026-11-12 to end of month)

**Key Outputs/Deliverables:**

- Binational Project Board Charter v1.0 (final, ready for adoption)
- PMO and Core Delivery Team Charter v1.0 (final)
- Independent Cost Authority Charter v1.0 (final)
- Design Basis and Certification Panel Charter v1.0 (final)
- Risk and Assurance Authority Charter v1.0 (final)
- Ecological Committee Charter v1.0 (final)
- Adoption-readiness summary for Project Sponsor

**Dependencies:**

- Stakeholder feedback received (Month 1 = 2026-11-12 week 1–3 = 2026-11-12 to 2026-11-26)

### 10. Project Sponsor formally adopts all five governance charters and ToRs. Spanish and Moroccan transport ministries issue joint adoption decree, confirming that governance framework is in effect and all bodies are authorized to be established. This step formally legitimizes the governance structure at the highest political level.

**Responsible Body/Role:** Project Sponsor (Spanish Minister of Transport and Moroccan Minister of Transport, or equivalents, via joint decree)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Joint Spanish–Moroccan Governance Adoption Decree (signed by both transport ministers)
- Published governance charters and ToRs (available to stakeholders)

**Dependencies:**

- All five charters finalized v1.0 (Month 1 = 2026-11-12)

### 11. Project Sponsor nominates and formally appoints the independent Chair of the Binational Project Board. The Chair must be an international maritime/tunnel engineering expert with no affiliation to either government. Publish appointment announcement and Chair biography.

**Responsible Body/Role:** Project Sponsor (Spanish and Moroccan transport ministers, acting jointly)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Binational Project Board Chair (4-year term, renewable once)
- Chair biography and statement of independence
- Public announcement of Chair appointment

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- International-expert recruitment process completed

### 12. Project Sponsor nominates and formally appoints the Spanish and Moroccan directors of the Binational Project Board. Spanish director appointed by Spanish transport minister; Moroccan director appointed by Moroccan transport minister. Publish appointment announcements.

**Responsible Body/Role:** Project Sponsor: Spanish transport minister (for Spanish director); Moroccan transport minister (for Moroccan director)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Spanish Project Board Director
- Appointment letter: Moroccan Project Board Director
- Public announcements of both director appointments

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- Nomination and vetting completed by each transport ministry

### 13. Project Sponsor nominates a Chief Executive Officer (CEO) of the PMO. The CEO is the senior executive responsible for day-to-day project delivery, cost control, schedule management and reporting to the Binational Project Board. Typically an experienced megaproject delivery leader with multinational experience. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Chair of the Binational Project Board, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Project Management Office Chief Executive Officer
- CEO biography and statement of qualifications
- Public announcement of CEO appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment process for megaproject experience completed

### 14. Project Sponsor nominates and formally appoints the Chief Financial Officer (head of the Independent Cost Authority). The CFO must be an independent financial specialist with no affiliation to either government or the delivery contractor, and must report directly to the Project Board. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Independent Cost Authority Chief Financial Officer
- CFO biography and independence declaration
- Public announcement of CFO appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International-expert recruitment (finance/audit/megaproject experience) completed

### 15. Project Sponsor nominates and formally appoints the Lead Certifier for the Design Basis and Independent Certification Panel. The Lead Certifier is typically a classification society (DNV-GL, ABS, Lloyds Register or equivalent) or international consortium of independent technical experts with authority to certify design against a project-specific code. Lead Certifier reports to the Project Board, not to national authorities. Publish contract and announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Contract: Lead Certifier appointment (2-year initial term, renewable; scope, reporting, decision authority)
- Lead Certifier organization profile and team assignment
- Public announcement of Lead Certifier contract award

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- International procurement process for Lead Certifier completed

### 16. Project Sponsor nominates and formally appoints the Head of Risk and Assurance Authority. This person is an independent risk and governance specialist, reporting directly to the Project Board, responsible for comprehensive risk management, compliance, ethics and supply-chain due diligence. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Head of Risk and Assurance Authority
- Risk Authority head biography and independence declaration
- Public announcement of Risk Authority head appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment (risk management, governance, megaproject experience) completed

### 17. Project Sponsor nominates and formally appoints the Binational Ecological Committee Lead. This person is an international environmental scientist with no national affiliation, responsible for coordinating joint ecological baseline, harmonizing Spanish and Moroccan environmental assessments, and managing mitigation delivery. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Spanish and Moroccan environment ministries jointly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Binational Ecological Committee Lead
- Ecological Committee Lead biography and independence declaration
- Public announcement of Ecological Committee Lead appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment (marine ecology, environmental permitting, Strait of Gibraltar expertise) completed

### 18. PMO Chief Executive Officer (appointed by Month 2 = 2026-12-12) establishes the Core Delivery Team. The CEO recruits or nominates the six core Directors: Project Controls and Finance, Engineering and Design, Contracts and Procurement, Environmental and Ecological Compliance, Rail Integration and Operations Planning, and Risk and Assurance (the latter reports to the Risk Authority, not the CEO). Publish organizational chart and team roster.

**Responsible Body/Role:** Project Management Office Chief Executive Officer

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- PMO organizational chart (CEO + six core Directors + supporting staff)
- Roster of Core Delivery Team members (names, roles, reporting lines)
- Job descriptions for each Director role
- Signed acceptance of appointment by each Director

**Dependencies:**

- PMO Chief Executive Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 19. Independent Cost Authority Chief Financial Officer (appointed by Month 2 = 2026-12-12) establishes the Cost Authority team. The CFO recruits or nominates the four supporting staff: Controller (cost baseline and earned-value), Finance Manager (invoice audit), Cost Engineer (design-change impact), and Schedule Analyst (critical-path variance and weather windows). Publish organizational chart and team roster.

**Responsible Body/Role:** Independent Cost Authority Chief Financial Officer

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Cost Authority organizational chart (CFO + four supporting staff)
- Roster of Cost Authority staff (names, roles, reporting lines)
- Job descriptions for each role (Controller, Finance Manager, Cost Engineer, Schedule Analyst)
- Signed acceptance of appointment by each staff member

**Dependencies:**

- Independent Cost Authority Chief Financial Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 20. Lead Certifier (appointed by Month 3 = 2027-01-12) forms the Technical Advisory Panel for the Design Basis and Certification Panel. Lead Certifier nominates the Panel Chair and 4–6 technical experts covering offshore structures, seismic/geotechnical engineering, railway safety, and emergency response. Panel Chair has no national affiliation. Lead Certifier also confirms appointment of Spanish and Moroccan technical authority observers (non-voting). Publish Panel roster and biographical information.

**Responsible Body/Role:** Lead Certifier (classification society or independent technical consortium)

**Suggested Timeframe:** Month 1–4 (2026-11-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Technical Advisory Panel charter (final, signed by Lead Certifier)
- Panel Chair appointment letter and biography
- Roster of 4–6 technical experts (names, affiliations, expertise areas, declared independence)
- Appointment confirmations: Spanish and Moroccan technical authority observers
- Public announcement of Panel formation

**Dependencies:**

- Lead Certifier appointed (Month 1–3 = 2026-11-12 to 2027-01-12)

### 21. Binational Ecological Committee Lead (appointed by Month 2 = 2026-12-12) establishes the joint Spanish–Moroccan ecological technical team. Lead nominates or recruits: marine biologist, hydrodynamicist, Spanish environmental authority representative, Moroccan environmental authority representative, and NGO/stakeholder liaison (non-voting). Publish team roster and charter.

**Responsible Body/Role:** Binational Ecological Committee Lead

**Suggested Timeframe:** Month 1–4 (2026-11-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Ecological Committee charter (final, signed by Lead)
- Roster of joint technical team (names, affiliations, roles)
- Appointment confirmations: Spanish environmental authority, Moroccan environmental authority
- NGO/stakeholder liaison appointment letter
- Public announcement of Ecological Committee formation

**Dependencies:**

- Binational Ecological Committee Lead appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 22. Binational Project Board holds its inaugural meeting. Formal constitution of the Board: Chair, Spanish director, Moroccan director (three voting members), and EU/multilateral-lender observer (non-voting) all confirmed present. Chair outlines the Board's mandate, decision rules, delegation authority and escalation protocols. Board approves the monthly meeting schedule starting Month 2 (2026-12-12). This meeting formally establishes the Board as operationally active.

**Responsible Body/Role:** Binational Project Board (Chair, Spanish Director, Moroccan Director)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Binational Project Board inaugural meeting minutes (including attendance, role confirmations, approved schedule)
- Board decision register (action items, owners, due dates)
- Approved monthly Board meeting calendar (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Board Chair appointed (Month 1–2 = 2026-11-12 to 2026-12-12)
- Spanish and Moroccan directors appointed (Month 1–2 = 2026-11-12 to 2026-12-12)
- Governance charters formally adopted (Month 1 = 2026-11-12)

### 23. Project Management Office holds its inaugural Core Delivery Team kickoff meeting. CEO chairs; all six Directors present (Controls & Finance, Engineering & Design, Contracts & Procurement, Environmental, Rail Integration, Risk & Assurance). CEO outlines the governance framework, delegation authority, change-control thresholds, and reporting lines. Core Team approves weekly standup, monthly DCCB, monthly risk review, and monthly cost-control meeting schedules. This meeting formally establishes the PMO as operationally active.

**Responsible Body/Role:** Project Management Office (CEO and six core Directors)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- PMO Core Delivery Team inaugural meeting minutes (attendance, role confirmations, approved schedules)
- PMO decision register and action-item log (owners, due dates)
- Approved meeting schedules: weekly standup, monthly DCCB, monthly risk review, monthly cost-control review (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- PMO Chief Executive Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Core Delivery Team (six Directors) nominated and confirmed (Month 1–3 = 2026-11-12 to 2027-01-12)

### 24. Independent Cost Authority holds its inaugural meeting. CFO chairs; all supporting staff present (Controller, Finance Manager, Cost Engineer, Schedule Analyst). CFO outlines the Cost Authority's independence, reporting directly to the Board (not the PMO CEO), cost-baseline definition, contingency-reserve management, earned-value-tracking methodology, variance-escalation thresholds (>5% of tranche), and quarterly cost-to-complete forecasting at P50/P80. Approves monthly and quarterly review schedules.

**Responsible Body/Role:** Independent Cost Authority (Chief Financial Officer and supporting staff)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Cost Authority inaugural meeting minutes (attendance, role confirmations, approved schedules)
- Cost-baseline definition document (budget allocation by tranche and phase, contingency reserve EUR 7.2 billion breakdown)
- Cost-tracking methodology and systems description
- Approved review schedules: monthly earned-value summary, quarterly cost-to-complete forecast, annual audit cycle (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Independent Cost Authority Chief Financial Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Cost Authority supporting staff nominated (Month 1–3 = 2026-11-12 to 2027-01-12)

### 25. Design Basis and Certification Panel (Lead Certifier and Technical Advisory Panel) holds its inaugural meeting. Lead Certifier and Panel Chair chair; all Panel members and observers present. Lead Certifier outlines the Panel's mandate: develop project-specific design code, establish certification gates (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12), define gate-certification criteria, oversee prototype testing and seismic/geotechnical input. Panel approves monthly design-review and quarterly panel-audit schedules starting Month 3 (2027-01-12).

**Responsible Body/Role:** Design Basis and Certification Panel (Lead Certifier, Panel Chair, technical members, Spanish and Moroccan authority observers)

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Lead Certifier and Panel inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Panel operating procedures (design-review frequency, gate-certification process, decision-making, escalation)
- Preliminary gate-certification criteria template (to be detailed at Month 9 = 2027-07-12)
- Approved monthly and quarterly meeting schedules (Months 3–12 = 2027-01-12 to 2027-10-12+ = 2027-01-12 to 2027-10-12+)

**Dependencies:**

- Lead Certifier appointed (Month 1–3 = 2026-11-12 to 2027-01-12)
- Technical Advisory Panel formed (Month 1–4 = 2026-11-12 to 2027-02-12)

### 26. Risk and Assurance Authority holds its inaugural meeting. Head of Risk and Assurance chairs; all supporting staff present (Risk Manager, Compliance & Ethics Officer, Supply-Chain Assurance Specialist). Head outlines the Authority's independence (reporting to the Board, not the PMO), risk-register management, escalation thresholds (>EUR 500 million impact, >6-month schedule, feasibility threat), compliance and ethics mandate, GDPR and whistleblower hotline, and supply-chain due-diligence protocols. Approves monthly risk-review, quarterly sensitivity analysis, and annual audit schedules.

**Responsible Body/Role:** Risk and Assurance Authority (Head of Risk and Assurance and supporting staff)

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Risk Authority inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Risk Register v1.0 (baseline: 19 risks from assumptions document, initial qualitative assessment)
- Risk-assessment methodology (probability, impact, timing; expected-value calculation)
- Escalation and decision matrix (thresholds, owners, timelines)
- Compliance and Ethics Policy (conflicts of interest, procurement transparency, whistleblower hotline, GDPR)
- Approved monthly and quarterly review schedules (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Head of Risk and Assurance Authority appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 27. Binational Ecological Committee holds its inaugural meeting. Committee Lead chairs; Spanish environmental authority, Moroccan environmental authority, marine biologist, hydrodynamicist, and NGO/stakeholder liaison present. Lead outlines the Committee's mandate: conduct joint baseline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum), harmonize national EIAs (Months 6–24 = 2027-04-12 to 2028-10-12), secure harmonised consent (Month 24 = 2028-10-12 target), design and cost mitigation, schedule construction to seasonal windows, coordinate with maritime authorities on shipping exclusion zones. Approves baseline-study protocols and national harmonization committee schedule (monthly, Months 6–24 = 2027-04-12 to 2028-10-12).

**Responsible Body/Role:** Binational Ecological Committee (Lead, Spanish authority, Moroccan authority, technical experts, NGO liaison)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Ecological Committee inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Baseline-study work plan (acoustic monitoring, visual surveys, oceanographic data, sampling schedule, vessel requirements)
- Environmental-impact assessment framework and timeline (Months 6–24 = 2027-04-12 to 2028-10-12)
- Harmonization protocol: Spanish–Moroccan EIA reconciliation process
- Approved monitoring and compliance meeting schedule (Months 0–12 = 2026-10-12 to 2027-10-12 baseline, then quarterly during construction)

**Dependencies:**

- Binational Ecological Committee Lead appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Spanish and Moroccan environmental authority representatives nominated

### 28. PMO Chief Executive Officer establishes a Governance Setup Team wind-down and transition. Governance Setup Team (initial interim body) transfers all governance documents, meeting records, and member rosters to the PMO Director of Controls and the Risk Authority Head of Assurance for ongoing governance administration. Governance Setup Team formally dissolves, having completed its transient mission to establish all five bodies.

**Responsible Body/Role:** Project Management Office CEO (in coordination with the Governance Setup Team lead and Risk Authority Head)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Governance-administration handoff memo (transfer of responsibility from Setup Team to PMO and Risk Authority)
- Consolidated governance document repository (all charters, ToRs, meeting minutes, member rosters)
- Governance Setup Team dissolution notice (confirming completion of mission)

**Dependencies:**

- All five governance bodies formally established and holding inaugural meetings (Month 1–3 = 2026-11-12 to 2027-01-12)

### 29. Binational Project Board holds its first operational month-end review meeting (Month 1 end = 2026-11-12 end, convene early Month 2 = 2026-12-12). Board reviews: (1) governance-body establishment status (all five bodies formally constituted?); (2) CEO and leadership-appointment confirmations; (3) project-start ASAP actions initiated (seabed campaign, treaty negotiation, ecological baseline, governance setup); (4) CPM schedule development status (due Month 1 = 2026-11-12); (5) risk register (baseline 19 risks populated); (6) forward-looking agenda (gate readiness, cost baseline, tranche-release readiness).

**Responsible Body/Role:** Binational Project Board (Chair, Spanish Director, Moroccan Director, EU observer)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Binational Project Board Month 1 (2026-11-12) end review meeting minutes
- Governance-establishment status report (all bodies constituted: yes/no, any open actions)
- Project-status dashboard (seabed, treaty, ecology, governance progress vs. Month 0–1 = 2026-10-12 to 2026-11-12 plan)
- Risk register review (19 baseline risks, top 5 high-severity risks, escalations identified)

**Dependencies:**

- All five governance bodies formally constituted and inaugural meetings held (Month 1–3 = 2026-11-12 to 2027-01-12)
- Seabed campaign initiated (Month 0 = 2026-10-12)
- Treaty negotiation team established (Month 0 = 2026-10-12)

### 30. All five governance bodies transition from establishment (startup) phase to operational phase. Each body begins its defined recurring meetings and starts executing its core responsibilities: (1) PMO Core Team: weekly standups, monthly design-change and cost-control reviews; (2) Cost Authority: monthly earned-value tracking, quarterly cost-to-complete forecasting; (3) Certification Panel: monthly design reviews with engineering teams; (4) Risk Authority: monthly risk tracking, quarterly sensitivity analysis; (5) Ecological Committee: baseline-data collection, EIA development. This step marks the formal operational launch of the governance system.

**Responsible Body/Role:** All five governance bodies (Binational Project Board, PMO Core Team, Cost Authority, Certification Panel, Risk Authority, Ecological Committee) operating independently and in coordination

**Suggested Timeframe:** Month 2 onwards (2026-12-12 and continuing)

**Key Outputs/Deliverables:**

- Monthly status reports from each governance body (PMO, Cost Authority, Certification, Risk, Ecology)
- First monthly PMO standup meeting minutes and action log
- First monthly Cost Authority earned-value report
- First monthly Risk Authority register update
- First monthly Ecological Committee baseline-data progress report

**Dependencies:**

- All five governance bodies formally constituted (Month 1–3 = 2026-11-12 to 2027-01-12)
- Inaugural meetings held and operating procedures approved (Month 1–3 = 2026-11-12 to 2027-01-12)
- Project sponsor funding and authorization confirmed (Month 0 = 2026-10-12)

# Decision Escalation Matrix

**Unresolved Support Concept and Seabed-Depth Conflict Affecting Design Feasibility and Cost**
Escalation Level: Binational Project Board
Approval Process: The Project Board reviews independent seabed-investigation findings and geotechnical engineering assessment at the Month 18 (2028-04-12) gate, with a formal recommendation from the Design Basis and Certification Panel on support-concept feasibility. The Board issues a go/no-go decision on concept freeze by Month 24 (2028-10-12). If seabed data contradicts the original plan (e.g., pillars prove infeasible beyond 300 m depth), the Board decides between: (a) adopting hybrid concept (pillars on sills, tethers in deep channels); (b) extending the seabed campaign; (c) escalating to the Ministerial Steering Committee if scope reduction or timeline extension is needed.
Rationale: The plan states '100 m anchoring depth' but published Strait bathymetry shows depths of several hundred to ~900 m. The choice between pillar-only, tether-only, or hybrid structural concepts is fundamental to cost (EUR 4–8 billion variance), timeline (12–36 months delay) and installation method. Early commitment to a single concept without seabed survey data makes a wrong choice irreversible once seabed works begin. The seabed campaign (Months 0–18 = 2026-10-12 to 2028-04-12) must resolve this before the Month 24 (2028-10-12) concept-freeze gate.
Negative Consequences: If the depth conflict is not resolved before major capital commitment, a mid-construction redesign could cost EUR 4–8 billion and delay immersion by 12–36 months, consuming 56–111% of the EUR 7.2 billion contingency reserve. Such overruns would either force scope reduction (shortened crossing, deferred systems, phased opening), schedule extension past Month 240 (2046-10-12) horizon, or demand for additional sovereign guarantees at unfavourable terms. Lender and insurer confidence would collapse if a restructured concept emerges during fabrication.

**Binational Treaty Ratification Delay or Governance Authority Not Established by Contract Close**
Escalation Level: Ministerial Steering Committee (Spanish and Moroccan Transport Ministers plus EU Observer)
Approval Process: A binational negotiation team (appointed Month 1 = 2026-11-12) targets treaty ratification by Month 12 (2027-10-12) with ministerial commitment. If ratification slips beyond Month 15 (2028-01-12), the matter escalates to the Ministerial Steering Committee (transport ministers of Spain and Morocco, EU representative) for political resolution. The committee issues a decision (within 10 days) either to: (a) accelerate ratification by specific date; (b) accept a governance framework that does not require full treaty ratification (e.g., executive agreement); or (c) halt main-construction-tranche release and revise the programme schedule. Any decision to proceed without treaty or with altered governance is documented and binding on the project.
Rationale: The project requires a treaty-backed authority with legal personality, Board with tie-breaking power, single technical regulator and single lead certifier by Month 12 (2027-10-12), target Month 15 (2028-01-12). A stop rule applies: if treaty is not ratified by Month 24 (2028-10-12), the EUR 20 billion main-construction tranche (including EUR 2–5 billion casting-yard advance) is not released and no casting-yard construction commitment is made. Delays in treaty negotiation, sovereignty disputes over procurement authority, or regulatory misalignment create decision-cycle gridlock (estimated 3–6 months per design change if consensus-based, versus 2–4 weeks if delegated). These delays cascade through design, permitting and fabrication schedules.
Negative Consequences: Treaty delay to Month 24 (2028-10-12) compresses the immersion schedule from ~100 months to 80–90 months, requiring segment production rates 25–50% above baseline (175+ m/month vs. 140 m/month), a productivity increase not demonstrated in deep-water marine construction. Regulatory misalignment (e.g., conflicting seismic standards) could add 6–12 months per design iteration. If treaty ratification fails entirely, the project cannot borrow, contract or regulate; lenders and insurers withdraw; the programme is abandoned and EUR 0.5–2 billion (Months 0–12 = 2026-10-12 to 2027-10-12 and 12–24 tranches) are unrecoverable sunk costs.

**Cumulative Cost Overrun Exceeding the EUR 7.2 Billion Contingency Reserve or Variance >5% of Current Tranche**
Escalation Level: Binational Project Board (with escalation to Ministerial Steering Committee if response is scope or schedule adjustment)
Approval Process: The Independent Cost Authority conducts monthly earned-value analysis and quarterly cost-to-complete forecasting (P50 and P80 confidence). If variance exceeds 5% of a tranche, the Cost Authority Chief Financial Officer escalates to the Board in writing within 5 days, with independent cost-to-complete analysis and corrective-action options. The Board must respond within 10 days with: (a) acceptance of the variance and reforecast; (b) direction to the PMO to implement corrective actions within a defined timeline; or (c) decision to reallocate contingency reserves. If cumulative overrun threatens the EUR 40 billion envelope (e.g., EUR 2.8–10.8 billion gap identified by Month 36–48 = 2029-10-12 to 2030-10-12), the Board escalates to the Ministerial Steering Committee with a recommendation for scope or schedule adjustment, additional funding, or programme cancellation.
Rationale: The project has a fixed EUR 40 billion envelope with an estimated EUR 7.2 billion (18%) contingency reserve. Plausible overrun sources include support-concept uncertainty (EUR 4–8 billion), seabed surprises (EUR 500 million–2 billion), dual-yard rework (EUR 500 million–1.5 billion), contractor claims (EUR 1–3 billion), and 20-year inflation (40–80% cumulative at 2–3% annually). First-of-kind marine megaprojects routinely exceed budgets by 20–40%. The Independent Cost Authority escalates any variance >5% of the current tranche to the Board within 5 business days.
Negative Consequences: If cost overruns of EUR 10–18 billion (25–45% of envelope) materialize by Month 36–48 (2029-10-12 to 2030-10-12), the contingency reserve is depleted and an unfunded gap of EUR 2.8–10.8 billion remains. The project then faces: (a) scope reduction (shortened crossing, deferred systems, phased opening, losing project value); (b) schedule extension past Month 240 (2046-10-12), violating the 20-year horizon; (c) demand for additional sovereign guarantees at unfavourable terms, straining public budgets; or (d) programme cancellation after EUR 4–8 billion sunk costs (Months 0–36 = 2026-10-12 to 2029-10-12 tranches).

**Environmental Consent Divergence or Seasonal-Window Constraint Threatening Schedule Feasibility**
Escalation Level: Binational Ecological and Environmental Compliance Committee, with escalation to Ministerial Steering Committee (Environment Ministers) if Consent Divergence Cannot Be Resolved
Approval Process: The Ecological Committee conducts a joint baseline starting Month 0 (2026-10-12), with first deliverable by Month 9 (2027-07-12) and 12 months of continuous data by Month 12 (2027-10-12). Parallel national EIAs are harmonized through a coordinating committee (monthly meetings, Months 6–24 = 2027-04-12 to 2028-10-12). If Spanish and Moroccan environmental authorities cannot reach consensus on permit conditions, the Ecological Committee Lead issues a recommendation to both environment ministries within 15 days; the ministers have 10 days to decide. If ministers diverge, the matter escalates to the Binational Project Board within 5 days for political resolution. Any resolution that restricts construction windows further or extends the baseline must be escalated to the Board immediately, with a CPM schedule re-baseline showing whether immersion can still complete by Month 120 (2036-10-12) baseline or whether the 20-year horizon is at risk.
Rationale: The Strait of Gibraltar is a marine-megafauna migration corridor protected under Spanish, Moroccan and EU regimes. A joint baseline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum, ongoing to Month 132 = 2037-10-12 opening) must inform harmonised environmental consents by Month 24 (2028-10-12), latest Month 30 (2029-04-12). Parallel national assessments risk divergent conditions (e.g., Spain requires year-round seasonal buffers, Morocco allows wider windows) that must be reconciled or trigger legal injunctions. Seasonal construction windows (estimated 60–90 days/year usable immersion) directly constrain immersion timeline: 14 km of tunnel may require 8.75–14 years of immersion at baseline productivity rates. If ecological conditions further restrict windows, immersion schedule compresses and squeezes other phases (design, fabrication, commissioning).
Negative Consequences: Sequential environmental consent (one state at a time) delays permits 24–36 months, pushing concept freeze and design start. Divergent parallel consents require 12–18 months of reconciliation or trigger legal injunctions and stop-work orders (3–6 month delays per challenge). Tighter seasonal windows (e.g., 60 days/year instead of 90) reduce immersion rate by 33%, extending 14 km immersion from ~9 years to ~14 years, which leaves only 6 years for fabrication, casting-yard build and ramp-up (Months 24–120 = 2028-10-12 to 2036-10-12 = 96 months total). This schedule is infeasible given the CPM critical path. Environmental injunctions or conditions undiscovered until Month 60–80 (2031-10-12 to 2033-10-12) could halt immersion for 6–12 months, stranding completed segments and forcing cost recovery or write-offs.

**Critical Design Certification Finding Unresolved at a Major Gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) Blocking Design Freeze or Construction Authority**
Escalation Level: Binational Project Board, with potential escalation to Ministerial Steering Committee if Finding Represents Material Safety or Feasibility Threat
Approval Process: At each gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12), the design team submits a design package to the Lead Certifier 6 weeks before the gate date. The Lead Certifier conducts technical review (typically 4–6 weeks) and issues either a Certification Letter (design approved) or a Finding Letter (outstanding items requiring resolution). If findings are identified, the design team has 2 weeks to respond with corrective actions or justification. The Lead Certifier re-reviews and issues either approval or a recommendation for Board escalation. Non-minor findings (safety impact, cost >EUR 500 million, schedule >6 months) are escalated to the Board within 2 weeks of gate submission. The Board has 10 days to decide: (a) approve gate despite finding (documented with Board rationale, reported to both governments); (b) hold gate open until finding is closed; or (c) require additional testing or study (extending the gate timeline). Only a unanimous Board vote (Spanish director, Moroccan director and Chair all voting yes) can approve a gate with open non-minor findings.
Rationale: A structure with no international design-code precedent must be certified by a Lead Certifier and Technical Advisory Panel working from a project-specific design code (to be drafted by Month 9 = 2027-07-12). Certification gates are scheduled at Months 9, 18, 30 and 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12). If the Lead Certifier identifies a non-minor finding (material impact on safety, cost >EUR 500 million, or schedule >6 months), the gate may not proceed without Board resolution. Unresolved findings at late gates (e.g., Month 42 = 2030-04-12, after fabrication has begun) force costly mid-production design changes, rework and delays. Lenders and insurers require a clean certification path; unresolved findings undermine financing confidence.
Negative Consequences: A non-minor certification finding at Month 18 (2028-04-12) or later (e.g., seismic load case unresolved, tether fatigue model rejected) forces redesign and re-certification (6–12 month cycle). If the finding emerges at Month 30 (2029-04-12) or Month 42 (2030-04-12) (detailed-design gates), production tooling and casting may need rework, adding EUR 200–500 million and 3–12 month delays. A finding that surfaces during construction (e.g., Month 60–80 = 2031-10-12 to 2033-10-12) becomes a safety or asset-integrity issue, requiring emergency inspections, segment isolation, possible salvage and extended service outage (weeks to months). Lenders and insurers may withhold or withdraw support if findings suggest design-basis inadequacy or regulator misalignment.

**Operating Revenue Forecast Slips >15% Below Planning Case, Threatening Debt Service or Availability-Payment Viability**
Escalation Level: Binational Project Board, with escalation to Ministerial Steering Committee if Structural Demand Deficiency Requires Subsidy or Service Adjustment
Approval Process: Monthly ridership demand forecasting and landside feeder-line integration progress are tracked by the PMO Director of Rail Integration. Quarterly demand-sensitivity reviews are conducted by the Risk and Assurance Authority. At Month 108–120 (2035-10-12 to 2036-10-12), if the opening-year demand forecast has declined >15% from the Month 30 (2029-04-12) baseline, the Board is notified and initiates a formal Demand and Service Adjustment Review. The Board convenes a panel (PMO, Cost Authority, Certification Panel, Risk Authority, Rail Integration director) to assess: (a) reasons for forecast slip (landside network delays, modal competition, economic downturn); (b) revised ridership scenarios and operating margins; (c) options: (i) defer opening pending landside completion; (ii) open with reduced frequency and accept subsidy; (iii) adjust fares upward and risk further demand reduction; (iv) seek additional availability-payment commitments from states/EU. The Board issues a decision within 4 weeks; decisions affecting service pattern or opening date are escalated to the Ministerial Steering Committee for approval within 10 days.
Rationale: The project assumes 4.0 million passengers/year opening (planning case), generating EUR 240 million/year fare revenue (at EUR 60 per trip). Annual operations and maintenance (opex) estimated at EUR 200 million/year. Private debt (EUR 4.4 billion of the EUR 8.8 billion systems tranche) requires ~EUR 270 million/year debt service, giving an operating surplus of EUR 40 million/year (DSCR 0.15x). The EUR 230 million gap to 1.0x coverage is funded by state/EU availability payments. If opening-year demand comes in 30–40% below forecast (e.g., 2.4–2.8 million passengers instead of 4.0 million), fare revenue drops to EUR 144–168 million/year, creating an operating deficit of EUR 56–102 million/year that requires additional public subsidy or forces fare increases that further reduce demand. A demand-review trigger is set for Month 108–120 (2035-10-12 to 2036-10-12): if forecast has slipped >15% vs. the Month 30 (2029-04-12) forecast, the Board conducts a full demand and service-pattern review.
Negative Consequences: If opening demand is 30–40% below forecast (4.0 to 2.4–2.8 million) and is not corrected by service adjustments or additional subsidy, operating deficits accumulate to EUR 1–2 billion over 10 years. Debt-covenant breaches trigger restructuring or default; lenders demand asset liquidation or equity injection. Private investors suffer losses, reducing appetite for future public infrastructure. Public budgets bear the subsidy burden, straining Spanish and Moroccan transport ministries. A sustained revenue shortfall (not corrected by Month 10–20 = 2027-08-12 to 2028-06-12 of service opening) could force the tunnel to be placed in care-and-maintenance mode or closed entirely, losing the operational asset and stranding the EUR 40 billion capital investment.

# Monitoring Progress

### 1. Tracking Support Concept Feasibility and Seabed Investigation Completion Against Design Basis Evidence
**Monitoring Tools/Platforms:**

  - Seabed Campaign Progress Dashboard (geophysical survey completion %, core drilling locations, in-situ testing results, independent review status)
  - Support Concept Evaluation Matrix (pillar vs. tether vs. hybrid technical and cost assessment, depth-feasibility cross-reference)
  - Design Basis and Certification Panel Monthly Review Log (gate criteria compliance, certification findings tracking)
  - Bathymetry and Geology Data Repository (maps, cores, seismic profiles, independent geotechnical assessment reports)

**Frequency:** Monthly during seabed campaign (Months 0–18 = 2026-10-12 to 2028-04-12); bi-weekly at Month 18–24 (2028-04-12 to 2028-10-12) during concept-freeze gate preparation; gate decision at Month 24 (2028-10-12)

**Responsible Role:** Design Basis and Certification Panel (Lead Certifier and Technical Advisory Panel) with supporting independent geotechnical engineering review; reported to Project Board

**Adaptation Process:** Monthly updates to the Support Concept Evaluation Matrix reflect new seabed data (lithology, bearing capacity, seismic hazard); if data contradicts the 100 m anchoring assumption or reveals depth >400 m unsuitable for pillars, the Panel recommends switching from pillar-only to hybrid concept (pillars on sills <400 m, tethers in deep channels). Panel escalates findings to the Design Basis Team; design team revises load cases and structural design. If hybrid pillar/tether transition is adopted, a full-scale joint mock-up test is added to the prototype test scope (cost +EUR 50–100 million, schedule +3–6 months). Month 24 (2028-10-12) gate decision binds the choice; if no single concept emerges by Month 18 (2028-04-12) independent review, gate date slips to Month 27–30 (2029-01-12 to 2029-04-12) and Board escalates for political decision.

**Adaptation Trigger:** Seabed geophysical survey >80% complete by Month 6 (2027-04-12) and 100% by Month 9 (2027-07-12); if show-stoppers identified (e.g., weak sediment layers, active faults at pillar locations), initiate design-basis revision. Core drilling results at Month 12 (2027-10-12): if bearing capacity <150 kPa at pillar foundation depth or seismic hazard (peak ground acceleration) exceeds initial design assumption by >20%, trigger support-concept reassessment. Independent geotechnical review at Month 18 (2028-04-12): if review identifies pillar-only concept infeasible (depth >300 m), recommend hybrid concept adoption by Month 24 (2028-10-12) gate; if recommendation cannot be implemented in time, escalate for decision to proceed with tether-only fallback or extend seabed work.

### 2. Tracking Binational Treaty Ratification, Governance Authority Establishment and Legal Personality Alignment
**Monitoring Tools/Platforms:**

  - Treaty Negotiation Status Tracker (draft treaty chapters, bilateral review cycle, anticipated ratification dates for Spanish and Moroccan parliaments)
  - Governance Authority Establishment Checklist (Board member appointments, CEO appointment, Lead Certifier contract, procurement-framework legal vetting, decision-authority documentation)
  - Delegation Threshold and Escalation Matrix Log (approval authorities recorded by decision type: design changes <2%, 2–5%, >5% thresholds)
  - Ministerial Steering Committee Meeting Log (political-level decision records, tie-breaking and escalation resolutions)

**Frequency:** Weekly during treaty-negotiation phase (Months 0–12 = 2026-10-12 to 2027-10-12); bi-weekly during ratification phase (Months 12–15 = 2027-10-12 to 2028-01-12); monthly thereafter during governance-body activation (Months 15–24 = 2028-01-12 to 2028-10-12); quarterly once operational

**Responsible Role:** Binational Project Board (Chair, Spanish and Moroccan Directors) with support from Governance Setup Team (Month 0–2 = 2026-10-12 to 2026-12-12), then PMO Chief Executive Officer and Project Controls Director; escalations to Ministerial Steering Committee (transport ministers)

**Adaptation Process:** Weekly tracking identifies negotiation blockers (e.g., disagreement over procurement authority, dispute-resolution mechanism, cost-sharing formula); bilateral negotiation team proposes resolutions and reports to Board. If consensus cannot be reached within 2 weeks on a major governance issue, matter escalates to Ministerial Steering Committee for political decision within 10 days. If ratification slips beyond Month 15 (2028-01-12), Board assesses root cause (legislative delays, opposition, treaty amendments needed) and decides by Month 18 (2028-04-12) whether to: (a) extend ratification target to Month 24 (2028-10-12) with accelerated parliamentary procedures; (b) proceed with executive-agreement framework without full treaty; or (c) halt the programme pending resolution. A slip beyond Month 24 (2028-10-12) triggers the stop rule: the EUR 20 billion main-construction tranche (including casting-yard advance) is not released, and no casting-yard construction commitment is made. Governance-authority establishment is tracked in parallel: Board appointments by Month 2 (2026-12-12), CEO by Month 2 (2026-12-12), Lead Certifier by Month 6 (2027-04-12). If any critical appointment slips beyond target, Board escalates to Project Sponsor for recruitment acceleration.

**Adaptation Trigger:** Treaty negotiation not advancing by Month 3 (2027-01-12): escalate to ministerial level for political engagement. Treaty draft not finalized by Month 9 (2027-07-12): Board reviews ratification feasibility; if unfeasible within Month 12–15 (2027-10-12 to 2028-01-12) window, initiate contingency governance framework (executive agreement). Ratification delayed beyond Month 15 (2028-01-12): formal Board decision required by Month 18 (2028-04-12) to extend or halt. Governance-authority appointments not in place by Month 3 (2027-01-12): Board escalates to Project Sponsor for immediate executive action. If treaty ratification not achieved by Month 24 (2028-10-12), apply stop rule: withhold EUR 20 billion main-construction tranche release and escalate to ministerial level for 30-day decision on programme continuation or scope adjustment.

### 3. Tracking Cost Performance, Contingency Reserve Drawdown and Variance Escalation (Independent Cost Authority Monthly Earned-Value and Quarterly Cost-to-Complete Forecasting)
**Monitoring Tools/Platforms:**

  - Earned-Value Analysis Dashboard (BCWS—Budgeted Cost of Work Scheduled, BCWP—Budgeted Cost of Work Performed, ACWP—Actual Cost of Work Performed, by tranche and phase; schedule and cost performance indices)
  - Contractor Invoice Audit Log (invoices received, verified, approved; change orders and claims; supplier-cost variance tracking)
  - Cost-to-Complete Forecasting Model (P50 and P80 confidence levels by tranche; cumulative overrun forecast at gate dates)
  - Contingency Reserve Deployment Log (EUR 7.2 billion reserve tracked by component: civil works EUR 5.6 billion, rail systems EUR 1.2 billion, operations EUR 0.4 billion; drawdowns recorded with Board decision authority and date)
  - Design-Change Cost Impact Register (all changes tracked, cost impact per change, cumulative change cost vs. baseline)

**Frequency:** Monthly earned-value summary and invoice audit (1st working day of month); quarterly cost-to-complete forecast and gate-readiness certification (one week before each scheduled Board meeting); annual independent audit of Cost Authority processes and data accuracy (Month 24, 48, 72 = 2028-10-12, 2030-10-12, 2032-10-12 onwards)

**Responsible Role:** Independent Cost Authority (Chief Financial Officer, Controller, Finance Manager, Cost Engineer, Schedule Analyst), reporting directly to Binational Project Board (not PMO CEO); escalations to Board within 5 business days if variance >5% of current tranche

**Adaptation Process:** Monthly earned-value tracking identifies cost and schedule variance. If variance is <5% of current tranche, Controller issues routine summary report to Board (administrative, no decision required). If variance exceeds 5%, Chief Financial Officer escalates to Board in writing within 5 business days, with independent cost-to-complete analysis and corrective-action options (cost control actions, design-change holds, contingency reallocation, scope reduction). Board responds within 10 days with: (a) acceptance of variance and re-forecast; (b) direction to PMO for corrective actions within defined timeline with Cost Authority audit; or (c) decision to reallocate contingency reserve. Quarterly cost-to-complete forecast updates P50 and P80 confidence intervals; if P80 forecast approaches or exceeds the EUR 40 billion cap, Cost Authority recommends triggers for scope or schedule adjustment. If cumulative cost overrun reaches EUR 2.8–10.8 billion (25–45% of envelope) by Month 36–48 (2029-10-12 to 2030-10-12), Cost Authority issues a formal Feasibility Alert to the Board and both governments, recommending immediate decision on scope reduction, schedule extension (past Month 240 = 2046-10-12 horizon), additional funding, or programme cancellation.

**Adaptation Trigger:** Monthly variance >5% of current tranche: escalate to Board within 5 business days. Cumulative variance >EUR 1 billion by Month 24 (2028-10-12) gate: Board reviews adequacy of EUR 7.2 billion reserve and whether design-change controls are effective; if variance is due to new risks (e.g., seabed surprises), activate mitigation plan and reforecast. Cumulative variance >EUR 2.8 billion (35% of contingency reserve) by Month 36 (2029-10-12): Board triggers a full cost-control review and possibly design freeze to prevent further changes. Trend analysis showing sustained cost inflation >3% annually (vs. 2% assumption): Board authorizes contingency increase (within EUR 40 billion cap, via scope reduction elsewhere) or rejects all design changes >1% variance. Cost-to-complete forecast (P80) exceeding EUR 40 billion at any quarterly gate: Board escalates to Ministerial Steering Committee within 10 days and requests decision on scope or additional funding within 15 days. Contractor claims >EUR 50 million: Cost Authority escalates to PMO Contracts Director and Board within 2 weeks; if unresolved within 30 days, matter goes to Board for cost-impact decision.

### 4. Tracking Schedule Progress, Critical-Path Variance and Weather-Window Utilisation Against Immersion Feasibility Constraints
**Monitoring Tools/Platforms:**

  - Critical Path Method (CPM) Schedule Dashboard (updated monthly: task start/finish dates, predecessor/successor links, schedule variance—scheduled date vs. actual progress, critical-path float, top 10 schedule risks)
  - Weather-Window Utilization Log (immersion campaign: planned vs. actual days used per month and quarter, sea-state forecasts, immersion rate m/month vs. plan)
  - Gate Readiness Status Board (gates at Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12; go/no-go criteria met, open items log, escalation tracker)
  - Schedule Reserve Tracking (6-month floating reserve outside critical path; drawdown decisions recorded, balance remaining)

**Frequency:** Weekly during critical phases (Months 0–3 = 2026-10-12 to 2027-01-12, Months 24–36 = 2028-10-12 to 2029-10-12, Months 36–48 = 2029-10-12 to 2030-10-12 casting-yard ramp); bi-weekly during normal phases; monthly schedule risk review and P50/P80 reforecasting of project completion date; quarterly gate-readiness certification (1 week before each gate meeting)

**Responsible Role:** Project Management Office (PMO Director of Project Controls and Schedule Analyst, with Cost Authority Schedule Analyst support); escalations to PMO CEO and Board if critical-path slip >6 months or weather-window utilisation falls >20% below plan

**Adaptation Process:** Weekly CPM updates identify schedule variance by task. If a critical-path task slips by >2 weeks, PMO initiates resource reallocation or scope adjustment to recover float. If a non-critical task consuming >10% of project slack slips, PMO escalates to CEO for schedule-risk decision. Monthly schedule-risk review tracks top 10 risks by schedule impact; if any single risk threatens >6-month slip, Risk Authority and PMO jointly recommend mitigation (e.g., early procurement, additional crew, parallel work paths). Weather-window utilisation is tracked monthly during immersion phases (Months 36–120 = 2029-10-12 to 2036-10-12); if actual immersion days fall >20% short of planned (e.g., 60 days available but only 48 days used due to poor weather or operational delays), immersion rate is recalculated and completion date reforecast. If reforecast shows immersion extending beyond Month 120 (2036-10-12) baseline, PMO escalates immediately to Board with options: (a) add a second immersion crew or contractor (cost +EUR 200–500 million, drawing on reserve); (b) defer non-critical systems to post-opening commissioning (schedule recovery but operational risk); (c) extend the overall programme past Month 240 (2046-10-12) horizon (political/funding implications). Gate readiness is tracked quarterly: 6 weeks before each gate (Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12), PMO issues a gate-readiness report listing open criteria, issues and escalations; if any critical criterion cannot be closed within 2 weeks of the gate date, Board decides to slip the gate or proceed with open finding (documented).

**Adaptation Trigger:** Critical-path task slip >2 weeks: PMO CEO directs resource reallocation within 5 days. Critical-path cumulative slip >6 months: Board escalates to Ministerial Steering Committee within 10 days. Non-critical slack consumption >10% of total project slack: PMO risk review triggered within 2 weeks. Weather-window utilisation <80% of plan for 2 consecutive months: PMO forecasts impact on immersion timeline; if slip >3 months, escalate to Board. Immersion reforecast (P80) extends beyond Month 120 (2036-10-12): Board decision required within 10 days on crew/contractor addition or schedule extension. Gate-readiness criteria not achievable 2 weeks before gate date: Board decides within 1 week to slip the gate or proceed-with-findings. Schedule reserve (6-month floating buffer) consumed >50%: Board escalates to Ministerial Steering Committee for decision on scope or timeline adjustment. Immersion campaign completion forecast (P80) moves beyond Month 120 (2036-10-12) to >Month 130 (2037-08-12): formal Board escalation for political review of 20-year horizon feasibility.

### 5. Tracking Environmental Consent Harmonisation, Baseline Ecological Data Collection and Seasonal-Window Compliance During Construction
**Monitoring Tools/Platforms:**

  - Ecological Baseline Data Repository (acoustic monitoring records, protected-species sightings by date/location/species, hydrodynamic measurements, sediment sampling, monthly data-quality audit)
  - Spanish and Moroccan Environmental Assessment Status Tracker (national EIA completion %, condition reconciliation log, consent issuance status)
  - Harmonisation Committee Meeting Log (monthly coordination meetings Months 6–24 = 2027-04-12 to 2028-10-12; consensus status, escalations to environment ministers)
  - Seasonal Window Compliance Log (immersion activity calendar, days spent within permitted window vs. annual budget, incident reports of window breaches, corrective actions)
  - Mitigation Delivery Dashboard (artificial-reef structure progress, research-partnership engagement status, long-term monitoring network deployment, budget tracking against EUR 250–400 million estimate)

**Frequency:** Monthly baseline-data review and environmental-compliance audit during baseline phase (Months 0–12 = 2026-10-12 to 2027-10-12); bimonthly during EIA development (Months 6–24 = 2027-04-12 to 2028-10-12); quarterly during construction phases (Months 36–132 = 2029-10-12 to 2037-10-12); consent renewal reviews every 5 years (post-opening baseline to Month 132 = 2037-10-12); escalation to Ecological Committee Lead or environment ministers if consent conditions are breached or conflicts emerge

**Responsible Role:** Binational Ecological and Environmental Compliance Committee (Committee Lead, Spanish and Moroccan environmental-authority representatives, marine biologist, hydrodynamicist); Construction Environmental Manager (appointed Month 24 = 2028-10-12) enforces seasonal compliance during construction; escalations to Committee Lead, then to Ministerial Steering Committee (Environment Ministers) if resolution fails

**Adaptation Process:** Monthly baseline-data review assesses acoustic, species-sighting and oceanographic trends; if new protected-species congregation areas are identified or migration timing shifts, Ecological Committee recommends mitigation adjustment (e.g., expanded seasonal buffer, extended baseline study). Bimonthly harmonisation meetings (Months 6–24 = 2027-04-12 to 2028-10-12) identify conflicts between Spanish and Moroccan environmental conditions (e.g., Spain requires year-round buffer, Morocco allows wider May–September window); Committee Lead mediates and recommends harmonised consent by Month 24 (2028-10-12). If national authorities diverge, matter escalates to both environment ministers for 10-day decision; if they diverge, escalates to Ministerial Steering Committee for political binding resolution within 10 days. Construction Environmental Manager (appointed Month 24 = 2028-10-12) enforces seasonal-window compliance: construction activities (e.g., immersion) are scheduled within permitted windows (e.g., May–September, 150 days/year). If an activity breaches the window, Construction Environmental Manager issues a 24-hour halt order; halt stands until PMO takes corrective action (reschedule work or escalate for Board risk acceptance) or 15 days pass (then automatically escalates to Board). Mitigation delivery (artificial reefs, research partnerships, monitoring network) is tracked against budget and schedule; if delays emerge (e.g., reef design not complete by Month 30 = 2029-04-12), Committee Lead escalates to Board for acceleration decision or contingency reallocation. Quarterly construction-phase audits verify that immersion campaigns comply with seasonal windows and that mitigation is being delivered on schedule.

**Adaptation Trigger:** Baseline data reveals new protected-species congregation area or change in migration timing by Month 12 (2027-10-12): trigger EIA revision and extended baseline to Month 18 (2028-04-12) if material change requires mitigation adjustment. Spanish and Moroccan environmental conditions diverge (conflicting seasonal windows or impact thresholds) by Month 18 (2028-04-12): escalate to harmonisation committee and environment ministers within 15 days; if unresolved by Month 24 (2028-10-12) gate, escalate to Ministerial Steering Committee for binding political decision. Seasonal-window breach detected during construction (immersion activity outside permitted dates): Construction Environmental Manager issues halt order within 24 hours; halt lasts until PMO corrects or Board accepts risk (within 15 days). Mitigation delivery (e.g., artificial-reef structure design) not on track for Month 30 (2029-04-12) completion: Committee Lead escalates to Board within 10 days for acceleration or cost-reallocation decision. Baseline ecological data shows persistent degradation trend (e.g., acoustic pollution from immersion affecting migration) by Month 60 (2031-10-12) or later: Ecological Committee recommends operational-procedure changes (e.g., reduced immersion rate, seasonal shutdowns) to mitigate further impact; if operational recommendations conflict with schedule or cost, escalate to Board for decision.

### 6. Tracking Design Certification Gate Readiness, Certification-Finding Resolution and Lead-Certifier Approval Against Design-Freeze and Construction Authority Milestones
**Monitoring Tools/Platforms:**

  - Design Certification Gate Tracker (gate dates Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12; design package submission status, Lead Certifier review timeline, finding log and closure status, interim/final certification letter)
  - Design-Code Development Checklist (load cases defined, safety factors approved, standards adapted and codified, Panel sign-off)
  - Prototype Testing Schedule and Results Log (tether pull-test, transition-joint mock-up assembly and hydrostatic test, segment immersion in sheltered water; test plans, results, certification letter)
  - Open Certification-Finding Register (all non-minor findings tracked: safety impact, cost and schedule implications, owner and closure date, escalation status)

**Frequency:** Monthly design-review meetings (2–4 hours) with design team and Lead Certifier starting Month 12 (2027-10-12); quarterly Technical Panel audits (1 day) during design phases (Months 12–48 = 2027-10-12 to 2030-10-12); gate submittals at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) with go/no-go certification decisions within 2 weeks of submission; annual Lead Certifier independence audit and performance review (Month 24, 48 onwards = 2028-10-12, 2030-10-12)

**Responsible Role:** Design Basis and Independent Certification Panel (Lead Certifier, Technical Advisory Panel Chair and members, Spanish and Moroccan technical-authority observers); escalations to Binational Project Board if non-minor findings emerge; Board escalations to Ministerial Steering Committee if political override is requested for a gate with open non-minor findings

**Adaptation Process:** Monthly design reviews between design team and Lead Certifier identify emerging certification risks (e.g., load case not covered by project design code, novel joint detail requires validation testing). Quarterly Panel audits assess progress against gate criteria; if finding-closure rate is <80%, Panel recommends extending design timeline for resolution. Gate submittals (6 weeks before gate date) trigger formal Lead Certifier review (4–6 weeks). If design is compliant, Lead Certifier issues a Certification Letter (design approved, gate open). If findings are identified, design team has 2 weeks to respond with corrective actions or justification; Lead Certifier re-reviews within 1 week. If findings are minor (documentation, inspection procedure, <EUR 50 million cost impact), gate may proceed with conditions. If findings are non-minor (safety impact, >EUR 500 million cost, >6 months schedule), Board escalates within 2 weeks. Board decision on non-minor finding: (a) approve gate despite finding (documented with rationale); (b) hold gate open until finding is closed (timeline TBD); or (c) require additional testing or study (extends gate timeline). Only unanimous Board vote (Spanish, Moroccan, Chair) can approve a gate with open non-minor findings. Prototype testing (tether pull-test, joint mock-up, full-scale segment immersion) is tracked and reported by Month 36 (2029-10-12); if testing identifies design deficiency, results feed into Month 42 (2030-04-12) detailed-design gate and may trigger design iteration (6–12 month cycle). Any finding emerging after Month 48 (2030-10-12) detailed-design gate is classified as late and escalates immediately to Board; late findings during fabrication (Months 48–120 = 2030-10-12 to 2036-10-12) trigger emergency design review and possible production halt pending resolution.

**Adaptation Trigger:** Design-code draft not complete by Month 9 (2027-07-12): extend gate to Month 12 (2027-10-12) and escalate to Board. Month 9 (2027-07-12) gate criteria not achievable 2 weeks before gate date: Board decides to slip gate or proceed-with-findings. Non-minor certification finding identified at Month 9 (2027-07-12) or Month 18 (2028-04-12) gate: Board has 10 days to decide (approve, hold gate or extend design). Non-minor finding identified at Month 30 (2029-04-12) gate during 60% design: escalate immediately to Board; if finding requires design change >EUR 200 million, Cost Authority escalates simultaneously. Prototype tether or joint test results (by Month 36 = 2029-10-12) identify design deficiency: escalate to Panel and Board within 1 week; test results feed Month 42 (2030-04-12) gate. Finding closure rate <80% 4 weeks before a gate: Panel recommends gate slip of 4–8 weeks for resolution; if slip jeopardizes critical path, Board decides on design acceleration or risk acceptance. Non-minor finding after Month 48 (2030-10-12) gate: Level-1 escalation to Board within 1 working day; emergency Board session convened within 5 days to decide on production halt or phased mitigation.

### 7. Tracking Operational Risk, Contingency Reserve Adequacy and Emerging Risks Against Feasibility Thresholds (Independent Risk and Assurance Authority Monthly Register Review and Quarterly Sensitivity Analysis)
**Monitoring Tools/Platforms:**

  - Risk Register (baseline: 19 risks from assumptions; qualitative and quantitative assessment—probability, impact, timing, expected value; monthly update, top-10 ranking)
  - Risk-Sensitivity Analysis (quarterly: Monte Carlo simulation or expected-value roll-up of top 10 risks; P50 and P80 cost/schedule impact; adequacy of EUR 7.2 billion contingency reserve assessed)
  - Feasibility Alert Log (cumulative cost/schedule/risk exposure approaching or exceeding programme thresholds; trigger conditions and Board recommendations documented)
  - Compliance and Ethics Dashboard (whistleblower reports logged, incidents tracked, investigation status, corrective actions, GDPR data-breach log)
  - Supply-Chain Risk Tracker (vendor sanctions, labour/environmental due diligence findings, material price and availability volatility, contractor day-rate escalation trends)

**Frequency:** Monthly risk-register review (1–2 hours internal to Risk Authority); monthly risk-governance summary (max. 2 pages) issued to Board by 10th working day of month; quarterly risk-sensitivity analysis and top-10-risks deep dive (1 day) one week before each Board meeting; annual compliance and ethics audit by external firm (Month 24, 48, 72 = 2028-10-12, 2030-10-12, 2032-10-12); quarterly whistleblower report summary (anonymized) to Board

**Responsible Role:** Risk and Assurance Authority (Head of Risk and Assurance, Risk Manager, Compliance & Ethics Officer, Supply-Chain Assurance Specialist), reporting directly to Binational Project Board; escalations to Board within 1 week of risk-event detection if impact >EUR 500 million, >6-month schedule, or threat to programme feasibility

**Adaptation Process:** Monthly risk-register updates reflect new information (e.g., seabed survey findings update geotechnical risk scores, delay news updates schedule-risk scores). Risk scores are adjusted in real-time as mitigation progresses or new triggers emerge. Risk Manager flags any risk moving from Medium to High severity or any emerging risk with High severity for immediate Head-of-Authority escalation. Quarterly sensitivity analysis models top-10 risks in combination; if combined P80 cost impact exceeds the available contingency reserve (EUR 6.8–6.95 billion after earmarking mitigation and design-change reserves), Head of Risk escalates a Contingency-Adequacy Alert to the Board within 1 week. Board responds within 10 days with: (a) acknowledgement that additional contingency is not available and recommends scope/schedule adjustment; (b) decision to reallocate reserves from lower-risk phases; or (c) request for new funding. Compliance and ethics monitoring tracks whistleblower reports, sanctions compliance, labour and environmental due-diligence findings. Material incidents (potential EUR 10 million impact or greater) are escalated to Board within 5 business days. Supply-chain risk tracking monitors vendor financial stability, material-price escalation and contractor day-rate trends; if inflation exceeds 2 percentage points above assumption (e.g., actual 4% vs. assumed 2% annually), Risk Authority recommends contingency increase or design-change freeze. A Feasibility Alert is issued if: (a) cumulative cost exposure (baseline + top-10 risks at P80) approaches EUR 40 billion + EUR 7.2 billion reserve; (b) cumulative schedule slip threatens to extend beyond Month 240 (2046-10-12) horizon; or (c) a single major risk (e.g., treaty non-ratification, regulator certification rejection) emerges with catastrophic impact. Feasibility Alerts escalate to Board and Ministerial Steering Committee within 2 weeks, with explicit recommendation for scope or schedule adjustment decisions.

**Adaptation Trigger:** Any risk-event detection with potential impact >EUR 500 million or >6-month schedule: escalate to Board within 1 week. Risk moving from Medium to High severity: Head of Risk escalates within 3 days. Emerging risk identified (not in baseline register) with High severity: escalate to Board within 5 days. Mitigation ineffectiveness detected (risk occurring despite mitigation, or mitigation cost overrun >20%): escalate to Board within 10 days with revised mitigation strategy. Quarterly sensitivity analysis shows top-10 combined P80 impact exceeding available reserve: escalate Contingency-Adequacy Alert to Board within 1 week. Whistleblower allegation involving potential fraud or corruption >EUR 10 million: escalate to Board and relevant governments within 5 business days. Vendor or contractor due-diligence finding indicating sanctions risk or labour-practice concern: halt engagement pending investigation; escalate to Board if unresolved within 15 days. Material-price or labour-cost inflation exceeds assumption by >2 percentage points: recommend contingency review and design-change freeze. Feasibility Alert threshold breached (cumulative exposure exceeding EUR 47.2 billion, or schedule slip threatening Month 240 = 2046-10-12 horizon): escalate to Ministerial Steering Committee within 2 weeks with recommendation for scope or schedule adjustment decision within 30 days.

# Governance Extra

## Governance Validation Checks

1. **Completeness Confirmation:** All core requested governance components are present and fully detailed. Audit procedures (Stage 1) define corruption prevention and financial controls; internal bodies (Stage 2) specify roles, decision authority and escalation paths for five entities; implementation plan (Stage 3) provides a 28-step monthly timeline from establishment through operational launch; decision escalation matrix (Stage 4) codifies issue-specific approval processes and negative consequences for eight major risk domains; monitoring (Stage 5) establishes tracking tools, frequencies, responsible roles and adaptation triggers for five continuous-monitoring streams. No major governance component is absent.
2. **Internal Consistency Check:** Logical alignment across stages is largely sound. Implementation steps establish governance bodies in a coherent sequence (Month 0–3 = 2026-10-12 to 2027-01-12); decision matrix escalation thresholds (>5% cost variance, >6-month schedule) align with PMO CEO delegation thresholds (<2% autonomous, 2–5% with Board) and Cost Authority variance reporting (>5% escalates); monitoring plans track KPIs against the same thresholds and feed into gate reviews cited in the escalation matrix. Certification gates (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) are consistently referenced across bodies and tranches. One minor inconsistency: the Risk Authority Charter specifies 'direct Board reporting' but the PMO Core Team includes a 'Director of Risk and Assurance' who appears subordinate to the CEO; clarification is needed on whether the Risk Authority Head reports to the Board or to the PMO (governance-phase2-bodies.json suggests Board reporting; governance-phase3-impl-plan.json step 16 describes the role as a PMO Director). Resolve this reporting line ambiguity before Month 1 (2026-11-12) governance adoption to ensure risk escalation independence.
3. **Clarity of Roles and Authority (Sponsor, Board, CEO, Cost Authority):** The Project Sponsor (Spanish and Moroccan governments) establishes governance but its ongoing decision authority is not explicitly defined. The Project Sponsor appears in the implementation plan (Month 0, 1–2 governance setup and adoption) and in governance-phase4-decision-escalation-matrix.json (for treaty ratification and political decisions escalated from the Ministerial Steering Committee), but no formal charter or ToR specifies what decisions the Sponsor retains (e.g., budget ceiling changes, scope reductions, programme cancellation). The Binational Project Board is the operational authority but does not appear to have unilateral power to approve scope or timeline changes >20% without sponsor consent. Recommendation: Draft a Project Sponsor Charter (Month 0–1 = 2026-10-12 to 2026-11-12) clarifying that the Sponsor retains authority for: (1) budget-cap changes (EUR 40 billion ± any adjustment); (2) programme scope reductions or timeline extensions past Month 240 (2046-10-12); (3) legal/political escalations (e.g., treaty failure, diplomatic breakdown); (4) ultimate approval of gate go/no-go decisions if cumulative cost/schedule variance exceeds defined thresholds (e.g., EUR 2.8 billion cumulative overrun or >12-month schedule slip triggers sponsor decision, not just Board escalation).
4. **Process Depth—Conflict of Interest, Whistleblower Investigation and Change-Control Specificity:** The Compliance and Ethics Policy is referenced in the Risk Authority Charter (drafted Month 3 = 2027-01-12) but details on how conflicts of interest are declared, reviewed and adjudicated are not provided. No specific conflict-of-interest protocol is defined for Board members with national ties, Cost Authority staff who may have prior accounting-firm relationships, or contractors with dual employment. The whistleblower hotline is mandated (Month 1 = 2026-11-12) but the investigation procedure (who investigates, timelines for closure, reporter protection mechanisms, escalation triggers) is specified only generically. Design-change control is detailed (DCCB monthly, decisions <2 weeks), but approval criteria for changes are vague ('cost impact independent assessment within 2 weeks'; what if assessment is not complete?). Recommendation: By Month 2–3 (2026-12-12 to 2027-01-12), draft a detailed Conflict-of-Interest Policy (declaration forms, annual refresh, recusal protocol for Board decisions, independent review process for disputes) and a Whistleblower Investigation Procedure (investigator qualifications, timelines—initial report 5 days, preliminary findings 30 days, closure with corrective action 60 days, appeals process). Strengthen design-change approval: specify that if cost-impact assessment is not complete within 2 weeks, the change is held pending assessment completion, with escalation to CEO after 20 days.
5. **Potential Gaps in Cross-Body Information Flow and Integration:** The five governance bodies (Board, PMO, Cost Authority, Certification Panel, Risk Authority, Ecological Committee) have specified meeting schedules and escalation paths, but mechanisms for information sharing and integrated decision-making are sparse. Example: The Cost Authority's quarterly cost-to-complete forecast (P50/P80) feeds the Board, but does not explicitly connect to the Risk Authority's sensitivity analysis of the top 10 risks at P80 (which also informs cost/schedule exposure). Similarly, the Design Certification Panel identifies non-minor findings at gates, escalating to the Board, but the Cost Authority's cost-to-complete does not appear to explicitly incorporate the cost impact of unresolved findings until the finding is formally closed. The Ecological Committee tracks seasonal windows and mitigation costs but may not integrate with the CPM schedule via the PMO unless an explicit handoff occurs. Recommendation: Establish a Cross-Body Integration Protocol (Month 3 = 2027-01-12) requiring: (1) monthly cost-to-complete forecast (Cost Authority) receives inputs from Risk Authority sensitivity analysis (top 10 risks, cost/schedule ranges) and Certification Panel (certification-finding cost impacts); (2) CPM schedule incorporates Ecological Committee seasonal-window constraints in real-time (monthly CPM updates include ecological milestones and any new window restrictions); (3) quarterly gate-readiness reviews (1 week before Board meetings) consolidate inputs from all five bodies: cost (Cost Authority), schedule (PMO), certification (Panel), risk (Risk Authority), environmental (Ecological Committee), producing a single gate-readiness report to the Board with integrated risk assessment.
6. **Operational Contingency Depletion and Mid-Course Adjustment Authority:** The governance framework specifies that contingency reserves (EUR 7.2 billion gross, EUR 6.8–6.95 billion available after ecological mitigation) are held at gate level and released by Board decision. However, if cumulative cost overruns reach EUR 2.8–10.8 billion (a plausible range given first-of-kind construction exposure), the reserve is depleted. The decision-escalation matrix addresses this via a Feasibility Alert (to Board and Ministerial Steering Committee), but does not specify who has authority to: (1) approve scope reductions (e.g., shorten crossing from 14 km to 12 km, defer rail systems, phase opening); (2) extend timeline past Month 240 (2046-10-12) horizon; or (3) request additional funding. The Board can escalate to the Ministerial Steering Committee, but the Steering Committee decision authority (and timeline for approval) is not codified in a charter. Recommendation: By Month 6 (2027-04-12), issue a Ministerial Steering Committee Charter specifying: (1) the Committee comprises Spanish Transport Minister, Moroccan Transport Minister, and EU development-bank representative (non-voting observer); (2) decisions are by consensus preferred, or majority if consensus fails (2-of-3 vote); (3) decision timelines: Feasibility Alert triggers decision within 15 days (acceptance of revised cost/schedule, approval of scope reduction, or request for additional sovereign funding); (4) decisions are binding on the Board and PMO; (5) if the Committee cannot reach consensus within 15 days, the matter escalates to political level (Spanish and Moroccan prime ministers) for final decision within 30 days.

## Tough Questions

1. **What is the current probability-weighted forecast for the support-concept resolution (pillar-only vs. hybrid vs. tether-only) by the Month 24 (2028-10-12) gate, and what would be the cost and schedule impact if the seabed campaign (Months 0–18 = 2026-10-12 to 2028-04-12) reveals that pure pillars are infeasible beyond 300 m depth?** Seabed bathymetry evidence is the critical path item for concept freeze; the governance framework mandates Month 18 (2028-04-12) completion of a front-loaded campaign, but contingency for redesign is only EUR 1–2 billion (Design Change Reserve). If a pillar-only fallback is forced, estimate EUR 4–8 billion and 12–36 month delays—this exhausts the reserve and compresses immersion schedule. What is the Board's contingency if geotechnical review at Month 18 (2028-04-12) cannot endorse any concept by Month 24 (2028-10-12) gate?
2. **Show evidence of treaty-ratification progress by Month 9 (2027-07-12): what is the current status of the draft binational treaty, which parliaments have formally reviewed it, and what are the outstanding political or legal objections?** The governance framework applies a stop rule: if treaty is not ratified by Month 24 (2028-10-12), the EUR 20 billion main-construction tranche is not released. Month 9 (2027-07-12) falls within the first 10 months of the project; by then, treaty negotiation should be 60–70% complete. What leading indicators confirm that ratification is on track for Month 12–15 (2027-10-12 to 2028-01-12) target?
3. **What is the P80 cost-to-complete forecast as of Month 12 (2027-10-12) and Month 24 (2028-10-12) gates, and if P80 exceeds EUR 40 billion + EUR 7.2 billion reserve (i.e., EUR 47.2 billion), what scope or schedule adjustment decisions have been prepared for Board and Ministerial Steering Committee approval?** The Independent Cost Authority must produce quarterly cost-to-complete forecasts by Month 12 (2027-10-12). If the P80 forecast at Month 12 (2027-10-12) shows cumulative cost exposure (baseline + top 10 risks) approaching EUR 47 billion, this is the Board's early warning signal to prepare contingency decisions (scope reduction, additional funding, timeline extension). What is the current forecast, and has the Board pre-authorized scenario analysis for a 25–45% cost envelope stretch?
4. **Provide a critical-path-method (CPM) schedule with P50 and P80 confidence showing the earliest possible immersion-start date given actual equipment-procurement lead times, casting-yard build duration (Months 12–36 = 2027-10-12 to 2029-10-12 estimated) and pilot-segment test timelines (Months 24–36 = 2028-10-12 to 2029-10-12), and confirm whether 14 km of immersion is feasible within the 20-year horizon at 60–90 days/year weather-window utilization.** The governance framework assumes immersion can run Months 36–120 (2029-10-12 to 2036-10-12), i.e., 84 months for ~14 km of tube at 500–800 m per yard per year (one to two yards). At two yards running in parallel, this implies 1.0–1.6 km/year, fitting within an 8.75–14-year immersion window if (a) both yards are fully operational by Month 36 (2029-10-12), (b) weather windows are 60–90 days/year, and (c) no major production rework occurs. What is the Board's confidence in this P50 estimate, and what P80 forecast (with schedule contingency allocation) covers setbacks?
5. **What is the earliest possible month for harmonized environmental consents from Spain and Morocco, and what is the contingency if ecological baseline (Months 0–12 = 2026-10-12 to 2027-10-12) reveals protected-species sensitivities that narrow seasonal construction windows to fewer than 60 days per year?** The governance framework assumes 60–90 days/year immersion windows (seasonal compliance monitored post-Month 24 = 2028-10-12 gate consent). If baseline monitoring identifies migration congregation areas or acoustic sensitivity not anticipated, seasonal windows may shrink and immersion rate may drop 30–50%, extending the 14 km completion timeline by 3–7 years. By what month (earliest and latest) must the Ecological Committee and Spanish/Moroccan environment ministries reach consent, and what is the Board's trigger to escalate if consent or baseline findings compress the immersion schedule?
6. **What specific criteria will the Design Basis and Independent Certification Panel use to approve or reject the hybrid (pillar/tether transition) concept at the Month 24 (2028-10-12) gate, and what is the cost and timeline for the full-scale transition-joint mock-up test mandated by Month 48 (2030-10-12)?** The hybrid concept introduces a novel fixed-to-floating structural interface (transition joint between pillar section and tether section) that has no precedent. The governance framework mandates prototype testing (EUR 50–100 million estimate, Month 48 = 2030-10-12), but Month 24 (2028-10-12) gate requires seabed data to validate the concept. What independent evidence by Month 24 (2028-10-12) will the Certification Panel require to approve the hybrid approach, and if that evidence is not available, what is the Board's fallback (delay gate, proceed-with-findings, or switch to pure tether/pillar)?
7. **If the Independent Cost Authority escalates a cumulative cost overrun (EUR 2.8–10.8 billion gap) by Month 36–48 (2029-10-12 to 2030-10-12), what is the Board's decision authority to approve scope reduction (e.g., defer rail systems, phase opening, shorten crossing), and within what timeline must the Ministerial Steering Committee approve such changes to avoid slipping the service-opening target (Month 132 = 2037-10-12)?** The governance framework escalates Feasibility Alerts to the Ministerial Steering Committee, but the Committee Charter (not yet drafted) must specify decision timelines and binding authority. If cost overruns are discovered at Month 36 (2029-10-12) (entry to main immersion), a 30-day ministerial decision process consumes time; the Board must then implement scope changes within 60–90 days to avoid immersion-schedule impact. What is the pre-authorized scope-reduction menu (e.g., cut freight capability, defer track-systems to post-opening, reduce opening-year frequency), and at what point does cumulative overrun + scope reduction force a timeline extension past Month 240 (2046-10-12)?

## Summary

This €40 billion, 20-year submerged floating tunnel project employs a distributed governance model centred on five specialized bodies—the Binational Project Board, PMO Core Team, Independent Cost Authority, Design Certification Panel, and Risk and Assurance Authority—reporting to and supervised by the Board. The framework prioritizes early risk retirement (seabed investigation, treaty ratification, prototype testing) through gated funding release and independent cost/risk/certification oversight. Core strengths include explicit escalation rules (variance thresholds >5% cost, >6-month schedule, >EUR 500 million impact), monthly earned-value tracking and quarterly forecasting, role separation (Cost Authority and Risk Authority report independently to the Board), and real-time design-change control. Primary governance gaps include ambiguous Project Sponsor ultimate accountability, under-specified processes for cross-body information integration and dispute resolution, and insufficient detail on how operational contingency will be managed when reserves deplete. Schedule feasibility against weather-window constraints and immersion-rate delivery remains a critical unknown not fully operationalized in the governance structure.