### 1. Project Sponsor establishes a Governance Setup Team (Spanish and Moroccan government representatives, legal counsel, international advisor) to draft governance charters, ToRs and appointment protocols for the five internal governance bodies. This team will prepare all foundational governance documents for Board and government approval.

**Responsible Body/Role:** Project Sponsor (Spanish and Moroccan governments, represented by Transport Ministry delegates and Chief Legal Advisors)

**Suggested Timeframe:** Month 0 (2026-10-12)

**Key Outputs/Deliverables:**

- Governance Setup Team roster and appointment letter
- High-level governance-implementation timeline and dependencies map
- Draft charter template for each of the five governance bodies

**Dependencies:**

- Project start authorization from both governments (Month 0 = 2026-10-12)

### 2. Governance Setup Team drafts Terms of Reference (ToR) and Charter for the Binational Project Board, including Board composition (Spanish director, Moroccan director, independent Chair), decision rules (majority vote, tie-breaker authority), meeting cadence (monthly, escalating to quarterly), and delegation thresholds (CEO approval <2% variance, Board 2–5%, >5% political escalation). Includes risk acceptance and cost authority limits.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Binational Project Board Charter v0.1
- Draft Binational Project Board ToR (roles, responsibilities, decision matrix, escalation rules)
- Proposed Board composition and appointment criteria

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 3. Governance Setup Team drafts Terms of Reference and Charter for the Project Management Office (PMO) and Core Delivery Team, covering the Chief Executive Officer role, Core Team composition (Directors of Controls, Engineering, Contracts, Environmental, Rail Integration, Risk), delegation authority, design-change-control procedures, and reporting lines to the Project Board.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor and senior delivery advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft PMO and Core Delivery Team Charter v0.1
- Draft PMO ToR (roles, responsibilities, delegation thresholds, reporting)
- Draft Design Change Control Board (DCCB) charter and monthly agenda template

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 4. Governance Setup Team drafts Terms of Reference and Charter for the Independent Cost Authority, covering reporting directly to the Project Board (not the PMO), earned-value tracking, contingency-reserve management, cost-to-complete forecasting (P50/P80), variance escalation thresholds (>5% of tranche), and contractor-invoice audit authority. Emphasizes independence from operational management.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Financial Officer or independent finance advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Independent Cost Authority Charter v0.1
- Draft Cost Authority ToR (scope, reporting, decision authority, escalation rules)
- Cost-baseline and contingency-reserve definition (EUR 7.2 billion; civil 20%, rail systems 15%, operations 10%)

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)
- Budget envelope (EUR 40 billion) confirmed (user constraint)

### 5. Governance Setup Team drafts Terms of Reference and Charter for the Design Basis and Independent Certification Panel, covering the Lead Certifier role, Technical Advisory Panel composition, gate-certification processes (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12), design-code development, and certification decision authority. Clarifies that the Lead Certifier reports to the Project Board, not to national authorities.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's senior technical advisor or international engineering consultant)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Design Basis and Certification Panel Charter v0.1
- Draft Lead Certifier role description and appointment criteria
- Draft Technical Advisory Panel charter and expertise matrix
- Preliminary gate-certification process flow and criteria template

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 6. Governance Setup Team drafts Terms of Reference and Charter for the Risk and Assurance Authority, covering the Head of Risk and Assurance role, risk-register management, escalation thresholds (>EUR 500 million impact or >6-month schedule), compliance and ethics oversight, supply-chain due diligence, GDPR, and whistleblower hotline. Emphasizes direct Board reporting and independence.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Risk Officer or independent governance advisor)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Risk and Assurance Authority Charter v0.1
- Draft Risk Authority ToR (scope, decision authority, escalation rules, compliance mandate)
- Draft Risk Register template and assessment methodology (qualitative and quantitative)
- Draft Compliance and Ethics Policy (conflicts of interest, procurement transparency, whistleblower process)

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 7. Governance Setup Team drafts Terms of Reference and Charter for the Binational Ecological and Environmental Compliance Committee, covering the Committee Lead role, joint Spanish–Moroccan technical teams, baseline monitoring coordination, environmental-consent harmonization process, seasonal-window enforcement, and Construction Environmental Manager role. Defines escalation to environmental ministers and the Project Board.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's environmental advisor or Spanish/Moroccan environment ministry delegate)

**Suggested Timeframe:** Month 0–1 (2026-10-12 to 2026-11-12)

**Key Outputs/Deliverables:**

- Draft Ecological Committee Charter v0.1
- Draft Ecological Committee ToR (baseline, consent harmonization, mitigation, seasonal enforcement)
- Draft baseline-study scope and timeline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum continuous monitoring through Month 132 = 2037-10-12)
- Draft harmonization protocol for Spanish and Moroccan environmental assessments

**Dependencies:**

- Governance Setup Team established (Month 0 = 2026-10-12)

### 8. Project Sponsor (and Governance Setup Team) circulates all five draft governance charters and ToRs for review by nominated government representatives, legal counsel, lenders and international partners. Collect and consolidate feedback within 3 weeks.

**Responsible Body/Role:** Project Sponsor (represented by Governance Setup Team)

**Suggested Timeframe:** Week 1–3 of Month 1 (2026-11-12 to 2026-11-26)

**Key Outputs/Deliverables:**

- Feedback summary report (consolidated from all stakeholders)
- Revision log identifying substantive comments and proposed changes to charters

**Dependencies:**

- All five draft charters completed (Month 0–1 = 2026-10-12 to 2026-11-12)

### 9. Governance Setup Team incorporates feedback into revised governance charters and ToRs. Finalizes all five charters for Project Sponsor approval and Board adoption.

**Responsible Body/Role:** Governance Setup Team (lead: Project Sponsor's Chief Legal Advisor)

**Suggested Timeframe:** Week 4 of Month 1 (2026-11-12) through Month 1 (2026-11-12 to end of month)

**Key Outputs/Deliverables:**

- Binational Project Board Charter v1.0 (final, ready for adoption)
- PMO and Core Delivery Team Charter v1.0 (final)
- Independent Cost Authority Charter v1.0 (final)
- Design Basis and Certification Panel Charter v1.0 (final)
- Risk and Assurance Authority Charter v1.0 (final)
- Ecological Committee Charter v1.0 (final)
- Adoption-readiness summary for Project Sponsor

**Dependencies:**

- Stakeholder feedback received (Month 1 = 2026-11-12 week 1–3 = 2026-11-12 to 2026-11-26)

### 10. Project Sponsor formally adopts all five governance charters and ToRs. Spanish and Moroccan transport ministries issue joint adoption decree, confirming that governance framework is in effect and all bodies are authorized to be established. This step formally legitimizes the governance structure at the highest political level.

**Responsible Body/Role:** Project Sponsor (Spanish Minister of Transport and Moroccan Minister of Transport, or equivalents, via joint decree)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Joint Spanish–Moroccan Governance Adoption Decree (signed by both transport ministers)
- Published governance charters and ToRs (available to stakeholders)

**Dependencies:**

- All five charters finalized v1.0 (Month 1 = 2026-11-12)

### 11. Project Sponsor nominates and formally appoints the independent Chair of the Binational Project Board. The Chair must be an international maritime/tunnel engineering expert with no affiliation to either government. Publish appointment announcement and Chair biography.

**Responsible Body/Role:** Project Sponsor (Spanish and Moroccan transport ministers, acting jointly)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Binational Project Board Chair (4-year term, renewable once)
- Chair biography and statement of independence
- Public announcement of Chair appointment

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- International-expert recruitment process completed

### 12. Project Sponsor nominates and formally appoints the Spanish and Moroccan directors of the Binational Project Board. Spanish director appointed by Spanish transport minister; Moroccan director appointed by Moroccan transport minister. Publish appointment announcements.

**Responsible Body/Role:** Project Sponsor: Spanish transport minister (for Spanish director); Moroccan transport minister (for Moroccan director)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Spanish Project Board Director
- Appointment letter: Moroccan Project Board Director
- Public announcements of both director appointments

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- Nomination and vetting completed by each transport ministry

### 13. Project Sponsor nominates a Chief Executive Officer (CEO) of the PMO. The CEO is the senior executive responsible for day-to-day project delivery, cost control, schedule management and reporting to the Binational Project Board. Typically an experienced megaproject delivery leader with multinational experience. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Chair of the Binational Project Board, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Project Management Office Chief Executive Officer
- CEO biography and statement of qualifications
- Public announcement of CEO appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment process for megaproject experience completed

### 14. Project Sponsor nominates and formally appoints the Chief Financial Officer (head of the Independent Cost Authority). The CFO must be an independent financial specialist with no affiliation to either government or the delivery contractor, and must report directly to the Project Board. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Independent Cost Authority Chief Financial Officer
- CFO biography and independence declaration
- Public announcement of CFO appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International-expert recruitment (finance/audit/megaproject experience) completed

### 15. Project Sponsor nominates and formally appoints the Lead Certifier for the Design Basis and Independent Certification Panel. The Lead Certifier is typically a classification society (DNV-GL, ABS, Lloyds Register or equivalent) or international consortium of independent technical experts with authority to certify design against a project-specific code. Lead Certifier reports to the Project Board, not to national authorities. Publish contract and announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Contract: Lead Certifier appointment (2-year initial term, renewable; scope, reporting, decision authority)
- Lead Certifier organization profile and team assignment
- Public announcement of Lead Certifier contract award

**Dependencies:**

- Governance charters adopted (Month 1 = 2026-11-12)
- International procurement process for Lead Certifier completed

### 16. Project Sponsor nominates and formally appoints the Head of Risk and Assurance Authority. This person is an independent risk and governance specialist, reporting directly to the Project Board, responsible for comprehensive risk management, compliance, ethics and supply-chain due diligence. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Binational Project Board Chair, once appointed; initially through Project Sponsor directly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Head of Risk and Assurance Authority
- Risk Authority head biography and independence declaration
- Public announcement of Risk Authority head appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment (risk management, governance, megaproject experience) completed

### 17. Project Sponsor nominates and formally appoints the Binational Ecological Committee Lead. This person is an international environmental scientist with no national affiliation, responsible for coordinating joint ecological baseline, harmonizing Spanish and Moroccan environmental assessments, and managing mitigation delivery. Publish appointment announcement.

**Responsible Body/Role:** Project Sponsor (acting through the Spanish and Moroccan environment ministries jointly)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Appointment letter: Binational Ecological Committee Lead
- Ecological Committee Lead biography and independence declaration
- Public announcement of Ecological Committee Lead appointment

**Dependencies:**

- Project Sponsor authorization (Month 0 = 2026-10-12)
- International recruitment (marine ecology, environmental permitting, Strait of Gibraltar expertise) completed

### 18. PMO Chief Executive Officer (appointed by Month 2 = 2026-12-12) establishes the Core Delivery Team. The CEO recruits or nominates the six core Directors: Project Controls and Finance, Engineering and Design, Contracts and Procurement, Environmental and Ecological Compliance, Rail Integration and Operations Planning, and Risk and Assurance (the latter reports to the Risk Authority, not the CEO). Publish organizational chart and team roster.

**Responsible Body/Role:** Project Management Office Chief Executive Officer

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- PMO organizational chart (CEO + six core Directors + supporting staff)
- Roster of Core Delivery Team members (names, roles, reporting lines)
- Job descriptions for each Director role
- Signed acceptance of appointment by each Director

**Dependencies:**

- PMO Chief Executive Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 19. Independent Cost Authority Chief Financial Officer (appointed by Month 2 = 2026-12-12) establishes the Cost Authority team. The CFO recruits or nominates the four supporting staff: Controller (cost baseline and earned-value), Finance Manager (invoice audit), Cost Engineer (design-change impact), and Schedule Analyst (critical-path variance and weather windows). Publish organizational chart and team roster.

**Responsible Body/Role:** Independent Cost Authority Chief Financial Officer

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Cost Authority organizational chart (CFO + four supporting staff)
- Roster of Cost Authority staff (names, roles, reporting lines)
- Job descriptions for each role (Controller, Finance Manager, Cost Engineer, Schedule Analyst)
- Signed acceptance of appointment by each staff member

**Dependencies:**

- Independent Cost Authority Chief Financial Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 20. Lead Certifier (appointed by Month 3 = 2027-01-12) forms the Technical Advisory Panel for the Design Basis and Certification Panel. Lead Certifier nominates the Panel Chair and 4–6 technical experts covering offshore structures, seismic/geotechnical engineering, railway safety, and emergency response. Panel Chair has no national affiliation. Lead Certifier also confirms appointment of Spanish and Moroccan technical authority observers (non-voting). Publish Panel roster and biographical information.

**Responsible Body/Role:** Lead Certifier (classification society or independent technical consortium)

**Suggested Timeframe:** Month 1–4 (2026-11-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Technical Advisory Panel charter (final, signed by Lead Certifier)
- Panel Chair appointment letter and biography
- Roster of 4–6 technical experts (names, affiliations, expertise areas, declared independence)
- Appointment confirmations: Spanish and Moroccan technical authority observers
- Public announcement of Panel formation

**Dependencies:**

- Lead Certifier appointed (Month 1–3 = 2026-11-12 to 2027-01-12)

### 21. Binational Ecological Committee Lead (appointed by Month 2 = 2026-12-12) establishes the joint Spanish–Moroccan ecological technical team. Lead nominates or recruits: marine biologist, hydrodynamicist, Spanish environmental authority representative, Moroccan environmental authority representative, and NGO/stakeholder liaison (non-voting). Publish team roster and charter.

**Responsible Body/Role:** Binational Ecological Committee Lead

**Suggested Timeframe:** Month 1–4 (2026-11-12 to 2027-02-12)

**Key Outputs/Deliverables:**

- Ecological Committee charter (final, signed by Lead)
- Roster of joint technical team (names, affiliations, roles)
- Appointment confirmations: Spanish environmental authority, Moroccan environmental authority
- NGO/stakeholder liaison appointment letter
- Public announcement of Ecological Committee formation

**Dependencies:**

- Binational Ecological Committee Lead appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 22. Binational Project Board holds its inaugural meeting. Formal constitution of the Board: Chair, Spanish director, Moroccan director (three voting members), and EU/multilateral-lender observer (non-voting) all confirmed present. Chair outlines the Board's mandate, decision rules, delegation authority and escalation protocols. Board approves the monthly meeting schedule starting Month 2 (2026-12-12). This meeting formally establishes the Board as operationally active.

**Responsible Body/Role:** Binational Project Board (Chair, Spanish Director, Moroccan Director)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- Binational Project Board inaugural meeting minutes (including attendance, role confirmations, approved schedule)
- Board decision register (action items, owners, due dates)
- Approved monthly Board meeting calendar (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Board Chair appointed (Month 1–2 = 2026-11-12 to 2026-12-12)
- Spanish and Moroccan directors appointed (Month 1–2 = 2026-11-12 to 2026-12-12)
- Governance charters formally adopted (Month 1 = 2026-11-12)

### 23. Project Management Office holds its inaugural Core Delivery Team kickoff meeting. CEO chairs; all six Directors present (Controls & Finance, Engineering & Design, Contracts & Procurement, Environmental, Rail Integration, Risk & Assurance). CEO outlines the governance framework, delegation authority, change-control thresholds, and reporting lines. Core Team approves weekly standup, monthly DCCB, monthly risk review, and monthly cost-control meeting schedules. This meeting formally establishes the PMO as operationally active.

**Responsible Body/Role:** Project Management Office (CEO and six core Directors)

**Suggested Timeframe:** Month 1 (2026-11-12)

**Key Outputs/Deliverables:**

- PMO Core Delivery Team inaugural meeting minutes (attendance, role confirmations, approved schedules)
- PMO decision register and action-item log (owners, due dates)
- Approved meeting schedules: weekly standup, monthly DCCB, monthly risk review, monthly cost-control review (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- PMO Chief Executive Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Core Delivery Team (six Directors) nominated and confirmed (Month 1–3 = 2026-11-12 to 2027-01-12)

### 24. Independent Cost Authority holds its inaugural meeting. CFO chairs; all supporting staff present (Controller, Finance Manager, Cost Engineer, Schedule Analyst). CFO outlines the Cost Authority's independence, reporting directly to the Board (not the PMO CEO), cost-baseline definition, contingency-reserve management, earned-value-tracking methodology, variance-escalation thresholds (>5% of tranche), and quarterly cost-to-complete forecasting at P50/P80. Approves monthly and quarterly review schedules.

**Responsible Body/Role:** Independent Cost Authority (Chief Financial Officer and supporting staff)

**Suggested Timeframe:** Month 1–2 (2026-11-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Cost Authority inaugural meeting minutes (attendance, role confirmations, approved schedules)
- Cost-baseline definition document (budget allocation by tranche and phase, contingency reserve EUR 7.2 billion breakdown)
- Cost-tracking methodology and systems description
- Approved review schedules: monthly earned-value summary, quarterly cost-to-complete forecast, annual audit cycle (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Independent Cost Authority Chief Financial Officer appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Cost Authority supporting staff nominated (Month 1–3 = 2026-11-12 to 2027-01-12)

### 25. Design Basis and Certification Panel (Lead Certifier and Technical Advisory Panel) holds its inaugural meeting. Lead Certifier and Panel Chair chair; all Panel members and observers present. Lead Certifier outlines the Panel's mandate: develop project-specific design code, establish certification gates (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12), define gate-certification criteria, oversee prototype testing and seismic/geotechnical input. Panel approves monthly design-review and quarterly panel-audit schedules starting Month 3 (2027-01-12).

**Responsible Body/Role:** Design Basis and Certification Panel (Lead Certifier, Panel Chair, technical members, Spanish and Moroccan authority observers)

**Suggested Timeframe:** Month 2–3 (2026-12-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Lead Certifier and Panel inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Panel operating procedures (design-review frequency, gate-certification process, decision-making, escalation)
- Preliminary gate-certification criteria template (to be detailed at Month 9 = 2027-07-12)
- Approved monthly and quarterly meeting schedules (Months 3–12 = 2027-01-12 to 2027-10-12+ = 2027-01-12 to 2027-10-12+)

**Dependencies:**

- Lead Certifier appointed (Month 1–3 = 2026-11-12 to 2027-01-12)
- Technical Advisory Panel formed (Month 1–4 = 2026-11-12 to 2027-02-12)

### 26. Risk and Assurance Authority holds its inaugural meeting. Head of Risk and Assurance chairs; all supporting staff present (Risk Manager, Compliance & Ethics Officer, Supply-Chain Assurance Specialist). Head outlines the Authority's independence (reporting to the Board, not the PMO), risk-register management, escalation thresholds (>EUR 500 million impact, >6-month schedule, feasibility threat), compliance and ethics mandate, GDPR and whistleblower hotline, and supply-chain due-diligence protocols. Approves monthly risk-review, quarterly sensitivity analysis, and annual audit schedules.

**Responsible Body/Role:** Risk and Assurance Authority (Head of Risk and Assurance and supporting staff)

**Suggested Timeframe:** Month 1–3 (2026-11-12 to 2027-01-12)

**Key Outputs/Deliverables:**

- Risk Authority inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Risk Register v1.0 (baseline: 19 risks from assumptions document, initial qualitative assessment)
- Risk-assessment methodology (probability, impact, timing; expected-value calculation)
- Escalation and decision matrix (thresholds, owners, timelines)
- Compliance and Ethics Policy (conflicts of interest, procurement transparency, whistleblower hotline, GDPR)
- Approved monthly and quarterly review schedules (Months 2–12 = 2026-12-12 to 2027-10-12+ = 2026-12-12 to 2027-10-12+)

**Dependencies:**

- Head of Risk and Assurance Authority appointed (Month 0–2 = 2026-10-12 to 2026-12-12)

### 27. Binational Ecological Committee holds its inaugural meeting. Committee Lead chairs; Spanish environmental authority, Moroccan environmental authority, marine biologist, hydrodynamicist, and NGO/stakeholder liaison present. Lead outlines the Committee's mandate: conduct joint baseline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum), harmonize national EIAs (Months 6–24 = 2027-04-12 to 2028-10-12), secure harmonised consent (Month 24 = 2028-10-12 target), design and cost mitigation, schedule construction to seasonal windows, coordinate with maritime authorities on shipping exclusion zones. Approves baseline-study protocols and national harmonization committee schedule (monthly, Months 6–24 = 2027-04-12 to 2028-10-12).

**Responsible Body/Role:** Binational Ecological Committee (Lead, Spanish authority, Moroccan authority, technical experts, NGO liaison)

**Suggested Timeframe:** Month 0–2 (2026-10-12 to 2026-12-12)

**Key Outputs/Deliverables:**

- Ecological Committee inaugural meeting minutes (attendance, role confirmations, mandate statement, approved schedules)
- Baseline-study work plan (acoustic monitoring, visual surveys, oceanographic data, sampling schedule, vessel requirements)
- Environmental-impact assessment framework and timeline (Months 6–24 = 2027-04-12 to 2028-10-12)
- Harmonization protocol: Spanish–Moroccan EIA reconciliation process
- Approved monitoring and compliance meeting schedule (Months 0–12 = 2026-10-12 to 2027-10-12 baseline, then quarterly during construction)

**Dependencies:**

- Binational Ecological Committee Lead appointed (Month 0–2 = 2026-10-12 to 2026-12-12)
- Spanish and Moroccan environmental authority representatives nominated

### 28. PMO Chief Executive Officer establishes a Governance Setup Team wind-down and transition. Governance Setup Team (initial interim body) transfers all governance documents, meeting records, and member rosters to the PMO Director of Controls and the Risk Authority Head of Assurance for ongoing governance administration. Governance Setup Team formally dissolves, having completed its transient mission to establish all five bodies.

**Responsible Body/Role:** Project Management Office CEO (in coordination with the Governance Setup Team lead and Risk Authority Head)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Governance-administration handoff memo (transfer of responsibility from Setup Team to PMO and Risk Authority)
- Consolidated governance document repository (all charters, ToRs, meeting minutes, member rosters)
- Governance Setup Team dissolution notice (confirming completion of mission)

**Dependencies:**

- All five governance bodies formally established and holding inaugural meetings (Month 1–3 = 2026-11-12 to 2027-01-12)

### 29. Binational Project Board holds its first operational month-end review meeting (Month 1 end = 2026-11-12 end, convene early Month 2 = 2026-12-12). Board reviews: (1) governance-body establishment status (all five bodies formally constituted?); (2) CEO and leadership-appointment confirmations; (3) project-start ASAP actions initiated (seabed campaign, treaty negotiation, ecological baseline, governance setup); (4) CPM schedule development status (due Month 1 = 2026-11-12); (5) risk register (baseline 19 risks populated); (6) forward-looking agenda (gate readiness, cost baseline, tranche-release readiness).

**Responsible Body/Role:** Binational Project Board (Chair, Spanish Director, Moroccan Director, EU observer)

**Suggested Timeframe:** Month 2 (2026-12-12)

**Key Outputs/Deliverables:**

- Binational Project Board Month 1 (2026-11-12) end review meeting minutes
- Governance-establishment status report (all bodies constituted: yes/no, any open actions)
- Project-status dashboard (seabed, treaty, ecology, governance progress vs. Month 0–1 = 2026-10-12 to 2026-11-12 plan)
- Risk register review (19 baseline risks, top 5 high-severity risks, escalations identified)

**Dependencies:**

- All five governance bodies formally constituted and inaugural meetings held (Month 1–3 = 2026-11-12 to 2027-01-12)
- Seabed campaign initiated (Month 0 = 2026-10-12)
- Treaty negotiation team established (Month 0 = 2026-10-12)

### 30. All five governance bodies transition from establishment (startup) phase to operational phase. Each body begins its defined recurring meetings and starts executing its core responsibilities: (1) PMO Core Team: weekly standups, monthly design-change and cost-control reviews; (2) Cost Authority: monthly earned-value tracking, quarterly cost-to-complete forecasting; (3) Certification Panel: monthly design reviews with engineering teams; (4) Risk Authority: monthly risk tracking, quarterly sensitivity analysis; (5) Ecological Committee: baseline-data collection, EIA development. This step marks the formal operational launch of the governance system.

**Responsible Body/Role:** All five governance bodies (Binational Project Board, PMO Core Team, Cost Authority, Certification Panel, Risk Authority, Ecological Committee) operating independently and in coordination

**Suggested Timeframe:** Month 2 onwards (2026-12-12 and continuing)

**Key Outputs/Deliverables:**

- Monthly status reports from each governance body (PMO, Cost Authority, Certification, Risk, Ecology)
- First monthly PMO standup meeting minutes and action log
- First monthly Cost Authority earned-value report
- First monthly Risk Authority register update
- First monthly Ecological Committee baseline-data progress report

**Dependencies:**

- All five governance bodies formally constituted (Month 1–3 = 2026-11-12 to 2027-01-12)
- Inaugural meetings held and operating procedures approved (Month 1–3 = 2026-11-12 to 2027-01-12)
- Project sponsor funding and authorization confirmed (Month 0 = 2026-10-12)