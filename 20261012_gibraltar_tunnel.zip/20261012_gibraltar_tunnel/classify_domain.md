**Primary domain:** Submerged Floating Tunnel Engineering

**Secondary domains:** Marine Geotechnical Engineering, Transport Infrastructure Finance, High-Speed Railway Systems

**Rationale:** Submerged Floating Tunnel Engineering is the only outcome-role candidate and names the core mechanism: buoyant anchored concrete tunnel tubes at 100 m depth. Finance, law, geotechnics, railway systems, and megaproject management are subordinate constraints or methods.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Submerged Floating Tunnel Engineering | 5 | 5 | outcome | Core mechanism: buoyant, anchored submerged concrete tunnel tubes at 100 m depth. |
| International Infrastructure Law | 5 | 4 | constraint | Bi-national treaty, jurisdiction, maritime boundaries, and concession arrangements between Spain and Morocco govern delivery. |
| Marine Geotechnical Engineering | 4 | 4 | method | Seabed foundations, pillars, and anchoring in the seismically active Strait of Gibraltar. |
| High-Speed Railway Systems | 4 | 4 | method | Tunnel must carry high-speed rail, requiring track, signalling, traction power, and ventilation integration. |
| Marine Environmental Assessment | 4 | 4 | constraint | Strait of Gibraltar ecosystems, shipping, and seismic setting require environmental impact permitting. |
| Offshore Hydrodynamics | 4 | 4 | method | Strait currents, waves and internal tides drive tunnel and mooring loads. |
| Earthquake Engineering | 4 | 4 | constraint | The Eurasia-Africa plate boundary imposes seismic design demands on the tunnel and anchors. |
| Transport Infrastructure Finance | 4 | 3 | constraint | €40 billion binational funding, procurement, and public-private structuring over 20 years. |
| Megaproject Management | 4 | 3 | method | A 20-year, €40 billion bi-national programme needs integrated governance and delivery control. |