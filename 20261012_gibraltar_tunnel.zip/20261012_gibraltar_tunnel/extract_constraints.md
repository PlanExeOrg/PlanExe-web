## Positive Constraints

- Duration: 20-year infrastructure initiative
- Budget: €40 billion
- Construct a pillar-supported transoceanic submerged tunnel connecting Spain and Morocco
- Use a system of submerged, buoyant concrete tunnels
- Tunnels engineered for high-speed rail traffic
- Tunnels securely anchored at a controlled depth of 100 meters below sea level
- Project start as soon as possible (ASAP)
- Do not present invented numbers as facts; mark figures that are not user constraints or established benchmarks as (estimate) or (proposed threshold)
- Write in the impersonal voice of a planning document
- Refer to points in time as month offsets from project start (e.g., Month 3 = 2027-01-12), with project start at Month 0 = 2026-10-12

## Negative Constraints

- Do not turn example values from input documents ("e.g. ...") into requirements
- Do not refer to oneself or the writing process (no "I", "my knowledge", "I could not verify", "I recomputed")
- Do not write calendar dates directly; use month offsets only
