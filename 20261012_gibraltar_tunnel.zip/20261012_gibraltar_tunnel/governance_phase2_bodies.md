### 1. Binational Project Board

**Rationale for Inclusion:** Strategic oversight body for a treaty-level megaproject requiring high-level political and financial commitment across two states, EU partners and multilateral lenders. The Board provides direction on budget allocation above strategic thresholds (>5% cost variance), approves major design decisions (support concept, concept freeze), ratifies stage gates and tranche releases, and resolves disputes between Spanish and Moroccan authorities that exceed operational authority. Essential for maintaining sustained political will across a 20-year horizon and multiple election cycles.

**Responsibilities:**

- Approve the project's strategic direction, including the choice between competing support concepts (hybrid pillar/tether vs. alternatives) at the Month 24 (2028-10-12) gate.
- Ratify tranche releases (Months 12, 24, 36, 48, 60 = 2027-10-12, 2028-10-12, 2029-10-12, 2030-10-12, 2031-10-12 and beyond) based on independent gate-readiness evidence; withhold tranches if gate criteria are not met.
- Resolve design-change requests exceeding 5% cost variance or 3-month schedule impact, with authority to escalate to ministerial level if consensus cannot be reached.
- Approve the annual operational and capital budget, including contingency deployment and reserve drawdowns.
- Review and approve binational agreements, procurement policy alignment, and dispute-resolution outcomes affecting both states.
- Monitor top-level schedule variance, cost status and risk trends quarterly; escalate critical risks to participating governments.

**Initial Setup Actions:**

- Establish Board composition: one Spanish director, one Moroccan director, one independent technical director (Chair with tie-breaking authority), and one EU/multilateral-lender observer (non-voting)
- Codify Board decision rules: unanimous consent preferred; if tie between Spanish and Moroccan directors, Chair casts tie-breaker; decisions below 2% variance may be delegated to Chief Executive Officer
- Establish quarterly Board meeting cadence starting Month 1 (2026-11-12) and monthly during critical gates (Month 6–12 = 2027-04-12 to 2027-10-12, Month 24 = 2028-10-12, Month 36–48 = 2029-10-12 to 2030-10-12).
- Define escalation criteria: issues unresolvable by consensus escalate to ministerial steering committee within 15 days; ministerial decision binding on project.
- Approve the independent Cost Authority charter (Month 2–3 = 2026-12-12 to 2027-01-12) and Lead Certifier appointment (Month 6 = 2027-04-12) before detailed design begins.

**Membership:**

- Spanish Government Director (transport/infrastructure ministry or concession-holder appointee)
- Moroccan Government Director (transport/infrastructure ministry or concession-holder appointee)
- Independent Technical Chair (international maritime/tunnel engineering expert, no national affiliation, appointed jointly by both governments; term 4 years, renewable once)
- EU / Multilateral Lender Observer (optional non-voting member from European Commission or development bank co-financing the project; provides lender perspective on tranches and risk appetite)

**Decision Rights:** Strategic decisions with threshold authority: (1) Tranche release >EUR 0.5 billion requires Board approval via formal vote; (2) Design changes >5% cost variance or >3 months schedule impact require Board approval; (3) Gate go/no-go decisions (Months 9, 15, 24, 36, 48 = 2027-07-12, 2028-01-12, 2028-10-12, 2029-10-12, 2030-10-12) are Board decisions based on independent evidence from the Project Cost Authority and Lead Certifier; (4) Major governance or procurement-framework changes require Board decision plus treaty-level ratification; (5) Contingency reserve deployment above EUR 500 million per decision requires Board approval.

**Decision Mechanism:** Majority vote of the three voting members (Spanish, Moroccan, Chair). In case of tie (one director votes yes, one votes no), the Chair casts the tie-breaking vote. Consensus strongly preferred; if consensus cannot be reached after 2 weeks of discussion, matter escalates to the Ministerial Steering Committee (see escalation_path) within 3 days for binding political decision. Board decisions documented in writing with rationale within 5 days of vote; rationale made public (within 30 days, redacting commercial or security details).

**Meeting Cadence:** Monthly during Months 0–12 (2026-10-12 to 2027-10-12) and critical gates (Months 24, 36, 48 = 2028-10-12, 2029-10-12, 2030-10-12); quarterly thereafter (Months 12–60 = 2027-10-12 to 2031-10-12) unless additional meetings called by 2 directors or the Chair. Emergency sessions convened within 48 hours if a risk event requires decision.

**Typical Agenda Items:**

- Gate readiness review: independent evidence from Cost Authority, Certifier and operational teams on go/no-go status; decision to release or hold tranches.
- Cost and schedule status: variance analysis by tranche, top 10 risks, mitigation actions, confidence in forecast cost-to-complete.
- Major design decisions: concept freeze (Month 24 = 2028-10-12), load cases, egress regime, support-concept commitment, certification finding resolution.
- Governance and treaty issues: procurement dispute resolution, national regulatory misalignment, dispute-escalation status, treaty-amendment proposals.
- Stakeholder and political updates: government priorities, lender and insurer feedback, environmental-consent progress, shipping and security coordination.

**Escalation Path:** Issues unresolvable by Board consensus (after 2 weeks of discussion) escalate to a Ministerial Steering Committee comprising the Spanish and Moroccan ministers responsible for transport and a representative from the EU (if EU funding >20%). Ministerial decision is binding on the project within 10 days. If ministerial consensus fails, the matter is escalated to the two governments' prime ministers or equivalent; decision must be issued within 30 days. For decisions involving a tie-break by the independent Chair, the relevant director may escalate to the Ministerial Steering Committee within 5 days for review; ministerial decision overrides Board decision but must be documented and explained.
### 2. Project Management Office and Core Delivery Team

**Rationale for Inclusion:** Operational management body responsible for day-to-day execution, cost control, schedule management, and risk mitigation within approved budgets and thresholds. The PMO translates Board-level strategic decisions into detailed work plans, tracks progress against milestones, manages contractor interfaces, coordinates work across two coasts, and escalates issues that exceed operational authority to the Board. Essential for delivering a 20-year programme with hundreds of staff, multiple contractors and partners, and tight quality and safety requirements.

**Responsibilities:**

- Develop and maintain a detailed Critical Path Method (CPM) schedule at P50/P80 confidence; manage schedule variance and weather-window utilisation.
- Manage the project cost baseline and contingency reserve (EUR 7.2 billion); approve design changes up to 2% cost variance without Board approval; track contractor invoices and change orders.
- Coordinate seabed investigation campaign (Months 0–18 = 2026-10-12 to 2028-04-12) with independent reviewers; prepare Month 24 (2028-10-12) gate evidence on support-concept resolution.
- Oversee design development and interface with the Lead Certifier; manage gate criteria compliance and certification findings tracking.
- Manage casting-yard construction and ramp-up at Algeciras and Tanger Med; coordinate material procurement and quality control across dual yards.
- Plan and execute fabrication and immersion logistics; manage immersion schedules, weather windows, and towing/landing procedures.
- Coordinate with environmental, maritime and rail-integration programmes; ensure schedule integration and mitigation compliance.
- Prepare quarterly progress reports for the Board and binational governments; conduct risk and change reviews; manage stakeholder communication.

**Initial Setup Actions:**

- Appoint a Chief Executive Officer (Month 0 = 2026-10-12) and establish a Core Delivery Team (project controls, engineering, contracts, finance, risk, environmental, rail integration) by Month 1 (2026-11-12).
- Develop a detailed CPM schedule at P50/P80 by Month 1 (2026-11-12); identify critical path and schedule reserve allocation.
- Establish a Design Change Control Board (DCCB), meeting monthly from Month 3 (2027-01-12) onwards, with authority to approve changes <2% variance and escalate others to CEO or Board.
- Create a Project Cost Authority within the PMO by Month 2–3 (2026-12-12 to 2027-01-12) with independent audit authority; establish monthly earned-value tracking and quarterly cost-to-complete forecasting.
- Set up a Risk Management Register by Month 1 (2026-11-12), tracking all 19 risks identified in the assumptions document and any project-specific risks; conduct monthly reviews and quarterly risk-governance updates to the Board.

**Membership:**

- Chief Executive Officer (reports to the Board; appointed by the Board; typically an experienced megaproject delivery leader with multinational experience)
- Director of Project Controls and Finance (managing cost, schedule, earned-value, contingency tracking and budget forecasting)
- Director of Engineering and Design (managing seabed investigation, design development, coordination with the Lead Certifier, and technical working groups)
- Director of Contracts and Procurement (managing competitive bidding, contract award, contractor performance, and supply-chain partnerships)
- Director of Environmental and Ecological Compliance (managing the joint ecological baseline, environmental-consent coordination, and mitigation delivery)
- Director of Rail Integration and Operations Planning (managing landside network coordination, rail-operator agreements, signalling standards and commissioning planning)
- Head of Risk and Assurance (managing the Risk Register, risk reviews, independent audits, and escalations to the Board)

**Decision Rights:** Operational decisions and delegated authority: (1) Design changes <2% cost variance may be approved by the CEO without Board escalation; (2) Changes 2–5% variance require DCCB recommendation and CEO sign-off, with notification to the Board within 5 days; (3) Changes >5% or >3-month schedule impact escalate to the Board; (4) Contingency drawdowns <EUR 500 million per decision may be approved by the CEO with Finance Director sign-off and Risk Authority audit; (5) Contractor performance issues, schedule variance and cost variance >5% of current tranche escalate to the Board; (6) Monthly progress reports and quarterly risk updates are issued to the Board and both governments.

**Decision Mechanism:** CEO decision authority for changes <2% cost variance, made in consultation with affected Directors and DCCB (monthly forum). Changes 2–5% are recommended by DCCB (consensus preferred, simple majority acceptable if DCCB cannot reach consensus) and approved by CEO with Finance and Risk Director sign-off. Major cost or schedule decisions requiring Board escalation are documented with independent analysis (Finance, Risk, Controls) and presented to the Board within 2 weeks of discovery. Risk decisions are made by the Risk Authority (Head of Risk and Assurance) in consultation with operational leaders; high-severity risks (impact >EUR 500 million or >6-month schedule) escalate to the Board within 1 week.

**Meeting Cadence:** Weekly Core Delivery Team standup (30–60 minutes) for schedule and cost status; monthly Design Change Control Board (2–4 hours) for design-change review; monthly Risk and Assurance review (1–2 hours) for risk trends and mitigation effectiveness; monthly Project Control review (2–3 hours) for earned-value analysis, cost-to-complete and contingency status. Quarterly Board-readiness meetings (1 day) prior to scheduled Board meetings, consolidating all updates and preparing gate evidence.

**Typical Agenda Items:**

- Weekly: schedule variance (days slip/gain by work package), critical-path updates, imminent risk triggers, contractor performance issues, environmental or permitting blockers.
- Monthly DCCB: design-change log (all changes >0.1% cost variance, cumulative tracking), change impact analysis (cost, schedule, risk), recommendation for Board or CEO approval.
- Monthly Risk: top 10 risks by severity, mitigation status, emerging risks, risk-driven cost and schedule variance, escalation decisions.
- Monthly Cost/Control: earned-value by tranche, invoice audit findings, contractor claims status, contingency deployment log, forecast cost-to-complete at P50 and P80, variance analysis >5% per tranche.
- Quarterly Board prep: consolidated gate-readiness evidence, cost and schedule confidence level, top risks and mitigation, stakeholder updates, lender/insurer feedback.

**Escalation Path:** Design changes >5% cost variance or >3-month schedule impact, and cost/schedule variance >5% of current tranche, escalate from CEO to the Project Board within 2 weeks, with independent Finance and Risk analysis. Risk events with potential impact >EUR 500 million or >6-month schedule slip escalate from the Risk Authority to the Board within 1 week. Unresolved contractor disputes or contractual claims >EUR 50 million escalate from the Contracts Director to the CEO and Board within 15 days. Permitting or environmental compliance issues that could delay a gate or tranche release escalate from the Environmental Director to the CEO and Board within 5 days. Any issue presenting a material threat to the project's feasibility (e.g., support concept redesign, treaty delay, lender withdrawal) escalates immediately to the Board, with escalation authority vested in any two of the Core Team Directors or the CEO.
### 3. Independent Cost Authority

**Rationale for Inclusion:** Specialized assurance body responsible for objective, independent tracking of project cost and schedule performance against the EUR 40 billion envelope. First-of-kind megaprojects commonly experience cost overruns of 20–40%; the project plan identifies a plausible cumulative overrun of EUR 10–18 billion (25–45% of envelope) versus a EUR 7.2 billion contingency reserve. An independent cost authority, staffed by external auditors and financial specialists with no affiliation to either state or the delivery team, provides the objectivity needed for lenders, governments and the Board to make informed funding decisions. The authority has explicit escalation authority to flag cost and schedule variances above 5% and demand corrective action within defined timelines.

**Responsibilities:**

- Conduct monthly earned-value analysis (schedule performance index, cost performance index) and variance reporting at the tranche level and aggregate programme level.
- Prepare quarterly cost-to-complete forecasts at P50 (50th percentile) and P80 (80th percentile) confidence; track confidence trends month-to-month.
- Audit all contractor invoices, change orders and cost claims; verify that costs charged align with contractual terms and approved scope changes.
- Review all design-change cost impacts independently before DCCB or CEO approval; flag cost inflation risk and cumulative change-order trends.
- Conduct quarterly risk-cost sensitivity analysis: model the top 10 risks and their cost/schedule impacts; update the contingency-reserve adequacy assessment.
- Escalate cost and schedule variance >5% of the current tranche to the Board and both governments within 5 business days; recommend corrective-action options.
- Provide independent certification that each tranche release is justified by actual spend, committed expenditure, and cost-to-complete forecasts aligned with the approved budget.

**Initial Setup Actions:**

- Establish the Cost Authority as an independent entity, chartered by the Project Board, reporting directly to the Board (not to the PMO CEO) by Month 2–3 (2026-12-12 to 2027-01-12).
- Appoint a Chief Financial Officer and Controller with multinational audit/megaproject experience; staff the Authority with a Finance Manager, Cost Engineer, Schedule Analyst and Audit Specialist by Month 3 (2027-01-12).
- Define the cost baseline for each tranche: establish P50 and P80 cost-at-completion forecasts and confidence levels by Month 3 (2027-01-12); document approved scope and change-control thresholds.
- Establish earned-value-tracking systems, contractor-invoice audit workflows, and change-order logging within the project's financial systems by Month 3 (2027-01-12).
- Publish the quarterly cost and schedule reporting format and cadence: monthly variance reports, quarterly gate-readiness cost certification, annual cost-confidence statement.

**Membership:**

- Chief Financial Officer (head of the Authority; independent financial specialist, no affiliation to Spanish or Moroccan government or delivery contractor; reports directly to the Board)
- Controller (responsible for cost baseline, earned-value tracking, and contingency reserve management)
- Finance Manager (day-to-day contractor-invoice audit and change-order cost verification)
- Cost Engineer (independent cost estimates for design changes, risk sensitivity analysis, and cost-to-complete forecasting)
- Schedule Analyst (earned-value schedule tracking, critical-path variance analysis, and weather-window utilisation modelling)

**Decision Rights:** The Cost Authority has authority to: (1) Audit and certify or reject contractor invoices and cost claims if they do not align with approved contracts or scope; (2) Recommend cost-control actions to the Board and PMO CEO if variance exceeds 5% or contingency deployment trends suggest reserve inadequacy; (3) Certify that each tranche release is justified by financial performance and cost-to-complete forecasts; (4) Halt or delay contractor payments if invoice documentation is incomplete or inconsistent with earned-value records, pending PMO CEO and Finance Director resolution; (5) Propose contingency-reallocation or cost-mitigation actions to the Board if risk sensitivity analysis identifies inadequate reserves for a particular work phase.

**Decision Mechanism:** Monthly cost and schedule variance is reported by the Controller without Board vote (administrative reporting). If variance >5% of the current tranche, the Chief Financial Officer escalates to the Board in writing within 5 business days, with independent cost-to-complete analysis and recommended corrective actions. The Board must respond within 10 days with either: (a) acceptance of the variance and reforecast, (b) direction to the PMO to implement corrective actions within a defined timeline, or (c) decision to reallocate contingency reserves or request additional funding. Contractor-invoice disputes are resolved through a three-step process: (1) Finance Manager and Contracts Director attempt resolution within 10 days; (2) if unresolved, PMO CEO makes final project decision within 15 days, documented in writing; (3) if Authority disagrees with CEO decision, matter escalates to the Board within 5 days for binding resolution.

**Meeting Cadence:** Monthly earned-value review (1–2 hours) internal to the Cost Authority; monthly summary variance report issued to the Board and PMO by the 5th working day of each month. Quarterly cost-to-complete forecasting and gate-readiness certification (1 full day) conducted one week before each scheduled Board meeting (Months 8, 14, 23, 35, 47, 59 = 2027-06-12, 2027-12-12, 2028-09-12, 2029-09-12, 2030-08-12, 2031-08-12 and quarterly thereafter). Annual independent audit of Cost Authority processes and cost-data accuracy by an external accounting firm (Month 24, 48, 72 onwards = 2028-10-12, 2030-10-12, 2032-10-12 and every 24 months).

**Typical Agenda Items:**

- Monthly: earned-value summary (BCWS, BCWP, ACWP by tranche), schedule and cost indices, variance analysis vs. Plan and variance trend, contingency-reserve drawdown log, top 5 cost-variance drivers, escalation decisions.
- Quarterly: cost-to-complete forecast (P50, P80) and confidence trend analysis, risk-cost sensitivity (top 10 risks and impact ranges), contingency-reserve adequacy assessment, tranche-readiness certification, corrective-action tracking from previous variance escalations.
- Annual: full audit of project cost baseline and approved-change log, cost-data quality and systems review, historical cost-forecasting accuracy (actuals vs. quarterly P50/P80 forecasts), contractor-claim patterns and dispute resolution effectiveness, external audit findings and corrective actions.

**Escalation Path:** Monthly variance >5% of the current tranche escalates from the Controller to the Chief Financial Officer, who reports to the Board within 5 business days. If the Board does not respond with corrective action or contingency allocation within 10 days, the matter escalates to the Ministerial Steering Committee (Spanish and Moroccan transport ministers plus EU observer). Contractor-invoice disputes that the PMO CEO cannot resolve within 15 days escalate to the Project Board for binding decision within 5 days. If the Cost Authority identifies a pattern of cost overruns or contingency depletion that threatens the programme's financial feasibility (e.g., cumulative variance >EUR 2 billion by a gate, or >5% variance in consecutive quarters), the Chief Financial Officer may issue a formal Feasibility Alert to the Board and both governments, recommending trigger points for scope or schedule adjustment decisions.
### 4. Design Basis and Independent Certification Panel

**Rationale for Inclusion:** Specialized technical assurance body responsible for establishing the design code, safety standards and certification criteria for a structure type with no international design precedent. The project faces seismic, hydrodynamic, marine-construction and long-term durability unknowns that must be codified into a defensible design basis before detailed design begins. An independent panel, comprising international experts in offshore engineering, immersed tunnels, seismic design and railway safety, working under a single Lead Certifier appointed by the Board, ensures that both Spanish and Moroccan regulators and international lenders/insurers accept the design basis. The panel also sets gate criteria, reviews certification findings at design milestones, and issues the final operating permit. Without a robust certification regime, the project cannot be financed or insured.

**Responsibilities:**

- Develop a project-specific design code by Month 9 (2027-07-12), adapting ISO 23600 (immersed tubes), EN 1993-1-11 (cable structures), EN 1992-1-1 (concrete), EN 1998 (seismic design) and Moroccan standards; codify seismic load cases, hydrodynamic loads, tether fatigue criteria, safety factors and inspection protocols.
- Establish design certification gates at Months 9, 18, 30 and 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) (concept, 30% design, 60% design, detailed design); define pass/fail criteria for each gate in advance.
- Review and approve the seismic hazard assessment (probabilistic seismic hazard analysis at 475- and 2475-year return periods) by Month 12 (2027-10-12); confirm design earthquake motions for load-case definition.
- Oversee prototype testing: full-scale tether pull-test, transition-joint mock-up assembly and performance testing, and segment hydrostatic test; certify results by Month 48 (2030-10-12).
- Conduct regular design-review audits (quarterly during design phases Months 12–48 = 2027-10-12 to 2030-10-12) to identify outstanding certification findings and verify closure rate; escalate non-closures to the Board.
- Prepare the final Safety Case for each gate, documenting that design meets code requirements and provides defensible evidence for insurers and regulators; issue final operating permit by Month 130 (2037-08-12).
- Provide independent expert testimony in regulatory disputes if Spanish or Moroccan authorities diverge on code interpretation or load-case requirements.

**Initial Setup Actions:**

- Appoint a Lead Certifier (classification society such as DNV-GL, ABS or equivalent, or a consortium of independent technical experts) by Month 6 (2027-04-12); establish Lead Certifier authority and scope in the contract (2-year initial term, renewable).
- Form a Technical Advisory Panel comprising: international experts in submerged tunnels/offshore structures, seismic and geotechnical engineering, railway safety and emergency response; Spanish and Moroccan technical authorities as observers (non-voting); panel size 5–7 members.
- Draft a project design code incorporating existing standards and project-specific requirements by Month 6 (2027-04-12); publish a draft for stakeholder and regulator review by Month 9 (2027-07-12); finalize and Board-approve by Month 9 (2027-07-12).
- Define the certification gate criteria (pass/fail checklist) for each gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) by Month 9 (2027-07-12); communicate criteria to design teams so gate readiness is clear.
- Establish a Design Review Schedule aligning with CPM schedule: monthly during design phases, with quarterly Lead Certifier audits to track open findings and closure rate.

**Membership:**

- Lead Certifier (independent classification society or consortium; reports to the Project Board, not the PMO; typically one firm with contract authority and lead signature)
- Chair, Technical Advisory Panel (international expert in submerged tunnels or offshore structures; no affiliation to Spanish or Moroccan authorities; appointed by the Lead Certifier in consultation with the Board)
- Technical Panel Members (typically 4–6): experts in seismic/earthquake engineering, marine geotechnics, tunnel/immersed-tube design, railway safety, emergency egress and operations (at least one from EU/OECD country to ensure international standard alignment)
- Spanish National Technical Authority Representative (observer, non-voting; typically from the transport ministry or national rail authority; provides input on Spanish code expectations and regulator acceptance)
- Moroccan National Technical Authority Representative (observer, non-voting; typically from the transport ministry; provides input on Moroccan code expectations and regulator acceptance)

**Decision Rights:** The Lead Certifier has authority to: (1) Approve or reject design submissions against the agreed design code at each gate; (2) Issue interim certification letters at each gate (Months 9, 18, 30, 42 = 2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) confirming that design meets code or identifying outstanding findings; (3) Require additional testing or analysis if code compliance is not demonstrated (e.g., prototype tether pull-test, full-scale joint mock-up); (4) Issue the final Safety Case and operating permit by Month 130 (2037-08-12), conditioned on satisfactory testing, construction quality and operational readiness; (5) Recommend rejection of a gate if outstanding findings are non-minor (material impact on safety, cost or schedule); (6) Provide expert judgment on code interpretation if Spanish and Moroccan authorities disagree on load cases or safety factors.

**Decision Mechanism:** Gate certification is a formal process: (1) Design team submits design package to the Lead Certifier 6 weeks before the gate date; (2) Lead Certifier conducts technical review with panel support, typically over 4–6 weeks; (3) Lead Certifier issues either a Certification Letter (design approved) or a Finding Letter (identifies outstanding items requiring resolution); (4) If findings are identified, design team has 2 weeks to respond with corrective actions or justification; (5) Lead Certifier re-reviews and issues either approval or recommendation for Board escalation; (6) Board makes the go/no-go gate decision based on Lead Certifier recommendation; (7) gate decisions are documented in writing with technical rationale, accessible to stakeholders (redacting only commercial/security details). Design code interpretation disputes between Spanish and Moroccan authorities are resolved through the Technical Panel: if consensus cannot be reached, the Panel Chair issues a binding interpretation (30 days to resolve).

**Meeting Cadence:** Monthly design-review meetings (2–4 hours) between the design team and the Lead Certifier, starting Month 12 (2027-10-12); quarterly technical panel meetings (1 day) during design phases (Months 12–48 = 2027-10-12 to 2030-10-12) for design audit and open-findings review. Quarterly interim certifications (Months 18, 30, 42 = 2028-04-12, 2029-04-12, 2030-04-12) issued by the Lead Certifier. Gate certification submittals at Months 9, 18, 30, 42 (2027-07-12, 2028-04-12, 2029-04-12, 2030-04-12) with go/no-go decisions within 2 weeks of submission.

**Typical Agenda Items:**

- Monthly design review: design update by package (load cases, structural design, geotechnical foundation, tether and anchor design, egress provisions, rail integration), compliance vs. design code, outstanding findings, schedule for resolution.
- Quarterly panel meeting: open-findings summary, closure rate, design risks identified in review, testing plan and timeline, resource adequacy, escalation decisions.
- Gate certification: formal submission package review, compliance checklist against gate criteria, interim or final certification decision, conditions for next gate.

**Escalation Path:** Non-minor certification findings (material impact on safety, cost >EUR 500 million, or schedule >6 months) escalate from the Lead Certifier to the Board within 2 weeks of gate submission, with a recommendation to approve, approve-with-conditions, or reject the gate. The Board has 10 days to decide; if the Board approves the gate despite a non-minor finding, that decision is documented with Board rationale and reported to both Spanish and Moroccan authorities. Design-code interpretation disputes between national authorities escalate from the Technical Panel Chair to the Board within 30 days; the Board may appoint an independent international arbitrator if political solution is preferred. If a finding remains unresolved at a gate, the Lead Certifier may recommend that the gate remain open (no go) until finding is closed; only a unanimous Board vote (Spanish, Moroccan and Chair, all three voting yes) can override the Lead Certifier and approve a gate with open non-minor findings.
### 5. Risk and Assurance Authority

**Rationale for Inclusion:** Specialized assurance body responsible for comprehensive risk management, compliance oversight and mitigation effectiveness across all 19 identified risks (support-concept uncertainty, treaty delays, cost overruns, schedule compression, environmental permitting, marine construction, governance disputes, supply-chain constraints, certification complexity, operational durability, demand shortfall, shipping security, seabed hazards, geotechnical unknowns, seismic design, emergency response, political transitions and cost control). The project faces multiple interconnected risks, any one of which could delay or derail the 20-year programme; a dedicated, independent Risk Authority with authority to escalate risk events and trigger governance responses is essential. The Authority also oversees GDPR, ethical compliance, corruption prevention and supply-chain due diligence, given the multinational public-procurement and binational authority context.

**Responsibilities:**

- Establish and maintain a comprehensive Risk Register (Months 0–240 = 2026-10-12 to 2046-10-12) covering all project risks identified in the assumptions document and emergent risks; conduct monthly risk-review meetings with the Core Delivery Team.
- Assess the probability, impact and timing of each risk; update risk scores monthly and conduct quarterly sensitivity analysis to identify risks with highest expected value.
- Develop and track mitigation strategies for the top 10 risks; monitor mitigation effectiveness and recommend escalation if a risk emerges or mitigation fails (e.g., seabed investigation discovers unexpected geology).
- Track cost and schedule exposure from all 19 risks; ensure that the contingency reserve (EUR 7.2 billion) is adequate for the top-risk scenarios; escalate if reserve depletion trends suggest inadequacy.
- Oversee GDPR and data-privacy compliance for personal data processed by the binational authority (payroll, contractor records, maritime traffic data); establish data-governance policies by Month 6 (2027-04-12).
- Oversee ethical and compliance standards: corruption prevention, conflicts of interest, procurement transparency; establish a whistleblower hotline and grievance log by Month 3 (2027-01-12); conduct annual third-party compliance audits.
- Manage supply-chain due diligence: vet all tier-1 contractors for sanctions compliance, labour standards, environmental practices, and conflicts of interest; establish a modern slavery statement and third-party assurance by Month 12 (2027-10-12).
- Prepare quarterly risk-governance reports for the Board and governments; escalate high-severity risks (impact >EUR 500 million, >6-month schedule, or threat to feasibility) within 1 week of detection.

**Initial Setup Actions:**

- Establish the Risk Authority as an independent function, reporting to the Project Board (not the PMO CEO), by Month 1 (2026-11-12); appoint a Head of Risk and Assurance with multinational megaproject and governance experience.
- Develop a Risk Register template and risk-assessment methodology (qualitative and quantitative) by Month 1 (2026-11-12); populate the Register with 19 baseline risks from the assumptions document by Month 1 (2026-11-12).
- Define risk-escalation thresholds: events with >EUR 500 million cost impact, >6-month schedule impact, or threat to programme feasibility escalate within 1 week; escalate to Board within 2 weeks; top 10 risks monitored monthly, full Register reviewed quarterly.
- Establish a Whistleblower Hotline (Month 1–2 = 2026-11-12 to 2026-12-12), governance policies for handling reports, and quarterly summary reporting (anonymized) to the Board.
- Draft a Compliance and Ethics Policy by Month 3 (2027-01-12), covering procurement transparency, conflict-of-interest declaration, supply-chain due diligence and GDPR; Board approval by Month 6 (2027-04-12).

**Membership:**

- Head of Risk and Assurance (senior risk and governance specialist; reports directly to the Board; independently staffed, not reporting to the PMO CEO)
- Risk Manager (day-to-day risk tracking, mitigation monitoring, escalation decisions)
- Compliance and Ethics Officer (GDPR, corruption prevention, whistleblower hotline management, annual compliance audits)
- Supply-Chain Assurance Specialist (vendor due diligence, sanctions compliance, labour and environmental standards verification)

**Decision Rights:** The Risk Authority has authority to: (1) Escalate any risk event with potential impact >EUR 500 million or >6-month schedule to the Board within 1 week of detection; (2) Recommend risk-mitigation actions and corrective-action timelines to the PMO and Board; (3) Request additional contingency reserve allocation if risk sensitivity analysis indicates reserve inadequacy; (4) Halt or delay contractor engagement if due-diligence findings reveal sanctions risk, unresolved legal disputes, or labour-practice concerns; (5) Recommend rejection of a contractor proposal if compliance or ethical concerns are material; (6) Issue a Feasibility Alert if cumulative risk exposure exceeds the programme's ability to deliver within the EUR 40 billion envelope and 20-year horizon (Month 240 = 2046-10-12); (7) Conduct investigations into suspected corruption, conflicts of interest or fraud allegations and report findings to the Board and governments within 30 days.

**Decision Mechanism:** Monthly risk-register update (administered by Risk Manager, no formal vote required; changes documented and reported to the Board). Risk-escalation decisions made by the Head of Risk and Assurance when impact thresholds are exceeded (EUR 500 million, 6-month schedule, or feasibility threat); escalation is automatic within 1 week of risk event or emerging evidence. Whistleblower and compliance reports are reviewed by the Compliance Officer and escalated to the Head of Risk and Assurance; allegations of material misconduct (potential EUR 10 million impact or greater) are escalated to the Board within 5 business days. Contractor due-diligence decisions are made by the Supply-Chain Assurance Specialist in consultation with the Contracts Director; if no resolution within 15 days, matter escalates to the PMO CEO; if unresolved within another 10 days, escalates to the Board.

**Meeting Cadence:** Monthly risk-register review (1–2 hours) internal to the Risk Authority; monthly risk-governance summary (max. 2 pages) issued to the Board by the 10th working day of each month. Quarterly risk-sensitivity analysis and top-10-risks deep dive (1 day) one week before each Board meeting. Annual compliance and ethics audit by an external firm (Month 24, 48, 72 onwards = 2028-10-12, 2030-10-12, 2032-10-12). Quarterly whistleblower report summary (anonymized, 30 minutes) to the Board.

**Typical Agenda Items:**

- Monthly: Risk Register update summary (new risks added, retired risks, probability/impact changes), top-10 risks by expected value, mitigation status, escalation decisions, emerging-risk indicators.
- Quarterly: sensitivity analysis (expected cost/schedule impact of top 10 risks at P50 and P80), contingency reserve adequacy assessment, portfolio-level risk aggregation, Feasibility Alert triggers, top-5 mitigation actions tracking.
- Annual: compliance audit findings and corrective-action status, whistleblower report themes and trends, supply-chain due-diligence effectiveness, contractor-performance and dispute patterns, anti-corruption control effectiveness.

**Escalation Path:** Risk events with impact >EUR 500 million or >6-month schedule automatically escalate from the Risk Manager to the Head of Risk and Assurance, who reports to the Board within 1 week. The Board must respond within 10 days with mitigation direction or contingency allocation. If a risk materializes (e.g., seabed investigation discovers unexpected geology) and the materialized cost or schedule impact exceeds EUR 500 million or 6 months, the event is classified as a Risk Trigger Event and escalates to the Board within 2 working days, with a request for emergency Board session within 5 days if necessary. Feasibility Alert (cumulative risk or cost exposure suggesting programme cannot deliver within EUR 40 billion and Month 240 = 2046-10-12 horizon) escalates to the Board and Ministerial Steering Committee within 2 weeks, with explicit recommendation for scope or schedule adjustment decisions. Whistleblower allegations involving potential fraud or corruption >EUR 10 million escalate to the Board, relevant governments and possibly law enforcement within 5 business days.
### 6. Binational Ecological and Environmental Compliance Committee

**Rationale for Inclusion:** Specialized assurance body responsible for ecological permitting, environmental-baseline compliance, and habitat-mitigation delivery in a marine-megafauna migration corridor protected under Spanish, Moroccan and EU regimes. Environmental consent is often the critical path in infrastructure projects; a multi-year baseline and seasonal timing restrictions can delay construction permitting 18–36 months. Parallel national environmental consents risk regulatory divergence (e.g., Spain requires year-round seasonal buffers, Morocco allows wider windows) that must be reconciled mid-construction, triggering injunctions and stop-work orders. A unified committee, with joint technical teams and a coordinating commission, harmonises consent conditions, manages baseline monitoring, enforces mitigation delivery and schedules construction work to comply with seasonal windows. The committee also coordinates with maritime authorities on shipping-exclusion zones and with the Ecological Permitting lever to ensure gate-readiness evidence.

**Responsibilities:**

- Conduct a joint multi-year ecological baseline (Months 0–12 = 2026-10-12 to 2027-10-12 minimum, with ongoing monitoring through Month 132 = 2037-10-12 opening) covering acoustic signatures, protected-species sightings, current profiles and sediment conditions in the crossing zone.
- Harmonise Spanish and Moroccan environmental assessments (Months 6–30 = 2027-04-12 to 2029-04-12) to identify conflicting mitigation requirements; resolve conflicts through the coordinating commission and escalate to both governments' environmental ministers if consensus fails.
- Prepare a joint environmental consent application (Months 6–24 = 2027-04-12 to 2028-10-12) that satisfies both Spanish and Moroccan regulators; secure harmonised consent by Month 24 (2028-10-12), latest Month 30 (2029-04-12).
- Design and cost ecological mitigation (artificial reef structures on pillars/tethers, long-term marine research partnerships, ferry-emissions offsets); budget EUR 250–400 million; embed mitigation as a binding condition in the consent.
- Schedule immersion and construction activities to respect seasonal windows for protected species (e.g., if migration season is May–September with 150 days/year usable, encode this into the CPM schedule); enforce compliance via a Construction Environmental Manager.
- Coordinate with maritime authorities (IMO, Spanish and Moroccan coast guards) on shipping-exclusion zones and sonar/radar monitoring for the no-anchoring corridor; update IMO vessel-traffic procedures by Month 12 (2027-10-12).
- Monitor construction environmental performance quarterly; track acoustic levels, sediment plumes, and incidental marine-mammal sightings; ensure mitigation delivery on schedule and budget; report to the Board and governments quarterly.

**Initial Setup Actions:**

- Appoint a Binational Ecological Committee lead (international environmental scientist, no national affiliation) and establish a joint technical team (marine biologists, hydrodynamicists, environmental assessment specialists from Spain and Morocco) by Month 1 (2026-11-12).
- Initiate the baseline ecological study (acoustic monitoring, visual surveys, oceanographic data collection) by Month 0 (2026-10-12); deploy seabed seismometers and current meters by Month 9 (2027-07-12); compile first-year data by Month 12 (2027-10-12).
- Draft the joint environmental impact assessment (EIA) based on baseline findings by Month 9 (2027-07-12); conduct stakeholder consultation (fishing communities, NGOs, local governments) by Month 12 (2027-10-12); finalize EIA by Month 18 (2028-04-12).
- Establish a Construction Environmental Manager role (joint Spanish–Moroccan team) by Month 24 (2028-10-12); this manager has authority to halt immersion work if seasonal windows are breached or mitigation conditions are violated.
- Negotiate mitigation partnerships (artificial reef design, research institutions) by Month 18 (2028-04-12); finalize mitigation scope and budget by Month 24 (2028-10-12); begin design of artificial reef structures by Month 30 (2029-04-12).

**Membership:**

- Binational Ecological Committee Lead (international environmental expert, independent, appointed jointly by Spanish and Moroccan environment ministries; reports to the Committee and the Board)
- Spanish Environmental Authority Representative (Spanish Ministry of Environment or equivalent; leads Spanish national EIA process and consent)
- Moroccan Environmental Authority Representative (Moroccan Ministry of Environment or equivalent; leads Moroccan national EIA process and consent)
- Marine Biologist and Hydrodynamicist (technical experts conducting baseline monitoring and impact assessment)
- NGO and Stakeholder Representative (liaison to environmental groups, fishing and port communities, ensuring transparency and co-design of consent conditions; non-voting member)
- Construction Environmental Manager (appointed Month 24 = 2028-10-12; enforces seasonal windows and mitigation compliance during construction)

**Decision Rights:** The Ecological Committee has authority to: (1) Determine acceptable seasonal windows for construction (e.g., May–September only, 150 days/year) based on baseline findings; encode these windows into the CPM schedule; (2) Design mitigation measures and cost estimates; recommend to the Board for approval and budget allocation within the EUR 7.2 billion contingency; (3) Recommend rejection of a permit application if baseline findings show unacceptable risk to protected species; escalate to the Board for override decision; (4) Require additional baseline data collection if findings are inconclusive; extend baseline timeline and gate dates if necessary (with Board approval); (5) Halt construction work if seasonal windows are breached or mitigation conditions are violated; the halt order stands for up to 30 days, during which the PMO must respond with corrective actions or Board escalation.

**Decision Mechanism:** Monthly baseline-data reviews and quarterly environmental-compliance audits (internal to the Committee, no formal vote). Environmental consent decisions made jointly by the Spanish and Moroccan environmental authority representatives; if they cannot reach consensus on permit conditions, the Ecological Committee Lead issues a recommendation to both governments' environment ministers within 15 days; the ministers have 10 days to decide; if they diverge, the matter escalates to the Binational Project Board for political resolution. Mitigation design and cost approval follow PMO change-control processes: changes <EUR 50 million can be approved by the Committee Lead with Board notification; changes >EUR 50 million require Board approval. Construction Environmental Manager halt orders are issued verbally within 24 hours of detection of a violation, with written justification within 48 hours; the halt stands until the PMO takes corrective action or escalates to the Board for risk acceptance.

**Meeting Cadence:** Monthly baseline-data and environmental-monitoring review (1–2 hours) during Months 0–12 (2026-10-12 to 2027-10-12); quarterly environmental-compliance audit (1 day) during construction phases (Months 36–132 = 2029-10-12 to 2037-10-12). Coordinated national EIA process meetings (monthly, Months 6–24 = 2027-04-12 to 2028-10-12). Harmonisation committee (every 2 weeks, Months 6–30 = 2027-04-12 to 2029-04-12) if Spanish and Moroccan consent conditions diverge.

**Typical Agenda Items:**

- Monthly baseline review: acoustic data quality, protected-species sightings (by species, date, location), hydrodynamic measurements, data-quality issues, sampling adjustments.
- Quarterly construction audit: immersion activity log (dates, locations, duration), seasonal-window usage (days spent vs. annual budget), mitigation delivery (artificial reef progress, research partnerships, acoustic monitoring), permit-condition compliance, incident reports.
- EIA development: baseline-findings summary, impact assessment methodology, draft permit conditions, mitigation design, stakeholder-consultation feedback.

**Escalation Path:** Environmental permit-condition disagreement between Spanish and Moroccan authorities escalates from the Ecological Committee to both environment ministries within 15 days; ministerial decision within 10 days; if ministers diverge, matter escalates to the Binational Project Board within 5 days for binding decision. Construction Environmental Manager halt orders (environmental violation detected) escalate to the PMO CEO within 24 hours; the halt stands until corrective action is taken or the Board accepts the risk (within 15 days). A halt order that exceeds 15 days or affects more than one immersion campaign escalates to the Board within 1 week, with a request for emergency Board session if the halt threatens the schedule. Baseline findings that show material change in environmental conditions (e.g., new protected-species congregation, shift in migration timing) escalate to the Ecological Committee Lead within 5 days of detection; escalate to the Board within 10 days if the finding materially changes permit conditions or mitigation scope.