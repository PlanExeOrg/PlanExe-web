A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | Seabed conditions along the Camarinal Sill corridor will support founded pillars where depth is <400 m and the hybrid pillar/tether split holds, so the support concept can freeze at Month 24 (2028-10-12) without a major redesign. | Desk-screen SECEGSA/SNED bathymetry, boring and seismic records plus GEBCO data, and run a parametric pillar bearing-capacity check by Month 3 (2027-01-12), before vessel mobilisation. | Archive data show >50% of the alignment deeper than 400 m, or typical strata with bearing capacity <250 kPa, making hybrid pillar founding unworkable. |
| A2 | Spain and Morocco will ratify a treaty with a binding Board tie-break, single lead certifier and delegated approval thresholds by Month 15 (2028-01-12), and keep funding commitments through election cycles. | Obtain signed heads-of-state letters of intent and a written mandate for the negotiation team by Month 3 (2027-01-12); ask both legal advisers to list incompatibilities with national law. | Either government declines a binding tie-break or single certifier, or legal review finds >=2 incompatibilities needing national legislative change. |
| A3 | Immersion can proceed at 60-90 usable days per year and 500-800 m per yard per year, so 14 km of tube is installed by Month 120 (2036-10-12) with the Month 240 (2046-10-12) limit as a margin. | Run a 30-year hydrographic and meteorological analysis for wave height <1.5 m and cross-current <0.5 m/s simultaneously, and test towing assumptions with a marine contractor by Month 3 (2027-01-12). | Climatology yields <60 usable days/year, or modelled immersion duration exceeds 11 years at P50. |
| A4 | Contractors, tether suppliers and skilled marine labour will be available at planned prices and volumes through Months 36-120 (2029-10-12 to 2036-10-12), with yard ramp-up slowing no more than 10-20% (estimate). | Run supply-chain mapping and sound out at least 5 tier-1 immersion, heavy-lift and tether suppliers on capacity and price commitments by Month 3 (2027-01-12). | Fewer than 2 qualified suppliers per critical item commit to capacity, or quoted day-rates exceed baseline by >30% (estimate). |
| A5 | Spanish and Moroccan environmental authorities will issue a single harmonised consent by Month 24 (2028-10-12), latest Month 30 (2029-04-12), that survives NGO legal challenge without injunctions. | Hold scoping meetings with both environment ministries and key NGOs by Month 3 (2027-01-12) and obtain written positions on unified consent and seasonal work windows. | Either ministry insists on a separate national permit, or NGOs state an intent to litigate, with a consent timeline later than Month 30 (2029-04-12). |
| A6 | States, EU and multilateral lenders will commit binding availability payments of about EUR 230-284 million/year (estimate) and fund the overrun gap, so privately financed rail systems reach financial close. | Convene a lender working group and obtain written indicative positions from both treasuries on availability payments and an overrun backstop by Month 9 (2027-07-12). | No treasury accepts a budget-law-backed payment, or lenders require DSCR >=1.0x with no sovereign support. |
| A7 | The pilot segment and tether/transition-joint tests will validate the design at full scale, and the lead certifier will accept the project-specific design code without major findings after Month 48 (2030-10-12). | Ask the E39 programme office and two classification societies to review the draft test and certification plan, and confirm in writing that pull-test, joint mock-up and pilot immersion results are accepted as sufficient evidence by Month 6 (2027-04-12). | Reviewers state that full-scale tests cannot represent 50-year fatigue and seismic response, or require additional testing of >= 12 months beyond the Month 48 (2030-10-12) plan. |
| A8 | Insurers will cover first-of-kind fatigue, vessel-strike and sabotage risk on commercially acceptable terms, and the no-anchoring corridor will be enforced by multi-flag shipping. | Approach at least 3 marine and construction underwriters and the IMO/maritime authorities for indicative terms and a corridor-consent timeline by Month 9 (2027-07-12). | Fewer than 2 underwriters quote cover, premiums exceed the O&M budget by >30% (estimate), or IMO process is projected beyond Month 48 (2030-10-12). |
| A9 | Passengers and freight operators will use the crossing at 4.0 million passengers/year at EUR 60 per trip, with through-running and landside feeder lines ready at opening. | Commission an independent demand and fare-elasticity study benchmarked against flights and ferries, and obtain feeder-line financing positions from both rail operators by Month 9 (2027-07-12). | Study shows opening demand < 3.0 million passengers/year at EUR 60, or feeder lines are unfunded for opening at Month 132 (2037-10-12). |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Treaty That Never Closed | Process/Financial | A2 | Binational Programme Director | CRITICAL (20/25) |
| FM2 | The Sill That Wouldn't Hold | Technical/Logistical | A1 | Chief Technical Officer | CRITICAL (20/25) |
| FM3 | The Tunnel Nobody Could Finish or Fund | Market/Human | A3 | Programme Schedule & Critical Path Lead | CRITICAL (20/25) |
| FM4 | The Payment Nobody Would Sign | Process/Financial | A6 | Cost Control & Project Finance Authority Lead | CRITICAL (20/25) |
| FM5 | The Yards With No Hands | Technical/Logistical | A4 | Marine Construction & Fabrication Programme Manager | HIGH (12/25) |
| FM6 | The Injunction in the Migration Lane | Market/Human | A5 | Environmental Permitting & Ecological Compliance Lead | CRITICAL (16/25) |
| FM7 | The Certificate That Never Arrived | Process/Financial | A7 | Independent Design Certifier & Safety Regime Lead | CRITICAL (15/25) |
| FM8 | The Anchor That Found the Tether | Technical/Logistical | A8 | Chief Technical Officer | HIGH (12/25) |
| FM9 | The Empty Platform | Market/Human | A9 | Binational Programme Director | CRITICAL (16/25) |


### Failure Modes

#### FM1 - The Treaty That Never Closed

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Binational Programme Director
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Parliaments in both states slip ratification past Month 15 (2028-01-12).
- Without legal personality, tranche 3 and the casting-yard advance cannot be released.
- Dual national reviews restore 3-6 month decision cycles.
- Lenders withhold closure on the EUR 4.4 billion rail debt.
- The Month 24 (2028-10-12) stop rule freezes the EUR 20 billion main-construction tranche, stranding early spend.

##### Early Warning Signs
- No signed heads-of-state letter of intent by Month 3 (2027-01-12)
- Draft treaty text not circulated to both legal advisers by Month 6 (2027-04-12)
- Either ministry rejects the Board tie-break clause in two consecutive negotiation rounds

##### Tripwires
- Heads-of-state letter not signed by Month 3 (2027-01-12)
- Treaty not ratified by Month 15 (2028-01-12)
- Decision cycles on design changes >= 12 weeks in 3 consecutive cases

##### Response Playbook
- Contain: Freeze all casting-yard commitments and tranche releases beyond tranche 2 until the authority is legally active.
- Assess: Map each blocking article, parliament calendar and legal incompatibility, and quantify the schedule loss in months against the Month 132 (2037-10-12) opening.
- Respond: Escalate to heads of state within 2 weeks, offer an interim concession-plus-commission structure, and re-baseline the schedule or scope with lenders.


**STOP RULE:** If the treaty is not ratified and the authority legally active by Month 24 (2028-10-12), cancel or pivot to a reduced-scope programme; no main-construction release.

---

#### FM2 - The Sill That Wouldn't Hold

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Chief Technical Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Borings show weak sediment or depths mostly >400 m, so the hybrid split collapses.
- Pillar-only redesign costs EUR 4-8 billion and 12-36 months (estimate); tether-only EUR 2-4 billion.
- The Month 24 (2028-10-12) concept freeze slips.
- Yard design and tether procurement start on a concept that must be reworked.
- The reserve is consumed before any other risk draws.

##### Early Warning Signs
- Archive screening shows >50% of alignment deeper than 400 m
- Preliminary borings show bearing capacity <250 kPa at >=2 candidate pillar sites
- Geophysics not 100% complete by Month 6 (2027-04-12)

##### Tripwires
- Bearing capacity <250 kPa at >=3 of 5-8 boring sites
- Concept freeze forecast later than Month 24 (2028-10-12) by >= 3 months
- Forecast redesign cost >= EUR 4 billion

##### Response Playbook
- Contain: Halt casting-yard site works and tether orders until the independent geotechnical review reports.
- Assess: Cost and schedule pillar-only, tether-only and bored-deep-section options at P50/P80 and compare them with the available reserve.
- Respond: Select the fallback by Board decision, secure a funding decision on any gap, and reset the gate schedule with lenders and certifier.


**STOP RULE:** If independent review finds no concept deliverable within EUR 7.2 billion contingency plus approved top-up and Month 240 (2046-10-12), cancel or pivot to a bored/phased scope.

---

#### FM3 - The Tunnel Nobody Could Finish or Fund

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Programme Schedule & Critical Path Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Real weather and ecological windows give <60 usable days/year.
- Immersion stretches to 18-25 years (estimate), threatening Month 240 (2046-10-12).
- Opening slips; ridership falls 20-40% below the 4.0 million planning case.
- DSCR (~0.15x) deteriorates; availability payments face political resistance.
- NGOs and lenders lose confidence.

##### Early Warning Signs
- Climatology study shows <60 usable days/year
- Seasonal consent conditions restrict work to a 150-day window
- Rail operators decline anchor-tenant agreements by Month 24 (2028-10-12)

##### Tripwires
- Modelled immersion duration > 11 years at P50
- Usable immersion days <60 per year
- Demand forecast slips >15% vs Month 30 (2029-04-12) forecast

##### Response Playbook
- Contain: Defer yard expansion and long-lead procurement beyond the pilot until the feasibility model is validated.
- Assess: Rebuild the CPM with validated windows, size phased-opening scope and recompute DSCR at 2.5-3.2 million passengers.
- Respond: Take a binational scope-or-timeline decision, lock availability-payment covenants, and re-contract operators and lenders on the phased plan.


**STOP RULE:** If validated P50 immersion completes later than Month 240 (2046-10-12) minus 12 months commissioning, with no funded phased-opening option, cancel or re-scope the crossing.

---

#### FM4 - The Payment Nobody Would Sign

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Cost Control & Project Finance Authority Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
- Operating surplus of EUR 40 million/year (estimate) against debt service of ~EUR 270 million/year gives DSCR ~0.15x.
- Treasuries treat availability payments as discretionary.
- The EUR 4.4 billion private debt cannot close.
- Rail tranche (EUR 8.8 billion) is pushed onto public balance sheets.
- The EUR 2.8-10.8 billion overrun gap stays unfunded, forcing scope cuts mid-programme.

##### Early Warning Signs
- No written treasury position on availability payments by Month 9 (2027-07-12)
- Lenders request a sovereign guarantee instead of availability payments
- Overrun backstop decision not scheduled by Month 24 (2028-10-12)

##### Tripwires
- Binding availability-payment covenant not deposited by Month 15 (2028-01-12)
- Indicative lender coupon >= 5.5% or maturity < 20 years (proposed threshold)
- Forecast cost-to-complete >= EUR 44 billion at any gate

##### Response Playbook
- Contain: Hold the tranche 5 release and rail procurement commitments until funding terms are signed.
- Assess: Recompute DSCR at 2.5-4.0 million passengers and size the public top-up needed for each financing structure.
- Respond: Rebalance toward public capital or phased scope by Board decision and obtain a pre-authorised overrun funding path from both states and the EU.


**STOP RULE:** If no binding availability-payment or overrun-backstop commitment exists by Month 24 (2028-10-12), release no part of the EUR 20 billion main-construction tranche and pivot to a reduced public-funded scope.

---

#### FM5 - The Yards With No Hands

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Marine Construction & Fabrication Programme Manager
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Competing offshore wind and LNG projects absorb heavy-lift vessels and immersion crews.
- Day-rates rise 30-50% (estimate); tether qualification slips.
- Local concrete-finisher and diver shortages slow yard ramp-up beyond 10-20% (estimate).
- Casting output misses 80% nameplate at the Month 48 (2030-10-12) gate.
- Quality drift between Algeciras and Tanger Med threatens joint watertightness.

##### Early Warning Signs
- Fewer than 2 qualified bidders for yard civil works or tether supply
- Yard recruitment below 70% of plan at Month 30 (2029-04-12) (proposed threshold)
- Quarterly supply-chain review shows inflation >2 percentage points above assumption

##### Tripwires
- Casting output <80% of nameplate at Month 48 (2030-10-12)
- Day-rate quotes >30% above baseline (estimate)
- Dimensional drift between yards >50 mm on 2 consecutive segments

##### Response Playbook
- Contain: Halt shipment of non-conforming segments and lock available crane and vessel capacity under short-term options.
- Assess: Quantify output gap, schedule loss in months and rework cost per yard against the 10-15% spare pool.
- Respond: Add a third sourcing route or modular shipyard production, retrain through yard academies, and re-sequence immersion by Board decision.


**STOP RULE:** If yards cannot reach 80% of nameplate by Month 60 (2031-10-12), pivot to a reduced-length or phased-opening scope.

---

#### FM6 - The Injunction in the Migration Lane

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Environmental Permitting & Ecological Compliance Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Parallel national consents carry divergent seasonal and noise conditions.
- NGOs with legal standing challenge consent robustness.
- Stop-work orders of 3-6 months (estimate) recur at construction phases.
- Public support erodes; fishing and port communities oppose works.
- Seasonal limits cut usable immersion days below 60 per year.

##### Early Warning Signs
- Either ministry refuses a single unified permit in writing
- NGO files notice of challenge or requests judicial review
- Baseline data show construction noise above cetacean disturbance threshold in May-September

##### Tripwires
- Harmonised consent not issued by Month 30 (2029-04-12)
- Seasonal window reduces usable immersion days to <60 per year
- Count of NGO legal challenges >= 1 before Month 24 (2028-10-12)

##### Response Playbook
- Contain: Pause in-water works inside the contested window and suspend new site mobilisation under the disputed permit.
- Assess: Map divergent conditions, litigation exposure and the immersion-days impact in months on the critical path.
- Respond: Reconvene the harmonisation committee, co-design binding mitigation with NGOs, and re-baseline the schedule with a phased-opening option.


**STOP RULE:** If no legally durable consent exists by Month 30 (2029-04-12), release no main-construction funds and pivot to a revised alignment or scope.

---

#### FM7 - The Certificate That Never Arrived

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Independent Design Certifier & Safety Regime Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
- No design code exists for this structure type; certifier findings accumulate at gates.
- Full-scale tests cannot prove 50-year fatigue, so extra testing is demanded.
- Late findings after Month 48 (2030-10-12) force redesign during fabrication.
- Lenders and insurers withhold confidence; tranche releases stall.
- Rework and delay draw on the EUR 7.2 billion reserve.

##### Early Warning Signs
- Open non-minor certification findings at the Month 18 (2028-04-12) gate
- Certifier requests additional test campaigns not budgeted in the EUR 50-100 million programme
- Dispute between certifier and Board unresolved for more than 30 days

##### Tripwires
- Open non-minor findings >= 5 at any certification gate
- Test programme cost forecast > EUR 100 million
- Certification dispute unresolved > 30 days

##### Response Playbook
- Contain: Hold production-release authorisations and tether procurement orders until open findings are classified.
- Assess: Quantify each finding in months of delay and EUR of rework and test the remaining reserve.
- Respond: Convene the technical appeal panel, fund added testing by Board decision, and re-baseline gates with lenders and insurers.


**STOP RULE:** If non-minor certification findings remain open at the Month 48 (2030-10-12) gate, release no full-rate production funds and pivot to a redesigned or reduced scope.

---

#### FM8 - The Anchor That Found the Tether

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Chief Technical Officer
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
- Busy multi-flag traffic ignores the no-anchoring corridor.
- Anchor drag or sinking vessel strikes tethers or the tube.
- Passive hardening adds mass to buoyancy-sensitive structure, up to EUR 1-3 billion (estimate).
- IMO consent slips 2-4 years, leaving operations unprotected.
- Insurers decline fatigue and strike cover, blocking operating licence.

##### Early Warning Signs
- IMO corridor consent not progressed by Month 12 (2027-10-12)
- Underwriters decline to quote by Month 9 (2027-07-12)
- Hardening cost estimate exceeds EUR 1 billion

##### Tripwires
- Fewer than 2 underwriter quotes by Month 9 (2027-07-12)
- Hardening forecast > EUR 1 billion (estimate)
- Corridor agreement not reached by Month 48 (2030-10-12)

##### Response Playbook
- Contain: Suspend installation of exposed tether groups in the busiest lanes until protection design is approved.
- Assess: Model strike scenarios, mass penalty on buoyancy margin and insurer exclusions.
- Respond: Combine passive hardening with sonar surveillance by Board decision and agree retained-risk terms with both states.


**STOP RULE:** If no insurance cover or corridor consent exists by Month 60 (2031-10-12), halt further in-water installation and pivot to a protected or bored scope.

---

#### FM9 - The Empty Platform

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Binational Programme Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
- Fares of EUR 60 compete with cheaper ferries and flights.
- Feeder lines are unfunded, capping through-running at opening.
- Opening demand falls 20-40% below 4.0 million passengers/year (estimate).
- DSCR of ~0.15x worsens; availability payments face public resistance.
- Public and political support erodes after a decade of spend.

##### Early Warning Signs
- Independent study shows demand < 3.0 million passengers/year
- Rail operators refuse anchor-tenant agreements by Month 24 (2028-10-12)
- Feeder-line financing undecided by Month 12 (2027-10-12)

##### Tripwires
- Demand forecast slips > 15% vs Month 30 (2029-04-12) forecast
- Anchor-tenant agreements < 2 signed by Month 24 (2028-10-12)
- Feeder-line funding not committed by Month 108 (2035-10-12)

##### Response Playbook
- Contain: Freeze rolling-stock and systems procurement commitments until demand evidence is validated.
- Assess: Recompute revenue and DSCR at 2.5-3.2 million passengers and size the feeder-line gap.
- Respond: Restructure fares, service pattern or phased opening by Board decision and secure operator and public revenue guarantees.


**STOP RULE:** If validated opening demand is below 3.0 million passengers/year with no funded availability or feeder commitment by Month 60 (2031-10-12), pivot to phased or shuttle scope.
