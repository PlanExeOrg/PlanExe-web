# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** Extremely high. A 20-year, €40 billion (user constraint) binational megaproject to build a submerged floating tunnel for high-speed rail across the Strait of Gibraltar. It would be the first of its kind at this scale, with national, treaty-level and continental significance, and two states, a maritime boundary and a very busy shipping lane involved.

**Risk and Novelty:** Very high and groundbreaking. No submerged floating tunnel has been built anywhere. The plan's 100 m anchoring depth and pillar-supported concept conflict with published Strait depths of several hundred metres, up to about 900 m (per the input lever documents). Seismic, current and wave loading, treaty ratification, cost overrun and demand risk all compound, and early concept errors are irreversible once seabed works begin.

**Complexity and Constraints:** Very high complexity. The plan needs treaty-based governance, multi-source financing, seabed and geohazard characterisation, segment casting, towing and immersion in strong currents, shipping and security interaction, and rail systems integration. The binding constraints are a fixed 20-year horizon, a €40 billion envelope with a likely overrun tendency, and a start ASAP, with no explicit stage gates or fallback concept in the plan.

**Domain and Tone:** Public-scale, cross-border civil and marine infrastructure with an engineering-led, aspirational tone. It is physical and cannot be delivered digitally. Delivery is most plausibly a government or bi-national programme, possibly with private participation.

**Holistic Profile:** A visionary, first-of-kind, treaty-level infrastructure programme with a fixed budget and timeline. It needs a delivery strategy that preserves the full-crossing ambition while converting the largest unknowns (support concept, seabed conditions, joint governance) into manageable risk. It cannot afford either an irreversible all-in bet or a drawn-out, hedged proving path that threatens the 20-year horizon.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Pragmatic Foundation
**Strategic Logic:** Use a hybrid support concept that matches each structural solution to the seabed it suits, and let a parallel exploratory gallery generate geotechnical data that benefits either tunnel concept. Delivery relies on a coordinated concession and paired yards, balancing political parity, quality and cost without requiring full sovereignty transfer.

**Fit Score:** 7/10

**Why This Path Was Chosen:** The hybrid support concept (founded pillars on shallow sills, tethers or buoyancy modules in deep channels) matches the plan's 'pillar-supported' premise and the real seabed. The exploratory gallery de-risks geotechnical unknowns while the full design proceeds. A coordinated concession and paired yards keep the ambition intact without demanding full sovereignty transfer. The main weakness is the lack of a formal prototype and pilot gate.

**Key Strategic Decisions:**

- **Pillar, Tether and Pontoon Support Concept:** Adopt a hybrid concept that uses founded pillars on shallow shelves and sills, and tether groups or buoyancy modules across deeper channels where pillars become impractical.
- **Technology Proving and Stage-Gate Sequence:** Run the design for the full crossing in parallel with an exploratory gallery or survey tunnel, so that geotechnical data and a possible service bore benefit either tunnel concept.
- **Binational Treaty and Delivery Vehicle:** Grant a long-term concession to a private-public joint venture under each state's law, with a coordinating commission to harmonise standards and resolve boundary issues.
- **Funding Architecture and Risk Allocation:** Structure availability-payment concessions with private equity and debt for the rail systems and operations, keeping civil works on public balance sheets to limit private exposure to construction risk.
- **Segment Fabrication and Immersion Logistics:** Establish paired casting yards on the Spanish and Moroccan coasts, each supplying its own half, with common specifications and shared supervision to balance industrial and employment benefits.

**The Decisive Factors:**

- **Ambition preserved, risk managed:** the hybrid pillar/tether concept keeps the full-crossing floating-tunnel vision and the plan's 'pillar-supported' premise, while matching structure to actual seabed depth and the unresolved 100 m assumption.
- **Uncertainty reduced without stalling:** the parallel exploratory gallery produces geotechnical data under either concept, so the 20-year horizon is protected.
- **Governance is realistic:** a coordinated concession plus paired yards gives political parity and shorter tows without demanding the sovereignty transfer that could stall treaty ratification.
- **Pioneer's Gambit rejected:** an irreversible, single-concept, single-package commitment before seabed data would rest on contractor risk pricing that does not exist.
- **Step-by-Step Consolidation rejected:** it effectively replaces the core concept in the deepest section, adds interface risk through two agencies, and may miss the fixed horizon.

---
## Alternative Paths
### The Pioneer's Gambit
**Strategic Logic:** Commit now to a single full-alignment tethered concept, a sovereign-level binational authority and a single accountable contractor consortium, so the crossing is locked in and the 20-year horizon is protected. Technology risk is deliberately priced into a contractor premium and private finance rather than staged away, accepting that a wrong early concept choice cannot be reversed once seabed works begin.

**Fit Score:** 3/10

**Assessment of this Path:** Locks in a single full-alignment tethered concept and single design-build package before the seabed is characterised, assuming a contractor market will underwrite risk that no one has priced. A wrong early choice is irreversible, which is a poor match for a first-of-kind plan whose stated depth assumption already conflicts with Strait bathymetry.

**Key Strategic Decisions:**

- **Pillar, Tether and Pontoon Support Concept:** Adopt tension-leg tethers anchored to the seabed along the whole alignment, accepting very long tether lengths in the deepest sections and relying on dynamic-response testing to qualify them.
- **Technology Proving and Stage-Gate Sequence:** Procure the whole crossing as a single design-build package with performance guarantees, shifting technology risk to a contractor consortium at a substantial risk premium.
- **Binational Treaty and Delivery Vehicle:** Create a treaty-backed binational authority with its own legal personality, procurement powers and technical regulator, building on the existing SECEGSA and SNED study companies.
- **Funding Architecture and Risk Allocation:** Structure availability-payment concessions with private equity and debt for the rail systems and operations, keeping civil works on public balance sheets to limit private exposure to construction risk.
- **Segment Fabrication and Immersion Logistics:** Build one large purpose-built casting basin and outfitting yard on a single coast, and tow finished segments to the crossing to maximise repetition and quality control.

### The Proven Step-by-Step Consolidation
**Strategic Logic:** Limit early exposure by proving the buoyant concept in shallow approach reaches first, with a bored or immersed-tube fallback for the deepest central section, and release funds only as technical milestones are met. Each state keeps its own delivery agency under a shared technical code, and segments come from existing yards. This minimises cost and sovereignty risk, but it extends the programme and may leave the full crossing at risk against the fixed 20-year horizon.

**Fit Score:** 5/10

**Assessment of this Path:** Strongest on risk control and tranche discipline, but it relegates the buoyant concept to shallow approach reaches and uses a bored or immersed tube for the deepest section. That departs from the plan's core concept and, with two separate national agencies and a pilot phase, endangers delivery within the fixed 20-year horizon.

**Key Strategic Decisions:**

- **Pillar, Tether and Pontoon Support Concept:** Adopt a bored or immersed-tube fallback for the deepest central section, and reserve the buoyant concept for shallow approach reaches where a floating tube can be proven first.
- **Technology Proving and Stage-Gate Sequence:** Commit to a gated programme that funds seabed investigation, a scaled prototype segment and a full-scale pilot in sheltered waters, releasing main construction funds only after independent assessment.
- **Binational Treaty and Delivery Vehicle:** Run two national delivery agencies that each build the section in their own waters to a shared technical code, joined at a defined interface point in mid-Strait.
- **Funding Architecture and Risk Allocation:** Release capital in tranches linked to technical milestones, with the opening tranche limited to investigation and pilot work, so that later commitments depend on demonstrated feasibility.
- **Segment Fabrication and Immersion Logistics:** Produce shorter modular elements in existing shipyards and industrial ports across the region and assemble them in sheltered water into long strings before immersion.
