**5 open decisions: 3 high and 2 medium severity.** The most urgent decisions are the opening baseline versus immersion rate and the overrun-gap funding source, both needed by Months 9-12 (2027-07-12 to 2027-10-12) ahead of the Month 15 (2028-01-12) and Month 24 (2028-10-12) gates; feeder-line financing is due Month 9 (2027-07-12) and the contingency base by Month 6 (2027-04-12). Before then the plan can safely run the seabed campaign, ecological baseline, treaty negotiation and desk screen with tranche 1 funds, and defer all casting-yard commitments.

| # | Decision | Severity | Owner | Decide by | Blocks |
|---|---|---|---|---|---|
| 1 | Baseline opening vs immersion rate | 🔴 High | Binational Project Board, escalating to Ministerial Steering Committee for re-baselined opening. | Month 9 (2027-07-12), when the weather model (Month 6 = 2027-04-12) and gate are available and before the Month 24 (2028-10-12) yard advance. | Month 9 (2027-07-12) weather-window gate; Month 24 (2028-10-12) casting-yard advance; lender terms. |
| 2 | Funding source for overrun gap | 🔴 High | Ministerial Steering Committee on Board recommendation. | Month 12 (2027-10-12), after Month 9 (2027-07-12) Monte Carlo and before Month 15 (2028-01-12) covenants and Month 24 (2028-10-12) gate. | Month 15 (2028-01-12) financing covenants; Month 24 (2028-10-12) tranche release. |
| 3 | Feeder-line financing and ownership | 🔴 High | Ministerial Steering Committee (Spain, Morocco, EU observer). | Month 9 (2027-07-12), before the lender working group and independent demand study. | Lender terms and availability-payment sizing (Month 15 = 2028-01-12); demand evidence for Month 24 (2028-10-12) gate. |
| 4 | Paired vs single casting yard | 🟡 Medium | Binational Project Board. | Month 9 (2027-07-12), with the re-run benefit case, before Month 24 (2028-10-12) yard advance. | Month 24 (2028-10-12) casting-yard advance; Month 36 (2029-10-12) paired yards gate. |
| 5 | Contingency base reconciliation | 🟡 Medium | Independent Project Cost Authority, approved by Board. | Month 6 (2027-04-12), with the Cost Breakdown Structure. | Cost Breakdown Structure (Month 6 = 2027-04-12); tranche 2 release rules. |

## 1. Baseline opening vs immersion rate (🔴 High)

**Decision:** Should the Month 132 (2037-10-12) opening baseline be re-baselined, or should the immersion rate, start date or opening scope change so that immersion fits the schedule?

**Why it is open:** Canonical baseline has immersion complete Month 120 (2036-10-12) (main construction Months 36-120 = 2029-10-12 to 2036-10-12), but 60-90 usable days/year gives 8.75-14 years for 14 km (estimate). Even the best case ends about Month 141 (2038-07-12). The P50 gate (below 11 years) protects only Month 240 (2046-10-12); KPI 2 says 12 years.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Re-baseline immersion completion and opening to the validated model P50, keeping Month 240 (2046-10-12). | Opening moves later than Month 132 (2037-10-12) (P50 11 years from Month 36 = 2029-10-12 ends about Month 168 = 2040-10-12). Honest baseline; reserve schedule and financing profile shift. | service_opening_target, gate thresholds, KPI 2, availability-payment profile. |
| B. Raise production/immersion rate (more yards or higher rate) or start immersion before Month 36 (2029-10-12). | Extra yard capex and rate risk; needs validation. Could keep Month 132 (2037-10-12) only if rate is proven. | immersion_rate_weather_windows, tranche_main_construction_eur, staffing_targets. |
| C. Phased opening of a shorter first section (7-10 km). | Earlier partial service; needs funding and scope decision, outside envelope. | service_opening_target, fallback_deep_section_and_scope, demand case. |

- **If nobody decides:** Month 9 (2027-07-12) gate is taken against an unreachable Month 132 (2037-10-12) baseline; the conservative branch (re-baseline or phased scope) is forced at Month 24 (2028-10-12).
- **Owner:** Binational Project Board, escalating to Ministerial Steering Committee for re-baselined opening.
- **Decide by:** Month 9 (2027-07-12), when the weather model (Month 6 = 2027-04-12) and gate are available and before the Month 24 (2028-10-12) yard advance.
- **Blocks:** Month 9 (2027-07-12) weather-window gate; Month 24 (2028-10-12) casting-yard advance; lender terms.

## 2. Funding source for overrun gap (🔴 High)

**Decision:** Who finances overruns above the EUR 7.2 billion reserve, and in what shares, or is scope/timeline reduced instead?

**Why it is open:** Documents set the decision at Month 3, 6, 9 and 24 (2027-01-12, 2027-04-12, 2027-07-12, 2028-10-12). Funding shares for civil works are not set. Gap is EUR 2.8-10.8 billion (estimate); the sizing Monte Carlo arrives Month 9 (2027-07-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Spain, Morocco and EU commit named shares, with multilateral lenders as backstop. | Closes gap on paper; needs budget-law action; supports Month 15 (2028-01-12) and Month 24 (2028-10-12) gates. | funding_split, overrun_exposure_vs_reserve. |
| B. Pre-authorise scope or timeline reduction instead of new money. | Keeps EUR 40 billion cap; opening later or scope phased. | fallback_deep_section_and_scope, service_opening_target. |
| C. Defer until Monte Carlo (Month 9 = 2027-07-12) and scope options only before. | Better sized decision; delays lender and treaty signals. | Self-audit, KPI 3 dates. |

- **If nobody decides:** No funding source named; EUR 20 billion tranche not released at Month 24 (2028-10-12) under FM4 stop rule.
- **Owner:** Ministerial Steering Committee on Board recommendation.
- **Decide by:** Month 12 (2027-10-12), after Month 9 (2027-07-12) Monte Carlo and before Month 15 (2028-01-12) covenants and Month 24 (2028-10-12) gate.
- **Blocks:** Month 15 (2028-01-12) financing covenants; Month 24 (2028-10-12) tranche release.

## 3. Feeder-line financing and ownership (🔴 High)

**Decision:** Who funds and owns the Spanish and Moroccan feeder-line upgrades, and do they stay outside the EUR 40 billion envelope?

**Why it is open:** Canonical marks financing OPEN and outside the envelope; pitch, DSCR and the 4.0 million case assume feeders are ready. Resolution dates range from Month 9 (2027-07-12) to Month 108 (2035-10-12). Estimated EUR 3-8 billion (estimate).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Outside envelope, funded by states/EU with a fixed completion gate tied to opening. | Envelope unchanged; separate funding and schedule risk; demand case conditional. | landside_feeder_financing, demand case, pitch. |
| B. Inside envelope, carved from contingency. | Reserve of EUR 7.2 billion cut by EUR 3-8 billion (estimate), widening the gap. | contingency_reserve_total_eur, overrun_exposure_vs_reserve, funding_split. |
| C. Descope: open with 2.5-3.0 million downside case. | Revenue below break-even; more availability payments. | opening_demand_planning_case, debt_service_coverage_gap. |

- **If nobody decides:** 4.0 million case stays unfunded and unscheduled; lender working group and demand study use an unsupported assumption.
- **Owner:** Ministerial Steering Committee (Spain, Morocco, EU observer).
- **Decide by:** Month 9 (2027-07-12), before the lender working group and independent demand study.
- **Blocks:** Lender terms and availability-payment sizing (Month 15 = 2028-01-12); demand evidence for Month 24 (2028-10-12) gate.

## 4. Paired vs single casting yard (🟡 Medium)

**Decision:** Are paired yards (Algeciras and Tanger Med) confirmed, or is a single yard with a higher rate or phased scope adopted?

**Why it is open:** Self-audit item 12 recommends one yard as gold plating (saves EUR 500 million-2 billion); canonical rate of 0.5-0.8 km/year for one yard gives 17.5-28 years, past Month 240 (2046-10-12).

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Keep paired yards. | Schedule arithmetic holds; premium retained; political parity. | Self-audit item 12 removed. |
| B. Single basin with validated higher rate. | Saves cost only if rate proven; adds schedule risk. | immersion_rate_weather_windows, delivery model. |
| C. Single yard with phased scope and later opening. | Lower capex; later or shorter opening needs scope decision. | service_opening_target, scope. |

- **If nobody decides:** Paired yards stay as canonical; the yard advance proceeds at Month 24 (2028-10-12) only if gate is met.
- **Owner:** Binational Project Board.
- **Decide by:** Month 9 (2027-07-12), with the re-run benefit case, before Month 24 (2028-10-12) yard advance.
- **Blocks:** Month 24 (2028-10-12) casting-yard advance; Month 36 (2029-10-12) paired yards gate.

## 5. Contingency base reconciliation (🟡 Medium)

**Decision:** Is the EUR 7.2 billion contingency kept on the 28.0/8.0/4.0 gross basis with a reconciliation to tranches, or recomputed on tranche line items?

**Why it is open:** Canonical contingency uses 28.0, 8.0, 4.0 bases; tranche line items are EUR 24.0 billion civil and EUR 8.8 billion rail. 20% of 24.0 is 4.8 and 15% of 8.8 is 1.32, so totals differ.

| Option | Consequences | What changes in the plan |
|---|---|---|
| A. Restate line items to gross split with reconciliation. | Keeps EUR 7.2 billion; cross-tranche rules clearer. | funding_split, tranche tables. |
| B. Recompute contingency on tranche line items. | Total differs from EUR 7.2 billion; reserve may shrink. | contingency_reserve_total_eur, free_contingency_after_earmarks_eur. |

- **If nobody decides:** Cost Breakdown Structure (Month 6 = 2027-04-12) is built on inconsistent bases and rebalancing rules stay ambiguous.
- **Owner:** Independent Project Cost Authority, approved by Board.
- **Decide by:** Month 6 (2027-04-12), with the Cost Breakdown Structure.
- **Blocks:** Cost Breakdown Structure (Month 6 = 2027-04-12); tranche 2 release rules.

## Choices made on your behalf

Set when the scenario was selected, not by you. Confirm or change them.

| Lever | Chosen | Strongest alternative | Why it matters | Revisit by |
|---|---|---|---|---|
| Pillar, tether and pontoon support concept | Hybrid: founded pillars on shallow shelves, tethers or buoyancy modules in deep channels. | Tether-only along the whole alignment (Pioneer's Gambit). | Fixes cost (+EUR 2-8 billion variance) and installation method. | Month 3 (2027-01-12) desk screen; Month 24 (2028-10-12) concept freeze. |
| Technology proving and stage-gate sequence | Full design in parallel with an exploratory gallery or survey tunnel feeding geotechnical data. | Gated prototype and pilot-first release of funds (Step-by-Step). | Determines how much capital is committed before seabed evidence. | Month 18 (2028-04-12) independent review. |
| Binational treaty and delivery vehicle | Concession to a public-private joint venture under each state's law, with a coordinating commission. | Treaty-backed authority with sovereign powers, or two national agencies. | Sets decision speed and whether ratification is feasible by Month 15 (2028-01-12). | Month 15 (2028-01-12) gate. |
| Funding architecture and risk allocation | Civil works public; rail systems and operations via private equity and debt repaid by availability payments. | Milestone-linked tranches limited initially to investigation and pilot. | Determines public exposure and lender terms. | Month 15 (2028-01-12) covenant gate. |
| Segment fabrication and immersion logistics | Paired casting yards on Spanish and Moroccan coasts with common specifications. | Single large casting basin on one coast. | Drives immersion rate against the Month 240 (2046-10-12) limit and political parity. | Month 9 (2027-07-12) gate. |
