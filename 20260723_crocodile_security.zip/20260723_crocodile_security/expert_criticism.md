# Project Expert Review & Recommendations

## A Compilation of Professional Feedback for Project Planning and Execution


# 1 Expert: International Wildlife Trade Attorney

**Knowledge**: CITES Appendix I exemptions, captive-breeding certification, international wildlife law, multi-jurisdictional regulatory compliance

**Why**: The CITES Appendix I exemption mechanism is legally undefined; without it, the entire animal sourcing chain has zero legal viability — the #1 existential risk.

**What**: File the Appendix I exemption mechanism (captive-breeding certification) simultaneously with Egyptian, Israeli, and UAE wildlife authorities.

**Skills**: CITES permit filing, captive-breeding exemption negotiation, multi-jurisdictional regulatory strategy, wildlife law litigation

**Search**: CITES Appendix I captive breeding exemption wildlife attorney Nile crocodile

## 1.1 Primary Actions

- Engage a CITES specialist legal firm with proven Appendix I captive-breeding exemption experience within 30 days (by October 5, 2026) and allocate $150,000-$250,000 of the first tranche to permit preparation across at least three target jurisdictions (Egypt, Israel, UAE)
- Pre-negotiate with the Egyptian CITES Management Authority to pre-approve breeding facility registrations before any commercial applications are filed, allocating $200,000-$500,000 in legal fees across jurisdictions
- Restructure the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (approximately $8.08 million total value) with 50% upfront payment upon signing, and if the client refuses bundled maintenance, price the standalone moat at the full $41,000 per meter Ketziot benchmark rather than at a loss
- Establish a formal contingency plan with pre-negotiated triggers and funding mechanisms by month 3 (December 2026), including a $1 million to $2 million bridge loan facility with the Gulf investor secured against the fortress asset, accessible upon milestone failure
- Implement triple-redundant physical containment systems on every moat: submerged electrified fencing with dual independent circuits, overhanging acrylic/glass walls angled outward at greater than 45 degrees, and dual-gate airlock entry chambers with biometric access, budgeting an additional 30% capital contingency above baseline engineering costs
- Secure comprehensive liability insurance ($25 million to $50 million aggregate, $5 million per-incident limit) from Lloyd's of London or equivalent specialty underwriters by month 3 (December 2026)
- Establish a monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche, reviewed weekly by the founding team, with a negotiated $1 million emergency reserve facility from the Gulf investor accessible upon milestone achievement
- Begin hiring the minimum viable team of 18-25 people starting month 1, prioritizing 3 veterinarians and 1 regulatory affairs specialist by October 1, 2026, with handler recruitment launching a 20-applicant inaugural cohort by November 1, 2026
- Adopt a written client-acceptance framework that excludes clients under active international sanctions or ICC investigation while maintaining the broader 'no client too controversial' stance, requiring board approval for any client whose public profile generates sustained negative media attention
- Set an internal hard gate at month 15 (December 2027): if no contract is signed, trigger a strategic pivot to regulatory consulting-only revenue while continuing moat sales, and activate the pre-negotiated $1 million to $2 million bridge loan facility secured against the fortress asset

## 1.2 Secondary Actions

- Negotiate exclusive long-term supply agreements with at least three Lake Nasser crocodile farms by December 2026, locking in volume and pricing for juvenile Nile crocodiles while simultaneously investing $500,000-$800,000 of the second tranche into a small proprietary breeding facility near Lake Nasser as a parallel capability
- Establish a 6-month strategic reserve of at least 20 juvenile crocodiles at the Lake Nasser facility by month 6 (March 2027), investing in climate-resilient aquaculture including water-recycling systems and temperature-controlled holding ponds
- Pre-negotiate transport contracts with specialized live-animal logistics firms experienced in CITES-compliant reptile transport, with GPS-tracked containers and estimated 5-15% transport mortality budgeted into per-moat animal costs
- Develop relationships with crocodile farms in Zimbabwe and South Africa as backup suppliers by month 9 (June 2027), diversifying the supply chain against drought-driven stock losses from the Grand Ethiopian Renaissance Dam's water-level effects on Lake Nasser
- Complete the reinforced-glass boardroom floor installation above the demonstration pool capable of housing twelve adult Nile crocodiles by month 6-9 (March-June 2027), allocating $1 million from the first tranche to critical demonstration-pool construction while deferring non-essential fortress finishes to later tranches
- Install closed-loop water recycling systems achieving 90%+ water reuse efficiency in the demonstration pool by month 8 (August 2027), with UV sterilization, biological filtration, and mechanical filtration in N+1 redundancy configuration
- Build IoT-based water quality monitoring with automated dosing and alerting (pH, ammonia, dissolved oxygen, temperature) by month 7 (July 2027), with a client-facing dashboard publicly accessible via company website showing 24/7 metrics
- Establish the handler academy on the Nile island headquarters with a four-month residential program producing the first cohort by month 8-10 (August-October 2027), combining Egyptian crocodile-farm apprenticeship with ceremonial hospitality protocol training, targeting 12 graduates bound by multi-year service contracts
- Hire a high-profile animal welfare advisor (former head of a recognized zoo or conservation body) as a board-level position by month 3 (December 2026), and commission an independent environmental impact assessment (EIA) costing $50,000-$150,000 per installation before any contract signing, with 5-year post-installation environmental monitoring
- Establish a dedicated safety director reporting directly to the board by month 3 (December 2026), and conduct quarterly third-party penetration testing of all containment systems with formal reports filed to the board
- Pre-negotiate emergency response MOUs with local authorities at every installation site by month 6 (March 2027), including pre-arranged coordination with local law enforcement, EMS, and wildlife authorities, with a 15-minute response-time standard documented in all client contracts
- Require all clients to sign liability waivers acknowledging inherent risks of live apex predator containment, and mandate that clients secure specialized excess-liability insurance; cap maximum acceptable single-incident financial exposure at $10 million (total seed capital), beyond which the company declares insolvency and triggers investor loss protocols
- Establish a $500,000 crisis management reserve and retain a specialized PR firm with experience in animal welfare controversies
- Implement monthly escape drills and quarterly third-party penetration testing of all containment systems starting month 6 (March 2027), with a dedicated on-call veterinary and handler response team at each installation maintaining a 15-minute response-time standard
- GPS-chip and externally transmit every crocodile, with a rapid-response protocol for animal loss events including pre-arranged coordination with local law enforcement and INTERPOL, and maintain a handler-to-crocodile ratio of at least 1:3 during all client events
- Adopt welfare standards that exceed independent audit requirements by a meaningful margin, investing in real-time public-facing monitoring dashboards showing water quality, temperature, and animal health metrics 24/7, with blockchain-based audit trails for all welfare data to prevent tampering
- Establish a formal client-review board including an independent ethics advisor by month 6 (March 2027)
- Diversify the first-contract pursuit between government (Ketziot-style) and private billionaire compound deals to hedge against political delays, targeting at least two letters of intent by month 12 to ensure pipeline depth
- Maintain multi-currency accounts with a primary USD treasury and local currency sub-accounts; hedge ILS exposure on the Ketziot contract using forward contracts or currency options through a major bank (estimated cost: 2-4% of contract value); budget EGP expenses with a 20% currency buffer and convert USD to EGP in tranches timed to favorable exchange rates; structure multi-year contracts with currency adjustment clauses tied to a published exchange rate index; leverage the AED-USD peg for Gulf transactions; engage a foreign exchange specialist as a part-time advisor from month one
- Commission an independent hydrological study of each proposed moat site before contract signing
- Develop a comprehensive handler safety program including protective equipment, emergency evacuation protocols, and psychological support; budget $150,000-$300,000 annually for handler training, equipment, and compensation
- Implement mandatory certification renewal every 6 months with practical escape-response testing for all handlers
- Establish a formal governance charter within the first 60 days specifying capital deployment thresholds, client-acceptance authority levels, and a regulatory escalation protocol
- Create a detailed cost-comparison analysis demonstrating that hiring Crocodile Security at 20% below the Ketziot benchmark is cheaper than a ministry building its own program
- Build relationships with multiple government decision-makers simultaneously across at least three countries
- Defer all saltwater-variant investment until three freshwater contracts are signed and generating positive cash flow, treating coastal fortresses as a year-seven expansion target rather than a concurrent development effort, and reallocating the study budget to core product refinement

## 1.3 Follow Up Consultation

Review CITES legal pathway confirmation status across all three target jurisdictions (Egypt, Israel, UAE) and confirm whether captive-breeding certification under Article VIII or registered commercial breeding operations is available for commercial security purposes. Assess first contract restructuring progress: confirm whether the 5-year bundled turnkey-plus-maintenance package has been presented to prospective clients and whether any client has accepted or rejected the bundled maintenance requirement. Review contingency plan formalization: confirm whether the $1 million to $2 million bridge loan facility has been pre-negotiated with the Gulf investor, whether the burn-rate dashboard is operational, and whether the month 15 hard gate trigger has been documented and approved by the board. Evaluate triple-redundant containment system design progress: confirm whether the engineering team has completed the preliminary design for dual-circuit submerged electrified fencing, overhanging acrylic walls, and dual-gate airlock chambers, and whether the 30% capital contingency has been incorporated into the budget. Review insurance procurement status: confirm whether Lloyd's of London or equivalent specialty underwriters have been approached and whether coverage terms are available at the target $25 million to $50 million aggregate limit. Assess team hiring progress: confirm whether the 3 veterinarians and 1 regulatory affairs specialist have been hired or are in final interview stages, and whether the handler academy recruitment has launched. Review client-acceptance framework adoption: confirm whether the written framework excluding clients under active international sanctions or ICC investigation has been drafted and approved by the board, and whether the independent ethics advisor has been identified. Discuss geographic expansion sequencing for year two and beyond: confirm whether the company will prioritize Middle Eastern and Gulf states first or pursue a more diverse continental mix, and how this aligns with the regulatory pathway design and animal sourcing strategy. Review currency risk management: confirm whether the foreign exchange specialist has been engaged and whether the ILS hedge facility and EGP currency buffer have been established. Assess regulatory consulting deferral: confirm whether the company has decided to defer regulatory consulting until after the first moat installation is completed, and whether this aligns with the Builder scenario's strategic choice. Review saltwater variant feasibility gate: confirm whether the company has decided to defer all saltwater-variant investment until three freshwater contracts are signed, and whether the study budget has been reallocated to core product refinement.

## 1.4.A Issue - CITES Appendix I Exemption Mechanism Is Legally Undefined

The entire animal sourcing and deployment chain has zero legal viability until the specific Appendix I commercial trade exemption mechanism is identified and filed. The plan assumes captive-breeding certification under Article VIII or registered commercial breeding operations will work, but this is an assumption, not a confirmed legal pathway. Nile crocodiles are Appendix I, which means commercial trade is prohibited unless a specific exemption applies. The plan mentions filing simultaneously with Egyptian, Israeli, and UAE authorities, but does not confirm that any of these jurisdictions will actually grant the exemption, nor does it address the possibility that captive-breeding certification may not be available for commercial security purposes. Every day of delay compounds the risk of total business model collapse. The pre-project assessment correctly flags this as the single most critical issue, but the plan treats it as a dependency to be resolved rather than an immediate action item with a 30-day deadline that has already passed.

### 1.4.B Tags

- CITES Appendix I
- legal viability
- commercial trade exemption
- captive-breeding certification
- multi-jurisdictional permits
- existential risk

### 1.4.C Mitigation

Engage a CITES specialist legal firm with proven Appendix I captive-breeding exemption experience within 30 days (by October 5, 2026). Allocate $150,000-$250,000 of the first tranche to permit preparation across at least three target jurisdictions (Egypt, Israel, UAE). Pre-negotiate with the Egyptian CITES Management Authority to pre-approve breeding facility registrations before any commercial applications are filed. File simultaneously in all three jurisdictions to create redundancy. Establish a CITES compliance officer role reporting directly to the board by month 3 (December 2026) with mandatory quarterly audits of all cross-border crocodile movements. If CITES export permits are not filed by month 3 or denied by month 12, trigger the Plan B pivot to regulatory consulting-only revenue and freeze all animal-sourcing expenditures until permits are secured. Consult: specialized international wildlife law firms with CITES Appendix I experience. Read: CITES Article VIII text, Egyptian CITES Management Authority regulations, Israeli Environmental Ministry wildlife classification guidelines. Provide: detailed legal pathway analysis for each jurisdiction, confirmation of captive-breeding certification availability for commercial security purposes.

### 1.4.D Consequence

Without confirmed CITES exemption, no animals can be legally sourced, transported, or deployed. The entire business model collapses. The company cannot sign contracts, cannot source crocodiles, and cannot operate. Every day of delay increases the probability that the legal pathway does not exist or is unavailable in target jurisdictions.

### 1.4.E Root Cause

The plan treats CITES compliance as a dependency to be resolved rather than an immediate action item. The assumption that captive-breeding certification will be available for commercial security purposes is untested and may not be legally valid in all target jurisdictions.

## 1.5.A Issue - Negative Unit Economics on First Contract Under 20% Discount Strategy

The standalone 20%-discounted moat price of approximately $32,800 per meter yields negative gross margins against approximately $6 million to $6.8 million in direct costs for a 170-meter moat. This mathematically prevents the 30-month positive cash flow target unless multi-year maintenance contracts are explicitly bundled and accepted by clients. The plan mentions restructuring the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (approximately $8.08 million total value) with 50% upfront payment, but this is presented as a mitigation strategy, not a core pricing assumption. The 20% discount strategy is anchored to the Ketziot benchmark of approximately $41,000 per meter, which is a construction-and-animal cost reference, not a measure of what premium clients will pay for the statement value. Bidding 20% below the benchmark wins the first government contract but anchors the brand to a public-sector price floor that ignores the symbolic premium royal palaces and bunker communities pay. The plan does not address what happens if the first client refuses bundled maintenance or if the government contract does not materialize.

### 1.5.B Tags

- negative unit economics
- 20% discount strategy
- pricing anchor
- bundled maintenance
- cash flow target
- first contract structure

### 1.5.C Mitigation

Restructure the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (approximately $8.08 million total value) with 50% upfront payment upon signing to fund second-tranche milestones. If the client refuses bundled maintenance, price the standalone moat at the full $41,000 per meter Ketziot benchmark rather than at a loss. Do not anchor pricing to the Ketziot benchmark for private clients; introduce a tiered pricing model that charges a premium for the ceremonial handler program, reinforced glass boardroom-grade specifications, and multi-year maintenance contract. Negotiate a currency hedge facility with the Gulf investor before tranche deployment. Set an internal hard gate at month 15 (December 2027): if no contract is signed, trigger a strategic pivot to regulatory consulting-only revenue while continuing moat sales, and activate the pre-negotiated $1 million to $2 million bridge loan facility secured against the fortress asset. Consult: pricing strategy consultants with experience in government procurement and luxury security markets. Read: Ketziot Prison moat cost breakdown, Florida 'Alligator Alcatraz' pricing data, government procurement benchmarking studies. Provide: detailed cost breakdown for a 170-meter moat including construction, animal sourcing, veterinary care, handler training, maintenance, and contingency; multi-year maintenance contract revenue projections; client willingness-to-pay analysis for premium private clients.

### 1.5.D Consequence

Without bundled maintenance contracts, the first contract yields negative gross margins, making the 30-month positive cash flow target mathematically impossible. The company burns through seed capital without achieving profitability. If the first client refuses bundled maintenance and the company prices at the 20% discount, the venture loses money on every meter installed.

### 1.5.E Root Cause

The 20% discount strategy is anchored to a public-sector cost benchmark that does not reflect the value proposition for premium private clients. The plan assumes bundled maintenance will be accepted without addressing client resistance or alternative pricing structures.

## 1.6.A Issue - No Formal Contingency Plan for First-Contract Failure

The gated tranche structure creates a dangerous dependency where a single delayed permit or contract signature freezes the entire operating budget. The plan mentions a Plan B protocol with an internal hard gate at month 15, but this is presented as a mitigation strategy, not a formal contingency plan with pre-negotiated triggers and funding mechanisms. The 30-50% probability of first-contract failure is not addressed with specific contingency actions, emergency funding triggers, or pivot strategies. The fortress headquarters competes for capital needed for the first moat, CITES permits, and veterinary infrastructure, but there is no clear decision framework for when to defer headquarters construction in favor of revenue-generating activities. The plan does not address what happens if the Ketziot-style government contract does not materialize, if the private billionaire prospects do not convert, or if both tracks fail simultaneously.

### 1.6.B Tags

- contingency planning
- first-contract failure
- gated tranche dependency
- capital freeze risk
- Plan B protocol
- emergency funding

### 1.6.C Mitigation

Establish a formal contingency plan with pre-negotiated triggers and funding mechanisms by month 3 (December 2026). Define specific failure conditions: no contract signed by month 15, CITES permits denied by month 12, or burn rate exceeding 90% of first tranche without revenue. Pre-negotiate a $1 million to $2 million bridge loan facility with the Gulf investor secured against the fortress asset, accessible upon milestone failure. Establish a monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche, reviewed weekly by the founding team. If no contract is signed by month 15, trigger a strategic pivot to regulatory consulting-only revenue while continuing moat sales. Defer non-essential fortress finishes to later tranches while completing the critical demonstration pool and boardroom. Target first revenue within 12 months to create a 6-month buffer before the 18-month deadline. Consult: crisis management consultants, turnaround specialists, venture capital contingency planning experts. Read: gated tranche structure best practices, startup contingency planning frameworks, government contract failure case studies. Provide: detailed contingency plan with specific triggers, funding mechanisms, pivot strategies, and decision frameworks; burn-rate dashboard design; bridge loan term sheet; fortress asset valuation for collateral purposes.

### 1.6.D Consequence

Without a formal contingency plan, a single delayed permit or contract signature freezes the entire operating budget. The company cannot pivot quickly if early assumptions prove wrong. The gated tranche structure means the company collapses if the first contract does not materialize within 18 months, with no fallback revenue and no reference case to show other buyers.

### 1.6.E Root Cause

The plan treats the gated tranche structure as a funding mechanism rather than a risk management tool. The 30-50% probability of first-contract failure is acknowledged but not addressed with specific contingency actions, emergency funding triggers, or pivot strategies.

---

# 2 Expert: Arid-Climate Aquatic Systems Engineer

**Knowledge**: desert water management, closed-loop water recycling, evaporation mitigation, thermal management for aquatic habitats, arid-climate engineering

**Why**: The plan requires crocodile moats in arid environments with 2m+ annual evaporation — a unique engineering challenge no standard aquatic engineer is trained to solve.

**What**: Design closed-loop water recycling achieving 90%+ reuse efficiency with UV sterilization, biological filtration, and N+1 redundancy, plus geothermal cooling.

**Skills**: closed-loop water recycling, evaporation mitigation, geothermal cooling, IoT water quality monitoring, arid-climate habitat engineering

**Search**: arid climate aquatic engineering water recycling evaporation mitigation crocodile habitat

## 2.1 Primary Actions

- Engage a CITES specialist legal firm with Appendix I captive-breeding exemption experience within 30 days (by October 5, 2026). Confirm in writing the specific exemption mechanism available for Nile crocodile commercial trade, file simultaneously with Egyptian, Israeli, and UAE authorities, and pre-negotiate breeding facility registration approval with the Egyptian CITES Management Authority. Allocate $200,000-$500,000 in legal fees.
- Restructure the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (~$8.08M total value) with 50% upfront payment. Make the 5-year maintenance and animal-replacement agreement ($500K/year = $2.5M) a non-negotiable term. If the client refuses bundled maintenance, price the standalone moat at the full $41,000/meter Ketziot benchmark rather than at a loss. Build a detailed financial model showing positive gross margins only with bundled maintenance.
- Establish a formal Plan B protocol with pre-negotiated emergency funding triggers by month 12 (September 2027). Pre-negotiate a $1M-$2M bridge loan facility secured against the fortress asset with the Gulf investor. Set an internal hard gate at month 15 (December 2027): if no contract is signed, trigger a strategic pivot to regulatory consulting-only revenue and activate the bridge loan. Define regulatory consulting pricing ($100K-$250K per engagement), target clients, and projected cash flow. Establish a monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche.

## 2.2 Secondary Actions

- Split the first $2M tranche into $1M for fortress headquarters demonstration-pool completion and $1M for CITES permit filing, regulatory counsel retainers, and first-site survey expenses by September 15, 2026, ensuring both physical presence and commercial momentum advance simultaneously.
- Begin hiring the minimum viable team of 18-25 people starting month 1, prioritizing 3 veterinarians and 1 regulatory affairs specialist by October 1, 2026, with handler recruitment launching a 20-applicant inaugural cohort by November 1, 2026.
- Negotiate exclusive long-term supply agreements with at least three Lake Nasser crocodile farms by December 2026, locking in volume and pricing for juvenile Nile crocodiles while simultaneously investing $500,000-$800,000 of the second tranche into a small proprietary breeding facility near Lake Nasser as a parallel capability.
- Implement triple-redundant physical containment systems on every moat: submerged electrified fencing with dual independent circuits, overhanging acrylic/glass walls angled outward at >45 degrees, and dual-gate airlock entry chambers with biometric access, budgeting an additional 30% capital contingency above baseline engineering costs.
- Adopt welfare standards that exceed independent audit requirements by a meaningful margin, investing in real-time public-facing monitoring dashboards showing water quality, temperature, and animal health metrics 24/7, with blockchain-based audit trails for all welfare data to prevent tampering.
- Secure comprehensive liability insurance from Lloyd's of London or equivalent specialty underwriters by month 3 (December 2026), at ~3-5% of annual contract revenue ($200K-$400K/year), providing $25M-$50M aggregate liability with a $5M per-incident limit for animal escape/bite events.
- Establish a written client-acceptance framework that excludes clients under active international sanctions or ICC investigation while maintaining the broader 'no client too controversial' stance, requiring board approval for any client whose public profile generates sustained negative media attention.
- Design closed-loop water recycling systems with 90%+ water reuse efficiency reducing replenishment needs by 80%, install redundant water treatment systems (UV sterilization, biological filtration, mechanical filtration) with N+1 redundancy, and implement IoT-based water quality monitoring with automated dosing and alerting.
- Establish the handler academy on the Nile island headquarters with a four-month residential program producing a fixed annual cohort, partner with Egypt's existing crocodile-farm labor pool for experienced recruits offering accelerated certification, and recruit from the hospitality industry for service-oriented candidates.
- Diversify the first-contract pursuit between government (Ketziot-style) and private billionaire compound deals to hedge against political delays, develop a compelling 'sovereign capability' argument, and target at least two letters of intent by month 12.
- Maintain multi-currency accounts with a primary USD treasury and local currency sub-accounts, hedge ILS exposure on the Ketziot contract using forward contracts or currency options through a major bank (estimated cost: 2-4% of contract value), and budget EGP expenses with a 20% currency buffer.
- Commission independent environmental impact assessments ($50,000-$150,000 per installation) before any contract signing, with 5-year post-installation environmental monitoring, and conduct quarterly third-party penetration testing of all containment systems with formal reports filed to the board.

## 2.3 Follow Up Consultation

Review the written confirmation from the CITES legal firm on the specific Appendix I exemption mechanism available, including timeline for permit approval and any jurisdictional rejections. Review the revised financial model showing positive gross margins only with bundled maintenance, and the client-facing contract template that makes the 5-year maintenance agreement a non-negotiable term. Review the written Plan B protocol document with clear triggers, funding mechanisms, pivot actions, and decision authority, signed off by the board and the Gulf investor. Assess progress on hiring the minimum viable team (3 veterinarians, 1 regulatory affairs specialist, initial handler cohort). Assess progress on negotiating exclusive supply agreements with Lake Nasser farms and the proprietary breeding facility investment plan. Assess progress on triple-redundant containment system design and the 30% capital contingency budget. Assess progress on liability insurance quotes from Lloyd's of London or equivalent underwriters. Discuss the client-acceptance framework and whether the 'no client too controversial' policy needs refinement based on early prospect conversations. Review the monthly burn-rate dashboard and tranche trigger status. Discuss any early signals from the dual-track client pipeline (government and private billionaire prospects).

## 2.4.A Issue - CITES Appendix I Commercial Trade Exemption Mechanism Is Legally Undefined

The entire animal sourcing and deployment chain has zero legal viability until the specific exemption mechanism is defined and filed. The plan assumes captive-breeding certification under CITES Article VIII or registered commercial breeding operations will work, but this has not been confirmed with the Egyptian CITES Management Authority or any other jurisdiction. Nile crocodiles are Appendix I, which means commercial trade is prohibited unless a specific exemption applies. The plan treats this as a paperwork exercise with a 30-day legal firm engagement, but the reality is that Appendix I exemptions for commercial security deployments have no established precedent. Israel's 'tended wild animal' reclassification is a domestic classification, not a CITES export permit. Without a confirmed CITES pathway, you cannot legally source, transport, or deploy a single crocodile across any international border. Every day of delay compounds the risk of total business model collapse, and the gated tranche structure means you could burn through the first $2M tranche on headquarters and team building before discovering the legal pathway does not exist.

### 2.4.B Tags

- CITES_Appendix_I
- legal_viability
- export_permits
- regulatory_precedent
- cross_border_trade

### 2.4.C Mitigation

Engage a CITES specialist legal firm with specific Appendix I captive-breeding exemption experience within 30 days (by October 5, 2026). Do not rely on general wildlife law firms. The firm must (1) confirm in writing whether captive-breeding certification under Article VIII is available for Nile crocodiles in Egypt, (2) identify any additional exemption mechanisms such as registered commercial breeding operations, (3) file simultaneously with the Egyptian CITES Management Authority, Israeli Environmental Ministry, and UAE wildlife authority to create redundancy, and (4) pre-negotiate with the Egyptian authority to pre-approve breeding facility registrations before commercial applications are filed. Allocate $200,000-$500,000 in legal fees across jurisdictions. Establish a CITES compliance officer role reporting directly to the board by month 3 (December 2026) with mandatory quarterly audits of all cross-border crocodile movements. If CITES export permits are not filed by month 3 (December 2026) or denied by month 12 (September 2027), trigger the Plan B pivot to regulatory consulting-only revenue and freeze all animal-sourcing expenditures until permits are secured. Consult: specialized CITES legal firms with Appendix I captive-breeding experience (e.g., firms that have handled crocodile farming export permits in Africa). Read: CITES Appendices I, II, and III text, Article VIII exemptions, and Egyptian CITES Management Authority guidance documents. Provide: written confirmation from legal counsel on the specific exemption mechanism available, timeline for permit approval, and any jurisdictional rejections.

### 2.4.D Consequence

Without a confirmed CITES exemption mechanism, the entire business model has zero legal viability. You cannot source, transport, or deploy Nile crocodiles across any international border. The venture collapses within months if this is not resolved, and the gated tranche structure means you could burn through capital on non-viable activities before discovering the legal pathway does not exist.

### 2.4.E Root Cause

The plan assumes a CITES exemption exists without confirming it with the relevant authorities. Israel's domestic 'tended wild animal' reclassification is conflated with international CITES export permit requirements. There is no established precedent for commercial security deployments of Appendix I species.

## 2.5.A Issue - Negative Unit Economics on First Contract Under 20% Discount Strategy

The standalone 20%-discounted moat price of ~$32,800/meter against ~$6M-$6.8M in direct costs for a 170-meter moat yields negative gross margins. The plan's 30-month positive cash flow target is mathematically impossible without multi-year maintenance contracts being explicitly bundled and accepted by clients. The Ketziot benchmark of $41,000/meter is a construction-and-animal cost reference, not a measure of what clients will pay. Bidding 20% below it wins the first government contract by being cheaper than an interior ministry improvising its own reptile program, but it also anchors the company's price floor to a public-sector number that ignores the premium clients pay for spectacle. The plan mentions bundling maintenance contracts as a possibility but does not make it mandatory. If the first client refuses bundled maintenance, the company prices at a loss. The $10M seed capital cannot sustain negative margins on the first contract while waiting for the 30-month positive cash flow target. The plan also does not address what happens if the first client negotiates the maintenance component down or refuses it entirely.

### 2.5.B Tags

- unit_economics
- negative_margins
- pricing_strategy
- cash_flow_target
- maintenance_bundling
- Ketziot_benchmark

### 2.5.C Mitigation

Restructure the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (~$8.08M total value) with 50% upfront payment. The standalone moat construction (~$5.58M at 20% discount) must be combined with a bundled 5-year maintenance and animal-replacement agreement ($500K/year = $2.5M) to yield positive gross margins. If the client refuses bundled maintenance, price the standalone moat at the full $41,000/meter Ketziot benchmark rather than at a loss. Do not offer the 20% discount without the maintenance bundle. Negotiate a currency hedge facility with the Gulf investor before tranche deployment to manage EGP and ILS exposure. Build a detailed financial model showing the revenue contribution from multi-year maintenance contracts versus one-time moat installations, with sensitivity analysis for maintenance rejection scenarios. Consult: a forensic accountant or financial modeler with experience in long-term service contracts and bundled pricing. Read: the Ketziot Prison moat budget breakdown (NIS 21 million allocation) to understand the cost structure you are competing against. Provide: a revised financial model showing positive gross margins only with bundled maintenance, and a client-facing contract template that makes the 5-year maintenance agreement a non-negotiable term.

### 2.5.D Consequence

Without bundled maintenance contracts, the first contract yields negative gross margins, making the 30-month positive cash flow target mathematically impossible. The $10M seed capital is depleted faster than projected, and the company cannot reach positive operating cash flow by month 30. If the first client refuses maintenance bundling, the company either loses money on the contract or must walk away from the reference deal that validates the entire business model.

### 2.5.E Root Cause

The 20% discount strategy is anchored to a public-sector cost benchmark without accounting for the full cost structure of a turnkey moat installation. The plan treats maintenance bundling as optional rather than mandatory, and does not model the financial impact of a client refusing the maintenance component.

## 2.6.A Issue - No Formal Contingency Plan for First-Contract Failure

The gated tranche structure creates a dangerous dependency where a single delayed permit or contract signature freezes the entire operating budget. The plan acknowledges this risk but does not establish a formal Plan B with pre-negotiated emergency funding triggers. The 18-month first-contract deadline is aggressive for an entirely new product category with zero operational precedent. Market validation is extremely recent (Israel's Ketziot moat, July 2026 — less than two months before the current date), representing a single data point. The probability of first-contract failure is estimated at 30-50% due to regulatory delays, political budget shifts, client hesitation, or CITES permit rejection. Without a contingency plan, a single failure cascades into total capital freeze. The plan mentions a 'Plan B pivot to regulatory consulting-only revenue' but does not pre-negotiate the bridge loan facility, does not establish the internal hard gate at month 15 with clear triggers, and does not define what 'regulatory consulting-only revenue' looks like in terms of pricing, clients, and cash flow. The fortress headquarters competes for capital needed for the first moat, CITES permits, and veterinary infrastructure, and there is no plan for what happens if the fortress becomes a financial liability rather than a brand asset.

### 2.6.B Tags

- contingency_planning
- single_point_failure
- gated_tranche_risk
- first_contract_failure
- Plan_B
- capital_freeze
- market_validation

### 2.6.C Mitigation

Establish a formal Plan B protocol with pre-negotiated emergency funding triggers by month 12 (September 2027). Specifically: (1) Pre-negotiate a $1M-$2M bridge loan facility secured against the fortress asset with the Gulf investor, accessible upon milestone failure. (2) Set an internal hard gate at month 15 (December 2027): if no contract is signed, trigger a strategic pivot to regulatory consulting-only revenue while continuing moat sales, and activate the bridge loan facility. (3) Define 'regulatory consulting-only revenue' with specific pricing ($100K-$250K per classification amendment engagement), target clients (governments considering wildlife reclassification), and projected cash flow. (4) Establish a monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche, reviewed weekly by the founding team, with a negotiated $1M emergency reserve facility from the Gulf investor accessible upon milestone achievement. (5) If CITES export permits are not filed by month 3 (December 2026) or denied by month 12 (September 2027), trigger the Plan B pivot and freeze all animal-sourcing expenditures. (6) Budget EGP expenses with a 20% currency buffer and convert USD to EGP in tranches timed to favorable exchange rates. Consult: a crisis management advisor or turnaround specialist with experience in capital-constrained startups facing single-point-of-failure risks. Read: the tranche-gated milestone architecture decision document and the risk assessment section of the project plan. Provide: a written Plan B protocol document with clear triggers, funding mechanisms, pivot actions, and decision authority, signed off by the board and the Gulf investor.

### 2.6.D Consequence

Without a formal contingency plan, a single delayed permit or contract signature freezes the entire operating budget. The 30-50% probability of first-contract failure means the company is likely to face a capital freeze scenario. Without pre-negotiated emergency funding, the company cannot pivot to regulatory consulting or sustain operations while waiting for the next opportunity. The venture collapses if the first contract fails and no Plan B exists.

### 2.6.E Root Cause

The plan treats the first contract as a certainty rather than a probability. The gated tranche structure is designed to protect the investor but creates a single point of failure for the company. The Plan B pivot is mentioned conceptually but not operationalized with specific triggers, funding mechanisms, or revenue projections.

---

# The following experts did not provide feedback:

# 3 Expert: Crisis Communications and Reputational Risk Director

**Knowledge**: animal welfare crisis management, reputational risk mitigation, stakeholder communications, media strategy for controversial industries

**Why**: The 'no client too controversial' policy means a client controversy damages the moat and welfare audit — a single violation triggers global media campaigns.

**What**: Establish the independently audited welfare program with real-time public-facing monitoring dashboards and blockchain-based audit trails, plus a $500K crisis reserve.

**Skills**: crisis communications, animal welfare media strategy, stakeholder engagement, reputation management, blockchain audit transparency

**Search**: crisis communications animal welfare reputational risk management controversial industries PR

# 4 Expert: Ultra-High-Net-Worth Client Experience Strategist

**Knowledge**: private client acquisition, billionaire compound security, royal palace protocols, ceremonial experience design, luxury hospitality

**Why**: The plan's success depends on diversifying beyond government into billionaire compounds and royal palaces — where the theatrical boardroom negotiation converts prospects.

**What**: Design three standardized ceremonial tiers (diplomatic, private, exclusive) for the boardroom negotiation experience, calibrating handler ratios and pool configurations.

**Skills**: private client acquisition, ceremonial experience design, luxury hospitality protocols, high-net-worth relationship management, theatrical staging

**Search**: ultra high net worth client acquisition private security ceremonial experience design billionaire compounds

# 5 Expert: Capital Deployment and Tranche Strategy Advisor

**Knowledge**: venture capital staging, gated milestone architecture, seed capital management, financial modeling for first ventures, investor relations

**Why**: The $10M seed capital in gated tranches of $2M, $3M, and $5M is the binding constraint on every other lever; a single delayed permit or contract signature freezes the entire operating budget, and no expert currently addresses this structural financial risk.

**What**: Design the tranche-gated milestone architecture calibrating each release to externally verifiable proof points, establish monthly burn-rate dashboards with hard triggers at 70% and 90%, and negotiate an emergency reserve facility with the Gulf investor.

**Skills**: financial modeling, milestone-based funding design, investor negotiation, burn-rate management, contingency reserve structuring

**Search**: venture capital tranche milestone architecture seed funding gated release financial advisor

# 6 Expert: Escape-Prevention Systems Engineer

**Knowledge**: redundant barrier design, submerged electrified fencing, acrylic wall engineering, dual-gate airlock systems, biometric access control, containment integrity monitoring

**Why**: A single crocodile breach causing human injury would terminate the business irreversibly — destroying the welfare audit PR shield and triggering liability exceeding $10M–$50M — yet no expert addresses the mechanical containment systems beyond water management.

**What**: Design triple-redundant physical containment systems for every moat: dual-circuit submerged electrified fencing, overhanging acrylic walls angled outward at >45 degrees, and dual-gate airlock chambers with biometric access, plus IoT containment integrity monitoring.

**Skills**: redundant barrier engineering, electrified fencing design, acrylic/glass structural engineering, biometric access systems, penetration testing, containment integrity sensors

**Search**: escape prevention engineering redundant containment systems electrified fencing acrylic wall crocodile moat

# 7 Expert: Animal Sourcing and Breeding Program Director

**Knowledge**: Nile crocodile husbandry, CITES-compliant supply chain management, Lake Nasser farm relationships, captive breeding programs, genetic lineage management, transport logistics for live reptiles

**Why**: Without Nile crocodiles sourced from Lake Nasser farms under CITES-compliant chains, there is no product to sell; sourcing determines unit economics, supply chain resilience, and the viability of the audited welfare program.

**What**: Negotiate exclusive long-term supply agreements with at least three Lake Nasser crocodile farms while simultaneously building a small proprietary breeding facility near Lake Nasser as a parallel capability, establishing a 6-month strategic reserve of 20+ juvenile crocodiles.

**Skills**: CITES-compliant sourcing, crocodile husbandry, farm relationship management, breeding program design, transport logistics, genetic diversity management

**Search**: Nile crocodile sourcing Lake Nasser farm CITES compliant supply chain breeding program director

# 8 Expert: Handler Corps Training and Ceremonial Standards Director

**Knowledge**: specialized workforce development, reptile behavior training, ceremonial protocol design, safety certification programs, talent pipeline management for niche roles

**Why**: The handler corps is the living embodiment of the theatrical experience that converts prospects into clients, yet the narrow talent pipeline is difficult to scale — training a single handler takes 4–6 months and building a corps of 20+ requires 12–18 months.

**What**: Establish the handler academy on the Nile island headquarters with a four-month residential program combining Egyptian crocodile-farm apprenticeship with ceremonial hospitality protocol training, targeting 12 graduates bound by multi-year service contracts.

**Skills**: specialized training program design, reptile behavior instruction, ceremonial protocol development, safety certification, talent pipeline scaling, performance standardization

**Search**: handler training academy reptile behavior ceremonial protocol specialized workforce development crocodile