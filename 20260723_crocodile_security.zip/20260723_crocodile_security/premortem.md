A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The regulatory environment will remain stable and supportive of using live crocodiles in security. | Engage with regulatory bodies to assess current sentiment and potential changes in wildlife regulations. | Any indication of upcoming regulatory changes that could restrict or complicate the use of live crocodiles. |
| A2 | There is a strong market demand for innovative security solutions involving live animals. | Conduct market research surveys targeting potential clients to gauge interest in crocodile moats. | Low interest or negative feedback from potential clients regarding the use of live crocodiles for security. |
| A3 | Public perception of using live animals for security can be positively influenced through effective communication. | Implement a community engagement strategy and monitor public sentiment through surveys. | Significant negative media coverage or community backlash despite engagement efforts. |
| A4 | The initial seed funding of $10 million will be sufficient to cover all project phases without additional financing. | Conduct a detailed financial analysis to project cash flow and funding needs over the initial project phases. | Identification of a funding shortfall requiring an additional $1-2 million due to unforeseen expenses. |
| A5 | The operational logistics for managing live crocodiles will be straightforward and manageable with the current team. | Evaluate the team's expertise and operational protocols through a comprehensive review of animal management practices. | Discovery of significant gaps in expertise or operational protocols that could lead to service delivery failures. |
| A6 | The market for innovative security solutions will remain stable and grow over the next five years. | Conduct market trend analysis and competitor assessments to evaluate the growth potential of the security solutions market. | Evidence of declining interest or saturation in the market for innovative security solutions. |
| A7 | The technology required for habitat management and crocodile monitoring will be readily available and affordable. | Research current technologies available for habitat management and monitoring of live animals, including costs and supplier reliability. | Identification of significant technological gaps or high costs that exceed budget constraints. |
| A8 | The project will attract skilled personnel necessary for operational success without significant recruitment challenges. | Conduct a labor market analysis to assess the availability of qualified candidates in the region for key roles. | Evidence of a shortage of qualified candidates or high turnover rates in critical positions. |
| A9 | The ecological impact of sourcing crocodiles will be minimal and manageable within existing environmental regulations. | Engage with environmental experts to conduct an ecological impact assessment of sourcing practices. | Findings that indicate significant ecological risks or regulatory challenges related to sourcing crocodiles. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Regulatory Quagmire | Process/Financial | A1 | Regulatory Compliance Officer | CRITICAL (20/25) |
| FM2 | The Integration Challenge | Technical/Logistical | A2 | Operations Manager | CRITICAL (20/25) |
| FM3 | The Public Backlash | Market/Human | A3 | Marketing and PR Specialist | CRITICAL (20/25) |
| FM4 | The Regulatory Quagmire | Process/Financial | A1 | Regulatory Compliance Officer | CRITICAL (20/25) |
| FM5 | The Integration Challenge | Technical/Logistical | A2 | Operations Manager | CRITICAL (20/25) |
| FM6 | The Public Backlash | Market/Human | A3 | Marketing and PR Specialist | CRITICAL (20/25) |
| FM7 | The Regulatory Quagmire | Process/Financial | A1 | Regulatory Compliance Officer | CRITICAL (20/25) |
| FM8 | The Integration Challenge | Technical/Logistical | A2 | Operations Manager | CRITICAL (20/25) |
| FM9 | The Public Backlash | Market/Human | A3 | Marketing and PR Specialist | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Regulatory Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Regulatory Compliance Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project heavily relies on regulatory approvals for using live crocodiles. Delays in obtaining necessary permits could extend project timelines by 3-6 months, increasing costs by over $50,000. This could also affect public perception and stakeholder confidence.

##### Early Warning Signs
- Regulatory agencies express concerns about the project.
- Delays in permit application processing exceed 30 days.
- Increased scrutiny from animal welfare organizations.

##### Tripwires
- Permit applications take longer than 60 days to process.
- Regulatory agency meetings are canceled or postponed more than twice.
- Negative feedback from regulatory bodies is received.

##### Response Playbook
- Contain: Schedule immediate meetings with regulatory agencies to clarify concerns.
- Assess: Review the status of all pending permits and identify bottlenecks.
- Respond: Develop a revised compliance strategy based on feedback from regulatory bodies.


**STOP RULE:** If regulatory approvals are not secured within 12 months, the project will be canceled.

---

#### FM2 - The Integration Challenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
Operational challenges in managing live crocodiles could lead to service delivery failures. Issues with habitat design, water management, and animal behavior could result in redesign costs of $100,000-$200,000 and delays of 2-4 months.

##### Early Warning Signs
- Increased veterinary care incidents reported.
- Habitat design plans receive multiple revisions.
- Negative feedback from pilot project testing.

##### Tripwires
- More than 3 redesigns of habitat plans are required.
- Veterinary care costs exceed $50,000 in the first year.
- Pilot project fails to meet performance metrics.

##### Response Playbook
- Contain: Halt further construction until habitat design is validated.
- Assess: Conduct a thorough review of habitat design and animal management protocols.
- Respond: Engage with habitat design experts to refine plans and address issues.


**STOP RULE:** If pilot project fails to demonstrate operational viability within 6 months, the project will pivot to alternative security solutions.

---

#### FM3 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing and PR Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Public backlash against using live crocodiles for security may lead to negative media coverage, resulting in delays of 3-6 months in contract signings and additional marketing costs of $30,000-$50,000. This could hinder client acquisition and overall project success.

##### Early Warning Signs
- Negative media articles or social media posts increase.
- Community engagement events receive low attendance.
- Feedback from community stakeholders is predominantly negative.

##### Tripwires
- Negative media coverage exceeds 5 articles in a month.
- Community sentiment surveys show less than 50% support.
- Marketing costs exceed budget by 20% due to backlash management.

##### Response Playbook
- Contain: Develop a rapid response plan for negative media coverage.
- Assess: Conduct community sentiment surveys to gauge public opinion.
- Respond: Implement a public relations strategy emphasizing animal welfare and community benefits.


**STOP RULE:** If community support does not improve within 6 months, the project will be re-evaluated for viability.

---

#### FM4 - The Regulatory Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Regulatory Compliance Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project heavily relies on regulatory approvals for using live crocodiles. Delays in obtaining necessary permits could extend project timelines by 3-6 months, increasing costs by over $50,000. This could also affect public perception and stakeholder confidence.

##### Early Warning Signs
- Regulatory agencies express concerns about the project.
- Delays in permit application processing exceed 30 days.
- Increased scrutiny from animal welfare organizations.

##### Tripwires
- Permit applications take longer than 60 days to process.
- Regulatory agency meetings are canceled or postponed more than twice.
- Negative feedback from regulatory bodies is received.

##### Response Playbook
- Contain: Schedule immediate meetings with regulatory agencies to clarify concerns.
- Assess: Review the status of all pending permits and identify bottlenecks.
- Respond: Develop a revised compliance strategy based on feedback from regulatory bodies.


**STOP RULE:** If regulatory approvals are not secured within 12 months, the project will be canceled.

---

#### FM5 - The Integration Challenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
Operational challenges in managing live crocodiles could lead to service delivery failures. Issues with habitat design, water management, and animal behavior could result in redesign costs of $100,000-$200,000 and delays of 2-4 months.

##### Early Warning Signs
- Increased veterinary care incidents reported.
- Habitat design plans receive multiple revisions.
- Negative feedback from pilot project testing.

##### Tripwires
- More than 3 redesigns of habitat plans are required.
- Veterinary care costs exceed $50,000 in the first year.
- Pilot project fails to meet performance metrics.

##### Response Playbook
- Contain: Halt further construction until habitat design is validated.
- Assess: Conduct a thorough review of habitat design and animal management protocols.
- Respond: Engage with habitat design experts to refine plans and address issues.


**STOP RULE:** If pilot project fails to demonstrate operational viability within 6 months, the project will pivot to alternative security solutions.

---

#### FM6 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing and PR Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Public backlash against using live crocodiles for security may lead to negative media coverage, resulting in delays of 3-6 months in contract signings and additional marketing costs of $30,000-$50,000. This could hinder client acquisition and overall project success.

##### Early Warning Signs
- Negative media articles or social media posts increase.
- Community engagement events receive low attendance.
- Feedback from community stakeholders is predominantly negative.

##### Tripwires
- Negative media coverage exceeds 5 articles in a month.
- Community sentiment surveys show less than 50% support.
- Marketing costs exceed budget by 20% due to backlash management.

##### Response Playbook
- Contain: Develop a rapid response plan for negative media coverage.
- Assess: Conduct community sentiment surveys to gauge public opinion.
- Respond: Implement a public relations strategy emphasizing animal welfare and community benefits.


**STOP RULE:** If community support does not improve within 6 months, the project will be re-evaluated for viability.

---

#### FM7 - The Regulatory Quagmire

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Regulatory Compliance Officer
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project heavily relies on regulatory approvals for using live crocodiles. Delays in obtaining necessary permits could extend project timelines by 3-6 months, increasing costs by over $50,000. This could also affect public perception and stakeholder confidence.

##### Early Warning Signs
- Regulatory agencies express concerns about the project.
- Delays in permit application processing exceed 30 days.
- Increased scrutiny from animal welfare organizations.

##### Tripwires
- Permit applications take longer than 60 days to process.
- Regulatory agency meetings are canceled or postponed more than twice.
- Negative feedback from regulatory bodies is received.

##### Response Playbook
- Contain: Schedule immediate meetings with regulatory agencies to clarify concerns.
- Assess: Review the status of all pending permits and identify bottlenecks.
- Respond: Develop a revised compliance strategy based on feedback from regulatory bodies.


**STOP RULE:** If regulatory approvals are not secured within 12 months, the project will be canceled.

---

#### FM8 - The Integration Challenge

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Operations Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
Operational challenges in managing live crocodiles could lead to service delivery failures. Issues with habitat design, water management, and animal behavior could result in redesign costs of $100,000-$200,000 and delays of 2-4 months.

##### Early Warning Signs
- Increased veterinary care incidents reported.
- Habitat design plans receive multiple revisions.
- Negative feedback from pilot project testing.

##### Tripwires
- More than 3 redesigns of habitat plans are required.
- Veterinary care costs exceed $50,000 in the first year.
- Pilot project fails to meet performance metrics.

##### Response Playbook
- Contain: Halt further construction until habitat design is validated.
- Assess: Conduct a thorough review of habitat design and animal management protocols.
- Respond: Engage with habitat design experts to refine plans and address issues.


**STOP RULE:** If pilot project fails to demonstrate operational viability within 6 months, the project will pivot to alternative security solutions.

---

#### FM9 - The Public Backlash

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Marketing and PR Specialist
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
Public backlash against using live crocodiles for security may lead to negative media coverage, resulting in delays of 3-6 months in contract signings and additional marketing costs of $30,000-$50,000. This could hinder client acquisition and overall project success.

##### Early Warning Signs
- Negative media articles or social media posts increase.
- Community engagement events receive low attendance.
- Feedback from community stakeholders is predominantly negative.

##### Tripwires
- Negative media coverage exceeds 5 articles in a month.
- Community sentiment surveys show less than 50% support.
- Marketing costs exceed budget by 20% due to backlash management.

##### Response Playbook
- Contain: Develop a rapid response plan for negative media coverage.
- Assess: Conduct community sentiment surveys to gauge public opinion.
- Respond: Implement a public relations strategy emphasizing animal welfare and community benefits.


**STOP RULE:** If community support does not improve within 6 months, the project will be re-evaluated for viability.
