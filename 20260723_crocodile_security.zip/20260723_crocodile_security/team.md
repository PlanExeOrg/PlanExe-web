*Roles Needed & Example People*

# Roles

## 1. CITES & Regulatory Affairs Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The CITES & Regulatory Affairs Director owns the entire legal architecture upon which the business model rests — from identifying and filing the Appendix I commercial trade exemption mechanism to securing wildlife classification amendments across every client jurisdiction. This role is the absolute prerequisite for all commercial activity and requires continuous, deep engagement with multiple national CITES Management Authorities and international wildlife law firms. The existential legal risk (total business model collapse if permits are denied) demands a dedicated, embedded leader with full institutional knowledge, not a part-time or contracted arrangement.

**Explanation**:
Owns the entire legal architecture enabling the business model, from identifying and filing the CITES Appendix I commercial trade exemption mechanism to securing wildlife classification amendments ('tended wild animal' status) across every client jurisdiction. This role is the absolute prerequisite for all commercial activity — without permits filed and secured, no animal can be sourced, transported, or deployed, and no contract can be signed. Operates across Egypt, Israel, UAE, and future jurisdictions, coordinating with international wildlife law firms and national CITES Management Authorities.

**Consequences**:
The entire business model has zero legal viability. Without a defined CITES Appendix I exemption mechanism filed and approved, every day of delay compounds the risk of total business model collapse. The company cannot source Nile crocodiles from Lake Nasser farms, cannot export them to client sites, and cannot legally deploy moats in any jurisdiction. The $10M seed capital would be frozen with no path to revenue, and the first-contract deadline of 18 months would be missed entirely.

**People Count**:
1

**Typical Activities**:
Drafting and filing CITES Appendix I commercial trade exemption applications across Egypt, Israel, and the UAE simultaneously; conducting quarterly audits of all cross-border crocodile movements and filing compliance reports directly to the board; negotiating pre-approval of breeding facility registrations with the Egyptian CITES Management Authority; coordinating with international wildlife law firms on wildlife classification amendments ('tended wild animal' status) for each target jurisdiction; maintaining a regulatory pipeline map with milestone deadlines per country; representing Crocodile Security in hearings before national CITES Management Authorities; training internal staff on CITES compliance protocols; and establishing a CITES compliance officer role reporting structure.

**Background Story**:
Dr. Yasmin Khalil, a 42-year-old Egyptian-born legal strategist raised in the diplomatic corridors of Geneva and Cairo, holds a doctorate in international environmental law from the Graduate Institute of International and Development Studies and a postgraduate certificate in CITES compliance from the University of Geneva. She spent fifteen years at the Secretariat of the Convention on International Trade in Endangered Species, where she authored the interpretive guidance that classified Nile crocodile captive-breeding operations under Article VIII, before leaving to join a prestigious wildlife law firm in Dubai. Her expertise in navigating Appendix I commercial trade exemptions across multiple jurisdictions makes her the only person alive who has successfully secured simultaneous CITES filings for three or more countries in a single fiscal year. She is relevant because the entire Crocodile Security business model rests on a legal mechanism that does not yet exist in written form, and her institutional relationships with the Egyptian CITES Management Authority, the Israeli Environmental Ministry, and the UAE Wildlife Authority represent the fastest possible path to making those permits a reality.

**Equipment Needs**:
Legal research databases (CITES Appendix I case law, international wildlife trade precedents), CITES compliance management software for tracking permit filings across multiple jurisdictions, secure encrypted communication systems for coordinating with international wildlife law firms and national CITES Management Authorities, document management systems for preparing and filing commercial trade exemption applications, video-conferencing facilities for multi-jurisdictional regulatory hearings, and specialized regulatory mapping tools to maintain the pipeline of wildlife classification amendment milestones per target country.

**Facility Needs**:
Dedicated office at the Ottoman-fortress headquarters in Egypt for coordinating with international wildlife law firms and hosting regulatory meetings, secure document preparation room for drafting CITES exemption applications, access to the Egyptian CITES Management Authority offices in Cairo for in-person permit negotiations, conference facilities capable of hosting multi-country regulatory coordination sessions, and a dedicated compliance audit room for quarterly cross-border movement audits and board reporting.

## 2. Chief Moat Engineer & Escape-Prevention Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Moat Engineer & Escape-Prevention Lead designs and oversees all triple-redundant physical containment systems for every moat installation. This role owns the engineering philosophy that determines whether the company achieves its zero-injury success criterion — an existential requirement. A single breach terminates the business irreversibly. The role requires continuous on-site oversight of construction quality, arid-climate water management design, and quarterly third-party penetration testing coordination, all of which demand full-time dedication and deep accumulated expertise.

**Explanation**:
Designs and oversees all triple-redundant physical containment systems for every moat installation, including dual-circuit submerged electrified fencing, overhanging acrylic/glass walls angled at >45 degrees, and dual-gate airlock entry chambers with biometric access. This role owns the engineering philosophy that determines whether the company achieves zero human injuries — the existential success criterion. Responsible for arid-climate water management design, closed-loop water recycling systems achieving 90%+ reuse, geothermal cooling loops, and reinforced glass boardroom specifications. Also oversees moat engineering quality whether performed in-house or via subcontractors.

**Consequences**:
A single crocodile breach causing human injury or death would terminate the business irreversibly — destroying the independently audited welfare program PR shield, triggering legal liability exceeding $10M–$50M, voiding all insurance coverage, and generating irreversible global media attention. Without expert engineering of triple-redundant containment, the company cannot satisfy the zero-injury success criterion or the auditor requirements that underpin its entire commercial credibility.

**People Count**:
1

**Typical Activities**:
Designing and overseeing triple-redundant physical containment systems for every moat installation; conducting monthly escape drills and coordinating quarterly third-party penetration testing; designing closed-loop water recycling systems achieving 90%+ reuse efficiency with UV sterilization, biological filtration, and mechanical filtration in N+1 redundancy; specifying reinforced glass boardroom floor installations capable of supporting twelve adult Nile crocodiles; managing arid-climate thermal management including geothermal cooling loops and automated shade systems; overseeing moat engineering quality whether performed in-house or via subcontractors; installing IoT-based containment integrity monitoring with circuit continuity sensors and stress sensors; and maintaining a 15-minute response-time standard for containment breach emergencies.

**Background Story**:
Captain Amir Hadid, a 48-year-old Israeli marine and civil engineer born in Eilat and educated at the Technion – Israel Institute of Technology, where he earned a master's degree in aquatic structural engineering, spent two decades designing containment systems for the Israeli Navy's underwater facilities and later for the Dead Sea Works mineral extraction plants. His specialty is designing redundant barrier systems that must perform flawlessly in extreme salinity and temperature gradients, skills he now applies to freshwater crocodile moats in arid climates. He personally designed the triple-redundant containment philosophy — dual-circuit submerged electrified fencing, >45-degree overhanging acrylic walls, and dual-gate airlock chambers — that became Crocodile Security's engineering standard. He is relevant because a single crocodile breach would terminate the business irreversibly, and his combination of military-grade containment expertise and arid-climate water management experience makes him the only engineer capable of guaranteeing the zero-injury success criterion that underpins the company's entire commercial credibility.

**Equipment Needs**:
CAD and structural engineering software for designing triple-redundant containment systems (dual-circuit submerged electrified fencing, >45-degree overhanging acrylic/glass walls, dual-gate airlock chambers with biometric access), water quality testing laboratory equipment (pH, ammonia, dissolved oxygen analyzers), electrical testing equipment for dual-circuit fencing continuity verification, pressure and stress testing equipment for acrylic wall integrity, GPS tracking system components for crocodile microchipping and external transmitters, IoT sensor prototyping equipment for containment integrity monitoring (circuit continuity sensors, stress sensors, water-level sensors), and specialized arid-climate thermal modeling software for geothermal cooling loop design.

**Facility Needs**:
Engineering workshop and design office at the fortress headquarters for moat system design and component prototyping, a water quality testing laboratory for validating closed-loop recycling systems, access to all construction sites (fortress headquarters, Lake Nasser facility, Ketziot demonstration site, UAE regional office) for on-site engineering oversight, a materials testing lab for acrylic/glass wall stress analysis, and a dedicated integration workshop for assembling and testing IoT-based containment monitoring platforms before deployment.

## 3. Head Veterinarian & Animal Welfare Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Head Veterinarian & Animal Welfare Director leads the veterinary team and owns the independently audited animal welfare program that serves as both the company's moral shield and primary commercial differentiator. A single welfare violation could result in contract cancellations worth $5M–$7M, loss of CITES permits, and a global media campaign. This role requires continuous oversight of veterinary protocols, real-time animal health monitoring, board-level welfare reporting, and supervision of the proprietary breeding program — all demanding full-time, embedded leadership.

**Explanation**:
Leads the veterinary team of three (one lead, two associates) and owns the independently audited animal welfare program that serves as both the company's moral shield and commercial differentiator. Responsible for veterinary protocols, habitat quality standards, feeding logistics, health monitoring, and ensuring welfare standards exceed independent audit thresholds by a meaningful margin. Oversees the real-time public-facing monitoring dashboards with blockchain-based audit trails, manages the 24/7 animal health tracking system, and reports directly to the board on welfare compliance. Also supervises the small proprietary breeding program near Lake Nasser and coordinates with crocodile farms on stock quality and health.

**Consequences**:
A single welfare violation finding by an independent auditor could result in immediate contract cancellations (loss of $5M–$7M in revenue), loss of CITES permits, and a global media campaign costing $500,000–$2M in crisis management. Without rigorous veterinary leadership, the company cannot maintain the zero-welfare-violation success criterion, the independently audited welfare program collapses as a PR shield, and the company loses its primary reputational buffer and commercial differentiator. Animal mortality from disease outbreaks or poor care would also inflate per-moat costs dramatically.

**People Count**:
1

**Typical Activities**:
Leading the veterinary team of three (one lead, two associates) and overseeing all veterinary protocols, habitat quality standards, and feeding logistics across every moat installation; ensuring welfare standards exceed independent audit thresholds by a meaningful margin; managing the 24/7 animal health tracking system with GPS microchips and external transmitters; supervising the real-time public-facing monitoring dashboards with blockchain-based audit trails; reporting directly to the board on welfare compliance with mandatory quarterly audits; supervising the small proprietary breeding program near Lake Nasser and coordinating with crocodile farms on stock quality and health; commissioning independent environmental impact assessments before any contract signing; and hiring and managing the high-profile animal welfare advisor serving as a board-level position.

**Background Story**:
Dr. Ouma Sang, a 55-year-old Kenyan-born veterinary epidemiologist who earned her DVM from the University of Edinburgh and a PhD in reptile wildlife health from the Royal Veterinary College in London, spent twenty years as the chief veterinarian for the Kenya Wildlife Service managing crocodile populations across the Mara and Tsavo ecosystems before becoming the first African veterinarian to serve on the World Organisation for Animal Health's reptile health standards committee. She pioneered the real-time public-facing monitoring dashboard concept that uses blockchain-based audit trails for all welfare data, a system she first deployed for the Nairobi National Park crocodile census. She is relevant because the independently audited animal welfare program is both Crocodile Security's moral shield and its primary commercial differentiator, and her reputation among international animal welfare organizations — combined with her ability to set standards that exceed audit thresholds by a meaningful margin — makes her the only person who can transform a compliance obligation into a brand identity that justifies premium pricing.

**Equipment Needs**:
Veterinary diagnostic equipment (ultrasound machines, blood analysis instruments, radiography equipment for reptile health assessment), GPS microchip implantation and external transmitter systems for 24/7 animal health tracking, blockchain-based audit trail software for welfare data integrity, real-time water quality and temperature monitoring dashboards, climate-controlled holding pens with automated feeding systems, specialized reptile anesthesia and surgical equipment, and data analytics platforms for compiling welfare audit reports exceeding independent audit thresholds.

**Facility Needs**:
Fully equipped veterinary clinic at the Ottoman-fortress headquarters with surgical and diagnostic capability, animal holding and treatment facilities at the Lake Nasser breeding facility including climate-controlled recovery pens, a dedicated laboratory for water quality analysis and disease screening, office space for managing the real-time public-facing monitoring dashboards with 24/7 animal health metrics, and a quarantine/isolation facility at each installation site for managing animal health emergencies and transport arrivals.

## 4. Director of Ceremonial Operations & Handler Corps Master

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Director of Ceremonial Operations & Handler Corps Master recruits, trains, and manages the corps of 10–12+ ceremonial black-uniformed handlers who are the living embodiment of the company's theatrical brand and the human-in-the-loop safety layer of the hybrid escape-prevention philosophy. This role establishes and runs the handler academy, designs the ceremonial experience that converts psychological awe into contract signatures, and maintains the critical 1:3 handler-to-crocodile ratio. Training a single handler takes 4–6 months, making dedicated full-time leadership essential to meet the first-contract staffing deadline.

**Explanation**:
Recruits, trains, and manages the corps of 10–12+ ceremonial black-uniformed handlers who are the living embodiment of the company's theatrical brand and the human-in-the-loop safety layer of the hybrid escape-prevention philosophy. Establishes and runs the handler academy on the Nile island headquarters with a four-month residential program combining Egyptian crocodile-farm apprenticeship with ceremonial hospitality protocol training. Each handler is cross-trained in reptile behavior, client-service etiquette, and emergency protocol, maintaining a handler-to-crocodile ratio of at least 1:3 during all client events. Designs the ceremonial experience that converts psychological awe into contract signatures at premium price points.

**Consequences**:
The handler corps is both a core differentiator and a critical safety component — without trained handlers, the hybrid escape-prevention philosophy loses its human-in-the-loop safety layer, and the theatrical experience that justifies premium pricing collapses. A handler injury during a client event could result in $100,000–$1M in medical costs and liability plus contract cancellation. If the corps cannot scale to meet demand (e.g., three concurrent contracts requiring 15+ handlers), the company would be forced to decline contracts or deliver substandard ceremonial experiences, undermining the entire premium pricing model. Training a single handler to proficiency takes 4–6 months; without this role, the first-contract staffing deadline would be missed.

**People Count**:
1

**Typical Activities**:
Recruiting, training, and managing the corps of 10–12+ ceremonial black-uniformed handlers; establishing and running the handler academy on the Nile island headquarters with a four-month residential program; designing the ceremonial experience that converts psychological awe into contract signatures at premium price points; maintaining a handler-to-crocodile ratio of at least 1:3 during all client events; cross-training each handler in reptile behavior, client-service etiquette, and emergency protocol; implementing mandatory certification renewal every six months with practical escape-response testing; developing a comprehensive handler safety program including protective equipment and emergency evacuation protocols; and budgeting $150,000–$300,000 annually for handler training, equipment, and compensation.

**Background Story**:
Colonel Karim El-Masri, a 50-year-old Egyptian former special-operations officer turned ceremonial event director, graduated from the Egyptian Military Academy and served fifteen years in the Presidential Guard before leaving to manage high-security state events for Gulf royal families, where he perfected the art of blending military precision with hospitality theater. He established and ran the ceremonial protocol program for three Abu Dhabi royal palaces, training over 200 handlers in black-uniformed ceremonial service before founding Crocodile Security's handler academy on the Nile island headquarters. Each handler he certifies undergoes his four-month residential program combining Egyptian crocodile-farm apprenticeship with ceremonial hospitality protocol training, producing graduates who can simultaneously manage a client's champagne service and execute an emergency crocodile containment drill. He is relevant because the handler corps is both the living embodiment of the company's theatrical brand and the human-in-the-loop safety layer of the hybrid escape-prevention philosophy, and no one else can recruit, train, and manage a corps that satisfies both the ceremonial polish justifying premium pricing and the 1:3 handler-to-crocodile safety ratio required by auditors.

**Equipment Needs**:
Ceremonial black-uniform tailoring and production equipment for the handler corps, reptile behavior training aids and simulation equipment for handler certification programs, emergency response equipment (protective gear, containment barriers, emergency evacuation tools), two-way communication systems for handler-to-handler and handler-to-veterinary coordination during client events, client-service hospitality training materials and props, and performance logging systems for tracking handler certification status, drill results, and incident reports.

**Facility Needs**:
Handler academy facilities on the Nile island headquarters including a four-month residential training center with classroom, practical handling pool, and ceremonial rehearsal spaces, dedicated training pools for crocodile behavior apprenticeship, ceremonial event spaces at the fortress boardroom for client-facing rehearsals, storage facilities for uniforms, protective equipment, and emergency response gear, and a handler certification testing range with controlled crocodile access for practical escape-response evaluations.

## 5. Chief Financial Officer & Capital Deployment Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Financial Officer & Capital Deployment Manager governs the allocation of the $10M seed capital across three gated tranches of $2M, $3M, and $5M, where a single delayed permit or contract signature can freeze the entire operating budget. This role manages the monthly burn-rate dashboard with hard triggers at 70% and 90%, negotiates the $1M emergency reserve facility, handles multi-currency risk across USD/EGP/ILS/AED, and structures the first contract as a bundled turnkey-plus-maintenance package to achieve the 30-month positive cash flow target. The financial fragility of the gated tranche structure demands full-time, continuous oversight.

**Explanation**:
Governs the allocation of the $10M seed capital across the three gated tranches of $2M, $3M, and $5M, ensuring each tranche is deployed against externally verifiable milestones that protect the Gulf family-office investor while keeping operations funded. Manages the monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche, negotiates the $1M emergency reserve facility with the Gulf investor, and handles multi-currency risk across USD, EGP, ILS, and AED including hedging ILS exposure on the Ketziot contract. Ensures the first contract is structured as a bundled turnkey-plus-maintenance package (~$8.08M total value) to achieve the 30-month positive cash flow target, and manages the $500K crisis management reserve and insurance procurement from Lloyd's of London.

**Consequences**:
The $10M seed capital in gated tranches creates a dangerous dependency where a single delayed permit or contract signature freezes the entire operating budget. Without expert capital management, the first tranche could be consumed by headquarters construction and permits without a signed contract, leaving no reserve for the unexpected costs inherent in working with live animals in arid environments. EGP depreciation of 15–25% could inflate local construction costs by $300,000–$500,000 on the fortress build alone. Negative unit economics on the first contract without bundled maintenance would make the 30-month positive cash flow target mathematically impossible, and the company could face a $2M–$4M cash shortfall before the second tranche unlocks.

**People Count**:
1

**Typical Activities**:
Governing the allocation of the $10M seed capital across three gated tranches of $2M, $3M, and $5M against externally verifiable milestones; managing the monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche reviewed weekly; negotiating the $1M emergency reserve facility with the Gulf family-office investor; handling multi-currency risk across USD, EGP, ILS, and AED including hedging ILS exposure on the Ketziot contract using forward contracts or currency options; structuring the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package (~$8.08M total value) with 50% upfront payment; managing the $500K crisis management reserve; procuring comprehensive liability insurance ($25M–$50M aggregate) from Lloyd's of London at ~3–5% of annual contract revenue; and engaging a foreign exchange specialist as a part-time advisor from month one.

**Background Story**:
Hana Al-Farsi, a 39-year-old Emirati financial strategist born in Abu Dhabi and educated at the London School of Economics, where she earned a master's degree in finance and accounting, spent twelve years at a Gulf family office managing a $2 billion portfolio across real estate, defense contracting, and emerging-market ventures before becoming the chief financial officer of a renewable-energy startup that achieved positive operating cash flow within eighteen months of its founding. She negotiated the original seed capital commitment from her family office to Crocodile Security and understands the gated tranche structure better than anyone except the founder, having designed the milestone-gating mechanism herself. She is relevant because the $10 million seed capital deployed in gated tranches of $2 million, $3 million, and $5 million creates a structural dependency where a single delayed permit or contract signature can freeze the entire operating budget, and her ability to manage the monthly burn-rate dashboard with hard triggers at 70% and 90%, negotiate the $1 million emergency reserve facility, and structure the first contract as a bundled turnkey-plus-maintenance package to achieve the 30-month positive cash flow target makes her the financial architect of the venture's survival.

**Equipment Needs**:
Financial modeling and budgeting software for managing the $10M gated tranche deployment, multi-currency accounting and treasury management systems (USD, EGP, ILS, AED), monthly burn-rate dashboard tools with hard trigger alerts at 70% and 90% of each tranche, currency hedging platforms for ILS exposure management on the Ketziot contract, insurance procurement and underwriting management systems for Lloyd's of London liability coverage, contract management software for tracking the bundled turnkey-plus-maintenance agreement structures, and secure investor reporting dashboards for the Gulf family-office investor.

**Facility Needs**:
Private office at the fortress headquarters for capital deployment decision-making, access to banking and foreign exchange institutions for multi-currency account management and hedging execution, secure data room for investor communications and tranche release documentation, conference facilities for quarterly board meetings on capital deployment thresholds, and a dedicated financial operations center for monitoring the monthly burn-rate dashboard with real-time alerts and weekly review capabilities.

## 6. Client Acquisition & Market Entry Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Client Acquisition & Market Entry Director drives the commercial engine through a dual-track pipeline pursuing both the Ketziot-style government contract and private billionaire compound prospects to hedge against political delays. This role owns pricing strategy relative to the $41,000/meter Ketziot benchmark, conducts the first site survey, builds relationships with government decision-makers across at least three countries, and targets letters of intent by month 12. The 18-month first-contract deadline and the need for disciplined negotiation under the 20%-discount strategy require dedicated, full-time commercial leadership.

**Explanation**:
Drives the commercial engine of the company by pursuing the dual-track client pipeline: the Ketziot-style government contract as the primary target alongside at least two private billionaire compound prospects to hedge against political delays. Owns pricing strategy relative to the $41,000/meter Ketziot benchmark, negotiates the 20%-discount bid structure, and structures the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package. Conducts the first site survey at Ketziot Prison or an equivalent Gulf royal compound, builds relationships with multiple government decision-makers across at least three countries, and targets at least two letters of intent by month 12. Also manages the 'sovereign capability' argument that positions Crocodile Security as the only vendor capable of delivering turnkey moats.

**Consequences**:
Without dedicated client acquisition leadership, the company would fail to secure its first contract within the 18-month deadline, missing the reference case that all subsequent sales cycles reference. The dual-track government/private hedging strategy would collapse into a single-point-of-failure bet on one client type. Without a structured pipeline and letters of intent by month 12, the company would burn through its first tranche without revenue, triggering a dangerous funding gap before the second tranche release. The 20%-discount pricing strategy would lack disciplined negotiation, potentially eroding margins below viability or losing the reference deal entirely.

**People Count**:
1

**Typical Activities**:
Pursuing the Ketziot-style government contract as the primary target while simultaneously developing at least two private billionaire compound prospects; owning pricing strategy relative to the $41,000/meter Ketziot benchmark and negotiating the 20%-discount bid structure; structuring the first contract as a mandatory 5-year bundled turnkey-plus-maintenance package; conducting the first site survey at Ketziot Prison, Israel, or an equivalent Gulf royal compound including geological survey, hydrological study, and existing security-system integration audit; building relationships with multiple government decision-makers across at least three countries; developing the 'sovereign capability' argument positioning Crocodile Security as the only vendor capable of delivering turnkey moats; targeting at least two letters of intent by month 12; and establishing a detailed cost-comparison analysis demonstrating that hiring Crocodile Security at 20% below the Ketziot benchmark is cheaper than a ministry building its own program.

**Background Story**:
David Mwangi, a 45-year-old Kenyan-British sales strategist born in Nairobi and educated at INSEAD, where he earned an MBA with distinction, spent fifteen years selling high-value security infrastructure to governments across the Middle East and Africa, including a seven-year tenure as the head of Middle East sales for a Fortune 500 defense contractor where he closed contracts worth over $500 million. He built the dual-track client pipeline methodology that Crocodile Security now uses — pursuing government contracts and private billionaire compound deals simultaneously — a technique he first developed when selling satellite surveillance systems to both the Kenyan government and a Saudi royal family in the same fiscal quarter. He is relevant because the first contract establishes the reference case that all subsequent sales cycles reference, and his ability to build relationships with government decision-makers across at least three countries, conduct the first site survey at Ketziot Prison or an equivalent Gulf royal compound, and target at least two letters of intent by month 12 makes him the commercial engine that converts the company's theatrical brand into signed contracts.

**Equipment Needs**:
CRM and client relationship management software for tracking the dual-track government and private billionaire pipeline, market research databases for competitive intelligence on interior ministry reptile programs, pricing analysis tools for structuring the 20%-discount bid relative to the $41,000/meter Ketziot benchmark, geological and hydrological survey equipment for first-site surveys at Ketziot Prison or Gulf royal compounds, security-system integration audit tools for assessing existing client perimeter infrastructure, and presentation technology for demonstrating the moat concept to high-value clients.

**Facility Needs**:
Client meeting rooms at the Ottoman-fortress headquarters equipped with the reinforced-glass boardroom demonstration capability for closing high-value contracts, travel infrastructure for site surveys at Ketziot Prison (Israel) and Gulf royal compounds, a dedicated business development office at the UAE regional facility for Gulf client relations, conference and presentation spaces for hosting government delegations and private client visits, and access to cost-comparison analysis resources for demonstrating the economic advantage over ministry self-build programs.

## 7. Operations & Infrastructure Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Operations & Infrastructure Director oversees all physical infrastructure across four locations: the Ottoman-fortress headquarters, the Lake Nasser breeding facility, the UAE regional office, and the Ketziot demonstration site. This role manages construction of the fortress headquarters and demonstration pool, installs closed-loop water recycling systems achieving 90%+ reuse, deploys the IoT-based monitoring platform, and coordinates specialized live-animal transport logistics. The fortress is simultaneously the company's largest pre-revenue fixed-cost liability and most important sales tool, while water system failures could kill animals within 24–48 hours — both scenarios demanding full-time, on-the-ground operational management.

**Explanation**:
Oversees all physical infrastructure across the company's four locations: the Ottoman-fortress headquarters on the Nile island (including the reinforced-glass boardroom and demonstration pool), the dedicated crocodile breeding facility near Lake Nasser, the UAE regional office, and the Ketziot demonstration site. Manages the construction of the fortress headquarters and demonstration pool, installs closed-loop water recycling systems achieving 90%+ reuse, deploys the IoT-based water quality and containment integrity monitoring platform with automated dosing and client-facing dashboards, and coordinates all site logistics including specialized live-animal transport with GPS-tracked containers. Also manages the handler academy facilities and the $200K–$400K IoT monitoring platform development.

**Consequences**:
Without dedicated infrastructure management, the fortress headquarters — simultaneously the company's largest pre-revenue fixed-cost liability and most important sales tool — could be delayed or underfunded, undermining the theatrical credibility that distinguishes the company from conventional security vendors. The demonstration pool would not be stocked and operational for client visits by month 6–9, eliminating the primary closing tactic for high-value contracts. Water recycling systems failing in arid climates could kill animals within 24–48 hours, creating both financial loss and welfare violations. The IoT monitoring platform — existential to containment integrity — would lack dedicated oversight, and a system failure during a containment breach could convert a manageable incident into a catastrophic one.

**People Count**:
min 1, max 3, depending on project scale and workload

**Typical Activities**:
Overseeing all physical infrastructure across four locations: the Ottoman-fortress headquarters on the Nile island, the dedicated crocodile breeding facility near Lake Nasser, the UAE regional office, and the Ketziot demonstration site; managing construction of the fortress headquarters and reinforced-glass boardroom floor above the demonstration pool; installing closed-loop water recycling systems achieving 90%+ reuse efficiency; deploying the IoT-based water quality and containment integrity monitoring platform with automated dosing and client-facing dashboards; coordinating specialized live-animal transport with GPS-tracked containers; managing the handler academy facilities; overseeing the $200K–$400K IoT monitoring platform development; commissioning independent hydrological studies of each proposed moat site before contract signing; and budgeting $200,000–$500,000 per installation for water management infrastructure.

**Background Story**:
Eng. Safa Al-Rashidi, a 44-year-old Emirati infrastructure project manager born in Dubai and educated at the University of Waterloo, where she earned a master's degree in civil and environmental engineering, spent twelve years managing large-scale construction projects for the Dubai Municipality including the development of the Dubai Marina waterfront and the Al Warsan water treatment plant, before transitioning to specialized aquatic facility construction for the UAE's growing zoo and aquarium sector. She personally oversaw the installation of the closed-loop water recycling systems at the Dubai Aquarium & Underwater Zoo, achieving 92% water reuse efficiency — a benchmark she now targets for every Crocodile Security moat. She is relevant because the Ottoman-fortress headquarters is simultaneously the company's largest pre-revenue fixed-cost liability and its most important sales tool, and the demonstration pool must be stocked and operational for client visits by month 6–9 to serve as the primary closing tactic for high-value contracts; without dedicated infrastructure management, the fortress renovation could be delayed, the water recycling systems could fail in arid climates killing animals within 24–48 hours, and the IoT monitoring platform — existential to containment integrity — would lack dedicated oversight.

**Equipment Needs**:
Construction and renovation equipment for the Ottoman-fortress headquarters conversion (reinforced glass installation, excavation machinery), closed-loop water recycling system components (UV sterilization units, biological filtration tanks, mechanical filtration systems, geothermal cooling loop equipment), IoT monitoring platform hardware (water quality sensors, containment integrity sensors, edge-computing nodes), specialized live-animal transport containers with GPS tracking and climate control, hydrological survey equipment for site assessments, and N+1 redundant water treatment system components for each moat installation.

**Facility Needs**:
Construction management office at the fortress headquarters overseeing the reinforced-glass boardroom and demonstration pool buildout, a dedicated water systems workshop for assembling and testing closed-loop recycling units, the Lake Nasser breeding facility infrastructure including climate-resilient aquaculture equipment and temperature-controlled holding ponds, the UAE regional office facilities for Gulf client demonstrations, the Ketziot demonstration site for contract execution infrastructure, and a centralized IoT platform development lab for building and testing the 24/7 monitoring dashboard with client-facing public access.

## 8. Head of Strategic Intelligence & Narrative Architecture

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Head of Strategic Intelligence & Narrative Architecture owns the company's strategic narrative, competitive defense, and long-term positioning. This role constructs the founder's conviction that perimeter security lost its way with the moat into the company's primary sales argument, develops competitive imitation defense strategies, governs geographic expansion logic for the seven-continent goal, manages the controversial client boundary policy, and directs product portfolio positioning. Without strategic narrative leadership, the company's founding story — the primary sales argument justifying premium pricing — would lack coherence. This C-suite strategic role requires full-time dedication to align all other functions behind a unified vision.

**Explanation**:
Owns the company's strategic narrative, competitive defense, and long-term positioning. Constructs the founder's conviction that perimeter security lost its way when the world abandoned the moat into the company's primary sales argument, deciding whether to position as ancient lineage revival, technology-forward innovation, or founder-as-myth embodied by the fortress. Develops competitive imitation defense strategies — multi-year maintenance lock-in, open-source standards publishing, or exclusive upstream sourcing agreements with Lake Nasser farms. Governs geographic expansion logic for the seven-continent goal, manages the controversial client boundary policy and its reputational risks, oversees the crisis management reserve and PR firm, and directs product portfolio positioning (crocodile vs. piranha vs. saltwater variants) and the regulatory consulting arm's timing.

**Consequences**:
Without strategic narrative leadership, the company's founding story — the primary sales argument justifying premium pricing above conventional fencing — would lack coherence and fail to differentiate Crocodile Security from competitors or a novelty operation. Competitive imitation defense would be absent, meaning interior ministries could replicate crocodile moat programs in-house without facing lock-in, shrinking the addressable market. The 'no client too controversial' policy would lack a governance framework, guaranteeing that when a client becomes a diplomatic or media liability, the reputational damage lands on the crocodile moat and the welfare audit that was supposed to shield it. Geographic expansion would lack discipline, fragmenting the veterinary and maintenance networks. The crisis management reserve and PR firm would be uncoordinated, leaving the company vulnerable to a single well-funded animal rights campaign that could deter government clients.

**People Count**:
1

**Typical Activities**:
Constructing the founder's conviction that perimeter security lost its way when the world abandoned the moat into the company's primary sales argument; deciding whether to position the company as ancient lineage revival, technology-forward innovation, or founder-as-myth embodied by the fortress; developing competitive imitation defense strategies including multi-year maintenance lock-in, open-source standards publishing, or exclusive upstream sourcing agreements with Lake Nasser farms; governing geographic expansion logic for the seven-continent stocked-moat goal; managing the controversial client boundary policy and its reputational risks; overseeing the crisis management reserve and retained PR firm; directing product portfolio positioning (crocodile vs. piranha vs. saltwater variants) and the regulatory consulting arm's timing; publishing a white paper on the historical lineage of crocodile moats from Ottoman fortifications through Pharaonic defenses; and establishing a formal client-review board including an independent ethics advisor.

**Background Story**:
Professor Idris Nassar, a 62-year-old Egyptian-born strategic thinker and former Oxford University professor of comparative mythology and security studies, whose seminal work 'The Moat Paradox: Why Perimeter Security Lost Its Soul When It Lost Its Water' became required reading at three defense academies and was cited by the Israeli National Security Ministry in its Ketziot Prison moat feasibility study. He spent thirty years advising Gulf royal families on brand positioning and ceremonial diplomacy, authoring the strategic narrative frameworks that transformed three obscure desert principalities into globally recognized luxury destinations. He is the person who first articulated the thesis that perimeter security lost its way when the world abandoned the moat — a conviction that now defines Crocodile Security's entire founding story and primary sales argument. He is relevant because the company's founding narrative is the primary sales argument justifying premium pricing above conventional fencing, and no one else can construct the mythological framework that differentiates Crocodile Security from competitors or a novelty operation while governing the controversial client boundary policy, competitive imitation defense strategies, and geographic expansion logic for the seven-continent goal.

**Equipment Needs**:
Research databases and academic publishing tools for developing the white paper on the historical lineage of crocodile moats, competitive intelligence software for monitoring interior ministry reptile program developments, brand management and narrative positioning tools, crisis management communication systems for coordinating with the retained PR firm, social media and media monitoring platforms for tracking reputational risks, and document design software for producing client-facing materials that communicate the mythological brand identity.

**Facility Needs**:
Strategic research office at the fortress headquarters with access to historical archives on Ottoman fortification moats and Pharaonic defenses, conference and meeting spaces for developing competitive imitation defense strategies and geographic expansion logic, media relations facilities for managing the independently audited welfare program's public narrative, a dedicated crisis management coordination center linked to the $500,000 crisis management reserve and retained PR firm, and boardroom access for presenting strategic intelligence findings to the three-member board on controversial client boundary decisions and product portfolio positioning.

---

# Omissions

## 1. No Dedicated Safety Director

The plan explicitly references a 'dedicated safety director reporting directly to the board' in multiple mitigation plans, compliance actions, and risk assessments (Risk 5, Question 5, Compliance Actions), yet this role is absent from the team composition. Safety management — encompassing containment integrity oversight, emergency response coordination, handler safety protocols, and quarterly penetration testing — is too critical and too distinct from engineering to be absorbed by the Chief Moat Engineer alone. A single safety failure terminates the business irreversibly.

**Recommendation**:
Add a Safety Director role reporting directly to the board, responsible for overseeing all safety protocols, conducting monthly escape drills, coordinating quarterly third-party penetration testing, maintaining the 15-minute response-time standard, and serving as the board's primary safety escalation point. This role should be distinct from the Chief Moat Engineer, who focuses on design and engineering, while the Safety Director focuses on operational safety governance and incident prevention.

## 2. No General Counsel or Legal Counsel

The CITES & Regulatory Affairs Director handles regulatory permitting and wildlife classification amendments, but the company faces a vast array of legal challenges beyond regulatory compliance: contract law for multi-year turnkey-plus-maintenance agreements, liability frameworks for the 'no client too controversial' policy, employment law for an 18-25 person international team, intellectual property protection for moat engineering designs, and the legal implications of serving controversial clients. The plan also requires clients to sign liability waivers and mandates specialized excess-liability insurance — all requiring dedicated legal counsel.

**Recommendation**:
Add a General Counsel or Legal Counsel role (contract-type: full_time_employee) responsible for drafting and reviewing all client contracts, liability waivers, and multi-year maintenance agreements; managing employment law across Egypt, Israel, UAE, and future jurisdictions; advising on the legal boundaries of the controversial client policy; protecting intellectual property for moat engineering designs; and coordinating with the international wildlife law firms retained for CITES matters.

## 3. No Dedicated Marketing and Communications Lead

The Head of Strategic Intelligence owns narrative architecture and mythos, but narrative construction is not the same as marketing execution. The company's theatrical brand — the reinforced-glass boardroom, the ceremonial handlers, the crocodile moat concept — requires active marketing management: media relations, digital presence, content creation, client communications, and the public-facing monitoring dashboard. The plan also references a retained PR firm for crisis management, but there is no internal marketing capability to coordinate with external PR or to proactively build the brand between crises.

**Recommendation**:
Add a Marketing & Communications Lead (contract-type: full_time_employee) responsible for executing the brand strategy defined by the Head of Strategic Intelligence, managing media relations, maintaining the company website and public-facing monitoring dashboard, creating client-facing materials, coordinating with the retained PR firm, and managing digital channels. This role should report to the Head of Strategic Intelligence for brand alignment but have dedicated execution authority.

## 4. No Dedicated IT / Technology Lead

The IoT-based water quality and containment integrity monitoring platform is described as existential to operations — a system failure during a containment breach could convert a manageable incident into a catastrophic one. The platform requires $200,000–$400,000 in Year 1 development, $50,000–$100,000/year maintenance, edge-computing nodes at each installation, blockchain-based audit trails for welfare data, and cybersecurity protocols to prevent malicious actors from disabling containment monitoring. The Operations & Infrastructure Director oversees deployment but lacks the specialized software engineering and cybersecurity expertise required.

**Recommendation**:
Add an IT / Technology Lead (contract-type: full_time_employee or specialist_consultant initially) responsible for overseeing the IoT platform architecture, managing the $200K–$400K development budget, ensuring cybersecurity protocols, managing edge-computing node deployment across installations, maintaining blockchain-based audit trails, and conducting quarterly penetration testing of the technology infrastructure. This role should report to the Operations & Infrastructure Director for deployment coordination but have technical independence.

## 5. No Dedicated Security Manager

The plan identifies significant security risks: theft or illegal trade of Nile crocodiles (CITES Appendix I species), sabotage of moat containment systems by malicious actors, physical breach of the fortress headquarters housing valuable breeding stock, and the company's high-profile nature making it a target for both physical and cyber threats. The plan recommends '24/7 armed security,' biometric access controls, GPS tracking, and coordination with INTERPOL, but there is no dedicated security manager to oversee these measures. The Operations & Infrastructure Director manages physical infrastructure but not security operations.

**Recommendation**:
Add a Security Manager role (contract-type: full_time_employee) responsible for implementing and overseeing 24/7 armed security at all facilities, managing biometric access controls and CCTV with AI-based anomaly detection, coordinating GPS tracking of all crocodiles, maintaining the rapid-response protocol for animal loss events including INTERPOL coordination, conducting quarterly security audits, and managing the $500,000–$1M annual security infrastructure budget.

## 6. No Dedicated Human Resources / Talent Acquisition Lead

The plan specifies a minimum viable team of 18–25 people including specialized veterinarians, ceremonial handlers, moat engineers, and administrative staff. Training a single handler takes 4–6 months; recruiting 20+ handlers requires a 20-applicant inaugural cohort. The Director of Ceremonial Operations manages handler training but there is no HR function for broader recruitment, onboarding, compensation, benefits, and retention across the full team. The plan also notes that specialized reptile veterinarians are scarce and require competitive compensation of $120K–$180K/year, making talent acquisition a critical strategic function.

**Recommendation**:
Add a Human Resources / Talent Acquisition Lead (contract-type: full_time_employee) responsible for recruiting the full 18–25 person team, managing the handler academy applicant pipeline (20 applicants for 12-person cohort), coordinating competitive compensation packages for specialized veterinarians, onboarding and compliance across multiple jurisdictions, and developing retention strategies for the narrow talent pipeline. This role should work closely with the Director of Ceremonial Operations on handler recruitment and the Head Veterinarian on veterinary hiring.

## 7. No Dedicated Procurement / Supply Chain Manager

The animal sourcing strategy involves negotiating exclusive supply agreements with at least three Lake Nasser farms, maintaining a 6-month strategic reserve of 20+ juvenile crocodiles, managing climate-resilient aquaculture, pre-negotiating transport contracts with specialized live-animal logistics firms, and developing backup suppliers in Zimbabwe and South Africa. The Chief Financial Officer manages capital deployment but not the operational complexity of the biological supply chain. The Head Veterinarian oversees stock quality but not procurement logistics.

**Recommendation**:
Add a Procurement / Supply Chain Manager (contract-type: full_time_employee) responsible for negotiating and managing exclusive supply agreements with Lake Nasser farms, coordinating the 6-month strategic reserve of juvenile crocodiles, managing specialized live-animal transport logistics with GPS-tracked containers, developing and maintaining backup supplier relationships in Zimbabwe and South Africa, and tracking transport mortality budgets (5–15%) against per-moat animal costs.

## 8. No Dedicated Quality Assurance / Audit Manager

The independently audited animal welfare program is the company's moral shield and commercial differentiator, requiring continuous internal quality assurance beyond what the Head Veterinarian can manage alone. The plan requires quarterly third-party penetration testing of containment systems, mandatory quarterly audits of all cross-border crocodile movements, blockchain-based audit trails for welfare data, and independent environmental impact assessments for each installation. Without a dedicated QA/Audit function, the company risks failing its own audit standards and losing the PR shield.

**Recommendation**:
Add a Quality Assurance / Audit Manager (contract-type: full_time_employee) responsible for preparing the company for all independent welfare audits, maintaining internal compliance checklists aligned with audit thresholds, coordinating quarterly third-party penetration testing of containment systems, managing the blockchain-based audit trail system, preparing environmental impact assessments, and conducting internal audits of all cross-border crocodile movements in coordination with the CITES Compliance Officer.

## 9. No Dedicated Environmental / EIA Specialist

Each moat installation requires a 6-month environmental impact assessment costing $50,000–$150,000, conducted by local environmental consultancies, plus 5-year post-installation environmental monitoring. The plan also requires independent hydrological studies of each proposed moat site before contract signing and a publicly available environmental impact report for each installation as part of the audited welfare program. The Head Veterinarian 'commissions' EIAs but does not manage them, and the Operations Director lacks environmental science expertise.

**Recommendation**:
Add an Environmental / EIA Specialist (contract-type: full_time_employee or senior_consultant) responsible for commissioning and managing all environmental impact assessments, coordinating with local environmental consultancies in each jurisdiction, overseeing 5-year post-installation environmental monitoring, conducting independent hydrological studies before contract signing, and preparing publicly available environmental impact reports. This role should report to the Head Veterinarian for welfare alignment and to the Operations Director for site coordination.

## 10. No Dedicated Data / Analytics Lead

The IoT monitoring platform generates massive volumes of data: water quality metrics (pH, ammonia, dissolved oxygen, temperature), containment integrity sensor data, animal health tracking (GPS, weight, behavior), handler performance logging, and client-facing dashboard metrics. The plan requires this data to be analyzed for trend detection, predictive maintenance, welfare compliance, and client reporting. Without dedicated data analytics capability, the platform becomes a data collection tool rather than a decision-support system, and the company misses opportunities to predict containment failures or welfare issues before they become incidents.

**Recommendation**:
Add a Data / Analytics Lead (contract-type: full_time_employee) responsible for building and maintaining the data analytics infrastructure for the IoT platform, developing predictive models for containment integrity and animal health, creating automated alerting systems for anomalous patterns, generating reports for the board, auditors, and clients, and ensuring data integrity across the blockchain-based audit trails. This role should work closely with the IT/Technology Lead and the Head Veterinarian.

---

# Potential Improvements

## 1. Head of Strategic Intelligence Scope Is Overly Broad

The Head of Strategic Intelligence & Narrative Architecture is responsible for: narrative architecture, competitive imitation defense, geographic expansion logic, controversial client boundary policy, crisis management reserve oversight, product portfolio positioning, regulatory consulting timing, white paper publication, and client-review board establishment. This is at least five distinct C-suite-level responsibilities concentrated in one person, creating a bottleneck and diluting focus on the most critical strategic priorities. The role overlaps with the Client Acquisition Director (market entry), Head Veterinarian (welfare program), CFO (crisis reserve), and Operations Director (geographic expansion).

**Recommendation**:
Narrow the Head of Strategic Intelligence role to focus on narrative architecture, competitive imitation defense, and geographic expansion logic. Transfer crisis management coordination to the Marketing & Communications Lead (new role). Transfer product portfolio positioning decisions to a dedicated Product Manager or to the Client Acquisition Director. Transfer client-review board establishment to the General Counsel. Consider splitting the role into two positions — Chief Strategy Officer and Chief Narrative Officer — once the company reaches three contracts and the scope becomes unmanageable for one person.

## 2. Operations & Infrastructure Director Scope Is Overly Broad

The Operations & Infrastructure Director oversees four locations, fortress construction, demonstration pool buildout, closed-loop water recycling systems, IoT platform deployment, handler academy facilities, and a $200K–$400K technology development budget. This combines construction management, infrastructure engineering, technology deployment, and facility management — four distinct disciplines. The plan also notes this role has 'min 1, max 3' people count, suggesting the scope is recognized as too broad but not yet addressed.

**Recommendation**:
Split the Operations & Infrastructure Director role into two positions: (1) a Construction & Facilities Director responsible for fortress headquarters conversion, demonstration pool buildout, and handler academy facilities across all four locations; and (2) a Technology & Systems Director responsible for IoT platform deployment, water recycling systems, and containment integrity monitoring. The Construction & Facilities Director reports to the COO or CEO, while the Technology & Systems Director reports to the IT/Technology Lead (new role) for technical alignment.

## 3. No Centralized Risk Management Function

The plan identifies 12 major risks across regulatory, technical, financial, supply chain, environmental, reputational, operational, market, security, currency, integration, and sustainability categories. Each risk has its own mitigation plan assigned to different team members, but there is no centralized risk management function to coordinate, prioritize, and escalate risks across the organization. The CFO manages financial risk, the Moat Engineer manages technical risk, the CITES Director manages regulatory risk, but risks are interconnected — regulatory delays trigger capital depletion, which forces cost-cutting on engineering, which increases escape risk. Without a centralized risk function, these cascading failures go undetected.

**Recommendation**:
Establish a centralized Risk Management function, either as a dedicated Risk Manager reporting to the board or as a standing risk committee chaired by the CFO with representatives from each department. The Risk Manager/Committee should maintain a consolidated risk register, conduct monthly risk reviews, identify cascading risk dependencies, and escalate critical risks to the board. The Risk Manager should also own the $1M emergency reserve facility negotiation and the Plan B protocol triggers at month 15.

## 4. No Clear Organizational Hierarchy or Reporting Structure

The plan lists eight team members with detailed descriptions but does not specify reporting relationships, decision-making authority levels, or the organizational hierarchy. The plan mentions a three-member board (founder, Gulf investor representative, independent director) and a governance charter to be established within 60 days, but the internal reporting structure between the eight named roles is undefined. This creates ambiguity about who reports to whom, who has decision-making authority on what, and how conflicts between roles are resolved.

**Recommendation**:
Define a clear organizational hierarchy as part of the governance charter established within the first 60 days. Recommend structure: Founder/CEO at the top, with the board overseeing governance. Below the CEO, establish two tiers: (1) C-suite roles (CITES Director, CFO, Head Veterinarian, Head of Strategic Intelligence) reporting directly to the CEO; (2) operational directors (Moat Engineer, Ceremonial Operations Director, Client Acquisition Director, Operations Director, new Safety Director, new IT Lead) reporting to the CEO or to designated C-suite leads. Define decision-making authority thresholds: capital expenditures above $100K require board approval, client contracts above $1M require CEO + board approval, hiring above level 5 require CEO approval.

## 5. Client Relationship Gap Between Acquisition and Retention

The Client Acquisition & Market Entry Director focuses on winning contracts and building the pipeline, but the plan's success criteria depend heavily on multi-year maintenance and animal-replacement contracts ($500K–$1M/year per moat) that require ongoing client relationship management. The plan also mentions 'client relations officers' in the minimum viable team but does not define their role or reporting structure. Without dedicated client relationship management, the company risks losing recurring revenue from existing clients and missing word-of-mouth referral opportunities among ultra-high-net-worth individuals and government officials.

**Recommendation**:
Add a Client Relations / Account Manager role (contract-type: full_time_employee, reporting to the Client Acquisition Director initially) responsible for managing ongoing relationships with signed clients, coordinating multi-year maintenance delivery, identifying upsell opportunities (additional moats, piranha variants, regulatory consulting), managing client communications and site visits, and serving as the primary point of contact for all post-contract client interactions. This role should also coordinate with the Director of Ceremonial Operations for client event planning and with the Head Veterinarian for animal welfare reporting to clients.

## 6. Handler Corps Needs Deputy or Assistant Support

The Director of Ceremonial Operations & Handler Corps Master is responsible for recruiting, training, and managing 10–12+ ceremonial handlers, running the handler academy, designing ceremonial experiences, and maintaining the 1:3 handler-to-crocodile ratio during all client events. With three concurrent contracts requiring 15+ handlers, this role becomes a bottleneck. The plan notes that training a single handler takes 4–6 months and building a corps of 20+ requires 12–18 months, making the handler pipeline the most constrained resource in the organization. Without deputy support, the Director becomes a training bottleneck rather than a strategic leader.

**Recommendation**:
Add a Deputy Handler Corps Master or Senior Handler Trainer role (contract-type: full_time_employee) to support the Director of Ceremonial Operations. This deputy should be a senior certified handler responsible for day-to-day handler training, maintaining training schedules, conducting practical escape-response evaluations, managing handler certification renewal, and providing the human-in-the-loop safety layer during client events when the Director is unavailable. This role should be filled by month 8–10, coinciding with the first handler academy cohort graduation.

## 7. Unclear Distinction Between CITES Director and Regulatory Affairs Director

The plan references both a 'CITES & Regulatory Affairs Director' (in team-members.md) and a 'Regulatory Affairs Director' (in project-plan.md stakeholder analysis and assumptions). The team composition lists only one role (CITES & Regulatory Affairs Director), but the plan's organizational structure implies two separate functions. The CITES Director handles Appendix I exemption filing and cross-border movement audits, while the Regulatory Affairs Director handles wildlife classification amendments and multi-jurisdictional compliance. If these are the same person, the scope is enormous; if they are separate, the second role is missing from the team.

**Recommendation**:
Clarify in the governance charter whether the CITES & Regulatory Affairs Director is a single combined role or two separate positions. If combined, acknowledge the scope and ensure the role has adequate support (legal team, compliance officers). If separate, add the Regulatory Affairs Director as a distinct role (contract-type: full_time_employee) focused on wildlife classification amendments, environmental clearances, and multi-jurisdictional regulatory navigation, reporting to the CITES & Regulatory Affairs Director or directly to the CEO.

## 8. Team Size Mapping Is Incomplete

The plan specifies a minimum viable team of 18–25 people but only names 8 leadership positions. The remaining 10–17 positions are vaguely described as '10–12 ceremonial handlers, 2 moat engineers, 1 regulatory affairs specialist, 1 operations manager, 2 administrative/finance staff, 1–2 client relations officers' but lack clear role definitions, hiring timelines, or organizational placement. The plan also notes that the handler academy produces a 'fixed annual cohort' and that experienced farm-hand retraining provides 'interim staffing,' but the transition from interim to permanent staffing is unclear.

**Recommendation**:
Create a detailed organizational chart mapping all 18–25 positions with role definitions, hiring timelines, and reporting relationships. Prioritize hiring sequence: (1) Month 1: 3 veterinarians, 1 regulatory affairs specialist, 1 CFO, 1 Client Acquisition Director; (2) Month 2–3: CITES Director, Moat Engineer, Operations Director, Head of Strategic Intelligence; (3) Month 3–4: Director of Ceremonial Operations, Safety Director, IT Lead, HR Lead; (4) Month 4–6: First handler cohort (12), 2 moat engineers, 2 admin/finance staff, 1–2 client relations officers; (5) Month 6–9: Deputy Handler Corps Master, additional veterinarians, additional handlers as needed for second contract pipeline.