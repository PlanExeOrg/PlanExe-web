
## Documents to Create

### 1. Project Charter for Crocodile Security

**ID:** 1a3fb943-993f-4f25-af7e-222d3f45ab17

**Description:** A foundational document that formally authorizes the venture, defines the project scope (turnkey live-crocodile moat security company), outlines the $10M gated tranche funding structure, and establishes the primary objectives (first contract within 18 months, zero welfare violations, CITES compliance). It serves as the single source of truth for the founding team and the Gulf family-office investor, aligning all strategic levers under one approved framework.

**Responsible Role Type:** Founder / Project Sponsor

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Venture Capital Term Sheet Framework

**Steps:**

- Define project scope, objectives, and success criteria based on the 'Builder' scenario and SMART goals
- Document the $10M seed capital structure with $2M/$3M/$5M gated tranches and milestone triggers
- Identify key stakeholders (Founder, Gulf investor, Board of three, CITES Director, etc.) and their roles
- Outline high-level risks (CITES legal viability, escape-prevention, capital depletion) and mitigation approach
- Secure formal signature/approval from the Founder and Gulf family-office investor to authorize project initiation

**Approval Authorities:** Founder (majority voting control), Gulf family-office investor (minority equity with veto rights over capital deployments exceeding $1M), Board of three

### 2. CITES Appendix I Exemption Legal Pathway Strategy

**ID:** 72fc897f-f037-4a5c-95ac-963ab613213b

**Description:** A high-level strategic document that identifies and defines the specific legal mechanism (e.g., captive-breeding certification under CITES Article VIII or registered commercial breeding operations) for commercial trade of Nile crocodiles. It maps the filing strategy across target jurisdictions (Egypt, Israel, UAE), outlines the engagement plan for international wildlife law firms, and establishes the regulatory timeline. This is the absolute prerequisite document for all commercial activity.

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Primary Template:** CITES Permit Application Framework

**Secondary Template:** International Wildlife Law Firm Engagement Template

**Steps:**

- Engage a CITES specialist legal firm within 30 days to research and confirm the specific Appendix I exemption mechanism
- Map the regulatory landscape for each target jurisdiction (Egypt, Israel, UAE) including domestic 'tended wild animal' reclassification precedents
- Draft the filing strategy for simultaneous permit applications across multiple jurisdictions to create redundancy
- Define pre-negotiation approach with the Egyptian CITES Management Authority for breeding facility registration approval
- Establish the CITES Compliance Officer role and quarterly audit framework for cross-border crocodile movements
- Present the legal pathway strategy to the Board for approval before any commercial applications are filed

**Approval Authorities:** Board of three (including independent director with wildlife regulation expertise), CITES & Regulatory Affairs Director

### 3. Capital Deployment and Tranche-Gated Milestone Plan

**ID:** 0d57cfba-b786-43d5-9a34-80f9db3c216e

**Description:** A high-level financial strategy document that governs the allocation of the $10M seed capital across the three gated tranches ($2M, $3M, $5M). It defines the externally verifiable milestone gates for each tranche release, establishes the monthly burn-rate dashboard with hard triggers at 70% and 90%, and outlines the emergency reserve facility negotiation with the Gulf investor. This document operationalizes the Capital Deployment and Risk Management lever.

**Responsible Role Type:** Chief Financial Officer & Capital Deployment Manager

**Primary Template:** Venture Capital Tranche Milestone Framework

**Secondary Template:** Startup Burn-Rate Management Dashboard Template

**Steps:**

- Define specific, measurable milestone gates for each tranche release (e.g., CITES permit filing for Tranche 1, first contract signature for Tranche 2, positive cash flow for Tranche 3)
- Allocate the first $2M tranche evenly between headquarters readiness ($1M) and client acquisition/permitting ($1M) per the 'Builder' scenario
- Design the monthly burn-rate dashboard with hard triggers at 70% and 90% of each tranche, reviewed weekly
- Negotiate the $1M emergency reserve facility with the Gulf investor accessible upon milestone achievement
- Establish the internal hard gate at month 15: if no contract is signed, trigger Plan B pivot to regulatory consulting-only revenue
- Integrate multi-currency risk management (USD, EGP, ILS, AED) including hedging strategies and 20% EGP currency buffer
- Present the capital deployment plan to the Board and Gulf investor for approval before tranche release

**Approval Authorities:** Gulf family-office investor (veto rights over capital deployments exceeding $1M), Board of three, Founder

### 4. Escape-Prevention Engineering Philosophy and Containment Standards Framework

**ID:** f15e08a7-1a9e-4487-8373-d5feab97891c

**Description:** A high-level strategic document that defines the foundational containment strategy (hybrid philosophy: physical barriers plus trained handler corps intervention) upon which the entire business model rests. It specifies the triple-redundant physical barrier requirements (dual-circuit submerged electrified fencing, >45-degree overhanging acrylic walls, dual-gate airlock chambers), the 30% capital contingency for redundancy systems, and the integration with the Handler Corps for real-time behavioral intervention. This document establishes the engineering standards that satisfy the zero-injury success criterion and auditor requirements.

**Responsible Role Type:** Chief Moat Engineer & Escape-Prevention Lead

**Primary Template:** Engineering Standards Framework Template

**Secondary Template:** Risk Management Contingency Planning Template

**Steps:**

- Define the hybrid escape-prevention philosophy combining physical barriers with human-in-the-loop handler intervention
- Specify triple-redundant physical barrier requirements for all moat installations with detailed technical specifications
- Calculate the 30% capital contingency above baseline engineering costs for redundancy systems
- Define the handler-to-crocodile ratio (minimum 1:3) and real-time intervention protocols during client events
- Establish monthly escape drill and quarterly third-party penetration testing requirements
- Integrate IoT-based containment integrity monitoring specifications (circuit continuity sensors, stress sensors, water-level sensors)
- Present the engineering framework to the Board and Safety Director for approval before any moat construction begins

**Approval Authorities:** Board of three, Chief Moat Engineer & Escape-Prevention Lead, Safety Director (new role), Chief Financial Officer (for capital contingency approval)

### 5. Animal Sourcing and Breeding Program Strategy

**ID:** a3c05c66-3da7-457e-b28f-0588c7bb93e8

**Description:** A high-level strategic document that defines how Crocodile Security procures and manages its live Nile crocodile inventory. It outlines the hybrid sourcing model (exclusive long-term supply agreements with at least three Lake Nasser farms plus a small proprietary breeding facility as parallel capability), the 6-month strategic reserve of 20+ juvenile crocodiles, backup supplier development in Zimbabwe and South Africa, and CITES-compliant transport logistics. This document addresses the Animal Sourcing Strategy lever and determines unit economics and supply chain resilience.

**Responsible Role Type:** Head Veterinarian & Animal Welfare Director

**Primary Template:** Supply Chain Strategy Framework Template

**Secondary Template:** Biological Resource Management Plan Template

**Steps:**

- Identify and evaluate at least three Lake Nasser crocodile farms for exclusive long-term supply agreements
- Design the small proprietary breeding facility near Lake Nasser with climate-resilient aquaculture capabilities
- Establish the 6-month strategic reserve target of 20+ juvenile crocodiles at the Lake Nasser facility by month 6
- Pre-negotiate transport contracts with specialized live-animal logistics firms experienced in CITES-compliant reptile transport
- Develop backup supplier relationships in Zimbabwe and South Africa by month 9 to diversify against drought-driven stock losses
- Define transport mortality budget (5-15%) and GPS tracking requirements for all crocodiles
- Present the sourcing strategy to the Board and Chief Financial Officer for alignment with capital deployment plan

**Approval Authorities:** Board of three, Head Veterinarian & Animal Welfare Director, Chief Financial Officer (for budget alignment)

### 6. Market Entry Sequencing and Client Acquisition Strategy

**ID:** f3ed1ac0-19d0-4441-bebf-3423a7e4b736

**Description:** A high-level strategic document that determines the order and type of Crocodile Security's first commercial engagements. It defines the dual-track pipeline pursuing both the Ketziot-style government contract and private billionaire compound deals to hedge against political delays, outlines the 20% discount pricing strategy against the $41,000/meter Ketziot benchmark, and establishes the target of at least two letters of intent by month 12. This document operationalizes the Market Entry Sequencing lever and sets the commercial direction for the first 18 months.

**Responsible Role Type:** Client Acquisition & Market Entry Director

**Primary Template:** Go-to-Market Strategy Framework Template

**Secondary Template:** Sales Pipeline Management Template

**Steps:**

- Define the dual-track client pipeline: Ketziot-style government contract as primary target plus at least two private billionaire compound prospects
- Structure the 20% discount pricing strategy against the $41,000/meter Ketziot benchmark with tiered pricing model for premium private clients
- Develop the 'sovereign capability' argument positioning Crocodile Security as the only vendor capable of delivering turnkey moats
- Create a detailed cost-comparison analysis demonstrating that hiring Crocodile Security at 20% below benchmark is cheaper than ministry self-build programs
- Set targets for at least two letters of intent by month 12 and first contract signature by month 18
- Identify and prioritize government decision-makers across at least three countries for relationship building
- Present the market entry strategy to the Board and Founder for alignment with narrative architecture and brand positioning

**Approval Authorities:** Founder, Board of three, Client Acquisition & Market Entry Director

### 7. Animal Welfare Program Framework and Audit Standards

**ID:** 96d8ee63-f1c0-4e4f-8f62-b2c327171bb7

**Description:** A high-level strategic document that positions the independently audited animal welfare program as a core commercial differentiator rather than a compliance obligation. It defines welfare standards exceeding independent audit requirements by a meaningful margin, outlines the veterinary protocols, habitat quality standards, feeding logistics, and the real-time public-facing monitoring dashboard with blockchain-based audit trails. This document establishes the welfare program that serves as both a moral shield and PR shield, and determines the operating cost impact on the 20% pricing advantage.

**Responsible Role Type:** Head Veterinarian & Animal Welfare Director

**Primary Template:** Animal Welfare Audit Framework Template

**Secondary Template:** Corporate Social Responsibility Standards Template

**Steps:**

- Define welfare standards that exceed independent audit requirements by a meaningful margin, covering veterinary protocols, habitat quality, and feeding logistics
- Design the real-time public-facing monitoring dashboard showing water quality, temperature, and animal health metrics 24/7 with blockchain-based audit trails
- Establish the high-profile animal welfare advisor role (former head of recognized zoo or conservation body) as a board-level position
- Define the quarterly open-house event program at the Nile fortress headquarters inviting animal welfare organizations, media, and community leaders
- Create the transparent incident reporting protocol with mandatory public disclosure within 24 hours of any event
- Assess the cost impact of exceeding welfare standards on the 20% pricing advantage and per-moat margins
- Present the welfare framework to the Board and independent auditors for alignment on certification thresholds

**Approval Authorities:** Board of three (including high-profile animal welfare advisor), Head Veterinarian & Animal Welfare Director, Independent animal welfare auditors

### 8. Risk Register and Mitigation Framework

**ID:** 9fafd1f8-359c-4b23-9a8e-02618f7c8cd8

**Description:** A comprehensive high-level risk management document that identifies, assesses, and prioritizes the key risks facing Crocodile Security across regulatory, technical, financial, supply chain, environmental, reputational, operational, market, security, currency, integration, and sustainability categories. It establishes the centralized risk management function, defines the consolidated risk register, and outlines mitigation strategies for the three most critical risks (CITES legal viability, escape-prevention failure, capital depletion). This document serves as the foundational risk governance tool for the Board and founding team.

**Responsible Role Type:** Chief Financial Officer & Capital Deployment Manager (with Risk Manager role to be established)

**Primary Template:** Project Risk Register Template (PMI/PRINCE2)

**Secondary Template:** Enterprise Risk Management Framework Template

**Steps:**

- Identify and catalog all 12 major risk categories from the project plan and expert review
- Assess each risk for likelihood and severity, prioritizing the three critical risks (CITES, escape-prevention, capital depletion)
- Define specific mitigation strategies for each risk with assigned owners and timelines
- Establish the centralized risk management function (Risk Manager or standing risk committee chaired by CFO)
- Create the consolidated risk register with monthly review cadence and escalation protocols to the Board
- Define cascading risk dependencies (e.g., regulatory delays triggering capital depletion, which forces cost-cutting on engineering)
- Present the risk framework to the Board for approval and integration into the governance charter

**Approval Authorities:** Board of three, Chief Financial Officer, Risk Manager (to be hired), Founder

### 9. Stakeholder Engagement and Communication Plan

**ID:** 4be83b8b-d533-4473-bc11-6fdf497dd2ab

**Description:** A high-level strategic document that defines how Crocodile Security engages with all primary and secondary stakeholders including the Founder, Gulf investor, Board, CITES Director, veterinary team, handler corps, Lake Nasser farms, government clients, animal welfare organizations, local communities, and international law firms. It establishes communication cadences (weekly for founding team, monthly for Board), transparency mechanisms (public-facing monitoring dashboard), and crisis communication protocols. This document ensures aligned stakeholder management across all locations and functions.

**Responsible Role Type:** Head of Strategic Intelligence & Narrative Architecture (with Marketing & Communications Lead to be established)

**Primary Template:** Stakeholder Engagement Plan Template (PMI)

**Secondary Template:** Corporate Communications Strategy Template

**Steps:**

- Map all primary and secondary stakeholders with their interests, influence levels, and engagement requirements
- Define communication cadences: weekly updates for founding team, monthly reports for Board, quarterly open-house events for welfare organizations
- Establish the public-facing monitoring dashboard as the primary transparency mechanism for stakeholders
- Define crisis communication protocols including the $500K crisis management reserve and retained PR firm activation procedures
- Create stakeholder-specific engagement strategies for Lake Nasser farms, government clients, local communities, and animal welfare organizations
- Integrate the 'no client too controversial' policy communication strategy and client-review board establishment
- Present the stakeholder plan to the Board and Founder for alignment with narrative architecture and brand positioning

**Approval Authorities:** Founder, Board of three, Head of Strategic Intelligence & Narrative Architecture, Marketing & Communications Lead (new role)

### 10. High-Level Project Schedule and Milestone Timeline

**ID:** e1d90d2c-faa8-4ea2-a389-1df0dedf6548

**Description:** A high-level timeline document that maps the critical path from project initiation (September 2026) through first contract signature (March 2028), three contracts/pilots (September 2028), and positive cash flow (March 2029). It defines key milestones including CITES permit filing (month 3), demonstration pool stocking (month 6-9), first site survey (month 4-6), handler academy first cohort graduation (month 8-10), and the month 15 hard gate for Plan B activation. This document provides the temporal framework for all other planning documents.

**Responsible Role Type:** Operations & Infrastructure Director

**Primary Template:** Project Schedule Network Diagram Template

**Secondary Template:** Gantt Chart Template (Critical Path Method)

**Steps:**

- Map all critical path activities from project initiation through positive cash flow target (month 30)
- Define key milestone dates: CITES permit filing (month 3/December 2026), permit approval target (month 9-12/June-September 2027), first contract signature (month 18/March 2028)
- Schedule the first site survey (month 4-6), demonstration pool stocking (month 6-9), and handler academy first cohort graduation (month 8-10)
- Establish the month 15 hard gate (December 2027) for Plan B activation if no contract is signed
- Align milestone timing with the gated tranche release schedule ($2M month 1, $3M upon first contract, $5M upon positive cash flow)
- Identify dependencies between milestones (e.g., CITES permits required before animal sourcing, first contract required before second tranche release)
- Present the schedule to the Board and Gulf investor for alignment with tranche-gated milestone architecture

**Approval Authorities:** Board of three, Gulf family-office investor, Operations & Infrastructure Director, Chief Financial Officer

### 11. Monitoring and Evaluation (M&E) Framework

**ID:** 2d289669-00c0-4738-a457-c16a165c5fea

**Description:** A high-level framework that defines the success metrics, measurement methods, and evaluation cadence for Crocodile Security's strategic objectives. It establishes KPIs for the SMART goals (first contract within 18 months, three contracts by month 24, positive cash flow by month 30, zero welfare violations, zero human injuries, CITES permits secured in year one), defines data collection methods (IoT monitoring platform, blockchain audit trails, independent audits), and sets the evaluation schedule for Board reporting. This document ensures measurable accountability for all strategic levers.

**Responsible Role Type:** Head of Strategic Intelligence & Narrative Architecture (with Data/Analytics Lead to be established)

**Primary Template:** Logical Framework (LogFrame) Template

**Secondary Template:** Key Performance Indicator (KPI) Dashboard Template

**Steps:**

- Define specific, measurable KPIs for each SMART goal and strategic objective
- Establish data collection methods: IoT monitoring platform for real-time metrics, blockchain-based audit trails for welfare data, independent audits for compliance verification
- Define the evaluation cadence: monthly Board reports on capital deployment and burn rate, quarterly welfare audits, annual strategic reviews
- Create the client-facing public dashboard specifications for 24/7 transparency on water quality, animal health, and welfare metrics
- Define the success criteria for the three critical levers: CITES permit approval, first contract signature, and zero-injury record
- Establish the feedback loop for continuous improvement based on M&E findings
- Present the M&E framework to the Board and independent auditors for alignment on measurement standards

**Approval Authorities:** Board of three, Head of Strategic Intelligence & Narrative Architecture, Independent animal welfare auditors, Chief Financial Officer

### 12. Current State Assessment of CITES Regulatory Landscape

**ID:** 678bade1-2346-4309-8c94-b2ad07461223

**Description:** An initial baseline assessment report that evaluates the current regulatory environment for Nile crocodile commercial trade across target jurisdictions (Egypt, Israel, UAE). It analyzes the existing CITES Appendix I framework, identifies the specific exemption mechanisms available (captive-breeding certification under Article VIII, registered commercial breeding operations), assesses the Israeli 'tended wild animal' reclassification precedent from July 2026, and evaluates the feasibility of replicating this classification in other jurisdictions. This document provides the factual foundation for the CITES Legal Pathway Strategy.

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Primary Template:** Regulatory Environment Assessment Template

**Secondary Template:** Legal Feasibility Study Template

**Steps:**

- Research and document the current CITES Appendix I framework for Nile crocodiles (Crocodylus niloticus) including all exemption mechanisms
- Analyze Israel's July 2026 'tended wild animal' reclassification as a regulatory precedent for other jurisdictions
- Assess the Egyptian CITES Management Authority's current stance on captive-breeding certification for commercial security purposes
- Evaluate the UAE Wildlife Authority's import/export frameworks and wildlife classification amendment processes
- Identify gaps between current regulations and the requirements for commercial crocodile moat deployment
- Document the legal risks and uncertainties that could affect the business model's viability
- Present the assessment to the Board and international wildlife law firms to inform the CITES Legal Pathway Strategy

**Approval Authorities:** Board of three, CITES & Regulatory Affairs Director, International wildlife law firms (for validation)

### 13. Governance Charter and Organizational Structure Document

**ID:** dbdbc742-ba04-4554-90e1-1d34c36553e5

**Description:** A foundational document that defines the corporate governance structure, reporting relationships, decision-making authority levels, and organizational hierarchy for Crocodile Security. It establishes the three-member Board composition (Founder, Gulf investor representative, independent director), defines capital deployment thresholds requiring board approval, specifies client-acceptance authority levels, and creates the regulatory escalation protocol. This document addresses the organizational gaps identified in the expert review and provides the structural foundation for all other planning documents.

**Responsible Role Type:** Founder / Project Sponsor

**Primary Template:** Corporate Governance Charter Template

**Secondary Template:** Organizational Structure and Reporting Lines Template

**Steps:**

- Define the Board composition and roles: Founder (majority voting control 60-70%), Gulf investor representative (minority equity 30-40% with veto rights over capital deployments exceeding $1M), independent director (wildlife regulation or defense contracting expertise)
- Establish the organizational hierarchy with C-suite roles reporting to CEO and operational directors reporting to CEO or designated C-suite leads
- Define decision-making authority thresholds: capital expenditures above $100K require board approval, client contracts above $1M require CEO + board approval, hiring above level 5 require CEO approval
- Create the regulatory escalation protocol for CITES permit issues, wildlife classification amendments, and multi-jurisdictional compliance matters
- Define the client-acceptance authority levels including board approval requirements for clients generating sustained negative media attention
- Address the scope concerns for the Head of Strategic Intelligence role and recommend potential splitting into Chief Strategy Officer and Chief Narrative Officer
- Present the governance charter to the Board for formal adoption within the first 60 days (by November 2026)

**Approval Authorities:** Board of three, Founder, Gulf family-office investor

## Documents to Find

### 1. CITES Appendix I Text and Exemption Mechanisms Documentation

**ID:** edb169eb-a602-45f6-99a0-7ef606bf9d67

**Description:** The official CITES (Convention on International Trade in Endangered Species) Appendices I, II, and III text, including Article VIII exemptions for captive-breeding certification and registered commercial breeding operations. This is the primary legal source material needed to identify the specific exemption mechanism for Nile crocodile commercial trade. It serves as the foundational legal reference for the CITES Legal Pathway Strategy and Current State Assessment.

**Recency Requirement:** Current version of CITES Appendices and Article VIII text; any amendments or interpretive guidance issued by the CITES Secretariat

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Easy - CITES documentation is publicly available on the official CITES website and through the CITES Secretariat's online resources

**Steps:**

- Access the official CITES website (cites.org) for the current Appendices I, II, and III text
- Download Article VIII exemption provisions and any relevant interpretive guidance from the CITES Secretariat
- Search for CITES Secretariat decisions and resolutions related to Nile crocodile (Crocodylus niloticus) captive-breeding certification
- Review precedent cases of Appendix I commercial trade exemptions for crocodile species in other jurisdictions
- Consult with the engaged international wildlife law firm for their analysis of applicable exemption mechanisms

### 2. Egyptian CITES Management Authority Regulations and Guidelines

**ID:** dd6ea32c-c836-4335-9b03-e1d717e23f36

**Description:** Official regulations, guidelines, and procedural documents from the Egyptian CITES Management Authority regarding captive-breeding certification, commercial breeding operation registration, and export permit requirements for Nile crocodiles. This source material is essential for understanding the specific requirements and pre-approval processes for breeding facility registration in Egypt, which is the primary sourcing jurisdiction.

**Recency Requirement:** Current regulations and guidelines as of 2026; any recent policy updates or administrative decisions affecting crocodile breeding and export

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Medium - Requires direct contact with the Egyptian CITES Management Authority and potentially formal requests; some documents may be available through government portals but others require institutional access

**Steps:**

- Contact the Egyptian CITES Management Authority (under the Egyptian Environmental Affairs Agency) for official regulatory documents
- Search the Egyptian Ministry of Environment website for wildlife trade regulations and CITES implementation guidelines
- Request pre-approval procedures and requirements for breeding facility registration from the Egyptian CITES Management Authority
- Review any existing Egyptian crocodile farm licensing frameworks and export permit application processes
- Engage the international wildlife law firm to obtain updated regulatory guidance through their institutional relationships

### 3. Israeli Environmental Ministry Wildlife Classification Regulations (Post-July 2026)

**ID:** b6673e04-031b-4b46-ac0d-298ceb9d4209

**Description:** Official regulations, policy documents, and administrative decisions from the Israeli Environmental Ministry regarding the July 2026 reclassification of Nile crocodile as a 'tended wild animal.' This source material documents the regulatory precedent that enables crocodile moat deployment in Israel and serves as a model for wildlife classification amendments in other jurisdictions. It is critical for understanding the legal pathway that validates the Ketziot Prison reference contract.

**Recency Requirement:** Current regulations as of July 2026 reclassification; any subsequent amendments or implementing guidelines issued through September 2026

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Medium - Israeli government websites may have English translations but some documents may require Hebrew proficiency; direct contact with the Environmental Ministry may be necessary for complete regulatory documentation

**Steps:**

- Access the Israeli Environmental Ministry website for official announcements and regulatory documents related to the July 2026 reclassification
- Search the Israeli Knesset legislative database for any laws, regulations, or administrative orders related to 'tended wild animal' classification
- Contact the Israeli Environmental Ministry's wildlife regulation department for official guidance documents and permit procedures
- Review the Israeli National Security Ministry's Ketziot Prison moat project documentation (NIS 21 million budget allocation) for regulatory context
- Consult with the international wildlife law firm for their analysis of the Israeli reclassification precedent and its applicability to other jurisdictions

### 4. UAE Wildlife Authority Import/Export and Classification Framework

**ID:** 43be3d2c-3779-48f2-81bc-7df38351f327

**Description:** Official regulations, policies, and procedural frameworks from the UAE Wildlife Authority (or equivalent regulatory body) governing wildlife import/export permits, wildlife classification amendments, and commercial breeding operation registration. This source material is essential for understanding the regulatory pathway for deploying crocodile moats in the Gulf region, which is a key market for both the Gulf family-office investor and potential royal/private clients.

**Recency Requirement:** Current regulations and frameworks as of 2026; any recent updates to wildlife import/export policies or classification systems

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Medium - UAE government websites may have limited English documentation for specialized wildlife regulations; direct contact with the Wildlife Authority or engagement through the international law firm may be necessary

**Steps:**

- Access the UAE Wildlife Authority or Ministry of Climate Change and Environment website for wildlife trade regulations
- Search for UAE federal laws and ministerial decrees related to wildlife import/export, CITES implementation, and animal classification
- Contact the UAE Wildlife Authority for official guidance on wildlife classification amendment procedures and commercial breeding operation requirements
- Review any existing UAE frameworks for exotic animal keeping, security animal deployment, or wildlife-based security systems
- Engage the international wildlife law firm for their analysis of UAE regulatory requirements and classification amendment pathways

### 5. Lake Nasser Crocodile Farm Inventory and Production Data

**ID:** f2317162-9861-47a8-b05e-8a5a3f7b8f26

**Description:** Existing data on crocodile farm inventory, breeding stock levels, juvenile production capacity, pricing structures, and supply availability from farms around Lake Nasser, Aswan Governorate, Egypt. This source material is essential for the Animal Sourcing and Breeding Program Strategy, enabling assessment of supply chain resilience, drought-driven stock fluctuation risks, and negotiation of exclusive supply agreements with at least three farms.

**Recency Requirement:** Most recent available data (2025-2026); production and inventory data should reflect current breeding stock levels and recent drought impacts from Grand Ethiopian Renaissance Dam water-level effects

**Responsible Role Type:** Head Veterinarian & Animal Welfare Director

**Access Difficulty:** Medium - Farm data may be proprietary and require direct negotiation; some aggregated industry data may be available through government or industry associations but detailed production figures likely require farm-by-farm engagement

**Steps:**

- Contact existing Lake Nasser crocodile farms directly for inventory, production capacity, and pricing data
- Engage with the Egyptian Ministry of Environment or CITES Management Authority for aggregated farm data and licensing information
- Research any published reports or studies on Lake Nasser crocodile farming industry capacity and trends
- Assess the impact of Grand Ethiopian Renaissance Dam water-level effects on Lake Nasser crocodile farm stock availability
- Evaluate farm compliance with CITES breeding facility standards and welfare certification requirements

### 6. Israel Ketziot Prison Crocodile Moat Project Documentation

**ID:** aa768829-bba8-40dd-a516-abc938945214

**Description:** Official project documentation, budget allocations, technical specifications, and operational details for the Israeli National Security Ministry's NIS 21 million (~$7M) crocodile moat project at Ketziot Prison, announced July 2026. This source material provides the validated benchmark for Crocodile Security's pricing strategy ($41,000/meter), engineering specifications, and market validation. It serves as the reference case that all subsequent sales cycles will reference.

**Recency Requirement:** Most recent available documentation as of July 2026 announcement; any subsequent updates, contract awards, or technical specifications released through September 2026

**Responsible Role Type:** Client Acquisition & Market Entry Director

**Access Difficulty:** Medium - Israeli government project documentation may be partially public but detailed technical specifications and contract information may require formal requests or be limited; media coverage may provide supplementary information

**Steps:**

- Search Israeli National Security Ministry press releases and official announcements for Ketziot Prison moat project details
- Review Israeli government budget documents for the NIS 21 million allocation and any published cost breakdowns
- Contact the Israeli National Security Ministry or relevant procurement office for project specifications and technical requirements
- Research Israeli media coverage of the Ketziot moat project for additional details on scope, timeline, and contractor information
- Analyze the project as a benchmark for pricing strategy, engineering standards, and regulatory compliance requirements

### 7. Nile Crocodile (Crocodylus niloticus) Biological and Husbandry Reference Data

**ID:** 2778f8fb-77c6-4616-8fac-61e495da905e

**Description:** Scientific and technical reference data on Nile crocodile biology, growth rates, temperature requirements (28-33°C optimal), water quality parameters, dietary needs, behavioral characteristics, adult size ranges (3-5 meters, 200+ kg), and captive breeding husbandry practices. This source material is essential for the Escape-Prevention Engineering Philosophy, Animal Welfare Program Framework, and habitat design specifications across all moat installations.

**Recency Requirement:** Current scientific literature and husbandry guidelines; established biological data is relatively stable but recent research on crocodile behavior, thermal tolerance, and welfare standards should be included

**Responsible Role Type:** Head Veterinarian & Animal Welfare Director

**Access Difficulty:** Easy - Scientific literature and established husbandry guidelines are publicly available through academic databases and professional associations; some specialized veterinary resources may require subscription access

**Steps:**

- Access scientific databases (e.g., PubMed, Google Scholar, Web of Science) for peer-reviewed research on Nile crocodile biology and husbandry
- Consult established crocodile farming and zoological association guidelines for captive breeding and welfare standards
- Review veterinary literature on reptile health, disease management, and welfare assessment protocols for crocodilians
- Gather data on crocodile growth rates, adult size ranges, temperature requirements, and water quality parameters from authoritative sources
- Engage with the Head Veterinarian's professional network (World Organisation for Animal Health reptile health standards committee) for expert reference data

### 8. Egypt Currency Exchange Rate History and Economic Indicators

**ID:** 1a70d69c-0356-4bc0-bdcb-bdfa31ea046c

**Description:** Historical and current data on Egyptian Pound (EGP) exchange rates against USD, inflation rates, currency volatility patterns (15-25% depreciation cycles), and economic indicators affecting operational costs in Egypt. This source material is essential for the Capital Deployment and Tranche-Gated Milestone Plan, enabling accurate budgeting with 20% EGP currency buffer and multi-currency risk management strategies.

**Recency Requirement:** Most recent exchange rate data and economic indicators through September 2026; historical data for trend analysis (past 3-5 years recommended)

**Responsible Role Type:** Chief Financial Officer & Capital Deployment Manager

**Access Difficulty:** Easy - Exchange rate data and economic indicators are publicly available through central bank websites, international financial data providers, and economic research publications

**Steps:**

- Access the Central Bank of Egypt website for official exchange rates and monetary policy data
- Search international financial data sources (e.g., IMF, World Bank, XE.com, OANDA) for EGP/USD historical exchange rate data
- Review Egypt's economic indicators including inflation rates, foreign exchange reserves, and currency volatility reports
- Analyze recent EGP depreciation cycles (15-25%) and their impact on operational costs for foreign investors
- Consult with the foreign exchange specialist advisor for market analysis and hedging strategy recommendations

### 9. Israel New Israeli Shekel (ILS) Exchange Rate and Geopolitical Risk Data

**ID:** d4921666-cf2a-4b58-be63-87025fdd6123

**Description:** Current and historical data on Israeli Shekel (ILS) exchange rates against USD, currency fluctuation patterns related to Israeli geopolitical conditions, and risk assessments affecting ILS-denominated contract values. This source material is essential for hedging ILS exposure on the Ketziot contract and structuring multi-year contracts with currency adjustment clauses.

**Recency Requirement:** Most recent exchange rate data and geopolitical risk assessments through September 2026; historical data for trend analysis (past 3-5 years recommended)

**Responsible Role Type:** Chief Financial Officer & Capital Deployment Manager

**Access Difficulty:** Easy - Exchange rate data is publicly available through central bank websites and international financial data providers; geopolitical risk assessments may require subscription to specialized risk intelligence services

**Steps:**

- Access the Bank of Israel website for official exchange rates and monetary policy data
- Search international financial data sources for ILS/USD historical exchange rate data and volatility patterns
- Review geopolitical risk assessments and their impact on Israeli currency fluctuations from financial research institutions
- Analyze ILS fluctuation patterns related to regional security conditions and their implications for multi-year contract values
- Consult with the foreign exchange specialist advisor and major bank hedging desks for ILS forward contract and currency option pricing

### 10. Existing International Wildlife Law Firm Capabilities and CITES Case Experience

**ID:** dd778b91-7455-49bb-a6f6-6a6b72edc078

**Description:** Information on international wildlife law firms with proven experience in CITES Appendix I captive-breeding exemption filings, multi-jurisdictional regulatory compliance, and wildlife classification amendment services. This source material is essential for selecting and engaging the specialized legal counsel required for the CITES Legal Pathway Strategy, with a retainer budget of $150,000-$250,000 across at least three target jurisdictions.

**Recency Requirement:** Current firm capabilities and recent case experience (2024-2026); firms should have demonstrated success with Appendix I exemptions for crocodile species or similar Appendix I wildlife trade cases

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Medium - Firm capabilities and case histories are publicly available but detailed proposals and fee structures require direct engagement; some firms may require retainers or engagement letters before providing detailed regulatory analysis

**Steps:**

- Search legal directories and professional networks for international wildlife law firms with CITES expertise
- Review firm websites and case histories for Appendix I captive-breeding exemption experience with crocodile species
- Contact professional associations (e.g., International Association of Wildlife Lawyers) for firm recommendations
- Request proposals from shortlisted firms detailing their approach to multi-jurisdictional CITES filings and regulatory strategy
- Verify firm credentials, success rates, and institutional relationships with Egyptian, Israeli, and UAE wildlife authorities

### 11. Specialized Live-Animal Logistics Firms with CITES-Reptile Transport Experience

**ID:** 5161ff87-4509-4d8c-aa8c-337daabefe9d

**Description:** Information on specialized logistics firms experienced in CITES-compliant live reptile transport, including GPS-tracked container systems, climate-controlled transport vehicles, mortality rate data (5-15% for juveniles), and international border crossing procedures for Appendix I species. This source material is essential for the Animal Sourcing and Breeding Program Strategy and pre-negotiation of transport contracts for crocodile movements from Lake Nasser to headquarters and client sites.

**Recency Requirement:** Current service offerings and capabilities as of 2026; firms should have demonstrated experience with CITES-compliant reptile transport in the Middle East and Africa regions

**Responsible Role Type:** Head Veterinarian & Animal Welfare Director

**Access Difficulty:** Medium - Firm capabilities are publicly available but detailed proposals, mortality data, and pricing require direct engagement; some specialized firms may have limited public documentation of their CITES-compliant procedures

**Steps:**

- Search for specialized live-animal logistics firms with reptile transport experience through industry directories and professional networks
- Review firm capabilities including GPS tracking systems, climate-controlled containers, and CITES documentation handling
- Request mortality rate data and transport success statistics for juvenile crocodile shipments from potential logistics providers
- Contact firms for proposals on transport routes from Lake Nasser to Nile island headquarters, Israel, and Gulf destinations
- Verify firm compliance with CITES transport requirements and international live-animal shipping regulations

### 12. Lloyd's of London and Specialty Underwriter Liability Insurance Market Data

**ID:** 49a1d401-93f6-4d7b-87d2-032b8b6669c4

**Description:** Market information on liability insurance products from Lloyd's of London or equivalent specialty underwriters for exotic animal containment, wildlife security operations, and high-liability risk coverage. This source material includes coverage limits ($25M-$50M aggregate, $5M per-incident), premium rates (3-5% of annual contract revenue), underwriting requirements, and exclusions relevant to live crocodile moat operations. Essential for the Risk Register and insurance procurement strategy.

**Recency Requirement:** Current market data and underwriting guidelines as of 2026; insurance market conditions and premium rates should reflect current risk assessments for exotic animal containment operations

**Responsible Role Type:** Chief Financial Officer & Capital Deployment Manager

**Access Difficulty:** Medium - Insurance market data and underwriting guidelines require direct contact with specialty underwriters; some information may be available through insurance brokers specializing in exotic animal or high-liability coverage but detailed terms require formal quotes and engagement

**Steps:**

- Contact Lloyd's of London market participants and specialty underwriters for liability insurance product information
- Search for existing insurance products covering exotic animal containment, wildlife security operations, or similar high-liability risk categories
- Request underwriting guidelines, coverage limits, premium rate estimates, and exclusion criteria from multiple specialty underwriters
- Review any existing insurance frameworks for wildlife parks, crocodile farms, or exotic animal exhibition facilities as comparable risk models
- Assess the impact of the 'no client too controversial' policy and welfare audit PR shield on underwriting eligibility and premium pricing

### 13. Egypt Ottoman-Era Fortress Properties and Real Estate Data (Nile Island South of Cairo)

**ID:** c6ae104a-5990-4598-812d-2e8553f570b1

**Description:** Existing data on Ottoman-era fortress properties available for conversion on islands in the Nile south of Cairo, including property specifications, structural assessments, renovation requirements, reinforced-glass boardroom installation feasibility, demonstration pool construction requirements, and acquisition or lease costs. This source material is essential for the Headquarters as Brand or Burden decision and the Capital Deployment Plan's first tranche allocation for fortress construction.

**Recency Requirement:** Current property data and market conditions as of 2026; structural assessments and renovation cost estimates should be recent to reflect current construction costs and EGP currency impacts

**Responsible Role Type:** Operations & Infrastructure Director

**Access Difficulty:** Medium - Property data may be available through real estate listings but historic fortress properties may have limited market exposure; antiquities authority regulations and structural assessments require direct engagement with government bodies and specialized engineering firms

**Steps:**

- Search Egyptian real estate databases and property listings for Ottoman-era fortress properties on Nile islands south of Cairo
- Contact Egyptian antiquities authorities (Supreme Council of Antiquities) for regulations on converting historic fortress properties for commercial use
- Engage local construction and engineering firms for preliminary structural assessments and renovation cost estimates
- Assess reinforced-glass boardroom installation feasibility, demonstration pool construction requirements, and habitat specifications for twelve adult Nile crocodiles
- Evaluate property acquisition or lease costs, renovation timelines, and any heritage preservation restrictions affecting conversion

### 14. Egyptian Crocodile Farm Labor Pool and Handler Recruitment Data

**ID:** a52a1537-2830-4140-8037-79526ef6e13d

**Description:** Existing data on the labor pool available from Egypt's existing crocodile farms, including worker numbers, skill levels, experience with Nile crocodile handling, willingness to transition to ceremonial handler roles, and training requirements. This source material is essential for the Handler Corps Development strategy, particularly the option to partner with existing farm labor for accelerated certification rather than building a completely new talent pipeline from scratch.

**Recency Requirement:** Current labor pool data as of 2026; farm worker numbers, skill assessments, and availability should reflect current conditions at Lake Nasser farms

**Responsible Role Type:** Director of Ceremonial Operations & Handler Corps Master

**Access Difficulty:** Medium - Farm labor data is likely proprietary and requires direct engagement with farm management; some aggregated labor market data may be available through Egyptian government statistics but specialized wildlife handling workforce data requires farm-by-farm assessment

**Steps:**

- Contact Lake Nasser crocodile farms for information on their workforce size, skill levels, and handler experience
- Assess the feasibility of retraining experienced farm hands through an accelerated eight-week certification program
- Evaluate the ceremonial polish gap between farm-hand experience and the theatrical black-uniformed handler standard
- Research Egyptian labor market conditions for specialized wildlife handling and ceremonial service roles
- Identify potential partnership structures with farms for labor pipeline access and accelerated certification programs

### 15. Global Ultra-High-Net-Worth Individual and Royal Palace Security Market Data

**ID:** fcd888eb-97da-4821-99dc-713b976b474f

**Description:** Existing market data on security spending patterns among ultra-high-net-worth individuals, royal families, and governments in the Middle East, Gulf region, and globally. This source material includes data on perimeter security investments, luxury security product preferences, ceremonial/experiential security demand, and price sensitivity for premium security solutions. Essential for the Market Entry Sequencing Strategy and pricing the psychological perimeter.

**Recency Requirement:** Most recent market data available (2024-2026); security market trends and UHNWI spending patterns should reflect current conditions in target markets

**Responsible Role Type:** Client Acquisition & Market Entry Director

**Access Difficulty:** Medium - Some market research reports are available through industry publications and research firms but detailed UHNWI security spending data may require subscription access or custom research; government procurement data may be partially public but specialized security spending categories may be aggregated or classified

**Steps:**

- Search security industry market research reports for UHNWI and royal family security spending data
- Review luxury security product market analyses including high-end perimeter security, estate security, and experiential security solutions
- Access wealth management and family office reports on security spending patterns among Gulf royal families and billionaire compounds
- Analyze government security procurement data for interior ministry and national security ministry spending on perimeter security innovations
- Identify market trends in theatrical or experiential security products that could inform the psychological perimeter pricing strategy

### 16. Environmental Impact Assessment (EIA) Regulatory Requirements by Jurisdiction

**ID:** 2dfb2818-beed-4a53-a51b-0180118c3935

**Description:** Existing regulatory frameworks, EIA requirements, permitting procedures, and environmental compliance standards for moat construction and live animal deployment in target jurisdictions (Egypt, Israel, UAE, and future expansion markets). This source material includes EIA cost ranges ($50,000-$150,000 per installation), assessment timelines (6-month process), water usage regulations, and ecosystem impact assessment requirements. Essential for the Regulatory Pathway Design and Environmental Compliance planning.

**Recency Requirement:** Current EIA regulations and environmental compliance requirements as of 2026; any recent updates to environmental assessment procedures or water usage regulations in arid-climate jurisdictions

**Responsible Role Type:** CITES & Regulatory Affairs Director

**Access Difficulty:** Medium - EIA regulations are generally publicly available through government environmental agency websites but specific procedural details, cost estimates, and consultancy requirements may require direct contact with local environmental consultancies and regulatory bodies

**Steps:**

- Access environmental regulatory agency websites in Egypt, Israel, and UAE for EIA requirements and procedures
- Search for environmental impact assessment regulations specific to construction projects, water feature installations, and live animal deployment
- Contact local environmental consultancies in each jurisdiction for EIA cost estimates, timelines, and compliance requirements
- Review any existing EIA precedents for wildlife facilities, aquatic installations, or security infrastructure projects in target jurisdictions
- Assess water usage regulations and ecosystem impact requirements for arid-climate moat installations in each jurisdiction