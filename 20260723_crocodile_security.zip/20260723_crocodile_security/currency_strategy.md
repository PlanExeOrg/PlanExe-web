This plan involves money.

## Currencies

- **USD:** The seed capital of $10 million is denominated in USD, and the Ketziot benchmark (~$7 million per contract) is referenced in USD. As an international project spanning Egypt, Israel, the Gulf, and eventually multiple continents, USD serves as the primary currency for budgeting, reporting, and cross-border transactions.
- **EGP:** Egyptian Pounds are required for local operations including headquarters construction on the Nile island, animal sourcing from Lake Nasser farms, and day-to-day expenses in Egypt. Egypt has experienced notable currency volatility in recent years, making EGP transactions a risk factor to monitor.
- **ILS:** Israeli New Shekels are relevant for the reference contract at Ketziot Prison, where the Israeli National Security Ministry budgeted NIS 21 million. The contract bid and execution would be denominated in ILS, requiring currency management between ILS and USD.
- **AED:** The UAE Dirham is relevant for the Gulf family-office investor and potential royal/private clients in the Gulf region. The AED is pegged to the USD, reducing exchange risk for that portion of capital and client relationships.

**Primary currency:** USD

**Currency strategy:** Given the project's international scope across Egypt, Israel, the UAE, and eventual global expansion, USD will serve as the primary currency for all budgeting, reporting, and investor communications. Local currencies (EGP for Egypt operations, ILS for the Israeli reference contract, AED for Gulf investor relations) will be used for in-country transactions. To manage currency risk, the company should use hedging instruments for multi-year contracts denominated in ILS, maintain multi-currency accounts to minimize conversion losses, and leverage the AED-USD peg for Gulf transactions. Given Egypt's recent currency volatility, EGP expenses should be budgeted with a buffer and converted from USD at favorable rates where possible.