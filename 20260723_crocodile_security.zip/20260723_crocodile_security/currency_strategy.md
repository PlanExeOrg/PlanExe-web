This plan involves money.

## Currencies

- **EGP:** The local currency of Egypt, where the headquarters and operations will be based.
- **USD:** A stable international currency for budgeting and reporting, especially given the project's scale and potential international clientele.

**Primary currency:** USD

**Currency strategy:** The primary currency for budgeting and reporting will be USD to mitigate risks from potential currency instability in Egypt. Local transactions may be conducted in EGP as needed.