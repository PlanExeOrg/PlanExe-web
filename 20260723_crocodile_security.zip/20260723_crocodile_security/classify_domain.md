**Primary domain:** Security Engineering

**Secondary domains:** Wildlife Management, Regulatory Compliance, Aquatic Engineering

**Rationale:** Security Engineering owns the project's core outcome: delivering live-crocodile perimeter security moats for security clients, with success measured by winning contracts. Veterinary Medicine, though vital for animal welfare and safety criteria, is a supporting operational discipline rather than the venture's fundamental purpose.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Security Engineering | 5 | 5 | outcome | Core product is live-crocodile perimeter security moats requiring moat engineering and escape-prevention design. |
| Wildlife Management | 5 | 5 | method | Sourcing Nile crocodiles, habitat design, veterinary care, and handler training require wildlife biology expertise. |
| Veterinary Medicine | 5 | 5 | outcome | Critical for veterinary care, feeding logistics, and the independently audited animal welfare program that is a core success criterion. |
| CITES Compliance | 5 | 5 | constraint | Secures CITES-compliant export permits for Nile crocodile sourcing. |
| Regulatory Compliance | 4 | 4 | constraint | CITES export permits and wildlife classification amendments are mandatory legal requirements for operation. |
| Aquatic Engineering | 4 | 4 | method | Covers water management in arid climates, habitat design with thermal management, and water quality maintenance for moat systems. |
| Marine Construction | 4 | 4 | method | Encompasses excavation, moat engineering, reinforced glass structures, and escape-prevention engineering for water-based security barriers. |
| Zoological Facility Design | 4 | 4 | method | Designs crocodile habitats with basking zones, thermal management, and escape prevention. |
| Animal Welfare Science | 4 | 4 | constraint | Ensures independently audited animal welfare standards to avoid violations. |