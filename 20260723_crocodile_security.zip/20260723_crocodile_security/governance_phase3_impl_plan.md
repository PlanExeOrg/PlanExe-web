### 1. Founder / Project Sponsor drafts the initial Terms of Reference for the Project Steering Committee, including capital deployment thresholds, decision rights, voting protocol, and tranche release approval mechanism

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 1 (September 2026)

**Key Outputs/Deliverables:**

- Draft Project Steering Committee ToR v0.1
- Initial capital deployment threshold matrix
- Proposed voting protocol and casting vote provisions

**Dependencies:**

- Project Sponsor Identified
- Gulf family-office investor confirmed

### 2. Circulate Draft Steering Committee ToR to Gulf family-office investor representative nominee and independent director nominee for structured review and feedback

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 2 (September 2026)

**Key Outputs/Deliverables:**

- Review feedback summary from Gulf investor nominee
- Review feedback summary from independent director nominee
- List of required revisions to ToR

**Dependencies:**

- Draft Project Steering Committee ToR v0.1
- Gulf investor nominee identified
- Independent director nominee identified

### 3. Founder consolidates feedback, revises the Steering Committee ToR, and formally ratifies the final ToR as the pre-existing founding authority

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 2-3 (September 2026)

**Key Outputs/Deliverables:**

- Finalized Project Steering Committee ToR v1.0
- Signed ratification document from Founder
- Agreed capital deployment thresholds ($500K operational, $2M unanimity)

**Dependencies:**

- Review feedback from Gulf investor nominee
- Review feedback from independent director nominee

### 4. Founder drafts initial ToR frameworks and operating charter templates for all four subordinate governance bodies (Executive Operations Group, Technical & Engineering Advisory Board, Ethics Animal Welfare & Compliance Committee, Risk & Crisis Management Committee)

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 3 (September 2026)

**Key Outputs/Deliverables:**

- Draft ToR framework for Executive Operations Group
- Draft ToR framework for Technical & Engineering Advisory Board
- Draft ToR framework for Ethics, Animal Welfare & Compliance Committee
- Draft ToR framework for Risk & Crisis Management Committee

**Dependencies:**

- Finalized Project Steering Committee ToR v1.0

### 5. Founder identifies and nominates all candidates for governance body positions, including Gulf investor representative, independent director, and initial leads for subordinate bodies

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 3 (September 2026)

**Key Outputs/Deliverables:**

- Nominated membership list for Project Steering Committee
- Nominated membership list for Executive Operations Group
- Nominated candidate list for Technical & Engineering Advisory Board external members
- Nominated candidate list for Ethics Committee and Risk Committee

**Dependencies:**

- Finalized Project Steering Committee ToR v1.0
- Draft ToR frameworks for subordinate bodies

### 6. Founder formally confirms Project Steering Committee membership, appoints self as Chair, and issues formal membership confirmation communications to all nominated members

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 3 (September 2026)

**Key Outputs/Deliverables:**

- Formal membership confirmation emails to all SteerCo members
- Appointment confirmation for Founder as SteerCo Chair
- Documented voting protocol including casting vote and unanimity thresholds

**Dependencies:**

- Finalized Project Steering Committee ToR v1.0
- Nominated membership list confirmed

### 7. Hold the Project Steering Committee Inaugural Meeting: ratify the ToR, establish voting protocol, define tranche release approval mechanism, set meeting cadence, and define escalation protocols from subordinate bodies

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4 (late September 2026)

**Key Outputs/Deliverables:**

- Signed Project Steering Committee ToR ratification
- Documented voting protocol with casting vote and unanimity requirements
- Tranche release approval protocol linked to externally verifiable milestones
- Established monthly meeting cadence
- Escalation protocol document from subordinate bodies

**Dependencies:**

- Formal membership confirmation for all SteerCo members
- Finalized Project Steering Committee ToR v1.0

### 8. Project Steering Committee approves its formal governance charter, decision rights document, and conflict resolution mechanism, now that it is formally constituted

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4 (late September 2026)

**Key Outputs/Deliverables:**

- Approved governance charter
- Documented decision rights matrix
- Conflict resolution mechanism protocol

**Dependencies:**

- SteerCo Inaugural Meeting held
- ToR ratified

### 9. Project Steering Committee reviews and formally approves the Executive Operations Group ToR and operating charter, delegating day-to-day operational authority below the $500,000 threshold

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 5 (October 2026)

**Key Outputs/Deliverables:**

- Approved Executive Operations Group ToR
- Delegated authority thresholds document
- Reporting lines and organizational structure approval

**Dependencies:**

- SteerCo governance charter approved
- Draft ToR framework for Executive Operations Group

### 10. Founder and Operations Manager designate formally confirm Executive Operations Group membership, assign all core team roles, and issue formal appointment notifications

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 5 (October 2026)

**Key Outputs/Deliverables:**

- Formal membership confirmation for all EOG members
- Assigned organizational structure chart
- Appointment notifications for Operations Manager, Lead Veterinarian, Regulatory Affairs Director, Moat Engineering Lead, Handler Corps Lead, Finance/Admin Manager, Client Relations Lead

**Dependencies:**

- SteerCo approves EOG ToR
- Nominated EOG membership list confirmed

### 11. Hold the Executive Operations Group Inaugural Meeting: adopt the operating charter, establish weekly operational review cadence, set up project management tools and burn-rate dashboards

**Responsible Body/Role:** Executive Operations Group

**Suggested Timeframe:** Project Week 5-6 (October 2026)

**Key Outputs/Deliverables:**

- Adopted EOG operating charter
- Weekly operational review meeting schedule
- Project management tools and dashboards configured
- Monthly burn-rate dashboard with 70% and 90% tranche triggers

**Dependencies:**

- EOG membership formally confirmed
- EOG ToR approved by SteerCo

### 12. Executive Operations Group establishes vendor selection criteria, procurement workflows below $200,000, and communication protocols across all physical locations

**Responsible Body/Role:** Executive Operations Group

**Suggested Timeframe:** Project Week 6 (October 2026)

**Key Outputs/Deliverables:**

- Vendor selection criteria document
- Procurement workflow documentation
- Cross-location communication protocols
- Site-specific operational plans for Nile headquarters, Lake Nasser facility, UAE office, and Israeli demonstration site

**Dependencies:**

- EOG Inaugural Meeting held
- Core team roles assigned

### 13. Project Steering Committee reviews and formally approves the Technical & Engineering Advisory Board ToR, including its advisory authority and technical veto power over safety-critical designs

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6-7 (October-November 2026)

**Key Outputs/Deliverables:**

- Approved Technical & Engineering Advisory Board ToR
- Documented technical veto protocol
- Defined review protocols and submission requirements

**Dependencies:**

- SteerCo governance charter approved
- Draft ToR framework for T&EAB

### 14. Designated Technical Lead (Moat Engineering Lead) recruits external members for the Technical & Engineering Advisory Board, including marine/structural engineers, arid-climate aquatic specialists, IoT/cybersecurity experts, reinforced glass specialists, and reptile behavior experts

**Responsible Body/Role:** Moat Engineering Lead / Founder

**Suggested Timeframe:** Project Week 7-8 (November 2026)

**Key Outputs/Deliverables:**

- Recruited external members with verified expertise credentials
- Member acceptance confirmations
- Curriculum vitae and qualification summaries for all T&EAB members

**Dependencies:**

- SteerCo approves T&EAB ToR
- Candidate profiles defined in ToR framework

### 15. Project Steering Committee formally confirms Technical & Engineering Advisory Board membership and establishes secure communication channels for confidential technical assessments

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 8 (November 2026)

**Key Outputs/Deliverables:**

- Formal membership confirmation for all T&EAB members
- Secure communication channels established
- Documented confidentiality agreements signed

**Dependencies:**

- External members recruited
- T&EAB ToR approved

### 16. Hold the Technical & Engineering Advisory Board Inaugural Meeting: define technical documentation standards, establish quarterly review cadence, define the technical veto protocol, and schedule the first design review session

**Responsible Body/Role:** Technical & Engineering Advisory Board

**Suggested Timeframe:** Project Week 8-9 (November 2026)

**Key Outputs/Deliverables:**

- T&EAB terms of reference finalized
- Technical documentation standards document
- Quarterly review cadence established
- Technical veto protocol documented
- First design review session scheduled

**Dependencies:**

- T&EAB membership formally confirmed
- Secure communication channels established

### 17. Project Steering Committee reviews and formally approves the Ethics, Animal Welfare & Compliance Committee ToR, including its authority over CITES compliance, controversial client adjudication, and welfare audit certification

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9-10 (November-December 2026)

**Key Outputs/Deliverables:**

- Approved Ethics, Animal Welfare & Compliance Committee ToR
- Documented authority scope for CITES compliance and client acceptance
- Welfare standards exceeding audit thresholds framework

**Dependencies:**

- SteerCo governance charter approved
- Draft ToR framework for Ethics Committee

### 18. Founder and Steering Committee recruit the independent ethics advisor (former head of a recognized zoo or conservation body) to serve as Chair of the Ethics Committee

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 10 (December 2026)

**Key Outputs/Deliverables:**

- Independent ethics advisor identified and approached
- Candidate acceptance confirmation
- Curriculum vitae and qualifications documented

**Dependencies:**

- SteerCo approves Ethics Committee ToR
- Candidate profile defined in ToR framework

### 19. Project Steering Committee formally confirms Ethics, Animal Welfare & Compliance Committee membership, including the independent ethics advisor as Chair, CITES Compliance Officer, external auditor, legal counsel, community liaison, and independent media risk expert

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 10-11 (December 2026)

**Key Outputs/Deliverables:**

- Formal membership confirmation for all Ethics Committee members
- Independent ethics advisor confirmed as Chair
- CITES Compliance Officer appointment confirmed

**Dependencies:**

- Independent ethics advisor recruited
- Ethics Committee ToR approved

### 20. Hold the Ethics, Animal Welfare & Compliance Committee Inaugural Meeting: define the ethical framework, establish CITES compliance protocols, set up anonymous whistleblower mechanisms, define GDPR/data privacy standards, and establish the client-review board process

**Responsible Body/Role:** Ethics, Animal Welfare & Compliance Committee

**Suggested Timeframe:** Project Week 11-12 (December 2026-January 2027)

**Key Outputs/Deliverables:**

- Ethical framework document
- CITES compliance protocols established
- Anonymous whistleblower mechanism operational
- GDPR/data privacy standards for monitoring platform documented
- Client-review board process established
- Monthly meeting cadence confirmed

**Dependencies:**

- Ethics Committee membership formally confirmed
- Ethics Committee ToR approved

### 21. Ethics Committee engages specialized international wildlife law firms for CITES Appendix I exemption pathway filing and establishes relationships with the Egyptian CITES Management Authority, Israeli Environmental Ministry, and UAE Wildlife Authority

**Responsible Body/Role:** Ethics, Animal Welfare & Compliance Committee

**Suggested Timeframe:** Project Week 12-14 (January-February 2027)

**Key Outputs/Deliverables:**

- Retained international wildlife law firms
- CITES Appendix I exemption mechanism identified and documented
- Initial filings prepared for Egyptian CITES Management Authority
- Relationship established with Israeli Environmental Ministry
- Relationship established with UAE Wildlife Authority

**Dependencies:**

- Ethics Committee Inaugural Meeting held
- CITES compliance protocols established

### 22. Project Steering Committee reviews and formally approves the Risk & Crisis Management Committee ToR, including its authority to declare crises, activate emergency protocols, and manage the $10M single-incident financial exposure cap

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 12-13 (January 2027)

**Key Outputs/Deliverables:**

- Approved Risk & Crisis Management Committee ToR
- Documented crisis declaration authority
- $10M single-incident financial exposure cap protocol
- Emergency expenditure authorization thresholds

**Dependencies:**

- SteerCo governance charter approved
- Draft ToR framework for Risk Committee

### 23. Founder and Steering Committee recruit the Safety Director (to serve as Risk Committee Chair) and external risk management consultant, insurance broker liaison, and security consultant

**Responsible Body/Role:** Founder / Project Sponsor

**Suggested Timeframe:** Project Week 13-14 (February 2027)

**Key Outputs/Deliverables:**

- Safety Director identified and appointed
- External risk management consultant recruited
- Insurance broker/liaison engaged
- Security consultant recruited
- All Risk Committee member acceptances confirmed

**Dependencies:**

- SteerCo approves Risk Committee ToR
- Candidate profiles defined in ToR framework

### 24. Project Steering Committee formally confirms Risk & Crisis Management Committee membership and establishes the risk taxonomy framework

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14 (February 2027)

**Key Outputs/Deliverables:**

- Formal membership confirmation for all Risk Committee members
- Risk taxonomy and comprehensive risk register initialized
- Documented reporting lines for safety director to board

**Dependencies:**

- Risk Committee members recruited
- Risk Committee ToR approved

### 25. Hold the Risk & Crisis Management Committee Inaugural Meeting: establish the comprehensive risk register, define crisis response protocols for all existential risk categories, set up the insurance framework, and establish security protocols

**Responsible Body/Role:** Risk & Crisis Management Committee

**Suggested Timeframe:** Project Week 14-15 (February-March 2027)

**Key Outputs/Deliverables:**

- Comprehensive risk register with likelihood, severity, and mitigation status
- Crisis response protocols for containment breaches, regulatory reversals, and capital depletion
- Insurance framework established ($25M-$50M aggregate, $5M per-incident)
- Security protocols including 24/7 armed security and GPS tracking
- Bi-weekly meeting cadence established
- Crisis escalation triggers documented

**Dependencies:**

- Risk Committee membership formally confirmed
- Risk Committee ToR approved

### 26. Risk & Crisis Management Committee conducts the first quarterly penetration testing oversight session and establishes pre-negotiated emergency response MOUs with local authorities at all installation sites

**Responsible Body/Role:** Risk & Crisis Management Committee

**Suggested Timeframe:** Project Week 15-16 (March 2027)

**Key Outputs/Deliverables:**

- First quarterly penetration testing oversight report
- Emergency response MOUs signed with local authorities at Nile headquarters and Lake Nasser facility
- Crisis management reserve ($500,000) established
- Insurance coverage confirmed from Lloyd's of London or equivalent

**Dependencies:**

- Risk Committee Inaugural Meeting held
- Crisis response protocols defined

### 27. All five governance bodies conduct a joint operational readiness review, confirm inter-body escalation protocols are functional, and formally declare the governance structure operational

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 16-17 (March 2027)

**Key Outputs/Deliverables:**

- Joint governance readiness assessment report
- Inter-body escalation protocol validation document
- Formal declaration of governance structure operational
- Updated master governance charter incorporating all ratified ToRs

**Dependencies:**

- All five body inaugural meetings held
- All ToRs ratified
- All escalation protocols tested

### 28. Project Steering Committee conducts the first tranche release review, evaluating milestone achievement against the gated $2M tranche criteria and authorizing capital deployment

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 17-18 (March-April 2027)

**Key Outputs/Deliverables:**

- First tranche release approval document
- Milestone achievement assessment report
- Authorized capital deployment of $2M against approved budget categories
- Updated burn-rate dashboard with tranche trigger status

**Dependencies:**

- Governance structure declared operational
- Tranche release approval protocol established
- CITES permit filing progress confirmed