### 1. Project Sponsor identifies and appoints an Interim Chair for the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Appointment Confirmation Email for Interim Chair

**Dependencies:**


### 2. Interim Chair drafts initial Terms of Reference (ToR) for the Project Steering Committee.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft ToR for Project Steering Committee v0.1

**Dependencies:**

- Appointment Confirmation Email for Interim Chair

### 3. Circulate Draft ToR for review by nominated members of the Project Steering Committee.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary from Committee Members

**Dependencies:**

- Draft ToR for Project Steering Committee v0.1

### 4. Finalize and approve the Terms of Reference for the Project Steering Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved ToR for Project Steering Committee

**Dependencies:**

- Feedback Summary from Committee Members

### 5. Project Sponsor formally appoints members of the Project Steering Committee.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Appointment Confirmation Emails for Committee Members

**Dependencies:**

- Approved ToR for Project Steering Committee

### 6. Hold the inaugural meeting of the Project Steering Committee to establish roles and responsibilities.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Appointment Confirmation Emails for Committee Members

### 7. Interim Chair drafts initial Terms of Reference (ToR) for the Project Management Office (PMO).

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Draft ToR for PMO v0.1

**Dependencies:**

- Approved ToR for Project Steering Committee

### 8. Circulate Draft ToR for review by nominated members of the PMO.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Feedback Summary from PMO Members

**Dependencies:**

- Draft ToR for PMO v0.1

### 9. Finalize and approve the Terms of Reference for the PMO.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Approved ToR for PMO

**Dependencies:**

- Feedback Summary from PMO Members

### 10. Recruit project management staff for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Staff Recruitment Confirmation Emails

**Dependencies:**

- Approved ToR for PMO

### 11. Hold the inaugural meeting of the PMO to establish operational plans and reporting frameworks.

**Responsible Body/Role:** PMO

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Staff Recruitment Confirmation Emails

### 12. Interim Chair drafts initial Terms of Reference (ToR) for the Regulatory Compliance Committee.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Draft ToR for Regulatory Compliance Committee v0.1

**Dependencies:**

- Approved ToR for PMO

### 13. Circulate Draft ToR for review by nominated members of the Regulatory Compliance Committee.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 13

**Key Outputs/Deliverables:**

- Feedback Summary from Regulatory Compliance Committee Members

**Dependencies:**

- Draft ToR for Regulatory Compliance Committee v0.1

### 14. Finalize and approve the Terms of Reference for the Regulatory Compliance Committee.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 14

**Key Outputs/Deliverables:**

- Approved ToR for Regulatory Compliance Committee

**Dependencies:**

- Feedback Summary from Regulatory Compliance Committee Members

### 15. Hold the inaugural meeting of the Regulatory Compliance Committee to establish compliance strategies.

**Responsible Body/Role:** Regulatory Compliance Committee

**Suggested Timeframe:** Project Week 15

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Approved ToR for Regulatory Compliance Committee

### 16. Interim Chair drafts initial Terms of Reference (ToR) for the Animal Welfare Advisory Group.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 16

**Key Outputs/Deliverables:**

- Draft ToR for Animal Welfare Advisory Group v0.1

**Dependencies:**

- Approved ToR for Regulatory Compliance Committee

### 17. Circulate Draft ToR for review by nominated members of the Animal Welfare Advisory Group.

**Responsible Body/Role:** Interim Chair

**Suggested Timeframe:** Project Week 17

**Key Outputs/Deliverables:**

- Feedback Summary from Animal Welfare Advisory Group Members

**Dependencies:**

- Draft ToR for Animal Welfare Advisory Group v0.1

### 18. Finalize and approve the Terms of Reference for the Animal Welfare Advisory Group.

**Responsible Body/Role:** Project Steering Committee

**Suggested Timeframe:** Project Week 18

**Key Outputs/Deliverables:**

- Approved ToR for Animal Welfare Advisory Group

**Dependencies:**

- Feedback Summary from Animal Welfare Advisory Group Members

### 19. Hold the inaugural meeting of the Animal Welfare Advisory Group to establish animal welfare policies.

**Responsible Body/Role:** Animal Welfare Advisory Group

**Suggested Timeframe:** Project Week 19

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- Approved ToR for Animal Welfare Advisory Group