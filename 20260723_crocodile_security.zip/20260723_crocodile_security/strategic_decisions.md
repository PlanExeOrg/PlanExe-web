## Primary Decisions
The vital few decisions that have the most impact.


The five Critical levers—Regulatory Pathway Design, Capital Deployment and Risk Management, Escape-Prevention Engineering Philosophy, Animal Sourcing Strategy, and Market Entry Sequencing—address the fundamental tensions of this venture: legal viability versus operational readiness, scarce capital versus ambitious scope, existential containment risk versus cost efficiency, biological supply chain integrity versus third-party dependency, and the reference case that validates the entire business model. These levers collectively govern whether Crocodile Security can legally operate, financially survive, physically deliver a safe product, biologically source its core input, and commercially validate its concept. The remaining High and Medium levers represent important optimizations and secondary strategic choices that become consequential only after these foundational pillars are secured.

### Decision 1: Market Entry Sequencing
**Lever ID:** `b3575d82-1c84-41af-a621-b33615a44889`

**The Core Decision:** Determines the order and type of Crocodile Security's first commercial engagements, shaping whether the company enters the market as a proven government-grade specialist or a diversified niche vendor. The sequencing choice directly establishes the reference case that all subsequent sales cycles reference, influencing perceived credibility, pricing power, and the psychological weight of the moat concept itself.

**Why It Matters:** The first contract establishes the company's reputation and reference case, determining whether subsequent clients perceive Crocodile Security as a proven specialist or an unproven novelty. Securing the Ketziot-style reference deal early de-risks the sales cycle for all future contracts but concentrates the company's fortunes on a single government client whose political priorities may shift. Delaying to pursue multiple smaller pilots diversifies early revenue but risks missing the 18-month first-contract deadline and losing momentum in a market where being first matters.

**Strategic Choices:**

1. Pursue the Ketziot-style government contract as the primary target, structuring the entire sales effort around matching the NIS 21 million benchmark at a 20 percent discount.
2. Split efforts between a government contract and a private billionaire compound deal, hedging against political delays in the public sector.
3. Prioritize a smaller piranha-stocked moat pilot for a private client to demonstrate the concept rapidly and generate a reference case within months rather than years.

**Trade-Off / Risk:** Focusing entirely on one government contract mirrors the Ketziot dependency, but if that ministry's budget cycle shifts or a political scandal redirects funds, the company has no fallback revenue and no reference case to show other buyers.

**Strategic Connections:**

**Synergy:** Amplifies Tranche-Gated Milestone Architecture because the first contract triggers the next capital tranche, and reinforces Narrative Architecture and Mythos as the inaugural deal becomes the founding legend that attracts future clients.

**Conflict:** Constrains Controversial Client Boundary because a government-first strategy may lock the company into politically sensitive contracts that test its policy of accepting all clients, and competes with Product Portfolio Positioning by concentrating resources on a single large-scale offering.

**Justification:** *Critical*, The first contract establishes the reference case that all subsequent sales cycles reference, directly determining whether Crocodile Security is perceived as a proven specialist or an unproven novelty. This lever concentrates the company's early fortunes on a single client type and shapes pricing power, credibility, and the psychological weight of the moat concept itself for every future engagement.

### Decision 2: Animal Sourcing Strategy
**Lever ID:** `358e5f9b-be19-4396-b6fa-f1f6addb30e5`

**The Core Decision:** Defines how Crocodile Security procures and manages its live Nile crocodile inventory, balancing capital investment in proprietary breeding infrastructure against dependency on third-party Lake Nasser farms. This lever determines unit economics, CITES compliance viability, supply chain resilience, and the company's ability to maintain consistent animal welfare standards across all deployed moats.

**Why It Matters:** Nile crocodile sourcing determines both the unit economics of each moat and the company's ability to maintain CITES-compliant export chains. Building proprietary breeding stock at Lake Nasser farms gives long-term cost control and supply certainty but requires significant upfront investment in husbandry infrastructure and veterinary capacity. Relying on purchased juveniles from existing farms preserves seed capital for engineering and sales but creates dependency on third-party suppliers whose pricing and availability fluctuate with regional demand.

**Strategic Choices:**

1. Establish a dedicated crocodile breeding and rearing facility near Lake Nasser, investing founder capital in hatchery infrastructure to achieve self-sufficiency within three years.
2. Negotiate exclusive long-term supply agreements with three existing Lake Nasser crocodile farms, locking in volume and pricing without owning the breeding stock.
3. Develop a hybrid model purchasing juveniles for immediate contracts while simultaneously building a small proprietary breeding program as a parallel capability.

**Trade-Off / Risk:** Exclusive supply agreements preserve seed capital for moat engineering, but they transfer pricing power to farms that may face their own regulatory scrutiny or drought-driven stock losses.

**Strategic Connections:**

**Synergy:** Strengthens Animal Welfare as Strategic Asset because proprietary breeding gives direct control over welfare standards that underpin the company's audited welfare program and PR shield, and supports Regulatory Pathway Design by ensuring CITES-compliant sourcing chains.

**Conflict:** Competes with Capital Deployment and Risk Management because building proprietary breeding infrastructure consumes seed capital that the tranche structure reserves for other priorities, and limits Product Portfolio Positioning flexibility since sourcing chains optimized for crocodiles do not easily extend to piranha or saltwater variants.

**Justification:** *Critical*, Without Nile crocodiles sourced from Lake Nasser farms under CITES-compliant chains, there is no product to sell. This lever determines unit economics, supply chain resilience, and the viability of the audited welfare program. It is the biological foundation upon which every moat installation depends.

### Decision 3: Regulatory Pathway Design
**Lever ID:** `6a89c6aa-a362-44c0-ab7f-704b47b19bad`

**The Core Decision:** Establishes the legal architecture enabling the entire business model, centered on the 'tended wild animal' reclassification that makes Nile crocodile moats lawful. This lever encompasses securing CITES export permits, amending wildlife classifications across client jurisdictions, and navigating the regulatory landscape that transforms a security concept into a legally deployable product.

**Why It Matters:** The 'tended wild animal' reclassification is the legal foundation upon which the entire business model rests, making regulatory strategy inseparable from product strategy. Leading with regulatory consulting generates early revenue and builds government relationships that can convert into moat contracts, but it also means the company is selling legal opinions before it has a completed project to demonstrate capability. Waiting to secure its own reference moat before offering consulting services builds credibility but delays a revenue stream that could fund the expensive permit-acquisition process.

**Strategic Choices:**

1. Launch the regulatory consulting arm immediately, offering wildlife classification amendment services to prospective moat clients as a revenue-generating precursor to construction contracts.
2. Complete the first full turnkey moat installation to establish a proven case study, then offer regulatory consulting as a premium advisory service backed by demonstrated results.
3. Partner with an established international wildlife law firm to co-brand regulatory services, leveraging their existing government relationships while Crocodile Security focuses on engineering.

**Trade-Off / Risk:** Co-branding with an established law firm accelerates market access but dilutes the company's positioning as the sole specialist, potentially reducing consulting margins and creating a dependency on a partner who could eventually serve competitors.

**Strategic Connections:**

**Synergy:** Enables Market Entry Sequencing because regulatory clearance is the prerequisite for any contract signing, and reinforces Animal Welfare as Strategic Asset because a credible welfare program provides the evidentiary foundation that regulators require before granting classification amendments and export permits.

**Conflict:** Constrains Product Portfolio Positioning because regulatory pathways established for Nile crocodiles may not transfer to piranha or saltwater variants, requiring separate legal frameworks, and tensions with Controversial Client Boundary as regulatory consulting may require representing governments whose policies the company's client policy otherwise welcomes.

**Justification:** *Critical*, The 'tended wild animal' reclassification is the legal foundation upon which the entire business model rests. Without CITES permits and wildlife classification amendments, no contract can be signed, no animal can be sourced, and no moat can be deployed. This lever is the absolute prerequisite for all other strategic activity.

### Decision 4: Capital Deployment and Risk Management
**Lever ID:** `3e800c50-afe2-4181-8e50-71af742af95e`

**The Core Decision:** Governs the allocation of the $10 million seed capital across the three gated tranches of $2 million, $3 million, and $5 million, determining whether early spending prioritizes physical headquarters construction, revenue-generating sales and permitting, or balanced parallel tracks. This lever sets the financial rhythm that determines whether the company builds credibility through presence or through early contracts.

**Why It Matters:** The gated tranche structure of $2 million, $3 million, and $5 million creates natural decision gates where the founders must demonstrate progress before accessing later capital, but it also means the company cannot pivot quickly if early assumptions prove wrong. Deploying the first tranche aggressively on headquarters construction and infrastructure signals commitment to clients and recruits talent, but leaves little reserve for the unexpected costs inherent in working with live animals in arid environments. Conserving the initial tranche for client-facing activities accelerates revenue generation but may compromise the physical foundation on which the company's credibility rests.

**Strategic Choices:**

1. Allocate the first $2 million tranche primarily to headquarters construction and the demonstration pool facility, establishing a physical symbol of the company's commitment before pursuing clients.
2. Direct the initial $2 million toward sales, permitting, and animal sourcing infrastructure, prioritizing revenue-generating and legally essential activities over physical headquarters buildout.
3. Split the first tranche evenly between headquarters readiness and client acquisition, maintaining parallel tracks of physical presence and commercial momentum.

**Trade-Off / Risk:** Prioritizing sales and permits over headquarters construction accelerates the path to first revenue, but conducting negotiations from a temporary facility undermines the theatrical credibility that distinguishes this company from conventional security vendors.

**Strategic Connections:**

**Synergy:** Directly operationalizes Tranche-Gated Milestone Architecture because the tranche structure is the mechanism through which capital is released based on demonstrated progress, and amplifies Headquarters as Brand or Burden since the first tranche allocation determines whether the fortress headquarters becomes a powerful brand symbol or a financial liability.

**Conflict:** Constrains Product Portfolio Positioning because capital scarcity forces prioritization of the core crocodile moat over piranha and saltwater variants, and limits Handler Corps Development because funding for ceremonial handler training competes with the infrastructure and engineering expenditures that the tranche structure must cover.

**Justification:** *Critical*, The $10 million seed budget in gated tranches is the binding constraint on every other lever. How capital is allocated between headquarters construction, sales, permitting, animal sourcing, and handler training determines whether the company can execute its first contract, achieve cash flow by month 30, or collapses under fixed costs before revenue arrives.

### Decision 5: Escape-Prevention Engineering Philosophy
**Lever ID:** `75f56646-7b6f-416c-9fa3-c9796455f016`

**The Core Decision:** Escape-Prevention Engineering Philosophy determines the foundational containment strategy upon which the entire business model rests, because a single crocodile breach would violate both the zero-injury success criterion and the independently audited welfare program that serves as the company's PR shield. The chosen philosophy—purely mechanical, behavioral conditioning, or hybrid—sets the capital expenditure profile, ongoing maintenance burden, and the credibility of safety claims presented to institutional buyers. The engineering choice is effectively an existential risk-management decision, not merely a technical one.

**Why It Matters:** The entire business model collapses if a single crocodile breaches its moat, because the zero-injury success criterion and the independently audited welfare program both depend on containment integrity. The engineering philosophy chosen—whether it prioritizes physical barriers, behavioral conditioning, or hybrid systems—determines capital expenditure, maintenance burden, and the credibility of the company's safety claims.

**Strategic Choices:**

1. Design moats with redundant physical barriers including submerged electrified fencing, overhanging acrylic walls preventing climbing-out, and dual-gate entry chambers, treating escape prevention as a purely mechanical problem that tolerates no single point of failure.
2. Invest primarily in behavioral conditioning of individual crocodiles using negative-reinforcement boundary training, treating the animals themselves as the primary containment system and reducing reliance on hardware that corrodes in arid-water environments.
3. Adopt a hybrid philosophy where physical barriers handle the majority of containment while a trained handler corps provides real-time behavioral intervention during client events, accepting a marginally higher hardware cost in exchange for a human-in-the-loop safety layer that satisfies auditor requirements.

**Trade-Off / Risk:** A purely mechanical approach minimizes the catastrophic tail risk of a single animal escape but inflates upfront construction costs by an estimated 30 percent, whereas behavioral conditioning lowers capital intensity but introduces an irreducible variable—the animal's unpredictable stress response during high-profile events.

**Strategic Connections:**

**Synergy:** This lever amplifies Animal Welfare as Strategic Asset, because robust escape prevention is the prerequisite for maintaining the zero-violation record that makes the welfare program a credible PR shield rather than a liability. It also depends on Handler Corps Development, since the hybrid philosophy requires a human-in-the-loop safety layer that only a trained corps can provide.

**Conflict:** This lever constrains Capital Deployment and Risk Management, because the purely mechanical approach inflates upfront construction costs by an estimated 30 percent, consuming capital allocated elsewhere. It also tensions with Pricing the Psychological Perimeter, as higher engineering costs may force the company to abandon its 20-percent-discount strategy against the Ketziot benchmark.

**Justification:** *Critical*, The entire business model collapses if a single crocodile breaches its moat, violating both the zero-injury success criterion and the independently audited welfare program that serves as the company's PR shield. This existential risk lever determines capital expenditure profiles and maintenance burdens, and a single failure would destroy the company's credibility irreversibly.

---
## Secondary Decisions
These decisions are less significant, but still worth considering.

### Decision 6: Product Portfolio Positioning
**Lever ID:** `ab31115a-e54e-416b-a266-c4e257c1bf20`

**The Core Decision:** Shapes the balance between the core Nile crocodile moat and alternative offerings including piranha-stocked moats for restrictive jurisdictions and the saltwater variant for coastal sites. This lever determines whether Crocodile Security presents a focused specialist identity or a diversified security portfolio, directly affecting resource allocation, brand clarity, and the addressable market breadth.

**Why It Matters:** The piranha moat variant exists to address markets where large reptile regulations create barriers, but developing it diverts engineering and biological resources from the core crocodile offering. Prioritizing the crocodile moat exclusively concentrates the brand on its most distinctive and defensible product, but leaves the company without a lower-priced entry point for budget-constrained clients who might otherwise become long-term customers. Developing both simultaneously signals market breadth but risks spreading a $10 million seed budget too thin across unproven product lines.

**Strategic Choices:**

1. Focus exclusively on Nile crocodile moats until the core product achieves three reference installations, deferring piranha and saltwater variants to a later growth phase.
2. Develop the piranha moat in parallel as a lower-cost market entry product, using it to build a client base that can be upsold to crocodile systems.
3. Position the saltwater variant as the flagship offering for coastal clients from the outset, treating the freshwater crocodile moat as a secondary option for inland sites.

**Trade-Off / Risk:** Deferring piranha moats preserves engineering focus but forfeits the only product line that can penetrate jurisdictions where large reptile permits face political opposition.

**Strategic Connections:**

**Synergy:** Reinforces Pricing the Psychological Perimeter because a tiered product portfolio allows differentiated pricing strategies across client segments, and supports Market Entry Sequencing by providing lower-cost entry products that can accelerate first-contract timelines while the flagship crocodile moat matures.

**Conflict:** Tensions with Capital Deployment and Risk Management because developing multiple product lines strains the $10 million seed budget across unproven offerings, and competes with Animal Sourcing Strategy since each variant requires distinct biological supply chains, veterinary capabilities, and habitat engineering expertise.

**Justification:** *High*, The choice between focusing exclusively on crocodile moats versus developing piranha and saltwater variants determines brand clarity, resource allocation across the $10 million budget, and addressable market breadth. Each variant requires distinct biological supply chains and engineering expertise that strain a first venture's capacity.

### Decision 7: Animal Welfare as Strategic Asset
**Lever ID:** `43e09828-2d3a-4b35-b6e5-798fd31acdf8`

**The Core Decision:** Animal Welfare as Strategic Asset positions the independently audited welfare program as a core commercial differentiator rather than a compliance obligation. Its scope spans veterinary protocols, habitat quality standards, feeding logistics, and the audit framework itself, with success measured by zero violations, audit certification strength, and whether welfare investment translates into premium pricing power or contract wins. Beyond the stated shield function, rigorous welfare standards also serve as a talent magnet for specialized veterinary staff and handlers, and as a barrier to entry against would-be competitors who cannot match the operational sophistication of Crocodile Security's care protocols.

**Why It Matters:** The independently audited animal welfare program functions as both a moral shield and a commercial differentiator, but its rigor directly affects operating costs and the speed of scaling. Setting welfare standards above regulatory minimums builds an unassailable PR position and justifies premium pricing, but the cost of exceeding compliance requirements consumes capital that could fund additional moat installations. Aligning welfare protocols precisely with the minimum audit thresholds keeps costs manageable and permits faster expansion, but leaves the company vulnerable to a single activist campaign that reframes adequate care as inadequate.

**Strategic Choices:**

1. Adopt welfare standards that exceed independent audit requirements by a meaningful margin, positioning ethical excellence as the company's primary brand identity and pricing justification.
2. Meet audit thresholds precisely while investing in transparent real-time monitoring technology that allows clients and the public to verify welfare conditions independently.
3. Treat welfare compliance as a purely operational function managed by veterinary staff, keeping the audit program at arm's length from marketing and client-facing messaging.

**Trade-Off / Risk:** Exceeding welfare standards builds brand insulation but raises per-moat costs enough to erode the 20 percent pricing advantage that wins contracts against incumbent security vendors.

**Strategic Connections:**

**Synergy:** This lever amplifies Animal Sourcing Strategy, because exceeding welfare standards requires sourcing from higher-quality Nile crocodile farms around Lake Nasser, and reinforces Narrative Architecture and Mythos, since the welfare story becomes a foundational pillar of the company's origin narrative and public identity.

**Conflict:** This lever constrains Pricing the Psychological Perimeter, because exceeding welfare standards raises per-moat costs enough to erode the 20 percent pricing advantage that wins contracts, and tensions Capital Deployment and Risk Management, since welfare overinvestment consumes seed capital that could fund additional installations.

**Justification:** *High*, The independently audited welfare program functions as both a moral shield and a commercial differentiator, but its rigor directly affects operating costs and the 20 percent pricing advantage. Exceeding standards builds brand insulation but erodes margins; meeting thresholds precisely leaves vulnerability to activist campaigns.

### Decision 8: Geographic Expansion Logic
**Lever ID:** `cc347765-b8c8-40f6-b0fe-17457287a96f`

**The Core Decision:** Geographic Expansion Logic governs the temporal and spatial sequencing of entering new continental markets, balancing climate compatibility, regulatory familiarity, relationship proximity, and brand positioning against the year-seven goal of a stocked moat on every inhabited continent. Success is measured by time-to-first-contract per region, the operational sustainability of each outpost, and whether the sequencing strengthens or fragments the veterinary and maintenance networks. A deeper insight is that geographic sequencing also determines which Nile crocodile genetic lineages are deployed in which climates, shaping long-term adaptation strategies and whether the company builds regional expertise hubs or relies on traveling teams from the fortress headquarters.

**Why It Matters:** The year-seven goal of a stocked moat on every inhabited continent is aspirational, and the sequence in which continents are entered determines whether the company builds sustainable operational capabilities or merely scatters under-resourced outposts. Prioritizing Middle Eastern and Gulf states first leverages existing relationships, regulatory familiarity, and climate compatibility, but risks the perception that the company serves only authoritarian regimes and limits its global brand. Entering a diverse mix of continents simultaneously demonstrates global ambition and attracts international media attention, but fragments the limited management bandwidth and veterinary expertise needed to maintain quality across distant sites.

**Strategic Choices:**

1. Sequence expansion by political and regulatory proximity, securing Gulf Cooperation Council and North African contracts first before attempting European or Asian markets.
2. Target one marquee installation on each inhabited continent simultaneously, accepting thinner margins and higher coordination costs to establish the global brand immediately.
3. Follow the capital, prioritizing whichever continent's wealthiest private clients and most security-conscious governments respond first, regardless of geographic logic.

**Trade-Off / Risk:** Following the capital without geographic discipline may yield early contracts in unexpected markets, but scattered installations across incompatible climates and regulatory regimes strain the veterinary and maintenance networks that ensure animal welfare.

**Strategic Connections:**

**Synergy:** This lever synergizes with Regulatory Pathway Design, because each continent's entry depends on amending wildlife classifications of the 'tended wild animal' variety, and the sequence in which those pathways are tackled determines early momentum. It also reinforces Animal Sourcing Strategy, since regional expansion may eventually allow local crocodile populations to supplement farm-sourced animals and reduce transport mortality.

**Conflict:** This lever conflicts with Capital Deployment and Risk Management, because simultaneous multi-continent expansion fragments the seed budget and gated tranches across incompatible climates and regulatory regimes. It also strains Moat Engineering Depth, since different continents present divergent excavation and water management challenges that may require distinct engineering approaches the company has not yet standardized.

**Justification:** *Medium*, The year-seven goal of a stocked moat on every inhabited continent is aspirational, and sequencing determines operational sustainability. However, for a first venture targeting its first contract within 18 months, geographic expansion logic is a long-term consideration rather than a critical path lever.

### Decision 9: Moat Engineering Depth
**Lever ID:** `9062e122-dbb2-47ca-9e8a-fe3dea9e41de`

**The Core Decision:** Moat Engineering Depth determines the degree of vertical integration in physical moat construction — specifically how much excavation, water management, and reinforced glass installation is performed by dedicated in-house crews versus subcontracted to local marine construction firms. Success metrics include escape-prevention reliability rates, capital efficiency per contract, and construction quality consistency across sites. A less obvious dimension is that in-house construction accumulates tacit knowledge about crocodile behavior in different aquatic environments, generating site-specific engineering intuition that improves habitat design over time, whereas a subcontracting model keeps the company as a design-only firm that never develops that embodied expertise.

**Why It Matters:** Deciding how much of the moat's physical construction to perform in-house versus subcontract to local excavation and marine construction firms determines both quality control over escape-prevention engineering and the capital intensity of each contract. In-house construction lets the company guarantee the reinforced glass specifications and basking-zone thermal design that differentiate a Crocodile Security moat from a generic water barrier, but it ties up the seed budget in equipment and skilled labor before any revenue arrives. Subcontracting accelerates the first contract and preserves cash, yet introduces a dependency on local crews who may not understand why a half-meter gap in the underwater ledge matters when a crocodile tests the perimeter.

**Strategic Choices:**

1. Build a dedicated excavation and marine construction crew from the fortress base, treating moat engineering as a proprietary capability that justifies the 20 percent price discount through demonstrated escape-prevention reliability rather than cheap labor.
2. Subcontract all physical construction to vetted local marine construction firms in each client jurisdiction, retaining only the habitat design, thermal management, and escape-prevention engineering as in-house intellectual property that travels with the contract.
3. Start with subcontracted construction for the first two contracts to preserve cash and learn the failure modes, then bring excavation and water management in-house only if the repeat-contract pipeline justifies the fixed-cost commitment.

**Trade-Off / Risk:** Bringing moat construction in-house protects escape-prevention quality but consumes capital that the 18-month first-contract timeline cannot afford to tie up before revenue, while subcontracting preserves cash at the cost of quality control over the very detail that makes the product defensible.

**Strategic Connections:**

**Synergy:** This lever amplifies Escape-Prevention Engineering Philosophy, because in-house construction directly embeds escape-prevention thinking into every physical detail of the moat, ensuring the underwater ledge gaps and basking-zone thermal designs are executed precisely. It also reinforces Handler Corps Development, since in-house crews and ceremonial handlers develop shared operational language and safety protocols that subcontracting would dilute.

**Conflict:** This lever conflicts with Capital Deployment and Risk Management, because building a dedicated construction crew consumes seed capital in equipment and skilled labor before any revenue arrives, threatening the 18-month first-contract timeline. It also tensions Animal Welfare as Strategic Asset, since subcontracting may compromise the precise habitat construction that underpins the welfare standards the audit program certifies.

**Justification:** *High*, The decision to build in-house versus subcontract determines quality control over escape-prevention engineering, capital intensity per contract, and whether the company accumulates tacit knowledge about crocodile behavior. In-house construction protects quality but consumes capital before revenue arrives.

### Decision 10: Pricing the Psychological Perimeter
**Lever ID:** `33391909-f909-457c-9e5a-7cb90e327799`

**The Core Decision:** Pricing the Psychological Perimeter governs how the company prices its turnkey moat service relative to the 41,000 USD per meter Ketziot benchmark, balancing the need to win the reference government contract against the risk of anchoring the brand to a public-sector price floor that ignores the symbolic premium royal palaces and bunker communities pay for deterrence spectacle. Success metrics include contract win rate, margin per contract, and whether the pricing structure attracts premium private clients or only price-sensitive government buyers. A subtler insight is that pricing functions as a self-selection mechanism: the price point determines which client segments perceive the moat as a commodity security product versus an exclusive brand statement.

**Why It Matters:** The Ketziot benchmark of roughly 41,000 USD per meter of stocked moat is a construction-and-animal cost reference, not a measure of what a royal palace or a doomsday bunker community will pay for the statement the moat makes. Bidding 20 percent below that benchmark wins the first government contract by being cheaper than an interior ministry improvising its own reptile program, but it also anchors the company's price floor to a public-sector number that ignores the premium clients pay for the spectacle and the deterrence symbolism. Pricing too close to the benchmark leaves money on the table from clients who value the moat as a brand statement, while pricing too high too early risks losing the reference contract that validates the entire business model.

**Strategic Choices:**

1. Bid 20 percent below the Ketziot benchmark for the first contract to secure the reference deal and the publicity that comes with a government client, then introduce a tiered pricing model that charges a premium for the ceremonial handler program, the reinforced glass boardroom-grade specifications, and the multi-year maintenance contract.
2. Price every contract as a fully loaded turnkey package with no per-meter discount logic, letting the client's budget and the statement value set the price, and use the Ketziot number only as a cost reference for internal margin discipline rather than as a published price anchor.
3. Offer the first contract at the 20 percent discount but structure it as a loss-leader with a deliberately high-margin multi-year maintenance and animal-replacement contract, so the initial price wins the deal while the recurring revenue carries the venture's economics.

**Trade-Off / Risk:** Anchoring price to the Ketziot benchmark wins the first government contract but risks training the market to expect a public-sector price for a product whose value to royal palaces and bunker communities is largely symbolic, while ignoring that anchor leaves money on the table if the reference deal does not materialize.

**Strategic Connections:**

**Synergy:** This lever synergizes with Product Portfolio Positioning, because tiered pricing should map cleanly onto the product portfolio — crocodile moats, piranha-stocked variants, and the saltwater option — allowing each tier to carry its own value logic. It also reinforces Client Ceremonial Design, since premium pricing can bundle the ceremonial handler program in black uniforms as a value-add that justifies the markup beyond raw construction and animal costs.

**Conflict:** This lever conflicts with Animal Welfare as Strategic Asset, because pricing too low to secure the reference contract constrains the budget available for exceeding welfare standards, undermining the PR shield. It also tensions Capital Deployment and Risk Management, since the pricing model determines cash flow timing and margin structure that must align with the tranche-gated seed funding schedule.

**Justification:** *High*, Pricing relative to the 41,000 USD per meter Ketziot benchmark determines revenue viability, client segmentation, and whether the brand is perceived as a commodity security product or an exclusive statement. The 20 percent discount strategy wins the reference contract but risks anchoring the brand to a public-sector price floor.

### Decision 11: Controversial Client Boundary
**Lever ID:** `581092fb-c02f-4a66-b517-73b8e09984f2`

**The Core Decision:** Controversial Client Boundary defines the ethical and reputational perimeter of the client base, determining whether Crocodile Security accepts all comers under its 'no client is too controversial, only insufficiently ambitious' policy or establishes written criteria for exclusion. Success metrics include revenue diversity, the frequency and severity of reputational risk incidents, and whether the client boundary policy strengthens or undermines the animal welfare audit as a PR shield. A deeper insight is that this decision is inseparable from the founder's identity as a reclusive excavation magnate — it determines whether the company is perceived as a neutral specialist vendor or as an entity with implicit values that attract or repel different client archetypes.

**Why It Matters:** The stated policy that no client is too controversial, only insufficiently ambitious, is a deliberate brand position that maximizes the addressable market across corrections ministries, royal palaces, and private compounds, but it also means the company will eventually take a client whose actions generate sustained negative publicity that lands on the crocodile moat rather than on the client. The independently audited animal welfare program is designed as a PR shield, but an audit that certifies humane treatment of animals guarding a widely condemned facility does not neutralize the reputational association; it may amplify it by making the operation look deliberate and polished. Drawing no boundary maximizes early revenue and the 'specialist vendor beats every interior ministry' narrative, but it also means the company cannot distance itself from a client when that client becomes a diplomatic or media liability.

**Strategic Choices:**

1. Maintain the no-boundary policy explicitly and invest in the animal welfare audit as the sole reputational buffer, accepting that the company will be associated with whatever client it serves and that the fortress headquarters and ceremonial handlers are part of that deliberate identity.
2. Adopt a written client-acceptance standard that excludes clients under active international sanctions or ICC investigation, framing the boundary as a risk-management decision rather than a moral one, so the company can decline a pariah client without abandoning the broader controversial-client market.
3. Take the no-boundary stance for the first three contracts to prove the market and the reference deal, then introduce a client-review process once the company has enough revenue and enough public attention that a single controversial client can threaten the operating cash flow target.

**Trade-Off / Risk:** The no-boundary policy maximizes the early market and reinforces the specialist-vendor narrative, but it also guarantees that when a client becomes a diplomatic or media liability, the reputational damage lands on the crocodile moat and the welfare audit that was supposed to shield it.

**Strategic Connections:**

**Synergy:** This lever amplifies Narrative Architecture and Mythos, because the client boundary policy — or the deliberate absence of one — becomes a defining element of the company's founding story and public mythology. It also reinforces Animal Welfare as Strategic Asset, since the welfare audit's effectiveness as a reputational buffer depends heavily on whether the client base generates sustained negative attention that overwhelms the shield.

**Conflict:** This lever conflicts with Market Entry Sequencing, because a no-boundary policy may open markets in regions or client categories that a written exclusion standard would close, altering which geographies are viable first-mover targets. It also tensions Competitive Imitation Defense, since a controversial client base may either deter imitators who fear the reputational association or attract them if the controversy generates enough market attention to validate the concept.

**Justification:** *High*, The 'no client is too controversial' policy maximizes the addressable market and reinforces the specialist-vendor narrative, but guarantees that when a client becomes a diplomatic or media liability, the reputational damage lands on the crocodile moat and the welfare audit that was supposed to shield it.

### Decision 12: Headquarters as Brand or Burden
**Lever ID:** `98bf38a0-a83b-4155-833e-8e1b0fb9ac57`

**The Core Decision:** The converted Ottoman-era fortress headquarters functions as both the company's most persuasive sales instrument and its largest pre-revenue fixed-cost liability. The reinforced-glass boardroom above the demonstration pool creates an unmatched client experience that can convert high-value contracts, but it also concentrates the company's entire public identity at a single physical location where any welfare incident or security breach would be catastrophic. Success is measured by whether fortress-hosted client visits produce a measurable contract-close rate that justifies the capital consumed before the first revenue arrives.

**Why It Matters:** The converted Ottoman-era fortress on a Nile island with a reinforced-glass boardroom above the demonstration pool is a powerful sales environment that lets prospective clients negotiate price while crocodiles circle beneath them, but it is also a fixed-cost asset that consumes capital and management attention before the first contract arrives. If the fortress functions primarily as a demonstration and training site that wins contracts, its cost is justified by the deals it helps close; if it functions primarily as a vanity project that the founder wants regardless of commercial outcome, it competes with the seed budget that should fund the first moat, the CITES permits, and the veterinary team. The fortress also creates a single physical point of failure for the company's public identity: a welfare incident or a security breach at the headquarters damages the brand far more than an incident at a remote client site.

**Strategic Choices:**

1. Treat the fortress as a dedicated demonstration, training, and animal-holding facility that directly supports contract wins and handler certification, and fund it from the earliest seed tranche only if the projected contract pipeline makes the demonstration visits a measurable sales tool rather than a spectacle.
2. Defer the full fortress conversion and instead operate a smaller demonstration pool at a lower-cost site for the first 18 months, reserving the fortress renovation for a later tranche once the first contract revenue justifies the brand investment and the company has proven it can win deals without it.
3. Build the fortress as the company's public identity from day one, accepting that it will consume capital and become the brand's center of gravity, and design the first contract pipeline to include client visits to the fortress as a deliberate closing tactic rather than an incidental byproduct.

**Trade-Off / Risk:** The fortress boardroom is a compelling sales environment that can help close high-value clients, but it is also a fixed-cost asset that competes with the seed capital needed for the first contract, the CITES permits, and the veterinary team, and it concentrates brand risk at a single physical location.

**Strategic Connections:**

**Synergy:** This lever amplifies Narrative Architecture and Mythos, because the fortress is the physical embodiment of the founder's moat-revival story, making the narrative tangible and visitable. It also enables Handler Corps Development by providing a dedicated on-site academy where ceremonial protocols are drilled inside the same environment clients will experience.

**Conflict:** This lever constrains Capital Deployment and Risk Management, because the fortress renovation competes directly with seed capital needed for CITES permits, the veterinary team, and the first moat construction. It also conflicts with Tranche-Gated Milestone Architecture, as early fortress spending may consume the first tranche before externally verifiable milestones like permit approval are achieved.

**Justification:** *High*, The Ottoman-era fortress with its reinforced-glass boardroom above the demonstration pool is the company's most persuasive sales instrument and its largest pre-revenue fixed-cost liability. It concentrates the entire public identity at a single location where any incident would be catastrophic, while consuming capital needed for CITES permits and the first moat.

### Decision 13: Handler Corps Development
**Lever ID:** `9d599b4f-4809-40ec-a7d6-c28a4252ea95`

**The Core Decision:** Handler Corps Development addresses the narrow talent pipeline required to staff contracts on schedule while maintaining the theatrical black-uniform standard that justifies premium pricing. Each handler must be cross-trained in reptile behavior, client-service etiquette, and emergency protocol, creating a specialized workforce that is difficult to scale rapidly. The chosen recruitment path—academy, farm-hand retraining, or hospitality recruitment—determines whether the company can meet its first-contract staffing deadline without sacrificing the ceremonial differentiation that separates Crocodile Security from a generic wildlife contractor.

**Why It Matters:** Recruiting and training a specialized corps of ceremonial black-uniformed handlers determines whether the company can staff its first contract on schedule and maintain the theatrical standard that justifies premium pricing. Each handler requires cross-training in reptile behavior, client-service etiquette, and emergency protocol, creating a narrow talent pipeline that is difficult to scale quickly.

**Strategic Choices:**

1. Establish a dedicated handler academy on the Nile island headquarters, running a four-month residential program that combines Egyptian crocodile-farm apprenticeship with protocol training in ceremonial hospitality, producing a fixed annual cohort of graduates bound by multi-year service contracts.
2. Partner with Egypt's existing crocodile-farm labor pool and retrain experienced farm hands through an accelerated eight-week certification program, accepting lower ceremonial polish in exchange for immediate staffing volume and deep animal-handling familiarity.
3. Recruit from the hospitality and event-staging industries, hiring professionals accustomed to high-profile client environments and retraining them in crocodile behavior through a partnership with a zoological institution, prioritizing service demeanor over prior animal experience.

**Trade-Off / Risk:** Building a self-contained academy ensures cultural control and ceremonial consistency but delays first-contract staffing by months, whereas retraining farm hands accelerates deployment at the cost of the theatrical polish that differentiates Crocodile Security from a mere wildlife contractor.

**Strategic Connections:**

**Synergy:** This lever synergizes with Escape-Prevention Engineering Philosophy, because the hybrid containment approach explicitly depends on a trained handler corps providing real-time behavioral intervention during client events. It also reinforces Client Ceremonial Design, as the handlers are the living embodiment of the ceremonial experience that makes the moat service feel authoritative rather than utilitarian.

**Conflict:** This lever conflicts with Capital Deployment and Risk Management, because establishing a dedicated handler academy consumes seed capital that could fund the first moat or CITES permits. It also tensions with Moat Engineering Depth, as investment diverted to human capital reduces the budget available for redundant physical barrier systems.

**Justification:** *Medium*, The specialized corps of ceremonial black-uniformed handlers determines whether contracts can be staffed on schedule and whether the theatrical standard justifying premium pricing is maintained. The narrow talent pipeline is difficult to scale, but this is an execution lever rather than a strategic pivot point.

### Decision 14: Narrative Architecture and Mythos
**Lever ID:** `48dfc09e-61b4-4580-89fb-0d4aeb092bbb`

**The Core Decision:** Narrative Architecture and Mythos transforms the founder's personal conviction that perimeter security lost its way when the world abandoned the moat into the company's primary sales argument for clients paying a premium above conventional fencing. How this story is constructed—whether as ancient lineage revival, technology-forward innovation, or founder-as-myth embodied by the fortress—determines whether high-value clients perceive Crocodile Security as a serious security vendor or a novelty operation, directly affecting contract conversion rates and the sustainability of the price premium.

**Why It Matters:** The founder's conviction that perimeter security lost its way when the world abandoned the moat is not merely a founding story but the primary sales argument for clients paying a 20 percent discount to the Ketziot benchmark. How this narrative is constructed, propagated, and authenticated determines whether clients perceive Crocodile Security as a serious security vendor or a novelty operation, directly affecting conversion rates on high-value contracts.

**Strategic Choices:**

1. Position the company as the revival of an ancient security paradigm, publishing a white paper on the historical lineage of crocodile moats from Ottoman fortifications through Pharaonic defenses, and requiring all client materials to reference this lineage to establish gravitas and historical legitimacy.
2. Frame the offering as a technology-forward security innovation, emphasizing the engineering, thermal-management systems, and escape-prevention hardware as a modern product line, deliberately downplaying the historical narrative to avoid appearing antiquated to government procurement officers.
3. Let the founder's reclusive persona and the Ottoman-fortress headquarters serve as the primary narrative vehicles, minimizing published materials and instead relying on in-person site visits where the physical environment itself communicates the company's seriousness and commitment.

**Trade-Off / Risk:** Anchoring the brand in historical lineage differentiates Crocodile Security from competitors but risks alienating procurement officers who associate crocodile moats with backwardness, whereas a technology-forward framing attracts institutional buyers but erodes the mythological premium that justifies the price point.

**Strategic Connections:**

**Synergy:** This lever amplifies Competitive Imitation Defense, because a deeply rooted historical narrative creates a mythological moat that competitors cannot easily replicate through engineering alone. It also reinforces Headquarters as Brand or Burden, since the fortress itself is the most powerful narrative artifact, making the physical site inseparable from the brand story.

**Conflict:** This lever conflicts with Product Portfolio Positioning, because the historical crocodile-moat narrative does not transfer cleanly to piranha-stocked moats or the saltwater variant, potentially fragmenting the brand as the portfolio expands. It also tensions with Controversial Client Boundary, as the mythological framing may attract clients whose controversy level the company's 'no client is too controversial' policy was designed to accommodate without brand damage.

**Justification:** *High*, The founder's conviction that perimeter security lost its way with the moat is the primary sales argument justifying premium pricing above conventional fencing. How this story is constructed determines whether high-value clients perceive Crocodile Security as a serious vendor or a novelty operation, directly affecting contract conversion rates.

### Decision 15: Tranche-Gated Milestone Architecture
**Lever ID:** `54da7d38-01e0-4c83-8b3f-ead41f415bb1`

**The Core Decision:** Tranche-Gated Milestone Architecture governs the release of the 10 million USD seed capital across three gated tranches of 2, 3, and 5 million, determining whether the company can execute its first contract, secure CITES permits, and achieve positive cash flow by month 30. The critical design challenge is calibrating milestone difficulty: gates must be achievable enough to avoid starving operations, yet verifiable enough to protect the Gulf family-office investor. The architecture creates a structural dependency where a single delayed permit or contract signature can freeze the entire operating budget.

**Why It Matters:** The 10 million USD seed capital is deployed in gated tranches of 2, 3, and 5 million, and the timing of each release determines whether the company can execute its first contract, secure CITES permits, and achieve positive cash flow by month 30. The milestones gating each tranche must be calibrated to be achievable but not trivially met, because premature capital release wastes runway while overly restrictive gating starves operations.

**Strategic Choices:**

1. Gate the first 2 million on CITES-compliant export permit approval, the second 3 million on signing the first paid contract, and the final 5 million on achieving positive operating cash flow, tying each release to an externally verifiable proof point that de-risks the investor's exposure sequentially.
2. Release tranches on a fixed calendar schedule aligned to the 18-month first-contract timeline, with each tranche available at predetermined dates regardless of milestone achievement, trusting the founding team's execution judgment over investor-imposed proof gates.
3. Gate the first tranche on headquarters completion, the second on hiring a minimum viable handler corps and veterinary staff, and the final on securing a letter of intent from a second prospective client beyond the initial Ketziot-style deal, prioritizing operational readiness over revenue proof.

**Trade-Off / Risk:** Tying capital release to externally verifiable milestones protects the Gulf family-office investor from founder misexecution but creates a dangerous dependency where a single delayed permit or contract signature freezes the entire operating budget, whereas calendar-based release preserves operational flexibility at the cost of investor confidence.

**Strategic Connections:**

**Synergy:** This lever is the operational mechanism for Capital Deployment and Risk Management, translating the investor's risk tolerance into concrete funding gates. It also reinforces Regulatory Pathway Design, because gating the first tranche on CITES-compliant export permit approval directly ties capital availability to regulatory progress, ensuring the company does not spend before it is legally permitted to operate.

**Conflict:** This lever conflicts with Headquarters as Brand or Burden, because if the first tranche is gated on CITES permits rather than fortress completion, the brand-building facility may be delayed or underfunded. It also tensions with Handler Corps Development, because gating the second tranche on hiring milestones may force premature recruitment decisions that compromise the ceremonial quality standards the corps is meant to uphold.

**Justification:** *High*, This lever is the operational mechanism through which Capital Deployment is executed, translating investor risk tolerance into concrete funding gates. It determines when capital becomes available and creates a structural dependency where a single delayed permit or contract signature can freeze the entire operating budget.

### Decision 16: Competitive Imitation Defense
**Lever ID:** `04eaaca0-1d06-47a2-aa3f-29ce319193bc`

**The Core Decision:** This lever defines how Crocodile Security protects its first-mover advantage as governments inevitably attempt to replicate crocodile moat programs in-house. It addresses the fundamental strategic question of whether the company's competitive moat rests on operational lock-in, intellectual property dominance, or supply-chain control. The chosen approach determines whether the company captures one-time construction revenue or durable recurring service income across the full contract lifecycle.

**Why It Matters:** The plan explicitly acknowledges that interior ministries will attempt to improvise their own reptile security programs, and the company's competitive advantage depends on being the specialist vendor rather than having governments develop in-house capability. The defense strategy chosen determines whether Crocodile Security captures recurring maintenance contracts or faces one-time commodity competition from government-run programs.

**Strategic Choices:**

1. Structure every contract to include a multi-year maintenance and animal-replacement clause that makes it operationally and financially impractical for a client to transition to an in-house program, creating lock-in through ongoing dependency on Crocodile Security's veterinary and handler infrastructure.
2. Publish a limited open-source framework of moat-design standards and welfare protocols to establish Crocodile Security as the de facto industry authority, betting that standardization benefits the incumbent most because competitors must then conform to specifications the company already dominates.
3. Pursue exclusive multi-year sourcing agreements with Nile crocodile farms around Lake Nasser, controlling the upstream supply chain to the point where any competitor attempting to build a program faces either supply shortages or prohibitive procurement costs.

**Trade-Off / Risk:** Locking clients into multi-year maintenance contracts protects recurring revenue but may deter governments that insist on sovereign capability, whereas open-sourcing standards risks creating a framework that better-capitalized competitors adopt and improve upon.

**Strategic Connections:**

**Synergy:** This lever amplifies Animal Sourcing Strategy, because exclusive upstream agreements with Lake Nasser farms directly control competitor access to the biological input, making supply-chain lock-in and competitive defense mutually reinforcing.

**Conflict:** This lever constrains Controversial Client Boundary, because multi-year maintenance lock-in may deter sovereign-capability-minded governments that the company's own policy declares are eligible clients regardless of how controversial they are.

**Justification:** *Medium*, Protecting first-mover advantage against interior ministries improvising their own reptile programs is important for long-term durability, but for a first venture focused on securing its initial contracts, competitive defense mechanisms are secondary to establishing the reference case itself.

### Decision 17: Saltwater Variant Feasibility Gate
**Lever ID:** `20dcbce3-ff92-42ba-a2e4-54771945d137`

**The Core Decision:** This lever governs the decision of when and how to extend Crocodile Security's product line from freshwater Nile-crocodile moats to saltwater variants suitable for coastal fortresses and maritime installations. It balances the strategic imperative of geographic completeness against the resource constraints of a first venture, requiring disciplined evaluation of technical feasibility, capital allocation, and market timing before committing to an unproven product extension.

**Why It Matters:** The saltwater moat variant for coastal fortresses is described as under study, and pursuing it prematurely would divert scarce engineering and capital resources from the proven freshwater Nile-crocodile product, while delaying it too long risks ceding the coastal market to a competitor who solves the salinity-corrosion-biology problem first.

**Strategic Choices:**

1. Defer all saltwater-variant investment until three freshwater contracts are signed and generating positive cash flow, treating coastal fortresses as a year-seven expansion target rather than a concurrent development effort, and reallocating the study budget to core product refinement.
2. Commission a parallel feasibility study using 5 percent of the seed budget to test saline-water crocodile viability, thermal tolerance limits, and corrosion-resistant enclosure materials, with a formal go/no-go decision gated at month 18 based on whether the study demonstrates technical and economic feasibility.
3. Partner with a coastal-marine engineering firm to co-develop a saltwater prototype at a reduced scale, sharing development costs in exchange for first-right-of-refusal on commercial deployment, thereby accessing marine expertise without bearing the full R&D burden.

**Trade-Off / Risk:** Deferring the saltwater variant preserves focus on the core freshwater product but risks a competitor capturing the coastal market during the delay, whereas a parallel feasibility study consumes scarce seed capital on an unproven product line that may never reach commercial viability.

**Strategic Connections:**

**Synergy:** This lever enables Geographic Expansion Logic, because a viable saltwater product is a prerequisite for securing coastal fortress contracts, which are necessary to achieve the seven-continent stocked-moat goal by year seven.

**Conflict:** This lever conflicts with Capital Deployment and Risk Management, because any seed capital diverted to saltwater feasibility study reduces the disciplined tranche budget available for the proven freshwater core product and its gated milestone schedule.

**Justification:** *Low*, The saltwater variant is explicitly described as 'under study' and is not relevant to the first venture's critical path of securing three contracts or funded pilots by month 24. Deferring this decision preserves focus on the proven freshwater crocodile product.

### Decision 18: Client Ceremonial Design
**Lever ID:** `7e4922e2-728a-4255-a00f-ca05d4cf333e`

**The Core Decision:** This lever specifies how the physical and psychological experience of negotiating inside the reinforced-glass boardroom above the demonstration pool is structured, calibrated, and delivered to prospects. It recognizes that the ceremony itself—the crocodiles, the black-uniformed handlers, the spatial drama—is not merely ambiance but the core sales mechanism that converts psychological awe into contract signatures at premium price points.

**Why It Matters:** The negotiation experience itself—the reinforced-glass boardroom, the crocodiles circling beneath the feet, the ceremonial black-uniformed handlers—is the primary mechanism by which Crocodile Security converts prospects into paying clients at premium price points. The design of this ceremonial experience determines whether the psychological perimeter the company sells is genuinely felt by clients or merely performed, and whether the experience generates word-of-mouth referrals among ultra-high-net-worth individuals and government officials.

**Strategic Choices:**

1. Design the ceremonial experience as a fixed scripted sequence where handlers guide clients through a timed progression from arrival through negotiation to departure, with each phase calibrated to maximize the psychological impact of the crocodile proximity, treating the event as a reproducible product rather than a bespoke service.
2. Build each client's ceremonial experience from scratch around the client's cultural background, security concerns, and personal preferences, accepting higher operational complexity in exchange for a deeply personalized event that generates stronger loyalty and referral potential.
3. Offer three standardized ceremonial tiers—diplomatic, private, and exclusive—each with a predefined script, handler-to-client ratio, and crocodile-pool configuration, allowing prospects to self-select into an experience level that matches their budget and comfort without requiring custom design work.

**Trade-Off / Risk:** A fixed scripted sequence ensures consistency and scalability across multiple concurrent events but risks making the experience feel generic to repeat clients, whereas fully bespoke ceremonies maximize psychological impact per event but cannot be staffed or replicated efficiently as the contract pipeline grows.

**Strategic Connections:**

**Synergy:** This lever amplifies Handler Corps Development, because the ceremonial black-uniformed handlers are the performers of the experience; their training, presence, and discipline directly determine whether the ceremony generates genuine psychological impact or feels hollow.

**Conflict:** This lever constrains Headquarters as Brand or Burden, because the ceremonial experience is anchored to the Ottoman fortress setting; if the headquarters becomes operationally burdensome or inaccessible, the ceremony loses its defining spatial drama and psychological force.

**Justification:** *Medium*, The ceremonial experience is the primary conversion mechanism that turns psychological awe into contract signatures, but it is derivative of Handler Corps Development and Headquarters as Brand. The choice between scripted consistency and bespoke personalization is an operational optimization rather than a foundational strategic choice.
