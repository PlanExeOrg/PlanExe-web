## Positive Constraints

- Headquarters in a converted Ottoman-era fortress on an island in the Nile south of Cairo
- Boardroom floor is a single sheet of reinforced glass suspended above a demonstration pool with twelve adult Nile crocodiles
- Company designs, excavates, and stocks live-crocodile security moats as a turnkey service
- Seed budget of 10 million USD from founder capital plus a Gulf family-office investor
- Budget deployed in gated tranches of 2, 3, and 5 million USD
- First paying contract due within 18 months
- Reference deal size of 5 to 7 million USD (Ketziot-style)
- Three signed contracts or funded pilots by month 24
- CITES-compliant export permits for Nile crocodiles secured in year one
- Zero animal welfare violations
- Zero human injuries
- Positive operating cash flow by month 30
- Stocked moat on every inhabited continent by year seven
- Bidding 20 percent below the Ketziot benchmark of roughly 41,000 USD per meter
- Clientele includes corrections ministries, royal palaces, billionaire island compounds, doomsday bunker communities, gold vaults, and superyacht marinas
- Core offering includes site survey, excavation, water management, crocodile sourcing, habitat design, veterinary care, feeding logistics, handler training, escape-prevention engineering, and multi-year maintenance contracts
- Independently audited animal welfare program
- Secondary tier of piranha-stocked moats for narrower channels or smaller budgets
- Saltwater variant under study for coastal fortresses
- Regulatory consulting revenue line for amending wildlife classifications
- Handlers trained in ceremonial black uniforms

## Negative Constraints

- Do not use AR/VR/NFT/blockchain technologies
- Avoid aggressive scenarios; pick a realistic first venture
- Do not use DAO structures
- Avoid generic ROI fluff in analysis
