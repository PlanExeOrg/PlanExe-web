## Positive Constraints

- Headquartered in a converted Ottoman-era fortress on an island in the Nile south of Cairo
- Seed budget of 10 million USD
- First paying contract due within 18 months
- Ketziot-style deal reference size of 5 to 7 million USD
- Success criteria: three signed contracts or funded pilots by month 24
- CITES-compliant export permits for Nile crocodiles secured in year one
- Zero animal welfare violations
- Zero human injuries
- Positive operating cash flow by month 30
- Stocked moat on every inhabited continent by year seven

## Negative Constraints

- Avoid the most aggressive scenario
