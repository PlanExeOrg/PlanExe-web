Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 19 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 0 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the plan's success require breaking a known law of physics (e.g., thermodynamics, conservation of energy, speed-of-light limit, causality)?*

**Level**: ✅ Low

**Justification**: The plan outlines a business venture focused on creating live-crocodile security moats, which does not require breaking any laws of physics or depend on non-physical mechanisms. It operates within the realm of engineering and animal husbandry, adhering to known physical principles.

**Mitigation**: No physics-related action required — the plan does not invoke physics-incompatible mechanisms.


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan relies on a novel combination of live animals and security solutions without independent evidence of success at scale. This creates a significant risk of failure due to untested assumptions.

**Mitigation**: Project Manager: Develop parallel validation tracks for Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal within 60 days, ensuring each track produces authoritative sources or pilot results.


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks defined frameworks or strategies with clear mechanisms of action, ownership, and measurable outcomes. This creates a strategic blind spot that could hinder effective execution.

**Mitigation**: Project Manager: Assign owners to produce one-pagers detailing value hypotheses, success metrics, and decision hooks within 30 days.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not adequately address second-order risks associated with using live crocodiles, such as legal, safety, and reputational risks. Major hazard classes are minimized, creating potential failure modes.

**Mitigation**: Regulatory Compliance Officer: Expand the risk register to include detailed second-order risks, map potential cascades, and establish a review cadence within 30 days.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a detailed permit/approval matrix, and critical predecessors are not mapped, creating a high likelihood of delays. This absence poses a significant risk to project timelines.

**Mitigation**: Owner: Rebuild the critical path with dated predecessors and authoritative permit lead times, establishing a NO-GO threshold on slip within 30 days.


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the funding plan does not specify committed sources or term sheets that cover the required runway. There are no defined financing gates or covenants, creating a critical risk of funding shortfalls.

**Mitigation**: Finance Team: Draft a detailed financing plan listing sources, status, draw schedule, covenants, and a NO-GO on missed financing gates within 30 days.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the stated budget conflicts with the need for detailed vendor quotes and scale-appropriate benchmarks. The plan lacks evidence of cost normalization per area, creating a significant risk of financial misalignment.

**Mitigation**: Owner: Benchmark costs against at least three relevant comparables, obtain quotes, normalize per area, and adjust budget or de-scope by month 3.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections as single numbers without ranges or alternative scenarios, indicating a lack of contingency planning. This optimism creates a significant risk of failure.

**Mitigation**: Project Manager: Conduct a sensitivity analysis and develop best/worst/base-case scenario analyses for critical projections within 30 days.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks essential engineering artifacts such as specifications, interface contracts, acceptance tests, and an integration plan. This absence creates a critical risk for core components.

**Mitigation**: Engineering Team: Produce technical specs, interface definitions, test plans, and an integration map with owners and dates within 60 days.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks verifiable artifacts for critical claims, such as regulatory approvals and partnerships. The absence of these documents creates a significant risk of operational failure.

**Mitigation**: Regulatory Compliance Officer: Obtain all necessary regulatory permits and partnership agreements, ensuring documentation is complete within 30 days.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's final outputs, specifically the 'crocodile moats,' are mentioned without specific, verifiable qualities. This lack of clarity creates a significant risk of failure.

**Mitigation**: Project Manager: Define SMART acceptance criteria for the crocodile moats, including a KPI for effectiveness in deterring threats (e.g., 95% reduction in breach attempts) within 30 days.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project includes the integration of live crocodiles into security solutions, which adds complexity and cost without clear evidence of supporting core objectives like market entry and compliance. This creates a significant risk of failure.

**Mitigation**: Project Team: Conduct a Benefit Case Review for the crocodile moat feature, justifying its inclusion with a one-page document detailing KPIs, owner, and estimated costs, or move it to the backlog within 30 days.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies the 'Veterinary Specialist' role as critical for ensuring the health and welfare of crocodiles, which is essential yet likely difficult to fill due to specialized expertise requirements.

**Mitigation**: Project Manager: Validate the talent market for veterinary specialists with experience in reptiles by conducting outreach to local universities and veterinary associations within 30 days.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not outline specific legal or regulatory pathways for obtaining necessary permits, creating a significant risk of operational delays. This lack of clarity could lead to project failure.

**Mitigation**: Regulatory Compliance Officer: Develop a detailed regulatory matrix outlining required permits, lead times, and responsible authorities within 30 days.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project lacks a clear operational sustainability model, with concerns about ongoing costs, maintenance requirements, and scalability. This creates a significant risk of failure post-completion.

**Mitigation**: Project Manager: Develop an operational sustainability plan that includes funding strategies, maintenance schedules, and scalability assessments within 60 days.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the project's success hinges on obtaining various regulatory approvals, which are non-waivable and may be unlikely given the complexity of using live animals. This creates a critical risk of failure.

**Mitigation**: Regulatory Compliance Officer: Perform a fatal-flaw screen with regulatory authorities to identify potential approval challenges and establish NO-GO thresholds tied to outcomes within 30 days.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not provide evidence of contracts, SLAs, or tested failovers for external dependencies. This creates a critical risk of failure due to single points of failure without fallback options.

**Mitigation**: Project Manager: Secure contracts and SLAs with primary vendors, establish a secondary supplier path, and test failover mechanisms within 60 days.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan identifies conflicting incentives between the Finance Department, focused on budget adherence, and the R&D Team, driven by long-term innovation. This creates a risk of misalignment in project goals.

**Mitigation**: Project Manager: Facilitate a workshop to create shared OKRs that align both Finance and R&D on common objectives within 30 days.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop: KPIs, review cadence, owners, and a basic change-control process. Vague 'we will monitor' is insufficient for effective oversight.

**Mitigation**: Project Manager: Add a monthly review with a KPI dashboard and establish a lightweight change board within 30 days.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan does not assess interactions among risks using cross-impact, bow-tie, or FTA methodologies. This oversight creates a significant risk of unrecognized multi-node cascades and common-mode failures.

**Mitigation**: Project Manager: Create an interdependency map, conduct a bow-tie analysis, and develop a combined heatmap with NO-GO thresholds within 60 days.