**Verdict:** 🔴 REFUSE

**Rationale:** The plan seeks operational detail for a live-crocodile security moat business that materially increases capability to cause severe physical harm and environmental damage.

### Violation Details

| Detail                | Value |
|-----------------------|-------|
| **Category**              | Physical Harm |
| **Claim**                 | Live-crocodile security moat deployment for perimeter defense |
| **Capability Uplift**     | Yes |
| **Severity**              | High |