**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Exceeds financial limit for PMO approval, requiring higher-level oversight.
Negative Consequences: Potential budget overrun and project delays.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant risks that cannot be managed within existing resources need strategic intervention.
Negative Consequences: Project failure or severe operational disruptions.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Inability to reach consensus on vendor selection impacts project timelines.
Negative Consequences: Delays in project execution and potential loss of contracts.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee
Approval Process: Steering Committee Vote
Rationale: Significant changes to project scope require strategic alignment and approval.
Negative Consequences: Scope creep leading to budget overruns and project misalignment.

**Reported Ethical Concern**
Escalation Level: Project Steering Committee
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Ethical violations need independent review to maintain integrity and public trust.
Negative Consequences: Reputational damage and potential legal ramifications.