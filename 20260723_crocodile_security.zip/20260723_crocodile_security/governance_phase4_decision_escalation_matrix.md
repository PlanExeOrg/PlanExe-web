**Capital Deployment Exceeding Executive Operations Group Financial Authority**
Escalation Level: Project Steering Committee
Approval Process: Consensus-based decision-making with the founder holding a casting vote; unanimous consent is required for capital deployments exceeding $2 million, and the Gulf family-office investor's principal provides final arbitration if unanimity cannot be achieved within 14 days
Rationale: Exceeds the $500,000 operational authority threshold delegated to the Executive Operations Group, requiring strategic-level investor protection and alignment with the tranche-gated milestone architecture governing the $10 million seed budget
Negative Consequences: Unauthorized capital deployment, erosion of Gulf family-office investor confidence, blockage of subsequent tranche releases, potential breach of investor veto rights over capital expenditures exceeding $1 million, and jeopardized milestone-based funding continuity

**Critical Risk Materialization — Animal Escape Causing Human Injury or Imminent Threat**
Escalation Level: Risk & Crisis Management Committee
Approval Process: The Safety Director exercises unilateral authority to activate emergency protocols during the active crisis; post-crisis review requires unanimous consent on lessons-learned and protocol amendments, with any challenge escalated to the Project Steering Committee within 24 hours
Rationale: Existential tail risk requiring immediate specialized crisis response beyond operational authority; a single escape causing human injury would terminate the business irreversibly with legal liability exceeding $10M–$50M, destroying the independently audited welfare program PR shield and voiding insurance coverage
Negative Consequences: Business termination, legal liability exceeding $10M–$50M, destruction of the welfare audit PR shield, CITES permit revocation, irreversible reputational damage, and potential criminal prosecution

**Executive Operations Group Deadlock on Safety-Critical Containment Design**
Escalation Level: Project Steering Committee
Approval Process: Project Steering Committee makes the final decision; however, it cannot override a unanimous Technical & Engineering Advisory Board safety veto without assuming explicit liability, and if overridden, the matter must escalate to the Gulf family-office investor for explicit liability assumption
Rationale: Safety-critical engineering disagreements that cannot be resolved within the 48-hour operational consensus window require strategic-level accountability and liability assumption, given that containment integrity is the absolute prerequisite for the zero-injury success criterion
Negative Consequences: Construction delays compromising the 18-month first-contract deadline, compromised containment integrity increasing escape risk, potential violation of zero-injury success criterion, and technical decisions made without proper liability framework

**Client Acceptance Decision Involving Sustained Negative Media Attention or International Sanctions**
Escalation Level: Ethics, Animal Welfare & Compliance Committee
Approval Process: Committee consensus-based decision-making with the independent ethics advisor holding a casting vote on animal welfare matters; unanimous consent is required for client acceptance decisions involving clients under sustained negative media attention or international sanctions, with unresolved disputes escalating to the Project Steering Committee
Rationale: Reputational and legal risk requiring independent ethical oversight beyond operational sales authority; the 'no client too controversial' policy creates significant tail risk where association with a widely condemned client could trigger sanctions, boycotts, or investor withdrawal exceeding the $500,000 crisis reserve
Negative Consequences: Reputational damage, international sanctions, boycotts, investor withdrawal, PR shield failure, potential loss of CITES permits due to association with controversial entities, and sustained negative media attention undermining all client relationships

**CITES Appendix I Export Permit Denial or Regulatory Reversal Threatening Business Continuity**
Escalation Level: Ethics, Animal Welfare & Compliance Committee
Approval Process: Ethics Committee manages CITES compliance and exemption pathway strategy; if the denial or reversal threatens business continuity or exceeds the $10M single-incident financial exposure cap, the matter escalates immediately to the Project Steering Committee and the Gulf family-office investor for final arbitration
Rationale: Legal viability prerequisite requiring specialized regulatory expertise and board-level strategic response; without a defined CITES Appendix I commercial trade exemption mechanism, the entire animal sourcing and deployment chain has zero legal viability, making this the absolute prerequisite for all commercial activity
Negative Consequences: Total business model collapse, complete capital loss (-100% ROI), inability to source or deploy Nile crocodiles across jurisdictions, destruction of investor confidence, and freezing of all gated tranche releases

**Attempt to Override Technical & Engineering Advisory Board Unanimous Safety Veto on Containment Design**
Escalation Level: Project Steering Committee
Approval Process: Project Steering Committee cannot override a unanimous Technical & Engineering Advisory Board safety veto without assuming explicit liability; if the Steering Committee overrides the veto, the matter must escalate to the Gulf family-office investor for explicit liability assumption before proceeding
Rationale: Safety-critical design decisions require the highest level of accountability; the Technical Board's veto power exists to prevent containment failures that would cause existential business risk, and overriding it transfers liability beyond the operational and technical governance layers
Negative Consequences: Containment system failure, animal escape causing human injury or death, business termination, legal liability exceeding $10M–$50M, destruction of the welfare audit PR shield, and potential criminal prosecution for negligence