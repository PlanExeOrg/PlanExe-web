**Purpose:** business

**Purpose Detailed:** National transition plan for Denmark to adopt the euro, including legal, political, and operational steps.

**Topic:** Denmark Euro Adoption Plan