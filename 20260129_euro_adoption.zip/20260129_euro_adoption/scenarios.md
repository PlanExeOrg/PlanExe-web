# Choosing Our Strategic Path
## The Strategic Context
Understanding the core ambitions and constraints that guide our decision.

**Ambition and Scale:** National-scale, high ambition: Denmark transitions from opt-out to full euro adoption, requiring treaty change, referendum, and deep integration with the euro area.

**Risk and Novelty:** High political, economic, and operational risk; novel for Denmark given its opt-out; involves significant uncertainty around exchange rates and market confidence.

**Complexity and Constraints:** Highly complex: legal/treaty changes, ERM II compliance, central bank transition, dual-currency management, IT and payment system migration, strict EU/ECB rules, and constitutional referendum requirements.

**Domain and Tone:** Governmental/ministerial domain; authoritative, realistic, sequenced tone; explicitly bans crypto/cryptocurrency and mandates referendum.

**Holistic Profile:** A cautious but decisive national transition plan that balances political legitimacy (referendum), legal compliance (treaty change), economic stability (ERM II and convergence), and operational readiness (IT, cash, dual pricing), while respecting EU rules and Danish constitutional practice over a multi-year horizon.

---
## The Path Forward
This scenario aligns best with the project's characteristics and goals.

### The Builder
**Strategic Logic:** This scenario seeks a balanced, evidence-driven progression that manages risk while maintaining steady momentum. It emphasizes domestic readiness and broad stakeholder alignment, ensuring that each major step is underpinned by demonstrable compliance and public support. The approach favors staged, reversible actions to preserve flexibility.

**Fit Score:** 9/10

**Why This Path Was Chosen:** The Builder aligns strongly with the plan’s multi-year, sequenced approach, emphasizing domestic compliance, stakeholder alignment, and reversible steps. It respects referendum requirements, EU rules, and risk controls while providing a realistic, evidence-driven path.

**Key Strategic Decisions:**

- **Convergence Management Strategy:** Achieve and formally document compliance with all Maastricht criteria requirements domestically *before* applying for entry into ERM II, ensuring a highly stable, low-risk entry point into the required two-year convergence period.
- **Public Mandate Acquisition Timeline:** Schedule the referendum only after fulfilling all technical prerequisites, including the completion of all necessary IT system certification by commercial banks and publicly announcing the final, fixed DKK/EUR conversion rate buffer.
- **Financial Infrastructure Migration Strategy:** Mandate a 'dual pricing until full conversion' approach where all price tags and invoices must show both DKK and EUR for a full year, forcing market acclimatization before legally enforcing euro-only transactions for non-cash payments.
- **Cash Conversion Logistics and Seigniorage Capture:** Establish centralized, government-managed cash-in-transit hubs across all major municipalities to manage parallel DKK withdrawal and EUR issuance for the first month, creating a buffer against initial commercial bank distribution failures.
- **Treaty Change Negotiation Posture:** Present the EU with a non-negotiable, fully costed implementation timeline contingent on specific, pre-agreed flexibility clauses concerning the minimum ERM II participation duration.

**The Decisive Factors:**

The Builder scenario best fits the plan’s cautious, sequenced, and authoritative approach to Denmark’s euro adoption. It aligns with the multi-year timeline, staged reversibility, and emphasis on domestic readiness and stakeholder alignment, ensuring compliance with EU rules and constitutional referendum requirements. 
- Why The Builder fits: Prioritizes evidence-driven milestones, maintains stability through dual pricing and centralized cash hubs, and secures political mandate via a well-timed referendum after technical readiness.
- Why The Pioneer is less suitable: Its immediate ERM II entry and Big Bang conversion introduce unacceptable volatility and compress critical preparation phases.
- Why The Consolidator is less suitable: Its early advisory referendum and voluntary migration dilute the plan’s firm prerequisites and risk prolonging uncertainty.

---
## Alternative Paths
### The Pioneer
**Strategic Logic:** This path prioritizes speed and technological leadership, aiming to position Denmark at the forefront of euro integration. It accepts higher financial and operational risk in exchange for signaling strong commitment and gaining early influence over euro area rules. The approach minimizes prolonged dual-currency ambiguity by moving decisively once political consent is secured.

**Fit Score:** 3/10

**Assessment of this Path:** The Pioneer’s speed, early ERM II entry, and Big Bang conversion conflict with the plan’s emphasis on staged, reversible actions, robust domestic readiness, and risk mitigation. High novelty and compressed timelines increase volatility, clashing with the authoritative, cautious tone.

**Key Strategic Decisions:**

- **Convergence Management Strategy:** Enter ERM II immediately following the positive referendum outcome, utilizing the mechanism's parity commitment to immediately stabilize the DKK/EUR peg in foreign exchange markets, accepting the associated early scrutiny of central bank operations.
- **Public Mandate Acquisition Timeline:** Stage the referendum immediately following the political agreement with the EU on the opt-out lifting process, capitalizing on political momentum while accepting the subsequent two-year period will require heavy communication to manage technical uncertainty.
- **Financial Infrastructure Migration Strategy:** Implement a full, mandated 'Big Bang' conversion of all outstanding financial contracts, wages, and central bank accounts to the euro on a single pre-determined Day One, minimizing the administrative burden of prolonged dual-currency operations.
- **Cash Conversion Logistics and Seigniorage Capture:** Pre-finance a massive inbound shipment of ready-minted euro coins and notes from the Eurosystem partners immediately upon treaty ratification, financing the inventory cost via short-term Danish government borrowing to ensure zero supply uncertainty at conversion.
- **Treaty Change Negotiation Posture:** Adopt a strategy of complete alignment with the established ECB roadmap for new entrants, prioritizing technical compliance to secure immediate political endorsement for the treaty exemption process.

### The Consolidator
**Strategic Logic:** This path prioritizes stability, cost control, and risk aversion above all else. It relies on proven, low-disruption mechanisms and spreads conversion costs across the private sector to minimize immediate public-sector exposure. The approach accepts a longer timeline in exchange for minimized volatility and maximal predictability.

**Fit Score:** 6/10

**Assessment of this Path:** The Consolidator’s focus on cost control and spreading risk is partially compatible, but its reliance on early advisory referendums, voluntary conversion, and derivative ERM II derogation deviates from the plan’s preference for firm prerequisites and firm treaty/legal sequencing.

**Key Strategic Decisions:**

- **Convergence Management Strategy:** Seek a highly conditional, time-limited derogation from the full two-year ERM II requirement, leveraging Denmark's prior stable membership in the Exchange Rate Mechanism (ERM 1) to expedite the timeline to the final conversion date.
- **Public Mandate Acquisition Timeline:** Conduct a preliminary, non-binding advisory referendum early in the process to gauge public appetite for sovereignty transfer, using the binary result to either halt the process or to mandate the Folketinget to proceed with accelerated legal preparation.
- **Financial Infrastructure Migration Strategy:** Institute a voluntary, client-driven conversion structure for existing contracts (outside of government liabilities), allowing private entities to migrate their specific balance sheets to EUR upon their own readiness timelines, respecting the dual-circulation period.
- **Cash Conversion Logistics and Seigniorage Capture:** Mandate all large retailers and supermarkets to assume the function of DKK exchange points during the dual circulation period, offering euro change for DKK payments, thereby distributing the logistical cost and liability across private sector distribution networks.
- **Treaty Change Negotiation Posture:** Link the success of the treaty change negotiations explicitly to progress on unrelated Danish EU policy dossiers (e.g., Justice and Home Affairs cooperation) to create cross-issue leverage.
