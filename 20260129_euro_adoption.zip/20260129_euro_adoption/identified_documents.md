
## Documents to Create

### 1. Project Charter: DKK to EUR Transition (Builder's Blueprint)

**ID:** d82255ac-ff0a-483a-9a03-e131da63edfc

**Description:** Foundational project management document defining scope, objectives (SMART criteria), high-level milestones (4-8 years), resource baseline (DKK 15-25B estimate), primary dependencies, and alignment with the 'Builder's Blueprint' strategy. Primary audience is the Joint Ministerial Consultative Body.

**Responsible Role Type:** Chief Transition Architect / Project Director

**Primary Template:** PMI Project Charter Template

**Secondary Template:** Governmental Transition Program Template

**Steps:**

- Finalize SMART goals and objectives based on project scope documents.
- Define the initial structure and membership of the Joint Ministerial Consultative Body.
- Establish the initial, high-level budget range and funding stability requirements (including inflation indexation strategy).
- Obtain formal authorization signatures from core Ministerial stakeholders.

**Approval Authorities:** Joint Ministerial Consultative Body (Chaired by Prime Minister's Office)

### 2. Opt-Out Resolution & EU Negotiation Strategy Framework

**ID:** fe94fb70-e99c-4701-94da-755527818159

**Description:** High-level framework detailing the chosen legal pathway (Extraordinary Council Session focus) for lifting the DKK opt-out, including conditional negotiation triggers based on ERM II performance markers (12-month stability). Primary audience is the Senior EU Legal & Treaty Negotiator and the Chief Transition Architect.

**Responsible Role Type:** Senior EU Legal & Treaty Negotiator

**Primary Template:** International Treaty Negotiation Strategy Template

**Secondary Template:** Legal Pathway Analysis Document

**Steps:**

- Conduct feasibility assessment for Protocol Amendment vs. full Treaty Review.
- Define the precise 12-month ERM II stability markers that trigger formal EU negotiation advancement.
- Draft initial high-level talking points for engagement with the European Commission and relevant Member States.
- Integrate findings from the Dual-Path Legal Contingency Mandate planning.

**Approval Authorities:** Chief Transition Architect, Ministry of Justice

### 3. Initial ERM II Entry and Convergence Alignment Plan

**ID:** 01724a50-0737-4922-ae41-cca5cfe6fe7a

**Description:** Strategic plan outlining the 'Maintain Current Strict Policy' approach pre-ERM II entry, modeling the required DKK parity maintenance, and establishing initial benchmarks for meeting primary Maastricht criteria during the mandatory convergence tracking period. Primary audience: Macroeconomic Convergence & ERM Strategist, Danmarks Nationalbank.

**Responsible Role Type:** Macroeconomic Convergence & ERM Strategist

**Primary Template:** Monetary Policy Transition Scenario Plan

**Secondary Template:** ECB Convergence Checklist Pre-Audit Benchmark

**Steps:**

- Model the implications of maintaining the current DKK policy as informal ERM alignment.
- Establish benchmarks for inflation, deficit, and interest rate convergence metrics for the upcoming ERM II window.
- Define the initial operational limits for the DKK fluctuation band upon formal ERM II entry.
- Liaise with the Central Bank Technical Integration Lead regarding data reporting needs based on this strategy.

**Approval Authorities:** Joint Ministerial Consultative Body

### 4. Pre-Referendum Legal Contingency Mandate (Dual-Path)

**ID:** bf305173-c100-4042-9dcc-2d2a217cfd0a

**Description:** Legislation framework mandating automatic repeal (without penalty) of preparatory contract re-denomination and IT upgrade legislation if the national referendum fails. Developed to mitigate financial risk post-failure. Primary audience: Ministry of Justice, Financial & Legal Redenomination Specialist.

**Responsible Role Type:** Financial & Legal Redenomination Specialist

**Primary Template:** Contingency Legislation Template (Sovereign Transition)

**Secondary Template:** Danish Constitutional Review Assessment

**Steps:**

- Draft primary clauses defining the exact failure threshold for referendum nullification.
- Develop the mechanism for automatic legislative repeal linked to official rejection certification.
- Quantify and ring-fence the DKK 50M contingency fund required to cover interim legal documentation costs (Assumption Issue 3).
- Review draft legislation with the Chief Transition Architect for alignment with Governance Architecture.

**Approval Authorities:** Ministry of Justice, Chief Transition Architect

### 5. Governance Architecture Charter & Delegation Matrix

**ID:** c90cd6a3-b027-48b9-8b37-d1e8e54495d3

**Description:** Document formally establishing the Joint Ministerial Consultative Body, defining its mandate, decision escalation protocols (including consensus definition), and setting delegation thresholds for the Chief Transition Architect and operational leads (e.g., specialized directive authority below DKK 50M). Primary audience: All Role Leads.

**Responsible Role Type:** Chief Transition Architect / Project Director

**Primary Template:** Inter-Agency Governance Charter

**Secondary Template:** Delegation of Authority Matrix (Public Sector)

**Steps:**

- Formalize membership, frequency, and reporting lines for the Joint Ministerial Consultative Body.
- Define the specific thresholds for when operational leads (e.g., Technical Lead, Logistics Coordinator) can issue binding directives without full consensus.
- Document the process for annual review and adjustment of delegation thresholds.
- Secure sign-off from all participating Ministry Heads.

**Approval Authorities:** Prime Minister's Office

### 6. Initial Risk Register & Mitigation Action Plan (Priority Focus)

**ID:** a6b9d284-ddd2-4e2a-bde5-ae325d469b36

**Description:** Initial documentation of the top 9 identified risks, mapping residual risks to specific mitigation actions derived from the strategic decisions and expert feedback (e.g., establishing Shadow Team, launching conditional negotiation track). Primary audience: All Role Leads.

**Responsible Role Type:** Fiscal Oversight & Budget Manager

**Primary Template:** IPMA Standard Risk Register

**Secondary Template:** Risk & Mitigation Action Tracking Log

**Steps:**

- Populate initial risk scores (L/S) based on provided analysis.
- Map each mitigation strategy (e.g., Shadow Team, Indexation Mandate) to a responsible role and a firm deadline (e.g., Q3 2026).
- Establish the protocol for escalating unmitigated or materialized risks to the Joint Ministerial Consultative Body.
- Verify budget allocation for initial risk mitigation steps (e.g., DKK 25M for 'Killer App').

**Approval Authorities:** Chief Transition Architect

### 7. Societal Readiness & Communication Phasing Strategy

**ID:** 44e70446-78dd-4e64-9854-fd08c0917dd0

**Description:** Defines the sequencing (Pacing) for public engagement, detailing the content, channels, and timing for communication, specifically linking campaign intensity to the achievement of convergence milestones and the confirmed referendum date (post-2030 assumption). Includes the mandate for the 'Consumer Remediation and Education' function.

**Responsible Role Type:** Public Referendum & Change Management Lead

**Primary Template:** National Change Management Communication Plan

**Secondary Template:** Public Referendum Readiness Framework

**Steps:**

- Define the communication cadence tied to ERM II progress markers (e.g., milestones for Shadow Team completion).
- Design the mandate and resource structure for the 'Consumer Remediation and Education' function.
- Outline the criteria for triggering the high-intensity campaign (tied to referendum staging).
- Develop initial blueprint for the 'Killer App' prototype (Action 2).

**Approval Authorities:** Joint Ministerial Consultative Body

### 8. Budget Indexation and Contingency Management Protocol

**ID:** be702ebb-c2fd-4940-9a08-96a7ee4eff0f

**Description:** Protocol detailing the mandatory annual review schedule against baseline CPI, the formula for real-value preservation of the transition budget (DKK 15-25B), and the governance steps required by the Fiscal Oversight Manager to adjust allocated funds for inflation erosion (Mitigation Issue 2). Primary audience: Fiscal Oversight & Budget Manager, Chief Transition Architect.

**Responsible Role Type:** Fiscal Oversight & Budget Manager

**Primary Template:** Public Sector Multi-Year Budget Indexation Policy

**Secondary Template:** Contingency Fund Drawdown Protocol

**Steps:**

- Define the official baseline CPI index to be used for annual recalibration.
- Document the formal process for reporting the Real Value Erosion Index (RVEI) to the Consultative Body quarterly.
- Finalize escrow account signatory requirements for the DKK 50M inflation-adjusted contingency fund.
- Secure sign-off from the Ministry of Finance.

**Approval Authorities:** Chief Transition Architect, Ministry of Finance Directorate

### 9. Cash Logistics Synchronization Framework (Readiness-Weighted Rollout)

**ID:** 335da9a6-7307-4965-9748-9acfdc809c88

**Description:** Operational framework prioritizing the physical cash rollout (Decision 6 & 13) based on measured public readiness scores from ongoing surveys, rather than a fixed calendar date. Includes security contracting requirements derived from expert benchmarking (Risk 5 mitigation). Primary audience: Logistics & Operational Readiness Coordinator.

**Responsible Role Type:** Logistics & Operational Readiness Coordinator

**Primary Template:** High-Security Supply Chain Phasing Document

**Secondary Template:** Public Readiness Scorecard Integration Guide

**Steps:**

- Define the core 'Readiness Score' metrics provided by the Change Management Lead.
- Establish contractual mechanisms with 3rd party logistics firms to allow for demand-weighted inventory release schedules.
- Detail the security contracting pre-qualification process based on external logistics benchmark findings.
- Map cash rollout phases directly against Societal Readiness Pacing milestones.

**Approval Authorities:** Joint Ministerial Consultative Body

## Documents to Find

### 1. Existing EU Treaty Text Regarding Opt-Out Mechanisms (Article 16, Protocol No. 30, etc.)

**ID:** 9bd6c734-c945-436b-8ebc-25287fbbda23

**Description:** Raw legal text governing the existing DKK opt-out concerning the Euro. Essential for the Senior EU Legal & Treaty Negotiator to model potential amendment routes (Decision 4) and scope required for negotiation.

**Recency Requirement:** Current consolidated text is essential.

**Responsible Role Type:** Senior EU Legal & Treaty Negotiator

**Access Difficulty:** Easy

**Steps:**

- Search official EUR-Lex portal for latest consolidated Treaties of the European Union.
- Consult historical Danish protocols concerning the Edinburgh Agreement.
- Directly source official text from the Council of the EU documentation archives.

### 2. ECB Convergence Criteria Official Checklist and Latest Assessment Guide

**ID:** 1f050d91-076c-41b5-a95c-f2775e3d14a5

**Description:** The definitive, current checklist detailing all mandatory primary and secondary convergence criteria (inflation, deficit, debt, interest rates, ERM II participation) required by the ECB for final Euro adoption assessment. Essential input for the Initial ERM II Entry Plan (Decision 12).

**Recency Requirement:** Must be the most recently revised version published by ECB.

**Responsible Role Type:** Macroeconomic Convergence & ERM Strategist

**Access Difficulty:** Easy

**Steps:**

- Download current convergence criteria documentation directly from the ECB website.
- Review the standard ECB assessment methodology documents related to ongoing convergence monitoring.
- Search for historical ECB annual reports detailing the final compliance requirements for recent entrants (e.g., Slovakia, Lithuania).

### 3. Danmarks Nationalbank's Current IT Infrastructure Documentation Mapping

**ID:** c70bbf9c-34de-4f1b-be36-b280eed49c6c

**Description:** Detailed topological maps and system specifications for Danmarks Nationalbank's critical payment systems (e.g., gross settlement systems, real-time monitoring tools) as they currently interact with non-Eurozone systems. Needed to guide the Shadow Integration Team's initial simulation scope (Risk 4 mitigation).

**Recency Requirement:** System architecture documentation from the last 12 months.

**Responsible Role Type:** Central Bank Technical Integration Lead

**Access Difficulty:** Medium

**Steps:**

- Request internal documentation directly from Danmarks Nationalbank IT Security and Operations department.
- Review any existing internal gap analysis reports comparing current systems against TARGET2 specifications.
- Check internal National Bank secure data repositories for system specification drawings.

### 4. Danish Fiscal Data: Historical Deficit and Debt Ratios (Last 5 Years)

**ID:** 68c583fb-c961-489c-bf8f-17e7e422deaf

**Description:** Raw national accounts data providing mandatory metrics for fiscal convergence (Debt/GDP < 60%, Deficit/GDP < 3%). Needed by the Macroeconomic Strategist to set internal policy baselines.

**Recency Requirement:** Data covering the last five complete fiscal years, plus the latest quarterly figures.

**Responsible Role Type:** Fiscal Oversight & Budget Manager

**Access Difficulty:** Easy

**Steps:**

- Access Statistics Denmark (DST) database for national accounts tables.
- Review the Ministry of Finance's most recent publicly issued Budget Stress Test data.
- Source raw data from Eurostat tables related to Maastricht criterion reporting for Denmark.

### 5. Danish Constitutional Text Regarding National Referenda and Treaty Ratification

**ID:** 65931c18-fbf5-4265-b1e9-eb0ea60bf4d5

**Description:** The specific articles of the Danish Constitution governing the requirements (majority size, turnout thresholds, sequence) for enacting a national referendum on matters concerning international treaty changes, which constrains the Public Referendum Design (Decision 3).

**Recency Requirement:** Current version of the Constitution.

**Responsible Role Type:** Senior EU Legal & Treaty Negotiator

**Access Difficulty:** Easy

**Steps:**

- Retrieve the official, current text of the Danish Constitution from the Folketinget website.
- Consult prior legal analyses or White Papers concerning previous Danish treaty votes.
- Seek clarification from the Ministry of Justice's constitutional department on procedural precedents.

### 6. Historical ECB/Eurosystem Guidance on Pre-Accession Informal ERM Alignment

**ID:** 90deec72-0519-4da8-8f15-d30fa621d0a0

**Description:** Any official or technical ECB documentation, guidance papers, or historical precedents outlining how applicant countries managed exchange rate stability guidance *outside* the formal ERM II band before official entry, relevant for Decision 2 and 12 strategy development.

**Recency Requirement:** Documents relating to the 2007-2015 enlargement waves.

**Responsible Role Type:** Macroeconomic Convergence & ERM Strategist

**Access Difficulty:** Medium

**Steps:**

- Search ECB publications portal for 'pre-ERM II stability guidance' or 'informal alignment'.
- Review convergence reports for specific member states that had complex bilateral agreements prior to entry.
- Consult academic literature referencing ECB technical briefings on exchange rate signaling.

### 7. Slovakia (SKK) Dual Circulation Exit and Price Display Regulations (2008-2009)

**ID:** df6ad01f-32c2-47aa-9dce-b20433e49a0f

**Description:** Official Slovak documentation detailing the security protocols, duration, and specific regulatory mandates for dual price display and rounding rules during their short cash circulation phase (20 days). Provides direct comparative data for Decision 6 and 7.

**Recency Requirement:** Legislation/Regulations active between 2008 and 2009.

**Responsible Role Type:** Logistics & Operational Readiness Coordinator

**Access Difficulty:** Medium

**Steps:**

- Examine archives of the National Bank of Slovakia (NBS) on currency withdrawal.
- Search Slovak Ministry of Finance historical legislation archives for Price Display directives.
- Contact former Slovak officials via international network contacts (per Suggestion 1).

### 8. Sweden's Pre-Referendum Riksbank Working Papers on ERM Entry Scenarios (Pre-2003)

**ID:** 3d4fb0e6-6b3b-453b-b0af-39bcc147e07c

**Description:** Pre-2003 technical and economic working papers from Riksbanken analyzing the cost/benefit and technical hurdles of potential ERM II entry without a confirmed political mandate. Crucial for validating the resource allocation strategy for the Danish 'Shadow Integration Team' (Decision 8/Assumption 3).

**Recency Requirement:** Any technical papers published between 1999 and 2003.

**Responsible Role Type:** Central Bank Technical Integration Lead

**Access Difficulty:** Hard

**Steps:**

- Search the Riksbank digital archives for working papers tagged with 'Euro Area Entry' or 'ERM Scenarios'.
- Locate formal reports detailing resource allocation challenges during the preparation phase (if any).
- Consult with academic experts familiar with Scandinavian monetary history.

### 9. Lithuanian (LITAS) to TARGET2 Payment System Integration Reports (2013-2014)

**ID:** afd1a60c-7d77-4a90-bc07-59724fc5c43c

**Description:** Technical reports detailing the integration roadmap, security hardening efforts, and successful migration steps taken by the Bank of Lithuania (BoL) to connect their national payment systems to the ECB's TARGET2 infrastructure (Decision 8). Directly informs the Central Bank Technical Integration Lead.

**Recency Requirement:** Technical reports published between 2013 and 2014.

**Responsible Role Type:** Central Bank Technical Integration Lead

**Access Difficulty:** Medium

**Steps:**

- Access the Bank of Lithuania (Lietuvos bankas) official library/publication portal.
- Search ECB Convergence Reports (2014) for specific commentary on Payment System Migration.
- Review BoL annual reports detailing cooperation memoranda with the Eurosystem.

### 10. Danish Commercial Contract Law and Consumer Protection Statute regarding Price Fixed Obligations

**ID:** 13ab57d1-991b-46bc-8294-38af24ce1a07

**Description:** Current Danish statutes detailing the legal enforceability and rounding rules for long-term private financial contracts (e.g., mortgages, leases) that might be automatically converted upon a change of legal tender. Essential for drafting the mandatory re-denomination legislation (Decision 7).

**Recency Requirement:** Current codified private and commercial law statutes.

**Responsible Role Type:** Financial & Legal Redenomination Specialist

**Access Difficulty:** Medium

**Steps:**

- Search official Danish legislative databases (e.g., Retsinformation) for relevant acts concerning currency conversion precedents.
- Consult the Ministry of Justice guidance on commercial law impact during previous Danish monetary changes (e.g., major USD peg changes).
- Obtain codified texts via the Danish Bar Association or legal publishers.