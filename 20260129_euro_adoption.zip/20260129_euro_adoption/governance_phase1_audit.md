
## Audit - Corruption Risks

- Bribery of officials involved in vendor selection for IT system upgrades or currency logistics contracts.
- Conflicts of interest among government officials or central bank employees influencing the selection of financial institutions to manage the transition.
- Kickbacks from communication firms hired to manage the public information campaign, in exchange for inflated contracts or preferential treatment.
- Misuse of confidential information regarding the timing or terms of the euro adoption to benefit personal investments or those of close associates.
- Trading favors with EU officials to secure favorable negotiation terms, potentially overlooking due diligence or transparency requirements.

## Audit - Misallocation Risks

- Inflated contracts awarded to politically connected firms for IT system upgrades or currency conversion services.
- Duplication of effort in public information campaigns, with multiple agencies or contractors conducting similar activities without coordination.
- Inefficient allocation of resources to less critical aspects of the transition, such as excessive spending on promotional materials or unnecessary consulting services.
- Unauthorized use of project funds for personal expenses or unrelated activities by project team members.
- Misreporting of progress or results to maintain the appearance of success, potentially masking underlying problems or delays.

## Audit - Procedures

- Conduct periodic internal reviews of all contracts related to the euro adoption project, with a focus on vendor selection processes and pricing.
- Implement a robust expense approval workflow with multiple levels of authorization and detailed documentation requirements.
- Perform regular audits of financial transactions to identify any instances of double spending, unauthorized use of funds, or other irregularities.
- Conduct post-project external audits to assess the overall effectiveness of the transition and identify any areas for improvement.
- Implement compliance checks to ensure adherence to EU and ECB regulations, as well as Danish constitutional requirements.

## Audit - Transparency Measures

- Establish a public dashboard displaying key project metrics, including budget expenditures, timelines, and progress towards milestones.
- Publish minutes of key meetings of the project steering committee and other governing bodies.
- Implement a whistleblower mechanism to allow individuals to report suspected wrongdoing without fear of retaliation.
- Make relevant policies and reports related to the euro adoption project publicly accessible on a dedicated website.
- Document and publish the selection criteria for all major decisions and vendors involved in the project.