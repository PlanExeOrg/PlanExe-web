
## Audit - Corruption Risks

- Bribery of EU or Danish officials to fast-track or block treaty change and referendum processes
- Nepotism in awarding consultancy and IT conversion contracts to politically connected firms
- Conflicts of interest among ministers or regulators influencing the choice of conversion methodology or cash logistics partners
- Kickbacks from payment service providers or cash logistics firms in exchange for exclusive migration or distribution roles
- Misuse of non-public information on referendum timing or parity decisions to gain financial advantage in currency markets

## Audit - Misallocation Risks

- Budget padding for public information campaigns beyond actual reach, with funds diverted to unrelated priorities
- Double spending of earmarked euro transition funds across multiple ministries without reconciliation
- Inefficient allocation of technical personnel to IT conversion causing bottlenecks and extended dual-circulation costs
- Unauthorized use of Nationalbank or government contingency assets to cover cash shortages during conversion
- Poor record-keeping leading to unaccounted conversion costs and inability to trace disbursements for audits

## Audit - Procedures

- Quarterly internal compliance audits of treaty change and referendum documentation against legal checklists, with a post-referendum external audit
- Pre- and post-implementation IT system audits for payment and conversion platforms, including penetration testing and dual-currency reconciliation testing
- Contract review thresholds for procurement above a set value, with mandatory competitive bidding and conflict-of-interest declarations
- Expense and reimbursement workflows requiring itemized dual-currency conversion receipts and segregation of duties for payment approvals
- Periodic compliance checks against Maastricht criteria and ERM II rules, with remediation plans reported to the Folketinget

## Audit - Transparency Measures

- Public dashboard tracking referendum thresholds, ERM II entry status, and conversion milestones with weekly updates
- Published summaries of key ministerial and EU negotiation meetings, including voting records and derogation requests
- Whistleblower hotline and protection policy managed by an independent ombudsperson, with anonymized case tracking
- Open access to final conversion methodology documents, rounding rules, and cash logistics SOPs
- Mandatory disclosure registers for contracts above a defined threshold, listing beneficiaries and conflict-of-interest statements