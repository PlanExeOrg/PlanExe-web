
## Audit - Corruption Risks

- Bribery or undue influence targeting Danish FSA or Ministry of Finance personnel responsible for signing off on the final commercial banking compliance certifications required before ERM II entry.
- Nepotism in selecting the single, state-funded technology integrator tasked with mandatory IT upgrades for all municipalities, potentially leading to substandard or inflated contract awards (related to Decision 14).
- Kickbacks or conflicts of interest arising from the selection and contracting of European cash-in-transit security firms for the 30-day dual circulation window, where officials might favor specific providers for transportation or depot management contracts.
- Misuse of internal economic forecasts regarding the final DKK/EUR conversion rate by individuals within Danmarks Nationalbank or the PM's office to benefit related foreign exchange positions prior to public announcement.
- Trading favors between Ministry of Business representatives and Business/Employer Organisations in exchange for favorable, non-binding DKK/EUR contract re-denomination adherence during the transition period (Decision 7).

## Audit - Misallocation Risks

- Misuse of the ring-fenced DKK 50 million contingency fund intended for cash logistics security, potentially diverting funds to cover unexpected operational shortfalls in another unrelated workstream (e.g., IT system shadowing).
- Inefficient allocation of Danish diplomatic resources pursuing an 'Extraordinary European Council session' (Decision 4.2) when resources should have been focused on fulfilling domestic constitutional preparation timelines.
- Double spending on IT system integration by the 'Shadow Integration Team' (Decision 8.1) and the official Central Bank integration track, if the political decision to halt shadow work is delayed, leading to redundant consultant fees.
- Budgetary misuse of public funds allocated for the 'Societal Readiness Pacing' communication campaign (Decision 11), funding political messaging rather than mandatory educational requirements regarding rounding rules or dual pricing.
- Unauthorized use of Danmarks Nationalbank’s advanced sorting and counting machinery (intended for efficient DKK destruction per Decision 13) for non-official commercial purposes during the dual circulation overlap.

## Audit - Procedures

- Bi-annual forensic review of procurement contracts (especially for cash logistics and IT integration consultants) exceeding DKK 25 Million, focusing on sole-source justifications and conflict of interest disclosures, mandated by the Joint Ministerial Consultative Body.
- Quarterly reconciliation of actual expenditure against the inflation-indexed budget baseline, specifically scrutinizing expenditures related to the DKK 100 Million public information allocation to ensure funds are not drawn down prematurely or disproportionately during the ERM II period.
- Pre- and Post-Referendum Audit of Public Information Spend: Verifying compliance with Societal Readiness Pacing (Decision 11) by testing material content against established criteria and confirming disbursement to municipal outreach centers according to defined incentive structures (Decision 14).
- Compliance testing of a statistically significant sample (minimum 15%) of commercial loan and lease agreement files one year post-Euro Day to verify 100% adherence to the mandated 'automatic rounding to the nearest cent' rule (Decision 7), checking ledger entries against preparatory legislation.
- Technical Audit of Danmarks Nationalbank (Post-Shadow Phase): Reviewing the deliverables and technical audit trails from the 'Shadow Integration Team' (Decision 8.1) to confirm that non-binding simulations were executed robustly against ECB benchmarks before official ERM II commencement.

## Audit - Transparency Measures

- Publishing quarterly expenditure reports for the entire DKK 15–25 Billion transition envelope on a dedicated government project website, segmented by the 14 strategic decisions, allowing tracking of cost drivers beyond contingency.
- Mandatory public release of the agenda, key decisions, and Ministerial consensus records from the 'Joint Ministerial Consultative Body' meetings within 14 days, ensuring visibility into decision velocity (Decision 5) while protecting sensitive EU negotiation positions.
- Establishment of a centralized, anonymous whistleblower mechanism managed by an independent external body (not under PM/Ministry oversight) specifically for reporting misuse related to contract awarding for cash logistics and IT integration.
- Public release of the compliance roadmaps published by municipalities detailing their Strategy 14 adherence, allowing citizens to verify local government switchover timelines and service consistency.
- Post-referendum publication of the 'Dual-Path Legal Contingency Mandate' detailing the exact criteria for the automatic repeal of preparatory contract legislation should a 'No' vote occur, ensuring legal clarity for businesses regarding sunk costs and liabilities.