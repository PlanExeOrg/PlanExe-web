## Focus and Context
How can Denmark execute a credible, sequenced transition to the euro while balancing political legitimacy (referendum), legal compliance (treaty change), economic stability (ERM II and convergence), and operational continuity (dual‑currency systems)? This plan turns a complex, high‑risk national transformation into a manageable, evidence‑driven program.

## Purpose and Goals
Enable Denmark to adopt the euro as its sole currency through a reversible, phased pathway that meets EU convergence criteria, secures public mandate, minimizes disruption, and preserves monetary sovereignty. Success is measured by referendum thresholds, sustained ERM II parity, payment‑system resilience, and full migration to euro‑based accounting.

## Key Deliverables and Outcomes
• Referendum legitimacy with predefined turnout/support thresholds and a 12‑month cooling‑off protocol. • Treaty amendment enabling Denmark to lift its opt‑out. • ERM II entry and 24‑month DKK/EUR peg stability within ±0.5%. • Dual‑pricing mandate for retailers and public‑sector POS by 2026‑09‑01. • Central Conversion Unit (CCU) operational with 10k TPS dual‑currency processing capacity. • 100% migration of retail and public‑sector payments to the euro with <0.1% settlement failures.

## Timeline and Budget
4–8 years from political decision to full adoption, with gated milestones: referendum within 12 months, treaty change 6–18 months post‑referendum, ERM II entry 6–12 months after treaty, dual circulation 12–24 months, full adoption by 2030. Budget contingent on EU co‑financing and phased appropriations; key contingencies reserved for IT, cash logistics, and systemic risk buffers.

## Risks and Mitigations
• EU political delay or treaty blockage: mitigate via high‑level diplomatic engagement, pre‑agreed simplified adjustment options, and fallback derogation pathways. • Referendum failure: mitigate via legally defined thresholds, independent Electoral Commission, and a 12‑month cooling‑off with adjusted messaging. • Operational failures in payment systems: mitigate through phased cutover, rollback procedures, and a Central Conversion Unit with circuit‑breaker authority.

## Audience Tailoring
Tailored for senior Danish government officials, EU institutions, and national stakeholders—using authoritative, precise language aligned with policy, legal, and operational decision-making contexts.

## Action Orientation
Immediate next steps: (1) Commission independent legal review and draft Referendum Legality Act (deadline 2026‑04‑25). (2) Establish CCU with 15 specialists and procure dual‑currency processing platform (10k TPS by 2026‑06‑01). (3) Pass dual‑pricing mandate for retailers and public sector (deadline 2026‑09‑01). (4) Secure pre‑commitment facility with ECB/ESM and 6‑month import cover. (5) Launch real‑time public dashboard tracking convergence, FX bands, and cash logistics KPIs.

## Overall Takeaway
Denmark can achieve euro adoption through a disciplined, phased plan that prioritizes legal clarity, public trust, and operational resilience—delivering monetary integration while safeguarding sovereignty and minimizing economic volatility.

## Feedback
Strengthen the plan with: (1) quantified fiscal‑space analysis and independent stress tests; (2) explicit referendum threshold definitions and constitutional legal opinions; (3) a dynamic currency‑risk framework with hedging and a Sovereign Conversion Fund; (4) a detailed legacy payment‑system sunsetting schedule and interoperability certification; (5) inflation‑expectation management via Wage‑Price Protocol and public dashboards.