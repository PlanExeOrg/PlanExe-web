This plan involves money.

## Currencies

- **DKK:** Current currency of Denmark, needed for initial planning and local transactions during the transition.
- **EUR:** Target currency for Denmark, needed for budgeting and planning the transition.

**Primary currency:** EUR

**Currency strategy:** EUR will be used for consolidated budgeting and reporting. DKK will be used for local transactions during the transition period. Exchange rate risks should be monitored and managed, especially during the transition period, but are expected to be minimal given Denmark's peg to the EUR.