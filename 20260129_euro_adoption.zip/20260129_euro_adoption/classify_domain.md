**Primary domain:** Public Finance

**Secondary domains:** European Union Law, Macroeconomic Management, Monetary Policy

**Rationale:** Public Finance owns the core success criterion: successfully effecting the national financial transition to the euro. Monetary Policy is a close second, but Public Finance captures the holistic national adoption/replacement mandate better than general policy. Economic Policy Communication is relegated as it is subordinate to the actual financial execution.

**Disciplines this project involves:**

| Domain | Importance | Specificity | Role | Reason |
|---|---|---|---|---|
| Public Finance | 5 | 5 | outcome | The core outcome is the national change of legal tender to a new currency. |
| Monetary Policy | 5 | 5 | outcome | The primary outcome is the change of national currency, which is monetary policy execution. |
| European Union Law | 5 | 4 | constraint | Adoption requires navigating EU treaty changes and compliance with ECB mandates. |
| Macroeconomic Management | 4 | 4 | method | The transition requires managing ERM II, convergence criteria, and exchange rate risk. |
| Change Management | 4 | 4 | method | Large-scale operational and public preparedness requires dedicated change management strategies. |
| Economic Policy Communication | 4 | 4 | outcome | Successful public preparedness and managing perception are critical to achieving adoption legally. |
| Project Implementation | 4 | 3 | method | The project demands a structured, multi-phase implementation roadmap from decision to launch. |

**Warnings:**
- Dropped duplicate fit domain: European Union Law
- Dropped duplicate fit domain: European Union Law
- First-pass produced 7 candidate(s) after 3 batch call(s); target was 9.