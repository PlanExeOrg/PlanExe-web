**Budget Request Exceeding PMO Authority**
Escalation Level: Euro Adoption Steering Committee
Approval Process: Steering Committee vote with supermajority (≥75%) and independent chair tie-break
Rationale: Exceeds delegated financial thresholds; requires strategic alignment and risk oversight.
Negative Consequences: Budget overruns, delayed timelines, and compromised contingency reserves if not escalated.

**Critical Risk Materialization Beyond PMO Capacity**
Escalation Level: Risk and Contingency Oversight Board
Approval Process: Board consensus to activate contingency reserves and scenario response plans
Rationale: High-impact risk requiring cross-body coordination and immediate resource reallocation.
Negative Consequences: Operational failure, market instability, and potential project suspension if unaddressed.

**PMO Deadlock on Vendor Selection**
Escalation Level: Dual Circulation Management Office
Approval Process: Majority vote with Head of Operations casting tie-breaking vote
Rationale: Operational gridlock affecting conversion timelines and IT readiness.
Negative Consequences: Conversion delays, increased costs, and disruption to dual-circulation planning.

**Proposed Major Scope Change**
Escalation Level: Legal and Treaty Compliance Committee
Approval Process: Unanimous consent; if unreachable, independent arbitration
Rationale: Legal and treaty implications require specialized constitutional and EU law expertise.
Negative Consequences: Non-compliance with EU rules, referendum invalidation, or treaty rejection.

**Reported Ethical Violation**
Escalation Level: Stakeholder Engagement and Communication Council
Approval Process: Consensus-driven investigation with external advisor tie-break
Rationale: Requires transparent, independent review to preserve public trust and integrity.
Negative Consequences: Reputational damage, public mistrust, and potential legal penalties if mishandled.