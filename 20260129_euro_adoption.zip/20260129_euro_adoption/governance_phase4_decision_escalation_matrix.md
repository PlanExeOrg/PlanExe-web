**Budget Request Exceeding PMO Authority**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Vote
Rationale: Exceeds the PMO's delegated financial authority (above 5 million EUR) and requires strategic review and approval at a higher level.
Negative Consequences: Potential budget overruns, delays in project execution, and misalignment with strategic objectives.

**Critical Risk Materialization**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval of Mitigation Strategy
Rationale: The PMO cannot handle the risk with existing resources or the risk has strategic implications for the project's success.
Negative Consequences: Project failure, significant delays, reputational damage, and financial losses.

**PMO Deadlock on Vendor Selection**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review of Options and Vote
Rationale: The PMO cannot reach a consensus on a key operational decision, requiring higher-level arbitration to avoid delays.
Negative Consequences: Project delays, increased costs, and potential selection of a suboptimal vendor.

**Proposed Major Scope Change**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Steering Committee Review and Approval
Rationale: A significant change to the project scope impacts strategic objectives, budget, and timeline, requiring high-level approval.
Negative Consequences: Project failure, budget overruns, delays, and misalignment with strategic objectives.

**Reported Ethical Concern**
Escalation Level: Legal and Compliance Committee (LCC)
Approval Process: Ethics Committee Investigation & Recommendation
Rationale: Requires independent review and investigation to ensure ethical standards are maintained and legal compliance is upheld.
Negative Consequences: Legal penalties, reputational damage, and loss of public trust.

**Legal Challenge to Project Activities**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Review by PSC with input from LCC, followed by vote on strategic response.
Rationale: Legal challenges can significantly impact the project's timeline, budget, and overall feasibility, requiring strategic guidance from the highest level.
Negative Consequences: Project delays, increased costs, reputational damage, and potential project termination.