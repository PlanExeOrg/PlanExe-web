**Budget Request Exceeding Steering Committee Authority (>$50M)**
Escalation Level: Project Sponsor (Designated Minister)
Approval Process: Direct Ministerial authorization; requires justification report from PSC detailing alternatives rejected.
Rationale: Exceeds the financial approval limit delegated to the Project Steering Committee ($50 million threshold).
Negative Consequences: Project budget overrun; political liability for unauthorized expenditure; potential delay in funding critical work streams.

**Materialization of Critical Risk 1 (Failure to secure EU opt-out repeal agreement)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Emergency session vote by PSC members using majority rule, potentially calling for immediate diplomatic resource reallocation.
Rationale: This risk fundamentally threatens the project's legal trajectory (Legal Pathway to Opt-Out Removal) and risks exceeding the 8-year timeline limit.
Negative Consequences: Project termination or multi-year timeline extension; political embarrassment; massive sunk cost write-off.

**PMO Deadlock on Cross-Cutting Policy (e.g., finalizing ERM II entry parity guidance)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Submitted for urgent vote by PSC members, requiring ministerial consensus consensus if possible.
Rationale: The PMO requires consensus for operational decisions; deadlock prevents progress on high-priority levers like Exchange Rate Mechanism Entry Strategy.
Negative Consequences: Stagnation of critical monetary policy alignment; inability to meet ECB deadlines; potential market instability.

**Proposed Major Change to Conversion Schedule (e.g., shortening Dual Circulation to <30 days)**
Escalation Level: Project Steering Committee (PSC)
Approval Process: Risk review by TAG, followed by PSC vote, ensuring alignment with Societal Readiness Pacing (Decision 11).
Rationale: Such a change significantly alters operational execution (Cash Logistics) and impacts public acceptance, requiring strategic oversight beyond PMO authority.
Negative Consequences: Increased public confusion and operational errors; security risks during high-volume cash withdrawal; potential referendum backlash if perceived as too rushed.

**Reported Breach of Ethical Guidelines (e.g., Transparency Failure in Public Communication)**
Escalation Level: Ethics & Compliance Committee (ECC)
Approval Process: Independent investigation by ECC; recommended non-financial sanctions or corrective actions submitted to PSC.
Rationale: Requires impartial review by the Ethics & Compliance Committee as per its mandate to monitor transparency and fairness in public engagement.
Negative Consequences: Erosion of public trust, impacting referendum outcome (Risk 2); regulatory penalties related to communication fairness.

**Technical Integration Conflict requiring Nationalbank System Re-architecture (Risk 4)**
Escalation Level: Technical Advisory Group (TAG)
Approval Process: TAG consensus recommendation to PMO, with high-cost implications escalating to PSC for approval.
Rationale: Requires specialized technical remediation advice which exceeds the PMO's technical advisory capacity, especially concerning Eurosystem integration.
Negative Consequences: Failure to connect to Eurosystem infrastructure on Euro Day; non-compliance with Central Bank Operational Integration Timeline.