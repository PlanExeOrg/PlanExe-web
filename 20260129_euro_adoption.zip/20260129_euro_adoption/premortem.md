A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Danish public overwhelmingly trusts the government's economic projections regarding Euro adoption. | Conduct a blind survey asking the public to rate their trust in government economic forecasts on a scale of 1 to 10. | The average trust rating is below 6 out of 10. |
| A2 | The necessary IT infrastructure upgrades across all Danish financial institutions can be completed within the projected budget and timeline. | Request detailed, binding quotes from at least three independent IT vendors for a representative sample of the required upgrades. | The average of the lowest quotes exceeds 80% of the allocated budget, or any vendor projects a completion timeline exceeding the project's schedule by more than 10%. |
| A3 | The EU Council will readily approve Denmark's Euro adoption proposal without demanding significant concessions that negatively impact the Danish economy. | Conduct informal, confidential soundings with key EU member states' representatives to gauge their likely positions on Denmark's proposal. | More than two key member states express strong reservations or indicate they will demand significant concessions (e.g., increased contributions to the EU budget, stricter fiscal rules). |
| A4 | Danish businesses, particularly SMEs, will readily adapt their accounting and payment systems to the Euro within the transition period. | Conduct a survey of a representative sample of SMEs to assess their current preparedness for Euro adoption and their anticipated challenges. | More than 40% of SMEs report significant concerns about the cost or complexity of adapting their systems, or indicate they will require external assistance. |
| A5 | The existing legal framework in Denmark is sufficiently flexible to accommodate the necessary legal changes for Euro adoption without requiring significant constitutional amendments. | Commission a legal review by independent constitutional law experts to assess the potential need for constitutional amendments. | The legal review concludes that significant constitutional amendments are likely required, or that the legal process will be highly complex and time-consuming. |
| A6 | The supply chain for Euro banknotes and coins will be secure and reliable, ensuring a smooth and timely distribution of the new currency. | Conduct a risk assessment of the Euro banknote and coin supply chain, identifying potential vulnerabilities and disruptions. | The risk assessment identifies significant vulnerabilities in the supply chain, or indicates that the distribution timeline is unrealistic given logistical constraints. |
| A7 | The Danish public will readily adopt electronic payment methods, reducing reliance on physical currency and easing the transition to the Euro. | Analyze current trends in electronic payment adoption in Denmark and project future adoption rates based on historical data and demographic trends. | Projected electronic payment adoption rates remain below 70% of the population within the transition timeframe, indicating a continued reliance on physical currency. |
| A8 | The Eurozone economy will remain stable and attractive, providing a compelling incentive for Denmark to join. | Monitor key economic indicators in the Eurozone (GDP growth, unemployment rates, inflation) and assess the overall economic outlook. | The Eurozone economy experiences a significant downturn (e.g., recession, sovereign debt crisis), or the economic outlook becomes highly uncertain, diminishing the perceived benefits of joining. |
| A9 | There will be sufficient political consensus within Denmark to maintain a consistent and stable approach to Euro adoption throughout the multi-year transition process. | Assess the level of cross-party support for Euro adoption and monitor political stability indicators (e.g., government approval ratings, frequency of elections). | Cross-party support for Euro adoption erodes significantly, or political instability increases (e.g., government collapses, early elections are called), jeopardizing the continuity of the project. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Phantom Dividend Disaster | Process/Financial | A1 | Minister of Finance | CRITICAL (20/25) |
| FM2 | The Great IT Meltdown | Technical/Logistical | A2 | Head of Engineering | CRITICAL (15/25) |
| FM3 | The Brussels Blackmail | Market/Human | A3 | Permitting Lead | CRITICAL (15/25) |
| FM4 | The SME System Shock | Process/Financial | A4 | Minister of Finance | CRITICAL (20/25) |
| FM5 | The Constitutional Quagmire | Technical/Logistical | A5 | Head of Engineering | CRITICAL (15/25) |
| FM6 | The Counterfeit Flood | Market/Human | A6 | Permitting Lead | CRITICAL (15/25) |
| FM7 | The Cash-Clinging Crisis | Process/Financial | A7 | Minister of Finance | CRITICAL (20/25) |
| FM8 | The Eurozone Economic Earthquake | Technical/Logistical | A8 | Head of Engineering | HIGH (10/25) |
| FM9 | The Political Pendulum Peril | Market/Human | A9 | Permitting Lead | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Phantom Dividend Disaster

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Minister of Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project's financial projections, heavily reliant on government forecasts, prove overly optimistic. Public trust in these forecasts is low, leading to skepticism about the promised economic benefits of Euro adoption. As the project progresses, costs escalate due to unforeseen complications and optimistic initial estimates. The public, already wary, becomes increasingly resistant as they perceive the project as a financial boondoggle with no tangible benefits. This erodes support for the referendum, and the project faces increasing political opposition. The lack of public trust makes it difficult to secure additional funding or make necessary adjustments to the plan, leading to a financial crisis and ultimately, project failure.

##### Early Warning Signs
- Public approval ratings for the government's handling of the economy fall below 40%.
- Independent economic analyses contradict the government's projections, forecasting lower growth or higher costs.
- Key stakeholders (e.g., business leaders, labor unions) publicly express doubts about the project's financial viability.

##### Tripwires
- Public trust in government economic forecasts <= 50% based on quarterly surveys.
- Projected ROI falls below 8% based on independent economic analysis.
- Cost overruns exceed 15% of the initial budget within the first year.

##### Response Playbook
- Contain: Immediately commission an independent audit of the project's finances and projections.
- Assess: Conduct a thorough review of the financial model and identify areas of overestimation and potential cost savings.
- Respond: Implement cost-cutting measures, revise the financial projections based on the independent audit, and launch a communication campaign to restore public trust.


**STOP RULE:** Independent audit reveals that the projected ROI is below 5% and cannot be realistically improved.

---

#### FM2 - The Great IT Meltdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that IT infrastructure upgrades can be completed on time and within budget proves disastrously false. The existing systems of Danish financial institutions are far more complex and antiquated than initially assessed. The integration of Euro-compatible systems encounters unforeseen technical hurdles, leading to significant delays and cost overruns. As the deadline for the referendum approaches, it becomes clear that the IT infrastructure is not ready. This results in widespread system failures, transaction processing errors, and security vulnerabilities. Public confidence plummets as financial services are disrupted, and the risk of cyberattacks increases dramatically. The project grinds to a halt as the technical foundation crumbles, making Euro adoption impossible.

##### Early Warning Signs
- IT system integration projects fall behind schedule by more than 3 months.
- The number of reported IT system errors and security breaches increases significantly.
- Financial institutions express concerns about the readiness of their IT infrastructure.

##### Tripwires
- IT system integration projects are delayed by >= 6 months.
- Number of critical IT system errors increases by >= 50% compared to baseline.
- More than 25% of financial institutions report significant IT readiness concerns.

##### Response Playbook
- Contain: Immediately halt all non-essential IT system upgrades and focus on stabilizing critical infrastructure.
- Assess: Conduct a comprehensive assessment of the IT system integration challenges and develop a revised implementation plan.
- Respond: Secure additional funding for IT system upgrades, bring in external IT experts to assist with the integration, and delay the referendum until the IT infrastructure is fully functional.


**STOP RULE:** Critical IT systems are deemed unfixable within a reasonable timeframe (e.g., 12 months) by independent IT experts.

---

#### FM3 - The Brussels Blackmail

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
Denmark's assumption that the EU Council will readily approve Euro adoption without significant concessions proves fatally flawed. As negotiations progress, the EU, facing its own internal pressures, demands increasingly onerous concessions from Denmark, such as increased contributions to the EU budget or stricter adherence to fiscal rules. These demands are perceived by the Danish public as a betrayal of national interests and an erosion of sovereignty. Public support for Euro adoption plummets as the perceived benefits are outweighed by the costs of the EU's demands. The referendum campaign is undermined by widespread resentment towards the EU, and the vote fails decisively. The project collapses, leaving Denmark isolated and politically weakened within the European Union.

##### Early Warning Signs
- EU officials publicly express concerns about Denmark's economic policies or commitment to European integration.
- Key EU member states signal they will demand significant concessions from Denmark.
- Public opinion polls show a sharp decline in support for the EU.

##### Tripwires
- EU demands exceed pre-defined acceptable limits (e.g., annual EU contribution increase > 10%).
- Key EU member states publicly oppose Denmark's Euro adoption proposal.
- Support for EU membership in Denmark falls below 50%.

##### Response Playbook
- Contain: Immediately suspend negotiations with the EU and reassess Denmark's negotiating position.
- Assess: Conduct a thorough analysis of the EU's demands and their potential impact on the Danish economy and public opinion.
- Respond: Explore alternative legal pathways for Euro adoption, build alliances with other EU member states, and launch a communication campaign to defend Denmark's national interests.


**STOP RULE:** The EU demands concessions that are deemed unacceptable by a majority of the Danish Parliament.

---

#### FM4 - The SME System Shock

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A4
- **Owner**: Minister of Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that Danish businesses, especially SMEs, will easily adapt to the Euro proves false. Many SMEs lack the resources or expertise to upgrade their accounting and payment systems within the transition period. This leads to widespread confusion, errors, and delays in financial transactions. SMEs struggle to comply with new regulations and reporting requirements, increasing their administrative burden and costs. This disproportionately impacts smaller businesses, leading to closures and job losses. The public, witnessing the struggles of local businesses, loses confidence in the Euro adoption process, and the project faces increasing resistance.

##### Early Warning Signs
- SME participation in government-sponsored training programs is lower than expected.
- The number of SMEs reporting difficulties with Euro-related regulations increases significantly.
- Business organizations publicly express concerns about the impact of Euro adoption on SMEs.

##### Tripwires
- SME participation in training programs <= 50% of target.
- SME compliance rate with new regulations falls below 70%.
- SME closures increase by >= 10% compared to baseline.

##### Response Playbook
- Contain: Immediately launch a targeted support program for SMEs, providing financial assistance and technical expertise.
- Assess: Conduct a thorough review of the challenges faced by SMEs and identify areas where regulations can be simplified or streamlined.
- Respond: Extend the transition period for SMEs, provide additional training and resources, and offer tax incentives to encourage compliance.


**STOP RULE:** A significant number of SMEs (e.g., >20%) are forced to close due to the challenges of Euro adoption.

---

#### FM5 - The Constitutional Quagmire

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A5
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the existing legal framework is flexible enough to accommodate Euro adoption proves disastrously wrong. The legal review reveals that significant constitutional amendments are required, triggering a lengthy and complex political process. Opposition parties seize the opportunity to obstruct the process, demanding concessions and delaying the necessary legislation. Public debate becomes highly polarized, and the referendum campaign is overshadowed by constitutional wrangling. The legal challenges drag on for years, creating uncertainty and undermining investor confidence. The project becomes mired in a constitutional quagmire, making Euro adoption impossible within a reasonable timeframe.

##### Early Warning Signs
- The legal review concludes that constitutional amendments are likely required.
- Opposition parties publicly oppose the proposed legal changes.
- The parliamentary debate on the legal framework becomes highly contentious.

##### Tripwires
- Constitutional amendments are deemed necessary by the legal review.
- Opposition parties control >= 40% of parliamentary seats.
- The parliamentary debate on the legal framework is delayed by >= 6 months.

##### Response Playbook
- Contain: Immediately halt all non-essential legal changes and focus on securing a consensus on the constitutional amendments.
- Assess: Conduct a thorough assessment of the legal challenges and develop a revised implementation plan.
- Respond: Seek a compromise with opposition parties, bring in external legal experts to assist with the legal process, and delay the referendum until the legal framework is fully resolved.


**STOP RULE:** Constitutional amendments are deemed impossible to achieve due to political gridlock.

---

#### FM6 - The Counterfeit Flood

- **Archetype**: Market/Human
- **Root Cause**: Assumption A6
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the Euro banknote and coin supply chain will be secure and reliable proves fatally flawed. A sophisticated counterfeiting operation targets the new Euro currency, flooding the market with fake banknotes and coins. The public loses confidence in the Euro as they struggle to distinguish between genuine and counterfeit currency. Businesses refuse to accept Euro banknotes, and the financial system is disrupted. The government scrambles to implement anti-counterfeiting measures, but the damage is already done. Public support for Euro adoption collapses, and the project is abandoned in disgrace.

##### Early Warning Signs
- Reports of counterfeit Euro banknotes and coins increase sharply.
- Businesses begin to refuse to accept Euro banknotes.
- Public confidence in the Euro declines significantly.

##### Tripwires
- Counterfeit Euro banknotes in circulation exceed 1% of total currency.
- More than 20% of businesses refuse to accept Euro banknotes.
- Public trust in the Euro falls below 40%.

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to educate the public about counterfeit Euro banknotes and coins.
- Assess: Conduct a thorough investigation of the counterfeiting operation and identify vulnerabilities in the supply chain.
- Respond: Implement enhanced security measures, increase law enforcement efforts, and consider recalling all Euro banknotes and coins.


**STOP RULE:** The level of counterfeit currency in circulation is deemed to pose a significant threat to the stability of the financial system.

---

#### FM7 - The Cash-Clinging Crisis

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A7
- **Owner**: Minister of Finance
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The assumption that the Danish public will readily embrace electronic payments proves overly optimistic. A significant portion of the population, particularly the elderly and those in rural areas, remain resistant to digital transactions, preferring cash for various reasons (privacy concerns, lack of access, distrust of technology). This continued reliance on physical currency complicates the Euro transition, increasing logistical costs and creating bottlenecks in the financial system. Businesses struggle to adapt to the dual currency system, and the public loses confidence in the government's ability to manage the transition smoothly. The project faces increasing financial strain and operational challenges, ultimately leading to failure.

##### Early Warning Signs
- Adoption rates for electronic payment methods stagnate or decline.
- Cash withdrawals from ATMs remain high.
- Businesses report difficulties in managing cash transactions.

##### Tripwires
- Electronic payment adoption rate <= 60% based on quarterly surveys.
- Cash withdrawals from ATMs remain above pre-transition levels.
- More than 30% of businesses report difficulties in managing cash transactions.

##### Response Playbook
- Contain: Immediately launch a targeted campaign to promote electronic payment methods, addressing public concerns and providing incentives for adoption.
- Assess: Conduct a thorough review of the barriers to electronic payment adoption and identify areas where infrastructure can be improved.
- Respond: Invest in expanding access to electronic payment infrastructure, provide training and support for vulnerable populations, and consider offering subsidies for electronic payment adoption.


**STOP RULE:** The cost of managing the physical currency system becomes unsustainable, exceeding a pre-defined budget threshold.

---

#### FM8 - The Eurozone Economic Earthquake

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Head of Engineering
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the Eurozone economy will remain stable and attractive proves catastrophically wrong. A major economic crisis erupts within the Eurozone, triggered by a sovereign debt default or a banking collapse. The crisis spreads rapidly, causing widespread economic disruption and undermining confidence in the Euro. The Danish public, witnessing the turmoil in the Eurozone, becomes deeply skeptical of joining the currency union. Support for Euro adoption plummets, and the referendum is decisively defeated. The project collapses, leaving Denmark economically isolated and politically vulnerable.

##### Early Warning Signs
- A major Eurozone country experiences a sovereign debt crisis.
- A large Eurozone bank collapses.
- Economic indicators in the Eurozone decline sharply.

##### Tripwires
- A major Eurozone country defaults on its sovereign debt.
- The Eurozone unemployment rate exceeds 12%.
- The Euro exchange rate falls below a pre-defined threshold.

##### Response Playbook
- Contain: Immediately suspend all non-essential Euro adoption activities and focus on protecting the Danish economy from the Eurozone crisis.
- Assess: Conduct a thorough assessment of the potential impact of the Eurozone crisis on Denmark.
- Respond: Implement fiscal stimulus measures, strengthen financial regulations, and explore alternative economic partnerships.


**STOP RULE:** The Eurozone economy is deemed to be in a state of irreversible decline by independent economic experts.

---

#### FM9 - The Political Pendulum Peril

- **Archetype**: Market/Human
- **Root Cause**: Assumption A9
- **Owner**: Permitting Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that there will be sufficient political consensus to maintain a stable approach to Euro adoption throughout the transition proves fatally flawed. A snap election results in a change of government, with a new ruling coalition that opposes Euro adoption. The new government immediately halts all Euro adoption activities, reversing previous decisions and undermining investor confidence. Public debate becomes highly polarized, and the project is caught in a political crossfire. The multi-year transition process is disrupted, and the project ultimately collapses due to a lack of political will and continuity.

##### Early Warning Signs
- Government approval ratings decline sharply.
- Opposition parties gain momentum in public opinion polls.
- Early elections are called.

##### Tripwires
- Government approval rating falls below 30%.
- Opposition parties gain a majority in parliament.
- Early elections are called within the next 6 months.

##### Response Playbook
- Contain: Immediately engage with the new government to advocate for the benefits of Euro adoption and seek a compromise.
- Assess: Conduct a thorough assessment of the new government's position on Euro adoption and identify areas where common ground can be found.
- Respond: Explore alternative legal pathways for Euro adoption that do not require parliamentary approval, build alliances with other political parties, and launch a communication campaign to highlight the economic benefits of Euro adoption.


**STOP RULE:** The new government formally announces its opposition to Euro adoption and terminates all related activities.
