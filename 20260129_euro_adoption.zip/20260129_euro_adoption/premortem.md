A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Danish public will overwhelmingly support Euro adoption once presented with the economic benefits. | Conduct a statistically significant poll focusing on specific economic benefits and potential drawbacks. | Poll results show less than 40% support for Euro adoption even after highlighting economic benefits. |
| A2 | The necessary IT infrastructure upgrades across all Danish banks can be completed within the projected 24-month timeframe. | Conduct a pilot program with a representative sample of banks to assess the actual time required for IT upgrades. | The pilot program indicates that the average time required for IT upgrades exceeds 24 months. |
| A3 | The EU will readily grant Denmark a simplified treaty change to lift the Euro opt-out without significant political concessions. | Engage in preliminary, informal discussions with key EU member states to gauge their willingness to support a simplified treaty change. | Key EU member states express significant reservations or demand substantial concessions in exchange for supporting a simplified treaty change. |
| A4 | The existing Danish digital ID infrastructure can be seamlessly extended to support real-time Euro transaction authentication. | Conduct a technical audit of the current digital ID system to verify its capacity for high-frequency, low-latency Euro transactions. | The audit reveals that the digital ID system cannot handle the required transaction throughput or lacks necessary security certifications. |
| A5 | Danish consumers will readily adopt cashless payment methods for everyday Euro transactions without significant incentives. | Monitor the adoption rate of cashless payments in a controlled pilot zone during the dual-circulation period. | The adoption rate in the pilot zone remains below 60% after three months of active promotion and education. |
| A6 | The Danish logistics network has sufficient capacity to handle the surge in cross-border Euro cash flows without major delays. | Simulate peak cash flow scenarios using current logistics data and transport capacity models. | The simulation shows that transit times for Euro cash exceed 48 hours during peak periods, indicating a systemic bottleneck. |
| A7 | The Danish public will accept Euro adoption without major protests or civil unrest, even if price transparency leads to perceived inflation. | Monitor public sentiment and protest activity through social media analytics and real-time polling during the dual-circulation period. | A significant, sustained increase in public protests or a sharp decline in public trust metrics occurs within the first six months. |
| A8 | The existing Danish legal framework can accommodate the complexities of Euro adoption without requiring a full constitutional amendment. | Conduct a comprehensive legal review by independent experts to identify potential conflicts with existing laws. | The legal review identifies more than five major, unresolved conflicts that would necessitate a constitutional amendment. |
| A9 | The Danish banking sector will maintain sufficient liquidity and capital buffers to withstand the transition risks associated with Euro adoption. | Perform stress tests on the banking sector using Euro-specific transition scenarios and ECB guidelines. | Stress test results show that one or more major banks fail to meet the required capital adequacy ratios. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Treaty Trap: A Financial Black Hole | Process/Financial | A3 | Finance Minister | CRITICAL (15/25) |
| FM2 | The Glitch Gridlock: A Logistical Nightmare | Technical/Logistical | A2 | Head of Engineering | CRITICAL (16/25) |
| FM3 | The Public Rejection: A Mandate Lost | Market/Human | A1 | Communications Director | HIGH (10/25) |
| FM4 | The Digital Divide: Authentication Paralysis | Technical/Logistical | A4 | CTO | HIGH (12/25) |
| FM5 | The Cash Cling: Consumer Inertia and Behavioral Resistance | Market/Human | A5 | Head of Payments | MEDIUM (6/25) |
| FM6 | The Liquidity Logjam: Euro Cash Supply Chain Breakdown | Process/Financial | A6 | Supply Chain Director | MEDIUM (8/25) |
| FM7 | The Trust Erosion: Social License to Operate | Market/Human | A7 | Social Affairs Minister | HIGH (10/25) |
| FM8 | The Legal Quagmire: Constitutional Gridlock | Process/Financial | A8 | Minister of Justice | HIGH (10/25) |
| FM9 | The Banking Sector Liquidity Crisis | Technical/Logistical | A9 | Financial Supervisory Authority | CRITICAL (15/25) |


### Failure Modes

#### FM1 - The Treaty Trap: A Financial Black Hole

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Finance Minister
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The project's financial viability hinges on securing a simplified treaty change from the EU. However, if key EU member states demand significant concessions (e.g., increased contributions to the EU budget, acceptance of stricter fiscal rules, or compromises on unrelated policy areas like immigration), the cost of the treaty change could skyrocket. This could lead to budget overruns, reduced funding for other essential programs, and ultimately, a politically untenable situation where the economic benefits of Euro adoption are outweighed by the financial burden of securing the treaty change. The Danish government might then be forced to abandon the project, having already invested significant resources.

##### Early Warning Signs
- EU negotiators begin demanding concessions beyond the scope of the Euro opt-out.
- Projected costs for securing the treaty change exceed initial estimates by more than 25%.
- Key Danish political parties withdraw support for the project due to the financial burden.

##### Tripwires
- Projected treaty negotiation costs exceed 5 billion DKK.
- EU demands Danish concessions on unrelated policy areas.
- Public debt increases by more than 3% of GDP due to treaty-related expenses.

##### Response Playbook
- Contain: Immediately halt all non-essential project spending.
- Assess: Conduct a thorough reassessment of the project's financial viability, considering the increased costs of the treaty change.
- Respond: Explore alternative options, such as seeking a more limited form of Euro participation or abandoning the project altogether.


**STOP RULE:** The projected total cost of securing the treaty change exceeds 10 billion DKK, rendering the project economically unviable.

---

#### FM2 - The Glitch Gridlock: A Logistical Nightmare

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The project assumes a smooth and timely upgrade of IT infrastructure across all Danish banks. However, if the upgrades are more complex and time-consuming than anticipated, the entire financial system could face significant disruptions. Banks might struggle to process transactions, reconcile accounts, and comply with new Euro regulations. This could lead to widespread payment delays, errors, and even system failures. The logistical challenges of coordinating upgrades across hundreds of institutions, each with its own unique systems and priorities, could prove insurmountable within the projected timeframe. The dual-circulation period could become a chaotic mess, eroding public confidence and damaging the reputation of the Danish financial system.

##### Early Warning Signs
- Banks report significant delays in completing IT upgrades.
- Testing reveals widespread compatibility issues between different banking systems.
- The cost of IT upgrades exceeds initial estimates by more than 50%.

##### Tripwires
- More than 20% of banks report IT upgrade delays exceeding 3 months.
- Payment processing times increase by more than 50% during testing.
- The number of unresolved IT compatibility issues exceeds 1000.

##### Response Playbook
- Contain: Immediately suspend all non-critical IT upgrades and focus on stabilizing core systems.
- Assess: Conduct a comprehensive audit of the IT upgrade process to identify bottlenecks and problem areas.
- Respond: Implement a phased rollout of IT upgrades, prioritizing the most critical systems and providing additional support to struggling banks.


**STOP RULE:** Critical payment systems experience a major outage lasting more than 24 hours, indicating a systemic failure of the IT upgrade process.

---

#### FM3 - The Public Rejection: A Mandate Lost

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Communications Director
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The project's success hinges on securing public support for Euro adoption through a referendum. However, if the public is not convinced of the economic benefits or is swayed by anti-Euro sentiment, the referendum could fail. This could be due to a lack of trust in the government, concerns about sovereignty, or fears about the impact on prices and wages. A failed referendum would not only derail the project but also damage the government's credibility and create political instability. The public might perceive the Euro as a threat to Danish identity and values, leading to widespread resentment and resistance. The project would become a symbol of government overreach and a rejection of European integration.

##### Early Warning Signs
- Public opinion polls show declining support for Euro adoption.
- Anti-Euro groups gain significant traction in the media and online.
- Key political figures express reservations about the project.

##### Tripwires
- Public support for Euro adoption falls below 50% in multiple polls.
- Anti-Euro petitions gain more than 100,000 signatures.
- Major media outlets begin publishing negative stories about the Euro.

##### Response Playbook
- Contain: Immediately launch a comprehensive public awareness campaign to address concerns and promote the benefits of Euro adoption.
- Assess: Conduct focus groups and surveys to understand the reasons for declining public support.
- Respond: Adjust the project's messaging and implementation to address public concerns and build trust.


**STOP RULE:** Public support for Euro adoption falls below 40% and remains there for more than 3 consecutive months, indicating a fundamental rejection of the project.

---

#### FM4 - The Digital Divide: Authentication Paralysis

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: CTO
- **Risk Level:** HIGH 12/25 (Likelihood 3/5 × Impact 4/5)

##### Failure Story
If the digital ID infrastructure cannot support the required transaction volume, the transition to a cashless Euro economy will stall. This creates a bottleneck where consumers cannot authenticate payments, leading to delays, failed transactions, and a loss of confidence in the new currency. The project's reliance on a single, unproven technological backbone introduces a critical point of failure.

##### Early Warning Signs
- Digital ID authentication failure rates exceed 1% during stress testing.
- Transaction latency increases by more than 500ms during peak usage.
- Security audits flag vulnerabilities in the ID verification process.

##### Tripwires
- Digital ID system fails to process more than 95% of transactions within 2 seconds.
- More than 5% of transactions require manual intervention due to ID issues.
- System downtime exceeds 1 hour during a peak transaction period.

##### Response Playbook
- Contain: Switch to a backup authentication method, such as physical tokens or PIN-based verification.
- Assess: Analyze the root cause of the authentication failures and prioritize critical system upgrades.
- Respond: Implement a temporary hybrid system that allows both digital and physical verification methods until the infrastructure is stabilized.


**STOP RULE:** Digital ID authentication fails for more than 5% of transactions over a 48-hour period, indicating a fundamental flaw in the technological backbone.

---

#### FM5 - The Cash Cling: Consumer Inertia and Behavioral Resistance

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Head of Payments
- **Risk Level:** MEDIUM 6/25 (Likelihood 2/5 × Impact 3/5)

##### Failure Story
The assumption that consumers will readily adopt cashless payments ignores deep-seated behavioral habits and a segment of the population that relies on cash. If adoption is slow, the dual-circulation period could become a prolonged state of inefficiency, where cash handling remains a significant cost burden. This resistance could be exacerbated by a lack of trust in digital systems or a preference for tangible currency, leading to a bifurcated economy that is harder to manage and increases the risk of fraud in the cash-based segment.

##### Early Warning Signs
- Cash usage in retail transactions remains above 40% after six months of dual circulation.
- Consumer surveys indicate a preference for cash due to privacy or security concerns.
- Merchant adoption of cashless systems is significantly lower than expected.

##### Tripwires
- Cash accounts for more than 40% of all transactions after 6 months.
- Consumer satisfaction scores for cashless payments fall below 70%.
- The cost of handling cash exceeds projections by more than 20%.

##### Response Playbook
- Contain: Launch targeted incentives for cashless adoption, such as reduced transaction fees for digital payments.
- Assess: Conduct in-depth ethnographic studies to understand consumer resistance and identify barriers.
- Respond: Develop a hybrid education and support program to build trust and improve digital literacy among resistant groups.


**STOP RULE:** Cash usage remains above 30% of all transactions for more than 12 months, indicating a failure to achieve a critical mass of cashless adoption.

---

#### FM6 - The Liquidity Logjam: Euro Cash Supply Chain Breakdown

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Supply Chain Director
- **Risk Level:** MEDIUM 8/25 (Likelihood 2/5 × Impact 4/5)

##### Failure Story
The project assumes a robust and flexible logistics network capable of handling the physical distribution of Euro cash. However, if the network is not sufficiently resilient, it could lead to localized cash shortages. This would disrupt commerce, create public frustration, and force the central bank to engage in costly emergency interventions. The financial impact of these shortages could be significant, and the reputational damage to the project could be severe.

##### Early Warning Signs
- Reports of cash shortages in specific regions or municipalities.
- Euro cash inventory levels at distribution hubs fall below 20% of projected demand.
- Delivery times for cash replenishment exceed 72 hours.

##### Tripwires
- Euro cash inventory at any hub drops below 10% of capacity.
- Delivery delays exceed 24 hours in more than 5% of shipments.
- The number of reported cash shortages by merchants exceeds 100 per day.

##### Response Playbook
- Contain: Activate emergency cash reserves and prioritize distribution to affected areas.
- Assess: Map the supply chain to identify the specific points of failure and bottlenecks.
- Respond: Diversify the logistics network by adding new distribution partners and increasing buffer stock at critical nodes.


**STOP RULE:** A region experiences a cash shortage lasting more than 48 hours, causing significant disruption to local commerce and public services.

---

#### FM7 - The Trust Erosion: Social License to Operate

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Social Affairs Minister
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
If the public perceives the Euro transition as a source of inflation or financial instability, it could lead to a collapse in social license. This would manifest as protests, strikes, or political backlash, forcing the government to scale back or abandon the project. The erosion of trust would also make future economic reforms significantly more difficult, creating a volatile and unstable environment.

##### Early Warning Signs
- A sharp increase in the frequency and size of public protests related to prices or the Euro.
- A measurable decline in public trust in government institutions and the Euro project.
- Widespread negative sentiment on social media platforms regarding the transition.

##### Tripwires
- Public trust in the government drops below 50% in national polls.
- The number of reported protests related to the Euro exceeds 10 in a single month.
- Media sentiment analysis shows a sustained negative tone for over 60 days.

##### Response Playbook
- Contain: Launch a high-visibility public relations campaign to address concerns and highlight benefits.
- Assess: Establish a citizen's assembly to gather feedback and build consensus.
- Respond: Implement targeted subsidies or price controls to mitigate the most severe impacts on vulnerable populations.


**STOP RULE:** A major, unplanned public protest involving over 1,000 participants occurs in the capital city, indicating a complete breakdown of social cohesion around the project.

---

#### FM8 - The Legal Quagmire: Constitutional Gridlock

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A8
- **Owner**: Minister of Justice
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that the existing legal framework is sufficient may be fatally flawed. If the complexities of integrating the Euro are found to be incompatible with the current constitution, the project could be halted for years while a constitutional amendment is debated and passed. This process is politically fraught and could fail, leaving Denmark in a state of legal limbo where it cannot fully commit to the Euro but cannot revert to the old system without significant cost.

##### Early Warning Signs
- Legal experts identify a fundamental conflict between Euro adoption rules and the Danish constitution.
- Parliamentary debates on the necessary legal changes become stalled or acrimonious.
- The government is forced to seek an advisory opinion from the Supreme Court.

##### Tripwires
- A formal request for a constitutional interpretation is filed with the Supreme Court.
- Parliament fails to pass the necessary enabling legislation within two consecutive sessions.
- An independent legal review concludes that a constitutional amendment is the only viable path forward.

##### Response Playbook
- Contain: Form a cross-party legal working group to draft a compromise solution.
- Assess: Commission a full impact assessment of a constitutional amendment versus a judicial workaround.
- Respond: If amendment is necessary, initiate a formal political process to build a broad consensus for the change.


**STOP RULE:** The project is legally blocked by a Supreme Court ruling that deems Euro adoption incompatible with the constitution, and no political consensus exists to amend it.

---

#### FM9 - The Banking Sector Liquidity Crisis

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A9
- **Owner**: Financial Supervisory Authority
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The banking system is the conduit for the entire transition. If banks are not sufficiently capitalized or lack the necessary liquidity buffers, they could face solvency issues when faced with the dual-currency conversion and the need to hold Euro reserves. This could trigger a credit crunch, a run on banks, or even a systemic financial crisis, bringing the entire transition to a grinding halt.

##### Early Warning Signs
- A decline in the Common Equity Tier 1 (CET1) ratio for systemically important banks.
- Banks increasing their reliance on emergency central bank liquidity facilities.
- A significant rise in non-performing loans (NPLs) during the transition period.

##### Tripwires
- The average CET1 ratio for systemically important banks falls below 10%.
- The number of banks requiring emergency liquidity assistance doubles within a quarter.
- The aggregate NPL ratio for the banking sector exceeds 5%.

##### Response Playbook
- Contain: Provide temporary, targeted liquidity support to the most affected institutions.
- Assess: Conduct on-site inspections to determine the true extent of capital shortfalls.
- Respond: Mandate a capital raise or restructuring plan for failing banks, potentially involving public recapitalization.


**STOP RULE:** A systemically important bank fails or requires a government bailout due to transition-related liquidity shortfalls.
