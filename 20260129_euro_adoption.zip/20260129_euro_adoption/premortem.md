A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The established 'Builder's Blueprint' timeline, which defers formal Opt-Out repeal negotiations until *after* 24 months of successful ERM II participation, will be politically or bureaucratically accepted by the European Commission and Council. | Dispatch the Senior EU Legal & Treaty Negotiator (Søren Brandt) to secure written, conditional confirmation from the European Commission that the proposed sequencing (ERM stability first, political repeal second) is acceptable for initiating treaty protocol engagement. | The European Commission insists on progress on Opt-Out Resolution Mechanism Selection (Decision 4) concurrent with or prior to the 12-month ERM II stability mark, demanding formal engagement before technical convergence is proven. |
| A2 | The multi-year project budget of DKK 15–25 Billion will maintain its real value over the projected 4–8 year timeline, preserving the real purchasing power of dedicated contingency funds (DKK 50M+). | The Fiscal Oversight & Budget Manager must formalize and pass the mandatory annual budget real-indexation review mechanism, linked to revised CPI forecasts, within the Joint Ministerial Consultative Body by Q4 2026. | The Ministry of Finance denies mandated inflation-indexing for non-committed capital, forcing the project to absorb projected inflation (e.g., >2% annual deviation) into the base budget, degrading the real value of the DKK 50M contingency by over 5% annually. |
| A3 | The consensus-based 'Joint Ministerial Consultative Body' (JMCB) governance structure will maintain sufficient decision velocity to redirect resources and manage risks within the mandated operational windows (e.g., reacting to technical failures or diplomatic stalls). | The Chief Transition Architect must successfully pilot a high-urgency resource redirection directive (e.g., diverting funds from Societal Readiness to the Shadow Integration Team) requiring JMCB sign-off within a strict 14-day window. | The JMCB requires three or more full Ministerial meetings (exceeding 21 days total elapsed time) to approve the pilot resource redirection, demonstrating a critical bottleneck on operational execution speed. |
| A1 | The established 'Builder's Blueprint' timeline, which defers formal Opt-Out repeal negotiations until *after* 24 months of successful ERM II participation, will be politically or bureaucratically accepted by the European Commission and Council. | Dispatch the Senior EU Legal & Treaty Negotiator (Søren Brandt) to secure written, conditional confirmation from the European Commission that the proposed sequencing (ERM stability first, political repeal second) is acceptable for initiating treaty protocol engagement. | The European Commission insists on progress on Opt-Out Resolution Mechanism Selection (Decision 4) concurrent with or prior to the 12-month ERM II stability mark, demanding formal engagement before technical convergence is proven. |
| A2 | The multi-year project budget of DKK 15–25 Billion will maintain its real value over the projected 4–8 year timeline, preserving the real purchasing power of dedicated contingency funds (DKK 50M+). | The Fiscal Oversight & Budget Manager must formalize and pass the mandatory annual budget real-indexation review mechanism, linked to revised CPI forecasts, within the Joint Ministerial Consultative Body by Q4 2026. | The Ministry of Finance denies mandated inflation-indexing for non-committed capital, forcing the project to absorb projected inflation (e.g., >2% annual deviation) into the base budget, degrading the real value of the DKK 50M contingency by over 5% annually. |
| A3 | The consensus-based 'Joint Ministerial Consultative Body' (JMCB) governance structure will maintain sufficient decision velocity to redirect resources and manage risks within the mandated operational windows (e.g., reacting to technical failures or diplomatic stalls). | The Chief Transition Architect must successfully pilot a high-urgency resource redirection directive (e.g., diverting funds from Societal Readiness to the Shadow Integration Team) requiring JMCB sign-off within a strict 14-day window. | The JMCB requires three or more full Ministerial meetings (exceeding 21 days total elapsed time) to approve the pilot resource redirection, demonstrating a critical bottleneck on operational execution speed. |
| A4 | The centralized mandate for upgrading all municipal IT systems (Decision 14.1) will be fully adhered to because local governments possess either the necessary internal capacity or sufficient budget leverage to accept the state-funded integrator on schedule. | The Logistics & Operational Readiness Coordinator must achieve 95% mandatory sign-off on initial IT modernization dependency charts from the 20 largest municipalities by Q1 2027. | More than 20% of required municipal sign-offs are delayed beyond Q1 2027, citing incompatibility problems with contracted legacy systems or insufficient local administrative bandwidth to manage the integrator. |
| A5 | The strategy of mandating automatic rounding for all long-term commercial contracts (Decision 7.1) will result in negligible overall consumer dissatisfaction, preventing significant political backlash or legal challenges that could stall post-Euro Day normalization. | The Financial & Legal Redenomination Specialist must secure formal, non-binding guidance from the Danish Bar Association confirming that the automatic rounding rule is legally robust against constitutional challenge under anticipated 'good faith' interpretation of future legislation. | Post-referendum sentiment checks (run by the Public Referendum Lead) show that >15% of the public cites 'unfair rounding practices' directed at long-term debt as a reason for lingering negative sentiment toward the transition. |
| A6 | Danmarks Nationalbank's existing strict DKK exchange rate policy can be maintained throughout the ERM II period without causing severe domestic economic contradiction (e.g., unintended mortgage market contraction or competitive pressure on non-Eurozone exporters). | The Macroeconomic Convergence & ERM Strategist must confirm, via bi-monthly proprietary modeling, that the 24-month ERM II participation horizon will not require the DKK to test its upper band fluctuation limit against the Euro target by more than 10% cumulatively. | The National Bank is forced to conduct significant, unbudgeted foreign currency market interventions (exceeding DKK 100M in reserves defense costs) to prevent the DKK from appreciating above the stable pre-ERM II target range. |
| A1 | The established 'Builder's Blueprint' timeline, which defers formal Opt-Out repeal negotiations until *after* 24 months of successful ERM II participation, will be politically or bureaucratically accepted by the European Commission and Council. | Dispatch the Senior EU Legal & Treaty Negotiator (Søren Brandt) to secure written, conditional confirmation from the European Commission that the proposed sequencing (ERM stability first, political repeal second) is acceptable for initiating treaty protocol engagement. | The European Commission insists on progress on Opt-Out Resolution Mechanism Selection (Decision 4) concurrent with or prior to the 12-month ERM II stability mark, demanding formal engagement before technical convergence is proven. |
| A2 | The multi-year project budget of DKK 15–25 Billion will maintain its real value over the projected 4–8 year timeline, preserving the real purchasing power of dedicated contingency funds (DKK 50M+). | The Fiscal Oversight & Budget Manager must formalize and pass the mandatory annual budget real-indexation review mechanism, linked to revised CPI forecasts, within the Joint Ministerial Consultative Body by Q4 2026. | The Ministry of Finance denies mandated inflation-indexing for non-committed capital, forcing the project to absorb projected inflation (e.g., >2% annual deviation) into the base budget, degrading the real value of the DKK 50M contingency by over 5% annually. |
| A3 | The consensus-based 'Joint Ministerial Consultative Body' (JMCB) governance structure will maintain sufficient decision velocity to redirect resources and manage risks within the mandated operational windows (e.g., reacting to technical failures or diplomatic stalls). | The Chief Transition Architect must successfully pilot a high-urgency resource redirection directive (e.g., diverting funds from Societal Readiness to the Shadow Integration Team) requiring JMCB sign-off within a strict 14-day window. | The JMCB requires three or more full Ministerial meetings (exceeding 21 days total elapsed time) to approve the pilot resource redirection, demonstrating a critical bottleneck on operational execution speed. |
| A4 | The centralized mandate for upgrading all municipal IT systems (Decision 14.1) will be fully adhered to because local governments possess either the necessary internal capacity or sufficient budget leverage to accept the state-funded integrator on schedule. | The Logistics & Operational Readiness Coordinator must achieve 95% mandatory sign-off on initial IT modernization dependency charts from the 20 largest municipalities by Q1 2027. | More than 20% of required municipal sign-offs are delayed beyond Q1 2027, citing incompatibility problems with contracted legacy systems or insufficient local administrative bandwidth to manage the integrator. |
| A5 | The strategy of mandating automatic rounding for all long-term commercial contracts (Decision 7.1) will result in negligible overall consumer dissatisfaction, preventing significant political backlash or legal challenges that could stall post-Euro Day normalization. | The Financial & Legal Redenomination Specialist must secure formal, non-binding guidance from the Danish Bar Association confirming that the automatic rounding rule is legally robust against constitutional challenge under anticipated 'good faith' interpretation of future legislation. | Post-referendum sentiment checks (run by the Public Referendum Lead) show that >15% of the public cites 'unfair rounding practices' directed at long-term debt as a reason for lingering negative sentiment toward the transition. |
| A6 | Danmarks Nationalbank's existing strict DKK exchange rate policy can be maintained throughout the ERM II period without causing severe domestic economic contradiction (e.g., unintended mortgage market contraction or competitive pressure on non-Eurozone exporters). | The Macroeconomic Convergence & ERM Strategist must confirm, via bi-monthly proprietary modeling, that the 24-month ERM II participation horizon will not require the DKK to test its upper band fluctuation limit against the Euro target by more than 10% cumulatively. | The National Bank is forced to conduct significant, unbudgeted foreign currency market interventions (exceeding DKK 100M in reserves defense costs) to prevent the DKK from appreciating above the stable pre-ERM II target range. |
| A7 | The National Bank's internal 'Shadow Integration Team' (SIT) resources are sufficient and skilled enough to successfully simulate and mitigate all identified technical risks (Risk 4) against the full Eurosystem requirements *before* formal ERM II entry confirmation. | The Central Bank Technical Integration Lead must present signed-off audit reports from the SIT indicating 100% technical alignment confidence across all critical payment systems (based on Assumption Q8 simulations) 12 months *before* the planned ERM II entry date. | Technical simulations require external vendor augmentation or external ECB consultancy support, necessitating engagement of unbudgeted high-cost specialized external manpower. |
| A8 | The chosen aggressive cash logistics strategy (30-day dual circulation window, Decision 6.1) will be supported by a simultaneous, highly effective public awareness campaign, meaning consumer behavior will adapt rapidly enough to avoid cash shortages or widespread reliance on informal exchange. | The Public Referendum & Change Management Lead must certify, via a nationwide pre-Euro Day survey threshold of 85% awareness regarding basic rounding rules, that the public is prepared for a swift withdrawal. | During the first 15 days of dual circulation, commercial entities report cash handling errors exceeding 1.5% of transactions, forcing the Logistics Coordinator to request an extension to the dual circulation window beyond 45 days. |
| A9 | The political mandate, once secured via a national referendum, will stabilize domestic opposition sufficiently to allow the Joint Ministerial Consultative Body (JMCB) to enforce the necessary, potentially unpopular, fiscal austerity measures required to hit the final convergence criteria (e.g., Deficit < 3% GDP). | Immediately following a 'Yes' vote in the referendum, the Fiscal Oversight & Budget Manager must successfully pass the first mandatory post-divorce austerity proposal (required for finalizing convergence) through the JMCB without any substantive amendments or coalition delays. | The JMCB requires substantial political haggling (exceeding 90 days) to pass the first post-referendum austerity measure, indicating that the political capital secured by the vote is insufficient to enforce unpopular economic decisions. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Silent Erosion: Budget Collapse During Extended ERM Drift | Process/Financial | A2 | Fiscal Oversight & Budget Manager | CRITICAL (20/25) |
| FM2 | The Brussels Deadlock: Sequencing Friction Halts Technical Progress | Technical/Logistical | A1 | Senior EU Legal & Treaty Negotiator | CRITICAL (20/25) |
| FM3 | The Consensus Choke: Governance Paralysis During Operational Crisis | Market/Human | A3 | Chief Transition Architect / Project Director | CRITICAL (16/25) |
| FM4 | The Brussels Deadlock: Sequencing Friction Halts Technical Progress | Process/Financial | A1 | Senior EU Legal & Treaty Negotiator | CRITICAL (20/25) |
| FM5 | The Velocity Drain: Resourcing Failure Under Budget Erosion | Technical/Logistical | A2 | Central Bank Technical Integration Lead | CRITICAL (20/25) |
| FM6 | The Societal Slowdown: Public Confusion Derails Referendum Momentum | Market/Human | A3 | Public Referendum & Change Management Lead | CRITICAL (20/25) |
| FM7 | The Brussels Deadlock: Sequencing Friction Halts Technical Progress | Process/Financial | A1 | Senior EU Legal & Treaty Negotiator | CRITICAL (20/25) |
| FM8 | The Velocity Drain: Resourcing Failure Under Budget Erosion | Technical/Logistical | A2 | Central Bank Technical Integration Lead | CRITICAL (20/25) |
| FM9 | The Shadow Stagnation: Unvalidated Technical Debt Post-Simulation | Technical/Logistical | A7 | Central Bank Technical Integration Lead | CRITICAL (20/25) |


### Failure Modes

#### FM1 - The Silent Erosion: Budget Collapse During Extended ERM Drift

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A2
- **Owner**: Fiscal Oversight & Budget Manager
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The chosen 'Builder's Blueprint' requires a long lead time, relying on the ERM II monitoring period (2+ years) before the referendum. Assuming stable funding proves false when sustained, albeit low, inflation erodes the real value of committed operational and contingency funds. The DKK 50M cash logistics contingency, if not inflation-indexed, loses significant buying power within 3 years. This gradual financial depletion forces the Fiscal Oversight & Budget Manager to make impossible trade-offs late in the project lifecycle: either scale back critical risk mitigation (e.g., reducing the quality of technical shadow testing or cheapening cash security contracts) or delay the referendum timeline further to secure emergency supplementary funding, leading to project stagnation and political fallout due to missed budgetary promises.

##### Early Warning Signs
- Fiscal Oversight & Budget Manager reports a YOY change in the Real Value Erosion Index (RVEI) exceeding 1.5% for 2 consecutive reporting periods.
- The cost forecast for multi-year, fixed-price contracts (e.g., logistics security) exceeds the remaining budget allocation by > 8% in real terms.
- The Joint Ministerial Consultative Body requires more than two review cycles to approve the activation of the inflation-indexed budget contingency (if utilized).

##### Tripwires
- Annual projected budget erosion exceeds DKK 300 Million based on CPI variance.
- The DKK 50M ring-fenced contingency fund reserve drops below 80% of its inflation-adjusted baseline value.

##### Response Playbook
- Contain: Immediately freeze all non-essential new procurement contracts exceeding DKK 1 Million pending budget re-baseline review.
- Assess: Fiscal Oversight Manager performs mandatory, immediate, quarterly budget real-indexation audit and presents impact findings to the Chief Transition Architect.
- Respond: If indexation gap exceeds DKK 500M, the JMCB must immediately vote to pause public awareness campaigns (Decision 11) to redirect freed operational capital to secure necessary technical integration resources (Risk 4 mitigation).


**STOP RULE:** If the real value of the committed transition budget is projected to be insufficient to fund all active risk mitigation strategies (e.g., Shadow Team, Contingency) for the remaining timeline by more than 15%.

---

#### FM2 - The Brussels Deadlock: Sequencing Friction Halts Technical Progress

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A1
- **Owner**: Senior EU Legal & Treaty Negotiator
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The strategy assumes the EU will accept Denmark's preferred sequencing: proving economic performance (24 months in ERM II) before formally unlocking the opt-out repeal negotiation. If the European Commission or key member states refuse this condition—demanding proof of legal intent (Decision 4) first—the diplomatic channel freezes. Because the 'Shadow Integration Team' (Decision 8) must align its work based on the anticipated legal entry date, this diplomatic deadlock prevents the National Bank from securing final, authoritative technical interfaces with the ECB. This creates a multi-layered failure: legally stalled, technically unvalidated, and politically exposed, leading to critical delays in payment system integration (Risk 4) that cannot be recovered even after the political agreement is finally secured.

##### Early Warning Signs
- The EU Opt-Out Engagement Taskforce reports no formal scheduling commitment for the Extraordinary European Council Dialogue 18 months post-Political Decision.
- ECB technical liaison staff begin delaying provision of necessary interface specifications to the Shadow Integration Team citing 'lack of formal political mandate confirmation.'
- Key EU Member States publicly signal skepticism regarding the sequencing trade-off via non-official channels.

##### Tripwires
- No formal slot confirmed for Extraordinary European Council Dialogue 720 days post-Political Decision.
- Technical documentation exchange with ECB related to TARGET2 integration falls behind schedule by > 90 critical path days.

##### Response Playbook
- Contain: Immediately pivot the EU engagement team to focus exclusively on securing a *bilateral, non-binding* political assurance guaranteeing post-ERM stability review acceptance, leveraging historical cooperation agreements.
- Assess: Central Bank Technical Integration Lead must immediately provide a quantified impact assessment (in technical milestone delays) for every 30-day halt in diplomatic progress.
- Respond: If diplomatic block persists past 12 months, the Chief Transition Architect must formally advise the JMCB to initiate the legally permissible 'unilateral declaration' pathway (Decision 4.3), accepting higher domestic procedural risk to force EU engagement.


**STOP RULE:** If the legally binding negotiation timeline for the Opt-Out Repeal Protocol extends beyond the earliest projected referendum date (Q1 2030), triggering a guaranteed timeline breach of the 8-year maximum window.

---

#### FM3 - The Consensus Choke: Governance Paralysis During Operational Crisis

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Chief Transition Architect / Project Director
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The reliance on the consensus-driven Joint Ministerial Consultative Body (JMCB) is intended to build trust, but fails when short, urgent operational decisions are required. For instance, if a major commercial bank fails an early IT audit (Risk 7) or a sudden currency volatility spike necessitates rapid intervention (Risk 8), the requirement for ministerial consensus causes a critical delay. This bureaucratic inertia prevents the timely deployment of ring-fenced contingency funds or the redirection of specialized technical staff (Shadow Team). The failure is not in the plan itself, but in the inability of the governance structure to execute the plan rapidly when operational time windows (like defending the DKK peg or fixing a systemic IT bug) are measured in days, not weeks.

##### Early Warning Signs
- The average sign-off time for operational directives (under DKK 20M value) within the JMCB exceeds 10 working days for three successive monthly reviews.
- The Logistics Coordinator reports that 40% of urgent requests for cash synchronization adjustments are returned for 'further clarification' rather than approval/rejection.
- The Chief Transition Architect dedicates >25% of steering time to resolving procedural debates rather than strategic milestone tracking.

##### Tripwires
- Delegated spending authority thresholds are exceeded or ignored five times in a single quarter.
- The average time for approving critical contingency fund releases exceeds 17 days.

##### Response Playbook
- Contain: The Chief Transition Architect issues an immediate executive directive unilaterally delegating authority for *all* financial contingency releases (up to DKK 5M) to the Fiscal Oversight & Budget Manager for a 90-day trial period, effective immediately.
- Assess: The Architect conducts an emergency 'Decision Velocity Audit' across all JMCB members to formally benchmark current decision lag against the established service level agreements for urgency thresholds.
- Respond: In the following JMCB session, formally propose an amendment to the Governance Charter (Decision 5.2), codifying clear, tiered thresholds where specialized Leads (Technical, Legal, Fiscal) are granted temporary binding authority based on declared risk urgency, requiring only notification, not pre-approval.


**STOP RULE:** If the JMCB formally rejects the Chief Transition Architect's proposal to grant time-bound executive delegation for operational crisis management, confirming the structure is incapable of crisis response.

---

#### FM4 - The Brussels Deadlock: Sequencing Friction Halts Technical Progress

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Senior EU Legal & Treaty Negotiator
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The strategy assumes the EU will accept Denmark's preferred sequencing: proving economic performance (24 months in ERM II) before formally unlocking the opt-out repeal negotiation. If the European Commission or key member states refuse this condition—demanding proof of legal intent (Decision 4) first—the diplomatic channel freezes. Because the 'Shadow Integration Team' (Decision 8) must align its work based on the anticipated legal entry date, this diplomatic deadlock prevents the National Bank from securing final, authoritative technical interfaces with the ECB. This creates a multi-layered failure: legally stalled, technically unvalidated, and politically exposed, leading to critical delays in payment system integration (Risk 4) that cannot be recovered even after the political agreement is finally secured.

##### Early Warning Signs
- The EU Opt-Out Engagement Taskforce reports no formal scheduling commitment for the Extraordinary European Council Dialogue 18 months post-Political Decision.
- ECB technical liaison staff begin delaying provision of necessary interface specifications to the Shadow Integration Team citing 'lack of formal political mandate confirmation.'
- Key EU Member States publicly signal skepticism regarding the sequencing trade-off via non-official channels.

##### Tripwires
- No formal slot confirmed for Extraordinary European Council Dialogue 720 days post-Political Decision.
- Technical documentation exchange with ECB related to TARGET2 integration falls behind schedule by > 90 critical path days.

##### Response Playbook
- Contain: Immediately pivot the EU engagement team to focus exclusively on securing a *bilateral, non-binding* political assurance guaranteeing post-ERM stability acceptance, leveraging historical cooperation agreements.
- Assess: Central Bank Technical Integration Lead must immediately provide a quantified impact assessment (in technical milestone delays) for every 30-day halt in diplomatic progress.
- Respond: If diplomatic block persists past 12 months, the Chief Transition Architect must formally advise the JMCB to initiate the legally permissible 'unilateral declaration' pathway (Decision 4.3), accepting higher domestic procedural risk to force EU engagement.


**STOP RULE:** If the legally binding negotiation timeline for the Opt-Out Repeal Protocol extends beyond the earliest projected referendum date (Q1 2030), triggering a guaranteed timeline breach of the 8-year maximum window.

---

#### FM5 - The Velocity Drain: Resourcing Failure Under Budget Erosion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Central Bank Technical Integration Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The long timeline (4-8 years) exposes the fixed budget commitment to cumulative inflation (Risk 2/Issue 2). If the budget is not indexed, the fixed DKK 15-25 Billion budget loses substantial real value. This erosion manifests most critically in compensating for specialized technical acceleration needs. Specifically, the ICT requirements for the Shadow Integration Team (Decision 8) or the necessary incentives for municipal IT compliance (Decision 14) become underfunded relative to market rates for expert contractors. The Central Bank Technical Integration Lead receives insufficient funds to secure competitive external cybersecurity consultants, forcing reliance on internal staff whose time is already strained by existing duties, leading directly to delayed system integration ($R4$) and forcing a pivot away from the planned aggressive dual-circulation timeline ($D6$).

##### Early Warning Signs
- Fiscal Oversight reports indicate accumulated budget consumption is 5% ahead of the inflation-indexed baseline forecast at the 3-year mark.
- Hiring pipeline for specialized technical roles (e.g., ISO 20022 migration experts) reports a minimum of 20% variance between tendered cost and final secured contract price.
- The Logistics & Operational Readiness Coordinator signals delays in pre-qualifying premium cash-in-transit security providers due to pricing caps being insufficient.

##### Tripwires
- The rolling 12-month burn rate analysis shows that committed CAPEX for technical integration is lagging the planned milestone schedule by >60 critical path days.
- The DKK 50M contingency fund drops below 75% utilization capacity due to unplanned inflation adjustments in core operational contracts.

##### Response Playbook
- Contain: Immediately impose a 45-day hiring and procurement freeze across all non-Mandatory Convergence Stabilization workstreams, protecting capital earmarked for core technical integration buffers.
- Assess: Chief Transition Architect mandates an emergency 'Real Value Re-baseline' exercise across all workstreams, projecting required funding shortfall if inflation continues at the last reported rate for the next 24 months.
- Respond: If shortfall exceeds DKK 500 Million, the JMCB must immediately halt non-essential external-facing Societal Readiness expenditure (Decision 11) and reallocate those funds directly to secure binding contracts for the Shadow Integration Team, sacrificing public momentum buffer for technical surety.


**STOP RULE:** If the projected funding deficit, after internal cost optimization, necessitates cutting scope from either the core technical integration (Decision 8) or the legal contingency mandates (Issue 3 mitigation).

---

#### FM6 - The Societal Slowdown: Public Confusion Derails Referendum Momentum

- **Archetype**: Market/Human
- **Root Cause**: Assumption A3
- **Owner**: Public Referendum & Change Management Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The project relies on the governance structure (JMCB) to quickly approve rapid adjustments to the Societal Readiness Pacing (Decision 11) based on real-time public feedback (gathered via the EASF). Assumption A3 proves false when slow decision-making paralyzes the response to negative sentiment. For example, if focus groups reveal profound misunderstanding about contract rounding (Risk 7) or if confusion spikes geographically, the Public Referendum Lead cannot rapidly deploy corrective messaging or targeted outreach (e.g., municipal IT audit follow-up based on Decision 14). This delay (weeks or months) allows negative narratives to solidify in the public domain, leading to a drop in voter confidence below the critical threshold, causing the Folketinget to delay or reject the referendum timing.

##### Early Warning Signs
- The average time to approve emergency targeted communication supplements (post-sentiment audit) exceeds 20 calendar days across 3 consecutive requests.
- The measured Societal Readiness Score (SRS) drops by 5 percentage points or more between quarterly reports.
- Internal communications team reports resource gridlock due to waiting on JMCB approval to activate surge capacity.

##### Tripwires
- Sentiment tracking shows public satisfaction regarding 'contract fairness' drops below 60% approval.
- The time taken to approve a localized, high-urgency communication deployment exceeds 18 days on two consecutive occasions.

##### Response Playbook
- Contain: Public Referendum Lead issues an immediate, self-funded 'holding statement' of generalized reassurance and announces an 'intention to clarify complex points' without committing to specific policy changes until JMCB processes are streamlined.
- Assess: Conduct an immediate high-priority internal mapping of the JMCB approval process against the three most urgent pending readiness decisions identified by the Legal and Technical leads, identifying specific procedural bottlenecks.
- Respond: The Lead formally presents the bottleneck audit findings to the Chief Transition Architect, framing the issue as a critical path crisis, and proposes temporarily elevating specific risk category approvals (e.g., all Risk 7 messaging adjustments) to an executive signer (e.g., PM's Chief of Staff) for a mandatory 60-day period until governance is resolved.


**STOP RULE:** If the Societal Readiness Score (SRS) drops below the threshold that historically predicts referendum failure (e.g., <55% favorable disposition) and the JMCB cannot approve remediation/messaging pivots within 30 days.

---

#### FM7 - The Brussels Deadlock: Sequencing Friction Halts Technical Progress

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A1
- **Owner**: Senior EU Legal & Treaty Negotiator
- **Risk Level:** CRITICAL 20/25 (Likelihood 5/5 × Impact 4/5)

##### Failure Story
The strategy assumes the EU will accept Denmark's preferred sequencing: proving economic performance (24 months in ERM II) before formally unlocking the opt-out repeal negotiation. If the European Commission or key member states refuse this condition—demanding proof of legal intent (Decision 4) first—the diplomatic channel freezes. Because the 'Shadow Integration Team' (Decision 8) must align its work based on the anticipated legal entry date, this diplomatic deadlock prevents the National Bank from securing final, authoritative technical interfaces with the ECB. This creates a multi-layered failure: legally stalled, technically unvalidated, and politically exposed, leading to critical delays in payment system integration (Risk 4) that cannot be recovered even after the political agreement is finally secured.

##### Early Warning Signs
- The EU Opt-Out Engagement Taskforce reports no formal scheduling commitment for the Extraordinary European Council Dialogue 18 months post-Political Decision.
- ECB technical liaison staff begin delaying provision of necessary interface specifications to the Shadow Integration Team citing 'lack of formal political mandate confirmation.'
- Key EU Member States publicly signal skepticism regarding the sequencing trade-off via non-official channels.

##### Tripwires
- No formal slot confirmed for Extraordinary European Council Dialogue 720 days post-Political Decision.
- Technical documentation exchange with ECB related to TARGET2 integration falls behind schedule by > 90 critical path days.

##### Response Playbook
- Contain: Immediately pivot the EU engagement team to focus exclusively on securing a *bilateral, non-binding* political assurance guaranteeing post-ERM stability acceptance, leveraging historical cooperation agreements.
- Assess: Central Bank Technical Integration Lead must immediately provide a quantified impact assessment (in technical milestone delays) for every 30-day halt in diplomatic progress.
- Respond: If diplomatic block persists past 12 months, the Chief Transition Architect must formally advise the JMCB to initiate the legally permissible 'unilateral declaration' pathway (Decision 4.3), accepting higher domestic procedural risk to force EU engagement.


**STOP RULE:** If the legally binding negotiation timeline for the Opt-Out Repeal Protocol extends beyond the earliest projected referendum date (Q1 2030), triggering a guaranteed timeline breach of the 8-year maximum window.

---

#### FM8 - The Velocity Drain: Resourcing Failure Under Budget Erosion

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Central Bank Technical Integration Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The long timeline (4-8 years) exposes the fixed budget commitment to cumulative inflation (Risk 2/Issue 2). If the budget is not indexed, the fixed DKK 15-25 Billion budget loses substantial real value. This erosion manifests most critically in compensating for specialized technical acceleration needs. Specifically, the ICT requirements for the Shadow Integration Team (Decision 8) or the necessary incentives for municipal IT compliance (Decision 14) become underfunded relative to market rates for expert contractors. The Central Bank Technical Integration Lead receives insufficient funds to secure competitive external cybersecurity consultants, forcing reliance on internal staff whose time is already strained by existing duties, leading directly to delayed system integration ($R4$) and forcing a pivot away from the planned aggressive dual-circulation timeline ($D6$).

##### Early Warning Signs
- Fiscal Oversight reports indicate accumulated budget consumption is 5% ahead of the inflation-indexed baseline forecast at the 3-year mark.
- Hiring pipeline for specialized technical roles (e.g., ISO 20022 migration experts) reports a minimum of 20% variance between tendered cost and final secured contract price.
- The Logistics & Operational Readiness Coordinator signals delays in pre-qualifying premium cash-in-transit security providers due to pricing caps being insufficient.

##### Tripwires
- Rolling 12-month burn rate analysis shows that committed CAPEX for technical integration is lagging the planned milestone schedule by >60 critical path days.
- The DKK 50M ring-fenced contingency fund reserve drops below 75% of its inflation-adjusted baseline value.

##### Response Playbook
- Contain: Immediately impose a 45-day hiring and procurement freeze across all non-Mandatory Convergence Stabilization workstreams, protecting capital earmarked for core technical integration buffers.
- Assess: Chief Transition Architect mandates an emergency 'Real Value Re-baseline' exercise across all workstreams, projecting required funding shortfall if inflation continues at the last reported rate for the next 24 months.
- Respond: If shortfall exceeds DKK 500 Million, the JMCB must immediately vote to pause public awareness campaigns (Decision 11) to redirect freed operational capital to secure binding contracts for the Shadow Integration Team, sacrificing public momentum buffer for technical surety.


**STOP RULE:** If the projected funding deficit, after internal cost optimization, necessitates cutting scope from either the core technical integration (Decision 8) or the legal contingency mandates (Issue 3 mitigation).

---

#### FM9 - The Shadow Stagnation: Unvalidated Technical Debt Post-Simulation

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A7
- **Owner**: Central Bank Technical Integration Lead
- **Risk Level:** CRITICAL 20/25 (Likelihood 4/5 × Impact 5/5)

##### Failure Story
The Builder's Blueprint relies heavily on the 'Shadow Integration Team' (SIT) to de-risk technical integration ahead of the formal ERM II entry timeline. Assumption A7 posits that the SIT's internal simulations are sufficient to guarantee alignment with the complex Eurosystem requirements (Risk 4). If the SIT lacks real-time, externally validated access, their simulated environment may fail to surface critical discrepancies in cross-system communication protocols against the actual ECB infrastructure baseline. This technical debt remains hidden until formal linkage begins, leading to a catastrophic, non-recoverable bottleneck upon ERM II entry confirmation. Remediation requires emergency, high-cost external specialization and likely extends the technical integration window past the 24-month ERM II requirement, blocking the political path to referendum.

##### Early Warning Signs
- External consultant fees required for technical remediation exceed DKK 10 Million in a single quarter following ERM II entry notification.
- The SIT reports a variance of >5 major non-conformities against documented ECB connectivity standards during their final internal audit checkpoint.
- The Central Bank Technical Integration Lead requests an extension to the schedule for external penetration testing of the integrated systems.

##### Tripwires
- Formal ECB feedback (post-ERM II entry) reveals three or more critical technical integration points require correction within the first 90 days.
- The SIT reports that securing required access for simulated data exchange with non-Danish Eurosystem nodes is taking >60 days longer than projected.

##### Response Playbook
- Contain: Immediately isolate all non-essential development streams dependent on the suspect Eurosystem interface and revert to validated DKK protocol standards for all ongoing domestic operations.
- Assess: Mandate an independent, external audit firm to conduct a parallel, rapid gap analysis comparing SIT simulation outputs against known ECB technical specifications, funded immediately from the contingency reserve.
- Respond: If critical gaps are confirmed, the JMCB must immediately approve a 6-month pause on all non-essential Commercial Contract Re-denomination work (Decision 7) to redirect legal and technical manpower to address the core infrastructure failure.


**STOP RULE:** If external validation confirms that technical remediation requires an integration time extension exceeding 180 days, effectively eliminating the timeline buffer before the mandatory referendum window.
