## Positive Constraints

- Denmark adopts the euro: national transition plan
- Replace the Danish krone (DKK) with the euro (EUR)
- Respect Denmark's current EU opt-out on the single currency
- Outline the legal, political, and operational path from opt-out to adoption
- Include referendum
- Include treaty change if needed
- Include a managed transition
- Cover legal and treaty steps
- Cover economic and financial transition
- Cover communication and public preparedness
- Cover practical conversion
- Cover timeline and milestones from political decision to full euro use
- Compatible with EU and ECB rules for euro adoption
- Denmark joins the existing euro area
- Respect Danish constitutional and referendum practice
- Acknowledge political and exchange-rate uncertainty
- Include risk register and contingency options
- Indicate where the plan has cost implications
- Assume a multi-year process (e.g. 4–8 years from decision to full euro adoption)
- Clear sequence: political decision → referendum → treaty/legal steps → ERM II and convergence → conversion period → euro day and withdrawal of krone
- Deliverables: Executive summary
- Deliverables: legal and treaty roadmap
- Deliverables: economic and financial transition plan
- Deliverables: communication and change-management strategy
- Deliverables: implementation timeline with gates and dependencies
- Deliverables: risk and sensitivity analysis
- Deliverables: a short section on lessons from other euro adoptions
- Authoritative and ministerial tone
- Prefer a realistic, sequenced scenario

## Negative Constraints

- Do not use Cryptocurrency
- Do not use blockchain
- Do not use CBDC as replacement for the transition plan
- Do not suggest that Denmark can adopt the euro without changing the current opt-out
- Do not suggest that Denmark can adopt the euro without a referendum where constitutionally required
