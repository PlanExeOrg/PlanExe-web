## Positive Constraints

- Plan for Denmark to replace Danish krone (DKK) with the euro (EUR)
- Plan must outline the legal, political, and operational path from opt-out to adoption
- Include referendum
- Include treaty change if needed
- Include a managed transition
- Assume a government decision to pursue adoption
- Scope: Cover legal and treaty steps (domestic law, EU negotiation, referendum design and timing)
- Scope: Cover economic and financial transition (central bank, commercial banks, payment systems, rounding rules, dual circulation period)
- Scope: Cover communication and public preparedness (citizens, businesses, municipalities, media)
- Scope: Cover practical conversion (prices, wages, contracts, IT systems, cash and coin logistics)
- Scope: Cover timeline and milestones from political decision to full euro use
- Plan must include risk register and contingency options
- Indicate where the plan has cost implications (e.g. public information campaigns, IT and logistics, legal and advisory work)
- Suggest rough order-of-magnitude ranges for cost implications where possible
- Timeline assumption: multi-year process (e.g. 4–8 years from decision to full euro adoption)
- Timeline sequence: political decision → referendum → treaty/legal steps → ERM II and convergence → conversion period → euro day and withdrawal of krone
- Deliverable: Executive summary
- Deliverable: Legal and treaty roadmap
- Deliverable: Economic and financial transition plan
- Deliverable: Communication and change-management strategy
- Deliverable: Implementation timeline with gates and dependencies
- Deliverable: Risk and sensitivity analysis
- Deliverable: Short section on lessons from other euro adoptions (e.g. Baltic states, Slovakia)
- Tone: Authoritative and ministerial
- Prefer a realistic, sequenced scenario rather than an overly compressed or politically naive timeline
- Project start ASAP

## Negative Constraints

- Do not assume a "Nordic euro" or separate currency union
- Do not assume Denmark joins without changing the current opt-out or without a referendum where constitutionally required
- Avoid fixing a total budget; focus on credible phases and cost drivers
- Do not use Cryptocurrency
- Do not use blockchain
- Do not use CBDC as replacement for the transition plan (CBDC may be mentioned only in passing as future context)
