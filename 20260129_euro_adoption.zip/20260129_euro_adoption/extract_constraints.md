## Positive Constraints

- Plan must respect Denmark's current EU opt-out on the single currency
- Plan must be compatible with EU and ECB rules for euro adoption (convergence criteria, ERM II, etc.)
- No assumption of a Nordic euro or separate currency union; Denmark joins the existing euro area
- Respect Danish constitutional and referendum practice
- Acknowledge political and exchange-rate uncertainty; include risk register and contingency options
- Indicate budget implications for public information campaigns, IT and logistics, legal and advisory work with rough order-of-magnitude ranges
- Timeline assumes a multi-year process (4–8 years) with sequence: political decision → referendum → treaty/legal steps → ERM II and convergence → conversion period → euro day and withdrawal of krone
- Deliverables include executive summary, legal and treaty roadmap, economic and financial transition plan, communication strategy, implementation timeline, risk analysis, and lessons from other euro adoptions
- Tone must be authoritative and ministerial, suitable for Denmark's ministers

## Negative Constraints

- Do not use cryptocurrency, blockchain, or CBDC as replacement for the transition plan
- Do not suggest Denmark can adopt the euro without changing the current opt-out
- Do not suggest Denmark can adopt the euro without a referendum where constitutionally required
