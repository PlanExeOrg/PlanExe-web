**Goal Statement:** Execute a multi-year national transition plan for Denmark to replace the Danish Krone (DKK) with the Euro (EUR), achieving full euro adoption within 4 to 8 years following a political decision, contingent upon a successful national referendum and compliance with all EU/ECB convergence criteria.

## SMART Criteria

- **Specific:** Successfully transition Denmark's national currency from the Danish Krone to the Euro, following a process encompassing legal opt-out removal, ERM II participation, and nationwide operational conversion.
- **Measurable:** Completion is measured by achieving full euro use across all legal, financial, and physical domains, marking the end of the DKK withdrawal period, within the 4 to 8 year timeframe post-political decision.
- **Achievable:** The plan is achievable by utilizing the chosen 'Builder's Blueprint' strategy, which phases political commitment behind demonstrated economic convergence, aligning with EU/ECB requirements and existing Danish constitutional/referendum practice.
- **Relevant:** This goal is necessary as it fulfills the overarching strategic government decision to abandon the permanent opt-out and join the Euro Area, impacting national sovereignty, monetary policy, and economic integration.
- **Time-bound:** 4 to 8 years from the initial political decision to full euro adoption.

## Dependencies

- Securing a high-level EU political agreement on the mechanism for lifting the opt-out.
- Successful domestic constitutional review and passage of enabling legislation.
- Successful national referendum yielding a mandate for accession.
- Fulfilling minimum 24-month participation in ERM II and all primary ECB convergence criteria.
- Successful integration of Danmarks Nationalbank systems with Eurosystem infrastructure.

## Resources Required

- Expert legal and diplomatic advisory teams for EU negotiation.
- Budgeted public financing for multi-year transition (Estimated DKK 15–25 Billion reference range).
- Technical workforce for IT system integration and financial modeling (via secondments/consultants).
- Funding for mandatory public information and readiness campaigns.
- Physical infrastructure for secure cash logistics (storage, transport, destruction).

## Related Goals

- Successful navigation of Danish constitutional requirements for treaty amendment.
- Achieving primary Maastricht convergence criteria (inflation, deficit).
- Full integration into the Eurosystem's operational frameworks (e.g., payment systems).

## Tags

- Euro Adoption
- DKK Exit
- EU Opt-Out
- Monetary Union
- National Transition
- Referendum

## Risk Assessment and Mitigation Strategies


### Key Risks

- Failure to secure unanimous EU agreement/protocol amendment to lift DKK opt-out.
- Danish electorate rejecting the treaty change/accession in the national referendum.
- Failure to meet ECB primary convergence criteria (e.g., fiscal stability) during the ERM II period.
- Significant delays in Danmarks Nationalbank integration with Eurosystem technical infrastructure (e.g., TARGET2).

### Diverse Risks

- Decision-making paralysis within the Joint Ministerial Consultative Body slowing critical directives.
- Speculative market pressure or financial instability triggered by the chosen DKK pre-entry parity.
- Widespread legal disputes arising from mandatory re-denomination of existing commercial contracts.
- Logistical bottlenecks or security failures during the defined 30-day dual cash circulation period.

### Mitigation Plans

- Initiate parallel, conditional diplomatic tracks immediately, linking Opt-Out negotiation sequencing to 12-month ERM II stability mark to address EU sequencing risk.
- Implement continuous, high-quality communication campaigns emphasizing benefits post-referendum decision, and ensure the referendum design is simple and clearly conditional on convergence fulfillment.
- Adopt aggressive technical alignment, implementing ECB statistical reporting immediately post-referendum for early compliance audits, and maintaining strict historical DKK exchange rate policy pre-ERM II.
- Establish a 'Shadow Integration Team' immediately to conduct full-scale, non-binding alignment simulations with the ECB/Eurosystem independent of political progress to isolate technical readiness risks.
- Mandate automatic, legally-defined rounding for all existing long-term contracts upon Euro Day, with associated preparatory legislation automatically repealed if the referendum fails, protecting sunk costs.
- Ring-fence contingency capital (DKK 50M+) and secure multiple geographically diverse, specialized European cash-in-transit contracts immediately to support aggressive 30-day cash withdrawal window.
- Empower the Joint Ministerial Consultative Body with clear delegation thresholds for local directors to issue binding directives on technical matters, preventing bureaucratic stagnation.

## Stakeholder Analysis


### Primary Stakeholders

- Denmark's Ministers (Steering Committee via Joint Ministerial Consultative Body)
- Folketinget (Parliament)
- Danmarks Nationalbank (Central Bank Operations)
- Danish Public (Voters via Referendum)

### Secondary Stakeholders

- EU Institutions (European Commission, ECB, Eurogroup)
- Danish FSA (Financial Regulation & Supervision)
- Commercial Banks and Payment Providers (Operational Execution)
- Business and Employer Organisations (Contract/IT readiness)
- Trade Unions (Wage/Contract impact)

### Engagement Strategies

- Primary Stakeholders (Ministers, Nationalbank): Require mandatory weekly progress reports during preparatory phases and consensus-based decision-making via the Joint Ministerial Consultative Body.
- Folketinget: Provide detailed legal roadmap briefings quarterly, focusing on treaty amendment progress and constitutional compliance needs.
- EU Institutions: Maintain continuous, high-level diplomatic engagement regarding the Opt-Out repeal mechanism and ERM II entry strategy.
- Commercial Banks/Business Groups: Mandate quarterly updates via the Economic Alignment Stakeholder Forum (EASF), requiring published compliance roadmaps for IT migration and contract re-denomination.
- Danish Public: Launch targeted, sector-specific communication campaigns based on Societal Readiness Pacing, ensuring messaging focuses on verifiable economic advantages post-referendum.

## Regulatory and Compliance Requirements


### Permits and Licenses

- Extraordinary European Council Session Decision for Opt-Out Repeal Protocol Amendment (or equivalent legal endorsement).
- ECB Approval for formal entry into ERM II.
- National legislative approval (Folketinget) for treaty changes and domestic monetary law amendments.

### Compliance Standards

- Primary Maastricht Convergence Criteria (Deficit, Debt, Inflation, Interest Rates).
- ECB requirements for ERM II participation (Minimum 24 months stability).
- Danish Constitutional requirements concerning national referenda and treaty ratification.
- ECB climate-related financial risk reporting and stress testing protocols (proactively adopted).

### Regulatory Bodies

- European Commission (Treaty interpretation and negotiation oversight)
- European Central Bank (ECB) (Convergence assessment and ERM II monitoring)
- Eurogroup (Political endorsement of accession)

### Compliance Actions

- Initiate formal dialogue with the European Commission regarding the sequencing of Opt-Out repeal relative to ERM II participation.
- Establish an internal audit function within Danmarks Nationalbank to benchmark operations against full ESCB standards prior to ERM II entry.
- Design and schedule the national referendum contingent on ECB convergence checklist fulfillment affirmation by the Folketinget.
- Implement robust statistical reporting frameworks aligned with ECB requirements immediately post-political decision, irrespective of ERM II entry date.