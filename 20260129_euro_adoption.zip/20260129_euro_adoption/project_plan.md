**Goal Statement:** Enable Denmark to adopt the euro as its national currency by establishing a legally sound, politically legitimate, operationally robust, and EU-compliant transition pathway that respects the existing opt-out and requires a referendum.

## SMART Criteria

- **Specific:** Achieve full euro adoption for Denmark by completing a defined sequence: political decision, constitutionally compliant referendum, EU treaty change to lift the opt-out, ERM II membership meeting convergence criteria, dual-circulation operations, and final cash and electronic conversion.
- **Measurable:** Measured by: (1) successful referendum outcome meeting predefined turnout and support thresholds; (2) formal EU treaty modification ratified; (3) sustained DKK/EUR parity within agreed fluctuation band for 24 months; (4) completion of dual-circulation and migration of 100% of retail and public-sector payments to the euro; (5) operational continuity with predefined KPIs (e.g., payment success rate, settlement latency).
- **Achievable:** Achievable given Denmark’s EU membership, prior ERM experience, strong public institutions, and capacity to implement large-scale legal, technical, and communication programs; contingent on securing political consensus and EU goodwill.
- **Relevant:** Relevant because it delivers a sovereign monetary choice aligned with EU integration, reduces long-term transaction costs, and enhances financial stability while honoring constitutional practices and EU rules.
- **Time-bound:** Timeline of 4–8 years from political decision to full adoption; key gates: referendum within 12 months of decision, treaty change within 6–18 months post-referendum, ERM II entry within 6–12 months after treaty, dual circulation lasting 12–24 months, full adoption 4–8 years from start.

## Dependencies

- Political decision to pursue euro adoption and secure parliamentary mandate
- Constitutional and legislative framework enabling a binding referendum
- EU agreement to a treaty modification lifting Denmark’s opt-out
- Successful referendum meeting predefined thresholds
- Completion of ERM II membership and convergence with Maastricht criteria
- Operational readiness of payment systems, IT infrastructure, and cash logistics
- Public and institutional preparedness through communication and training

## Resources Required

- Dedicated Cross-Ministerial Transition Office and specialized units (Legal, IT, Operations, Communications)
- Technical platforms for dual-currency processing, real-time reconciliation, and settlement
- Euro liquidity reserves and contingency funding for cash and systemic needs
- Legal advisory capacity for treaty and domestic law alignment
- Public communication infrastructure and stakeholder engagement programs
- Monitoring and evaluation frameworks aligned with EU reporting standards

## Related Goals

- Strengthen Denmark’s monetary policy alignment with the Eurosystem
- Modernize Danish payment infrastructure and financial inclusion
- Enhance fiscal discipline and convergence with EU standards
- Build institutional capacity for complex multi-year public programs

## Tags

- monetary-transition
- euro-adoption-denmark
- referendum
- ERM-II
- EU-opt-out
- ministerial-planning
- cross-agency-coordination

## Risk Assessment and Mitigation Strategies


### Key Risks

- EU treaty change blocked or delayed by political opposition
- Referendum fails to achieve required thresholds
- Inability to meet Maastricht convergence criteria on time
- Operational failures in payment systems and dual-circulation management
- Public resistance to price rounding and dual pricing
- Currency volatility and loss of DKK stability during transition
- Supply shortages of euro cash
- Counterfeiting and fraud during dual circulation
- Budget overruns and cost escalation
- Market uncertainty and capital flight

### Diverse Risks

- Regulatory and permitting risks
- Political and reputational risks
- Economic and financial risks
- Operational and technical risks
- Social and governance risks
- Environmental and sustainability risks
- Security and fraud risks

### Mitigation Plans

- Diplomatic engagement with EU members; phased negotiation with fallback derogation options; legal assurance via independent counsel
- Pre-referendum readiness conditionality; clear communication of benefits and safeguards; fallback advisory referendum design
- Fiscal and monetary policy rules to maintain deficits <0.5% GDP; proactive ECB coordination; structural reforms to boost productivity
- Central Conversion Unit with dual-currency platforms; staged cutover; rigorous testing; contingency reserves for settlement failures
- Transparent rounding rules; consumer protection safeguards; phased pricing mandates; retail support programs
- FX hedging via forwards; Sovereign Conversion Fund; daily parity bands; weekly ECB stress tests
- Pre-positioned euro cash reserves; centralized cash hubs; armored logistics; real-time inventory tracking
- Anti-counterfeiting measures; public education; mandatory exchange-point standards; law enforcement coordination
- Detailed budget with stage gates; contingent appropriations; EU funding exploration; independent audits
- Market communication protocols; capital flow monitoring; temporary intervention facilities; contingency triggers

## Stakeholder Analysis


### Primary Stakeholders

- Government of Denmark (Prime Minister and relevant ministers)
- Folketinget (Parliament)
- Danmarks Nationalbank
- Danish Financial Supervisory Authority
- Commercial banks and payment providers
- Business and employer organizations
- Trade unions
- Municipalities and public-sector entities

### Secondary Stakeholders

- European Commission
- European Central Bank
- Eurogroup
- European Council
- International Monetary Fund
- Danish public and citizens

### Engagement Strategies

- Primary stakeholders receive monthly executive briefings, formal consultations before key decisions, and dedicated working-group sessions; information requests answered within 48 hours
- Secondary stakeholders receive quarterly progress reports, ad hoc briefings for major milestones, and notification of referendum timelines and outcomes; compliance feedback incorporated into policy adjustments

## Regulatory and Compliance Requirements


### Permits and Licenses

- EU treaty derogation or simplified amendment enabling opt-out waiver
- National referendum authorization under Danish constitutional law
- Central bank operational license for euro settlement and liquidity provision
- Payment system operator certifications for dual-currency processing

### Compliance Standards

- Maastricht convergence criteria (inflation, deficit, debt, exchange-rate stability)
- ERM II participation rules and minimum two-year membership
- ECB guidelines on new member state adoption
- EU data protection and financial reporting directives
- Anti-money laundering and counterfeiting regulations

### Regulatory Bodies

- European Commission
- European Central Bank
- Eurogroup
- Danish Financial Supervisory Authority
- National Bank of Denmark

### Compliance Actions

- Apply for EU treaty modification with detailed implementation schedule
- Schedule and conduct referendum with independent electoral oversight
- Submit convergence assessments to ECB every 45 days
- Implement ECB-recommended monetary and fiscal safeguards
- Conduct annual compliance audits and publish summaries