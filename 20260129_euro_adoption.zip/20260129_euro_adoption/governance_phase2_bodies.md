### 1. Euro Adoption Steering Committee

**Rationale for Inclusion:** High-level strategic oversight is required to guide Denmark’s multi-year transition from opt-out to full euro adoption, manage treaty change, referendum, and alignment with EU/ECB rules.

**Responsibilities:**

- Approve major strategic decisions and milestone gates
- Authorize budgets above defined thresholds (e.g., >500M DKK)
- Oversee risk register and contingency planning
- Ensure compliance with EU, ECB, and Danish constitutional requirements
- Provide final sign-off on referendum timing and treaty change posture

**Initial Setup Actions:**

- Define Terms of Reference and membership
- Select Chair and independent members
- Establish financial thresholds and escalation matrix

**Membership:**

- Prime Minister (Chair)
- Minister of Finance
- Minister of Economic Affairs
- Danmarks Nationalbank Governor
- Danish Financial Supervisory Authority Head
- Independent external macroeconomist (non-Danish)

**Decision Rights:** Strategic decisions including referendum authorization, treaty change posture, ERM II entry approval, budgets >500M DKK, and adoption-go/no-go gates.

**Decision Mechanism:** Consensus required; fallback to supermajority (≥75%) with independent chair casting tie-breaking vote.

**Meeting Cadence:** Monthly, with ad hoc emergency sessions.

**Typical Agenda Items:**

- Review of convergence metrics vs Maastricht criteria
- Referendum readiness and public mandate status
- ERM II entry and parity setting
- Budget and funding approvals
- Risk register updates and contingency triggers

**Escalation Path:** Directly to Folketinget and, if unresolved, to the Danish Parliament’s Constitutional Committee within 14 days.
### 2. Dual Circulation Management Office

**Rationale for Inclusion:** Operational management of day-to-day transition activities, including IT, cash logistics, payment systems, and dual pricing coordination.

**Responsibilities:**

- Execute conversion of payment systems and IT infrastructure
- Manage dual circulation scheduling and cutover plans
- Coordinate cash supply and seigniorage capture
- Monitor operational KPIs and incident response
- Implement stakeholder training and support programs

**Initial Setup Actions:**

- Define RACI and governance workflows
- Establish technical standards and test plans
- Set up cross-functional workstreams (Legal, IT, Operations, Communications)

**Membership:**

- Deputy Prime Minister (Head of Operations)
- Chief Digital Officer
- Danmarks Nationalbank Deputy Governor
- FSA Head of Payment Systems
- Municipalities Representative
- Commercial Banks Liaison (non-voting advisor)

**Decision Rights:** Operational decisions up to 250M DKK, implementation schedules, and day-to-day risk management within approved thresholds.

**Decision Mechanism:** Majority vote; tie resolved by Head of Operations.

**Meeting Cadence:** Weekly operational reviews; biweekly steering alignment.

**Typical Agenda Items:**

- IT system migration status and testing results
- Cash logistics and euro availability metrics
- Dual pricing and rounding compliance
- Incident logs and resolution plans
- Stakeholder feedback integration

**Escalation Path:** Escalate to Euro Adoption Steering Committee for decisions beyond operational thresholds or unresolved issues within 7 days.
### 3. Legal and Treaty Compliance Committee

**Rationale for Inclusion:** Dedicated oversight of legal, treaty, and constitutional compliance, including referendum design, EU negotiations, and contract conversion rules.

**Responsibilities:**

- Draft and review treaty change and derogation requests
- Ensure referendum design meets constitutional thresholds
- Provide legal interpretation of EU requirements
- Oversee legacy DKK contract renegotiation frameworks
- Monitor GDPR and regulatory alignment

**Initial Setup Actions:**

- Establish legal assessment checklists
- Engage independent external counsel for impartial review
- Define compliance audit schedule

**Membership:**

- Minister of Justice (Chair)
- Attorney General
- EU Law Professor (independent academic)
- Data Protection Authority Representative
- FSA Legal Counsel (non-voting)

**Decision Rights:** Authority to approve legal instruments up to 1B DKK in contingent liabilities; binding interpretation of EU and constitutional mandates.

**Decision Mechanism:** Unanimous consent; if unreachable, refer to independent arbitration panel.

**Meeting Cadence:** Biweekly, with urgent sessions as needed.

**Typical Agenda Items:**

- Treaty change draft review and legal risk scoring
- Referendum question wording and threshold validation
- Contract conversion methodology compliance
- Data protection and privacy impact assessments
- Regulatory filings and EU correspondence review

**Escalation Path:** Escalate unresolved legal disputes to the Danish Supreme Court or EU Court of Justice as appropriate.
### 4. Stakeholder Engagement and Communication Council

**Rationale for Inclusion:** Ensure sustained public and stakeholder buy-in through structured communication, education, and inclusive participation across demographics.

**Responsibilities:**

- Design and execute multi-channel communication strategy
- Coordinate town halls, digital Q&A, and SME outreach
- Monitor sentiment and misinformation trends
- Manage public dashboards and transparency reporting
- Engage unions, employers, and municipalities on social pacts

**Initial Setup Actions:**

- Develop communication roadmap and KPIs
- Establish independent media monitoring
- Create stakeholder advisory panels

**Membership:**

- Minister of Culture (Chair)
- Head of National Broadcasting
- Consumer Association Representative
- Trade Union Confederation Lead
- Business Federation Spokesperson
- Independent Communications Strategist (external)

**Decision Rights:** Approve communication budgets up to 100M DKK; mandate public messaging standards; trigger corrective campaigns.

**Decision Mechanism:** Consensus; fallback to majority vote with external advisor tie-break.

**Meeting Cadence:** Biweekly; ad hoc during referendum and conversion peaks.

**Typical Agenda Items:**

- Message testing and channel performance
- Public awareness and misinformation tracking
- Stakeholder feedback synthesis
- Crisis communication drills
- Transparency dashboard updates

**Escalation Path:** Escalate to Euro Adoption Steering Committee if public trust metrics fall below defined thresholds.
### 5. Risk and Contingency Oversight Board

**Rationale for Inclusion:** Integrated risk management across all governance bodies, with dedicated focus on financial, operational, and systemic contingencies.

**Responsibilities:**

- Maintain and update the comprehensive risk register
- Monitor contingency reserves and trigger usage
- Run scenario simulations and stress tests
- Report risk posture to steering and operational bodies
- Ensure alignment with EU/ECB stability requirements

**Initial Setup Actions:**

- Finalize risk taxonomy and scoring matrix
- Establish contingency funding mechanisms
- Define simulation and drill schedules

**Membership:**

- Head of Risk Management (Chair)
- Chief Financial Officer
- IT Security Lead
- External Risk Consultant (independent)
- Representative from Euro Adoption Steering Committee

**Decision Rights:** Approve risk mitigation budgets up to 500M DKK; authorize contingency activation; mandate corrective actions.

**Decision Mechanism:** Consensus; supermajority (≥80%) if consensus fails.

**Meeting Cadence:** Weekly risk review; monthly deep-dive simulations.

**Typical Agenda Items:**

- Risk register updates and new risk identification
- Contingency fund status and drawdown triggers
- Scenario analysis results and action plans
- Cross-body risk dependencies and mitigation coordination
- Compliance with EU risk reporting standards

**Escalation Path:** Immediate escalation to Euro Adoption Steering Committee and Folketinget if high-impact risks materialize or reserves are breached.