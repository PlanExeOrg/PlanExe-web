### 1. Project Steering Committee (PSC)

**Rationale for Inclusion:** Provides high-level strategic direction and oversight, crucial given the project's political sensitivity, economic impact, and legal complexity. Ensures alignment with government policy and EU requirements.

**Responsibilities:**

- Approve the overall project plan and any significant deviations.
- Set strategic priorities and resolve high-level conflicts.
- Approve major project milestones and budget allocations above 5 million EUR.
- Monitor project progress against strategic objectives.
- Oversee risk management and approve mitigation strategies for critical risks.
- Approve the communication strategy and ensure its effectiveness.
- Approve the EU negotiation strategy and monitor its progress.
- Approve the referendum question and timing.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair and Vice-Chair.
- Establish meeting schedule and communication protocols.
- Review and approve the initial project plan.
- Define escalation paths and conflict resolution mechanisms.

**Membership:**

- Prime Minister (or designated representative)
- Minister of Finance
- Minister of Economy
- Minister of Foreign Affairs
- Governor of Danmarks Nationalbank
- Director of the Danish FSA
- Independent Expert in EU Law (External)
- Independent Economist (External)

**Decision Rights:** Strategic decisions related to project scope, budget (above 5 million EUR), timeline, and key policy choices. Approval of major project milestones and risk mitigation strategies.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Prime Minister (or designated representative) has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Monthly, with ad-hoc meetings as needed for critical decisions.

**Typical Agenda Items:**

- Review of project progress against milestones.
- Discussion of key risks and mitigation strategies.
- Approval of budget allocations and expenditures.
- Updates on EU negotiations.
- Review of public sentiment and communication strategy.
- Discussion of legal and regulatory issues.
- Review of audit reports and compliance.

**Escalation Path:** Cabinet (for issues exceeding the PSC's authority or requiring broader government consensus).
### 2. Project Management Office (PMO)

**Rationale for Inclusion:** Manages day-to-day execution, ensuring efficient resource allocation, risk management, and adherence to project timelines and budget. Provides centralized support and coordination for all project activities.

**Responsibilities:**

- Develop and maintain the detailed project plan.
- Manage project budget and track expenditures.
- Monitor project progress and identify potential delays or issues.
- Coordinate project activities across different workstreams.
- Manage project risks and implement mitigation strategies.
- Prepare regular project reports for the PSC.
- Manage communication within the project team.
- Ensure compliance with project governance standards.
- Manage operational decisions below 5 million EUR.

**Initial Setup Actions:**

- Establish PMO structure and staffing.
- Develop project management methodologies and tools.
- Set up project reporting and communication systems.
- Define roles and responsibilities within the PMO.
- Establish risk management framework.

**Membership:**

- Project Director
- Workstream Leads (Legal, Economic, Communication, IT, Logistics)
- Risk Manager
- Finance Manager
- Communication Manager
- PMO Support Staff

**Decision Rights:** Operational decisions related to project execution, resource allocation (within approved budget), and risk management (below strategic thresholds).

**Decision Mechanism:** Decisions made by the Project Director, in consultation with Workstream Leads. Unresolved issues are escalated to the PSC.

**Meeting Cadence:** Weekly, with daily stand-up meetings for workstream leads.

**Typical Agenda Items:**

- Review of project progress against plan.
- Discussion of key issues and risks.
- Coordination of project activities.
- Review of budget and expenditures.
- Updates from workstream leads.
- Action item tracking.

**Escalation Path:** Project Steering Committee (for issues exceeding the PMO's authority or requiring strategic guidance).
### 3. Legal and Compliance Committee (LCC)

**Rationale for Inclusion:** Ensures compliance with EU and Danish laws and regulations, including GDPR, ethical standards, and financial regulations. Provides legal guidance and oversight throughout the project lifecycle.

**Responsibilities:**

- Review and approve all legal documents and agreements.
- Ensure compliance with EU and Danish laws and regulations.
- Provide legal advice to the PSC and PMO.
- Monitor legal risks and develop mitigation strategies.
- Oversee data protection and privacy compliance (GDPR).
- Ensure ethical standards are maintained throughout the project.
- Oversee compliance with financial regulations.
- Manage external legal counsel.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule and communication protocols.
- Develop compliance framework.
- Identify key legal and regulatory requirements.

**Membership:**

- Chief Legal Counsel (Chair)
- Data Protection Officer
- Compliance Officer
- Representative from the Ministry of Justice
- External Legal Expert in EU Law
- External Expert in Danish Constitutional Law

**Decision Rights:** Decisions related to legal compliance, data protection, and ethical standards. Approval of legal documents and agreements. Authority to halt project activities if legal or ethical concerns arise.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Chief Legal Counsel has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Bi-weekly, with ad-hoc meetings as needed for critical legal issues.

**Typical Agenda Items:**

- Review of legal documents and agreements.
- Discussion of legal and regulatory issues.
- Updates on compliance activities.
- Review of data protection and privacy compliance.
- Discussion of ethical concerns.
- Review of audit reports related to legal and compliance matters.

**Escalation Path:** Project Steering Committee (for issues exceeding the LCC's authority or requiring strategic guidance).
### 4. Stakeholder Engagement and Communication Group (SECG)

**Rationale for Inclusion:** Ensures effective communication with all stakeholders, including the public, businesses, and EU institutions. Manages public sentiment, addresses concerns, and promotes understanding of the euro adoption process.

**Responsibilities:**

- Develop and implement the communication strategy.
- Manage public relations and media relations.
- Monitor public sentiment and address concerns.
- Organize public forums and information sessions.
- Develop and maintain the project website and helpline.
- Coordinate communication with EU institutions.
- Engage with business and employer organizations and trade unions.
- Manage stakeholder feedback and incorporate it into the project plan.

**Initial Setup Actions:**

- Finalize Terms of Reference.
- Appoint Chair.
- Establish meeting schedule and communication protocols.
- Develop stakeholder engagement plan.
- Identify key stakeholders and their communication needs.

**Membership:**

- Communication Director (Chair)
- Public Relations Manager
- Media Relations Manager
- Stakeholder Engagement Manager
- Representative from the Ministry of Economy
- Representative from the Ministry of Foreign Affairs
- External Communication Expert

**Decision Rights:** Decisions related to communication strategy, public relations, and stakeholder engagement. Approval of communication materials and public statements.

**Decision Mechanism:** Decisions made by majority vote. In case of a tie, the Communication Director has the casting vote. Dissenting opinions are recorded in the minutes.

**Meeting Cadence:** Weekly, with ad-hoc meetings as needed for critical communication issues.

**Typical Agenda Items:**

- Review of communication strategy and activities.
- Discussion of public sentiment and concerns.
- Updates on stakeholder engagement activities.
- Review of communication materials and public statements.
- Discussion of media coverage.
- Planning for public forums and information sessions.

**Escalation Path:** Project Steering Committee (for issues exceeding the SECG's authority or requiring strategic guidance).