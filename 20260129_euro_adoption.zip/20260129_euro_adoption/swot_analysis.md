
## Strengths 👍💪🦾
- Strong institutional capacity and public trust in Danish governance
- Prior experience with ERM II providing technical familiarity with exchange-rate anchoring
- EU membership and existing legal framework facilitating treaty adjustments
- High fiscal discipline and low public debt supporting convergence
- Mature financial sector and payment infrastructure enabling smoother migration

## Weaknesses 👎😱🪫⚠️
- Constitutional requirement for a binding referendum creating political and timeline uncertainty
- Opt-out legacy requiring complex treaty change negotiations with EU
- Potential public resistance to rounding rules and dual pricing transparency
- Limited domestic experience with large-scale currency replacement
- Dependence on ECB cooperation for ERM II and convergence criteria interpretation

## Opportunities 🌈🌐
- Killer application: a seamless, public-trust-centric dual-circulation and conversion platform that becomes the benchmark for retail and institutional euro adoption
- Leverage Denmark’s tech and fintech ecosystem to build a real-time reconciliation and anti-counterfeiting infrastructure
- Use the transition to modernize public finance reporting and integrate green/sustainability metrics aligned with EU standards
- Develop a regional leadership role in Nordic-Baltic monetary coordination post-adoption
- Create a citizen-centric communication hub that turns the referendum and conversion into a participatory governance success

## Threats ☠️🛑🚨☢︎💩☣︎
- EU political dynamics delaying or complicating opt-out waiver negotiations
- Referendum failure due to sovereignty concerns or misinformation
- Maastricht criteria tightening or asymmetric enforcement by EU institutions
- Currency speculation and DKK volatility during pre-ERM and dual-circulation phases
- Operational failures in payment systems causing business disruption
- Public backlash against price rounding perceived as inflationary
- Supply chain disruptions for euro cash leading to shortages
- Cybersecurity threats targeting conversion platforms and financial data

## Recommendations 💡✅
- Establish a Central Conversion Unit (CCU) with legal, IT, and operations authority by 2026-04-30; staff with 15 specialists and procure a dual-currency processing platform capable of 10k TPS by 2026-06-01 (Owner: Ministry of Finance)
- Implement a phased dual-pricing mandate for all retailers and public-facing POS by 2026-09-01, supported by training for 10k staff and anti-counterfeiting holograms on 50M labels (Owner: Danish Competition Authority)
- Secure a pre-commitment facility with the ECB/ESM and hold 6 months of import cover (≥15B EUR) with daily liquidity stress tests and a 500M DKK anti-counterfeiting task force by 2026-06-01 (Owner: Danmarks Nationalbank)
- Pass a referendum safeguards law by 2026-04-25 defining turnout and support thresholds, creating an independent Electoral Commission, and a 12-month cooling-off protocol (Owner: Ministry of Justice)
- Launch a real-time public dashboard tracking convergence metrics, FX bands, and cash logistics KPIs with weekly ECB coordination calls by 2026-05-01 (Owner: CCU)

## Strategic Objectives 🎯🔭⛳🏅
- Achieve and document Maastricht compliance and pass a binding referendum with >50% turnout and >40% electorate support by 2027-12-31
- Enter ERM II and maintain DKK/EUR parity within ±0.5% for 24 consecutive months by 2029-12-31
- Migrate 100% of retail and public-sector payments to EUR with <0.1% settlement failures and 99.9% payment success rate by 2030-12-31
- Operationalize a Central Conversion Unit and dual-pricing infrastructure with 100% merchant onboarding and 95% public awareness by 2026-09-01
- Maintain fiscal deficit <0.5% of GDP and public debt <60% of GDP throughout the transition, verified by independent audits every 45 days

## Assumptions 🤔🧠🔍
- EU and Denmark agree on a simplified treaty adjustment focused solely to lift the opt-out
- Danish referendum is a binary Yes/No on waiving the opt-out with clear turnout and support thresholds
- Danmarks Nationalbank can operate under ECB oversight while retaining emergency liquidity tools
- Payment system upgrades follow open standards (e.g., ISO 20022) with ECB alignment
- Public communication can achieve >70% awareness and >60% support before referendum and conversion

## Missing Information 🧩🤷‍♂️🤷‍♀️
- Fiscal space analysis and independent assessment of Danmarks Nationalbank’s capacity to manage pre-ERM II convergence
- Legal enforceability of referendum outcomes and predefined fallback mechanisms for narrow or ambiguous results
- Currency risk management framework for dual circulation FX volatility and DKK depreciation scenarios
- Legacy payment system sunsetting schedule and interoperability certification criteria
- Modeling of inflation expectations and wage-price dynamics during dual pricing

## Questions 🙋❓💬📌
- What specific legal and treaty steps are required to lift Denmark’s EU opt-out and establish a binding roadmap for euro adoption?
- How will Denmark sequence milestones from the political decision to adopt the euro through full withdrawal of the Danish krone?
- What governance structures will manage the transition domestically and with EU institutions to ensure compliance and adaptability?
- Which measures will mitigate financial, operational, and systemic risks during the transition, including market stability and contingency planning?
- How will the government sustain public and stakeholder buy-in through communication, education, and inclusive participation?