
## Audit - Corruption Risks

- Bribery of government officials or members of the Folketinget to influence the legal pathway selection or referendum outcome.
- Conflicts of interest involving ministers or central bank officials with personal investments in financial institutions that would benefit from the euro adoption.
- Kickbacks from IT vendors or consultants hired for the financial system conversion.
- Misuse of confidential information regarding the timing or details of the transition for personal financial gain.
- Nepotism in awarding contracts for public communication campaigns or IT system upgrades.
- Trading favors with banks or financial institutions in exchange for favorable treatment during the conversion process.

## Audit - Misallocation Risks

- Excessive spending on public information campaigns with questionable effectiveness, potentially benefiting politically connected advertising agencies.
- Unnecessary or overpriced IT system upgrades for financial institutions, leading to inflated costs and potential kickbacks.
- Double spending on legal and advisory services, with multiple firms performing overlapping work.
- Inefficient allocation of resources for cash and coin conversion, resulting in delays and increased costs.
- Misreporting of progress on key milestones to maintain project momentum, masking underlying issues and potential delays.
- Unauthorized use of project funds for personal expenses or unrelated activities.

## Audit - Procedures

- Conduct periodic internal reviews of all contracts related to the euro adoption project, with a focus on IT, consulting, and public relations contracts. Review thresholds should be set at 500,000 EUR.
- Implement a robust expense workflow with multiple levels of approval and detailed documentation requirements for all project-related expenditures.
- Perform regular compliance checks to ensure adherence to EU convergence criteria and ECB regulations, with quarterly reports submitted to the Folketinget.
- Conduct a post-project external audit by an independent firm to assess the overall effectiveness and efficiency of the euro adoption process.
- Establish a whistleblower mechanism with clear procedures for reporting suspected fraud or corruption, ensuring anonymity and protection for whistleblowers.
- Implement a system for tracking and verifying the actual costs of IT system upgrades against initial estimates and industry benchmarks.

## Audit - Transparency Measures

- Create a public dashboard displaying the project's progress against key milestones, budget expenditures, and risk indicators, updated monthly.
- Publish minutes of key meetings of the steering committee and working groups involved in the euro adoption project, excluding confidential or commercially sensitive information.
- Establish a publicly accessible website containing all relevant policies, reports, and documents related to the euro adoption project.
- Document and publish the selection criteria and rationale for all major decisions, including the selection of vendors and consultants.
- Implement a system for tracking and responding to public inquiries and concerns regarding the euro adoption process.
- Publish a detailed breakdown of the project budget, including allocations for legal, communication, IT, and logistics, updated quarterly.