## Domain of the expert reviewer
Strategic Project Planning & Governmental Transition Management

## Domain-specific considerations

- Sequencing of political consent vs. economic convergence criteria
- Management of EU/ECB institutional dependencies and external dependencies
- Public behavior change management and democratic mandate security
- Sunk cost management due to long pre-adoption phase (ERM II)

## Issue 1 - Underestimated Timeline Risk Associated with Deferring Opt-Out Repeal
The chosen 'Builder's Blueprint' strategy assumes the earliest referendum date is Q1 2030, based on a minimum 24-month ERM II period starting in Q3 2027. This implies a political decision today (May 2026) leads to an 8-year timeline (2026-2034) for full adoption, which strains the implied 4-8 year window. Furthermore, deferring the Opt-Out repeal negotiation (Decision 1) until after ERM II completion (Decision 4) creates a *missed assumption*: the assumption that the EU will entertain a treaty amendment process *after* Denmark has already met technical convergence criteria, rather than demanding the political alignment happens concurrently or beforehand. This sequence increases political risk with the EU Council/Parliament.

**Recommendation:** Immediately initiate parallel, high-level diplomatic tracks. While ERM entry proceeds (Strategy 12), a 'conditional negotiation' track for the Opt-Out Repeal Protocol must begin, explicitly tied to meeting the 12-month ERM II stability mark, not the end. This requires amending the governance structure to empower the Consultative Body (Decision 5) to manage the diplomatic risk transfer, rather than relying solely on late-stage treaty requests ($Risk 1$).

**Sensitivity:** If the EU demands the Opt-Out resolution precede formal ERM II entry confirmation, the project timeline baseline of Q1 2030 would be delayed by 12–18 months (pushing adoption to Q1 2031/2032) due to extended EU ratification timelines. This delay impacts ROI by reducing the period of full utilization by 1.5 years, lowering projected ROI by 8-12% based on a standard 15-year cash flow model.

## Issue 2 - Critical Missing Assumption: Funding Stability During Prolonged ERM II Period
The project assumes funding levels (DKK 15–25 billion over 6 years) are stable, and technical staffing relies on secondments (Assumption 3). Crucially, there is *no assumption* explicitly stating the funding mechanism is indexed or protected against sustained high inflation or elevated interest rates over the 6-8 year projected timeline. The 'Builder's Blueprint' is economically conservative (maintaining strict DKK policy), but high inflation during the 24-month ERM II period could rapidly erode the real value of the committed budget (DKK 100M for communication, DKK 50M contingency) and make retaining seconded staff unaffordable.

**Recommendation:** Introduce mandatory annual budget real-indexation reviews tied to a neutral CPI index (e.g., Euro Area CPI). Specifically, the contingency fund (Assumption 5) should be structured as an external ring-fenced escrow account protected from annual departmental reallocation, with a minimum capital hold of DKK 50M + 5% annual inflation adjustment.

**Sensitivity:** If average annual inflation over the 6-year timeline exceeds the current baseline expectation by 2 percentage points (e.g., 3.5% vs. 1.5% baseline), the real value of the DKK 20B budget is reduced by roughly DKK 2.2 Billion. This forces delays in cash logistics scaling or requires an immediate capital call, potentially increasing the cost of capital by 0.5-1.0% per year on any bridging loans taken during the ERM II phase.

## Issue 3 - Under-Explored Assumption: Legal Finality of Contract Re-denomination Post-Referendum Failure
Assumption 7 mandates automatic rounding for all contracts post-Euro Day. However, the 'Builder's Blueprint' strategy defers the vote/legal opt-out repeal until the end of ERM II participation (Q1 2030). There is a critical *omission* regarding the legal status of these pre-mandate contract rounding rules if the referendum *fails*. If the referendum fails, is the government legally obliged to retract the mandatory rounding legislation enacted contingent on success? This uncertainty creates massive risk for SMEs and IT readiness (Risk 7).

**Recommendation:** Immediately task the Justice Ministry (via the Joint Ministerial Body, Decision 5) to draft a **Dual-Path Legal Contingency Mandate**. This mandate must clearly stipulate that all preparatory legislation for re-denomination (Decision 7) is automatically repealed *without penalty or sunk cost imputation* if the referendum fails. The cost of preparing this dual documentation should be factored into the DKK 50M contingency fund ($Risk 5$).

**Sensitivity:** If legal challenge invalidates the provisional contract legislation post-referendum failure, the cost of retrospective litigation and compensation payments to entities that upgraded systems based on the assumption of mandated conversion could range from DKK 500 Million to DKK 1.5 Billion in unforeseen liabilities, potentially impacting future ROI by 3-6% from write-offs.

## Review conclusion
The project's chosen 'Builder's Blueprint' strategy introduces significant timeline dependency risks by sequencing political opt-out repeal strictly after substantial operational convergence. The three most critical intervening issues are the **unrealistic sequencing risk concerning EU approval timelines**, the **failure to explicitly hedge against budget erosion during the long ERM II period (e.g., inflation)**, and the **unspecified legal consequence for preparatory contract legislation should the national referendum fail**. Addressing these requires immediate parallel diplomatic engagement, establishing inflation-indexed budget mechanisms, and drafting definitive dual-path legal contingency mandates.