## Domain of the expert reviewer
National monetary transition and EU integration policy

## Domain-specific considerations

- ERM II entry sequencing and ECB oversight
- Treaty change and constitutional referendum design
- Dual-currency IT and payment system conversion
- Cash logistics and seigniorage capture
- Stakeholder alignment and social pacts
- Environmental and sustainability impacts
- Risk register and contingency budgeting

## Issue 1 - Missing assumption: Independent fiscal and monetary capacity during the pre-ERM II convergence period
No explicit assumption on Denmark’s ability to maintain autonomous fiscal support and Danmarks Nationalbank’s operational capacity while converging under external ECB oversight. This is critical because convergence criteria require low deficits and stable inflation, yet pre-ERM II monetary accommodation may be constrained by external parity commitments. Impact: If fiscal space is insufficient, convergence delays could increase project cost by 5–10% (approx. 2–4 billion DKK) and delay the referendum by 6–12 months.

**Recommendation:** Quantify fiscal space using a baseline structural deficit threshold (<0.5% of GDP) and simulate ECB policy scenarios. Establish a pre-commitment facility (e.g., a temporary credit line with the ECB or ESM) to preserve autonomy. Define a fiscal rule that allows temporary, rules-based deviations during the convergence ramp-up, with independent verification by the FSA.

**Sensitivity:** 

## Issue 2 - Missing assumption: Legal enforceability of referendum outcomes and fallback mechanisms
The plan assumes a binary referendum can lock the process, but does not address scenarios where turnout or margin is ambiguous, or where post-referendum political shifts occur. This is critical because legal uncertainty can stall treaty change and delay ERM II entry by 12–24 months. Impact: Potential cost of 10–15% of budget (approx. 5–8 billion DKK) due to extended legal processes, repeated campaigns, and market uncertainty.

**Recommendation:** Embed a clear legal test (e.g., >50% turnout and >40% of electorate in favor) and a defined fallback (e.g., a ‘soft referendum’ mandate for the Folketing to proceed with treaty change under specified conditions). Draft contingency protocols for annulment or narrow wins, including a 12-month cooling-off and re-engagement phase with adjusted communication.

**Sensitivity:** 

## Issue 3 - Missing assumption: Currency risk management during dual circulation and ECB balance sheet exposure
Assumptions on cash logistics and seigniorage do not fully account for exchange-rate volatility between DKK and EUR during the dual-circulation window. This is critical because DKK depreciation could trigger import inflation and erode public confidence, while ECB valuation of Danmarks Nationalbank reserves may fluctuate. Impact: A 5% DKK depreciation could increase conversion costs by 2–3% (approx. 1–2 billion DKK) and delay full adoption by 3–6 months due to repricing pressures.

**Recommendation:** Implement a dynamic hedging program using EUR/DAK forwards aligned with the parity band, and establish a Sovereign Conversion Fund capitalized at 0.5–1% of GDP to absorb FX volatility. Publish daily parity bands and conduct weekly stress tests with the ECB.

**Sensitivity:** 

## Issue 4 - Missing assumption: Interoperability and legacy system sunsetting for payment infrastructures
Assumptions on IT alignment (e.g., ISO 20022) do not address coexistence costs and technical debt in legacy Danish banking systems. This is critical because fragmented standards can cause transaction failures and increase dual-circulation costs. Impact: Inadequate integration could raise operational risk costs by 15–20% (approx. 300–500 million DKK annually) and delay full adoption by 6–9 months.

**Recommendation:** Mandate a phased legacy sunsetting schedule with incentives for early adoption (e.g., regulatory capital relief for compliant institutions). Create an Interoperability Certification Body under the FSA to audit and accredit systems, with penalties for non-compliance.

**Sensitivity:** 

## Issue 5 - Missing assumption: Public inflation expectations and wage-price spiral risks during dual circulation
The plan does not explicitly model how price rounding and dual pricing may feed into inflation expectations. This is critical because anchored expectations are vital for ECB compliance and referendum stability. Impact: Unanchored expectations could increase wage demands by 1–2 percentage points, raising CPI inflation by 0.5–1% and forcing premature ECB-style tightening, which could reduce ROI by 3–5% over the transition.

**Recommendation:** Introduce a Wage-Price Protocol with indexed rounding caps and a public dashboard for transparency. Pair with a macroprudential buffer (e.g., countercyclical capital buffers) to dampen demand-side pressures, and simulate scenarios using the ECB’s Convergence Report templates.

**Sensitivity:** 

## Review conclusion
The transition plan lacks explicit assumptions on fiscal-monetary autonomy during convergence, referendum legal enforceability, currency risk management, legacy system interoperability, and inflation expectation anchoring. These gaps could increase costs by 5–15% and delay completion by 12–24 months. Prioritize: (1) fiscal space analysis with ECB-aligned rules; (2) referendum legal design with fallback clauses; (3) dynamic FX hedging and a Sovereign Conversion Fund. Embed these into a quantified risk register with contingency budgets and independent audits.