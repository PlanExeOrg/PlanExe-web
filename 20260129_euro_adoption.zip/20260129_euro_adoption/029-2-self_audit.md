Reality check: fix before go.

### Summary

| Level | Count | Explanation |
|---|---|---|
| 🛑 High | 15 | Existential blocker without credible mitigation. |
| ⚠️ Medium | 4 | Material risk with plausible path. |
| ✅ Low | 1 | Minor/controlled risk. |


## Checklist

## 1. Violates Known Physics

*Does the project require a major, unpredictable discovery in fundamental science to succeed?*

**Level**: ✅ Low

**Justification**: Rated LOW because the plan concerns the adoption of the Euro, which does not require breaking any physical laws. The plan is about economics, tokenization, governance, AI, regulation, and engineering scale, which are out of scope.

**Mitigation**: None


## 2. No Real-World Proof

*Does success depend on a technology or system that has not been proven in real projects at this scale or in this domain?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (euro adoption) + market (Denmark with opt-out) + tech/process (legal pathway, financial conversion) + policy (EU regulations, referendum) without independent evidence at comparable scale. No precedent exists for a nation with Denmark's specific opt-out history successfully adopting the euro.

**Mitigation**: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2025-12-31


## 3. Buzzwords

*Does the plan use excessive buzzwords without evidence of knowledge?*

**Level**: 🛑 High

**Justification**: Rated HIGH because no business-level mechanism-of-action is defined for the named frameworks/strategies. The plan lacks one-pagers defining inputs→process→customer value, an owner, and measurable outcomes for each strategic concept driving the plan. "The options don't consider the impact of global economic shocks during the transition period."

**Mitigation**: Project Manager: Create one-pagers for each strategic concept, defining the value hypothesis, success metrics, and decision hooks, to ensure strategic clarity and accountability by 2024-12-31.


## 4. Underestimating Risks

*Does this plan grossly underestimate risks?*

**Level**: 🛑 High

**Justification**: Rated HIGH because a major hazard class (cybersecurity) is minimized. The plan mentions risks, but lacks concrete details on proactive threat intelligence, advanced security monitoring, and incident response. "The options don't consider the potential for cyber security vulnerabilities during the IT system upgrades."

**Mitigation**: Risk & Contingency Planner: Expand the risk register to include detailed cybersecurity risks, map potential cascades, add controls, and establish a dated review cadence by 2024-12-31.


## 5. Timeline Issues

*Does the plan rely on unrealistic or internally inconsistent schedules?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan hinges on a novel combination of product (euro adoption) + market (Denmark with opt-out) + tech/process (legal pathway, financial conversion) + policy (EU regulations, referendum) without independent evidence at comparable scale. No precedent exists for a nation with Denmark's specific opt-out history successfully adopting the euro.

**Mitigation**: Project Manager: Run parallel validation tracks covering Market/Demand, Legal/IP/Regulatory, Technical/Operational/Safety, and Ethics/Societal. Each track must produce one authoritative source or a supervised pilot showing results vs a baseline. Define NO-GO gates: (1) empirical/engineering validity, (2) legal/compliance clearance. Owner: Project Manager / Deliverable: Validation Report / Date: 2025-12-31


## 6. Money Issues

*Are there flaws in the financial model, funding plan, or cost realism?*

**Level**: 🛑 High

**Justification**: Rated HIGH because committed sources/term sheets are not defined. The plan assumes Danish government funding, but lacks detail. "Assumption: Danish government primary funding, EU grants supplementary. Legal/advisory work first, then communication, IT. 10% contingency."

**Mitigation**: Ministry of Finance: Develop a dated financing plan listing funding sources/status, draw schedule, covenants, and NO‑GO on missed financing gates by 2024-12-31.


## 7. Budget Too Low

*Is there a significant mismatch between the project's stated goals and the financial resources allocated, suggesting an unrealistic or inadequate budget?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not include benchmarks or quotes to substantiate the budget. The plan mentions resources required, but lacks specific cost estimates or per-area normalization. "Resources Required: Legal and advisory services. IT infrastructure upgrades for financial institutions."

**Mitigation**: Ministry of Finance: Obtain at least three relevant cost benchmarks for similar projects, normalize costs per area, and adjust the budget or de-scope by 2024-12-31.


## 8. Overly Optimistic Projections

*Does this plan grossly overestimate the likelihood of success, while neglecting potential setbacks, buffers, or contingency plans?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan presents key projections (e.g., economic impact, public support) as single numbers without providing a range or discussing alternative scenarios. The plan lacks sensitivity analysis for key projections. "Systemic: 10% swing in referendum outcome".

**Mitigation**: Economic Impact Analyst: Conduct a sensitivity analysis for the referendum outcome projection, including best-case, worst-case, and base-case scenarios by 2024-12-31.


## 9. Lacks Technical Depth

*Does the plan omit critical technical details or engineering steps required to overcome foreseeable challenges, especially for complex components of the project?*

**Level**: 🛑 High

**Justification**: Rated HIGH because build-critical components lack engineering artifacts. The plan describes high-level strategies but omits technical specifications, interface definitions, test plans, and integration maps for key components like IT systems and financial infrastructure. "The options don't consider the potential for cyber security vulnerabilities during the IT system upgrades."

**Mitigation**: Head of Engineering: Produce technical specs, interface definitions, test plans, and an integration map with owners/dates for build-critical components by 2025-03-31.


## 10. Assertions Without Evidence

*Does each critical claim (excluding timeline and budget) include at least one verifiable piece of evidence?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan makes claims without verifiable artifacts. For example, it states: "Systemic: 15% reduction in transaction costs through standardized systems" but lacks a study or report to support this claim.

**Mitigation**: Project Manager: Obtain or produce verifiable evidence (reports, studies, contracts) for all quantitative claims in the plan by 2024-12-31.


## 11. Unclear Deliverables

*Are the project's final outputs or key milestones poorly defined, lacking specific criteria for completion, making success difficult to measure objectively?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the deliverable "a new system" is mentioned without specific, verifiable qualities. "IT infrastructure upgrades for financial institutions." lacks SMART criteria.

**Mitigation**: Head of Engineering: Define SMART criteria for IT infrastructure upgrades, including a KPI for system uptime (e.g., 99.9% availability) by 2024-12-31.


## 12. Gold Plating

*Does the plan add unnecessary features, complexity, or cost beyond the core goal?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the 'digital euro' pilot program in the Financial System Transition Approach (Decision 9) does not appear to directly support the core project goals of minimizing economic disruption and maintaining financial stability. It adds complexity without clear benefit.

**Mitigation**: Project Team: Produce a one-page benefit case justifying the inclusion of the 'digital euro' pilot program, complete with a KPI, owner, and estimated cost, or move the feature to the project backlog by 2024-12-31.


## 13. Staffing Fit & Rationale

*Do the roles, capacity, and skills match the work, or is the plan under- or over-staffed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan requires a "Political Strategist & Negotiator" to navigate complex political landscapes and secure agreements. This role is critical, and finding someone with deep understanding of Danish and EU politics, negotiation skills, and familiarity with public opinion is likely difficult.

**Mitigation**: HR: Conduct a talent market analysis for the "Political Strategist & Negotiator" role, assessing the availability of qualified candidates and potential recruitment challenges by 2024-12-31.


## 14. Legal Minefield

*Does the plan involve activities with high legal, regulatory, or ethical exposure, such as potential lawsuits, corruption, illegal actions, or societal harm?*

**Level**: 🛑 High

**Justification**: Rated HIGH because legality is unclear. The plan mentions "EU convergence criteria", "ERM II participation", and "ECB regulations" but lacks a regulatory matrix mapping authority, artifact, lead time, and predecessors. The plan does not address potential legal challenges from Eurosceptic groups.

**Mitigation**: Legal Team: Develop a regulatory matrix mapping authority, artifact, lead time, and predecessors for all required legal and regulatory approvals by 2024-12-31.


## 15. Lacks Operational Sustainability

*Even if the project is successfully completed, can it be sustained, maintained, and operated effectively over the long term without ongoing issues?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan lacks a detailed operational sustainability plan. While the plan mentions economic stability and financial system transition, it does not address long-term maintenance, scalability, or technology obsolescence. The plan does not address personnel dependencies.

**Mitigation**: Project Manager: Develop an operational sustainability plan including a funding/resource strategy, maintenance schedule, succession planning, and technology roadmap by 2025-03-31.


## 16. Infeasible Constraints

*Does the project depend on overcoming constraints that are practically insurmountable, such as obtaining permits that are almost certain to be denied?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan does not explicitly address zoning, fire load, or structural limits. It mentions "Public squares, community centers, and polling stations" but lacks details on compliance. The plan does not address noise constraints.

**Mitigation**: Operations Coordinator: Conduct a fatal-flaw screen of planned physical locations, addressing zoning, fire load, structural limits, and noise, with dated NO-GO thresholds by 2025-03-31.


## 17. External Dependencies

*Does the project depend on critical external factors, third parties, suppliers, or vendors that may fail, delay, or be unavailable when needed?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks evidence of tested failovers or secondary suppliers. The plan mentions "Secure supply chains, coordinate with ECB, contingency plans" but lacks specifics on redundancy or tested resilience.

**Mitigation**: Logistics & Operations Coordinator: Secure SLAs with primary vendors, add a secondary supplier/path for euro banknote/coin supply, and test failover by 2025-06-30.


## 18. Stakeholder Misalignment

*Are there conflicting interests, misaligned incentives, or lack of genuine commitment from key stakeholders that could derail the project?*

**Level**: ⚠️ Medium

**Justification**: Rated MEDIUM because the plan pits the 'Prime Minister' (incentivized by successful euro adoption) against 'Danmarks Nationalbank' (incentivized by financial stability), creating tension over transition speed. The plan does not include a shared objective.

**Mitigation**: Project Manager: Define a shared OKR for the Prime Minister and Danmarks Nationalbank, focusing on a balanced transition with measurable stability metrics, by 2024-12-31.


## 19. No Adaptive Framework

*Does the plan lack a clear process for monitoring progress and managing changes, treating the initial plan as final?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a feedback loop. Vague ‘we will monitor’ is insufficient. The plan lacks KPIs, review cadence, owners, and a basic change-control process with thresholds (when to re-plan/stop).

**Mitigation**: Project Manager: Add a monthly review with KPI dashboard and a lightweight change board, including owners, thresholds, and a basic change-control process by 2024-12-31.


## 20. Uncategorized Red Flags

*Are there any other significant risks or major issues that are not covered by other items in this checklist but still threaten the project's viability?*

**Level**: 🛑 High

**Justification**: Rated HIGH because the plan lacks a cross-impact analysis or FTA to surface multi-node cascades. A sudden Eurozone financial crisis could undermine public confidence (Referendum Framing) and derail the referendum (Legal Pathway Selection), wasting prior investment.

**Mitigation**: Risk & Contingency Planner: Create an interdependency map + bow-tie/FTA + combined heatmap with owner/date and NO-GO/contingency thresholds by 2025-03-31.