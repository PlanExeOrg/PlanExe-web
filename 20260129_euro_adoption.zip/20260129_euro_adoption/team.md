*Roles Needed & Example People*

# Roles

## 1. Chief Transition Architect / Project Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Chief Transition Architect is responsible for overall strategic direction, managing complex cross-pillar dependencies, and steering Ministerial reporting. This role requires deep, ongoing commitment and integration with core government structures, typical of a senior civil servant.

**Explanation**:
Responsible for overall strategic direction, managing complex cross-pillar dependencies (political, legal, economic), and steering the implementation of the 'Builder's Blueprint'. Directly reports to Ministerial Steering Group.

**Consequences**:
Lack of strategic coherence; mission drift; failure to manage critical path dependencies between legal negotiation and operational readiness.

**People Count**:
min 1, max 2, depending on project scale and workload.

**Typical Activities**:
Chairing the Joint Ministerial Consultative Body (Decision 5); developing inter-agency service level agreements; overseeing the phasing of the Societal Readiness Pacing (Decision 11); managing the overall critical path dependencies across legal, technical, and public affairs workstreams; reporting progress against milestones to the Prime Minister's Office.

**Background Story**:
Dr. Elara Vinter, based in Copenhagen, holds a Master's in Public Administration from CBS and a Ph.D. in Governmental Change Management from the London School of Economics. Her extensive experience includes leading the Danish government's massive IT modernization project following the 2015 digital transformation mandate, giving her unparalleled skills in large-scale organizational restructuring and complex stakeholder management. She is intimately familiar with the dependencies between ministerial mandates and operational timelines, particularly concerning national infrastructure upgrades. Elara is relevant here because the success of the 'Builder's Blueprint' hinges on carefully sequencing legal negotiation with public buy-in, a dependency she expertly manages.

**Equipment Needs**:
Secure high-grade video conferencing suite for continuous transnational steering committee meetings (Joint Ministerial Consultative Body); Dedicated secure document management system for handling classified negotiation drafts (Opt-Out Resolution); Executive reporting software for dependency tracking against the 4-8 year timeline.

**Facility Needs**:
Dedicated high-security office suite within Christiansborg Palace or Prime Minister's Office for the Central Transition Authority/Steering Committee; Access to high-level diplomatic briefing rooms for EU negotiations.

## 2. Senior EU Legal & Treaty Negotiator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Senior EU Legal & Treaty Negotiator is needed for high-stakes, finite tasks (EU consultation, drafting protocol amendments) with external bodies. This expertise is specialized and often sourced from top international law firms on a project-specific basis, making contracting efficient.

**Explanation**:
Leads all diplomatic engagement with the European Commission, Council, and ECB regarding the removal of the DKK opt-out, drafting protocol amendments, and ensuring domestic constitutional steps align with EU requirements.

**Consequences**:
Critical failure in the geopolitical dependency (Risk 1); inability to secure the necessary legal foundation for entry (Opt-Out Resolution Mechanism Selection).

**People Count**:
min 1, max 3, depending on the stage of external negotiation.

**Typical Activities**:
Leading the EU Opt-Out Engagement Taskforce (Action 1); drafting formal requests for Extraordinary European Council sessions (Decision 4.2); advising on constitutional alignment for the referendum design; negotiating treaty language proposals with the European Commission legal service; ensuring compliance with all EU procedural requirements before ERM II entry confirmation.

**Background Story**:
Mr. Søren Brandt resides in Brussels, having practiced EU law for two decades, specializing in Treaty Law and European Council protocols, an expertise honed while serving as legal counsel to several smaller EU member states negotiating accession protocols. His qualifications include advanced degrees from the College of Europe. Søren has specific historical knowledge of the Edinburgh Agreement's context and the legal nuances required to petition for its amendment or repeal. He is relevant because successfully navigating the 'Opt-Out Resolution Mechanism Selection' (Decision 4) and the 'Legal Pathway to Opt-Out Removal' (Decision 1) depends entirely on his capacity to negotiate precisely worded legal frameworks with Brussels institutions.

**Equipment Needs**:
Access to specialized EU treaty archival and comparison databases; Secure digital links to European Commission/Council legal drafting platforms; Encrypted communication hardware for sensitive, real-time negotiation strategy relays between Brussels and Copenhagen.

**Facility Needs**:
Dedicated, secure liaison office space in the European Quarter, Brussels, with vetted Danish support staff access; Private meeting rooms designed for high-level bilateral discussions with EU Member State representatives.

## 3. Macroeconomic Convergence & ERM Strategist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Macroeconomic Convergence & ERM Strategist must manage the long, highly sensitive ERM II period (2+ years) and maintain consistent fiscal alignment with recurring ECB standards. This requires continuous, integrated policy execution rooted within the central bank or Ministry of Finance.

**Explanation**:
Designs and manages the DKK's entry into ERM II, oversees fiscal policy calibration to meet Maastricht criteria, and models the impact of exchange rate decisions (Decision 2 and 12).

**Consequences**:
Failure to meet ECB convergence audit (Risk 3); accidental economic shock due to poor parity selection, undermining public support.

**People Count**:
min 2, max 2, due to the high analytical requirement for convergence modeling.

**Typical Activities**:
Conducting rigorous modeling for the DKK's target parity within ERM II (Decision 2); calculating required fiscal adjustments to meet Maastricht convergence criteria (Decision 9); stress-testing the macroeconomic framework against potential external rate shocks; advising the Joint Ministerial Body on the timing and impact of pre-entry DKK valuation adjustments.

**Background Story**:
Professor Inga Kristensen, based in Aarhus, is a Macroeconomist famed for her rigorous modeling of Scandinavian currency valuations against the basket currencies. She earned her reputation through comprehensive Ph.D. work at the University of Copenhagen on the transmission mechanisms of ERM membership, leading to her subsequent advisory role at Danmarks Nationalbank during previous global economic realignments. Inga is now critical because the 'Builder's Blueprint' strategy hinges on maintaining the existing strict exchange rate policy pre-ERM II and defining a stable entry point. Her expertise minimizes the economic shock associated with parity selection (Decision 2) and ensures convergence targets are met robustly (Decision 12).

**Equipment Needs**:
High-performance economic modeling/simulation software (e.g., specialized econometric packages) licensed for DKK/EUR parity projection under ERM II scenarios; Access to proprietary ECB forward-looking economic data feeds.

**Facility Needs**:
Dedicated, isolated modeling lab within Danmarks Nationalbank or the Ministry of Finance for complex scenario planning (Decision 12); Conference facilities for quarterly economic convergence review briefings with the Joint Ministerial Body.

## 4. Central Bank Technical Integration Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Central Bank Technical Integration Lead and their team manage the critical, long-term integration of core national infrastructure (TARGET2, payment systems). This requires deep, continuous knowledge of both Danish and ECB proprietary systems, making full-time employment necessary.

**Explanation**:
Directs the National Bank's technical alignment (Shadow Integration Team, system integration), ensuring Danmarks Nationalbank meets all ECB operational standards (Decision 8 & 9) necessary for Eurosystem participation.

**Consequences**:
Technical failure on Euro Day (Risk 4); inability to participate in critical payment systems, leading to project termination or severe operational isolation.

**People Count**:
min 2, max 4, due to the heavy workload of securing IT and operational readiness concurrently with ongoing central bank duties.

**Typical Activities**:
Directing the six-month Euro Simulation Exercises (Assumption Q8) across all critical payment systems; managing the technical integration roadmap with ECB systems like TARGET2; ensuring the National Bank meets ECB statistical reporting standards ahead of schedule (Decision 9.2); overseeing the security hardening of financial communication channels.

**Background Story**:
Helle Jørgensen, a highly skilled IT architect working out of the National Bank headquarters in Copenhagen, led the core infrastructure overhaul that standardized data reporting across Danish financial regulators prior to this project. Her deep knowledge of payment systems, particularly legacy mainframe compatibility, is key. Helle established the internal 'Shadow Integration Team' (Action 2) and developed the proprietary simulation environment. She is relevant because the technical success of the Euro adoption (Risk 4) rests entirely on her ability to enforce the 'Central Bank Technical Integration Timeline' (Decision 8) and achieve full alignment with Eurosystem infrastructure before the final deadline.

**Equipment Needs**:
Full license suite and dedicated hardware clusters for running the 'Euro Simulation Exercises' (Assumption Q8) on a replicated national payment infrastructure; Specialized cyber-security monitoring tools for real-time integration testing against assumed Eurosystem protocols; Access to ECB/TARGET2 technical documentation portals.

**Facility Needs**:
Secured, climate-controlled server rooms housing the parallel 'Shadow Integration Team' infrastructure, physically proximal to Danmarks Nationalbank core systems; Dedicated training facilities for National Bank staff specializing in new ECB operational interfaces.

## 5. Public Referendum & Change Management Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Public Referendum & Change Management Lead oversees a massive, multi-year public engagement effort (Societal Readiness Pacing) and the high-stakes referendum execution. This requires sustained governmental authority and resource control for the duration of the project.

**Explanation**:
Manages the design, timing, and execution of the public consultation and referendum process (Decision 3), overseeing the comprehensive Societal Readiness Pacing and communication strategy (Decision 11).

**Consequences**:
Referendum failure (Risk 2) due to low trust or poor messaging; widespread public confusion leading to operational errors post-conversion (Risk 6).

**People Count**:
min 1, max 3, with surge capacity needed during active referendum campaigns.

**Typical Activities**:
Designing the communication strategy for the conditional binary referendum (Decision 3.2); overseeing the continuous educational stream via municipal outreach centers (Decision 11.2); managing the Quarterly Economic Alignment Stakeholder Forum (EASF) communications; tailoring messaging to vulnerable populations regarding rounding and price changes (Risk 6 mitigation).

**Background Story**:
Lars Møller, based in Odense, is an expert in political communication and democratic mandate securing. His background includes managing several multi-billion kroner national bond issuances that required winning public confidence through transparent reporting. Lars specializes in translating complex economic constraints into accessible political narratives. He is crucial for the 'Builder's Blueprint' as he ensures the complexity of deferring the opt-out repeal is managed alongside the public campaign; his work directly underpins the success of the 'Public Referendum Design and Timing' (Decision 3) and mitigates the risk of popular rejection (Risk 2).

**Equipment Needs**:
Multi-platform Digital Content Management System (CMS) capable of generating tailored communications across physical print, web, and broadcast media; Access to real-time national sentiment tracking and survey data platforms; Dedicated facility for hosting nationwide deliberative panel sessions (if chosen as sub-strategy).

**Facility Needs**:
Central Communications Hub for crisis management and media relations; Network of pre-vetted, adaptable municipal/regional venues suitable for hosting targeted community outreach centers for 'Societal Readiness Pacing' (Decision 11.2).

## 6. Financial & Legal Redenomination Specialist

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Financial & Legal Redenomination Specialist handles highly specific post-conversion legal frameworks, including drafting contingency legislation. This is a finite, specialized legal drafting task, well-suited for a contracted expert to ensure impartiality and finality (Risk 7 mitigation).

**Explanation**:
Focuses exclusively on the legal ramifications of DKK exit, guiding the mandatory re-denomination strategy for commercial contracts and ensuring clear dual-path legal contingency planning for referendum failure.

**Consequences**:
Prolonged post-adoption legal paralysis and significant litigation burden from private sector disputes (Risk 7).

**People Count**:
min 1, max 1, as this is a deep specialty requiring focused legal drafting.

**Typical Activities**:
Drafting the mandatory automatic rounding legislation for all existing long-term contracts (Decision 7.1); developing the formalized, non-punitive repeal clauses for preparatory legislation in case of referendum failure (Action 3); ensuring all new commercial contracts specify conversion methodology; advising the Ministry of Justice on Risk 7 mitigation.

**Background Story**:
Astrid Holm, operating as an independent legal consultant currently based primarily in The Hague but frequently commuting to Copenhagen, is a specialist in cross-border contract law and pre-emptive legislative drafting tailored for sovereign transitions. Her career has focused on minimizing corporate liability during forced currency changes. Astrid's primary contribution is structuring the legal certainty required for private sector actors. She is highly relevant for addressing Risk 7 and the critical requirement (Issue 3) to create a legally sound 'Dual-Path Legal Contingency Mandate.'

**Equipment Needs**:
Advanced legal research databases focused on EU Protocol Amendments and Danish Constitutional Law; Secure drafting and version control software for producing legally binding, dual-path legislation (contingency mandates); Secure digital platform for sharing sensitive legal drafts with Ministry of Justice and Bar Association.

**Facility Needs**:
Temporary, secure legal drafting chambers located near the Ministry of Justice in Copenhagen, with restricted access protocols; Private consultation rooms for sensitive legal feedback sessions with external counsel.

## 7. Fiscal Oversight & Budget Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: The Fiscal Oversight & Budget Manager is essential for tracking multi-year funding stability, inflation indexing, and managing contingency risks. This responsibility requires embedded, continuous financial control over the entire project lifespan within the Ministry of Finance structure.

**Explanation**:
Tracks multi-year budget expenditure, ensures funding stability (inflation hedging), manages contingency funds (DKK 50M), and reports on alignment with convergence targets from a fiscal perspective.

**Consequences**:
Budget erosion over the long timeline (Issue 2); inability to release contingency funds quickly for critical risks; project cost overruns forcing scope cuts.

**People Count**:
min 1, max 1, focused on internal financial hygiene and risk accounting.

**Typical Activities**:
Implementing mandatory annual budget real-indexation reviews for the transition costs; managing the DKK 50 million ring-fenced, inflation-adjusted contingency escrow account (Action 4); overseeing the allocation of funds for municipal IT incentives (Action 6); monitoring fiscal compliance against the Maastricht deficit goal from a treasury perspective.

**Background Story**:
Jens Pedersen, a career civil servant from the Ministry of Finance in Copenhagen, has overseen major capital program financing for over fifteen years, recently advising on long-term public debt management strategies. Jens is uniquely familiar with the erosion of budgetary commitments over multi-year timelines, having witnessed funding shortfalls caused by unexpected inflation spikes (Issue 2). He is responsible for ensuring the project's massive DKK 15–25 billion budget remains viable throughout the 6-8 year transition window, safeguarding the contingency fund necessary for risk mitigation.

**Equipment Needs**:
Enterprise Resource Planning (ERP) system capable of tracking multi-year budget expenditures with mandatory inflation-indexing features; Fiduciary management software for administering the ring-fenced, multi-signature contingency escrow account (DKK 50M+); Tools for generating mandated annual fiscal compliance reports against Maastricht targets.

**Facility Needs**:
A dedicated, secure office within the Ministry of Finance central accounting division for budget oversight; Private, secure meeting rooms for presenting sensitive fiscal projections to the Steering Committee.

## 8. Logistics & Operational Readiness Coordinator

**Contract Type**: `independent_contractor`

**Contract Type Justification**: The Logistics & Operational Readiness Coordinator manages several discrete, high-intensity implementation phases (cash logistics, municipal IT alignment). These are defined operational sprints that benefit from private sector expertise mobilized contractually for specific durations.

**Explanation**:
Oversees the physical aspects of conversion: managing the aggressive cash logistics plan (Decision 6 & 13), synchronizing dual circulation, and coordinating municipal IT compliance based on central mandates (Decision 14).

**Consequences**:
Cash shortages or security failures during dual circulation (Risk 5); inconsistent service delivery across municipalities (Risk 6/Decision 14 fallout).

**People Count**:
min 2, max 3, demanding parallel management of physical supply chain and local government readiness.

**Typical Activities**:
Securing and mobilizing specialized European cash-in-transit security contracts (Action 7); coordinating the DKK destruction schedule with Danmarks Nationalbank's secure storage capacity; designing the staggered rollout for cash distribution (Decision 13.2); overseeing the physical readiness audits for municipal cash handling points (Decision 14 synergy).

**Background Story**:
Marius Olsen, a seasoned logistics and supply chain specialist who spent years optimizing complex inter-Scandinavian cargo flows, was brought in specifically to manage the physical, high-security elements of the transition. He has a proven track record in rapid infrastructure qualification and mobilization under strict time constraints. Marius is the key driver for the aggressive 30-day dual circulation window (Decision 6.1), requiring him to manage the immediate security contracts (Action 7) and ensure physical cash synchronization (Decision 13) aligns with public readiness targets.

**Equipment Needs**:
Logistics Management Software (LMS) integrated with secure transport tracking systems (for cash movement); Contracts with certified European cash-handling and destruction facilities; IT inventory and compliance tracking tools for assessing municipal system readiness (Decision 14).

**Facility Needs**:
Negotiated usage rights for three geographically dispersed, high-security 'Buffer Stock Depots' (Decision 10.3) for EUR inventory; Secured tender evaluation rooms for assessing contracts with cash-in-transit security firms.

---

# Omissions

## 1. Missing Role for Local/Municipal Implementation Oversight

The plan relies heavily on the Central Bank and high-level Ministries, but Decision 14 focuses on Municipal/Regional conversion. There is no dedicated role responsible for coordinating, auditing, or enforcing compliance among the diverse, lower-tier governmental IT systems and administrative structures necessary for successful local-level adoption.

**Recommendation**:
Introduce a part-time or contracted 'Local Government Liaison Officer' role, reporting to the Public Referendum & Change Management Lead, tasked specifically with executing Decision 14 (Municipal Alignment) and ensuring centralized mandates are met via local outreach and incentive tracking.

## 2. Lack of Dedicated Internal Audit/Compliance Function

The project involves meeting strict, ongoing ECB convergence criteria (Risk 3) and internal technical readiness checks (Risk 4). While the Macroeconomic Strategist assesses criteria, there is no independent function explicitly tasked with conducting internal audits against ECB checklists or certifying readiness stages before reporting to the Joint Ministerial Body.

**Recommendation**:
Designate the Central Bank Technical Integration Lead's team (or a dedicated sub-unit) as the 'Internal Convergence Assurance Team,' making it their explicit responsibility to track readiness against Decision Parameters 9 and 12 and report compliance status directly to the Chief Transition Architect, ensuring independence from implementation drivers.

## 3. Absence of Public Financial Counseling/Consumer Protection Oversight

The plan addresses contract re-denomination (Decision 7) and public communication (Decision 11), but lacks a role dedicated to the immediate aftermath concerning consumer vulnerability, loan structuring, or providing sanctioned, neutral financial advice on conversion issues, which is critical given the high risk of public confusion (Risk 6).

**Recommendation**:
Integrate a specific mandate within the Public Referendum & Change Management Lead's scope (or create a small subcommittee) focused on 'Consumer Remediation and Education,' ensuring standardized, accessible guidance is available immediately post-referendum, protecting vulnerable citizens from exploitation during early price volatility.

---

# Potential Improvements

## 1. Clarifying Contingency Trigger for Dual-Path Legislation

Assumption Issue 3 highlights the uncertainty around the legal status of preparatory legislation if the referendum fails. The mitigation relies on automatic repeal, but this needs explicit formal sign-off alignment between the Ministry of Justice and the Directorate drafting the preparation laws.

**Recommendation**:
The Joint Ministerial Consultative Body must issue a Directive (Decision 5) mandating that the Financial & Legal Redenomination Specialist and the Chief Transition Architect jointly define—and publicly document—the *exact* failure threshold (e.g., majority rejection, or below X% turnout) that unilaterally triggers the legal team’s plan for legislative repeal.

## 2. Defining ERM II Stability Markers for Governance Checkpoints

The 'Builder's Blueprint' links the Opt-Out negotiation track to 12-month ERM II stability (Review Issue 1), but the current operational plan lacks defined markers (beyond standard ECB ones) for the *Joint Ministerial Consultative Body* to recognize 12 months of sufficient stability to advance diplomatic efforts.

**Recommendation**:
The Macroeconomic Convergence & ERM Strategist must propose three specific, measurable domestic fiscal/monetary stability metrics (e.g., core inflation band stability, reserve buffer level) that, when maintained for 12 consecutive months post-ERM II entry, trigger a mandatory, accelerated review session by the Consultative Body regarding the opt-out repeal negotiation.

## 3. Improving Budget Management Indexation Transparency to Stakeholders

Issue 2 correctly identifies budget erosion risk without inflation hedging. While the Fiscal Oversight & Budget Manager handles this internally, stakeholders, particularly the operational leads (Logistics, Technical), need assurance that resources allocated years in advance will retain real value.

**Recommendation**:
The Fiscal Oversight & Budget Manager must incorporate the annual **Real Value Erosion Index (RVEI)**—the real value of the original DKK budget based on indexation—into the quarterly EASF/Consultative Body reports, showcasing that contracted resources (like the Logistics Coordinator contracts) are benchmarked against the indexed budget baseline.

## 4. Standardizing Cash Logistics Phasing with Readiness Surveys

The plan mandates an aggressive 30-day dual circulation period (Decision 6.1), which relies heavily on public absorption speed. The Logistics Coordinator might mobilize cash supply ahead of the public's actual learned capacity.

**Recommendation**:
The Logistics & Operational Readiness Coordinator must synchronize the commercial sector cash rollout (Decision 13.3) with the Public Referendum & Change Management Lead's ongoing Societal Readiness Pacing surveys. Specifically, the release of high-denomination Euro notes into regional banks should be weighted based on achieving city/region-specific 'Readiness Scores' (e.g., 70% public comprehension of rounding rules) rather than a fixed national calendar date.