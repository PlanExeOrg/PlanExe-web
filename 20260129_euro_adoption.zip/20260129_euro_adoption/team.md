*Roles Needed & Example People*

# Roles

## 1. Transition Program Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Leads the overall transition, aligns political decision with technical execution, and ensures coherence across legal, economic, and operational workstreams.

**Explanation**:
Provides overall leadership, aligns political decision with technical execution, and ensures coherence across legal, economic, and operational workstreams.

**Consequences**:
Risk of fragmented decision-making, delayed milestones, and inability to reconcile trade-offs between referendum timing, ERM II entry, and fiscal constraints.

**People Count**:
1

**Typical Activities**:
Leading cross-ministry coordination, designing convergence roadmaps, preparing ECB-compliant documentation, drafting referendum legislation, and overseeing ERM II entry preparations.

**Background Story**:
A Copenhagen-based economist with a PhD in Monetary Policy from the University of Copenhagen and 15 years of experience at Danmarks Nationalbank and the Ministry of Finance. Specialized in ERM II transitions and EU fiscal frameworks, having contributed to Denmark’s earlier monetary policy assessments. Familiar with the national referendum process and the legal intricacies of treaty changes. Relevant because they can align technical convergence requirements with political timelines and ensure Denmark’s opt-out is lifted without compromising sovereignty.

**Equipment Needs**:
Dual-currency transaction processing platform (10k TPS capacity), hardened payment switch, core banking integration adapters, real-time reconciliation tools, FX rate feed and hedging systems, armored logistics tracking hardware, anti-counterfeiting sensors (holograms, UV), secure communication channels (E2EE), market sentiment AI infrastructure, API gateways to EU systems.

**Facility Needs**:
24/7 operations center, secure data centers with EU-grade resilience, cash vaults and regional micro-hubs (20 across municipalities), secure transport corridors, ECB/NatBank colocation, parliamentary/legal drafting rooms, stakeholder workshop facilities, training centers for retail staff.

## 2. Legal and Treaty Specialist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Designs the path to lift Denmark’s EU opt-out, drafts amendment options, and ensures compatibility with EU procedures and Danish constitutional requirements.

**Explanation**:
Designs the path to lift Denmark’s EU opt-out, drafts amendment options, and ensures compatibility with EU procedures and Danish constitutional requirements.

**Consequences**:
Treaty change may be blocked or delayed, causing loss of political momentum and increased uncertainty about the legal pathway to adoption.

**People Count**:
1

**Typical Activities**:
Drafting treaty amendment proposals, ensuring compatibility with EU law, advising on referendum legality, liaising with EU institutions, and stress-testing legal scenarios.

**Background Story**:
A Brussels-based legal expert who previously advised the European Commission on EU enlargement and opt-out negotiations. Holds a Master’s in European Law and has negotiated derogation waivers for several member states. Familiar with the precise language needed for treaty modifications and Danish constitutional constraints. Relevant because they can translate EU procedural expectations into actionable steps for Denmark while safeguarding legal certainty.

**Equipment Needs**:
Legal drafting suites, treaty simulation tools, compliance checklists, EU legislative tracking systems, referendum legal test calculators, contingency protocol templates, multilingual communication assets, document management with version control.

**Facility Needs**:
Secure legislative drafting environment, parliamentary consultation rooms, independent electoral commission office, EU liaison desk at national representation in Brussels, secure archives for referendum data.

## 3. Monetary and ERM II Strategist

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Defines convergence strategy, DKK/EUR peg management, and sequencing of ERM II entry relative to referendum and legislative changes.

**Explanation**:
Defines the convergence strategy, DKK/EUR peg management, and the sequencing of ERM II entry relative to the referendum and legislative changes.

**Consequences**:
Poorly timed ERM II entry could undermine price stability expectations and complicate central bank credibility and ECB oversight.

**People Count**:
1

**Typical Activities**:
Modeling peg stability, designing central bank intervention rules, forecasting FX reserves needs, and aligning monetary policy with ECB guidelines.

**Background Story**:
A monetary strategist formerly at the ECB and now leading a Nordic fintech transition project. Expert in exchange-rate peg management, dual-currency systems, and central bank balance sheet optimization. Played a key role in the technical design of the Baltic euro adoptions. Relevant because they can design Denmark’s ERM II entry parity and ensure minimal volatility during the pre-adoption phase.

**Equipment Needs**:
Convergence modeling workstations, DSGE and FX stress test tools, ECB communication monitoring dashboards, scenario planning sandboxes, liquidity forecasting systems, zero/low-code integration platforms for policy rules.

**Facility Needs**:
Policy lab with sandbox access to ECB test environments, secure analytics enclave, meeting facilities with ECB/Eurogroup observers, crisis simulation rooms.

## 4. Financial Infrastructure and IT Lead

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Oversees dual-currency conversion of payment systems, central bank reserves, and settlement platforms to ensure technical resilience and continuity.

**Explanation**:
Oversees dual-currency conversion of payment systems, central bank reserves, and settlement platforms to ensure technical resilience and continuity.

**Consequences**:
Operational failures in payment systems could cause market disruptions, increased costs, and delays in achieving full euro adoption.

**People Count**:
1

**Typical Activities**:
Overseeing dual-currency processing platforms, certifying bank systems, managing cutover plans, and validating settlement workflows.

**Background Story**:
A payments infrastructure lead with a background in deploying large-scale real-time gross settlement systems for multiple EU countries. Previously modernized payment rails in a country transitioning to the euro. Familiar with ISO 20022 standards and legacy system integration. Relevant because they can ensure Denmark’s financial infrastructure is resilient and interoperable before, during, and after the switch.

**Equipment Needs**:
Core bank settlement systems (RTGS), ISO 20022 messaging infrastructure, API management for commercial banks, certificate authority for digital identities, secure key management, cash management automation engines.

**Facility Needs**:
National bank operations center, secure key custody facilities, 24/7 network operations center, redundant connectivity to Eurosystem, secure cloud or on-prem enclave for critical modules.

## 5. Cash Logistics and Seigniorage Manager

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Plans euro cash supply, distribution hubs, and dual-circulation handling to avoid shortages and manage withdrawal of the krone.

**Explanation**:
Plans euro cash supply, distribution hubs, and dual-circulation handling to avoid shortages and manage the withdrawal of the krone.

**Consequences**:
Cash shortages and logistical bottlenecks could erode public trust and disrupt commerce during the transition.

**People Count**:
1

**Typical Activities**:
Designing cash hub networks, forecasting euro cash demand, managing armored logistics, and securing coin supply chains.

**Background Story**:
A logistics and supply-chain manager with extensive experience in cash-in-transit operations for central banks across Europe. Previously coordinated the physical euro rollout in two mid-sized EU economies. Relevant because they can plan the distribution and withdrawal of Danish krone and euro cash while minimizing shortages and seigniorage leakage.

**Equipment Needs**:
Forecasting and route optimization tools, real-time inventory sensors, cross-dock management systems, temperature-controlled secure transport for coin, mobile coin processing units, smart dispensers/recyclers, tamper-evident packaging.

**Facility Needs**:
15 regional cash hubs with secure storage, armored transport fleet and depots, micro-hubs at municipalities, reverse logistics for old currency destruction, 24/7 logistics control center.

## 6. Stakeholder and Communication Director

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Coordinates public and institutional outreach, referendum preparation, and change management across citizens, businesses, and municipalities.

**Explanation**:
Coordinates public and institutional outreach, referendum preparation, and change management across citizens, businesses, and municipalities.

**Consequences**:
Misinformation and low public readiness could lead to referendum failure or social resistance during dual circulation.

**People Count**:
1

**Typical Activities**:
Designing communication campaigns, training spokespersons, monitoring misinformation, and coordinating with municipalities and unions.

**Background Story**:
A public communication strategist who led nationwide change-management programs during the Slovak and Estonian euro adoptions. Expert in voter sentiment analysis, media outreach, and referendum messaging. Relevant because they can craft narratives that build public trust and ensure high turnout and informed choice.

**Equipment Needs**:
Campaign management platforms, multilingual content creation tools, misinformation detection systems, sentiment analytics, training LMS for spokespersons, accessibility-compliant materials, event management systems.

**Facility Needs**:
National media war room, regional community centers for town halls, stakeholder roundtable venues, digital engagement portals, secure feedback channels.

## 7. Risk and Contingency Planner

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Maintains the risk register, stress tests, and contingency reserves; ensures fiscal and monetary safeguards are in place.

**Explanation**:
Maintains the risk register, stress tests, and contingency reserves; ensures fiscal and monetary safeguards are in place.

**Consequences**:
Unmanaged financial, operational, or market risks could escalate costs and delay the timeline by years.

**People Count**:
1

**Typical Activities**:
Quantifying risk exposure, stress-testing conversion timelines, designing contingency reserves, and reporting to oversight bodies.

**Background Story**:
A risk-management specialist with a focus on fiscal and operational resilience in large public transitions. Developed contingency frameworks for several EU structural funds and euro adoption programs. Relevant because they can maintain a live risk register, model downside scenarios, and safeguard budget integrity.

**Equipment Needs**:
Risk register database, stress testing and Monte Carlo tools, contingency fund accounting systems, early warning indicators, audit trails, compliance reporting automation.

**Facility Needs**:
Risk war room, independent audit facilities, secure data lakes for monitoring, board-level oversight rooms, incident response SOC.

## 8. EU and Governance Liaison Officer

**Contract Type**: `full_time_employee`

**Contract Type Justification**: Engages with EU institutions (Commission, ECB, Eurogroup) to align on convergence criteria, treaty changes, and ongoing compliance.

**Explanation**:
Engages with EU institutions (Commission, ECB, Eurogroup) to align on convergence criteria, treaty changes, and ongoing compliance.

**Consequences**:
Weak EU alignment may result in rejected derogations, delayed approvals, and loss of policy leverage.

**People Count**:
1

**Typical Activities**:
Managing EU institutional relationships, tracking convergence assessments, and translating EU guidance into domestic implementation plans.

**Background Story**:
An EU governance liaison officer with prior postings in the European Commission and the Danish Permanent Representation to the EU. Fluent in EU decision-making dynamics and conditionality requirements. Relevant because they can keep Denmark’s opt-out waiver negotiations aligned with political red lines and technical realities.

**Equipment Needs**:
EU regulatory tracking systems, negotiation document management, secure video conferencing with EU institutions, translation and interpretation systems, legal document comparison tools.

**Facility Needs**:
EU liaison office in Brussels, secure negotiation suites, parliamentary oversight chambers, stakeholder hearing rooms.

---

# Omissions

## 1. Independent fiscal-monetary capacity during convergence

No explicit assumption on Denmark’s ability to maintain autonomous fiscal support and Danmarks Nationalbank’s operational capacity while converging under external ECB oversight. This gap could delay the timeline and increase costs.

**Recommendation**:
Quantify fiscal space using a structural deficit threshold (<0.5% of GDP) and simulate ECB policy scenarios. Establish a pre-commitment facility (e.g., a temporary credit line with the ECB or ESM) to preserve autonomy. Define a fiscal rule allowing temporary, rules-based deviations during convergence ramp-up, with independent verification by the FSA.

## 2. Legal enforceability of referendum outcomes and fallback mechanisms

The plan assumes a binary referendum can lock the process but does not address scenarios where turnout or margin is ambiguous, or where post-referendum political shifts occur. This creates legal uncertainty that can stall treaty change and delay ERM II entry.

**Recommendation**:
Embed a clear legal test (e.g., >50% turnout and >40% of electorate in favor) and a defined fallback (e.g., a ‘soft referendum’ mandate for the Folketing to proceed with treaty change under specified conditions). Draft contingency protocols for annulment or narrow wins, including a 12-month cooling-off and re-engagement phase with adjusted communication.

## 3. Currency risk management during dual circulation and ECB balance sheet exposure

Assumptions on cash logistics and seigniorage do not fully account for exchange-rate volatility between DKK and EUR during the dual-circulation window. A depreciation could increase conversion costs and delay full adoption.

**Recommendation**:
Implement a dynamic hedging program using EUR/DKK forwards aligned with the parity band, and establish a Sovereign Conversion Fund capitalized at 0.5–1% of GDP to absorb FX volatility. Publish daily parity bands and conduct weekly stress tests with the ECB.

## 4. Interoperability and legacy system sunsetting for payment infrastructures

Assumptions on IT alignment (e.g., ISO 20022) do not address coexistence costs and technical debt in legacy Danish banking systems. This could raise operational risk costs and delay full adoption.

**Recommendation**:
Mandate a phased legacy sunsetting schedule with incentives for early adoption (e.g., regulatory capital relief for compliant institutions). Create an Interoperability Certification Body under the FSA to audit and accredit systems, with penalties for non-compliance.

## 5. Public inflation expectations and wage-price spiral risks during dual circulation

The plan does not explicitly model how price rounding and dual pricing may feed into inflation expectations. This could trigger wage-price spirals and force premature ECB-style tightening, reducing ROI.

**Recommendation**:
Introduce a Wage-Price Protocol with indexed rounding caps and a public dashboard for transparency. Pair with a macroprudential buffer (e.g., countercyclical capital buffers) to dampen demand-side pressures, and simulate scenarios using the ECB’s Convergence Report templates.

---

# Potential Improvements

## 1. Clarify roles and reduce overlap in transition governance

The team documents multiple leads (e.g., Transition Program Director, Legal and Treaty Specialist, Monetary and ERM II Strategist) but does not explicitly define decision rights and interfaces. Ambiguity can cause duplicated efforts and delayed decisions.

**Recommendation**:
Create a RACI matrix for all major workstreams (legal, IT, cash logistics, communication) and institute a weekly steering-committee decision log. Assign a single decision owner for each major gate (e.g., referendum timing, ERM II entry) to reduce overlap.

## 2. Strengthen contingency and risk register integration

The risk register exists but lacks integration with day-to-day decision triggers and contingency budgeting. This reduces responsiveness when events like supply shortages or market shocks occur.

**Recommendation**:
Embed the risk register into a live dashboard with traffic-light indicators and predefined contingency triggers. Allocate a contingency reserve of 5–10% of the projected transition budget and link release to objective metrics (e.g., FX band breaches, IT incident severity).

## 3. Simplify communication for public and stakeholder readiness

The plan calls for sustained multi-channel communication but does not specify a unified message architecture and feedback loops. Misinformation can erode referendum support and cause confusion during dual circulation.

**Recommendation**:
Define a core message hierarchy (why, what, when, how) for all stakeholders, and establish a single public-facing portal for FAQs, calculators, and updates. Implement a rumor-tracking and rapid-response protocol with a 24-hour acknowledgment SLA.

## 4. Define clear cutover and rollback procedures for IT and payments

The plan mentions phased cutover but lacks explicit rollback criteria and responsibilities if critical systems fail during the switch.

**Recommendation**:
Document a cutover playbook with go/no-go checkpoints, rollback triggers (e.g., settlement failure rate >1%), and a 24/7 incident command structure. Conduct at least two end-to-end dry runs with live data before go-live.

## 5. Align EU negotiation posture with domestic referendum sequencing

Treaty Change Negotiation Posture and Public Mandate Acquisition Timeline are linked but not explicitly synchronized. Misalignment can weaken Denmark’s negotiating position or cause public confusion.

**Recommendation**:
Create a synchronized timeline that ties referendum dates to pre-agreed EU deliverables (e.g., derogation waiver draft). Assign a dedicated liaison to coordinate messaging between the EU desk and the communications team.