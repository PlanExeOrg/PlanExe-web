A premortem assumes the project has failed and works backward to identify the most likely causes.

## Assumptions to Kill

These foundational assumptions represent the project's key uncertainties. If proven false, they could lead to failure. Validate them immediately using the specified methods.

| ID | Assumption | Validation Method | Failure Trigger |
|----|------------|-------------------|-----------------|
| A1 | The Danish public is primarily driven by rational economic arguments and will support Euro adoption if presented with sufficient data on its benefits. | Conduct a survey focusing on emotional responses to Euro adoption, including questions about national identity and cultural values. | The survey reveals that emotional concerns outweigh economic considerations for a significant portion (>=40%) of the population. |
| A2 | The Danish financial sector can efficiently and securely upgrade its IT infrastructure to handle Euro transactions within the projected timeline and budget. | Conduct a pilot program with a representative sample of banks to assess the actual time and resources required for IT system upgrades. | The pilot program reveals that the average upgrade time exceeds the projected timeline by more than 25% or the average cost exceeds the budget by more than 25%. |
| A3 | The EU will remain politically stable and supportive of Denmark's specific legal pathway for Euro adoption throughout the negotiation process. | Conduct regular (monthly) consultations with key EU officials to gauge their support for Denmark's preferred legal pathway and identify potential roadblocks. | Key EU officials express significant reservations or opposition to Denmark's preferred legal pathway, or a major political crisis disrupts EU decision-making processes. |
| A4 | The supply of Euro banknotes and coins will be readily available and uninterrupted throughout the transition period. | Conduct a detailed supply chain analysis, mapping out all potential sources and transportation routes for Euro banknotes and coins. | The analysis reveals significant vulnerabilities in the supply chain, such as reliance on a single supplier or transportation route, or insufficient storage capacity. |
| A5 | Danish businesses will proactively adapt to Euro-denominated pricing and transactions, minimizing disruption to commerce. | Conduct a survey of Danish businesses to assess their preparedness for Euro-denominated pricing and transactions, including their understanding of conversion rates and their plans for IT system updates. | The survey reveals that a significant portion (>=30%) of Danish businesses are unprepared for Euro-denominated pricing and transactions, lacking the necessary knowledge or resources. |
| A6 | The transition to the Euro will not significantly increase the risk of financial crime, such as money laundering and counterfeiting. | Conduct a comprehensive risk assessment, focusing on potential vulnerabilities in the financial system during the transition period, and develop enhanced monitoring and detection mechanisms. | The risk assessment identifies significant vulnerabilities in the financial system, or the enhanced monitoring mechanisms detect a significant increase (>=20%) in suspicious financial activity. |
| A7 | Citizens will readily exchange their Danish Krone (DKK) for Euros within the designated timeframe, minimizing disruption to the currency transition. | Conduct a pilot exchange program in a representative region, offering incentives for early exchange and monitoring the rate of DKK return. | The pilot program reveals a low exchange rate (<=50% of DKK returned) within the designated timeframe, indicating public reluctance or logistical barriers. |
| A8 | The Danish legal system can efficiently adapt to Eurozone regulations and legal frameworks without significant delays or conflicts. | Conduct a comprehensive legal review, comparing Danish law with Eurozone regulations and identifying potential areas of conflict or required amendments. | The legal review identifies significant conflicts or required amendments that are projected to take more than 12 months to resolve, potentially delaying the Euro adoption process. |
| A9 | The adoption of the Euro will not negatively impact Denmark's social cohesion or exacerbate existing inequalities. | Conduct a social impact assessment, focusing on potential effects on vulnerable populations, income distribution, and access to essential services. | The social impact assessment projects a significant increase (>=10%) in income inequality or a decline in access to essential services for vulnerable populations, indicating a negative impact on social cohesion. |


## Failure Scenarios and Mitigation Plans

Each scenario below links to a root-cause assumption and includes a detailed failure story, early warning signs, measurable tripwires, a response playbook, and a stop rule to guide decision-making.

### Summary of Failure Modes

| ID | Title | Archetype | Root Cause | Owner | Risk Level |
|----|-------|-----------|------------|-------|------------|
| FM1 | The Glitch Gridlock | Technical/Logistical | A2 | Head of Engineering | CRITICAL (16/25) |
| FM2 | The Sovereignty Storm | Market/Human | A1 | Public Communication Lead | CRITICAL (15/25) |
| FM3 | The Treaty Trap | Process/Financial | A3 | Permitting Lead | HIGH (10/25) |
| FM4 | The Empty Vault Crisis | Technical/Logistical | A4 | Logistics & Operations Coordinator | CRITICAL (15/25) |
| FM5 | The Price Confusion Catastrophe | Market/Human | A5 | Stakeholder Liaison & Community Outreach | CRITICAL (16/25) |
| FM6 | The Crime Wave Calamity | Process/Financial | A6 | Risk & Contingency Planner | HIGH (10/25) |
| FM7 | The Krone Clutch Catastrophe | Market/Human | A7 | Public Communication & Engagement Lead | CRITICAL (16/25) |
| FM8 | The Legal Labyrinth Lockdown | Technical/Logistical | A8 | Legal & Treaty Expert | CRITICAL (15/25) |
| FM9 | The Inequality Inferno | Process/Financial | A9 | Economic Impact Analyst | HIGH (10/25) |


### Failure Modes

#### FM1 - The Glitch Gridlock

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A2
- **Owner**: Head of Engineering
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that the Danish financial sector can handle the IT upgrades proves false. Banks, particularly smaller regional ones, struggle with outdated systems and a lack of specialized IT personnel. 

*   Initial upgrades reveal unexpected incompatibilities between different banking platforms.
*   The standardized conversion process, intended to streamline the transition, becomes a bottleneck as banks struggle to adapt.
*   Cybersecurity vulnerabilities are discovered during the upgrade process, requiring costly and time-consuming patches.
*   The payment system conversion is delayed as a result of the IT issues, leading to disruptions in financial services.
*   The delays cascade, impacting businesses and consumers who are unable to conduct Euro transactions efficiently.

##### Early Warning Signs
- IT upgrade costs exceed initial estimates by 15%
- More than 20% of banks report significant delays in IT system upgrades
- Critical cybersecurity vulnerabilities are discovered during testing

##### Tripwires
- IT system upgrade completion rate <= 75% by [Date]
- Number of critical cybersecurity vulnerabilities discovered >= 5
- Payment system transaction processing time >= 5 seconds

##### Response Playbook
- Contain: Immediately halt further IT system upgrades.
- Assess: Conduct a thorough audit of the IT infrastructure and identify the root causes of the delays and vulnerabilities.
- Respond: Develop a revised IT upgrade plan with a phased approach, providing additional technical assistance and resources to struggling banks.


**STOP RULE:** If critical IT systems remain unstable 6 months after the initial Euro adoption date, halt the project.

---

#### FM2 - The Sovereignty Storm

- **Archetype**: Market/Human
- **Root Cause**: Assumption A1
- **Owner**: Public Communication Lead
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The government assumes that rational economic arguments will sway the Danish public, but they fail to account for deep-seated emotional attachments to national identity and sovereignty. 

*   The public communication campaign focuses on economic benefits, neglecting concerns about loss of control over monetary policy.
*   Eurosceptic groups effectively frame the Euro adoption as a betrayal of Danish values and independence.
*   Misinformation campaigns spread rapidly through social media, undermining public trust in the government's message.
*   Key demographic groups, particularly older citizens and those in rural areas, remain unconvinced of the benefits of Euro adoption.
*   Public support for the Euro plummets, leading to a 'no' vote in the referendum.

##### Early Warning Signs
- Public approval rating for Euro adoption falls below 50%
- Social media sentiment towards Euro adoption turns negative
- Eurosceptic groups gain significant traction in public discourse

##### Tripwires
- Public support for Euro adoption <= 45% in national polls
- Negative sentiment score on social media >= 60%
- Eurosceptic party support >= 25% in parliamentary polls

##### Response Playbook
- Contain: Immediately reassess the public communication strategy.
- Assess: Conduct focus groups and surveys to understand the root causes of public opposition.
- Respond: Develop a revised communication campaign that addresses emotional concerns and emphasizes the benefits of Euro adoption for Danish identity and sovereignty.


**STOP RULE:** If public support remains below 40% one month before the referendum, cancel the project.

---

#### FM3 - The Treaty Trap

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A3
- **Owner**: Permitting Lead
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
Denmark assumes that the EU will remain politically stable and supportive, but a sudden shift in EU politics throws the legal pathway into disarray. 

*   A major political crisis in the EU leads to a change in leadership and policy priorities.
*   Key EU officials who previously supported Denmark's preferred legal pathway are replaced by those with reservations.
*   Negotiations stall as the EU focuses on internal issues and postpones discussions on Denmark's Euro adoption.
*   The legal framework for Euro adoption becomes uncertain, delaying the project and increasing legal costs.
*   Investors lose confidence in Denmark's ability to join the Eurozone, leading to a decline in foreign investment.

##### Early Warning Signs
- Key EU officials express reservations about Denmark's legal pathway
- EU negotiations are delayed by more than 3 months
- Foreign investment in Denmark declines by 10%

##### Tripwires
- EU negotiations stalled for >= 6 months
- Key EU official support score <= 2 out of 5
- Legal costs exceed budget by >= 20%

##### Response Playbook
- Contain: Immediately explore alternative legal pathways.
- Assess: Conduct a thorough assessment of the new EU political landscape and its impact on Denmark's Euro adoption prospects.
- Respond: Develop a revised legal strategy that aligns with the new EU political realities, potentially seeking support from other member states.


**STOP RULE:** If a viable legal pathway cannot be secured within 12 months, cancel the project.

---

#### FM4 - The Empty Vault Crisis

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A4
- **Owner**: Logistics & Operations Coordinator
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption of a readily available Euro supply proves false. A confluence of unforeseen events cripples the supply chain. 

*   A major strike at the printing facility responsible for Euro banknotes causes significant production delays.
*   Severe weather disrupts transportation routes, preventing the timely delivery of banknotes and coins to Denmark.
*   Unexpectedly high demand for Euro currency depletes existing reserves, leading to shortages at ATMs and banks.
*   Public panic ensues as people struggle to access cash, undermining confidence in the new currency.
*   Businesses are unable to conduct transactions, leading to economic disruption and widespread frustration.

##### Early Warning Signs
- Euro banknote production is delayed by more than 2 weeks
- Transportation routes are disrupted due to severe weather
- ATM cash withdrawals increase by 20%

##### Tripwires
- Euro banknote reserves <= 25% of projected demand
- ATM cash withdrawal wait times >= 30 minutes
- Number of ATMs out of cash >= 10%

##### Response Playbook
- Contain: Immediately implement emergency cash distribution measures, prioritizing essential services.
- Assess: Conduct a thorough assessment of the supply chain disruptions and identify alternative sources of Euro currency.
- Respond: Negotiate emergency shipments of Euro banknotes from other Eurozone countries, and implement rationing measures to conserve existing reserves.


**STOP RULE:** If Euro currency shortages persist for more than 1 week, postpone the official Euro adoption date.

---

#### FM5 - The Price Confusion Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A5
- **Owner**: Stakeholder Liaison & Community Outreach
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The government assumes that Danish businesses will adapt quickly, but many struggle with the complexities of Euro-denominated pricing. 

*   Small businesses, lacking the resources for IT upgrades and staff training, fail to accurately convert prices.
*   Consumers are confused by the new pricing system, leading to distrust and reluctance to spend.
*   Some businesses exploit the confusion by engaging in price gouging, further eroding public trust.
*   A significant portion of the economy remains stuck in DKK pricing, creating a parallel currency system and hindering the transition.
*   The lack of Euro-denominated pricing undermines the benefits of Euro adoption, such as increased price transparency and reduced transaction costs.

##### Early Warning Signs
- Consumer complaints about price gouging increase by 50%
- A significant portion of businesses continue to display prices in DKK only
- Economic activity slows down due to consumer reluctance to spend

##### Tripwires
- Number of consumer complaints about price gouging >= 100 per day
- Percentage of businesses displaying prices in DKK only >= 40%
- Retail sales decline by >= 10%

##### Response Playbook
- Contain: Immediately launch a public awareness campaign to educate consumers about Euro pricing and combat price gouging.
- Assess: Conduct a survey of businesses to identify the challenges they are facing in adapting to Euro-denominated pricing.
- Respond: Provide additional training and resources to struggling businesses, and implement stricter enforcement measures against price gouging.


**STOP RULE:** If a significant portion of the economy remains stuck in DKK pricing 3 months after the official Euro adoption date, halt the project.

---

#### FM6 - The Crime Wave Calamity

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A6
- **Owner**: Risk & Contingency Planner
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
Denmark assumes that the transition will not increase financial crime, but the introduction of a new currency creates opportunities for illicit activity. 

*   Money launderers exploit vulnerabilities in the financial system to convert illicit funds into Euros.
*   Counterfeit Euro banknotes flood the market, undermining public trust in the new currency.
*   Cybercriminals target financial institutions, stealing Euro currency and sensitive customer data.
*   The authorities are overwhelmed by the surge in financial crime, struggling to effectively investigate and prosecute offenders.
*   The increase in financial crime undermines the benefits of Euro adoption, such as increased financial stability and reduced transaction costs.

##### Early Warning Signs
- Suspicious financial activity increases by 30%
- Counterfeit Euro banknotes are detected in circulation
- Cyberattacks targeting financial institutions increase

##### Tripwires
- Number of suspicious financial transactions reported >= 50 per day
- Number of counterfeit Euro banknotes detected >= 100 per week
- Successful cyberattacks on financial institutions >= 2

##### Response Playbook
- Contain: Immediately implement enhanced monitoring and detection mechanisms to identify and prevent financial crime.
- Assess: Conduct a thorough assessment of the vulnerabilities in the financial system that are being exploited by criminals.
- Respond: Strengthen law enforcement efforts to investigate and prosecute financial crime, and implement stricter regulations to prevent money laundering and counterfeiting.


**STOP RULE:** If financial crime rates remain significantly elevated 6 months after the official Euro adoption date, halt the project.

---

#### FM7 - The Krone Clutch Catastrophe

- **Archetype**: Market/Human
- **Root Cause**: Assumption A7
- **Owner**: Public Communication & Engagement Lead
- **Risk Level:** CRITICAL 16/25 (Likelihood 4/5 × Impact 4/5)

##### Failure Story
The assumption that citizens will readily exchange their DKK for Euros proves false. A combination of factors leads to widespread reluctance. 

*   Distrust in the Euro and the government's handling of the transition fuels a desire to hold onto the familiar Krone.
*   Logistical challenges, such as limited exchange locations and long wait times, discourage many citizens from exchanging their currency.
*   Misinformation about the exchange rate and potential fees creates confusion and anxiety.
*   A black market for DKK emerges, further undermining the official exchange process.
*   The slow pace of DKK return disrupts the currency transition, creating a parallel currency system and hindering economic integration.

##### Early Warning Signs
- DKK return rate remains low after the initial exchange period
- Long lines and wait times are reported at exchange locations
- Misinformation about the exchange rate spreads rapidly on social media

##### Tripwires
- DKK return rate <= 60% after 3 months
- Average wait time at exchange locations >= 1 hour
- Number of inquiries about exchange rate discrepancies >= 500 per day

##### Response Playbook
- Contain: Immediately launch a targeted communication campaign to address public concerns and promote the benefits of exchanging DKK for Euros.
- Assess: Conduct a survey to identify the reasons for public reluctance to exchange currency.
- Respond: Increase the number of exchange locations, extend exchange hours, and offer incentives for early exchange.


**STOP RULE:** If DKK return rate remains below 50% six months after the official exchange deadline, the project will be re-evaluated.

---

#### FM8 - The Legal Labyrinth Lockdown

- **Archetype**: Technical/Logistical
- **Root Cause**: Assumption A8
- **Owner**: Legal & Treaty Expert
- **Risk Level:** CRITICAL 15/25 (Likelihood 3/5 × Impact 5/5)

##### Failure Story
The assumption that the Danish legal system can efficiently adapt to Eurozone regulations proves overly optimistic. Unexpected complexities and conflicts emerge. 

*   Significant discrepancies are discovered between Danish law and Eurozone regulations, requiring extensive amendments.
*   Legal challenges are filed, questioning the compatibility of Euro adoption with the Danish constitution.
*   The legal review process is delayed by bureaucratic hurdles and political disagreements.
*   Uncertainty about the legal framework undermines investor confidence and hinders financial system integration.
*   The delays cascade, impacting the timeline for Euro adoption and increasing legal costs.

##### Early Warning Signs
- Legal review process falls behind schedule
- Significant discrepancies are identified between Danish law and Eurozone regulations
- Legal challenges are filed against the Euro adoption process

##### Tripwires
- Legal review completion rate <= 75% by [Date]
- Number of legal challenges filed >= 3
- Projected time to resolve legal conflicts >= 6 months

##### Response Playbook
- Contain: Immediately prioritize the resolution of legal conflicts and streamline the legal review process.
- Assess: Conduct a thorough assessment of the legal challenges and identify potential solutions.
- Respond: Engage with legal experts and stakeholders to develop a revised legal strategy, and seek political support for necessary legal amendments.


**STOP RULE:** If the legal framework for Euro adoption remains unresolved 12 months after the initial target date, the project will be re-evaluated.

---

#### FM9 - The Inequality Inferno

- **Archetype**: Process/Financial
- **Root Cause**: Assumption A9
- **Owner**: Economic Impact Analyst
- **Risk Level:** HIGH 10/25 (Likelihood 2/5 × Impact 5/5)

##### Failure Story
The assumption that Euro adoption will not negatively impact social cohesion proves tragically wrong. The transition exacerbates existing inequalities. 

*   Vulnerable populations, such as low-income individuals and the elderly, struggle to adapt to the new currency and financial systems.
*   Businesses in disadvantaged communities are unable to compete with larger firms, leading to job losses and economic decline.
*   The cost of essential goods and services increases, disproportionately impacting low-income households.
*   Social unrest erupts as inequalities widen and public trust in the government erodes.
*   The social and economic costs of Euro adoption outweigh the benefits, undermining the project's legitimacy.

##### Early Warning Signs
- Income inequality increases significantly
- Access to essential services declines for vulnerable populations
- Social unrest and protests increase

##### Tripwires
- Gini coefficient increases by >= 0.05
- Access to essential services (healthcare, education) declines by >= 10% for vulnerable populations
- Number of social unrest incidents >= 5 per month

##### Response Playbook
- Contain: Immediately implement social safety net programs to support vulnerable populations and mitigate the negative impacts of Euro adoption.
- Assess: Conduct a thorough assessment of the social and economic consequences of Euro adoption, focusing on vulnerable populations.
- Respond: Develop targeted policies to address income inequality, promote economic development in disadvantaged communities, and ensure access to essential services for all citizens.


**STOP RULE:** If social unrest and inequality reach a level that threatens social stability, the project will be halted.
