### 1. Project Manager drafts initial Terms of Reference (ToR) for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft SteerCo ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 2. Project Manager circulates Draft PSC ToR for review by nominated PSC members (Prime Minister's Office, Minister of Finance, etc.).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Circulation Email
- Draft SteerCo ToR v0.1

**Dependencies:**

- Draft SteerCo ToR v0.1
- Nominated Members List Available

### 3. Project Manager consolidates feedback on the Draft PSC ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SteerCo ToR v0.2

**Dependencies:**

- Circulation of Draft SteerCo ToR
- Feedback Received from Nominated Members

### 4. Project Sponsor (Prime Minister or designated representative) formally approves the PSC Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Approved SteerCo ToR v1.0

**Dependencies:**

- Draft SteerCo ToR v0.2
- Feedback Incorporated

### 5. Project Sponsor formally appoints the Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 6. Project Sponsor formally appoints the Vice-Chair of the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SteerCo ToR v1.0

### 7. Project Sponsor formally confirms all other members of the Project Steering Committee (PSC) (Minister of Finance, Minister of Economy, etc.).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Approved SteerCo ToR v1.0

### 8. Project Manager, in coordination with the PSC Chair, schedules the initial Project Steering Committee (PSC) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- PSC Members Confirmed
- PSC Chair Appointed

### 9. Hold the initial Project Steering Committee (PSC) kick-off meeting to review the project plan, discuss strategic priorities, and establish communication protocols.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PSC Members Confirmed
- PSC Chair Appointed
- Meeting Scheduled

### 10. Project Manager establishes the Project Management Office (PMO) structure and staffing.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- PMO Structure Chart
- Staffing Plan

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 11. Project Manager develops project management methodologies and tools for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Project Management Handbook
- Templates and Tools

**Dependencies:**

- PMO Structure Established

### 12. Project Manager sets up project reporting and communication systems for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Reporting Templates
- Communication Protocols

**Dependencies:**

- Project Management Methodologies Developed

### 13. Project Manager defines roles and responsibilities within the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Role Descriptions
- Responsibility Matrix

**Dependencies:**

- PMO Structure Established

### 14. Project Manager establishes a risk management framework for the PMO.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Risk Management Plan
- Risk Register Template

**Dependencies:**

- Project Management Methodologies Developed

### 15. Project Manager holds the initial PMO kick-off meeting to assign initial tasks and establish communication protocols.

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- PMO Structure Established
- Project Management Methodologies Developed
- Risk Management Framework Established

### 16. Project Manager drafts initial Terms of Reference (ToR) for the Legal and Compliance Committee (LCC).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft LCC ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 17. Project Manager circulates Draft LCC ToR for review by Ministry of Justice and external legal experts.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Circulation Email
- Draft LCC ToR v0.1

**Dependencies:**

- Draft LCC ToR v0.1

### 18. Project Manager consolidates feedback on the Draft LCC ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft LCC ToR v0.2

**Dependencies:**

- Circulation of Draft LCC ToR
- Feedback Received

### 19. Project Sponsor formally approves the LCC Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved LCC ToR v1.0

**Dependencies:**

- Draft LCC ToR v0.2
- Feedback Incorporated

### 20. Project Sponsor appoints the Chief Legal Counsel as Chair of the Legal and Compliance Committee (LCC).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved LCC ToR v1.0

### 21. Project Sponsor confirms all other members of the Legal and Compliance Committee (LCC) (Data Protection Officer, Compliance Officer, etc.).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Approved LCC ToR v1.0

### 22. Project Manager, in coordination with the LCC Chair, schedules the initial Legal and Compliance Committee (LCC) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- LCC Members Confirmed
- LCC Chair Appointed

### 23. Hold the initial Legal and Compliance Committee (LCC) kick-off meeting to review the project plan, discuss legal and regulatory requirements, and establish communication protocols.

**Responsible Body/Role:** Legal and Compliance Committee (LCC)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- LCC Members Confirmed
- LCC Chair Appointed
- Meeting Scheduled

### 24. Project Manager drafts initial Terms of Reference (ToR) for the Stakeholder Engagement and Communication Group (SECG).

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Draft SECG ToR v0.1

**Dependencies:**

- Project Start ASAP
- Project Plan Approved

### 25. Project Manager circulates Draft SECG ToR for review by Ministry of Economy, Ministry of Foreign Affairs, and external communication experts.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 4

**Key Outputs/Deliverables:**

- Circulation Email
- Draft SECG ToR v0.1

**Dependencies:**

- Draft SECG ToR v0.1

### 26. Project Manager consolidates feedback on the Draft SECG ToR and revises the document.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Feedback Summary
- Draft SECG ToR v0.2

**Dependencies:**

- Circulation of Draft SECG ToR
- Feedback Received

### 27. Project Sponsor formally approves the SECG Terms of Reference.

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Approved SECG ToR v1.0

**Dependencies:**

- Draft SECG ToR v0.2
- Feedback Incorporated

### 28. Project Sponsor appoints the Communication Director as Chair of the Stakeholder Engagement and Communication Group (SECG).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Appointment Confirmation Email

**Dependencies:**

- Approved SECG ToR v1.0

### 29. Project Sponsor confirms all other members of the Stakeholder Engagement and Communication Group (SECG) (Public Relations Manager, Media Relations Manager, etc.).

**Responsible Body/Role:** Project Sponsor

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Membership Confirmation List
- Appointment Confirmation Emails

**Dependencies:**

- Approved SECG ToR v1.0

### 30. Project Manager, in coordination with the SECG Chair, schedules the initial Stakeholder Engagement and Communication Group (SECG) kick-off meeting.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Meeting Invitation
- Agenda

**Dependencies:**

- SECG Members Confirmed
- SECG Chair Appointed

### 31. Hold the initial Stakeholder Engagement and Communication Group (SECG) kick-off meeting to review the project plan, discuss communication strategy, and establish communication protocols.

**Responsible Body/Role:** Stakeholder Engagement and Communication Group (SECG)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Meeting Minutes with Action Items

**Dependencies:**

- SECG Members Confirmed
- SECG Chair Appointed
- Meeting Scheduled