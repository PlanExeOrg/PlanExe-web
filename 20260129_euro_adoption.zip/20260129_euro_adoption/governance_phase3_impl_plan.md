### 1. Project Sponsor (Designated Minister) approves the 'Builder's Blueprint' strategy (Decision 5.2, 5.4, 5.11, 5.12) and formally authorizes the creation of the governance structure.

**Responsible Body/Role:** Project Sponsor (Designated Minister)

**Suggested Timeframe:** Project Week 1 (Day 1)

**Key Outputs/Deliverables:**

- Formal Endorsement of 'Builder's Blueprint'
- Authorization Memo for Governance Setup

**Dependencies:**

- Strategic Decisions finalized and adopted

### 2. Project Manager (Acting Lead) drafts the initial Terms of Reference (ToR) for the Project Steering Committee (PSC) and the Project Management Office (PMO), incorporating governance roles defined in Decision 5.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 1

**Key Outputs/Deliverables:**

- Draft PSC ToR v0.1
- Draft PMO Charter v0.1

**Dependencies:**

- Authorization Memo for Governance Setup

### 3. Project Sponsor officially nominates members and designates the Chair for the Project Steering Committee (PSC).

**Responsible Body/Role:** Project Sponsor (Designated Minister)

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Official PSC Member List & Chair Nomination Letter

**Dependencies:**

- Draft PSC ToR v0.1

### 4. Project Manager (Acting Lead) drafts the initial charters/scopes for the Technical Advisory Group (TAG) and Ethics & Compliance Committee (ECC), ensuring alignment with Decision 9 adherence and Risk 7 mitigation.

**Responsible Body/Role:** Project Manager

**Suggested Timeframe:** Project Week 2

**Key Outputs/Deliverables:**

- Draft TAG Scope v0.1
- Draft ECC Charter v0.1

**Dependencies:**

- Authorization Memo for Governance Setup

### 5. PSC Chair (once appointed) reviews and approves the PSC ToR and PMO Charter, formally authorizing the PMO to proceed with operational setup and recruitment.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 3

**Key Outputs/Deliverables:**

- Approved PSC ToR v1.0
- Approved PMO Charter v1.0

**Dependencies:**

- Official PSC Member List & Chair Nomination Letter
- Draft PSC ToR v0.1

### 6. Project Manager (now operating under PMO Charter) initiates the recruitment/selection process for independent members of the TAG and ECC, utilizing external consultant contacts (Assumption 3, Decision 9).

**Responsible Body/Role:** Project Management Office (PMO)

**Suggested Timeframe:** Project Week 3 - 4

**Key Outputs/Deliverables:**

- Shortlist of TAG/ECC Candidates
- Contracts/Secondment Agreements for External Experts (incl. EU Compliance Consultant)

**Dependencies:**

- Approved PMO Charter v1.0

### 7. PSC Chair approves the final Charters/Scopes for the TAG and ECC based on recommendations from the Project Sponsor.

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved TAG Scope v1.0
- Approved ECC Charter v1.0

**Dependencies:**

- Draft TAG Scope v0.1
- Draft ECC Charter v0.1

### 8. The newly appointed Project Manager officially assumes leadership and establishes project management framework, communication protocols defined in PMO Charter (Decision 5.2).

**Responsible Body/Role:** Project Manager (PMO)

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Established Project Management Tools & Reporting Baseline
- Internal Communication Protocols Document

**Dependencies:**

- Approved PMO Charter v1.0

### 9. Finalize memberships for TAG and ECC. Assign Reporting Officers (Legal Counsel, Compliance Officer) as required by ECC/TAG operational mandates.

**Responsible Body/Role:** Project Manager (PMO) & Project Sponsor

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Final Confirmed Membership Lists for TAG and ECC
- Designation of ECC Independent Compliance Officer

**Dependencies:**

- Shortlist of TAG/ECC Candidates

### 10. Hold the inaugural (kick-off) meeting for the Project Steering Committee (PSC) to confirm governance mandate, review initial priorities (Legal Pathway, ERM Strategy), and approve communication timeline sequencing (Decision 11).

**Responsible Body/Role:** Project Steering Committee (PSC)

**Suggested Timeframe:** Project Week 7

**Key Outputs/Deliverables:**

- Steering Committee Kick-off Meeting Minutes
- Approved High-Level Timeline reflecting pre-ERM II strategy
- Action Item: PMO to schedule regular monthly meetings

**Dependencies:**

- Final Confirmed Membership Lists for TAG and ECC
- Approved PSC ToR v1.0

### 11. Hold inaugural kick-off meetings for the Project Management Office (PMO), Technical Advisory Group (TAG), and Ethics & Compliance Committee (ECC) to establish operating rhythm and immediate engagement priorities (e.g., Legal/Convergence requirements).

**Responsible Body/Role:** Project Manager (PMO) leading kickoff, Committee Chairs overseeing session

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- PMO Kick-off Minutes & Initial Action Log
- TAG Initial Workplan focusing on Convergence Triage (Decision 9)
- ECC Initial Compliance Review Schedule

**Dependencies:**

- Final Confirmed Membership Lists for TAG and ECC
- Established Project Management Tools & Reporting Baseline

### 12. PMO establishes linkage protocols with the Ministry of Finance for budget tracking and contingency fund management (Assumption 2 & 5), ensuring inflation indexing provisions are captured.

**Responsible Body/Role:** Project Management Office (PMO) & Financial Analyst (within PMO)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Budget Monitoring Framework v1.0
- Ring-fenced Contingency Account Protocol Established (DKK 50M+)

**Dependencies:**

- Approved PSC ToR v1.0