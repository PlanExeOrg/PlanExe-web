### 1. Establish an Inter-Ministerial Formation Team to set up the Euro Adoption Steering Committee, Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) and designated Formation Lead

**Suggested Timeframe:** Project Week 1–2

**Key Outputs/Deliverables:**

- Formation Team charter
- Initial membership lists and Terms of Reference drafts
- High-level timeline and governance calendar

**Dependencies:**

- Government decision to pursue euro adoption
- Ministerial mandate and budget allocation

### 2. Draft Terms of Reference (ToR) for the Euro Adoption Steering Committee, Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Formation Lead (with legal and policy support)

**Suggested Timeframe:** Project Week 2–3

**Key Outputs/Deliverables:**

- Draft ToR for each governance body
- Draft RACI and decision matrices

**Dependencies:**

- Formation Team charter
- Initial membership lists

### 3. Circulate draft ToR for review and feedback to nominated members and relevant ministries.

**Responsible Body/Role:** Formation Lead

**Suggested Timeframe:** Project Week 3–4

**Key Outputs/Deliverables:**

- Feedback summary
- Annotated draft ToR

**Dependencies:**

- Draft ToR availability
- Nominated members confirmed

### 4. Finalize and approve Terms of Reference for all governance bodies.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) with ministerial sign-off

**Suggested Timeframe:** Project Week 5

**Key Outputs/Deliverables:**

- Approved ToR for each governance body
- Official appointment letters for initial members

**Dependencies:**

- Completed review and feedback incorporation
- Ministerial endorsement

### 5. Formally appoint and confirm membership of the Euro Adoption Steering Committee, including Chair and independent members.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office)

**Suggested Timeframe:** Project Week 6

**Key Outputs/Deliverables:**

- Membership confirmation notices
- Appointment confirmation email

**Dependencies:**

- Approved ToR
- Ministerial decision

### 6. Formally appoint and confirm membership of the Dual Circulation Management Office, Legal and Treaty Compliance Committee, Stakeholder Engagement and Communication Council, and Risk and Contingency Oversight Board.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office)

**Suggested Timeframe:** Project Week 6–7

**Key Outputs/Deliverables:**

- Membership confirmation notices for all bodies
- Organizational charts

**Dependencies:**

- Approved ToR
- Ministerial decision

### 7. Hold inaugural kick-off meeting for the Euro Adoption Steering Committee to set strategic direction and approve milestone gates.

**Responsible Body/Role:** Euro Adoption Steering Committee (Chair)

**Suggested Timeframe:** Project Week 8

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Approved strategic roadmap and milestone gates

**Dependencies:**

- Membership confirmations
- Approved ToR

### 8. Hold inaugural kick-off meeting for the Dual Circulation Management Office to finalize conversion methodology and operational timelines.

**Responsible Body/Role:** Dual Circulation Management Office (Head of Operations)

**Suggested Timeframe:** Project Week 9

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Operational plan and timeline

**Dependencies:**

- Membership confirmations
- Strategic roadmap from Steering Committee

### 9. Hold inaugural kick-off meeting for the Legal and Treaty Compliance Committee to initiate treaty change and referendum design.

**Responsible Body/Role:** Legal and Treaty Compliance Committee (Chair)

**Suggested Timeframe:** Project Week 10

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Initial legal and treaty workplan

**Dependencies:**

- Membership confirmations
- Strategic roadmap

### 10. Hold inaugural kick-off meeting for the Stakeholder Engagement and Communication Council to launch communication strategy and public preparedness planning.

**Responsible Body/Role:** Stakeholder Engagement and Communication Council (Chair)

**Suggested Timeframe:** Project Week 11

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Communication strategy and calendar

**Dependencies:**

- Membership confirmations
- Initial legal and treaty workplan

### 11. Hold inaugural kick-off meeting for the Risk and Contingency Oversight Board to activate risk register and contingency planning.

**Responsible Body/Role:** Risk and Contingency Oversight Board (Chair)

**Suggested Timeframe:** Project Week 12

**Key Outputs/Deliverables:**

- Kick-off meeting minutes
- Risk register and contingency plan

**Dependencies:**

- Membership confirmations
- Communication strategy

### 12. Conduct a 90-day governance health-check after all bodies are formed and initial meetings held to verify alignment, decision rights, and escalation paths.

**Responsible Body/Role:** Project Sponsor (Prime Minister's Office) with Formation Lead support

**Suggested Timeframe:** Project Week 13–16

**Key Outputs/Deliverables:**

- Governance health-check report
- Corrective action plan (if needed)

**Dependencies:**

- All kick-off meetings completed
- Initial workplans and risk register