**Purpose:** business

**Purpose Detailed:** A structured, ministerial-level plan outlining the legal, political, economic, operational, and communication steps required for Denmark to replace the Danish krone with the euro, respecting the current EU opt-out and requiring treaty change and referendum.

**Topic:** Denmark national transition plan to adopt the euro as national currency