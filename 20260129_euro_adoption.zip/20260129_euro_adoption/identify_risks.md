
## Risk 1 - Regulatory & Permitting
Failure to secure the necessary unanimous agreement from the European Council/Parliament to amend the TEU protocol and lift the Danish opt-out, as required by the chosen 'Formally request an Extraordinary European Council session' strategy.

**Impact:** A minimum delay of 12–24 months in the entire timeline due to being forced onto a less certain legal pathway or requiring domestic ratification processes for a new treaty amendment. Potential political capital burnout.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 4 (Opt-Out Resolution Mechanism Selection): Focus diplomatic efforts immediately on securing bilateral assurances from key member states (e.g., Germany, France) to minimize political resistance during the Council session. Prepare parallel contingency legal arguments based on existing EU treaties in case the protocol amendment fails.

## Risk 2 - Regulatory & Permitting
The Danish Folketinget or the public rejects the required constitutional change/referendum needed to lift the existing opt-out.

**Impact:** Project termination or forced return to a permanent opt-out status. Financial loss of DKK 500M–1B in sunk costs relating to preparatory EU engagement, IT simulations, and initial communication materials.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 11 (Societal Readiness Pacing): Implement continuous, high-quality communication campaigns starting immediately after the 'political decision' to proceed, emphasizing the benefits of adoption, even before the finalized ERM II parity is known. Ensure the 'Public Referendum Design' is structurally simple and widely accepted.

## Risk 3 - Financial/Economic
Failure to meet the primary convergence criteria (e.g., deficit within 3% of GDP) within the required ERM II participation window, leading to a delayed entry approval from the ECB.

**Impact:** Delay of 6–18 months, forcing the government to implement painful, last-minute fiscal adjustments (e.g., unexpected cuts or tax hikes) which can trigger public backlash and increase economic contraction.

**Likelihood:** Medium

**Severity:** High

**Action:** Mitigation via Strategy 9 (Convergence Harmonization Triage): Adopt the most aggressive technical alignment strategy, implementing ECB statistical reporting immediately post-referendum to secure early internal compliance audit capabilities. Strategy 2 for ERM Entry should be chosen to provide a buffer against market misalignment shocks.

## Risk 4 - Technical/Operational
Integration failure or significant delay in Danmarks Nationalbank's core operational systems (e.g., payment systems, reserve management) connecting with Eurosystem infrastructure (e.g., TARGET2).

**Impact:** Inability to participate fully in Eurosystem operations on Euro Day, risking operational isolation or non-compliance with ECB governance requirements. Requires an extra 4–6 months of dedicated technical remediation effort.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mitigation via Strategy 8 (Central Bank Integration): Establish the 'Shadow Integration Team' immediately, operating irrespective of the 'Opt-Out Resolution' timeline, ensuring that technical readiness precedes political certainty, minimizing risk if the referendum passes quickly.

## Risk 5 - Supply Chain/Logistics
Inadequate supply, security failure, or logistical bottlenecks in the distribution/destruction of EUR/DKK cash during the short dual circulation window (assumed 30-60 days due to strain on resources).

**Impact:** Localized cash shortages leading to public panic, increased counterfeiting risk, or extended dual circulation periods due to slow DKK removal, costing an extra DKK 100M in security/storage overhead.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 10 & 6: Contract multiple specialized cash-in-transit firms for dispersion (Strategy 13.1) and commit to an aggressive 30-day dual circulation period (Strategy 6.1) predicated on a massive, front-loaded media campaign to drive immediate consumer acceptance of carrying two currencies.

## Risk 6 - Social/Change Management
Significant public confusion or rejection due to inconsistent pricing, especially among SMEs or vulnerable populations, leading to widespread errors in dual circulation and public trust erosion.

**Impact:** High incidence of consumer disputes or accidental overpayment, potentially forcing the government to enforce complex consumer protection measures retroactively, delaying the final DKK withdrawal timeline by 1–3 months.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 11: Implement rolling, sector-specific educational outreach through municipal centers, focusing efforts *after* the referendum result, but ensuring key operational rules (rounding, conversion) are communicated early via utility providers and tax authorities.

## Risk 7 - Operational/Contractual
Widespread legal disputes regarding the mandatory re-denomination of private, long-term contracts (e.g., housing loans, existing B2B agreements) under the chosen legislative framework.

**Impact:** Significant litigation burden on the judicial system post-Euro Day, potentially requiring emergency legislation or the creation of complex arbitration bodies, delaying full economic normalization by up to 2 years in some sectors.

**Likelihood:** Medium

**Severity:** Medium

**Action:** Mitigation via Strategy 7: Mandate automatic rounding for all existing long-term contracts without negotiation (Strategy 7.1), coupled with robust legal clarity published by the Ministry of Justice well in advance, reinforcing the certainty required by the 'Builder's Blueprint'.

## Risk 8 - Financial/Market Risk
Speculative pressure or market instability arising from the announcement of the DKK's entry parity within ERM II, contradicting the desired 'minimal pre-entry shock' based on Strategy 2 for ERM Entry.

**Impact:** The National Bank being forced to expend significant reserves defending the peg or being forced to adopt a less favorable official entry rate than preferred, leading to negative long-term impact on Danish export competitiveness.

**Likelihood:** Low

**Severity:** High

**Action:** Mitigation via Strategy 12 (Structuring ERM Inclusion): Focus negotiation with the ECB on maintaining the current implied tight binding band during the informal convergence period (Strategy 2 for ERM Entry), using historical alignment as leverage to minimize market surprises during the formal entry.

## Risk 9 - Governance/Resource Management
Decision-making paralysis or resource contention within the 'Joint Ministerial Consultative Body' (Strategy 5.2), where required consensus among multiple ministers slows down urgent operational directives.

**Impact:** Cascading delays across technical and operational workstreams (e.g., IT system harmonization, contract law finalization) due to bottlenecks in required political sign-off, potentially extending the timeline beyond 8 years.

**Likelihood:** High

**Severity:** Medium

**Action:** Mitigation via Strategy 5: While adopting the consultative body, delegate clear thresholds to the chairs of the consultation (PM's office representative) to issue binding directives on logistical and technical matters (e.g., DKK 50M budget allocations) unless an explicit policy conflict is raised by a minister within 7 days.

## Risk summary
The transition plan, adhering to the 'Builder's Blueprint,' faces critical risks concentrated at the intersection of political authorization and economic convergence. The **most critical risks (High Severity/High Impact)** involve **Legal/Regulatory Approval of Opt-Out Removal** (delaying accession) and **Failure to meet ECB Convergence Criteria** (blocking entry). These hinge on external agreements and domestic fiscal discipline, respectively. The third critical area is **Governance Bottlenecks** within the chosen consultative structure, which could translate political certainty into operational delays. Successful mitigation requires aggressive, early diplomatic action regarding the treaty change in parallel with immediate, high-quality technical preparation (Shadow Integration Teams) to bridge the gap between the political decision and the necessary operational reality, accepting the high upfront costs associated with rigorous convergence alignment.